﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using UOF.Common.EntityModel;

namespace UOF.API.Models
{
    public class FormPermissionModel
    {
        public List<FormsNameSettings> FrmsName { get; set; }
        public List<UserRoleSettingsEntity> UserRoles { get; set; }
        public List<FormPermissionSettings> FrmPermission { get; set; }
        
        public bool GetFormPermission(string formCode, string roleCode)
        {
            if (string.IsNullOrWhiteSpace(formCode)) { throw new Exception("form Code needed."); };
            if (roleCode == "SuperAdmin") { return true; };
                dynamic result = null;
                var roleResult = (from roles in UserRoles where roles.RoleCode == roleCode select roles).FirstOrDefault();
                var frmInfo = (from frmName in FrmsName where frmName.FormCode == formCode select new { frmName.FormId, frmName.ParentId }).FirstOrDefault();

                if (frmInfo.ParentId == 0)
                {
                    var isChildExtst = (from frmForm in FrmsName
                                        where frmForm.ParentId == frmInfo.FormId
                                        select frmForm).Any();
                    if (isChildExtst)
                    {
                        result = (from frmName in FrmsName
                                  join frmPermission in  FrmPermission on frmName.FormId equals frmPermission.FormId
                                  where frmName.ParentId == frmInfo.FormId && frmPermission.RoleId == roleResult.RoleId
                                  select FrmPermission).FirstOrDefault();
                    }
                    else
                    {
                        result = (from frmPermission in FrmPermission
                                  where frmPermission.FormId == frmInfo.FormId && frmPermission.RoleId == roleResult.RoleId
                                  select frmPermission).FirstOrDefault();
                    }


                }
                else
                {
                    result = (from frmPermission in FrmPermission
                              where frmPermission.FormId == frmInfo.FormId && frmPermission.RoleId == roleResult.RoleId
                              select frmPermission
                                      ).FirstOrDefault();

                }
                if (result != null)
                    return true;
                else
                    return false;

        }
    }
}