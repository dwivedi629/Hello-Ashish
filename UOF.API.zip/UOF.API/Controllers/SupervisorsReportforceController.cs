﻿using UOF.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using UOF.Business;
using UOF.Common.EntityModel;
using System.Web.Providers.Entities;
using System.Web;
namespace UOF.API.Controllers
{
    public class SupervisorsReportforceController : ApiController
    {
        //
        // GET: /SupervisorsReportforce/

        readonly ILogService LogService = new LogService(typeof(SupervisorsReportforceController));
        public HttpResponseMessage SupervisorsReportforce()
        {
            return Request.CreateResponse(HttpStatusCode.OK);
        }

        #region SupervisorsReportforce

        [HttpPost]
        public HttpResponseMessage SaveSupervisorsReportforceInfo(SupervisorsReportBusinessModel supervisorsReportBusinessModel)
        {
            int formDataId = 0;
            try
            {
                BLSupervisorsReportforce sRBusiness = new BLSupervisorsReportforce();
                formDataId= sRBusiness.SaveSupervisorsReportforceInfo(supervisorsReportBusinessModel);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveSupervisorsReportforceInfo", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, formDataId);
        }

        [HttpPost]
        public HttpResponseMessage GetSupervisorsReportforceInfo(ParameterCriteria cirteria)
        {
            var sRModel = new SupervisorsReportBusinessModel();
            try
            {
                var sRBusiness = new BLSupervisorsReportforce();
                sRModel = sRBusiness.GetSupervisorsReportforceInfo(cirteria);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetSupervisorsReportforceInfo", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Data Not Retrived");
            }
            return Request.CreateResponse(HttpStatusCode.OK, sRModel);
        }

        #endregion

        #region Tracking
        [HttpPost]
        public HttpResponseMessage SaveTracking(TrackingModel model)
        {
            try
            {
                BLSupervisorsReportforce sRBusiness = new BLSupervisorsReportforce();
                sRBusiness.SaveTracking(model);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveTracking", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Data Saved");
        }
        [HttpGet]
        public HttpResponseMessage GetTracking(int FormId, int IncidentId)
        {
            var sRModel = new TrackingModel();
            try
            {
                var sRBusiness = new BLSupervisorsReportforce();
                sRModel = sRBusiness.GetTracking(FormId, IncidentId);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetTracking", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Data Not Retrived");
            }
            return Request.CreateResponse(HttpStatusCode.OK, sRModel);
        }
        #endregion

    }
}
