﻿using UOF.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using UOF.Business;
using UOF.Common.EntityModel;
using UOF.Common.Utilities;
using System.Net.Mail;
namespace UOF.API.Controllers
{
    public class UserController : ApiController
    {
        BLUser userBusiness = null;
        //Need to put Log4net.config file in the api bin
        readonly ILogService LogService = new LogService(typeof(UserController));
        [HttpPost]
        public HttpResponseMessage SaveInvolvedUser(InvolvedUserEntity involvedUserEntity)
        {
            try
            {
                using (userBusiness = new BLUser())
                {
                    //involvedUserEntity.IncidentUserId = 1; //No Idea what is the purpose of this field.
                    //involvedUserEntity.IncidentId = 5; // Hardcoded
                    involvedUserEntity.UserTypeId = (int)Constants.UserType.InvolvedEmployee;

                    if (userBusiness.SaveInvolvedUser(involvedUserEntity))
                    {
                        //sendMailtoInvolvedUsers(involvedUserEntity);
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveInvolvedUser", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Data Saved");
        }



        [HttpPost]
        public HttpResponseMessage SaveSuspectUser(SuspectUserEntity suspectUserEntity)
        {
            try
            {
                using (userBusiness = new BLUser())
                {
                    suspectUserEntity.IncidentUserId = 1; //No Idea what is the purpose of this field.
                    //suspectUserEntity.IncidentId = 5; // Hardcoded
                    suspectUserEntity.UserTypeId = (int)Constants.UserType.Suspect;
                    suspectUserEntity.AddressTypeId = (int)Constants.AddressType.User;
                    userBusiness.SaveSuspectUser(suspectUserEntity);
                }
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveSuspectUser", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, suspectUserEntity.Mode == Convert.ToString(Constants.Mode.Add) ? "Data Saved" : "Data Updated");
        }

        [HttpPost]
        public HttpResponseMessage SaveWitnessUser(WitnessUserEntity witnessUserEntity)
        {
            try
            {
                using (userBusiness = new BLUser())
                {
                    //witnessUserEntity.IncidentUserId = 1; //No Idea what is the purpose of this field.
                    //witnessUserEntity.IncidentId = 5; // Hardcoded
                    //witnessUserEntity.UserTypeId = (int)UserType.EmployeeWitness;
                    witnessUserEntity.AddressTypeId = (int)Constants.AddressType.User;
                    userBusiness.SaveWitnessUser(witnessUserEntity);
                }
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveWitnessUser", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Data Saved");
        }

        [HttpPost]
        public HttpResponseMessage SaveDuputiesInfo(List<WitnessUserEntity> DuputiesEntity)
        {
            try
            {
                using (userBusiness = new BLUser())
                {
                    foreach (WitnessUserEntity Duty in DuputiesEntity)
                    {
                        userBusiness.SaveDuptiesInfo(Duty);
                    }

                }
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveDuputiesInfo", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Data Saved");
        }
        [HttpPost]
        public HttpResponseMessage SaveCanine(CanineEntity canineEntity)
        {
            try
            {
                using (userBusiness = new BLUser())
                {
                    userBusiness.SaveCanineInfo(canineEntity);
                }
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveCanine", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Data Saved");
        }

        /// <summary>
        /// Get IncidentUser
        /// </summary>
        /// <returns>IncidentUsers</returns>
        [HttpGet]
        public HttpResponseMessage GetIncidentUser()
        {
            try
            {
                using (userBusiness = new BLUser())
                {
                    var incidentUserList = userBusiness.GetIncidentUser();
                    if (incidentUserList != null)
                    {
                        return Request.CreateResponse(HttpStatusCode.OK, incidentUserList);
                    }
                    else
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, " incidentUserList Not Found");
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetIncidentUser", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
        }

        /// <summary>
        /// Get IncidentUser by incidentId
        /// </summary>
        /// <param name="incidentId">incidentId</param>
        /// <returns>Incident User</returns>
        [HttpGet]
        public HttpResponseMessage GetIncidentUser(int incidentId)
        {
            try
            {
                using (userBusiness = new BLUser())
                {
                    var incidentUserEntity = userBusiness.GetIncidentUser(incidentId);
                    if (incidentUserEntity != null)
                    {
                        return Request.CreateResponse(HttpStatusCode.OK, incidentUserEntity);
                    }
                    else
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, " incidentUserList Not Found");
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetIncidentUser", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
        }
        [HttpGet]
        public HttpResponseMessage GetUsersByFormId(int IncidentId, int formId)
        {
            try
            {
                using (userBusiness = new BLUser())
                {
                    var incidentUserList = userBusiness.GetUsersByFormId(IncidentId, formId);
                    if (incidentUserList != null)
                    {
                        return Request.CreateResponse(HttpStatusCode.OK, incidentUserList);
                    }
                    else
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, " incidentUserList Not Found");
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetIncidentUserWithName", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
        }


        [HttpGet]
        public HttpResponseMessage GetIncidentUserWithName(int IncidentId)
        {
            try
            {
                using (userBusiness = new BLUser())
                {
                    var incidentUserList = userBusiness.GetIncidentUserWithName(IncidentId);
                    if (incidentUserList != null)
                    {
                        return Request.CreateResponse(HttpStatusCode.OK, incidentUserList);
                    }
                    else
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, " incidentUserList Not Found");
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetIncidentUserWithName", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
        }

        [HttpGet]
        public HttpResponseMessage GetInvolvedUserWithName(int IncidentId)
        {
            try
            {
                using (userBusiness = new BLUser())
                {
                    var involvedUserList = userBusiness.GetInvolvedUserWithName(IncidentId);
                    if (involvedUserList != null)
                    {
                        return Request.CreateResponse(HttpStatusCode.OK, involvedUserList);
                    }
                    else
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, " involvedUserList Not Found");
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetInvolvedUser", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
        }
        [HttpGet]
        public HttpResponseMessage GetAssignedUserWithName(int IncidentId)
        {
            try
            {
                using (userBusiness = new BLUser())
                {
                    var involvedUserList = userBusiness.GetAssignedUserWithName(IncidentId);
                    if (involvedUserList != null)
                    {
                        return Request.CreateResponse(HttpStatusCode.OK, involvedUserList);
                    }
                    else
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, " involvedUserList Not Found");
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetInvolvedUser", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
        }
        [HttpGet]
        public HttpResponseMessage GetReportingEmployees(int IncidentId, string loggedRole)
        {
            try
            {
                using (userBusiness = new BLUser())
                {
                    var involvedUserList = userBusiness.GetReportingEmployees(IncidentId, loggedRole);
                    if (involvedUserList != null)
                    {
                        return Request.CreateResponse(HttpStatusCode.OK, involvedUserList);
                    }
                    else
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, " ReportingEmployees Not Found");
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetReportingEmployees", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
        }
        /// <summary>
        /// Get InvolvedUser
        /// </summary>
        /// <returns>InvolvedUsers</returns>
        [HttpGet]
        public HttpResponseMessage GetInvolvedUser()
        {
            try
            {
                using (userBusiness = new BLUser())
                {
                    var involvedUserList = userBusiness.GetInvolvedUser();
                    if (involvedUserList != null)
                    {
                        return Request.CreateResponse(HttpStatusCode.OK, involvedUserList);
                    }
                    else
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, " involvedUserList Not Found");
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetInvolvedUser", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
        }
        /// <summary>
        /// Get InvolvedUser
        /// </summary>
        /// <param name="incidentId">involvedUserId</param>
        /// <returns>InvolvedUsers</returns>
        [HttpGet]
        public HttpResponseMessage GetInvolvedUser(int incidentId)
        {
            try
            {
                using (userBusiness = new BLUser())
                {
                    var involvedUserEntity = userBusiness.GetInvolvedUser(incidentId);
                    if (involvedUserEntity != null)
                    {
                        return Request.CreateResponse(HttpStatusCode.OK, involvedUserEntity);
                    }
                    else
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, " involvedUserList Not Found");
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetInvolvedUser", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
        }
        /// <summary>
        /// GetInvolvedUser
        /// </summary>
        /// <param name="incidentId"></param>
        /// <param name="incidentUserInvolvedId"></param>
        /// <returns></returns>
        [HttpGet]
        public HttpResponseMessage GetInvolvedUser(int incidentId, int incidentUserInvolvedId)
        {
            try
            {
                using (userBusiness = new BLUser())
                {
                    var involvedUserEntity = userBusiness.GetInvolvedUser(incidentId, incidentUserInvolvedId);
                    if (involvedUserEntity != null)
                    {
                        return Request.CreateResponse(HttpStatusCode.OK, involvedUserEntity);
                    }
                    else
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, " involvedUserEntity Not Found");
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetInvolvedUser", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
        }

        /// <summary>
        /// Get SuspectUser
        /// </summary>
        /// <returns>SuspectUsers</returns>
        [HttpGet]
        public HttpResponseMessage GetSuspectUser(int incidentId)
        {
            try
            {
                using (userBusiness = new BLUser())
                {
                    var suspectUserList = userBusiness.GetSuspectUser(incidentId);
                    if (suspectUserList != null)
                    {
                        return Request.CreateResponse(HttpStatusCode.OK, suspectUserList);
                    }
                    else
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, " SuspectUsers Not Found");
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetSuspectUser", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
        }

        /// <summary>
        /// GetSuspectUser
        /// </summary>
        /// <param name="incidentId"></param>
        /// <param name="incidentUserSuspectId"></param>
        /// <returns></returns>
        [HttpGet]
        public HttpResponseMessage GetSuspectUser(int incidentId, int incidentUserSuspectId)
        {
            try
            {
                using (userBusiness = new BLUser())
                {
                    var suspectUserEntity = userBusiness.GetSuspectUser(incidentId, incidentUserSuspectId);
                    if (suspectUserEntity != null)
                    {
                        return Request.CreateResponse(HttpStatusCode.OK, suspectUserEntity);
                    }
                    else
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, " suspectUserEntity Not Found");
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetSuspectUser", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
        }

        ///// <summary>
        ///// Get WitnessUser
        ///// </summary>
        ///// <returns>WitnessUsers</returns>
        //[HttpGet]
        //public HttpResponseMessage GetWitnessUser()
        //{
        //    try
        //    {
        //        using (userBusiness = new UserBusiness())
        //        {
        //            var witnessUserList = userBusiness.GetWitnessUser();
        //            if (witnessUserList != null)
        //            {
        //                return Request.CreateResponse(HttpStatusCode.OK, witnessUserList);
        //            }
        //            else
        //            {
        //                return Request.CreateErrorResponse(HttpStatusCode.NotFound, " witnessUserList Not Found");
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        LogService.CustomError(ex, "GetWitnessUser", ex.Source, ex.StackTrace);
        //        return Request.CreateResponse(HttpStatusCode.NotAcceptable, "witnessUserList Not Found");
        //    }
        //}
        /// <summary>
        /// Get WitnessUser
        /// </summary>
        /// <param name="incidentId">incidentId</param>
        /// <returns>WitnessUser</returns>
        [HttpGet]
        public HttpResponseMessage GetWitnessUser(int incidentId, int witnessType)
        {
            try
            {
                using (userBusiness = new BLUser())
                {
                    var witnessUserEntity = userBusiness.GetWitnessUser(incidentId, witnessType);
                    if (witnessUserEntity != null)
                    {
                        return Request.CreateResponse(HttpStatusCode.OK, witnessUserEntity);
                    }
                    else
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, "witnessUserList Not Found");
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetWitnessUser by", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
        }
        [HttpGet]
        public HttpResponseMessage GetincidentDupties(int incidentId)
        {
            try
            {
                using (userBusiness = new BLUser())
                {
                    var witnessUserEntity = userBusiness.GetincidentDupties(incidentId);
                    if (witnessUserEntity != null)
                    {
                        return Request.CreateResponse(HttpStatusCode.OK, witnessUserEntity);
                    }
                    else
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, "incident Dupties Not Found");
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetincidentDupties", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
        }
        /// <summary>
        /// GetWitnessUser
        /// </summary>
        /// <param name="incidentId"></param>
        /// <param name="incidentUserWitnessId"></param>
        /// <returns></returns>
        [HttpGet]
        public HttpResponseMessage GetIncidentWitnessUser(int incidentId, int incidentUserWitnessId)
        {
            try
            {
                using (userBusiness = new BLUser())
                {
                    var witnessUserEntity = userBusiness.GetIncidentWitnessUser(incidentId, incidentUserWitnessId);
                    if (witnessUserEntity != null)
                    {
                        return Request.CreateResponse(HttpStatusCode.OK, witnessUserEntity);
                    }
                    else
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, "witnessUserEntity Not Found");
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetWitnessUser by", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
        }
        /// <summary>
        /// AssigntoCommander
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        [HttpPost]
        public HttpResponseMessage AssigntoCommander(List<WitnessUserEntity> Commanders)
        {
            try
            {
                using (userBusiness = new BLUser())
                {
                    userBusiness.AssigntoCommander(Commanders);
                }
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "AssigntoCommander", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Data Saved");
        }
        /// <summary>
        /// AssigntoCommander
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        [HttpPost]
        public HttpResponseMessage AssignPackage(ChangeOwnerModel Commanders)
        {
            try
            {
                using (userBusiness = new BLUser())
                {
                    userBusiness.AssignPackage(Commanders);
                }
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "AssigntoCommander", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Data Saved");
        }
        #region //Just for testing
        [HttpGet]
        public HttpResponseMessage GetInvoldedEmployees(int incidentId, string empId = "0")
        {

            List<InvolvedUserEntity> objIncidentColl = new List<InvolvedUserEntity>();

            for (int i = 1; i < 30; i++)
            {

                objIncidentColl.Add(new InvolvedUserEntity()
                {
                    FirstName = "FName" + i,
                    LastName = "LName",
                    MiddleName = "K",
                    Age = i,
                    City = "HYD",
                    IncidentId = i,
                    EmployeeId = "Emp" + i,

                });
            }

            if (empId != "")
            {
                objIncidentColl = objIncidentColl.FindAll(a => a.EmployeeId == empId && a.IncidentId == incidentId);
            }
            // Write the list to the response body.
            return Request.CreateResponse(HttpStatusCode.OK, objIncidentColl);
        }

        [HttpGet]
        public HttpResponseMessage GetWitness(int incidentUserWitnessId, bool isWitness)
        {
            WitnessUserEntity witnessEntiry = null;
            List<WitnessUserEntity> objIncidentColl = new List<WitnessUserEntity>();

            for (int i = 1; i < 30; i++)
            {

                objIncidentColl.Add(new WitnessUserEntity()
                {
                    FirstName = "FName" + i,
                    LastName = "LName",
                    MiddleName = "K",
                    Age = i,
                    City = "HYD",
                    IncidentId = i,
                    IncidentUserWitnessId = i,
                    IsWitness = isWitness ? Boolean.TrueString : Boolean.FalseString,

                });
            }

            if (incidentUserWitnessId > 0)
            {
                witnessEntiry = objIncidentColl.Where(a => a.IncidentUserWitnessId == incidentUserWitnessId && a.IsWitness == (isWitness ? Boolean.TrueString : Boolean.FalseString)).FirstOrDefault();
                return Request.CreateResponse(HttpStatusCode.OK, witnessEntiry);
            }
            // Write the list to the response body.
            return Request.CreateResponse(HttpStatusCode.OK, objIncidentColl);
        }


        [HttpGet]
        public HttpResponseMessage GetSuspectList(int incidentId)
        {

            List<SuspectUserEntity> objIncidentColl = new List<SuspectUserEntity>();

            for (int i = 1; i < 30; i++)
            {

                objIncidentColl.Add(new SuspectUserEntity()
                {
                    Age = i,
                    IncidentUserSuspectId = i,
                    BookingNumber = i.ToString(),


                });
            }

            // Write the list to the response body.
            return Request.CreateResponse(HttpStatusCode.OK, objIncidentColl);
        }

        [HttpGet]
        public HttpResponseMessage GetStaticalData(int incidentId)
        {
            try
            {
                using (userBusiness = new BLUser())
                {
                    var Statical = userBusiness.GetStaticalData(incidentId);
                    return Request.CreateResponse(HttpStatusCode.OK, Statical);

                }
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetIncidentUser", ex.Source, ex.StackTrace);
                return Request.CreateErrorResponse(HttpStatusCode.NotAcceptable, "Canine Data Not Found");
            }
        }

        [HttpGet]
        public HttpResponseMessage GetCanineData(int incidentId)
        {
            try
            {
                using (userBusiness = new BLUser())
                {
                    var CanineEntity = userBusiness.GetCanineData(incidentId);
                    return Request.CreateResponse(HttpStatusCode.OK, CanineEntity);

                }
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetIncidentUser", ex.Source, ex.StackTrace);
                return Request.CreateErrorResponse(HttpStatusCode.NotAcceptable, "Canine Data Not Found");
            }
        }
        //[HttpGet]
        //public HttpResponseMessage GetInvolvedUsers(int incidentId)
        //{
        //    try
        //    {
        //        using (userBusiness = new BLUser())
        //        {
        //            var users = userBusiness.GetInvolvedUsers(incidentId);
        //            return Request.CreateResponse(HttpStatusCode.OK, users);

        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        LogService.CustomError(ex, "GetInvolvedUsers", ex.Source, ex.StackTrace);
        //        return Request.CreateErrorResponse(HttpStatusCode.NotAcceptable, "Canine Data Not Found");
        //    }
        //}
        //[HttpGet]
        //public HttpResponseMessage GetSuspectUsers(int incidentId)
        //{
        //    try
        //    {
        //        using (userBusiness = new BLUser())
        //        {
        //            var users = userBusiness.GetSuspectUsers(incidentId);
        //            return Request.CreateResponse(HttpStatusCode.OK, users);

        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        LogService.CustomError(ex, "GetSuspectUsers", ex.Source, ex.StackTrace);
        //        return Request.CreateErrorResponse(HttpStatusCode.NotAcceptable, "Canine Data Not Found");
        //    }
        //}
        [HttpGet]
        public HttpResponseMessage GetInvolvedUsersAndSuspects(int incidentId)
        {
            try
            {
                using (userBusiness = new BLUser())
                {
                    var users = userBusiness.GetInvolvedUsersAndSuspects(incidentId);
                    return Request.CreateResponse(HttpStatusCode.OK, users);

                }
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetInvolvedUsersAndSuspects", ex.Source, ex.StackTrace);
                return Request.CreateErrorResponse(HttpStatusCode.NotAcceptable, "Data Not Found");
            }
        }
        #endregion

        [HttpGet]
        public HttpResponseMessage GetSuspectDetails(string bookingNumber)
        {
            if (!string.IsNullOrWhiteSpace(bookingNumber))
            {
                // Write the list to the response body.
                return Request.CreateResponse(HttpStatusCode.OK, new SuspectUserEntity()
                {
                    FirstName = "Asiasiga",
                    LastName = "Umu",
                    MiddleName="Matthew",
                    AkaMiddleName="Matthew",
                    AkaFirstname="Asiasiga",
                    AkaLastname="Umu",
                    City="Lynwood",
                    State="CA",
                    ZipCode="90262",
                    //Height = "511",
                    //Weight = "240",
                    Sex = "M",
                    Dress = "PU",
                    Age = 32,
                    Race = "O",
                    DateOfBirth = Convert.ToDateTime("01/01/1979"),
                    SecurityLevel="1",
                    SpecialHandle = "A;J;F"

                });
            }
            return Request.CreateResponse(HttpStatusCode.OK, true);
        }
        /// <summary>
        /// This method will delete the incident record
        /// </summary>
        /// <param name="incidentId"></param>
        /// <returns>Message</returns>
        [HttpDelete]
        public HttpResponseMessage DeleteUser(int incidentId, int userId, string employeeNumber, int userType)
        {
            try
            {
                using (userBusiness = new BLUser())
                {
                    userBusiness.DeleteUser(incidentId,userId,employeeNumber, userType);
                }
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "DeleteUser", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "User Not deleted");
            }
            return Request.CreateResponse(HttpStatusCode.OK, "User deleted");
        }

    }
}

