﻿using UOF.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using UOF.Business;
using UOF.Common.EntityModel;
using UOF.Common.Utilities;

namespace UOF.API.Controllers
{
    public class ArtifactsController : ApiController
    {
        readonly ILogService LogService = new LogService(typeof(ArtifactsController));

        [HttpGet]
        public HttpResponseMessage GetIncidentArtifacts(int incidentId)
        {
            List<ArtifactEntity> listArtifacts = new List<ArtifactEntity>();
            try
            {
                BLArtifacts artifactsObj = new BLArtifacts();
                listArtifacts = artifactsObj.GetIncidentArtifacts(incidentId);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetIncidentArtifacts", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, listArtifacts);
        }
        //SaveIncidentArtifacts(artEntity)
        [HttpPost]
        public HttpResponseMessage SaveIncidentArtifacts(ArtifactEntity artEntity)
        {
            try
            {
                BLArtifacts artifactsObj = new BLArtifacts();
                artifactsObj.SaveIncidentArtifacts(artEntity);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveIncidentArtifacts", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Data Saved");
        }
    }
}
