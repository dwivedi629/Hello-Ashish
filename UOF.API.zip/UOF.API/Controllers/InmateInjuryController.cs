﻿using UOF.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using UOF.Business;
using UOF.Common.EntityModel;
namespace UOF.API.Controllers
{
    public class InmateInjuryController : ApiController
    {
        //
        // GET: /InmateInjury/
        //Need to put Log4net.config file in the api bin
        readonly ILogService LogService = new LogService(typeof(InmateInjuryController));
        public HttpResponseMessage InmateInjury()
        {
            return Request.CreateResponse(HttpStatusCode.OK);
        }

        [HttpPost]
        public HttpResponseMessage SaveInmateInjuryInfo(InmateInjuryBusinessModel inmateInjuryBusinessModel)
        {
            int formDataId = 0;
            try
            {
                BLInmateInjury inmateInjuryBusinessBusiness = new BLInmateInjury();
                formDataId = inmateInjuryBusinessBusiness.SaveInmateInjury(inmateInjuryBusinessModel);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveInmateInjuryInfo", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, formDataId);
        }

        [HttpPost]
        public HttpResponseMessage GetInmateInjuryInfo(ParameterCriteria cirteria)
        {
            var inmateModel = new InmateInjuryBusinessModel();
            try
            {
                BLInmateInjury inmateInjuryBusinessBusiness = new BLInmateInjury();
                inmateModel = inmateInjuryBusinessBusiness.GetInmateInjury(cirteria);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetInmateInjuryInfo", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Data Not Retrived");
            }
            return Request.CreateResponse(HttpStatusCode.OK, inmateModel);
        }



    }
}
