﻿using UOF.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using UOF.Business;
using UOF.Common.EntityModel;
using UOF.Common.Utilities;

namespace UOF.API.Controllers
{
    public class LookupController : ApiController
    {
        BLLookup lookup = new BLLookup();
        readonly ILogService LogService = new LogService(typeof(LookupController));

        [HttpGet]
        public HttpResponseMessage GetAllLookupInformationforIncident()
        {
            LogService.CustomInfo("GetAllLookupInformationforIncident", "LookupController");
            try
            {
                var GroupInfo = new List<LookupEntity>();
                GroupInfo.AddRange(lookup.GetFacilties());
                GroupInfo.AddRange(lookup.GetStations());
                GroupInfo.AddRange(lookup.GetBureaus());
                var incidentDetail = new LookupData
                {
                    CustodyEventsInfo = lookup.GetCustodyEvents(),
                    BodyPartInfo = lookup.GetBodyPart(),
                    CitiesInfo = lookup.GetCities(),
                    ContactTypesInfo = lookup.GetContactTypes(),
                    PerceivedArmedInfo = lookup.GetPerceivedArmed(),
                    ResistanceInfo = lookup.GetResistance(),
                    LocationofForceInfo = lookup.GetLocationofForce(),
                    MethodsInfo = lookup.GetMethods(),
                    StagingInfo = lookup.GetStaging(),
                    GroupInfoforIR = GroupInfo.OrderBy(a => a.Name).ToList()
                };

                return Request.CreateResponse(HttpStatusCode.OK, incidentDetail);
            }
            // Write the list to the response body.

            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetAllLookupInformationforIncident", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Data Not Retrived");
            }
        }

        [HttpGet]
        public HttpResponseMessage GetAllLookupInformationforSuspect()
        {
            LogService.CustomInfo("GetAllLookupInformationforSuspect", "LookupController");
            try
            {
                var suspectDetail = new LookupData
                {
                    DressInfo = lookup.GetInmateDress(),
                    LocationofForceInfo = lookup.GetLocationofForce(),
                    GenderInfo = lookup.GetSex(),
                    ResistanceInfo = lookup.GetResistance(),
                    SubstanceInfo = lookup.GetSubstance(),
                    PerceivedArmedInfo = lookup.GetPerceivedArmed(),
                    InjuriesInfo = lookup.GetInjuries(),
                    RacesInfo = lookup.GetRacies(),
                    ArmedInfo = lookup.GetArmed(),
                    ConfirmedArmedInfo = lookup.GetConfirmedArmed(),
                    CivilianInjurySeverityInfo = lookup.GetInjurySeverities(),
                    SuspectLocationofForceInfo = lookup.GetSuspectLocationofForce(),
                    MethodsInfo = lookup.GetMethods(),
                    SecurityInfo = lookup.GetSecurityLevel(),
                    SpecialHandleInfo = lookup.GetSpecialHandles()
                };
                return Request.CreateResponse(HttpStatusCode.OK, suspectDetail);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetAllLookupInformationforSuspect", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Data Not Retrived");
            }
        }

        [HttpGet]
        public HttpResponseMessage GetAllLookupInformationforStatsData()
        {
            LogService.CustomInfo("GetAllLookupInformationforStatsData", "LookupController");
            try
            {
                var AllInjuries = lookup.GetInjuries();
                AllInjuries = AllInjuries.Where(x => x.Type == "B" || x.Type == "C").ToList();
                var statsDataDetail = new LookupData
                {
                    BodyPartInfo = lookup.GetBodyPart(),
                    InjuriesInfo = AllInjuries,
                    MethodsInfo = lookup.GetMethods(),
                };
                return Request.CreateResponse(HttpStatusCode.OK, statsDataDetail);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetAllLookupInformationforStatsData", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Data Not Retrived");
            }
        }

        [HttpGet]
        public HttpResponseMessage GetAllLookupInvolvedEmpInfo()
        {
            LogService.CustomInfo("GetAllLookupInvolvedEmpInfo", "LookupController");
            try
            {
                var suspectDetail = new LookupData
                {
                    DressInfo = lookup.GetDress(),
                    SergeantInfo = lookup.GetSergeant(),
                    GenderInfo = lookup.GetSex(),
                    RacesInfo = lookup.GetRacies(),
                    CivilianInjurySeverityInfo = lookup.GetInjurySeverities(),
                    MethodsInfo = lookup.GetMethods(),
                };
                return Request.CreateResponse(HttpStatusCode.OK, suspectDetail);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetAllLookupInvolvedEmpInfo", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Data Not Retrived");
            }
        }
        [HttpGet]
        public HttpResponseMessage GetAllLookupDeputyIncidentReportInfo()
        {
            LogService.CustomInfo("GetAllLookupDeputyIncidentReportInfo", "LookupController");
            try
            {
                var GroupInfo = new List<LookupEntity>();
                GroupInfo.AddRange(lookup.GetFacilties());
                GroupInfo.AddRange(lookup.GetStations());
                GroupInfo.AddRange(lookup.GetBureaus());
                var suspectDetail = new LookupData
                {
                    GenderInfo = lookup.GetSex(),
                    RacesInfo = lookup.GetRacies(),
                    GroupInfoforIR = GroupInfo.OrderBy(a => a.Name).ToList(),
                };
                return Request.CreateResponse(HttpStatusCode.OK, suspectDetail);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetAllLookupDeputyIncidentReportInfo", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Data Not Retrived");
            }
        }

        [HttpGet]
        public HttpResponseMessage GetAllBodyParts()
        {
            LogService.CustomInfo("GetAllBodyParts", "LookupController");
            var lst = lookup.GetBodyPart();
            // Write the list to the response body.
            return Request.CreateResponse(HttpStatusCode.OK, lst);
        }
        [HttpGet]
        public HttpResponseMessage GetAllInjuries()
        {
            LogService.CustomInfo("GetAllInjuries", "LookupController");
            var lst = lookup.GetInjuries();
            // Write the list to the response body.
            return Request.CreateResponse(HttpStatusCode.OK, lst);
        }
        [HttpGet]
        public HttpResponseMessage GetAllMethods()
        {
            LogService.CustomInfo("GetAllMethods", "LookupController");
            var lst = lookup.GetMethods();
            // Write the list to the response body.
            return Request.CreateResponse(HttpStatusCode.OK, lst);
        }
        [HttpGet]
        public HttpResponseMessage GetCities()
        {
            LogService.CustomInfo("GetCities", "LookupController");
            var lst = lookup.GetCities();
            // Write the list to the response body.
            return Request.CreateResponse(HttpStatusCode.OK, lst);
        }

        [HttpGet]
        public HttpResponseMessage GetContactTypes()
        {
            LogService.CustomInfo("GetContactTypes", "LookupController");
            var lst = lookup.GetContactTypes();
            // Write the list to the response body.
            return Request.CreateResponse(HttpStatusCode.OK, lst);
        }
        [HttpGet]
        public HttpResponseMessage GetCustodyEvents()
        {
            LogService.CustomInfo("GetCustodyEvents", "LookupController");
            var lst = lookup.GetCustodyEvents();
            // Write the list to the response body.
            return Request.CreateResponse(HttpStatusCode.OK, lst);
        }
        [HttpGet]
        public HttpResponseMessage GetDress()
        {
            LogService.CustomInfo("GetDress", "LookupController");
            var lst = lookup.GetDress();
            // Write the list to the response body.
            return Request.CreateResponse(HttpStatusCode.OK, lst);
        }
        [HttpGet]
        public HttpResponseMessage GetFacilties()
        {
            LogService.CustomInfo("GetFacilties", "LookupController");
            var lst = lookup.GetFacilties();
            // Write the list to the response body.
            return Request.CreateResponse(HttpStatusCode.OK, lst);
        }
        [HttpGet]
        public HttpResponseMessage GetStations()
        {
            LogService.CustomInfo("GetStations", "LookupController");
            var lst = lookup.GetStations();
            // Write the list to the response body.
            return Request.CreateResponse(HttpStatusCode.OK, lst);
        }
        [HttpGet]
        public HttpResponseMessage GetStaging()
        {
            LogService.CustomInfo("GetStaging", "LookupController");
            var lst = lookup.GetStaging();
            // Write the list to the response body.
            return Request.CreateResponse(HttpStatusCode.OK, lst);
        }
        [HttpGet]
        public HttpResponseMessage GetInjurySeverities()
        {
            LogService.CustomInfo("GetInjurySeverities", "LookupController");
            var lst = lookup.GetInjurySeverities();
            // Write the list to the response body.
            return Request.CreateResponse(HttpStatusCode.OK, lst);
        }
        [HttpGet]
        public HttpResponseMessage GetLocationofForce()
        {
            LogService.CustomInfo("GetLocationofForce", "LookupController");
            var lst = lookup.GetLocationofForce();
            // Write the list to the response body.
            return Request.CreateResponse(HttpStatusCode.OK, lst);
        }
        [HttpGet]
        public HttpResponseMessage GetSuspectLocationofForce()
        {
            LogService.CustomInfo("GetSuspectLocationofForce", "LookupController");
            var lst = lookup.GetSuspectLocationofForce();
            // Write the list to the response body.
            return Request.CreateResponse(HttpStatusCode.OK, lst);
        }
        [HttpGet]
        public HttpResponseMessage GetPerceivedArmed()
        {
            LogService.CustomInfo("GetPerceivedArmed", "LookupController");
            var lst = lookup.GetPerceivedArmed();
            // Write the list to the response body.
            return Request.CreateResponse(HttpStatusCode.OK, lst);
        }
        [HttpGet]
        public HttpResponseMessage GetConfirmedArmed()
        {
            LogService.CustomInfo("GetConfirmedArmed", "LookupController");
            var lst = lookup.GetConfirmedArmed();
            // Write the list to the response body.
            return Request.CreateResponse(HttpStatusCode.OK, lst);
        }
        [HttpGet]
        public HttpResponseMessage GetRacies()
        {
            LogService.CustomInfo("GetRacies", "LookupController");
            var lst = lookup.GetRacies();
            // Write the list to the response body.
            return Request.CreateResponse(HttpStatusCode.OK, lst);
        }
        [HttpGet]
        public HttpResponseMessage GetResistance()
        {
            LogService.CustomInfo("GetResistance", "LookupController");
            var lst = lookup.GetResistance();
            // Write the list to the response body.
            return Request.CreateResponse(HttpStatusCode.OK, lst);
        }
        [HttpGet]
        public HttpResponseMessage GetGender()
        {
            LogService.CustomInfo("GetSex", "LookupController");
            var lst = lookup.GetSex();
            // Write the list to the response body.
            return Request.CreateResponse(HttpStatusCode.OK, lst);
        }
        [HttpGet]
        public HttpResponseMessage GetSubstance()
        {
            LogService.CustomInfo("GetSubstance", "LookupController");
            var lst = lookup.GetSubstance();
            // Write the list to the response body.
            return Request.CreateResponse(HttpStatusCode.OK, lst);
        }
        [HttpGet]
        public HttpResponseMessage GetArmed()
        {
            LogService.CustomInfo("GetArmed", "LookupController");
            var lst = lookup.GetSubstance();
            // Write the list to the response body.
            return Request.CreateResponse(HttpStatusCode.OK, lst);
        }

    }
}
