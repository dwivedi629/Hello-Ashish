﻿using UOF.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using UOF.Business;
using UOF.Common.EntityModel;
using UOF.Common.Utilities;
namespace UOF.API.Controllers
{
    public class IncidentController : ApiController
    {
        BLIncident incidentBusiness = null;
        //Need to put Log4net.config file in the api bin
        readonly ILogService LogService = new LogService(typeof(IncidentController));

        [HttpGet]
        public HttpResponseMessage GetIncidentDetails(int incidentId)
        {
            IncidentEntity incidentEntity = null;
            try
            {
                LogService.CustomInfo("GetIncidentDetails", incidentId.ToString());
                incidentBusiness = new BLIncident();
                incidentEntity = incidentBusiness.Get(incidentId);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetIncidentDetails", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, incidentEntity);
        }

        [HttpGet]
        public HttpResponseMessage GetIncidentDetails()
        {
            LogService.CustomInfo("GetIncidentDetails", "Test");
            incidentBusiness = new BLIncident();
            var incidentList = incidentBusiness.Get();
            // Write the list to the response body.
            return Request.CreateResponse(HttpStatusCode.OK, incidentList);
        }

        [HttpGet]
        public HttpResponseMessage GetUserIncidents(string userId, string userRole)
        {
            incidentBusiness = new BLIncident();
            List<IncidentEntity> incidentList = incidentBusiness.GetUserIncidents(userId, userRole);
            
            //Assigned Forms
            foreach (var item in incidentList)
            {
                item.IncidentStatus = incidentBusiness.GetIncidentFormData(userId, userRole, item.IncidentId);
                // //Explanation Forms
                //foreach (var exp in item.IncidentStatus)
                //{
                //    exp.ExplanationForms = incidentBusiness.GetExplanationFormData(userId, userRole, item.IncidentId, exp.FormId);
                //}
            }
           
           
            // Write the list to the response body.
            return Request.CreateResponse(HttpStatusCode.OK, incidentList);
        }
        [HttpPost]
        public HttpResponseMessage GetExplanationFormData(ExplanationCriteria model)
        {
            incidentBusiness = new BLIncident();
            var incidentList = incidentBusiness.GetExplanationFormData(model.userId, model.userRole, model.incidentId, model.formId);
            // Write the list to the response body.
            return Request.CreateResponse(HttpStatusCode.OK, incidentList);
        }
        [HttpPost]
        public HttpResponseMessage SubmitIncident(int incidentId, string sergeantId)
        {
            try
            {
                incidentBusiness = new BLIncident();
                incidentBusiness.IncidentSubmit(incidentId, sergeantId);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "Submit Incident for WF", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Incident Submited Successfully");
        }

        [HttpGet]
        public HttpResponseMessage GetAllIncidentDetails(int incidentId)
        {
            LogService.CustomInfo("GetAllIncidentDetails", incidentId.ToString());
            incidentBusiness = new BLIncident();
            var incidentList = incidentBusiness.Get(incidentId);// Just for time being for Uday

            // Write the list to the response body.
            return Request.CreateResponse(HttpStatusCode.OK, incidentList);
        }

        [HttpGet]
        public HttpResponseMessage GetEmployeeDetails(string empId)
        {
            if (!string.IsNullOrWhiteSpace(empId))
            {
                // Write the list to the response body.
                return Request.CreateResponse(HttpStatusCode.OK, new InvolvedUserEntity()
                {
                    FirstName = "Smith",
                    LastName = "Mark",
                    MiddleName = "Kennady",
                    Rank = "Test Rank",
                    //Height = "100",
                    //Weight = "200",
                    Sex = "M",
                    Dress = "PU",
                    Age = 32,
                    Race = "B",
                    DateOfBirth = Convert.ToDateTime("01/01/1979"),
                    UnitOfAssignment = "UnitOfAssignment",
                    WorkAssignment = "WorkAssignment",
                    EmailId = "madhu@ctrlcs.com",
                    Shift = "DAY",
                    ShiftType = "OFFDUTY",
                    DepartmentHireDate = Convert.ToDateTime("01/01/1999"),
                    LastPromotionDate = Convert.ToDateTime("01/01/2013"),
                    DepartmentTenureInDays = 100,
                    RankTenureIndays = 200,
                });
            }
            return Request.CreateResponse(HttpStatusCode.OK, true);
        }

        [HttpPost]
        public HttpResponseMessage AssingIncidentForms(AssignForm assignForms)
        {
            var incidentId = 0;
            try
            {
                incidentBusiness = new BLIncident();
                incidentId = incidentBusiness.AssingIncidentForms(assignForms);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "AssingIncidentForms", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }

            var result = new
            {
                Message = "Data Saved",
                IncidentId = incidentId,
            };

            return Request.CreateResponse(HttpStatusCode.OK, result);
        }
        [HttpPost]
        public HttpResponseMessage SaveIncident(IncidentEntity incidentEntity)
        {
            var incidentId = 0;
            try
            {
                incidentBusiness = new BLIncident();
                incidentId = incidentBusiness.SaveIncident(incidentEntity);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveIncident", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }

            var result = new
            {
                Message = incidentEntity.currentMode == Convert.ToString(Constants.Mode.Add) ? "Data Saved" : "Data Updated",
                IncidentId = incidentId,
            };

            return Request.CreateResponse(HttpStatusCode.OK, result);
        }

        [HttpPost]
        public HttpResponseMessage SaveStatiticalData(List<StatisticalEntity> statisticalEntity)
        {
            try
            {
                incidentBusiness = new BLIncident();
                incidentBusiness.SaveStatistical(statisticalEntity);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveIncident", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Data Saved");
        }

        
       
        /// <summary>
        /// This method will delete the incident record
        /// </summary>
        /// <param name="incidentId"></param>
        /// <returns>Message</returns>
        [HttpDelete]
        public HttpResponseMessage DeleteIncident(int incidentId)
        {
            try
            {
                incidentBusiness = new BLIncident();
                incidentBusiness.DeleteIncident(incidentId);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "DeleteIncident", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Data Not deleted");
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Data deleted");
        }

        [HttpGet]
        public HttpResponseMessage GetIncidentFormAssignInfo(int incidentId)
        {
            incidentBusiness = new BLIncident();
            var assignFormInfo = incidentBusiness.GetIncidentFormAssignInfo(incidentId);

            // Write the list to the response body.
            return Request.CreateResponse(HttpStatusCode.OK, assignFormInfo);
        }
        [HttpGet]
        public HttpResponseMessage VerifyURN(string URN)
        {
            int retValue = 0;
            try
            {
                incidentBusiness = new BLIncident();
                retValue = incidentBusiness.VerifyURN(URN);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveIncident", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }

            var result = new
            {
                isExists = retValue > 0 ? true : false,
                incidentId = retValue
            };

            return Request.CreateResponse(HttpStatusCode.OK, result);
        }


        [HttpGet]
        public HttpResponseMessage CheckDuplicateURN(string URN, int incidentId)
        {
            bool isExist = false;
            try
            {
                incidentBusiness = new BLIncident();
                isExist = incidentBusiness.CheckDuplicateURN(URN, incidentId);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "CheckDuplicateURN", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            } 

            return Request.CreateResponse(HttpStatusCode.OK, isExist);
        }

        [HttpGet]
        public HttpResponseMessage GetIncidentData(int incidentId, string userId)
        {
            UoFModel uofModel = new UoFModel();
            try
            {
                incidentBusiness = new BLIncident();
                uofModel = incidentBusiness.GetIncidentData(incidentId, userId);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetIncidentData", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }

            return Request.CreateResponse(HttpStatusCode.OK, uofModel);
        }
        [HttpGet]
        public HttpResponseMessage VerifyCatFormsStatus(int incidentId, int formID)
        {
            bool isExist = false;
            try
            {
                incidentBusiness = new BLIncident();
                isExist = incidentBusiness.VerifyCatFormsStatus(incidentId, formID);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "VerifyCatFormsStatus", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }

            return Request.CreateResponse(HttpStatusCode.OK, isExist);
        }
        //
        /// <summary>
        /// This method will delete the incident record
        /// </summary>
        /// <param name="incidentId"></param>
        /// <returns>Message</returns>
        [HttpDelete]
        public HttpResponseMessage DeleteIncidentForm(int ReviewId)
        {
            try
            {
                incidentBusiness = new BLIncident();
                incidentBusiness.DeleteIncidentForm(ReviewId);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "DeleteIncident", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Data Not deleted");
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Data deleted");
        }

    }
}
