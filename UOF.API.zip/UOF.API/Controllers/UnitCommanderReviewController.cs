﻿using UOF.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using UOF.Business;
using UOF.Common.EntityModel;
using System.Web.Providers.Entities;
using System.Web;

namespace UOF.API.Controllers
{
    public class UnitCommanderReviewController : ApiController
    {
        //
        // GET: /UnitCommanderReview/
        
        //Need to put Log4net.config file in the api bin
        readonly ILogService LogService = new LogService(typeof(UnitCommanderReviewController));
        string strXMLData = string.Empty;
        public HttpResponseMessage UnitCommanderReview()
        {
            return Request.CreateResponse(HttpStatusCode.OK);
        }
        [HttpPost]
        public HttpResponseMessage SaveUCReviewInfo(ReviewsResponse reviewsResponse)
        {
            try
            {
                BLReview reviewBusiness = new BLReview();
                reviewBusiness.SaveUCReviewInfo(reviewsResponse);
                
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "CreateResponse", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Data Saved");
        }

        [HttpGet]
        public HttpResponseMessage GetUCReviewData(ParameterCriteria cirteria)
        {
            ReviewsResponse rvResponse = new ReviewsResponse();
            try
            {
                BLReview reviewBusiness = new BLReview();

                rvResponse = reviewBusiness.GetUCReviewData(cirteria);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetUCReviewData", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Data Not Retrived");
            }
            return Request.CreateResponse(HttpStatusCode.OK, rvResponse);
        }

    }
}
