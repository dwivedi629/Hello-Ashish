﻿using UOF.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using UOF.Business;
using UOF.Common.EntityModel;
using System.Web.Providers.Entities;
using System.Web;
using UOF.API.Models;
using System.Threading.Tasks;

namespace UOF.API.Controllers
{    
    public class SettingsController : ApiController
    {
        readonly ILogService LogService = new LogService(typeof(SettingsController));
        static List<FormsNameSettings> frmsName = null;
        static List<UserRoleSettingsEntity> userRoles = null;
        static List<FormPermissionSettings> frmPermission = null;
        //
        // GET: /Settings/
        [HttpGet]
        /// <summary>
        /// Get List of Roles
        /// </summary>
        /// <returns>list of roles</returns>
        public HttpResponseMessage GetRoles()
        {
            IList<UserRoleSettingsEntity> listOfRoles = null;
            try {
                if (userRoles == null)
                {
                    BLFormPermissionSettings objsettings = new BLFormPermissionSettings();
                    listOfRoles = objsettings.GetRoles();
                }
                else
                {
                    listOfRoles = userRoles;
                }
            } 
            catch (Exception ex)
            {
                LogService.CustomError(ex, "CreateResponse", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Error");
            }
            return Request.CreateResponse(HttpStatusCode.OK, listOfRoles);

        }
        [HttpGet]
        /// <summary>
        /// Get all Forms name
        /// </summary>
        /// <returns>List of forms</returns>
        public HttpResponseMessage GetFormsName()
        {
            IList<FormsNameSettings> listOfformsName = null;
            try
            {
                if (frmsName == null)
                {
                    BLFormPermissionSettings objsettings = new BLFormPermissionSettings();
                    listOfformsName = objsettings.GetFormsName();
                }
                else
                {
                    listOfformsName = frmsName;
                }
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetFormsName", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Error");
            }
            return Request.CreateResponse(HttpStatusCode.OK, listOfformsName);

        }
        [HttpGet]

        /// <summary>
        /// Get all role's permission
        /// </summary>
        /// <returns>form permission</returns>
        public HttpResponseMessage GetFormPermission()
        {
            IList<FormPermissionSettings> listOfformsP = null;
            try
            {
                if (frmPermission == null)
                {
                    BLFormPermissionSettings objsettings = new BLFormPermissionSettings();
                    listOfformsP = objsettings.GetFormPermission();
                }
                else
                {
                    listOfformsP = frmPermission;
                }
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetFormPermission", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Error");
            }
            return Request.CreateResponse(HttpStatusCode.OK, listOfformsP);

        }
        [HttpGet]
        /// <summary>
        /// Get all role's permission
        /// </summary>
        /// <param name="formCode"></param>
        /// <param name="roleCode"></param>
        /// <returns>true or false</returns>
        public HttpResponseMessage GetFormPermission(string formCode, string roleCode)
        {
            bool result = false;
            try
            {
                FormPermissionModel objsettings = new FormPermissionModel();
                objsettings.FrmPermission = frmPermission;
                objsettings.FrmsName = frmsName;
                objsettings.UserRoles = userRoles;
                result = objsettings.GetFormPermission(formCode, roleCode);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetFormPermission", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Error");
            }
            return Request.CreateResponse(result ? HttpStatusCode.OK : HttpStatusCode.NotAcceptable, result);

        }

        [HttpGet]
        /// <summary>
        /// Get all role's permission
        /// </summary>
        /// <returns>ok</returns>
        public HttpResponseMessage GetAllRequiredEntities()
        {
            bool result = false;
            try
            {
                BLFormPermissionSettings objsettings = new BLFormPermissionSettings();
                Task<List<FormsNameSettings>> taskFormName = Task.Factory.StartNew(() => objsettings.GetFormsName());
                Task<List<UserRoleSettingsEntity>> taskRoles = Task.Factory.StartNew(() => objsettings.GetRoles());
                Task<List<FormPermissionSettings>> taskFormPermission = Task.Factory.StartNew(() => objsettings.GetFormPermission());
                Task.WaitAll(taskFormName, taskFormPermission, taskRoles);

                frmsName = taskFormName.Result;
                userRoles = taskRoles.Result;
                frmPermission = taskFormPermission.Result;
                result = true;
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetFormPermission", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Error");
            }
            return Request.CreateResponse(result ? HttpStatusCode.OK : HttpStatusCode.NotAcceptable, result);
        }

        [HttpPost]
        /// <summary>
        /// Save all form based permissions
        /// </summary>
        /// <param name="objfrmPermission"></param>
        /// <returns>result, true or false</returns>
        public HttpResponseMessage SaveFormPermissions(List<FormPermissionSettings> objfrmPermission)
        {
            bool result = false;
            try
            {
                BLFormPermissionSettings objsettings = new BLFormPermissionSettings();
                result = objsettings.SaveFormPermissions(objfrmPermission);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveFormPermissions", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Error");
            }
            return Request.CreateResponse(HttpStatusCode.OK, result);
        }
        [HttpPost]
        /// <summary>
        /// Save all form based permissions
        /// </summary>
        /// <param name="objfrmPermission"></param>
        /// <returns>result, true or false</returns>
        public HttpResponseMessage SaveRole(UserRoleSettingsEntity roleEntity)
        {
            bool result = false;
            try
            {
                BLFormPermissionSettings objsettings = new BLFormPermissionSettings();
                result = objsettings.SaveRole(roleEntity);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveRole", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Error");
            }
            return Request.CreateResponse(HttpStatusCode.OK, result);
        }
        //GetIncidentForms
        [HttpGet]
        /// <summary>
        /// GetIncidentForms
        /// </summary>
        /// <returns>ok</returns>
        public HttpResponseMessage GetIncidentForms(string URN)
        {
            try
            {
                BLFormPermissionSettings objsettings = new BLFormPermissionSettings();
                var incidentList = objsettings.GetIncidentFormData(URN);
                return Request.CreateResponse(HttpStatusCode.OK, incidentList);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetFormPermission", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Error");
            }
        }
        [HttpGet]
        /// <summary>
        /// GetPackageInfo
        /// </summary>
        /// <returns>ok</returns>
        public HttpResponseMessage GetPackageInfo(string URN)
        {
            try
            {
                BLFormPermissionSettings objsettings = new BLFormPermissionSettings();
                var incidentList = objsettings.GetPackageInfo(URN);
                return Request.CreateResponse(HttpStatusCode.OK, incidentList);
              
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetFormPermission", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Error");
            }
        }
        [HttpPost]
        /// <summary>
        /// Save all form based permissions
        /// </summary>
        /// <param name="objfrmPermission"></param>
        /// <returns>result, true or false</returns>
        public HttpResponseMessage ChangeOwnerShip(ChangeOwnerModel model)
        {
            bool result = false;
            try
            {
                BLFormPermissionSettings objsettings = new BLFormPermissionSettings();
                result = objsettings.ChangeOwnerShip(model);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveRole", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Error");
            }
            return Request.CreateResponse(HttpStatusCode.OK, result);
        }

    }
}
