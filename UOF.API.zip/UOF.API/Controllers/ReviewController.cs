﻿using UOF.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using UOF.Business;
using UOF.Common.EntityModel;
using System.Web.Providers.Entities;
using System.Web;


namespace UOF.API.Controllers
{
    public class ReviewController : ApiController
    {

        string strXMLData = string.Empty;
        //
        // GET: /WCReview/
        //Need to put Log4net.config file in the api bin
        readonly ILogService LogService = new LogService(typeof(ReviewController));
        public HttpResponseMessage Review()
        {
            return Request.CreateResponse(HttpStatusCode.OK);
        }

        #region Watch Commander Section

        [HttpPost]
        public HttpResponseMessage SaveWCReviewInfo(ReviewsResponse model)//List<ReviewBusinessModel> model)
        {
            int FormDataId = 0;
            try
            {
                BLReview reviewBusiness = new BLReview();
                FormDataId = reviewBusiness.SaveWCReviewInfo(model);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveWCReviewInfo", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, FormDataId);
        }

        [HttpPost]
        public HttpResponseMessage GetWCReviewData(ParameterCriteria cirteria)
        {
            var rvResponse = new ReviewsResponse();
            try
            {
                BLReview reviewBusiness = new BLReview();
                rvResponse = reviewBusiness.GetWCReviewData(cirteria);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetWCReviewData", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Data Not Retrived");
            }
            return Request.CreateResponse(HttpStatusCode.OK, rvResponse);
        }

        #endregion

        #region Unit Commander Section

        [HttpPost]
        public HttpResponseMessage SaveUCReviewInfo(ReviewsResponse model)
        {
            int FormDataId = 0;
            try
            {
                BLReview reviewBusiness = new BLReview();
                FormDataId = reviewBusiness.SaveUCReviewInfo(model);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveUCReviewInfo", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, FormDataId);
        }

        [HttpPost]
        public HttpResponseMessage GetUCReviewData(ParameterCriteria cirteria)
        {
            var rvResponse = new ReviewsResponse();
            try
            {
                BLReview reviewBusiness = new BLReview();
                rvResponse = reviewBusiness.GetUCReviewData(cirteria);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetUCReviewData", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Data Not Retrived");
            }
            return Request.CreateResponse(HttpStatusCode.OK, rvResponse);
        }

        #endregion

        #region  Commander Section
        [HttpPost]
        public HttpResponseMessage SaveCommanderReviewInfo(ReviewsResponse model)
        {
            int FormDataId = 0;
            try
            {
                BLReview reviewBusiness = new BLReview();
                FormDataId = reviewBusiness.SaveCommanderReviewInfo(model);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveCommanderReviewInfo", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, FormDataId);
        }

        [HttpPost]
        public HttpResponseMessage GetCommanderReviewData(ParameterCriteria cirteria)
        {
            var rvResponse = new ReviewsResponse();
            try
            {
                BLReview reviewBusiness = new BLReview();
                rvResponse = reviewBusiness.GetCommanderReviewData(cirteria);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetCommanderReviewData", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Data Not Retrived");
            }
            return Request.CreateResponse(HttpStatusCode.OK, rvResponse);
        }

        #endregion


        #region Assign Cat3 to WC
        [HttpPost]
        public HttpResponseMessage AssignCat3(WitnessUserEntity WC)
        {
            var rvResponse = new ReviewsResponse();
            try
            {
                BLReview reviewBusiness = new BLReview();
                reviewBusiness.AssignCat3(WC);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetWCReviewData", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Category 3 Incident is assigned");
        }

        #endregion

        [HttpGet]
        public HttpResponseMessage AssigntoIAB(int incidentId)
        {
            bool retValue;
            try
            {
                BLReview reviewBusiness = new BLReview();
                retValue = reviewBusiness.AssigntoIAB(incidentId);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "AssigntoIAB", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }

            return Request.CreateResponse(HttpStatusCode.OK, retValue);
        }

        [HttpGet]
        public HttpResponseMessage SentToCFRT(string emailId, int IncidentId, string LoggedInRole)
        {
            var rvResponse = new ReviewsResponse();
            try
            {
                BLReview reviewBusiness = new BLReview();
                reviewBusiness.SentToCFRT(emailId, IncidentId, LoggedInRole);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SentoCFRT", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Incident is Sent to CFRT");
        }
        [HttpPost]
        public HttpResponseMessage RolloutToChief(int incidentId)
        {
            try
            {
                BLReview reviewBusiness = new BLReview();
                reviewBusiness.RolloutToChief(incidentId);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SentoCFRT", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Rollout to Chief Successfull");
        }
    }
}
