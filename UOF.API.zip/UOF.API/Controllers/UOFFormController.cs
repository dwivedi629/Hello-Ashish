﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using UOF.Business;
using UOF.Common.EntityModel;
using UOF.Common.Utilities;
using UOF.Logging;

namespace UOF.API.Controllers
{
    public class UOFFormController : ApiController
    {
        readonly ILogService LogService = new LogService(typeof(UOFFormController));
        public HttpResponseMessage Narrative()
        {
            return Request.CreateResponse(HttpStatusCode.OK);
        }
        [HttpPost]
        public HttpResponseMessage SaveUoFNarrative(UoFNarrativeEntityModel narrativeModel)
        {
            int FormDataId = 0;
            try
            {
                BLNarrative narrativeBusiness = new BLNarrative();
                FormDataId=narrativeBusiness.SaveNarrative(narrativeModel);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveUoFNarrative", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, FormDataId);
        }

        [HttpPost]
        public HttpResponseMessage GetUoFNarrativeInfo(ParameterCriteria cirteria)
        {
            UoFNarrativeEntityModel narrativeModel = new UoFNarrativeEntityModel();
            try
            {
                BLNarrative narrativeBusiness = new BLNarrative();
                narrativeModel = narrativeBusiness.GetNarrative(cirteria);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetUoFNarrativeInfo", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Data Not Retrived");
            }
            return Request.CreateResponse(HttpStatusCode.OK, narrativeModel);
        }

        [HttpPost]
        public HttpResponseMessage saveReviewNoticeDetails(UOFReviewNoticeBusinessModel reviewNoticeModel)
        {
            try
            {
                BLUoFForm uofform = new BLUoFForm();
                uofform.SaveReviewNotice(reviewNoticeModel);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "saveReviewNoticeDetails", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Data Saved");
        }
        [HttpGet]
        public HttpResponseMessage GetReviewNotice(int FormId, int IncidentId, string empId)
        {
            UOFReviewNoticeBusinessModel model = new UOFReviewNoticeBusinessModel();
            try
            {
                BLUoFForm uofform = new BLUoFForm();
                model = uofform.GetReviewNotice(FormId, IncidentId, empId);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetReviewNotice", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Data Not Retrived");
            }
            return Request.CreateResponse(HttpStatusCode.OK, model);
        }
        [HttpGet]
        public HttpResponseMessage ReadyforPackage(int incidentId, string rank)
        {
            string isReady = string.Empty;
            try
            {
                BLUoFForm uofform = new BLUoFForm();
                isReady = uofform.ReadyforPackage(incidentId, Convert.ToInt32(rank));
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "ReadyforPackage", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Package validation Failed");
            }
            return Request.CreateResponse(HttpStatusCode.OK, isReady);
        }
        [HttpPost]
        public HttpResponseMessage SaveOperationForceReview(OperationsForceReview forceModel)
        {
            int formDataId = 0;
            try
            {
                BLUoFForm UoFForm = new BLUoFForm();
                formDataId= UoFForm.SaveForceReview(forceModel);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveUoFNarrative", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, formDataId);
        }
        [HttpPost]
        public HttpResponseMessage GetForceReview(ParameterCriteria cirteria)
        {
            OperationsForceReview model = new OperationsForceReview();
            try
            {
                BLUoFForm uofform = new BLUoFForm();
                model = uofform.GetForceReview(cirteria);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetReviewNotice", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Data Not Retrived");
            }
            return Request.CreateResponse(HttpStatusCode.OK, model);
        }
        // [HttpGet]
        //public HttpResponseMessage GetSupervisorsReportforceInfo(int FormId, int IncidentId, string empId)
        //{
        //    SupervisorsReportBusinessModel model = new SupervisorsReportBusinessModel();
        //    try
        //    {
        //        BLUoFForm uofform = new BLUoFForm();
        //        model = uofform.GetReviewNotice(FormId,  IncidentId,  empId);
        //    }
        //    catch (Exception ex)
        //    {
        //        LogService.CustomError(ex, "GetReviewNotice", ex.Source, ex.StackTrace);
        //        return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Data Not Retrived");
        //    }
        //    return Request.CreateResponse(HttpStatusCode.OK, model);
        //}

        [HttpPost]
        public HttpResponseMessage SaveMedicalReport(MedicalEntity entity)
        {
            int FormDataId = 0;
            try
            {
                BLUoFForm UoFForm = new BLUoFForm();
                FormDataId = UoFForm.SaveMedicalReport(entity);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveMedicalReport", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, FormDataId);
        }
        [HttpPost]
        public HttpResponseMessage GetMedicalReport(ParameterCriteria cirteria)
        {
            MedicalEntity model = new MedicalEntity();
            try
            {
                BLUoFForm uofform = new BLUoFForm();
                model = uofform.GetMedicalReport(cirteria);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetMedicalReport", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Data Not Retrived");
            }
            return Request.CreateResponse(HttpStatusCode.OK, model);
        }
        [HttpPost]
        public HttpResponseMessage SaveDeputyMemo(UOFMemo entity)
        {
            int FormDataId = 0;
            try
            {
                BLUoFForm UoFForm = new BLUoFForm();
                FormDataId = UoFForm.SaveDeputyMemo(entity);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveDeputyMemo", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, FormDataId);
        }

        [HttpPost]
        public HttpResponseMessage GetMemoDetails(ParameterCriteria cirteria)
        {
            UOFMemo model = new UOFMemo();
            try
            {
                BLUoFForm uofform = new BLUoFForm();
                model = uofform.GetMemoDetails(cirteria);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetMemoDetails", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Data Not Retrived");
            }
            return Request.CreateResponse(HttpStatusCode.OK, model);
        }
        [HttpPost]
        public HttpResponseMessage SaveSupplementalData(SupplementalModel entity)
        {
            int FormDataId = 0;
            try
            {
                BLUoFForm UoFForm = new BLUoFForm();
                FormDataId = UoFForm.SaveSupplementalData(entity);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveSupplementalData", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, FormDataId);
        }
        [HttpPost]
        public HttpResponseMessage GetSupplementalDetails(ParameterCriteria cirteria)
        {
            SupplementalModel model = new SupplementalModel();
            try
            {
                BLUoFForm uofform = new BLUoFForm();
                model = uofform.GetSupplementalDetails(cirteria);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetSupplementalDetails", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Data Not Retrived");
            }
            return Request.CreateResponse(HttpStatusCode.OK, model);
        }
        [HttpPost]
        public HttpResponseMessage SaveIABDetails(IABModel entity)
        {
            int FormDataId = 0;
            try
            {
                BLUoFForm UoFForm = new BLUoFForm();
                FormDataId= UoFForm.SaveIABDetails(entity);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveIABDetails", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, FormDataId);
        }
        [HttpGet]
        public HttpResponseMessage GetIABDetails(int FormId, int IncidentId, string DeputyId)
        {
            IABModel model = new IABModel();
            try
            {
                BLUoFForm uofform = new BLUoFForm();
                model = uofform.GetIABDetails(FormId, IncidentId, DeputyId);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetIABDetails", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Data Not Retrived");
            }
            return Request.CreateResponse(HttpStatusCode.OK, model);
        }
        [HttpPost]
        public HttpResponseMessage SaveCADetails(CAEntity entity)
        {
            int FormDataId = 0;
            try
            {
                BLUoFForm UoFForm = new BLUoFForm();
                FormDataId= UoFForm.SaveCADetails(entity);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveCADetails", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, FormDataId);
        }
        [HttpPost]
        public HttpResponseMessage GetCADetails(ParameterCriteria cirteria)
        {
            CAEntity model = new CAEntity();
            try
            {
                BLUoFForm uofform = new BLUoFForm();
                model = uofform.GetCADetails(cirteria);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetCADetails", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Data Not Retrived");
            }
            return Request.CreateResponse(HttpStatusCode.OK, model);
        }

        [HttpPost]
        public HttpResponseMessage SaveCSDetails(CSEntity entity)
        {
            int FormDataId = 0;
            try
            {
                var UoFForm = new BLUoFForm();
                FormDataId = UoFForm.SaveCSDetails(entity);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveCSDetails", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, FormDataId);
        }
        [HttpPost]
        public HttpResponseMessage GetCSDetails(ParameterCriteria cirteria)
        {
            var model = new CSEntity();
            try
            {
                var uofform = new BLUoFForm();
                model = uofform.GetCSDetails(cirteria);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetCSDetails", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Data Not Retrived");
            }
            return Request.CreateResponse(HttpStatusCode.OK, model);
        }

        [HttpGet]
        public HttpResponseMessage GetFormURL(int formId)
        {
            UoFFormEntity model = new UoFFormEntity();
            try
            {
                BLUoFForm uofform = new BLUoFForm();
                model = uofform.GetFormURL(formId);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetFormURL", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Data Not Retrived");
            }
            return Request.CreateResponse(HttpStatusCode.OK, model);
        }
        [HttpPost]
        public HttpResponseMessage ApproveorReject(ReviewEntity entity)
        {
            try
            {
                BLUoFForm UoFForm = new BLUoFForm();
                UoFForm.ApproveorReject(entity);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "ApproveorReject", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Data Saved");
        }


        [HttpGet]
        public HttpResponseMessage FormStatus(int formId, int incidentId, string reviewerId, string reviewerRole, int IncidentReviewId)
        {

            try
            {
                BLUoFForm UoFForm = new BLUoFForm();
                var result = new
                {
                    response = true,
                    frmStatus = UoFForm.FormStatus(formId, incidentId, reviewerId, reviewerRole, IncidentReviewId),
                };
                return Request.CreateResponse(HttpStatusCode.OK, result);
            }
            catch (Exception ex)
            {
                var result = new
                {
                    response = false,
                    frmStatus = "",
                };
                LogService.CustomError(ex, "FormStatus", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, result);
            }

        }
        [HttpPost]
        public HttpResponseMessage SaveReviewComments(ReviewCommentModel entity)
        {
            try
            {
                BLUoFForm UoFForm = new BLUoFForm();
                UoFForm.SaveReviewComments(entity);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveReviewComments", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Data Saved");
        }
        [HttpPost]
        public HttpResponseMessage SaveIncidentAlert(IncidentAlertModel entity)
        {
            try
            {
                BLUoFForm UoFForm = new BLUoFForm();
                UoFForm.SaveIncidentAlert(entity);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveIncidentAlert", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Data Saved");
        }
        [HttpPost]
        public HttpResponseMessage SaveMCJAlert(MCJAlertModel entity)
        {
            try
            {
                BLUoFForm UoFForm = new BLUoFForm();
                UoFForm.SaveMCJAlert(entity);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveMCJAlert", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Data Saved");
        }
        [HttpGet]
        public HttpResponseMessage GetIncidentAlerDetails(int FormId = 0, int IncidentId = 0, string DeputyId = "")
        {
            var model = new IncidentAlertModel();
            try
            {
                var uofform = new BLUoFForm();
                model = uofform.GetIncidentAlerDetails(FormId, IncidentId, DeputyId);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetIncidentAlerDetails", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Data Not Retrived");
            }
            return Request.CreateResponse(HttpStatusCode.OK, model);
        }
        [HttpGet]
        public HttpResponseMessage GetMCJAlertDetails(int FormId = 0, int IncidentId = 0, string DeputyId = "")
        {
            var model = new MCJAlertModel();
            try
            {
                var uofform = new BLUoFForm();
                model = uofform.GetMCJAlertDetails(FormId, IncidentId, DeputyId);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetMCJAlertDetails", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Data Not Retrived");
            }
            return Request.CreateResponse(HttpStatusCode.OK, model);
        }
        [HttpGet]
        public HttpResponseMessage GetReportedForms(int IncidentId, string reportedId)
        {
            var model = new List<LookupEntity>();
            try
            {
                var uofform = new BLUoFForm();
                model = uofform.GetReportedForms(IncidentId, reportedId);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetReportedForms", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Data Not Retrived");
            }
            return Request.CreateResponse(HttpStatusCode.OK, model);
        }

        #region Report Methods
        [HttpGet]
        public HttpResponseMessage GetTrackingDetails(int FormId, int IncidentId)
        {
            var model = new TrackingModel();
            try
            {
                var uofform = new BLUoFForm();
                model = uofform.GetTrackingDetails(FormId, IncidentId);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetTrackingDetails", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Data Not Retrived");
            }
            return Request.CreateResponse(HttpStatusCode.OK, model);
        }

        #endregion
        [HttpPost]
        public HttpResponseMessage SaveChangeRole(ChangeRoleEntity entity)
        {
            try
            {
                BLUoFForm UoFForm = new BLUoFForm();
                UoFForm.SaveChangeRole(entity);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveChangeRole", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Role changed successfully");
        }
    }
}
