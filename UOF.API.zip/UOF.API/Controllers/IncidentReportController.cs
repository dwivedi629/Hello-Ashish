﻿using UOF.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using UOF.Business;
using UOF.Common.EntityModel;
using Newtonsoft.Json.Linq;

namespace UOF.API.Controllers
{
    public class IncidentReportController : ApiController
    {

        readonly ILogService LogService = new LogService(typeof(IncidentReportController));
        //
        // GET: /IncidentReport/

        public HttpResponseMessage IncidentReport()
        {
            return Request.CreateResponse(HttpStatusCode.OK);
        }

        [HttpPost]
        public HttpResponseMessage SaveDeputyIncidentReport(DeputyIncidentReportBusinessModel jsonData)
        {
            int formDataId = 0;
            try
            {
                var BLDeputyIncidentReport = new BLDeputyIncidentReport();
                formDataId= BLDeputyIncidentReport.SaveDeputyIncidentReport(jsonData);
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveDeputyIncidentReport", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, ex.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }
            return Request.CreateResponse(HttpStatusCode.OK, formDataId);
        }


        [HttpPost]
        public HttpResponseMessage GetDeputyIncidentReport(ParameterCriteria cirteria)
        {
            var DeputyModel = new DeputyIncidentReportBusinessModel();
            try
            {
                var BLDeputyIncidentReport = new BLDeputyIncidentReport();
                DeputyModel = BLDeputyIncidentReport.GetDeputyIncidentReport(cirteria);
                if (DeputyModel != null)
                {
                    if (DeputyModel.VictimModel != null && DeputyModel.VictimModel.Count > 0)
                       DeputyModel.VictimModel=DeputyModel.VictimModel.OrderBy(a => a.VictimSerialNumber).ToList();

                    if (DeputyModel.VehicleModel != null && DeputyModel.VehicleModel.Count > 0)
                        DeputyModel.VehicleModel=DeputyModel.VehicleModel.OrderBy(a => a.VehicleSerialNumber).ToList();

                    if (DeputyModel.SuspectModel != null && DeputyModel.SuspectModel.Count > 0)
                       DeputyModel.SuspectModel =DeputyModel.SuspectModel.OrderBy(a => a.SuspectSerialNumber).ToList();
                }
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetDeputyIncidentReport", ex.Source, ex.StackTrace);
                return Request.CreateResponse(HttpStatusCode.NotAcceptable, "Data Not Retrived");
            }
            return Request.CreateResponse(HttpStatusCode.OK, DeputyModel);
        }

    }
}
