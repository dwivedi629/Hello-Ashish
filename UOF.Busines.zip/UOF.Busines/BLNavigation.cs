﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.DataAccess.DbRepository;

namespace UOF.Business
{
    public class BLNavigation
    {
        public List<NavigationEntity> getMenuDetails(int role)
        {
            var navigation=new NavigationRepository();
            return navigation.getMenuDetails(role);
        }

    }
}
