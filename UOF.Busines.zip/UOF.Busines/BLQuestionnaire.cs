﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.DataAccess.DbRepository;

namespace UOF.Business
{
    public class BLQuestionnaire
    {

        #region Dont Delete the code as this cod eis for questionnare part demo " Ashish"  

        private QuestionnaireRepository _questionnaireModel=null;
        public QuestionnaireRepository questionnaireModel
        {
            get
            {
                if (_questionnaireModel==null)
                _questionnaireModel=new QuestionnaireRepository ();
                return _questionnaireModel;
            }
            
        }


        public bool SaveQuestionnaire(List<QuestionnareModel> model, ref string strXML)
        {
            return questionnaireModel.SaveQuestionnaire(model, ref strXML);
        }

        public void GetQuestionnaireBy(int id)
        {
             //questionnaireModel.GetQuestionnaireBy(id);
        }

        public QuestionSet GetQuestionnaire(string strXML)
        {
            return questionnaireModel.GetQuestionnaire(strXML);
        }
    }

    public class questionSet
    {
        public int MyProperty { get; set; }
    }

   #endregion 
}
