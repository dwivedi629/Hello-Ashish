﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.DataAccess.DbRepository;

namespace UOF.Business
{
    public class BLInmateInjury
    {
        InmateInjuryRepository inmateInjuryModel = new InmateInjuryRepository();
        public int SaveInmateInjury(InmateInjuryBusinessModel inmateInjuryBusinessModel)
        {
            return inmateInjuryModel.SaveInmateInjury(inmateInjuryBusinessModel);
        }

        public InmateInjuryBusinessModel GetInmateInjury(ParameterCriteria cirteria)
        {
            return inmateInjuryModel.GetInmateInjury(cirteria);
        }
    }
}
