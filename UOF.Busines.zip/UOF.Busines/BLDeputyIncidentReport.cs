﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.DataAccess.DbRepository;

namespace UOF.Business
{
    public class BLDeputyIncidentReport
    {
        DeputyIncidentReportRepository DeputyIRRepository = new DeputyIncidentReportRepository();
        public int SaveDeputyIncidentReport(DeputyIncidentReportBusinessModel DeputyIReportBusinessModel)
        {
            return DeputyIRRepository.SaveDeputyIncidentReport(DeputyIReportBusinessModel);
        }

        public DeputyIncidentReportBusinessModel GetDeputyIncidentReport(ParameterCriteria cirteria)
        {
            return DeputyIRRepository.GetDeputyIncidentReport(cirteria);
        }
    }
}
