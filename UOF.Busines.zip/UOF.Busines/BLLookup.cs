﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.DataAccess.DbRepository;

namespace UOF.Business
{
    public class BLLookup
    {
        LookupRespository repo = new LookupRespository();
        public List<LookupEntity> GetBodyPart()
        {
            return repo.GetBodyPart();
        }
        public List<LookupEntity> GetInjuries()
        {
            return repo.GetInjuries();
        }
        public List<LookupEntity> GetMethods()
        {
            return repo.GetMethods();
        }
        public List<LookupEntity> GetSecurityLevel()
        {
            return repo.GetSecurityLevel();
        }
        public List<LookupEntity> GetSpecialHandles()
        {
            return repo.GetSpecialHandles();
        }
        public List<LookupEntity> GetCities()
        {
            return repo.GetCities();
        }
        public List<LookupEntity> GetContactTypes()
        {
            return repo.GetContactTypes();
        }
        public List<LookupEntity> GetCustodyEvents()
        {
            return repo.GetCustodyEvents();
        }
        public List<LookupEntity> GetDress()
        {
            return repo.GetDress();
        }
        public List<LookupEntity> GetInmateDress()
        {
            return repo.GetInmateDress();
        }
        public List<LookupEntity> GetSergeant()
        {
            return repo.GetSergeant();
        }
        public List<LookupEntity> GetFacilties()
        {
            return repo.GetFacilties();
        }
        public List<LookupEntity> GetStations()
        {
            return repo.GetStations();
        }
        public List<LookupEntity> GetStaging()
        {
            return repo.GetStaging();
        }
        public List<LookupEntity> GetBureaus()
        {
            return repo.GetBureaus();
        }
        public List<LookupEntity> GetInjurySeverities()
        {
            return repo.GetInjurySeverities();
        }
        public List<LookupEntity> GetLocationofForce()
        {
            return repo.GetLocationofForce();
        }
        public List<LookupEntity> GetSuspectLocationofForce()
        {
            return repo.GetSuspectLocationofForce();
        }
        public List<LookupEntity> GetPerceivedArmed()
        {
            return repo.GetPerceivedArmed();
        }
        public List<LookupEntity> GetConfirmedArmed()
        {
            return repo.GetConfirmedArmed();
        }
        public List<LookupEntity> GetRacies()
        {
            return repo.GetRacies();
        }
        public List<LookupEntity> GetResistance()
        {
            return repo.GetResistance();
        }
        public List<LookupEntity> GetSex()
        {
            return repo.GetSex();
        }
        public List<LookupEntity> GetSubstance()
        {
            return repo.GetSubstance();
        }
        public List<LookupEntity> GetArmed()
        {
            return repo.GetArmed();
        }


    }
}
