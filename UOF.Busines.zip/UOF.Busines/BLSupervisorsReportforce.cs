﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.DataAccess.DbRepository;


namespace UOF.Business
{
    public class BLSupervisorsReportforce
    {
        SupervisorsReportforceRepository sPRepository = new SupervisorsReportforceRepository();
        public int SaveSupervisorsReportforceInfo(SupervisorsReportBusinessModel supervisorsReportBusinessModel)
        {
            return sPRepository.SaveSupervisorsReportforceInfo(supervisorsReportBusinessModel);
        }

        public SupervisorsReportBusinessModel GetSupervisorsReportforceInfo(ParameterCriteria cirteria)
        {
            return sPRepository.GetSupervisorsReportforceInfo( cirteria);
        }
        public bool SaveTracking(TrackingModel model)
        {
            return sPRepository.SaveTracking( model);
        }
        public TrackingModel GetTracking(int FormId, int IncidentId)
        {
            return sPRepository.GetTracking(FormId, IncidentId);
        }
    }
}
