﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.DataAccess.DbRepository;

namespace UOF.Business
{
    public class BLArtifacts
    {
        ArtifactsRepository repository = new ArtifactsRepository();

        /// <summary>
        /// Get artifacts data based on incident id
        /// </summary>
        /// <param name="incidentId">incident id</param>
        /// <returns>true or false</returns>
        public List<ArtifactEntity> GetIncidentArtifacts(int incidentId)
        {
            List<ArtifactEntity> listArtifacts = new List<ArtifactEntity>();
            try
            {
                listArtifacts = repository.GetIncidentArtifacts(incidentId);
                return listArtifacts;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Save artifacts data based on incident id
        /// </summary>
        /// <param name="artifactEntity">entity of artifacts</param>
        /// <returns>true or false</returns>
        public bool SaveIncidentArtifacts(ArtifactEntity artifactEntity)
        {
            return repository.SaveIncidentArtifacts(artifactEntity);
        }

        /// <summary>
        /// Delete the file
        /// </summary>
        /// <param name="artifactId"></param>
        /// <param name="incidentId"></param>
        /// <returns>true or false</returns>
        public bool DeleteIncidentArtifacts(int artifactId, int incidentId)
        {
            return repository.DeleteIncidentArtifacts(artifactId, incidentId);
        }
    }
}
