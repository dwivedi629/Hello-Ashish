﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.DataAccess.DbRepository;

namespace UOF.Business
{
    public class BLUoFForm
    {
        UoFReviewNoticeRepository reviewModel = new UoFReviewNoticeRepository();
        public bool SaveReviewNotice(UOFReviewNoticeBusinessModel reviewNoticeModel)
        {
            return reviewModel.SaveUOFReviewNotice(reviewNoticeModel);
        }

        public UOFReviewNoticeBusinessModel GetReviewNotice(int FormId, int IncidentId, string empId)
        {
            return reviewModel.GetReviewNotice(FormId, IncidentId, empId);
        }


        public int SaveForceReview(OperationsForceReview forceModel)
        {
            ForceReviewRepository forceRespo = new ForceReviewRepository();
            return forceRespo.SaveForceReview(forceModel);
        }

        public OperationsForceReview GetForceReview(ParameterCriteria cirteria)
        {
            ForceReviewRepository forceRespo = new ForceReviewRepository();
            return forceRespo.GetForceReview(cirteria);
        }

        public int SaveMedicalReport(MedicalEntity entity)
        {
            MedicalRepository Respo = new MedicalRepository();
            return Respo.SaveMedical(entity);
        }

        public MedicalEntity GetMedicalReport(ParameterCriteria cirteria)
        {
            MedicalRepository Respo = new MedicalRepository();
            return Respo.GetMedicalInformation(cirteria);
        }
        public int SaveDeputyMemo(UOFMemo entity)
        {
            DeputyMemoRespository Respo = new DeputyMemoRespository();

            return Respo.SaveDeputyMemo(entity);
        }
        public UOFMemo GetMemoDetails(ParameterCriteria cirteria)
        {
            DeputyMemoRespository Respo = new DeputyMemoRespository();
            return Respo.GetDeputyMemo(cirteria);
        }
        public int SaveSupplementalData(SupplementalModel entity)
        {
            SupplementalRepository Respo = new SupplementalRepository();
            return Respo.SaveSupplementalData(entity);
        }
        public SupplementalModel GetSupplementalDetails(ParameterCriteria cirteria)
        {
            SupplementalRepository Respo = new SupplementalRepository();
            return Respo.GetSupplementalDetails(cirteria);
        }
        public int SaveIABDetails(IABModel entity)
        {
            IABRepository Respo = new IABRepository();
            return Respo.SaveIABData(entity);
        }
        public IABModel GetIABDetails(int FormId, int IncidentId, string DeputyId)
        {
            IABRepository Respo = new IABRepository();
            return Respo.GetIABDetails(FormId, IncidentId, DeputyId);
        }
        public int SaveCADetails(CAEntity entity)
        {
            CARepository Respo = new CARepository();
            return Respo.SaveCAData(entity);
        }
        public int SaveCSDetails(CSEntity entity)
        {
            var Respo = new CSRepository();
            return Respo.SaveCSData(entity);
        }
        public CSEntity GetCSDetails(ParameterCriteria cirteria)
        {
            var Respo = new CSRepository();
            return Respo.GetCSDetails(cirteria);
        }
        public CAEntity GetCADetails(ParameterCriteria cirteria)
        {
            CARepository Respo = new CARepository();
            return Respo.GetCADetails( cirteria);
        }
        public UoFFormEntity GetFormURL(int formId)
        {
            LookupRespository Respo = new LookupRespository();
            return Respo.GetFormURL(formId);
        }
        public bool ApproveorReject(ReviewEntity entity)
        {
            LookupRespository Respo = new LookupRespository();
            return Respo.ApproveorReject(entity);
        }
        public string ReadyforPackage(int incidentId, int rank)
        {
            LookupRespository Respo = new LookupRespository();
            return Respo.ReadyforPackage(incidentId, rank);
        }
        public bool SaveReviewComments(ReviewCommentModel entity)
        {
            ReviewCommentsRespository Respo = new ReviewCommentsRespository();
            return Respo.SaveReviewComments(entity);
        }

        public string FormStatus(int formId, int incidentId, string reviewerId, string reviewerRole, int IncidentReviewId)
        {
            FormReviewRespository resp = new FormReviewRespository();
            return resp.FormStatus(formId, incidentId, reviewerId, reviewerRole, IncidentReviewId);
        }

        public bool EmailNotification(EmailNotificationModel entity)
        {
            EmailRepository Respo = new EmailRepository();
            return Respo.EmailNotification(entity);
        }
        public TrackingModel GetTrackingDetails(int FormId, int IncidentId)
        {
            ReportRepository Respo = new ReportRepository();
            return Respo.GetTrackingDetails(FormId, IncidentId);
        }
        public bool SaveIncidentAlert(IncidentAlertModel model)
        {
            AlertRepository Respo = new AlertRepository();
            return Respo.SaveIncidentAlert(model);
        }
        public bool SaveMCJAlert(MCJAlertModel model)
        {
            AlertRepository Respo = new AlertRepository();
            return Respo.SaveMCJAlert(model);
        }
        public IncidentAlertModel GetIncidentAlerDetails(int FormId, int IncidentId, string DeputyId)
        {
            AlertRepository Respo = new AlertRepository();
            return Respo.GetIncidentAlerDetails(FormId, IncidentId, DeputyId);
        }
        public MCJAlertModel GetMCJAlertDetails(int FormId, int IncidentId, string DeputyId)
        {
            AlertRepository Respo = new AlertRepository();
            return Respo.GetMCJAlertDetails(FormId, IncidentId, DeputyId);
        }
        public List<LookupEntity> GetReportedForms(int IncidentId, string reportedID)
        {
            FormReviewRespository resp = new FormReviewRespository();
            return resp.GetReportedForms(IncidentId, reportedID);
        }
        public bool SaveChangeRole(ChangeRoleEntity model)
        {
            ChangeRoleRepository Respo = new ChangeRoleRepository();
            return Respo.saveChangeRole(model);
        }
    }
}
