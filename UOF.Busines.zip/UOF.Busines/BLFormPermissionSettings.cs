﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.DataAccess;
using UOF.DataAccess.DbRepository;

namespace UOF.Business
{
    public class BLFormPermissionSettings
    {
        ISettingsRepository settingModel = new SettingsRepository();

        /// <summary>
        /// Get List of Roles
        /// </summary>
        /// <returns>list of roles</returns>
        public List<UserRoleSettingsEntity> GetRoles()
        {
          return  settingModel.GetRoles();

        }
        /// <summary>
        /// Get all Forms name
        /// </summary>
        /// <returns>List of forms</returns>
        public List<FormsNameSettings> GetFormsName()
        {
            return settingModel.GetFormsName();

        }
        public List<IncidentStatusDetail> GetIncidentFormData(string urn)
        {
            return settingModel.GetIncidentFormData(urn);
        }
        public List<IncidentStatusDetail> GetPackageInfo(string urn)
        {
            return settingModel.GetPackageInfo(urn);
        }
        /// <summary>
        /// Get all role's permission
        /// </summary>
        /// <returns>form permission</returns>
        public List<FormPermissionSettings> GetFormPermission()
        {
            return settingModel.GetFormPermission();

        }

        /// <summary>
        /// Get all role's permission
        /// </summary>
        /// <param name="formCode"></param>
        /// <param name="roleCode"></param>
        /// <returns>true or false</returns>
        public bool GetFormPermission(string formCode, string roleCode)
        {
            return settingModel.GetFormPermission(formCode, roleCode);

        }

        /// <summary>
        /// Save all form based permissions
        /// </summary>
        /// <param name="objfrmPermission"></param>
        /// <returns>result, true false</returns>
        public bool SaveFormPermissions(List<FormPermissionSettings> objfrmPermission)
        {
            List<FormPermisssion> listFormPermission = new List<FormPermisssion>();
            foreach (var item in objfrmPermission)
            {
                listFormPermission.Add(
                new FormPermisssion()
                {
                    IsViewOnly = item.IsViewOnly,
                    RoleId = item.RoleId,
                    FormId = item.FormId
                });
            }
            return settingModel.SaveFormPermissions(listFormPermission);
        }
        public bool SaveRole(UserRoleSettingsEntity roleEntity)
        {
            return settingModel.SaveRole(roleEntity);

        }
        public bool ChangeOwnerShip(ChangeOwnerModel entity)
        {
            return settingModel.ChangeOwnerShip(entity);

        }

    }
}
