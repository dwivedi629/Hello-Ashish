﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.DataAccess.DbRepository;

namespace UOF.Business
{
    public class BLUser : IDisposable
    {
        UserRepository userModel = new UserRepository();
        public bool SaveInvolvedUser(InvolvedUserEntity involvedUserEntity)
        {
            return userModel.SaveInvolvedUser(involvedUserEntity);
        }

        public bool SaveSuspectUser(SuspectUserEntity suspectUserEntity)
        {
            return userModel.SaveSuspectUser(suspectUserEntity);
        }

        public bool SaveWitnessUser(WitnessUserEntity witnessUserEntity)
        {
            return userModel.SaveWitnessUser(witnessUserEntity);
        }

        public bool SaveDuptiesInfo(WitnessUserEntity witnessUserEntity)
        {
            return userModel.SaveDuptiesInfo(witnessUserEntity);
        }
        public bool SaveCanineInfo(CanineEntity canineEntity)
        {
            return userModel.SaveCanineInfo(canineEntity);
        }

        public List<IncidentUserEntity> GetIncidentUser()
        {
            return userModel.Get();
        }
        public IncidentUserEntity GetIncidentUser(int incidentId)
        {
            return userModel.Get(incidentId);
        }
        public List<LookupEntity> GetInvolvedUserWithName(int IncidentId)
        {
            return userModel.GetInvolvedUserWithName(IncidentId);
        }
        public List<LookupEntity> GetAssignedUserWithName(int IncidentId)
        {
            return userModel.GetAssignedUserWithName(IncidentId);
        }
        public List<LookupEntity> GetReportingEmployees(int IncidentId, string loggedRole)
        {
            return userModel.GetReportingEmployees(IncidentId, loggedRole);
        }

        public List<LookupEntity> GetIncidentUserWithName(int IncidentId)
        {
            return userModel.GetIncidentUserWithName(IncidentId);
        }
        public List<LookupEntity> GetUsersByFormId(int IncidentId, int formId)
        {
            return userModel.GetUsersByFormId(IncidentId, formId);
        }
        public List<InvolvedUserEntity> GetInvolvedUser()
        {
            return userModel.GetInvolvedUser();
        }
        public List<InvolvedUserEntity> GetInvolvedUser(int incidentId)
        {
            return userModel.GetInvolvedUser(incidentId);
        }
        public InvolvedUserEntity GetInvolvedUser(int incidentId, int incidentUserInvolvedId)
        {
            return userModel.GetInvolvedUser(incidentId, incidentUserInvolvedId);
        }

        public List<SuspectUserEntity> GetSuspectUser()
        {
            return userModel.GetSuspectUser();
        }
        public List<SuspectUserEntity> GetSuspectUser(int incidentId)
        {
            return userModel.GetSuspectUser(incidentId);
        }
        public SuspectUserEntity GetSuspectUser(int incidentId, int incidentUserSuspectId)
        {
            return userModel.GetSuspectUser(incidentId, incidentUserSuspectId);
        }

        public List<WitnessUserEntity> GetWitnessUser()
        {
            return userModel.GetWitnessUser();
        }
        public List<WitnessUserEntity> GetWitnessUser(int incidentId, int witnessType)
        {
            return userModel.GetWitnessUser(incidentId, witnessType);
        }
        public List<WitnessUserEntity> GetincidentDupties(int incidentId)
        {
            return userModel.GetincidentDupties(incidentId);
        }
        public WitnessUserEntity GetIncidentWitnessUser(int incidentId, int incidentUserWitnessId)
        {
            return userModel.GetIncidentWitnessUser(incidentId, incidentUserWitnessId);
        }
        public List<StatisticalEntity> GetStaticalData(int incidentId)
        {
            return userModel.GetStaticalData(incidentId);
        }
        public CanineEntity GetCanineData(int incidentId)
        {
            return userModel.GetCanineInfo(incidentId);
        }
        public List<string> GetSuspectUsers(int incidentId)
        {
            return userModel.GetSuspectUsers(incidentId);
        }
        //public List<string> GetInvolvedUsers(int incidentId)
        //{
        //    return userModel.GetInvolvedUsers(incidentId);
        //}
        public List<LookupEntity> GetInvolvedUsersAndSuspects(int incidentId)
        {
            return userModel.GetInvolvedUsersAndSuspects(incidentId);
        }
        public bool AssigntoCommander(List<WitnessUserEntity> Commanders)
        {
            return userModel.AssigntoCommander(Commanders);
        }
        public bool AssignPackage(ChangeOwnerModel Commanders)
        {
            return userModel.AssignPackage(Commanders);
        }
        
        public bool DeleteUser(int incidentId, int userId, string employeeNumber, int userType)
        {
            return userModel.DeleteUser(incidentId, userId, employeeNumber, userType);
        }
        #region Dispose
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                // free managed resources
                if (userModel != null)
                {
                    userModel = null;
                }
            }
        }
        #endregion
    }
}
