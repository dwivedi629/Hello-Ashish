﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.DataAccess.DbRepository;

namespace UOF.Business
{
    public class BLReview
    {

        ReviewRepository reviewModel = new ReviewRepository();

        #region Watch Commander Section
        public int SaveWCReviewInfo(ReviewsResponse reviewsResponse)//List<ReviewBusinessModel> reviewBusinessModel)
        {
            return reviewModel.SaveWCReviewInfo(reviewsResponse);
        }

        public ReviewsResponse GetWCReviewData(ParameterCriteria cirteria)
        {
            return reviewModel.GetWCReviewData(cirteria);
        }
        #endregion

        #region Unit Commander Section
        public int SaveUCReviewInfo(ReviewsResponse reviewsResponse)
        {
            return reviewModel.SaveUCReviewInfo(reviewsResponse);
        }

        public ReviewsResponse GetUCReviewData(ParameterCriteria cirteria)
        {
            return reviewModel.GetUCReviewData(cirteria);
        }

        #endregion

        #region  Commander Section
        public int SaveCommanderReviewInfo(ReviewsResponse reviewBusinessModel)
        {
            return reviewModel.SaveCommanderReviewInfo(reviewBusinessModel);
        }

        public ReviewsResponse GetCommanderReviewData(ParameterCriteria cirteria)
        {
            return reviewModel.GetCommanderReviewData(cirteria);
        }

        #endregion

        #region Assing to WC
        public bool AssignCat3(WitnessUserEntity WC)
        {
            return reviewModel.AssignCat3(WC);
        }
        
        #endregion

        public bool AssigntoIAB(int incidentId)
        {
            IABRepository Respo = new IABRepository();
            return Respo.AssigntoIAB(incidentId);
        }
        public bool SentToCFRT(string emailId, int IncidentId, string LoggedInRole)
        {
            return reviewModel.SentToCFRT(emailId, IncidentId, LoggedInRole);
        }
        public bool RolloutToChief(int incidentId)
        {
            return reviewModel.RolloutToChief(incidentId);
        }
    }
}
