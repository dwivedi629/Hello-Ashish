﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.DataAccess.DbRepository;

namespace UOF.Business
{
    public class BLNarrative
    {
        NarrativeRepository narrativeModel = new NarrativeRepository();
        public int SaveNarrative(UoFNarrativeEntityModel narrativeBusinessModel)
        {
            return narrativeModel.SaveUOFNarrative(narrativeBusinessModel);
        }

        public UoFNarrativeEntityModel GetNarrative(ParameterCriteria cirteria)
        {
            return narrativeModel.GetUOFNarrative(cirteria);
        }
    }
}
