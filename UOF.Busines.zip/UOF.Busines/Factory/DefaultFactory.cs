﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;

namespace UOF.Business.Factory
{
    public class DefaultFactory
    {
        private BLReport _blReport = null;
        private BLReport BLReport
        {
            get
            {
                if (_blReport == null)
                    return _blReport = new BLReport();

                return _blReport;
            }
        }
        public IEntityBusinessModel GetModelObject(int formID = 0, int IncidentId = 0, string empId = "0")
        {
            switch (formID)
            {
                case 10:
                    return BLReport.GetReportModel<UoFNarrativeEntityModel>(formID, IncidentId);
                case 11:
                    return BLReport.GetReportModel<SupervisorsReportBusinessModel>(formID, IncidentId);
                case 12:
                    return BLReport.GetReportModel<OperationsForceReview>(formID, IncidentId);
                case 13:
                //return BLReport.GetReportModel<UOFMemo>(formID,  IncidentId);
                case 14:
                    return BLReport.GetReportModel<SupervisorsReportBusinessModel>(formID, IncidentId);
                case 15:
                    return BLReport.GetReportModel<UOFReviewNoticeBusinessModel>(formID, IncidentId);
                case 16:
                    return BLReport.GetReportModel<DeputyIncidentReportBusinessModel>(formID, IncidentId);
                case 17:
                    return BLReport.GetReportModel<MedicalEntity>(formID, IncidentId);
                case 18:
                    return BLReport.GetReportModel<CAEntity>(formID, IncidentId);
                case 19:
                    return BLReport.GetReportModel<InmateInjuryBusinessModel>(formID, IncidentId);
                case 20:
                    return BLReport.GetReportModel<UOFMemo>(formID, IncidentId, empId); //UOF Memo
                case 21:
                    return BLReport.GetReportModel<CSEntity>(formID, IncidentId);
                case 22:
                    return BLReport.GetReportModel<SupplementalModel>(formID, IncidentId, empId); //UOF Supplemental Report
                case 23:
                    return BLReport.GetReportModel<ReviewsResponse>(formID, IncidentId);
                case 24:
                    return BLReport.GetReportModel<IABModel>(formID, IncidentId);
                case 25:
                    return BLReport.GetReportModel<UOFReviewNoticeBusinessModel>(formID, IncidentId);
                case 26:
                    return BLReport.GetReportModel<ReviewsResponse>(formID, IncidentId);
                case 27:
                    return BLReport.GetReportModel<UOFReviewNoticeBusinessModel>(formID, IncidentId);
                case 30:
                    return BLReport.GetReportModel<ReviewsResponse>(formID, IncidentId);
                case 31:
                    return BLReport.GetReportModel<UOFReviewNoticeBusinessModel>(formID, IncidentId);
                case 0: //Supervisory Report
                    return BLReport.GetReportModel<SupervisoryModel>(0, IncidentId);
                //case 16:
                //    return report.GetReportModel<UOFReviewNoticeBusinessModel>(formID, deputyID);
                //case 17:
                //    return report.GetReportModel<UOFMemo>(formID, deputyID);
                default:
                    return null;
            }
        }
    }
}
