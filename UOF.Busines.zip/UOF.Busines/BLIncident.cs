﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.Common.Utilities;
using UOF.DataAccess.DbRepository;

namespace UOF.Business
{
    public class BLIncident
    {
        IncidentRepository incidentModel = new IncidentRepository();
        public int SaveIncident(IncidentEntity incidentEntity)
        {
            return incidentModel.SaveIncident(incidentEntity);
        }
        public int AssingIncidentForms(AssignForm assignForms)
        {
            return incidentModel.AssingIncidentForms(assignForms);
        }

        public List<IncidentEntity> Get()
        {
            return incidentModel.GetIncident();
        }
        public List<IncidentEntity> GetUserIncidents(string userId, string userRole)
        {
            return incidentModel.GetUserIncidents(userId, userRole);
        }
        public IncidentEntity Get(int incidentId)
        {
            return incidentModel.GetIncident(incidentId);
        }
        public void SaveStatistical(List<StatisticalEntity> statisticalEntity)
        {
            IncidentStatisticalRespository resp = new IncidentStatisticalRespository();
            resp.SaveStatistical(statisticalEntity);
        }
        public List<IncidentStatusDetail> GetIncidentFormData(string userId, string userRole, int incidentId)
        {
            return incidentModel.GetIncidentFormData(userId, userRole, incidentId);
        }
        public List<IncidentStatusDetail> GetExplanationFormData(string userId, string userRole, int incidentId, int formId)
        {
            return incidentModel.GetExplanationFormData(userId, userRole, incidentId, formId);
        }

        public UoFModel GetIncidentData(int incidentId, string userId)
        {
            return incidentModel.GetIncidentData(incidentId, userId);
        }

        public int GetNotifications(string userRole, string userId)
        {
            return incidentModel.GetNotifications(userRole, userId);
        }
        public bool VerifyCatFormsStatus(int incidentId, int formID)
        {
            return incidentModel.VerifyCatFormsStatus(incidentId, formID);
        }
        public int VerifyURN(string URN)
        {
            return incidentModel.VerifyURN(URN);
        }

        public bool CheckDuplicateURN(string URN, int incidentId)
        {
            return incidentModel.CheckDuplicateURN(URN, incidentId);
        }

        /// <summary>
        /// This method will delete the incident record
        /// </summary>
        /// <param name="incidentId"></param>
        /// <returns>true or false</returns>
        public bool DeleteIncident(int incidentId)
        {
            return incidentModel.DeleteIncident(incidentId);
        }

        /// <summary>
        /// This method will delete the incident form Review record
        /// </summary>
        /// <param name="incidentId"></param>
        /// <returns>true or false</returns>
        public bool DeleteIncidentForm(int ReviewId)
        {
            return incidentModel.DeleteIncidentForm(ReviewId);
        }

        public AssignForm GetIncidentFormAssignInfo(int incidentId)
        {
            return incidentModel.GetIncidentFormAssignInfo(incidentId);
        }

        public bool IncidentSubmit(int incidentId, string sergeantId)
        {
            return incidentModel.IncidentSubmit(incidentId, sergeantId);
        }
    }
}
