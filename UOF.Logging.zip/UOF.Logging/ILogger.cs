﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Logging
{
    /// <summary>   Logging Interface/ Contract for Logger class. </summary>
    public interface ILogService
    {
        /* Log a message object */

        /// <summary>   Debugs. </summary>
        ///
        /// <param name="message">          The message. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>

        void Debug(object message,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0);

        /// <summary>   Infoes. </summary>
        ///
        /// <param name="message">          The message. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>

        void Info(object message,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0);

        /// <summary>   Warns. </summary>
        ///
        /// <param name="message">          The message. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>

        void Warn(object message,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0);

        /// <summary>   Errors. </summary>
        ///
        /// <param name="message">          The message. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>

        void Error(object message,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0);

        /// <summary>   Fatals. </summary>
        ///
        /// <param name="message">          The message. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>

        void Fatal(object message,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0);

        /// <summary>   Fatals. </summary>
        ///
        /// <param name="exception">        The exception. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>

        void Fatal(Exception exception,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0);

        /// <summary>   Errors. </summary>
        ///
        /// <param name="exception">        The exception. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>

        void Error(Exception exception,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0);

        /// <summary>   Warns. </summary>
        ///
        /// <param name="exception">        The exception. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>

        void Warn(Exception exception,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0);

        /// <summary>   Infoes. </summary>
        ///
        /// <param name="exception">        The exception. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>

        void Info(Exception exception,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0);

        /// <summary>   Debugs. </summary>
        ///
        /// <param name="exception">        The exception. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>

        void Debug(Exception exception,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0);

        /* Log a message string using the System.String.Format syntax */

        /// <summary>   Debug format. </summary>
        ///
        /// <param name="format">           Describes the format to use. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>
        /// <param name="args">             A variable-length parameters list containing arguments. </param>

        void DebugFormat(string format,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0, params object[] args);

        /// <summary>   Information format. </summary>
        ///
        /// <param name="format">           Describes the format to use. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>
        /// <param name="args">             A variable-length parameters list containing arguments. </param>

        void InfoFormat(string format,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0, params object[] args);

        /// <summary>   Warning format. </summary>
        ///
        /// <param name="format">           Describes the format to use. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>
        /// <param name="args">             A variable-length parameters list containing arguments. </param>

        void WarnFormat(string format,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0, params object[] args);

        /// <summary>   Error format. </summary>
        ///
        /// <param name="format">           Describes the format to use. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>
        /// <param name="args">             A variable-length parameters list containing arguments. </param>

        void ErrorFormat(string format,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0, params object[] args);

        /// <summary>   Fatal format. </summary>
        ///
        /// <param name="format">           Describes the format to use. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>
        /// <param name="args">             A variable-length parameters list containing arguments. </param>

        void FatalFormat(string format,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0, params object[] args);

        /* Log a message string using the System.String.Format syntax */

        /// <summary>   Debug format. </summary>
        ///
        /// <param name="provider">         The provider. </param>
        /// <param name="format">           Describes the format to use. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>
        /// <param name="args">             A variable-length parameters list containing arguments. </param>

        void DebugFormat(IFormatProvider provider, string format, [CallerMemberName] string memberName = "",
           [CallerFilePath] string sourceFilePath = "", [CallerLineNumber] int sourceLineNumber = 0, params object[] args);

        /// <summary>   Information format. </summary>
        ///
        /// <param name="provider">         The provider. </param>
        /// <param name="format">           Describes the format to use. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>
        /// <param name="args">             A variable-length parameters list containing arguments. </param>

        void InfoFormat(IFormatProvider provider, string format, [CallerMemberName] string memberName = "",
           [CallerFilePath] string sourceFilePath = "", [CallerLineNumber] int sourceLineNumber = 0, params object[] args);

        /// <summary>   Warning format. </summary>
        ///
        /// <param name="provider">         The provider. </param>
        /// <param name="format">           Describes the format to use. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>
        /// <param name="args">             A variable-length parameters list containing arguments. </param>

        void WarnFormat(IFormatProvider provider, string format, [CallerMemberName] string memberName = "",
           [CallerFilePath] string sourceFilePath = "", [CallerLineNumber] int sourceLineNumber = 0, params object[] args);

        /// <summary>   Error format. </summary>
        ///
        /// <param name="provider">         The provider. </param>
        /// <param name="format">           Describes the format to use. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>
        /// <param name="args">             A variable-length parameters list containing arguments. </param>

        void ErrorFormat(IFormatProvider provider, string format, [CallerMemberName] string memberName = "",
           [CallerFilePath] string sourceFilePath = "", [CallerLineNumber] int sourceLineNumber = 0, params object[] args);

        /// <summary>   Fatal format. </summary>
        ///
        /// <param name="provider">         The provider. </param>
        /// <param name="format">           Describes the format to use. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>
        /// <param name="args">             A variable-length parameters list containing arguments. </param>

        void FatalFormat(IFormatProvider provider, string format, [CallerMemberName] string memberName = "",
           [CallerFilePath] string sourceFilePath = "", [CallerLineNumber] int sourceLineNumber = 0, params object[] args);

        /// <summary>   Gets file appender file name. </summary>
        ///
        /// <returns>   The file appender file name. </returns>

        string GetFileAppenderFileName();

        /// <summary>   Custom error. </summary>
        ///
        /// <param name="exception">        The exception. </param>
        /// <param name="guid">             Unique identifier. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>

        void CustomError(Exception exception, string methodName, [CallerMemberName] string memberName = "", [CallerFilePath] string sourceFilePath = "", [CallerLineNumber] int sourceLineNumber = 0);

        /// <summary>   Custom information. </summary>
        ///
        /// <param name="exception">        The exception. </param>
        /// <param name="guid">             Unique identifier. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>

        void CustomInfo(Exception exception, string methodName, [CallerMemberName] string memberName = "", [CallerFilePath] string sourceFilePath = "", [CallerLineNumber] int sourceLineNumber = 0);

        /// <summary>   Custom information. </summary>
        ///
        /// <param name="message">          The message. </param>
        /// <param name="guid">             Unique identifier. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>

        void CustomInfo(object message, string methodName, [CallerMemberName] string memberName = "", [CallerFilePath] string sourceFilePath = "", [CallerLineNumber] int sourceLineNumber = 0);
    }
}
