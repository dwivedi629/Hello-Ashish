﻿using System.Diagnostics.CodeAnalysis;
using log4net;
using log4net.Appender;
using log4net.Core;
using log4net.Config;
using log4net.Repository;
using System;
using System.Collections;
using System.ComponentModel;
using System.IO;
using System.Runtime.CompilerServices;
using log4net.Repository.Hierarchy;
using System.Configuration;

namespace UOF.Logging
{
   /// <summary>   Provide the Logging mechanism. </summary>
    public sealed class LogService : ILogService
    {
        /// <summary>   The logger. </summary>
        readonly ILog _logger;

        /// <summary>   Static constructor. </summary>
        static LogService()
        {

            // Gets directory path of the calling application
            // RelativeSearchPath is null if the executing assembly i.e. calling assembly is a
            // stand alone exe file (Console, WinForm, etc). 
            // RelativeSearchPath is not null if the calling assembly is a web hosted application i.e. a web site
            var log4NetConfigDirectory = AppDomain.CurrentDomain.RelativeSearchPath ?? AppDomain.CurrentDomain.BaseDirectory;

            var log4NetConfigFilePath = Path.Combine(log4NetConfigDirectory, "log4net.config");
            log4net.Config.XmlConfigurator.ConfigureAndWatch(new FileInfo(log4NetConfigFilePath));

            //Code to read the connection string from the web.config.
            Hierarchy hierarchy = LogManager.GetRepository() as Hierarchy;
            if (hierarchy != null && hierarchy.Configured)
            {
                foreach (IAppender appender in hierarchy.GetAppenders())
                {
                    var objappender = appender as AdoNetAppender;
                    if (objappender != null)
                    {
                        var adoNetAppender = (AdoNetAppender)appender;
                        adoNetAppender.ConnectionString = ConfigurationManager.ConnectionStrings["UseofForce"].ToString();
                        adoNetAppender.ActivateOptions(); //Refresh AdoNetAppenders Settings
                    }
                }
            }
        }

        /// <summary>   Constructor. </summary>
        ///
        /// <param name="logClass"> The log class. </param>

        public LogService(Type logClass)
        {
            _logger = LogManager.GetLogger(logClass);
        }

        #region Methods

        /// <summary>   Log(s) Exceptions/Errors which has level of FATAL type with the Exception. </summary>
        ///
        /// <param name="exception">        . </param>
        /// <param name="memberName">       (Optional) </param>
        /// <param name="sourceFilePath">   (Optional) </param>
        /// <param name="sourceLineNumber"> (Optional) </param>

        public void Fatal(Exception exception,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0)
        {
            if (_logger.IsFatalEnabled)
            {
                _logger.Fatal(string.Format(
                "Error Logged From method {0} in file {1} at line {2}",
                memberName, sourceFilePath, sourceLineNumber), exception);
            }
        }

        /// <summary>
        /// Log(s) Exceptions/Errors which has level of ERROR type  with the Exception.
        /// </summary>
        ///
        /// <param name="exception">        . </param>
        /// <param name="memberName">       (Optional) </param>
        /// <param name="sourceFilePath">   (Optional) </param>
        /// <param name="sourceLineNumber"> (Optional) </param>

        public void Error(Exception exception,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0)
        {
            if (_logger.IsErrorEnabled)
            {
                _logger.Error(string.Format(
                "Error Logged From method {0} in file {1} at line {2}",
                memberName, sourceFilePath, sourceLineNumber), exception);
            }
        }

        /// <summary>   Log(s) Exceptions/Errors which has level of WARN type with the Exception. </summary>
        ///
        /// <param name="exception">        . </param>
        /// <param name="memberName">       (Optional) </param>
        /// <param name="sourceFilePath">   (Optional) </param>
        /// <param name="sourceLineNumber"> (Optional) </param>

        public void Warn(Exception exception,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0)
        {
            if (_logger.IsWarnEnabled)
            {
                _logger.Warn(string.Format(
                "Error Logged From method {0} in file {1} at line {2}",
                memberName, sourceFilePath, sourceLineNumber), exception);
            }
        }

        /// <summary>   Log(s) Exceptions/Errors which has level of INFO type with the Exception. </summary>
        ///
        /// <param name="exception">        . </param>
        /// <param name="memberName">       (Optional) </param>
        /// <param name="sourceFilePath">   (Optional) </param>
        /// <param name="sourceLineNumber"> (Optional) </param>

        public void Info(Exception exception,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0)
        {
            if (_logger.IsInfoEnabled)
            {
                _logger.Info(string.Format(
                "Error Logged From method {0} in file {1} at line {2}",
                memberName, sourceFilePath, sourceLineNumber), exception);
            }
        }

        /// <summary>   Log(s) Exceptions/Errors which has level of DEBUG type with the Exception. </summary>
        ///
        /// <param name="exception">        . </param>
        /// <param name="memberName">       (Optional) </param>
        /// <param name="sourceFilePath">   (Optional) </param>
        /// <param name="sourceLineNumber"> (Optional) </param>

        public void Debug(Exception exception,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0)
        {
            if (_logger.IsDebugEnabled)
            {
                _logger.Debug(string.Format(
                "Error Logged From method {0} in file {1} at line {2}",
                memberName, sourceFilePath, sourceLineNumber), exception);
            }
        }

        /// <summary>   Log(s) Exceptions/Errors which has level of DEBUG type. </summary>
        ///
        /// <param name="message">          . </param>
        /// <param name="memberName">       (Optional) </param>
        /// <param name="sourceFilePath">   (Optional) </param>
        /// <param name="sourceLineNumber"> (Optional) </param>

        public void Debug(object message,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0)
        {
            if (_logger.IsDebugEnabled)
            {
                _logger.Debug(string.Format(
                "Message: {0} Logged From method {1} in file {2} at line {3}",
                message, memberName, sourceFilePath, sourceLineNumber));
            }
        }

        /// <summary>   Log(s) Exceptions/Errors which has level of INFO type. </summary>
        ///
        /// <param name="message">          . </param>
        /// <param name="memberName">       (Optional) </param>
        /// <param name="sourceFilePath">   (Optional) </param>
        /// <param name="sourceLineNumber"> (Optional) </param>

        public void Info(object message,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0)
        {
            if (_logger.IsInfoEnabled)
            {
                _logger.Info(string.Format(
                "Message: {0} Logged From method {1} in file {2} at line {3}",
                message, memberName, sourceFilePath, sourceLineNumber));
            }
        }

        /// <summary>   Log(s) Exceptions/Errors which has level of WARN type. </summary>
        ///
        /// <param name="message">          . </param>
        /// <param name="memberName">       (Optional) </param>
        /// <param name="sourceFilePath">   (Optional) </param>
        /// <param name="sourceLineNumber"> (Optional) </param>

        public void Warn(object message,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0)
        {
            if (_logger.IsWarnEnabled)
            {
                _logger.Warn(string.Format(
                "Message: {0} Logged From method {1} in file {2} at line {3}",
                message, memberName, sourceFilePath, sourceLineNumber));
            }
        }

        /// <summary>   Log(s) Exceptions/Errors which has level of Error type. </summary>
        ///
        /// <param name="message">          . </param>
        /// <param name="memberName">       (Optional) </param>
        /// <param name="sourceFilePath">   (Optional) </param>
        /// <param name="sourceLineNumber"> (Optional) </param>

        public void Error(object message,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0)
        {
            if (_logger.IsErrorEnabled)
            {
                _logger.Error(string.Format(
                "Message: {0} Logged From method {1} in file {2} at line {3}",
                message, memberName, sourceFilePath, sourceLineNumber));
            }
        }

        /// <summary>   Log(s) Exceptions/Errors which has level of FATAL type. </summary>
        ///
        /// <param name="message">          . </param>
        /// <param name="memberName">       (Optional) </param>
        /// <param name="sourceFilePath">   (Optional) </param>
        /// <param name="sourceLineNumber"> (Optional) </param>
        public void Fatal(object message,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0)
        {
            if (_logger.IsFatalEnabled)
            {
                _logger.Fatal(string.Format(
                "Message: {0} Logged From method {1} in file {2} at line {3}",
                message, memberName, sourceFilePath, sourceLineNumber));
            }
        }

        /// <summary>   Debug format. </summary>
        ///
        /// <exception cref="NotImplementedException">  Thrown when the requested operation is
        ///                                             unimplemented. </exception>
        ///
        /// <param name="format">           Describes the format to use. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>
        /// <param name="args">             A variable-length parameters list containing arguments. </param>
        [ExcludeFromCodeCoverage]
        public void DebugFormat(string format,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0, params object[] args)
        {
            throw new NotImplementedException();
        }

        /// <summary>   Information format. </summary>
        ///
        /// <exception cref="NotImplementedException">  Thrown when the requested operation is
        ///                                             unimplemented. </exception>
        ///
        /// <param name="format">           Describes the format to use. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>
        /// <param name="args">             A variable-length parameters list containing arguments. </param>
        [ExcludeFromCodeCoverage]
        public void InfoFormat(string format,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0, params object[] args)
        {
            throw new NotImplementedException();
        }

        /// <summary>   Warning format. </summary>
        ///
        /// <exception cref="NotImplementedException">  Thrown when the requested operation is
        ///                                             unimplemented. </exception>
        ///
        /// <param name="format">           Describes the format to use. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>
        /// <param name="args">             A variable-length parameters list containing arguments. </param>
        [ExcludeFromCodeCoverage]
        public void WarnFormat(string format,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0, params object[] args)
        {
            throw new NotImplementedException();
        }

        /// <summary>   Error format. </summary>
        ///
        /// <exception cref="NotImplementedException">  Thrown when the requested operation is
        ///                                             unimplemented. </exception>
        ///
        /// <param name="format">           Describes the format to use. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>
        /// <param name="args">             A variable-length parameters list containing arguments. </param>
        [ExcludeFromCodeCoverage]
        public void ErrorFormat(string format,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0, params object[] args)
        {
            throw new NotImplementedException();
        }

        /// <summary>   Fatal format. </summary>
        ///
        /// <exception cref="NotImplementedException">  Thrown when the requested operation is
        ///                                             unimplemented. </exception>
        ///
        /// <param name="format">           Describes the format to use. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>
        /// <param name="args">             A variable-length parameters list containing arguments. </param>
        [ExcludeFromCodeCoverage]
        public void FatalFormat(string format,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0, params object[] args)
        {
            throw new NotImplementedException();
        }

        /// <summary>   Debug format. </summary>
        ///
        /// <exception cref="NotImplementedException">  Thrown when the requested operation is
        ///                                             unimplemented. </exception>
        ///
        /// <param name="provider">         The provider. </param>
        /// <param name="format">           Describes the format to use. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>
        /// <param name="args">             A variable-length parameters list containing arguments. </param>
        [ExcludeFromCodeCoverage]
        public void DebugFormat(IFormatProvider provider, string format, [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "", [CallerLineNumber] int sourceLineNumber = 0, params object[] args)
        {
            throw new NotImplementedException();
        }

        /// <summary>   Information format. </summary>
        ///
        /// <exception cref="NotImplementedException">  Thrown when the requested operation is
        ///                                             unimplemented. </exception>
        ///
        /// <param name="provider">         The provider. </param>
        /// <param name="format">           Describes the format to use. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>
        /// <param name="args">             A variable-length parameters list containing arguments. </param>
        [ExcludeFromCodeCoverage]
        public void InfoFormat(IFormatProvider provider, string format, [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "", [CallerLineNumber] int sourceLineNumber = 0,
            params object[] args)
        {
            throw new NotImplementedException();
        }

        /// <summary>   Warning format. </summary>
        ///
        /// <exception cref="NotImplementedException">  Thrown when the requested operation is
        ///                                             unimplemented. </exception>
        ///
        /// <param name="provider">         The provider. </param>
        /// <param name="format">           Describes the format to use. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>
        /// <param name="args">             A variable-length parameters list containing arguments. </param>
        [ExcludeFromCodeCoverage]
        public void WarnFormat(IFormatProvider provider, string format, [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "", [CallerLineNumber] int sourceLineNumber = 0,
            params object[] args)
        {
            throw new NotImplementedException();
        }

        /// <summary>   Error format. </summary>
        ///
        /// <exception cref="NotImplementedException">  Thrown when the requested operation is
        ///                                             unimplemented. </exception>
        ///
        /// <param name="provider">         The provider. </param>
        /// <param name="format">           Describes the format to use. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>
        /// <param name="args">             A variable-length parameters list containing arguments. </param>
        [ExcludeFromCodeCoverage]
        public void ErrorFormat(IFormatProvider provider, string format, [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "", [CallerLineNumber] int sourceLineNumber = 0,
            params object[] args)
        {
            throw new NotImplementedException();
        }

        /// <summary>   Fatal format. </summary>
        ///
        /// <exception cref="NotImplementedException">  Thrown when the requested operation is
        ///                                             unimplemented. </exception>
        ///
        /// <param name="provider">         The provider. </param>
        /// <param name="format">           Describes the format to use. </param>
        /// <param name="memberName">       (Optional) name of the member. </param>
        /// <param name="sourceFilePath">   (Optional) full pathname of the source file. </param>
        /// <param name="sourceLineNumber"> (Optional) source line number. </param>
        /// <param name="args">             A variable-length parameters list containing arguments. </param>
        [ExcludeFromCodeCoverage]
        public void FatalFormat(IFormatProvider provider, string format, [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "", [CallerLineNumber] int sourceLineNumber = 0,
            params object[] args)
        {
            throw new NotImplementedException();
        }

        /// <summary>   Gets file appender file name. </summary>
        ///
        /// <returns>   The file appender file name. </returns>
        [ExcludeFromCodeCoverage]
        public string GetFileAppenderFileName()
        {
            var appenders = new ArrayList();
            var h = (log4net.Repository.Hierarchy.Hierarchy)log4net.LogManager.GetRepository();
            appenders.AddRange(h.Root.Appenders);
            IAppender[] appenderList = (log4net.Appender.IAppender[])appenders.ToArray(typeof(log4net.Appender.IAppender));

            FileAppender fileAppender = null;
            foreach (IAppender appender in appenderList)
            {
                if (appender.GetType().FullName == typeof(FileAppender).FullName)
                {
                    fileAppender = (FileAppender)appender;
                    break;
                }
            }

            return fileAppender != null ? fileAppender.File : string.Empty;
        }
        #endregion

        #region Custom Log

        /// <summary>   Extension to base method to log the GUID with Error. </summary>
        ///
        /// <param name="exception">        . </param>
        /// <param name="guid">             . </param>
        /// <param name="memberName">       (Optional) </param>
        /// <param name="sourceFilePath">   (Optional) </param>
        /// <param name="sourceLineNumber"> (Optional) </param>

        public void CustomError(Exception exception, string guid,
           [CallerMemberName] string memberName = "",
           [CallerFilePath] string sourceFilePath = "",
           [CallerLineNumber] int sourceLineNumber = 0)
        {
            if (_logger.IsErrorEnabled)
            {
                if (exception.InnerException != null)
                    sourceFilePath = exception.InnerException.InnerException.Message;
                log4net.GlobalContext.Properties["GUID"] = guid;
                _logger.Error(string.Format(
                "Error Logged From method {0} in file {1} at line {2}",
                memberName, sourceFilePath, sourceLineNumber), exception);
            }
        }

        /// <summary>   Extension to base method to log the GUID with Information. </summary>
        ///
        /// <param name="exception">        . </param>
        /// <param name="guid">             . </param>
        /// <param name="memberName">       (Optional) </param>
        /// <param name="sourceFilePath">   (Optional) </param>
        /// <param name="sourceLineNumber"> (Optional) </param>

        public void CustomInfo(Exception exception, string guid,
                 [CallerMemberName] string memberName = "",
                 [CallerFilePath] string sourceFilePath = "",
                 [CallerLineNumber] int sourceLineNumber = 0)
        {
            if (_logger.IsInfoEnabled)
            {
                log4net.GlobalContext.Properties["GUID"] = guid;
                _logger.Info(string.Format(
                "Error Logged From method {0} in file {1} at line {2}",
                memberName, sourceFilePath, sourceLineNumber), exception);
            }
        }

        /// <summary>
        /// Extension to base method to log the GUID with information and custom message.
        /// </summary>
        ///
        /// <param name="message">          . </param>
        /// <param name="guid">             . </param>
        /// <param name="memberName">       (Optional) </param>
        /// <param name="sourceFilePath">   (Optional) </param>
        /// <param name="sourceLineNumber"> (Optional) </param>
        public void CustomInfo(object message, string guid,
           [CallerMemberName] string memberName = "",
           [CallerFilePath] string sourceFilePath = "",
           [CallerLineNumber] int sourceLineNumber = 0)
        {
            if (_logger.IsInfoEnabled)
            {
                log4net.GlobalContext.Properties["GUID"] = guid;
                _logger.Info(string.Format(
                "Message: {0} Logged From method {1} in file {2} at line {3}",
                message, memberName, sourceFilePath, sourceLineNumber));
            }
        }
        
        #endregion
    }
}
