﻿namespace UOF.DataModelDesign
{
    using System;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;
    using System.Text;

    public class ClassBuilder
    {
        /// <summary>   Default constructor. </summary>
        ///
        /// <remarks>    </remarks>

        internal ClassBuilder()
        {
        }

        /// <summary>   Builds column list. </summary>
        ///
        /// <remarks>    </remarks>
        ///
        /// <param name="prefix">   The prefix. </param>
        /// <param name="suffix">   The suffix. </param>
        ///
        /// <returns>   A string. </returns>

        public string BuildColumnList(string prefix, string suffix)
        {
            StringBuilder builder = new StringBuilder();
            foreach (PropertyBuilder builder2 in this.Properties)
            {
                if (builder.Length > 0)
                {
                    builder.Append('\t', 3);
                }
                if (!string.IsNullOrEmpty(prefix))
                {
                    builder.Append(prefix);
                }
                builder.Append(builder2.ColumnName);
                if (!string.IsNullOrEmpty(suffix))
                {
                    builder.Append(suffix);
                }
                builder.Append(",");
                builder.Append("\r\n");
            }
            if (builder.Length >= 3)
            {
                builder.Remove(builder.Length - 3, 3);
            }
            return builder.ToString();
        }

        /// <summary>   Gets or sets the name of the class. </summary>
        ///
        /// <value> The name of the class. </value>

        public string ClassName
        { get; set; }

        /// <summary>   Gets or sets the name of the database. </summary>
        ///
        /// <value> The name of the database. </value>

        public string DatabaseName
        { get; set; }

        /// <summary>   Gets or sets the name of the local schema. </summary>
        ///
        /// <value> The name of the local schema. </value>

        public string LocalSchemaName
        { get; set; }

        /// <summary>   Gets or sets the navigation properties. </summary>
        ///
        /// <value> The navigation properties. </value>

        public List<NavigationProperty> NavigationProperties
        { get; set; }

        /// <summary>   Gets or sets the properties. </summary>
        ///
        /// <value> The properties. </value>

        public List<PropertyBuilder> Properties
        { get; set; }

        /// <summary>   Gets or sets the name of the schema. </summary>
        ///
        /// <value> The name of the schema. </value>

        public string SchemaName
        { get; set; }

        /// <summary>   Gets the name of the scoped table. </summary>
        ///
        /// <value> The name of the scoped table. </value>

        public string ScopedTableName
        {
            get
            {
                return string.Format("{0}.{1}", this.LocalSchemaName, this.TableName);
            }
        }

        /// <summary>   Gets or sets the name of the table. </summary>
        ///
        /// <value> The name of the table. </value>

        public string TableName
        { get; set; }
    }
}
