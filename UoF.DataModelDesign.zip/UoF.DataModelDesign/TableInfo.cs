﻿namespace UOF.DataModelDesign
{
    using System;
    using System.Runtime.CompilerServices;

    /// <summary>   Information about the table. </summary>
    ///
    /// <remarks>    </remarks>

    public class TableInfo
    {
        private TableInfo()
        {
        }

        /// <summary>   Parses. </summary>
        ///
        /// <remarks>   </remarks>
        ///
        /// <param name="scopedTableName">      Name of the scoped table. </param>
        /// <param name="defaultDatabaseName">  The default database name. </param>
        ///
        /// <returns>   A TableInfo. </returns>

        public static TableInfo Parse(string scopedTableName, string defaultDatabaseName)
        {
            string[] strArray = scopedTableName.Split(new char[] { '.' });
            TableInfo info = new TableInfo();
            info.DatabaseName = defaultDatabaseName;
            switch (strArray.Length)
            {
                case 2:
                    info.Schema = strArray[0];
                    info.TableName = strArray[1];
                    return info;

                case 3:
                    info.DatabaseName = strArray[0];
                    info.Schema = strArray[1];
                    info.TableName = strArray[2];
                    return info;
            }
            info.TableName = scopedTableName;
            return info;
        }

        /// <summary>   Gets or sets the name of the database. </summary>
        ///
        /// <value> The name of the database. </value>

        public string DatabaseName
        { get; private set; }

        /// <summary>   Gets or sets the schema. </summary>
        ///
        /// <value> The schema. </value>

        public string Schema
        { get; private set; }

        /// <summary>   Gets or sets the name of the table. </summary>
        ///
        /// <value> The name of the table. </value>

        public string TableName
        { get; private set; }
    }
}

