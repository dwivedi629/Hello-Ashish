﻿namespace UOF.DataModelDesign
{
    using System;
    using System.Runtime.CompilerServices;

    public class NavigationProperty
    {
        //[CompilerGenerated]
        //private string <ForeignColumnName>k__BackingField;
        //[CompilerGenerated]
        //private string <ForeignTableName>k__BackingField;
        //[CompilerGenerated]
        //private string <LocalColumnName>k__BackingField;
        //[CompilerGenerated]
        //private string <PropertyDataType>k__BackingField;
        //[CompilerGenerated]
        //private string <PropertyName>k__BackingField;

        /// <summary>   Gets or sets the name of the foreign column. </summary>
        ///
        /// <value> The name of the foreign column. </value>

        public string ForeignColumnName
        { get; set; }

        /// <summary>   Gets or sets the name of the foreign table. </summary>
        ///
        /// <value> The name of the foreign table. </value>

        public string ForeignTableName
        { get; set; }

        /// <summary>   Gets or sets the name of the local column. </summary>
        ///
        /// <value> The name of the local column. </value>

        public string LocalColumnName
        { get; set; }

        /// <summary>   Gets or sets the type of the property data. </summary>
        ///
        /// <value> The type of the property data. </value>

        public string PropertyDataType
        { get; set; }

        /// <summary>   Gets or sets the name of the property. </summary>
        ///
        /// <value> The name of the property. </value>

        public string PropertyName
        { get; set; }
    }
}
