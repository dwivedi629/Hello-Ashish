﻿namespace UOF.DataModelDesign
{
    using Microsoft.SqlServer.Management.Common;
    using Microsoft.SqlServer.Management.Smo;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Runtime.CompilerServices;

    public class SqlCodeGenerator
    {
        private readonly ConnectionInfo _connectionInfo;
        //[CompilerGenerated]
        //private string <CrossDatabasePrefix>k__BackingField;

        public SqlCodeGenerator(ConnectionInfo connectionInfo, string crossDatabasePrefix)
        {
            this._connectionInfo = connectionInfo;
            this.CrossDatabasePrefix = crossDatabasePrefix;
        }

        private string[] BuildColumnNames(SqlDataReader reader)
        {
            List<string> list = new List<string>();
            for (int i = 0; i < reader.FieldCount; i++)
            {
                list.Add(reader.GetName(i));
            }
            return list.ToArray();
        }

        /// <summary>   Builds navigation properties. </summary>
        ///
        /// <remarks>    </remarks>
        ///
        /// <exception cref="Exception">    Thrown when an exception error condition occurs. </exception>
        ///
        /// <param name="generatorItems">   The generator items. </param>
        /// <param name="table">            The table. </param>
        /// <param name="properties">       The properties. </param>
        /// <param name="item">             The item. </param>

        private void BuildNavigationProperties(List<GeneratorItem> generatorItems, Table table, List<PropertyBuilder> properties, GeneratorItem item)
        {
            IEnumerator enumerator = table.ForeignKeys.GetEnumerator();
            {
                while (enumerator.MoveNext())
                {
                    Func<GeneratorItem, bool> predicate = null;
                    ForeignKey eachKey = (ForeignKey)enumerator.Current;
                    if (eachKey.Columns.Count > 1)
                    {
                        throw new Exception("Multiple navigation columns not supported at this time. Either implement, or turn off generating nav properties for the item via the config and use a partial class to add it manually.");
                    }
                    string name = eachKey.Columns[0].Name;
                    Column eachColumn = table.Columns[name];
                    if (predicate == null)
                    {
                        predicate = delegate(GeneratorItem i)
                        {
                            return i.TableName == eachKey.ReferencedTable;
                        };
                    }
                    GeneratorItem item2 = generatorItems.FirstOrDefault<GeneratorItem>(predicate);
                    PropertyBuilder builder = this.BuildProperty(item, eachColumn, 0);
                    string className = ((item2 == null) || string.IsNullOrEmpty(item2.ClassName)) ? eachKey.ReferencedTable : item2.ClassName;
                    builder.IsNavigationProperty = true;
                    builder.PropertyName = this.FormatNavigationName(name);
                    builder.PropertyDataType = this.FormatClassName(className);
                    properties.Add(builder);
                }
            }
            
        }

        /// <summary>   Builds the properties. </summary>
        ///
        /// <remarks>    </remarks>
        ///
        /// <param name="table">            The table. </param>
        /// <param name="properties">       The properties. </param>
        /// <param name="buildForeignKeys"> true to build foreign keys. </param>
        /// <param name="settings">         Options for controlling the operation. </param>

        private void BuildProperties(Table table, List<PropertyBuilder> properties, bool buildForeignKeys, GeneratorItem settings)
        {
            int index = 0;
            foreach (Column column in table.Columns)
            {
                if (!column.IsForeignKey || buildForeignKeys)
                {
                    PropertyBuilder item = this.BuildProperty(settings, column, index);
                    properties.Add(item);
                    index++;
                }
            }
        }

        /// <summary>   Builds a property. </summary>
        ///
        /// <remarks>    </remarks>
        ///
        /// <param name="settings">     Options for controlling the operation. </param>
        /// <param name="eachColumn">   The each column. </param>
        /// <param name="index">        Zero-based index of the. </param>
        ///
        /// <returns>   A PropertyBuilder. </returns>

        private PropertyBuilder BuildProperty(GeneratorItem settings, Column eachColumn, int index)
        {
            PropertyBuilder builder = new PropertyBuilder(settings);
            builder.PropertyIndex = index;
            builder.ColumnName = eachColumn.Name;
            builder.IsRowVersion = eachColumn.DataType.SqlDataType == SqlDataType.Timestamp;
            builder.PropertyName = this.FormatPropertyName(eachColumn.Name);
            builder.PropertyDataType = this.GetDotNetDataType(eachColumn.DataType.SqlDataType, eachColumn.DataType.NumericPrecision, eachColumn.DataType.NumericScale, !eachColumn.Nullable);
            builder.IsIdentity = eachColumn.Identity;
            builder.IsPrimaryKey = eachColumn.InPrimaryKey;
            builder.Size = this.GetDataTypeSize(eachColumn.DataType.SqlDataType, eachColumn.DataType.MaximumLength);
            builder.IsRequired = !eachColumn.Nullable;
            return builder;
        }

        /// <summary>   Builds a record. </summary>
        ///
        /// <remarks>    </remarks>
        ///
        /// <param name="reader">       The reader. </param>
        /// <param name="columnNames">  List of names of the columns. </param>
        ///
        /// <returns>   A QueryRecord. </returns>

        private QueryRecord BuildRecord(SqlDataReader reader, string[] columnNames)
        {
            QueryRecord record = new QueryRecord();
            for (int i = 0; i < reader.FieldCount; i++)
            {
                record.Add(columnNames[i], reader.GetString(i));
            }
            return record;
        }

        /// <summary>   Connects to database. </summary>
        ///
        /// <remarks>    </remarks>
        ///
        /// <param name="info"> The information. </param>
        ///
        /// <returns>   A Database. </returns>

        public Database ConnectToDatabase(ConnectionInfo info)
        {
            return this.ConnectToServer(info).Databases[info.Database];
        }

        /// <summary>   Connects to server. </summary>
        ///
        /// <remarks>    </remarks>
        ///
        /// <param name="info"> The information. </param>
        ///
        /// <returns>   A Server. </returns>

        public Server ConnectToServer(ConnectionInfo info)
        {
            return new Server(new ServerConnection(info.Server, info.Username, info.Password));
        }

        /// <summary>   Creates class builder. </summary>
        ///
        /// <remarks>    </remarks>
        ///
        /// <exception cref="InvalidArgumentException"> Thrown when an Invalid Argument error condition
        ///                                             occurs. </exception>
        ///
        /// <param name="generatorItems">   The generator items. </param>
        /// <param name="item">             The item. </param>
        ///
        /// <returns>   The new class builder. </returns>

        public ClassBuilder CreateClassBuilder(List<GeneratorItem> generatorItems, GeneratorItem item)
        {
            Database database = this.ConnectToServer(this._connectionInfo).Databases[item.DatabaseName];
            string tableName = item.TableName;
            database.DefaultSchema = item.SchemaName;
            Table table = database.Tables[tableName];
            if (table == null)
            {
                throw new InvalidArgumentException(string.Format("Table {0} not found. ", tableName),null);
            }
            ClassBuilder builder = new ClassBuilder();
            builder.ClassName = this.FormatClassName(string.IsNullOrEmpty(item.ClassName) ? item.TableName : item.ClassName);
            builder.DatabaseName = item.DatabaseName;
            builder.LocalSchemaName = this.FormatSchemaName(item.DatabaseName, this._connectionInfo.Database, this.CrossDatabasePrefix, item.SchemaName);
            builder.SchemaName = item.SchemaName;
            builder.TableName = item.TableName;
            builder.Properties = new List<PropertyBuilder>();
            this.BuildProperties(table, builder.Properties, item.ShowForeignKeyColumns, item);
            if (item.ShowNavigationProperties)
            {
                this.BuildNavigationProperties(generatorItems, table, builder.Properties, item);
            }
            return builder;
        }

        /// <summary>   Executes the query operation. </summary>
        ///
        /// <remarks>    </remarks>
        ///
        /// <param name="sql">  The SQL. </param>
        ///
        /// <returns>   A List&lt;QueryRecord&gt; </returns>

        public List<QueryRecord> ExecuteQuery(string sql)
        {
            ConnectionInfo info = this._connectionInfo;
            ServerConnection connection = new ServerConnection(info.Server, info.Username, info.Password);
            connection.DatabaseName = info.Database;
            if (!connection.IsOpen)
            {
                connection.Connect();
            }
            List<QueryRecord> list = new List<QueryRecord>();
            string[] columnNames = null;
            using (SqlDataReader reader = connection.ExecuteReader(sql))
            {
                while (reader.Read())
                {
                    if (columnNames == null)
                    {
                        columnNames = this.BuildColumnNames(reader);
                    }
                    list.Add(this.BuildRecord(reader, columnNames));
                }
                reader.Close();
            }
            return list;
        }

        /// <summary>   Format class name. </summary>
        ///
        /// <remarks>    </remarks>
        ///
        /// <param name="className">    Name of the class. </param>
        ///
        /// <returns>   The formatted class name. </returns>

        public string FormatClassName(string className)
        {
            return StringExtensions.RemoveAtEnd(className, "s", 0);
        }

        /// <summary>   Format navigation name. </summary>
        ///
        /// <remarks>    </remarks>
        ///
        /// <param name="columnName">   Name of the column. </param>
        ///
        /// <returns>   The formatted navigation name. </returns>

        public string FormatNavigationName(string columnName)
        {
            string str = columnName;
            return StringExtensions.RemoveAtEnd(str, "id", 0);
        }

        /// <summary>   Format property name. </summary>
        ///
        /// <remarks>    </remarks>
        ///
        /// <param name="propertyName"> Name of the property. </param>
        ///
        /// <returns>   The formatted property name. </returns>

        public string FormatPropertyName(string propertyName)
        {
            return StringExtensions.Capitalize(propertyName);
        }

        /// <summary>   Format schema name. </summary>
        ///
        /// <remarks>    </remarks>
        ///
        /// <param name="targetDatabase">   Target database. </param>
        ///
        /// <returns>   The formatted schema name. </returns>

        public string FormatSchemaName(string targetDatabase)
        {
            return this.FormatSchemaName(targetDatabase, this._connectionInfo.Database, this.CrossDatabasePrefix, string.Empty);
        }

        /// <summary>   Format schema name. </summary>
        ///
        /// <remarks>    </remarks>
        ///
        /// <param name="targetDatabase">       Target database. </param>
        /// <param name="currentDatabase">      The current database. </param>
        /// <param name="crossDatabasePrefix">  The cross database prefix. </param>
        /// <param name="defaultSchema">        The default schema. </param>
        ///
        /// <returns>   The formatted schema name. </returns>

        public string FormatSchemaName(string targetDatabase, string currentDatabase, string crossDatabasePrefix, string defaultSchema)
        {
            if (targetDatabase == currentDatabase)
            {
                return defaultSchema;
            }
            return (crossDatabasePrefix + targetDatabase);
        }

        /// <summary>   Gets data type size. </summary>
        ///
        /// <remarks>    </remarks>
        ///
        /// <param name="dataType">     Type of the data. </param>
        /// <param name="maxLength">    The maximum length. </param>
        ///
        /// <returns>   The data type size. </returns>

        public int? GetDataTypeSize(SqlDataType dataType, int maxLength)
        {
            SqlDataType type = dataType;
            if (type <= SqlDataType.NVarChar)
            {
                switch (type)
                {
                    case SqlDataType.NChar:
                    case SqlDataType.NVarChar:
                    case SqlDataType.Char:
                        goto Label_002C;

                    case SqlDataType.NText:
                        goto Label_0033;
                }
                goto Label_0033;
            }
            if ((type != SqlDataType.VarChar) && (type != SqlDataType.Xml))
            {
                goto Label_0033;
            }
        Label_002C:
            return new int?(maxLength);
        Label_0033:
            return null;
        }

        /// <summary>   Gets dot net data type. </summary>
        ///
        /// <remarks>    </remarks>
        ///
        /// <param name="dataTypeA">    The data type a. </param>
        /// <param name="precision">    The precision. </param>
        /// <param name="scale">        The scale. </param>
        /// <param name="isRequired">   true if this object is required. </param>
        ///
        /// <returns>   The dot net data type. </returns>

        public string GetDotNetDataType(SqlDataType dataTypeA, int precision, int scale, bool isRequired)
        {
            Type type;
            switch (dataTypeA)
            {
                case SqlDataType.BigInt:
                    type = typeof(long);
                    break;

                case SqlDataType.Binary:
                case SqlDataType.Image:
                case SqlDataType.Timestamp:
                case SqlDataType.VarBinary:
                case SqlDataType.VarBinaryMax:
                    type = typeof(byte[]);
                    break;

                case SqlDataType.Bit:
                    type = typeof(bool);
                    break;

                case SqlDataType.Char:
                case SqlDataType.NChar:
                case SqlDataType.NText:
                case SqlDataType.NVarChar:
                case SqlDataType.NVarCharMax:
                case SqlDataType.Text:
                case SqlDataType.VarChar:
                case SqlDataType.VarCharMax:
                case SqlDataType.Xml:
                    type = typeof(string);
                    break;

                case SqlDataType.DateTime:
                case SqlDataType.SmallDateTime:
                case SqlDataType.Date:
                case SqlDataType.Time:
                case SqlDataType.DateTime2:
                    type = typeof(DateTime);
                    break;

                case SqlDataType.Decimal:
                case SqlDataType.Money:
                    type = typeof(decimal);
                    break;

                case SqlDataType.Float:
                    type = typeof(float);
                    break;

                case SqlDataType.Int:
                    type = typeof(int);
                    break;

                case SqlDataType.SmallInt:
                    type = typeof(short);
                    break;

                case SqlDataType.TinyInt:
                    type = typeof(byte);
                    break;

                case SqlDataType.UniqueIdentifier:
                    type = typeof(Guid);
                    break;

                case SqlDataType.Numeric:
                    if ((precision <= 0) && (scale <= 0))
                    {
                        type = typeof(int);
                    }
                    else
                    {
                        type = typeof(decimal);
                    }
                    break;

                default:
                    type = typeof(object);
                    break;
            }
            string name = type.Name;
            if ((!isRequired && (type != typeof(string))) && ((type != typeof(object)) && (type != typeof(byte[]))))
            {
                name = name + "?";
            }
            return name;
        }

        /// <summary>   Gets or sets the cross database prefix. </summary>
        ///
        /// <value> The cross database prefix. </value>

        public string CrossDatabasePrefix
        { get; set; }
    }
}

