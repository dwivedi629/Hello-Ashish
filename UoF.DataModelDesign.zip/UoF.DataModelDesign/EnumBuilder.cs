﻿
namespace UOF.DataModelDesign
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.CompilerServices;

    public class EnumBuilder
    {
        //[CompilerGenerated]
        //private Dictionary<string, MetaData[]> <EnumItems>k__BackingField;
        //[CompilerGenerated]
        //private string[] <EnumNames>k__BackingField;

        /// <summary>   From query result. </summary>
        ///
        /// <remarks>   </remarks>
        ///
        /// <param name="results">              The results. </param>
        /// <param name="enumColumn">           The enum column. </param>
        /// <param name="enumItemColumn">       The enum item column. </param>
        /// <param name="descriptionColumn">    The description column. </param>
        ///
        /// <returns>   An EnumBuilder. </returns>

        public static EnumBuilder FromQueryResult(List<QueryRecord> results, string enumColumn, string enumItemColumn, string descriptionColumn)
        {
            Func<QueryRecord, MetaData> selector = null;
            EnumBuilder builder = new EnumBuilder();
            builder.EnumNames = results.Select<QueryRecord, string>(delegate(QueryRecord r)
            {
                return r[enumColumn];
            }).Distinct<string>().ToArray<string>();
            builder.EnumItems = new Dictionary<string, MetaData[]>();
            foreach (string str in builder.EnumNames)
            {
                string name = str;
                if (selector == null)
                {
                    selector = delegate(QueryRecord r)
                    {
                        return new MetaData { Name = r[enumItemColumn], Description = string.IsNullOrEmpty(descriptionColumn) ? string.Empty : r[descriptionColumn] };
                    };
                }
                MetaData[] dataArray = results.Where<QueryRecord>(delegate(QueryRecord x)
                {
                    return (x[enumColumn] == name);
                }).ToArray<QueryRecord>().Select<QueryRecord, MetaData>(selector).ToArray<MetaData>();
                builder.EnumItems.Add(name, dataArray);
            }
            return builder;
        }

        /// <summary>   Gets or sets the enum items. </summary>
        ///
        /// <value> The enum items. </value>

        public Dictionary<string, MetaData[]> EnumItems
        { get; set; }

        /// <summary>   Gets or sets a list of names of the enums. </summary>
        ///
        /// <value> A list of names of the enums. </value>

        public string[] EnumNames
        { get; set; }
    }
}
