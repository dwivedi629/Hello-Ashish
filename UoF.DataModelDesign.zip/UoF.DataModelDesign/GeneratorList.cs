﻿
namespace UOF.DataModelDesign
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Xml.Serialization;

    /// <summary>   List of generators. </summary>
    ///
    /// <remarks>   </remarks>

    [Serializable, XmlRoot(ElementName = "GeneratorList")]
    public class GeneratorList : List<GeneratorItem>
    {
        /// <summary>   Gets database list. </summary>
        ///
        /// <remarks>   </remarks>
        ///
        /// <returns>   The database list. </returns>

        public List<string> GetDatabaseList()
        {
            return this.Where<GeneratorItem>(delegate(GeneratorItem x)
            {
                return !string.IsNullOrEmpty(x.DatabaseName);
            }).Select<GeneratorItem, string>(delegate(GeneratorItem x)
            {
                return x.DatabaseName;
            }).Distinct<string>().ToList<string>();
        }

        /// <summary>   Gets a list. </summary>
        ///
        /// <remarks>    </remarks>
        ///
        /// <param name="filePath"> Full pathname of the file. </param>
        ///
        /// <returns>   The list. </returns>

        public static GeneratorList GetList(string filePath)
        {
            GeneratorList list;
            FileInfo info = new FileInfo(filePath);
            XmlSerializer serializer = new XmlSerializer(typeof(GeneratorList));
            using (FileStream stream = info.OpenRead())
            {
                try
                {
                    list = (GeneratorList)serializer.Deserialize(info.OpenRead());
                }
                finally
                {
                    stream.Close();
                }
            }
            return list;
        }

        /// <summary>   Serializes the given file. </summary>
        ///
        /// <remarks>   </remarks>
        ///
        /// <param name="path"> Full pathname of the file. </param>

        public void Serialize(string path)
        {
            FileInfo info = new FileInfo(path);
            XmlSerializer serializer = new XmlSerializer(typeof(GeneratorList));
            using (FileStream stream = info.OpenWrite())
            {
                try
                {
                    serializer.Serialize((Stream)stream, this);
                }
                finally
                {
                    stream.Close();
                }
            }
        }
    }
}
