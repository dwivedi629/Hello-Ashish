﻿namespace UOF.DataModelDesign
{
    using System;
    using System.Runtime.CompilerServices;
    using System.Xml.Serialization;

    [Serializable]
    public class GeneratorItem
    {
        //[CompilerGenerated]
        //private string <ClassName>k__BackingField;
        //[CompilerGenerated]
        //private string <DatabaseName>k__BackingField;
        //[CompilerGenerated]
        //private bool <RequireNavProperties>k__BackingField;
        //[CompilerGenerated]
        //private string <SchemaName>k__BackingField;
        //[CompilerGenerated]
        //private bool <ShowForeignKeyColumns>k__BackingField;
        //[CompilerGenerated]
        //private bool <ShowNavigationProperties>k__BackingField;
        //[CompilerGenerated]
        //private string <TableName>k__BackingField;

        /// <summary>   Default constructor. </summary>
        ///
        /// <remarks>    </remarks>

        public GeneratorItem()
        {
            this.ShowForeignKeyColumns = true;
            this.ShowNavigationProperties = true;
            this.RequireNavProperties = false;
        }

        /// <summary>
        /// Determines whether the specified <see cref="T:System.Object" /> is equal to the current
        /// <see cref="T:System.Object" />.
        /// </summary>
        ///
        /// <remarks>    </remarks>
        ///
        /// <param name="obj">  The object to compare with the current object. </param>
        ///
        /// <returns>
        /// true if the specified object  is equal to the current object; otherwise, false.
        /// </returns>

        public override bool Equals(object obj)
        {
            GeneratorItem item = obj as GeneratorItem;
            if (item == null)
            {
                return false;
            }
            return (this.GetHashCode() == item.GetHashCode());
        }

        /// <summary>   Serves as a hash function for a particular type. </summary>
        ///
        /// <remarks>   </remarks>
        ///
        /// <returns>   A hash code for the current <see cref="T:System.Object" />. </returns>

        public override int GetHashCode()
        {
            return ((this.DatabaseName.GetHashCode() + this.SchemaName.GetHashCode()) + this.TableName.GetHashCode());
        }

        /// <summary>   Gets schema name. </summary>
        ///
        /// <remarks>   </remarks>
        ///
        /// <param name="linkedDatabasePrefix"> The linked database prefix. </param>
        /// <param name="sourceDatabaseName">   Name of the source database. </param>
        /// <param name="sourceSchema">         Source schema. </param>
        ///
        /// <returns>   The schema name. </returns>

        public string GetSchemaName(string linkedDatabasePrefix, string sourceDatabaseName, string sourceSchema)
        {
            if (!(sourceDatabaseName == this.DatabaseName))
            {
                return (linkedDatabasePrefix + this.DatabaseName);
            }
            return sourceSchema;
        }

        /// <summary>   Gets or sets the name of the class. </summary>
        ///
        /// <value> The name of the class. </value>

        [XmlAttribute(AttributeName = "className")]
        public string ClassName
        { get; set; }

        /// <summary>   Gets or sets the name of the database. </summary>
        ///
        /// <value> The name of the database. </value>

        [XmlAttribute(AttributeName = "databaseName")]
        public string DatabaseName
        { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the require navigaiton properties.
        /// </summary>
        ///
        /// <value> true if require navigaiton properties, false if not. </value>

        [XmlAttribute(AttributeName = "requireNavProperties")]
        public bool RequireNavProperties
        { get; set; }

        /// <summary>   Gets or sets the name of the schema. </summary>
        ///
        /// <value> The name of the schema. </value>

        [XmlAttribute(AttributeName = "schemaName")]
        public string SchemaName
        { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the foreign key columns is shown.
        /// </summary>
        ///
        /// <value> true if show foreign key columns, false if not. </value>

        [XmlAttribute(AttributeName = "showNavColumns")]
        public bool ShowForeignKeyColumns
        { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the navigation properties is shown.
        /// </summary>
        ///
        /// <value> true if show navigation properties, false if not. </value>

        [XmlAttribute(AttributeName = "showNavProperties")]
        public bool ShowNavigationProperties
        { get; set; }

        /// <summary>   Gets or sets the name of the table. </summary>
        ///
        /// <value> The name of the table. </value>

        [XmlAttribute(AttributeName = "tableName")]
        public string TableName
        { get; set; }
    }
}
