﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UOF.DataModelDesign
{
    /// <summary>   Bitfield of flags for specifying StringReplacementOptions. </summary>
    ///
    /// <remarks>   </remarks>

    [Flags]
    public enum StringReplacementOptions
    {
        None=0,
        CaseSensitive
    }

 

 

}
