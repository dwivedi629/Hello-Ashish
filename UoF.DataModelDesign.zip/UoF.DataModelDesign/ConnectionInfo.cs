﻿
namespace UOF.DataModelDesign
{
    using System;
    using System.Configuration;
    using System.Data.Common;
    using System.Runtime.CompilerServices;
    using System.Web.Configuration;
    //using System.Web.Configuration;

    public class ConnectionInfo
    {
        //[CompilerGenerated]
        //private string <Database>k__BackingField;
        //[CompilerGenerated]
        //private string <Password>k__BackingField;
        //[CompilerGenerated]
        //private string <Server>k__BackingField;
        //[CompilerGenerated]
        //private string <Username>k__BackingField;

        /// <summary>   Gets connection string. </summary>
        ///
        /// <remarks>    </remarks>
        ///
        /// <param name="config">   The configuration. </param>
        /// <param name="key">      The key. </param>
        ///
        /// <returns>   The connection string. </returns>

        private static string GetConnectionString(string key)
        {
            //Console.WriteLine(config.FilePath);
            //ConnectionStringSettings settings = config.ConnectionStrings.ConnectionStrings[key];
            //if (settings != null)
            //{
            //    return settings.ConnectionString;
            //}
            //foreach (ConfigurationLocation location in config.Locations)
            //{
            //    return GetConnectionString(location.OpenConfiguration(), key);
            //}
            //return string.Empty;
            // return ConfigurationManager.ConnectionStrings[key].ConnectionString;
            //<add name="UOFDataContext" providerName="system.data.sqlclient" connectionString="server=WIN8\SQLEXPRESS;database=UoF;persist security info=true;user=sa;password=mind@123;multipleactiveresultsets=true;" />
            return "server=WIN8\\SQLEXPRESS;database=UoF;persist security info=true;user=sa;password=mind@123;multipleactiveresultsets=true;";
        }

        /// <summary>   Parse web configuration. </summary>
        ///
        /// <remarks>  </remarks>
        ///
        /// <exception cref="InvalidOperationException">    Thrown when the requested operation is
        ///                                                 invalid. </exception>
        ///
        /// <param name="path"> Full pathname of the file. </param>
        /// <param name="key">  The key. </param>
        ///
        /// <returns>   A ConnectionInfo. </returns>

        public static ConnectionInfo ParseWebConfig(string path, string key)
        {
            //VirtualDirectoryMapping mapping = new VirtualDirectoryMapping(path.Replace("Web.config", ""), true);
            //WebConfigurationFileMap fileMap = new WebConfigurationFileMap();
            //fileMap.VirtualDirectories.Add("/", mapping);
            //System.Configuration.Configuration config = WebConfigurationManager.OpenMappedWebConfiguration(fileMap, "/");
            //if (config == null)
            //{
            //    throw new InvalidOperationException(string.Format("'{0}' file not found", path));
            //}
            string connectionString = GetConnectionString(key);
            if (string.IsNullOrEmpty(connectionString))
            {
                throw new InvalidOperationException(string.Format("'{0}' connection string key not found", key));
            }
            DbConnectionStringBuilder builder = new DbConnectionStringBuilder();
            builder.ConnectionString = connectionString;

            ConnectionInfo info = new ConnectionInfo();
            info.Server = Convert.ToString(builder["server"]);
            info.Database = Convert.ToString(builder["database"]);
            info.Username = Convert.ToString(builder["user"]);
            info.Password = Convert.ToString(builder["password"]);
            return info;
        }

        /// <summary>   Gets or sets the database. </summary>
        ///
        /// <value> The database. </value>

        public string Database
        { get; set; }

        /// <summary>   Gets or sets the password. </summary>
        ///
        /// <value> The password. </value>

        public string Password
        { get; set; }

        /// <summary>   Gets or sets the server. </summary>
        ///
        /// <value> The server. </value>

        public string Server
        { get; set; }

        /// <summary>   Gets or sets the username. </summary>
        ///
        /// <value> The username. </value>

        public string Username
        { get; set; }
    }
}
