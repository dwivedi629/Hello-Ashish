﻿namespace UOF.DataModelDesign
{
    using System;
    using System.Runtime.CompilerServices;

    public class MetaData
    {
        //    [CompilerGenerated]
        //    private string <Description>k__BackingField;
        //    [CompilerGenerated]
        //    private string <Name>k__BackingField;

        /// <summary>   Gets or sets the description. </summary>
        ///
        /// <value> The description. </value>

        public string Description
        { get; set; }

        /// <summary>   Gets or sets the name. </summary>
        ///
        /// <value> The name. </value>

        public string Name
        { get; set; }
    }
}
