﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

namespace UOF.DataModelDesign
{
    /// <summary>   A string extensions.</summary>
    ///
    /// <remarks>    </remarks>

    public static class StringExtensions
{
    // Methods. 
    public static string Capitalize(this string source)
    {
        if (string.IsNullOrEmpty(source))
        {
            return source;
        }
        char ch = source[0];
        return (ch.ToString(CultureInfo.InvariantCulture).ToUpper() + source.Remove(0, 1));
    }

    /// <summary>
    /// A string extension method that query if this object contains the given source.
    /// </summary>
    ///
    /// <remarks>    </remarks>
    ///
    /// <param name="source">           The source to act on. </param>
    /// <param name="find">             The find. </param>
    /// <param name="compOperation">    The component operation. </param>
    ///
    /// <returns>   true if the object is in this collection, false if not. </returns>

    public static bool Contains(this string source, string find, StringComparison compOperation)
    {
        return (source.IndexOf(find, compOperation) >= 0);
    }

    /// <summary>
    /// A string extension method that query if 'source' contains case insensitive.
    /// </summary>
    ///
    /// <remarks>    </remarks>
    ///
    /// <param name="source">   The source to act on. </param>
    /// <param name="find">     The find. </param>
    ///
    /// <returns>   true if it succeeds, false if it fails. </returns>

    public static bool ContainsCaseInsensitive(this string source, string find)
    {
        return source.Contains(find, StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>   A string extension method that defaults. </summary>
    ///
    /// <remarks>    </remarks>
    ///
    /// <param name="source">       The source to act on. </param>
    /// <param name="defaultValue"> The default value. </param>
    ///
    /// <returns>   A string. </returns>

    public static string Default(this string source, string defaultValue)
    {
        if (!string.IsNullOrEmpty(source))
        {
            return source;
        }
        return defaultValue;
    }

    /// <summary>   A string extension method that equals no case. </summary>
    ///
    /// <remarks>    </remarks>
    ///
    /// <param name="source">   The source to act on. </param>
    /// <param name="compare">  The compare. </param>
    ///
    /// <returns>   true if equals no case, false if not. </returns>

    public static bool EqualsNoCase(this string source, string compare)
    {
        return source.Equals(compare, StringComparison.InvariantCultureIgnoreCase);
    }

    /// <summary>   A string extension method that null parse. </summary>
    ///
    /// <remarks>    </remarks>
    ///
    /// <typeparam name="TType">    Type of the type. </typeparam>
    /// <param name="source">   The source to act on. </param>
    ///
    /// <returns>   A TType? </returns>

    public static TType? NullParse<TType>(this string source) where TType: struct
    {
        if (!string.IsNullOrEmpty(source))
        {
            object obj2 = TypeDescriptor.GetConverter(typeof(TType)).ConvertFromString(source);
            if (obj2 != null)
            {
                return new TType?((TType) obj2);
            }
        }
        return null;
    }

    /// <summary>   A string extension method that removes at end. </summary>
    ///
    /// <remarks>    </remarks>
    ///
    /// <param name="source">   The source to act on. </param>
    /// <param name="target">   Target for the. </param>
    /// <param name="options">  Options for controlling the operation. </param>
    ///
    /// <returns>   A string. </returns>

    public static string RemoveAtEnd(this string source, string target, [Optional, DefaultParameterValue(StringReplacementOptions.None)] StringReplacementOptions options)
    {
        if ((string.IsNullOrEmpty(source) || string.IsNullOrEmpty(target)) || (source.Length < target.Length))
        {
            return source;
        }
        if (((options & StringReplacementOptions.CaseSensitive) == StringReplacementOptions.CaseSensitive) && !source.EndsWith(target))
        {
            return source;
        }
        if (!source.ToUpper().EndsWith(target.ToUpper()))
        {
            return source;
        }
        return source.Remove(source.Length - target.Length);
    }

    /// <summary>   A string extension method that removes the null described by source. </summary>
    ///
    /// <remarks>    </remarks>
    ///
    /// <param name="source">   The source to act on. </param>
    ///
    /// <returns>   A string. </returns>

    public static string RemoveNull(this string source)
    {
        return source.Default("");
    }

    /// <summary>   A string extension method that replace at end. </summary>
    ///
    /// <remarks>    </remarks>
    ///
    /// <param name="source">       The source to act on. </param>
    /// <param name="target">       Target for the. </param>
    /// <param name="replacement">  The replacement. </param>
    ///
    /// <returns>   A string. </returns>

    public static string ReplaceAtEnd(this string source, string target, string replacement)
    {
        string str = source.RemoveAtEnd(target, StringReplacementOptions.CaseSensitive);
        if (str == source)
        {
            return source;
        }
        return (str + replacement);
    }
}

 


}
