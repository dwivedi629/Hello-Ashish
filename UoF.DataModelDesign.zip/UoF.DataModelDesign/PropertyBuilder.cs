﻿namespace UOF.DataModelDesign
{
    using System;
    using System.Runtime.CompilerServices;

    public class PropertyBuilder
    {
        //[CompilerGenerated]
        //private string <ColumnName>k__BackingField;
        //[CompilerGenerated]
        //private string <DatabaseDataType>k__BackingField;
        //[CompilerGenerated]
        //private bool <IsIdentity>k__BackingField;
        //[CompilerGenerated]
        //private bool <IsNavigationProperty>k__BackingField;
        //[CompilerGenerated]
        //private bool <IsPrimaryKey>k__BackingField;
        //[CompilerGenerated]
        //private bool <IsRequired>k__BackingField;
        //[CompilerGenerated]
        //private bool <IsRowVersion>k__BackingField;
        //[CompilerGenerated]
        //private string <PropertyDataType>k__BackingField;
        //[CompilerGenerated]
        //private int <PropertyIndex>k__BackingField;
        //[CompilerGenerated]
        //private string <PropertyName>k__BackingField;
        //[CompilerGenerated]
        //private GeneratorItem <Settings>k__BackingField;
        //[CompilerGenerated]
        //private int? <Size>k__BackingField;

        /// <summary>   Constructor. </summary>
        ///
        /// <remarks>   </remarks>
        ///
        /// <param name="settings"> Options for controlling the operation. </param>

        public PropertyBuilder(GeneratorItem settings)
        {
            this.Settings = settings;
        }

        /// <summary>   Gets the attribute builder. </summary>
        ///
        /// <value> The attribute builder. </value>

        public AttributeBuilder AttributeBuilder
        {
            get
            {
                return new AttributeBuilder(this);
            }
        }

        /// <summary>   Gets or sets the name of the column. </summary>
        ///
        /// <value> The name of the column. </value>

        public string ColumnName
        { get; set; }

        /// <summary>   Gets or sets the type of the database data. </summary>
        ///
        /// <value> The type of the database data. </value>

        public string DatabaseDataType
        { get; set; }

        /// <summary>   Gets or sets a value indicating whether this object is identity. </summary>
        ///
        /// <value> true if this object is identity, false if not. </value>

        public bool IsIdentity
        { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this object is navigation property.
        /// </summary>
        ///
        /// <value> true if this object is navigation property, false if not. </value>

        public bool IsNavigationProperty
        { get; set; }

        /// <summary>   Gets or sets a value indicating whether this object is primary key. </summary>
        ///
        /// <value> true if this object is primary key, false if not. </value>

        public bool IsPrimaryKey
        { get; set; }

        /// <summary>   Gets or sets a value indicating whether this object is required. </summary>
        ///
        /// <value> true if this object is required, false if not. </value>

        public bool IsRequired
        { get; set; }

        /// <summary>   Gets or sets a value indicating whether this object is row version. </summary>
        ///
        /// <value> true if this object is row version, false if not. </value>

        public bool IsRowVersion
        { get; set; }

        /// <summary>   Gets or sets the type of the property data. </summary>
        ///
        /// <value> The type of the property data. </value>

        public string PropertyDataType
        { get; set; }

        /// <summary>   Gets or sets the zero-based index of the property. </summary>
        ///
        /// <value> The property index. </value>

        public int PropertyIndex
        { get; set; }

        /// <summary>   Gets or sets the name of the property. </summary>
        ///
        /// <value> The name of the property. </value>

        public string PropertyName
        { get; set; }

        /// <summary>   Gets or sets options for controlling the operation. </summary>
        ///
        /// <value> The settings. </value>

        public GeneratorItem Settings
        { get; set; }

        /// <summary>   Gets or sets the size. </summary>
        ///
        /// <value> The size. </value>

        public int? Size
        { get; set; }
    }
}

