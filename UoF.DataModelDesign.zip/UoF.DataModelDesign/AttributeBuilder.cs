﻿namespace UOF.DataModelDesign
{
    using System;
    using System.Text;

    /// <summary>   An attribute builder. </summary>
    ///
    /// <remarks>   </remarks>

    public class AttributeBuilder
    {

        /// <summary>   Information describing the attribute. </summary>
        private readonly StringBuilder _attributeData = new StringBuilder();

        /// <summary>   The property builder. </summary>
        private readonly PropertyBuilder _propertyBuilder;

        /// <summary>   Constructor. </summary>
        ///
        /// <remarks>   </remarks>
        ///
        /// <param name="property"> The property. </param>

        public AttributeBuilder(PropertyBuilder property)
        {
            this._propertyBuilder = property;
        }

        /// <summary>   Appends the attribute space. </summary>
        ///
        /// <remarks>   </remarks>

        private void AppendAttributeSpace()
        {
            if (this._attributeData.Length != 0)
            {
                this._attributeData.Append("\r\n");
                this._attributeData.Append('\t', 3);
            }
        }

        /// <summary>   Builds column attribute. </summary>
        ///
        /// <remarks>   </remarks>
        ///
        /// <param name="includeColumnOrder">   true to include, false to exclude the column order. </param>
        ///
        /// <returns>   An AttributeBuilder. </returns>

        public AttributeBuilder BuildColumnAttribute(bool includeColumnOrder)
        {
            if (!this._propertyBuilder.IsNavigationProperty)
            {
                this.AppendAttributeSpace();
                this._attributeData.Append(string.Format("[Column(\"{0}\"", this._propertyBuilder.ColumnName));
                if (includeColumnOrder)
                {
                    this._attributeData.Append(string.Format(", Order={0}", this._propertyBuilder.PropertyIndex));
                }
                this._attributeData.Append(")]");
            }
            return this;
        }

        /// <summary>   Builds data type attribute. </summary>
        ///
        /// <remarks>   </remarks>
        ///
        /// <returns>   An AttributeBuilder. </returns>

        public AttributeBuilder BuildDataTypeAttribute()
        {
            if (this._propertyBuilder.PropertyDataType == typeof(string).Name)
            {
                return this.BuildStringLengthAttribute();
            }
            if (this._propertyBuilder.IsRowVersion)
            {
                return this.BuildTimestampAttribute();
            }
            return this;
        }

        /// <summary>   Builds foreign key attribute. </summary>
        ///
        /// <remarks>   </remarks>
        ///
        /// <returns>   An AttributeBuilder. </returns>

        public AttributeBuilder BuildForeignKeyAttribute()
        {
            if (this._propertyBuilder.IsNavigationProperty)
            {
                string format = "[ForeignKey(\"{0}\")]";
                this.AppendAttributeSpace();
                this._attributeData.Append(string.Format(format, this._propertyBuilder.ColumnName));
            }
            return this;
        }

        /// <summary>   Builds key attribute. </summary>
        ///
        /// <remarks>   </remarks>
        ///
        /// <returns>   An AttributeBuilder. </returns>

        public AttributeBuilder BuildKeyAttribute()
        {
            if (this._propertyBuilder.IsPrimaryKey)
            {
                this.AppendAttributeSpace();
                this._attributeData.Append("[");
                this._attributeData.Append("Key");
                this._attributeData.Append(this._propertyBuilder.IsIdentity ? ", DatabaseGenerated(DatabaseGeneratedOption.Identity)" : ", DatabaseGenerated(DatabaseGeneratedOption.None)");
                this._attributeData.Append("]");
            }
            return this;
        }

        /// <summary>   Builds required attribute. </summary>
        ///
        /// <remarks>   </remarks>
        ///
        /// <returns>   An AttributeBuilder. </returns>

        public AttributeBuilder BuildRequiredAttribute()
        {
            GeneratorItem settings = this._propertyBuilder.Settings;
            string str = "[Required]";
            if (this._propertyBuilder.IsRequired && ((!this._propertyBuilder.IsNavigationProperty || (this._propertyBuilder.IsNavigationProperty && settings.RequireNavProperties)) || (this._propertyBuilder.IsNavigationProperty && !settings.ShowForeignKeyColumns)))
            {
                this.AppendAttributeSpace();
                this._attributeData.Append(str);
            }
            return this;
        }

        /// <summary>   Builds string length attribute. </summary>
        ///
        /// <remarks>   </remarks>
        ///
        /// <returns>   An AttributeBuilder. </returns>

        public AttributeBuilder BuildStringLengthAttribute()
        {
            if (((this._propertyBuilder.PropertyDataType == typeof(string).Name) && this._propertyBuilder.Size.HasValue) && (this._propertyBuilder.Size.Value > 0))
            {
                string format = "[StringLength({0})]";
                this.AppendAttributeSpace();
                this._attributeData.Append(string.Format(format, this._propertyBuilder.Size));
            }
            return this;
        }

        /// <summary>   Builds timestamp attribute. </summary>
        ///
        /// <remarks>   </remarks>
        ///
        /// <returns>   An AttributeBuilder. </returns>

        public AttributeBuilder BuildTimestampAttribute()
        {
            string str = "[Timestamp]";
            this.AppendAttributeSpace();
            this._attributeData.Append(str);
            return this;
        }

        /// <summary>   Gets the write. </summary>
        ///
        /// <remarks>   </remarks>
        ///
        /// <returns>   A string. </returns>

        public string Write()
        {
            string str = this._attributeData.ToString();
            this._attributeData.Clear();
            return str;
        }
    }
}
