﻿namespace UOF.DataModelDesign
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;

    public class QueryRecord : Dictionary<string, string>
    {
        /// <summary>
        /// Indexer to get or set items within this collection using array index syntax.
        /// </summary>
        ///
        /// <param name="column">   The column. </param>
        ///
        /// <returns>   The indexed item. </returns>

        public string this[string column]
        {
            get
            {
                if (base.Keys.Contains<string>(column))
                {
                    return base[column];
                }
                return string.Empty;
            }
            set
            {
                if (base.Keys.Contains<string>(column))
                {
                    base[column] = value;
                }
                else
                {
                    base.Add(column, value);
                }
            }
        }
    }
}

