﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Force_DL
{
    internal interface IForceRepository<IEntity>
    {
        IEnumerable<IEntity> GetAllRecord();

        void Add(IEntity entity);

        void Update(IEntity entity);

        IEntity SearchEntity(int fId);

        void Delete(IEntity entity);
    }
}
