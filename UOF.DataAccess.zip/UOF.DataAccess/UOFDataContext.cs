﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.DataAccess
{
    public class UOFDataContext : BaseEntityFrameworkDbContext
    {
        static UOFDataContext()
        {
            Database.SetInitializer<UOFDataContext>(null);
        }
        public DbSet<Addres> Addresses { get; set; }
        public DbSet<AddressType> AddressTypes { get; set; }
        public DbSet<CFRT_RolledOut> CFRT_RolledOut { get; set; }
        public DbSet<ChargeCode> ChargeCodes { get; set; }
        public DbSet<ChargeCodeType> ChargeCodeTypes { get; set; }
        public DbSet<Contact> Contacts { get; set; }
        public DbSet<ContactType> ContactTypes { get; set; }
        public DbSet<ForceOnSuspect> ForceOnSuspects { get; set; }
        public DbSet<Handler> Handlers { get; set; }
        public DbSet<Hospital> Hospitals { get; set; }
        public DbSet<IAB_RolledOut> IAB_RolledOut { get; set; }
        public DbSet<Incident> Incidents { get; set; }
        public DbSet<IncidentCanineDeployment> IncidentCanineDeployments { get; set; }
        public DbSet<IncidentUser> IncidentUsers { get; set; }
        public DbSet<IncidentUserChargeCode> IncidentUserChargeCodes { get; set; }
        public DbSet<IncidentUserCopy> IncidentUserCopies { get; set; }
        public DbSet<IncidentUserDirector> IncidentUserDirectors { get; set; }
        public DbSet<IncidentStatisticalData> IncidentStatisticalData { get; set; }
        public DbSet<IncidentUserInterview> IncidentUserInterviews { get; set; }
        public DbSet<IncidentUserInvolved> IncidentUserInvolved { get; set; }
        public DbSet<IncidentUserSuspect> IncidentUserSuspects { get; set; }
        public DbSet<IncidentUserWitnes> IncidentUserWitnesses { get; set; }
        public DbSet<Treatment> Treatments { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<UserAddres> UserAddresses { get; set; }
        public DbSet<UserContact> UserContacts { get; set; }
        public DbSet<UserDetail> UserDetails { get; set; }
        public DbSet<UserType> UserTypes { get; set; }
        public DbSet<InmateInjury> InmateInjurys { get; set; }
        public DbSet<FormPermisssion> FormPermission { get; set; }
        public DbSet<UserRole> UserRole { get; set; }
        public DbSet<UofForm> UofForm { get; set; }
        public DbSet<IncidentCategoryForm> IncidentCategoryForm { get; set; }
        public DbSet<IncidentFormData> IncidentFormData { get; set; }

        public DbSet<LookupBodyPart> LookupBodyPart { get; set; }
        public DbSet<LookupInjury> LookupInjury { get; set; }
        public DbSet<LookupBureau> LookupBureau { get; set; }
        public DbSet<LookupMethod> LookupMethod { get; set; }
        public DbSet<LookupCity> LookupCity { get; set; }
        public DbSet<LookupContactType> LookupContactType { get; set; }
        public DbSet<LookupCustodyEvent> LookupCustodyEvent { get; set; }
        public DbSet<LookupDres> LookupDress { get; set; }
        public DbSet<LookupFacility> LookupFacility { get; set; }
        public DbSet<LookupInjurySeverity> LookupInjurySeverity { get; set; }
        public DbSet<LookupLocationofForce> LookupLocationofForce { get; set; }
        public DbSet<LookupPerceivedArmed> LookupPerceivedArmed { get; set; }
        public DbSet<LookupRace> LookupRace { get; set; }
        public DbSet<LookupResistance> LookupResistance { get; set; }
        public DbSet<LookupSex> LookupSex { get; set; }
        public DbSet<LookupArmed> LookupArmed { get; set; }
        public DbSet<LookupSubstance> LookupSubstance { get; set; }
        public DbSet<LookupConfirmedArmed> LookupConfirmedArmed { get; set; }

        public DbSet<IncidentWorkflow> IncidentWorkflow { get; set; }
        public DbSet<IncidentCFRTFlow> IncidentCFRTFlow { get; set; }
        public DbSet<IncidentFormReview> IncidentFormReview { get; set; }
        public DbSet<EmailNotification> EmailNotification { get; set; }
        public DbSet<ReturnComment> ReturnComment { get; set; }
        public DbSet<ReviewComment> ReviewComment { get; set; }
        public DbSet<IncidentSergeant> IncidentSergeant { get; set; }
        public DbSet<LookupStaging> LookupStaging { get; set; }
        public DbSet<LookupStation> LookupStation { get; set; }
        public DbSet<IncidentBusinessAddres> IncidentBusinessAddres { get; set; }
        public DbSet<LookupSecurityLevel> LookupSecurityLevel { get; set; }
        public DbSet<LookupSpecialHandle> LookupSpecialHandle { get; set; }
        public DbSet<LookupInmateDres> LookupInmateDress { get; set; }
        public DbSet<FormApprovalorReject> FormApprovalorReject { get; set; }
        public DbSet<IncidentFormExplaination> IncidentFormExplaination { get; set; }
        public DbSet<ArtifactsInformation> ArtifactsInformation { get; set; }
        public DbSet<UoF_ChangeRole> ChangeRole { get; set; }
        public DbSet<AT_ChangeOwner> ChangeOwner { get; set; }
        public DbSet<IncidentInvestigationOfficer> IncidentInvestigationOfficer { get; set; }
        public DbSet<IncidentRank> IncidentRank { get; set; }
        public DbSet<FormReviewRank> FormReviewRank { get; set; }
        public DbSet<IncidentPackage> IncidentPackage { get; set; }
        public DbSet<IncidentMedicalUser> IncidentMedicalUser { get; set; }
    }
}
