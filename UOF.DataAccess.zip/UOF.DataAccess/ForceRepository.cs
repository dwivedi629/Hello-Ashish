﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Force_DL
{
    public class ForceRepository<IEntity> : IForceRepository<IEntity> where IEntity : class
    {
        DbSet<IEntity> _dbSet;
        private USForceDbEntities _dbContext;

        public ForceRepository(USForceDbEntities dbContext)
        {
            _dbContext = dbContext;
            _dbSet = dbContext.Set<IEntity>();
        }

        public IEnumerable<IEntity> GetAllRecord()
        {
            return _dbSet.ToList();
        }

        public void Add(IEntity entity)
        {
            _dbSet.Add(entity);
        }


        public  void Update(IEntity entity)
        {
             _dbSet.Attach(entity);
             _dbContext.Entry(entity).State = System.Data.EntityState.Modified;

        }

        public IEntity SearchEntity(int fId)
        {
           return  _dbSet.Find(fId);
        }

        public void Delete(IEntity entity)
        {
            _dbSet.Remove(entity);
            _dbContext.Entry(entity).State = System.Data.EntityState.Deleted;
        }
    }
}
