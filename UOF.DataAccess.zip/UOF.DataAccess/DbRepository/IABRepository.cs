﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using UOF.Common.EntityModel;
using UOF.Common.Utilities;
using UOF.DataAccess.Repository;
namespace UOF.DataAccess.DbRepository
{
    public class IABRepository
    {
        UnitOfWork uow = new UnitOfWork();

        public int SaveIABData(IABModel model)
        {
            FormReviewRespository repo = new FormReviewRespository();
            int result = 0;
            model.UserRoleId = repo.GetUserRoleID(model.UserRole);
            int FormDataId = 0;
            model.UserRoleId = (int)Constants.UserRoles.WC;
            try
            {
                var sup = new SupplementalModel();
                var iabModel = uow.UOFIncidentFormDataRepository.FindBy(a => a.UserRoleId == model.UserRoleId && a.FormID == model.FormID && a.IncidentID == model.IncidentID && a.EmpID == model.EmpID).FirstOrDefault();
                if (iabModel != null)
                {
                    iabModel.XmlData = model.Serialize();
                    //iabModel.UpdateBy = model.UserRoleId;
                    iabModel.UpdateOn = DateTime.Now;
                    uow.UOFIncidentFormDataRepository.Update(iabModel);
                    result = iabModel.FormDataID;
                }
                else
                {
                    var uofIAB = new IncidentFormData();
                    uofIAB.IncidentID = model.IncidentID;
                    uofIAB.EmpID = model.EmpID;
                    uofIAB.CreatedOn = DateTime.Now;
                    uofIAB.CreatedBy = model.EmpID;
                    uofIAB.FormID = model.FormID;
                    uofIAB.UserRoleId = model.UserRoleId;
                    uofIAB.XmlData = model.Serialize();
                    uofIAB.Status = Constants.Status.DON.ToString();
                    uow.UOFIncidentFormDataRepository.Add(uofIAB);
                    result = uofIAB.FormDataID;
                    FormDataId = uofIAB.FormDataID;
                    //Update Incident Category form
                    var CAModel = uow.CategoryFormRepository.FindBy(a => a.FormID == model.FormID && a.IncidentID == model.IncidentID).FirstOrDefault();
                    if (CAModel != null)
                    {
                        CAModel.Status = Constants.Status.DON.ToString();
                        uow.CategoryFormRepository.Update(CAModel);
                    }
                }
                repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                {
                    FormDataId = FormDataId,
                    IncidentReviewID = model.IncidentReviewId,
                    IncidentID = model.IncidentID,
                    SubmittedEmpId = model.EmpID,
                    FormId = model.FormID,
                    SubmitteduserRole = model.UserRole,
                    ReviewerRole = !model.IsOnlySave ? Constants.UserRoles.SGT.ToString() : "",
                    SergeantStatus = !model.IsOnlySave ? Constants.Status.Pending.ToString() : "",
                    SubmittedStatus = !model.IsOnlySave ? Constants.Status.DON.ToString() : Constants.Status.Pending.ToString(),
                });
                uow.Commit();

            }
            catch (Exception ex)
            {

                throw ex;
            }
            return result;
        }

        public IABModel GetIABDetails(int FormId, int IncidentId, string EmpId)
        {

            try
            {
                var data = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.FormID == FormId && x.EmpID == EmpId && x.IncidentID == IncidentId).FirstOrDefault();
                var result = data != null ? data.XmlData.Deserialize<IABModel>() : null;
                if (result != null)
                {
                    using (ReturnCommentsRepository obj = new ReturnCommentsRepository())
                    {
                        result.RejectComments = obj.getReturnComments(new ReturnCommentModel { IncidentId = IncidentId, FormId = FormId, FormSubmitedId = EmpId });
                    }
                }
                return result;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }


        public bool AssigntoIAB(int incidentId)
        {
            var check = uow.CategoryFormRepository.GetAll().Where(x => x.FormID == (int) Constants.UOFForms.IABMandatoryForm && x.IncidentID == incidentId).FirstOrDefault();

            if (uow.CategoryFormRepository.GetAll().Where(x => x.IncidentID == incidentId && x.FormID == (int)Constants.UOFForms.IABMandatoryForm && x.Status == Constants.Status.DON.ToString()).Any())
            {
                if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && x.FormId == (int)Constants.UOFForms.WatchCommanderUseofForceReview && x.WCStatus == Constants.Status.Completed.ToString()).Any())
                {
                    using (var transaction = new TransactionScope())
                    {
                        var IncidentDetails = (from incident in uow.IncidentRepository.GetAll()
                                               where incident.IncidentId == incidentId
                                               select new IncidentEntity
                                               {
                                                   IncidentId = incident.IncidentId,
                                                   URN = incident.URN,
                                                   IncidentDate = incident.IncidentDate,
                                                   IncidentCategoryId = incident.IncidentCategoryId,
                                                   IsIABNotified = incident.IsIABNotified,
                                                   IABNotifiedUserId = incident.IABNotifiedUserId,
                                                   IABNotifiedEmailId = incident.IABNotifiedEmailId
                                               }).FirstOrDefault();

                        #region Email Notifications
                        EmailRepository email = new EmailRepository();
                        email.EmailNotification(new EmailNotificationModel
                        {
                            Department = "IAB Assigned",
                            EmailId = IncidentDetails.IABNotifiedEmailId,
                            IncidentId = IncidentDetails.IncidentId,
                            EmployeeNumber = IncidentDetails.IABNotifiedUserId,
                        });
                        #endregion
                        using (UoFWorkFlowRepository wf = new UoFWorkFlowRepository())
                        {
                            wf.InsertUpdateWorkFlow(new WorkFlowEntity { IncidentId = incidentId, WCStatus = Constants.Status.Completed.ToString() });
                            wf.updateIncident(incidentId, Convert.ToString((int)Constants.IncidentStatus.AtIAB));
                        }
                        transaction.Complete();
                        return true;
                    }
                }
                else
                    return false;
            }
            else
                return false;
        }

    }
}
