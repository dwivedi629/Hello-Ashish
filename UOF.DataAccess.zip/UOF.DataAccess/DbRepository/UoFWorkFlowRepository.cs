﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.Common.Utilities;
using UOF.DataAccess.Repository;

namespace UOF.DataAccess.DbRepository
{
    public class UoFWorkFlowRepository : IDisposable
    {
        UnitOfWork uow = new UnitOfWork();

        public void InsertUpdateWorkFlow(WorkFlowEntity WF)
        {
            var model = uow.IncidentWorkflowRepository.GetAll();
            IncidentWorkflow WfModel = model.Where(x => x.IncidentId == WF.IncidentId).FirstOrDefault();
            if (WfModel != null)
            {
                if (!string.IsNullOrWhiteSpace(WF.SergeantID) && WF.SergeantID != "0")
                    WfModel.SergeantID = WF.SergeantID;
                if (!string.IsNullOrWhiteSpace(WF.WCID))

                    WfModel.WCID = WF.WCID;
                if (!string.IsNullOrWhiteSpace(WF.UCID))

                    WfModel.UCID = WF.UCID;
                if (!string.IsNullOrWhiteSpace(WF.CMID))

                    WfModel.CMID = WF.CMID;
                if (!string.IsNullOrWhiteSpace(WF.CFRCID))
                    WfModel.CFRCID = WF.CFRCID;

                if (!string.IsNullOrWhiteSpace(WF.CFRTID))
                    WfModel.CFRTID = WF.CFRTID;

                if (!string.IsNullOrWhiteSpace(WF.DCID))
                    WfModel.DCID = WF.DCID;

                if (!string.IsNullOrWhiteSpace(WF.DeputyStatus))
                    WfModel.DeputyStatus = WF.DeputyStatus;

                if (!string.IsNullOrWhiteSpace(WF.ChiefStatus))
                   WfModel.DCStatus = WF.ChiefStatus;

                if (!string.IsNullOrWhiteSpace(WF.SergeantStatus))
                    WfModel.SergeantStatus = WF.SergeantStatus;

                if (!string.IsNullOrWhiteSpace(WF.WCStatus))
                    WfModel.WCStatus = WF.WCStatus; ;
               
                if (!string.IsNullOrWhiteSpace(WF.UCStatus))
                    WfModel.UCStatus = WF.UCStatus;
               
                if (!string.IsNullOrWhiteSpace(WF.CMStatus))
                    WfModel.CMStatus = WF.CMStatus;
               
                if (!string.IsNullOrWhiteSpace(WF.CFRCStatus))
                    WfModel.CFRCStatus = WF.CFRCStatus;
                
                if (!string.IsNullOrWhiteSpace(WF.CFRTStatus))
                    WfModel.CFRTStatus = WF.CFRTStatus;
              
                uow.IncidentWorkflowRepository.Update(WfModel);
            }
            else
            {
                //Insert inot IncidentWorkflow
                IncidentWorkflow Wf = new IncidentWorkflow();
                Wf.IncidentId = WF.IncidentId;
                Wf.SergeantID = WF.SergeantID;
                Wf.SergeantStatus = WF.SergeantStatus;
                
                if (!string.IsNullOrWhiteSpace(WF.CFRTID))
                    Wf.CFRTID = WF.CFRTID;
                if (!string.IsNullOrWhiteSpace(WF.CFRTStatus))
                    Wf.CFRTStatus = WF.CFRTStatus;
                uow.IncidentWorkflowRepository.Add(Wf);
            }
            uow.Commit();
            //End
        }

        public void BuildWorkflowObject(WorkFlowEntity WF)
        {
            if (!string.IsNullOrWhiteSpace(WF.SergeantStatus) && WF.SergeantStatus == "Return")
            {
                if (WF.SergeantStatus == "Return")
                    WF.SergeantStatus = "Return to Deputy";
                if (WF.SergeantStatus == "Completed")
                {
                    WF.SergeantStatus = "At WC";
                    WF.WCStatus = "Review Pending";
                }
                //Need to update incident deputy form table


            }
            else if (!string.IsNullOrWhiteSpace(WF.WCStatus))
            {
                if (WF.WCStatus == "Return")
                    WF.SergeantStatus = "Return from WC";
                if (WF.WCStatus == "Completed")
                {
                    WF.WCStatus = "Review Completed";
                    WF.UCStatus = "Review Pending";
                }

            }
            else if (!string.IsNullOrWhiteSpace(WF.UCStatus) && WF.UCStatus == "Return")
            {
                if (WF.UCStatus == "Return")
                    WF.WCStatus = "Return from UC";
                if (WF.UCStatus == "Completed")
                {
                    WF.UCStatus = "Review Completed";
                    WF.CMStatus = "Review Pending";
                }
            }
            else if (!string.IsNullOrWhiteSpace(WF.CFRTStatus) && WF.CFRTStatus == "Return")
            {
                WF.UCStatus = "Return from CFRT";

            }
            else if (!string.IsNullOrWhiteSpace(WF.CMStatus) && WF.CMStatus == "Completed")
            {
                if (WF.CMStatus == "Return")
                    WF.UCStatus = "Return from CM";
                if (WF.CMStatus == "Completed")
                {
                    WF.CMStatus = "Package Done";
                }

            }
            InsertUpdateWorkFlow(WF);
        }

        public void UpdateSergeantStatus(ReviewEntity entity)
        {
            IncidentWorkflow WfModel = uow.IncidentWorkflowRepository.GetAll().Where(x => x.IncidentId == entity.IncidentId).FirstOrDefault();

            if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == entity.IncidentId).Any())
            {
                //var chkDeputy = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == entity.IncidentId && x.InvolvedRole == Constants.UserRoles.DSG.ToString() && (x.InvolvedStatus != Constants.Status.Completed.ToString())).ToList();
                var chkDeputy = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == entity.IncidentId && x.InvolvedRole == Constants.UserRoles.DSG.ToString() && (x.InvolvedStatus != Constants.Status.Completed.ToString() && x.InvolvedStatus != Constants.Status.DON.ToString())).ToList();

                bool isDptyFilled = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == entity.IncidentId && x.InvolvedRole == Constants.UserRoles.DSG.ToString() && (x.InvolvedStatus != Constants.Status.Completed.ToString() && x.InvolvedStatus != Constants.Status.DON.ToString())).Any();
                //bool isDeputyCompleted = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.IncidentID == entity.IncidentId && x.Status != Constants.Status.DON.ToString() && x.UserRoleId == (int)Constants.UserRoles.DSG).Any();

                if (isDptyFilled) //If incident is at Deputy
                {
                    if (WfModel != null)
                        WfModel.DeputyStatus = Constants.Status.Pending.ToString();

                    updateIncident(entity.IncidentId, Convert.ToString((int)Constants.IncidentStatus.AtDeputy));

                }
                //else
                //{
                //    if (WfModel != null)
                //    {
                //        WfModel.DeputyStatus = Constants.Status.Completed.ToString();
                //        WfModel.SergeantStatus = Constants.Status.Pending.ToString();
                //    }


                //    updateIncident(entity.IncidentId, Convert.ToString((int)Constants.IncidentStatus.AtSergeant));
                //}
                //var chkSerFrmCompleted = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.IncidentID == entity.IncidentId && x.Status != Constants.Status.DON.ToString() && x.UserRoleId == (int)Constants.UserRoles.SGT).ToList();
                //var chkSerReviewCompleted = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == entity.IncidentId && x.SergeantStatus != Constants.Status.Completed.ToString() && x.SergeantStatus != null).ToList();
                //var chkSerReviewCompleted1 = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == entity.IncidentId && x.SergeantStatus != Constants.Status.Completed.ToString() ).ToList();

                bool isSergeantFrmCompleted = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.IncidentID == entity.IncidentId && x.Status != Constants.Status.DON.ToString() && x.UserRoleId == (int)Constants.UserRoles.SGT).Any();
                bool isSergeantReviewCompleted = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == entity.IncidentId && x.SergeantStatus != Constants.Status.Completed.ToString() && x.SergeantStatus != null).Any();

                if (!isSergeantFrmCompleted && !isSergeantReviewCompleted)
                {
                    if (WfModel != null)
                    {
                        if (WfModel.SergeantStatus == Constants.Status.Pending.ToString())
                        {
                            bool isSRSubmitted = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == entity.IncidentId && x.FormId == (int)Constants.UOFForms.SupervisoryReport).Any();
                            
                            //WfModel.SergeantStatus = Constants.IncidentStatus.ReadyforReview.ToString();
                            //updateIncident(entity.IncidentId, Convert.ToString((int)Constants.IncidentStatus.ReadyforReview));
                            //Changed as per the requirement change
                            if (isSRSubmitted)
                            {
                                WfModel.SergeantStatus = Constants.Status.Completed.ToString();
                                //updateIncidentRank(entity.IncidentId, Constants.IncidentStatus.AtWatchCommander.ToString());
                               // updateIncident(entity.IncidentId, Convert.ToString((int)Constants.IncidentStatus.AtWatchCommander));
                            }
                        }
                    }
                }
                else // If Sergeant Status is having Pending 
                {
                    if (WfModel != null)
                    {
                        WfModel.SergeantStatus = Constants.Status.Pending.ToString();
                        WfModel.DeputyStatus = Constants.Status.Completed.ToString();
                    }
                    updateIncident(entity.IncidentId, Convert.ToString((int)Constants.IncidentStatus.AtSergeant));

                }
            }
        }
        public void UpdateWCStatus(ReviewEntity DE)
        {
            IncidentWorkflow WfModel = uow.IncidentWorkflowRepository.GetAll().Where(x => x.IncidentId == DE.IncidentId).FirstOrDefault();

            var chkWCFrmCompleted = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.IncidentID == DE.IncidentId && x.Status != Constants.Status.DON.ToString() && x.UserRoleId == (int)Constants.UserRoles.WC).ToList();
            var chkWCReviewCompleted = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == DE.IncidentId && x.WCStatus != Constants.Status.Completed.ToString() && x.WCID == DE.LoggedId && x.WCStatus != null).ToList();

            bool isWCFrmCompleted = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.IncidentID == DE.IncidentId && x.Status != Constants.Status.DON.ToString() && x.UserRoleId == (int)Constants.UserRoles.WC).Any();
            bool isWCReviewCompleted = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == DE.IncidentId && x.WCStatus != Constants.Status.Completed.ToString() && x.WCID == DE.LoggedId).Any();

            if (!isWCFrmCompleted && !isWCReviewCompleted)
            {
                if (WfModel != null)
                {
                    WfModel.WCStatus = Constants.Status.Completed.ToString();
                    WfModel.UCStatus = Constants.Status.Pending.ToString();
                    uow.IncidentWorkflowRepository.Update(WfModel);
                    uow.Commit();
                }
                //updateIncident(DE.IncidentId, Convert.ToString((int)Constants.IncidentStatus.AtUnitCommander));
            }



            //if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == DE.IncidentId).Any())
            //{
            //    bool isWCCompleted = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == DE.IncidentId && x.WCStatus != Constants.Status.Completed.ToString() && x.WCID == DE.LoggedId).Any();
            //    if (isWCCompleted)
            //    {
            //        //do nothing
            //    }
            //    else
            //    {
            //        if (WfModel != null)
            //        {
            //            WfModel.WCStatus = Constants.Status.Completed.ToString();
            //            WfModel.UCStatus = Constants.Status.Pending.ToString();
            //            uow.IncidentWorkflowRepository.Update(WfModel);
            //            uow.Commit();
            //        }

            //        updateIncident(DE.IncidentId, Convert.ToString((int)Constants.IncidentStatus.AtUnitCommander));
            //    }
            //}
        }


        public void UpdateUCStatus(ReviewEntity DE)
        {

            IncidentWorkflow WfModel = uow.IncidentWorkflowRepository.GetAll().Where(x => x.IncidentId == DE.IncidentId).FirstOrDefault();

            var chkUCFrmCompleted = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.IncidentID == DE.IncidentId && x.Status != Constants.Status.DON.ToString() && x.UserRoleId == (int)Constants.UserRoles.CAPT).ToList();
            var chkUCReviewCompleted = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == DE.IncidentId && x.UCStatus != Constants.Status.Completed.ToString() && x.UCID == DE.LoggedId && x.UCStatus != null).ToList();

            bool isUCFrmCompleted = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.IncidentID == DE.IncidentId && x.Status != Constants.Status.DON.ToString() && x.UserRoleId == (int)Constants.UserRoles.CAPT).Any();
            bool isUCReviewCompleted = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == DE.IncidentId && x.UCStatus != Constants.Status.Completed.ToString() && x.UCID == DE.LoggedId).Any();

            if (!isUCFrmCompleted && !isUCReviewCompleted)
            {
                if (WfModel != null)
                {
                    WfModel.UCStatus = Constants.Status.Completed.ToString();
                    WfModel.CMStatus = Constants.Status.Pending.ToString();
                    uow.IncidentWorkflowRepository.Update(WfModel);
                    uow.Commit();
                }

                //updateIncident(DE.IncidentId, Convert.ToString((int)Constants.IncidentStatus.AtCommander));
            }

            //IncidentWorkflow WfModel = uow.IncidentWorkflowRepository.GetAll().Where(x => x.IncidentId == DE.IncidentId).FirstOrDefault();
            //if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == DE.IncidentId).Any())
            //{
            //    bool isWCCompleted = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == DE.IncidentId && x.UCStatus != Constants.Status.Completed.ToString() && x.UCID == DE.LoggedId).Any();
            //    if (isWCCompleted)
            //    {
            //        //do nothing
            //    }
            //    else
            //    {
            //        if (WfModel != null)
            //        {
            //            WfModel.UCStatus = Constants.Status.Completed.ToString();
            //            WfModel.CMStatus = Constants.Status.Pending.ToString();
            //            uow.IncidentWorkflowRepository.Update(WfModel);
            //            uow.Commit();
            //        }

            //        updateIncident(DE.IncidentId, Convert.ToString((int)Constants.IncidentStatus.AtCommander));
            //        //}
            //    }
            //}
        }
        public void UpdateCMStatus(ReviewEntity DE)
        {
            IncidentWorkflow WfModel = uow.IncidentWorkflowRepository.GetAll().Where(x => x.IncidentId == DE.IncidentId).FirstOrDefault();

            var chkCMFrmCompleted = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.IncidentID == DE.IncidentId && x.Status != Constants.Status.DON.ToString() && x.UserRoleId == (int)Constants.UserRoles.CMDR).ToList();
            var chkCMReviewCompleted = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == DE.IncidentId && x.CMStatus != Constants.Status.Completed.ToString() && x.CMID == DE.LoggedId && x.CMStatus != null).ToList();


            bool isCMFrmCompleted = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.IncidentID == DE.IncidentId && x.Status != Constants.Status.DON.ToString() && x.UserRoleId == (int)Constants.UserRoles.CMDR).Any();
            bool isCMReviewCompleted = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == DE.IncidentId && x.CMStatus != Constants.Status.Completed.ToString() && x.CMID == DE.LoggedId).Any();

            if (!isCMFrmCompleted && !isCMReviewCompleted)
            {
                if (WfModel != null)
                {
                    WfModel.CMStatus = Constants.Status.Completed.ToString();
                    WfModel.DCStatus = Constants.Status.Pending.ToString();
                    uow.IncidentWorkflowRepository.Update(WfModel);
                    uow.Commit();
                }

                updateIncident(DE.IncidentId, Convert.ToString((int)Constants.IncidentStatus.AtChief));
            }

            //IncidentWorkflow WfModel = uow.IncidentWorkflowRepository.GetAll().Where(x => x.IncidentId == DE.IncidentId).FirstOrDefault();
            //if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == DE.IncidentId).Any())
            //{
            //    bool isWCCompleted = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == DE.IncidentId && x.CMStatus != Constants.Status.Completed.ToString() && x.CMID == DE.LoggedId).Any();
            //    if (isWCCompleted)
            //    {
            //        //do nothing
            //    }
            //    else
            //    {
            //        if (WfModel != null)
            //        {
            //            WfModel.CMStatus = Constants.Status.Pending.ToString();
            //            uow.IncidentWorkflowRepository.Update(WfModel);
            //            uow.Commit();
            //        }

            //        updateIncident(DE.IncidentId, Convert.ToString((int)Constants.IncidentStatus.Completed));
            //        //}
            //    }
            //}
        }
        public void UpdateDCStatus(ReviewEntity DE)
        {
            IncidentWorkflow WfModel = uow.IncidentWorkflowRepository.GetAll().Where(x => x.IncidentId == DE.IncidentId).FirstOrDefault();

            var chkCMFrmCompleted = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.IncidentID == DE.IncidentId && x.Status != Constants.Status.DON.ToString() && x.UserRoleId == (int)Constants.UserRoles.CMDR).ToList();
            var chkCMReviewCompleted = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == DE.IncidentId && x.CMStatus != Constants.Status.Completed.ToString() && x.CMID == DE.LoggedId && x.CMStatus != null).ToList();


            bool isCMFrmCompleted = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.IncidentID == DE.IncidentId && x.Status != Constants.Status.DON.ToString() && x.UserRoleId == (int)Constants.UserRoles.DC).Any();
            bool isCMReviewCompleted = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == DE.IncidentId && x.DCStatus != Constants.Status.Completed.ToString() && x.DCID == DE.LoggedId).Any();

            if (!isCMFrmCompleted && !isCMReviewCompleted)
            {
                if (WfModel != null)
                {
                    WfModel.DCStatus = Constants.Status.Completed.ToString();
                    uow.IncidentWorkflowRepository.Update(WfModel);
                    uow.Commit();
                }

                updateIncident(DE.IncidentId, Convert.ToString((int)Constants.IncidentStatus.Completed));
            }

            //IncidentWorkflow WfModel = uow.IncidentWorkflowRepository.GetAll().Where(x => x.IncidentId == DE.IncidentId).FirstOrDefault();
            //if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == DE.IncidentId).Any())
            //{
            //    bool isWCCompleted = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == DE.IncidentId && x.CMStatus != Constants.Status.Completed.ToString() && x.CMID == DE.LoggedId).Any();
            //    if (isWCCompleted)
            //    {
            //        //do nothing
            //    }
            //    else
            //    {
            //        if (WfModel != null)
            //        {
            //            WfModel.CMStatus = Constants.Status.Pending.ToString();
            //            uow.IncidentWorkflowRepository.Update(WfModel);
            //            uow.Commit();
            //        }

            //        updateIncident(DE.IncidentId, Convert.ToString((int)Constants.IncidentStatus.Completed));
            //        //}
            //    }
            //}
        }

        public void updateIncident(int incidentId, string status)
        {
            //Updating the Incident table with current status....
            if (uow.IncidentRepository.GetAll().Where(x => x.IncidentId == incidentId).Any())
            {
                Incident incidentModel = uow.IncidentRepository.GetAll().Where(x => x.IncidentId == incidentId).FirstOrDefault();
                if (incidentModel != null)
                {
                    incidentModel.IncidentApprovalStatus = status;
                    uow.IncidentRepository.Update(incidentModel);
                    uow.Commit();
                }
            }
            updateIncidentRank(incidentId, status);
        }
        public void updateIncidentRank(int incidentId, string status)
        {
            //Updating the Incident table with current status....
            if (uow.IncidentRankRespository.GetAll().Where(x => x.IncidentId == incidentId).Any())
            {
                IncidentRank model = uow.IncidentRankRespository.GetAll().Where(x => x.IncidentId == incidentId).FirstOrDefault();
                if (model != null)
                {
                    int RANK = Convert.ToInt32(status);
                    switch (status)
                    {
                        case "AtDeputy":
                            model.Rank = 0;
                            break;
                        case "AtSergeant":
                            model.Rank = 1;
                            break;
                        case "AtWatchCommander":
                            model.Rank = 2;
                            break;
                        case "AtUnitCommander":
                            model.Rank = 3;
                            break;
                        case "AtCommander":
                            model.Rank = 4;
                            break;
                    }
                    model.Rank = RANK;
                    uow.IncidentRankRespository.Update(model);
                    uow.Commit();
                }
            }
        }
        //public void UpdateIncidentStatus(ReviewEntity entity)
        //{
        //    IncidentWorkflow WfModel = uow.IncidentWorkflowRepository.GetAll().Where(x => x.IncidentId == entity.IncidentId).FirstOrDefault();
        //    if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == entity.IncidentId).Any())
        //    {
        //        bool Cnt = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == entity.IncidentId && x.SergeantStatus != "Completed").Any();
        //        int approvalCnt = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == entity.IncidentId && x.SergeantStatus == "Completed" && x.InvolvedRole == "DSG").Count();
        //        if (Cnt)
        //        {
        //            if (WfModel != null)
        //            {
        //                WfModel.SergeantStatus = "At Sergeant";
        //                uow.IncidentWorkflowRepository.Update(WfModel);
        //                uow.Commit();
        //            }
        //            updateIncident(entity.IncidentId, Convert.ToString((int)Constants.IncidentStatus.AtSergeant));
        //        }
        //        else
        //        {
        //            Cnt = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == entity.IncidentId && x.WCStatus != "Completed").Any();
        //            if (Cnt)
        //            {
        //                if (WfModel != null)
        //                {
        //                    WfModel.SergeantStatus = "Completed";
        //                    WfModel.WCStatus = "At Watch Commander";
        //                    uow.IncidentWorkflowRepository.Update(WfModel);
        //                    uow.Commit();
        //                }
        //            }
        //            else
        //            {
        //                Cnt = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == entity.IncidentId && x.UCStatus != "Completed").Any();
        //                if (Cnt)
        //                {
        //                    if (WfModel != null)
        //                    {
        //                        WfModel.WCStatus = "Completed";
        //                        WfModel.UCStatus = "At Unit Commander";
        //                        uow.IncidentWorkflowRepository.Update(WfModel);
        //                        uow.Commit();
        //                    }
        //                }
        //                else
        //                {
        //                    Cnt = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == entity.IncidentId && x.CMStatus != "Completed").Any();
        //                    if (Cnt)
        //                    {
        //                        if (WfModel != null)
        //                        {
        //                            WfModel.UCStatus = "Completed";
        //                            WfModel.CMStatus = "At Commander";
        //                            uow.IncidentWorkflowRepository.Update(WfModel);
        //                            uow.Commit();
        //                        }
        //                    }
        //                    else
        //                    {
        //                        if (WfModel != null)
        //                        {
        //                            WfModel.CMStatus = "Package Completed";
        //                            uow.IncidentWorkflowRepository.Update(WfModel);
        //                            uow.Commit();
        //                        }
        //                    }
        //                }
        //            }
        //        }
        //    }

        //}

        //public void UpdateDeputyForms(ReviewEntity DE)
        //{
        //    var model = uow.IncidentDeputyFormRepository.GetAll();
        //    IncidentDeputyForm DEModel = model.Where(x => x.FormId == DE.FormId && x.DeputyEmpId == DE.DeputyEmpId).FirstOrDefault();
        //    if (DEModel != null)
        //    {
        //        if (!string.IsNullOrWhiteSpace(DE.SergeantStatus))
        //            DEModel.SergeantStatus = DE.SergeantStatus;
        //        if (!string.IsNullOrWhiteSpace(DE.FormStatus))
        //            DEModel.FormStatus = DE.FormStatus;

        //        uow.IncidentDeputyFormRepository.Update(DEModel);
        //        uow.Commit();
        //    }
        //}

        public void UpdateCFRTStatus(int incidentId)
        {
            if (uow.IncidentCFRTRepository.GetAll().Where(x => x.IncidentId == incidentId).Any())
            {
                IncidentCFRTFlow Model = uow.IncidentCFRTRepository.GetAll().Where(x => x.IncidentId == incidentId).FirstOrDefault();
                if (Model != null)
                {
                    Model.CRFCStatus = Constants.Status.Completed.ToString();
                    uow.IncidentCFRTRepository.Update(Model);
                    uow.Commit();
                }
                updateIncident(incidentId, Convert.ToString((int)Constants.IncidentStatus.CFRTCompleted));
            }
        }


        public void Dispose()
        {
            //throw new NotImplementedException();
        }
    }
}
