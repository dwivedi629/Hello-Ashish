﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;

namespace UOF.DataAccess.DbRepository
{
    public interface ICSRepository
    {
        int SaveCSData(CSEntity model);
        CSEntity GetCSDetails(ParameterCriteria cirteria);
    }
}
