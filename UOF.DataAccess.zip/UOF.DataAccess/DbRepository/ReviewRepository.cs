﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.DataAccess.Repository;
using UOF.Common.Utilities;
using System.Transactions;

namespace UOF.DataAccess.DbRepository
{
    public class ReviewRepository
    {
        UnitOfWork uow = new UnitOfWork();
        UoFWorkFlowRepository wf = new UoFWorkFlowRepository();
        #region Watch Commander Section
        public int SaveWCReviewInfo(ReviewsResponse reviewsResponse)//List<ReviewBusinessModel> reviewBusinessModel)
        {
            int FormDataId = 0;
            int result = 0;
            try
            {
                ReviewsResponse rvResponse = new ReviewsResponse();
                rvResponse.ReviewBusinessModel = reviewsResponse.ReviewBusinessModel;
                //rvResponse.FormID = (int)Constants.UOFForms.WatchCommanderUseofForceReview;
                rvResponse.UserRoleId = (int)Constants.UserRoles.WC;
                var wcReviewModel = uow.UOFIncidentFormDataRepository.FindBy(a => a.UserRoleId == rvResponse.UserRoleId && a.FormID == reviewsResponse.FormID && a.IncidentID == reviewsResponse.IncidentID && a.EmpID == reviewsResponse.EmpId && a.FormDataID == reviewsResponse.formDataId).FirstOrDefault();
                if (wcReviewModel != null)
                {
                    wcReviewModel.UpdateOn = DateTime.Now;
                    wcReviewModel.XmlData = rvResponse.Serialize();
                    uow.UOFIncidentFormDataRepository.Update(wcReviewModel);
                    result = wcReviewModel.FormDataID;
                }

                else
                {
                    var wcReview = new IncidentFormData();
                    wcReview.IncidentID = reviewsResponse.IncidentID;
                    wcReview.EmpID = reviewsResponse.EmpId;
                    wcReview.CreatedOn = DateTime.Now;
                    wcReview.CreatedBy = rvResponse.EmpId; ;
                    wcReview.FormID = reviewsResponse.FormID;
                    wcReview.UserRoleId = rvResponse.UserRoleId;
                    wcReview.XmlData = reviewsResponse.Serialize();
                    wcReview.Status = Constants.Status.DON.ToString();
                    uow.UOFIncidentFormDataRepository.Add(wcReview);
                    uow.Commit();
                    FormDataId = wcReview.FormDataID;
                    result = FormDataId;
                }

                uow.Commit();

                //string UnitCommanderId = (from ind in uow.IncidentWorkflowRepository.GetAll()
                //                          where ind.IncidentId == reviewsResponse.IncidentID
                //                          select new { ind.UCID }).Single().UCID;

                FormReviewRespository repo = new FormReviewRespository();
                repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                {
                    FormDataId = FormDataId,
                    IncidentReviewID = reviewsResponse.IncidentReviewId,
                    IncidentID = reviewsResponse.IncidentID,
                    SubmittedEmpId = reviewsResponse.EmpId,
                    FormId = reviewsResponse.FormID,
                    SubmitteduserRole = Constants.UserRoles.WC.ToString(),
                    WCID = reviewsResponse.EmpId,
                    //UCID = UnitCommanderId,
                    WCStatus = !reviewsResponse.IsOnlySave ? Constants.Status.Completed.ToString() : Constants.Status.Pending.ToString(),
                    ReviewerRole = !reviewsResponse.IsOnlySave ? Constants.UserRoles.CAPT.ToString() : Constants.UserRoles.WC.ToString(),
                    SubmittedStatus = !reviewsResponse.IsOnlySave ? Constants.Status.Completed.ToString() : "",
                    UCStatus = !reviewsResponse.IsOnlySave ? Constants.Status.Pending.ToString() : Constants.Status.NotReady.ToString(),
                });

                #region Updating the WC Status to the incident
                wf.UpdateWCStatus(new ReviewEntity { IncidentId = reviewsResponse.IncidentID, LoggedId = reviewsResponse.EmpId });
                #endregion




            }
            catch (Exception ex)
            {

                throw ex;
            }
            return result;
        }

        public ReviewsResponse GetWCReviewData(ParameterCriteria cirteria)
        {
            try
            {
                //var wcReviewResponse = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.FormID == FormId && x.EmpID == WCId && x.IncidentID == IncidentId).FirstOrDefault();
                //var wcReviewResponse = uow.UOFIncidentFormDataRepository.GetById(cirteria.formDataId);

                IncidentFormData data = null;
                if (cirteria.report)
                    data = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.FormID == cirteria.formId && x.EmpID == cirteria.employeeId && x.IncidentID == cirteria.incidentId).FirstOrDefault();
                else
                    data = uow.UOFIncidentFormDataRepository.GetById(cirteria.formDataId);

                return data != null ? data.XmlData.Deserialize<ReviewsResponse>() : null;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        #endregion

        #region Unit Commander Section
        public int SaveUCReviewInfo(ReviewsResponse reviewsResponse)//List<ReviewBusinessModel> reviewBusinessModel)
        {
            int result = 0;
            int FormDataId = 0;
            try
            {
                ReviewsResponse rvResponse = new ReviewsResponse();
                rvResponse.ReviewBusinessModel = reviewsResponse.ReviewBusinessModel;
                //rvResponse.FormID = (int)Constants.UOFForms.UnitCommanderUseoFForceReview;
                rvResponse.UserRoleId = (int)Constants.UserRoles.CAPT;
                var ucReviewModel = uow.UOFIncidentFormDataRepository.FindBy(a => a.UserRoleId == rvResponse.UserRoleId && a.FormID == reviewsResponse.FormID && a.IncidentID == reviewsResponse.IncidentID && a.EmpID == reviewsResponse.EmpId && a.FormDataID == reviewsResponse.formDataId).FirstOrDefault();
                if (ucReviewModel != null)
                {
                    ucReviewModel.UpdateOn = DateTime.Now;
                    ucReviewModel.XmlData = rvResponse.Serialize();
                    ucReviewModel.Status = Constants.Status.UPD.ToString();
                    uow.UOFIncidentFormDataRepository.Update(ucReviewModel);
                    result = ucReviewModel.FormDataID;
                }

                else
                {
                    var ucReview = new IncidentFormData();
                    ucReview.IncidentID = reviewsResponse.IncidentID;
                    ucReview.EmpID = reviewsResponse.EmpId;
                    ucReview.CreatedOn = DateTime.Now;
                    ucReview.CreatedBy = reviewsResponse.EmpId;
                    ucReview.FormID = reviewsResponse.FormID;
                    ucReview.UserRoleId = rvResponse.UserRoleId;
                    ucReview.XmlData = reviewsResponse.Serialize();
                    ucReview.Status = Constants.Status.DON.ToString();
                    uow.UOFIncidentFormDataRepository.Add(ucReview);
                    uow.Commit();
                    FormDataId = ucReview.FormDataID;
                    result = FormDataId;
                }

                uow.Commit();

                //string CommanderId = (from ind in uow.IncidentWorkflowRepository.GetAll()
                //                      where ind.IncidentId == reviewsResponse.IncidentID
                //                      select new { ind.CMID }).Single().CMID;

                FormReviewRespository repo = new FormReviewRespository();
                repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                {
                    FormDataId = FormDataId,
                    IncidentReviewID = reviewsResponse.IncidentReviewId,
                    IncidentID = reviewsResponse.IncidentID,
                    SubmittedEmpId = reviewsResponse.EmpId,
                    FormId = reviewsResponse.FormID,
                    SubmitteduserRole = Constants.UserRoles.CAPT.ToString(),
                    ReviewerRole = !reviewsResponse.IsOnlySave ? Constants.UserRoles.CMDR.ToString() : Constants.UserRoles.CAPT.ToString(),
                    SubmittedStatus = !reviewsResponse.IsOnlySave ? Constants.Status.Completed.ToString() : Constants.Status.Pending.ToString(),
                    UCStatus = !reviewsResponse.IsOnlySave ? Constants.Status.Completed.ToString() : Constants.Status.Pending.ToString(),
                    CMStatus = !reviewsResponse.IsOnlySave ? Constants.Status.Pending.ToString() : Constants.Status.NotReady.ToString(),
                    //CMID = CommanderId,
                });
                #region Updating the UC Status to the incident
                wf.UpdateUCStatus(new ReviewEntity { IncidentId = reviewsResponse.IncidentID, LoggedId = reviewsResponse.EmpId });
                #endregion



            }
            catch (Exception ex)
            {

                throw ex;
            }
            return result;
        }

        public ReviewsResponse GetUCReviewData(ParameterCriteria cirteria)
        {
            try
            {
                //var ucReviewResponse = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.FormID == FormId && x.EmpID == UCID && x.IncidentID == IncidentId).FirstOrDefault();
                //var ucReviewResponse = uow.UOFIncidentFormDataRepository.GetById(cirteria.formDataId);
                IncidentFormData data = null;
                if (cirteria.report)
                    data = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.FormID == cirteria.formId && x.EmpID == cirteria.employeeId && x.IncidentID == cirteria.incidentId).FirstOrDefault();
                else
                    data = uow.UOFIncidentFormDataRepository.GetById(cirteria.formDataId);

                return data != null ? data.XmlData.Deserialize<ReviewsResponse>() : null;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        #endregion

        #region  Commander Section
        public int SaveCommanderReviewInfo(ReviewsResponse reviewBusinessModel)
        {
            int result = 0;
            int FormDataId = 0;
            try
            {
                ReviewsResponse rvResponse = new ReviewsResponse();
                reviewBusinessModel.FormID = (int)Constants.UOFForms.CommanderUseofForceReview;
                rvResponse.ReviewBusinessModel = reviewBusinessModel.ReviewBusinessModel;
                rvResponse.UserRoleId = (int)Constants.UserRoles.CMDR;
                var cmndrReviewModel = uow.UOFIncidentFormDataRepository.FindBy(a => a.UserRoleId == rvResponse.UserRoleId && a.FormID == reviewBusinessModel.FormID && a.IncidentID == reviewBusinessModel.IncidentID && a.EmpID == reviewBusinessModel.EmpId && a.FormDataID == reviewBusinessModel.formDataId).FirstOrDefault();
                if (cmndrReviewModel != null)
                {
                    cmndrReviewModel.UpdateOn = DateTime.Now;
                    cmndrReviewModel.XmlData = rvResponse.Serialize();
                    cmndrReviewModel.Status = Constants.Status.UPD.ToString();
                    uow.UOFIncidentFormDataRepository.Update(cmndrReviewModel);
                    result = cmndrReviewModel.FormDataID;
                }

                else
                {
                    var cmndrReview = new IncidentFormData();
                    cmndrReview.IncidentID = reviewBusinessModel.IncidentID;
                    cmndrReview.EmpID = reviewBusinessModel.EmpId;
                    cmndrReview.CreatedBy = rvResponse.EmpId;
                    cmndrReview.FormID = reviewBusinessModel.FormID;
                    cmndrReview.UserRoleId = rvResponse.UserRoleId;
                    cmndrReview.XmlData = reviewBusinessModel.Serialize();
                    cmndrReview.Status = Constants.Status.DON.ToString();
                    uow.UOFIncidentFormDataRepository.Add(cmndrReview);
                    uow.Commit();
                    FormDataId = cmndrReview.FormDataID;
                    result = FormDataId;
                }

                uow.Commit();

                //string CommanderId = (from ind in uow.IncidentWorkflowRepository.GetAll()
                //                      where ind.IncidentId == reviewsResponse.IncidentID
                //                      select new { ind.CMID }).Single().CMID;

                FormReviewRespository repo = new FormReviewRespository();
                repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                {
                    FormDataId = FormDataId,
                    IncidentReviewID = reviewBusinessModel.IncidentReviewId,
                    IncidentID = reviewBusinessModel.IncidentID,
                    SubmittedEmpId = reviewBusinessModel.EmpId,
                    FormId = reviewBusinessModel.FormID,
                    SubmitteduserRole = Constants.UserRoles.CMDR.ToString(),
                    ReviewerRole = Constants.UserRoles.CMDR.ToString(),
                    CMStatus = !reviewBusinessModel.IsOnlySave ? Constants.Status.Completed.ToString() : Constants.Status.Pending.ToString(),
                    SubmittedStatus = !reviewBusinessModel.IsOnlySave ? Constants.Status.Completed.ToString() : Constants.Status.Pending.ToString()
                });

                #region Updating the CM Status to the incident
                wf.UpdateCMStatus(new ReviewEntity { IncidentId = reviewBusinessModel.IncidentID, LoggedId = reviewBusinessModel.EmpId });
                #endregion



            }
            catch (Exception ex)
            {

                throw ex;
            }
            return result;
        }

        public ReviewsResponse GetCommanderReviewData(ParameterCriteria cirteria)
        {
            try
            {
                //var cmndrReviewResponse = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.FormID == FormId && x.EmpID == CMID && x.IncidentID == IncidentId).FirstOrDefault();
                //var cmndrReviewResponse = uow.UOFIncidentFormDataRepository.GetById(cirteria.formDataId);
                IncidentFormData data = null;
                if (cirteria.report)
                    data = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.FormID == cirteria.formId && x.EmpID == cirteria.employeeId && x.IncidentID == cirteria.incidentId).FirstOrDefault();
                else
                    data = uow.UOFIncidentFormDataRepository.GetById(cirteria.formDataId);

                return data != null ? data.XmlData.Deserialize<ReviewsResponse>() : null;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        #endregion

        #region Assign to Category 3 Cases WC
        public bool AssignCat3(WitnessUserEntity WC)
        {
            bool result = false;
            try
            {
                using (var transaction = new TransactionScope())
                {

                    //Insert record into Incident Users

                    IncidentUserEntity incidentUserEntity = new IncidentUserEntity();
                    IncidentUserRepository usr = new IncidentUserRepository();
                    incidentUserEntity.FirstName = WC.FirstName;
                    incidentUserEntity.MiddleName = WC.MiddleName;
                    incidentUserEntity.LastName = WC.LastName;
                    incidentUserEntity.Rank = WC.Rank;
                    incidentUserEntity.UserTypeId = WC.UserTypeId;
                    incidentUserEntity.IncidentId = WC.IncidentId;
                    incidentUserEntity.ForceEmployeeId = WC.EmployeeId;
                    incidentUserEntity.CreatedOn = DateTime.Now;
                    incidentUserEntity.UserTypeId = (int)Constants.UserType.WatchCommander;
                    usr.SaveIncidentUser(incidentUserEntity);
                    //End

                    var IncidentDetails = (from incident in uow.IncidentRepository.GetAll()
                                           where incident.IncidentId == WC.IncidentId
                                           select new IncidentEntity
                                           {
                                               IncidentId = incident.IncidentId,
                                               URN = incident.URN,
                                               IncidentDate = incident.IncidentDate,
                                               IncidentCategoryId = incident.IncidentCategoryId,
                                               IsIABNotified = incident.IsIABNotified,
                                               IABNotifiedUserId = incident.IABNotifiedUserId,
                                               IABNotifiedEmailId = incident.IABNotifiedEmailId
                                           }).FirstOrDefault();


                    IncidentCategoryForm categoryForm = new IncidentCategoryForm();

                    #region Inserting into CategoryForm Table
                    categoryForm.FormID = (int)Constants.UOFForms.IABMandatoryForm;
                    categoryForm.IncidentCategoryId = 3;
                    categoryForm.IncidentID = WC.IncidentId;
                    categoryForm.Status = Constants.Status.PND.ToString();
                    uow.CategoryFormRepository.Add(categoryForm);
                    uow.Commit();
                    #endregion
                    #region Insert IAB Notification record in Review Table
                    FormReviewRespository repo = new FormReviewRespository();
                    repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                    {
                        IncidentID = WC.IncidentId,
                        FormId = (int)Constants.UOFForms.IABMandatoryForm,
                        SubmitteduserRole = Constants.UserRoles.WC.ToString(),
                        SubmittedStatus = Constants.Status.Pending.ToString(),
                        WCID = WC.EmployeeId,
                        WCStatus = Constants.Status.Pending.ToString(),
                        SubmittedEmpId = WC.EmployeeId
                    });

                    repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                    {
                        IncidentID = WC.IncidentId,
                        FormId = (int)Constants.UOFForms.WatchCommanderUseofForceReview,
                        SubmitteduserRole = Constants.UserRoles.WC.ToString(),
                        SubmittedStatus = Constants.Status.Pending.ToString(),
                        SubmittedEmpId = WC.EmployeeId,
                        WCID = WC.EmployeeId,
                        WCStatus = Constants.Status.Pending.ToString(),
                    });

                    #endregion

                    #region Update Work flow
                    using (UoFWorkFlowRepository wf = new UoFWorkFlowRepository())
                    {
                        wf.InsertUpdateWorkFlow(new WorkFlowEntity { IncidentId = WC.IncidentId, SergeantStatus = Constants.Status.Completed.ToString(), WCID = WC.EmployeeId, WCStatus = Constants.Status.Pending.ToString() });
                        wf.updateIncident(WC.IncidentId, Convert.ToString((int)Constants.IncidentStatus.AtWatchCommander));
                    }


                    #endregion

                    #region Email Notifications
                    EmailRepository email = new EmailRepository();
                    email.EmailNotification(new EmailNotificationModel
                    {
                        Department = "Category 3 Assigned",
                        EmailId = WC.EmailId,
                        IncidentId = WC.IncidentId,
                        EmployeeNumber = WC.EmployeeId,
                    });
                    #endregion

                    uow.Commit();
                    transaction.Complete();
                }


                result = true;


            }
            catch (Exception ex)
            {

                throw ex;
            }
            return result;
        }
        #endregion

        public bool SentToCFRT(string emailId, int IncidentId, string LoggedInRole)
        {
            bool result = false;
            try
            {
                var WFModel = new WorkFlowEntity();
                if (LoggedInRole == Constants.UserRoles.WC.ToString())
                {
                    WFModel = (from ind in uow.IncidentWorkflowRepository.GetAll()
                               where ind.IncidentId == IncidentId
                               select new WorkFlowEntity { CFRTID = ind.CFRTID, WCID = ind.WCID }).FirstOrDefault();
                }
                else if (LoggedInRole == Constants.UserRoles.CAPT.ToString())
                {
                    WFModel = (from ind in uow.IncidentWorkflowRepository.GetAll()
                               where ind.IncidentId == IncidentId
                               select new WorkFlowEntity { CFRTID = ind.CFRTID, UCID = ind.UCID }).FirstOrDefault();
                }



                #region Insert into INcidentCFRT Flow

                IncidentCFRTFlow entity = new IncidentCFRTFlow();
                entity.IncidentId = IncidentId;
                entity.CRFCEmailId = emailId;
                entity.CFRCID = WFModel.CFRTID == null ? "000000" : WFModel.CFRTID;
                entity.CFRTID = WFModel.CFRTID == null ? "000000" : WFModel.CFRTID;
                entity.CRFCStatus = Constants.Status.Pending.ToString();
                entity.CreatedBy = (LoggedInRole == Constants.UserRoles.WC.ToString() ? WFModel.WCID : WFModel.UCID);
                entity.CreatedOn = DateTime.Now;
                uow.IncidentCFRTRepository.Add(entity);
                #endregion

                #region Update Work flow
                using (UoFWorkFlowRepository wf = new UoFWorkFlowRepository())
                {
                    if (LoggedInRole == Constants.UserRoles.WC.ToString())
                        wf.InsertUpdateWorkFlow(new WorkFlowEntity { IncidentId = IncidentId, WCStatus = Constants.IncidentStatus.AtCFRT.ToString(), CFRTID = WFModel.CFRTID, CFRCStatus = Constants.Status.Pending.ToString() });
                    else if (LoggedInRole == Constants.UserRoles.CAPT.ToString())
                        wf.InsertUpdateWorkFlow(new WorkFlowEntity { IncidentId = IncidentId, UCStatus = Constants.IncidentStatus.AtCFRT.ToString(), CFRTID = WFModel.CFRTID, CFRCStatus = Constants.Status.Pending.ToString() });

                    wf.updateIncident(IncidentId, Convert.ToString((int)Constants.IncidentStatus.AtCFRT));
                }

                #endregion

                #region Email Notifications
                EmailRepository email = new EmailRepository();
                email.EmailNotification(new EmailNotificationModel
                {
                    Department = "Sent to CFRT",
                    EmailId = emailId,
                    IncidentId = IncidentId,
                    EmployeeNumber = WFModel.CFRTID == null ? "000000" : WFModel.CFRTID,
                });
                #endregion

                uow.Commit();
            }



            catch (Exception ex)
            {

                throw ex;
            }
            return result;
        }

        public bool RolloutToChief(int incidentId)
        {
            bool result = false;
            try
            {
                var WFModel = new WorkFlowEntity();

                #region Update into INcidentCFRT Flow

                var model = uow.IncidentCFRTRepository.GetAll().Where(x => x.IncidentId == incidentId && x.CRFCStatus == Constants.Status.Pending.ToString()).FirstOrDefault();
                if (model != null)
                {
                    model.CRFCStatus = Constants.Status.Completed.ToString();
                    uow.IncidentCFRTRepository.Update(model);
                }
                #endregion

                #region Update Work flow
                using (UoFWorkFlowRepository wf = new UoFWorkFlowRepository())
                {
                    wf.InsertUpdateWorkFlow(new WorkFlowEntity { IncidentId = incidentId, UCStatus = Constants.IncidentStatus.Completed.ToString(), CFRCStatus = Constants.Status.Completed.ToString(), ChiefStatus = Constants.Status.Pending.ToString() });

                    wf.updateIncident(incidentId, Convert.ToString((int)Constants.IncidentStatus.AtChief));
                }

                #endregion

                #region Email Notifications
                EmailRepository email = new EmailRepository();
                //email.EmailNotification(new EmailNotificationModel
                //{
                //    Department = "Sent to CFRT",
                //    EmailId = emailId,
                //    IncidentId = incidentId,
                //    EmployeeNumber = WFModel.CFRTID == null ? "000000" : WFModel.CFRTID,
                //});
                #endregion

                uow.Commit();
            }



            catch (Exception ex)
            {

                throw ex;
            }
            return result;
        }
    }
}
