﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.Common.Utilities;
using UOF.DataAccess.Repository;

namespace UOF.DataAccess.DbRepository
{
    public class ReturnCommentsRepository : IDisposable
    {
        UnitOfWork uow = new UnitOfWork();

        public bool returnComments(ReturnCommentModel entity)
        {
            int reviewId = 0;
            try
            {
                if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == entity.IncidentId && x.FormId == entity.FormId && x.InvolvedId == entity.FormSubmitedId && x.IncidentReviewID == entity.IncidentReviewID).Any())
                {
                    //reviewId = (from ind in uow.ReviewRespository.GetAll()
                    //            where ind.IncidentID == entity.IncidentId && ind.FormId == entity.FormId && ind.InvolvedId == entity.FormSubmitedId
                    //            select new { ind.IncidentReviewID }).Single().IncidentReviewID;

                    var returnCommt = uow.ReturnRepository.FindBy(a => a.IncidentReviewID == entity.IncidentReviewID && a.Status == Constants.Status.Pending.ToString()).FirstOrDefault();
                    if (returnCommt != null)
                    {
                        returnCommt.UpdatedOn = DateTime.Now;
                        returnCommt.Updatedby = entity.FormSubmitedId;
                        returnCommt.Comments = entity.Comments;
                        returnCommt.Status = Constants.Status.Completed.ToString();
                        uow.ReturnRepository.Update(returnCommt);
                    }
                    else
                    {
                        returnCommt = uow.ReturnRepository.FindBy(a => a.IncidentReviewID == entity.IncidentReviewID && a.Status == Constants.Status.Pending.ToString() && a.CreatedBy == entity.EmployeeNumber).FirstOrDefault();
                        if (returnCommt != null)
                        {
                            returnCommt.Comments = entity.Comments;
                            returnCommt.Status = Constants.Status.Pending.ToString();
                            uow.ReturnRepository.Update(returnCommt);
                            uow.Commit();
                        }
                        else
                        {
                            var comment = new ReturnComment();
                            comment.IncidentReviewID = entity.IncidentReviewID;
                            comment.EmployeeNumber = entity.EmployeeNumber;
                            comment.CreatedOn = DateTime.Now;
                            comment.CreatedBy = entity.EmployeeNumber;
                            comment.Comments = entity.Comments;
                            comment.Status = Constants.Status.Pending.ToString();
                            uow.ReturnRepository.Add(comment);
                        }
                    }
                    uow.Commit();
                }
                return true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public string getReturnComments(ReturnCommentModel entity)
        {
            if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == entity.IncidentId && x.FormId == entity.FormId && x.InvolvedId == entity.FormSubmitedId).Any())
            {
                //var reviewId = (from ind in uow.ReviewRespository.GetAll()
                //                where ind.IncidentID == entity.IncidentId && ind.FormId == entity.FormId && ind.InvolvedId == entity.FormSubmitedId
                //                select new { ind.IncidentReviewID }).Single().IncidentReviewID;

                if (uow.ReturnRepository.GetAll().Where(x => x.IncidentReviewID == entity.IncidentReviewID).Any())
                    return uow.ReturnRepository.GetAll().OrderByDescending(x => x.ReturnId).FirstOrDefault().Comments;
                else
                    return "";
            }

            return "";

        }


        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                }
                disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
        }
        #endregion

    }
}
