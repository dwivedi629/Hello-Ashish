﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.DataAccess.Repository;
using UOF.Common.Utilities;

namespace UOF.DataAccess.DbRepository
{
    public class NarrativeRepository
    {
        UnitOfWork uow = new UnitOfWork();

        public int SaveUOFNarrative(UoFNarrativeEntityModel narrativeBusinessModel)
        {
            int result = 0;
            FormReviewRespository repo = new FormReviewRespository();
            IncidentCategoryForm categoryForm = new IncidentCategoryForm();
            narrativeBusinessModel.UserRoleId = repo.GetUserRoleID(narrativeBusinessModel.UserRole);
            int FormDataId = 0;
            try
            {
                var narrative = new UoFNarrativeEntityModel();
                var narrativeModel = uow.UOFIncidentFormDataRepository.FindBy(a => a.UserRoleId == narrativeBusinessModel.UserRoleId && a.FormID == narrativeBusinessModel.FormID && a.IncidentID == narrativeBusinessModel.IncidentID && a.EmpID == narrativeBusinessModel.EmpId && a.FormDataID == narrativeBusinessModel.formDataId).FirstOrDefault();
                if (narrativeModel != null)
                {
                    narrativeModel.IncidentID = narrativeBusinessModel.IncidentID;
                    narrativeModel.XmlData = narrativeBusinessModel.Serialize();
                    narrativeModel.UpdateBy = narrativeBusinessModel.EmpId;
                    narrativeModel.UpdateOn = DateTime.Now;
                    uow.UOFIncidentFormDataRepository.Update(narrativeModel);
                    result = narrativeModel.FormDataID;
                }
                else
                {
                    var uofNarrative = new IncidentFormData();
                    uofNarrative.IncidentID = narrativeBusinessModel.IncidentID;
                    uofNarrative.EmpID = narrativeBusinessModel.EmpId;
                    uofNarrative.CreatedOn = DateTime.Now;
                    uofNarrative.CreatedBy = narrativeBusinessModel.EmpId;
                    uofNarrative.FormID = narrativeBusinessModel.FormID;
                    uofNarrative.UserRoleId = narrativeBusinessModel.UserRoleId;
                    uofNarrative.XmlData = narrativeBusinessModel.Serialize();
                    uofNarrative.Status = Constants.Status.DON.ToString();
                    uow.UOFIncidentFormDataRepository.Add(uofNarrative);
                    uow.Commit();
                    FormDataId = uofNarrative.FormDataID;
                    result = FormDataId;
                    
                    


                    ////Update Incident Category form
                    //var CAModel = uow.CategoryFormRepository.FindBy(a=>a.FormID == narrativeBusinessModel.FormID && a.IncidentID == narrativeBusinessModel.IncidentID).FirstOrDefault();
                    //if (CAModel != null)
                    //{
                    //    CAModel.Status = Constants.Status.DON.ToString();
                    //    uow.CategoryFormRepository.Update(CAModel);
                    //}
                }
                #region Update Incident Review Forms
                string sergeantID = (from ind in uow.IncidentRepository.GetAll()
                                     where ind.IncidentId == narrativeBusinessModel.IncidentID
                                     select new { ind.SergeantId }).Single().SergeantId;
                repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                {
                    FormDataId = FormDataId,
                    IncidentReviewID = narrativeBusinessModel.IncidentReviewId,
                    IncidentID = narrativeBusinessModel.IncidentID,
                    SubmittedEmpId = sergeantID,
                    FormId = narrativeBusinessModel.FormID,
                    SubmitteduserRole = narrativeBusinessModel.UserRole,
                    ReviewerRole = !narrativeBusinessModel.IsOnlySave ? Constants.UserRoles.WC.ToString() : "",
                    SergeantStatus = !narrativeBusinessModel.IsOnlySave ? Constants.Status.Completed.ToString() : "" ,
                    WCStatus = !narrativeBusinessModel.IsOnlySave ?  Constants.Status.Pending.ToString():"",
                    SubmittedStatus = !narrativeBusinessModel.IsOnlySave ? Constants.Status.Completed.ToString() : Constants.Status.Pending.ToString(),
                });
                #endregion
                uow.Commit();

               
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return result;
        }

        public UoFNarrativeEntityModel GetUOFNarrative(ParameterCriteria cirteria)
        {

            try
            {
                IncidentFormData data = null;
                if (cirteria.report)
                    data = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.FormID == cirteria.formId && x.EmpID == cirteria.employeeId && x.IncidentID == cirteria.incidentId).FirstOrDefault();
                else
                    data = uow.UOFIncidentFormDataRepository.GetById(cirteria.formDataId);

                var result = data != null ? data.XmlData.Deserialize<UoFNarrativeEntityModel>() : null;
                if (result != null)
                {
                    using (ReturnCommentsRepository obj = new ReturnCommentsRepository())
                    {
                        result.caseStatus.RejectComments = obj.getReturnComments(new ReturnCommentModel { IncidentId = cirteria.incidentId, FormId = cirteria.formId, FormSubmitedId = cirteria.employeeId, IncidentReviewID = cirteria.IncidentReviewId });
                    }
                }
                return result;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
    }
}
