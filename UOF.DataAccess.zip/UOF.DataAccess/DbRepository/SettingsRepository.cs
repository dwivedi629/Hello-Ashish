﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using UOF.Common.EntityModel;
using UOF.Common.Utilities;
using UOF.DataAccess.Repository;

namespace UOF.DataAccess.DbRepository
{
    public class SettingsRepository : ISettingsRepository
    {
        const string SuperRoleAdmin = "SuperAdmin";
        public List<UserRoleSettingsEntity> GetRoles()
        {
            using (UnitOfWork unitofWork = new UnitOfWork())
            {
                return (from s in unitofWork.UserRoleRepository.GetAll()
                        select new UserRoleSettingsEntity
                        {
                            Description = s.Description,
                            RoleCode = s.RoleCode,
                            RoleId = s.RoleId,
                            RoleName = s.RoleName

                        }).ToList();
            }
        }

        public List<FormsNameSettings> GetFormsName()
        {
            using (UnitOfWork unitofWork = new UnitOfWork())
            {
                return (from s in unitofWork.UofFormRepository.GetAll()
                        select new FormsNameSettings
                        {
                            Description = s.Description,
                            FormCode = s.FormCode,
                            FormId = s.FormId,
                            FormName = s.FormName,
                            Text = s.Text,
                            ParentId = s.ParentId,
                            ActionName = s.ActionName,
                            ControllerName = s.ControllerName,
                            IsMenuItem = s.IsMenuItem,
                            IsSettingItem = s.IsSettingItem,

                        }).ToList();
            }
        }

        public List<FormPermissionSettings> GetFormPermission()
        {
            using (UnitOfWork unitofWork = new UnitOfWork())
            {
                return (from s in unitofWork.FormPermissionRepository.GetAll()
                        join f in unitofWork.UofFormRepository.GetAll() on s.FormId equals f.FormId
                        select new FormPermissionSettings
                        {
                            FormId = s.FormId,
                            RoleId = s.RoleId,
                            FormPermissionId = s.FormPermissionId,
                            IsViewOnly = s.IsViewOnly,
                            FormCode = f.FormCode
                        }).ToList();
            }
        }

        public bool GetFormPermission(string formCode, string roleCode)
        {
            if (string.IsNullOrWhiteSpace(formCode)) { throw new Exception("form Code needed."); };
            if (roleCode == SuperRoleAdmin) { return true; };
            using (UnitOfWork unitofWork = new UnitOfWork())
            {
                dynamic result = null;
                var roleResult = (from roles in unitofWork.UserRoleRepository.GetAll() where roles.RoleCode == roleCode select roles).FirstOrDefault();
                var frmInfo = (from frmName in unitofWork.UofFormRepository.GetAll() where frmName.FormCode == formCode select new { frmName.FormId, frmName.ParentId }).FirstOrDefault();

                if (frmInfo.ParentId == 0)
                {
                    var isChildExtst = (from frmForm in unitofWork.UofFormRepository.GetAll()
                                        where frmForm.ParentId == frmInfo.FormId
                                        select frmForm).Any();
                    if (isChildExtst)
                    {
                        result = (from frmName in unitofWork.UofFormRepository.GetAll()
                                  join frmPermission in unitofWork.FormPermissionRepository.GetAll() on frmName.FormId equals frmPermission.FormId
                                  where frmName.ParentId == frmInfo.FormId && frmPermission.RoleId == roleResult.RoleId
                                  select frmPermission).FirstOrDefault();
                    }
                    else
                    {
                        result = (from frmPermission in unitofWork.FormPermissionRepository.GetAll()
                                  where frmPermission.FormId == frmInfo.FormId && frmPermission.RoleId == roleResult.RoleId
                                  select frmPermission).FirstOrDefault();
                    }


                }
                else
                {
                    result = (from frmPermission in unitofWork.FormPermissionRepository.GetAll()
                              where frmPermission.FormId == frmInfo.FormId && frmPermission.RoleId == roleResult.RoleId
                              select frmPermission
                                      ).FirstOrDefault();

                }
                if (result != null)
                    return true;
                else
                    return false;

            }
        }

        public bool SaveFormPermissions(List<FormPermisssion> objfrmPermission)
        {
            using (UnitOfWork unitofWork = new UnitOfWork())
            {
                unitofWork.FormPermissionRepository.DeleteAll("FormPermisssion");
                unitofWork.Commit();
                foreach (var item in objfrmPermission)
                {
                    unitofWork.FormPermissionRepository.Add(item);
                    unitofWork.Commit();
                }


            }

            return true;
        }
        public bool SaveRole(UserRoleSettingsEntity roleEntity)
        {
            using (UnitOfWork unitofWork = new UnitOfWork())
            {
                var userRole = new UserRole();
                userRole.RoleCode = roleEntity.RoleCode;
                userRole.RoleName = roleEntity.RoleName;
                userRole.Description = roleEntity.Description;
                userRole.ReadOnly = roleEntity.ReadOnly;
                userRole.Rank = roleEntity.Rank;
                unitofWork.UserRoleRepository.Add(userRole);
                unitofWork.Commit();
            }
            return true;
        }

        public List<IncidentStatusDetail> GetIncidentFormData(string URN)
        {
            List<IncidentStatusDetail> formsList = new List<IncidentStatusDetail>();
            using (UnitOfWork unitofWork = new UnitOfWork())
            {
                formsList = (from a in unitofWork.ReviewRespository.GetAll()
                             join b in unitofWork.UofFormRepository.GetAll() on a.FormId equals b.FormId
                             //join c in unitofWork.UOFIncidentFormDataRepository.GetAll() on a.FormDataID equals c.FormDataID
                             join user in unitofWork.UserRepository.GetAll() on a.InvolvedId equals user.ForceEmployeeId
                             join incident in unitofWork.IncidentRepository.GetAll() on a.IncidentID equals incident.IncidentId
                             join userDetail in unitofWork.UserDetailRepository.GetAll() on user.UserDetailId equals userDetail.UserDetailId
                             where incident.URN == URN && incident.IsDeleted == false
                             && (a.InvolvedStatus != "Deleted") && a.FormId != (int)Constants.UOFForms.SupervisoryReport
                             select new IncidentStatusDetail
                             {
                                 URN = incident.URN,
                                 ReviewId = a.IncidentReviewID,
                                 FromDataId = a.FormDataID,
                                 EmployeeID = a.InvolvedId,
                                 Role = a.InvolvedRole,
                                 IncidentId = a.IncidentID,
                                 FirstName = userDetail.FirstName,
                                 LastName = userDetail.LastName,
                                 Status = a.SergeantStatus,
                                 FormId = a.FormId,
                                 FormName = b.FormName,
                                 FormStatus = (a.InvolvedStatus == "DON" || a.InvolvedStatus == "Completed") ? "Completed" : (a.InvolvedStatus == Constants.Status.Rejected.ToString() ? Constants.Status.Rejected.ToString() : "Pending"),
                                 ReviewerRole = a.ReviewerRole,
                                 SergeantId = a.SergeantId,
                                 WCID = a.WCID,
                                 WCStatus = a.WCStatus,
                                 UCID = a.UCID,
                                 UCStatus = a.UCStatus,
                                 CMID = a.CMID,
                                 CMStatus = a.CMStatus,
                             }).Distinct().ToList();

            }
            return formsList;

        }
        public bool ChangeOwnerShip(ChangeOwnerModel entity)
        {


            using (UnitOfWork unitofWork = new UnitOfWork())
            {
                using (var transaction = new TransactionScope())
                {
                    var ReviewData = unitofWork.ReviewRespository.GetById(entity.IncidentReviewId);
                    if (ReviewData != null)
                    {
                        if (entity.owner == "R") // Reviewer
                        {
                            //Update Incident Form Review table
                            //ReviewData.SergeantId = entity.ChangedEmpId;
                            entity.ChangedEmpId = ReviewData.SergeantId;
                            ReviewData.SergeantId = string.Empty;
                            ReviewData.SergeantStatus = Constants.Status.Pending.ToString();
                            ReviewData.WCStatus = Constants.Status.NotReady.ToString();
                            ReviewData.UCStatus = Constants.Status.NotReady.ToString();
                            unitofWork.ReviewRespository.Update(ReviewData);
                        }
                        else
                        {
                            //Update Incident Form Review table
                            ReviewData.InvolvedId = entity.ChangedEmpId;
                            ReviewData.InvolvedStatus = Constants.Status.Pending.ToString();
                            unitofWork.ReviewRespository.Update(ReviewData);

                            //Update Incident Form Data table
                            int RId = Convert.ToInt32(ReviewData.FormDataID);
                            var formData = unitofWork.UOFIncidentFormDataRepository.GetById(RId);
                            if (formData != null)
                            {
                                formData.EmpID = entity.ChangedEmpId;
                                formData.CreatedBy = entity.ChangedEmpId;
                                unitofWork.UOFIncidentFormDataRepository.Update(formData);
                            }

                            //Check whether existing emp is having forms assigned or not

                            int formExists = unitofWork.ReviewRespository.GetAll().Where(x => x.InvolvedId == entity.ExistingEmpId && x.IncidentID == entity.IncidentId).Count();
                            if (formExists == 0)
                            {
                                //Update User and User Details tables.
                                var usr = (from user in unitofWork.UserRepository.GetAll()
                                           join f in unitofWork.IncidentUserRepository.GetAll() on user.UserId equals f.UserId
                                           join g in unitofWork.UserDetailRepository.GetAll() on user.UserDetailId equals g.UserDetailId
                                           where f.IncidentId == entity.IncidentId && user.ForceEmployeeId == entity.ExistingEmpId
                                           select user).FirstOrDefault();
                                if (usr != null)
                                {
                                    var usrDetail = unitofWork.UserDetailRepository.GetAll().Where(x => x.UserDetailId == usr.UserDetailId).FirstOrDefault();
                                    if (usrDetail != null)
                                    {
                                        usrDetail.FirstName = entity.ChangedEmmFirstName;
                                        usrDetail.LastName = entity.ChangedEmpLastName;
                                        usrDetail.Rank = entity.ChangedEmpRank;
                                        unitofWork.UserDetailRepository.Update(usrDetail);
                                    }
                                    usr.ForceEmployeeId = entity.ChangedEmpId;
                                    usr.Active = true;
                                    unitofWork.UserRepository.Update(usr);
                                }
                            }
                            else
                            {  
                                //Insert the changed user information into Incident Users, Users, User Details 
                                IncidentUserEntity incidentUser = new IncidentUserEntity() { Mode = Constants.Mode.Add.ToString(), FirstName = entity.ChangedEmmFirstName, LastName = entity.ChangedEmpLastName, Rank = entity.ChangedEmpRank, EmailId = entity.EmailId, ForceEmployeeId = entity.ChangedEmpId, UserTypeId = (int)Constants.UserType.AssignedUser, IncidentId = entity.IncidentId };
                                UserRepository repo = new UserRepository();
                                var usr = (from s in unitofWork.UserRepository.GetAll()
                                           join f in unitofWork.IncidentUserRepository.GetAll() on s.UserId equals f.UserId
                                           where f.IncidentId == incidentUser.IncidentId && f.UserTypeId == 11 && s.ForceEmployeeId == incidentUser.ForceEmployeeId
                                           select s).FirstOrDefault();
                                if (usr != null)
                                {
                                    var usrDetail = unitofWork.UserDetailRepository.GetAll().Where(x => x.UserDetailId == usr.UserDetailId).FirstOrDefault();
                                    if (usrDetail == null)
                                        repo.SaveIncidentUser(incidentUser);
                                }
                                else
                                    repo.SaveIncidentUser(incidentUser);
                            }

                        }
                        //Insertinto Record into Audti Trails.
                        var CO = new AT_ChangeOwner();
                        CO.IncidentId = entity.IncidentId;
                        CO.FormId = entity.FormId;
                        CO.ExistingEmpId = entity.ExistingEmpId;
                        CO.ChangedEmpId = entity.ChangedEmpId;
                        CO.CreatedBy = entity.CreatedBy;
                        CO.CreatedOn = DateTime.Now;
                        unitofWork.ChangeownerRespository.Add(CO);
                        unitofWork.Commit();

                        #region Email Notification
                        //TODO 
                        #endregion
                    }
                    transaction.Complete();
                }
                return true;
            }

        }

        //Package

        public List<IncidentStatusDetail> GetPackageInfo(string URN)
        {
            List<IncidentStatusDetail> data = new List<IncidentStatusDetail>();
            using (UnitOfWork unitofWork = new UnitOfWork())
            {
                data = (from incident in unitofWork.IncidentRepository.GetAll()
                             join b in unitofWork.IncidentWorkflowRepository.GetAll() on incident.IncidentId equals b.IncidentId
                             where incident.URN == URN && incident.IsDeleted == false
                             select new IncidentStatusDetail
                             {
                                 URN = incident.URN,
                                 IncidentId = incident.IncidentId,
                                 SergeantStatus = b.SergeantStatus != null ? b.SergeantStatus : "--",
                                 WCStatus = b.WCStatus!= null ? b.WCStatus : "--",
                                 UCStatus = b.UCStatus != null ? b.UCStatus : "--",
                                 CMStatus = b.CMStatus != null ? b.CMStatus : "--",
                                 DeputyStatus = b.DeputyStatus != null ? b.DeputyStatus : "--",
                                 CFRCStatus = b.CFRCStatus != null ? b.CFRCStatus : "--",
                                 CFRTStatus = b.CFRTStatus != null ? b.CFRTStatus : "--",
                                 DCStatus = b.DCStatus != null ? b.DCStatus : "--",
                                 UCID = b.UCID!= null ? b.UCID : "--",
                                 CMID = b.CMID != null ? b.CMID : "--",
                                 CFRCID = b.CFRCID != null ? b.CFRCID : "--",
                                 CFRTID = b.CFRTID != null ? b.CFRTID : "--",
                                 SergeantId = b.SergeantID != null ? b.SergeantID : "--",
                                 DCID = b.DCID != null ? b.DCID : "--",
                                 WCID = b.WCID != null ? b.WCID : "--",
                             }).Distinct().ToList();
            }
            return data;

        }
    }
}
