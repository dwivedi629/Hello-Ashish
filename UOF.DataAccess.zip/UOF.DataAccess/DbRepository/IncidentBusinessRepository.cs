﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.DataAccess.Repository;

namespace UOF.DataAccess.DbRepository
{
    public class IncidentBusinessRepository
    {
        UnitOfWork uow = new UnitOfWork();
        public void InsertUpdateIncidentBusiness(IncidentEntity model)
        {
            try
            {
                if (uow.IncidentBusinessRespository.GetAll().Where(x => x.IncidentID == model.IncidentId).Any())
                {
                    var dbEntity = uow.IncidentBusinessRespository.FindBy(a => a.IncidentID == model.IncidentId ).FirstOrDefault();
                    if (dbEntity != null)
                    {
                        var uofAdd = new IncidentBusinessAddres();
                        dbEntity.Name = model.BusinessName;
                        dbEntity.AddressNumber = "12345";
                        dbEntity.Street = model.BusinessStreet;
                        dbEntity.City = model.BusinessCity;
                        dbEntity.Zip = model.BusinessZipCode;
                        dbEntity.CreatedBy = model.EmpId;
                        dbEntity.CreatedOn = DateTime.Now;
                        uow.IncidentBusinessRespository.Update(dbEntity);
                    }
                    else
                    {
                        var uofAdd = new IncidentBusinessAddres();
                        uofAdd.IncidentID = model.IncidentId;
                        uofAdd.Name = model.BusinessName;
                        uofAdd.AddressNumber ="12345";
                        uofAdd.Street = model.BusinessStreet;
                        uofAdd.City = model.BusinessCity;
                        uofAdd.Zip = model.BusinessZipCode;
                        uofAdd.CreatedBy = model.EmpId;
                        uofAdd.CreatedOn = DateTime.Now;
                        uow.IncidentBusinessRespository.Add(uofAdd);
                    }
                }
                else
                {
                    var uofAdd = new IncidentBusinessAddres();
                    uofAdd.IncidentID = model.IncidentId;
                    uofAdd.Name = model.BusinessName;
                    uofAdd.AddressNumber = "12345";
                    uofAdd.Street = model.BusinessStreet;
                    uofAdd.City = model.BusinessCity;
                    uofAdd.Zip = model.BusinessZipCode;
                    uofAdd.CreatedBy = model.EmpId;
                    uofAdd.CreatedOn = DateTime.Now;
                    uow.IncidentBusinessRespository.Add(uofAdd);

                }
                uow.Commit();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
