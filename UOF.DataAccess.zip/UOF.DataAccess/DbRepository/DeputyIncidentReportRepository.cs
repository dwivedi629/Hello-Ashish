﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.DataAccess.Repository;
using UOF.Common.Utilities;

namespace UOF.DataAccess.DbRepository
{
    public class DeputyIncidentReportRepository : IDeputyIncidentReportRepository
    {
        UnitOfWork uow = new UnitOfWork();

        public int SaveDeputyIncidentReport(DeputyIncidentReportBusinessModel deputyIncidentReportBusinessModel)
        {
            int result = 0;
            FormReviewRespository repo = new FormReviewRespository();
            int FormDataId = 0;
            deputyIncidentReportBusinessModel.UserRoleId = repo.GetUserRoleID(deputyIncidentReportBusinessModel.UserRole);
            try
            {
                //inmateInjuryBusinessModel.FormID = (int)Constants.UOFForms.InmateInjury;
                var DeputyIRModel = uow.UOFIncidentFormDataRepository.FindBy(a => a.UserRoleId == deputyIncidentReportBusinessModel.UserRoleId && a.FormID == deputyIncidentReportBusinessModel.FormID && a.IncidentID == deputyIncidentReportBusinessModel.IncidentID && a.EmpID == deputyIncidentReportBusinessModel.EmpId && a.FormDataID == deputyIncidentReportBusinessModel.formDataId).FirstOrDefault();
                if (deputyIncidentReportBusinessModel.isApproval)
                {
                    DeputyIRModel = uow.UOFIncidentFormDataRepository.FindBy(a => a.FormID == deputyIncidentReportBusinessModel.FormID && a.IncidentID == deputyIncidentReportBusinessModel.IncidentID && a.EmpID == deputyIncidentReportBusinessModel.SubmitedId && a.FormDataID == deputyIncidentReportBusinessModel.formDataId).FirstOrDefault();
                    if (DeputyIRModel != null)
                    {
                        DeputyIRModel.IncidentID = DeputyIRModel.IncidentID;
                        DeputyIRModel.XmlData = deputyIncidentReportBusinessModel.Serialize();
                        DeputyIRModel.UpdateBy = deputyIncidentReportBusinessModel.EmpId;
                        DeputyIRModel.UpdateOn = DateTime.Now;
                        uow.UOFIncidentFormDataRepository.Update(DeputyIRModel);
                        result = DeputyIRModel.FormDataID;
                        uow.Commit();
                        using (LookupRespository lp = new LookupRespository())
                        {
                            lp.ApproveorReject(new ReviewEntity { IncidentId = deputyIncidentReportBusinessModel.IncidentID, DeputyEmpId = deputyIncidentReportBusinessModel.SubmitedId, ReviewerReviewId = deputyIncidentReportBusinessModel.EmpId, FormId = deputyIncidentReportBusinessModel.FormID, ReviewerRole = deputyIncidentReportBusinessModel.UserRole, isApprove = "Y", IncidentReviewId = deputyIncidentReportBusinessModel.IncidentReviewId });
                        }
                    }
                }
                else
                {
                    if (DeputyIRModel != null)
                    {
                        DeputyIRModel.IncidentID = deputyIncidentReportBusinessModel.IncidentID;
                        DeputyIRModel.XmlData = deputyIncidentReportBusinessModel.Serialize();
                        DeputyIRModel.UpdateBy = deputyIncidentReportBusinessModel.EmpId;
                        DeputyIRModel.UpdateOn = DateTime.Now;
                        uow.UOFIncidentFormDataRepository.Update(DeputyIRModel);
                        result = DeputyIRModel.FormDataID;
                        uow.Commit();
                    }
                    else
                    {
                        var DeputyIReport = new IncidentFormData();
                        DeputyIReport.IncidentID = deputyIncidentReportBusinessModel.IncidentID;
                        DeputyIReport.EmpID = deputyIncidentReportBusinessModel.EmpId;
                        DeputyIReport.CreatedOn = DateTime.Now;
                        DeputyIReport.CreatedBy = deputyIncidentReportBusinessModel.EmpId;
                        DeputyIReport.FormID = deputyIncidentReportBusinessModel.FormID;
                        DeputyIReport.UserRoleId = deputyIncidentReportBusinessModel.UserRoleId;
                        DeputyIReport.XmlData = deputyIncidentReportBusinessModel.Serialize();
                        DeputyIReport.Status = Constants.Status.DON.ToString();
                        uow.UOFIncidentFormDataRepository.Add(DeputyIReport);
                        uow.Commit();
                        FormDataId = DeputyIReport.FormDataID;
                        result = FormDataId;


                    }
                    repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                    {
                        FormDataId = FormDataId,
                        IncidentID = deputyIncidentReportBusinessModel.IncidentID,
                        IncidentReviewID = deputyIncidentReportBusinessModel.IncidentReviewId,
                        SubmittedEmpId = deputyIncidentReportBusinessModel.EmpId,
                        FormId = deputyIncidentReportBusinessModel.FormID,
                        SubmitteduserRole = deputyIncidentReportBusinessModel.UserRole,
                        ReviewerRole = !deputyIncidentReportBusinessModel.IsOnlySave ? Constants.UserRoles.SGT.ToString() : "",
                        SergeantStatus = !deputyIncidentReportBusinessModel.IsOnlySave ? Constants.Status.Pending.ToString() : "",
                        SubmittedStatus = !deputyIncidentReportBusinessModel.IsOnlySave ? Constants.Status.DON.ToString() : Constants.Status.Pending.ToString(),
                    });
                }


            }
            catch (Exception ex)
            {

                throw ex;
            }
            return result;
        }

        public DeputyIncidentReportBusinessModel GetDeputyIncidentReport(ParameterCriteria cirteria)
        {
            try
            {
                IncidentFormData data = null;
                if (cirteria.report)
                    data = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.FormID == cirteria.formId && x.EmpID == cirteria.employeeId && x.IncidentID == cirteria.incidentId).FirstOrDefault();
                else
                    data = uow.UOFIncidentFormDataRepository.GetById(cirteria.formDataId);

                var result = data != null ? data.XmlData.Deserialize<DeputyIncidentReportBusinessModel>() : null;
                if (result != null)
                {
                    using (ReturnCommentsRepository obj = new ReturnCommentsRepository())
                    {
                        result.property.RejectComments = obj.getReturnComments(new ReturnCommentModel { IncidentId = cirteria.incidentId, FormId = cirteria.formId, FormSubmitedId = cirteria.employeeId, IncidentReviewID = cirteria.IncidentReviewId });
                    }

                    var ApprovOrReject = uow.FormApprovalRejectRespository.GetAll().Where(x => x.FormId == cirteria.formId && x.FormFilledBy == cirteria.employeeId && x.IncidentId == cirteria.incidentId && x.ActionBy == cirteria.reviewerId && x.Active == true).ToList();
                    if (ApprovOrReject != null)
                    {
                        foreach (FormApprovalorReject item in ApprovOrReject)
                        {
                            if (!string.IsNullOrWhiteSpace(item.EmployeeNo) && !string.IsNullOrWhiteSpace(item.Assignment) && !string.IsNullOrWhiteSpace(item.ActionDate.ToString()) && !string.IsNullOrWhiteSpace(item.SRD))
                            {
                                result.deputy.Deputy2ApprovedEmployeeNumber = item.EmployeeNo;
                                result.deputy.Deputy2ApprovedDateORTime = item.ActionDate.ToString();
                                result.deputy.Deputy2Assignment = item.Assignment;
                                result.deputy.SpecialRequestDistribution = item.SRD;
                            }
                        }
                        
                    }
                }
                return result;

                //return xml.Deserialize<DeputyIncidentReportBusinessModel>();
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
    }
}
