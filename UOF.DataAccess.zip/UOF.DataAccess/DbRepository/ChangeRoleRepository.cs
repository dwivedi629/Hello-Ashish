﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.DataAccess.Repository;

namespace UOF.DataAccess.DbRepository
{
    public class ChangeRoleRepository
    {
        UnitOfWork unitOfWork = new UnitOfWork();

        public bool saveChangeRole(ChangeRoleEntity model)
        {
            bool result = false;
            try
            {
                model.IncidentId = (from ind in unitOfWork.IncidentRepository.GetAll()
                                     where ind.URN == model.URN
                                  select new { ind.IncidentId }).Single().IncidentId;

                var entity = unitOfWork.ChangeRoleRespository.FindBy(a => a.IncidentId == model.IncidentId && a.EmployeeId == model.EmployeeId ).FirstOrDefault();
                if (entity != null)
                {
                    entity.IncidentId = model.IncidentId;
                    entity.ValidStill = model.ValidStill;
                    unitOfWork.ChangeRoleRespository.Update(entity);
                }
                else
                {
                    var dbEntity = new UoF_ChangeRole();
                    string[] userInfo = model.Name.Split('-');
                    dbEntity.IncidentId = model.IncidentId;
                    dbEntity.URN = model.URN;
                    dbEntity.CreatedOn = DateTime.Now;
                    dbEntity.CreatedBy = model.loggedId;
                    dbEntity.EmployeeId = model.EmployeeId;
                    if (userInfo.Length == 2)
                    {
                        dbEntity.Name = userInfo[0];
                        dbEntity.ForceRank = userInfo[1];
                    }
                    dbEntity.ValidStill = model.ValidStill;
                    dbEntity.Active = true;
                    dbEntity.UoFRank = model.UoFRank;
                    unitOfWork.ChangeRoleRespository.Add(dbEntity);
                }

                unitOfWork.Commit();

                result = true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return result;
        }
    }
}
