﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.DataAccess.Repository;
using UOF.Common.Utilities;

namespace UOF.DataAccess.DbRepository
{
    public class NavigationRepository
    {
        private UnitOfWork _uow = null;
        private UnitOfWork uow
        {
            get
            {
                if (_uow == null)
                    _uow = new UnitOfWork();
                return _uow;

            }
        }


        public List<NavigationEntity> getMenuDetails(int role)
        {
            var menu = (from a in uow.FormPermissionRepository.GetAll()
                          join b in uow.UofFormRepository.GetAll() on a.FormId equals b.FormId
                          where a.RoleId == role && (b.ActionName!=null && b.ControllerName!=null)
                          select new NavigationEntity
                          {
                              ActionName = b.ActionName,
                              ControllerName = b.ControllerName,
                              FormCode = b.FormCode,
                              FormName = b.FormName,
                              FormText = b.Text
                          }).ToList();

            return menu;
        }
    }
}
