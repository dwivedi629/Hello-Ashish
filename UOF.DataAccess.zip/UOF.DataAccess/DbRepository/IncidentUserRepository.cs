﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using UOF.Common.EntityModel;
using UOF.Common.Utilities;
using UOF.DataAccess.DataModel;
//using UOF.DataAccess.DataModel;
using UOF.DataAccess.Repository;

namespace UOF.DataAccess.DbRepository
{
    public class IncidentUserRepository : IncidentRepository
    {
        UnitOfWork uow = new UnitOfWork();

        public int InsertIncidentUser(IncidentUserEntity incidentUserEntity)
        {
            // Insert into IncidentUser
            IncidentUser incidentUser = new IncidentUser();
            incidentUser.IncidentId = incidentUserEntity.IncidentId;
            incidentUser.UserId = incidentUserEntity.UserId;
            incidentUser.UserTypeId = incidentUserEntity.UserTypeId;
            if (!string.IsNullOrWhiteSpace(incidentUserEntity.SergeantId))
                incidentUser.ReviewerId = incidentUserEntity.SergeantId;
            if (!string.IsNullOrWhiteSpace(incidentUserEntity.ReviewerId))
                incidentUser.ReviewerId = incidentUserEntity.ReviewerId;
            incidentUser.Createdon = DateTime.Now;
            uow.IncidentUserRepository.Add(incidentUser);
            uow.Commit();
            incidentUserEntity.IncidentUserId = incidentUser.IncidentUserId;
            return incidentUser.IncidentUserId;

        }

        public int InsertUser(IncidentUserEntity incidentUserEntity)
        {
            //Insert into User
            User user = new User();
            user.ForceEmployeeId = !string.IsNullOrWhiteSpace(incidentUserEntity.ForceUserId) ? incidentUserEntity.ForceUserId : incidentUserEntity.ForceEmployeeId;
            user.UserDetailId = incidentUserEntity.UserDetailId;
            user.UserTypeId = incidentUserEntity.UserTypeId;
            user.Active = true;
            uow.UserRepository.Add(user);
            uow.Commit();
            return user.UserId;

        }
        public void InsertUserAddress(IncidentUserEntity incidentUserEntity)
        {
            //Insert into User
            UserAddres userAddress = new UserAddres();
            userAddress.AddressId = incidentUserEntity.AddressId;
            userAddress.UserId = incidentUserEntity.UserId;
            uow.UserAddressRepository.Add(userAddress);
            uow.Commit();
        }

        private void InsertUserContact(IncidentUserEntity incidentUserEntity)
        {
            Contact contact = new Contact();
            int contactId = 0;
            UserContact userContact = new UserContact();
            if (!string.IsNullOrWhiteSpace(incidentUserEntity.PrimaryPhone))
            {
             
                contact.Number = incidentUserEntity.PrimaryPhone;
                contact.ContactTypeId = (int)UOF.Common.Utilities.Constants.ContactTypes.Phone1;
                uow.ContactRepository.Add(contact);
                uow.Commit();
                contactId = contact.ContactId;

                //User Contact Insert
                userContact.ContactId = contactId;
                userContact.UserId = incidentUserEntity.UserId;
                uow.UserContactRepository.Add(userContact);
                uow.Commit();
            }

            if (!string.IsNullOrWhiteSpace(incidentUserEntity.SecondaryPhone))
            {
                contact = new Contact();
                contact.Number = incidentUserEntity.SecondaryPhone;
                contact.ContactTypeId = (int)UOF.Common.Utilities.Constants.ContactTypes.Phone2;
                uow.ContactRepository.Add(contact);
                uow.Commit();
                contactId = contact.ContactId;

                //User Contact Insert
                userContact = new UserContact();
                userContact.ContactId = contactId;
                userContact.UserId = incidentUserEntity.UserId;
                uow.UserContactRepository.Add(userContact);
                uow.Commit();
            }
        }

        public int InsertUserDetail(IncidentUserEntity incidentUserEntity)
        {
            //No address for the below user types
            if (incidentUserEntity.UserTypeId == (int)Constants.UserType.NonEmpWitness || incidentUserEntity.UserTypeId == (int)Constants.UserType.Suspect)
            {
                // Insert into Address
                Addres address = new Addres();
                address.AddressId = incidentUserEntity.AddressId;
                address.AddressTypeId = (int)Constants.AddressType.User;
                address.City = incidentUserEntity.City;
                address.State = incidentUserEntity.State;
                address.StationFacility = incidentUserEntity.StationFacility;
                address.ZipCode = incidentUserEntity.ZipCode;
                address.Street = incidentUserEntity.Street;
                uow.AddressRepository.Add(address);
                uow.Commit();
                incidentUserEntity.AddressId = address.AddressId;
            }
            // Insert into User Detail
            UserDetail userDetail = new UserDetail();
            userDetail.FirstName = incidentUserEntity.FirstName;
            userDetail.MiddleName = incidentUserEntity.MiddleName;
            userDetail.LastName = incidentUserEntity.LastName;
            userDetail.Rank = incidentUserEntity.Rank;
            userDetail.Sex = incidentUserEntity.Sex;
            userDetail.Race = incidentUserEntity.Race;
            userDetail.Dress = incidentUserEntity.Dress;
            userDetail.Height = incidentUserEntity.Height;
            userDetail.Weight = incidentUserEntity.Weight;
            userDetail.Age = incidentUserEntity.Age;
            userDetail.ShiftId = incidentUserEntity.Shift;
            userDetail.UnitOfAssignment = incidentUserEntity.UnitOfAssignment;
            userDetail.WorkAssignment = incidentUserEntity.WorkAssignment;
            userDetail.DateOfBirth = incidentUserEntity.DateOfBirth;
            uow.UserDetailRepository.Add(userDetail);
            uow.Commit();
            return userDetail.UserDetailId;
        }

        public bool SaveIncidentUser(IncidentUserEntity incidentUserEntity)
        {
            bool result = false;
            try
            {
                using (var transaction = new TransactionScope())
                {
                    // Insert into Address and UserDetails
                    int userDetailId = InsertUserDetail(incidentUserEntity);

                    //Insert into Users
                    incidentUserEntity.UserDetailId = userDetailId;
                    int userId = InsertUser(incidentUserEntity);

                    //Insert into IncidentUser
                    incidentUserEntity.UserId = userId;
                    InsertIncidentUser(incidentUserEntity);

                    if (incidentUserEntity.UserTypeId == (int)Constants.UserType.NonEmpWitness || incidentUserEntity.UserTypeId == (int)Constants.UserType.Suspect)
                    {
                        //Insert into UserAddress
                        incidentUserEntity.AddressId = incidentUserEntity.AddressId;
                        incidentUserEntity.UserId = userId;
                        InsertUserAddress(incidentUserEntity);
                    }
                    if (incidentUserEntity.UserTypeId == (int)Constants.UserType.NonEmpWitness)
                    {
                        InsertUserContact(incidentUserEntity);
                    }

                    transaction.Complete();
                    result = true;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return result;
        }

        public List<IncidentUserEntity> Get()
        {
            var incidentUserList = (from incidentUser in uow.IncidentUserRepository.GetAll()
                                    join incident in GetIncident() on incidentUser.IncidentId equals incident.IncidentId
                                    join user in uow.UserRepository.GetAll() on incidentUser.UserId equals user.UserId
                                    join userDeatail in uow.UserDetailRepository.GetAll() on user.UserDetailId equals userDeatail.UserDetailId
                                    select new IncidentUserEntity
                                    {
                                        IncidentUserId = incidentUser.IncidentUserId,
                                    }).ToList();

            return incidentUserList;
        }

        public IncidentUserEntity Get(int incidentId)
        {
            IncidentUserEntity incidentUserEntity = (from incidentUser in uow.IncidentUserRepository.GetAll()
                                                     join incident in GetIncident() on incidentUser.IncidentId equals incident.IncidentId
                                                     join user in uow.UserRepository.GetAll() on incidentUser.UserId equals user.UserId
                                                     join userDeatail in uow.UserDetailRepository.GetAll() on user.UserDetailId equals userDeatail.UserDetailId
                                                     where incident.IncidentId == incidentId
                                                     select new IncidentUserEntity
                                                     {
                                                         IncidentId = incidentId,
                                                         UserId = user.UserId,
                                                         UserTypeId=user.UserTypeId,
                                                         FirstName = userDeatail.LastName + ' ' + userDeatail.FirstName
                                                     }).FirstOrDefault();

            return incidentUserEntity;
        }
    }
}
