﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.Common.Utilities;
using UOF.DataAccess.Repository;

namespace UOF.DataAccess.DbRepository
{
    public class AlertRepository
    {
        UnitOfWork uow = new UnitOfWork();
        FormReviewRespository repo = new FormReviewRespository();
        public bool SaveIncidentAlert(IncidentAlertModel model)
        {
            bool result = false;
            model.UserRoleId = repo.GetUserRoleID(model.LoggedRole);
            try
            {
                var Model = new OperationsForceReview();
                var entity = uow.UOFIncidentFormDataRepository.FindBy(a => a.UserRoleId == model.UserRoleId && a.FormID == model.FormId && a.IncidentID == model.IncidentId && a.EmpID == model.LoggedId).FirstOrDefault();
                if (entity != null)
                {
                    entity.IncidentID = model.IncidentId;
                    entity.UpdateBy = model.LoggedId;
                    entity.UpdateOn = DateTime.Now;
                    entity.XmlData = model.Serialize();
                    uow.UOFIncidentFormDataRepository.Update(entity);
                }
                else
                {
                    var dbEntity = new IncidentFormData();
                    dbEntity.IncidentID = model.IncidentId;
                    dbEntity.EmpID = model.LoggedId;
                    dbEntity.CreatedOn = DateTime.Now;
                    dbEntity.CreatedBy = model.LoggedId;
                    dbEntity.FormID = model.FormId;
                    dbEntity.UserRoleId = model.UserRoleId;
                    dbEntity.XmlData = model.Serialize();
                    dbEntity.Status = Constants.Status.DON.ToString();
                    uow.UOFIncidentFormDataRepository.Add(dbEntity);
                }
              
                uow.Commit();

                result = true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return result;
        }

        public IncidentAlertModel GetIncidentAlerDetails(int FormId, int IncidentId, string EmpId)
        {
            try
            {
                var data = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.FormID == FormId && x.EmpID == EmpId && x.IncidentID == IncidentId).FirstOrDefault();
                var result = data != null ? data.XmlData.Deserialize<IncidentAlertModel>() : null;
                if (result != null)
                {
                    using (ReturnCommentsRepository obj = new ReturnCommentsRepository())
                    {
                        result.RejectComments = obj.getReturnComments(new ReturnCommentModel { IncidentId = IncidentId, FormId = FormId, FormSubmitedId = EmpId });
                    }
                }
                return result;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        public bool SaveMCJAlert(MCJAlertModel model)
        {
            bool result = false;
            model.UserRoleId = repo.GetUserRoleID(model.LoggedRole);
            try
            {
                var Model = new OperationsForceReview();
                var entity = uow.UOFIncidentFormDataRepository.FindBy(a => a.UserRoleId == model.UserRoleId && a.FormID == model.FormId && a.IncidentID == model.IncidentId && a.EmpID == model.LoggedId).FirstOrDefault();
                if (entity != null)
                {
                    entity.IncidentID = model.IncidentId;
                    entity.UpdateBy = model.LoggedId;
                    entity.UpdateOn = DateTime.Now;
                    entity.XmlData = model.Serialize();
                    uow.UOFIncidentFormDataRepository.Update(entity);
                }
                else
                {
                    var dbEntity = new IncidentFormData();
                    dbEntity.IncidentID = model.IncidentId;
                    dbEntity.EmpID = model.LoggedId;
                    dbEntity.CreatedOn = DateTime.Now;
                    dbEntity.CreatedBy = model.LoggedId;
                    dbEntity.FormID = model.FormId;
                    dbEntity.UserRoleId = model.UserRoleId;
                    dbEntity.XmlData = model.Serialize();
                    dbEntity.Status = Constants.Status.DON.ToString();
                    uow.UOFIncidentFormDataRepository.Add(dbEntity);
                }

                uow.Commit();

                result = true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return result;
        }

        public MCJAlertModel GetMCJAlertDetails(int FormId, int IncidentId, string EmpId)
        {
            try
            {
                var data = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.FormID == FormId && x.EmpID == EmpId && x.IncidentID == IncidentId).FirstOrDefault();
                var result = data != null ? data.XmlData.Deserialize<MCJAlertModel>() : null;
                if (result != null)
                {
                    using (ReturnCommentsRepository obj = new ReturnCommentsRepository())
                    {
                        result.RejectComments = obj.getReturnComments(new ReturnCommentModel { IncidentId = IncidentId, FormId = FormId, FormSubmitedId = EmpId });
                    }
                }
                return result;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
    }
}
