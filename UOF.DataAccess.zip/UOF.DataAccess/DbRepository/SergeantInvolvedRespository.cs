﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.DataAccess.Repository;

namespace UOF.DataAccess.DbRepository
{
    public class SergeantInvolvedRespository
    {
        UnitOfWork uow = new UnitOfWork();
        public void MapSergeantInvolved(SergeantInvolvedModel model)
        {
            try
            {
                var entity = new SergeantInvolvedEmployee();
                entity.IncidentId = model.IncidentId;
                entity.InvolvedEmplId = model.InvolvedEmplId;
                entity.SergeantId = model.SergeantId;
                entity.Createdby = model.Createdby;
                entity.CreatedOn = DateTime.Now;
                uow.SergeantInvolvedRepository.Add(entity);
                uow.Commit();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
