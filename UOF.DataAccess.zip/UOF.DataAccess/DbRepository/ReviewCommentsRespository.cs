﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using UOF.Common.EntityModel;
using UOF.Common.Utilities;
using UOF.DataAccess.Repository;

namespace UOF.DataAccess.DbRepository
{
    public class ReviewCommentsRespository
    {
        UnitOfWork uow = new UnitOfWork();
        public bool SaveReviewComments(ReviewCommentModel entity)
        {
            using (var transaction = new TransactionScope())
            {
                //// Insert into Address
                ReviewComment RC = new ReviewComment();
                RC.FormId = entity.FormId;
                RC.IncidentId = entity.IncidentId;
                RC.CommentedBy = entity.CommentedBy;
                if (!string.IsNullOrWhiteSpace(entity.SubmitedId))
                    RC.AddressedBy = entity.SubmitedId;
                RC.ReviewComments = entity.ReviewComments;
                RC.CreatedOn = DateTime.Now;
                RC.Status = Constants.Status.PND.ToString();
                uow.ReviewCommentsRespository.Add(RC);
                uow.Commit();

                string reviwerRole = string.Empty;
                //Update Workflow
                //Based on the Form id Checking  the Review  role to update the status(review status, Submitted status and incidnet status) in the review form
                var reviewModel = uow.ReviewRespository.FindBy(a => a.InvolvedId == entity.SubmitedId && a.FormId == entity.FormId && a.IncidentID == entity.IncidentId).FirstOrDefault();
                if (reviewModel != null)
                {
                    if (reviewModel.SergeantId == RC.CommentedBy)
                    {
                        reviwerRole = Constants.UserRoles.SGT.ToString();
                        reviewModel.InvolvedStatus = Constants.Status.Return.ToString();
                        reviewModel.SergeantStatus = Constants.Status.NotReady.ToString();
                        using (UoFWorkFlowRepository wf = new UoFWorkFlowRepository())
                        {
                            wf.InsertUpdateWorkFlow(new WorkFlowEntity { IncidentId = RC.IncidentId, SergeantStatus = Constants.IncidentStatus.AtDeputy.ToString()});
                            wf.updateIncident(RC.IncidentId, Convert.ToString((int)Constants.IncidentStatus.AtDeputy));
                        }
                    }
                    else if (reviewModel.WCID == RC.CommentedBy)
                    {
                        reviwerRole = Constants.UserRoles.WC.ToString();
                        reviewModel.SergeantStatus = Constants.Status.Return.ToString();
                        reviewModel.WCStatus = Constants.Status.NotReady.ToString();
                        using (UoFWorkFlowRepository wf = new UoFWorkFlowRepository())
                        {
                            wf.InsertUpdateWorkFlow(new WorkFlowEntity { IncidentId = RC.IncidentId, SergeantStatus = Constants.IncidentStatus.AtSergeant.ToString() });
                            wf.updateIncident(RC.IncidentId, Convert.ToString((int)Constants.IncidentStatus.AtSergeant));
                        }
                    }
                    else if (reviewModel.UCID == RC.CommentedBy)
                    {
                        reviwerRole = Constants.UserRoles.CAPT.ToString();
                        reviewModel.WCStatus = Constants.Status.Return.ToString();
                        reviewModel.UCStatus = Constants.Status.NotReady.ToString();
                        using (UoFWorkFlowRepository wf = new UoFWorkFlowRepository())
                        {
                            wf.InsertUpdateWorkFlow(new WorkFlowEntity { IncidentId = RC.IncidentId, SergeantStatus = Constants.IncidentStatus.AtWatchCommander.ToString() });
                            wf.updateIncident(RC.IncidentId, Convert.ToString((int)Constants.IncidentStatus.AtWatchCommander));
                        }
                    }
                    else if (reviewModel.CMID == RC.CommentedBy)
                    {
                        reviwerRole = Constants.UserRoles.CMDR.ToString();
                        reviewModel.UCStatus = Constants.Status.Return.ToString();
                        reviewModel.CMStatus = Constants.Status.NotReady.ToString();
                        using (UoFWorkFlowRepository wf = new UoFWorkFlowRepository())
                        {
                            wf.InsertUpdateWorkFlow(new WorkFlowEntity { IncidentId = RC.IncidentId, SergeantStatus = Constants.IncidentStatus.AtUnitCommander.ToString() });
                            wf.updateIncident(RC.IncidentId, Convert.ToString((int)Constants.IncidentStatus.AtUnitCommander));
                        }
                    }
                }

                
                
                transaction.Complete();
            }
            return true;
        }

    }
}
