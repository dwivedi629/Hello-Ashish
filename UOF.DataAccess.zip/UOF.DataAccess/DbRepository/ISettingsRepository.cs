﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UOF.Common.EntityModel;

namespace UOF.DataAccess.DbRepository
{
    public interface ISettingsRepository
    {
        List<UserRoleSettingsEntity> GetRoles();

        List<FormsNameSettings> GetFormsName();

        List<FormPermissionSettings> GetFormPermission();

        bool GetFormPermission(string formCode, string  roleCode);

        bool SaveFormPermissions(List<FormPermisssion> objfrmPermission);

        bool SaveRole(UserRoleSettingsEntity roleEntity);

        List<IncidentStatusDetail> GetIncidentFormData(string URN);

        List<IncidentStatusDetail> GetPackageInfo(string URN);

        bool ChangeOwnerShip(ChangeOwnerModel model);
    }
}
