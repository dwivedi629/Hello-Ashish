﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using UOF.Common.EntityModel;
using UOF.DataAccess.Repository;

namespace UOF.DataAccess.DbRepository
{
    public class IncidentStatisticalRespository
    {
        UnitOfWork uow = new UnitOfWork();



        public void SaveStatistical(List<StatisticalEntity> statisticalEntity)
        {
            try
            {
                int incidentId = statisticalEntity[0].IncidentId;
                var existingEntity = uow.IncidentStatisticalRepository.GetAll().Where(x => x.IncidentId == incidentId).ToList();
                foreach (var item in existingEntity)
                {
                    uow.IncidentStatisticalRepository.Delete(item);
                    uow.Commit();
                }
                foreach (StatisticalEntity item in statisticalEntity)
                {
                    Insert(item);
                }
            }
            
            catch (Exception ex)
            {

                throw ex;
            }
        }


        private void Insert(StatisticalEntity statisticalEntity)
        {
            // Insert into IncidentStatisticalData
            try
            {
                using (var transaction = new TransactionScope())
                {
                    IncidentStatisticalData incidentStatistical = new IncidentStatisticalData();
                    incidentStatistical.IncidentId = statisticalEntity.IncidentId;
                    incidentStatistical.IncidentUsedBy = statisticalEntity.ForcedUsedById;
                    incidentStatistical.IncidentAgainstBy = statisticalEntity.ForcedUsedAgainstId;
                    incidentStatistical.Method = statisticalEntity.MethodCode;
                    incidentStatistical.InjuryType = statisticalEntity.InjuryTypeCode;
                    incidentStatistical.BodyPartInvolved = statisticalEntity.BodyPartInvolvedCode;
                    incidentStatistical.CreatedBy = statisticalEntity.LoggedId;
                    incidentStatistical.CreatedOn = DateTime.Now;
                    uow.IncidentStatisticalRepository.Add(incidentStatistical);
                    uow.Commit();
                    transaction.Complete();
                }
            }

            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
