﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.DataAccess.Repository;

namespace UOF.DataAccess.DbRepository
{
    public class ArtifactsRepository
    {
        UnitOfWork unitOfWork = new UnitOfWork();

        /// <summary>
        /// Get artifacts data based on incident id
        /// </summary>
        /// <param name="incidentId">incident id</param>
        /// <returns>true or false</returns>
        public List<ArtifactEntity> GetIncidentArtifacts(int incidentId)
        {
            List<ArtifactEntity> listArtifacts = new List<ArtifactEntity>();
            try
            {
                var getAllArtifacts = unitOfWork.ArtifactsInformationRepository.GetAll().Where(a => a.IncidentId == incidentId);
                if (getAllArtifacts.Any())
                {
                    foreach (var item in getAllArtifacts)
                    {
                        var artifactEntity = new ArtifactEntity
                        {
                            FileName = item.FileName,
                            ArtifactId = item.ArtifactId,
                            IncidentId = item.IncidentId,
                            UploadedDate = item.UplodedDate,
                        };

                        listArtifacts.Add(artifactEntity);
                    }
                }

                return listArtifacts;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Save artifacts data based on incident id
        /// </summary>
        /// <param name="artifactEntity">entity of artifacts</param>
        /// <returns>true or false</returns>
        public bool SaveIncidentArtifacts(ArtifactEntity artifactEntity)
        {
            var fileFound = unitOfWork.ArtifactsInformationRepository.GetAll().Where(a => a.FileName == artifactEntity.FileName && a.IncidentId == artifactEntity.IncidentId);

            if (!fileFound.Any())
            {
                ArtifactsInformation artInfo = new ArtifactsInformation
                {
                    FileName = artifactEntity.FileName,
                    IncidentId = artifactEntity.IncidentId,
                    UplodedDate = artifactEntity.UploadedDate
                };

                unitOfWork.ArtifactsInformationRepository.Add(artInfo);
                unitOfWork.Commit();
            }

            return true;
        }

        /// <summary>
        /// Delete the file
        /// </summary>
        /// <param name="artifactId"></param>
        /// <param name="incidentId"></param>
        /// <returns>true or false</returns>
        public bool DeleteIncidentArtifacts(int artifactId, int incidentId)
        {
            ArtifactsInformation info = new ArtifactsInformation
            {
                ArtifactId = artifactId,
                IncidentId = incidentId
            };
            unitOfWork.ArtifactsInformationRepository.Delete(info);
            unitOfWork.Commit();
            return true;
        }
    }
}
