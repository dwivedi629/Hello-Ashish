﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.Common.Utilities;
using UOF.DataAccess.Repository;

namespace UOF.DataAccess.DbRepository
{
    public class FormReviewRespository
    {
        UnitOfWork uow = new UnitOfWork();

        public bool InsertUpdateReviewForm(IncidentFormReviewEntity model)
        {
            bool result = false;
            try
            {
                var sup = new IncidentFormReviewEntity();
                //&& x.SubmitteduserRole == model.SubmitteduserRole
                //var dbModel = uow.ReviewRespository.GetById(model.IncidentID); //TODO going forword we need to use this to get uniqe record////FindBy(a=>a.UserRoleId==inmateInjuryBusinessModel.UserRoleId && a.FormID==inmateInjuryBusinessModel.FormID).FirstOrDefault() ;


                if (string.IsNullOrWhiteSpace(model.SubmitteduserRole))
                {
                    //Gettign the submited Roles based on the Submited ID
                    if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == model.IncidentID && x.FormId == model.FormId && x.InvolvedId == model.SubmittedEmpId && x.IncidentReviewID == model.IncidentReviewID).Any())
                    {
                        model.SubmitteduserRole = (from ind in uow.ReviewRespository.GetAll()
                                                   where ind.IncidentID == model.IncidentID && ind.FormId == model.FormId && ind.InvolvedId == model.SubmittedEmpId && ind.IncidentReviewID == model.IncidentReviewID
                                                   select new { ind.InvolvedRole }).Single().InvolvedRole;
                    }
                    if (model.loggedInRank == 1)
                        model.SubmitteduserRole = Constants.UserRoles.DSG.ToString();
                    else if (model.loggedInRank == 2)
                        model.SubmitteduserRole = Constants.UserRoles.SGT.ToString();
                    else
                    {
                        model.SubmitteduserRole = "";

                    }
                }

                



                //var dbModel = uow.ReviewRespository.GetAll().Where(x => x.FormId == model.FormId && x.InvolvedId == model.SubmittedEmpId && x.InvolvedRole == model.SubmitteduserRole && x.IncidentID == model.IncidentID && x.IncidentReviewID == model.IncidentReviewID).FirstOrDefault();
                //Temp Fix
                if (string.IsNullOrWhiteSpace(model.SergeantStatus) && string.IsNullOrWhiteSpace(model.ReviewerRole))
                    model.isTempSave = true;

                var dbModel = uow.ReviewRespository.GetAll().Where(x => x.IncidentReviewID == model.IncidentReviewID).FirstOrDefault();
                if (dbModel != null)
                {
                    if (!model.isAssignForms)//Need to pass this flag as true, when assignform is save.
                    {
                        if (string.IsNullOrWhiteSpace(model.SergeantId) || model.SergeantId == "0")
                        {
                            //model.SergeantId = (from ind in uow.IncidentRepository.GetAll()
                            //                    where ind.IncidentId == model.IncidentID
                            //                    select new { ind.SergeantId }).Single().SergeantId;

                            //var ser = (from ind in uow.IncidentRepository.GetAll()
                            //           where ind.IncidentId == model.IncidentID
                            //           select ind).FirstOrDefault();
                           // if (ser != null && ser.SergeantId != "0")
                           
                                //model.SergeantId = ser.SergeantId;
                        }

                        var usr = (from incidentUser in uow.IncidentUserRepository.GetAll()
                                   join user in uow.UserRepository.GetAll() on incidentUser.UserId equals user.UserId
                                   where incidentUser.IncidentId == model.IncidentID && user.UserTypeId == (int)Constants.UserType.WatchCommander
                                   select user).FirstOrDefault();
                        //if (usr != null)
                            //model.WCID = usr.ForceEmployeeId;

                        //New Implementation Getting Forms Review Rank and Assiging.
                        if (!model.isApproveOrReject && !model.isTempSave) // Should not consider while form is approve or rejected
                        {
                            FormReviewRank rankResult = (from review in uow.FormReviewRankRespository.GetAll() where review.FormId == model.FormId && review.Active == true select review).FirstOrDefault();
                            if (rankResult != null)
                            {
                                model.ReviewerRole = (from ind in uow.UserRoleRepository.GetAll() where ind.Rank == rankResult.ReviewRank select new { ind.RoleCode }).Single().RoleCode;
                                if (model.ReviewerRole == Constants.UserRoles.SGT.ToString())
                                {
                                    model.SergeantStatus = Constants.Status.Pending.ToString();
                                    model.SubmittedStatus = Constants.Status.Completed.ToString();
                                }
                                if (model.ReviewerRole == Constants.UserRoles.WC.ToString())
                                {
                                    model.SergeantStatus = Constants.Status.Completed.ToString();
                                    model.WCStatus = Constants.Status.Pending.ToString();
                                    model.SubmittedStatus = Constants.Status.Completed.ToString();
                                }
                                if (model.ReviewerRole == Constants.UserRoles.CAPT.ToString())
                                {
                                    model.UCStatus = Constants.Status.Pending.ToString();
                                    model.WCStatus = Constants.Status.Completed.ToString();
                                    model.SubmittedStatus = Constants.Status.Completed.ToString();


                                }
                                if (model.ReviewerRole == Constants.UserRoles.CMDR.ToString())
                                {
                                    model.CMStatus = Constants.Status.Pending.ToString();
                                    model.UCStatus = Constants.Status.Completed.ToString();
                                    model.SubmittedStatus = Constants.Status.Completed.ToString();
                                }
                            }
                        }


                        if (!string.IsNullOrWhiteSpace(model.ReviewerRole))
                            dbModel.ReviewerRole = model.ReviewerRole;
                        if (!string.IsNullOrWhiteSpace(model.SergeantId))
                            dbModel.SergeantId = model.SergeantId;

                        if (!string.IsNullOrWhiteSpace(model.WCID))
                            dbModel.WCID = model.WCID;
                        if (!string.IsNullOrWhiteSpace(model.UCID))
                            dbModel.UCID = model.UCID;
                        if (!string.IsNullOrWhiteSpace(model.CMID))
                            dbModel.CMID = model.CMID;
                        if (!string.IsNullOrWhiteSpace(model.CFRTID))
                            dbModel.CFRTID = model.CFRTID;
                        if (!string.IsNullOrWhiteSpace(model.CFRCID))
                            dbModel.CFRCID = model.CFRCID;
                        if (!string.IsNullOrWhiteSpace(model.SergeantStatus))
                            dbModel.SergeantStatus = model.SergeantStatus;
                        if (!string.IsNullOrWhiteSpace(model.WCStatus))
                            dbModel.WCStatus = model.WCStatus;
                        if (!string.IsNullOrWhiteSpace(model.UCStatus))
                            dbModel.UCStatus = model.UCStatus;
                        if (!string.IsNullOrWhiteSpace(model.CMStatus))
                            dbModel.CMStatus = model.CMStatus;
                        if (!string.IsNullOrWhiteSpace(model.CFRTStatus))
                            dbModel.CFRTStatus = model.CFRTStatus;
                        if (!string.IsNullOrWhiteSpace(model.CFRCStatus))
                            dbModel.CFRCStatus = model.CFRCStatus;
                        if (!string.IsNullOrWhiteSpace(model.SubmittedStatus))
                            dbModel.InvolvedStatus = model.SubmittedStatus;
                        if (model.FormDataId > 0)
                            dbModel.FormDataID = model.FormDataId;
                        uow.ReviewRespository.Update(dbModel);
                    }
                }
                else
                {
                    //var usr = (from incidentUser in uow.IncidentUserRepository.GetAll()
                    //           join user in uow.UserRepository.GetAll() on incidentUser.UserId equals user.UserId
                    //           where incidentUser.IncidentId == model.IncidentID && user.UserTypeId == (int)Constants.UserType.WatchCommander
                    //           select user).FirstOrDefault();
                    //if (usr != null)
                    //    model.WCID = usr.ForceEmployeeId;

                    
                    var uofReview = new IncidentFormReview();

                    uofReview.IncidentID = model.IncidentID;
                    uofReview.InvolvedId = model.SubmittedEmpId;
                    uofReview.FormId = model.FormId;
                    uofReview.InvolvedRole = model.SubmitteduserRole;
                    uofReview.ReviewerRole = model.ReviewerRole;
                    uofReview.SergeantId = model.SergeantId;
                    uofReview.WCID = model.WCID;
                    uofReview.UCID = model.UCID;
                    uofReview.CMID = model.CMID;
                    uofReview.CFRTID = model.CFRTID;
                    uofReview.CFRCID = model.CFRCID;
                    uofReview.SergeantStatus = model.SergeantStatus;
                    uofReview.WCStatus = model.WCStatus;
                    uofReview.UCStatus = model.UCStatus;
                    uofReview.CMStatus = model.CMStatus;
                    uofReview.CFRTStatus = model.CFRTStatus;
                    uofReview.CFRCStatus = model.CFRCStatus;
                    uofReview.FormDataID = model.FormDataId;
                    uofReview.InvolvedStatus = model.SubmittedStatus; ; // Deputy form status
                    uow.ReviewRespository.Add(uofReview);
                }

                uow.Commit();

                //Checking the status and updating the status of incident  ONLY IF LOGGED USER ROLE IS Deputy and Sergeant
                if (model.isApproveOrReject ) // Should not consider while form is approve or rejected
                {
                    if (model.SubmitteduserRole == Constants.UserRoles.SGT.ToString() || model.SubmitteduserRole == Constants.UserRoles.DSG.ToString())
                    {
                        UoFWorkFlowRepository wf = new UoFWorkFlowRepository();
                        wf.UpdateSergeantStatus(new ReviewEntity { IncidentId = model.IncidentID });
                    }
                }

                result = true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return result;
        }

        public int GetUserRoleID(string userrole)
        {
            switch (userrole)
            {
                case "SGT":
                    return (int)Constants.UserRoles.SGT;
                case "DSG":
                    return (int)Constants.UserRoles.DSG;
                case "WC":
                    return (int)Constants.UserRoles.WC;
                case "CAPT":
                    return (int)Constants.UserRoles.CAPT;
                case "CMDR":
                    return (int)Constants.UserRoles.CMDR;
                default:
                    break;
            }
            return (int)Constants.UserRoles.SGT;
        }

        /// <summary>
        /// check the current status of form
        /// </summary>
        /// <param name="formId"></param>
        /// <param name="incidentId"></param>
        /// <returns>string</returns>
        public string FormStatus(int formId, int incidentId, string reviewerId, string reviewerRole, int IncidentReviewId)
        {
            Constants.UserRoles uRoles;
            Enum.TryParse(reviewerRole, out uRoles);
            StringBuilder msg = new StringBuilder();
            string frmStatus = string.Empty;
            string SubmitedId = string.Empty;
            IncidentFormReview review = null;
            IQueryable<IncidentFormReview> frmReviewStatus = uow.ReviewRespository.GetAll().Where(a => a.FormId == formId && a.IncidentID == incidentId && a.IncidentReviewID == IncidentReviewId);
            string sergeantID = (from ind in uow.IncidentRepository.GetAll() where ind.IncidentId == incidentId select new { ind.SergeantId }).Single().SergeantId;
            IncidentMedicalUser MedUser = uow.IncidentMedicalRespository.GetAll().Where(a => a.FormId == formId && a.IncidentId == incidentId && a.Active == true).FirstOrDefault();
            if (frmReviewStatus.Any())
            {
                review = frmReviewStatus.FirstOrDefault();
                SubmitedId = review.InvolvedId;
                msg.AppendLine("IsFormOwner:" + (SubmitedId == reviewerId ? true : false));
                msg.AppendLine("IsIncidentOwner:" + (sergeantID == reviewerId ? true : false));

                //Locking
                FormReviewRank rankResult = (from rev in uow.FormReviewRankRespository.GetAll() where rev.FormId == formId && rev.Active == true select rev).FirstOrDefault();

                if (review.InvolvedRole == Constants.UserRoles.DSG.ToString())
                {
                    if (rankResult != null)
                    {
                        string ReviewerRole = (from ind in uow.UserRoleRepository.GetAll() where ind.Rank == rankResult.ReviewRank select new { ind.RoleCode }).Single().RoleCode;
                        switch (ReviewerRole.ToUpper())
                        {
                            case "SGT":
                                if (review.SergeantStatus == Constants.Status.Completed.ToString())
                                    msg.AppendLine("IsLock:" + true);
                                else
                                    msg.AppendLine("IsLock:" + false);
                                break;
                            case "WC":
                                if (review.WCStatus == Constants.Status.Completed.ToString())
                                    msg.AppendLine("IsLock:" + true);
                                else
                                    msg.AppendLine("IsLock:" + false);
                                break;
                            case "CAPT":
                                if (review.UCStatus == Constants.Status.Completed.ToString())
                                    msg.AppendLine("IsLock:" + true);
                                else
                                    msg.AppendLine("IsLock:" + false);
                                break;
                            case "CMDR":
                                if (review.CMStatus == Constants.Status.Completed.ToString())
                                    msg.AppendLine("IsLock:" + true);
                                else
                                    msg.AppendLine("IsLock:" + false);
                                break;
                            case "DC":
                                if (review.DCStatus == Constants.Status.Completed.ToString())
                                    msg.AppendLine("IsLock:" + true);
                                else
                                    msg.AppendLine("IsLock:" + false);
                                break;
                            default:
                                break;
                        }
                        //rankResult.ReviewRank
                    }
                }
                else if (review.InvolvedRole == Constants.UserRoles.SGT.ToString())
                {
                    if (rankResult != null)
                    {
                        string ReviewerRole = (from ind in uow.UserRoleRepository.GetAll() where ind.Rank == rankResult.ReviewRank select new { ind.RoleCode }).Single().RoleCode;
                        switch (ReviewerRole.ToUpper())
                        {
                            case "SGT":
                                if (review.SergeantStatus == Constants.Status.Completed.ToString())
                                    msg.AppendLine("IsLock:" + true);
                                else
                                    msg.AppendLine("IsLock:" + false);
                                break;
                            case "WC":
                                if (review.WCStatus == Constants.Status.Completed.ToString())
                                    msg.AppendLine("IsLock:" + true);
                                else
                                    msg.AppendLine("IsLock:" + false);
                                break;
                            case "CAPT":
                                if (review.UCStatus == Constants.Status.Completed.ToString())
                                    msg.AppendLine("IsLock:" + true);
                                else
                                    msg.AppendLine("IsLock:" + false);
                                break;
                            case "CMDR":
                                if (review.CMStatus == Constants.Status.Completed.ToString())
                                    msg.AppendLine("IsLock:" + true);
                                else
                                    msg.AppendLine("IsLock:" + false);
                                break;
                            case "DC":
                                if (review.DCStatus == Constants.Status.Completed.ToString())
                                    msg.AppendLine("IsLock:" + true);
                                else
                                    msg.AppendLine("IsLock:" + false);
                                break;
                            default:
                                break;
                        }
                        //rankResult.ReviewRank
                    }
                }
                else if (review.InvolvedRole == Constants.UserRoles.WC.ToString())
                {
                    if (rankResult != null)
                    {
                        string ReviewerRole = (from ind in uow.UserRoleRepository.GetAll() where ind.Rank == rankResult.ReviewRank select new { ind.RoleCode }).Single().RoleCode;
                        switch (ReviewerRole.ToUpper())
                        {
                            case "SGT":
                                if (review.SergeantStatus == Constants.Status.Completed.ToString())
                                    msg.AppendLine("IsLock:" + true);
                                else
                                    msg.AppendLine("IsLock:" + false);
                                break;
                            case "WC":
                                if (review.WCStatus == Constants.Status.Completed.ToString())
                                    msg.AppendLine("IsLock:" + true);
                                else
                                    msg.AppendLine("IsLock:" + false);
                                break;
                            case "CAPT":
                                if (review.UCStatus == Constants.Status.Completed.ToString())
                                    msg.AppendLine("IsLock:" + true);
                                else
                                    msg.AppendLine("IsLock:" + false);
                                break;
                            case "CMDR":
                                if (review.CMStatus == Constants.Status.Completed.ToString())
                                    msg.AppendLine("IsLock:" + true);
                                else
                                    msg.AppendLine("IsLock:" + false);
                                break;
                            case "DC":
                                if (review.DCStatus == Constants.Status.Completed.ToString())
                                    msg.AppendLine("IsLock:" + true);
                                else
                                    msg.AppendLine("IsLock:" + false);
                                break;
                            default:
                                break;
                        }
                        //rankResult.ReviewRank
                    }
                }
                else if (review.InvolvedRole == Constants.UserRoles.CAPT.ToString())
                {
                    if (rankResult != null)
                    {
                        string ReviewerRole = (from ind in uow.UserRoleRepository.GetAll() where ind.Rank == rankResult.ReviewRank select new { ind.RoleCode }).Single().RoleCode;
                        switch (ReviewerRole.ToUpper())
                        {
                            case "SGT":
                                if (review.SergeantStatus == Constants.Status.Completed.ToString())
                                    msg.AppendLine("IsLock:" + true);
                                else
                                    msg.AppendLine("IsLock:" + false);
                                break;
                            case "WC":
                                if (review.WCStatus == Constants.Status.Completed.ToString())
                                    msg.AppendLine("IsLock:" + true);
                                else
                                    msg.AppendLine("IsLock:" + false);
                                break;
                            case "CAPT":
                                if (review.UCStatus == Constants.Status.Completed.ToString())
                                    msg.AppendLine("IsLock:" + true);
                                else
                                    msg.AppendLine("IsLock:" + false);
                                break;
                            case "CMDR":
                                if (review.CMStatus == Constants.Status.Completed.ToString())
                                    msg.AppendLine("IsLock:" + true);
                                else
                                    msg.AppendLine("IsLock:" + false);
                                break;
                            case "DC":
                                if (review.DCStatus == Constants.Status.Completed.ToString())
                                    msg.AppendLine("IsLock:" + true);
                                else
                                    msg.AppendLine("IsLock:" + false);
                                break;
                            default:
                                break;
                        }
                        //rankResult.ReviewRank
                    }
                }
                else if (review.InvolvedRole == Constants.UserRoles.CMDR.ToString())
                {
                    if (rankResult != null)
                    {
                        string ReviewerRole = (from ind in uow.UserRoleRepository.GetAll() where ind.Rank == rankResult.ReviewRank select new { ind.RoleCode }).Single().RoleCode;
                        switch (ReviewerRole.ToUpper())
                        {
                            case "SGT":
                                if (review.SergeantStatus == Constants.Status.Completed.ToString())
                                    msg.AppendLine("IsLock:" + true);
                                else
                                    msg.AppendLine("IsLock:" + false);
                                break;
                            case "WC":
                                if (review.WCStatus == Constants.Status.Completed.ToString())
                                    msg.AppendLine("IsLock:" + true);
                                else
                                    msg.AppendLine("IsLock:" + false);
                                break;
                            case "CAPT":
                                if (review.UCStatus == Constants.Status.Completed.ToString())
                                    msg.AppendLine("IsLock:" + true);
                                else
                                    msg.AppendLine("IsLock:" + false);
                                break;
                            case "CMDR":
                                if (review.CMStatus == Constants.Status.Completed.ToString())
                                    msg.AppendLine("IsLock:" + true);
                                else
                                    msg.AppendLine("IsLock:" + false);
                                break;
                            case "DC":
                                if (review.DCStatus == Constants.Status.Completed.ToString())
                                    msg.AppendLine("IsLock:" + true);
                                else
                                    msg.AppendLine("IsLock:" + false);
                                break;
                            default:
                                break;
                        }
                        //rankResult.ReviewRank
                    }
                }
                switch (uRoles)
                {
                    case Constants.UserRoles.SGT:
                        //if (review.SergeantId == reviewerId)
                        frmStatus = review.SergeantStatus.ToUpper();

                        msg.Append("ReviewerStatus:" + frmStatus);
                        break;
                    case Constants.UserRoles.DSG:
                        //if (review.InvolvedId == reviewerId)
                        frmStatus = review.InvolvedStatus.ToUpper();
                        msg.Append("ReviewerStatus:" + frmStatus);
                        break;
                    case Constants.UserRoles.MS:
                        break;
                    case Constants.UserRoles.WC:
                        review.WCStatus = review.WCStatus == null ? Constants.Status.Pending.ToString() : review.WCStatus;
                        frmStatus = review.WCStatus.ToUpper();
                        msg.Append("ReviewerStatus:" + frmStatus);
                        break;
                    case Constants.UserRoles.CAPT:
                        review.UCStatus = review.UCStatus == null ? Constants.Status.Pending.ToString() : review.UCStatus;
                        frmStatus = review.UCStatus.ToUpper();
                        msg.Append("ReviewerStatus:" + frmStatus);
                        break;
                    case Constants.UserRoles.CMDR:
                        review.CMStatus = review.CMStatus == null ? Constants.Status.Pending.ToString() : review.CMStatus;
                        frmStatus = review.CMStatus.ToUpper();
                        msg.Append("ReviewerStatus:" + frmStatus);
                        break;
                    case Constants.UserRoles.CA:
                        break;
                    case Constants.UserRoles.DC:
                        break;
                    case Constants.UserRoles.MED:
                        string MUStatus = MedUser == null ? Constants.Status.Pending.ToString() : Constants.Status.Completed.ToString();
                        frmStatus = MUStatus.ToUpper();
                        msg.Append("ReviewerStatus:" + frmStatus);
                        break;
                    default:
                        break;
                }
            }
            else
            {
                msg.AppendLine("IsLock:" + false);
                msg.Append("ReviewerStatus:Pending");
            }
            return msg.ToString();
        }
        public List<LookupEntity> GetReportedForms(int incidentId, string reportedId)
        {
            using (UnitOfWork unitofWork = new UnitOfWork())
            {
                return (from s in unitofWork.UofFormRepository.GetAll()
                        join f in unitofWork.UOFIncidentFormDataRepository.GetAll() on s.FormId equals f.FormID
                        where f.IncidentID == incidentId && f.EmpID == reportedId && f.Status == "DON"
                        select new LookupEntity
                        {
                            ID = s.FormId,
                            Name = s.FormName
                        }).ToList();
            }
        }
    }
}
