﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using UOF.Common.EntityModel;
//using UOF.DataAccess.DataModel;
using UOF.DataAccess.Repository;
using UOF.Common.Utilities;

namespace UOF.DataAccess.DbRepository
{
    public class QuestionnaireRepository
    {
        UnitOfWork uow = new UnitOfWork();
        #region Dont Delete the code as this cod eis for questionnare part demo " Ashish"

        //QuestionnaireTab quest = new QuestionnaireTab();
        string xmlText = string.Empty;
        public QuestionSet GetQuestionnaire(string strXML)
        {
           QuestionSet questnnare=new QuestionSet ();
            //var test = uow.QuestionnaireTabRepository.GetById(id);
            //t = test.QuestionnareXML.Deserialize<Test>();
           //quest.QuestionnareXML = strXML; //"<?xml version=\"1.0\" encoding=\"utf-16\"?><QuestionSet xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><lstQuestionModel><QuestionnareModel><ID>chk1</ID><Type>checkbox</Type><Answer>True</Answer></QuestionnareModel><QuestionnareModel><ID>ChkText</ID><Type>text</Type><Answer>test</Answer></QuestionnareModel><QuestionnareModel><ID>ReportingEmp</ID><Type>text</Type><Answer>k;lk;lk</Answer></QuestionnareModel><QuestionnareModel><ID>Radio2</ID><Type>radio</Type><Answer>Radio2</Answer></QuestionnareModel></lstQuestionModel></QuestionSet>";
           //questnnare = quest.QuestionnareXML.Deserialize<QuestionSet>();
           return questnnare;
        }

        public bool SaveQuestionnaire(List<QuestionnareModel> model, ref string strXML)
        {
            bool result = false;
            try
            {
                using (var transaction = new TransactionScope())
                {
                    QuestionSet testQuestion = new QuestionSet();
                    testQuestion.lstQuestionModel = model;
                    strXML = testQuestion.Serialize();
                    //quest.CreatedBy = "";
                    //quest.CreatedOn = DateTime.Now.ToString();
                    //quest.QuestionnareXML = testQuestion.Serialize();
                    //xmlText = testQuestion.Serialize();
                    //quest.IncidentUserID = 3;
                    //quest.UpdatedBy = "";
                    //quest.UpdatedOn = DateTime.Now.ToString();
                    //uow.QuestionnaireTabRepository.Add(quest);
                    //uow.Commit();
                    //transaction.Complete();
                    result = true;
                    
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return result;
          
        }
    }

    public class Questionnares
    {
        
        //public string Questions { get; set; }
        //public string Answesr { get; set; }
        //public string Note1 { get; set; }
        //public string Note2 { get; set; }

        //public static List<Questionnares> fill()
        //{
        //    List<Questionnares> quest = new List<Questionnares>();
        //    quest.Add(new Questionnares() { Questions = "TestQ1", Answesr = "TestA1", Note1 = "TestNot1", Note2 = "TestNote1" });
        //    quest.Add(new Questionnares() { Questions = "TestQ2", Answesr = "TestA2", Note1 = "TestNot2", Note2 = "TestNote2" });
        //    quest.Add(new Questionnares() { Questions = "TestQ3", Answesr = "TestA3", Note1 = "TestNot3", Note2 = "TestNote3" });
        //    quest.Add(new Questionnares() { Questions = "TestQ4", Answesr = "TestA4", Note1 = "TestNot4", Note2 = "TestNote4" });
        //    quest.Add(new Questionnares() { Questions = "TestQ5", Answesr = "TestA5", Note1 = "TestNot5", Note2 = "TestNote5" });
        //    return quest;
        //}
         public List<QuestionnareModel> lstQuestionModel { get; set; }

    }
    //public class Test
    //{
    //    public List<Questionnares> lst = Questionnares.fill();

    //}

        #endregion
}
