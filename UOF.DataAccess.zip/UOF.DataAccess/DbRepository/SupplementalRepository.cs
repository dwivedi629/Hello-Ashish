﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using UOF.Common.EntityModel;
using UOF.Common.Utilities;
using UOF.DataAccess.Repository;

namespace UOF.DataAccess.DbRepository
{
    public class SupplementalRepository
    {
        UnitOfWork uow = new UnitOfWork();

        public int SaveSupplementalData(SupplementalModel model)
        {
            int result = 0;
            FormReviewRespository repo = new FormReviewRespository();
            model.UserRoleId = repo.GetUserRoleID(model.UserRole);
            int FormDataId = 0;
            try
            {
                using (var transaction = new TransactionScope())
                {
                    var sup = new SupplementalModel();
                    var supModel = uow.UOFIncidentFormDataRepository.FindBy(a => a.UserRoleId == model.UserRoleId && a.FormID == model.FormID && a.IncidentID == model.IncidentID && a.EmpID == model.EmpId && a.FormDataID == model.FormDataId).FirstOrDefault();
                    if (model.isApproval)
                    {
                        supModel = uow.UOFIncidentFormDataRepository.FindBy(a => a.FormID == model.FormID && a.IncidentID == model.IncidentID && a.EmpID == model.SubmitedId && a.FormDataID == model.FormDataId).FirstOrDefault();
                        if (supModel != null)
                        {
                            supModel.IncidentID = supModel.IncidentID;
                            supModel.XmlData = model.Serialize();
                            supModel.UpdateBy = model.EmpId;
                            supModel.UpdateOn = DateTime.Now;
                            uow.UOFIncidentFormDataRepository.Update(supModel);
                            uow.Commit();
                            result = supModel.FormDataID;
                            using (LookupRespository lp = new LookupRespository())
                            {
                                lp.ApproveorReject(new ReviewEntity { IncidentId = model.IncidentID, DeputyEmpId = model.SubmitedId, ReviewerReviewId = model.EmpId, FormId = model.FormID, ReviewerRole = model.UserRole, isApprove = "Y", IncidentReviewId = model.IncidentReviewId });
                            }
                        }
                    }
                    else
                    {
                        if (supModel != null)
                        {
                            supModel.IncidentID = model.IncidentID;
                            supModel.XmlData = model.Serialize();
                            supModel.UpdateBy = model.EmpId;
                            supModel.UpdateOn = DateTime.Now;
                            supModel.Status = Constants.Status.DON.ToString();
                            uow.UOFIncidentFormDataRepository.Update(supModel);
                        }
                        else
                        {
                            var uofSup = new IncidentFormData();
                            uofSup.IncidentID = model.IncidentID;
                            uofSup.EmpID = model.EmpId;
                            uofSup.CreatedOn = DateTime.Now;
                            uofSup.CreatedBy = model.EmpId;
                            uofSup.FormID = model.FormID;
                            uofSup.UserRoleId = model.UserRoleId;
                            uofSup.XmlData = model.Serialize();
                            uofSup.Status = Constants.Status.DON.ToString();
                            uow.UOFIncidentFormDataRepository.Add(uofSup);
                            uow.Commit();
                            FormDataId = uofSup.FormDataID;
                            result = FormDataId;
                        }
                        if (!string.IsNullOrWhiteSpace(model.RejectComments))
                        {
                            using (ReturnCommentsRepository objRet = new ReturnCommentsRepository())
                            {
                                objRet.returnComments(new ReturnCommentModel { IncidentId = model.IncidentID, FormId = model.FormID, FormSubmitedId = model.SubmitedId, Comments = model.RejectComments });
                            }

                        }
                        #region Update Incident Review Forms
                        string sergeantID = (from ind in uow.IncidentRepository.GetAll()
                                             where ind.IncidentId == model.IncidentID
                                             select new { ind.SergeantId }).Single().SergeantId;

                        string reviewerRole = string.Empty;
                        string status = string.Empty;
                        switch (model.UserRole.ToUpper())
                        {
                            case "DSG":
                                reviewerRole = Constants.UserRoles.SGT.ToString();
                                break;
                            case "SGT":
                                reviewerRole = Constants.UserRoles.WC.ToString();
                                break;
                            case "WC":
                                reviewerRole = Constants.UserRoles.CAPT.ToString();
                                break;
                            case "CAPT":
                                reviewerRole = Constants.UserRoles.CMDR.ToString();
                                break;
                            default:
                                break;
                        }
                        string Id = string.Empty;
                        IncidentFormReviewEntity obj = new IncidentFormReviewEntity();
                        obj.IncidentID = model.IncidentID;
                        obj.SubmittedEmpId = model.EmpId;
                        obj.FormId = model.FormID;
                        obj.SubmitteduserRole = model.UserRole;
                        obj.ReviewerRole = !model.IsOnlySave ? reviewerRole : "";
                        obj.FormDataId = FormDataId;
                        obj.IncidentReviewID = model.IncidentReviewId;
                        if (model.UserRole == Constants.UserRoles.DSG.ToString())
                        {
                            //Id = (from ind in uow.IncidentWorkflowRepository.GetAll()
                            //      where ind.IncidentId == model.IncidentID
                            //      select new { ind.SergeantID }).Single().SergeantID;
                            //if (!string.IsNullOrEmpty(Id))
                            //    obj.SergeantId = Id;

                            obj.SergeantStatus = !model.IsOnlySave ? Constants.Status.Pending.ToString() : "";
                            obj.SubmittedStatus = !model.IsOnlySave ? Constants.Status.DON.ToString() : Constants.Status.Pending.ToString();
                            obj.WCStatus = Constants.Status.NotReady.ToString();
                            repo.InsertUpdateReviewForm(obj); ;
                            uow.Commit();
                            using (UoFWorkFlowRepository wfobj = new UoFWorkFlowRepository())
                            {
                                wfobj.UpdateSergeantStatus(new ReviewEntity { IncidentId = model.IncidentID });
                            }
                        }
                        if (model.UserRole == Constants.UserRoles.SGT.ToString())
                        {
                            //Id = (from ind in uow.IncidentWorkflowRepository.GetAll()
                            //      where ind.IncidentId == model.IncidentID
                            //      select new { ind.SergeantID }).Single().SergeantID;
                            //if (!string.IsNullOrEmpty(Id))
                            //    obj.SergeantId = Id;

                            obj.SergeantStatus = !model.IsOnlySave ? Constants.Status.Completed.ToString() : "";
                            obj.WCStatus = !model.IsOnlySave ? Constants.Status.Pending.ToString() : "";
                            obj.SubmittedStatus = !model.IsOnlySave ? Constants.Status.DON.ToString() : Constants.Status.Pending.ToString();
                            repo.InsertUpdateReviewForm(obj); ;
                            uow.Commit();
                            using (UoFWorkFlowRepository wfobj = new UoFWorkFlowRepository())
                            {
                                wfobj.UpdateSergeantStatus(new ReviewEntity { IncidentId = model.IncidentID });
                            }


                        }
                        if (model.UserRole == Constants.UserRoles.WC.ToString())
                        {

                            //Id = (from ind in uow.IncidentWorkflowRepository.GetAll()
                            //      where ind.IncidentId == model.IncidentID
                            //      select new { ind.WCID }).Single().WCID;
                            //if (!string.IsNullOrEmpty(Id))
                            //    obj.WCID = Id;

                            obj.WCStatus = !model.IsOnlySave ? Constants.Status.Completed.ToString() : "";
                            obj.UCStatus = !model.IsOnlySave ? Constants.Status.Pending.ToString() : "";
                            obj.SubmittedStatus = !model.IsOnlySave ? Constants.Status.DON.ToString() : Constants.Status.Pending.ToString();
                            repo.InsertUpdateReviewForm(obj); ;
                            uow.Commit();
                            using (UoFWorkFlowRepository wfobj = new UoFWorkFlowRepository())
                            {
                                wfobj.UpdateWCStatus(new ReviewEntity { IncidentId = model.IncidentID, LoggedId = model.EmpId });
                            }

                        }
                        if (model.UserRole == Constants.UserRoles.CAPT.ToString())
                        {
                            //Id = (from ind in uow.IncidentWorkflowRepository.GetAll()
                            //      where ind.IncidentId == model.IncidentID
                            //      select new { ind.UCID }).Single().UCID;
                            //if (!string.IsNullOrEmpty(Id))
                            //    obj.UCID = Id;

                            obj.UCStatus = !model.IsOnlySave ? Constants.Status.Completed.ToString() : "";
                            obj.CMStatus = !model.IsOnlySave ? Constants.Status.Pending.ToString() : "";
                            obj.SubmittedStatus = !model.IsOnlySave ? Constants.Status.DON.ToString() : Constants.Status.Pending.ToString();
                            repo.InsertUpdateReviewForm(obj); ;
                            uow.Commit();
                            using (UoFWorkFlowRepository wfobj = new UoFWorkFlowRepository())
                            {
                                wfobj.UpdateUCStatus(new ReviewEntity { IncidentId = model.IncidentID, LoggedId = model.EmpId });
                            }
                        }
                        if (model.UserRole == Constants.UserRoles.CMDR.ToString())
                        {
                            //Id = (from ind in uow.IncidentWorkflowRepository.GetAll()
                            //      where ind.IncidentId == model.IncidentID
                            //      select new { ind.CMID }).Single().CMID;
                            //if (!string.IsNullOrEmpty(Id))
                            //    obj.CMID = Id;

                            obj.CMStatus = !model.IsOnlySave ? Constants.Status.Completed.ToString() : "";
                            obj.SubmittedStatus = !model.IsOnlySave ? Constants.Status.DON.ToString() : Constants.Status.Pending.ToString();
                            repo.InsertUpdateReviewForm(obj); ;
                            uow.Commit();
                            using (UoFWorkFlowRepository wfobj = new UoFWorkFlowRepository())
                            {
                                wfobj.UpdateCMStatus(new ReviewEntity { IncidentId = model.IncidentID, LoggedId = model.EmpId });
                            }

                        }

                        Id = string.Empty;
                        #endregion
                        //repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                        //{
                        //    FormDataId = FormDataId,
                        //    IncidentReviewID = model.IncidentReviewId,
                        //    IncidentID = model.IncidentID,
                        //    SubmittedEmpId = model.EmpId,
                        //    FormId = model.FormID,
                        //    SubmitteduserRole = model.UserRole,
                        //    ReviewerRole = Constants.UserRoles.SGT.ToString(),
                        //    SergeantStatus = "Pending",
                        //    SubmittedStatus = Constants.Status.DON.ToString()
                        //});
                        if (model.IncidentReviewId > 0) //Explanation Form Update
                        {
                            if (uow.ExplainationReviewRespository.GetAll().Where(a => a.IncidentID == model.IncidentID && a.ExplanedFormID == model.FormID && a.IncidentReviewId == model.IncidentReviewId && a.RptId == model.EmpId && a.RptStatus == Constants.Status.Pending.ToString()).Any())
                            {
                                var explanationNotice = uow.ExplainationReviewRespository.FindBy(a => a.IncidentID == model.IncidentID && a.ExplanedFormID == model.FormID && a.IncidentReviewId == model.IncidentReviewId && a.RptId == model.EmpId && a.RptStatus == Constants.Status.Pending.ToString()).FirstOrDefault();
                                if (explanationNotice != null)
                                {
                                    explanationNotice.UpdatedOn = DateTime.Now;
                                    explanationNotice.UpdatedBy = model.EmpId;
                                    explanationNotice.RptStatus = Constants.Status.Completed.ToString();
                                    uow.ExplainationReviewRespository.Update(explanationNotice);
                                    uow.Commit();
                                    List<LookupEntity> AssignedForms = new List<LookupEntity>();
                                    #region Email Notification
                                    var SerId = (from ind in uow.ReviewRespository.GetAll()
                                                 where ind.IncidentID == model.IncidentID && ind.IncidentReviewID == model.IncidentReviewId
                                                 select new { ind.SergeantId }).Single().SergeantId;
                                    AssignedForms.Add(new LookupEntity { ID = model.FormID, Name = Constants.GetFormName(model.FormID) });
                                    string expfName = Constants.GetFormName(explanationNotice.ExplanedOnFormID);
                                    EmailRepository email = new EmailRepository();
                                    email.EmailNotification(new EmailNotificationModel
                                    {
                                        ToEmployeeId = SerId,
                                        Department = "Completed",
                                        IncidentId = Convert.ToInt32(model.IncidentID),
                                        EmployeeNumber = model.EmpId,
                                        AssignedForms = AssignedForms,
                                        ExplanationFormName = expfName
                                    });
                                    #endregion
                                }
                            }
                        }
                    }
                    uow.Commit();
                    transaction.Complete();
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return result;
        }
        public SupplementalModel GetSupplementalDetails(ParameterCriteria cirteria)
        {

            try
            {
                IncidentFormData data = null;
                if (cirteria.report)
                    data = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.FormID == cirteria.formId && x.EmpID == cirteria.employeeId && x.IncidentID == cirteria.incidentId).FirstOrDefault();
                else
                    data = uow.UOFIncidentFormDataRepository.GetById(cirteria.formDataId);

                var result = data != null ? data.XmlData.Deserialize<SupplementalModel>() : null;
                if (result != null)
                {
                    using (ReturnCommentsRepository obj = new ReturnCommentsRepository())
                    {
                        result.RejectComments = obj.getReturnComments(new ReturnCommentModel { IncidentId = cirteria.incidentId, FormId = cirteria.formId, FormSubmitedId = cirteria.employeeId, IncidentReviewID = cirteria.IncidentReviewId });
                    }
                }
                return result;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

    }
}
