﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.DataAccess.Repository;

namespace UOF.DataAccess.DbRepository
{
    public class IncidentPackageRepository : IDisposable
    {
        UnitOfWork uow = new UnitOfWork();

        public bool InsertUpdatePackage(PackageEntity model)
        {
            try
            {
                var dbModel = uow.PackageRespository.GetAll().Where(x => x.IncidentId == model.IncidentId && x.ExistingEmpId == model.ExistingEmpId && x.Active == true).FirstOrDefault();
                if (dbModel != null)
                {
                    dbModel.ChangedEmpId = model.ChangedEmpId;
                    dbModel.UserTypeId = model.UserTypeId;
                    uow.PackageRespository.Update(dbModel);
                    uow.Commit();

                }
                else
                {
                    var uofPackage = new IncidentPackage();
                    uofPackage.IncidentId = model.IncidentId;
                    uofPackage.ExistingEmpId = model.ExistingEmpId;
                    uofPackage.ChangedEmpId = model.ChangedEmpId;
                    uofPackage.CreatedBy = model.CreatedBy;
                    uofPackage.CreatedDate = DateTime.Now;
                    uofPackage.Active = true;
                    uofPackage.UserTypeId = model.UserTypeId;
                    uow.PackageRespository.Add(uofPackage);
                    uow.Commit();
                }
            }
            catch (Exception ex)
            {
                return false;
                throw ex;
            }
            return true;
        }
        public void Dispose()
        {
            //throw new NotImplementedException();
        }

    }

}
