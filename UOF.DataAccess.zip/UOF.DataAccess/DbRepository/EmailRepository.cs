﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.DataAccess.Repository;
using System.Configuration;
using UOF.Logging;

namespace UOF.DataAccess.DbRepository
{
    public class EmailRepository
    {
        UnitOfWork uow = new UnitOfWork();
        readonly ILogService LogService = new LogService(typeof(EmailRepository));
        public bool EmailNotification(EmailNotificationModel entity)
        {
            //EmailNotification model = uow.EmailRepository.GetAll().Where(x => x.IncidentId == entity.IncidentId).FirstOrDefault();
            try
            {
                //if (model != null)
                //{
                //    model.Responded = entity.Responded;
                //    model.RespondedOn = entity.RespondedOn;
                //    uow.EmailRepository.Update(model);
                //    uow.Commit();
                //}
                //else
                //{
                if (string.IsNullOrWhiteSpace(entity.EmailId))
                {
                    var usr = (from incidentUser in uow.IncidentUserRepository.GetAll()
                               join user in uow.UserRepository.GetAll() on incidentUser.UserId equals user.UserId
                               join det in uow.UserDetailRepository.GetAll() on user.UserDetailId equals det.UserDetailId
                               where incidentUser.IncidentId == entity.IncidentId && user.ForceEmployeeId == entity.ToEmployeeId
                               select det).FirstOrDefault();
                    if (usr != null)
                        entity.EmailId = usr.EmailId;
                }
                entity.UoFbaseURL = ConfigurationManager.AppSettings["UoFbaseURL"].ToString();
                if (ConfigurationManager.AppSettings["SendEmail"].ToString() == "true")
                {
                    if (entity.EmailId != null)
                    {
                        var email = new EmailNotification();
                        email.IncidentId = entity.IncidentId;
                        email.EmailId = entity.EmailId;
                        email.EmployeeNumber = entity.EmployeeNumber;
                        email.Department = entity.Department;
                        email.Sent = true;
                        email.Responded = false;
                        email.SentOn = DateTime.Now;
                        email.Status = "ACT";
                        uow.EmailRepository.Add(email);
                        uow.Commit();
                        //Getting the URN Number
                        string URN = (from ind in uow.IncidentRepository.GetAll()
                                      where ind.IncidentId == entity.IncidentId
                                      select new { ind.URN }).Single().URN;
                        entity.URN = URN;
                        sendMail(entity);
                        //}
                    }
                }
                else
                    LogService.CustomInfo(entity, "EmailNotification", entity.EmployeeNumber);

                return true;
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "EmailNotification", entity.EmployeeNumber, ex.Source);
                throw ex;
            }
        }

        private void sendMail(EmailNotificationModel entity)
        {
            StringBuilder body = new StringBuilder();
            var message = new System.Net.Mail.MailMessage();
            message.To.Add(new MailAddress(entity.EmailId));

            if (entity.Department == "Started")
            {
                message.Subject = "Use Of Force Application started with Incident with " + entity.URN;

                body.AppendLine("<table>");
                body.AppendLine("<tr><td>" + "Incident was Started with  entity.URN : " + entity.URN + ", Please click below link to access the application" + "</td></tr>");
                body.AppendLine("<tr><td>" + "Link for Application: " + entity.UoFbaseURL + "</td></tr>");
                body.AppendLine("</table>");
                message.Body = body.ToString();
            }
            else if (entity.Department == "Involved" || entity.Department == "Assign" || entity.Department == "Supervisor")
            {
                message.Subject = "Use Of Force Application , Involved Employee with Incident with " + entity.URN;

                body.AppendLine("<table>");
                body.AppendLine("<tr><td>" + "You are Involved in the Incident with  " + entity.URN + "</td></tr>");
                if (entity.AssignedForms != null && entity.AssignedForms.Count > 0)
                {
                    body.AppendLine("<tr><td> Here is the list of forms you need to fill </td></tr>");
                    foreach (LookupEntity item in entity.AssignedForms)
                    {
                        body.AppendLine("<tr><td><li>" + item.Name + "</li> </td></tr>");
                    }
                }
                body.AppendLine("<tr><td>  Please click below link to access the application</td></tr>");
                body.AppendLine("<tr><td>  Link for Application: " + entity.UoFbaseURL + "</td></tr>");
                body.AppendLine("</table>");

                message.Body = body.ToString();
            }
            else if (entity.Department == "Explanation")
            {
                message.Subject = "Use Of Force, You have been assigned to give the explanation report";

                body.AppendLine("<table>");
                body.AppendLine("<tr><td>" + "You are requested to give explanation to the form  " + entity.ExplanationFormName + "</td></tr>");
                if (entity.AssignedForms != null && entity.AssignedForms.Count > 0)
                {
                    body.AppendLine("<tr><td> Here is the list of forms you need to fill </td></tr>");
                    foreach (LookupEntity item in entity.AssignedForms)
                    {
                        body.AppendLine("<tr><td><li><a href='" + entity.UoFbaseURL + "'>" + item.Name + "</a></li> </td></tr>");
                    }
                }
                body.AppendLine("<tr><td> " + entity.comments + "</td></tr>");
                body.AppendLine("<tr><td>  Please click below link to access the application</td></tr>");
                body.AppendLine("<tr><td>  Link for Application: " + entity.UoFbaseURL + "</td></tr>");
                body.AppendLine("</table>");


                message.Body = body.ToString();
            }
            else if (entity.Department == "Completed")
            {
                message.Subject = "Use Of Force, Completed the explanation report";

                body.AppendLine("<table>");
                body.AppendLine("<tr><td>" + "Completed explanation to the form  " + entity.ExplanationFormName + "</td></tr>");
                if (entity.AssignedForms != null && entity.AssignedForms.Count > 0)
                {
                    body.AppendLine("<tr><td> Here is the list of forms you need to fill </td></tr>");
                    foreach (LookupEntity item in entity.AssignedForms)
                    {
                        body.AppendLine("<tr><td><li><a href='" + entity.UoFbaseURL + "'>" + item.Name + "</a></li> </td></tr>");
                    }
                }
                body.AppendLine("<tr><td> " + entity.comments + "</td></tr>");
                body.AppendLine("<tr><td>  Please click below link to access the application</td></tr>");
                body.AppendLine("<tr><td>  Link for Application: " + entity.UoFbaseURL + "</td></tr>");
                body.AppendLine("</table>");


                message.Body = body.ToString();
            }
            else if (entity.Department == "Report")
            {
                message.Subject = "Use Of Force, You have been assigned following reports to complete";

                body.AppendLine("<table>");
                if (entity.AssignedForms != null && entity.AssignedForms.Count > 0)
                {
                    body.AppendLine("<tr><td> Here is the list of forms you need to fill </td></tr>");
                    foreach (LookupEntity item in entity.AssignedForms)
                    {
                        body.AppendLine("<tr><td><li><a href='"+ entity.UoFbaseURL +"'>" + item.Name + "</a></li> </td></tr>");
                    }
                }
                body.AppendLine("<tr><td>  Please click below link to access the application</td></tr>");
                body.AppendLine("<tr><td>  Link for Application: " + entity.UoFbaseURL + "</td></tr>");
                body.AppendLine("</table>");


                message.Body = body.ToString();
            }

            else if (entity.Department == "Supervisory Information")
            {
                message.Subject = "Use Of Force Package started  with " + entity.URN;

                body.AppendLine("<table>");
                body.AppendLine("<tr><td>The above listed package was ongoing, You have been listed as assigned Watch Commander </td></tr>");
                body.AppendLine("<tr><td>Please click below link to access the application </td></tr>");
                body.AppendLine("<tr><td>" + "Link for Application: " + entity.UoFbaseURL + "</td></tr>");
                body.AppendLine("</table>");

                message.Body = body.ToString();
            }
            else
            {
                body.AppendLine("<table>");
                body.AppendLine("<tr><td>" + "Incident was Started with  entity.URN : " + entity.URN + ", Please click below link to access the application" + "</td></tr>");
                body.AppendLine("<tr><td>" + "Link for Application: " + entity.UoFbaseURL + "</td></tr>");
                body.AppendLine("</table>");
                message.Body = body.ToString();
            }
            message.IsBodyHtml = true;
            SmtpClient smtp = new SmtpClient();
            smtp.Send(message);
        }

    }
}
