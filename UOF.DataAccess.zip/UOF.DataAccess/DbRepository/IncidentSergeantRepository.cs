﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.DataAccess.Repository;

namespace UOF.DataAccess.DbRepository
{
    public class IncidentSergeantRepository
    {
        UnitOfWork uow = new UnitOfWork();
        public void SaveIncidentSergeant(AdditionalSergeantModel model)
        {
            try
            {
                if (uow.IncidentSergeantRepository.GetAll().Where(x => x.IncidentId == model.IncidentId).Any())
                {
                    var dbEntity = uow.IncidentSergeantRepository.FindBy(a => a.IncidentId == model.IncidentId && a.SergeantType == "A" && a.AddlSergeantId == model.AddlSergeantId).FirstOrDefault();
                    if (dbEntity != null)
                    {
                        dbEntity.EmployeeNumber = model.EmployeeNumber;
                        uow.IncidentSergeantRepository.Update(dbEntity);
                    }
                    else
                    {
                        var uofSerg = new IncidentSergeant();
                        uofSerg.IncidentId = model.IncidentId;
                        uofSerg.EmployeeNumber = model.EmployeeNumber;
                        uofSerg.Name = model.Name;
                        uofSerg.SergeantType = model.SergeantType;
                        uofSerg.CreatedBy = model.CreateBy;
                        uofSerg.CreatedOn = DateTime.Now;
                        uow.IncidentSergeantRepository.Add(uofSerg);
                    }
                }
                else
                {
                    var uofSerg = new IncidentSergeant();
                    uofSerg.IncidentId = model.IncidentId;
                    uofSerg.EmployeeNumber = model.EmployeeNumber;
                    uofSerg.Name = model.Name;
                    uofSerg.SergeantType = model.SergeantType;
                    uofSerg.CreatedBy = model.CreateBy;
                    uofSerg.CreatedOn = DateTime.Now;
                    uow.IncidentSergeantRepository.Add(uofSerg);

                }
                uow.Commit();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
