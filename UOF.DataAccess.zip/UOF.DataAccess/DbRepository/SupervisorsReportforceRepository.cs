﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using UOF.Common.EntityModel;
using UOF.DataAccess.Repository;
using UOF.Common.Utilities;

namespace UOF.DataAccess.DbRepository
{
    public class SupervisorsReportforceRepository
    {
        UnitOfWork uow = new UnitOfWork();

        public int SaveSupervisorsReportforceInfo(SupervisorsReportBusinessModel supervisorsReportBusinessModel)
        {
            int result = 0;
            try
            {
                //supervisorsReportBusinessModel.FormID = (int)Constants.UOFForms.SupervisorsReportforce;
                FormReviewRespository repo = new FormReviewRespository();
                supervisorsReportBusinessModel.UserRoleId = repo.GetUserRoleID(supervisorsReportBusinessModel.UserRole);
                int FormDataId = 0;
                var spReviewModel = uow.UOFIncidentFormDataRepository.FindBy(a => a.UserRoleId == supervisorsReportBusinessModel.UserRoleId && a.FormID == supervisorsReportBusinessModel.FormID && a.IncidentID == supervisorsReportBusinessModel.IncidentID && a.EmpID == supervisorsReportBusinessModel.EmpId && a.FormDataID == supervisorsReportBusinessModel.formDataId).FirstOrDefault();
                if (spReviewModel != null)
                {
                    spReviewModel.IncidentID = supervisorsReportBusinessModel.IncidentID;
                    spReviewModel.XmlData = supervisorsReportBusinessModel.Serialize();
                    spReviewModel.UpdateBy = supervisorsReportBusinessModel.EmpId;
                    spReviewModel.UpdateOn = DateTime.Now;
                    uow.UOFIncidentFormDataRepository.Update(spReviewModel);
                    result = spReviewModel.FormDataID;
                }
                else
                {
                    var spReview = new IncidentFormData();
                    spReview.IncidentID = supervisorsReportBusinessModel.IncidentID;
                    spReview.EmpID = supervisorsReportBusinessModel.EmpId;
                    spReview.CreatedOn = DateTime.Now;
                    spReview.CreatedBy = supervisorsReportBusinessModel.EmpId;
                    spReview.FormID = supervisorsReportBusinessModel.FormID;
                    spReview.UserRoleId = supervisorsReportBusinessModel.UserRoleId;
                    spReview.XmlData = supervisorsReportBusinessModel.Serialize();
                    spReview.Status = Constants.Status.DON.ToString();
                    uow.UOFIncidentFormDataRepository.Add(spReview);
                    uow.Commit();
                    FormDataId = spReview.FormDataID;
                    result = FormDataId;

                    //Update Incident Category form
                    var CAModel = uow.CategoryFormRepository.FindBy(a => a.FormID == supervisorsReportBusinessModel.FormID && a.IncidentID == supervisorsReportBusinessModel.IncidentID).FirstOrDefault();
                    if (CAModel != null)
                    {
                        CAModel.Status = Constants.Status.DON.ToString();
                        uow.CategoryFormRepository.Update(CAModel);
                    }
                }
                #region Update Incident Review Forms
                string sergeantID = (from ind in uow.IncidentRepository.GetAll()
                                     where ind.IncidentId == supervisorsReportBusinessModel.IncidentID
                                     select new { ind.SergeantId }).Single().SergeantId;

                repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                {
                    FormDataId = FormDataId,
                    IncidentReviewID = supervisorsReportBusinessModel.IncidentReviewId,
                    IncidentID = supervisorsReportBusinessModel.IncidentID,
                    SubmittedEmpId = sergeantID,
                    FormId = supervisorsReportBusinessModel.FormID,
                    SubmitteduserRole = supervisorsReportBusinessModel.UserRole,
                    ReviewerRole = !supervisorsReportBusinessModel.IsOnlySave ? Constants.UserRoles.WC.ToString() : "",
                    SergeantStatus = !supervisorsReportBusinessModel.IsOnlySave ? Constants.Status.Completed.ToString() : "",
                    WCStatus = !supervisorsReportBusinessModel.IsOnlySave ? Constants.Status.Pending.ToString() : "",
                    SubmittedStatus = !supervisorsReportBusinessModel.IsOnlySave ? Constants.Status.Completed.ToString() : Constants.Status.Pending.ToString(),
                });
                #endregion

                uow.Commit();

               
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return result;
        }



        public SupervisorsReportBusinessModel GetSupervisorsReportforceInfo(ParameterCriteria cirteria)
        {

            try
            {
                IncidentFormData data = null;
                if (cirteria.report)
                    data = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.FormID == cirteria.formId && x.EmpID == cirteria.employeeId && x.IncidentID == cirteria.incidentId).FirstOrDefault();
                else
                    data = uow.UOFIncidentFormDataRepository.GetById(cirteria.formDataId);

                var result = data != null ? data.XmlData.Deserialize<SupervisorsReportBusinessModel>() : null;
                if (result != null)
                {
                    using (ReturnCommentsRepository obj = new ReturnCommentsRepository())
                    {
                        result.Category1.RejectComments = obj.getReturnComments(new ReturnCommentModel { IncidentId = cirteria.incidentId, FormId = cirteria.formId, FormSubmitedId = cirteria.employeeId, IncidentReviewID=cirteria.IncidentReviewId });
                    }
                }
                return result;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }


        public bool SaveTracking(TrackingModel model)
        {
            bool result = false;
            try
            {
                FormReviewRespository repo = new FormReviewRespository();
                model.UserRoleId = 1;

                var spReviewModel = uow.UOFIncidentFormDataRepository.FindBy(a => a.UserRoleId == model.UserRoleId && a.FormID == model.FormID && a.IncidentID == model.IncidentID && a.EmpID == model.EmpId).FirstOrDefault();
                if (spReviewModel != null)
                {
                    spReviewModel.IncidentID = model.IncidentID;
                    spReviewModel.XmlData = model.Serialize();
                    spReviewModel.UpdateBy = model.EmpId;
                    spReviewModel.UpdateOn = DateTime.Now;
                    uow.UOFIncidentFormDataRepository.Update(spReviewModel);
                }
                else
                {
                    var spReview = new IncidentFormData();
                    spReview.IncidentID = model.IncidentID;
                    spReview.EmpID = model.EmpId;
                    spReview.CreatedOn = DateTime.Now;
                    spReview.CreatedBy = model.EmpId;
                    spReview.FormID = model.FormID;
                    spReview.UserRoleId = model.UserRoleId;
                    spReview.XmlData = model.Serialize();
                    spReview.Status = Constants.Status.DON.ToString();
                    uow.UOFIncidentFormDataRepository.Add(spReview);
                }
                uow.Commit();

                result = true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return result;
        }

        public TrackingModel GetTracking(int FormId, int IncidentId)
        {

            try
            {
                var data = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.FormID == FormId && x.IncidentID == IncidentId).FirstOrDefault();
                var result = data != null ? data.XmlData.Deserialize<TrackingModel>() : null;
                if (result == null)
                {
                    TrackingModel model = new TrackingModel();
                    IncidentRepository IncReposit = new IncidentRepository();
                    var Incident = IncReposit.GetIncident(IncidentId);

                    switch (Incident.IncidentCategoryId)
                    {
                        case 1:
                            model.Cat1 = true;
                            break;
                        case 2:
                            model.Cat2 = true;
                            break;
                        case 3:
                            model.Cat3 = true;
                            break;
                    }
                    if (Incident.ForceTypeId.Contains("OC"))
                        model.ForceTypeIdOC = true;
                    else if (Incident.ForceTypeId.Contains("PK"))
                        model.ForceTypeIdPK = true;
                    else if (Incident.ForceTypeId.Contains("TR"))
                        model.ForceTypeIdTR = true;
                    else if (Incident.ForceTypeId.Contains("CT"))
                        model.ForceTypeIdCT = true;
                    else if (Incident.ForceTypeId.Contains("TT"))
                        model.ForceTypeIdTT = true;
                    else if (Incident.ForceTypeId.Contains("ST"))
                        model.ForceTypeIdST = true;
                    else if (Incident.ForceTypeId.Contains("CR"))
                        model.ForceTypeIdCR = true;
                    else if (Incident.ForceTypeId.Contains("FH"))
                        model.ForceTypeIdFH = true;

                    model.eLOTS = Incident.eLOTS;
                    model.FileNumber = Incident.URN;
                    model.ReferenceNumber = Incident.ReferenceNo;
                    model.IncidentDate  = Incident.IncidentDate.ToShortDateString();
                    model.SubmittedtoCFRT = Incident.IsCFRTNotified == "Y" ? Incident.IncidentDate.ToShortDateString() : string.Empty;
                    var submiitedForms = uow.UOFIncidentFormDataRepository.GetAll().Where(a => a.IncidentID == IncidentId).ToList();
                    var ReviewForms = uow.ReviewRespository.GetAll().Where(a => a.IncidentID == IncidentId).ToList();

                    model.isSHR49Submitted = submiitedForms.Where(x => x.FormID == 16).Any();
                    model.isUOFMemoSubmitted = submiitedForms.Where(x => x.FormID == 20).Any();
                    model.isSuppRptSubmitted = submiitedForms.Where(x => x.FormID == 22).Any();
                    model.isInmateRptSubmitted = submiitedForms.Where(x => x.FormID == 19).Any();

                    model.isWCReviewSubmitted = submiitedForms.Where(x => x.FormID == 25).Any();
                    model.isUCReviewSubmitted = submiitedForms.Where(x => x.FormID == 26).Any();
                    model.isCMReviewSubmitted = submiitedForms.Where(x => x.FormID == 27).Any();
                    if (submiitedForms.Where(x => x.FormID == 25).Any())
                    {
                        model.isWCReviewDate = submiitedForms.FirstOrDefault(x => x.FormID == 25).CreatedOn.ToString();

                    }
                    if (submiitedForms.Where(x => x.FormID == 26).Any())
                    {
                        model.isUCReviewDate = submiitedForms.FirstOrDefault(x => x.FormID == 26).CreatedOn.ToString();

                    }
                    if (submiitedForms.Where(x => x.FormID == 27).Any())
                    {
                        model.isCMReviewDate = submiitedForms.FirstOrDefault(x => x.FormID == 27).CreatedOn.ToString();

                    }

                    result = model;
                }
                return result;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
    }
}
