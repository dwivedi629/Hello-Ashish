﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.Common.Utilities;
using UOF.DataAccess.Repository;

namespace UOF.DataAccess.DbRepository
{
    public class CARepository
    {
        UnitOfWork uow = new UnitOfWork();

        public int SaveCAData(CAEntity model)
        {
            int result = 0;
            FormReviewRespository repo = new FormReviewRespository();
            int FormDataId = 0;
            CAModel ObjCA = model.Model;
            ObjCA.FormID = (int)Constants.UOFForms.CrimeAnalysisSupplementalForm;
            ObjCA.UserRoleId = repo.GetUserRoleID(ObjCA.UserRole);
            try
            {
                var sup = new SupplementalModel();
                var iabModel = uow.UOFIncidentFormDataRepository.FindBy(a => a.UserRoleId == ObjCA.UserRoleId && a.FormID == ObjCA.FormID && a.IncidentID == ObjCA.IncidentID && a.EmpID == ObjCA.EmpId && a.FormDataID == ObjCA.formDataId).FirstOrDefault();
                if (iabModel != null)
                {
                    iabModel.IncidentID = ObjCA.IncidentID;
                    iabModel.XmlData = model.Serialize();
                    iabModel.UpdateBy = ObjCA.EmpId;
                    iabModel.UpdateOn = DateTime.Now;
                    uow.UOFIncidentFormDataRepository.Update(iabModel);
                    result =iabModel.FormDataID;
                }
                else
                {
                    var uofform = new IncidentFormData();
                    uofform.IncidentID = ObjCA.IncidentID;
                    uofform.EmpID = ObjCA.EmpId;
                    uofform.CreatedOn = DateTime.Now;
                    uofform.CreatedBy = ObjCA.EmpId;
                    uofform.FormID = ObjCA.FormID;
                    uofform.UserRoleId = ObjCA.UserRoleId;
                    uofform.XmlData = model.Serialize();
                    uofform.Status = Constants.Status.DON.ToString();
                    uow.UOFIncidentFormDataRepository.Add(uofform);
                    uow.Commit();
                    FormDataId = uofform.FormDataID;
                    result = FormDataId;
                }

                uow.Commit();
                repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                {
                    IncidentID = ObjCA.IncidentID,
                    FormDataId = FormDataId,
                    IncidentReviewID = ObjCA.IncidentReviewId,
                    SubmittedEmpId = ObjCA.EmpId,
                    FormId = ObjCA.FormID,
                    SubmitteduserRole = ObjCA.UserRole,
                    ReviewerRole = !ObjCA.IsOnlySave ? Constants.UserRoles.SGT.ToString() : "",
                    SergeantStatus = !ObjCA.IsOnlySave ? Constants.Status.Pending.ToString() : "",
                    SubmittedStatus = !ObjCA.IsOnlySave ? Constants.Status.DON.ToString() : Constants.Status.Pending.ToString(),
                });

            }
            catch (Exception ex)
            {

                throw ex;
            }
            return result;
        }
        public CAEntity GetCADetails(ParameterCriteria cirteria)
        {

            try
            {
                IncidentFormData data = null;
                if (cirteria.report)
                    data = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.FormID == cirteria.formId && x.EmpID == cirteria.employeeId && x.IncidentID == cirteria.incidentId).FirstOrDefault();
                else
                    data = uow.UOFIncidentFormDataRepository.GetById(cirteria.formDataId);

                var result = data != null ? data.XmlData.Deserialize<CAEntity>() : null;
                if (result != null)
                {
                    using (ReturnCommentsRepository obj = new ReturnCommentsRepository())
                    {
                        result.Model.RejectComments = obj.getReturnComments(new ReturnCommentModel { IncidentId = cirteria.incidentId, FormId = cirteria.formId, FormSubmitedId = cirteria.employeeId, IncidentReviewID = cirteria.IncidentReviewId });
                    }
                }
                return result;
            }
            catch (Exception ex)
            {

                throw ex;

            }
        }
    }
}
