﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.Common.Utilities;
using UOF.DataAccess.Repository;

namespace UOF.DataAccess.DbRepository
{
    public class LookupRespository : IDisposable
    {
        UnitOfWork uow = new UnitOfWork();

        public List<LookupEntity> GetBodyPart()
        {

            try
            {
                var lookup = (from lk in uow.BodyPartRepository.GetAll()
                              select new LookupEntity
                              {
                                  Code = lk.BodyPartCode,
                                  Name = lk.BodyPartName,
                              }).ToList();
                lookup.Add(new LookupEntity { Code = "NN", Name = "None" });
                return lookup;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public List<LookupEntity> GetInjuries()
        {
            List<LookupEntity> injuries = new List<LookupEntity>();
            try
            {
                var lookup = (from lk in uow.InjuryRepository.GetAll()
                              select new LookupEntity
                              {
                                  Code = lk.InjuryCode,
                                  Name = lk.InjuryName,
                                  Type = lk.Type
                              }).ToList();
                lookup.Add(new LookupEntity { Code = "NN", Name = "None" });
                return lookup;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public List<LookupEntity> GetBureaus()
        {
            List<LookupEntity> Bureaus = new List<LookupEntity>();
            try
            {
                var lookup = (from lk in uow.BureauRepository.GetAll()
                              select new LookupEntity
                              {
                                  Code = lk.Identifier,
                                  Name = lk.Name,
                              }).ToList();
                lookup.Add(new LookupEntity { Code = "NN", Name = "None" });
                return lookup;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public List<LookupEntity> GetMethods()
        {

            try
            {
                var lookup = (from lk in uow.MethodRepository.GetAll()
                              select new LookupEntity
                              {
                                  Code = lk.MethodCode,
                                  Name = lk.MethodName
                              }).ToList();
                return lookup;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public List<LookupEntity> GetSpecialHandles()
        {

            try
            {
                var lookup = (from lk in uow.SpecialHandleRepository.GetAll()
                              select new LookupEntity
                              {
                                  Code = lk.Code,
                                  Name = lk.Name
                              }).ToList();
                lookup.Add(new LookupEntity { Code = "NN", Name = "None" });
                return lookup;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public List<LookupEntity> GetSecurityLevel()
        {

            try
            {
                var lookup = (from lk in uow.SecurityLevelRepository.GetAll()
                              select new LookupEntity
                              {
                                  Code = lk.Code,
                                  Name = lk.Name
                              }).ToList();
                lookup.Add(new LookupEntity { Code = "NN", Name = "None" });
                return lookup;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public List<LookupEntity> GetCities()
        {

            try
            {
                var lookup = (from lk in uow.CityRepository.GetAll()
                              select new LookupEntity
                              {
                                  Code = lk.Code,
                                  Name = lk.Name
                              }).ToList();
                lookup.Add(new LookupEntity { Code = "NN", Name = "None" });
                return lookup;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public List<LookupEntity> GetContactTypes()
        {

            try
            {
                var lookup = (from lk in uow.ContactLookupRepository.GetAll()
                              select new LookupEntity
                              {
                                  Code = lk.Code,
                                  Name = lk.Name
                              }).ToList();
                lookup.Add(new LookupEntity { Code = "NN", Name = "None" });
                return lookup;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public List<LookupEntity> GetCustodyEvents()
        {

            try
            {
                var lookup = (from lk in uow.CustodyEventRepository.GetAll()
                              select new LookupEntity
                              {
                                  Code = lk.Code,
                                  Name = lk.Name
                              }).ToList();
                lookup.Add(new LookupEntity { Code = "NN", Name = "None" });
                return lookup;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public List<LookupEntity> GetInmateDress()
        {

            try
            {
                var lookup = (from lk in uow.InmateDressRepository.GetAll()
                              select new LookupEntity
                              {
                                  Code = lk.Code,
                                  Name = lk.Name
                              }).ToList();
                return lookup;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public List<LookupEntity> GetDress()
        {

            try
            {
                var lookup = (from lk in uow.DressRepository.GetAll()
                              select new LookupEntity
                              {
                                  Code = lk.Code,
                                  Name = lk.Name
                              }).ToList();
                return lookup;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public List<LookupEntity> GetFacilties()
        {

            try
            {
                var lookup = (from lk in uow.FacilityRepository.GetAll()
                              select new LookupEntity
                              {
                                  Code = lk.Code,
                                  Name = lk.Name
                              }).ToList();
                lookup.Add(new LookupEntity { Code = "NN", Name = "None" });
                return lookup;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public List<LookupEntity> GetInjurySeverities()
        {

            try
            {
                //var Injury = (from lk in uow.InjuryRepository.GetAll()
                //              where lk.Type == "B"
                //              select new LookupEntity
                //              {
                //                  Code = lk.InjuryCode,
                //                  Name = lk.InjuryName
                //              }).ToList();

                var lookup = (from lk in uow.InjurySeverityRepository.GetAll()
                              select new LookupEntity
                              {
                                  Code = lk.Code,
                                  Name = lk.Name
                              }).ToList();
                return lookup;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public List<LookupEntity> GetLocationofForce()
        {

            try
            {
                var lookup = (from lk in uow.LocationofForceRepository.GetAll()
                              select new LookupEntity
                              {
                                  Code = lk.Code,
                                  Name = lk.Name
                              }).ToList();
                return lookup;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public List<LookupEntity> GetSuspectLocationofForce()
        {

            try
            {
                var Injury = (from lk in uow.BodyPartRepository.GetAll()
                              select new LookupEntity
                              {
                                  Code = lk.BodyPartCode,
                                  Name = lk.BodyPartName
                              }).ToList();
                List<LookupEntity> lst = new List<LookupEntity>()
                                                    {
                                                        new LookupEntity() { Code = "HF",Name = "Head(front)" },
                                                        new LookupEntity() { Code = "HF",Name = "Head(Side)" },
                                                        new LookupEntity() { Code = "HR",Name = "Head(rear)"},
                                                        new LookupEntity() { Code = "NT",Name = "Neck/Throat" },
                                                        new LookupEntity() {Code = "FL",Name = "Front legs/feet" },
                                                         new LookupEntity() {Code = "RL",Name = "Rear Legs" },
                                                         new LookupEntity() {Code = "NN",Name = "None" }
                                                    };


                return Injury.Concat(lst).ToList();
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public List<LookupEntity> GetPerceivedArmed()
        {

            try
            {
                var lookup = (from lk in uow.PerceivedArmedRepository.GetAll()
                              select new LookupEntity
                              {
                                  Code = lk.Code,
                                  Name = lk.Name
                              }).ToList();
                return lookup;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public List<LookupEntity> GetConfirmedArmed()
        {

            try
            {
                var lookup = (from lk in uow.ConfirmedArmedRepository.GetAll()
                              select new LookupEntity
                              {
                                  Code = lk.Code,
                                  Name = lk.Name
                              }).ToList();
                lookup.Add(new LookupEntity { Code = "NN", Name = "None" });
                return lookup;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        public List<LookupEntity> GetRacies()
        {

            try
            {
                var lookup = (from lk in uow.RaceRepository.GetAll()
                              select new LookupEntity
                              {
                                  Code = lk.Code,
                                  Name = lk.Name
                              }).ToList();
                return lookup;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        public List<LookupEntity> GetResistance()
        {

            try
            {
                var lookup = (from lk in uow.ResistanceRepository.GetAll()
                              select new LookupEntity
                              {
                                  Code = lk.Code,
                                  Name = lk.Name
                              }).ToList();
                return lookup;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        public List<LookupEntity> GetSex()
        {

            try
            {
                var lookup = (from lk in uow.SexRepository.GetAll()
                              select new LookupEntity
                              {
                                  Code = lk.Code,
                                  Name = lk.Name
                              }).ToList();
                lookup.Add(new LookupEntity { Code = "NN", Name = "None" });
                return lookup;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public List<LookupEntity> GetSubstance()
        {

            try
            {
                var lookup = (from lk in uow.SubstanceRepository.GetAll()
                              select new LookupEntity
                              {
                                  Code = lk.Code,
                                  Name = lk.Name
                              }).ToList();
                lookup.Add(new LookupEntity { Code = "NN", Name = "None" });
                return lookup;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public List<LookupEntity> GetArmed()
        {

            try
            {
                var lookup = (from lk in uow.ArmedRepository.GetAll()
                              select new LookupEntity
                              {
                                  Code = lk.Code,
                                  Name = lk.Name
                              }).ToList();
                return lookup;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }


        public UoFFormEntity GetFormURL(int formId)
        {
            try
            {
                var formUrl = (from lk in uow.UofFormRepository.GetAll()
                               where lk.FormId == formId
                               select new UoFFormEntity
                               {
                                   ActionName = lk.ActionName,
                                   ControllerName = lk.ControllerName
                               }).FirstOrDefault();
                return formUrl;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public List<LookupEntity> GetSergeant()
        {
            try
            {
                var lookup = (from lk in uow.IncidentSergeantRepository.GetAll()
                              where lk.SergeantType == "A"
                              select new LookupEntity
                              {
                                  ID = lk.IncidentId,
                                  Code = lk.EmployeeNumber,
                                  Name = lk.Name
                              }).ToList();
                return lookup;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public string ReadyforPackage(int incidentId, int rank)
        {
            string role = (from ind in uow.UserRoleRepository.GetAll() where ind.Rank == rank select new { ind.RoleCode }).Single().RoleCode;
            if (role == Constants.UserRoles.SGT.ToString())
            {
                if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && x.WCStatus != Constants.Status.Completed.ToString() && x.WCStatus != null && x.FormId == (int)Constants.UOFForms.MedicalReport && x.FormId == (int)Constants.UOFForms.InmateInjuryIllness).Any())
                    return "Medical and Inmate Report review is not done";
                if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && (x.FormId == (int)Constants.UOFForms.Cat1ChemicalAgent || x.FormId == (int)Constants.UOFForms.UseofForceNarrativeReport)).Any())
                {
                    if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && x.SergeantStatus != Constants.Status.Completed.ToString() && x.SergeantStatus != null && (x.FormId == (int)Constants.UOFForms.Cat1ChemicalAgent || x.FormId == (int)Constants.UOFForms.UseofForceNarrativeReport)).Any())
                        return "Supervisory forms are not done";
                }
                if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && x.SergeantStatus != Constants.Status.Completed.ToString() && x.SergeantStatus != null).Any())
                    return "Please complete all form before assigning the package";
            }
            if (role == Constants.UserRoles.WC.ToString())
            {
                if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && x.WCStatus != Constants.Status.Completed.ToString() && x.WCStatus != null).Any())
                    return "Please complete all form before assigning the package";
            }
            if (role == Constants.UserRoles.CAPT.ToString())
            {
                if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && x.UCStatus != Constants.Status.Completed.ToString() && x.UCStatus != null).Any())
                    return "Please complete all form before assigning the package";
            }
            if (role == Constants.UserRoles.CMDR.ToString())
            {
                if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && x.CMStatus != Constants.Status.Completed.ToString() && x.CMStatus != null).Any())
                    return "Please complete all form before assigning the package";
            }

            return "OK";
        }

        public bool ApproveorReject(ReviewEntity entity)
        {
            try
            {
                FormReviewRespository repo = new FormReviewRespository();
                UoFWorkFlowRepository wf = new UoFWorkFlowRepository();
                IncidentWorkflow WfModel = uow.IncidentWorkflowRepository.GetAll().Where(x => x.IncidentId == entity.IncidentId).FirstOrDefault();
                switch (entity.ReviewerRole)
                {
                    case "SGT":
                        string WCID = string.Empty;
                        var usr = (from incidentUser in uow.IncidentUserRepository.GetAll()
                                   join user in uow.UserRepository.GetAll() on incidentUser.UserId equals user.UserId
                                   where incidentUser.IncidentId == entity.IncidentId && user.UserTypeId == (int)Constants.UserType.WatchCommander
                                   select user).FirstOrDefault();
                        if (usr != null)
                            WCID = usr.ForceEmployeeId;

                        var checkMedical = uow.IncidentMedicalRespository.GetAll().Where(x => x.IncidentId == entity.IncidentId && x.FormId == entity.FormId && x.Active == true).FirstOrDefault();
                        string sentToWC = string.Empty;

                        if (checkMedical != null)
                            sentToWC = Constants.Status.Pending.ToString();
                        else
                            sentToWC = Constants.Status.NotReady.ToString();

                        repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                        {
                            loggedInRank = 2,
                            isApproveOrReject = true,
                            IncidentReviewID = entity.IncidentReviewId,
                            IncidentID = entity.IncidentId,
                            SubmittedEmpId = entity.DeputyEmpId,
                            FormId = entity.FormId,
                            SergeantId = entity.ReviewerReviewId,
                            ReviewerRole = (entity.isApprove == "Y" ? Constants.UserRoles.WC.ToString() : entity.ReviewerRole),
                            SergeantStatus = (entity.isApprove == "Y" ? Constants.Status.Completed.ToString() : Constants.Status.Rejected.ToString()),
                            WCID = (entity.isApprove == "Y" ? WCID : null),
                            WCStatus = (entity.isApprove == "Y" ? (entity.FormId == (int)Constants.UOFForms.InmateInjuryIllness || entity.FormId == (int)Constants.UOFForms.MedicalReport ? sentToWC : Constants.Status.Completed.ToString()) : ""),
                            SubmittedStatus = (entity.isApprove == "N" ? Constants.Status.Rejected.ToString() : Constants.Status.Completed.ToString())
                        });
                        if (entity.isApprove == "N")
                        {
                            using (ReturnCommentsRepository obj = new ReturnCommentsRepository())
                            {
                                obj.returnComments(new ReturnCommentModel { IncidentId = entity.IncidentId, FormId = entity.FormId, FormSubmitedId = entity.DeputyEmpId, EmployeeNumber = entity.ReviewerReviewId, Comments = entity.Comment, IncidentReviewID = entity.IncidentReviewId });
                            }
                        }

                        using (UoFWorkFlowRepository wfobj = new UoFWorkFlowRepository())
                        {
                            wfobj.UpdateSergeantStatus(new ReviewEntity { IncidentId = entity.IncidentId });
                        }
                        break;
                    case "WC":
                        
                        if (entity.isSRForm)
                        {
                            var Invt = uow.InvestigationOfficerRespository.GetAll().Where(x => x.IncidentId == entity.IncidentId && x.Status == "Active").FirstOrDefault();
                            entity.DeputyEmpId = Invt.EmployeeId;

                            var dbModel = uow.ReviewRespository.GetAll().Where(x => x.FormId == entity.FormId && x.InvolvedId == entity.DeputyEmpId && x.InvolvedRole == "SGT" && x.IncidentID == entity.IncidentId && x.FormId == 48).FirstOrDefault();
                            entity.IncidentReviewId = dbModel.IncidentReviewID;
                        }
                            
                        repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                        {
                            loggedInRank=3,
                            isApproveOrReject = true,
                            IncidentReviewID = entity.IncidentReviewId,
                            IncidentID = entity.IncidentId,
                            SubmittedEmpId = entity.DeputyEmpId,
                            FormId = entity.FormId,
                            WCID = entity.ReviewerReviewId,
                            ReviewerRole = (entity.isApprove == "Y" ? Constants.UserRoles.CAPT.ToString() : entity.ReviewerRole),
                            WCStatus = (entity.isApprove == "Y" ? Constants.Status.Completed.ToString() : Constants.Status.Rejected.ToString()),
                            UCStatus = (entity.isApprove == "Y" ? (entity.isSRForm ? Constants.Status.Pending.ToString() : null) : null),
                            CMStatus = (entity.isApprove == "Y" ? (entity.isSRForm ? Constants.Status.Completed.ToString() : null) : null),
                            DCStatus = (entity.isApprove == "Y" ? (entity.isSRForm ? Constants.Status.Completed.ToString() : null) : null),
                            SergeantStatus = (entity.isApprove == "Y" ? Constants.Status.Completed.ToString() : Constants.Status.Rejected.ToString()),
                        });
                        if (entity.isApprove == "N")
                        {
                            using (ReturnCommentsRepository obj = new ReturnCommentsRepository())
                            {
                                obj.returnComments(new ReturnCommentModel { IncidentId = entity.IncidentId, FormId = entity.FormId, FormSubmitedId = entity.DeputyEmpId, EmployeeNumber = entity.ReviewerReviewId, Comments = entity.Comment , IncidentReviewID = entity.IncidentReviewId });
                            }
                        }

                        using (UoFWorkFlowRepository wfobj = new UoFWorkFlowRepository())
                        {
                            wfobj.UpdateWCStatus(new ReviewEntity { IncidentId = entity.IncidentId, LoggedId = entity.ReviewerReviewId });
                        }
                        
                        break;
                    case "CAPT":
                        if (entity.isSRForm)
                        {
                            var Invt = uow.InvestigationOfficerRespository.GetAll().Where(x => x.IncidentId == entity.IncidentId && x.Status == "Active").FirstOrDefault();
                            entity.DeputyEmpId = Invt.EmployeeId;

                            var dbModel = uow.ReviewRespository.GetAll().Where(x => x.FormId == entity.FormId && x.InvolvedId == entity.DeputyEmpId && x.InvolvedRole == "SGT" && x.IncidentID == entity.IncidentId && x.FormId == 48).FirstOrDefault();
                            entity.IncidentReviewId = dbModel.IncidentReviewID;
                        }
                        repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                        {
                            loggedInRank = 4,
                            isApproveOrReject = true,
                            IncidentReviewID = entity.IncidentReviewId,
                            IncidentID = entity.IncidentId,
                            SubmittedEmpId = entity.DeputyEmpId,
                            FormId = entity.FormId,
                            UCID = entity.ReviewerReviewId,
                            ReviewerRole = (entity.isApprove == "Y" ? Constants.UserRoles.CMDR.ToString() : entity.ReviewerRole),
                            UCStatus = (entity.isApprove == "Y" ? Constants.Status.Completed.ToString() : Constants.Status.Rejected.ToString()),
                            CMStatus = (entity.isApprove == "Y" ? Constants.Status.Completed.ToString() : null),
                            WCStatus = (entity.isApprove == "Y" ? Constants.Status.Completed.ToString() : Constants.Status.Rejected.ToString()),
                        });
                        if (entity.isApprove == "N")
                        {
                            using (ReturnCommentsRepository obj = new ReturnCommentsRepository())
                            {
                                obj.returnComments(new ReturnCommentModel { IncidentId = entity.IncidentId, FormId = entity.FormId, FormSubmitedId = entity.DeputyEmpId, EmployeeNumber = entity.ReviewerReviewId, Comments = entity.Comment, IncidentReviewID = entity.IncidentReviewId });
                            }
                        }

                        using (UoFWorkFlowRepository wfobj = new UoFWorkFlowRepository())
                        {
                            wfobj.UpdateUCStatus(new ReviewEntity { IncidentId = entity.IncidentId, LoggedId = entity.ReviewerReviewId });
                        }
                       
                        break;
                    case "CMDR":
                        repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                        {
                            loggedInRank = 5,
                            isApproveOrReject = true,
                            IncidentReviewID = entity.IncidentReviewId,
                            IncidentID = entity.IncidentId,
                            SubmittedEmpId = entity.DeputyEmpId,
                            FormId = entity.FormId,
                            CMID = entity.ReviewerReviewId,
                            ReviewerRole = entity.ReviewerRole,
                            SergeantStatus = (entity.isApprove == "Y" ? Constants.Status.Completed.ToString() : Constants.Status.Pending.ToString()),
                            WCStatus = (entity.isApprove == "Y" ? Constants.Status.Completed.ToString() : Constants.Status.Pending.ToString()),
                            CMStatus = (entity.isApprove == "Y" ? Constants.Status.Completed.ToString() : Constants.Status.Pending.ToString()),
                            UCStatus = (entity.isApprove == "Y" ? Constants.Status.Completed.ToString() : Constants.Status.Rejected.ToString()),
                            DCStatus = (entity.isApprove == "Y" ? Constants.Status.Pending.ToString() : Constants.Status.NotReady.ToString())
                        });
                        if (entity.isApprove == "N")
                        {
                            using (ReturnCommentsRepository obj = new ReturnCommentsRepository())
                            {
                                obj.returnComments(new ReturnCommentModel { IncidentId = entity.IncidentId, FormId = entity.FormId, FormSubmitedId = entity.DeputyEmpId, EmployeeNumber = entity.ReviewerReviewId, Comments = entity.Comment, IncidentReviewID = entity.IncidentReviewId });
                            }
                        }

                        using (UoFWorkFlowRepository wfobj = new UoFWorkFlowRepository())
                        {
                            wfobj.UpdateCMStatus(new ReviewEntity { IncidentId = entity.IncidentId, LoggedId = entity.ReviewerReviewId });
                        }
                        break;
                    case "DC":
                        repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                        {
                            loggedInRank = 6,
                            isApproveOrReject = true,
                            IncidentReviewID = entity.IncidentReviewId,
                            IncidentID = entity.IncidentId,
                            SubmittedEmpId = entity.DeputyEmpId,
                            FormId = entity.FormId,
                            CMID = entity.ReviewerReviewId,
                            ReviewerRole = entity.ReviewerRole,
                            CMStatus = (entity.isApprove == "Y" ? Constants.Status.Completed.ToString() : Constants.Status.Rejected.ToString()),
                            UCStatus = (entity.isApprove == "Y" ? Constants.Status.Completed.ToString() : Constants.Status.Rejected.ToString()),
                            DCStatus = (entity.isApprove == "Y" ? Constants.Status.Completed.ToString() : Constants.Status.Rejected.ToString())
                        });
                        if (entity.isApprove == "N")
                        {
                            using (ReturnCommentsRepository obj = new ReturnCommentsRepository())
                            {
                                obj.returnComments(new ReturnCommentModel { IncidentId = entity.IncidentId, FormId = entity.FormId, FormSubmitedId = entity.DeputyEmpId, EmployeeNumber = entity.ReviewerReviewId, Comments = entity.Comment, IncidentReviewID = entity.IncidentReviewId });
                            }
                        }

                        using (UoFWorkFlowRepository wfobj = new UoFWorkFlowRepository())
                        {
                            wfobj.UpdateDCStatus(new ReviewEntity { IncidentId = entity.IncidentId, LoggedId = entity.ReviewerReviewId });
                        }
                        break;
                    default:
                        break;
                }
                //Insert into FormApproveorReject Table

                var ApprovOrReject = uow.FormApprovalRejectRespository.GetAll().Where(x => x.FormId == entity.FormId && x.FormFilledBy == entity.DeputyEmpId && x.IncidentId == entity.IncidentId && x.ActionBy == entity.ReviewerReviewId).ToList();
                foreach (FormApprovalorReject item in ApprovOrReject)
                {
                    item.Active = false;
                    uow.FormApprovalRejectRespository.Update(item);
                    uow.Commit();
                }

                var ApproveOrReject = new FormApprovalorReject();
                bool? isApproval = entity.isApprove == "Y" ? true : false;
                ApproveOrReject.IncidentId = entity.IncidentId;
                ApproveOrReject.FormId = entity.FormId;
                ApproveOrReject.ApproverRole = entity.ReviewerRole;
                ApproveOrReject.ActionBy = entity.ReviewerReviewId;
                ApproveOrReject.FormFilledBy = entity.DeputyEmpId;
                ApproveOrReject.IsApproved = isApproval;
                if (!string.IsNullOrWhiteSpace(entity.ActionDate))
                    ApproveOrReject.ActionDate = Convert.ToDateTime(entity.ActionDate);
                else
                    ApproveOrReject.ActionDate = DateTime.Now; ;
                ApproveOrReject.CreatedDate = DateTime.Now;
                if (!string.IsNullOrWhiteSpace(entity.EmployeeNo))
                    ApproveOrReject.EmployeeNo = entity.EmployeeNo;
                if (!string.IsNullOrWhiteSpace(entity.Assignment))
                    ApproveOrReject.Assignment = entity.Assignment;
                if (!string.IsNullOrWhiteSpace(entity.SRD))
                    ApproveOrReject.SRD = entity.SRD;
                ApproveOrReject.Active = true;
                uow.FormApprovalRejectRespository.Add(ApproveOrReject);
                uow.Commit();
                //End
                return true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public List<LookupEntity> GetStations()
        {

            try
            {
                var bodyLookup = (from lk in uow.StationRepository.GetAll()
                                  select new LookupEntity
                                  {
                                      Code = lk.Code,
                                      Name = lk.Name,
                                  }).ToList();
                return bodyLookup;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public List<LookupEntity> GetStaging()
        {

            try
            {
                var bodyLookup = (from lk in uow.StagingRepository.GetAll()
                                  select new LookupEntity
                                  {
                                      Code = lk.Code,
                                      Name = lk.Name,
                                  }).ToList();
                return bodyLookup;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        public bool EmailNotification(EmailNotificationModel entity)
        {
            //EmailNotification model = uow.EmailRepository.GetAll().Where(x => x.IncidentId == entity.IncidentId).FirstOrDefault();
            try
            {
                //if (model != null)
                //{
                //    model.Responded = entity.Responded;
                //    model.RespondedOn = entity.RespondedOn;
                //    uow.EmailRepository.Update(model);
                //    uow.Commit();
                //}
                //else
                //{
                var email = new EmailNotification();
                email.IncidentId = entity.IncidentId;
                email.EmailId = entity.EmailId;
                email.EmployeeNumber = entity.EmployeeNumber;
                email.Department = entity.Department;
                email.Sent = entity.Sent;
                email.Responded = false;
                email.SentOn = DateTime.Now;
                email.Status = "ACT";
                uow.EmailRepository.Add(email);
                uow.Commit();
                //}
                return true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public void Dispose()
        {
            //throw new NotImplementedException();
        }
    }
}
