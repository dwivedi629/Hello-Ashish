﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.Common.Utilities;
using UOF.DataAccess.Repository;

namespace UOF.DataAccess.DbRepository
{
    public class MedicalRepository
    {
        UnitOfWork uow = new UnitOfWork();

        public int SaveMedical(MedicalEntity medicalBusinessModel)
        {
            int result = 0;
            try
            {
                FormReviewRespository repo = new FormReviewRespository();
                int FormDataId = 0;
                medicalBusinessModel.UserRoleId = repo.GetUserRoleID(medicalBusinessModel.UserRole);
                var medicalModel = uow.UOFIncidentFormDataRepository.FindBy(a => a.UserRoleId == medicalBusinessModel.UserRoleId && a.FormID == medicalBusinessModel.FormID && a.IncidentID == medicalBusinessModel.IncidentID && a.EmpID == medicalBusinessModel.EmpId && a.FormDataID == medicalBusinessModel.formDataId).FirstOrDefault();
                if (medicalBusinessModel.isApproval)
                {
                    medicalModel = uow.UOFIncidentFormDataRepository.FindBy(a => a.FormID == medicalBusinessModel.FormID && a.IncidentID == medicalBusinessModel.IncidentID && a.EmpID == medicalBusinessModel.SubmitedId && a.FormDataID == medicalBusinessModel.formDataId).FirstOrDefault();
                    if (medicalModel != null)
                    {
                        FormDataId = medicalModel.FormDataID;
                        medicalModel.IncidentID = medicalModel.IncidentID;
                        medicalModel.XmlData = medicalBusinessModel.Serialize();
                        medicalModel.UpdateBy = medicalBusinessModel.EmpId;
                        medicalModel.UpdateOn = DateTime.Now;
                        uow.UOFIncidentFormDataRepository.Update(medicalModel);
                        uow.Commit();
                        using (LookupRespository lp = new LookupRespository())
                        {
                            lp.ApproveorReject(new ReviewEntity { IncidentId = medicalBusinessModel.IncidentID, DeputyEmpId = medicalBusinessModel.SubmitedId, ReviewerReviewId = medicalBusinessModel.EmpId, FormId = medicalBusinessModel.FormID, ReviewerRole = medicalBusinessModel.UserRole, isApprove = "Y", IncidentReviewId = medicalBusinessModel.IncidentReviewId });
                        }
                        result = medicalModel.FormDataID;
                    }
                }
                else if (medicalBusinessModel.isMedical)
                {
                    medicalModel = uow.UOFIncidentFormDataRepository.FindBy(a => a.FormID == medicalBusinessModel.FormID && a.IncidentID == medicalBusinessModel.IncidentID && a.EmpID == medicalBusinessModel.SubmitedId && a.FormDataID == medicalBusinessModel.formDataId).FirstOrDefault();
                    if (medicalModel != null)
                    {
                        FormDataId = medicalModel.FormDataID;
                        medicalModel.IncidentID = medicalModel.IncidentID;
                        medicalModel.XmlData = medicalBusinessModel.Serialize();
                        medicalModel.UpdateBy = medicalBusinessModel.EmpId;
                        medicalModel.UpdateOn = DateTime.Now;
                        uow.UOFIncidentFormDataRepository.Update(medicalModel);
                        uow.Commit();
                        result = medicalModel.FormDataID;
                    }
                    else
                    {
                        var medical = new IncidentFormData();
                        medical.IncidentID = medicalBusinessModel.IncidentID;
                        medical.EmpID = medicalBusinessModel.EmpId;
                        medical.CreatedOn = DateTime.Now;
                        medical.CreatedBy = medicalBusinessModel.EmpId;
                        medical.FormID = medicalBusinessModel.FormID;
                        medical.UserRoleId = medicalBusinessModel.UserRoleId;
                        medical.XmlData = medicalBusinessModel.Serialize();
                        medical.Status = Constants.Status.PND.ToString();
                        uow.UOFIncidentFormDataRepository.Add(medical);
                        uow.Commit();
                        result = FormDataId = medical.FormDataID;
                    }
                    var checkMedical = uow.IncidentMedicalRespository.GetAll().Where(x => x.IncidentId == medicalBusinessModel.IncidentID && x.FormId == medicalBusinessModel.FormID && x.Active == true).ToList();
                    if (checkMedical.Count > 0) {
                        foreach (var frm in checkMedical)
                        {
                            frm.Active = false;
                            uow.IncidentMedicalRespository.Update(frm);
                            uow.Commit();
                        }
                    }
                    //Insert into Medical Table
                    IncidentMedicalUser medUser = new IncidentMedicalUser();
                    medUser.IncidentId = medicalBusinessModel.IncidentID;
                    medUser.FormId = medicalBusinessModel.FormID;
                    medUser.EmpId = medicalBusinessModel.EmpId;
                    medUser.CreatedBy = medicalBusinessModel.EmpId;
                    medUser.CreatedDate = DateTime.Now;
                    medUser.Active = true;
                    uow.IncidentMedicalRespository.Add(medUser);
                    uow.Commit();
                    //End
                    repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                    {
                        FormDataId = FormDataId,
                        IncidentID = medicalBusinessModel.IncidentID,
                        IncidentReviewID = medicalBusinessModel.IncidentReviewId,
                        SubmittedEmpId = medicalBusinessModel.EmpId,
                        FormId = medicalBusinessModel.FormID,
                        WCStatus = Constants.Status.Pending.ToString(),
                    });
                }
                else
                {
                    if (medicalModel != null)
                    {
                        medicalModel.IncidentID = medicalModel.IncidentID;
                        medicalModel.XmlData = medicalBusinessModel.Serialize();
                        medicalModel.UpdateBy = medicalBusinessModel.EmpId;
                        medicalModel.UpdateOn = DateTime.Now;
                        uow.UOFIncidentFormDataRepository.Update(medicalModel);
                        result = medicalModel.FormDataID;
                    }
                    else
                    {
                        var medical = new IncidentFormData();
                        medical.IncidentID = medicalBusinessModel.IncidentID;
                        medical.EmpID = medicalBusinessModel.EmpId;
                        medical.CreatedOn = DateTime.Now;
                        medical.CreatedBy = medicalBusinessModel.EmpId;
                        medical.FormID = medicalBusinessModel.FormID;
                        medical.UserRoleId = medicalBusinessModel.UserRoleId;
                        medical.XmlData = medicalBusinessModel.Serialize();
                        medical.Status = Constants.Status.DON.ToString();
                        uow.UOFIncidentFormDataRepository.Add(medical);
                        uow.Commit();
                        result = FormDataId = medical.FormDataID;
                    }
                    var checkMedical = uow.IncidentMedicalRespository.GetAll().Where(x => x.IncidentId == medicalBusinessModel.IncidentID && x.FormId == medicalBusinessModel.FormID && x.Active == true).FirstOrDefault();
                    string sentToWC = string.Empty;

                    if (checkMedical != null)
                        sentToWC = Constants.Status.Pending.ToString();
                    else
                        sentToWC = Constants.Status.NotReady.ToString();

                    repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                    {
                        FormDataId = FormDataId,
                        IncidentID = medicalBusinessModel.IncidentID,
                        IncidentReviewID = medicalBusinessModel.IncidentReviewId,
                        SubmittedEmpId = medicalBusinessModel.EmpId,
                        FormId = medicalBusinessModel.FormID,
                        SubmitteduserRole = medicalBusinessModel.UserRole,
                        ReviewerRole = !medicalBusinessModel.IsOnlySave ? Constants.UserRoles.SGT.ToString() : "",
                        SergeantStatus = !medicalBusinessModel.IsOnlySave ? Constants.Status.Pending.ToString() : "",
                        WCStatus = sentToWC,
                        SubmittedStatus = !medicalBusinessModel.IsOnlySave ? Constants.Status.DON.ToString() : Constants.Status.Pending.ToString(),
                    });

                }
                uow.Commit();
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return result;
        }

        public MedicalEntity GetMedicalInformation(ParameterCriteria cirteria)
        {

            try
            {
                IncidentFormData data = null;

                if (cirteria.report)
                    data = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.FormID == cirteria.formId && x.EmpID == cirteria.employeeId && x.IncidentID == cirteria.incidentId).FirstOrDefault();
                else
                    data = uow.UOFIncidentFormDataRepository.GetById(cirteria.formDataId);

                var result = data != null ? data.XmlData.Deserialize<MedicalEntity>() : null;
                if (result != null)
                {
                    using (ReturnCommentsRepository obj = new ReturnCommentsRepository())
                    {
                        result.diagnosisInformation.RejectComments = obj.getReturnComments(new ReturnCommentModel { IncidentId = cirteria.incidentId, FormId = cirteria.formId, FormSubmitedId = cirteria.employeeId, IncidentReviewID = cirteria.IncidentReviewId });
                    }
                }
                return result;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

    }
}
