﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using UOF.Common.EntityModel;
using UOF.Common.Utilities;
using UOF.DataAccess.DataModel;
//using UOF.DataAccess.DataModel;
using UOF.DataAccess.Repository;

namespace UOF.DataAccess.DbRepository
{
    public class UserRepository : IncidentUserRepository
    {
        UnitOfWork unitofWork = new UnitOfWork();
        UoFWorkFlowRepository wf = new UoFWorkFlowRepository();
        FormReviewRespository repo = new FormReviewRespository();
        public bool SaveInvolvedUser(InvolvedUserEntity involvedUserEntity)
        {
            if (involvedUserEntity.Mode == Convert.ToString(Constants.Mode.Edit))
            {
                return UpdateInvolvedEmployee(involvedUserEntity);
            }
            else
                return InsertInvolvedEmployee(involvedUserEntity);
        }
        public bool UpdateUserType(int? incidentId, int userTypedId, int changedUserTypeId)
        {
            IncidentUser IncUsr = unitofWork.IncidentUserRepository.GetAll().Where(x => x.IncidentId == incidentId && x.UserTypeId == userTypedId).FirstOrDefault();
            if (IncUsr != null)
            {
                User usr = unitofWork.UserRepository.GetAll().Where(x => x.UserId == IncUsr.UserId).FirstOrDefault();
                if (usr != null)
                {
                    usr.UserTypeId = changedUserTypeId;
                    unitofWork.UserRepository.Update(usr);
                    IncUsr.UserTypeId = changedUserTypeId;
                    unitofWork.IncidentUserRepository.Update(IncUsr);
                    unitofWork.Commit();
                    return true;
                }
            }
            return false;
        }
        public bool UpdateUserDetails(UserDetailEntity detail)
        {
            UserDetail userDetail = unitofWork.UserDetailRepository.GetById(detail.UserDetailId);
            userDetail.FirstName = detail.FirstName;
            userDetail.MiddleName = detail.MiddleName;
            userDetail.LastName = detail.LastName;
            userDetail.Rank = detail.Rank;
            userDetail.Sex = detail.Sex;
            userDetail.Race = detail.Race;
            userDetail.Height = detail.Height;
            userDetail.Weight = detail.Weight;
            userDetail.Age = detail.Age;
            userDetail.Dress = detail.Dress;
            userDetail.ShiftId = detail.Shift;
            userDetail.UnitOfAssignment = detail.UnitOfAssignment;
            userDetail.WorkAssignment = detail.WorkAssignment;
            unitofWork.UserDetailRepository.Update(userDetail);
            unitofWork.Commit();
            return true;
        }
        private bool UpdateInvolvedEmployee(InvolvedUserEntity involvedUserEntity)
        {

            IncidentUserInvolved incidentUserInvolved = unitofWork.IncidentUserInvolvedRepository.GetById(involvedUserEntity.IncidentUserInvolvedId);
            UpdateUserDetails(new UserDetailEntity
            {
                UserDetailId = involvedUserEntity.UserDetailId,
                FirstName = involvedUserEntity.FirstName,
                LastName = involvedUserEntity.LastName,
                MiddleName = involvedUserEntity.MiddleName,
                Rank = involvedUserEntity.Rank,
                Sex = involvedUserEntity.Sex,
                Race = involvedUserEntity.Race,
                Weight = involvedUserEntity.Weight,
                Height = involvedUserEntity.Height,
                Age = involvedUserEntity.Age,
                Dress = involvedUserEntity.SelectedDress,
                Shift = involvedUserEntity.Shift,
                UnitOfAssignment = involvedUserEntity.UnitOfAssignment,
                WorkAssignment = involvedUserEntity.WorkAssignment
            });
            using (var transaction = new TransactionScope())
            {

                incidentUserInvolved.IndForceUsed = involvedUserEntity.IndForceUsed != null ? involvedUserEntity.IndForceUsed : string.Empty;
                incidentUserInvolved.IndividualCatId = involvedUserEntity.IndividualCatId;
                incidentUserInvolved.IsDirected = involvedUserEntity.IsDirected ? "Y" : "N";
                if (incidentUserInvolved.IsDirected == "Y")
                    incidentUserInvolved.DirectedEmplId = involvedUserEntity.DirectedEmpId;
                incidentUserInvolved.IsRescue = involvedUserEntity.IsRescue ? "Y" : "N";
                incidentUserInvolved.IsMedicalAssist = involvedUserEntity.IsMedicalAssist ? "Y" : "N";
                incidentUserInvolved.IsInjured = involvedUserEntity.IsInjured ? "Y" : "N";
                incidentUserInvolved.IsTreated = involvedUserEntity.IsTreated ? "Y" : "N";
                incidentUserInvolved.IsAdmitted = involvedUserEntity.IsAdmitted ? "Y" : "N";
                incidentUserInvolved.Facility = involvedUserEntity.Facility != null ? involvedUserEntity.Facility : string.Empty;
                incidentUserInvolved.CoronerCaseId = involvedUserEntity.CoronerCaseId != null ? involvedUserEntity.CoronerCaseId : string.Empty;
                incidentUserInvolved.DateOfBirth = involvedUserEntity.DateOfBirth;
                incidentUserInvolved.EmployeeItemNumber = involvedUserEntity.EmployeeItemNumber;
                incidentUserInvolved.DepartmentHireDate = involvedUserEntity.DepartmentHireDate;
                incidentUserInvolved.LastPromotionDate = involvedUserEntity.LastPromotionDate;
                incidentUserInvolved.DepartmentTenureInDays = involvedUserEntity.DepartmentTenureInDays;
                incidentUserInvolved.RankTenureIndays = involvedUserEntity.RankTenureIndays;
                incidentUserInvolved.IsEmployeeEscortSuspect = involvedUserEntity.IsEmployeeEscortSuspect;
                incidentUserInvolved.TypeOfForce = involvedUserEntity.TypeOfForce;
                incidentUserInvolved.InjurySeverity = involvedUserEntity.InjurySeverity;
                incidentUserInvolved.ShiftType = involvedUserEntity.ShiftType;
                incidentUserInvolved.DVERT = involvedUserEntity.DVert ? "Y" : "N";
                incidentUserInvolved.Isforecasting = involvedUserEntity.Isforecasting;
                if (involvedUserEntity.InvolType != null)
                    incidentUserInvolved.InvolvementType = involvedUserEntity.InvolType.Trim();

                unitofWork.IncidentUserInvolvedRepository.Update(incidentUserInvolved);
                unitofWork.Commit();
                #region Email Notification
                //EmailRepository email = new EmailRepository();
                //email.EmailNotification(new EmailNotificationModel
                //{
                //    Department = "Involved",
                //    EmailId = involvedUserEntity.EmailId,
                //    IncidentId = Convert.ToInt32(involvedUserEntity.IncidentId),
                //    EmployeeNumber = involvedUserEntity.EmployeeId,
                //});
                #endregion
                transaction.Complete();
            }
            return true;
        }

        private bool InsertInvolvedEmployee(InvolvedUserEntity involvedUserEntity)
        {
            using (var transaction = new TransactionScope())
            {
                //// Insert into Address
                IncidentUserEntity incidentUserEntity = new IncidentUserEntity();
                //incidentUserEntity.AddressId = involvedUserEntity.AddressId;
                //incidentUserEntity.AddressTypeId = involvedUserEntity.AddressTypeId;
                ////incidentUserEntity.Location = involvedUserEntity.Location;
                //incidentUserEntity.City = involvedUserEntity.City;
                //incidentUserEntity.State = involvedUserEntity.State;
                //incidentUserEntity.StationFacility = involvedUserEntity.StationFacility;
                //incidentUserEntity.ZipCode = involvedUserEntity.ZipCode;

                // Insert into User Detail
                incidentUserEntity.UserDetailId = involvedUserEntity.UserDetailId;
                incidentUserEntity.FirstName = involvedUserEntity.FirstName;
                incidentUserEntity.MiddleName = involvedUserEntity.MiddleName;
                incidentUserEntity.LastName = involvedUserEntity.LastName;
                incidentUserEntity.Rank = involvedUserEntity.Rank;
                incidentUserEntity.Sex = involvedUserEntity.Sex;
                incidentUserEntity.Race = involvedUserEntity.Race;
                incidentUserEntity.Height = involvedUserEntity.Height;
                incidentUserEntity.Weight = involvedUserEntity.Weight;
                incidentUserEntity.Age = involvedUserEntity.Age;
                incidentUserEntity.Shift = involvedUserEntity.Shift;
                incidentUserEntity.UnitOfAssignment = involvedUserEntity.UnitOfAssignment;
                incidentUserEntity.WorkAssignment = involvedUserEntity.WorkAssignment;
                incidentUserEntity.Dress = involvedUserEntity.SelectedDress;


                //Insert into User
                incidentUserEntity.UserDetailId = incidentUserEntity.UserDetailId;
                incidentUserEntity.UserTypeId = involvedUserEntity.UserTypeId;
                incidentUserEntity.ForceEmployeeId = involvedUserEntity.EmployeeId;
                incidentUserEntity.Active = involvedUserEntity.Active;

                //Insert into UserAddress
                //incidentUserEntity.AddressId = incidentUserEntity.AddressId;
                //incidentUserEntity.UserId = incidentUserEntity.UserId;

                // Insert into IncidentUser
                incidentUserEntity.IncidentId = Convert.ToInt32(involvedUserEntity.IncidentId);
                incidentUserEntity.UserId = incidentUserEntity.UserId;
                incidentUserEntity.SergeantId = involvedUserEntity.ReviewerId;
                incidentUserEntity.UserTypeId = involvedUserEntity.UserTypeId;
                incidentUserEntity.CreatedOn = DateTime.Now;
                SaveIncidentUser(incidentUserEntity);

                //Insert into IncidentUserInvloved
                IncidentUserInvolved incidentUserInvolved = new IncidentUserInvolved();
                incidentUserInvolved.IncidentUserId = incidentUserEntity.IncidentUserId;
                incidentUserInvolved.IndForceUsed = involvedUserEntity.IndForceUsed;
                incidentUserInvolved.IndividualCatId = involvedUserEntity.IndividualCatId;
                incidentUserInvolved.InjurySeverity = involvedUserEntity.InjurySeverity;
                incidentUserInvolved.IsDirected = involvedUserEntity.IsDirected ? "Y" : "N";
                if (incidentUserInvolved.IsDirected == "Y")
                    incidentUserInvolved.DirectedEmplId = involvedUserEntity.DirectedEmpId;
                incidentUserInvolved.IsRescue = involvedUserEntity.IsRescue ? "Y" : "N";
                incidentUserInvolved.IsMedicalAssist = involvedUserEntity.IsMedicalAssist ? "Y" : "N";
                incidentUserInvolved.IsInjured = involvedUserEntity.IsInjured ? "Y" : "N";
                incidentUserInvolved.IsTreated = involvedUserEntity.IsTreated ? "Y" : "N";
                incidentUserInvolved.IsAdmitted = involvedUserEntity.IsAdmitted ? "Y" : "N";
                incidentUserInvolved.Facility = involvedUserEntity.Facility;
                incidentUserInvolved.CoronerCaseId = involvedUserEntity.CoronerCaseId;
                incidentUserInvolved.DateOfBirth = involvedUserEntity.DateOfBirth;
                incidentUserInvolved.EmployeeItemNumber = involvedUserEntity.EmployeeItemNumber;
                incidentUserInvolved.DepartmentHireDate = involvedUserEntity.DepartmentHireDate;
                incidentUserInvolved.LastPromotionDate = involvedUserEntity.LastPromotionDate;
                incidentUserInvolved.DepartmentTenureInDays = involvedUserEntity.DepartmentTenureInDays;
                incidentUserInvolved.RankTenureIndays = involvedUserEntity.RankTenureIndays;
                incidentUserInvolved.IsEmployeeEscortSuspect = involvedUserEntity.IsEmployeeEscortSuspect;
                incidentUserInvolved.TypeOfForce = involvedUserEntity.TypeOfForce;
                incidentUserInvolved.ShiftType = involvedUserEntity.ShiftType;
                incidentUserInvolved.DVERT = involvedUserEntity.DVert ? "Y" : "N";
                incidentUserInvolved.Isforecasting = involvedUserEntity.Isforecasting;
                incidentUserInvolved.InvolvementType = involvedUserEntity.InvolType;
                unitofWork.IncidentUserInvolvedRepository.Add(incidentUserInvolved);
                unitofWork.Commit();

                //#region MapSergeantInvolved
                //SergeantInvolvedRespository repo = new SergeantInvolvedRespository();
                //repo.MapSergeantInvolved(new SergeantInvolvedModel { IncidentId = Convert.ToInt32(involvedUserEntity.IncidentId), SergeantId = involvedUserEntity.ReviewerId, InvolvedEmplId = involvedUserEntity.EmployeeId, Createdby = involvedUserEntity.LoggedId });
                //#endregion

                //#region Inserting Involved Employee Form in Incident Review Forms
                //InsertDeputyForms(involvedUserEntity, (int)Constants.UOFForms.IncidentReport);
                //InsertDeputyForms(involvedUserEntity, (int)Constants.UOFForms.CrimeAnalysisSupplementalForm);
                //InsertDeputyForms(involvedUserEntity, (int)Constants.UOFForms.InmateInjuryIllness);
                //InsertDeputyForms(involvedUserEntity, (int)Constants.UOFForms.MedicalReport);
                //InsertDeputyForms(involvedUserEntity, (int)Constants.UOFForms.CustodyServicesDivisionCrimeAnalysisSupplemental);
                ////InsertDeputyForms(incidentUserEntity, (int)Constants.UOFForms.UseofForceReviewNotice); //Commented Timebeing
                //InsertDeputyForms(involvedUserEntity, (int)Constants.UOFForms.DeputySupplementalReport);
                //InsertDeputyForms(involvedUserEntity, (int)Constants.UOFForms.DeputysUseofForceMemorandum);
                //#endregion

                //Update Workflow

                wf.InsertUpdateWorkFlow(new WorkFlowEntity { IncidentId = incidentUserEntity.IncidentId, SergeantStatus = Constants.IncidentStatus.AtSergeant.ToString() });
                wf.updateIncident(incidentUserEntity.IncidentId, Convert.ToString((int)Constants.IncidentStatus.AtSergeant));

                #region Email Notification
                EmailRepository email = new EmailRepository();
                email.EmailNotification(new EmailNotificationModel
                {
                    Department = "Involved",
                    EmailId = involvedUserEntity.EmailId,
                    IncidentId = Convert.ToInt32(involvedUserEntity.IncidentId),
                    EmployeeNumber = involvedUserEntity.EmployeeId,
                });
                if (incidentUserInvolved.IsDirected == "Y")
                {
                    email.EmailNotification(new EmailNotificationModel
                    {
                        Department = "Directed",
                        EmailId = involvedUserEntity.DirectedEmailId,
                        IncidentId = Convert.ToInt32(involvedUserEntity.IncidentId),
                        EmployeeNumber = involvedUserEntity.EmployeeId,
                    });
                }
                #endregion
                transaction.Complete();
            }
            return true;
        }



        public bool SaveSuspectUser(SuspectUserEntity suspectUserEntity)
        {
            bool result = false;
            if (suspectUserEntity.Mode == Convert.ToString(Constants.Mode.Edit))
            {
                return UpdateSuspect(suspectUserEntity, ref result);
            }
            else
            {
                result = InsertSuspect(suspectUserEntity, result);
            }
            return result;
        }

        private bool UpdateSuspect(SuspectUserEntity suspectUserEntity, ref bool result)
        {
            using (var transaction = new TransactionScope())
            {
                IncidentUserSuspect incidentUserSuspect = unitofWork.IncidentUserSuspectRepository.GetById(suspectUserEntity.IncidentUserSuspectId);
                UserDetail userDetail = unitofWork.UserDetailRepository.GetById(suspectUserEntity.UserDetailId);
                userDetail.FirstName = suspectUserEntity.FirstName;
                userDetail.MiddleName = suspectUserEntity.MiddleName;
                userDetail.LastName = suspectUserEntity.LastName;
                userDetail.Rank = suspectUserEntity.Rank;
                userDetail.Sex = suspectUserEntity.Sex;
                userDetail.Race = suspectUserEntity.Race;
                userDetail.Height = suspectUserEntity.Height;
                userDetail.Weight = suspectUserEntity.Weight;
                userDetail.Age = suspectUserEntity.Age;
                userDetail.ShiftId = suspectUserEntity.Shift;
                userDetail.DateOfBirth = suspectUserEntity.DateOfBirth;
                unitofWork.UserDetailRepository.Update(userDetail);
                unitofWork.Commit();
                //*************************
                incidentUserSuspect.BookingNumber = suspectUserEntity.BookingNumber;
                incidentUserSuspect.Armed = suspectUserEntity.Armed;
                incidentUserSuspect.AkaLastname = suspectUserEntity.AkaLastname;
                incidentUserSuspect.AkaFirstname = suspectUserEntity.AkaFirstname;
                incidentUserSuspect.AkaMiddleName = suspectUserEntity.AkaMiddleName;
                incidentUserSuspect.PrimaryPhno = suspectUserEntity.PrimaryPhno;
                incidentUserSuspect.SecondaryPhno = suspectUserEntity.SecondaryPhno;
                incidentUserSuspect.PhoneMode = suspectUserEntity.PhoneMode;
                incidentUserSuspect.PPhMode = suspectUserEntity.PPhMode;
                incidentUserSuspect.SPhMode = suspectUserEntity.SPhMode;
                incidentUserSuspect.PrimaryChargCode = suspectUserEntity.PrimaryChargCode;
                incidentUserSuspect.SecondaryChargCode = suspectUserEntity.SecondaryChargCode;
                incidentUserSuspect.CivilianResistance = suspectUserEntity.CivilianResistance;
                incidentUserSuspect.Lifethreatening = suspectUserEntity.Lifethreatening;
                incidentUserSuspect.Assulative = suspectUserEntity.Assulative;
                incidentUserSuspect.IsMentalHistory = suspectUserEntity.MentalHistory;
                incidentUserSuspect.CoronerCaseNumber = suspectUserEntity.CornerCase;
                incidentUserSuspect.Perceivedarmed = suspectUserEntity.Perceivedarmed;
                incidentUserSuspect.CivilianConfirmedarmed = suspectUserEntity.CivilianConfirmedarmed;
                incidentUserSuspect.CivilianInjurySeverity = suspectUserEntity.CivilianInjurySeverity;
                incidentUserSuspect.Forecasting = suspectUserEntity.forecasting;
                incidentUserSuspect.TypeofForce = suspectUserEntity.TypeofForce;
                incidentUserSuspect.TypeOfInjury = suspectUserEntity.TypeOfInjury;
                incidentUserSuspect.SafetyChairUsed = suspectUserEntity.SafetyChairUsed;
                incidentUserSuspect.CriminalHistory = suspectUserEntity.CriminalHistory == "True" ? "Y" : "N";
                incidentUserSuspect.TreatedOnScene = suspectUserEntity.TreatedOnScene == "True" ? "Y" : "N";
                incidentUserSuspect.HospitalAdmission = suspectUserEntity.HospitalAdmission == "True" ? "Y" : "N";
                //incidentUserSuspect.HospitalAdmission = suspectUserEntity.HospitalAdmission;
                incidentUserSuspect.InmatePhysicallyAssaultive = suspectUserEntity.InmatePhysicallyAssaultive;
                incidentUserSuspect.InmateRecalcitrant = suspectUserEntity.InmateRecalcitrant;
                incidentUserSuspect.InmateonInmateViolenceProvoked = suspectUserEntity.InmateonInmateViolenceProvoked;
                incidentUserSuspect.InmateonInmateViolence = suspectUserEntity.InmateonInmateViolence;
                incidentUserSuspect.MultiPointRestraintsUsed = suspectUserEntity.MultiPointRestraintsUsed;
                incidentUserSuspect.OthertypesofRestraints = suspectUserEntity.OthertypesofRestraints;
                incidentUserSuspect.MedicalRecordschecked = suspectUserEntity.MedicalRecordschecked;
                incidentUserSuspect.MedicalRestraintsUsed = suspectUserEntity.MedicalRestraintsUsed;
                incidentUserSuspect.ForceusedasDiscipline = suspectUserEntity.forceusedasDiscipline;
                incidentUserSuspect.CorporalPunishment = suspectUserEntity.CorporalPunishment;
                incidentUserSuspect.CellExtraction = suspectUserEntity.cellExtraction;
                incidentUserSuspect.Extractionordered = suspectUserEntity.Extractionordered;
                incidentUserSuspect.InmateHarassed = suspectUserEntity.InmateHarassed;
                incidentUserSuspect.SuspectInterviewedAwayfromInmates = suspectUserEntity.SuspectInterviewedAwayfromInmates;
                incidentUserSuspect.TransorRefuse = suspectUserEntity.TransorRefuse;
                incidentUserSuspect.OtherplannedUoF = suspectUserEntity.OtherplannedUoF;
                incidentUserSuspect.UnderInfluence = suspectUserEntity.UnderInfluence;
                incidentUserSuspect.Substance = suspectUserEntity.Substance;
                incidentUserSuspect.FactorinForce = suspectUserEntity.factorinForce;
                incidentUserSuspect.SuspectConfArmedOther = suspectUserEntity.SuspectConfArmedOther;
                incidentUserSuspect.LOCATIONOFFORCE = suspectUserEntity.SuspectLOC;
                incidentUserSuspect.IspregnantInmate = suspectUserEntity.IspregnantInmate;
                incidentUserSuspect.SpecialHandling = suspectUserEntity.SpecialHandle;
                incidentUserSuspect.SecurityLevel = suspectUserEntity.SecurityLevel;

                unitofWork.IncidentUserSuspectRepository.Update(incidentUserSuspect);
                unitofWork.Commit();
                if (incidentUserSuspect.TreatedOnScene == "Y")
                {
                    Treatment treated = null;
                    var treatment = unitofWork.TreatmentRepository.GetAll().Where(a => a.IncidentUserSuspectId == suspectUserEntity.IncidentUserSuspectId).FirstOrDefault();
                    if (treatment != null)
                    {
                        treated = unitofWork.TreatmentRepository.GetById(treatment.TreatmentId);
                        treated.TreatedBy = suspectUserEntity.TreatedName;
                        treated.PhoneNumber = suspectUserEntity.TreatedPhone;
                        treated.TreatedUnit = suspectUserEntity.TreatedUnit;
                        unitofWork.TreatmentRepository.Update(treated);
                    }
                    else
                    {
                        treated = new Treatment();
                        treated.TreatedBy = suspectUserEntity.TreatedName;
                        treated.PhoneNumber = suspectUserEntity.TreatedPhone;
                        treated.TreatedUnit = suspectUserEntity.TreatedUnit;
                        treated.IncidentUserSuspectId = suspectUserEntity.IncidentUserSuspectId;
                        unitofWork.TreatmentRepository.Add(treated);
                    }

                    unitofWork.Commit();
                }
                if (incidentUserSuspect.HospitalAdmission == "Y")
                {
                    Hospital hospital = null;
                    var hospitalExit = unitofWork.HospitalRepository.GetAll().Where(a => a.IncidentUserSuspectId == suspectUserEntity.IncidentUserSuspectId).FirstOrDefault();
                    if (hospitalExit != null)
                    {
                        hospital = unitofWork.HospitalRepository.GetById(hospitalExit.HospitalId);
                        hospital.RecdTreatmentAt = suspectUserEntity.RecdTreatmentAt;
                        hospital.HospitalAddress = suspectUserEntity.HospitalAddress;
                        hospital.HospitalPhone = suspectUserEntity.HospitalPhone;
                        hospital.HospitalAdmissionBy = suspectUserEntity.BY;
                        unitofWork.HospitalRepository.Update(hospital);
                    }
                    else
                    {
                        hospital = new Hospital();
                        hospital.RecdTreatmentAt = suspectUserEntity.RecdTreatmentAt;
                        hospital.HospitalAddress = suspectUserEntity.HospitalAddress;
                        hospital.HospitalPhone = suspectUserEntity.HospitalPhone;
                        hospital.HospitalAdmissionBy = suspectUserEntity.BY;
                        hospital.IncidentUserSuspectId = suspectUserEntity.IncidentUserSuspectId;
                        unitofWork.HospitalRepository.Add(hospital);
                    }

                    unitofWork.Commit();
                }
                if (suspectUserEntity.Interview == "True")
                {
                    IncidentUserInterview interview = null;
                    var interviewExist = unitofWork.IncidentUserInterviewRepository.GetAll().Where(a => a.IncidentUserId == suspectUserEntity.IncidentUserId).FirstOrDefault();
                    if (interviewExist != null)
                    {
                        interview.IncidentUserId = incidentUserSuspect.IncidentUserId;
                        interview.InterviewDate = suspectUserEntity.InterviewDate;
                        interview.InterviewTime = suspectUserEntity.InterviewTime;
                        unitofWork.IncidentUserInterviewRepository.Update(interview);
                    }
                    else
                    {
                        interview = new IncidentUserInterview();
                        interview.IncidentUserId = incidentUserSuspect.IncidentUserId;
                        interview.InterviewDate = suspectUserEntity.InterviewDate;
                        interview.InterviewTime = suspectUserEntity.InterviewTime;
                        unitofWork.IncidentUserInterviewRepository.Add(interview);
                    }

                    unitofWork.Commit();
                }
                transaction.Complete();
                result = true;
            }
            return result;
        }

        private bool InsertSuspect(SuspectUserEntity suspectUserEntity, bool result)
        {
            using (var transaction = new TransactionScope())
            {
                IncidentUserEntity incidentUserEntity = new IncidentUserEntity();
                suspectUserEntity.AddressTypeId = (int)Constants.AddressType.User;
                incidentUserEntity.AddressTypeId = suspectUserEntity.AddressTypeId;
                //incidentUserEntity.Location = suspectUserEntity.Location;
                incidentUserEntity.City = suspectUserEntity.City;
                incidentUserEntity.State = suspectUserEntity.State;
                incidentUserEntity.Street = suspectUserEntity.Street;
                incidentUserEntity.ZipCode = suspectUserEntity.ZipCode;

                // Insert into User Detail
                incidentUserEntity.UserDetailId = suspectUserEntity.UserDetailId;
                incidentUserEntity.FirstName = suspectUserEntity.FirstName;
                incidentUserEntity.MiddleName = suspectUserEntity.MiddleName;
                incidentUserEntity.LastName = suspectUserEntity.LastName;
                incidentUserEntity.Rank = suspectUserEntity.Rank;
                incidentUserEntity.Dress = suspectUserEntity.Dress;
                incidentUserEntity.Sex = suspectUserEntity.Sex;
                incidentUserEntity.Race = suspectUserEntity.Race;
                incidentUserEntity.Height = suspectUserEntity.Height;
                incidentUserEntity.Weight = suspectUserEntity.Weight;
                incidentUserEntity.Age = suspectUserEntity.Age;
                incidentUserEntity.Shift = suspectUserEntity.Shift;
                incidentUserEntity.DateOfBirth = suspectUserEntity.DateOfBirth;

                //Insert into User
                incidentUserEntity.ForceEmployeeId = suspectUserEntity.BookingNumber;
                incidentUserEntity.UserDetailId = incidentUserEntity.UserDetailId;
                incidentUserEntity.UserTypeId = suspectUserEntity.UserTypeId;
                incidentUserEntity.Active = suspectUserEntity.Active;

                //Insert into UserAddress
                incidentUserEntity.AddressId = incidentUserEntity.AddressId;
                incidentUserEntity.UserId = incidentUserEntity.UserId;

                // Insert into IncidentUser
                incidentUserEntity.IncidentId = suspectUserEntity.IncidentId;
                incidentUserEntity.UserId = suspectUserEntity.UserId;
                incidentUserEntity.UserTypeId = suspectUserEntity.UserTypeId;
                incidentUserEntity.SergeantId = suspectUserEntity.LoggedId;
                incidentUserEntity.CreatedOn = DateTime.Now;
                SaveIncidentUser(incidentUserEntity);

                // Insert into IncidentUserSuspect
                IncidentUserSuspect incidentUserSuspect = new IncidentUserSuspect();
                incidentUserSuspect.IncidentUserSuspectId = suspectUserEntity.IncidentUserSuspectId;
                incidentUserSuspect.IncidentUserId = incidentUserEntity.IncidentUserId;
                incidentUserSuspect.BookingNumber = suspectUserEntity.BookingNumber;
                incidentUserSuspect.Armed = suspectUserEntity.Armed;
                incidentUserSuspect.AkaLastname = suspectUserEntity.AkaLastname;
                incidentUserSuspect.AkaFirstname = suspectUserEntity.AkaFirstname;
                incidentUserSuspect.AkaMiddleName = suspectUserEntity.AkaMiddleName;
                incidentUserSuspect.PrimaryPhno = suspectUserEntity.PrimaryPhno;
                incidentUserSuspect.SecondaryPhno = suspectUserEntity.SecondaryPhno;
                incidentUserSuspect.PhoneMode = suspectUserEntity.PhoneMode;
                incidentUserSuspect.PPhMode = suspectUserEntity.PPhMode;
                incidentUserSuspect.SPhMode = suspectUserEntity.SPhMode;
                incidentUserSuspect.PrimaryChargCode = suspectUserEntity.PrimaryChargCode;
                incidentUserSuspect.SecondaryChargCode = suspectUserEntity.SecondaryChargCode;
                incidentUserSuspect.CivilianResistance = suspectUserEntity.CivilianResistance;
                incidentUserSuspect.Lifethreatening = suspectUserEntity.Lifethreatening;
                incidentUserSuspect.Assulative = suspectUserEntity.Assulative;
                incidentUserSuspect.Perceivedarmed = suspectUserEntity.Perceivedarmed;
                incidentUserSuspect.CivilianConfirmedarmed = suspectUserEntity.CivilianConfirmedarmed;
                incidentUserSuspect.CivilianInjurySeverity = suspectUserEntity.CivilianInjurySeverity;
                incidentUserSuspect.Forecasting = suspectUserEntity.forecasting;
                incidentUserSuspect.TypeofForce = suspectUserEntity.TypeofForce;
                incidentUserSuspect.TypeOfInjury = suspectUserEntity.TypeOfInjury;
                incidentUserSuspect.SafetyChairUsed = suspectUserEntity.SafetyChairUsed;
                incidentUserSuspect.CriminalHistory = suspectUserEntity.CriminalHistory == "True" ? "Y" : "N";
                incidentUserSuspect.TreatedOnScene = suspectUserEntity.TreatedOnScene == "True" ? "Y" : "N";
                incidentUserSuspect.HospitalAdmission = suspectUserEntity.HospitalAdmission == "True" ? "Y" : "N";
                //incidentUserSuspect.HospitalAdmission = suspectUserEntity.HospitalAdmission;
                incidentUserSuspect.InmatePhysicallyAssaultive = suspectUserEntity.InmatePhysicallyAssaultive;
                incidentUserSuspect.InmateRecalcitrant = suspectUserEntity.InmateRecalcitrant;
                incidentUserSuspect.InmateonInmateViolenceProvoked = suspectUserEntity.InmateonInmateViolenceProvoked;
                incidentUserSuspect.InmateonInmateViolence = suspectUserEntity.InmateonInmateViolence;
                incidentUserSuspect.MultiPointRestraintsUsed = suspectUserEntity.MultiPointRestraintsUsed;
                incidentUserSuspect.OthertypesofRestraints = suspectUserEntity.OthertypesofRestraints;
                incidentUserSuspect.MedicalRecordschecked = suspectUserEntity.MedicalRecordschecked;
                incidentUserSuspect.MedicalRestraintsUsed = suspectUserEntity.MedicalRestraintsUsed;
                incidentUserSuspect.ForceusedasDiscipline = suspectUserEntity.forceusedasDiscipline;
                incidentUserSuspect.CorporalPunishment = suspectUserEntity.CorporalPunishment;
                incidentUserSuspect.CellExtraction = suspectUserEntity.cellExtraction;
                incidentUserSuspect.Extractionordered = suspectUserEntity.Extractionordered;
                incidentUserSuspect.InmateHarassed = suspectUserEntity.InmateHarassed;
                incidentUserSuspect.SuspectInterviewedAwayfromInmates = suspectUserEntity.SuspectInterviewedAwayfromInmates;
                incidentUserSuspect.TransorRefuse = suspectUserEntity.TransorRefuse;
                incidentUserSuspect.OtherplannedUoF = suspectUserEntity.OtherplannedUoF;
                incidentUserSuspect.UnderInfluence = suspectUserEntity.UnderInfluence;
                incidentUserSuspect.Substance = suspectUserEntity.Substance;
                incidentUserSuspect.FactorinForce = suspectUserEntity.factorinForce;
                incidentUserSuspect.FORCEUSED = suspectUserEntity.ForceUsed;
                incidentUserSuspect.LOCATIONOFFORCE = suspectUserEntity.SuspectLOC;
                incidentUserSuspect.SuspectConfArmedOther = suspectUserEntity.SuspectConfArmedOther;
                incidentUserSuspect.CoronerCaseNumber = suspectUserEntity.CornerCase;
                incidentUserSuspect.IsMentalHistory = suspectUserEntity.MentalHistory;
                incidentUserSuspect.IspregnantInmate = suspectUserEntity.IspregnantInmate;
                incidentUserSuspect.SpecialHandling = suspectUserEntity.SpecialHandle;
                incidentUserSuspect.SecurityLevel = suspectUserEntity.SecurityLevel;

                unitofWork.IncidentUserSuspectRepository.Add(incidentUserSuspect);
                unitofWork.Commit();
                suspectUserEntity.IncidentUserSuspectId = incidentUserSuspect.IncidentUserSuspectId;
                if (incidentUserSuspect.TreatedOnScene == "Y")
                {
                    Treatment treated = new Treatment();
                    treated.IncidentUserSuspectId = suspectUserEntity.IncidentUserSuspectId;
                    treated.TreatedBy = suspectUserEntity.TreatedName;
                    treated.PhoneNumber = suspectUserEntity.TreatedPhone;
                    treated.TreatedUnit = suspectUserEntity.TreatedUnit;
                    unitofWork.TreatmentRepository.Add(treated);
                    unitofWork.Commit();
                }
                if (incidentUserSuspect.HospitalAdmission == "Y")
                {
                    Hospital hospital = new Hospital();
                    hospital.RecdTreatmentAt = suspectUserEntity.RecdTreatmentAt;
                    hospital.HospitalAddress = suspectUserEntity.HospitalAddress;
                    hospital.HospitalAdmissionBy = suspectUserEntity.HospitalAdmission;
                    hospital.HospitalPhone = suspectUserEntity.HospitalPhone;
                    hospital.IncidentUserSuspectId = incidentUserSuspect.IncidentUserSuspectId;
                    unitofWork.HospitalRepository.Add(hospital);
                    unitofWork.Commit();
                }
                if (suspectUserEntity.Interview == "True")
                {
                    IncidentUserInterview Int = new IncidentUserInterview();
                    Int.IncidentUserId = incidentUserEntity.IncidentUserId;
                    Int.InterviewDate = suspectUserEntity.InterviewDate;
                    Int.InterviewTime = suspectUserEntity.InterviewTime;
                    Int.IsAudioTape = suspectUserEntity.Audiotape == "True" ? "Y" : "N";
                    Int.IsVideoType = suspectUserEntity.Videotape == "True" ? "Y" : "N";
                    Int.IsInjuryPhoto = suspectUserEntity.PhotosofInjuries == "True" ? "Y" : "N";
                    Int.IsHearingAdmits = suspectUserEntity.Announcements == "True" ? "Y" : "N";
                    Int.AudioPath = suspectUserEntity.AudioTapePath;
                    Int.VideoPath = suspectUserEntity.VideoTapePath;
                    Int.PhotosPath = suspectUserEntity.InjuryPhotosPath;
                    unitofWork.IncidentUserInterviewRepository.Add(Int);
                    unitofWork.Commit();
                }
                transaction.Complete();
                result = true;
            }
            return result;
        }

        public bool SaveWitnessUser(WitnessUserEntity witnessUserEntity)
        {
            bool result = false;
            if (witnessUserEntity.Mode == Convert.ToString(Constants.Mode.Edit))
            {
                result = UpdateWitness(witnessUserEntity, result);
            }
            else
            {
                result = InsertWitness(witnessUserEntity, result);
            }
            return result;
        }

        private bool UpdateWitness(WitnessUserEntity witnessUserEntity, bool result)
        {
            using (var transaction = new TransactionScope())
            {
                IncidentUserWitnes incidentUserWitnes = unitofWork.IncidentUserWitnessRepository.GetById(witnessUserEntity.IncidentUserWitnessId);
                UserDetail userDetail = unitofWork.UserDetailRepository.GetById(witnessUserEntity.UserDetailId);
                Addres addressDetails = unitofWork.AddressRepository.GetById(witnessUserEntity.AddressId);
                userDetail.FirstName = witnessUserEntity.FirstName;
                userDetail.MiddleName = witnessUserEntity.MiddleName;
                userDetail.LastName = witnessUserEntity.LastName;

                if (witnessUserEntity.UserTypeId == (int)Constants.UserType.NonEmpWitness)
                {
                    //Update Witness Address
                    addressDetails.City = witnessUserEntity.City;
                    addressDetails.ZipCode = witnessUserEntity.ZipCode;
                    addressDetails.Street = witnessUserEntity.Street;
                    userDetail.Age = witnessUserEntity.Age;
                    userDetail.DateOfBirth = witnessUserEntity.DateOfBirth;
                }
                else if (witnessUserEntity.UserTypeId == (int)Constants.UserType.EmployeeWitness)
                {
                    userDetail.ShiftId = witnessUserEntity.Shift;
                    incidentUserWitnes.ShiftType = witnessUserEntity.ShiftType;
                    userDetail.UnitOfAssignment = witnessUserEntity.UnitOfAssignment;
                    userDetail.WorkAssignment = witnessUserEntity.WorkAssignment;
                    incidentUserWitnes.WitnessIntAwayfromInmates = witnessUserEntity.WitnessIntAwayfromInmates;
                }
                unitofWork.UserDetailRepository.Update(userDetail);
                unitofWork.IncidentUserWitnessRepository.Update(incidentUserWitnes);
                unitofWork.Commit();
                transaction.Complete();
                result = true;
            }
            return result;
        }

        private bool InsertWitness(WitnessUserEntity witnessUserEntity, bool result)
        {
            using (var transaction = new TransactionScope())
            {
                witnessUserEntity.AddressTypeId = (int)Constants.AddressType.User;
                IncidentUserEntity incidentUserEntity = new IncidentUserEntity();
                if (witnessUserEntity.UserTypeId == (int)Constants.UserType.NonEmpWitness)
                {
                    // Insert into Address
                    incidentUserEntity.AddressId = witnessUserEntity.AddressId;
                    incidentUserEntity.AddressTypeId = witnessUserEntity.AddressTypeId;
                    incidentUserEntity.City = witnessUserEntity.City;
                    incidentUserEntity.ZipCode = witnessUserEntity.ZipCode;
                    incidentUserEntity.Street = witnessUserEntity.Street;
                    incidentUserEntity.ForceEmployeeId = witnessUserEntity.BookingNum;
                    incidentUserEntity.InmateType = witnessUserEntity.InmateType;

                }
                // Insert into User Detail
                incidentUserEntity.UserDetailId = witnessUserEntity.UserDetailId;
                incidentUserEntity.FirstName = witnessUserEntity.FirstName;
                incidentUserEntity.MiddleName = witnessUserEntity.MiddleName;
                incidentUserEntity.LastName = witnessUserEntity.LastName;
                incidentUserEntity.Age = witnessUserEntity.Age;
                incidentUserEntity.DateOfBirth = witnessUserEntity.DateOfBirth;

                if (witnessUserEntity.UserTypeId == (int)Constants.UserType.EmployeeWitness)
                {
                    incidentUserEntity.Shift = witnessUserEntity.Shift;

                    incidentUserEntity.UnitOfAssignment = witnessUserEntity.UnitOfAssignment;
                    incidentUserEntity.WorkAssignment = witnessUserEntity.WorkAssignment;
                    incidentUserEntity.ForceEmployeeId = witnessUserEntity.EmployeeId;

                }
                //Insert into User
                incidentUserEntity.UserDetailId = incidentUserEntity.UserDetailId;
                incidentUserEntity.UserTypeId = witnessUserEntity.UserTypeId;

                incidentUserEntity.Active = witnessUserEntity.Active;


                // Insert into IncidentUser
                incidentUserEntity.IncidentId = witnessUserEntity.IncidentId;
                incidentUserEntity.UserId = witnessUserEntity.UserId;
                incidentUserEntity.UserTypeId = witnessUserEntity.UserTypeId;
                incidentUserEntity.CreatedOn = DateTime.Now;
                incidentUserEntity.SergeantId = witnessUserEntity.LoggedId;

                //Insert User Contact
                incidentUserEntity.PrimaryPhone = witnessUserEntity.PrimaryPhone;
                incidentUserEntity.SecondaryPhone = witnessUserEntity.SecondaryPhone;

                SaveIncidentUser(incidentUserEntity);

                // Insert into IncidentUserWiteness
                IncidentUserWitnes incidentUserWitness = new IncidentUserWitnes();
                incidentUserWitness.IncidentUserWitnessId = witnessUserEntity.IncidentUserWitnessId;
                incidentUserWitness.IncidentUserId = incidentUserEntity.IncidentUserId;
                incidentUserWitness.ShiftType = witnessUserEntity.ShiftType;
                incidentUserWitness.IsWitness = witnessUserEntity.IsWitness;
                incidentUserWitness.IsPresent = witnessUserEntity.IsPresent;
                incidentUserWitness.WitnessIntAwayfromInmates = witnessUserEntity.WitnessIntAwayfromInmates;
                incidentUserWitness.InmateType = witnessUserEntity.InmateType;
                incidentUserWitness.TransorRefuse = witnessUserEntity.TransorRefuse;
                unitofWork.IncidentUserWitnessRepository.Add(incidentUserWitness);
                unitofWork.Commit();
                if (witnessUserEntity.UserTypeId == (int)Constants.UserType.EmployeeWitness)
                {
                    EmailRepository email = new EmailRepository();
                    email.EmailNotification(new EmailNotificationModel
                    {
                        Department = "Witness",
                        EmailId = witnessUserEntity.EmailId,
                        IncidentId = witnessUserEntity.IncidentId,
                        EmployeeNumber = witnessUserEntity.EmployeeId,
                    });
                }

                transaction.Complete();
                result = true;
            }
            return result;
        }

        public bool SaveDuptiesInfo(WitnessUserEntity witnessUserEntity)
        {
            bool result = false;
            if (witnessUserEntity.Mode == Convert.ToString(Constants.Mode.Edit))
            {
                result = UpdateDupties(witnessUserEntity, result);
            }
            else
            {
                result = InsertDupties(witnessUserEntity, result);
            }
            return result;
        }

        private bool UpdateDupties(WitnessUserEntity witnessUserEntity, bool result)
        {
            using (var transaction = new TransactionScope())
            {
                IncidentUserWitnes incidentUserWitnes = unitofWork.IncidentUserWitnessRepository.GetById(witnessUserEntity.IncidentUserWitnessId);
                if (incidentUserWitnes == null)
                {
                    InsertDupties(witnessUserEntity, result);
                }
                else
                {
                    UserDetail userDetail = unitofWork.UserDetailRepository.GetById(witnessUserEntity.UserDetailId);
                    userDetail.FirstName = witnessUserEntity.FirstName;
                    userDetail.MiddleName = witnessUserEntity.MiddleName;
                    userDetail.LastName = witnessUserEntity.LastName;
                    userDetail.Age = witnessUserEntity.Age;
                    userDetail.DateOfBirth = witnessUserEntity.DateOfBirth;
                    userDetail.Rank = witnessUserEntity.Rank;
                    unitofWork.UserDetailRepository.Update(userDetail);
                    incidentUserWitnes.IsPresent = witnessUserEntity.IsPresent.Trim();
                    incidentUserWitnes.IsWitness = witnessUserEntity.IsWitness.Trim();
                    unitofWork.IncidentUserWitnessRepository.Update(incidentUserWitnes);
                    unitofWork.Commit();
                }
                transaction.Complete();
                result = true;
            }
            return result;
        }

        private bool InsertDupties(WitnessUserEntity witnessUserEntity, bool result)
        {
            using (var transaction = new TransactionScope())
            {

                IncidentUserEntity incidentUserEntity = new IncidentUserEntity();
                // Insert into User Detail
                incidentUserEntity.UserDetailId = witnessUserEntity.UserDetailId;
                incidentUserEntity.FirstName = witnessUserEntity.FirstName;
                incidentUserEntity.MiddleName = witnessUserEntity.MiddleName;
                incidentUserEntity.LastName = witnessUserEntity.LastName;
                incidentUserEntity.Rank = witnessUserEntity.Rank;

                //Insert into User
                incidentUserEntity.ForceUserId = witnessUserEntity.EmployeeId;
                incidentUserEntity.UserDetailId = incidentUserEntity.UserDetailId;
                incidentUserEntity.UserTypeId = witnessUserEntity.UserTypeId;
                incidentUserEntity.SergeantId = witnessUserEntity.LoggedId;
                incidentUserEntity.Active = witnessUserEntity.Active;

                // Insert into IncidentUser
                incidentUserEntity.IncidentId = witnessUserEntity.IncidentId;
                incidentUserEntity.UserId = witnessUserEntity.UserId;
                incidentUserEntity.UserTypeId = witnessUserEntity.UserTypeId;

                SaveIncidentUser(incidentUserEntity);

                // Insert into IncidentUserWiteness
                IncidentUserWitnes incidentUserWitness = new IncidentUserWitnes();
                incidentUserWitness.IncidentUserWitnessId = witnessUserEntity.IncidentUserWitnessId;
                incidentUserWitness.IncidentUserId = incidentUserEntity.IncidentUserId;
                incidentUserWitness.IsWitness = witnessUserEntity.IsWitness;
                incidentUserWitness.IsPresent = witnessUserEntity.IsPresent;
                unitofWork.IncidentUserWitnessRepository.Add(incidentUserWitness);
                unitofWork.Commit();

                #region Update and Insert into Incident Investigation Officer table
                if (witnessUserEntity.UserTypeId == (int)Constants.UserType.Supervisor)
                {
                    List<IncidentInvestigationOfficer> InvestModel = unitofWork.InvestigationOfficerRespository.GetAll().Where(x => x.IncidentId == witnessUserEntity.IncidentId && x.Status == "Active").ToList();
                    if (InvestModel.Count > 0)
                    {
                        foreach (var item in InvestModel)
                        {
                            if (item != null)
                            {
                                item.Status = "Inactive";
                                unitofWork.InvestigationOfficerRespository.Update(item);
                                unitofWork.Commit();
                            }
                        }
                    }

                    var model = new IncidentInvestigationOfficer();
                    model.IncidentId = witnessUserEntity.IncidentId;
                    model.EmployeeId = witnessUserEntity.EmployeeId;
                    model.FirstName = witnessUserEntity.FirstName;
                    model.LastName = witnessUserEntity.LastName;
                    model.Rank = witnessUserEntity.Rank;
                    model.Status = "Active";
                    unitofWork.InvestigationOfficerRespository.Add(model);
                    unitofWork.Commit();

                }
                #endregion

                //#region Update Incient Workflow Table, and Review Forms table
                //if (witnessUserEntity.UserTypeId == (int)Constants.UserType.WatchCommander)
                //{
                //    UoFWorkFlowRepository wf = new UoFWorkFlowRepository();
                //    wf.InsertUpdateWorkFlow(new WorkFlowEntity { IncidentId = witnessUserEntity.IncidentId, WCID = witnessUserEntity.EmployeeId, WCStatus = Constants.Status.Pending.ToString() });

                //    List<IncidentFormReview> SRmodel = unitofWork.ReviewRespository.GetAll().Where(x => x.IncidentID == witnessUserEntity.IncidentId).ToList();
                //    foreach (var item in SRmodel)
                //    {
                //        if (item != null)
                //        {
                //            item.WCID = witnessUserEntity.EmployeeId;
                //            if (item.InvolvedRole == Constants.UserRoles.DSG.ToString())
                //            {
                //                if ((item.InvolvedStatus == Constants.Status.DON.ToString() || item.InvolvedStatus == Constants.Status.Completed.ToString()) && item.SergeantStatus == Constants.Status.Completed.ToString())
                //                    item.WCStatus = Constants.Status.Completed.ToString();
                //                else
                //                    item.WCStatus = Constants.Status.NotReady.ToString();
                //            }
                //            else if (item.InvolvedRole == Constants.UserRoles.SGT.ToString())
                //            {
                //                if ((item.InvolvedStatus == Constants.Status.DON.ToString() || item.InvolvedStatus == Constants.Status.Completed.ToString()))
                //                    item.WCStatus = Constants.Status.Pending.ToString();
                //                else
                //                    item.WCStatus = Constants.Status.NotReady.ToString();
                //            }

                //            unitofWork.ReviewRespository.Update(item);
                //            unitofWork.Commit();
                //        }
                //    }
                //    #region Inserting Watch Commander Forms
                //    //Insert WC Review forms

                //    repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                //    {
                //        IncidentID = witnessUserEntity.IncidentId,
                //        FormId = (int)Constants.UOFForms.WatchCommanderUseofForceReview,
                //        SubmitteduserRole = Constants.UserRoles.WC.ToString(),
                //        SubmittedStatus = Constants.Status.Pending.ToString(),
                //        SubmittedEmpId = witnessUserEntity.EmployeeId,
                //        ReviewerRole = Constants.UserRoles.CAPT.ToString(),
                //        WCStatus = Constants.Status.Pending.ToString(),
                //        WCID = witnessUserEntity.EmployeeId,
                //    });

                //    ////Insert UOF Review Notices forms
                //    //repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                //    //{
                //    //    IncidentID = witnessUserEntity.IncidentId,
                //    //    FormId = (int)Constants.UOFForms.UseofForceReviewNotice,
                //    //    SubmitteduserRole = Constants.UserRoles.WC.ToString(),
                //    //    SubmittedStatus = Constants.Status.Pending.ToString(),
                //    //    SubmittedEmpId = witnessUserEntity.EmployeeId,
                //    //    ReviewerRole = Constants.UserRoles.CAPT.ToString(),
                //    //    WCStatus = Constants.Status.Pending.ToString(),
                //    //    WCID = witnessUserEntity.EmployeeId,
                //    //});

                //    //Inserting INcide Category 3 IAB Mandatory Form.
                //    int? Id = (from ind in unitofWork.IncidentRepository.GetAll()
                //               where ind.IncidentId == witnessUserEntity.IncidentId
                //               select new { ind.IncidentCategoryId }).Single().IncidentCategoryId;
                //    if (Convert.ToInt32(Id) == 3)
                //    {
                //        repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                //        {
                //            IncidentID = witnessUserEntity.IncidentId,
                //            FormId = (int)Constants.UOFForms.IABMandatoryForm,
                //            SubmitteduserRole = Constants.UserRoles.WC.ToString(),
                //            SubmittedStatus = Constants.Status.Pending.ToString(),
                //            SubmittedEmpId = witnessUserEntity.EmployeeId,
                //            ReviewerRole = Constants.UserRoles.CAPT.ToString(),
                //            WCStatus = Constants.Status.Pending.ToString(),
                //            WCID = witnessUserEntity.EmployeeId,
                //        });
                //    }
                //    #endregion
                //}
                //#endregion

                #region Email Notification
                EmailRepository email = new EmailRepository();
                email.EmailNotification(new EmailNotificationModel
                {
                    Department = witnessUserEntity.UserTypeId == 5 ? "Supervisory Information" : witnessUserEntity.UserTypeId == 8 ? "Deputy" : "Supervisor",
                    EmailId = witnessUserEntity.EmailId,
                    IncidentId = witnessUserEntity.IncidentId,
                    EmployeeNumber = witnessUserEntity.EmployeeId,
                });
                #endregion
                transaction.Complete();
                result = true;
            }
            return result;
        }

        public bool SaveCanineInfo(CanineEntity canineEntity)
        {
            bool result = false;
            if (canineEntity.Mode == Convert.ToString(Constants.Mode.Edit))
            {
                result = UpdateCanine(canineEntity, result);
            }
            else
            {
                result = InsertCanine(canineEntity, result);
            }
            return result;
        }

        private bool UpdateCanine(CanineEntity canineEntity, bool result)
        {
            using (var transaction = new TransactionScope())
            {
                IncidentCanineDeployment canineDeployment = unitofWork.IncidentCanineDeploymentRepository.GetById(canineEntity.IncidentCanineDeploymentId);
                var canineHandler = unitofWork.HandlerRepository.GetAll();
                List<Handler> handlers = canineHandler.Where(x => x.IncidentCanineDeploymentId == canineEntity.IncidentCanineDeploymentId).ToList();
                canineDeployment.Area = canineEntity.Area ? "Y" : "N";
                canineDeployment.Building = canineEntity.Building ? "Y" : "N";
                canineDeployment.TOSOther = canineEntity.TOSOther ? "Y" : "N";
                canineDeployment.ApprehendingSuspect = canineEntity.ApprehendingSuspect ? "Y" : "N";
                canineDeployment.ConductingSearch = canineEntity.ConductingSearch ? "Y" : "N";
                canineDeployment.ProtectingHandler = canineEntity.ProtectingHandler ? "Y" : "N";
                canineDeployment.BOWOtherReason = canineEntity.BOWOtherReason == "True" ? "Y" : "N";
                canineDeployment.Bite = canineEntity.Bite ? "Y" : "N";
                canineDeployment.TOIOther = canineEntity.TOIOther ? "Y" : "N";
                canineDeployment.BYAeroUnit = canineEntity.BYAeroUnit ? "Y" : "N";
                canineDeployment.ByRadioCar = canineEntity.ByRadioCar ? "Y" : "N";
                canineDeployment.English = canineEntity.English ? "Y" : "N";
                canineDeployment.Spanish = canineEntity.Spanish ? "Y" : "N";
                canineDeployment.Recorded = canineEntity.Recorded ? "Y" : "N";
                canineDeployment.AnnouncementsNoneReason = canineEntity.AnnouncementsNoneReason;
                canineDeployment.AnnouncementMadeby = canineEntity.AnnouncementMadeby ? "Y" : "N";
                canineDeployment.AnnouncementMadebyReason = canineEntity.AnnouncementMadebyReason;
                canineDeployment.CriminalHistory = canineEntity.CriminalHistory;
                canineDeployment.Notifications = canineEntity.Notifications;

                unitofWork.IncidentCanineDeploymentRepository.Update(canineDeployment);
                unitofWork.Commit();
                foreach (HandlerEntity item in canineEntity.Handlers)
                {
                    foreach (var hd in handlers)
                    {
                        if (hd.HandlerType == item.HandlerType)
                        {
                            hd.HandlerNumber = item.HandlerNumber;
                            hd.HandlerName = item.HandlerName;
                            hd.CanineNumber = item.CanineNumber;
                            hd.UnitNumber = item.UnitNumber;
                            unitofWork.HandlerRepository.Update(hd);
                            unitofWork.Commit();
                        }
                    }
                }
                transaction.Complete();
                result = true;
            }
            return result;
        }

        private bool InsertCanine(CanineEntity canineEntity, bool result)
        {
            using (var transaction = new TransactionScope())
            {
                // Insert into IncidentCanine
                IncidentCanineDeployment canineDeployment = new IncidentCanineDeployment();
                canineDeployment.IncidentId = canineEntity.IncidentId;
                canineDeployment.Area = canineEntity.Area ? "Y" : "N";
                canineDeployment.Building = canineEntity.Building ? "Y" : "N";
                canineDeployment.TOSOther = canineEntity.TOSOther ? "Y" : "N";
                canineDeployment.ApprehendingSuspect = canineEntity.ApprehendingSuspect ? "Y" : "N";
                canineDeployment.ConductingSearch = canineEntity.ConductingSearch ? "Y" : "N";
                canineDeployment.ProtectingHandler = canineEntity.ProtectingHandler ? "Y" : "N";
                canineDeployment.BOWOtherReason = canineEntity.BOWOtherReason;
                canineDeployment.Bite = canineEntity.Bite ? "Y" : "N";
                canineDeployment.TOIOther = canineEntity.TOIOther ? "Y" : "N";
                canineDeployment.BYAeroUnit = canineEntity.BYAeroUnit ? "Y" : "N";
                canineDeployment.ByRadioCar = canineEntity.ByRadioCar ? "Y" : "N";
                canineDeployment.English = canineEntity.English ? "Y" : "N";
                canineDeployment.Spanish = canineEntity.Spanish ? "Y" : "N";
                canineDeployment.Recorded = canineEntity.Recorded ? "Y" : "N";
                canineDeployment.AnnouncementsNoneReason = canineEntity.AnnouncementsNoneReason;
                canineDeployment.AnnouncementMadeby = canineEntity.AnnouncementMadeby ? "Y" : "N";
                canineDeployment.AnnouncementMadebyReason = canineEntity.AnnouncementMadebyReason;
                canineDeployment.CriminalHistory = canineEntity.CriminalHistory;
                canineDeployment.Notifications = canineEntity.Notifications;
                canineDeployment.CreatedBy = canineEntity.LoggedId;
                canineDeployment.CreatedOn = DateTime.Now;
                unitofWork.IncidentCanineDeploymentRepository.Add(canineDeployment);
                unitofWork.Commit();
                canineEntity.IncidentCanineDeploymentId = canineDeployment.IncidentCanineDeploymentId;
                //Insert into Handler, based on Canine Deployment id
                foreach (HandlerEntity item in canineEntity.Handlers)
                {
                    Handler handler = new Handler();
                    handler.IncidentCanineDeploymentId = canineEntity.IncidentCanineDeploymentId;
                    handler.HandlerNumber = item.HandlerNumber;
                    handler.HandlerName = item.HandlerName;
                    handler.CanineNumber = item.CanineNumber;
                    handler.UnitNumber = item.UnitNumber;
                    handler.HandlerType = item.HandlerType;
                    unitofWork.HandlerRepository.Add(handler);
                    unitofWork.Commit();
                }
                transaction.Complete();
                result = true;
            }
            return result;
        }
        public List<StatisticalEntity> GetStaticalData(int incidentId)
        {
            var list = (from incidentStatistical in unitofWork.IncidentStatisticalRepository.GetAll()
                        where incidentStatistical.IncidentId == incidentId
                        select new StatisticalEntity
                        {
                            IncidentId = incidentStatistical.IncidentId,
                            ForcedUsedById = incidentStatistical.IncidentUsedBy,
                            ForcedUsedAgainstId = incidentStatistical.IncidentAgainstBy,
                            MethodCode = incidentStatistical.Method,
                            InjuryTypeCode = incidentStatistical.InjuryType,
                            BodyPartInvolvedCode = incidentStatistical.BodyPartInvolved
                        }).ToList();

            return list;
        }
        public CanineEntity GetCanineInfo(int? incidentId)
        {
            int _incidentId = Convert.ToInt32(incidentId);
            var canineEnt = (from canine in unitofWork.IncidentCanineDeploymentRepository.GetAll()
                             where canine.IncidentId == _incidentId
                             select new CanineEntity
                             {
                                 IncidentCanineDeploymentId = canine.IncidentCanineDeploymentId,
                                 IncidentId = canine.IncidentId,
                                 Area = canine.Area.Trim() == "Y" ? true : false,
                                 Building = canine.Building.Trim() == "Y" ? true : false,
                                 TOSOther = canine.TOSOther.Trim() == "Y" ? true : false,
                                 ApprehendingSuspect = canine.ApprehendingSuspect == "Y" ? true : false,
                                 ConductingSearch = canine.ConductingSearch == "Y" ? true : false,
                                 ProtectingHandler = canine.ProtectingHandler.Trim() == "Y" ? true : false,
                                 BOWOtherReason = canine.BOWOtherReason.Trim(),
                                 Bite = canine.Bite.Trim() == "Y" ? true : false,
                                 TOIOther = canine.TOIOther.Trim() == "Y" ? true : false,
                                 BYAeroUnit = canine.BYAeroUnit.Trim() == "Y" ? true : false,
                                 ByRadioCar = canine.ByRadioCar.Trim() == "Y" ? true : false,
                                 English = canine.English.Trim() == "Y" ? true : false,
                                 Spanish = canine.Spanish.Trim() == "Y" ? true : false,
                                 Recorded = canine.Recorded.Trim() == "Y" ? true : false,
                                 //AnnouncementsBy = canine.AnnouncementMadeby,
                                 //AnnouncementsIn = canine.AnnouncementsIn,
                                 AnnouncementsNoneReason = canine.AnnouncementsNoneReason.Trim(),
                                 AnnouncementMadeby = canine.AnnouncementMadeby == "Y" ? true : false,
                                 AnnouncementMadebyReason = canine.AnnouncementMadebyReason.Trim(),
                                 CriminalHistory = canine.CriminalHistory,
                                 Notifications = canine.Notifications,
                             }).FirstOrDefault();
            if (canineEnt != null)
            {
                List<HandlerEntity> handlers = (from hd in unitofWork.HandlerRepository.GetAll() where canineEnt.IncidentCanineDeploymentId == hd.IncidentCanineDeploymentId select new HandlerEntity { HandlerId = hd.HandlerId, HandlerName = hd.HandlerName, HandlerNumber = hd.HandlerNumber, CanineNumber = hd.CanineNumber, UnitNumber = hd.UnitNumber, HandlerType = hd.HandlerType.Trim(), IncidentCanineDeploymentId = hd.IncidentCanineDeploymentId }).ToList();
                canineEnt.Handlers = handlers;
            }
            return canineEnt;
        }

        public List<InvolvedUserEntity> GetInvolvedUser()
        {
            var involvedUserList = (from involvedUser in unitofWork.IncidentUserInvolvedRepository.GetAll()
                                    join incidentUser in Get() on involvedUser.IncidentUserId equals incidentUser.IncidentUserId
                                    select new InvolvedUserEntity
                                    {
                                        IncidentUserInvolvedId = involvedUser.IncidentUserInvolvedId,
                                        IncidentUserId = involvedUser.IncidentUserId.GetValueOrDefault(),
                                        IncidentId = incidentUser.IncidentId,
                                        EmployeeId = incidentUser.ForceUserId,
                                        FirstName = incidentUser.FirstName + ' ' + incidentUser.LastName,
                                        TypeOfForce = involvedUser.TypeOfForce,
                                        InjurySeverity = involvedUser.InjurySeverity,
                                        Isforecasting = involvedUser.Isforecasting,
                                        IndForceUsed = involvedUser.IndForceUsed,
                                        IndividualCatId = involvedUser.IndividualCatId,
                                        IsDirected = involvedUser.IsDirected == "Y" ? true : false,
                                        IsRescue = involvedUser.IsRescue == "Y" ? true : false,
                                        IsMedicalAssist = involvedUser.IsMedicalAssist == "Y" ? true : false,
                                        IsInjured = involvedUser.IsInjured == "Y" ? true : false,
                                        IsTreated = involvedUser.IsTreated == "Y" ? true : false,
                                        IsAdmitted = involvedUser.IsAdmitted == "Y" ? true : false,
                                        Facility = involvedUser.Facility,
                                        CoronerCaseId = involvedUser.CoronerCaseId,
                                        DateOfBirth = involvedUser.DateOfBirth,
                                        EmployeeItemNumber = involvedUser.EmployeeItemNumber,
                                        DepartmentHireDate = involvedUser.DepartmentHireDate,
                                        LastPromotionDate = involvedUser.LastPromotionDate,
                                        DepartmentTenureInDays = involvedUser.DepartmentTenureInDays,
                                        RankTenureIndays = involvedUser.RankTenureIndays,
                                        IsEmployeeEscortSuspect = involvedUser.IsEmployeeEscortSuspect

                                    }).ToList();

            return involvedUserList;
        }

        public List<InvolvedUserEntity> GetInvolvedUser(int? incidentId)
        {
            int _incidentId = Convert.ToInt32(incidentId);
            //IncidentUser incidUser = unitofWork.IncidentUserRepository.GetAll().Where(x => x.IncidentId == _incidentId && x.UserTypeId == (int)UOF.Common.Utilities.Constants.UserType.InvolvedEmployee).FirstOrDefault();
            //int _IncidentUserId = Convert.ToInt32(incidUser.IncidentUserId);
            var list = (from involvedUsers in unitofWork.IncidentUserInvolvedRepository.GetAll()
                        join incidentUser in unitofWork.IncidentUserRepository.GetAll() on involvedUsers.IncidentUserId equals incidentUser.IncidentUserId
                        join user in unitofWork.UserRepository.GetAll() on incidentUser.UserId equals user.UserId
                        join userDetail in unitofWork.UserDetailRepository.GetAll() on user.UserDetailId equals userDetail.UserDetailId
                        //join reviewer in unitofWork.SergeantInvolvedRepository.GetAll() on user.ForceEmployeeId equals reviewer.InvolvedEmplId
                        where incidentUser.IncidentId == _incidentId && user.Active == true

                        select new InvolvedUserEntity
                        {
                            IncidentUserInvolvedId = involvedUsers.IncidentUserInvolvedId,
                            IncidentUserId = incidentUser.IncidentUserId,
                            UserDetailId = userDetail.UserDetailId,
                            IncidentId = _incidentId,
                            EmployeeId = user.ForceEmployeeId,
                            FirstName = userDetail.FirstName,
                            LastName = userDetail.LastName,
                            MiddleName = userDetail.MiddleName,
                            Rank = userDetail.Rank,
                            Sex = userDetail.Sex.Trim(),
                            SelectedDress = userDetail.Dress,
                            Dress = userDetail.Dress,
                            Age = userDetail.Age,
                            Race = userDetail.Race,
                            Height = userDetail.Height,
                            Weight = userDetail.Weight,
                            Shift = userDetail.ShiftId,
                            UnitOfAssignment = userDetail.UnitOfAssignment,
                            WorkAssignment = userDetail.WorkAssignment,
                            TypeOfForce = involvedUsers.TypeOfForce,
                            InjurySeverity = involvedUsers.InjurySeverity,
                            Isforecasting = involvedUsers.Isforecasting.Trim(),
                            IndForceUsed = involvedUsers.IndForceUsed.Trim(),
                            IndividualCatId = involvedUsers.IndividualCatId,
                            IsDirected = involvedUsers.IsDirected.Trim() == "Y" ? true : false,
                            IsRescue = involvedUsers.IsRescue.Trim() == "Y" ? true : false,
                            IsMedicalAssist = involvedUsers.IsMedicalAssist.Trim() == "Y" ? true : false,
                            IsInjured = involvedUsers.IsInjured.Trim() == "Y" ? true : false,
                            IsTreated = involvedUsers.IsTreated.Trim() == "Y" ? true : false,
                            IsAdmitted = involvedUsers.IsAdmitted.Trim() == "Y" ? true : false,
                            RM = (involvedUsers.IsRescue.Trim() != null ? "R" : (involvedUsers.IsMedicalAssist.Trim() != null ? "M" : "")),
                            ITA = (involvedUsers.IsInjured.Trim() != null ? "I" : (involvedUsers.IsTreated.Trim() != null ? "T" : (involvedUsers.IsAdmitted.Trim() != null ? "A" : ""))),
                            Facility = involvedUsers.Facility,
                            CoronerCaseId = involvedUsers.CoronerCaseId,
                            DateOfBirth = involvedUsers.DateOfBirth,
                            EmployeeItemNumber = involvedUsers.EmployeeItemNumber,
                            DepartmentHireDate = involvedUsers.DepartmentHireDate,
                            LastPromotionDate = involvedUsers.LastPromotionDate,
                            DepartmentTenureInDays = involvedUsers.DepartmentTenureInDays,
                            RankTenureIndays = involvedUsers.RankTenureIndays,
                            IsEmployeeEscortSuspect = involvedUsers.IsEmployeeEscortSuspect.Trim(),
                            DVert = involvedUsers.DVERT.Trim() == "Y" ? true : false,
                            InvolType = involvedUsers.InvolvementType.Trim(),
                            ShiftType = involvedUsers.ShiftType.Trim(),
                            ReviewerId = incidentUser.ReviewerId,
                            DirectedEmpId = involvedUsers.DirectedEmplId,
                        }).ToList();
            foreach (var item in list)
            {

            }
            return list;
        }

        public InvolvedUserEntity GetInvolvedUser(int incidentId, int incidentUserInvolvedId)
        {
            var involvedUserEntity = (from involvedUser in unitofWork.IncidentUserInvolvedRepository.GetAll()
                                      join incidentUser in Get() on involvedUser.IncidentUserId equals incidentUser.IncidentUserId
                                      where incidentUser.IncidentId == incidentId && involvedUser.IncidentUserInvolvedId == incidentUserInvolvedId
                                      select new InvolvedUserEntity
                                      {
                                          IncidentUserInvolvedId = involvedUser.IncidentUserInvolvedId,
                                          IncidentUserId = involvedUser.IncidentUserId.GetValueOrDefault(),
                                          IncidentId = incidentUser.IncidentId,
                                          EmployeeId = incidentUser.ForceEmployeeId,
                                          FirstName = incidentUser.FirstName,
                                          TypeOfForce = involvedUser.TypeOfForce,
                                          InjurySeverity = involvedUser.InjurySeverity,
                                          Isforecasting = involvedUser.Isforecasting,
                                          IndForceUsed = involvedUser.IndForceUsed,
                                          IndividualCatId = involvedUser.IndividualCatId,
                                          IsDirected = involvedUser.IsDirected == "Y" ? true : false,
                                          IsRescue = involvedUser.IsRescue == "Y" ? true : false,
                                          IsMedicalAssist = involvedUser.IsMedicalAssist == "Y" ? true : false,
                                          IsInjured = involvedUser.IsInjured == "Y" ? true : false,
                                          IsTreated = involvedUser.IsTreated == "Y" ? true : false,
                                          IsAdmitted = involvedUser.IsAdmitted == "Y" ? true : false,
                                          Facility = involvedUser.Facility,
                                          CoronerCaseId = involvedUser.CoronerCaseId,
                                          DateOfBirth = involvedUser.DateOfBirth,
                                          EmployeeItemNumber = involvedUser.EmployeeItemNumber,
                                          DepartmentHireDate = involvedUser.DepartmentHireDate,
                                          LastPromotionDate = involvedUser.LastPromotionDate,
                                          DepartmentTenureInDays = involvedUser.DepartmentTenureInDays,
                                          RankTenureIndays = involvedUser.RankTenureIndays,
                                          IsEmployeeEscortSuspect = involvedUser.IsEmployeeEscortSuspect
                                      }).FirstOrDefault();
            return involvedUserEntity;
        }

        public List<SuspectUserEntity> GetSuspectUser()
        {
            var suspectUserList = (from suspectUser in unitofWork.IncidentUserSuspectRepository.GetAll()
                                   join incidentUser in Get() on suspectUser.IncidentUserId equals incidentUser.IncidentUserId
                                   select new SuspectUserEntity
                                   {
                                       IncidentUserSuspectId = suspectUser.IncidentUserSuspectId,
                                       IncidentUserId = suspectUser.IncidentUserId.GetValueOrDefault(),
                                       IncidentId = incidentUser.IncidentId,
                                       UserId = incidentUser.UserId,
                                       FirstName = incidentUser.FirstName,
                                       BookingNumber = suspectUser.BookingNumber,
                                       Armed = suspectUser.Armed,
                                       AkaLastname = suspectUser.AkaLastname,
                                       AkaFirstname = suspectUser.AkaFirstname,
                                       AkaMiddleName = suspectUser.AkaMiddleName,
                                       PrimaryPhno = suspectUser.PrimaryPhno,
                                       SecondaryPhno = suspectUser.SecondaryPhno,
                                       PPhMode = suspectUser.PPhMode,
                                       SPhMode = suspectUser.SPhMode,
                                       //PhoneMode = suspectUser.PhoneMode,
                                       PrimaryChargCode = suspectUser.PrimaryChargCode,
                                       SecondaryChargCode = suspectUser.SecondaryChargCode,
                                       CivilianResistance = suspectUser.CivilianResistance,
                                       Lifethreatening = suspectUser.Lifethreatening.Trim(),
                                       Assulative = suspectUser.Assulative.Trim(),
                                       Perceivedarmed = suspectUser.Perceivedarmed,
                                       CivilianConfirmedarmed = suspectUser.CivilianConfirmedarmed,
                                       CivilianInjurySeverity = suspectUser.CivilianInjurySeverity,
                                       // forecasting =suspectUser.forecasting,
                                       TypeofForce = suspectUser.TypeofForce,
                                       TypeOfInjury = suspectUser.TypeOfInjury,
                                       SafetyChairUsed = suspectUser.SafetyChairUsed,
                                       CriminalHistory = suspectUser.CriminalHistory,
                                       TreatedOnScene = suspectUser.TreatedOnScene,
                                       HospitalAdmission = suspectUser.HospitalAdmission,
                                       InmatePhysicallyAssaultive = suspectUser.InmatePhysicallyAssaultive,
                                       InmateRecalcitrant = suspectUser.InmateRecalcitrant,
                                       InmateonInmateViolenceProvoked = suspectUser.InmateonInmateViolenceProvoked,
                                       InmateonInmateViolence = suspectUser.InmateonInmateViolence,
                                       MultiPointRestraintsUsed = suspectUser.MultiPointRestraintsUsed,
                                       OthertypesofRestraints = suspectUser.OthertypesofRestraints,
                                       MedicalRecordschecked = suspectUser.MedicalRecordschecked,
                                       MedicalRestraintsUsed = suspectUser.MedicalRestraintsUsed,
                                       //forceusedasDiscipline =suspectUser.forceusedasDiscipline,
                                       CorporalPunishment = suspectUser.CorporalPunishment,
                                       //cellExtraction =suspectUser.cellExtraction,
                                       Extractionordered = suspectUser.Extractionordered,
                                       InmateHarassed = suspectUser.InmateHarassed,
                                       SuspectInterviewedAwayfromInmates = suspectUser.SuspectInterviewedAwayfromInmates,
                                       TransorRefuse = suspectUser.TransorRefuse,
                                       OtherplannedUoF = suspectUser.OtherplannedUoF,
                                       UnderInfluence = suspectUser.UnderInfluence,
                                       Substance = suspectUser.Substance
                                       //factorinForce =suspectUser.factorinForce,

                                       //PFExtraction=suspectUser.PFExtraction,
                                       //PFPlannedUoF=suspectUser.PFPlannedUoF,
                                       ////RecdTreatmentAt=suspectUser.RecdTreatmentAt,
                                       //CornerCase=suspectUser.CornerCase,
                                       //MentalHistory=suspectUser.MentalHistory,
                                       //BY=suspectUser.BY,
                                       //HospitalAddress=suspectUser.HospitalAddress,
                                       //HospitalPhone=suspectUser.HospitalPhone,
                                       //TreatedName=suspectUser.TreatedName,
                                       //TreatedUnit=suspectUser.TreatedUnit,
                                       //TreatedPhone = suspectUser.TreatedPhone,
                                   }).ToList();

            return suspectUserList;
        }

        public List<SuspectUserEntity> GetSuspectUser(int incidentId)
        {
            int _incidentId = Convert.ToInt32(incidentId);
            var list = (from suspectUser in unitofWork.IncidentUserSuspectRepository.GetAll()
                        join incidentUser in unitofWork.IncidentUserRepository.GetAll() on suspectUser.IncidentUserId equals incidentUser.IncidentUserId
                        join user in unitofWork.UserRepository.GetAll() on incidentUser.UserId equals user.UserId
                        join userDetail in unitofWork.UserDetailRepository.GetAll() on user.UserDetailId equals userDetail.UserDetailId
                        join useraddress in unitofWork.UserAddressRepository.GetAll() on user.UserId equals useraddress.UserId
                        join addressDet in unitofWork.AddressRepository.GetAll() on useraddress.AddressId equals addressDet.AddressId
                        where incidentUser.IncidentId == _incidentId && user.Active == true
                        select new SuspectUserEntity
                        {
                            IncidentUserSuspectId = suspectUser.IncidentUserSuspectId,
                            UserDetailId = userDetail.UserDetailId,
                            IncidentId = _incidentId,
                            //UserId = 1234,
                            AddressId = addressDet.AddressId,
                            Street = addressDet.Street,
                            City = addressDet.City,
                            ZipCode = addressDet.ZipCode,
                            State = addressDet.State,
                            FirstName = userDetail.FirstName,
                            LastName = userDetail.LastName,
                            MiddleName = userDetail.MiddleName,
                            Rank = userDetail.Rank,
                            Sex = userDetail.Sex.Trim(),
                            Dress = userDetail.Dress,
                            DateOfBirth = userDetail.DateOfBirth,
                            Age = userDetail.Age,
                            Race = userDetail.Race,
                            Height = userDetail.Height,
                            Weight = userDetail.Weight,
                            BookingNumber = suspectUser.BookingNumber,
                            Armed = suspectUser.Armed,
                            AkaLastname = suspectUser.AkaLastname,
                            AkaFirstname = suspectUser.AkaFirstname,
                            AkaMiddleName = suspectUser.AkaMiddleName,
                            PrimaryPhno = suspectUser.PrimaryPhno,
                            SecondaryPhno = suspectUser.SecondaryPhno,
                            PhoneMode = suspectUser.PhoneMode,
                            PPhMode = suspectUser.PPhMode,
                            SPhMode = suspectUser.SPhMode,
                            PrimaryChargCode = suspectUser.PrimaryChargCode,
                            SecondaryChargCode = suspectUser.SecondaryChargCode,
                            CivilianResistance = suspectUser.CivilianResistance,
                            Lifethreatening = suspectUser.Lifethreatening.Trim(),
                            Assulative = suspectUser.Assulative.Trim(),
                            Perceivedarmed = suspectUser.Perceivedarmed,
                            CivilianConfirmedarmed = suspectUser.CivilianConfirmedarmed,
                            CivilianInjurySeverity = suspectUser.CivilianInjurySeverity,
                            forecasting = suspectUser.Forecasting.Trim(),
                            TypeofForce = suspectUser.TypeofForce,
                            TypeOfInjury = suspectUser.TypeOfInjury,
                            SafetyChairUsed = suspectUser.SafetyChairUsed.Trim(),
                            CriminalHistory = suspectUser.CriminalHistory,
                            TreatedOnScene = suspectUser.TreatedOnScene.Trim(),
                            HospitalAdmission = suspectUser.HospitalAdmission.Trim(),
                            InmatePhysicallyAssaultive = suspectUser.InmatePhysicallyAssaultive.Trim(),
                            InmateRecalcitrant = suspectUser.InmateRecalcitrant.Trim(),
                            InmateonInmateViolenceProvoked = suspectUser.InmateonInmateViolenceProvoked.Trim(),
                            InmateonInmateViolence = suspectUser.InmateonInmateViolence.Trim(),
                            MultiPointRestraintsUsed = suspectUser.MultiPointRestraintsUsed.Trim(),
                            OthertypesofRestraints = suspectUser.OthertypesofRestraints.Trim(),
                            MedicalRecordschecked = suspectUser.MedicalRecordschecked.Trim(),
                            MedicalRestraintsUsed = suspectUser.MedicalRestraintsUsed.Trim(),
                            forceusedasDiscipline = suspectUser.ForceusedasDiscipline.Trim(),
                            CorporalPunishment = suspectUser.CorporalPunishment.Trim(),
                            cellExtraction = suspectUser.CellExtraction.Trim(),
                            Extractionordered = suspectUser.Extractionordered.Trim(),
                            InmateHarassed = suspectUser.InmateHarassed.Trim(),
                            SuspectInterviewedAwayfromInmates = suspectUser.SuspectInterviewedAwayfromInmates.Trim(),
                            TransorRefuse = suspectUser.TransorRefuse.Trim(),
                            OtherplannedUoF = suspectUser.OtherplannedUoF.Trim(),
                            UnderInfluence = suspectUser.UnderInfluence.Trim(),
                            Substance = suspectUser.Substance.Trim(),
                            factorinForce = suspectUser.FactorinForce.Trim(),
                            ForceUsed = suspectUser.FORCEUSED,
                            SuspectLOC = suspectUser.LOCATIONOFFORCE,
                            SuspectConfArmedOther = suspectUser.SuspectConfArmedOther,
                            CornerCase = suspectUser.CoronerCaseNumber,
                            IspregnantInmate = suspectUser.IspregnantInmate,
                            SecurityLevel = suspectUser.SecurityLevel,
                            SpecialHandle = suspectUser.SpecialHandling,
                            IncidentUserId = suspectUser.IncidentUserId,
                            MentalHistory = suspectUser.IsMentalHistory,

                        }).ToList();

            foreach (var item in list)
            {
                if (unitofWork.IncidentUserInterviewRepository.GetAll().Where(a => a.IncidentUserId == item.IncidentUserId).Any())
                {
                    var interviewSection = unitofWork.IncidentUserInterviewRepository.GetAll().Where(a => a.IncidentUserId == item.IncidentUserId).FirstOrDefault();
                    if (interviewSection != null)
                    {
                        item.InterviewDate = interviewSection.InterviewDate;
                        item.InterviewTime = interviewSection.InterviewTime;
                    }
                }
                if (unitofWork.TreatmentRepository.GetAll().Where(a => a.IncidentUserSuspectId == item.IncidentUserSuspectId).Any())
                {
                    var treatedOnScene = unitofWork.TreatmentRepository.GetAll().Where(a => a.IncidentUserSuspectId == item.IncidentUserSuspectId).FirstOrDefault();
                    if (treatedOnScene != null)
                    {
                        item.TreatedName = treatedOnScene.TreatedBy;
                        item.TreatedPhone = treatedOnScene.PhoneNumber;
                        item.TreatedUnit = treatedOnScene.TreatedUnit;
                    }
                }
                if (unitofWork.HospitalRepository.GetAll().Where(a => a.IncidentUserSuspectId == item.IncidentUserSuspectId).Any())
                {
                    var hospitalInfo = unitofWork.HospitalRepository.GetAll().Where(a => a.IncidentUserSuspectId == item.IncidentUserSuspectId).FirstOrDefault();
                    if (hospitalInfo != null)
                    {
                        item.HospitalAddress = hospitalInfo.HospitalAddress;
                        item.HospitalPhone = hospitalInfo.HospitalPhone;
                        item.BY = hospitalInfo.HospitalAdmissionBy;
                        item.RecdTreatmentAt = hospitalInfo.RecdTreatmentAt;
                    }
                }
            }

            return list;
        }

        public SuspectUserEntity GetSuspectUser(int incidentId, int incidentUserSuspectId = 0)
        {
            var suspectUserEntity = (from suspectUser in unitofWork.IncidentUserSuspectRepository.GetAll()
                                     join incidentUser in Get() on suspectUser.IncidentUserId equals incidentUser.IncidentUserId
                                     where incidentUser.IncidentId == incidentId && (incidentUserSuspectId != 0 ? (suspectUser.IncidentUserSuspectId == incidentUserSuspectId) : 1 == 1)
                                     select new SuspectUserEntity
                                     {
                                         IncidentUserSuspectId = suspectUser.IncidentUserSuspectId,
                                         IncidentUserId = suspectUser.IncidentUserId.GetValueOrDefault(),
                                         IncidentId = incidentUser.IncidentId,
                                         UserId = incidentUser.UserId,
                                         FirstName = incidentUser.FirstName,
                                         BookingNumber = suspectUser.BookingNumber,
                                         Armed = suspectUser.Armed,
                                         AkaLastname = suspectUser.AkaLastname,
                                         AkaFirstname = suspectUser.AkaFirstname,
                                         AkaMiddleName = suspectUser.AkaMiddleName,
                                         PrimaryPhno = suspectUser.PrimaryPhno,
                                         SecondaryPhno = suspectUser.SecondaryPhno,
                                         PPhMode = suspectUser.PPhMode,
                                         SPhMode = suspectUser.SPhMode,
                                         PrimaryChargCode = suspectUser.PrimaryChargCode,
                                         SecondaryChargCode = suspectUser.SecondaryChargCode,
                                         CivilianResistance = suspectUser.CivilianResistance,
                                         Lifethreatening = suspectUser.Lifethreatening,
                                         Assulative = suspectUser.Assulative,
                                         Perceivedarmed = suspectUser.Perceivedarmed,
                                         CivilianConfirmedarmed = suspectUser.CivilianConfirmedarmed,
                                         CivilianInjurySeverity = suspectUser.CivilianInjurySeverity,
                                         // forecasting =suspectUser.forecasting,
                                         TypeofForce = suspectUser.TypeofForce,
                                         TypeOfInjury = suspectUser.TypeOfInjury,
                                         SafetyChairUsed = suspectUser.SafetyChairUsed,
                                         CriminalHistory = suspectUser.CriminalHistory,
                                         TreatedOnScene = suspectUser.TreatedOnScene,
                                         HospitalAdmission = suspectUser.HospitalAdmission,
                                         InmatePhysicallyAssaultive = suspectUser.InmatePhysicallyAssaultive,
                                         InmateRecalcitrant = suspectUser.InmateRecalcitrant,
                                         InmateonInmateViolenceProvoked = suspectUser.InmateonInmateViolenceProvoked,
                                         InmateonInmateViolence = suspectUser.InmateonInmateViolence,
                                         MultiPointRestraintsUsed = suspectUser.MultiPointRestraintsUsed,
                                         OthertypesofRestraints = suspectUser.OthertypesofRestraints,
                                         MedicalRecordschecked = suspectUser.MedicalRecordschecked,
                                         MedicalRestraintsUsed = suspectUser.MedicalRestraintsUsed,
                                         //forceusedasDiscipline =suspectUser.forceusedasDiscipline,
                                         CorporalPunishment = suspectUser.CorporalPunishment,
                                         //cellExtraction =suspectUser.cellExtraction,
                                         Extractionordered = suspectUser.Extractionordered,
                                         InmateHarassed = suspectUser.InmateHarassed,
                                         SuspectInterviewedAwayfromInmates = suspectUser.SuspectInterviewedAwayfromInmates,
                                         TransorRefuse = suspectUser.TransorRefuse,
                                         OtherplannedUoF = suspectUser.OtherplannedUoF,
                                         UnderInfluence = suspectUser.UnderInfluence,
                                         Substance = suspectUser.Substance
                                         //factorinForce =suspectUser.factorinForce,

                                         //PFExtraction=suspectUser.PFExtraction,
                                         //PFPlannedUoF=suspectUser.PFPlannedUoF,
                                         ////RecdTreatmentAt=suspectUser.RecdTreatmentAt,
                                         //CornerCase=suspectUser.CornerCase,
                                         //MentalHistory=suspectUser.MentalHistory,
                                         //BY=suspectUser.BY,
                                         //HospitalAddress=suspectUser.HospitalAddress,
                                         //HospitalPhone=suspectUser.HospitalPhone,
                                         //TreatedName=suspectUser.TreatedName,
                                         //TreatedUnit=suspectUser.TreatedUnit,
                                         //TreatedPhone = suspectUser.TreatedPhone,
                                     }).FirstOrDefault();

            return suspectUserEntity;
        }

        public List<WitnessUserEntity> GetWitnessUser()
        {
            var witnessUserList = (from witnessUser in unitofWork.IncidentUserWitnessRepository.GetAll()
                                   join incidentUser in Get() on witnessUser.IncidentUserId equals incidentUser.IncidentUserId
                                   select new WitnessUserEntity
                                   {
                                       IncidentUserWitnessId = witnessUser.IncidentUserWitnessId,
                                       IncidentUserId = witnessUser.IncidentUserId.GetValueOrDefault(),
                                       IncidentId = incidentUser.IncidentId,
                                       UserId = incidentUser.UserId,
                                       FirstName = incidentUser.FirstName,
                                       WitnessIntAwayfromInmates = witnessUser.WitnessIntAwayfromInmates,
                                       IsWitness = witnessUser.IsWitness,
                                       IsPresent = witnessUser.IsPresent
                                   }).ToList();

            return witnessUserList;
        }

        public List<WitnessUserEntity> GetWitnessUser(int incidentId, int witnessType)
        {
            List<WitnessUserEntity> lst = new List<WitnessUserEntity>();
            int _incidentId = Convert.ToInt32(incidentId);
            if (witnessType == (int)UOF.Common.Utilities.Constants.UserType.EmployeeWitness)
            {
                var list = (from witnessUser in unitofWork.IncidentUserWitnessRepository.GetAll()
                            join incidentUser in unitofWork.IncidentUserRepository.GetAll() on witnessUser.IncidentUserId equals incidentUser.IncidentUserId
                            join user in unitofWork.UserRepository.GetAll() on incidentUser.UserId equals user.UserId
                            join userDetail in unitofWork.UserDetailRepository.GetAll() on user.UserDetailId equals userDetail.UserDetailId
                            where incidentUser.IncidentId == _incidentId && incidentUser.UserTypeId == 3 && user.Active == true
                            select new WitnessUserEntity
                            {
                                IncidentUserWitnessId = witnessUser.IncidentUserWitnessId,
                                EmployeeId = user.ForceEmployeeId,
                                IncidentId = _incidentId,
                                FirstName = userDetail.FirstName,
                                LastName = userDetail.LastName,
                                MiddleName = userDetail.MiddleName,
                                Shift = userDetail.ShiftId,
                                ShiftType = witnessUser.ShiftType,
                                UserDetailId = userDetail.UserDetailId,
                                UserTypeId = user.UserTypeId,
                                UnitOfAssignment = userDetail.UnitOfAssignment,
                                WorkAssignment = userDetail.WorkAssignment,
                                WitnessIntAwayfromInmates = witnessUser.WitnessIntAwayfromInmates.Trim(),
                            }).ToList();
                return list;
            }
            else if (witnessType == (int)UOF.Common.Utilities.Constants.UserType.NonEmpWitness)
            {
                var list = (from witnessUser in unitofWork.IncidentUserWitnessRepository.GetAll()
                            join incidentUser in unitofWork.IncidentUserRepository.GetAll() on witnessUser.IncidentUserId equals incidentUser.IncidentUserId
                            join user in unitofWork.UserRepository.GetAll() on incidentUser.UserId equals user.UserId
                            join userDetail in unitofWork.UserDetailRepository.GetAll() on user.UserDetailId equals userDetail.UserDetailId
                            join useraddress in unitofWork.UserAddressRepository.GetAll() on user.UserId equals useraddress.UserId
                            join addressDet in unitofWork.AddressRepository.GetAll() on useraddress.AddressId equals addressDet.AddressId
                            where incidentUser.IncidentId == _incidentId && incidentUser.UserTypeId == 4 && user.Active == true
                            select new WitnessUserEntity
                            {
                                IncidentUserWitnessId = witnessUser.IncidentUserWitnessId,
                                AddressId = addressDet.AddressId,
                                Street = addressDet.Street,
                                City = addressDet.City,
                                ZipCode = addressDet.ZipCode,
                                EmployeeId = user.ForceEmployeeId,
                                IncidentId = _incidentId,
                                Age = userDetail.Age,
                                UserDetailId = userDetail.UserDetailId,
                                DateOfBirth = userDetail.DateOfBirth,
                                UserTypeId = user.UserTypeId,
                                FirstName = userDetail.FirstName,
                                LastName = userDetail.LastName,
                                MiddleName = userDetail.MiddleName,
                                UserId = user.UserId,
                                BookingNum = user.ForceEmployeeId,
                                InmateType = witnessUser.InmateType,
                                TransorRefuse = witnessUser.TransorRefuse
                            }).ToList();

                getContactDetails(list);//Updating the Primary and secondry Number before display
                return list;
            }
            return lst;
        }

        /// <summary>
        /// Updating the Primary and secondry Number before display
        /// </summary>
        /// <param name="list"></param>
        private void getContactDetails(List<WitnessUserEntity> list)
        {
            foreach (var item in list)
            {
                var contacts = (from contact in unitofWork.ContactRepository.GetAll()
                                join userContact in unitofWork.UserContactRepository.GetAll() on contact.ContactId equals userContact.ContactId
                                where userContact.UserId == item.UserId
                                select new
                                {
                                    ContactTypeId = contact.ContactTypeId,
                                    Number = contact.Number
                                }).ToList();
                if (contacts.Count == 2)
                {
                    item.PrimaryPhone = contacts != null ? contacts.FirstOrDefault(a => a.ContactTypeId == (int)UOF.Common.Utilities.Constants.ContactTypes.Phone1).Number : string.Empty;
                    item.SecondaryPhone = contacts != null ? contacts.FirstOrDefault(a => a.ContactTypeId == (int)UOF.Common.Utilities.Constants.ContactTypes.Phone2).Number : string.Empty;
                }
                else if (contacts.Count == 1)
                {
                    if (contacts[0].ContactTypeId == (int)UOF.Common.Utilities.Constants.ContactTypes.Phone1)
                        item.PrimaryPhone = contacts != null ? contacts.FirstOrDefault(a => a.ContactTypeId == (int)UOF.Common.Utilities.Constants.ContactTypes.Phone1).Number : string.Empty;
                    else if (contacts[0].ContactTypeId == (int)UOF.Common.Utilities.Constants.ContactTypes.Phone2)
                        item.SecondaryPhone = contacts != null ? contacts.FirstOrDefault(a => a.ContactTypeId == (int)UOF.Common.Utilities.Constants.ContactTypes.Phone2).Number : string.Empty;
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="incidentId"></param>
        /// <returns></returns>
        public List<WitnessUserEntity> GetincidentDupties(int incidentId)
        {
            List<WitnessUserEntity> list = new List<WitnessUserEntity>();
            int _incidentId = Convert.ToInt32(incidentId);
            WitnessUserEntity userEntity = getDupties(_incidentId, (int)UOF.Common.Utilities.Constants.UserType.OnDuty);
            WitnessUserEntity SupervisorEntity = getDupties(_incidentId, (int)UOF.Common.Utilities.Constants.UserType.Supervisor);
            WitnessUserEntity WCEntity = getDupties(_incidentId, (int)UOF.Common.Utilities.Constants.UserType.WatchCommander);
            list.Add(userEntity);
            list.Add(SupervisorEntity);
            list.Add(WCEntity);
            return list;

        }

        private WitnessUserEntity getDupties(int _incidentId, int officerType)
        {
            WitnessUserEntity userEntity = (from witnessUser in unitofWork.IncidentUserWitnessRepository.GetAll()
                                            join incidentUser in unitofWork.IncidentUserRepository.GetAll() on witnessUser.IncidentUserId equals incidentUser.IncidentUserId
                                            join user in unitofWork.UserRepository.GetAll() on incidentUser.UserId equals user.UserId
                                            join userDetail in unitofWork.UserDetailRepository.GetAll() on user.UserDetailId equals userDetail.UserDetailId
                                            orderby userDetail.UserDetailId descending
                                            where incidentUser.IncidentId == _incidentId && incidentUser.UserTypeId == officerType
                                            select new WitnessUserEntity
                                            {
                                                IncidentUserWitnessId = witnessUser.IncidentUserWitnessId,
                                                UserDetailId = userDetail.UserDetailId,
                                                EmployeeId = user.ForceEmployeeId,
                                                IncidentId = _incidentId,
                                                UserTypeId = officerType,
                                                FirstName = userDetail.FirstName,
                                                LastName = userDetail.LastName,
                                                MiddleName = userDetail.MiddleName,
                                                IsPresent = witnessUser.IsPresent,
                                                IsWitness = witnessUser.IsWitness,
                                                Rank = userDetail.Rank,
                                            }).FirstOrDefault();
            return userEntity;
        }

        public WitnessUserEntity GetIncidentWitnessUser(int incidentId, int incidentUserWitnessId)
        {
            var witnessUserEntity = (from witnessUser in unitofWork.IncidentUserWitnessRepository.GetAll()
                                     join incidentUser in Get() on witnessUser.IncidentUserId equals incidentUser.IncidentUserId
                                     where incidentUser.IncidentId == incidentId && witnessUser.IncidentUserWitnessId == incidentUserWitnessId
                                     select new WitnessUserEntity
                                     {
                                         IncidentUserWitnessId = witnessUser.IncidentUserWitnessId,
                                         IncidentUserId = witnessUser.IncidentUserId.GetValueOrDefault(),
                                         IncidentId = incidentUser.IncidentId,
                                         UserId = incidentUser.UserId,
                                         FirstName = incidentUser.FirstName,
                                         WitnessIntAwayfromInmates = witnessUser.WitnessIntAwayfromInmates,
                                         IsWitness = witnessUser.IsWitness,
                                         IsPresent = witnessUser.IsPresent
                                     }).FirstOrDefault();
            return witnessUserEntity;
        }

        public List<LookupEntity> GetInvolvedUsersAndSuspects(int incidentId)
        {
            var Ecounter = 1;
            var Scounter = 1;
            var users = (from usr in unitofWork.UserRepository.GetAll()
                         join incidentUser in unitofWork.IncidentUserRepository.GetAll() on usr.UserId equals incidentUser.UserId
                         join userDetail in unitofWork.UserDetailRepository.GetAll() on usr.UserDetailId equals userDetail.UserDetailId
                         where incidentUser.IncidentId == incidentId && (incidentUser.UserTypeId == 1 || incidentUser.UserTypeId == 2)
                         select new LookupEntity
                         {
                             Code = usr.ForceEmployeeId,
                             Name = userDetail.FirstName + " " + userDetail.LastName + " " + userDetail.MiddleName,
                             UserTypeID = usr.UserTypeId,
                         }).ToList();

            foreach (var user in users)
            {
                user.Name = Convert.ToInt32(user.UserTypeID) == 1 ? "E" + Ecounter + "(" + user.Name + ")" : user.Name = "S" + Scounter + "(" + user.Name + ")";
                if (Convert.ToInt32(user.UserTypeID) == 1)
                    Ecounter++;
                if (Convert.ToInt32(user.UserTypeID) == 2)
                    Scounter++;
            }

            return users;
        }
        public List<LookupEntity> GetUsersByFormId(int incidentId, int formId)
        {
            int userTypeId = 0;
            switch (formId)
            {
                case 16:
                case 17:
                case 18:
                case 19:
                case 20:
                case 21:
                case 22:
                    userTypeId = 1;
                    break;
                case 23:
                case 24:
                case 25:
                    userTypeId = 5;
                    break;
                case 26:
                case 27:
                    userTypeId = 6;
                    break;
                case 30:
                case 31:
                    userTypeId = 7;
                    break;
                default:
                    userTypeId = 0;
                    break;
            }
            var users = new List<LookupEntity>();
            var formData = unitofWork.UOFIncidentFormDataRepository.GetAll().Where(x => x.FormID == formId && x.IncidentID == incidentId).ToList();
            if (formData != null)
            {
                //if (userTypeId != 0)
                //{
                foreach (IncidentFormData item in formData)
                {
                    LookupEntity user = (from usr in unitofWork.UserRepository.GetAll()
                                         join userDetail in unitofWork.UserDetailRepository.GetAll() on usr.UserDetailId equals userDetail.UserDetailId
                                         join incidentUser in unitofWork.IncidentUserRepository.GetAll() on usr.UserId equals incidentUser.UserId
                                         where incidentUser.IncidentId == incidentId && usr.ForceEmployeeId == item.EmpID
                                         select new LookupEntity
                                         {
                                             Code = usr.ForceEmployeeId,
                                             Name = userDetail.FirstName + " " + userDetail.LastName + " " + userDetail.MiddleName,
                                             UserTypeID = usr.UserTypeId
                                         }).FirstOrDefault();
                    users.Add(user);
                }

                //}
                //else
                //{
                //    string sergeantID = (from ind in unitofWork.IncidentRepository.GetAll()
                //                         where ind.IncidentId == incidentId
                //                         select new { ind.SergeantId }).Single().SergeantId;
                //    LookupEntity le = new LookupEntity { Code = sergeantID, Name = "Seargent", UserTypeID = 0 };
                //    users.Add(le);
                //}
            }

            //var users = (from usr in unitofWork.UserRepository.GetAll()
            //             join incidentUser in unitofWork.IncidentUserRepository.GetAll() on usr.UserId equals incidentUser.UserId
            //             join userDetail in unitofWork.UserDetailRepository.GetAll() on usr.UserDetailId equals userDetail.UserDetailId
            //             join fd in unitofWork.UOFIncidentFormDataRepository.GetAll() on incidentUser.IncidentId equals fd.IncidentID
            //             where incidentUser.IncidentId == incidentId && fd.UserRoleId == userRoleId
            //             select new LookupEntity
            //             {
            //                 Code = usr.ForceEmployeeId,
            //                 Name = userDetail.FirstName + " " + userDetail.LastName + " " + userDetail.MiddleName,
            //                 UserTypeID = usr.UserTypeId
            //             }).ToList();

            return users;
        }
        public List<LookupEntity> GetIncidentUserWithName(int incidentId)
        {
            var users = (from usr in unitofWork.UserRepository.GetAll()
                         join incidentUser in unitofWork.IncidentUserRepository.GetAll() on usr.UserId equals incidentUser.UserId
                         join userDetail in unitofWork.UserDetailRepository.GetAll() on usr.UserDetailId equals userDetail.UserDetailId
                         join wf in unitofWork.IncidentWorkflowRepository.GetAll() on incidentUser.IncidentId equals wf.IncidentId
                         where incidentUser.IncidentId == incidentId && (usr.UserTypeId == 1 || usr.UserTypeId == 5 || usr.UserTypeId == 6 || usr.UserTypeId == 7)
                         select new LookupEntity
                         {
                             Code = usr.ForceEmployeeId,
                             Name = userDetail.FirstName + " " + userDetail.LastName + " " + userDetail.MiddleName,
                             UserTypeID = usr.UserTypeId
                         }).ToList();

            string sergeantID = (from ind in unitofWork.IncidentRepository.GetAll()
                                 where ind.IncidentId == incidentId
                                 select new { ind.SergeantId }).Single().SergeantId;
            LookupEntity le = new LookupEntity { Code = sergeantID, Name = "Seargent", UserTypeID = 0 };
            users.Add(le);
            return users;
        }

        public List<LookupEntity> GetInvolvedUserWithName(int incidentId)
        {
            var users = (from usr in unitofWork.UserRepository.GetAll()
                         join incidentUser in unitofWork.IncidentUserRepository.GetAll() on usr.UserId equals incidentUser.UserId
                         join userDetail in unitofWork.UserDetailRepository.GetAll() on usr.UserDetailId equals userDetail.UserDetailId
                         where incidentUser.IncidentId == incidentId && usr.UserTypeId == 1
                         select new LookupEntity
                         {
                             Code = usr.ForceEmployeeId,
                             Name = userDetail.FirstName + " " + userDetail.LastName + " " + userDetail.MiddleName
                         }).ToList();
            return users;
        }
        public List<LookupEntity> GetAssignedUserWithName(int incidentId)
        {
            var users = (from usr in unitofWork.UserRepository.GetAll()
                         join incidentUser in unitofWork.IncidentUserRepository.GetAll() on usr.UserId equals incidentUser.UserId
                         join userDetail in unitofWork.UserDetailRepository.GetAll() on usr.UserDetailId equals userDetail.UserDetailId
                         where incidentUser.IncidentId == incidentId && (usr.UserTypeId == 1 || usr.UserTypeId == 11)
                         select new LookupEntity
                         {
                             Code = usr.ForceEmployeeId,
                             Name = userDetail.FirstName + " " + userDetail.LastName + " " + userDetail.MiddleName
                         }).ToList();
            return users;
        }
        public List<LookupEntity> GetReportingEmployees(int incidentId, string loggedRole)
        {
            var users = (from usr in unitofWork.UserRepository.GetAll()
                         join incidentUser in unitofWork.IncidentUserRepository.GetAll() on usr.UserId equals incidentUser.UserId
                         join userDetail in unitofWork.UserDetailRepository.GetAll() on usr.UserDetailId equals userDetail.UserDetailId
                         join review in unitofWork.ReviewRespository.GetAll() on usr.ForceEmployeeId equals review.InvolvedId
                         where incidentUser.IncidentId == incidentId && review.IncidentID == incidentId
                         select new LookupEntity
                         {
                             Code = usr.ForceEmployeeId,
                             Name = userDetail.FirstName + " " + userDetail.LastName + " " + userDetail.MiddleName,
                             Type = review.InvolvedRole
                         }).Distinct().ToList();
            switch (loggedRole)
            {
                case "SGT":
                    users = users.FindAll(a => a.Type == "DSG");
                    break;
                case "WC":
                    users = users.FindAll(a => a.Type == "DSG" || a.Type == "SGT");
                    break;
                default:
                    break;
            }
            return users;
        }

        public List<string> GetSuspectUsers(int incidentId)
        {
            var users = (from suspect in unitofWork.IncidentUserSuspectRepository.GetAll()
                         join incidentUser in unitofWork.IncidentUserRepository.GetAll() on suspect.IncidentUserId equals incidentUser.IncidentUserId
                         where incidentUser.IncidentId == incidentId
                         select suspect.BookingNumber).ToList();
            return users;
        }
        public bool AssigntoCommander(List<WitnessUserEntity> Commanders)
        {
            int incidentId = 0;
            string WCID = string.Empty, UCID = string.Empty, CMID = string.Empty, DCID = string.Empty;
            var requiredRoleTypeIds = new string[] { "" };
            WitnessUserEntity Rmodel = new WitnessUserEntity();
            try
            {
                using (var transaction = new TransactionScope())
                {
                    foreach (WitnessUserEntity item in Commanders)
                    {
                        //#if DEBUG
                        //                        item.UserTypeId = (int)Constants.UserType.UnitCommander;
                        //#endif
                        string reviwerId = string.Empty;
                        IncidentUserEntity incidentUserEntity = new IncidentUserEntity();
                        incidentId = item.IncidentId;
                        incidentUserEntity.FirstName = item.FirstName;
                        incidentUserEntity.MiddleName = item.MiddleName;
                        incidentUserEntity.LastName = item.LastName;
                        incidentUserEntity.Rank = item.Rank;
                        incidentUserEntity.UserTypeId = item.UserTypeId;
                        incidentUserEntity.IncidentId = item.IncidentId;
                        incidentUserEntity.ForceEmployeeId = item.EmployeeId;
                        incidentUserEntity.CreatedOn = DateTime.Now;

                        SaveIncidentUser(incidentUserEntity);
                        if (item.UserTypeId == (int)Constants.UserType.WatchCommander)
                        {
                            requiredRoleTypeIds = new string[] { Constants.UserRoles.SGT.ToString(), Constants.UserRoles.DSG.ToString() };
                            WCID = item.EmployeeId;
                            List<IncidentFormReview> model = unitofWork.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && (x.InvolvedRole == Constants.UserRoles.DSG.ToString() || x.InvolvedRole == Constants.UserRoles.SGT.ToString())).ToList();
                            foreach (var frm in model)
                            {
                                if (frm != null)
                                {
                                    FormReviewRank rankResult = (from review in unitofWork.FormReviewRankRespository.GetAll() where review.FormId == frm.FormId && review.Active == true select review).FirstOrDefault();
                                    if (rankResult != null)
                                    {
                                        if (rankResult.ReviewRank == 3)
                                        {
                                            frm.WCStatus = Constants.Status.Pending.ToString();
                                            unitofWork.ReviewRespository.Update(frm);
                                            unitofWork.Commit();
                                        }
                                        else
                                        {
                                            frm.WCID = WCID;
                                            if (frm.InvolvedRole == Constants.UserRoles.DSG.ToString())
                                                frm.WCStatus = Constants.Status.Completed.ToString();
                                            else if (frm.InvolvedRole == Constants.UserRoles.SGT.ToString())
                                                frm.WCStatus = Constants.Status.Pending.ToString();
                                            unitofWork.ReviewRespository.Update(frm);
                                            unitofWork.Commit();
                                        }

                                    }
                                    else
                                    {
                                        frm.WCID = WCID;
                                        if (frm.InvolvedRole == Constants.UserRoles.DSG.ToString())
                                            frm.WCStatus = Constants.Status.Completed.ToString();
                                        else if (frm.InvolvedRole == Constants.UserRoles.SGT.ToString())
                                            frm.WCStatus = Constants.Status.Pending.ToString();
                                        unitofWork.ReviewRespository.Update(frm);
                                        unitofWork.Commit();
                                    }
                                }
                            }

                            IncidentWorkflow WfModel = unitofWork.IncidentWorkflowRepository.GetAll().Where(x => x.IncidentId == incidentId).FirstOrDefault();
                            if (WfModel != null)
                            {
                                WfModel.WCID = WCID;
                                WfModel.SergeantStatus = Constants.Status.Completed.ToString();
                                WfModel.WCStatus = Constants.Status.Pending.ToString();
                                unitofWork.IncidentWorkflowRepository.Update(WfModel);
                                unitofWork.Commit();
                            }
                            wf.updateIncident(incidentId, Convert.ToString((int)Constants.IncidentStatus.AtWatchCommander));

                        }
                        else if (item.UserTypeId == (int)Constants.UserType.UnitCommander)
                        {
                            UCID = item.EmployeeId;
                            Rmodel = Commanders.Where(x => x.IncidentId == item.IncidentId && x.UserTypeId == (int)Constants.UserType.UnitCommander).FirstOrDefault();
                            //incidentUserEntity.ReviewerId = Rmodel.EmployeeId;

                            //#region Inserting Unit Commander Forms
                            ////Insert Unit Commander Review Form
                            //repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                            //{
                            //    IncidentID = incidentId,
                            //    FormId = (int)Constants.UOFForms.UnitCommanderUseoFForceReview,
                            //    SubmitteduserRole = Constants.UserRoles.CAPT.ToString(),
                            //    SubmittedStatus = Constants.Status.Pending.ToString(),
                            //    SubmittedEmpId = UCID,
                            //    ReviewerRole = Constants.UserRoles.CMDR.ToString(),
                            //    UCStatus = Constants.Status.Pending.ToString(),
                            //    UCID = UCID,
                            //    CMID = CMID,
                            //});

                            //#endregion


                            requiredRoleTypeIds = new string[] { Constants.UserRoles.SGT.ToString(), Constants.UserRoles.DSG.ToString(), Constants.UserRoles.WC.ToString() };
                            List<IncidentFormReview> model = unitofWork.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && (x.InvolvedRole == Constants.UserRoles.DSG.ToString() || x.InvolvedRole == Constants.UserRoles.SGT.ToString() || x.InvolvedRole == Constants.UserRoles.WC.ToString())).ToList();
                            foreach (var frm in model)
                            {
                                if (frm != null)
                                {
                                    FormReviewRank rankResult = (from review in unitofWork.FormReviewRankRespository.GetAll() where review.FormId == frm.FormId && review.Active == true select review).FirstOrDefault();
                                    if (rankResult != null)
                                    {
                                        if (rankResult.ReviewRank == 4)
                                        {
                                            frm.UCStatus = Constants.Status.Pending.ToString();
                                            unitofWork.ReviewRespository.Update(frm);
                                            unitofWork.Commit();
                                        }
                                        else
                                        {
                                            frm.UCID = UCID;
                                            if (frm.InvolvedRole == Constants.UserRoles.DSG.ToString() || frm.InvolvedRole == Constants.UserRoles.SGT.ToString())
                                                frm.UCStatus = Constants.Status.Completed.ToString();
                                            else if (frm.InvolvedRole == Constants.UserRoles.WC.ToString())
                                                frm.UCStatus = Constants.Status.Pending.ToString();
                                            unitofWork.ReviewRespository.Update(frm);
                                            unitofWork.Commit();
                                        }

                                    }
                                    else
                                    {
                                        frm.UCID = UCID;
                                        if (frm.InvolvedRole == Constants.UserRoles.DSG.ToString() || frm.InvolvedRole == Constants.UserRoles.SGT.ToString())
                                            frm.UCStatus = Constants.Status.Completed.ToString();
                                        else if (frm.InvolvedRole == Constants.UserRoles.WC.ToString())
                                            frm.UCStatus = Constants.Status.Pending.ToString();
                                        unitofWork.ReviewRespository.Update(frm);
                                        unitofWork.Commit();
                                    }
                                }
                            }

                            IncidentWorkflow WfModel = unitofWork.IncidentWorkflowRepository.GetAll().Where(x => x.IncidentId == incidentId).FirstOrDefault();
                            if (WfModel != null)
                            {
                                WfModel.WCStatus = Constants.Status.Completed.ToString();
                                WfModel.UCID = UCID;
                                WfModel.UCStatus = Constants.Status.Pending.ToString();
                                unitofWork.IncidentWorkflowRepository.Update(WfModel);
                                unitofWork.Commit();
                            }
                            wf.updateIncident(incidentId, Convert.ToString((int)Constants.IncidentStatus.AtUnitCommander));
                        }
                        else if (item.UserTypeId == (int)Constants.UserType.Commander)
                        {
                            CMID = item.EmployeeId;
                            //#region Inserting Commander Forms
                            ////Insert Commander Review Form
                            //repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                            //{
                            //    IncidentID = incidentId,
                            //    FormId = (int)Constants.UOFForms.CommanderUseofForceReview,
                            //    SubmitteduserRole = Constants.UserRoles.CMDR.ToString(),
                            //    SubmittedStatus = Constants.Status.Pending.ToString(),
                            //    ReviewerRole = Constants.UserRoles.CMDR.ToString(),
                            //    CMID = CMID,
                            //    SubmittedEmpId = CMID,
                            //    CMStatus = Constants.Status.NotReady.ToString(),
                            //});
                            //#endregion
                            requiredRoleTypeIds = new string[] { Constants.UserRoles.SGT.ToString(), Constants.UserRoles.DSG.ToString(), Constants.UserRoles.WC.ToString(), Constants.UserRoles.CAPT.ToString() };
                            List<IncidentFormReview> model = unitofWork.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && (x.InvolvedRole == Constants.UserRoles.DSG.ToString() || x.InvolvedRole == Constants.UserRoles.SGT.ToString() || x.InvolvedRole == Constants.UserRoles.WC.ToString()) || x.InvolvedRole == Constants.UserRoles.CAPT.ToString()).ToList();
                            foreach (var frm in model)
                            {
                                if (frm != null)
                                {
                                    FormReviewRank rankResult = (from review in unitofWork.FormReviewRankRespository.GetAll() where review.FormId == frm.FormId && review.Active == true select review).FirstOrDefault();
                                    if (rankResult != null)
                                    {
                                        if (rankResult.ReviewRank == 5)
                                        {
                                            frm.CMStatus = Constants.Status.Pending.ToString();
                                            unitofWork.ReviewRespository.Update(frm);
                                            unitofWork.Commit();
                                        }
                                        else
                                        {
                                            frm.CMID = CMID;
                                            if (frm.InvolvedRole == Constants.UserRoles.DSG.ToString() || frm.InvolvedRole == Constants.UserRoles.SGT.ToString() || frm.InvolvedRole == Constants.UserRoles.WC.ToString())
                                                frm.CMStatus = Constants.Status.Completed.ToString();
                                            else if (frm.InvolvedRole == Constants.UserRoles.CAPT.ToString())
                                                frm.CMStatus = Constants.Status.Pending.ToString();
                                            unitofWork.ReviewRespository.Update(frm);
                                            unitofWork.Commit();
                                        }

                                    }
                                    else
                                    {
                                        frm.CMID = CMID;
                                        if (frm.InvolvedRole == Constants.UserRoles.DSG.ToString() || frm.InvolvedRole == Constants.UserRoles.SGT.ToString() || frm.InvolvedRole == Constants.UserRoles.WC.ToString())
                                            frm.CMStatus = Constants.Status.Completed.ToString();
                                        else if (frm.InvolvedRole == Constants.UserRoles.CAPT.ToString())
                                            frm.CMStatus = Constants.Status.Pending.ToString();
                                        unitofWork.ReviewRespository.Update(frm);
                                        unitofWork.Commit();
                                    }
                                }
                            }
                            IncidentWorkflow WfModel = unitofWork.IncidentWorkflowRepository.GetAll().Where(x => x.IncidentId == incidentId).FirstOrDefault();
                            if (WfModel != null)
                            {
                                WfModel.UCStatus = Constants.Status.Completed.ToString();
                                WfModel.CMID = CMID;
                                WfModel.CMStatus = Constants.Status.Pending.ToString();
                                unitofWork.IncidentWorkflowRepository.Update(WfModel);
                                unitofWork.Commit();
                            }
                            wf.updateIncident(incidentId, Convert.ToString((int)Constants.IncidentStatus.AtCommander));
                        }
                        else if (item.UserTypeId == (int)Constants.UserType.Chief)
                        {
                            DCID = item.EmployeeId;
                            requiredRoleTypeIds = new string[] { Constants.UserRoles.SGT.ToString(), Constants.UserRoles.DSG.ToString(), Constants.UserRoles.WC.ToString(), Constants.UserRoles.CAPT.ToString(), Constants.UserRoles.DC.ToString() };
                            List<IncidentFormReview> model = unitofWork.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && (x.InvolvedRole == Constants.UserRoles.DSG.ToString() || x.InvolvedRole == Constants.UserRoles.SGT.ToString() || x.InvolvedRole == Constants.UserRoles.WC.ToString()) || x.InvolvedRole == Constants.UserRoles.CAPT.ToString() || x.InvolvedRole == Constants.UserRoles.CMDR.ToString()).ToList();
                            foreach (var frm in model)
                            {
                                if (frm != null)
                                {
                                    //frm.DCID = DCID;
                                    if (frm.InvolvedRole == Constants.UserRoles.DSG.ToString() || frm.InvolvedRole == Constants.UserRoles.SGT.ToString() || frm.InvolvedRole == Constants.UserRoles.WC.ToString() || frm.InvolvedRole == Constants.UserRoles.CAPT.ToString() || frm.InvolvedRole == Constants.UserRoles.CMDR.ToString())
                                        //frm.Chi = Constants.Status.Completed.ToString();
                                        unitofWork.ReviewRespository.Update(frm);
                                    unitofWork.Commit();
                                }
                            }
                            IncidentWorkflow WfModel = unitofWork.IncidentWorkflowRepository.GetAll().Where(x => x.IncidentId == incidentId).FirstOrDefault();
                            if (WfModel != null)
                            {
                                WfModel.CMStatus = Constants.Status.Completed.ToString();
                                WfModel.DCID = DCID;
                                WfModel.DCStatus = Constants.Status.Pending.ToString();
                                unitofWork.IncidentWorkflowRepository.Update(WfModel);
                                unitofWork.Commit();
                            }
                            wf.updateIncident(incidentId, Convert.ToString((int)Constants.IncidentStatus.AtChief));
                        }


                        #region Email Notification
                        EmailRepository email = new EmailRepository();
                        email.EmailNotification(new EmailNotificationModel
                        {
                            Department = "Assign",
                            EmailId = item.EmailId,
                            IncidentId = Convert.ToInt32(item.IncidentId),
                            EmployeeNumber = item.EmployeeId,
                        });
                        #endregion
                    }
                    transaction.Complete();
                    return true;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return true;
        }

        public bool AssignPackage(ChangeOwnerModel model)
        {
            int incidentId = model.IncidentId;
            string WCID = string.Empty, UCID = string.Empty, CMID = string.Empty, DCID = string.Empty;
            var requiredRoleTypeIds = new string[] { "" };
            try
            {
                using (var transaction = new TransactionScope())
                {
                    string reviwerId = string.Empty;
                    if (model.isCFRT)
                    {
                        var usr = (from s in unitofWork.UserRepository.GetAll()
                                   join f in unitofWork.IncidentUserRepository.GetAll() on s.UserId equals f.UserId
                                   where f.IncidentId == model.IncidentId && s.ForceEmployeeId == model.ChangedEmpId && f.UserTypeId == (int)Constants.UserType.UnitCommander
                                   select s).FirstOrDefault();
                        if (usr != null)
                        {
                            UserDetail userDetail = unitofWork.UserDetailRepository.GetAll().Where(x => x.UserDetailId == usr.UserDetailId).FirstOrDefault();
                            requiredRoleTypeIds = new string[] { Constants.UserRoles.SGT.ToString(), Constants.UserRoles.DSG.ToString(), Constants.UserRoles.WC.ToString() };
                            List<IncidentFormReview> Existingmodel = unitofWork.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && (x.InvolvedRole == Constants.UserRoles.DSG.ToString() || x.InvolvedRole == Constants.UserRoles.SGT.ToString() || x.InvolvedRole == Constants.UserRoles.WC.ToString())).ToList();
                            foreach (var frm in Existingmodel)
                            {
                                if (frm != null)
                                {
                                    FormReviewRank rankResult = (from review in unitofWork.FormReviewRankRespository.GetAll() where review.FormId == frm.FormId && review.Active == true select review).FirstOrDefault();
                                    if (rankResult != null)
                                    {
                                        if (rankResult.ReviewRank == 4)
                                        {
                                            frm.UCStatus = Constants.Status.Pending.ToString();
                                            unitofWork.ReviewRespository.Update(frm);
                                            unitofWork.Commit();
                                        }
                                        else
                                        {
                                            frm.UCID = UCID;
                                            if (frm.InvolvedRole == Constants.UserRoles.DSG.ToString() || frm.InvolvedRole == Constants.UserRoles.SGT.ToString())
                                                frm.UCStatus = Constants.Status.Completed.ToString();
                                            else if (frm.InvolvedRole == Constants.UserRoles.WC.ToString())
                                                frm.UCStatus = Constants.Status.Pending.ToString();
                                            unitofWork.ReviewRespository.Update(frm);
                                            unitofWork.Commit();
                                        }

                                    }
                                    else
                                    {
                                        frm.UCID = UCID;
                                        if (frm.InvolvedRole == Constants.UserRoles.DSG.ToString() || frm.InvolvedRole == Constants.UserRoles.SGT.ToString())
                                            frm.UCStatus = Constants.Status.Completed.ToString();
                                        else if (frm.InvolvedRole == Constants.UserRoles.WC.ToString())
                                            frm.UCStatus = Constants.Status.Pending.ToString();
                                        unitofWork.ReviewRespository.Update(frm);
                                        unitofWork.Commit();
                                    }
                                }
                            }
                            IncidentWorkflow WfModel = unitofWork.IncidentWorkflowRepository.GetAll().Where(x => x.IncidentId == incidentId).FirstOrDefault();
                            if (WfModel != null)
                            {
                                WfModel.UCID = UCID;
                                WfModel.UCStatus = Constants.Status.Pending.ToString();
                                WfModel.CFRCStatus = Constants.Status.Completed.ToString();
                                WfModel.CFRTStatus = Constants.Status.Completed.ToString();
                                unitofWork.IncidentWorkflowRepository.Update(WfModel);
                                unitofWork.Commit();
                            }
                            wf.updateIncident(incidentId, Convert.ToString((int)Constants.IncidentStatus.AtUnitCommander));
                        }
                    }
                    else
                    {

                        if (model.UserTypeId == (int)Constants.UserType.WatchCommander)
                        {
                            WCID = model.ChangedEmpId;

                            VerifyAndUpdateUser(model, (int)Constants.UserType.WatchCommander);

                            requiredRoleTypeIds = new string[] { Constants.UserRoles.SGT.ToString(), Constants.UserRoles.DSG.ToString() };
                            List<IncidentFormReview> Existmodel = unitofWork.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && (x.InvolvedRole == Constants.UserRoles.DSG.ToString() || x.InvolvedRole == Constants.UserRoles.SGT.ToString())).ToList();
                            foreach (var frm in Existmodel)
                            {
                                if (frm != null)
                                {
                                    FormReviewRank rankResult = (from review in unitofWork.FormReviewRankRespository.GetAll() where review.FormId == frm.FormId && review.Active == true select review).FirstOrDefault();
                                    if (rankResult != null)
                                    {
                                        if (rankResult.ReviewRank == 3)
                                        {
                                            frm.WCStatus = Constants.Status.Pending.ToString();
                                            unitofWork.ReviewRespository.Update(frm);
                                            unitofWork.Commit();
                                        }
                                        else
                                        {
                                            frm.WCID = WCID;
                                            if (frm.InvolvedRole == Constants.UserRoles.DSG.ToString())
                                                frm.WCStatus = Constants.Status.Completed.ToString();
                                            else if (frm.InvolvedRole == Constants.UserRoles.SGT.ToString())
                                                frm.WCStatus = Constants.Status.Pending.ToString();
                                            unitofWork.ReviewRespository.Update(frm);
                                            unitofWork.Commit();
                                        }

                                    }
                                    else
                                    {
                                        frm.WCID = WCID;
                                        if (frm.InvolvedRole == Constants.UserRoles.DSG.ToString())
                                            frm.WCStatus = Constants.Status.Completed.ToString();
                                        else if (frm.InvolvedRole == Constants.UserRoles.SGT.ToString())
                                            frm.WCStatus = Constants.Status.Pending.ToString();
                                        unitofWork.ReviewRespository.Update(frm);
                                        unitofWork.Commit();
                                    }
                                }
                            }

                            IncidentWorkflow WfModel = unitofWork.IncidentWorkflowRepository.GetAll().Where(x => x.IncidentId == incidentId).FirstOrDefault();
                            if (WfModel != null)
                            {
                                WfModel.WCID = WCID;
                                WfModel.WCStatus = Constants.Status.Pending.ToString();
                                unitofWork.IncidentWorkflowRepository.Update(WfModel);
                                unitofWork.Commit();
                            }

                            wf.updateIncident(incidentId, Convert.ToString((int)Constants.IncidentStatus.AtWatchCommander));

                        }
                        else if (model.UserTypeId == (int)Constants.UserType.UnitCommander)
                        {
                            UCID = model.ChangedEmpId;
                            VerifyAndUpdateUser(model, (int)Constants.UserType.UnitCommander);
                            requiredRoleTypeIds = new string[] { Constants.UserRoles.SGT.ToString(), Constants.UserRoles.DSG.ToString(), Constants.UserRoles.WC.ToString() };
                            List<IncidentFormReview> Existingmodel = unitofWork.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && (x.InvolvedRole == Constants.UserRoles.DSG.ToString() || x.InvolvedRole == Constants.UserRoles.SGT.ToString() || x.InvolvedRole == Constants.UserRoles.WC.ToString())).ToList();
                            foreach (var frm in Existingmodel)
                            {
                                if (frm != null)
                                {
                                    FormReviewRank rankResult = (from review in unitofWork.FormReviewRankRespository.GetAll() where review.FormId == frm.FormId && review.Active == true select review).FirstOrDefault();
                                    if (rankResult != null)
                                    {
                                        if (rankResult.ReviewRank == 4)
                                        {
                                            frm.UCStatus = Constants.Status.Pending.ToString();
                                            unitofWork.ReviewRespository.Update(frm);
                                            unitofWork.Commit();
                                        }
                                        else
                                        {
                                            frm.UCID = UCID;
                                            if (frm.InvolvedRole == Constants.UserRoles.DSG.ToString() || frm.InvolvedRole == Constants.UserRoles.SGT.ToString())
                                                frm.UCStatus = Constants.Status.Completed.ToString();
                                            else if (frm.InvolvedRole == Constants.UserRoles.WC.ToString())
                                                frm.UCStatus = Constants.Status.Pending.ToString();
                                            unitofWork.ReviewRespository.Update(frm);
                                            unitofWork.Commit();
                                        }

                                    }
                                    else
                                    {
                                        frm.UCID = UCID;
                                        if (frm.InvolvedRole == Constants.UserRoles.DSG.ToString() || frm.InvolvedRole == Constants.UserRoles.SGT.ToString())
                                            frm.UCStatus = Constants.Status.Completed.ToString();
                                        else if (frm.InvolvedRole == Constants.UserRoles.WC.ToString())
                                            frm.UCStatus = Constants.Status.Pending.ToString();
                                        unitofWork.ReviewRespository.Update(frm);
                                        unitofWork.Commit();
                                    }
                                }
                            }
                            IncidentWorkflow WfModel = unitofWork.IncidentWorkflowRepository.GetAll().Where(x => x.IncidentId == incidentId).FirstOrDefault();
                            if (WfModel != null)
                            {
                                WfModel.UCID = UCID;
                                WfModel.UCStatus = Constants.Status.Pending.ToString();
                                unitofWork.IncidentWorkflowRepository.Update(WfModel);
                                unitofWork.Commit();
                            }
                            wf.updateIncident(incidentId, Convert.ToString((int)Constants.IncidentStatus.AtUnitCommander));
                        }
                        else if (model.UserTypeId == (int)Constants.UserType.Commander)
                        {
                            CMID = model.ChangedEmpId;
                            VerifyAndUpdateUser(model, (int)Constants.UserType.Commander);
                            requiredRoleTypeIds = new string[] { Constants.UserRoles.SGT.ToString(), Constants.UserRoles.DSG.ToString(), Constants.UserRoles.WC.ToString(), Constants.UserRoles.CAPT.ToString() };
                            List<IncidentFormReview> Existingmodel = unitofWork.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && (x.InvolvedRole == Constants.UserRoles.DSG.ToString() || x.InvolvedRole == Constants.UserRoles.SGT.ToString() || x.InvolvedRole == Constants.UserRoles.WC.ToString()) || x.InvolvedRole == Constants.UserRoles.CAPT.ToString()).ToList();
                            foreach (var frm in Existingmodel)
                            {
                                if (frm != null)
                                {
                                    FormReviewRank rankResult = (from review in unitofWork.FormReviewRankRespository.GetAll() where review.FormId == frm.FormId && review.Active == true select review).FirstOrDefault();
                                    if (rankResult != null)
                                    {
                                        if (rankResult.ReviewRank == 5)
                                        {
                                            frm.CMStatus = Constants.Status.Pending.ToString();
                                            unitofWork.ReviewRespository.Update(frm);
                                            unitofWork.Commit();
                                        }
                                        else
                                        {
                                            frm.CMID = CMID;
                                            if (frm.InvolvedRole == Constants.UserRoles.DSG.ToString() || frm.InvolvedRole == Constants.UserRoles.SGT.ToString() || frm.InvolvedRole == Constants.UserRoles.WC.ToString())
                                                frm.CMStatus = Constants.Status.Completed.ToString();
                                            else if (frm.InvolvedRole == Constants.UserRoles.CAPT.ToString())
                                                frm.CMStatus = Constants.Status.Pending.ToString();
                                            unitofWork.ReviewRespository.Update(frm);
                                            unitofWork.Commit();
                                        }

                                    }
                                    else
                                    {
                                        frm.CMID = CMID;
                                        if (frm.InvolvedRole == Constants.UserRoles.DSG.ToString() || frm.InvolvedRole == Constants.UserRoles.SGT.ToString() || frm.InvolvedRole == Constants.UserRoles.WC.ToString())
                                            frm.CMStatus = Constants.Status.Completed.ToString();
                                        else if (frm.InvolvedRole == Constants.UserRoles.CAPT.ToString())
                                            frm.CMStatus = Constants.Status.Pending.ToString();
                                        unitofWork.ReviewRespository.Update(frm);
                                        unitofWork.Commit();
                                    }
                                }
                            }
                            IncidentWorkflow WfModel = unitofWork.IncidentWorkflowRepository.GetAll().Where(x => x.IncidentId == incidentId).FirstOrDefault();
                            if (WfModel != null)
                            {
                                WfModel.CMID = CMID;
                                WfModel.CMStatus = Constants.Status.Pending.ToString();
                                unitofWork.IncidentWorkflowRepository.Update(WfModel);
                                unitofWork.Commit();
                            }
                            wf.updateIncident(incidentId, Convert.ToString((int)Constants.IncidentStatus.AtCommander));
                        }
                        else if (model.UserTypeId == (int)Constants.UserType.Chief)
                        {
                            DCID = model.ChangedEmpId;
                            VerifyAndUpdateUser(model, (int)Constants.UserType.Chief);
                            requiredRoleTypeIds = new string[] { Constants.UserRoles.SGT.ToString(), Constants.UserRoles.DSG.ToString(), Constants.UserRoles.WC.ToString(), Constants.UserRoles.CAPT.ToString(), Constants.UserRoles.DC.ToString() };
                            List<IncidentFormReview> Existingmodel = unitofWork.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && (x.InvolvedRole == Constants.UserRoles.DSG.ToString() || x.InvolvedRole == Constants.UserRoles.SGT.ToString() || x.InvolvedRole == Constants.UserRoles.WC.ToString()) || x.InvolvedRole == Constants.UserRoles.CAPT.ToString() || x.InvolvedRole == Constants.UserRoles.CMDR.ToString()).ToList();
                            foreach (var frm in Existingmodel)
                            {
                                if (frm != null)
                                {
                                    //frm.DCID = DCID;
                                    if (frm.InvolvedRole == Constants.UserRoles.DSG.ToString() || frm.InvolvedRole == Constants.UserRoles.SGT.ToString() || frm.InvolvedRole == Constants.UserRoles.WC.ToString() || frm.InvolvedRole == Constants.UserRoles.CAPT.ToString() || frm.InvolvedRole == Constants.UserRoles.CMDR.ToString())
                                        frm.DCStatus = Constants.Status.Completed.ToString();
                                    unitofWork.ReviewRespository.Update(frm);
                                    unitofWork.Commit();
                                }
                            }
                            IncidentWorkflow WfModel = unitofWork.IncidentWorkflowRepository.GetAll().Where(x => x.IncidentId == incidentId).FirstOrDefault();
                            if (WfModel != null)
                            {
                                WfModel.DCID = DCID;
                                WfModel.DCStatus = Constants.Status.Pending.ToString();
                                unitofWork.IncidentWorkflowRepository.Update(WfModel);
                                unitofWork.Commit();
                            }
                            wf.updateIncident(incidentId, Convert.ToString((int)Constants.IncidentStatus.AtChief));
                        }
                    }

                    #region Audit log into Incident Package Table
                    using (IncidentPackageRepository obj = new IncidentPackageRepository())
                    {
                        obj.InsertUpdatePackage(new PackageEntity
                        {
                            ChangedEmpId = model.ChangedEmpId,
                            ExistingEmpId = model.ExistingEmpId,
                            IncidentId = model.IncidentId,
                            UserTypeId = model.UserTypeId,
                            CreatedBy = model.CreatedBy,
                            CreatedDate = DateTime.Now,
                            Active = true
                        });
                    }

                    #endregion

                    #region Email Notification
                    EmailRepository email = new EmailRepository();
                    email.EmailNotification(new EmailNotificationModel
                    {
                        Department = "Assign",
                        EmailId = model.EmailId,
                        IncidentId = Convert.ToInt32(model.IncidentId),
                        EmployeeNumber = model.ChangedEmpId,
                    });
                    #endregion
                    transaction.Complete();
                    return true;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return true;
        }

        private void VerifyAndUpdateUser(ChangeOwnerModel model, int userTypeId)
        {
            //Checking  user already inserted or not.
            var usr = (from s in unitofWork.UserRepository.GetAll()
                       join f in unitofWork.IncidentUserRepository.GetAll() on s.UserId equals f.UserId
                       where f.IncidentId == model.IncidentId && s.ForceEmployeeId == model.ExistingEmpId && f.UserTypeId == userTypeId
                       select s).FirstOrDefault();
            if (usr != null)
            {
                UserDetail userDetail = unitofWork.UserDetailRepository.GetAll().Where(x => x.UserDetailId == usr.UserDetailId).FirstOrDefault();
                if (userDetail != null)
                {
                    userDetail.FirstName = model.ChangedEmmFirstName;
                    userDetail.LastName = model.ChangedEmpLastName;
                    userDetail.Rank = model.ChangedEmpRank;
                    userDetail.EmailId = model.EmailId;
                    unitofWork.UserDetailRepository.Update(userDetail);
                    unitofWork.Commit();
                }
                usr.ForceEmployeeId = model.ChangedEmpId;
                unitofWork.UserRepository.Update(usr);
                unitofWork.Commit();
            }
        }

        public bool AssigntoCommander_old(List<WitnessUserEntity> Commanders)
        {
            int incidentId = 0;
            string WCID = string.Empty, UCID = string.Empty, CMID = string.Empty;
            WitnessUserEntity Rmodel = new WitnessUserEntity();
            try
            {
                using (var transaction = new TransactionScope())
                {
                    foreach (WitnessUserEntity item in Commanders)
                    {
#if DEBUG
                        item.UserTypeId = (int)Constants.UserType.UnitCommander;
#endif
                        string reviwerId = string.Empty;
                        IncidentUserEntity incidentUserEntity = new IncidentUserEntity();
                        incidentId = item.IncidentId;
                        incidentUserEntity.FirstName = item.FirstName;
                        incidentUserEntity.MiddleName = item.MiddleName;
                        incidentUserEntity.LastName = item.LastName;
                        incidentUserEntity.Rank = item.Rank;
                        incidentUserEntity.UserTypeId = item.UserTypeId;
                        incidentUserEntity.IncidentId = item.IncidentId;
                        incidentUserEntity.ForceEmployeeId = item.EmployeeId;
                        incidentUserEntity.CreatedOn = DateTime.Now;

                        SaveIncidentUser(incidentUserEntity);

                        if (item.UserTypeId == (int)Constants.UserType.UnitCommander)
                        {
                            UCID = item.EmployeeId;
                            Rmodel = Commanders.Where(x => x.IncidentId == item.IncidentId && x.UserTypeId == (int)Constants.UserType.UnitCommander).FirstOrDefault();
                            //incidentUserEntity.ReviewerId = Rmodel.EmployeeId;

                            #region Inserting Unit Commander Forms
                            //Insert Unit Commander Review Form
                            repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                            {
                                IncidentID = incidentId,
                                FormId = (int)Constants.UOFForms.UnitCommanderUseoFForceReview,
                                SubmitteduserRole = Constants.UserRoles.CAPT.ToString(),
                                SubmittedStatus = Constants.Status.Pending.ToString(),
                                SubmittedEmpId = UCID,
                                ReviewerRole = Constants.UserRoles.CMDR.ToString(),
                                UCStatus = Constants.Status.Pending.ToString(),
                                UCID = UCID,
                                CMID = CMID,
                            });
                            ////Insert UOF Review Notices forms
                            //repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                            //{
                            //    IncidentID = incidentId,
                            //    FormId = (int)Constants.UOFForms.UseofForceReviewNotice,
                            //    SubmitteduserRole = Constants.UserRoles.CAPT.ToString(),
                            //    SubmittedStatus = Constants.Status.Pending.ToString(),
                            //    SubmittedEmpId = UCID,
                            //    ReviewerRole = Constants.UserRoles.CMDR.ToString(),
                            //    UCStatus = Constants.Status.Pending.ToString(),
                            //    UCID = UCID,
                            //});
                            #endregion

                            //List<IncidentFormReview> model = unitofWork.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && x.InvolvedRole == Constants.UserRoles.DSG.ToString() && x.InvolvedRole == Constants.UserRoles.SGT.ToString() && x.InvolvedRole == Constants.UserRoles.WC.ToString()).ToList();
                            List<IncidentFormReview> model = unitofWork.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && (x.InvolvedRole == Constants.UserRoles.DSG.ToString() || x.InvolvedRole == Constants.UserRoles.SGT.ToString() || x.InvolvedRole == Constants.UserRoles.WC.ToString())).ToList();
                            foreach (var frm in model)
                            {
                                if (frm != null)
                                {
                                    frm.UCID = UCID;
                                    if (frm.InvolvedRole == Constants.UserRoles.DSG.ToString() || frm.InvolvedRole == Constants.UserRoles.SGT.ToString())
                                        frm.UCStatus = Constants.Status.Completed.ToString();
                                    else if (frm.InvolvedRole == Constants.UserRoles.WC.ToString())
                                        frm.UCStatus = Constants.Status.Pending.ToString();
                                    unitofWork.ReviewRespository.Update(frm);
                                    unitofWork.Commit();
                                }
                            }

                            IncidentWorkflow WfModel = unitofWork.IncidentWorkflowRepository.GetAll().Where(x => x.IncidentId == incidentId).FirstOrDefault();
                            if (WfModel != null)
                            {
                                WfModel.UCID = UCID;
                                WfModel.UCStatus = Constants.Status.Pending.ToString();
                                unitofWork.IncidentWorkflowRepository.Update(WfModel);
                                unitofWork.Commit();
                            }
                            wf.updateIncident(incidentId, Convert.ToString((int)Constants.IncidentStatus.AtUnitCommander));
                        }
                        else if (item.UserTypeId == (int)Constants.UserType.Commander)
                        {
                            CMID = item.EmployeeId;
                            #region Inserting Commander Forms
                            //Insert Commander Review Form
                            repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                            {
                                IncidentID = incidentId,
                                FormId = (int)Constants.UOFForms.CommanderUseofForceReview,
                                SubmitteduserRole = Constants.UserRoles.CMDR.ToString(),
                                SubmittedStatus = Constants.Status.Pending.ToString(),
                                ReviewerRole = Constants.UserRoles.CMDR.ToString(),
                                CMID = CMID,
                                SubmittedEmpId = CMID,
                                CMStatus = Constants.Status.NotReady.ToString(),
                            });
                            #endregion


                            //List<IncidentFormReview> model = unitofWork.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && x.InvolvedRole == Constants.UserRoles.DSG.ToString() && x.InvolvedRole == Constants.UserRoles.SGT.ToString() && x.InvolvedRole == Constants.UserRoles.WC.ToString() && x.InvolvedRole == Constants.UserRoles.CAPT.ToString()).ToList();
                            List<IncidentFormReview> model = unitofWork.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && (x.InvolvedRole == Constants.UserRoles.DSG.ToString() || x.InvolvedRole == Constants.UserRoles.SGT.ToString() || x.InvolvedRole == Constants.UserRoles.WC.ToString()) || x.InvolvedRole == Constants.UserRoles.CAPT.ToString()).ToList();
                            foreach (var frm in model)
                            {
                                if (frm != null)
                                {
                                    frm.CMID = CMID;
                                    if (frm.InvolvedRole == Constants.UserRoles.DSG.ToString() || frm.InvolvedRole == Constants.UserRoles.SGT.ToString() || frm.InvolvedRole == Constants.UserRoles.WC.ToString())
                                        frm.CMStatus = Constants.Status.Completed.ToString();
                                    else if (frm.InvolvedRole == Constants.UserRoles.CAPT.ToString())
                                        frm.CMStatus = Constants.Status.Pending.ToString();
                                    unitofWork.ReviewRespository.Update(frm);
                                    unitofWork.Commit();
                                }
                            }
                            IncidentWorkflow WfModel = unitofWork.IncidentWorkflowRepository.GetAll().Where(x => x.IncidentId == incidentId).FirstOrDefault();
                            if (WfModel != null)
                            {
                                WfModel.CMID = CMID;
                                WfModel.CMStatus = Constants.Status.Pending.ToString();
                                unitofWork.IncidentWorkflowRepository.Update(WfModel);
                                unitofWork.Commit();
                            }
                            wf.updateIncident(incidentId, Convert.ToString((int)Constants.IncidentStatus.AtCommander));
                        }



                        #region Email Notification
                        EmailRepository email = new EmailRepository();
                        email.EmailNotification(new EmailNotificationModel
                        {
                            Department = "Assign",
                            EmailId = item.EmailId,
                            IncidentId = Convert.ToInt32(item.IncidentId),
                            EmployeeNumber = item.EmployeeId,
                        });
                        #endregion
                    }
                    transaction.Complete();
                    return true;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return true;
        }

        //This method is calling from the Invovled, Emp Wit, Suspect, Non Emp Wit
        public bool DeleteUser(int incidentId, int userId, string employeeNumber, int userType)
        {
            //int IndId = Convert.ToInt32(incidentId);
            //int usrId = Convert.ToInt32(userId);
            using (var transaction = new TransactionScope())
            {
                if (userType == 1)
                {

                    var usr = (from s in unitofWork.UserRepository.GetAll()
                               join f in unitofWork.IncidentUserRepository.GetAll() on s.UserId equals f.UserId
                               join g in unitofWork.IncidentUserInvolvedRepository.GetAll() on f.IncidentUserId equals g.IncidentUserId
                               where f.IncidentId == incidentId && f.UserTypeId == userType && g.IncidentUserInvolvedId == userId
                               select s).FirstOrDefault();
                    if (usr != null)
                    {
                        usr.Active = false;
                        unitofWork.UserRepository.Update(usr);
                        unitofWork.Commit();


                        //IncidentUserInvolved deleteRecord = unitofWork.IncidentUserInvolvedRepository.GetById(userId);
                        //if (deleteRecord != null)
                        //{
                        //    //unitofWork.IncidentUserInvolvedRepository.Delete(deleteRecord);
                        //    unitofWork.Commit();
                        List<IncidentFormReview> model = unitofWork.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && x.InvolvedId == employeeNumber).ToList();
                        foreach (var frm in model)
                        {
                            if (frm != null)
                            {
                                unitofWork.ReviewRespository.Delete(frm);
                                unitofWork.Commit();
                            }
                        }
                        transaction.Complete();
                        return true;
                        ////}
                        //else
                        //{
                        //    return false;
                        //}
                    }
                }
                else if (userType == 2)
                {
                    var usr = (from s in unitofWork.UserRepository.GetAll()
                               join f in unitofWork.IncidentUserRepository.GetAll() on s.UserId equals f.UserId
                               join g in unitofWork.IncidentUserSuspectRepository.GetAll() on f.IncidentUserId equals g.IncidentUserId
                               where f.IncidentId == incidentId && f.UserTypeId == userType && g.IncidentUserSuspectId == userId
                               select s).FirstOrDefault();
                    if (usr != null)
                    {
                        usr.Active = false;
                        unitofWork.UserRepository.Update(usr);
                        unitofWork.Commit();
                    }
                    transaction.Complete();
                    return true;
                }
                else if (userType == 3)
                {
                    var usr = (from s in unitofWork.UserRepository.GetAll()
                               join f in unitofWork.IncidentUserRepository.GetAll() on s.UserId equals f.UserId
                               join g in unitofWork.IncidentUserWitnessRepository.GetAll() on f.IncidentUserId equals g.IncidentUserId
                               where f.IncidentId == incidentId && f.UserTypeId == userType && g.IncidentUserWitnessId == userId
                               select s).FirstOrDefault();
                    if (usr != null)
                    {
                        usr.Active = false;
                        unitofWork.UserRepository.Update(usr);
                        unitofWork.Commit();

                        List<IncidentFormReview> model = unitofWork.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && x.InvolvedId == employeeNumber).ToList();
                        List<IncidentFormData> frmData = unitofWork.UOFIncidentFormDataRepository.GetAll().Where(x => x.IncidentID == incidentId && x.EmpID == employeeNumber).ToList();
                        foreach (var frm in model)
                        {
                            if (frm != null)
                            {
                                unitofWork.ReviewRespository.Delete(frm);
                                unitofWork.Commit();
                            }
                        }
                        foreach (var frm in frmData)
                        {
                            if (frm != null)
                            {
                                unitofWork.UOFIncidentFormDataRepository.Delete(frm);
                                unitofWork.Commit();
                            }
                        }
                    }
                    transaction.Complete();
                    return true;
                }
                else if (userType == 4)
                {
                    var usr = (from s in unitofWork.UserRepository.GetAll()
                               join f in unitofWork.IncidentUserRepository.GetAll() on s.UserId equals f.UserId
                               join g in unitofWork.IncidentUserWitnessRepository.GetAll() on f.IncidentUserId equals g.IncidentUserId
                               where f.IncidentId == incidentId && f.UserTypeId == userType && g.IncidentUserWitnessId == userId
                               select s).FirstOrDefault();
                    if (usr != null)
                    {
                        usr.Active = false;
                        unitofWork.UserRepository.Update(usr);
                        unitofWork.Commit();

                    }
                    transaction.Complete();
                    return true;
                }
                return false;
            }

            //public bool AssigntoCommander(List<WitnessUserEntity> Commanders)
            //{
            //    int incidentId = 0;
            //    string WCID = string.Empty, UCID = string.Empty, CMID = string.Empty;
            //    WitnessUserEntity Rmodel = new WitnessUserEntity();
            //    foreach (WitnessUserEntity item in Commanders)
            //    {
            //        string reviwerId = string.Empty;
            //        IncidentUserEntity incidentUserEntity = new IncidentUserEntity();
            //        incidentId = item.IncidentId;
            //        incidentUserEntity.FirstName = item.FirstName;
            //        incidentUserEntity.MiddleName = item.MiddleName;
            //        incidentUserEntity.LastName = item.LastName;
            //        incidentUserEntity.Rank = item.Rank;
            //        incidentUserEntity.UserTypeId = item.UserTypeId;
            //        incidentUserEntity.IncidentId = item.IncidentId;
            //        incidentUserEntity.ForceEmployeeId = item.EmployeeId;
            //        incidentUserEntity.CreatedOn = DateTime.Now;

            //        if (item.UserTypeId == (int)Constants.UserType.WatchCommander)
            //        {
            //            WCID = item.EmployeeId;
            //            Rmodel = Commanders.Where(x => x.IncidentId == item.IncidentId && x.UserTypeId == 6).FirstOrDefault();
            //            incidentUserEntity.ReviewerId = Rmodel.EmployeeId;
            //        }
            //        else if (item.UserTypeId == (int)Constants.UserType.UnitCommander)
            //        {
            //            UCID = item.EmployeeId;
            //            Rmodel = Commanders.Where(x => x.IncidentId == item.IncidentId && x.UserTypeId == 7).FirstOrDefault();
            //            //incidentUserEntity.ReviewerId = Rmodel.EmployeeId;
            //        }
            //        else if (item.UserTypeId == (int)Constants.UserType.Commander)
            //            CMID = item.EmployeeId;

            //        SaveIncidentUser(incidentUserEntity);

            //        #region Email Notification
            //        EmailRepository email = new EmailRepository();
            //        email.EmailNotification(new EmailNotificationModel
            //        {
            //            Department = "Assign",
            //            EmailId = item.EmailId,
            //            IncidentId = Convert.ToInt32(item.IncidentId),
            //            EmployeeNumber = item.EmployeeId,
            //        });
            //        #endregion
            //    }
            //    IncidentWorkflow WfModel = unitofWork.IncidentWorkflowRepository.GetAll().Where(x => x.IncidentId == incidentId).FirstOrDefault();
            //    if (WfModel != null)
            //    {
            //        WfModel.SergeantStatus = "At Watch Commander";
            //        WfModel.WCID = WCID;
            //        WfModel.WCStatus = Constants.Status.Pending.ToString();
            //        WfModel.UCID = UCID;
            //        WfModel.UCStatus = Constants.Status.NotReady.ToString();
            //        WfModel.CMID = CMID;
            //        WfModel.CMStatus = Constants.Status.NotReady.ToString();
            //        unitofWork.IncidentWorkflowRepository.Update(WfModel);
            //        unitofWork.Commit();
            //    }

            //    #region Assigning Sergeant and Involved Employee Forms to WatchCommander
            //    List<IncidentFormReview> SRmodel = unitofWork.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && x.InvolvedRole == Constants.UserRoles.SGT.ToString()).ToList();
            //    foreach (var item in SRmodel)
            //    {
            //        if (item != null)
            //        {
            //            item.WCID = WCID;
            //            item.UCID = UCID;
            //            item.CMID = CMID;
            //            item.WCStatus = Constants.Status.Pending.ToString();
            //            item.UCStatus = Constants.Status.NotReady.ToString();
            //            item.CMStatus = Constants.Status.NotReady.ToString();
            //            unitofWork.ReviewRespository.Update(item);
            //            unitofWork.Commit();
            //        }
            //    }
            //    List<IncidentFormReview> model = unitofWork.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && x.InvolvedRole == Constants.UserRoles.DSG.ToString()).ToList();
            //    foreach (var item in model)
            //    {
            //        if (item != null)
            //        {
            //            item.WCID = WCID;
            //            item.UCID = UCID;
            //            item.CMID = CMID;
            //            item.WCStatus = Constants.Status.Pending.ToString();
            //            item.UCStatus = Constants.Status.NotReady.ToString();
            //            item.CMStatus = Constants.Status.NotReady.ToString();
            //            unitofWork.ReviewRespository.Update(item);
            //            unitofWork.Commit();
            //        }
            //    }
            //    #endregion



            //    #region Inserting Unit Commander Forms
            //    //Insert Unit Commander Review Form
            //    repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
            //    {
            //        IncidentID = incidentId,
            //        FormId = (int)Constants.UOFForms.UnitCommanderUseoFForceReview,
            //        SubmitteduserRole = Constants.UserRoles.CAPT.ToString(),
            //        SubmittedStatus = Constants.Status.Pending.ToString(),
            //        SubmittedEmpId = UCID,
            //        ReviewerRole = Constants.UserRoles.CMDR.ToString(),
            //        UCStatus = Constants.Status.Pending.ToString(),
            //        UCID = UCID,
            //        CMID = CMID,
            //    });
            //    #endregion

            //    #region Inserting Commander Forms
            //    //Insert Commander Review Form
            //    repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
            //    {
            //        IncidentID = incidentId,
            //        FormId = (int)Constants.UOFForms.CommanderUseofForceReview,
            //        SubmitteduserRole = Constants.UserRoles.CMDR.ToString(),
            //        SubmittedStatus = Constants.Status.Pending.ToString(),
            //        ReviewerRole = Constants.UserRoles.CMDR.ToString(),
            //        SubmittedEmpId = CMID,
            //        CMStatus = Constants.Status.NotReady.ToString(),
            //    });
            //    #endregion
            //    wf.updateIncident(incidentId, Convert.ToString((int)Constants.IncidentStatus.AtWatchCommander));
            //    return true;
            //}
        }
    }
}

//delete from dbo.IncidentUser
//delete from dbo.[User]
//delete from dbo.UserDetail
//delete from dbo.IncidentUserSuspect
//delete from dbo.IncidentUserInvolved
//delete from IncidentUserWitness
//delete from Incident
//delete from Address
