﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using UOF.Common.EntityModel;
using UOF.DataAccess.Repository;
using UOF.Common.Utilities;

namespace UOF.DataAccess.DbRepository
{
    public class InmateInjuryRepository
    {
        UnitOfWork uow = new UnitOfWork();

        public int SaveInmateInjury(InmateInjuryBusinessModel inmateInjuryBusinessModel)
        {
            int result = 0;
            try
            {
                FormReviewRespository repo = new FormReviewRespository();
                inmateInjuryBusinessModel.UserRoleId = repo.GetUserRoleID(inmateInjuryBusinessModel.UserRole);
                int FormDataId = 0;
                //inmateInjuryBusinessModel.FormID = (int)Constants.UOFForms.InmateInjury;
                inmateInjuryBusinessModel.UserRoleId = (int)Constants.UserRoles.DSG;
                var inmateModel = uow.UOFIncidentFormDataRepository.FindBy(a => a.UserRoleId == inmateInjuryBusinessModel.UserRoleId && a.FormID == inmateInjuryBusinessModel.FormID && a.IncidentID == inmateInjuryBusinessModel.IncidentID && a.EmpID == inmateInjuryBusinessModel.EmpId && a.FormDataID == inmateInjuryBusinessModel.formDataId).FirstOrDefault();
                if (inmateInjuryBusinessModel.isApproval)
                {
                    inmateModel = uow.UOFIncidentFormDataRepository.FindBy(a => a.FormID == inmateInjuryBusinessModel.FormID && a.IncidentID == inmateInjuryBusinessModel.IncidentID && a.EmpID == inmateInjuryBusinessModel.SubmitedId && a.FormDataID == inmateInjuryBusinessModel.formDataId).FirstOrDefault();
                    if (inmateModel != null)
                    {
                        FormDataId = inmateInjuryBusinessModel.formDataId;
                        inmateModel.IncidentID = inmateModel.IncidentID;
                        inmateModel.XmlData = inmateInjuryBusinessModel.Serialize();
                        inmateModel.UpdateBy = inmateInjuryBusinessModel.EmpId;
                        inmateModel.UpdateOn = DateTime.Now;
                        uow.UOFIncidentFormDataRepository.Update(inmateModel);
                        uow.Commit();
                        using (LookupRespository lp = new LookupRespository())
                        {
                            lp.ApproveorReject(new ReviewEntity { IncidentId = inmateInjuryBusinessModel.IncidentID, DeputyEmpId = inmateInjuryBusinessModel.SubmitedId, ReviewerReviewId = inmateInjuryBusinessModel.EmpId, FormId = inmateInjuryBusinessModel.FormID, ReviewerRole = inmateInjuryBusinessModel.UserRole, isApprove = "Y", IncidentReviewId = inmateInjuryBusinessModel.IncidentReviewId });
                        }
                    }
                    result = inmateModel.FormDataID;
                }
                else if (inmateInjuryBusinessModel.isMedical)
                {
                    inmateModel = uow.UOFIncidentFormDataRepository.FindBy(a => a.FormID == inmateInjuryBusinessModel.FormID && a.IncidentID == inmateInjuryBusinessModel.IncidentID && a.EmpID == inmateInjuryBusinessModel.SubmitedId && a.FormDataID == inmateInjuryBusinessModel.formDataId).FirstOrDefault();
                    if (inmateModel != null)
                    {
                        FormDataId = inmateInjuryBusinessModel.formDataId;
                        inmateModel.IncidentID = inmateModel.IncidentID;
                        inmateModel.XmlData = inmateInjuryBusinessModel.Serialize();
                        inmateModel.UpdateBy = inmateInjuryBusinessModel.EmpId;
                        inmateModel.UpdateOn = DateTime.Now;
                        uow.UOFIncidentFormDataRepository.Update(inmateModel);
                        uow.Commit();
                        result = inmateModel.FormDataID;
                    }
                    else
                    {
                        var inmate = new IncidentFormData();
                        inmate.IncidentID = inmateInjuryBusinessModel.IncidentID;
                        inmate.EmpID = inmateInjuryBusinessModel.EmpId;
                        inmate.CreatedOn = DateTime.Now;
                        inmate.CreatedBy = inmateInjuryBusinessModel.EmpId;
                        inmate.FormID = inmateInjuryBusinessModel.FormID;
                        inmate.UserRoleId = inmateInjuryBusinessModel.UserRoleId;
                        inmate.XmlData = inmateInjuryBusinessModel.Serialize();
                        inmate.Status = Constants.Status.PND.ToString();
                        uow.UOFIncidentFormDataRepository.Add(inmate);
                        uow.Commit();
                        FormDataId = inmate.FormDataID;
                        result = FormDataId;
                    }
                    var checkMedical = uow.IncidentMedicalRespository.GetAll().Where(x => x.IncidentId == inmateInjuryBusinessModel.IncidentID && x.FormId == inmateInjuryBusinessModel.FormID && x.Active == true).ToList();
                    if (checkMedical.Count > 0) {
                        foreach (var frm in checkMedical)
                        {
                            frm.Active = false;
                            uow.IncidentMedicalRespository.Update(frm);
                            uow.Commit();
                        }
                    }

                        //Insert into Medical Table
                        IncidentMedicalUser medUser = new IncidentMedicalUser();
                    medUser.IncidentId = inmateInjuryBusinessModel.IncidentID;
                    medUser.FormId = inmateInjuryBusinessModel.FormID;
                    medUser.EmpId = inmateInjuryBusinessModel.EmpId;
                    medUser.CreatedBy = inmateInjuryBusinessModel.EmpId;
                    medUser.CreatedDate = DateTime.Now;
                    medUser.Active = true;
                    uow.IncidentMedicalRespository.Add(medUser);
                    uow.Commit();
                    //End

                   

                    repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                    {
                        FormDataId = FormDataId,
                        IncidentID = inmateInjuryBusinessModel.IncidentID,
                        IncidentReviewID = inmateInjuryBusinessModel.IncidentReviewId,
                        SubmittedEmpId = inmateInjuryBusinessModel.EmpId,
                        FormId = inmateInjuryBusinessModel.FormID,
                        WCStatus = Constants.Status.Pending.ToString(),
                    });
                }
                else
                {
                    if (inmateModel != null)
                    {
                        inmateModel.IncidentID = inmateInjuryBusinessModel.IncidentID;
                        inmateModel.XmlData = inmateInjuryBusinessModel.Serialize();
                        inmateModel.UpdateBy = inmateInjuryBusinessModel.EmpId;
                        inmateModel.UpdateOn = DateTime.Now;
                        uow.UOFIncidentFormDataRepository.Update(inmateModel);
                        result = inmateModel.FormDataID;
                        uow.Commit();
                    }
                    else
                    {
                        var inmate = new IncidentFormData();
                        inmate.IncidentID = inmateInjuryBusinessModel.IncidentID;
                        inmate.EmpID = inmateInjuryBusinessModel.EmpId;
                        inmate.CreatedOn = DateTime.Now;
                        inmate.CreatedBy = inmateInjuryBusinessModel.EmpId;
                        inmate.FormID = inmateInjuryBusinessModel.FormID;
                        inmate.UserRoleId = inmateInjuryBusinessModel.UserRoleId;
                        inmate.XmlData = inmateInjuryBusinessModel.Serialize();
                        inmate.Status = Constants.Status.DON.ToString();
                        uow.UOFIncidentFormDataRepository.Add(inmate);
                        uow.Commit();
                        FormDataId = inmate.FormDataID;
                        result = FormDataId;
                    }
                    if (!string.IsNullOrWhiteSpace(inmateInjuryBusinessModel.wittnessStatement.RejectComments))
                    {
                        using (ReturnCommentsRepository obj = new ReturnCommentsRepository())
                        {
                            obj.returnComments(new ReturnCommentModel { IncidentId = inmateInjuryBusinessModel.IncidentID, FormId = inmateInjuryBusinessModel.FormID, FormSubmitedId = inmateInjuryBusinessModel.SubmitedId, Comments = inmateInjuryBusinessModel.wittnessStatement.RejectComments });
                        }
                        //if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == inmateInjuryBusinessModel.IncidentID && x.FormId == inmateInjuryBusinessModel.FormID && x.InvolvedId == inmateInjuryBusinessModel.SubmitedId).Any())
                        //{
                        //    var RCmts = (from ind in uow.ReviewRespository.GetAll()
                        //                 where ind.IncidentID == inmateInjuryBusinessModel.IncidentID && ind.FormId == inmateInjuryBusinessModel.FormID && ind.InvolvedId == inmateInjuryBusinessModel.SubmitedId
                        //                 select ind).FirstOrDefault();
                        //    if (RCmts != null)
                        //    {

                        //    }
                        //}
                    }

                    repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                    {
                        FormDataId = FormDataId,
                        IncidentID = inmateInjuryBusinessModel.IncidentID,
                        IncidentReviewID = inmateInjuryBusinessModel.IncidentReviewId,
                        SubmittedEmpId = inmateInjuryBusinessModel.EmpId,
                        FormId = inmateInjuryBusinessModel.FormID,
                        SubmitteduserRole = inmateInjuryBusinessModel.UserRole,
                        ReviewerRole = !inmateInjuryBusinessModel.IsOnlySave ? Constants.UserRoles.SGT.ToString() : "",
                        SergeantStatus = !inmateInjuryBusinessModel.IsOnlySave ? Constants.Status.Pending.ToString() : "",
                        SubmittedStatus = !inmateInjuryBusinessModel.IsOnlySave ? Constants.Status.DON.ToString() : Constants.Status.Pending.ToString(),
                    });

                }
            }
            catch (Exception ex)
            {
                result = 0;
                throw ex;
            }
            return result;
        }

        public InmateInjuryBusinessModel GetInmateInjury(ParameterCriteria cirteria)
        {

            try
            {
                IncidentFormData data = null;
                if (cirteria.report)
                    data = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.FormID == cirteria.formId && x.EmpID == cirteria.employeeId && x.IncidentID == cirteria.incidentId).FirstOrDefault();
                else
                    data = uow.UOFIncidentFormDataRepository.GetById(cirteria.formDataId);

                var result = data != null ? data.XmlData.Deserialize<InmateInjuryBusinessModel>() : null;
                if (result != null)
                {
                    using (ReturnCommentsRepository obj = new ReturnCommentsRepository())
                    {
                        result.wittnessStatement.RejectComments = obj.getReturnComments(new ReturnCommentModel { IncidentId = cirteria.incidentId, FormId = cirteria.formId, FormSubmitedId = cirteria.employeeId, IncidentReviewID = cirteria.IncidentReviewId });
                    }
                    //Get Approve or Reject Information from the FormApprove or Reject Table

                    var approveInfo = uow.FormApprovalRejectRespository.GetAll().Where(x => x.FormId == cirteria.formId && x.FormFilledBy == cirteria.employeeId && x.IncidentId == cirteria.incidentId).FirstOrDefault();
                    if (approveInfo != null)
                    {
                        result.incidentNarrative.ApprovedBy_EmployeeNumber = approveInfo.ActionBy;
                        DateTime dt = DateTime.Parse(approveInfo.CreatedDate.ToString());
                        result.incidentNarrative.ApprovedBy_Date = dt.ToString("MM/dd/yyyy");
                    }
                }
                return result;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

    }
}
