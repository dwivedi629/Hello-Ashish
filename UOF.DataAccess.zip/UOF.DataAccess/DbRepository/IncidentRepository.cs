﻿//using UOF.DataAccess.DataModel;
using UOF.DataAccess.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using UOF.Common.EntityModel;
using UOF.Common.Utilities;
using UOF.Logging;

namespace UOF.DataAccess.DbRepository
{
    public class IncidentRepository
    {
        UnitOfWork uow = new UnitOfWork();
        readonly ILogService LogService = new LogService(typeof(IncidentRepository));
        private int InsertAddress(IncidentEntity incidentEntity)
        {
            Addres address = new Addres();
            address.AddressId = incidentEntity.AddressId;
            address.AddressTypeId = incidentEntity.AddressTypeId;
            address.AddressNumber = incidentEntity.AddressNumber;
            address.Street = incidentEntity.Street;
            address.City = incidentEntity.SelectedCity;
            address.State = incidentEntity.State;
            address.StationFacility = incidentEntity.StationFacility;
            address.ZipCode = incidentEntity.ZipCode;
            address.IncidentId = incidentEntity.IncidentId;
            uow.AddressRepository.Add(address);
            uow.Commit();
            return address.AddressId;
        }

        private int InsertIncident(IncidentEntity incidentEntity)
        {
            Incident incident = new Incident();
            incident.URN = incidentEntity.URN;
            incident.AddressId = incidentEntity.AddressId;
            incident.IncidentDate = incidentEntity.IncidentDate;
            incident.ContactTypeId = incidentEntity.ContactTypeId;
            incident.CustodyEventId = incidentEntity.CustodyEventId;
            incident.IncidentLocationName = incidentEntity.IncidentLocationName;
            incident.CTOthers = incidentEntity.CTOthers;
            incident.IsAdminInvestigation = incidentEntity.IsAdminInvestigation;
            incident.IncidentCategoryId = incidentEntity.IncidentCategoryId;
            incident.ForceTypeId = incidentEntity.ForceTypeId;
            incident.IsDeptyInjury = incidentEntity.IsDeptyInjury;
            incident.IsSuspectInjury = incidentEntity.IsSuspectInjury;
            incident.IsUnderlyingArrest = incidentEntity.IsUnderlyingArrest;
            incident.IsUnderlyingCrime = incidentEntity.IsUnderlyingCrime;
            incident.IsOnK12Campus = incidentEntity.IsOnK12Campus;
            incident.IsByFootPursuit = incidentEntity.IsByFootPursuit.Trim();
            incident.IsByVehiclePursuit = incidentEntity.IsByVehiclePursuit.Trim();
            incident.IsIABNotified = incidentEntity.IsIABNotified;
            incident.IABNotifiedUserId = incidentEntity.IABNotifiedUserId;
            incident.IABNotifiedEmailId = incidentEntity.IABNotifiedEmailId;
            incident.IsIABRollOut = incidentEntity.IsIABRollOut;
            incident.IABRolloutEmployees = incidentEntity.IABRolloutEmployees;
            incident.IsIABHandling = incidentEntity.IsIABHandling;
            incident.IABHandlingUserId = incidentEntity.IABHandlingUserId;
            incident.IsCFRTNotified = incidentEntity.IsCFRTNotified;
            incident.CFRTNotifiedUserId = incidentEntity.CFRTNotifiedUserId;
            incident.CFRTNotifiedEmailId = incidentEntity.CFRTNotifiedEmailId;
            incident.IsCFRTRollOut = incidentEntity.IsCFRTRollOut;
            incident.CFRTRolloutEmployees = incidentEntity.CFRTRolloutEmployees;
            incident.IsCFRTHandling = incidentEntity.IsCFRTHandling;
            incident.CFRTHandlingUserId = incidentEntity.CFRTHandlingUserId;
            incident.IsReactiveForce = incidentEntity.IsReactiveForce == "True" ? "Y" : "N";
            incident.IsPlannedForce = incidentEntity.IsPlannedForce == "True" ? "Y" : "N";
            incident.IsInmateInjuryReportWritten = incidentEntity.IsInmateInjuryReportWritten;
            incident.IsMedicalStaffPresent = incidentEntity.IsMedicalStaffPresent;
            incident.IsMentalHealthPresent = incidentEntity.IsMentalHealthPresent;
            incident.IsSuperVisorPresent = incidentEntity.IsSuperVisorPresent;
            incident.IsMedicalRecordChecked = incidentEntity.IsMedicalRecordChecked;
            incident.IsExtractionOrderByMedical = incidentEntity.IsExtractionOrderByMedical;
            incident.IsMentalHealthProfessional = incidentEntity.IsMentalHealthProfessional;
            incident.IsDepartmentSignAdmonishmentAndNotedChangesInReport = incidentEntity.IsDepartmentSignAdmonishmentAndNotedChangesInReport;
            incident.IsInvestigatorDirectedTheForce = incidentEntity.IsInvestigatorDirectedTheForce;
            incident.IsInvestigatorParticipatedInTheForce = incidentEntity.IsInvestigatorParticipatedInTheForce;
            incident.IsInvestigatorPlannedTheForce = incidentEntity.IsInvestigatorPlannedTheForce;
            incident.IsStaffEscortInvolvedInmates = incidentEntity.IsStaffEscortInvolvedInmates;
            incident.IsCCTVCoverage = incidentEntity.IsCCTVCoverage;
            incident.IsVideoShooted = incidentEntity.IsVideoShooted;
            incident.VideoofIncident = incidentEntity.IsVideoOfIncident;
            incident.Location = incidentEntity.ForceLocation;
            incident.LevelofResistance = incidentEntity.LevelofResistance;
            incident.IsDepartmentMembersSeparated = incidentEntity.IsDepartmentMembersSeparated;
            incident.IsPPIReviewCompleted = incidentEntity.IsPPIReviewCompleted;
            incident.IncidentCreatedDate = DateTime.Now;
            incident.IncidentCity = incidentEntity.SelectedCity;
            incident.IncidentApprovalStatus = Convert.ToString((int)Constants.IncidentStatus.AtSergeant);
            incident.SergeantId = incidentEntity.EmpId;
            incident.Assulative = incidentEntity.Assulative == "True" ? "Y" : "N";
            incident.Lifethreatening = incidentEntity.Lifethreatening == "True" ? "Y" : "N";
            incident.ExtractionEmpId = incidentEntity.ExtractionEmpId;
            incident.MentalHealthEmpId = incidentEntity.MentalHealthEmpId;
            incident.CCTVNoReason = incidentEntity.CCTVNoReason;
            incident.IsCCTVExtracted = incidentEntity.CCTVExtracted == "True" ? "Y" : "N";
            incident.VideoShootedNoReason = incidentEntity.VideoShootedNoReason;
            //incident.Bureau = incidentEntity.Bureau;
            incident.Station = incidentEntity.Station;
            //incident.Facility = incidentEntity.Facility;
            incident.Staging = incidentEntity.Staging;
            incident.IsDeleted = false;

            incident.PPINo = incidentEntity.PPINo;
            incident.ELots = incidentEntity.eLOTS;
            incident.ElotsYN = incidentEntity.elotsYN;

            incident.MHS = incidentEntity.MHS;
            incident.MHSReason = incidentEntity.MHSReason;
            incident.PFData = incidentEntity.PFData;
            incident.MedicalLife = incidentEntity.MedicalLife;
            incident.MedRcdPrior = incidentEntity.MedRcdPrior;
            incident.PlanAltered = incidentEntity.PlanAltered;

            //SupervisorDirected User Insertion
            if (incidentEntity.SupervisorDirectedId != null)
            {
                incident.InvestigatorDirectedId = incidentEntity.SupervisorDirectedId;
                SaveUserDetails(new IncidentUserEntity { ForceEmployeeId = incidentEntity.SupervisorDirectedId, FirstName = incidentEntity.SupervisorDirectedFirstName, LastName = incidentEntity.SupervisorDirectedLastName, Rank = incidentEntity.SupervisorDirectedRank, EmailId = incidentEntity.SupervisorDirectedMailId, UserTypeId = (int)Constants.UserType.InvestigatorDirected });
            }
            //End
            incident.ReferenceNo = incidentEntity.ReferenceNo;
            incident.PRReason = incidentEntity.PRReason;
            incident.IncidentName = incidentEntity.BusinessName;
            uow.IncidentRepository.Add(incident);
            uow.Commit();
            int incidentId = incident.IncidentId;
            incidentEntity.IncidentId = incidentId;

            //#region Save PlannedForce
            //if (incidentEntity.IsPlannedForce == "Y")
            //{
            //    incidentEntity.PlannedForceInfo.incidentId = incidentId;
            //    SavePlannedForce(incidentEntity.PlannedForceInfo);
            //}
            //#endregion

            #region Incident Business Address
            IncidentBusinessRepository addRepo = new IncidentBusinessRepository();
            addRepo.InsertUpdateIncidentBusiness(incidentEntity);
            #endregion

            #region User Information
            if (incidentEntity.UserDetails != null)
            {
#if DEBUG
                incidentEntity.UserDetails.FirstName = "FName";
                incidentEntity.UserDetails.LastName = "LName";
#endif
                IncidentUserRepository repo = new IncidentUserRepository();
                User usrs = uow.UserRepository.GetAll().Where(x => x.UserTypeId == (int)Constants.UserType.Sergeant).FirstOrDefault();
                if (usrs == null)
                {
                    repo.SaveIncidentUser(new IncidentUserEntity
                    {
                        FirstName = incidentEntity.UserDetails.FirstName ?? "Sergeant First Name",//TODO: Need to remove
                        LastName = incidentEntity.UserDetails.LastName ?? "Sergeant Last Name",//TODO: Need to remove
                        ForceEmployeeId = incidentEntity.UserDetails.ForceUserId,
                        UserTypeId = (int)Constants.UserType.Sergeant,
                        IncidentId = incidentId
                    });
                }
            }
            #endregion


            #region Inserting into CategoryForm Table and Incident Review Forms
            IncidentCategoryForm categoryForm = new IncidentCategoryForm();

            if ((incidentEntity.IncidentCategoryId == 1 && incidentEntity.ForceTypeId.Contains("CT")) || (incidentEntity.IncidentCategoryId == 1 && incidentEntity.ForceTypeId.Contains("CE")))
            {
                categoryForm.FormID = (int)Constants.UOFForms.UseofForceCategoryOneIncidents;
                categoryForm.IncidentCategoryId = Convert.ToInt32(incidentEntity.IncidentCategoryId);
                categoryForm.IncidentID = incidentId;
                categoryForm.Status = Constants.Status.PND.ToString();
                uow.CategoryFormRepository.Add(categoryForm);
                uow.Commit();
                InsertSergeantForms(incidentId, incidentEntity.EmpId.ToUpper(), (int)Constants.UOFForms.UseofForceCategoryOneIncidents);

            }
            //if (incidentEntity.IncidentCategoryId == 2)
            //    categoryForm.FormID = (int)Constants.UOFForms.UseofForceNarrativeReport;
            //if (incidentEntity.IncidentCategoryId == 3 && incidentEntity.IsIABNotified == "Y")
            //{
            //    FormReviewRespository repo = new FormReviewRespository();
            //    categoryForm.FormID = (int)Constants.UOFForms.IABMandatoryForm;
            //    categoryForm.IncidentCategoryId = Convert.ToInt32(incidentEntity.IncidentCategoryId);
            //    categoryForm.IncidentID = incidentId;
            //    categoryForm.Status = Constants.Status.PND.ToString();
            //    uow.CategoryFormRepository.Add(categoryForm);
            //    uow.Commit();
            //    repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
            //    {
            //        IncidentID = incidentId,
            //        //SubmittedEmpId = incidentEntity.EmpId.ToUpper(),
            //        FormId = categoryForm.FormID,
            //        SubmitteduserRole = Constants.UserRoles.WC.ToString(),
            //        SergeantId = incidentEntity.EmpId.ToUpper(),
            //        ReviewerRole = Constants.UserRoles.WC.ToString(),
            //        SergeantStatus = Constants.Status.NotReady.ToString(),
            //        SubmittedStatus = Constants.Status.PND.ToString()
            //    });
            //}
            #endregion

            //#region Inserting Sergeant Forms only if Incident Category is 1 or 2. Category 3 cases will assign to WC.
            //if (incidentEntity.IncidentCategoryId != 3)
            //{
            //    InsertSergeantForms(incidentId, incidentEntity.EmpId.ToUpper(), (int)Constants.UOFForms.UseofForceNarrativeReport);
            //    InsertSergeantForms(incidentId, incidentEntity.EmpId.ToUpper(), (int)Constants.UOFForms.CustodyDivisionForceReviewChecklist);
            //}
            //#endregion
            UpdateFormReview(incidentEntity.IncidentId, incidentEntity.EmpId);

            #region Inserting record into Incident Workflow Table
            UoFWorkFlowRepository wf = new UoFWorkFlowRepository();
            if (incidentEntity.IsCFRTNotified == "Y")
                wf.InsertUpdateWorkFlow(new WorkFlowEntity { IncidentId = incidentId, SergeantID = incidentEntity.EmpId, SergeantStatus = Constants.Status.Pending.ToString(), CFRTID = incidentEntity.CFRTNotifiedUserId, CFRTStatus = Constants.Status.NotReady.ToString() });
            else
                wf.InsertUpdateWorkFlow(new WorkFlowEntity { IncidentId = incidentId, SergeantID = incidentEntity.EmpId, SergeantStatus = Constants.Status.Pending.ToString() });
            #endregion

            #region Insert into Incident Rank Table
            SaveIncidentRank(incidentEntity.IncidentId);
            #endregion

            #region Email Notifications
            EmailRepository email = new EmailRepository();
            if (incidentEntity.IsIABNotified == "Y")
            {
                email.EmailNotification(new EmailNotificationModel
                {
                    Department = "Notified",
                    EmailId = incidentEntity.IABNotifiedEmailId,
                    IncidentId = incidentId,
                    EmployeeNumber = incidentEntity.IABNotifiedUserId,
                });
            }
            if (incidentEntity.IsIABHandling == "Y")
            {
                email.EmailNotification(new EmailNotificationModel
                {
                    Department = "Handling",
                    EmailId = incidentEntity.IABHandlingEmailId,
                    IncidentId = incidentId,
                    EmployeeNumber = incidentEntity.IABHandlingUserId,
                });
            }

            if (incidentEntity.IsCFRTHandling == "Y")
            {
                email.EmailNotification(new EmailNotificationModel
                {
                    Department = "Handling",
                    EmailId = incidentEntity.CFRTHandlingEmailId,
                    IncidentId = incidentId,
                    EmployeeNumber = incidentEntity.CFRTHandlingUserId,
                });
            }
            if (incidentEntity.IsCFRTNotified == "Y")
            {
                email.EmailNotification(new EmailNotificationModel
                {
                    Department = "Notified",
                    EmailId = incidentEntity.CFRTNotifiedEmailId,
                    IncidentId = incidentId,
                    EmployeeNumber = incidentEntity.CFRTNotifiedUserId,
                });
            }
            #endregion

            return incidentId;
        }
        private void UpdateFormReview(int IncidentID, string SergeantId)
        {
            if (SergeantId != "0")
            {
                if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == IncidentID).Any())
                {
                    List<IncidentFormReview> SRmodel = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == IncidentID && x.InvolvedRole == Constants.UserRoles.DSG.ToString()).ToList();
                    foreach (var item in SRmodel)
                    {
                        if (item != null)
                        {
                            if ((item.InvolvedStatus == Constants.Status.DON.ToString() || item.InvolvedStatus == Constants.Status.Completed.ToString()) && item.SergeantStatus != Constants.Status.Completed.ToString())
                            {
                                item.SergeantId = SergeantId;
                                item.SergeantStatus = Constants.Status.Pending.ToString();
                                uow.ReviewRespository.Update(item);
                                uow.Commit();
                            }
                        }
                    }
                }
            }

        }

        //private void SavePlannedForce(PlannedForce entity)
        //{
        //    IncidentPlannedForce force = new IncidentPlannedForce();
        //    force.Extraction = entity.PFExtraction;
        //    force.IncidentId = entity.incidentId;
        //    force.UoFPlanned = entity.PFPlannedUoF;
        //    //force.MHS = entity.MHS;
        //    //force.MHSReason = entity.MHSReason;
        //    //force.Investienter = entity.Investienter;
        //    //force.InvestiExplain = entity.InvestiExplain;
        //    uow.PlannedForceRepository.Add(force);
        //    uow.Commit();
        //}

        //private void UpdatePlannedForce(PlannedForce entity)
        //{
        //    IncidentPlannedForce force = uow.PlannedForceRepository.GetAll().Where(x => x.IncidentId == entity.incidentId).FirstOrDefault();
        //    if (force != null)
        //    {
        //        force.Extraction = entity.PFExtraction;
        //        force.IncidentId = entity.incidentId;
        //        force.UoFPlanned = entity.PFPlannedUoF;
        //        //force.MHS = entity.MHS;
        //        //force.MHSReason = entity.MHSReason;
        //        //force.Investienter = entity.Investienter;
        //        //force.InvestiExplain = entity.InvestiExplain;
        //        uow.PlannedForceRepository.Update(force);
        //        uow.Commit();
        //    }
        //    else
        //        SavePlannedForce(entity);
        //}
        private void InsertAssignedForms(InvolvedUserEntity model, int FormID, string SubmitedRole)
        {

            //Insert Into [IncidentDeputyForms]
            string sergeantID = (from ind in uow.IncidentRepository.GetAll()
                                 where ind.IncidentId == model.IncidentId
                                 select new { ind.SergeantId }).Single().SergeantId;

            sergeantID = model.ReviewerId ?? sergeantID;

            //Insert Into [IncidentDeputyForms]
            string WCID = (from ind in uow.IncidentWorkflowRepository.GetAll()
                           where ind.IncidentId == model.IncidentId
                           select new { ind.WCID }).Single().WCID;

            WCID = WCID ?? "";
            string reviewerRole = string.Empty;

            switch (SubmitedRole.ToUpper())
            {
                case "DSG":
                    reviewerRole = Constants.UserRoles.SGT.ToString();
                    break;
                case "SGT":
                    reviewerRole = Constants.UserRoles.WC.ToString();
                    break;
                case "WC":
                    reviewerRole = Constants.UserRoles.CAPT.ToString();
                    break;
                case "CAPT":
                    reviewerRole = Constants.UserRoles.CMDR.ToString();
                    break;
                default:
                    break;
            }

            //New Implementation Getting Forms Review Rank and Assiging.
            string SID = string.Empty, WCHID = string.Empty, UCID = string.Empty, CMID = string.Empty, DCID = string.Empty;
            FormReviewRank rankResult = (from review in uow.FormReviewRankRespository.GetAll() where review.FormId == FormID && review.Active == true select review).FirstOrDefault();
            if (rankResult != null)
            {
                reviewerRole = (from ind in uow.UserRoleRepository.GetAll() where ind.Rank == rankResult.ReviewRank select new { ind.RoleCode }).Single().RoleCode;
                switch (reviewerRole)
                {
                    case "WC":
                        SID = model.EmployeeId;
                        SubmitedRole = "SGT";
                        break;
                    case "CAPT":
                        WCHID = model.EmployeeId;
                        SubmitedRole = "WC";
                        break;
                    case "SGT":
                        SubmitedRole = "DSG";
                        break;
                    case "CMDR":
                        UCID = model.EmployeeId;
                        SubmitedRole = "CAPT";
                        break;
                    case "DC":
                        CMID = model.EmployeeId;
                        SubmitedRole = "CMDR";
                        break;
                    default:
                        break;
                }
            }


            //Commented as we need to insert multiple record for the below combination
            //if (!uow.ReviewRespository.GetAll().Where(x => x.IncidentID == model.IncidentId && x.FormId == FormID && x.InvolvedId == model.EmployeeId).Any())
            //{
            FormReviewRespository repo = new FormReviewRespository();
            repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
            {
                IncidentID = Convert.ToInt32(model.IncidentId),
                SubmittedEmpId = model.EmployeeId,
                FormId = FormID,
                SubmitteduserRole = SubmitedRole,
                SergeantId = !string.IsNullOrWhiteSpace(SID) ? SID : string.Empty,
                WCID = !string.IsNullOrWhiteSpace(WCHID) ? WCHID : string.Empty,
                UCID = !string.IsNullOrWhiteSpace(UCID) ? UCID : string.Empty,
                CMID = !string.IsNullOrWhiteSpace(CMID) ? CMID : string.Empty,
                ReviewerRole = reviewerRole,
                SergeantStatus = !string.IsNullOrWhiteSpace(SID) ? Constants.Status.Pending.ToString() : string.Empty,
                WCStatus = !string.IsNullOrWhiteSpace(WCHID) ? Constants.Status.Pending.ToString() : string.Empty,
                UCStatus = !string.IsNullOrWhiteSpace(UCID) ? Constants.Status.Pending.ToString() : string.Empty,
                CMStatus = !string.IsNullOrWhiteSpace(CMID) ? Constants.Status.Pending.ToString() : string.Empty,
                DCStatus = !string.IsNullOrWhiteSpace(CMID) ? Constants.Status.NotReady.ToString() : string.Empty,
                SubmittedStatus = Constants.Status.PND.ToString(),
                isAssignForms = true,
            });
            // }

            //End


        }
        private string GetFormName(int formId)
        {
            string formName = string.Empty;
            switch (formId)
            {
                case 10:
                    formName = Constants.UOFForms.UseofForceNarrativeReport.ToString();
                    break;
                case 11:
                    formName = Constants.UOFForms.Cat1ChemicalAgent.ToString();
                    break;
                case 12:
                    formName = Constants.UOFForms.CustodyDivisionForceReviewChecklist.ToString();
                    break;
                case 13:
                    formName = Constants.UOFForms.UseofForcePackageTrackingSheet.ToString();
                    break;
                case 14:
                    formName = Constants.UOFForms.UseofForceCategoryOneIncidents.ToString();
                    break;
                case 15:
                    formName = Constants.UOFForms.UseofForceReviewNotice.ToString();
                    break;
                case 16:
                    formName = Constants.UOFForms.IncidentReport.ToString();
                    break;
                case 17:
                    formName = Constants.UOFForms.MedicalReport.ToString();
                    break;
                case 18:
                    formName = Constants.UOFForms.CrimeAnalysisSupplementalForm.ToString();
                    break;
                case 19:
                    formName = Constants.UOFForms.InmateInjuryIllness.ToString();
                    break;
                case 20:
                    formName = Constants.UOFForms.DeputysUseofForceMemorandum.ToString();
                    break;
                case 21:
                    formName = Constants.UOFForms.CustodyServicesDivisionCrimeAnalysisSupplemental.ToString();
                    break;
                case 22:
                    formName = Constants.UOFForms.DeputySupplementalReport.ToString();
                    break;
                case 23:
                    formName = Constants.UOFForms.WatchCommanderUseofForceReview.ToString();
                    break;
                case 24:
                    formName = Constants.UOFForms.IABMandatoryForm.ToString();
                    break;
                case 25:
                    formName = Constants.UOFForms.WCUseofForceReviewNotice.ToString();
                    break;
                case 26:
                    formName = Constants.UOFForms.UnitCommanderUseoFForceReview.ToString();
                    break;
                case 27:
                    formName = Constants.UOFForms.UCUseofForceReviewNotice.ToString();
                    break;
                case 30:
                    formName = Constants.UOFForms.CommanderUseofForceReview.ToString();
                    break;

                case 31:
                    formName = Constants.UOFForms.CMUseofForceReviewNotice.ToString();
                    break;
            }
            return formName;
        }
        public int AssingIncidentForms(AssignForm assignedEntity)
        {
            UserRepository repo = new UserRepository();
            int incidentId = 0;
            try
            {
                using (var transaction = new TransactionScope())
                {
                    if (assignedEntity.Mode == Constants.Mode.Add.ToString()) //Inserting the information into Incident table.
                    {
                        //Commented as client need to One Sergeant Self Assigned to another Sergeant. 31/03/2017
                        //if (assignedEntity.LoggedRole.ToUpper() == Constants.UserRoles.SGT.ToString() || assignedEntity.LoggedRole.ToUpper() == Constants.UserRoles.WC.ToString() || assignedEntity.LoggedRole.ToUpper() == Constants.UserRoles.CAPT.ToString() || assignedEntity.LoggedRole.ToUpper() == Constants.UserRoles.CMDR.ToString())
                        //    incidentId = InsertIncident(new IncidentEntity { URN = assignedEntity.URN, IncidentDate = assignedEntity.Date, EmpId = assignedEntity.LoggedId });
                        //else

                        incidentId = InsertIncident(new IncidentEntity { URN = assignedEntity.URN, IncidentDate = assignedEntity.Date, EmpId = "0" });
                        assignedEntity.IncidentId = incidentId;
                    }
                    #region Delete User Functionality
                    foreach (var entity in assignedEntity.DeletedUsers)
                    {
                        int formId = Convert.ToInt32(entity.FormIds);
                        //using (var transaction = new TransactionScope())
                        //{
                        if (entity.InvolvedEmployee)
                        {
                            var usr = (from s in uow.UserRepository.GetAll()
                                       join f in uow.IncidentUserRepository.GetAll() on s.UserId equals f.UserId
                                       join g in uow.IncidentUserInvolvedRepository.GetAll() on f.IncidentUserId equals g.IncidentUserId
                                       where f.IncidentId == entity.IncidentId && f.UserTypeId == 1 && s.ForceEmployeeId == entity.EmployeeId
                                       select s).FirstOrDefault();
                            if (usr != null)
                            {
                                //usr.Active = false;
                                //uow.UserRepository.Update(usr);
                                //uow.Commit();

                                List<IncidentFormReview> model = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == entity.IncidentId && x.InvolvedId == entity.EmployeeId && x.FormId == formId).ToList();
                                List<IncidentFormData> frmData = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.IncidentID == entity.IncidentId && x.EmpID == entity.EmployeeId && x.FormID == formId).ToList();
                                foreach (var frm in model)
                                {
                                    if (frm != null)
                                    {
                                        frm.InvolvedStatus = Constants.Status.Deleted.ToString();
                                        uow.ReviewRespository.Update(frm);
                                        // uow.ReviewRespository.Delete(frm);
                                        uow.Commit();
                                    }
                                }
                                foreach (var frm in frmData)
                                {
                                    if (frm != null)
                                    {
                                        //uow.UOFIncidentFormDataRepository.Delete(frm);
                                        frm.Status = Constants.Status.Deleted.ToString();
                                        uow.UOFIncidentFormDataRepository.Update(frm);
                                        uow.Commit();
                                    }
                                }
                            }
                        }
                        else if (entity.EmployeeWitness)
                        {
                            var usr = (from s in uow.UserRepository.GetAll()
                                       join f in uow.IncidentUserRepository.GetAll() on s.UserId equals f.UserId
                                       join g in uow.IncidentUserWitnessRepository.GetAll() on f.IncidentUserId equals g.IncidentUserId
                                       where f.IncidentId == entity.IncidentId && f.UserTypeId == 3 && s.ForceEmployeeId == entity.EmployeeId
                                       select s).FirstOrDefault();
                            if (usr != null)
                            {
                                //usr.Active = false;
                                //uow.UserRepository.Update(usr);
                                //uow.Commit();

                                List<IncidentFormReview> model = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == entity.IncidentId && x.InvolvedId == entity.EmployeeId && x.FormId == formId).ToList();
                                List<IncidentFormData> frmData = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.IncidentID == entity.IncidentId && x.EmpID == entity.EmployeeId && x.FormID == formId).ToList();
                                foreach (var frm in model)
                                {
                                    if (frm != null)
                                    {
                                        frm.InvolvedStatus = Constants.Status.Deleted.ToString();
                                        uow.ReviewRespository.Update(frm);
                                        // uow.ReviewRespository.Delete(frm);
                                        uow.Commit();
                                    }
                                }
                                foreach (var frm in frmData)
                                {
                                    if (frm != null)
                                    {
                                        //uow.UOFIncidentFormDataRepository.Delete(frm);
                                        frm.Status = Constants.Status.Deleted.ToString();
                                        uow.UOFIncidentFormDataRepository.Update(frm);
                                        uow.Commit();
                                    }
                                }
                            }
                        }
                        else
                        {
                            var usr = (from s in uow.UserRepository.GetAll()
                                       join f in uow.IncidentUserRepository.GetAll() on s.UserId equals f.UserId
                                       where f.IncidentId == entity.IncidentId && f.UserTypeId == 11 && s.ForceEmployeeId == entity.EmployeeId
                                       select s).FirstOrDefault();
                            if (usr != null)
                            {
                                //usr.Active = false;
                                //uow.UserRepository.Update(usr);
                                //uow.Commit();

                                List<IncidentFormReview> model = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == entity.IncidentId && x.InvolvedId == entity.EmployeeId && x.FormId == formId).ToList();
                                List<IncidentFormData> frmData = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.IncidentID == entity.IncidentId && x.EmpID == entity.EmployeeId && x.FormID == formId).ToList();
                                foreach (var frm in model)
                                {
                                    if (frm != null)
                                    {
                                        frm.InvolvedStatus = Constants.Status.Deleted.ToString();
                                        uow.ReviewRespository.Update(frm);
                                        // uow.ReviewRespository.Delete(frm);
                                        uow.Commit();
                                    }
                                }
                                foreach (var frm in frmData)
                                {
                                    if (frm != null)
                                    {
                                        //uow.UOFIncidentFormDataRepository.Delete(frm);
                                        frm.Status = Constants.Status.Deleted.ToString();
                                        uow.UOFIncidentFormDataRepository.Update(frm);
                                        uow.Commit();
                                    }
                                }
                            }
                        }
                        //    transaction.Complete();
                        //}
                    }
                    #endregion
                    foreach (var entity in assignedEntity.Assignment)
                    {
                        using (var assnTrans = new TransactionScope())
                        {
                            entity.IncidentId = entity.IncidentId == 0 ? assignedEntity.IncidentId : entity.IncidentId;
                            string SubmitedRole = string.Empty;

                            entity.EmpRole = entity.EmpRole ?? Constants.UserRoles.DSG.ToString();

                            if (entity.EmpRole.ToUpper() != Constants.UserRoles.SGT.ToString() || entity.EmpRole.ToUpper() != Constants.UserRoles.WC.ToString() || entity.EmpRole.ToUpper() != Constants.UserRoles.CAPT.ToString() || entity.EmpRole.ToUpper() != Constants.UserRoles.CMDR.ToString())
                                SubmitedRole = Constants.UserRoles.DSG.ToString();
                            else
                                SubmitedRole = entity.EmpRole.ToUpper();

                            #region Assing Forms
                            List<LookupEntity> AssignedForms = new List<LookupEntity>();
                            //Commented by ~m as Multi select is removed
                            ////If any forms are unchecked then delete from the DB
                            //var isNotExistsList = uow.ReviewRespository.GetAll().Where(x => x.InvolvedId == entity.EmployeeId && x.InvolvedRole == SubmitedRole && x.IncidentID == assignedEntity.IncidentId && !entity.FormIds.Contains(x.FormId.ToString())).ToList();
                            //if (isNotExistsList.Count > 0)
                            //{
                            //    foreach (var item in isNotExistsList)
                            //    {
                            //        var formData = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.EmpID == item.InvolvedId && x.IncidentID == item.IncidentID && x.FormID == item.FormId).FirstOrDefault();
                            //        if (formData != null)
                            //        {
                            //            formData.Status = "DEL";
                            //            uow.UOFIncidentFormDataRepository.Update(formData);
                            //            uow.Commit();
                            //        }

                            //        uow.ReviewRespository.Delete(item);
                            //        uow.Commit();
                            //    }
                            //}
                            if (!string.IsNullOrWhiteSpace(entity.FormIds))
                            {
                                int cnt = entity.instanceCnt;
                                int fid = Convert.ToInt32(entity.FormIds);
                                string[] ids = entity.FormIds.Split(',');
                                int existingCount = uow.ReviewRespository.GetAll().Where(a => a.IncidentID == entity.IncidentId && a.InvolvedId == entity.EmployeeId && a.FormId == fid).Count();
                                if (cnt != existingCount)
                                {
                                    if (cnt > existingCount) // If given count is greater than existing count then only inserting.
                                        cnt = cnt - existingCount;

                                    for (int i = 0; i < cnt; i++)
                                    {

                                        InsertAssignedForms(new InvolvedUserEntity { IncidentId = assignedEntity.IncidentId, EmployeeId = entity.EmployeeId, EmailId = entity.MailId }, Convert.ToInt32(entity.FormIds), SubmitedRole);

                                        if (Convert.ToInt32(entity.FormIds) == (int)Constants.UOFForms.IncidentReport) //If Incident Report Selected then need to add CA Form
                                        {
                                            var isExists = uow.ReviewRespository.GetAll().Where(x => x.FormId == (int)Constants.UOFForms.CustodyServicesDivisionCrimeAnalysisSupplemental && x.InvolvedId == entity.EmployeeId && x.InvolvedRole == SubmitedRole && x.IncidentID == entity.IncidentId).FirstOrDefault();
                                            if (isExists == null)
                                                InsertAssignedForms(new InvolvedUserEntity { IncidentId = assignedEntity.IncidentId, EmployeeId = entity.EmployeeId, EmailId = entity.MailId }, (int)Constants.UOFForms.CrimeAnalysisSupplementalForm, SubmitedRole);
                                        }
                                        AssignedForms.Add(new LookupEntity { ID = Convert.ToInt32(entity.FormIds), Name = Constants.GetFormName(Convert.ToInt32(entity.FormIds)) });

                                    }

                                    #region Email Notification
                                    this.SendEmailNotification(entity, assignedEntity, AssignedForms);
                                    #endregion
                                }
                                else if (cnt == existingCount)
                                {

                                }
                            }


                            #endregion


                            //Insert into Involved Employee
                            if (entity.InvolvedEmployee)
                            {
                                //Checking  user already inserted or not.
                                var usr = (from s in uow.UserRepository.GetAll()
                                           join f in uow.IncidentUserRepository.GetAll() on s.UserId equals f.UserId
                                           where f.IncidentId == entity.IncidentId && s.ForceEmployeeId == entity.EmployeeId && (f.UserTypeId == (int)Constants.UserType.InvolvedEmployee || f.UserTypeId == (int)Constants.UserType.AssignedUser || f.UserTypeId == (int)Constants.UserType.EmployeeWitness)
                                           select s).FirstOrDefault();
                                if (usr != null)
                                {
                                    var usrDetail = uow.UserDetailRepository.GetAll().Where(x => x.UserDetailId == usr.UserDetailId).FirstOrDefault();
                                    if (usrDetail == null)
                                        repo.SaveInvolvedUser(new InvolvedUserEntity { Mode = Constants.Mode.Add.ToString(), FirstName = entity.FirstName, LastName = entity.LastName, Rank = entity.Rank, EmailId = entity.MailId, EmployeeId = entity.EmployeeId, UserTypeId = (int)Constants.UserType.InvolvedEmployee, IncidentId = assignedEntity.IncidentId });
                                    else if (usr.UserTypeId == (int)Constants.UserType.AssignedUser || usr.UserTypeId == (int)Constants.UserType.EmployeeWitness)
                                        repo.UpdateUserType(assignedEntity.IncidentId, usr.UserTypeId, (int)Constants.UserType.InvolvedEmployee);
                                }
                                else
                                    repo.SaveInvolvedUser(new InvolvedUserEntity { Mode = Constants.Mode.Add.ToString(), FirstName = entity.FirstName, LastName = entity.LastName, Rank = entity.Rank, EmailId = entity.MailId, EmployeeId = entity.EmployeeId, UserTypeId = (int)Constants.UserType.InvolvedEmployee, IncidentId = assignedEntity.IncidentId });

                            }
                            else if (entity.EmployeeWitness)
                            {
                                //Checking  user already inserted or not.
                                var usr = (from s in uow.UserRepository.GetAll()
                                           join f in uow.IncidentUserRepository.GetAll() on s.UserId equals f.UserId
                                           where f.IncidentId == entity.IncidentId && s.ForceEmployeeId == entity.EmployeeId && (f.UserTypeId == (int)Constants.UserType.EmployeeWitness || f.UserTypeId == (int)Constants.UserType.AssignedUser || f.UserTypeId == (int)Constants.UserType.InvolvedEmployee)
                                           select s).FirstOrDefault();
                                if (usr != null)
                                {
                                    var usrDetail = uow.UserDetailRepository.GetAll().Where(x => x.UserDetailId == usr.UserDetailId).FirstOrDefault();
                                    if (usrDetail == null)
                                        repo.SaveWitnessUser(new WitnessUserEntity { Mode = Constants.Mode.Add.ToString(), UserTypeId = (int)Constants.UserType.EmployeeWitness, FirstName = entity.FirstName, LastName = entity.LastName, Rank = entity.Rank, EmailId = entity.MailId, EmployeeId = entity.EmployeeId, IncidentId = assignedEntity.IncidentId });
                                    else if (usr.UserTypeId == (int)Constants.UserType.AssignedUser || usr.UserTypeId == (int)Constants.UserType.InvolvedEmployee)
                                        repo.UpdateUserType(assignedEntity.IncidentId, usr.UserTypeId, (int)Constants.UserType.EmployeeWitness);
                                }
                                else
                                    repo.SaveWitnessUser(new WitnessUserEntity { Mode = Constants.Mode.Add.ToString(), UserTypeId = (int)Constants.UserType.EmployeeWitness, FirstName = entity.FirstName, LastName = entity.LastName, Rank = entity.Rank, EmailId = entity.MailId, EmployeeId = entity.EmployeeId, IncidentId = assignedEntity.IncidentId });

                            }
                            else
                            {
                                var Existingusr = (from s in uow.UserRepository.GetAll()
                                                   join f in uow.IncidentUserRepository.GetAll() on s.UserId equals f.UserId
                                                   where f.IncidentId == entity.IncidentId && s.ForceEmployeeId == entity.EmployeeId
                                                   select s).FirstOrDefault();
                                if (Existingusr == null)
                                {
                                    var usr = (from s in uow.UserRepository.GetAll()
                                               join f in uow.IncidentUserRepository.GetAll() on s.UserId equals f.UserId
                                               where f.IncidentId == entity.IncidentId && s.ForceEmployeeId == entity.EmployeeId && (f.UserTypeId == (int)Constants.UserType.EmployeeWitness || f.UserTypeId == (int)Constants.UserType.InvolvedEmployee)
                                               select s).FirstOrDefault();
                                    if (usr != null)
                                    {
                                        repo.UpdateUserType(assignedEntity.IncidentId, usr.UserTypeId, (int)Constants.UserType.AssignedUser);
                                    }
                                    else
                                        //Insert Assigned User Data into Incident User, User and UserDetails Tables
                                        InsertUpdateIncientUser(new IncidentUserEntity { Mode = Constants.Mode.Add.ToString(), FirstName = entity.FirstName, LastName = entity.LastName, Rank = entity.Rank, EmailId = entity.MailId, ForceEmployeeId = entity.EmployeeId, UserTypeId = (int)Constants.UserType.AssignedUser, IncidentId = assignedEntity.IncidentId });
                                }

                            }
                            uow.Commit();
                            assnTrans.Complete();
                        }

                    }
                    transaction.Complete();
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }

            return incidentId;
        }

        private void InsertUpdateIncientUser(IncidentUserEntity incidentUser)
        {
            UserRepository repo = new UserRepository();

            var usr = (from s in uow.UserRepository.GetAll()
                       join f in uow.IncidentUserRepository.GetAll() on s.UserId equals f.UserId
                       where f.IncidentId == incidentUser.IncidentId && f.UserTypeId == 11 && s.ForceEmployeeId == incidentUser.ForceEmployeeId
                       select s).FirstOrDefault();
            if (usr != null)
            {
                var usrDetail = uow.UserDetailRepository.GetAll().Where(x => x.UserDetailId == usr.UserDetailId).FirstOrDefault();
                if (usrDetail == null)
                    repo.SaveIncidentUser(incidentUser);
            }
            else
                repo.SaveIncidentUser(incidentUser);
        }

        private void InsertSergeantForms(int incidentId, string UserId, int FormId)
        {
            FormReviewRespository repo = new FormReviewRespository();
            #region inserting sergeatn related forms in to Incidet Form Review
            repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
            {
                IncidentID = incidentId,
                SubmittedEmpId = UserId,
                FormId = FormId,
                SubmitteduserRole = Constants.UserRoles.SGT.ToString(),
                SergeantId = UserId,
                ReviewerRole = Constants.UserRoles.WC.ToString(),
                SergeantStatus = Constants.Status.Pending.ToString(),
                SubmittedStatus = Constants.Status.PND.ToString()
            });
            #endregion
        }

        public int SaveIncident(IncidentEntity incidentEntity)
        {
            int incidentId;
            incidentEntity.AddressTypeId = (int)Constants.AddressType.Incident;
            try
            {
                using (var transaction = new TransactionScope())
                {

                    if (incidentEntity.currentMode == Convert.ToString(Constants.Mode.Edit))
                    {
                        UpdateIncident(incidentEntity);
                        transaction.Complete();
                        incidentId = incidentEntity.IncidentId;
                    }
                    else
                    {
                        //Insert into Incident
                        incidentId = InsertIncident(incidentEntity);
                        // Insert into Address
                        int addressId = InsertAddress(incidentEntity);
                        incidentEntity.AddressId = addressId;
                        Incident incident = uow.IncidentRepository.GetById(incidentId);
                        incident.AddressId = addressId;
                        uow.IncidentRepository.Update(incident);
                        uow.Commit();
                        transaction.Complete();
                    }

                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return incidentId;
        }

        public bool UpdateIncident(IncidentEntity incidentEntity)
        {
            Incident incident = uow.IncidentRepository.GetById(incidentEntity.IncidentId);
            if (incidentEntity.AddressId == 0)
            {
                // Insert into Address
                int addressId = InsertAddress(incidentEntity);

                //Insert into Incident
                incidentEntity.AddressId = addressId;
            }
            else
            {
                Addres addressModel = uow.AddressRepository.GetById(incidentEntity.AddressId);

                addressModel.AddressNumber = incidentEntity.AddressNumber;
                addressModel.Street = incidentEntity.Street;
                addressModel.City = incidentEntity.SelectedCity;
                addressModel.State = incidentEntity.State;
                addressModel.StationFacility = incidentEntity.StationFacility;
                addressModel.ZipCode = incidentEntity.ZipCode;
                uow.AddressRepository.Update(addressModel);
                uow.Commit();
            }

            incident.URN = incidentEntity.URN;
            incident.AddressId = incidentEntity.AddressId;
            incident.IncidentDate = incidentEntity.IncidentDate;
            incident.ContactTypeId = incidentEntity.ContactTypeId;
            incident.CustodyEventId = incidentEntity.CustodyEventId;
            incident.IncidentLocationName = incidentEntity.IncidentLocationName;
            incident.CTOthers = incidentEntity.CTOthers;
            incident.IsAdminInvestigation = incidentEntity.IsAdminInvestigation;
            incident.IncidentCategoryId = incidentEntity.IncidentCategoryId;
            incident.ForceTypeId = incidentEntity.ForceTypeId;
            incident.IsDeptyInjury = incidentEntity.IsDeptyInjury;
            incident.IsSuspectInjury = incidentEntity.IsSuspectInjury;
            incident.IsUnderlyingArrest = incidentEntity.IsUnderlyingArrest;
            incident.IsUnderlyingCrime = incidentEntity.IsUnderlyingCrime;
            incident.IsOnK12Campus = incidentEntity.IsOnK12Campus;
            incident.IsByFootPursuit = incidentEntity.IsByFootPursuit.Trim();
            incident.IsByVehiclePursuit = incidentEntity.IsByVehiclePursuit.Trim();
            incident.IsIABNotified = incidentEntity.IsIABNotified;
            incident.IABNotifiedUserId = incidentEntity.IABNotifiedUserId;
            incident.IsIABRollOut = incidentEntity.IsIABRollOut;
            incident.IABRolloutEmployees = incidentEntity.IABRolloutEmployees;
            incident.IsIABHandling = incidentEntity.IsIABHandling;
            incident.IABHandlingUserId = incidentEntity.IABHandlingUserId;
            incident.IsCFRTNotified = incidentEntity.IsCFRTNotified;
            incident.CFRTNotifiedUserId = incidentEntity.CFRTNotifiedUserId;
            incident.IsCFRTRollOut = incidentEntity.IsCFRTRollOut;
            incident.CFRTRolloutEmployees = incidentEntity.CFRTRolloutEmployees;
            incident.IsCFRTHandling = incidentEntity.IsCFRTHandling;
            incident.CFRTHandlingUserId = incidentEntity.CFRTHandlingUserId;
            incident.IsReactiveForce = incidentEntity.IsReactiveForce == "True" ? "Y" : "N";
            incident.IsPlannedForce = incidentEntity.IsPlannedForce == "True" ? "Y" : "N";
            incident.IsInmateInjuryReportWritten = incidentEntity.IsInmateInjuryReportWritten;
            incident.IsMedicalStaffPresent = incidentEntity.IsMedicalStaffPresent;
            incident.IsMentalHealthPresent = incidentEntity.IsMentalHealthPresent;
            incident.IsSuperVisorPresent = incidentEntity.IsSuperVisorPresent;
            incident.IsMedicalRecordChecked = incidentEntity.IsMedicalRecordChecked;
            incident.IsExtractionOrderByMedical = incidentEntity.IsExtractionOrderByMedical;
            incident.IsMentalHealthProfessional = incidentEntity.IsMentalHealthProfessional;
            incident.IsDepartmentSignAdmonishmentAndNotedChangesInReport = incidentEntity.IsDepartmentSignAdmonishmentAndNotedChangesInReport;
            incident.IsInvestigatorDirectedTheForce = incidentEntity.IsInvestigatorDirectedTheForce;
            incident.IsInvestigatorParticipatedInTheForce = incidentEntity.IsInvestigatorParticipatedInTheForce;
            incident.IsInvestigatorPlannedTheForce = incidentEntity.IsInvestigatorPlannedTheForce;
            incident.IsStaffEscortInvolvedInmates = incidentEntity.IsStaffEscortInvolvedInmates;
            incident.IsCCTVCoverage = incidentEntity.IsCCTVCoverage;
            incident.IsVideoShooted = incidentEntity.IsVideoShooted;
            incident.VideoofIncident = incidentEntity.IsVideoOfIncident;
            incident.Location = incidentEntity.ForceLocation;
            incident.LevelofResistance = incidentEntity.LevelofResistance;
            incident.IsDepartmentMembersSeparated = incidentEntity.IsDepartmentMembersSeparated;
            incident.IsPPIReviewCompleted = incidentEntity.IsPPIReviewCompleted;
            incident.IncidentCity = incidentEntity.SelectedCity;
            incident.Assulative = incidentEntity.Assulative;
            incident.Lifethreatening = incidentEntity.Lifethreatening;
            incident.UpdatedDate = DateTime.Now;

            incident.MentalHealthEmpId = incidentEntity.MentalHealthEmpId;
            incident.CCTVNoReason = incidentEntity.CCTVNoReason;
            incident.IsCCTVExtracted = incidentEntity.CCTVExtracted == "True" ? "Y" : "N";
            incident.VideoShootedNoReason = incidentEntity.VideoShootedNoReason;

            //incident.Bureau = incidentEntity.Bureau;
            incident.Station = incidentEntity.Station;
            //incident.Facility = incidentEntity.Facility;
            incident.Staging = incidentEntity.Staging;
            incident.PRReason = incidentEntity.PRReason;
            incident.PPINo = incidentEntity.PPINo;
            incident.ELots = incidentEntity.eLOTS;
            incident.ElotsYN = incidentEntity.elotsYN;
            incident.ElotsNoReason = incidentEntity.elotsNoReason;
            incident.ReferenceNo = incidentEntity.ReferenceNo;

            incident.MHS = incidentEntity.MHS;
            incident.MHSReason = incidentEntity.MHSReason;
            incident.PFData = incidentEntity.PFData;
            incident.MedicalLife = incidentEntity.MedicalLife;
            incident.MedRcdPrior = incidentEntity.MedRcdPrior;
            incident.PlanAltered = incidentEntity.PlanAltered;
            if (incidentEntity.EmpId == "0") //Added on 31/03/2017
                incident.SergeantId = incidentEntity.EmpId;

            #region Update Supervisory Directed User
            //SupervisorDirected User Insertion
            incident.InvestigatorDirectedId = incidentEntity.SupervisorDirectedId;
            UpdateUserDetails(new IncidentUserEntity { PreviousId = incident.InvestigatorDirectedId, ForceEmployeeId = incidentEntity.SupervisorDirectedId, FirstName = incidentEntity.SupervisorDirectedFirstName, LastName = incidentEntity.SupervisorDirectedLastName, Rank = incidentEntity.SupervisorDirectedRank, EmailId = incidentEntity.SupervisorDirectedMailId, UserTypeId = (int)Constants.UserType.InvestigatorDirected });
            //End
            #endregion

            incident.IncidentName = incidentEntity.BusinessName;
            uow.IncidentRepository.Update(incident);
            uow.Commit();
            //#region Save PlannedForce
            //incidentEntity.PlannedForceInfo.incidentId = incidentEntity.IncidentId;
            //UpdatePlannedForce(incidentEntity.PlannedForceInfo);
            //#endregion
            #region User Information
            if (incidentEntity.UserDetails != null)
            {
                IncidentUserRepository repo = new IncidentUserRepository();
                repo.SaveIncidentUser(new IncidentUserEntity
                {
                    FirstName = incidentEntity.UserDetails.FirstName ?? "Sergeant First Name",//TODO: Need to remove
                    LastName = incidentEntity.UserDetails.LastName ?? "Sergeant Last Name",//TODO: Need to remove
                    ForceEmployeeId = incidentEntity.UserDetails.ForceUserId,
                    UserTypeId = (int)Constants.UserType.Sergeant,
                    IncidentId = incidentEntity.IncidentId
                });
            }
            #endregion


            #region Update Incident Business Address
            IncidentBusinessRepository addRepo = new IncidentBusinessRepository();
            addRepo.InsertUpdateIncidentBusiness(incidentEntity);
            #endregion

            if ((incidentEntity.IncidentCategoryId == 1 && incidentEntity.ForceTypeId.Contains("CT")) || (incidentEntity.IncidentCategoryId == 1 && incidentEntity.ForceTypeId.Contains("CE")))
            {
                //Update Incident Category form
                var CAModel = uow.CategoryFormRepository.FindBy(a => a.FormID == (int)Constants.UOFForms.UseofForceCategoryOneIncidents && a.IncidentID == incidentEntity.IncidentId).FirstOrDefault();
                if (CAModel != null)
                {
                    CAModel.Status = Constants.Status.PND.ToString();
                    uow.CategoryFormRepository.Update(CAModel);
                }
            }

            List<string> AddlSergeantIds = new List<string>();

            #region Inserting into Incident Sergeant Table
            //IncidentSergeantRepository serRepo = new IncidentSergeantRepository();
            //foreach (AdditionalSergeantModel item in incidentEntity.AdditionalSergeant)
            //{
            //    AddlSergeantIds.Add(item.EmployeeNumber);
            //    item.IncidentId = incidentEntity.IncidentId;
            //    item.CreateBy = incidentEntity.EmpId;
            //    item.SergeantType = item.SergeantType ?? "A";
            //    serRepo.SaveIncidentSergeant(item);
            //}

            #endregion

            #region Inserting record into Incident Workflow Table
            UoFWorkFlowRepository wf = new UoFWorkFlowRepository();
            if (incidentEntity.IsCFRTNotified == "Y")
                wf.InsertUpdateWorkFlow(new WorkFlowEntity { IncidentId = incidentEntity.IncidentId, SergeantID = incidentEntity.EmpId, CFRTID = incidentEntity.CFRTNotifiedUserId, CFRTStatus = "Not Ready" });
            else
                wf.InsertUpdateWorkFlow(new WorkFlowEntity { IncidentId = incidentEntity.IncidentId, SergeantID = incidentEntity.EmpId });
            #endregion

            uow.Commit();
            UpdateFormReview(incidentEntity.IncidentId, incidentEntity.EmpId);

            uow.Commit();
            return true;

        }

        private string ResolveStatus(int status)
        {
            switch (status)
            {
                case 1:
                    return Constants.IncidentStatus.AtDeputy.ToString();
                case 2:
                    return Constants.IncidentStatus.AtSergeant.ToString();
                case 3:
                    return Constants.IncidentStatus.AtWatchCommander.ToString();
                case 4:
                    return Constants.IncidentStatus.AtUnitCommander.ToString();
                case 5:
                    return Constants.IncidentStatus.AtCommander.ToString();
                case 6:
                    return Constants.IncidentStatus.AtChief.ToString();
                case 7:
                    return Constants.IncidentStatus.AtIAB.ToString();
                case 8:
                    return Constants.IncidentStatus.AtCFRT.ToString();
                case 9:
                    return Constants.IncidentStatus.CFRTCompleted.ToString();
                case 10:
                    return Constants.IncidentStatus.Completed.ToString();

            }

            return "Pending";

        }

        private int SaveUserDetails(IncidentUserEntity incidentUserEntity)
        {
            UserDetail userDetail = new UserDetail();
            userDetail.FirstName = incidentUserEntity.FirstName;
            userDetail.LastName = incidentUserEntity.LastName;
            userDetail.Rank = incidentUserEntity.Rank;
            userDetail.EmailId = incidentUserEntity.EmailId;
            uow.UserDetailRepository.Add(userDetail);
            uow.Commit();

            User user = new User();
            user.ForceEmployeeId = incidentUserEntity.ForceEmployeeId;
            user.UserDetailId = userDetail.UserDetailId; ;
            user.UserTypeId = (int)Constants.UserType.InvestigatorDirected;
            user.Active = true;
            uow.UserRepository.Add(user);
            uow.Commit();

            return user.UserId;

        }
        private void UpdateUserDetails(IncidentUserEntity incidentUserEntity)
        {
            User usrs = uow.UserRepository.GetAll().Where(x => x.ForceEmployeeId == incidentUserEntity.PreviousId && x.UserTypeId == incidentUserEntity.UserTypeId).FirstOrDefault();
            if (usrs != null)
            {
                if (usrs.ForceEmployeeId != incidentUserEntity.PreviousId)
                {
                    UserDetail userDetail = uow.UserDetailRepository.GetById(usrs.UserDetailId);
                    userDetail.FirstName = incidentUserEntity.FirstName;
                    userDetail.LastName = incidentUserEntity.LastName;
                    userDetail.Rank = incidentUserEntity.Rank;
                    userDetail.EmailId = incidentUserEntity.EmailId;
                    uow.UserDetailRepository.Update(userDetail);
                    uow.Commit();

                    usrs.ForceEmployeeId = incidentUserEntity.ForceEmployeeId;
                    usrs.UserDetailId = userDetail.UserDetailId;
                    uow.UserRepository.Update(usrs);
                    uow.Commit();
                }
            }

        }

        public List<IncidentEntity> GetUserIncidents(string userId, string userRole)
        {
            List<IncidentEntity> rankIncidents = new List<IncidentEntity>();
            List<IncidentEntity> incidentList = (from incident in uow.IncidentRepository.GetAll()
                                                 join IS in uow.InvestigationOfficerRespository.GetAll() on incident.IncidentId equals IS.IncidentId into Invest
                                                 from mappings in Invest.DefaultIfEmpty()
                                                 where incident.IsDeleted == false
                                                 select new IncidentEntity
                                                 {
                                                     IncidentId = incident.IncidentId,
                                                     URN = incident.URN,
                                                     IncidentCreateDate = incident.IncidentCreatedDate,
                                                     ForceTypeId = incident.ForceTypeId,
                                                     IncidentApprovalStatus = incident.IncidentApprovalStatus,
                                                     IncidentCategoryId = incident.IncidentCategoryId,
                                                     EmpId = incident.SergeantId,
                                                     InvestOfficerId = mappings.EmployeeId,
                                                 }).ToList();
            //TODO: Need to remove tolist in the main query: Performance

            int? rank = (from ind in uow.UserRoleRepository.GetAll()
                         where ind.RoleCode == userRole
                         select new { ind.Rank }).Single().Rank;
            if (incidentList.Count > 0)
            {
                rankIncidents = (from incident in incidentList
                                 join ir in uow.IncidentRankRespository.GetAll() on incident.IncidentId equals ir.IncidentId
                                 join wf in uow.IncidentWorkflowRepository.GetAll() on incident.IncidentId equals wf.IncidentId
                                 where (wf.DCStatus != "Completed")
                                 select new IncidentEntity
                                 {
                                     IncidentId = incident.IncidentId,
                                     URN = incident.URN,
                                     IncidentCreateDate = incident.IncidentCreateDate,
                                     ForceTypeId = incident.ForceTypeId,
                                     IncidentApprovalStatus = incident.IncidentApprovalStatus,
                                     UserStatusOnIncident = wf.SergeantStatus,
                                     IncidentCategoryId = incident.IncidentCategoryId,
                                     InvestOfficerId = incident.InvestOfficerId,
                                     incidentRank = ir.Rank,
                                     WorkFlowStatus = new WorkFlowEntity { SergeantStatus = wf.SergeantStatus, WCStatus = wf.WCStatus, UCStatus = wf.UCStatus, CMStatus = wf.CMStatus, CFRCStatus = wf.CFRCStatus, CFRTStatus = wf.CFRTStatus },
                                 }).ToList();
            }
            rankIncidents.ForEach(se => se.IncidentApprovalStatus = ResolveStatus(Convert.ToInt32(se.IncidentApprovalStatus)));
            switch (userRole)
            {
                //case "DC":
                //    rankIncidents = rankIncidents.Where(x => x.incidentRank <= 6).ToList();
                //    break;
                //case "CMDR":
                //    rankIncidents = rankIncidents.Where(x => x.incidentRank <= 5).ToList();
                //    break;
                //case "CAPT":
                //    rankIncidents = rankIncidents.Where(x => x.incidentRank <= 5).ToList();
                //    break;
                //case "WC":
                //    rankIncidents = rankIncidents.Where(x => x.incidentRank <= 4).ToList();
                //    break;
                //case "SGT":
                //    rankIncidents = rankIncidents.Where(x => x.incidentRank <= 2).ToList();
                //    break;
                case "CFRT":
                    rankIncidents = rankIncidents.Where(x => x.IncidentApprovalStatus == Constants.IncidentStatus.AtCFRT.ToString()).ToList();
                    break;
                case "MED":
                    rankIncidents = (from incident in rankIncidents
                                     join ir in uow.ReviewRespository.GetAll() on incident.IncidentId equals ir.IncidentID
                                     where ((ir.FormId == (int)Constants.UOFForms.MedicalReport || ir.FormId == (int)Constants.UOFForms.InmateInjuryIllness) && ir.InvolvedStatus != "Deleted")
                                     select incident).Distinct().ToList();

                    //rankIncidents = rankIncidents.Where(x => x.IncidentApprovalStatus == Constants.IncidentStatus.AtDeputy.ToString() || x.IncidentApprovalStatus == Constants.IncidentStatus.AtSergeant.ToString()).ToList();
                    break;
                //default:
                //    rankIncidents = (from incident in rankIncidents
                //                     join ir in uow.ReviewRespository.GetAll() on incident.IncidentId equals ir.IncidentID
                //                     where ((ir.FormId == (int)Constants.UOFForms.MedicalReport || ir.FormId == (int)Constants.UOFForms.InmateInjuryIllness) && ir.InvolvedStatus != "Deleted")
                //                     select incident).Distinct().ToList();
                //    break;
            }
            return rankIncidents;
        }


        public List<IncidentEntity> GetUserIncidents_old(string userId, string userRole)
        {
            List<IncidentEntity> IncidentUses = new List<IncidentEntity>();

            List<IncidentEntity> incidentList = (from incident in uow.IncidentRepository.GetAll()
                                                 //join address in uow.AddressRepository.GetAll() on incident.AddressId equals address.AddressId
                                                 where incident.IsDeleted == false
                                                 select new IncidentEntity
                                                 {
                                                     IncidentId = incident.IncidentId,
                                                     URN = incident.URN,
                                                     IncidentCreateDate = incident.IncidentCreatedDate,
                                                     ForceTypeId = incident.ForceTypeId,
                                                     IncidentApprovalStatus = incident.IncidentApprovalStatus,
                                                     IncidentCategoryId = incident.IncidentCategoryId,
                                                     EmpId = incident.SergeantId,
                                                 }).ToList();

            if (incidentList.Count > 0)
            {

                //#region Investigation Officer
                //var superList = (from incident in incidentList
                //                 join incidentUser in uow.IncidentUserRepository.GetAll() on incident.IncidentId equals incidentUser.IncidentId
                //                 join user in uow.UserRepository.GetAll() on incidentUser.UserId equals user.UserId
                //                 join userDetail in uow.UserDetailRepository.GetAll() on user.UserDetailId equals userDetail.UserDetailId
                //                 join wf in uow.IncidentWorkflowRepository.GetAll() on incident.IncidentId equals wf.IncidentId
                //                 join IO in uow.InvestigationOfficerRespository.GetAll() on user.ForceEmployeeId equals IO.EmployeeId
                //                 where user.ForceEmployeeId == userId && (user.UserTypeId == 9 || user.UserTypeId == 8) && IO.Status == "Active"
                //                 select new IncidentEntity
                //                 {
                //                     IncidentId = incident.IncidentId,
                //                     URN = incident.URN,
                //                     IncidentCreateDate = incident.IncidentCreateDate,
                //                     ForceTypeId = incident.ForceTypeId,
                //                     IncidentCategoryId = incident.IncidentCategoryId,
                //                     IncidentApprovalStatus = incident.IncidentApprovalStatus,
                //                 }).ToList().Distinct();
                //foreach (var item in superList)
                //{
                //    IncidentUses.Add(item);
                //}

                //#endregion


                switch (userRole)
                {
                    case "SGT":
                        //var superList = (from incident in incidentList
                        //                 join incidentUser in uow.IncidentUserRepository.GetAll() on incident.IncidentId equals incidentUser.IncidentId
                        //                 join user in uow.UserRepository.GetAll() on incidentUser.UserId equals user.UserId
                        //                 join userDetail in uow.UserDetailRepository.GetAll() on user.UserDetailId equals userDetail.UserDetailId
                        //                 join wf in uow.IncidentWorkflowRepository.GetAll() on incident.IncidentId equals wf.IncidentId
                        //                 where user.ForceEmployeeId == userId && (user.UserTypeId == 9 || user.UserTypeId == 8)
                        //                 select new IncidentEntity
                        //                 {
                        //                     IncidentId = incident.IncidentId,
                        //                     URN = incident.URN,
                        //                     IncidentCreateDate = incident.IncidentCreateDate,
                        //                     ForceTypeId = incident.ForceTypeId,
                        //                     IncidentCategoryId = incident.IncidentCategoryId,
                        //                     IncidentApprovalStatus = incident.IncidentApprovalStatus,
                        //                     WorkFlowStatus = new WorkFlowEntity { SergeantStatus = wf.SergeantStatus, WCStatus = wf.WCStatus, UCStatus = wf.UCStatus, CMStatus = wf.CMStatus, CFRCStatus = wf.CFRCStatus, CFRTStatus = wf.CFRTStatus },
                        //                 }).ToList().Distinct();
                        //foreach (var item in superList)
                        //{
                        //    IncidentUses.Add(item);
                        //}

                        var PrimSergts = (from incident in incidentList
                                          join wf in uow.IncidentWorkflowRepository.GetAll() on incident.IncidentId equals wf.IncidentId
                                          where (wf.SergeantID == userId || incident.EmpId == "0")
                                          select new IncidentEntity
                                          {
                                              IncidentId = incident.IncidentId,
                                              URN = incident.URN,
                                              IncidentCreateDate = incident.IncidentCreateDate,
                                              ForceTypeId = incident.ForceTypeId,
                                              IncidentApprovalStatus = incident.IncidentApprovalStatus,
                                              UserStatusOnIncident = wf.SergeantStatus,
                                              IncidentCategoryId = incident.IncidentCategoryId,
                                              WorkFlowStatus = new WorkFlowEntity { SergeantStatus = wf.SergeantStatus, WCStatus = wf.WCStatus, UCStatus = wf.UCStatus, CMStatus = wf.CMStatus, CFRCStatus = wf.CFRCStatus, CFRTStatus = wf.CFRTStatus },
                                          }).ToList();

                        foreach (var item in PrimSergts)
                        {
                            IncidentUses.Add(item);
                        }
                        //}
                        IncidentUses.ForEach(se => se.IncidentApprovalStatus = ResolveStatus(Convert.ToInt32(se.IncidentApprovalStatus)));
                        //For sergeant should know where the incident. so below code.

                        break;
                    case "DSG":
                        foreach (IncidentEntity item in incidentList)
                        {
                            string deputyStatus = CheckIncidentStatus(item.IncidentId, userId, item.IncidentApprovalStatus);
                            if (!string.IsNullOrWhiteSpace(deputyStatus))
                            {
                                item.IncidentApprovalStatus = deputyStatus;
                                IncidentUses.Add(item);
                            }
                            else
                            {
                                if (IncidentUses.Count <= 0)
                                    IncidentUses = new List<IncidentEntity>();
                            }
                        }
                        break;
                    case "WC":

                        //Involved Employee
                        if (uow.ReviewRespository.GetAll().Where(x => x.InvolvedId == userId).Any())
                        {
                            foreach (IncidentEntity item in incidentList)
                            {
                                if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == item.IncidentId && x.InvolvedId == userId && x.WCID != userId).Any())
                                {
                                    //bool DeputyCount = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == item.IncidentId && x.InvolvedId == userId && x.SergeantStatus != "Completed").Any();
                                    //if (DeputyCount)
                                    //    return "At Deputy";
                                    //else
                                    //    return ResolveStatus(Convert.ToInt16(item.IncidentApprovalStatus));

                                    //item.IncidentApprovalStatus = ResolveStatus(Convert.ToInt16(item.IncidentApprovalStatus));
                                    IncidentUses.Add(item);
                                }

                                //string deputyStatus = CheckIncidentStatus(item.IncidentId, userId, item.IncidentApprovalStatus);
                                //if (!string.IsNullOrWhiteSpace(deputyStatus))
                                //{
                                //item.IncidentApprovalStatus = deputyStatus;
                                //IncidentUses.Add(item);
                                //}
                            }

                            //var InvolvedLst = (from incident in incidentList
                            //                   join rr in uow.ReviewRespository.GetAll() on incident.IncidentId equals rr.IncidentID
                            //                   //join incidentUser in uow.IncidentUserRepository.GetAll() on incident.IncidentId equals incidentUser.IncidentId
                            //                   //join user in uow.UserRepository.GetAll() on incidentUser.UserId equals user.UserId
                            //                   //join userDetail in uow.UserDetailRepository.GetAll() on user.UserDetailId equals userDetail.UserDetailId
                            //                   where rr.InvolvedId == userId //|| (user.ForceEmployeeId == userId && user.UserTypeId == 1)
                            //                   select new IncidentEntity
                            //                   {
                            //                       IncidentId = incident.IncidentId,
                            //                       URN = incident.URN,
                            //                       IncidentCreateDate = incident.IncidentCreateDate,
                            //                       ForceTypeId = incident.ForceTypeId,
                            //                       IncidentCategoryId = incident.IncidentCategoryId,
                            //                       IncidentApprovalStatus = CheckIncidentStatus(incident.IncidentId, userId, incident.IncidentApprovalStatus)
                            //                   }).ToList().Distinct();
                            //foreach (var item in InvolvedLst)
                            //{
                            //    IncidentUses.Add(item);
                            //}
                        }

                        //Watch Commander Role
                        if (uow.UserRepository.GetAll().Where(x => x.ForceEmployeeId == userId).Any())
                        {
                            var WCRoleIncidents = (from incident in incidentList
                                                   join wf in uow.IncidentWorkflowRepository.GetAll() on incident.IncidentId equals wf.IncidentId
                                                   where wf.WCID == userId
                                                   select new IncidentEntity
                                                   {
                                                       IncidentId = incident.IncidentId,
                                                       URN = incident.URN,
                                                       IncidentCreateDate = incident.IncidentCreateDate,
                                                       ForceTypeId = incident.ForceTypeId,
                                                       IncidentCategoryId = incident.IncidentCategoryId,
                                                       IncidentApprovalStatus = incident.IncidentApprovalStatus,
                                                       UserStatusOnIncident = wf.WCStatus,
                                                   }).ToList();
                            foreach (var item in WCRoleIncidents)
                            {
                                IncidentUses.Add(item);
                            }

                            //For sergeant should know where the incident. so below code.
                            // WCRoleIncidents.ForEach(se => se.IncidentApprovalStatus = ResolveStatus(Convert.ToInt32(se.IncidentApprovalStatus)));
                        }

                        //Incident Is added.
                        //if (uow.IncidentRepository.GetAll().Where(x => x.SergeantId == userId).Any())
                        //{
                        var WCIncidents = (from incident in incidentList
                                           join wf in uow.IncidentWorkflowRepository.GetAll() on incident.IncidentId equals wf.IncidentId
                                           where (wf.SergeantID == userId || incident.EmpId == "0")
                                           select new IncidentEntity
                                           {
                                               IncidentId = incident.IncidentId,
                                               URN = incident.URN,
                                               IncidentCreateDate = incident.IncidentCreateDate,
                                               ForceTypeId = incident.ForceTypeId,
                                               IncidentApprovalStatus = incident.IncidentApprovalStatus,
                                               IncidentCategoryId = incident.IncidentCategoryId,
                                               UserStatusOnIncident = wf.WCStatus,
                                           }).ToList();
                        //For sergeant should know where the incident. so below code.
                        //WCIncidents.ForEach(se => se.IncidentApprovalStatus = ResolveStatus(Convert.ToInt32(se.IncidentApprovalStatus)));

                        foreach (var item in WCIncidents)
                        {
                            IncidentUses.Add(item);
                        }

                        //}
                        IncidentUses.ForEach(se => se.IncidentApprovalStatus = ResolveStatus(Convert.ToInt32(se.IncidentApprovalStatus)));
                        break;
                    case "CAPT":
                        //Involved Employee
                        if (uow.ReviewRespository.GetAll().Where(x => x.InvolvedId == userId).Any())
                        {

                            foreach (IncidentEntity item in incidentList)
                            {
                                if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == item.IncidentId && x.InvolvedId == userId && x.UCID != userId).Any())
                                {
                                    //item.IncidentApprovalStatus = ResolveStatus(Convert.ToInt16(item.IncidentApprovalStatus));
                                    IncidentUses.Add(item);
                                }

                            }

                        }

                        //Unit Commander Role
                        if (uow.UserRepository.GetAll().Where(x => x.ForceEmployeeId == userId).Any())
                        {
                            var WCRoleIncidents = (from incident in incidentList
                                                   join wf in uow.IncidentWorkflowRepository.GetAll() on incident.IncidentId equals wf.IncidentId
                                                   where wf.UCID == userId
                                                   select new IncidentEntity
                                                   {
                                                       IncidentId = incident.IncidentId,
                                                       URN = incident.URN,
                                                       IncidentCreateDate = incident.IncidentCreateDate,
                                                       ForceTypeId = incident.ForceTypeId,
                                                       IncidentCategoryId = incident.IncidentCategoryId,
                                                       IncidentApprovalStatus = incident.IncidentApprovalStatus,
                                                       UserStatusOnIncident = wf.UCStatus,
                                                   }).ToList();
                            foreach (var item in WCRoleIncidents)
                            {
                                IncidentUses.Add(item);
                            }
                            //For sergeant should know where the incident. so below code.
                            // WCRoleIncidents.ForEach(se => se.IncidentApprovalStatus = ResolveStatus(Convert.ToInt32(se.IncidentApprovalStatus)));
                        }

                        //Incident Is added.
                        //if (uow.IncidentRepository.GetAll().Where(x => x.SergeantId == userId).Any())
                        //{
                        var UCIncidents = (from incident in incidentList
                                           join wf in uow.IncidentWorkflowRepository.GetAll() on incident.IncidentId equals wf.IncidentId
                                           where (wf.SergeantID == userId || incident.EmpId == "0")
                                           select new IncidentEntity
                                           {
                                               IncidentId = incident.IncidentId,
                                               URN = incident.URN,
                                               IncidentCreateDate = incident.IncidentCreateDate,
                                               ForceTypeId = incident.ForceTypeId,
                                               IncidentApprovalStatus = incident.IncidentApprovalStatus,
                                               IncidentCategoryId = incident.IncidentCategoryId,
                                               UserStatusOnIncident = wf.SergeantStatus,
                                           }).ToList();


                        foreach (var item in UCIncidents)
                        {
                            IncidentUses.Add(item);
                        }
                        IncidentUses.ForEach(se => se.IncidentApprovalStatus = ResolveStatus(Convert.ToInt32(se.IncidentApprovalStatus)));
                        break;
                    case "CMDR":
                        if (uow.ReviewRespository.GetAll().Where(x => x.InvolvedId == userId).Any())
                        {
                            foreach (IncidentEntity item in incidentList)
                            {
                                if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == item.IncidentId && x.InvolvedId == userId && x.CMID != userId).Any())
                                {
                                    //item.IncidentApprovalStatus = ResolveStatus(Convert.ToInt16(item.IncidentApprovalStatus));
                                    IncidentUses.Add(item);
                                }

                            }

                        }

                        //Commander Role
                        if (uow.UserRepository.GetAll().Where(x => x.ForceEmployeeId == userId).Any())
                        {
                            var CMRoleIncidents = (from incident in incidentList
                                                   join wf in uow.IncidentWorkflowRepository.GetAll() on incident.IncidentId equals wf.IncidentId
                                                   where wf.CMID == userId
                                                   select new IncidentEntity
                                                   {
                                                       IncidentId = incident.IncidentId,
                                                       URN = incident.URN,
                                                       IncidentCreateDate = incident.IncidentCreateDate,
                                                       ForceTypeId = incident.ForceTypeId,
                                                       IncidentCategoryId = incident.IncidentCategoryId,
                                                       IncidentApprovalStatus = incident.IncidentApprovalStatus,
                                                       UserStatusOnIncident = wf.CMStatus,
                                                   }).ToList();
                            foreach (var item in CMRoleIncidents)
                            {
                                IncidentUses.Add(item);
                            }
                            // CMRoleIncidents.ForEach(se => se.IncidentApprovalStatus =  (se.IncidentApprovalStatus.Length == 2? ResolveStatus(Convert.ToInt32(se.IncidentApprovalStatus)): (se.IncidentApprovalStatus)));
                            //CMRoleIncidents.ForEach(se => se.IncidentApprovalStatus = ResolveStatus(Convert.ToInt32(se.IncidentApprovalStatus)));
                        }
                        //if (uow.IncidentRepository.GetAll().Where(x => x.SergeantId == userId).Any())
                        //{
                        var incds = (from incident in incidentList
                                     join wf in uow.IncidentWorkflowRepository.GetAll() on incident.IncidentId equals wf.IncidentId

                                     where (wf.SergeantID == userId || incident.EmpId == "0")
                                     select new IncidentEntity
                                     {
                                         IncidentId = incident.IncidentId,
                                         URN = incident.URN,
                                         IncidentCreateDate = incident.IncidentCreateDate,
                                         ForceTypeId = incident.ForceTypeId,
                                         IncidentApprovalStatus = incident.IncidentApprovalStatus,
                                         IncidentCategoryId = incident.IncidentCategoryId,
                                         UserStatusOnIncident = wf.SergeantStatus,

                                         WorkFlowStatus = new WorkFlowEntity { SergeantStatus = wf.SergeantStatus, WCStatus = wf.WCStatus, UCStatus = wf.UCStatus, CMStatus = wf.CMStatus, CFRCStatus = wf.CFRCStatus, CFRTStatus = wf.CFRTStatus },
                                     }).ToList();
                        foreach (var item in incds)
                        {
                            IncidentUses.Add(item);
                        }
                        //}
                        IncidentUses.ForEach(se => se.IncidentApprovalStatus = ResolveStatus(Convert.ToInt32(se.IncidentApprovalStatus)));
                        break;
                    case "CFRT":
                        //CFRT Role
                        var CFRTIncidents = (from incident in incidentList
                                             join wf in uow.IncidentCFRTRepository.GetAll() on incident.IncidentId equals wf.IncidentId
                                             select new IncidentEntity
                                             {
                                                 IncidentId = incident.IncidentId,
                                                 URN = incident.URN,
                                                 IncidentCreateDate = incident.IncidentCreateDate,
                                                 ForceTypeId = incident.ForceTypeId,
                                                 IncidentCategoryId = incident.IncidentCategoryId,
                                                 IncidentApprovalStatus = incident.IncidentApprovalStatus,
                                                 UserStatusOnIncident = wf.CRFCStatus
                                             }).ToList();
                        foreach (var item in CFRTIncidents)
                        {
                            IncidentUses.Add(item);
                        }
                        IncidentUses.ForEach(se => se.IncidentApprovalStatus = ResolveStatus(Convert.ToInt32(se.IncidentApprovalStatus)));
                        break;
                    case "MED":
                        //MED Role
                        var MEDIncidents = (from incident in incidentList
                                            join frm in uow.ReviewRespository.GetAll() on incident.IncidentId equals frm.IncidentID
                                            where frm.FormId == (int)Constants.UOFForms.MedicalReport
                                            select new IncidentEntity
                                            {
                                                IncidentId = incident.IncidentId,
                                                URN = incident.URN,
                                                IncidentCreateDate = incident.IncidentCreateDate,
                                                ForceTypeId = incident.ForceTypeId,
                                                IncidentCategoryId = incident.IncidentCategoryId,
                                                IncidentApprovalStatus = incident.IncidentApprovalStatus,
                                            }).ToList();
                        foreach (var item in MEDIncidents)
                        {
                            IncidentUses.Add(item);
                        }
                        IncidentUses.ForEach(se => se.IncidentApprovalStatus = ResolveStatus(Convert.ToInt32(se.IncidentApprovalStatus)));
                        break;
                    default:
                        break;

                }
            }

            return IncidentUses;
        }

        public List<IncidentStatusDetail> GetIncidentFormData(string userId, string userRole, int incidentId)
        {
            List<IncidentStatusDetail> formsList = new List<IncidentStatusDetail>();

            var incidentList = (from a in uow.ReviewRespository.GetAll()
                                join c in uow.UofFormRepository.GetAll() on a.FormId equals c.FormId
                                join incidentUser in uow.IncidentUserRepository.GetAll() on a.IncidentID equals incidentUser.IncidentId
                                join user in uow.UserRepository.GetAll() on incidentUser.UserId equals user.UserId
                                join userDetail in uow.UserDetailRepository.GetAll() on user.UserDetailId equals userDetail.UserDetailId
                                where a.IncidentID == incidentId && a.InvolvedId == user.ForceEmployeeId 
                                && a.InvolvedStatus != Constants.Status.Deleted.ToString() && a.FormId != 48
                                select new IncidentStatusDetail
                                {
                                    ReviewId = a.IncidentReviewID,
                                    FromDataId = a.FormDataID,
                                    EmployeeID = a.InvolvedId,
                                    Role = a.InvolvedRole,
                                    IncidentId = a.IncidentID,
                                    FirstName = userDetail.FirstName,
                                    LastName = userDetail.LastName,
                                    Status = a.InvolvedStatus,
                                    SergeantStatus = a.SergeantStatus,
                                    FormId = a.FormId,
                                    FormName = c.FormName,
                                    FormStatus = (a.InvolvedStatus == "DON" || a.InvolvedStatus == "Completed") ? "Completed" : (a.InvolvedStatus == Constants.Status.Rejected.ToString() ? Constants.Status.Rejected.ToString() : "Pending"),
                                    ReviewerRole = a.ReviewerRole,
                                    SergeantId = a.SergeantId,
                                    WCID = a.WCID,
                                    WCStatus = a.WCStatus,
                                    UCID = a.UCID,
                                    UCStatus = a.UCStatus,
                                    CMID = a.CMID,
                                    CMStatus = a.CMStatus,
                                }).Distinct().ToList();
            incidentList = incidentList.FindAll(a => a.FormStatus == Constants.Status.DON.ToString() || a.FormStatus == Constants.Status.Completed.ToString() || a.FormStatus == Constants.Status.Pending.ToString() || a.FormStatus == Constants.Status.Rejected.ToString()); //Added pending also




            var requiredRoleTypeIds = new string[] { "" };
            switch (userRole)
            {
                //Rank"2"
                case "SGT":
                    requiredRoleTypeIds = new string[] { Constants.UserRoles.SGT.ToString(), Constants.UserRoles.DSG.ToString() };
                    formsList = (from a in incidentList
                                 where requiredRoleTypeIds.Contains(a.Role)
                                 select new IncidentStatusDetail
                                 {
                                     ReviewId = a.ReviewId,
                                     FromDataId = a.FromDataId,
                                     URN = a.URN,
                                     EmployeeID = a.EmployeeID,
                                     Role = a.Role,
                                     IncidentId = a.IncidentId,
                                     Status = (a.EmployeeID != userId ? a.SergeantStatus : a.WCStatus),
                                     FormId = a.FormId,
                                     FormName = a.FormName,
                                     FormStatus = a.FormStatus == "PND" ? "Pending" : a.FormStatus == "DON" ? "Completed" : a.FormStatus,
                                     ReviewerRole = a.ReviewerRole,
                                     ReviewerUserId = a.SergeantId,
                                     FirstName = a.FirstName,
                                     LastName = a.LastName,
                                     isOwner = (a.SergeantId == userId) ? true : false
                                 }).ToList();
                    break;
                //Rank"1"
                case "DSG":
                    requiredRoleTypeIds = new string[] { Constants.UserRoles.DSG.ToString() };
                    formsList = (from a in incidentList
                                 where requiredRoleTypeIds.Contains(a.Role) &&
                                 a.EmployeeID == userId
                                 select new IncidentStatusDetail
                                 {
                                     ReviewId = a.ReviewId,
                                     FromDataId = a.FromDataId,
                                     URN = a.URN,
                                     EmployeeID = a.EmployeeID,
                                     Role = a.Role,
                                     IncidentId = a.IncidentId,
                                     Status = a.SergeantStatus,
                                     FormId = a.FormId,
                                     FormName = a.FormName,
                                     FormStatus = a.FormStatus == "PND" ? "Pending" : a.FormStatus == "DON" ? "Completed" : a.FormStatus,
                                     ReviewerRole = a.ReviewerRole,
                                     ReviewerUserId = a.SergeantId,
                                     FirstName = a.FirstName,
                                     LastName = a.LastName,
                                     isOwner = (a.EmployeeID == userId) ? true : false
                                 }).ToList();
                    break;
                //Rank"3"
                case "WC":
                    requiredRoleTypeIds = new string[] { Constants.UserRoles.SGT.ToString(), Constants.UserRoles.DSG.ToString(), Constants.UserRoles.WC.ToString() };
                    //Condition to implementWF for MEdical and Inmate Forms
                    bool isMIFormsExists = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && x.SergeantStatus == Constants.Status.Completed.ToString() && x.WCStatus != Constants.Status.Completed.ToString() && (x.FormId == (int)Constants.UOFForms.MedicalReport || x.FormId == (int)Constants.UOFForms.InmateInjuryIllness)).Any();
                    var checkMedical = uow.IncidentMedicalRespository.GetAll().Where(x => x.IncidentId == incidentId && (x.FormId == (int)Constants.UOFForms.MedicalReport || x.FormId == (int)Constants.UOFForms.InmateInjuryIllness) && x.Active == true).FirstOrDefault();
                    if (isMIFormsExists)
                    {
                        formsList = (from a in incidentList
                                     join ir in uow.IncidentRankRespository.GetAll() on a.IncidentId equals ir.IncidentId
                                     where requiredRoleTypeIds.Contains(a.Role)
                                     && a.SergeantStatus == Constants.Status.Completed.ToString()
                                     && (a.FormId == (int)Constants.UOFForms.MedicalReport || a.FormId == (int)Constants.UOFForms.InmateInjuryIllness)
                                     && (ir.Rank == 3 || ((a.WCStatus == Constants.Status.Completed.ToString() || a.WCStatus == Constants.Status.Pending.ToString()) && a.SergeantStatus == Constants.Status.Completed.ToString()))
                                     select new IncidentStatusDetail
                                     {
                                         ReviewId = a.ReviewId,
                                         FromDataId = a.FromDataId,
                                         URN = a.URN,
                                         EmployeeID = a.EmployeeID,
                                         Role = a.Role,
                                         IncidentId = a.IncidentId,
                                         Status = a.WCStatus,
                                         FormId = a.FormId,
                                         FormName = a.FormName,
                                         FormStatus = (checkMedical == null ? "Pending at Medical" : a.FormStatus == "PND" ? "Pending" : a.FormStatus == "DON" ? "Completed" : a.FormStatus),
                                         ReviewerRole = a.ReviewerRole,
                                         ReviewerUserId = a.WCID,
                                         FirstName = a.FirstName,
                                         LastName = a.LastName,
                                         isOwner = (a.WCID == userId) ? true : false
                                     }).ToList();
                    }
                    else
                    {

                        formsList = (from a in incidentList
                                     join ir in uow.IncidentRankRespository.GetAll() on a.IncidentId equals ir.IncidentId
                                     where requiredRoleTypeIds.Contains(a.Role)
                                         //&& a.SergeantStatus == Constants.Status.Completed.ToString()
                                     && (ir.Rank == 3 || (a.WCStatus == Constants.Status.Completed.ToString() && (a.SergeantStatus == Constants.Status.Completed.ToString() || a.SergeantStatus == "")))
                                     //&& (ir.Rank == 3)
                                     select new IncidentStatusDetail
                                     {
                                         ReviewId = a.ReviewId,
                                         FromDataId = a.FromDataId,
                                         URN = a.URN,
                                         EmployeeID = a.EmployeeID,
                                         Role = a.Role,
                                         IncidentId = a.IncidentId,
                                         Status = (a.WCStatus == Constants.Status.Completed.ToString() ? Constants.Status.Completed.ToString() : (a.WCStatus == Constants.Status.Pending.ToString() ? Constants.Status.Pending.ToString() : Constants.Status.NotReady.ToString())),
                                         FormId = a.FormId,
                                         FormName = a.FormName,
                                         FormStatus = a.FormStatus == "PND" ? "Pending" : a.FormStatus == "DON" ? "Completed" : a.FormStatus,
                                         ReviewerRole = a.ReviewerRole,
                                         ReviewerUserId = a.WCID,
                                         FirstName = a.FirstName,
                                         LastName = a.LastName,
                                         isOwner = (a.WCID == userId) ? true : false
                                     }).ToList();
                    }
                    break;
                //Rank"4"
                case "CAPT":
                    requiredRoleTypeIds = new string[] { Constants.UserRoles.SGT.ToString(), Constants.UserRoles.DSG.ToString(), Constants.UserRoles.WC.ToString(), Constants.UserRoles.CAPT.ToString() };
                    formsList = (from a in incidentList
                                 join ir in uow.IncidentRankRespository.GetAll() on a.IncidentId equals ir.IncidentId
                                 where requiredRoleTypeIds.Contains(a.Role)
                                 && (ir.Rank == 4 || ((a.WCStatus == Constants.Status.Completed.ToString() && a.WCStatus == "") && a.UCStatus == Constants.Status.Completed.ToString()))
                                 select new IncidentStatusDetail
                                 {
                                     ReviewId = a.ReviewId,
                                     FromDataId = a.FromDataId,
                                     URN = a.URN,
                                     EmployeeID = a.EmployeeID,
                                     Role = a.Role,
                                     IncidentId = a.IncidentId,
                                     Status = a.UCStatus,
                                     FormId = a.FormId,
                                     FormName = a.FormName,
                                     FormStatus = a.FormStatus == "PND" ? "Pending" : a.FormStatus == "DON" ? "Completed" : a.FormStatus,
                                     ReviewerRole = a.ReviewerRole,
                                     ReviewerUserId = a.UCID,
                                     FirstName = a.FirstName,
                                     LastName = a.LastName,
                                     isOwner = (a.UCID == userId) ? true : false
                                 }).ToList();
                    break;
                //Rank"5"
                case "CMDR":
                    requiredRoleTypeIds = new string[] { Constants.UserRoles.SGT.ToString(), Constants.UserRoles.DSG.ToString(), Constants.UserRoles.WC.ToString(), Constants.UserRoles.CAPT.ToString(), Constants.UserRoles.CMDR.ToString() };
                    formsList = (from a in incidentList
                                 //join ir in uow.IncidentRankRespository.GetAll() on a.IncidentId equals ir.IncidentId
                                 where requiredRoleTypeIds.Contains(a.Role) && (a.CMStatus == Constants.Status.Completed.ToString() || a.CMStatus == Constants.Status.Pending.ToString())
                                 //&& (ir.Rank == 5 || (a.CMStatus == Constants.Status.Completed.ToString() && (a.UCStatus == Constants.Status.Completed.ToString() || a.UCStatus == "")))
                                 select new IncidentStatusDetail
                                 {
                                     ReviewId = a.ReviewId,
                                     FromDataId = a.FromDataId,
                                     URN = a.URN,
                                     EmployeeID = a.EmployeeID,
                                     Role = a.Role,
                                     IncidentId = a.IncidentId,
                                     Status = a.CMStatus,
                                     FormId = a.FormId,
                                     FormName = a.FormName,
                                     FormStatus = a.FormStatus == "PND" ? "Pending" : a.FormStatus == "DON" ? "Completed" : a.FormStatus,
                                     ReviewerRole = a.ReviewerRole,
                                     ReviewerUserId = a.CMID,
                                     FirstName = a.FirstName,
                                     LastName = a.LastName,
                                     isOwner = (a.CMID == userId) ? true : false
                                 }).ToList();
                    break;
                //Rank "6"
                case "DC":
                    requiredRoleTypeIds = new string[] { Constants.UserRoles.SGT.ToString(), Constants.UserRoles.DSG.ToString(), Constants.UserRoles.WC.ToString(), Constants.UserRoles.CAPT.ToString(), Constants.UserRoles.CMDR.ToString() };
                    formsList = (from a in incidentList
                                 join ir in uow.IncidentRankRespository.GetAll() on a.IncidentId equals ir.IncidentId
                                 where requiredRoleTypeIds.Contains(a.Role)
                                 && (ir.Rank == 6 || (a.DCStatus == Constants.Status.Completed.ToString() && a.WCStatus == Constants.Status.Completed.ToString() && a.SergeantStatus == Constants.Status.Completed.ToString() && a.UCStatus == Constants.Status.Completed.ToString() && a.CMStatus == Constants.Status.Completed.ToString()))
                                 select new IncidentStatusDetail
                                 {
                                     ReviewId = a.ReviewId,
                                     FromDataId = a.FromDataId,
                                     URN = a.URN,
                                     EmployeeID = a.EmployeeID,
                                     Role = a.Role,
                                     IncidentId = a.IncidentId,
                                     Status = a.CMStatus,
                                     FormId = a.FormId,
                                     FormName = a.FormName,
                                     FormStatus = a.FormStatus == "PND" ? "Pending" : a.FormStatus == "DON" ? "Completed" : a.FormStatus,
                                     ReviewerRole = a.ReviewerRole,
                                     ReviewerUserId = a.CMID,
                                     FirstName = a.FirstName,
                                     LastName = a.LastName,
                                     isOwner = (a.CMID == userId) ? true : false
                                 }).ToList();
                    break;


                //Rank"8"
                case "CFRT":
                    requiredRoleTypeIds = new string[] { Constants.UserRoles.SGT.ToString(), Constants.UserRoles.DSG.ToString(), Constants.UserRoles.WC.ToString(), Constants.UserRoles.CAPT.ToString() };
                    formsList = (from a in incidentList
                                 join ir in uow.IncidentRankRespository.GetAll() on a.IncidentId equals ir.IncidentId
                                 where requiredRoleTypeIds.Contains(a.Role) && (ir.Rank == 8)
                                 select new IncidentStatusDetail
                                 {
                                     ReviewId = a.ReviewId,
                                     FromDataId = a.FromDataId,
                                     URN = a.URN,
                                     EmployeeID = a.EmployeeID,
                                     Role = a.Role,
                                     IncidentId = a.IncidentId,
                                     Status = a.UCStatus,
                                     FormId = a.FormId,
                                     FormName = a.FormName,
                                     FormStatus = a.FormStatus == "PND" ? "Pending" : a.FormStatus == "DON" ? "Completed" : a.FormStatus,
                                     ReviewerRole = a.ReviewerRole,
                                     FirstName = a.FirstName,
                                     LastName = a.LastName,
                                 }).ToList();
                    break;
                //Rank"1"
                case "MED":
                    //Using same variable to get the Medical and Inmate forms
                    var chkMedical = uow.IncidentMedicalRespository.GetAll().Where(x => x.IncidentId == incidentId && (x.FormId == (int)Constants.UOFForms.MedicalReport || x.FormId == (int)Constants.UOFForms.InmateInjuryIllness) && x.Active == true).FirstOrDefault();
                    requiredRoleTypeIds = new string[] { Convert.ToString((int)Constants.UOFForms.MedicalReport), Convert.ToString((int)Constants.UOFForms.InmateInjuryIllness) };
                    formsList = (from a in incidentList
                                 where requiredRoleTypeIds.Contains(a.FormId.ToString())

                                 select new IncidentStatusDetail
                                 {
                                     ReviewId = a.ReviewId,
                                     FromDataId = a.FromDataId,
                                     URN = a.URN,
                                     EmployeeID = a.EmployeeID,
                                     Role = a.Role,
                                     IncidentId = a.IncidentId,
                                     Status = Constants.Status.Pending.ToString(),
                                     FormId = a.FormId,
                                     FormName = a.FormName,
                                     FormStatus = (chkMedical == null ? "Pending" : a.FormStatus == "PND" ? "Pending" : a.FormStatus == "DON" ? "Completed" : a.FormStatus),
                                     ReviewerRole = a.ReviewerRole,
                                     FirstName = a.FirstName,
                                     LastName = a.LastName,
                                 }).ToList();
                    break;
                default:
                    break;
            }
            return formsList;

        }


        public List<IncidentStatusDetail> GetExplanationFormData(string userId, string userRole, int incidentId, int formId)
        {
            List<IncidentStatusDetail> explanationList = new List<IncidentStatusDetail>();
            //var explanationList = (from a in uow.ExplainationReviewRespository.GetAll()
            //                       join b in uow.ReviewRespository.GetAll() on a.IncidentReviewId equals b.IncidentReviewID
            //                       join c in uow.UofFormRepository.GetAll() on a.ExplanedOnFormID equals c.FormId
            //                       join incidentUser in uow.IncidentUserRepository.GetAll() on a.IncidentID equals incidentUser.IncidentId
            //                       join user in uow.UserRepository.GetAll() on incidentUser.UserId equals user.UserId
            //                       join userDetail in uow.UserDetailRepository.GetAll() on user.UserDetailId equals userDetail.UserDetailId
            //                       where a.IncidentID == incidentId && a.RptId == userId && a.ExplanedOnFormID == formId
            //                       select new IncidentStatusDetail
            //                       {
            //                           ReviewId = a.IncidentReviewId,
            //                           FromDataId = a.FormExplainationID,
            //                           EmployeeID = a.RptId,
            //                           Role = b.InvolvedRole,
            //                           IncidentId = a.IncidentID,
            //                           FirstName = userDetail.FirstName,
            //                           LastName = userDetail.LastName,
            //                           Status = b.SergeantStatus,
            //                           FormId = a.ExplanedFormID,
            //                           FormName = c.FormName,
            //                           FormStatus = (a.RptStatus == "DON" || a.RptStatus == "Completed") ? "Completed" : "Pending",
            //                           //ReviewerRole = b.SupervisoryRole,
            //                           SergeantId = b.SergeantId,
            //                           WCID = b.WCID,
            //                           WCStatus = b.WCStatus,
            //                           UCID = b.UCID,
            //                           UCStatus = b.UCStatus,
            //                           CMID = b.CMID,
            //                           CMStatus = b.CMStatus,
            //                       }).ToList();

            return explanationList;
        }


        private string CheckIncidentStatus(int incidentId, string empNumber, string status)
        {
            if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && x.InvolvedId == empNumber).Any())
            {
                bool DeputyCount = uow.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && x.InvolvedId == empNumber && x.SergeantStatus != "Completed").Any();
                if (DeputyCount)
                    return "At Deputy";
                else
                    return ResolveStatus(Convert.ToInt16(status));
            }
            return "";
        }
        public List<IncidentEntity> GetIncident()
        {
            var incidentList = (from incident in uow.IncidentRepository.GetAll()
                                join address in uow.AddressRepository.GetAll() on incident.AddressId equals address.AddressId
                                join wf in uow.IncidentWorkflowRepository.GetAll() on incident.IncidentId equals wf.IncidentId
                                select new IncidentEntity
                                {
                                    IncidentId = incident.IncidentId,
                                    URN = incident.URN,
                                    IncidentCreateDate = incident.IncidentCreatedDate,
                                    ForceTypeId = incident.ForceTypeId,
                                    IncidentApprovalStatus = wf.SergeantStatus,
                                    IsDeleted = Convert.ToBoolean(incident.IsDeleted),
                                }).ToList();

            if (incidentList != null && incidentList.Any())
            {
                incidentList = incidentList.Where(a => !a.IsDeleted).ToList();
            }

            return incidentList;
        }


        public IncidentEntity GetIncident(int incidentId)
        {
            IncidentEntity incidentEntity = (from incident in uow.IncidentRepository.GetAll()
                                             //join address in uow.AddressRepository.GetAll() on incident.AddressId equals address.AddressId
                                             where incident.IncidentId == incidentId
                                             select new IncidentEntity
                                             {
                                                 IncidentId = incident.IncidentId,
                                                 URN = incident.URN,
                                                 AddressId = incident.AddressId,
                                                 //Address information
                                                 //AddressNumber = address.AddressNumber,
                                                 //Street = address.Street,
                                                 //SelectedCity = address.City,
                                                 //StationFacility = address.StationFacility,
                                                 //ZipCode = address.ZipCode,
                                                 //End
                                                 IncidentDate = incident.IncidentDate,
                                                 ContactTypeId = incident.ContactTypeId,
                                                 CustodyEventId = incident.CustodyEventId,
                                                 CTOthers = incident.CTOthers,
                                                 IsAdminInvestigation = incident.IsAdminInvestigation.Trim(),
                                                 IncidentCategoryId = incident.IncidentCategoryId,
                                                 ForceTypeId = incident.ForceTypeId,
                                                 IsDeptyInjury = incident.IsDeptyInjury.Trim(),
                                                 IsSuspectInjury = incident.IsSuspectInjury.Trim(),
                                                 IsUnderlyingArrest = incident.IsUnderlyingArrest.Trim(),
                                                 IsUnderlyingCrime = incident.IsUnderlyingCrime.Trim(),
                                                 IsOnK12Campus = incident.IsOnK12Campus.Trim(),
                                                 IsByFootPursuit = incident.IsByFootPursuit.Trim(),
                                                 IsByVehiclePursuit = incident.IsByVehiclePursuit.Trim(),
                                                 IsReactiveForce = incident.IsReactiveForce.Trim(),
                                                 IsPlannedForce = incident.IsPlannedForce.Trim(),
                                                 IsInmateInjuryReportWritten = incident.IsInmateInjuryReportWritten.Trim(),
                                                 IsMedicalStaffPresent = incident.IsMedicalStaffPresent.Trim(),
                                                 IsMentalHealthPresent = incident.IsMentalHealthPresent.Trim(),
                                                 IsSuperVisorPresent = incident.IsSuperVisorPresent.Trim(),
                                                 IsMedicalRecordChecked = incident.IsMedicalRecordChecked.Trim(),
                                                 IsExtractionOrderByMedical = incident.IsExtractionOrderByMedical.Trim(),
                                                 IsMentalHealthProfessional = incident.IsMentalHealthProfessional.Trim(),
                                                 IsDepartmentSignAdmonishmentAndNotedChangesInReport = incident.IsDepartmentSignAdmonishmentAndNotedChangesInReport.Trim(),
                                                 IsInvestigatorDirectedTheForce = incident.IsInvestigatorDirectedTheForce.Trim(),
                                                 IsInvestigatorParticipatedInTheForce = incident.IsInvestigatorParticipatedInTheForce.Trim(),
                                                 IsInvestigatorPlannedTheForce = incident.IsInvestigatorPlannedTheForce.Trim(),
                                                 IsDepartmentMembersSeparated = incident.IsDepartmentMembersSeparated.Trim(),
                                                 IsPPIReviewCompleted = incident.IsPPIReviewCompleted.Trim(),
                                                 EmpId = incident.SergeantId,
                                                 //PersonNotified = incident.Perceivedarmed.Trim(),
                                                 IsStaffEscortInvolvedInmates = incident.IsStaffEscortInvolvedInmates.Trim(),
                                                 //IsVideoInReport=incident.IsVideoInReport,
                                                 IsCCTVCoverage = incident.IsCCTVCoverage.Trim(),
                                                 IsVideoShooted = incident.IsVideoShooted.Trim(),
                                                 IsVideoOfIncident = incident.VideoofIncident,
                                                 IsIABNotified = incident.IsIABNotified.Trim(),
                                                 IABNotifiedUserId = incident.IABNotifiedUserId,
                                                 IsIABRollOut = incident.IsIABRollOut.Trim(),
                                                 IABRolloutEmployees = incident.IABRolloutEmployees,
                                                 IsIABHandling = incident.IsIABHandling.Trim(),
                                                 IABHandlingUserId = incident.IABHandlingUserId,
                                                 //IABHandlingFirstName=incident.IABHandlingFirstName,
                                                 //IABHandlingLastName=incident.IABHandlingLastName,
                                                 //IABHandlingRank=incident.IABHandlingRank,
                                                 IsCFRTNotified = incident.IsCFRTNotified.Trim(),
                                                 CFRTNotifiedUserId = incident.CFRTNotifiedUserId,
                                                 //CFRTNotifiedFirstName=incident.CFRTNotifiedFirstName,
                                                 //CFRTNotifiedLastName=incident.CFRTNotifiedLastName,
                                                 //CFRTNotifiedRank=incident.CFRTNotifiedRank,
                                                 IsCFRTHandling = incident.IsCFRTHandling.Trim(),
                                                 CFRTHandlingUserId = incident.CFRTHandlingUserId,
                                                 IsCFRTRollOut = incident.IsCFRTRollOut.Trim(),
                                                 CFRTRolloutEmployees = incident.CFRTRolloutEmployees,
                                                 IncidentLocationName = incident.IncidentLocationName,
                                                 LevelofResistance = incident.LevelofResistance,
                                                 //IsResultedInArrest=incident.IsResultedInArrest,
                                                 //IsResultedInCrimeReport=incident.IsResultedInCrimeReport,
                                                 ForceLocation = incident.Location,
                                                 IncidentApprovalStatus = incident.IncidentApprovalStatus,
                                                 IncidentCreateDate = incident.IncidentCreatedDate,
                                                 Assulative = incident.Assulative,
                                                 Lifethreatening = incident.Lifethreatening,

                                                 ExtractionEmpId = incident.ExtractionEmpId,
                                                 MentalHealthEmpId = incident.MentalHealthEmpId,
                                                 CCTVNoReason = incident.CCTVNoReason,
                                                 CCTVExtracted = incident.IsCCTVExtracted,
                                                 VideoShootedNoReason = incident.VideoShootedNoReason,
                                                 //Bureau = incident.Bureau,
                                                 Station = incident.Station,
                                                 //Facility = incident.Facility,
                                                 Staging = incident.Staging,
                                                 PPINo = incident.PPINo,
                                                 eLOTS = incident.ELots,
                                                 PRReason = incident.PRReason,
                                                 SupervisorDirectedId = incident.InvestigatorDirectedId,
                                                 elotsYN = incident.ElotsYN,
                                                 elotsNoReason = incident.ElotsNoReason,
                                                 ReferenceNo = incident.ReferenceNo,
                                                 MHS = incident.MHS,
                                                 MHSReason = incident.MHSReason,
                                                 PFData = incident.PFData,
                                                 MedicalLife = incident.MedicalLife,
                                                 MedRcdPrior = incident.MedRcdPrior,
                                                 PlanAltered = incident.PlanAltered,
                                                 BusinessName = incident.IncidentName
                                             }).FirstOrDefault();
            if (incidentEntity != null)
            {
                var Invst = uow.InvestigationOfficerRespository.GetAll().Where(x => x.IncidentId == incidentId && x.Status == "Active").FirstOrDefault();
                if (Invst != null)
                {
                    var dbModel = uow.ReviewRespository.GetAll().Where(x => x.FormId == (int)Constants.UOFForms.SupervisoryReport && x.InvolvedId == Invst.EmployeeId && x.IncidentID == incidentId).FirstOrDefault();
                    if (dbModel != null)
                    {
                        if (dbModel.WCStatus == Constants.Status.Completed.ToString() || dbModel.UCStatus == Constants.Status.Completed.ToString())
                            incidentEntity.isSRApproved = true;
                    }
                }

                //var business = (uow.IncidentBusinessRespository.GetAll().Where(x => x.IncidentID == incidentEntity.IncidentId)).FirstOrDefault();
                //if (business != null)
                //{
                //    incidentEntity.BusinessName = business.Name;
                //    incidentEntity.BusinessZipCode = business.Zip;
                //    incidentEntity.BusinessCity = business.City;
                //    incidentEntity.BusinessStreet = business.Street;
                //    incidentEntity.BusinessAddressNumber = business.AddressNumber;
                //}

                //List<AdditionalSergeantModel> AdditionalSergeant = (from Serg in uow.IncidentSergeantRepository.GetAll() where incidentEntity.IncidentId == Serg.IncidentId && Serg.SergeantType == "A" select new AdditionalSergeantModel { AddlSergeantId = Serg.AddlSergeantId, EmployeeNumber = Serg.EmployeeNumber, Name = Serg.Name }).ToList();
                //incidentEntity.AdditionalSergeant = AdditionalSergeant;

                //TODO Fill Address Entity
                AddressEntity addr = (from fr in uow.AddressRepository.GetAll()
                                      where incidentEntity.AddressId == fr.AddressId && fr.IncidentId == incidentEntity.IncidentId

                                      select new AddressEntity
                                      {
                                          AddressId = fr.AddressId,
                                          AddressNumber = fr.AddressNumber,
                                          Street = fr.Street,
                                          State = fr.State,
                                          StationFacility = fr.StationFacility,
                                          City = fr.City,
                                          ZipCode = fr.ZipCode
                                      }).FirstOrDefault();
                if (addr != null)
                {
                    incidentEntity.AddressNumber = addr.AddressNumber;
                    incidentEntity.AddressId = addr.AddressId;
                    incidentEntity.Street = addr.Street;
                    incidentEntity.State = addr.State;
                    incidentEntity.ZipCode = addr.ZipCode;
                    incidentEntity.SelectedCity = addr.City;
                }

            }


            return incidentEntity;
        }

        public AssignForm GetIncidentFormAssignInfo(int incidentId)
        {
            List<Assignment> Assignments = new List<Assignment>();
            AssignForm asnForm = (from IR in uow.IncidentRepository.GetAll()
                                  where IR.IncidentId == incidentId
                                  select new AssignForm
                                  {
                                      IncidentId = IR.IncidentId,
                                      Date = IR.IncidentDate,
                                      URN = IR.URN,
                                  }).FirstOrDefault();
            if (asnForm != null)
            {
                //This gets the user details
                var asn = (from IR in uow.IncidentRepository.GetAll()
                           join IUR in uow.IncidentUserRepository.GetAll() on IR.IncidentId equals IUR.IncidentId
                           join UR in uow.UserRepository.GetAll() on IUR.UserId equals UR.UserId
                           join UDR in uow.UserDetailRepository.GetAll() on UR.UserDetailId equals UDR.UserDetailId
                           where IR.IncidentId == incidentId && (UR.UserTypeId == 1 || UR.UserTypeId == 11 || UR.UserTypeId == 3) && UR.Active == true
                           select new Assignment
                           {
                               EmployeeId = UR.ForceEmployeeId,
                               FirstName = UDR.FirstName,
                               LastName = UDR.LastName,
                               Rank = UDR.Rank,
                               MailId = UDR.EmailId,
                               IncidentId = IR.IncidentId,
                               InvolvedEmployee = (UR.UserTypeId == (int)Constants.UserType.InvolvedEmployee ? true : false),
                               EmployeeWitness = (UR.UserTypeId == (int)Constants.UserType.EmployeeWitness ? true : false)
                           }).Distinct().ToList();

                //var asn = (from IR in uow.IncidentRepository.GetAll()
                //           join IUR in uow.IncidentUserRepository.GetAll() on IR.IncidentId equals IUR.IncidentId
                //           join UR in uow.UserRepository.GetAll() on IUR.UserId equals UR.UserId
                //           join UDR in uow.UserDetailRepository.GetAll() on UR.UserDetailId equals UDR.UserDetailId
                //           join IUI in uow.IncidentUserInvolvedRepository.GetAll() on IUR.IncidentUserId equals IUI.IncidentUserId
                //           where IR.IncidentId == incidentId
                //           select new Assignment
                //           {
                //               EmployeeId = UR.ForceEmployeeId,
                //               FirstName = UDR.FirstName,
                //               LastName = UDR.LastName,
                //               Rank = UDR.Rank,
                //               MailId = UDR.EmailId,
                //               IncidentId = IR.IncidentId,
                //               InvolvedEmployee = IUI.IncidentUserInvolvedId > 0 ? true : false,
                //           }).ToList();



                // asn.FormIds = string.Join(",",uow.ReviewRespository.GetAll().Where(a => a.IncidentID == incidentId).Select(x=>x.FormId));
                // var lst = new List<Assignment>();
                var id = 0;
                foreach (var item in asn)
                {
                    item.ID = id;

                    item.FormIds = string.Join(",", uow.ReviewRespository.GetAll().Where(a => a.IncidentID == item.IncidentId && a.InvolvedId == item.EmployeeId && a.InvolvedStatus != Constants.Status.Deleted.ToString() && a.FormId != (int)Constants.UOFForms.SupervisoryReport).Select(x => x.FormId).Distinct());
                    //item.FormIds = Convert.ToString((from ind in uow.ReviewRespository.GetAll() where ind.IncidentID == item.IncidentId && ind.InvolvedId == item.EmployeeId && ind.InvolvedStatus != Constants.Status.Deleted.ToString() select new { ind.FormId }).Single().FormId);

                    id++;
                }
                foreach (var item in asn)
                {
                    if (!string.IsNullOrEmpty(item.FormIds))
                    {
                        string[] fids = item.FormIds.Split(',');
                        if (fids.Length > 0)
                        {
                            for (int i = 0; i < fids.Length; i++)
                            {
                                //foreach (string ite1 in fids)
                                //{
                                int fid = Convert.ToInt32(fids[i]);
                                item.instanceCnt = uow.ReviewRespository.GetAll().Where(a => a.IncidentID == item.IncidentId && a.InvolvedId == item.EmployeeId && a.FormId == fid && a.InvolvedStatus != Constants.Status.Deleted.ToString()).Count();
                                Assignment assignment = new Assignment();
                                assignment.EmployeeId = item.EmployeeId;
                                assignment.FirstName = item.FirstName;
                                assignment.LastName = item.LastName;
                                assignment.Rank = item.Rank;
                                assignment.MailId = item.MailId;
                                assignment.IncidentId = item.IncidentId;
                                assignment.InvolvedEmployee = item.InvolvedEmployee;
                                assignment.EmployeeWitness = item.EmployeeWitness;
                                assignment.instanceCnt = item.instanceCnt;
                                assignment.FormIds = fids[i];
                                Assignments.Add(assignment);
                                //}
                            }
                        }
                    }
                }
                asnForm.Assignment = Assignments;
            }

            return asnForm;
        }

        public UoFModel GetIncidentData(int incidentId, string userId)
        {
            UoFModel model = new UoFModel();
            model.UserDetails = new UserModel();
            try
            {
                model.IncidentDetails = (from incident in uow.IncidentRepository.GetAll()
                                         where incident.IncidentId == incidentId
                                         select new IncidentEntity
                                         {
                                             IncidentId = incident.IncidentId,
                                             URN = incident.URN,
                                             IncidentDate = incident.IncidentDate,
                                             IncidentCategoryId = incident.IncidentCategoryId,
                                             ForceTypeId = incident.ForceTypeId,
                                             IsIABNotified = incident.IsIABNotified,
                                             ReferenceNo = incident.ReferenceNo,
                                             IncidentName = incident.IncidentLocationName,
                                             Station = incident.Station,
                                             eLOTS = incident.ELots,
                                             ForceLocation = incident.Location,
                                         }).FirstOrDefault();

                #region Getting Incident Related User like WC, ONDuty,Supervisor
                var usrEntity = (from incidentUser in uow.IncidentUserRepository.GetAll()
                                 join user in uow.UserRepository.GetAll() on incidentUser.UserId equals user.UserId
                                 join userDet in uow.UserDetailRepository.GetAll() on user.UserDetailId equals userDet.UserDetailId
                                 where incidentUser.IncidentId == incidentId
                                 select new IncidentUserEntity
                                 {
                                     UserId = user.UserId,
                                     UserTypeId = user.UserTypeId,
                                     ForceEmployeeId = user.ForceEmployeeId,
                                     FirstName = userDet.FirstName,
                                     LastName = userDet.LastName
                                 }).ToList();
                if (usrEntity != null)
                {
                    foreach (var item in usrEntity)
                    {
                        string name = item.LastName + " " + item.FirstName;
                        switch (item.UserTypeId)
                        {

                            case 8:
                                model.OnDutySupervisor = item.ForceEmployeeId + "-" + name;
                                break;
                            case 9:
                                model.InvestSupervisor = item.ForceEmployeeId + "-" + name;
                                break;
                            case 5:
                                model.WC = item.ForceEmployeeId + "-" + name;
                                break;
                        }
                    }
                }
                #endregion
                #region Checking the Delete Permission
                if (!string.IsNullOrWhiteSpace(model.InvestSupervisor))
                {
                    string[] InvestInfo = model.InvestSupervisor.Split('-');
                    if (InvestInfo.Length == 2)
                    {
                        if (InvestInfo[0] == userId)
                            model.isDeletePermission = true;
                        else
                        {
                            if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && x.SergeantId == userId && (x.InvolvedStatus == Constants.Status.DON.ToString() || x.InvolvedStatus == Constants.Status.Completed.ToString())).Any())
                                model.isDeletePermission = false;
                            else
                                model.isDeletePermission = true;
                        }
                    }
                }
                else
                {
                    if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && x.SergeantId == userId && (x.InvolvedStatus == Constants.Status.DON.ToString() || x.InvolvedStatus == Constants.Status.Completed.ToString())).Any())
                        model.isDeletePermission = false;
                    else
                        model.isDeletePermission = true;
                }
                #endregion



                #region Checking the whether the logged in user involved in the Incident Commented by ~M on 12th Mar
                //                if (uow.IncidentSergeantRepository.GetAll().Where(x => x.EmployeeNumber == userId && x.IncidentId == incidentId).Any())
                //                {
                //                    model.UserDetails.UoFUserRole = "Sergeant";
                //                    string sergeantID = (from ind in uow.IncidentRepository.GetAll() where ind.IncidentId == incidentId select new { ind.SergeantId }).Single().SergeantId;
                //                    if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && x.InvolvedId == sergeantID).Any())
                //                    {
                //                        model.UserAccess = (from access in uow.ReviewRespository.GetAll()
                //                                            where access.IncidentID == incidentId && access.InvolvedId == sergeantID
                //                                            select new UserAccess
                //                                            {
                //                                                FormId = access.FormId,
                //                                                IncidentId = access.IncidentID,
                //                                                isFormEntered = (access.InvolvedStatus == "DON" ? true : false)
                //                                            }).ToList();
                //                    }
                //                }
                //                else
                //                {

                //                    var entity = (from incidentUser in uow.IncidentUserRepository.GetAll()
                //                                  join user in uow.UserRepository.GetAll() on incidentUser.UserId equals user.UserId
                //                                  where incidentUser.IncidentId == incidentId && user.ForceEmployeeId == userId
                //                                  select new IncidentUserEntity
                //                                  {
                //                                      UserId = user.UserId,
                //                                      UserTypeId = user.UserTypeId
                //                                  }
                //                                      ).FirstOrDefault();

                //                    if (entity == null)
                //                    {
                //                        if (uow.IncidentRepository.GetAll().Where(x => x.SergeantId == userId && x.IncidentId == incidentId).Any())
                //                        {
                //                            model.UserDetails.UoFUserRole = "Sergeant";
                //                            if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && x.InvolvedId == userId).Any())
                //                            {
                //                                model.UserAccess = (from access in uow.ReviewRespository.GetAll()
                //                                                    where access.IncidentID == incidentId && access.InvolvedId == userId
                //                                                    select new UserAccess
                //                                                    {
                //                                                        FormId = access.FormId,
                //                                                        IncidentId = access.IncidentID,
                //                                                        isFormEntered = (access.InvolvedStatus == "DON" ? true : false)
                //                                                    }).ToList();
                //                            }
                //                        }
                //                    }
                //                    else
                //                    {
                //                        //int UserType = (from incidentUser in uow.IncidentUserRepository.GetAll()
                //                        //                join user in uow.UserRepository.GetAll() on incidentUser.UserId equals user.UserId
                //                        //                where incidentUser.IncidentId == incidentId && user.ForceEmployeeId == userId
                //                        //                select new { user.UserTypeId }).Single().UserTypeId;

                //                        switch (entity.UserTypeId)
                //                        {
                //                            case 1:
                //                                model.UserDetails.UoFUserRole = Constants.UserType.InvolvedEmployee.ToString();
                //                                if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && x.InvolvedId == userId).Any())
                //                                {
                //                                    model.UserAccess = (from access in uow.ReviewRespository.GetAll()
                //                                                        where access.IncidentID == incidentId && access.InvolvedId == userId
                //                                                        select new UserAccess
                //                                                        {
                //                                                            FormId = access.FormId,
                //                                                            IncidentId = access.IncidentID,
                //                                                            isFormEntered = (access.InvolvedStatus == "DON" ? true : false)
                //                                                        }).ToList();
                //                                }
                //                                break;
                //                            case 3:
                //                                model.UserDetails.UoFUserRole = Constants.UserType.EmployeeWitness.ToString();
                //                                break;
                //                            case 4:
                //                                model.UserDetails.UoFUserRole = Constants.UserType.NonEmpWitness.ToString();
                //                                break;
                //                            case 5:
                //                                model.UserDetails.UoFUserRole = Constants.UserType.WatchCommander.ToString();
                //                                if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && x.InvolvedId == userId).Any())
                //                                {
                //                                    model.UserAccess = (from access in uow.ReviewRespository.GetAll()
                //                                                        where access.IncidentID == incidentId && access.InvolvedId == userId
                //                                                        select new UserAccess
                //                                                        {
                //                                                            FormId = access.FormId,
                //                                                            IncidentId = access.IncidentID,
                //                                                            isFormEntered = (access.InvolvedStatus == "DON" ? true : false)
                //                                                        }).ToList();
                //                                }
                //                                break;
                //                            case 6:
                //                                model.UserDetails.UoFUserRole = Constants.UserType.UnitCommander.ToString();
                //                                if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && x.InvolvedId == userId).Any())
                //                                {
                //                                    model.UserAccess = (from access in uow.ReviewRespository.GetAll()
                //                                                        where access.IncidentID == incidentId && access.InvolvedId == userId
                //                                                        select new UserAccess
                //                                                        {
                //                                                            FormId = access.FormId,
                //                                                            IncidentId = access.IncidentID,
                //                                                            isFormEntered = (access.InvolvedStatus == "DON" ? true : false)
                //                                                        }).ToList();
                //                                }
                //                                break;
                //                            case 7:
                //                                model.UserDetails.UoFUserRole = Constants.UserType.Commander.ToString();
                //                                if (uow.ReviewRespository.GetAll().Where(x => x.IncidentID == incidentId && x.InvolvedId == userId).Any())
                //                                {
                //                                    model.UserAccess = (from access in uow.ReviewRespository.GetAll()
                //                                                        where access.IncidentID == incidentId && access.InvolvedId == userId
                //                                                        select new UserAccess
                //                                                        {
                //                                                            FormId = access.FormId,
                //                                                            IncidentId = access.IncidentID,
                //                                                            isFormEntered = (access.InvolvedStatus == "DON" ? true : false)
                //                                                        }).ToList();
                //                                }
                //                                break;
                //                        }
                //                    }

                //                }
                #endregion
            }
            catch
            {

            }



            return model;
        }
        public int GetNotifications(string userRole, string userId)
        {
            int Cnt = 0;
            if (uow.ReviewRespository.GetAll().Where(x => x.InvolvedRole == userRole).Any())
            {
                Cnt = uow.ReviewRespository.GetAll().Where(a => a.InvolvedRole == userRole && a.InvolvedId == userId && a.InvolvedStatus == Constants.Status.PND.ToString()).Count();
            }
            return Cnt;
        }
        public bool VerifyCatFormsStatus(int incidentId, int formID)
        {
            bool isCompleted = true;
            if (uow.CategoryFormRepository.GetAll().Where(x => x.IncidentID == incidentId && x.FormID == formID).Any())
            {
                isCompleted = uow.CategoryFormRepository.GetAll().Where(a => a.IncidentID == incidentId && a.FormID == formID && a.Status == Constants.Status.DON.ToString()).Any();
            }
            return isCompleted;
        }
        public int VerifyURN(string URN)
        {
            int retValue = 0;
            if (uow.IncidentRepository.GetAll().Where(x => x.URN == URN).Any())
            {
                retValue = (from ind in uow.IncidentRepository.GetAll()
                            where ind.URN == URN
                            select new { ind.IncidentId }).Single().IncidentId;
            }
            return retValue;
        }

        public bool CheckDuplicateURN(string URN, int incidentId)
        {
            bool exist = incidentId == 0 ? uow.IncidentRepository.GetAll().Where(x => x.URN == URN).Any()
                : uow.IncidentRepository.GetAll().Where(x => x.URN == URN && x.IncidentId != incidentId).Any();

            return exist;
        }

        /// <summary>
        /// This method will delete the incident record
        /// </summary>
        /// <param name="incidentId"></param>
        /// <returns>true or false</returns>
        public bool DeleteIncident(int incidentId)
        {
            var deleteRecord = uow.IncidentRepository.FindBy(a => a.IncidentId == incidentId);
            if (deleteRecord.Any())
            {
                var dRecord = deleteRecord.FirstOrDefault();
                dRecord.IsDeleted = true;
                uow.IncidentRepository.Update(dRecord);
                uow.Commit();
            }
            return true;
        }
        //DeleteIncidentForm(ReviewId)
        /// <summary>
        /// This method will delete the incidentform review  record
        /// </summary>
        /// <param name="ReviewId"></param>
        /// <returns>true or false</returns>
        public bool DeleteIncidentForm(int ReviewId)
        {
            var deleteRecord = uow.ReviewRespository.FindBy(a => a.IncidentReviewID == ReviewId);
            if (deleteRecord.Any())
            {
                var dRecord = deleteRecord.FirstOrDefault();
                if (dRecord.FormDataID > 0)
                {
                    var formRecord = uow.UOFIncidentFormDataRepository.FindBy(a => a.FormDataID == dRecord.FormDataID).FirstOrDefault();
                    if (formRecord != null)
                    {

                        formRecord.Status = Constants.Status.Deleted.ToString();
                        uow.UOFIncidentFormDataRepository.Update(formRecord);
                        uow.Commit();
                        return true;
                    }
                    dRecord.InvolvedStatus = Constants.Status.Deleted.ToString();
                    uow.ReviewRespository.Update(dRecord);
                    uow.Commit();
                    return true;
                }
                else
                {
                    dRecord.InvolvedStatus = Constants.Status.Deleted.ToString();
                    uow.ReviewRespository.Update(dRecord);
                    uow.Commit();
                    return true;
                }
            }

            return false;
        }

        private void SendEmailNotification(Assignment entity, AssignForm assignedEntity, List<LookupEntity> lookupEntity)
        {
            #region Email Notification

            Task.Run(() =>
            {
                try
                {
                    EmailRepository email = new EmailRepository();
                    email.EmailNotification(new EmailNotificationModel
                    {
                        Department = "Assign",
                        EmailId = entity.MailId,
                        IncidentId = Convert.ToInt32(assignedEntity.IncidentId),
                        EmployeeNumber = entity.EmployeeId,
                        AssignedForms = lookupEntity,
                    });
                }
                catch (Exception ex)
                {
                    LogService.CustomError(ex, "SendEmailNotification", ex.Source, ex.StackTrace);
                }
            });

            #endregion
        }

        public bool IncidentSubmit(int incidentId, string sergeantId)
        {
            try
            {
                SaveIncidentWF(incidentId, sergeantId);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }

        private void SaveIncidentWF(int incidentId, string sergeantId)
        {
            FormReviewRespository repo = new FormReviewRespository();
            int IncidentReviewId = 0;
            try
            {
                #region Insert Incident Review Forms
                //IncidentReviewId = (from ind in uow.ReviewRespository.GetAll()
                //                    where ind.IncidentID == incidentId && ind.FormId == (int)Constants.UOFForms.SupervisoryReport
                //                    select new { ind.IncidentReviewID }).Single().IncidentReviewID;
                repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                {
                    FormDataId = 0,
                    IncidentReviewID = IncidentReviewId,
                    IncidentID = incidentId,
                    SubmittedEmpId = sergeantId,
                    SergeantId = sergeantId,
                    FormId = (int)Constants.UOFForms.SupervisoryReport,
                    SubmitteduserRole = Constants.UserRoles.SGT.ToString(),
                    ReviewerRole = Constants.UserRoles.WC.ToString(),
                    SergeantStatus = Constants.Status.Completed.ToString(),
                    WCStatus = Constants.Status.Pending.ToString(),
                    SubmittedStatus = Constants.Status.Completed.ToString(),
                });
                #endregion
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        private void SaveIncidentRank(int incidentId)
        {
            try
            {
                if (!uow.IncidentRankRespository.GetAll().Where(x => x.IncidentId == incidentId).Any())
                {
                    var rank = new IncidentRank();
                    rank.IncidentId = incidentId;
                    rank.Rank = 1;
                    uow.IncidentRankRespository.Add(rank);
                    uow.Commit();

                }

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
