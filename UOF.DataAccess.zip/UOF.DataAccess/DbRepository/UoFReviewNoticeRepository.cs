﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using UOF.Common.EntityModel;
using UOF.Common.Utilities;
using UOF.DataAccess.Repository;

namespace UOF.DataAccess.DbRepository
{
    public class UoFReviewNoticeRepository
    {
        UnitOfWork uow = new UnitOfWork();
        FormReviewRespository repo = new FormReviewRespository();

        public bool SaveUOFReviewNotice_Old(UOFReviewNoticeBusinessModel reviewNoticeModel)
        {
            bool result = false;
            reviewNoticeModel.UserRoleId = (int)Constants.UserRoles.SGT;
            reviewNoticeModel.UserRoleId = repo.GetUserRoleID(reviewNoticeModel.UserRole);
            try
            {
                var reviewModel = new UOFReviewNoticeBusinessModel();
                var reviewNotice = uow.UOFIncidentFormDataRepository.FindBy(a => a.UserRoleId == reviewNoticeModel.UserRoleId && a.FormID == reviewNoticeModel.FormID && a.IncidentID == reviewNoticeModel.IncidentID && a.EmpID == reviewNoticeModel.EmpId).FirstOrDefault();
                if (reviewNotice != null)
                {
                    reviewNotice.IncidentID = reviewNoticeModel.IncidentID;
                    reviewNotice.UpdateBy = reviewNoticeModel.EmpId;
                    reviewNotice.UpdateOn = DateTime.Now;
                    reviewNotice.Status = Constants.Status.DON.ToString();
                    reviewNotice.XmlData = reviewNoticeModel.Serialize();
                    uow.UOFIncidentFormDataRepository.Update(reviewNotice);
                }
                else
                {
                    var review = new IncidentFormData();
                    review.IncidentID = reviewNoticeModel.IncidentID;
                    review.EmpID = reviewNoticeModel.EmpId;
                    review.CreatedOn = DateTime.Now;
                    review.CreatedBy = reviewNoticeModel.EmpId;
                    review.FormID = reviewNoticeModel.FormID;
                    review.UserRoleId = reviewNoticeModel.UserRoleId;
                    review.XmlData = reviewNoticeModel.Serialize();
                    review.Status = Constants.Status.DON.ToString();
                    uow.UOFIncidentFormDataRepository.Add(review);

                }
                #region Update Incident Review Forms
                string sergeantID = (from ind in uow.IncidentRepository.GetAll()
                                     where ind.IncidentId == reviewNoticeModel.IncidentID
                                     select new { ind.SergeantId }).Single().SergeantId;

                string reviewerRole = string.Empty;
                string status = string.Empty;
                switch (reviewNoticeModel.UserRole.ToUpper())
                {
                    case "DSG":
                        reviewerRole = Constants.UserRoles.SGT.ToString();
                        break;
                    case "SGT":
                        reviewerRole = Constants.UserRoles.WC.ToString();
                        break;
                    case "WC":
                        reviewerRole = Constants.UserRoles.CAPT.ToString();
                        break;
                    case "CAPT":
                        reviewerRole = Constants.UserRoles.CMDR.ToString();
                        break;
                    default:
                        break;
                }
                string Id = string.Empty;
                IncidentFormReviewEntity obj = new IncidentFormReviewEntity();
                obj.IncidentID = reviewNoticeModel.IncidentID;
                obj.SubmittedEmpId = reviewNoticeModel.EmpId;
                obj.FormId = reviewNoticeModel.FormID;
                obj.SubmitteduserRole = reviewNoticeModel.UserRole;
                obj.ReviewerRole = reviewerRole;
                if (reviewNoticeModel.UserRole == Constants.UserRoles.SGT.ToString())
                {
                    //Id = (from ind in uow.IncidentWorkflowRepository.GetAll()
                    //      where ind.IncidentId == reviewNoticeModel.IncidentID
                    //      select new { ind.SergeantID }).Single().SergeantID;
                    //if (!string.IsNullOrEmpty(Id))
                    //    obj.SergeantId = Id;

                    obj.SergeantStatus = Constants.Status.Completed.ToString();
                    obj.WCStatus = Constants.Status.Pending.ToString();
                    obj.SubmittedStatus = Constants.Status.Completed.ToString();
                    repo.InsertUpdateReviewForm(obj); ;
                    uow.Commit();
                    using (UoFWorkFlowRepository wfobj = new UoFWorkFlowRepository())
                    {
                        wfobj.UpdateSergeantStatus(new ReviewEntity { IncidentId = reviewNoticeModel.IncidentID });
                    }


                }
                if (reviewNoticeModel.UserRole == Constants.UserRoles.WC.ToString())
                {

                    //Id = (from ind in uow.IncidentWorkflowRepository.GetAll()
                    //      where ind.IncidentId == reviewNoticeModel.IncidentID
                    //      select new { ind.WCID }).Single().WCID;
                    //if (!string.IsNullOrEmpty(Id))
                    //    obj.WCID = Id;

                    obj.WCStatus = Constants.Status.Completed.ToString();
                    obj.UCStatus = Constants.Status.Pending.ToString();
                    obj.SubmittedStatus = Constants.Status.Completed.ToString();
                    repo.InsertUpdateReviewForm(obj); ;
                    uow.Commit();
                    using (UoFWorkFlowRepository wfobj = new UoFWorkFlowRepository())
                    {
                        wfobj.UpdateWCStatus(new ReviewEntity { IncidentId = reviewNoticeModel.IncidentID, LoggedId = reviewNoticeModel.EmpId });
                    }

                }
                if (reviewNoticeModel.UserRole == Constants.UserRoles.CAPT.ToString())
                {
                    //Id = (from ind in uow.IncidentWorkflowRepository.GetAll()
                    //      where ind.IncidentId == reviewNoticeModel.IncidentID
                    //      select new { ind.UCID }).Single().UCID;
                    //if (!string.IsNullOrEmpty(Id))
                    //    obj.UCID = Id;

                    obj.UCStatus = Constants.Status.Completed.ToString();
                    obj.CMStatus = Constants.Status.Pending.ToString();
                    obj.SubmittedStatus = Constants.Status.Completed.ToString();
                    repo.InsertUpdateReviewForm(obj); ;
                    uow.Commit();
                    using (UoFWorkFlowRepository wfobj = new UoFWorkFlowRepository())
                    {
                        wfobj.UpdateUCStatus(new ReviewEntity { IncidentId = reviewNoticeModel.IncidentID, LoggedId = reviewNoticeModel.EmpId });
                    }
                }
                if (reviewNoticeModel.UserRole == Constants.UserRoles.CMDR.ToString())
                {
                    //Id = (from ind in uow.IncidentWorkflowRepository.GetAll()
                    //      where ind.IncidentId == reviewNoticeModel.IncidentID
                    //      select new { ind.CMID }).Single().CMID;
                    //if (!string.IsNullOrEmpty(Id))
                    //    obj.CMID = Id;

                    obj.CMStatus = Constants.Status.Completed.ToString();
                    obj.SubmittedStatus = Constants.Status.Completed.ToString();
                    repo.InsertUpdateReviewForm(obj); ;
                    uow.Commit();
                    using (UoFWorkFlowRepository wfobj = new UoFWorkFlowRepository())
                    {
                        wfobj.UpdateCMStatus(new ReviewEntity { IncidentId = reviewNoticeModel.IncidentID, LoggedId = reviewNoticeModel.EmpId });
                    }

                }

                Id = string.Empty;
                #endregion
                result = true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return result;
        }


        public bool SaveUOFReviewNotice(UOFReviewNoticeBusinessModel reviewNoticeModel)
        {
            bool result = false;
           
                List<LookupEntity> AssignedForms = new List<LookupEntity>();
            reviewNoticeModel.UserRoleId = repo.GetUserRoleID(reviewNoticeModel.UserRole);
                try
                {
                using (var transaction = new TransactionScope())
                {
                    var reviewModel = new UOFReviewNoticeBusinessModel();
                    var review = new IncidentFormData();
                    review.IncidentID = reviewNoticeModel.IncidentID;
                    review.EmpID = reviewNoticeModel.EmpId;
                    review.CreatedOn = DateTime.Now;
                    //review.CreatedBy = reviewNoticeModel.UserRoleId;
                    review.FormID = reviewNoticeModel.FormID;
                    review.UserRoleId = reviewNoticeModel.UserRoleId;
                    review.XmlData = reviewNoticeModel.Serialize();
                    review.Status = Constants.Status.DON.ToString();
                    uow.UOFIncidentFormDataRepository.Add(review);
                    uow.Commit();
                    //}


                    #region Assigning the Deputy Memo or Supplemental Report
                    //int frmId = reviewNoticeModel.ReportingForm > 0 ? reviewNoticeModel.ReportingForm : reviewNoticeModel.FormID;

                    //var submittedInfo = (from ind in uow.UOFIncidentFormDataRepository.GetAll()
                    //                     where ind.IncidentID == reviewNoticeModel.IncidentID && ind.EmpID == reviewNoticeModel.ReportingEmployee && ind.FormID == frmId
                    //                     select ind).FirstOrDefault();

                    ////string sergeantID = (from ind in uow.IncidentRepository.GetAll()
                    ////                     where ind.IncidentId == reviewNoticeModel.IncidentID
                    ////                     select new { ind.SergeantId }).Single().SergeantId;

                    //IncidentWorkflow WfModel = uow.IncidentWorkflowRepository.GetAll().Where(x => x.IncidentId == reviewNoticeModel.IncidentID).FirstOrDefault();

                    //int formId = 0;

                    //if (reviewNoticeModel.ReportingForm == (int)Constants.UOFForms.IncidentReport)
                    //    formId = (int)Constants.UOFForms.DeputySupplementalReport;
                    //else
                    //    formId = (int)Constants.UOFForms.DeputysUseofForceMemorandum;

                    //string reviewerRole = string.Empty;
                    //string SubmitedRole = string.Empty;
                    //switch (submittedInfo.UserRoleId)
                    //{
                    //    case 1:
                    //        SubmitedRole = Constants.UserRoles.SGT.ToString();
                    //        break;
                    //    case 2:
                    //        SubmitedRole = Constants.UserRoles.DSG.ToString();
                    //        break;
                    //    case 4:
                    //        SubmitedRole = Constants.UserRoles.WC.ToString();
                    //        break;
                    //    case 5:
                    //        SubmitedRole = Constants.UserRoles.CAPT.ToString();
                    //        break;

                    //    default:
                    //        break;
                    //}

                    //repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                    //{
                    //    IncidentID = reviewNoticeModel.IncidentID,
                    //    SubmittedEmpId = reviewNoticeModel.ReportingEmployee,
                    //    FormId = formId,
                    //    SubmitteduserRole = SubmitedRole,
                    //    ReviewerRole = !reviewNoticeModel.IsOnlySave ? Constants.UserRoles.SGT.ToString() : "",
                    //    SergeantStatus = !reviewNoticeModel.IsOnlySave ? Constants.Status.NotReady.ToString() : "",
                    //    SubmittedStatus = !reviewNoticeModel.IsOnlySave ? Constants.Status.Pending.ToString() : "",
                    //    SergeantId = WfModel.SergeantID,
                    //    WCID = WfModel.WCID,
                    //    UCID = WfModel.UCID,
                    //    WCStatus = Constants.Status.NotReady.ToString(),
                    //    UCStatus = Constants.Status.NotReady.ToString(),
                    //    CMStatus = Constants.Status.NotReady.ToString(),
                    //});
                    //uow.Commit();
                    //int Id = uow.ReviewRespository.GetAll().OrderByDescending(x => x.IncidentReviewID).FirstOrDefault().IncidentReviewID;

                    //var obj = new IncidentFormExplaination();
                    //obj.IncidentReviewId = Id;
                    //obj.IncidentID = reviewNoticeModel.IncidentID;
                    //obj.ExplanedOnFormID = reviewNoticeModel.ReportingForm;
                    //obj.ExplanedFormID = formId;
                    //obj.RptId = reviewNoticeModel.ReportingEmployee;
                    //obj.RptStatus = Constants.Status.Pending.ToString();
                    //obj.CreatedBy = reviewNoticeModel.EmpId; //Logged In User ID
                    //obj.CreatedOn = DateTime.Now;
                    //uow.ExplainationReviewRespository.Add(obj);
                    //uow.Commit();

                    #endregion
                    //AssignedForms.Add(new LookupEntity { ID = formId, Name = Constants.GetFormName(formId) });
                    ///string expfName = Constants.GetFormName(reviewNoticeModel.ReportingForm);
                    #region Email Notification
                    EmailRepository email = new EmailRepository();
                    email.EmailNotification(new EmailNotificationModel
                    {
                        ToEmployeeId = reviewNoticeModel.ReportingEmployee,
                        Department = "Explanation",
                        IncidentId = Convert.ToInt32(reviewNoticeModel.IncidentID),
                        EmployeeNumber = reviewNoticeModel.ReportingEmployee,
                        AssignedForms = AssignedForms,
                        comments = reviewNoticeModel.MemoComments,
                        //ExplanationFormName = expfName
                    });
                    #endregion
                    transaction.Complete();
                }
                result = true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return result;
        }

       
        public UOFReviewNoticeBusinessModel GetReviewNotice(int FormId, int IncidentId, string EmpId)
        {

            try
            {
                var data = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.FormID == FormId && x.EmpID == EmpId && x.IncidentID == IncidentId).FirstOrDefault();
                var result = data != null ? data.XmlData.Deserialize<UOFReviewNoticeBusinessModel>() : null;
                if (result != null)
                {
                    using (ReturnCommentsRepository obj = new ReturnCommentsRepository())
                    {
                        result.RejectComments = obj.getReturnComments(new ReturnCommentModel { IncidentId = IncidentId, FormId = FormId, FormSubmitedId = EmpId });
                    }
                }
                return result;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
    }
}
