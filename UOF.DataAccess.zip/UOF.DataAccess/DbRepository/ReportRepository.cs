﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.DataAccess.Repository;
using UOF.Common.Utilities;
using UOF.Common.EntityModel;

namespace UOF.DataAccess.DbRepository
{
    public class ReportRepository
    {
        UnitOfWork uow = new UnitOfWork();

        public T GetReportModel<T>(int FormId = 0, int IncidentId = 0, string empId = "0") where T : class, new()
        {
            //string empId = "0";
            if (FormId == 0)
            {
                UserRepository UserReposit = new UserRepository();
                IncidentRepository IncReposit = new IncidentRepository();
                SupervisoryModel Supervisor = new SupervisoryModel(); 
                Supervisor.Incident = IncReposit.GetIncident(IncidentId);
                Supervisor.Involved = UserReposit.GetInvolvedUser(IncidentId);
                Supervisor.Suspects = UserReposit.GetSuspectUser(IncidentId);
                Supervisor.EmpWitness = UserReposit.GetWitnessUser(IncidentId, (int)Constants.UserType.EmployeeWitness);
                Supervisor.NonEmpWitness = UserReposit.GetWitnessUser(IncidentId, (int)Constants.UserType.NonEmpWitness);
                Supervisor.Dupties = UserReposit.GetincidentDupties(IncidentId);
                Supervisor.Canine = UserReposit.GetCanineInfo(IncidentId);
                List<StatisticalEntity> Statisticals = UserReposit.GetStaticalData(IncidentId);

                foreach (StatisticalEntity item in Statisticals)
                {
                    if(Supervisor.Involved.Where(a => a.EmployeeId == item.ForcedUsedAgainstId).Any())
                    {
                        item.ForcedUsedAgainstName = Supervisor.Involved.FirstOrDefault(a => a.EmployeeId == item.ForcedUsedAgainstId).Name;
                    }
                    else if(Supervisor.Suspects.Where(a => a.BookingNumber == item.ForcedUsedAgainstId).Any())
                    {
                        item.ForcedUsedAgainstName = Supervisor.Suspects.FirstOrDefault(a => a.BookingNumber == item.ForcedUsedAgainstId).Name;
                    }
                    if (Supervisor.Involved.Where(a => a.EmployeeId == item.ForcedUsedById).Any())
                    {
                        item.ForcedUsedByName = Supervisor.Involved.FirstOrDefault(a => a.EmployeeId == item.ForcedUsedById).Name;
                    }
                    else if (Supervisor.Suspects.Where(a => a.BookingNumber == item.ForcedUsedById).Any())
                    {
                        item.ForcedUsedByName = Supervisor.Suspects.FirstOrDefault(a => a.BookingNumber == item.ForcedUsedById).Name;
                    }
                }
                Supervisor.Statisticals = Statisticals;
                return (T)Convert.ChangeType(Supervisor, typeof(T));
            }
            else
            {
                //var resultQuery = uow.UOFIncidentFormDataRepository.GetAll().Where(a => a.IncidentID == IncidentId && a.FormID == FormId);
                //if (resultQuery.ToList<IncidentFormData>().Any())
                //    empId = resultQuery.FirstOrDefault<IncidentFormData>().EmpID;
                var data = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.FormID == FormId && x.EmpID == empId && x.IncidentID == IncidentId).FirstOrDefault();
                return data != null ? data.XmlData.Deserialize<T>() : null;
            }
        }

        public TrackingModel GetTrackingDetails(int FormId, int IncidentId)
        {
            try
            {
                var data = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.FormID == FormId && x.IncidentID == IncidentId).FirstOrDefault();
                var result = data != null ? data.XmlData.Deserialize<TrackingModel>() : null;
                if (result == null)
                {
                    TrackingModel model = new TrackingModel();
                    IncidentRepository IncReposit = new IncidentRepository();
                    var Incident = IncReposit.GetIncident(IncidentId);

                    switch (Incident.IncidentCategoryId)
                    {
                        case 1:
                            model.Cat1 = true;
                            break;
                        case 2:
                            model.Cat2 = true;
                            break;
                        case 3:
                            model.Cat3 = true;
                            break;
                    }
                    if (Incident.ForceTypeId.Contains("OC"))
                        model.ForceTypeIdOC = true;
                    else if (Incident.ForceTypeId.Contains("PK"))
                        model.ForceTypeIdPK = true;
                    else if (Incident.ForceTypeId.Contains("TR"))
                        model.ForceTypeIdTR = true;
                    else if (Incident.ForceTypeId.Contains("CT"))
                        model.ForceTypeIdCT = true;
                    else if (Incident.ForceTypeId.Contains("TT"))
                        model.ForceTypeIdTT = true;
                    else if (Incident.ForceTypeId.Contains("ST"))
                        model.ForceTypeIdST = true;
                    else if (Incident.ForceTypeId.Contains("CR"))
                        model.ForceTypeIdCR = true;
                    else if (Incident.ForceTypeId.Contains("FH"))
                        model.ForceTypeIdFH = true;

                    model.eLOTS = Incident.eLOTS;
                    model.FileNumber = Incident.URN;
                    model.ReferenceNumber = Incident.ReferenceNo;
                    model.IncidentDate = Incident.IncidentDate.ToShortDateString();
                    model.SubmittedtoCFRT = Incident.IsCFRTNotified == "Y" ? Incident.IncidentDate.ToShortDateString() : string.Empty;
                    var submiitedForms = uow.UOFIncidentFormDataRepository.GetAll().Where(a => a.IncidentID == IncidentId).ToList();
                    var ReviewForms = uow.ReviewRespository.GetAll().Where(a => a.IncidentID == IncidentId).ToList();

                    model.isSHR49Submitted = submiitedForms.Where(x => x.FormID == 16).Any();
                    model.isUOFMemoSubmitted = submiitedForms.Where(x => x.FormID == 20).Any();
                    model.isSuppRptSubmitted = submiitedForms.Where(x => x.FormID == 22).Any();
                    model.isInmateRptSubmitted = submiitedForms.Where(x => x.FormID == 19).Any();

                    model.isWCReviewSubmitted = submiitedForms.Where(x => x.FormID == 25).Any();
                    model.isUCReviewSubmitted = submiitedForms.Where(x => x.FormID == 26).Any();
                    model.isCMReviewSubmitted = submiitedForms.Where(x => x.FormID == 27).Any();
                    if (submiitedForms.Where(x => x.FormID == 25).Any())
                    {
                        model.isWCReviewDate = submiitedForms.FirstOrDefault(x => x.FormID == 25).CreatedOn.ToString();

                    }
                    if (submiitedForms.Where(x => x.FormID == 26).Any())
                    {
                        model.isUCReviewDate = submiitedForms.FirstOrDefault(x => x.FormID == 26).CreatedOn.ToString();

                    }
                    if (submiitedForms.Where(x => x.FormID == 27).Any())
                    {
                        model.isCMReviewDate = submiitedForms.FirstOrDefault(x => x.FormID == 27).CreatedOn.ToString();

                    }

                    result = model;
                }
                return result;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
    }
}
