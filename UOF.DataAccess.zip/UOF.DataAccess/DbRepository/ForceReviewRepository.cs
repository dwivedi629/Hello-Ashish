﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.Common.Utilities;
using UOF.DataAccess.Repository;

namespace UOF.DataAccess.DbRepository
{
    public class ForceReviewRepository
    {
        UnitOfWork uow = new UnitOfWork();

        public int SaveForceReview(OperationsForceReview reviewModel)
        {
            int result = 0;
            int FormDataId = 0;
            FormReviewRespository repo = new FormReviewRespository();
            reviewModel.UserRoleId = repo.GetUserRoleID(reviewModel.UserRole);
            try
            {
                var Model = new OperationsForceReview();
                var reviewNotice = uow.UOFIncidentFormDataRepository.FindBy(a => a.UserRoleId == reviewModel.UserRoleId && a.FormID == reviewModel.FormID && a.IncidentID == reviewModel.IncidentID && a.EmpID == reviewModel.EmpId && a.FormDataID == reviewModel.formDataId).FirstOrDefault();
                if (reviewNotice != null)
                {
                    reviewNotice.IncidentID = reviewModel.IncidentID;
                    reviewNotice.UpdateBy = reviewModel.EmpId;
                    reviewNotice.UpdateOn = DateTime.Now;
                    reviewNotice.XmlData = reviewModel.Serialize();
                    uow.UOFIncidentFormDataRepository.Update(reviewNotice);
                    result = reviewNotice.FormDataID;
                }
                else
                {
                    var review = new IncidentFormData();
                    review.IncidentID = reviewModel.IncidentID;
                    review.EmpID =  reviewModel.EmpId;
                    review.CreatedOn = DateTime.Now;
                    review.CreatedBy = reviewModel.EmpId;
                    review.FormID = reviewModel.FormID;
                    review.UserRoleId = reviewModel.UserRoleId;
                    review.XmlData = reviewModel.Serialize();
                    review.Status = Constants.Status.DON.ToString();
                    uow.UOFIncidentFormDataRepository.Add(review);
                    uow.Commit();
                    FormDataId = review.FormDataID;
                    result = FormDataId;
                    
                }
                #region Update Incident Review Forms
                string sergeantID = (from ind in uow.IncidentRepository.GetAll()
                                     where ind.IncidentId == reviewModel.IncidentID
                                     select new { ind.SergeantId }).Single().SergeantId;
                repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                {
                    FormDataId = FormDataId,
                    IncidentReviewID = reviewModel.IncidentReviewId,
                    IncidentID = reviewModel.IncidentID,
                    SubmittedEmpId = sergeantID,
                    FormId = reviewModel.FormID,
                    SubmitteduserRole = reviewModel.UserRole,
                    ReviewerRole = !reviewModel.IsOnlySave ? Constants.UserRoles.WC.ToString() : "",
                    SergeantStatus = !reviewModel.IsOnlySave ? Constants.Status.Completed.ToString() : "",
                    WCStatus = !reviewModel.IsOnlySave ? Constants.Status.Pending.ToString() : "",
                    SubmittedStatus = !reviewModel.IsOnlySave ? Constants.Status.Completed.ToString() : Constants.Status.Pending.ToString(),
                });
                #endregion
                uow.Commit();

            }
            catch (Exception ex)
            {

                throw ex;
            }
            return result;
        }

        public OperationsForceReview GetForceReview(ParameterCriteria cirteria)
        {

            try
            {
                IncidentFormData data = null;
                if (cirteria.report)
                    data = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.FormID == cirteria.formId && x.EmpID == cirteria.employeeId && x.IncidentID == cirteria.incidentId).FirstOrDefault();
                else
                    data = uow.UOFIncidentFormDataRepository.GetById(cirteria.formDataId);

                var result = data != null ? data.XmlData.Deserialize<OperationsForceReview>() : null;
                if (result != null)
                {
                    using (ReturnCommentsRepository obj = new ReturnCommentsRepository())
                    {
                        result.RejectComments = obj.getReturnComments(new ReturnCommentModel { IncidentId = cirteria.incidentId, FormId = cirteria.formId, FormSubmitedId = cirteria.employeeId, IncidentReviewID = cirteria.IncidentReviewId });
                    }
                }
                return result;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
    }
}
