﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.Common.Utilities;
using UOF.DataAccess.Repository;

namespace UOF.DataAccess.DbRepository
{
    public class CSRepository : ICSRepository
    {
        UnitOfWork uow = new UnitOfWork();

        public int SaveCSData(CSEntity model)
        {
            FormReviewRespository repo = new FormReviewRespository();
            int result = 0;
            int FormDataId = 0;
            model.FormID = (int)Constants.UOFForms.CustodyServicesDivisionCrimeAnalysisSupplemental;
            model.UserRoleId = repo.GetUserRoleID(model.UserRole);
            try
            {
                //var sup = new SupplementalModel();
                var csModel = uow.UOFIncidentFormDataRepository.FindBy(a => a.UserRoleId == model.UserRoleId && a.FormID == model.FormID && a.IncidentID == model.IncidentID && a.EmpID == model.EmpId && a.FormDataID == model.formDataId).FirstOrDefault();
                if (csModel != null)
                {
                    csModel.IncidentID = model.IncidentID;
                    csModel.XmlData = model.Serialize();
                    //string xml = model.Serialize();
                    csModel.UpdateBy = model.EmpId;
                    csModel.UpdateOn = DateTime.Now;
                    uow.UOFIncidentFormDataRepository.Update(csModel);
                    result = csModel.FormDataID;
                }
                else
                {
                    var uofCS = new IncidentFormData();
                    uofCS.IncidentID = model.IncidentID;
                    uofCS.EmpID = model.EmpId;
                    uofCS.CreatedOn = DateTime.Now;
                    uofCS.CreatedBy = model.EmpId;
                    uofCS.FormID = model.FormID;
                    uofCS.UserRoleId = model.UserRoleId;
                    uofCS.XmlData = model.Serialize();
                    uofCS.Status = Constants.Status.DON.ToString();
                    uow.UOFIncidentFormDataRepository.Add(uofCS);
                    uow.Commit();
                    FormDataId = uofCS.FormDataID;
                    result = uofCS.FormDataID;
                }
                uow.Commit();
                repo.InsertUpdateReviewForm(new IncidentFormReviewEntity
                {
                    FormDataId = FormDataId,
                    IncidentReviewID = model.IncidentReviewId,
                    IncidentID = model.IncidentID,
                    SubmittedEmpId = model.EmpId,
                    FormId = model.FormID,
                    SubmitteduserRole = model.UserRole,
                    ReviewerRole = !model.IsOnlySave ? Constants.UserRoles.SGT.ToString() : "",
                    SergeantStatus = !model.IsOnlySave ? Constants.Status.Pending.ToString() : "",
                    SubmittedStatus = !model.IsOnlySave ? Constants.Status.DON.ToString() : Constants.Status.Pending.ToString(),
                });

            }
            catch (Exception ex)
            {

                throw ex;
            }
            return result;
        }
        public CSEntity GetCSDetails(ParameterCriteria cirteria)
        {

            try
            {
                IncidentFormData data = null;
                if (cirteria.report)
                    data = uow.UOFIncidentFormDataRepository.GetAll().Where(x => x.FormID == cirteria.formId && x.EmpID == cirteria.employeeId && x.IncidentID == cirteria.incidentId).FirstOrDefault();
                else
                    data = uow.UOFIncidentFormDataRepository.GetById(cirteria.formDataId);

                var result = data != null ? data.XmlData.Deserialize<CSEntity>() : null;
                if (result != null)
                {
                    using (ReturnCommentsRepository obj = new ReturnCommentsRepository())
                    {
                        result.RejectComments = obj.getReturnComments(new ReturnCommentModel { IncidentId = cirteria.incidentId, FormId = cirteria.formId, FormSubmitedId = cirteria.employeeId, IncidentReviewID = cirteria.IncidentReviewId });
                    }
                }
                return result;
            }
            catch (Exception ex)
            {

                throw ex;

            }
        }
    }
}
