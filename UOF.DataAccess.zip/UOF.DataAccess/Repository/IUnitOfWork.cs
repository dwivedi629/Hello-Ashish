﻿//using UOF.DataAccess.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.DataAccess
{
    public interface IUnitOfWork
    {
        //Save pending changes to the data store.
        int Commit();
        //IRepositories
        IRepository<Addres> AddressRepository { get; }
        IRepository<AddressType> AddressTypeRepository { get; }
        IRepository<CFRT_RolledOut> CFRT_RolledOutRepository { get; }
        IRepository<ChargeCode> ChargeCodeRepository { get; }
        IRepository<ChargeCodeType> ChargeCodeTypeRepository { get; }
        IRepository<Contact> ContactRepository { get; }
        IRepository<ContactType> ContactTypeRepository { get; }
        IRepository<ForceOnSuspect> ForceOnSuspectRepository { get; }
        IRepository<Handler> HandlerRepository { get; }
        IRepository<Hospital> HospitalRepository { get; }
        IRepository<IAB_RolledOut> IAB_RolledOutRepository { get; }
        IRepository<Incident> IncidentRepository { get; }
        IRepository<IncidentCanineDeployment> IncidentCanineDeploymentRepository { get; }
        IRepository<IncidentUser> IncidentUserRepository { get; }
        IRepository<IncidentUserChargeCode> IncidentUserChargeCodeRepository { get; }
        IRepository<IncidentUserCopy> IncidentUserCopyRepository { get; }
        IRepository<ArtifactsInformation> ArtifactsInformationRepository { get; }
        IRepository<IncidentUserDirector> IncidentUserDirectorRepository { get; }
        IRepository<IncidentStatisticalData> IncidentStatisticalRepository { get; }
        IRepository<IncidentUserInterview> IncidentUserInterviewRepository { get; }
        IRepository<IncidentUserSuspect> IncidentUserSuspectRepository { get; }
        IRepository<IncidentUserWitnes> IncidentUserWitnessRepository { get; }
        IRepository<Treatment> TreatmentRepository { get; }
        IRepository<User> UserRepository { get; }
        IRepository<UserAddres> UserAddressRepository { get; }
        IRepository<UserContact> UserContactRepository { get; }
        IRepository<UserDetail> UserDetailRepository { get; }
        IRepository<UserType> UserTypeRepository { get; }
        IRepository<EmailNotification> EmailRepository { get; }
        IRepository<ReturnComment> ReturnRepository { get; }
        IRepository<ReviewComment> ReviewCommentsRespository { get; }
        IRepository<IncidentSergeant> IncidentSergeantRepository { get; }
        IRepository<IncidentBusinessAddres> IncidentBusinessRespository { get; }
        IRepository<UoF_ChangeRole> ChangeRoleRespository { get; }
        IRepository<IncidentInvestigationOfficer> InvestigationOfficerRespository { get; }
        IRepository<IncidentRank> IncidentRankRespository { get; }
        IRepository<FormReviewRank> FormReviewRankRespository { get; }
        IRepository<IncidentPackage> PackageRespository { get; }
        IRepository<IncidentMedicalUser> IncidentMedicalRespository { get; }
    }
}


