﻿//using UOF.DataAccess.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.DataAccess.Repository
{
    public class UnitOfWork : IUnitOfWork, IDisposable
    {
        private UOFDataContext DbContext { get; set; }

        public UnitOfWork()
        {
            CreateDbContext();
        }



        //repositories
        #region Repositries
        private IRepository<Addres> _addressRepository;
        private IRepository<AddressType> _addressTypeRepository;
        private IRepository<CFRT_RolledOut> _CFRT_RolledOutRepository;
        private IRepository<ChargeCode> _chargeCodeRepository;
        private IRepository<ChargeCodeType> _chargeCodeTypeRepository;
        private IRepository<Contact> _contactRepository;
        private IRepository<ContactType> _contactTypeRepository;
        private IRepository<ForceOnSuspect> _forceOnSuspectRepository;
        private IRepository<Handler> _handlerRepository;
        private IRepository<Hospital> _hospitalRepository;
        private IRepository<IAB_RolledOut> _IAB_RolledOutRepository;
        private IRepository<Incident> _incidentRepository;
        private IRepository<IncidentCanineDeployment> _incidentCanineDeploymentRepository;
        private IRepository<IncidentUser> _incidentUserRepository;
        private IRepository<IncidentUserChargeCode> _incidentUserChargeCodeRepository;
        private IRepository<IncidentUserCopy> _incidentUserCopyRepository;
        private IRepository<IncidentUserDirector> _incidentUserDirectorRepository;
        private IRepository<IncidentStatisticalData> _incidentStatisticalRepository;
        private IRepository<IncidentUserInterview> _incidentUserInterviewRepository;
        private IRepository<IncidentUserSuspect> _incidentUserSuspectRepository;
        private IRepository<IncidentUserWitnes> _incidentUserWitnessRepository;
        private IRepository<IncidentUserInvolved> _incidentUserInvolvedRepository;
        private IRepository<Treatment> _treatmentRepository;
        private IRepository<User> _userRepository;
        private IRepository<UserAddres> _userAddressRepository;
        private IRepository<UserContact> _userContactRepository;
        private IRepository<UserDetail> _userDetailRepository;
        private IRepository<UserType> _userTypeRepository;
        private IRepository<InmateInjury> _inmateInjury;
        private IRepository<IncidentFormData> _UOFnarrative;
        private IRepository<ArtifactsInformation> _artifactInfo;
        private IRepository<UserRole> _userRole;
        private IRepository<UofForm> _uofForm;
        private IRepository<FormPermisssion> _formPermission;
        private IRepository<IncidentCategoryForm> _categoryForm;
        private IRepository<LookupBodyPart> _bodyPartLookup;
        private IRepository<LookupInjury> _injuryLookup;
        private IRepository<LookupBureau> _bureauLookup;

        private IRepository<LookupMethod> _methodLookup;
        private IRepository<LookupSecurityLevel> _securityLookup;
        private IRepository<LookupSpecialHandle> _specialLookup;
        private IRepository<LookupInmateDres> _inmateDressLookup;
        private IRepository<LookupCity> _cityLookup;
        private IRepository<LookupContactType> _contactTypeLookup;
        private IRepository<LookupCustodyEvent> _custodyEventLookup;
        private IRepository<LookupDres> _dressLookup;
        private IRepository<LookupFacility> _facilityLookup;
        private IRepository<LookupStation> _stationLookup;
        private IRepository<LookupStaging> _stagingLookup;
        private IRepository<LookupInjurySeverity> _injurySeverityLookup;
        private IRepository<LookupLocationofForce> _locationofForceLookup;
        private IRepository<LookupPerceivedArmed> _perceivedArmedLookup;
        private IRepository<LookupConfirmedArmed> _confirmedArmedLookup;

        private IRepository<LookupRace> _raceLookup;
        private IRepository<LookupResistance> _resistanceLookup;
        private IRepository<LookupSex> _sexLookup;
        private IRepository<LookupSubstance> _substanceLookup;
        private IRepository<LookupArmed> _armedLookup;

        private IRepository<IncidentWorkflow> _incidentWorkflow;
        private IRepository<IncidentCFRTFlow> _incidentCFRTflow;
        private IRepository<IncidentFormReview> _formReview;
        private IRepository<EmailNotification> _email;
        private IRepository<ReturnComment> _return;
        private IRepository<ReviewComment> _review;

        private IRepository<IncidentSergeant> _incidentSergeant;

        private IRepository<IncidentBusinessAddres> _incidentBusiness;
        private IRepository<FormApprovalorReject> _formApprovalorReject;

        private IRepository<IncidentFormExplaination> _explainReview;

        private IRepository<UoF_ChangeRole> _changeRole;
        private IRepository<AT_ChangeOwner> _changeOwner;
        private IRepository<IncidentInvestigationOfficer> _investOfficer;
        private IRepository<IncidentRank> _incidentRank;
        private IRepository<FormReviewRank> _formReviewRank;
        private IRepository<IncidentPackage> _package;
        private IRepository<IncidentMedicalUser> _indMedical;
        

        #region
        public IRepository<LookupBodyPart> BodyPartRepository
        {
            get
            {
                if (_bodyPartLookup == null)
                {
                    _bodyPartLookup = new Repository<LookupBodyPart>(DbContext);

                }
                return _bodyPartLookup;
            }
        }
        public IRepository<LookupCity> CityRepository
        {
            get
            {
                if (_cityLookup == null)
                {
                    _cityLookup = new Repository<LookupCity>(DbContext);

                }
                return _cityLookup;
            }
        }
        public IRepository<LookupContactType> ContactLookupRepository
        {
            get
            {
                if (_contactTypeLookup == null)
                {
                    _contactTypeLookup = new Repository<LookupContactType>(DbContext);

                }
                return _contactTypeLookup;
            }
        }



        public IRepository<LookupCustodyEvent> CustodyEventRepository
        {
            get
            {
                if (_custodyEventLookup == null)
                {
                    _custodyEventLookup = new Repository<LookupCustodyEvent>(DbContext);

                }
                return _custodyEventLookup;
            }
        }
        public IRepository<LookupDres> DressRepository
        {
            get
            {
                if (_dressLookup == null)
                {
                    _dressLookup = new Repository<LookupDres>(DbContext);

                }
                return _dressLookup;
            }
        }
        public IRepository<LookupFacility> FacilityRepository
        {
            get
            {
                if (_facilityLookup == null)
                {
                    _facilityLookup = new Repository<LookupFacility>(DbContext);

                }
                return _facilityLookup;
            }
        }
        public IRepository<LookupStation> StationRepository
        {
            get
            {
                if (_stationLookup == null)
                {
                    _stationLookup = new Repository<LookupStation>(DbContext);

                }
                return _stationLookup;
            }
        }
        public IRepository<LookupStaging> StagingRepository
        {
            get
            {
                if (_stagingLookup == null)
                {
                    _stagingLookup = new Repository<LookupStaging>(DbContext);

                }
                return _stagingLookup;
            }
        }
        public IRepository<LookupInjurySeverity> InjurySeverityRepository
        {
            get
            {
                if (_injurySeverityLookup == null)
                {
                    _injurySeverityLookup = new Repository<LookupInjurySeverity>(DbContext);

                }
                return _injurySeverityLookup;
            }
        }
        public IRepository<LookupLocationofForce> LocationofForceRepository
        {
            get
            {
                if (_locationofForceLookup == null)
                {
                    _locationofForceLookup = new Repository<LookupLocationofForce>(DbContext);

                }
                return _locationofForceLookup;
            }
        }
        public IRepository<LookupPerceivedArmed> PerceivedArmedRepository
        {
            get
            {
                if (_perceivedArmedLookup == null)
                {
                    _perceivedArmedLookup = new Repository<LookupPerceivedArmed>(DbContext);

                }
                return _perceivedArmedLookup;
            }
        }
        public IRepository<LookupConfirmedArmed> ConfirmedArmedRepository
        {
            get
            {
                if (_confirmedArmedLookup == null)
                {
                    _confirmedArmedLookup = new Repository<LookupConfirmedArmed>(DbContext);

                }
                return _confirmedArmedLookup;
            }
        }

        public IRepository<LookupRace> RaceRepository
        {
            get
            {
                if (_raceLookup == null)
                {
                    _raceLookup = new Repository<LookupRace>(DbContext);

                }
                return _raceLookup;
            }
        }
        public IRepository<LookupResistance> ResistanceRepository
        {
            get
            {
                if (_resistanceLookup == null)
                {
                    _resistanceLookup = new Repository<LookupResistance>(DbContext);

                }
                return _resistanceLookup;
            }
        }
        public IRepository<LookupSex> SexRepository
        {
            get
            {
                if (_sexLookup == null)
                {
                    _sexLookup = new Repository<LookupSex>(DbContext);

                }
                return _sexLookup;
            }
        }
        public IRepository<LookupSubstance> SubstanceRepository
        {
            get
            {
                if (_substanceLookup == null)
                {
                    _substanceLookup = new Repository<LookupSubstance>(DbContext);

                }
                return _substanceLookup;
            }
        }

        public IRepository<LookupInjury> InjuryRepository
        {
            get
            {
                if (_injuryLookup == null)
                {
                    _injuryLookup = new Repository<LookupInjury>(DbContext);

                }
                return _injuryLookup;
            }
        }
        public IRepository<LookupBureau> BureauRepository
        {
            get
            {
                if (_bureauLookup == null)
                {
                    _bureauLookup = new Repository<LookupBureau>(DbContext);

                }
                return _bureauLookup;
            }
        }

        public IRepository<LookupMethod> MethodRepository
        {
            get
            {
                if (_methodLookup == null)
                {
                    _methodLookup = new Repository<LookupMethod>(DbContext);

                }
                return _methodLookup;
            }
        }
        public IRepository<LookupSecurityLevel> SecurityLevelRepository
        {
            get
            {
                if (_securityLookup == null)
                {
                    _securityLookup = new Repository<LookupSecurityLevel>(DbContext);

                }
                return _securityLookup;
            }
        }
        public IRepository<LookupSpecialHandle> SpecialHandleRepository
        {
            get
            {
                if (_specialLookup == null)
                {
                    _specialLookup = new Repository<LookupSpecialHandle>(DbContext);

                }
                return _specialLookup;
            }
        }
        public IRepository<LookupInmateDres> InmateDressRepository
        {
            get
            {
                if (_inmateDressLookup == null)
                {
                    _inmateDressLookup = new Repository<LookupInmateDres>(DbContext);

                }
                return _inmateDressLookup;
            }
        }
        public IRepository<LookupArmed> ArmedRepository
        {
            get
            {
                if (_armedLookup == null)
                {
                    _armedLookup = new Repository<LookupArmed>(DbContext);

                }
                return _armedLookup;
            }
        }
        #endregion

        public IRepository<IncidentFormReview> ReviewRespository
        {
            get
            {
                if (_formReview == null)
                {
                    _formReview = new Repository<IncidentFormReview>(DbContext);

                }
                return _formReview;
            }
        }

        public IRepository<IncidentCategoryForm> CategoryFormRepository
        {
            get
            {
                if (_categoryForm == null)
                {
                    _categoryForm = new Repository<IncidentCategoryForm>(DbContext);

                }
                return _categoryForm;
            }
        }
        public IRepository<IncidentBusinessAddres> IncidentBusinessRespository
        {
            get
            {
                if (_incidentBusiness == null)
                {
                    _incidentBusiness = new Repository<IncidentBusinessAddres>(DbContext);

                }
                return _incidentBusiness;
            }
        }
        public IRepository<FormApprovalorReject> FormApprovalRejectRespository
        {
            get
            {
                if (_formApprovalorReject == null)
                {
                    _formApprovalorReject = new Repository<FormApprovalorReject>(DbContext);

                }
                return _formApprovalorReject;
            }
        }
        public IRepository<UoF_ChangeRole> ChangeRoleRespository
        {
            get
            {
                if (_changeRole == null)
                {
                    _changeRole = new Repository<UoF_ChangeRole>(DbContext);

                }
                return _changeRole;
            }
        }
        public IRepository<AT_ChangeOwner> ChangeownerRespository
        {
            get
            {
                if (_changeOwner == null)
                {
                    _changeOwner = new Repository<AT_ChangeOwner>(DbContext);

                }
                return _changeOwner;
            }
        }
        public IRepository<IncidentInvestigationOfficer> InvestigationOfficerRespository
        {
            get
            {
                if (_investOfficer == null)
                {
                    _investOfficer = new Repository<IncidentInvestigationOfficer>(DbContext);

                }
                return _investOfficer;
            }
        }
        public IRepository<IncidentRank> IncidentRankRespository
        {
            get
            {
                if (_incidentRank == null)
                {
                    _incidentRank = new Repository<IncidentRank>(DbContext);

                }
                return _incidentRank;
            }
        }
        public IRepository<FormReviewRank> FormReviewRankRespository
        {
            get
            {
                if (_formReviewRank == null)
                {
                    _formReviewRank = new Repository<FormReviewRank>(DbContext);

                }
                return _formReviewRank;
            }
        }

        public IRepository<IncidentPackage> PackageRespository
        {
            get
            {
                if (_package == null)
                {
                    _package = new Repository<IncidentPackage>(DbContext);

                }
                return _package;
            }
        }

        public IRepository<IncidentMedicalUser> IncidentMedicalRespository
        {
            get
            {
                if (_indMedical == null)
                {
                    _indMedical = new Repository<IncidentMedicalUser>(DbContext);

                }
                return _indMedical;
            }
        }
        public IRepository<IncidentFormData> UOFIncidentFormDataRepository
        {
            get
            {
                if (_UOFnarrative == null)
                {
                    _UOFnarrative = new Repository<IncidentFormData>(DbContext);

                }
                return _UOFnarrative;
            }
        }

        public IRepository<ArtifactsInformation> ArtifactsInformationRepository
        {
            get
            {
                if (_artifactInfo == null)
                {
                    _artifactInfo = new Repository<ArtifactsInformation>(DbContext);

                }
                return _artifactInfo;
            }
        }

        public IRepository<IncidentSergeant> IncidentSergeantRepository
        {
            get
            {
                if (_incidentSergeant == null)
                {
                    _incidentSergeant = new Repository<IncidentSergeant>(DbContext);

                }
                return _incidentSergeant;
            }
        }
        public IRepository<IncidentWorkflow> IncidentWorkflowRepository
        {
            get
            {
                if (_incidentWorkflow == null)
                {
                    _incidentWorkflow = new Repository<IncidentWorkflow>(DbContext);

                }
                return _incidentWorkflow;
            }
        }
        public IRepository<IncidentCFRTFlow> IncidentCFRTRepository
        {
            get
            {
                if (_incidentCFRTflow == null)
                {
                    _incidentCFRTflow = new Repository<IncidentCFRTFlow>(DbContext);

                }
                return _incidentCFRTflow;
            }
        }
        public IRepository<InmateInjury> InmateInjuryRepository
        {
            get
            {
                if (_inmateInjury == null)
                {
                    _inmateInjury = new Repository<InmateInjury>(DbContext);

                }
                return _inmateInjury;
            }
        }

        public IRepository<Addres> AddressRepository
        {
            get
            {
                if (_addressRepository == null)
                {
                    _addressRepository = new Repository<Addres>(DbContext);

                }
                return _addressRepository;
            }
        }
        public IRepository<AddressType> AddressTypeRepository
        {
            get
            {
                if (_addressTypeRepository == null)
                {
                    _addressTypeRepository = new Repository<AddressType>(DbContext);

                }
                return _addressTypeRepository;
            }
        }
        public IRepository<CFRT_RolledOut> CFRT_RolledOutRepository
        {
            get
            {
                if (_CFRT_RolledOutRepository == null)
                {
                    _CFRT_RolledOutRepository = new Repository<CFRT_RolledOut>(DbContext);

                }
                return _CFRT_RolledOutRepository;
            }
        }
        public IRepository<ChargeCode> ChargeCodeRepository
        {
            get
            {
                if (_chargeCodeRepository == null)
                {
                    _chargeCodeRepository = new Repository<ChargeCode>(DbContext);

                }
                return _chargeCodeRepository;
            }
        }
        public IRepository<ChargeCodeType> ChargeCodeTypeRepository
        {
            get
            {
                if (_chargeCodeTypeRepository == null)
                {
                    _chargeCodeTypeRepository = new Repository<ChargeCodeType>(DbContext);

                }
                return _chargeCodeTypeRepository;
            }
        }
        public IRepository<Contact> ContactRepository
        {
            get
            {
                if (_contactRepository == null)
                {
                    _contactRepository = new Repository<Contact>(DbContext);

                }
                return _contactRepository;
            }
        }
        public IRepository<ContactType> ContactTypeRepository
        {
            get
            {
                if (_contactTypeRepository == null)
                {
                    _contactTypeRepository = new Repository<ContactType>(DbContext);

                }
                return _contactTypeRepository;
            }
        }
        public IRepository<ForceOnSuspect> ForceOnSuspectRepository
        {
            get
            {
                if (_forceOnSuspectRepository == null)
                {
                    _forceOnSuspectRepository = new Repository<ForceOnSuspect>(DbContext);

                }
                return _forceOnSuspectRepository;
            }
        }
        public IRepository<Handler> HandlerRepository
        {
            get
            {
                if (_handlerRepository == null)
                {
                    _handlerRepository = new Repository<Handler>(DbContext);

                }
                return _handlerRepository;
            }
        }
        public IRepository<Hospital> HospitalRepository
        {
            get
            {
                if (_hospitalRepository == null)
                {
                    _hospitalRepository = new Repository<Hospital>(DbContext);

                }
                return _hospitalRepository;
            }
        }
        public IRepository<IAB_RolledOut> IAB_RolledOutRepository
        {
            get
            {
                if (_IAB_RolledOutRepository == null)
                {
                    _IAB_RolledOutRepository = new Repository<IAB_RolledOut>(DbContext);

                }
                return _IAB_RolledOutRepository;
            }
        }
        public IRepository<Incident> IncidentRepository
        {
            get
            {
                if (_incidentRepository == null)
                {
                    _incidentRepository = new Repository<Incident>(DbContext);

                }
                return _incidentRepository;
            }
        }
        public IRepository<IncidentCanineDeployment> IncidentCanineDeploymentRepository
        {
            get
            {
                if (_incidentCanineDeploymentRepository == null)
                {
                    _incidentCanineDeploymentRepository = new Repository<IncidentCanineDeployment>(DbContext);

                }
                return _incidentCanineDeploymentRepository;
            }
        }
        public IRepository<IncidentUser> IncidentUserRepository
        {
            get
            {
                if (_incidentUserRepository == null)
                {
                    _incidentUserRepository = new Repository<IncidentUser>(DbContext);

                }
                return _incidentUserRepository;
            }
        }
        public IRepository<IncidentUserChargeCode> IncidentUserChargeCodeRepository
        {
            get
            {
                if (_incidentUserChargeCodeRepository == null)
                {
                    _incidentUserChargeCodeRepository = new Repository<IncidentUserChargeCode>(DbContext);

                }
                return _incidentUserChargeCodeRepository;
            }
        }
        public IRepository<IncidentUserCopy> IncidentUserCopyRepository
        {
            get
            {
                if (_incidentUserCopyRepository == null)
                {
                    _incidentUserCopyRepository = new Repository<IncidentUserCopy>(DbContext);

                }
                return _incidentUserCopyRepository;
            }
        }
        public IRepository<IncidentUserDirector> IncidentUserDirectorRepository
        {
            get
            {
                if (_incidentUserDirectorRepository == null)
                {
                    _incidentUserDirectorRepository = new Repository<IncidentUserDirector>(DbContext);

                }
                return _incidentUserDirectorRepository;
            }
        }
        public IRepository<IncidentStatisticalData> IncidentStatisticalRepository
        {
            get
            {
                if (_incidentStatisticalRepository == null)
                {
                    _incidentStatisticalRepository = new Repository<IncidentStatisticalData>(DbContext);

                }
                return _incidentStatisticalRepository;
            }
        }
        public IRepository<IncidentUserInterview> IncidentUserInterviewRepository
        {
            get
            {
                if (_incidentUserInterviewRepository == null)
                {
                    _incidentUserInterviewRepository = new Repository<IncidentUserInterview>(DbContext);

                }
                return _incidentUserInterviewRepository;
            }
        }
        public IRepository<IncidentUserInvolved> IncidentUserInvolvedRepository
        {
            get
            {
                if (_incidentUserInvolvedRepository == null)
                {
                    _incidentUserInvolvedRepository = new Repository<IncidentUserInvolved>(DbContext);

                }
                return _incidentUserInvolvedRepository;
            }
        }
        public IRepository<IncidentUserSuspect> IncidentUserSuspectRepository
        {
            get
            {
                if (_incidentUserSuspectRepository == null)
                {
                    _incidentUserSuspectRepository = new Repository<IncidentUserSuspect>(DbContext);

                }
                return _incidentUserSuspectRepository;
            }
        }
        public IRepository<IncidentUserWitnes> IncidentUserWitnessRepository
        {
            get
            {
                if (_incidentUserWitnessRepository == null)
                {
                    _incidentUserWitnessRepository = new Repository<IncidentUserWitnes>(DbContext);

                }
                return _incidentUserWitnessRepository;
            }
        }
        public IRepository<Treatment> TreatmentRepository
        {
            get
            {
                if (_treatmentRepository == null)
                {
                    _treatmentRepository = new Repository<Treatment>(DbContext);

                }
                return _treatmentRepository;
            }
        }
        public IRepository<User> UserRepository
        {
            get
            {
                if (_userRepository == null)
                {
                    _userRepository = new Repository<User>(DbContext);

                }
                return _userRepository;
            }
        }
        public IRepository<UserAddres> UserAddressRepository
        {
            get
            {
                if (_userAddressRepository == null)
                {
                    _userAddressRepository = new Repository<UserAddres>(DbContext);

                }
                return _userAddressRepository;
            }
        }
        public IRepository<UserContact> UserContactRepository
        {
            get
            {
                if (_userContactRepository == null)
                {
                    _userContactRepository = new Repository<UserContact>(DbContext);

                }
                return _userContactRepository;
            }
        }
        public IRepository<UserDetail> UserDetailRepository
        {
            get
            {
                if (_userDetailRepository == null)
                {
                    _userDetailRepository = new Repository<UserDetail>(DbContext);

                }
                return _userDetailRepository;
            }
        }
        public IRepository<UserType> UserTypeRepository
        {
            get
            {
                if (_userTypeRepository == null)
                {
                    _userTypeRepository = new Repository<UserType>(DbContext);

                }
                return _userTypeRepository;
            }
        }
        public IRepository<UserRole> UserRoleRepository
        {
            get
            {
                if (_userRole == null)
                {
                    _userRole = new Repository<UserRole>(DbContext);

                }
                return _userRole;
            }
        }


        public IRepository<UofForm> UofFormRepository
        {
            get
            {
                if (_uofForm == null)
                {
                    _uofForm = new Repository<UofForm>(DbContext);

                }
                return _uofForm;
            }
        }


        public IRepository<FormPermisssion> FormPermissionRepository
        {
            get
            {
                if (_formPermission == null)
                {
                    _formPermission = new Repository<FormPermisssion>(DbContext);

                }
                return _formPermission;
            }
        }
        public IRepository<EmailNotification> EmailRepository
        {
            get
            {
                if (_email == null)
                {
                    _email = new Repository<EmailNotification>(DbContext);

                }
                return _email;
            }
        }
        public IRepository<ReturnComment> ReturnRepository
        {
            get
            {
                if (_return == null)
                {
                    _return = new Repository<ReturnComment>(DbContext);

                }
                return _return;
            }
        }
        public IRepository<ReviewComment> ReviewCommentsRespository
        {
            get
            {
                if (_review == null)
                {
                    _review = new Repository<ReviewComment>(DbContext);

                }
                return _review;
            }
        }
        public IRepository<IncidentFormExplaination> ExplainationReviewRespository
        {
            get
            {
                if (_explainReview == null)
                {
                    _explainReview = new Repository<IncidentFormExplaination>(DbContext);

                }
                return _explainReview;
            }
        }

        #endregion

        /// <summary>
        /// Save changes to the database
        /// </summary>
        public int Commit()
        {
            return DbContext.SaveChanges();
        }
        protected void CreateDbContext()
        {
            DbContext = new UOFDataContext();

            // Do NOT enable proxied entities, else serialization fails.
            //if false it will not get the associated certification and skills when we
            //get the applicants
            DbContext.Configuration.ProxyCreationEnabled = false;

            // Load navigation properties explicitly (avoid serialization trouble)
            DbContext.Configuration.LazyLoadingEnabled = false;

            // Because Web API will perform validation, we don't need/want EF to do so
            DbContext.Configuration.ValidateOnSaveEnabled = false;

            //DbContext.Configuration.AutoDetectChangesEnabled = false;
            // We won't use this performance tweak because we don't need
            // the extra performance and, when autodetect is false,
            // we'd have to be careful. We're not being that careful.
        }

        #region IDisposable

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (DbContext != null)
                {
                    DbContext.Dispose();
                }
            }
        }

        #endregion



    }


}
