﻿ 
 
 

 

 

//NOTE:  This file was generated.  Do not change anything in this file manually
//		 If changes are needed, use one of the following options:
//
//		 1.   Use a partial class to extend the entity 
//		 2.	  Modify the T4 template and regen all entities
//	     3.   Remove the entity from the list of generated entities and create the entity in a new file 

using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.Serialization;

namespace UOF.DataAccess
{

 				
		[DataContract(IsReference=true)]
		[Table("Address", Schema="dbo")]
		public partial class Addres 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("AddressId", Order=0)]
			public Int32 AddressId { get; set;}

			[DataMember]
			[StringLength(500)]
			[Column("AddressNumber", Order=1)]
			public String AddressNumber { get; set;}

			[DataMember]
			[StringLength(50)]
			[Column("City", Order=2)]
			public String City { get; set;}

			[DataMember]
			[StringLength(150)]
			[Column("StationFacility", Order=3)]
			public String StationFacility { get; set;}

			[DataMember]
			[StringLength(50)]
			[Column("ZipCode", Order=4)]
			public String ZipCode { get; set;}

			[DataMember]
			[StringLength(50)]
			[Column("State", Order=5)]
			public String State { get; set;}

			[DataMember]
			[Required]
			[Column("AddressTypeId", Order=6)]
			public Int32 AddressTypeId { get; set;}

			[DataMember]
			[StringLength(100)]
			[Column("Street", Order=7)]
			public String Street { get; set;}

			[DataMember]
			[Column("IncidentId", Order=8)]
			public Int32? IncidentId { get; set;}

			[DataMember]
			[ForeignKey("AddressTypeId")]
			public AddressType AddressType { get; set;}

			[DataMember]
			[ForeignKey("IncidentId")]
			public Incident Incident { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("AddressType", Schema="dbo")]
		public partial class AddressType 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("AddressTypeId", Order=0)]
			public Int32 AddressTypeId { get; set;}

			[DataMember]
			[Required]
			[StringLength(50)]
			[Column("TypeName", Order=1)]
			public String TypeName { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("CFRT_RolledOut", Schema="dbo")]
		public partial class CFRT_RolledOut 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("CFRT_RolledOutId", Order=0)]
			public Int32 CFRT_RolledOutId { get; set;}

			[DataMember]
			[Column("IncidentId", Order=1)]
			public Int32? IncidentId { get; set;}

			[DataMember]
			[Column("UserId", Order=2)]
			public Int32? UserId { get; set;}

			[DataMember]
			[ForeignKey("IncidentId")]
			public Incident Incident { get; set;}

			[DataMember]
			[ForeignKey("UserId")]
			public User User { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("ChargeCode", Schema="dbo")]
		public partial class ChargeCode 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("ChargeCodeId", Order=0)]
			public Int32 ChargeCodeId { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("CodeNumber", Order=1)]
			public String CodeNumber { get; set;}

			[DataMember]
			[Column("ChargeCodeTypeId", Order=2)]
			public Int32? ChargeCodeTypeId { get; set;}

			[DataMember]
			[ForeignKey("ChargeCodeTypeId")]
			public ChargeCodeType ChargeCodeType { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("ChargeCodeType", Schema="dbo")]
		public partial class ChargeCodeType 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("ChargeCodeTypeId", Order=0)]
			public Int32 ChargeCodeTypeId { get; set;}

			[DataMember]
			[StringLength(50)]
			[Column("TypeName", Order=1)]
			public String TypeName { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("Contact", Schema="dbo")]
		public partial class Contact 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("ContactId", Order=0)]
			public Int32 ContactId { get; set;}

			[DataMember]
			[Required]
			[StringLength(15)]
			[Column("Number", Order=1)]
			public String Number { get; set;}

			[DataMember]
			[Required]
			[Column("ContactTypeId", Order=2)]
			public Int32 ContactTypeId { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("ContactType", Schema="dbo")]
		public partial class ContactType 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("ContactTypeId", Order=0)]
			public Int32 ContactTypeId { get; set;}

			[DataMember]
			[StringLength(50)]
			[Column("TypeName", Order=1)]
			public String TypeName { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("ForceOnSuspect", Schema="dbo")]
		public partial class ForceOnSuspect 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("ForceOnSuspectId", Order=0)]
			public Int32 ForceOnSuspectId { get; set;}

			[DataMember]
			[Column("IncidentUserId", Order=1)]
			public Int32? IncidentUserId { get; set;}

			[DataMember]
			[Column("ForceId", Order=2)]
			public Int32? ForceId { get; set;}

			[DataMember]
			[ForeignKey("IncidentUserId")]
			public IncidentUser IncidentUser { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("Handler", Schema="dbo")]
		public partial class Handler 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("HandlerId", Order=0)]
			public Int32 HandlerId { get; set;}

			[DataMember]
			[Required]
			[Column("IncidentCanineDeploymentId", Order=1)]
			public Int32 IncidentCanineDeploymentId { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("HandlerNumber", Order=2)]
			public String HandlerNumber { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("HandlerName", Order=3)]
			public String HandlerName { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("CanineNumber", Order=4)]
			public String CanineNumber { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("UnitNumber", Order=5)]
			public String UnitNumber { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("HandlerType", Order=6)]
			public String HandlerType { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("Hospital", Schema="dbo")]
		public partial class Hospital 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("HospitalId", Order=0)]
			public Int32 HospitalId { get; set;}

			[DataMember]
			[StringLength(150)]
			[Column("RecdTreatmentAt", Order=1)]
			public String RecdTreatmentAt { get; set;}

			[DataMember]
			[StringLength(150)]
			[Column("HospitalAdmissionBy", Order=2)]
			public String HospitalAdmissionBy { get; set;}

			[DataMember]
			[StringLength(500)]
			[Column("HospitalAddress", Order=3)]
			public String HospitalAddress { get; set;}

			[DataMember]
			[StringLength(50)]
			[Column("HospitalPhone", Order=4)]
			public String HospitalPhone { get; set;}

			[DataMember]
			[Column("IncidentUserSuspectId", Order=5)]
			public Int32? IncidentUserSuspectId { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("IAB_RolledOut", Schema="dbo")]
		public partial class IAB_RolledOut 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("IAB_RolledOutId", Order=0)]
			public Int32 IAB_RolledOutId { get; set;}

			[DataMember]
			[Column("IncidentId", Order=1)]
			public Int32? IncidentId { get; set;}

			[DataMember]
			[Column("UserId", Order=2)]
			public Int32? UserId { get; set;}

			[DataMember]
			[ForeignKey("IncidentId")]
			public Incident Incident { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("Incident", Schema="dbo")]
		public partial class Incident 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("IncidentId", Order=0)]
			public Int32 IncidentId { get; set;}

			[DataMember]
			[StringLength(25)]
			[Column("URN", Order=1)]
			public String URN { get; set;}

			[DataMember]
			[Required]
			[Column("AddressId", Order=2)]
			public Int32 AddressId { get; set;}

			[DataMember]
			[Required]
			[Column("IncidentDate", Order=3)]
			public DateTime IncidentDate { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("ContactTypeId", Order=4)]
			public String ContactTypeId { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("CustodyEventId", Order=5)]
			public String CustodyEventId { get; set;}

			[DataMember]
			[StringLength(100)]
			[Column("IncidentName", Order=6)]
			public String IncidentName { get; set;}

			[DataMember]
			[StringLength(100)]
			[Column("incidentCity", Order=7)]
			public String IncidentCity { get; set;}

			[DataMember]
			[StringLength(100)]
			[Column("CTOthers", Order=8)]
			public String CTOthers { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsAdminInvestigation", Order=9)]
			public String IsAdminInvestigation { get; set;}

			[DataMember]
			[Column("IncidentCategoryId", Order=10)]
			public Int32? IncidentCategoryId { get; set;}

			[DataMember]
			[StringLength(50)]
			[Column("ForceTypeId", Order=11)]
			public String ForceTypeId { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsDeptyInjury", Order=12)]
			public String IsDeptyInjury { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsSuspectInjury", Order=13)]
			public String IsSuspectInjury { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsUnderlyingArrest", Order=14)]
			public String IsUnderlyingArrest { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsUnderlyingCrime", Order=15)]
			public String IsUnderlyingCrime { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsOnK12Campus", Order=16)]
			public String IsOnK12Campus { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsByFootPursuit", Order=17)]
			public String IsByFootPursuit { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsByVehiclePursuit", Order=18)]
			public String IsByVehiclePursuit { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsIABNotified", Order=19)]
			public String IsIABNotified { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("IABNotifiedUserId", Order=20)]
			public String IABNotifiedUserId { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsIABRollOut", Order=21)]
			public String IsIABRollOut { get; set;}

			[DataMember]
			[StringLength(500)]
			[Column("IABRolloutEmployees", Order=22)]
			public String IABRolloutEmployees { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsIABHandling", Order=23)]
			public String IsIABHandling { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("IABHandlingUserId", Order=24)]
			public String IABHandlingUserId { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsCFRTNotified", Order=25)]
			public String IsCFRTNotified { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("CFRTNotifiedUserId", Order=26)]
			public String CFRTNotifiedUserId { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsCFRTRollOut", Order=27)]
			public String IsCFRTRollOut { get; set;}

			[DataMember]
			[StringLength(500)]
			[Column("CFRTRolloutEmployees", Order=28)]
			public String CFRTRolloutEmployees { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsCFRTHandling", Order=29)]
			public String IsCFRTHandling { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("CFRTHandlingUserId", Order=30)]
			public String CFRTHandlingUserId { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsReactiveForce", Order=31)]
			public String IsReactiveForce { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsPlannedForce", Order=32)]
			public String IsPlannedForce { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsInmateInjuryReportWritten", Order=33)]
			public String IsInmateInjuryReportWritten { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsMedicalStaffPresent", Order=34)]
			public String IsMedicalStaffPresent { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsMentalHealthPresent", Order=35)]
			public String IsMentalHealthPresent { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsSuperVisorPresent", Order=36)]
			public String IsSuperVisorPresent { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsMedicalRecordChecked", Order=37)]
			public String IsMedicalRecordChecked { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsExtractionOrderByMedical", Order=38)]
			public String IsExtractionOrderByMedical { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsMentalHealthProfessional", Order=39)]
			public String IsMentalHealthProfessional { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsDepartmentSignAdmonishmentAndNotedChangesInReport", Order=40)]
			public String IsDepartmentSignAdmonishmentAndNotedChangesInReport { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsInvestigatorDirectedTheForce", Order=41)]
			public String IsInvestigatorDirectedTheForce { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsInvestigatorParticipatedInTheForce", Order=42)]
			public String IsInvestigatorParticipatedInTheForce { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsInvestigatorPlannedTheForce", Order=43)]
			public String IsInvestigatorPlannedTheForce { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsStaffEscortInvolvedInmates", Order=44)]
			public String IsStaffEscortInvolvedInmates { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsCCTVCoverage", Order=45)]
			public String IsCCTVCoverage { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsVideoShooted", Order=46)]
			public String IsVideoShooted { get; set;}

			[DataMember]
			[StringLength(100)]
			[Column("VideoofIncident", Order=47)]
			public String VideoofIncident { get; set;}

			[DataMember]
			[StringLength(100)]
			[Column("Location", Order=48)]
			public String Location { get; set;}

			[DataMember]
			[StringLength(100)]
			[Column("LevelofResistance", Order=49)]
			public String LevelofResistance { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsDepartmentMembersSeparated", Order=50)]
			public String IsDepartmentMembersSeparated { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsPPIReviewCompleted", Order=51)]
			public String IsPPIReviewCompleted { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("SergeantId", Order=52)]
			public String SergeantId { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IncidentApprovalStatus", Order=53)]
			public String IncidentApprovalStatus { get; set;}

			[DataMember]
			[Column("UpdatedDate", Order=54)]
			public DateTime? UpdatedDate { get; set;}

			[DataMember]
			[Column("IncidentCreatedDate", Order=55)]
			public DateTime? IncidentCreatedDate { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("Assulative", Order=56)]
			public String Assulative { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("Lifethreatening", Order=57)]
			public String Lifethreatening { get; set;}

			[DataMember]
			[Column("IsDeleted", Order=58)]
			public Boolean? IsDeleted { get; set;}

			[DataMember]
			[StringLength(250)]
			[Column("IABNotifiedEmailId", Order=59)]
			public String IABNotifiedEmailId { get; set;}

			[DataMember]
			[StringLength(250)]
			[Column("CFRTNotifiedEmailId", Order=60)]
			public String CFRTNotifiedEmailId { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("ExtractionEmpId", Order=61)]
			public String ExtractionEmpId { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("MentalHealthEmpId", Order=62)]
			public String MentalHealthEmpId { get; set;}

			[DataMember]
			[StringLength(100)]
			[Column("CCTVNoReason", Order=63)]
			public String CCTVNoReason { get; set;}

			[DataMember]
			[StringLength(100)]
			[Column("VideoShootedNoReason", Order=64)]
			public String VideoShootedNoReason { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsCCTVExtracted", Order=65)]
			public String IsCCTVExtracted { get; set;}

			[DataMember]
			[StringLength(50)]
			[Column("IncidentLocationName", Order=66)]
			public String IncidentLocationName { get; set;}

			[DataMember]
			[StringLength(15)]
			[Column("Station", Order=67)]
			public String Station { get; set;}

			[DataMember]
			[StringLength(15)]
			[Column("Facility", Order=68)]
			public String Facility { get; set;}

			[DataMember]
			[StringLength(10)]
			[Column("Staging", Order=69)]
			public String Staging { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("PPINo", Order=70)]
			public String PPINo { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("eLots", Order=71)]
			public String ELots { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("InvestigatorDirectedId", Order=72)]
			public String InvestigatorDirectedId { get; set;}

			[DataMember]
			[Column("PRReason", Order=73)]
			public String PRReason { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("elotsYN", Order=74)]
			public String ElotsYN { get; set;}

			[DataMember]
			[StringLength(500)]
			[Column("elotsNoReason", Order=75)]
			public String ElotsNoReason { get; set;}

			[DataMember]
			[StringLength(50)]
			[Column("ReferenceNo", Order=76)]
			public String ReferenceNo { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("MHS", Order=77)]
			public String MHS { get; set;}

			[DataMember]
			[StringLength(500)]
			[Column("MHSReason", Order=78)]
			public String MHSReason { get; set;}

			[DataMember]
			[StringLength(50)]
			[Column("PFData", Order=79)]
			public String PFData { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("MedicalLife", Order=80)]
			public String MedicalLife { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("MedRcdPrior", Order=81)]
			public String MedRcdPrior { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("PlanAltered", Order=82)]
			public String PlanAltered { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("IncidentCanineDeployment", Schema="dbo")]
		public partial class IncidentCanineDeployment 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("IncidentCanineDeploymentId", Order=0)]
			public Int32 IncidentCanineDeploymentId { get; set;}

			[DataMember]
			[Column("IncidentId", Order=1)]
			public Int32? IncidentId { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("Area", Order=2)]
			public String Area { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("Building", Order=3)]
			public String Building { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("TOSOther", Order=4)]
			public String TOSOther { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("ApprehendingSuspect", Order=5)]
			public String ApprehendingSuspect { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("ConductingSearch", Order=6)]
			public String ConductingSearch { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("ProtectingHandler", Order=7)]
			public String ProtectingHandler { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("BOWOtherReason", Order=8)]
			public String BOWOtherReason { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("Bite", Order=9)]
			public String Bite { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("TOIOther", Order=10)]
			public String TOIOther { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("BYAeroUnit", Order=11)]
			public String BYAeroUnit { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("ByRadioCar", Order=12)]
			public String ByRadioCar { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("English", Order=13)]
			public String English { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("Spanish", Order=14)]
			public String Spanish { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("Recorded", Order=15)]
			public String Recorded { get; set;}

			[DataMember]
			[StringLength(100)]
			[Column("AnnouncementsNoneReason", Order=16)]
			public String AnnouncementsNoneReason { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("AnnouncementMadeby", Order=17)]
			public String AnnouncementMadeby { get; set;}

			[DataMember]
			[StringLength(100)]
			[Column("AnnouncementMadebyReason", Order=18)]
			public String AnnouncementMadebyReason { get; set;}

			[DataMember]
			[StringLength(500)]
			[Column("CriminalHistory", Order=19)]
			public String CriminalHistory { get; set;}

			[DataMember]
			[StringLength(500)]
			[Column("Notifications", Order=20)]
			public String Notifications { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("CreatedBy", Order=21)]
			public String CreatedBy { get; set;}

			[DataMember]
			[Column("CreatedOn", Order=22)]
			public DateTime? CreatedOn { get; set;}

			[DataMember]
			[ForeignKey("IncidentId")]
			public Incident Incident { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("IncidentUser", Schema="dbo")]
		public partial class IncidentUser 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("IncidentUserId", Order=0)]
			public Int32 IncidentUserId { get; set;}

			[DataMember]
			[Column("IncidentId", Order=1)]
			public Int32? IncidentId { get; set;}

			[DataMember]
			[Column("UserId", Order=2)]
			public Int32? UserId { get; set;}

			[DataMember]
			[Column("UserTypeId", Order=3)]
			public Int32? UserTypeId { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("ReviewerId", Order=4)]
			public String ReviewerId { get; set;}

			[DataMember]
			[Column("Createdon", Order=5)]
			public DateTime? Createdon { get; set;}

			[DataMember]
			[ForeignKey("IncidentId")]
			public Incident Incident { get; set;}

			[DataMember]
			[ForeignKey("UserId")]
			public User User { get; set;}

			[DataMember]
			[ForeignKey("UserTypeId")]
			public UserType UserType { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("IncidentUserChargeCode", Schema="dbo")]
		public partial class IncidentUserChargeCode 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("IncidentUserChargeCodeId", Order=0)]
			public Int32 IncidentUserChargeCodeId { get; set;}

			[DataMember]
			[Column("IncidentUserId", Order=1)]
			public Int32? IncidentUserId { get; set;}

			[DataMember]
			[Column("ChargeCodeId", Order=2)]
			public Int32? ChargeCodeId { get; set;}

			[DataMember]
			[ForeignKey("ChargeCodeId")]
			public ChargeCode ChargeCode { get; set;}

			[DataMember]
			[ForeignKey("IncidentUserId")]
			public IncidentUser IncidentUser { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("IncidentUserCopy", Schema="dbo")]
		public partial class IncidentUserCopy 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("IncidentUserCopyId", Order=0)]
			public Int32 IncidentUserCopyId { get; set;}

			[DataMember]
			[Column("IncidentUserId", Order=1)]
			public Int32? IncidentUserId { get; set;}

			[DataMember]
			[Column("CopyToUserId", Order=2)]
			public Int32? CopyToUserId { get; set;}

			[DataMember]
			[ForeignKey("IncidentUserId")]
			public IncidentUser IncidentUser { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("IncidentUserDirector", Schema="dbo")]
		public partial class IncidentUserDirector 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("IncidentUserDirectorId", Order=0)]
			public Int32 IncidentUserDirectorId { get; set;}

			[DataMember]
			[Column("IncidentUserId", Order=1)]
			public Int32? IncidentUserId { get; set;}

			[DataMember]
			[Column("DirectedByUserId", Order=2)]
			public Int32? DirectedByUserId { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("IncidentUserInterview", Schema="dbo")]
		public partial class IncidentUserInterview 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("IncidentUserInterviewId", Order=0)]
			public Int32 IncidentUserInterviewId { get; set;}

			[DataMember]
			[Column("IncidentUserId", Order=1)]
			public Int32? IncidentUserId { get; set;}

			[DataMember]
			[Column("InterviewDate", Order=2)]
			public DateTime? InterviewDate { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsAudioTape", Order=3)]
			public String IsAudioTape { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsVideoType", Order=4)]
			public String IsVideoType { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsInjuryPhoto", Order=5)]
			public String IsInjuryPhoto { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsHearingAdmits", Order=6)]
			public String IsHearingAdmits { get; set;}

			[DataMember]
			[StringLength(10)]
			[Column("InterviewTime", Order=7)]
			public String InterviewTime { get; set;}

			[DataMember]
			[StringLength(100)]
			[Column("AudioPath", Order=8)]
			public String AudioPath { get; set;}

			[DataMember]
			[StringLength(100)]
			[Column("VideoPath", Order=9)]
			public String VideoPath { get; set;}

			[DataMember]
			[StringLength(100)]
			[Column("PhotosPath", Order=10)]
			public String PhotosPath { get; set;}

			[DataMember]
			[ForeignKey("IncidentUserId")]
			public IncidentUser IncidentUser { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("IncidentUserSuspect", Schema="dbo")]
		public partial class IncidentUserSuspect 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("IncidentUserSuspectId", Order=0)]
			public Int32 IncidentUserSuspectId { get; set;}

			[DataMember]
			[Column("IncidentUserId", Order=1)]
			public Int32? IncidentUserId { get; set;}

			[DataMember]
			[StringLength(10)]
			[Column("BookingNumber", Order=2)]
			public String BookingNumber { get; set;}

			[DataMember]
			[StringLength(10)]
			[Column("Armed", Order=3)]
			public String Armed { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("AkaLastname", Order=4)]
			public String AkaLastname { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("AkaFirstname", Order=5)]
			public String AkaFirstname { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("AkaMiddleName", Order=6)]
			public String AkaMiddleName { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("PrimaryPhno", Order=7)]
			public String PrimaryPhno { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("SecondaryPhno", Order=8)]
			public String SecondaryPhno { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("PhoneMode", Order=9)]
			public String PhoneMode { get; set;}

			[DataMember]
			[StringLength(100)]
			[Column("PrimaryChargCode", Order=10)]
			public String PrimaryChargCode { get; set;}

			[DataMember]
			[StringLength(100)]
			[Column("SecondaryChargCode", Order=11)]
			public String SecondaryChargCode { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("CivilianResistance", Order=12)]
			public String CivilianResistance { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("Lifethreatening", Order=13)]
			public String Lifethreatening { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("Assulative", Order=14)]
			public String Assulative { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("Perceivedarmed", Order=15)]
			public String Perceivedarmed { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("CivilianConfirmedarmed", Order=16)]
			public String CivilianConfirmedarmed { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("CivilianInjurySeverity", Order=17)]
			public String CivilianInjurySeverity { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("forecasting", Order=18)]
			public String Forecasting { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("TypeofForce", Order=19)]
			public String TypeofForce { get; set;}

			[DataMember]
			[StringLength(100)]
			[Column("TypeOfInjury", Order=20)]
			public String TypeOfInjury { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("SafetyChairUsed", Order=21)]
			public String SafetyChairUsed { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("CriminalHistory", Order=22)]
			public String CriminalHistory { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("TreatedOnScene", Order=23)]
			public String TreatedOnScene { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("HospitalAdmission", Order=24)]
			public String HospitalAdmission { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("InmatePhysicallyAssaultive", Order=25)]
			public String InmatePhysicallyAssaultive { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("InmateRecalcitrant", Order=26)]
			public String InmateRecalcitrant { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("InmateonInmateViolenceProvoked", Order=27)]
			public String InmateonInmateViolenceProvoked { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("InmateonInmateViolence", Order=28)]
			public String InmateonInmateViolence { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("MultiPointRestraintsUsed", Order=29)]
			public String MultiPointRestraintsUsed { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("OthertypesofRestraints", Order=30)]
			public String OthertypesofRestraints { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("MedicalRecordschecked", Order=31)]
			public String MedicalRecordschecked { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("MedicalRestraintsUsed", Order=32)]
			public String MedicalRestraintsUsed { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("forceusedasDiscipline", Order=33)]
			public String ForceusedasDiscipline { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("CorporalPunishment", Order=34)]
			public String CorporalPunishment { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("cellExtraction", Order=35)]
			public String CellExtraction { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("Extractionordered", Order=36)]
			public String Extractionordered { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("InmateHarassed", Order=37)]
			public String InmateHarassed { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("SuspectInterviewedAwayfromInmates", Order=38)]
			public String SuspectInterviewedAwayfromInmates { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("TransorRefuse", Order=39)]
			public String TransorRefuse { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("OtherplannedUoF", Order=40)]
			public String OtherplannedUoF { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("UnderInfluence", Order=41)]
			public String UnderInfluence { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("Substance", Order=42)]
			public String Substance { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("factorinForce", Order=43)]
			public String FactorinForce { get; set;}

			[DataMember]
			[StringLength(100)]
			[Column("LOCATIONOFFORCE", Order=44)]
			public String LOCATIONOFFORCE { get; set;}

			[DataMember]
			[StringLength(100)]
			[Column("FORCEUSED", Order=45)]
			public String FORCEUSED { get; set;}

			[DataMember]
			[StringLength(5)]
			[Column("PPhMode", Order=46)]
			public String PPhMode { get; set;}

			[DataMember]
			[StringLength(5)]
			[Column("SPhMode", Order=47)]
			public String SPhMode { get; set;}

			[DataMember]
			[StringLength(15)]
			[Column("CoronerCaseNumber", Order=48)]
			public String CoronerCaseNumber { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsMentalHistory", Order=49)]
			public String IsMentalHistory { get; set;}

			[DataMember]
			[StringLength(100)]
			[Column("SuspectConfArmedOther", Order=50)]
			public String SuspectConfArmedOther { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IspregnantInmate", Order=51)]
			public String IspregnantInmate { get; set;}

			[DataMember]
			[StringLength(100)]
			[Column("SpecialHandling", Order=52)]
			public String SpecialHandling { get; set;}

			[DataMember]
			[StringLength(100)]
			[Column("SecurityLevel", Order=53)]
			public String SecurityLevel { get; set;}

			[DataMember]
			[ForeignKey("IncidentUserId")]
			public IncidentUser IncidentUser { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("IncidentUserWitness", Schema="dbo")]
		public partial class IncidentUserWitnes 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("IncidentUserWitnessId", Order=0)]
			public Int32 IncidentUserWitnessId { get; set;}

			[DataMember]
			[Column("IncidentUserId", Order=1)]
			public Int32? IncidentUserId { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsWitness", Order=2)]
			public String IsWitness { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsPresent", Order=3)]
			public String IsPresent { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("WitnessIntAwayfromInmates", Order=4)]
			public String WitnessIntAwayfromInmates { get; set;}

			[DataMember]
			[StringLength(5)]
			[Column("ShiftType", Order=5)]
			public String ShiftType { get; set;}

			[DataMember]
			[StringLength(3)]
			[Column("InmateType", Order=6)]
			public String InmateType { get; set;}

			[DataMember]
			[StringLength(3)]
			[Column("TransorRefuse", Order=7)]
			public String TransorRefuse { get; set;}

			[DataMember]
			[ForeignKey("IncidentUserId")]
			public IncidentUser IncidentUser { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("Treatment", Schema="dbo")]
		public partial class Treatment 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("TreatmentId", Order=0)]
			public Int32 TreatmentId { get; set;}

			[DataMember]
			[Column("HospitalId", Order=1)]
			public Int32? HospitalId { get; set;}

			[DataMember]
			[Column("AddressId", Order=2)]
			public Int32? AddressId { get; set;}

			[DataMember]
			[StringLength(15)]
			[Column("TreatedBy", Order=3)]
			public String TreatedBy { get; set;}

			[DataMember]
			[StringLength(15)]
			[Column("TreatedUnit", Order=4)]
			public String TreatedUnit { get; set;}

			[DataMember]
			[StringLength(15)]
			[Column("CoronerCaseNumber", Order=5)]
			public String CoronerCaseNumber { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsMentalHistory", Order=6)]
			public String IsMentalHistory { get; set;}

			[DataMember]
			[StringLength(15)]
			[Column("PhoneNumber", Order=7)]
			public String PhoneNumber { get; set;}

			[DataMember]
			[Column("IncidentUserSuspectId", Order=8)]
			public Int32? IncidentUserSuspectId { get; set;}

			[DataMember]
			[ForeignKey("AddressId")]
			public Addres Address { get; set;}

			[DataMember]
			[ForeignKey("IncidentUserSuspectId")]
			public IncidentUserSuspect IncidentUserSuspect { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("User", Schema="dbo")]
		public partial class User 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("UserId", Order=0)]
			public Int32 UserId { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("ForceEmployeeId", Order=1)]
			public String ForceEmployeeId { get; set;}

			[DataMember]
			[Required]
			[Column("UserDetailId", Order=2)]
			public Int32 UserDetailId { get; set;}

			[DataMember]
			[Required]
			[Column("UserTypeId", Order=3)]
			public Int32 UserTypeId { get; set;}

			[DataMember]
			[Required]
			[Column("Active", Order=4)]
			public Boolean Active { get; set;}

			[DataMember]
			[ForeignKey("UserDetailId")]
			public UserDetail UserDetail { get; set;}

			[DataMember]
			[ForeignKey("UserTypeId")]
			public UserType UserType { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("UserAddress", Schema="dbo")]
		public partial class UserAddres 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("UserAddressId", Order=0)]
			public Int32 UserAddressId { get; set;}

			[DataMember]
			[Required]
			[Column("UserId", Order=1)]
			public Int32 UserId { get; set;}

			[DataMember]
			[Required]
			[Column("AddressId", Order=2)]
			public Int32 AddressId { get; set;}

			[DataMember]
			[ForeignKey("AddressId")]
			public Addres Address { get; set;}

			[DataMember]
			[ForeignKey("UserId")]
			public User User { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("UserContact", Schema="dbo")]
		public partial class UserContact 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("UserContactId", Order=0)]
			public Int32 UserContactId { get; set;}

			[DataMember]
			[Column("UserId", Order=1)]
			public Int32? UserId { get; set;}

			[DataMember]
			[Column("ContactId", Order=2)]
			public Int32? ContactId { get; set;}

			[DataMember]
			[ForeignKey("ContactId")]
			public Contact Contact { get; set;}

			[DataMember]
			[ForeignKey("UserId")]
			public User User { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("UserDetail", Schema="dbo")]
		public partial class UserDetail 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("UserDetailId", Order=0)]
			public Int32 UserDetailId { get; set;}

			[DataMember]
			[Required]
			[StringLength(150)]
			[Column("FirstName", Order=1)]
			public String FirstName { get; set;}

			[DataMember]
			[StringLength(150)]
			[Column("MiddleName", Order=2)]
			public String MiddleName { get; set;}

			[DataMember]
			[Required]
			[StringLength(150)]
			[Column("LastName", Order=3)]
			public String LastName { get; set;}

			[DataMember]
			[StringLength(250)]
			[Column("Rank", Order=4)]
			public String Rank { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("Sex", Order=5)]
			public String Sex { get; set;}

			[DataMember]
			[StringLength(50)]
			[Column("Race", Order=6)]
			public String Race { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("Dress", Order=7)]
			public String Dress { get; set;}

			[DataMember]
			[StringLength(50)]
			[Column("Height", Order=8)]
			public String Height { get; set;}

			[DataMember]
			[StringLength(50)]
			[Column("Weight", Order=9)]
			public String Weight { get; set;}

			[DataMember]
			[Column("Age", Order=10)]
			public Int32? Age { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("ShiftId", Order=11)]
			public String ShiftId { get; set;}

			[DataMember]
			[StringLength(150)]
			[Column("UnitOfAssignment", Order=12)]
			public String UnitOfAssignment { get; set;}

			[DataMember]
			[StringLength(250)]
			[Column("WorkAssignment", Order=13)]
			public String WorkAssignment { get; set;}

			[DataMember]
			[Column("DateOfBirth", Order=14)]
			public DateTime? DateOfBirth { get; set;}

			[DataMember]
			[StringLength(200)]
			[Column("EmailId", Order=15)]
			public String EmailId { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("UserType", Schema="dbo")]
		public partial class UserType 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("UserTypeId", Order=0)]
			public Int32 UserTypeId { get; set;}

			[DataMember]
			[Required]
			[StringLength(50)]
			[Column("TypeName", Order=1)]
			public String TypeName { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("InmateInjury", Schema="dbo")]
		public partial class InmateInjury 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("InmateInjuryId", Order=0)]
			public Int32 InmateInjuryId { get; set;}

			[DataMember]
			[Required]
			[Column("IncidentUserId", Order=1)]
			public Int32 IncidentUserId { get; set;}

			[DataMember]
			[Required]
			[Column("IncidentId", Order=2)]
			public Int32 IncidentId { get; set;}

			[DataMember]
			[Required]
			[Column("InmateInjuryXML", Order=3)]
			public String InmateInjuryXML { get; set;}

			[DataMember]
			[StringLength(50)]
			[Column("Status", Order=4)]
			public String Status { get; set;}

			[DataMember]
			[ForeignKey("IncidentId")]
			public Incident Incident { get; set;}

			[DataMember]
			[ForeignKey("IncidentUserId")]
			public IncidentUser IncidentUser { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("IncidentUserInvolved", Schema="dbo")]
		public partial class IncidentUserInvolved 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("IncidentUserInvolvedId", Order=0)]
			public Int32 IncidentUserInvolvedId { get; set;}

			[DataMember]
			[Column("IncidentUserId", Order=1)]
			public Int32? IncidentUserId { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("TypeOfForce", Order=2)]
			public String TypeOfForce { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("InjurySeverity", Order=3)]
			public String InjurySeverity { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("Isforecasting", Order=4)]
			public String Isforecasting { get; set;}

			[DataMember]
			[StringLength(250)]
			[Column("IndForceUsed", Order=5)]
			public String IndForceUsed { get; set;}

			[DataMember]
			[Column("IndividualCatId", Order=6)]
			public Int32? IndividualCatId { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsDirected", Order=7)]
			public String IsDirected { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("DirectedEmplId", Order=8)]
			public String DirectedEmplId { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsRescue", Order=9)]
			public String IsRescue { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsMedicalAssist", Order=10)]
			public String IsMedicalAssist { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsInjured", Order=11)]
			public String IsInjured { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsTreated", Order=12)]
			public String IsTreated { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsAdmitted", Order=13)]
			public String IsAdmitted { get; set;}

			[DataMember]
			[StringLength(250)]
			[Column("Facility", Order=14)]
			public String Facility { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("CoronerCaseId", Order=15)]
			public String CoronerCaseId { get; set;}

			[DataMember]
			[Column("DateOfBirth", Order=16)]
			public DateTime? DateOfBirth { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("EmployeeItemNumber", Order=17)]
			public String EmployeeItemNumber { get; set;}

			[DataMember]
			[Column("DepartmentHireDate", Order=18)]
			public DateTime? DepartmentHireDate { get; set;}

			[DataMember]
			[Column("LastPromotionDate", Order=19)]
			public DateTime? LastPromotionDate { get; set;}

			[DataMember]
			[Column("DepartmentTenureInDays", Order=20)]
			public Int32? DepartmentTenureInDays { get; set;}

			[DataMember]
			[Column("RankTenureIndays", Order=21)]
			public Int32? RankTenureIndays { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("IsEmployeeEscortSuspect", Order=22)]
			public String IsEmployeeEscortSuspect { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("DVERT", Order=23)]
			public String DVERT { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("InvolvementType", Order=24)]
			public String InvolvementType { get; set;}

			[DataMember]
			[StringLength(5)]
			[Column("ShiftType", Order=25)]
			public String ShiftType { get; set;}

			[DataMember]
			[ForeignKey("IncidentUserId")]
			public IncidentUser IncidentUser { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("UofForm", Schema="dbo")]
		public partial class UofForm 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("FormId", Order=0)]
			public Int32 FormId { get; set;}

			[DataMember]
			[Required]
			[Column("ParentId", Order=1)]
			public Int32 ParentId { get; set;}

			[DataMember]
			[Required]
			[StringLength(500)]
			[Column("FormName", Order=2)]
			public String FormName { get; set;}

			[DataMember]
			[Required]
			[StringLength(100)]
			[Column("FormCode", Order=3)]
			public String FormCode { get; set;}

			[DataMember]
			[StringLength(250)]
			[Column("Text", Order=4)]
			public String Text { get; set;}

			[DataMember]
			[StringLength(250)]
			[Column("Description", Order=5)]
			public String Description { get; set;}

			[DataMember]
			[StringLength(250)]
			[Column("ActionName", Order=6)]
			public String ActionName { get; set;}

			[DataMember]
			[StringLength(250)]
			[Column("ControllerName", Order=7)]
			public String ControllerName { get; set;}

			[DataMember]
			[Column("IsSettingItem", Order=8)]
			public Boolean? IsSettingItem { get; set;}

			[DataMember]
			[Column("IsMenuItem", Order=9)]
			public Boolean? IsMenuItem { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("UserRole", Schema="dbo")]
		public partial class UserRole 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("RoleId", Order=0)]
			public Int32 RoleId { get; set;}

			[DataMember]
			[Required]
			[StringLength(150)]
			[Column("RoleName", Order=1)]
			public String RoleName { get; set;}

			[DataMember]
			[Required]
			[StringLength(100)]
			[Column("RoleCode", Order=2)]
			public String RoleCode { get; set;}

			[DataMember]
			[StringLength(250)]
			[Column("Description", Order=3)]
			public String Description { get; set;}

			[DataMember]
			[Column("ReadOnly", Order=4)]
			public Boolean? ReadOnly { get; set;}

			[DataMember]
			[Column("Rank", Order=5)]
			public Int32? Rank { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("FormPermisssion", Schema="dbo")]
		public partial class FormPermisssion 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("FormPermissionId", Order=0)]
			public Int32 FormPermissionId { get; set;}

			[DataMember]
			[Required]
			[Column("RoleId", Order=1)]
			public Int32 RoleId { get; set;}

			[DataMember]
			[Required]
			[Column("FormId", Order=2)]
			public Int32 FormId { get; set;}

			[DataMember]
			[Required]
			[Column("IsViewOnly", Order=3)]
			public Boolean IsViewOnly { get; set;}

			[DataMember]
			[ForeignKey("FormId")]
			public UofForm Form { get; set;}

			[DataMember]
			[ForeignKey("RoleId")]
			public UserRole Role { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("IncidentCategoryForm", Schema="dbo")]
		public partial class IncidentCategoryForm 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("CategoryFormID", Order=0)]
			public Int32 CategoryFormID { get; set;}

			[DataMember]
			[Required]
			[Column("IncidentID", Order=1)]
			public Int32 IncidentID { get; set;}

			[DataMember]
			[Required]
			[Column("IncidentCategoryId", Order=2)]
			public Int32 IncidentCategoryId { get; set;}

			[DataMember]
			[Required]
			[Column("FormID", Order=3)]
			public Int32 FormID { get; set;}

			[DataMember]
			[Required]
			[StringLength(5)]
			[Column("Status", Order=4)]
			public String Status { get; set;}

			[DataMember]
			[ForeignKey("IncidentID")]
			public Incident Incident { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("IncidentFormData", Schema="dbo")]
		public partial class IncidentFormData 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("FormDataID", Order=0)]
			public Int32 FormDataID { get; set;}

			[DataMember]
			[Column("IncidentID", Order=1)]
			public Int32? IncidentID { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("EmpID", Order=2)]
			public String EmpID { get; set;}

			[DataMember]
			[Required]
			[Column("FormID", Order=3)]
			public Int32 FormID { get; set;}

			[DataMember]
			[Required]
			[Column("UserRoleId", Order=4)]
			public Int32 UserRoleId { get; set;}

			[DataMember]
			[Column("XmlData", Order=5)]
			public String XmlData { get; set;}

			[DataMember]
			[Column("CreatedOn", Order=6)]
			public DateTime? CreatedOn { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("CreatedBy", Order=7)]
			public String CreatedBy { get; set;}

			[DataMember]
			[Column("UpdateOn", Order=8)]
			public DateTime? UpdateOn { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("UpdateBy", Order=9)]
			public String UpdateBy { get; set;}

			[DataMember]
			[Required]
			[StringLength(25)]
			[Column("Status", Order=10)]
			public String Status { get; set;}

			[DataMember]
			[ForeignKey("FormID")]
			public UofForm Form { get; set;}

			[DataMember]
			[ForeignKey("UserRoleId")]
			public UserRole UserRole { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("LookupBodyPart", Schema="dbo")]
		public partial class LookupBodyPart 
		{
			[DataMember]
			[Required]
			[Column("ID", Order=0)]
			public Int32 ID { get; set;}

			[DataMember]
			[Required]
			[StringLength(10)]
			[Column("BodyPartCode", Order=1)]
			public String BodyPartCode { get; set;}

			[DataMember]
			[Required]
			[StringLength(100)]
			[Column("BodyPartName", Order=2)]
			public String BodyPartName { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("LookupInjury", Schema="dbo")]
		public partial class LookupInjury 
		{
			[DataMember]
			[Required]
			[Column("ID", Order=0)]
			public Int32 ID { get; set;}

			[DataMember]
			[Required]
			[StringLength(10)]
			[Column("InjuryCode", Order=1)]
			public String InjuryCode { get; set;}

			[DataMember]
			[Required]
			[StringLength(100)]
			[Column("InjuryName", Order=2)]
			public String InjuryName { get; set;}

			[DataMember]
			[StringLength(2)]
			[Column("Type", Order=3)]
			public String Type { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("LookupMethod", Schema="dbo")]
		public partial class LookupMethod 
		{
			[DataMember]
			[Required]
			[Column("ID", Order=0)]
			public Int32 ID { get; set;}

			[DataMember]
			[Required]
			[StringLength(10)]
			[Column("MethodCode", Order=1)]
			public String MethodCode { get; set;}

			[DataMember]
			[StringLength(100)]
			[Column("MethodName", Order=2)]
			public String MethodName { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("UofChildForm", Schema="dbo")]
		public partial class UofChildForm 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("ChildFormId", Order=0)]
			public Int32 ChildFormId { get; set;}

			[DataMember]
			[Required]
			[StringLength(250)]
			[Column("ChildFormName", Order=1)]
			public String ChildFormName { get; set;}

			[DataMember]
			[Required]
			[StringLength(250)]
			[Column("ChildFormCode", Order=2)]
			public String ChildFormCode { get; set;}

			[DataMember]
			[StringLength(500)]
			[Column("ChildFormDescription", Order=3)]
			public String ChildFormDescription { get; set;}

			[DataMember]
			[Required]
			[Column("FormId", Order=4)]
			public Int32 FormId { get; set;}

			[DataMember]
			[ForeignKey("FormId")]
			public UofForm Form { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("IncidentStatisticalData", Schema="dbo")]
		public partial class IncidentStatisticalData 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("IncidentUserForceId", Order=0)]
			public Int32 IncidentUserForceId { get; set;}

			[DataMember]
			[Required]
			[Column("IncidentId", Order=1)]
			public Int32 IncidentId { get; set;}

			[DataMember]
			[Required]
			[StringLength(20)]
			[Column("IncidentUsedBy", Order=2)]
			public String IncidentUsedBy { get; set;}

			[DataMember]
			[Required]
			[StringLength(20)]
			[Column("IncidentAgainstBy", Order=3)]
			public String IncidentAgainstBy { get; set;}

			[DataMember]
			[Required]
			[StringLength(50)]
			[Column("Method", Order=4)]
			public String Method { get; set;}

			[DataMember]
			[Required]
			[StringLength(50)]
			[Column("InjuryType", Order=5)]
			public String InjuryType { get; set;}

			[DataMember]
			[Required]
			[StringLength(50)]
			[Column("BodyPartInvolved", Order=6)]
			public String BodyPartInvolved { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("CreatedBy", Order=7)]
			public String CreatedBy { get; set;}

			[DataMember]
			[Column("CreatedOn", Order=8)]
			public DateTime? CreatedOn { get; set;}

			[DataMember]
			[Column("IsDeleted", Order=9)]
			public Boolean? IsDeleted { get; set;}

			[DataMember]
			[ForeignKey("IncidentId")]
			public Incident Incident { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("LookupCity", Schema="dbo")]
		public partial class LookupCity 
		{
			[DataMember]
			[Required]
			[Column("ID", Order=0)]
			public Int32 ID { get; set;}

			[DataMember]
			[Required]
			[StringLength(5)]
			[Column("Code", Order=1)]
			public String Code { get; set;}

			[DataMember]
			[Required]
			[StringLength(100)]
			[Column("Name", Order=2)]
			public String Name { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("LookupContactType", Schema="dbo")]
		public partial class LookupContactType 
		{
			[DataMember]
			[Required]
			[Column("ID", Order=0)]
			public Int32 ID { get; set;}

			[DataMember]
			[Required]
			[StringLength(5)]
			[Column("Code", Order=1)]
			public String Code { get; set;}

			[DataMember]
			[Required]
			[StringLength(100)]
			[Column("Name", Order=2)]
			public String Name { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("LookupCustodyEvent", Schema="dbo")]
		public partial class LookupCustodyEvent 
		{
			[DataMember]
			[Required]
			[Column("ID", Order=0)]
			public Int32 ID { get; set;}

			[DataMember]
			[Required]
			[StringLength(5)]
			[Column("Code", Order=1)]
			public String Code { get; set;}

			[DataMember]
			[Required]
			[StringLength(100)]
			[Column("Name", Order=2)]
			public String Name { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("LookupDress", Schema="dbo")]
		public partial class LookupDres 
		{
			[DataMember]
			[Required]
			[Column("ID", Order=0)]
			public Int32 ID { get; set;}

			[DataMember]
			[Required]
			[StringLength(5)]
			[Column("Code", Order=1)]
			public String Code { get; set;}

			[DataMember]
			[Required]
			[StringLength(100)]
			[Column("Name", Order=2)]
			public String Name { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("LookupFacility", Schema="dbo")]
		public partial class LookupFacility 
		{
			[DataMember]
			[Required]
			[Column("ID", Order=0)]
			public Int32 ID { get; set;}

			[DataMember]
			[Required]
			[StringLength(5)]
			[Column("Code", Order=1)]
			public String Code { get; set;}

			[DataMember]
			[Required]
			[StringLength(100)]
			[Column("Name", Order=2)]
			public String Name { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("LookupInjurySeverity", Schema="dbo")]
		public partial class LookupInjurySeverity 
		{
			[DataMember]
			[Required]
			[Column("ID", Order=0)]
			public Int32 ID { get; set;}

			[DataMember]
			[Required]
			[StringLength(5)]
			[Column("Code", Order=1)]
			public String Code { get; set;}

			[DataMember]
			[Required]
			[StringLength(100)]
			[Column("Name", Order=2)]
			public String Name { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("LookupLocationofForce", Schema="dbo")]
		public partial class LookupLocationofForce 
		{
			[DataMember]
			[Required]
			[Column("ID", Order=0)]
			public Int32 ID { get; set;}

			[DataMember]
			[Required]
			[StringLength(5)]
			[Column("Code", Order=1)]
			public String Code { get; set;}

			[DataMember]
			[Required]
			[StringLength(100)]
			[Column("Name", Order=2)]
			public String Name { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("LookupPerceivedArmed", Schema="dbo")]
		public partial class LookupPerceivedArmed 
		{
			[DataMember]
			[Required]
			[Column("ID", Order=0)]
			public Int32 ID { get; set;}

			[DataMember]
			[Required]
			[StringLength(5)]
			[Column("Code", Order=1)]
			public String Code { get; set;}

			[DataMember]
			[Required]
			[StringLength(100)]
			[Column("Name", Order=2)]
			public String Name { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("LookupRace", Schema="dbo")]
		public partial class LookupRace 
		{
			[DataMember]
			[Required]
			[Column("ID", Order=0)]
			public Int32 ID { get; set;}

			[DataMember]
			[Required]
			[StringLength(5)]
			[Column("Code", Order=1)]
			public String Code { get; set;}

			[DataMember]
			[Required]
			[StringLength(100)]
			[Column("Name", Order=2)]
			public String Name { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("LookupResistance", Schema="dbo")]
		public partial class LookupResistance 
		{
			[DataMember]
			[Required]
			[Column("ID", Order=0)]
			public Int32 ID { get; set;}

			[DataMember]
			[Required]
			[StringLength(5)]
			[Column("Code", Order=1)]
			public String Code { get; set;}

			[DataMember]
			[Required]
			[StringLength(100)]
			[Column("Name", Order=2)]
			public String Name { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("LookupSex", Schema="dbo")]
		public partial class LookupSex 
		{
			[DataMember]
			[Required]
			[Column("ID", Order=0)]
			public Int32 ID { get; set;}

			[DataMember]
			[Required]
			[StringLength(5)]
			[Column("Code", Order=1)]
			public String Code { get; set;}

			[DataMember]
			[Required]
			[StringLength(100)]
			[Column("Name", Order=2)]
			public String Name { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("LookupSubstance", Schema="dbo")]
		public partial class LookupSubstance 
		{
			[DataMember]
			[Required]
			[Column("ID", Order=0)]
			public Int32 ID { get; set;}

			[DataMember]
			[Required]
			[StringLength(5)]
			[Column("Code", Order=1)]
			public String Code { get; set;}

			[DataMember]
			[Required]
			[StringLength(100)]
			[Column("Name", Order=2)]
			public String Name { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("LookupArmed", Schema="dbo")]
		public partial class LookupArmed 
		{
			[DataMember]
			[Required]
			[Column("ID", Order=0)]
			public Int32 ID { get; set;}

			[DataMember]
			[Required]
			[StringLength(7)]
			[Column("Code", Order=1)]
			public String Code { get; set;}

			[DataMember]
			[Required]
			[StringLength(100)]
			[Column("Name", Order=2)]
			public String Name { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("LookupConfirmedArmed", Schema="dbo")]
		public partial class LookupConfirmedArmed 
		{
			[DataMember]
			[Required]
			[Column("ID", Order=0)]
			public Int32 ID { get; set;}

			[DataMember]
			[Required]
			[StringLength(5)]
			[Column("Code", Order=1)]
			public String Code { get; set;}

			[DataMember]
			[Required]
			[StringLength(100)]
			[Column("Name", Order=2)]
			public String Name { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("IncidentWorkflow", Schema="dbo")]
		public partial class IncidentWorkflow 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("WorkflowId", Order=0)]
			public Int32 WorkflowId { get; set;}

			[DataMember]
			[Required]
			[Column("IncidentId", Order=1)]
			public Int32 IncidentId { get; set;}

			[DataMember]
			[Required]
			[StringLength(20)]
			[Column("SergeantID", Order=2)]
			public String SergeantID { get; set;}

			[DataMember]
			[StringLength(25)]
			[Column("SergeantStatus", Order=3)]
			public String SergeantStatus { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("WCID", Order=4)]
			public String WCID { get; set;}

			[DataMember]
			[StringLength(25)]
			[Column("WCStatus", Order=5)]
			public String WCStatus { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("UCID", Order=6)]
			public String UCID { get; set;}

			[DataMember]
			[StringLength(25)]
			[Column("UCStatus", Order=7)]
			public String UCStatus { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("CFRCID", Order=8)]
			public String CFRCID { get; set;}

			[DataMember]
			[StringLength(25)]
			[Column("CFRCStatus", Order=9)]
			public String CFRCStatus { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("CFRTID", Order=10)]
			public String CFRTID { get; set;}

			[DataMember]
			[StringLength(25)]
			[Column("CFRTStatus", Order=11)]
			public String CFRTStatus { get; set;}

			[DataMember]
			[StringLength(25)]
			[Column("CMID", Order=12)]
			public String CMID { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("CMStatus", Order=13)]
			public String CMStatus { get; set;}

			[DataMember]
			[StringLength(25)]
			[Column("DCID", Order=14)]
			public String DCID { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("DCStatus", Order=15)]
			public String DCStatus { get; set;}

			[DataMember]
			[StringLength(25)]
			[Column("DeputyStatus", Order=16)]
			public String DeputyStatus { get; set;}

			[DataMember]
			[ForeignKey("IncidentId")]
			public Incident Incident { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("IncidentFormReview", Schema="dbo")]
		public partial class IncidentFormReview 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("IncidentReviewID", Order=0)]
			public Int32 IncidentReviewID { get; set;}

			[DataMember]
			[Required]
			[Column("IncidentID", Order=1)]
			public Int32 IncidentID { get; set;}

			[DataMember]
			[Required]
			[Column("FormId", Order=2)]
			public Int32 FormId { get; set;}

			[DataMember]
			[StringLength(25)]
			[Column("InvolvedId", Order=3)]
			public String InvolvedId { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("InvolvedRole", Order=4)]
			public String InvolvedRole { get; set;}

			[DataMember]
			[StringLength(25)]
			[Column("SergeantId", Order=5)]
			public String SergeantId { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("ReviewerRole", Order=6)]
			public String ReviewerRole { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("SergeantStatus", Order=7)]
			public String SergeantStatus { get; set;}

			[DataMember]
			[StringLength(25)]
			[Column("WCID", Order=8)]
			public String WCID { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("WCStatus", Order=9)]
			public String WCStatus { get; set;}

			[DataMember]
			[StringLength(25)]
			[Column("UCID", Order=10)]
			public String UCID { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("UCStatus", Order=11)]
			public String UCStatus { get; set;}

			[DataMember]
			[StringLength(25)]
			[Column("CMID", Order=12)]
			public String CMID { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("CMStatus", Order=13)]
			public String CMStatus { get; set;}

			[DataMember]
			[StringLength(25)]
			[Column("CFRTID", Order=14)]
			public String CFRTID { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("CFRTStatus", Order=15)]
			public String CFRTStatus { get; set;}

			[DataMember]
			[StringLength(25)]
			[Column("CFRCID", Order=16)]
			public String CFRCID { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("CFRCStatus", Order=17)]
			public String CFRCStatus { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("InvolvedStatus", Order=18)]
			public String InvolvedStatus { get; set;}

			[DataMember]
			[Column("FormDataID", Order=19)]
			public Int32? FormDataID { get; set;}

			[DataMember]
			[StringLength(25)]
			[Column("DCID", Order=20)]
			public String DCID { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("DCStatus", Order=21)]
			public String DCStatus { get; set;}

			[DataMember]
			[ForeignKey("IncidentID")]
			public Incident Incident { get; set;}

			[DataMember]
			[ForeignKey("FormId")]
			public UofForm Form { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("DigitalSignatures", Schema="dbo")]
		public partial class DigitalSignature 
		{
			[DataMember]
			[Required]
			[Column("SignatureId", Order=0)]
			public Int32 SignatureId { get; set;}

			[DataMember]
			[Required]
			[StringLength(25)]
			[Column("EmployeeNumber", Order=1)]
			public String EmployeeNumber { get; set;}

			[DataMember]
			[Required]
			[Column("Signature", Order=2)]
			public Byte[] Signature { get; set;}

			[DataMember]
			[Required]
			[StringLength(20)]
			[Column("Status", Order=3)]
			public String Status { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("EmailNotifications", Schema="dbo")]
		public partial class EmailNotification 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("EmailNotificationId", Order=0)]
			public Int32 EmailNotificationId { get; set;}

			[DataMember]
			[Required]
			[Column("IncidentId", Order=1)]
			public Int32 IncidentId { get; set;}

			[DataMember]
			[StringLength(25)]
			[Column("EmployeeNumber", Order=2)]
			public String EmployeeNumber { get; set;}

			[DataMember]
			[StringLength(100)]
			[Column("Department", Order=3)]
			public String Department { get; set;}

			[DataMember]
			[Required]
			[StringLength(250)]
			[Column("EmailId", Order=4)]
			public String EmailId { get; set;}

			[DataMember]
			[Column("Sent", Order=5)]
			public Boolean? Sent { get; set;}

			[DataMember]
			[Column("Responded", Order=6)]
			public Boolean? Responded { get; set;}

			[DataMember]
			[Required]
			[Column("SentOn", Order=7)]
			public DateTime SentOn { get; set;}

			[DataMember]
			[Column("RespondedOn", Order=8)]
			public DateTime? RespondedOn { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("Status", Order=9)]
			public String Status { get; set;}

			[DataMember]
			[ForeignKey("IncidentId")]
			public Incident Incident { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("ReturnComments", Schema="dbo")]
		public partial class ReturnComment 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("ReturnId", Order=0)]
			public Int32 ReturnId { get; set;}

			[DataMember]
			[Required]
			[Column("IncidentReviewID", Order=1)]
			public Int32 IncidentReviewID { get; set;}

			[DataMember]
			[StringLength(25)]
			[Column("EmployeeNumber", Order=2)]
			public String EmployeeNumber { get; set;}

			[DataMember]
			[Column("Comments", Order=3)]
			public String Comments { get; set;}

			[DataMember]
			[Column("CreatedOn", Order=4)]
			public DateTime? CreatedOn { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("Updatedby", Order=5)]
			public String Updatedby { get; set;}

			[DataMember]
			[Column("UpdatedOn", Order=6)]
			public DateTime? UpdatedOn { get; set;}

			[DataMember]
			[StringLength(10)]
			[Column("Status", Order=7)]
			public String Status { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("CreatedBy", Order=8)]
			public String CreatedBy { get; set;}

			[DataMember]
			[ForeignKey("IncidentReviewID")]
			public IncidentFormReview IncidentReview { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("ReviewComments", Schema="dbo")]
		public partial class ReviewComment 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("ReviewCommentId", Order=0)]
			public Int32 ReviewCommentId { get; set;}

			[DataMember]
			[Required]
			[Column("IncidentId", Order=1)]
			public Int32 IncidentId { get; set;}

			[DataMember]
			[Required]
			[Column("FormId", Order=2)]
			public Int32 FormId { get; set;}

			[DataMember]
			[Required]
			[Column("ReviewComments", Order=3)]
			public String ReviewComments { get; set;}

			[DataMember]
			[Required]
			[StringLength(25)]
			[Column("CommentedBy", Order=4)]
			public String CommentedBy { get; set;}

			[DataMember]
			[StringLength(25)]
			[Column("AddressedBy", Order=5)]
			public String AddressedBy { get; set;}

			[DataMember]
			[Required]
			[Column("CreatedOn", Order=6)]
			public DateTime CreatedOn { get; set;}

			[DataMember]
			[Required]
			[StringLength(10)]
			[Column("Status", Order=7)]
			public String Status { get; set;}

			[DataMember]
			[ForeignKey("IncidentId")]
			public Incident Incident { get; set;}

			[DataMember]
			[ForeignKey("FormId")]
			public UofForm Form { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("IncidentSergeant", Schema="dbo")]
		public partial class IncidentSergeant 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("AddlSergeantId", Order=0)]
			public Int32 AddlSergeantId { get; set;}

			[DataMember]
			[Required]
			[Column("IncidentId", Order=1)]
			public Int32 IncidentId { get; set;}

			[DataMember]
			[Required]
			[StringLength(25)]
			[Column("EmployeeNumber", Order=2)]
			public String EmployeeNumber { get; set;}

			[DataMember]
			[Required]
			[StringLength(150)]
			[Column("Name", Order=3)]
			public String Name { get; set;}

			[DataMember]
			[Required]
			[StringLength(10)]
			[Column("SergeantType", Order=4)]
			public String SergeantType { get; set;}

			[DataMember]
			[Required]
			[StringLength(25)]
			[Column("CreatedBy", Order=5)]
			public String CreatedBy { get; set;}

			[DataMember]
			[Required]
			[Column("CreatedOn", Order=6)]
			public DateTime CreatedOn { get; set;}

			[DataMember]
			[ForeignKey("IncidentId")]
			public Incident Incident { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("IncidentCFRTFlow", Schema="dbo")]
		public partial class IncidentCFRTFlow 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("ID", Order=0)]
			public Int32 ID { get; set;}

			[DataMember]
			[Required]
			[Column("IncidentId", Order=1)]
			public Int32 IncidentId { get; set;}

			[DataMember]
			[Required]
			[StringLength(25)]
			[Column("CFRTID", Order=2)]
			public String CFRTID { get; set;}

			[DataMember]
			[Required]
			[StringLength(25)]
			[Column("CFRCID", Order=3)]
			public String CFRCID { get; set;}

			[DataMember]
			[Required]
			[StringLength(200)]
			[Column("CRFCEmailId", Order=4)]
			public String CRFCEmailId { get; set;}

			[DataMember]
			[Required]
			[StringLength(20)]
			[Column("CRFCStatus", Order=5)]
			public String CRFCStatus { get; set;}

			[DataMember]
			[Required]
			[StringLength(25)]
			[Column("CreatedBy", Order=6)]
			public String CreatedBy { get; set;}

			[DataMember]
			[Required]
			[Column("CreatedOn", Order=7)]
			public DateTime CreatedOn { get; set;}

			[DataMember]
			[ForeignKey("IncidentId")]
			public Incident Incident { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("IncidentBusinessAddress", Schema="dbo")]
		public partial class IncidentBusinessAddres 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("IncidentBusinessID", Order=0)]
			public Int32 IncidentBusinessID { get; set;}

			[DataMember]
			[Required]
			[Column("IncidentID", Order=1)]
			public Int32 IncidentID { get; set;}

			[DataMember]
			[StringLength(50)]
			[Column("Name", Order=2)]
			public String Name { get; set;}

			[DataMember]
			[Required]
			[StringLength(10)]
			[Column("AddressNumber", Order=3)]
			public String AddressNumber { get; set;}

			[DataMember]
			[StringLength(50)]
			[Column("Street", Order=4)]
			public String Street { get; set;}

			[DataMember]
			[StringLength(50)]
			[Column("City", Order=5)]
			public String City { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("Zip", Order=6)]
			public String Zip { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("CreatedBy", Order=7)]
			public String CreatedBy { get; set;}

			[DataMember]
			[Column("CreatedOn", Order=8)]
			public DateTime? CreatedOn { get; set;}

			[DataMember]
			[ForeignKey("IncidentID")]
			public Incident Incident { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("LookupStation", Schema="dbo")]
		public partial class LookupStation 
		{
			[DataMember]
			[Required]
			[Column("ID", Order=0)]
			public Int32 ID { get; set;}

			[DataMember]
			[Required]
			[StringLength(5)]
			[Column("Code", Order=1)]
			public String Code { get; set;}

			[DataMember]
			[Required]
			[StringLength(100)]
			[Column("Name", Order=2)]
			public String Name { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("LookupStaging", Schema="dbo")]
		public partial class LookupStaging 
		{
			[DataMember]
			[Required]
			[Column("ID", Order=0)]
			public Int32 ID { get; set;}

			[DataMember]
			[StringLength(10)]
			[Column("Code", Order=1)]
			public String Code { get; set;}

			[DataMember]
			[StringLength(50)]
			[Column("Name", Order=2)]
			public String Name { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("LookupBureaus", Schema="dbo")]
		public partial class LookupBureau 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("ID", Order=0)]
			public Int32 ID { get; set;}

			[DataMember]
			[Required]
			[StringLength(20)]
			[Column("Identifier", Order=1)]
			public String Identifier { get; set;}

			[DataMember]
			[Required]
			[StringLength(200)]
			[Column("Name", Order=2)]
			public String Name { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("LookupSpecialHandle", Schema="dbo")]
		public partial class LookupSpecialHandle 
		{
			[DataMember]
			[Required]
			[Column("ID", Order=0)]
			public Int32 ID { get; set;}

			[DataMember]
			[Required]
			[StringLength(5)]
			[Column("Code", Order=1)]
			public String Code { get; set;}

			[DataMember]
			[Required]
			[StringLength(100)]
			[Column("Name", Order=2)]
			public String Name { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("LookupSecurityLevel", Schema="dbo")]
		public partial class LookupSecurityLevel 
		{
			[DataMember]
			[Required]
			[Column("ID", Order=0)]
			public Int32 ID { get; set;}

			[DataMember]
			[Required]
			[StringLength(5)]
			[Column("Code", Order=1)]
			public String Code { get; set;}

			[DataMember]
			[Required]
			[StringLength(100)]
			[Column("Name", Order=2)]
			public String Name { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("LookupInmateDress", Schema="dbo")]
		public partial class LookupInmateDres 
		{
			[DataMember]
			[Required]
			[Column("ID", Order=0)]
			public Int32 ID { get; set;}

			[DataMember]
			[Required]
			[StringLength(5)]
			[Column("Code", Order=1)]
			public String Code { get; set;}

			[DataMember]
			[Required]
			[StringLength(100)]
			[Column("Name", Order=2)]
			public String Name { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("FormApprovalorReject", Schema="dbo")]
		public partial class FormApprovalorReject 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("ApprovalId", Order=0)]
			public Int32 ApprovalId { get; set;}

			[DataMember]
			[Required]
			[Column("IncidentId", Order=1)]
			public Int32 IncidentId { get; set;}

			[DataMember]
			[Required]
			[Column("FormId", Order=2)]
			public Int32 FormId { get; set;}

			[DataMember]
			[StringLength(10)]
			[Column("ApproverRole", Order=3)]
			public String ApproverRole { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("ActionBy", Order=4)]
			public String ActionBy { get; set;}

			[DataMember]
			[StringLength(50)]
			[Column("Name", Order=5)]
			public String Name { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("FormFilledBy", Order=6)]
			public String FormFilledBy { get; set;}

			[DataMember]
			[Column("IsApproved", Order=7)]
			public Boolean? IsApproved { get; set;}

			[DataMember]
			[Column("ActionDate", Order=8)]
			public DateTime? ActionDate { get; set;}

			[DataMember]
			[Column("CreatedDate", Order=9)]
			public DateTime? CreatedDate { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("EmployeeNo", Order=10)]
			public String EmployeeNo { get; set;}

			[DataMember]
			[StringLength(50)]
			[Column("Assignment", Order=11)]
			public String Assignment { get; set;}

			[DataMember]
			[StringLength(50)]
			[Column("SRD", Order=12)]
			public String SRD { get; set;}

			[DataMember]
			[Column("Active", Order=13)]
			public Boolean? Active { get; set;}

			[DataMember]
			[ForeignKey("IncidentId")]
			public Incident Incident { get; set;}

			[DataMember]
			[ForeignKey("FormId")]
			public UofForm Form { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("IncidentFormExplaination", Schema="dbo")]
		public partial class IncidentFormExplaination 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("FormExplainationID", Order=0)]
			public Int32 FormExplainationID { get; set;}

			[DataMember]
			[Required]
			[Column("IncidentID", Order=1)]
			public Int32 IncidentID { get; set;}

			[DataMember]
			[Required]
			[Column("ExplanedOnFormID", Order=2)]
			public Int32 ExplanedOnFormID { get; set;}

			[DataMember]
			[Required]
			[Column("ExplanedFormID", Order=3)]
			public Int32 ExplanedFormID { get; set;}

			[DataMember]
			[Required]
			[Column("IncidentReviewId", Order=4)]
			public Int32 IncidentReviewId { get; set;}

			[DataMember]
			[Required]
			[StringLength(20)]
			[Column("RptId", Order=5)]
			public String RptId { get; set;}

			[DataMember]
			[Required]
			[StringLength(20)]
			[Column("RptStatus", Order=6)]
			public String RptStatus { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("UpdatedBy", Order=7)]
			public String UpdatedBy { get; set;}

			[DataMember]
			[Column("UpdatedOn", Order=8)]
			public DateTime? UpdatedOn { get; set;}

			[DataMember]
			[Required]
			[StringLength(20)]
			[Column("CreatedBy", Order=9)]
			public String CreatedBy { get; set;}

			[DataMember]
			[Required]
			[Column("CreatedOn", Order=10)]
			public DateTime CreatedOn { get; set;}

			[DataMember]
			[ForeignKey("IncidentID")]
			public Incident Incident { get; set;}

			[DataMember]
			[ForeignKey("ExplanedOnFormID")]
			public UofForm ExplanedOnForm { get; set;}

			[DataMember]
			[ForeignKey("ExplanedFormID")]
			public UofForm ExplanedForm { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("ArtifactsInformation", Schema="dbo")]
		public partial class ArtifactsInformation 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("ArtifactId", Order=0)]
			public Int32 ArtifactId { get; set;}

			[DataMember]
			[Required]
			[Column("IncidentId", Order=1)]
			public Int32 IncidentId { get; set;}

			[DataMember]
			[Required]
			[StringLength(300)]
			[Column("FileName", Order=2)]
			public String FileName { get; set;}

			[DataMember]
			[Required]
			[Column("UplodedDate", Order=3)]
			public DateTime UplodedDate { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("IncidentInvestigationOfficer", Schema="dbo")]
		public partial class IncidentInvestigationOfficer 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("InvestId", Order=0)]
			public Int32 InvestId { get; set;}

			[DataMember]
			[Required]
			[Column("IncidentId", Order=1)]
			public Int32 IncidentId { get; set;}

			[DataMember]
			[Required]
			[StringLength(20)]
			[Column("EmployeeId", Order=2)]
			public String EmployeeId { get; set;}

			[DataMember]
			[Required]
			[StringLength(20)]
			[Column("FirstName", Order=3)]
			public String FirstName { get; set;}

			[DataMember]
			[Required]
			[StringLength(20)]
			[Column("LastName", Order=4)]
			public String LastName { get; set;}

			[DataMember]
			[Required]
			[StringLength(20)]
			[Column("Rank", Order=5)]
			public String Rank { get; set;}

			[DataMember]
			[Required]
			[Column("IsLock", Order=6)]
			public Boolean IsLock { get; set;}

			[DataMember]
			[Required]
			[StringLength(10)]
			[Column("Status", Order=7)]
			public String Status { get; set;}

			[DataMember]
			[ForeignKey("IncidentId")]
			public Incident Incident { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("UoF_ChangeRole", Schema="dbo")]
		public partial class UoF_ChangeRole 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("RoleId", Order=0)]
			public Int32 RoleId { get; set;}

			[DataMember]
			[Required]
			[Column("IncidentId", Order=1)]
			public Int32 IncidentId { get; set;}

			[DataMember]
			[Required]
			[StringLength(20)]
			[Column("URN", Order=2)]
			public String URN { get; set;}

			[DataMember]
			[Required]
			[StringLength(20)]
			[Column("EmployeeId", Order=3)]
			public String EmployeeId { get; set;}

			[DataMember]
			[Required]
			[StringLength(50)]
			[Column("Name", Order=4)]
			public String Name { get; set;}

			[DataMember]
			[Required]
			[StringLength(50)]
			[Column("ForceRank", Order=5)]
			public String ForceRank { get; set;}

			[DataMember]
			[Required]
			[StringLength(50)]
			[Column("UoFRank", Order=6)]
			public String UoFRank { get; set;}

			[DataMember]
			[Required]
			[Column("ValidStill", Order=7)]
			public DateTime ValidStill { get; set;}

			[DataMember]
			[Required]
			[Column("Active", Order=8)]
			public Boolean Active { get; set;}

			[DataMember]
			[Required]
			[Column("CreatedOn", Order=9)]
			public DateTime CreatedOn { get; set;}

			[DataMember]
			[Required]
			[StringLength(20)]
			[Column("CreatedBy", Order=10)]
			public String CreatedBy { get; set;}

			[DataMember]
			[ForeignKey("IncidentId")]
			public Incident Incident { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("AT_ChangeOwner", Schema="dbo")]
		public partial class AT_ChangeOwner 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("OwnerId", Order=0)]
			public Int32 OwnerId { get; set;}

			[DataMember]
			[Required]
			[Column("IncidentId", Order=1)]
			public Int32 IncidentId { get; set;}

			[DataMember]
			[Required]
			[Column("FormId", Order=2)]
			public Int32 FormId { get; set;}

			[DataMember]
			[Required]
			[StringLength(20)]
			[Column("ExistingEmpId", Order=3)]
			public String ExistingEmpId { get; set;}

			[DataMember]
			[Required]
			[StringLength(20)]
			[Column("ChangedEmpId", Order=4)]
			public String ChangedEmpId { get; set;}

			[DataMember]
			[Required]
			[StringLength(20)]
			[Column("CreatedBy", Order=5)]
			public String CreatedBy { get; set;}

			[DataMember]
			[Required]
			[Column("CreatedOn", Order=6)]
			public DateTime CreatedOn { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("IncidentRank", Schema="dbo")]
		public partial class IncidentRank 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("IncidentRankId", Order=0)]
			public Int32 IncidentRankId { get; set;}

			[DataMember]
			[Required]
			[Column("IncidentId", Order=1)]
			public Int32 IncidentId { get; set;}

			[DataMember]
			[Required]
			[Column("Rank", Order=2)]
			public Int32 Rank { get; set;}

			[DataMember]
			[StringLength(20)]
			[Column("AssignedUserId", Order=3)]
			public String AssignedUserId { get; set;}

			[DataMember]
			[ForeignKey("IncidentId")]
			public Incident Incident { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("FormReviewRank", Schema="dbo")]
		public partial class FormReviewRank 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("ReviewRankId", Order=0)]
			public Int32 ReviewRankId { get; set;}

			[DataMember]
			[Required]
			[Column("FormId", Order=1)]
			public Int32 FormId { get; set;}

			[DataMember]
			[Required]
			[Column("ReviewRank", Order=2)]
			public Int32 ReviewRank { get; set;}

			[DataMember]
			[Required]
			[Column("Active", Order=3)]
			public Boolean Active { get; set;}

			[DataMember]
			[ForeignKey("FormId")]
			public UofForm Form { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("IncidentPackage", Schema="dbo")]
		public partial class IncidentPackage 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("PackageId", Order=0)]
			public Int32 PackageId { get; set;}

			[DataMember]
			[Required]
			[Column("IncidentId", Order=1)]
			public Int32 IncidentId { get; set;}

			[DataMember]
			[Required]
			[StringLength(20)]
			[Column("ExistingEmpId", Order=2)]
			public String ExistingEmpId { get; set;}

			[DataMember]
			[Required]
			[StringLength(20)]
			[Column("ChangedEmpId", Order=3)]
			public String ChangedEmpId { get; set;}

			[DataMember]
			[Required]
			[Column("UserTypeId", Order=4)]
			public Int32 UserTypeId { get; set;}

			[DataMember]
			[Required]
			[StringLength(20)]
			[Column("CreatedBy", Order=5)]
			public String CreatedBy { get; set;}

			[DataMember]
			[Required]
			[Column("CreatedDate", Order=6)]
			public DateTime CreatedDate { get; set;}

			[DataMember]
			[Required]
			[Column("Active", Order=7)]
			public Boolean Active { get; set;}

			[DataMember]
			[ForeignKey("IncidentId")]
			public Incident Incident { get; set;}

		}
 				
		[DataContract(IsReference=true)]
		[Table("IncidentMedicalUser", Schema="dbo")]
		public partial class IncidentMedicalUser 
		{
			[DataMember]
			[Required]
			[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
			[Column("MedicalId", Order=0)]
			public Int32 MedicalId { get; set;}

			[DataMember]
			[Required]
			[Column("IncidentId", Order=1)]
			public Int32 IncidentId { get; set;}

			[DataMember]
			[Required]
			[StringLength(20)]
			[Column("EmpId", Order=2)]
			public String EmpId { get; set;}

			[DataMember]
			[Required]
			[Column("FormId", Order=3)]
			public Int32 FormId { get; set;}

			[DataMember]
			[Required]
			[Column("CreatedDate", Order=4)]
			public DateTime CreatedDate { get; set;}

			[DataMember]
			[Required]
			[StringLength(20)]
			[Column("CreatedBy", Order=5)]
			public String CreatedBy { get; set;}

			[DataMember]
			[Required]
			[Column("Active", Order=6)]
			public Boolean Active { get; set;}

			[DataMember]
			[ForeignKey("IncidentId")]
			public Incident Incident { get; set;}

		}
	
}