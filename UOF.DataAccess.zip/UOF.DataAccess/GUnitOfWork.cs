﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Force_DL
{
    public class GUnitOfWork
    {
        USForceDbEntities _dbContext = new USForceDbEntities();

        public ForceRepository<IEntityType> GetResponse<IEntityType>() where IEntityType : class
        {
            return new ForceRepository<IEntityType>(_dbContext);
        }

        public void SaveChange()
        {
            _dbContext.SaveChanges();
        }
    }
}
