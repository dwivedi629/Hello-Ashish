GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ArtifactsInformation](
	[ArtifactId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NOT NULL,
	[FileName] [varchar](300) NOT NULL,
	[UplodedDate] [date] NOT NULL,
 CONSTRAINT [PK_ArtifactsInformation] PRIMARY KEY CLUSTERED 
(
	[ArtifactId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[ArtifactsInformation] ADD  CONSTRAINT [DF_ArtifactsInformation_UplodedDate]  DEFAULT (getdate()) FOR [UplodedDate]
GO

DECLARE @FormId Varchar(100)
SET @FormId = (Select FormId from UofForm where FormCode = 'ArtifactPermission')
IF(@FormId <= 0)
BEGIN
SET @FormId = (Select FormId from UofForm where FormCode = 'IncidentDetails')

INSERT INTO [dbo].[UofForm]
           ([ParentId]
           ,[FormName]
           ,[FormCode]
           ,[IsSettingItem]
           ,[IsMenuItem])
     VALUES
           (@FormId,'Artifacts','ArtifactPermission',1, 0)
END
Go
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentFormExplaination_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentFormExplaination]'))
ALTER TABLE [dbo].[IncidentFormExplaination] DROP CONSTRAINT [FK_IncidentFormExplaination_Incident]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentFormExplaination_UofForm]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentFormExplaination]'))
ALTER TABLE [dbo].[IncidentFormExplaination] DROP CONSTRAINT [FK_IncidentFormExplaination_UofForm]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentFormExplaination_UofForm1]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentFormExplaination]'))
ALTER TABLE [dbo].[IncidentFormExplaination] DROP CONSTRAINT [FK_IncidentFormExplaination_UofForm1]
GO


GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IncidentFormExplaination]') AND type in (N'U'))
DROP TABLE [dbo].[IncidentFormExplaination]
GO


GO

/****** Object:  Table [dbo].[IncidentFormExplaination]    Script Date: 03/19/2017 02:00:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[IncidentFormExplaination](
	[FormExplainationID] [int] IDENTITY(1,1) NOT NULL,
	[IncidentID] [int] NOT NULL,
	[ExplanedOnFormID] [int] NOT NULL,
	[ExplanedFormID] [int] NOT NULL,
	[RptId] [varchar](20) NOT NULL,
	[RptStatus] [varchar](20) NOT NULL,
	[UpdatedBy] [varchar](20) NULL,
	[UpdatedOn] [datetime] NULL,
	[CreatedBy] [varchar](20) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
 CONSTRAINT [PK_IncidentFormExplaination] PRIMARY KEY CLUSTERED 
(
	[FormExplainationID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[IncidentFormExplaination]  WITH CHECK ADD  CONSTRAINT [FK_IncidentFormExplaination_Incident] FOREIGN KEY([IncidentID])
REFERENCES [dbo].[Incident] ([IncidentId])
GO

ALTER TABLE [dbo].[IncidentFormExplaination] CHECK CONSTRAINT [FK_IncidentFormExplaination_Incident]
GO

ALTER TABLE [dbo].[IncidentFormExplaination]  WITH CHECK ADD  CONSTRAINT [FK_IncidentFormExplaination_UofForm] FOREIGN KEY([ExplanedOnFormID])
REFERENCES [dbo].[UofForm] ([FormId])
GO

ALTER TABLE [dbo].[IncidentFormExplaination] CHECK CONSTRAINT [FK_IncidentFormExplaination_UofForm]
GO

ALTER TABLE [dbo].[IncidentFormExplaination]  WITH CHECK ADD  CONSTRAINT [FK_IncidentFormExplaination_UofForm1] FOREIGN KEY([ExplanedFormID])
REFERENCES [dbo].[UofForm] ([FormId])
GO

ALTER TABLE [dbo].[IncidentFormExplaination] CHECK CONSTRAINT [FK_IncidentFormExplaination_UofForm1]
GO

ALTER TABLE [dbo].[IncidentFormExplaination] CHECK CONSTRAINT [FK_IncidentFormExplaination_UofForm1]
GO
IF COL_LENGTH('IncidentFormReview','FormDataID') IS NULL
 BEGIN
 ALTER TABLE [dbo].[IncidentFormReview] ADD [FormDataID] int DEFAULT 0
 END
GO
IF COL_LENGTH('IncidentFormExplaination','IncidentReviewId') IS NULL
 BEGIN
 ALTER TABLE [dbo].[IncidentFormExplaination] ADD [IncidentReviewId] int DEFAULT 0
 END
GO








