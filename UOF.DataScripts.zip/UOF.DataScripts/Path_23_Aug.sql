﻿ALTER  TABLE  dbo.IncidentUserInvolved
ADD DVERT  char(2)  NULL

ALTER  TABLE  dbo.IncidentUserInvolved
ADD  InvolvementType  char(2)  NULL  ;

ALTER  TABLE  dbo.IncidentUserInvolved
ADD  ShiftType  varchar(5)  NULL  ;


ALTER  TABLE  dbo.IncidentUserInterview
ADD  InterviewTime  varchar(10)  NULL  ;

ALTER  TABLE  dbo.IncidentUserInterview
ADD AudioPath  varchar(100)  NULL

ALTER  TABLE  dbo.IncidentUserInterview
ADD  VideoPath  varchar(100)  NULL  ;

ALTER  TABLE  dbo.IncidentUserInterview
ADD  PhotosPath  varchar(100)  NULL  ;

ALTER  TABLE  dbo.UofForm
ADD  ActionName  varchar(250) NULL  ;

ALTER  TABLE  dbo.UofForm
ADD  ControllerName  varchar(250)  NULL  ;
