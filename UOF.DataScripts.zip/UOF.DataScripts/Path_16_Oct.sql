﻿ALTER TABLE [dbo].[IncidentUserSuspect] ADD [PPhMode] [varchar](5) NULL
ALTER TABLE [dbo].[IncidentUserSuspect] ADD [SPhMode] [varchar](5) NULL
ALTER TABLE [dbo].[IncidentUserWitness] ADD [ShiftType] [varchar](5) NULL