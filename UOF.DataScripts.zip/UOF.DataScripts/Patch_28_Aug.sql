USE [UseofForce]
GO


IF EXISTS( SELECT *    FROM sys.columns     WHERE Name      = N'ActionName'      AND Object_ID = Object_ID(N'UofForm'))
BEGIN
    -- Column Exists	
ALTER TABLE UofForm DROP COLUMN ActionName
END
	
	BEGIN
		ALTER TABLE UofForm Add ActionName varchar(200)
	END



IF EXISTS(SELECT *    FROM sys.columns     WHERE Name      = N'ControllerName'      AND Object_ID = Object_ID(N'UofForm'))
BEGIN
    -- Column Exists	
ALTER TABLE UofForm DROP COLUMN ControllerName
END
	BEGIN
		ALTER TABLE UofForm Add ControllerName varchar(200)
	END


IF EXISTS(SELECT *    FROM sys.columns     WHERE Name      = N'Text'      AND Object_ID = Object_ID(N'UofForm'))
BEGIN
    -- Column Exists	
ALTER TABLE UofForm DROP COLUMN Text
END


IF EXISTS(SELECT *    FROM sys.columns     WHERE Name      = N'Description'      AND Object_ID = Object_ID(N'UofForm'))
BEGIN
    -- Column Exists	
ALTER TABLE UofForm DROP COLUMN [Description]
END

	BEGIN
		ALTER TABLE UofForm Add [Description] varchar(400)
	END




IF EXISTS(SELECT *    FROM sys.columns     WHERE Name      = N'IsSettingItem'      AND Object_ID = Object_ID(N'UofForm'))
BEGIN
    -- Column Exists	
ALTER TABLE UofForm DROP COLUMN IsSettingItem
END
	BEGIN
		BEGIN
			ALTER TABLE UofForm 
			ADD IsSettingItem bit
		END
	END


IF EXISTS(SELECT *    FROM sys.columns     WHERE Name      = N'IsMenuItem'      AND Object_ID = Object_ID(N'UofForm'))
BEGIN
    -- Column Exists	
ALTER TABLE UofForm DROP COLUMN IsMenuItem
END
	BEGIN
		BEGIN
			ALTER TABLE UofForm 
			ADD IsMenuItem bit
		END
	END


	delete from UofForm;


SET IDENTITY_INSERT [dbo].[UofForm] ON 

GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (19, 0, N'Sergeant', N'Sergeant', NULL, NULL, NULL, 1, 1)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (20, 0, N'Deputy', N'Deputy', NULL, NULL, NULL, 1, 1)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (21, 0, N'Watch Commander', N'WatchCommander', NULL, NULL, NULL, 1, 1)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (22, 0, N'Unit Commander', N'UnitCommander', NULL, NULL, NULL, 1, 1)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (23, 0, N'Commander', N'Commander', NULL, NULL, NULL, 1, 1)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (24, 0, N'Reports', N'Reports', NULL, NULL, NULL, 1, 1)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (25, 19, N'Use of Force Narrative Report', N'Ser_ForceNarrativeReport', NULL, N'Narrative', N'UseofForceNarrative', 1, 1)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (26, 19, N'Cat1- Chemical Agent', N'Ser_ChemicalAgent', NULL, N'COForceReviewCheckList', N'UseofForceNarrative', 1, 1)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (27, 19, N'Custody Division Force Review Checklist', N'Ser_CDFRchecklist', NULL, N'COForceReviewCheckList', N'UseofForceNarrative', 1, 1)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (28, 19, N'Use of Force Package Tracking Sheet', N'Ser_UofPTS', NULL, NULL, NULL, 1, 1)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (29, 19, N'Use of Force Category 1 Incidents', N'Ser_UofC1Incidents', NULL, N'SupervisorsReportforce', N'SupervisorsReportforce', 1, 1)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (30, 19, N'Use of Force Review Notice', N'Ser_UofRNotice', NULL, N'UoFReviewNotice', N'UseofForceNarrative', 1, 1)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (31, 20, N'Incident Report', N'D_IncidentReport', NULL, N'Incident', N'IncidentReport', 1, 1)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (32, 20, N'Medical Report', N'D_MedicalReport', NULL, N'Medical', N'Medical', 1, 1)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (33, 20, N'Crime Analysis Supplemental Form', N'D_CASS', NULL, N'CrimeAnalysis', N'UseofForceNarrative', 1, 1)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (34, 20, N'Inmate Injury/Illness', N'D_InmateInjurtIllness', NULL, N'InmateInjury', N'InmateInjury', 1, 1)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (35, 20, N'Deputy�s Use of Force Memorandum', N'D_DUofM', NULL, N'UoFMemo', N'UseofForceNarrative', 1, 1)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (36, 20, N'Custody Services Division Crime Analysis Supplemental', N'D_CSDCAS', NULL, N'CustodyServices', N'CustodyServices', 1, 1)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (37, 20, N'Deputy�s Supplemental Report', N'D_DSR', NULL, N'SupplementalReport', N'UseofForceNarrative', 1, 1)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (38, 21, N'Watch Commander�s Use of Force Review', N'WC_UofReview', NULL, N'WCUoFReview', N'WCReview', 1, 1)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (39, 21, N'IAB- Mandatory Form', N'WC_IMF', NULL, N'IAB', N'UseofForceNarrative', 1, 1)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (40, 22, N'Unit Commander�s Use of Force Review', N'UC_UofReview', NULL, N'UWUoFReview', N'UnitCommanderReview', 1, 1)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (41, 23, N'Commander�s Use of Force Review', N'C_UofReview', NULL, N'CommanderUoFReview', N'CommanderReview', 1, 1)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (42, 0, N'Settings', N'Settings', NULL, NULL, NULL, 1, 1)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (43, 24, N'Custody Operations', N'Report_COperation', NULL, N'Index', N'Report', 1, 1)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (44, 0, N'IncidentDetails', N'IncidentDetails', NULL, NULL, NULL, 1, 0)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (45, 0, N'IncidentList', N'IncidentList', NULL, NULL, NULL, 1, 0)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (46, 44, N'Involved Employee', N'InvolvedEmp', NULL, NULL, NULL, 1, 0)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (47, 44, N'Suspect Information', N'SuspectInfo', NULL, NULL, NULL, 1, 0)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (48, 44, N'Employee Witness', N'EmpWitness', NULL, NULL, NULL, 1, 0)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (49, 44, N'Non Employee Witness', N'NonEmpWitness', NULL, NULL, NULL, 1, 0)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (50, 44, N'Statistical Data', N'StaticalData', NULL, NULL, NULL, 1, 0)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (51, 44, N'On Duty', N'OnDuty', NULL, NULL, NULL, 1, 0)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (52, 44, N'Canine Deployment', N'CanineDeployment', NULL, NULL, NULL, 1, 0)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (54, 42, N'Settings', N'Settings', NULL, N'Index', N'Settings', 1, 1)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description], [ActionName], [ControllerName], [IsSettingItem], [IsMenuItem]) VALUES (55, 0, N'Logout', N'Logout', NULL, N'Logout', N'Login', 0, 1)
GO
SET IDENTITY_INSERT [dbo].[UofForm] OFF
GO
ALTER TABLE [dbo].[UofForm] ADD  CONSTRAINT [DF_UofForm_isParentForm]  DEFAULT ((0)) FOR [ParentId]
GO
ALTER TABLE [dbo].[UofForm] ADD  CONSTRAINT [DF_UofForm_IsMenuItem]  DEFAULT ((0)) FOR [IsSettingItem]
GO
ALTER TABLE [dbo].[UofForm] ADD  CONSTRAINT [DF_UofForm_IsMenuItem_1]  DEFAULT ((0)) FOR [IsMenuItem]
GO
