--INSERT INTO dbo.LookupCustodyEvent (Code,Name) VALUES('S','Search')
--INSERT INTO dbo.AddressType (TypeName) VALUES('Business')
--INSERT INTO dbo.LookupLocationofForce (Code,Name) VALUES('CL','Clinic')
--INSERT INTO dbo.LookupLocationofForce (Code,Name) VALUES('EL','Elevator')
--INSERT INTO dbo.LookupLocationofForce (Code,Name) VALUES('RA','Recreation Area')
--INSERT INTO dbo.LookupLocationofForce (Code,Name) VALUES('SA','Staging Area')

exec sp_rename 'Incident.BusinessName','IncidentName','COLUMN'
GO
IF COL_LENGTH('IncidentStatisticalData','CreatedBy') IS NULL
 BEGIN
 ALTER TABLE [dbo].[IncidentStatisticalData] ADD [CreatedBy] [varchar](20) NULL
 END
GO
IF COL_LENGTH('IncidentStatisticalData','CreatedOn') IS NULL
 BEGIN
 ALTER TABLE [dbo].[IncidentStatisticalData] ADD [CreatedOn] [datetime] NULL
 END
GO
IF COL_LENGTH('Incident','ExtractionEmpId') IS NULL
 BEGIN
 ALTER TABLE [dbo].[Incident] ADD [ExtractionEmpId] [varchar](20) NULL
 END
GO
IF COL_LENGTH('Incident','MentalHealthEmpId') IS NULL
 BEGIN
 ALTER TABLE [dbo].[Incident] ADD [MentalHealthEmpId] [varchar](20) NULL
 END
GO
IF COL_LENGTH('Incident','CCTVNoReason') IS NULL
 BEGIN
 ALTER TABLE [dbo].[Incident] ADD [CCTVNoReason] [varchar](100) NULL
 END
GO
IF COL_LENGTH('Incident','VideoShootedNoReason') IS NULL
 BEGIN
 ALTER TABLE [dbo].[Incident] ADD [VideoShootedNoReason] [varchar](100) NULL
 END
GO
IF COL_LENGTH('Incident','CCTVExtracted') IS NULL
 BEGIN
 ALTER TABLE [dbo].[Incident] ADD [CCTVExtracted] [varchar](2) NULL
 END
GO
IF COL_LENGTH('Incident','Staging') IS NULL
 BEGIN
 ALTER TABLE [dbo].[Incident] ADD [Staging] [varchar](10) NULL
 END
GO
IF COL_LENGTH('Incident','Bureau') IS NULL
 BEGIN
 ALTER TABLE [dbo].[Incident] ADD [Bureau] [varchar](50) NULL
 END
GO
IF COL_LENGTH('Incident','Station') IS NULL
 BEGIN
 ALTER TABLE [dbo].[Incident] ADD [Station] [varchar](15) NULL
 END
GO
IF COL_LENGTH('Incident','Facility') IS NULL
 BEGIN
 ALTER TABLE [dbo].[Incident] ADD [Facility] [varchar](15) NULL
 END
GO
/****** Object:  Table [dbo].[LookupStation]    Script Date: 12/03/2016 13:18:02 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupStation]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LookupStation](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](5) NOT NULL,
	[Name] [varchar](100) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
SET IDENTITY_INSERT [dbo].[LookupStation] ON
INSERT [dbo].[LookupStation] ([ID], [Code], [Name]) VALUES (1, N'LC', N'Lancaster')
INSERT [dbo].[LookupStation] ([ID], [Code], [Name]) VALUES (2, N'MLH', N'Malibu/Lost Hills')
INSERT [dbo].[LookupStation] ([ID], [Code], [Name]) VALUES (3, N'PLM', N'Palmdale')
INSERT [dbo].[LookupStation] ([ID], [Code], [Name]) VALUES (4, N'SC', N'Santa Clarita')
INSERT [dbo].[LookupStation] ([ID], [Code], [Name]) VALUES (5, N'WH', N'West Hollywood ')
INSERT [dbo].[LookupStation] ([ID], [Code], [Name]) VALUES (6, N'UCW', N'Universal City walk')
INSERT [dbo].[LookupStation] ([ID], [Code], [Name]) VALUES (7, N'AV', N'Avalon')
INSERT [dbo].[LookupStation] ([ID], [Code], [Name]) VALUES (8, N'CN', N'Century')
INSERT [dbo].[LookupStation] ([ID], [Code], [Name]) VALUES (9, N'CO', N'Compton')
INSERT [dbo].[LookupStation] ([ID], [Code], [Name]) VALUES (10, N'ELA', N'East LA')
INSERT [dbo].[LookupStation] ([ID], [Code], [Name]) VALUES (11, N'LW', N'Lawndale')
INSERT [dbo].[LookupStation] ([ID], [Code], [Name]) VALUES (12, N'MDR', N'Marina Del Rey')
INSERT [dbo].[LookupStation] ([ID], [Code], [Name]) VALUES (13, N'SLA', N'South LA (Lennox)')
INSERT [dbo].[LookupStation] ([ID], [Code], [Name]) VALUES (14, N'CN', N'Carson')
INSERT [dbo].[LookupStation] ([ID], [Code], [Name]) VALUES (15, N'CE', N'Cerritos')
INSERT [dbo].[LookupStation] ([ID], [Code], [Name]) VALUES (16, N'LW', N'Lakewood')
INSERT [dbo].[LookupStation] ([ID], [Code], [Name]) VALUES (17, N'LO', N'Lomita')
INSERT [dbo].[LookupStation] ([ID], [Code], [Name]) VALUES (18, N'NW', N'Norwalk')
INSERT [dbo].[LookupStation] ([ID], [Code], [Name]) VALUES (19, N'PR', N'Pico Rivera')
INSERT [dbo].[LookupStation] ([ID], [Code], [Name]) VALUES (20, N'AL', N'Altadena')
INSERT [dbo].[LookupStation] ([ID], [Code], [Name]) VALUES (21, N'CV', N'Crescenta Valley')
INSERT [dbo].[LookupStation] ([ID], [Code], [Name]) VALUES (22, N'IN', N'Industry')
INSERT [dbo].[LookupStation] ([ID], [Code], [Name]) VALUES (23, N'SD', N'San Dimas')
INSERT [dbo].[LookupStation] ([ID], [Code], [Name]) VALUES (24, N'TM', N'Temple')
INSERT [dbo].[LookupStation] ([ID], [Code], [Name]) VALUES (25, N'WB', N'Walnut/Diamond Bar')
SET IDENTITY_INSERT [dbo].[LookupStation] OFF
/****** Object:  Table [dbo].[LookupFacility]    Script Date: 12/03/2016 13:18:02 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupFacility]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LookupFacility](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](5) NOT NULL,
	[Name] [varchar](100) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
SET IDENTITY_INSERT [dbo].[LookupFacility] ON
INSERT [dbo].[LookupFacility] ([ID], [Code], [Name]) VALUES (1, N'CRDF', N'Century Regional Detention Center')
INSERT [dbo].[LookupFacility] ([ID], [Code], [Name]) VALUES (2, N'IRC', N'Inmate Reception Center')
INSERT [dbo].[LookupFacility] ([ID], [Code], [Name]) VALUES (3, N'MCJ', N'Men''s Central Jail')
INSERT [dbo].[LookupFacility] ([ID], [Code], [Name]) VALUES (4, N'MLDC', N'Mira Loma Detention Center')
INSERT [dbo].[LookupFacility] ([ID], [Code], [Name]) VALUES (5, N'NCCF', N'NCCF')
INSERT [dbo].[LookupFacility] ([ID], [Code], [Name]) VALUES (6, N'PDCE', N'PDC EAST')
INSERT [dbo].[LookupFacility] ([ID], [Code], [Name]) VALUES (7, N'PDCN', N'PDC North')
INSERT [dbo].[LookupFacility] ([ID], [Code], [Name]) VALUES (9, N'PDCS', N'PDC South')
INSERT [dbo].[LookupFacility] ([ID], [Code], [Name]) VALUES (10, N'TTCF', N'Twin Towers')
INSERT [dbo].[LookupFacility] ([ID], [Code], [Name]) VALUES (11, N'LCMC', N'LCMC')
SET IDENTITY_INSERT [dbo].[LookupFacility] OFF
/****** Object:  Table [dbo].[IncidentBusinessAddress]    Script Date: 12/03/2016 13:18:02 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IncidentBusinessAddress]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[IncidentBusinessAddress](
	[IncidentBusinessID] [int] IDENTITY(1,1) NOT NULL,
	[IncidentID] [int] NOT NULL,
	[Name] [varchar](50) NULL,
	[AddressNumber] [varchar](10) NOT NULL,
	[Street] [varchar](50) NULL,
	[City] [varchar](50) NULL,
	[Zip] [varchar](20) NULL,
	[CreatedBy] [varchar](20) NULL,
	[CreatedOn] [datetime] NULL,
 CONSTRAINT [PK_IncidentBusinessAddress] PRIMARY KEY CLUSTERED 
(
	[IncidentBusinessID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[IncidentBusinessAddress]  WITH CHECK ADD  CONSTRAINT [FK_IncidentBusinessAddress_Incident] FOREIGN KEY([IncidentID])
REFERENCES [dbo].[Incident] ([IncidentId])
GO

ALTER TABLE [dbo].[IncidentBusinessAddress] CHECK CONSTRAINT [FK_IncidentBusinessAddress_Incident]
GO
GO
/****** Object:  Table [dbo].[LookupStaging]    Script Date: 12/03/2016 13:30:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupStaging]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LookupStaging](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](10) NULL,
	[Name] [varchar](50) NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
SET IDENTITY_INSERT [dbo].[LookupStaging] ON
INSERT [dbo].[LookupStaging] ([ID], [Code], [Name]) VALUES (1, N'IS', N'Indoor Staging area')
INSERT [dbo].[LookupStaging] ([ID], [Code], [Name]) VALUES (2, N'OS', N'Outdoor ')
SET IDENTITY_INSERT [dbo].[LookupStaging] OFF
GO
GO

/****** Object:  Table [dbo].[IncidentCFRTFlow]    Script Date: 12/03/2016 22:15:13 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[IncidentCFRTFlow](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NOT NULL,
	[CFRTID] [varchar](25) NOT NULL,
	[CFRCID] [varchar](25) NOT NULL,
	[CRFCEmailId] [varchar](200) NOT NULL,
	[CRFCStatus] [varchar](20) NOT NULL,
	[CreatedBy] [varchar](25) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
 CONSTRAINT [PK_IncidentCFRTFlow] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[IncidentCFRTFlow]  WITH CHECK ADD  CONSTRAINT [FK_IncidentCFRTFlow_Incident] FOREIGN KEY([IncidentId])
REFERENCES [dbo].[Incident] ([IncidentId])
GO

ALTER TABLE [dbo].[IncidentCFRTFlow] CHECK CONSTRAINT [FK_IncidentCFRTFlow_Incident]
GO