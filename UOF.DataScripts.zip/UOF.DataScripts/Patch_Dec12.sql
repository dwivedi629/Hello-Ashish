IF COL_LENGTH('ReturnComments','Updatedby') IS NULL
 BEGIN
 ALTER TABLE [dbo].[ReturnComments] ADD [Updatedby] [varchar](20) NULL
 END
GO
IF COL_LENGTH('ReturnComments','UpdatedOn') IS NULL
 BEGIN
 ALTER TABLE [dbo].[ReturnComments] ADD [UpdatedOn] [datetime] NULL
 END
GO
IF COL_LENGTH('ReturnComments','CreatedBy') IS NULL
 BEGIN
 ALTER TABLE [dbo].[ReturnComments] ADD [CreatedBy] [varchar](20) NULL
 END
GO
IF COL_LENGTH('ReturnComments','Status') IS NULL
 BEGIN
 ALTER TABLE [dbo].[ReturnComments] ADD [Status] [varchar](10) NULL
 END
GO
IF COL_LENGTH('IncidentStatisticalData','IsDeleted') IS NULL
 BEGIN
 ALTER TABLE [dbo].[IncidentStatisticalData] ADD [IsDeleted] [bit] NULL
 END
GO
exec sp_rename 'IncidentUserSuspect.SuspectPlannedForce','TransorRefuse','COLUMN'
GO
exec sp_rename 'Incident.Perceivedarmed','CTOthers','COLUMN'