IF COL_LENGTH('Incident','elotsYN') IS NULL
 BEGIN
 ALTER TABLE [dbo].[Incident] ADD [elotsYN] [varchar](2) NULL
 END
GO
IF COL_LENGTH('Incident','elotsNoReason') IS NULL
 BEGIN
 ALTER TABLE [dbo].[Incident] ADD [elotsNoReason] [varchar](500) NULL
 END
GO