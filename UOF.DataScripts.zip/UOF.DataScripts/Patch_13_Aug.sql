USE [UseofForce]
GO
SET IDENTITY_INSERT [dbo].[UofForm] ON 

GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (8, 0, N'Sergeant', N'Sergeant', N'')
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (9, 0, N'Deputy', N'Deputy', N'')
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (10, 0, N'Watch Commander', N'WatchCommander', N'')
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (11, 0, N'Unit Commander', N'UnitCommander', N'')
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (12, 0, N'Commander', N'Commander', N'')
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (13, 0, N'Reports', N'Reports', N'')
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (14, 8, N'Use of Force Narrative Report', N'Ser_ForceNarrativeReport', N'')
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (15, 8, N'Cat1- Chemical Agent', N'Ser_ChemicalAgent', N'')
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (16, 8, N'Custody Division Force Review Checklist', N'Ser_CDFRchecklist', N'')
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (17, 8, N'Use of Force Package Tracking Sheet', N'Ser_UofPTS', N'')
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (18, 8, N'Use of Force Category 1 Incidents', N'Ser_UofC1Incidents', N'')
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (19, 8, N'Use of Force Review Notice', N'Ser_UofRNotice', N'')
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (20, 9, N'Incident Report', N'D_IncidentReport', N'')
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (21, 9, N'Medical Report', N'D_MedicalReport', N'')
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (22, 9, N'Crime Analysis Supplemental Form', N'D_CASS', N'')
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (24, 9, N'Inmate Injury/Illness', N'D_InmateInjurtIllness', N'')
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (25, 9, N'Deputy�s Use of Force Memorandum', N'D_DUofM', N'')
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (26, 9, N'Custody Services Division Crime Analysis Supplemental', N'D_CSDCAS', N'')
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (27, 9, N'Deputy�s Supplemental Report', N'D_DSR', N'')
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (28, 10, N'Watch Commander�s Use of Force Review', N'WC_UofReview', N'')
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (31, 10, N'IAB- Mandatory Form', N'WC_IMF', NULL)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (32, 11, N'Unit Commander�s Use of Force Review', N'UC_UofReview', NULL)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (33, 12, N'Commander�s Use of Force Review', N'C_UofReview', NULL)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (34, 0, N'Settings', N'Settings', NULL)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (35, 13, N'Custody Operations', N'Report_COperation', NULL)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (36, 0, N'IncidentDetails', N'IncidentDetails', NULL)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (37, 0, N'IncidentList', N'IncidentList', NULL)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (38, 36, N'Involved Employee', N'InvolvedEmp', NULL)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (39, 36, N'Suspect Information', N'SuspectInfo', NULL)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (40, 36, N'Employee Witness', N'EmpWitness', NULL)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (41, 36, N'Non Employee Witness', N'NonEmpWitness', NULL)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (42, 36, N'Statistical Data', N'StaticalData', NULL)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (43, 36, N'On Duty', N'OnDuty', NULL)
GO
INSERT [dbo].[UofForm] ([FormId], [ParentId], [FormName], [FormCode], [Description]) VALUES (44, 36, N'Canine Deployment', N'CanineDeployment', NULL)
GO
SET IDENTITY_INSERT [dbo].[UofForm] OFF
GO
