﻿IF COL_LENGTH('Incident','Assulative') IS NULL
 BEGIN
 ALTER TABLE [dbo].[Incident] ADD [Assulative] [varchar](2) NULL
 END
 GO
 IF COL_LENGTH('Incident','Lifethreatening') IS NULL
 BEGIN
 ALTER TABLE [dbo].[Incident] ADD [Lifethreatening] [varchar](2) NULL
 END
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_EmailNotifications_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[EmailNotifications]'))
ALTER TABLE [dbo].[EmailNotifications] DROP CONSTRAINT [FK_EmailNotifications_Incident]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EmailNotifications]') AND type in (N'U'))
DROP TABLE [dbo].[EmailNotifications]
GO

/****** Object:  Table [dbo].[EmailNotifications]    Script Date: 10/31/2016 09:24:37 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[EmailNotifications](
	[EmailNotificationId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NOT NULL,
	[EmployeeNumber] [varchar](25) NULL,
	[Department] [varchar](100) NULL,
	[EmailId] [varchar](250) NOT NULL,
	[Sent] [bit] NULL,
	[Responded] [bit] NULL,
	[SentOn] [datetime] NOT NULL,
	[RespondedOn] [datetime] NULL,
	[Status] [varchar](20) NULL,
 CONSTRAINT [PK_EmailNotifications] PRIMARY KEY CLUSTERED 
(
	[EmailNotificationId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[EmailNotifications]  WITH CHECK ADD  CONSTRAINT [FK_EmailNotifications_Incident] FOREIGN KEY([IncidentId])
REFERENCES [dbo].[Incident] ([IncidentId])
GO

ALTER TABLE [dbo].[EmailNotifications] CHECK CONSTRAINT [FK_EmailNotifications_Incident]
GO
/****** Object:  Table [dbo].[DigitalSignatures]    Script Date: 11/06/2016 10:12:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[DigitalSignatures](
	[SignatureId] [int] IDENTITY(1,1) NOT NULL,
	[EmployeeNumber] [varchar](25) NOT NULL,
	[Signature] [varbinary](max) NOT NULL,
	[Status] [varchar](20) NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ReviewComments]    Script Date: 11/06/2016 10:12:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ReviewComments](
	[ReviewCommentId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NOT NULL,
	[FormId] [int] NOT NULL,
	[ReviewComments] [varchar](max) NOT NULL,
	[CommentedBy] [varchar](25) NOT NULL,
	[AddressedBy] [varchar](25) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[Status] [varchar](10) NOT NULL,
 CONSTRAINT [PK_ReviewComments] PRIMARY KEY CLUSTERED 
(
	[ReviewCommentId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ReturnComments]    Script Date: 11/06/2016 10:12:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ReturnComments](
	[ReturnId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NOT NULL,
	[FormId] [int] NOT NULL,
	[ReturnBy] [varchar](25) NOT NULL,
	[AddressedBy] [varchar](25) NOT NULL,
	[Comments] [varchar](max) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[Status] [varchar](10) NOT NULL,
 CONSTRAINT [PK_ReturnComments] PRIMARY KEY CLUSTERED 
(
	[ReturnId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  ForeignKey [FK_ReturnComments_Incident]    Script Date: 11/06/2016 10:12:22 ******/
ALTER TABLE [dbo].[ReturnComments]  WITH CHECK ADD  CONSTRAINT [FK_ReturnComments_Incident] FOREIGN KEY([IncidentId])
REFERENCES [dbo].[Incident] ([IncidentId])
GO
ALTER TABLE [dbo].[ReturnComments] CHECK CONSTRAINT [FK_ReturnComments_Incident]
GO
/****** Object:  ForeignKey [FK_ReturnComments_UofForm]    Script Date: 11/06/2016 10:12:22 ******/
ALTER TABLE [dbo].[ReturnComments]  WITH CHECK ADD  CONSTRAINT [FK_ReturnComments_UofForm] FOREIGN KEY([FormId])
REFERENCES [dbo].[UofForm] ([FormId])
GO
ALTER TABLE [dbo].[ReturnComments] CHECK CONSTRAINT [FK_ReturnComments_UofForm]
GO
/****** Object:  ForeignKey [FK_ReviewComments_Incident]    Script Date: 11/06/2016 10:12:22 ******/
ALTER TABLE [dbo].[ReviewComments]  WITH CHECK ADD  CONSTRAINT [FK_ReviewComments_Incident] FOREIGN KEY([IncidentId])
REFERENCES [dbo].[Incident] ([IncidentId])
GO
ALTER TABLE [dbo].[ReviewComments] CHECK CONSTRAINT [FK_ReviewComments_Incident]
GO
/****** Object:  ForeignKey [FK_ReviewComments_UofForm]    Script Date: 11/06/2016 10:12:22 ******/
ALTER TABLE [dbo].[ReviewComments]  WITH CHECK ADD  CONSTRAINT [FK_ReviewComments_UofForm] FOREIGN KEY([FormId])
REFERENCES [dbo].[UofForm] ([FormId])
GO
ALTER TABLE [dbo].[ReviewComments] CHECK CONSTRAINT [FK_ReviewComments_UofForm]
GO
IF COL_LENGTH('Treatment','IncidentUserSuspectId') IS NULL
 BEGIN
 ALTER TABLE [dbo].[Treatment] ADD [IncidentUserSuspectId] [int] NULL
 END
 ALTER TABLE [dbo].[Treatment]  WITH CHECK ADD  CONSTRAINT [FK_Treatment_IncidentUserSuspect] FOREIGN KEY([IncidentUserSuspectId])
	REFERENCES [dbo].[IncidentUserSuspect] ([IncidentUserSuspectId])
GO

ALTER TABLE [dbo].[Treatment] CHECK CONSTRAINT [FK_Treatment_IncidentUserSuspect]

EXEC sp_RENAME 'Incident.EmpId' , 'SergeantId', 'COLUMN'






delete from IncidentFormData
delete from IncidentWorkflow
delete from dbo.IncidentFormReview
delete from [User]
delete from UserDetail
delete from IncidentUser
delete from IncidentUserInvolved
delete from Hospital
delete from Treatment
delete from IncidentUserInterview
delete from UserAddress
delete from UserContact
delete from ReturnComments
delete from ReviewComments
delete from IncidentUserSuspect
delete from IncidentUserWitness
delete from IncidentSergeant
delete from IncidentCategoryForm
delete from IncidentStatisticalData
delete from IncidentCanineDeployment
delete from IAB_RolledOut
delete from Handler
delete from EmailNotifications
delete from CFRT_RolledOut
delete from [Address]
delete from ForceOnSuspect
delete from Incident
