USE [UseofForce]
GO
ALTER TABLE [dbo].[FormPermisssion] DROP CONSTRAINT [FK_FormPermisssion_UserRole]
GO
ALTER TABLE [dbo].[FormPermisssion] DROP CONSTRAINT [FK_FormPermisssion_UofForm]
GO
ALTER TABLE [dbo].[FormPermisssion] DROP CONSTRAINT [DF_FormPermisssion_IsViewOnly]
GO
/****** Object:  Table [dbo].[UserType]    Script Date: 8/7/2016 12:57:18 PM ******/
DROP TABLE [dbo].[UserType]
GO
/****** Object:  Table [dbo].[UserRole]    Script Date: 8/7/2016 12:57:18 PM ******/
DROP TABLE [dbo].[UserRole]
GO
/****** Object:  Table [dbo].[FormPermisssion]    Script Date: 8/7/2016 12:57:18 PM ******/
DROP TABLE [dbo].[FormPermisssion]
GO
/****** Object:  Table [dbo].[FormPermisssion]    Script Date: 8/7/2016 12:57:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FormPermisssion](
	[FormPermissionId] [int] IDENTITY(1,1) NOT NULL,
	[RoleId] [int] NOT NULL,
	[FormId] [int] NOT NULL,
	[IsViewOnly] [bit] NOT NULL,
 CONSTRAINT [PK_FormPermisssion] PRIMARY KEY CLUSTERED 
(
	[FormPermissionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[UserRole]    Script Date: 8/7/2016 12:57:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[UserRole](
	[RoleId] [int] IDENTITY(1,1) NOT NULL,
	[RoleName] [nvarchar](150) NOT NULL,
	[RoleCode] [nvarchar](100) NOT NULL,
	[Description] [varchar](250) NULL,
 CONSTRAINT [PK_UserRole] PRIMARY KEY CLUSTERED 
(
	[RoleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[UserType]    Script Date: 8/7/2016 12:57:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[UserType](
	[UserTypeId] [int] IDENTITY(1,1) NOT NULL,
	[TypeName] [varchar](50) NOT NULL,
 CONSTRAINT [PK_UserType] PRIMARY KEY CLUSTERED 
(
	[UserTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
SET IDENTITY_INSERT [dbo].[FormPermisssion] ON 

GO
INSERT [dbo].[FormPermisssion] ([FormPermissionId], [RoleId], [FormId], [IsViewOnly]) VALUES (1, 2, 9, 0)
GO
INSERT [dbo].[FormPermisssion] ([FormPermissionId], [RoleId], [FormId], [IsViewOnly]) VALUES (2, 2, 12, 0)
GO
INSERT [dbo].[FormPermisssion] ([FormPermissionId], [RoleId], [FormId], [IsViewOnly]) VALUES (3, 2, 13, 0)
GO
INSERT [dbo].[FormPermisssion] ([FormPermissionId], [RoleId], [FormId], [IsViewOnly]) VALUES (4, 3, 10, 0)
GO
INSERT [dbo].[FormPermisssion] ([FormPermissionId], [RoleId], [FormId], [IsViewOnly]) VALUES (5, 3, 11, 0)
GO
INSERT [dbo].[FormPermisssion] ([FormPermissionId], [RoleId], [FormId], [IsViewOnly]) VALUES (6, 3, 13, 0)
GO
INSERT [dbo].[FormPermisssion] ([FormPermissionId], [RoleId], [FormId], [IsViewOnly]) VALUES (7, 3, 14, 0)
GO
INSERT [dbo].[FormPermisssion] ([FormPermissionId], [RoleId], [FormId], [IsViewOnly]) VALUES (8, 1, 12, 0)
GO
INSERT [dbo].[FormPermisssion] ([FormPermissionId], [RoleId], [FormId], [IsViewOnly]) VALUES (9, 1, 24, 0)
GO
INSERT [dbo].[FormPermisssion] ([FormPermissionId], [RoleId], [FormId], [IsViewOnly]) VALUES (10, 1, 25, 0)
GO
INSERT [dbo].[FormPermisssion] ([FormPermissionId], [RoleId], [FormId], [IsViewOnly]) VALUES (11, 1, 26, 0)
GO
SET IDENTITY_INSERT [dbo].[FormPermisssion] OFF
GO
SET IDENTITY_INSERT [dbo].[UserRole] ON 

GO
INSERT [dbo].[UserRole] ([RoleId], [RoleName], [RoleCode], [Description]) VALUES (1, N'Supervisor', N'Supervisor', N'This is for supervisor role')
GO
INSERT [dbo].[UserRole] ([RoleId], [RoleName], [RoleCode], [Description]) VALUES (2, N'Watch Commandor', N'WCommandor', N'This is for watch Commandor role')
GO
INSERT [dbo].[UserRole] ([RoleId], [RoleName], [RoleCode], [Description]) VALUES (3, N'Commandor', N'Commandor', N'This is for Commandor role')
GO
INSERT [dbo].[UserRole] ([RoleId], [RoleName], [RoleCode], [Description]) VALUES (4, N'Watch Commander', N'WC', N'Watch Commander Role')
GO
INSERT [dbo].[UserRole] ([RoleId], [RoleName], [RoleCode], [Description]) VALUES (5, N'Supervising Lieutenant', N'SL', N'Supervising Lieutenant Role')
GO
INSERT [dbo].[UserRole] ([RoleId], [RoleName], [RoleCode], [Description]) VALUES (6, N'Unit Commander', N'UC', N'Unit Commander Role')
GO
INSERT [dbo].[UserRole] ([RoleId], [RoleName], [RoleCode], [Description]) VALUES (7, N'Commander', N'CM', N'Commander Role')
GO
INSERT [dbo].[UserRole] ([RoleId], [RoleName], [RoleCode], [Description]) VALUES (8, N'Division Chief', N'DC', N'Division Chief Role')
GO
INSERT [dbo].[UserRole] ([RoleId], [RoleName], [RoleCode], [Description]) VALUES (9, N'Discovery', N'DI', N'Discovery Role')
GO
INSERT [dbo].[UserRole] ([RoleId], [RoleName], [RoleCode], [Description]) VALUES (10, N'SuperAdmin', N'SuperAdmin', N'Only to do form settings mapping')
GO
INSERT [dbo].[UserRole] ([RoleId], [RoleName], [RoleCode], [Description]) VALUES (11, N'Surgeant', N'Surgeant', N'for incident entry')
GO
SET IDENTITY_INSERT [dbo].[UserRole] OFF
GO
SET IDENTITY_INSERT [dbo].[UserType] ON 

GO
INSERT [dbo].[UserType] ([UserTypeId], [TypeName]) VALUES (1, N'Unknown')
GO
INSERT [dbo].[UserType] ([UserTypeId], [TypeName]) VALUES (2, N'Employee')
GO
INSERT [dbo].[UserType] ([UserTypeId], [TypeName]) VALUES (3, N'Suspect')
GO
INSERT [dbo].[UserType] ([UserTypeId], [TypeName]) VALUES (4, N'EmployeeWitness')
GO
INSERT [dbo].[UserType] ([UserTypeId], [TypeName]) VALUES (5, N'NonEmpWitness')
GO
INSERT [dbo].[UserType] ([UserTypeId], [TypeName]) VALUES (6, N'WatchCommander')
GO
INSERT [dbo].[UserType] ([UserTypeId], [TypeName]) VALUES (7, N'UnitCommander')
GO
INSERT [dbo].[UserType] ([UserTypeId], [TypeName]) VALUES (8, N'Commander')
GO
INSERT [dbo].[UserType] ([UserTypeId], [TypeName]) VALUES (9, N'OnDuty')
GO
INSERT [dbo].[UserType] ([UserTypeId], [TypeName]) VALUES (10, N'Supervisor')
GO
SET IDENTITY_INSERT [dbo].[UserType] OFF
GO
ALTER TABLE [dbo].[FormPermisssion] ADD  CONSTRAINT [DF_FormPermisssion_IsViewOnly]  DEFAULT ((0)) FOR [IsViewOnly]
GO
ALTER TABLE [dbo].[FormPermisssion]  WITH CHECK ADD  CONSTRAINT [FK_FormPermisssion_UofForm] FOREIGN KEY([FormId])
REFERENCES [dbo].[UofForm] ([FormId])
GO
ALTER TABLE [dbo].[FormPermisssion] CHECK CONSTRAINT [FK_FormPermisssion_UofForm]
GO
ALTER TABLE [dbo].[FormPermisssion]  WITH CHECK ADD  CONSTRAINT [FK_FormPermisssion_UserRole] FOREIGN KEY([RoleId])
REFERENCES [dbo].[UserRole] ([RoleId])
GO
ALTER TABLE [dbo].[FormPermisssion] CHECK CONSTRAINT [FK_FormPermisssion_UserRole]
GO
