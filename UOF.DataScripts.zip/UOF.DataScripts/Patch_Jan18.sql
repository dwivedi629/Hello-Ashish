IF COL_LENGTH('Address','IncidentId') IS NULL

BEGIN

ALTER TABLE [dbo].[Address] ADD [IncidentId] INT NULL

END

GO

ALTER TABLE Incident

DROP CONSTRAINT FK_Incident_Address

GO

ALTER TABLE Address

ADD CONSTRAINT FK_Incident_Address

FOREIGN KEY (IncidentId)

REFERENCES Incident(IncidentId)

INSERT INTO UserType (TypeName) VALUES ('AssignedUser')
