﻿GO
/****** Object:  Table [dbo].[UserType]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserType]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UserType](
	[UserTypeId] [int] IDENTITY(1,1) NOT NULL,
	[TypeName] [varchar](50) NOT NULL,
 CONSTRAINT [PK_UserType] PRIMARY KEY CLUSTERED 
(
	[UserTypeId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[UserRole]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserRole]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UserRole](
	[RoleId] [int] IDENTITY(1,1) NOT NULL,
	[RoleName] [nvarchar](150) NOT NULL,
	[RoleCode] [nvarchar](100) NOT NULL,
	[Description] [varchar](250) NULL,
	[ReadOnly] [bit] NULL,
	[Rank] [int] NULL,
 CONSTRAINT [PK_UserRole] PRIMARY KEY CLUSTERED 
(
	[RoleId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[UserDetail]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserDetail]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UserDetail](
	[UserDetailId] [int] IDENTITY(1,1) NOT NULL,
	[FirstName] [varchar](150) NOT NULL,
	[MiddleName] [varchar](150) NULL,
	[LastName] [varchar](150) NOT NULL,
	[Rank] [varchar](250) NULL,
	[Sex] [char](2) NULL,
	[Race] [varchar](50) NULL,
	[Dress] [varchar](20) NULL,
	[Height] [varchar](50) NULL,
	[Weight] [varchar](50) NULL,
	[Age] [int] NULL,
	[ShiftId] [varchar](20) NULL,
	[UnitOfAssignment] [varchar](150) NULL,
	[WorkAssignment] [varchar](250) NULL,
	[DateOfBirth] [date] NULL
) ON [PRIMARY]
SET ANSI_PADDING OFF
ALTER TABLE [dbo].[UserDetail] ADD [EmailId] [varchar](200) NULL
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[UserDetail]') AND name = N'PK_UserDetail')
ALTER TABLE [dbo].[UserDetail] ADD  CONSTRAINT [PK_UserDetail] PRIMARY KEY CLUSTERED 
(
	[UserDetailId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[IncidentWorkflow]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IncidentWorkflow]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[IncidentWorkflow](
	[WorkflowId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NOT NULL,
	[SergeantID] [varchar](20) NOT NULL,
	[SergeantStatus] [varchar](25) NULL,
	[WCID] [varchar](20) NULL,
	[WCStatus] [varchar](25) NULL,
	[UCID] [varchar](20) NULL,
	[UCStatus] [varchar](25) NULL,
	[CFRCID] [varchar](20) NULL,
	[CFRCStatus] [varchar](25) NULL,
	[CFRTID] [varchar](20) NULL,
	[CFRTStatus] [varchar](25) NULL,
	[CMID] [varchar](25) NULL,
	[CMStatus] [varchar](20) NULL
) ON [PRIMARY]
SET ANSI_PADDING OFF
ALTER TABLE [dbo].[IncidentWorkflow] ADD [DeputyStatus] [varchar](25) NULL
SET ANSI_PADDING ON
ALTER TABLE [dbo].[IncidentWorkflow] ADD [DCID] [varchar](25) NULL
ALTER TABLE [dbo].[IncidentWorkflow] ADD [DCStatus] [varchar](20) NULL
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[IncidentWorkflow]') AND name = N'PK_IncidentWorkflow')
ALTER TABLE [dbo].[IncidentWorkflow] ADD  CONSTRAINT [PK_IncidentWorkflow] PRIMARY KEY CLUSTERED 
(
	[WorkflowId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[IncidentUserDirector]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IncidentUserDirector]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[IncidentUserDirector](
	[IncidentUserDirectorId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentUserId] [int] NULL,
	[DirectedByUserId] [int] NULL,
 CONSTRAINT [PK_IncidentUserDirector] PRIMARY KEY CLUSTERED 
(
	[IncidentUserDirectorId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[UofForm]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UofForm]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UofForm](
	[FormId] [int] IDENTITY(1,1) NOT NULL,
	[ParentId] [int] NOT NULL,
	[FormName] [nvarchar](500) NOT NULL,
	[FormCode] [nvarchar](100) NOT NULL,
	[Text] [varchar](250) NULL,
	[Description] [varchar](250) NULL,
	[ActionName] [varchar](250) NULL,
	[ControllerName] [varchar](250) NULL,
	[IsSettingItem] [bit] NULL,
	[IsMenuItem] [bit] NULL,
 CONSTRAINT [PK_UofForm] PRIMARY KEY CLUSTERED 
(
	[FormId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[DigitalSignatures]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DigitalSignatures]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DigitalSignatures](
	[SignatureId] [int] IDENTITY(1,1) NOT NULL,
	[EmployeeNumber] [varchar](25) NOT NULL,
	[Signature] [varbinary](max) NOT NULL,
	[Status] [varchar](20) NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ContactType]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ContactType]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ContactType](
	[ContactTypeId] [int] IDENTITY(1,1) NOT NULL,
	[TypeName] [varchar](50) NULL,
 CONSTRAINT [PK_ContactType] PRIMARY KEY CLUSTERED 
(
	[ContactTypeId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Contact]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Contact]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Contact](
	[ContactId] [int] IDENTITY(1,1) NOT NULL,
	[Number] [varchar](15) NOT NULL,
	[ContactTypeId] [int] NOT NULL,
 CONSTRAINT [PK_Contact] PRIMARY KEY CLUSTERED 
(
	[ContactId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ChargeCodeType]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ChargeCodeType]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ChargeCodeType](
	[ChargeCodeTypeId] [int] IDENTITY(1,1) NOT NULL,
	[TypeName] [varchar](50) NULL,
 CONSTRAINT [PK_ChargeCodeType] PRIMARY KEY CLUSTERED 
(
	[ChargeCodeTypeId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Hospital]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Hospital]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Hospital](
	[HospitalId] [int] IDENTITY(1,1) NOT NULL,
	[RecdTreatmentAt] [varchar](150) NULL,
	[HospitalAdmissionBy] [varchar](150) NULL,
	[HospitalAddress] [varchar](500) NULL,
	[HospitalPhone] [varchar](50) NULL,
	[IncidentUserSuspectId] [int] NULL,
 CONSTRAINT [PK_Hospital] PRIMARY KEY CLUSTERED 
(
	[HospitalId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Handler]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Handler]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Handler](
	[HandlerId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentCanineDeploymentId] [int] NOT NULL,
	[HandlerNumber] [varchar](20) NULL,
	[HandlerName] [varchar](20) NULL,
	[CanineNumber] [varchar](20) NULL,
	[UnitNumber] [varchar](20) NULL,
	[HandlerType] [char](2) NULL,
 CONSTRAINT [PK_Handler] PRIMARY KEY CLUSTERED 
(
	[HandlerId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[AT_ChangeOwner]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AT_ChangeOwner]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[AT_ChangeOwner](
	[OwnerId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NOT NULL,
	[FormId] [int] NOT NULL,
	[ExistingEmpId] [varchar](20) NOT NULL,
	[ChangedEmpId] [varchar](20) NOT NULL,
	[CreatedBy] [varchar](20) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
 CONSTRAINT [PK_AuditTrail_CO] PRIMARY KEY CLUSTERED 
(
	[OwnerId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ArtifactsInformation]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ArtifactsInformation]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ArtifactsInformation](
	[ArtifactId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NOT NULL,
	[FileName] [varchar](300) NOT NULL,
	[UplodedDate] [date] NOT NULL,
 CONSTRAINT [PK_ArtifactsInformation] PRIMARY KEY CLUSTERED 
(
	[ArtifactId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[AddressType]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AddressType]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[AddressType](
	[AddressTypeId] [int] IDENTITY(1,1) NOT NULL,
	[TypeName] [varchar](50) NOT NULL,
 CONSTRAINT [PK_AddressType] PRIMARY KEY CLUSTERED 
(
	[AddressTypeId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Incident]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Incident]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Incident](
	[IncidentId] [int] IDENTITY(1,1) NOT NULL,
	[URN] [nvarchar](25) NULL,
	[AddressId] [int] NOT NULL,
	[IncidentDate] [datetime] NOT NULL,
	[ContactTypeId] [varchar](20) NULL,
	[CustodyEventId] [varchar](20) NULL,
	[IncidentName] [varchar](100) NULL,
	[incidentCity] [varchar](100) NULL,
	[CTOthers] [varchar](100) NULL,
	[IsAdminInvestigation] [char](2) NULL,
	[IncidentCategoryId] [int] NULL,
	[ForceTypeId] [varchar](50) NULL,
	[IsDeptyInjury] [char](2) NULL,
	[IsSuspectInjury] [char](2) NULL,
	[IsUnderlyingArrest] [char](2) NULL,
	[IsUnderlyingCrime] [char](2) NULL,
	[IsOnK12Campus] [char](2) NULL,
	[IsByFootPursuit] [char](2) NULL,
	[IsByVehiclePursuit] [char](2) NULL,
	[IsIABNotified] [char](2) NULL,
	[IABNotifiedUserId] [varchar](20) NULL,
	[IsIABRollOut] [char](2) NULL,
	[IABRolloutEmployees] [varchar](500) NULL,
	[IsIABHandling] [char](2) NULL,
	[IABHandlingUserId] [varchar](20) NULL,
	[IsCFRTNotified] [char](2) NULL,
	[CFRTNotifiedUserId] [varchar](20) NULL,
	[IsCFRTRollOut] [char](2) NULL,
	[CFRTRolloutEmployees] [varchar](500) NULL,
	[IsCFRTHandling] [char](2) NULL,
	[CFRTHandlingUserId] [varchar](20) NULL,
	[IsReactiveForce] [char](2) NULL,
	[IsPlannedForce] [char](2) NULL,
	[IsInmateInjuryReportWritten] [char](2) NULL,
	[IsMedicalStaffPresent] [char](2) NULL,
	[IsMentalHealthPresent] [char](2) NULL,
	[IsSuperVisorPresent] [char](2) NULL,
	[IsMedicalRecordChecked] [char](2) NULL,
	[IsExtractionOrderByMedical] [char](2) NULL,
	[IsMentalHealthProfessional] [char](2) NULL,
	[IsDepartmentSignAdmonishmentAndNotedChangesInReport] [char](2) NULL,
	[IsInvestigatorDirectedTheForce] [char](2) NULL,
	[IsInvestigatorParticipatedInTheForce] [char](2) NULL,
	[IsInvestigatorPlannedTheForce] [char](2) NULL,
	[IsStaffEscortInvolvedInmates] [char](2) NULL,
	[IsCCTVCoverage] [char](2) NULL,
	[IsVideoShooted] [char](2) NULL,
	[VideoofIncident] [varchar](100) NULL,
	[Location] [varchar](100) NULL,
	[LevelofResistance] [varchar](100) NULL,
	[IsDepartmentMembersSeparated] [char](2) NULL,
	[IsPPIReviewCompleted] [char](2) NULL,
	[SergeantId] [varchar](20) NULL,
	[IncidentApprovalStatus] [char](2) NULL,
	[UpdatedDate] [datetime] NULL,
	[IncidentCreatedDate] [datetime] NULL,
	[Assulative] [varchar](2) NULL,
	[Lifethreatening] [varchar](2) NULL,
	[IsDeleted] [bit] NULL,
	[IABNotifiedEmailId] [varchar](250) NULL,
	[CFRTNotifiedEmailId] [varchar](250) NULL,
	[ExtractionEmpId] [varchar](20) NULL,
	[MentalHealthEmpId] [varchar](20) NULL,
	[CCTVNoReason] [varchar](100) NULL,
	[VideoShootedNoReason] [varchar](100) NULL,
	[IsCCTVExtracted] [varchar](2) NULL,
	[Staging] [varchar](10) NULL,
	[IncidentLocationName] [varchar](50) NULL,
	[Station] [varchar](15) NULL,
	[Facility] [varchar](15) NULL,
	[PPINo] [varchar](20) NULL,
	[eLots] [varchar](20) NULL
) ON [PRIMARY]  
SET ANSI_PADDING OFF
ALTER TABLE [dbo].[Incident] ADD [InvestigatorDirectedId] [varchar](20) NULL
ALTER TABLE [dbo].[Incident] ADD [PRReason] [varchar](max) NULL
SET ANSI_PADDING ON
ALTER TABLE [dbo].[Incident] ADD [elotsYN] [varchar](2) NULL
ALTER TABLE [dbo].[Incident] ADD [elotsNoReason] [varchar](500) NULL
ALTER TABLE [dbo].[Incident] ADD [ReferenceNo] [varchar](50) NULL
ALTER TABLE [dbo].[Incident] ADD [MHS] [varchar](2) NULL
ALTER TABLE [dbo].[Incident] ADD [MHSReason] [varchar](500) NULL
ALTER TABLE [dbo].[Incident] ADD [PFData] [varchar](50) NULL
ALTER TABLE [dbo].[Incident] ADD [MedicalLife] [varchar](2) NULL
ALTER TABLE [dbo].[Incident] ADD [MedRcdPrior] [varchar](2) NULL
ALTER TABLE [dbo].[Incident] ADD [PlanAltered] [varchar](2) NULL
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Incident]') AND name = N'PK_Incident')
ALTER TABLE [dbo].[Incident] ADD  CONSTRAINT [PK_Incident] PRIMARY KEY CLUSTERED 
(
	[IncidentId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[LookupSubstance]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupSubstance]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LookupSubstance](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](5) NOT NULL,
	[Name] [varchar](100) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[LookupStation]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupStation]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LookupStation](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](5) NOT NULL,
	[Name] [varchar](100) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[LookupStaging]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupStaging]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LookupStaging](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](10) NULL,
	[Name] [varchar](50) NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[LookupSpecialHandle]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupSpecialHandle]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LookupSpecialHandle](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](5) NOT NULL,
	[Name] [varchar](100) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[LookupSex]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupSex]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LookupSex](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](5) NOT NULL,
	[Name] [varchar](100) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[LookupSecurityLevel]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupSecurityLevel]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LookupSecurityLevel](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](5) NOT NULL,
	[Name] [varchar](100) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[LookupResistance]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupResistance]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LookupResistance](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](5) NOT NULL,
	[Name] [varchar](100) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[LookupRace]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupRace]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LookupRace](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](5) NOT NULL,
	[Name] [varchar](100) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[LookupPerceivedArmed]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupPerceivedArmed]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LookupPerceivedArmed](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](5) NOT NULL,
	[Name] [varchar](100) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[LookupMethod]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupMethod]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LookupMethod](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[MethodCode] [varchar](10) NOT NULL,
	[MethodName] [varchar](100) NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[LookupLocationofForce]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupLocationofForce]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LookupLocationofForce](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](5) NOT NULL,
	[Name] [varchar](100) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[LookupInmateDress]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupInmateDress]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LookupInmateDress](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](5) NOT NULL,
	[Name] [varchar](100) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[LookupInjurySeverity]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupInjurySeverity]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LookupInjurySeverity](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](5) NOT NULL,
	[Name] [varchar](100) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[LookupInjury]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupInjury]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LookupInjury](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[InjuryCode] [varchar](10) NOT NULL,
	[InjuryName] [varchar](100) NOT NULL,
	[Type] [varchar](2) NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[LookupFacility]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupFacility]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LookupFacility](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](5) NOT NULL,
	[Name] [varchar](100) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[LookupDress]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupDress]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LookupDress](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](5) NOT NULL,
	[Name] [varchar](100) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[LookupCustodyEvent]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupCustodyEvent]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LookupCustodyEvent](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](5) NOT NULL,
	[Name] [varchar](100) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[LookupContactType]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupContactType]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LookupContactType](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](5) NOT NULL,
	[Name] [varchar](100) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[LookupConfirmedArmed]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupConfirmedArmed]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LookupConfirmedArmed](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](5) NOT NULL,
	[Name] [varchar](100) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[LookupCity]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupCity]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LookupCity](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](5) NOT NULL,
	[Name] [varchar](100) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[LookupBureaus]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupBureaus]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LookupBureaus](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Identifier] [varchar](20) NOT NULL,
	[Name] [varchar](200) NOT NULL,
 CONSTRAINT [PK_LookupBureaus] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[LookupBodyPart]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupBodyPart]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LookupBodyPart](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[BodyPartCode] [varchar](10) NOT NULL,
	[BodyPartName] [varchar](100) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[LookupArmed]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupArmed]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LookupArmed](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](7) NOT NULL,
	[Name] [varchar](100) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[IncidentStatisticalData]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IncidentStatisticalData]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[IncidentStatisticalData](
	[IncidentUserForceId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NOT NULL,
	[IncidentUsedBy] [varchar](20) NOT NULL,
	[IncidentAgainstBy] [varchar](20) NOT NULL,
	[Method] [varchar](50) NOT NULL,
	[InjuryType] [varchar](50) NULL,
	[BodyPartInvolved] [varchar](50) NULL,
	[CreatedBy] [varchar](25) NULL,
	[CreatedOn] [datetime] NULL,
	[IsDeleted] [bit] NULL,
 CONSTRAINT [PK_IncidentStatisticalData] PRIMARY KEY CLUSTERED 
(
	[IncidentUserForceId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[IncidentSergeant]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IncidentSergeant]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[IncidentSergeant](
	[AddlSergeantId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NOT NULL,
	[EmployeeNumber] [varchar](25) NOT NULL,
	[Name] [varchar](150) NOT NULL,
	[SergeantType] [varchar](10) NOT NULL,
	[CreatedBy] [varchar](25) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
 CONSTRAINT [PK_IncidentSergeant] PRIMARY KEY CLUSTERED 
(
	[AddlSergeantId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[IncidentRank]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IncidentRank]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[IncidentRank](
	[IncidentRankId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NOT NULL,
	[Rank] [int] NOT NULL,
	[AssignedUserId] [varchar](20) NULL,
 CONSTRAINT [PK_IncidentRank] PRIMARY KEY CLUSTERED 
(
	[IncidentRankId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[IncidentPlannedForce]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IncidentPlannedForce]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[IncidentPlannedForce](
	[PlannedForceId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NOT NULL,
	[Extraction] [varchar](2) NULL,
	[UoFPlanned] [varchar](2) NULL,
	[MHS] [varchar](2) NULL,
	[MHSReason] [varchar](500) NULL,
	[MedicalFile] [varchar](2) NULL,
	[Investienter] [nvarchar](2) NULL,
	[InvestiExplain] [varchar](500) NULL,
 CONSTRAINT [PK_IncidentPlanned] PRIMARY KEY CLUSTERED 
(
	[PlannedForceId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[IncidentMedicalUser]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IncidentMedicalUser]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[IncidentMedicalUser](
	[MedicalId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NOT NULL,
	[EmpId] [varchar](20) NOT NULL,
	[FormId] [int] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [varchar](20) NOT NULL,
	[Active] [bit] NOT NULL,
 CONSTRAINT [PK_IncidentMedicalUser] PRIMARY KEY CLUSTERED 
(
	[MedicalId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[IncidentInvestigationOfficer]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IncidentInvestigationOfficer]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[IncidentInvestigationOfficer](
	[InvestId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NOT NULL,
	[EmployeeId] [varchar](20) NOT NULL,
	[FirstName] [varchar](20) NOT NULL,
	[LastName] [varchar](20) NOT NULL,
	[Rank] [varchar](20) NOT NULL,
	[IsLock] [bit] NOT NULL,
	[Status] [nchar](10) NOT NULL,
 CONSTRAINT [PK_IncidentInvestigationOfficer] PRIMARY KEY CLUSTERED 
(
	[InvestId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[IncidentFormReview]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IncidentFormReview]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[IncidentFormReview](
	[IncidentReviewID] [int] IDENTITY(1,1) NOT NULL,
	[IncidentID] [int] NOT NULL,
	[FormId] [int] NOT NULL,
	[InvolvedId] [varchar](25) NULL,
	[InvolvedRole] [varchar](20) NULL,
	[SergeantId] [varchar](25) NULL,
	[ReviewerRole] [varchar](20) NULL,
	[SergeantStatus] [varchar](20) NULL,
	[WCID] [varchar](25) NULL,
	[WCStatus] [varchar](20) NULL,
	[UCID] [varchar](25) NULL,
	[UCStatus] [varchar](20) NULL,
	[CMID] [varchar](25) NULL,
	[CMStatus] [varchar](20) NULL,
	[CFRTID] [varchar](25) NULL,
	[CFRTStatus] [varchar](20) NULL,
	[CFRCID] [varchar](25) NULL,
	[CFRCStatus] [varchar](20) NULL,
	[InvolvedStatus] [varchar](20) NULL,
	[FormDataID] [int] NULL
) ON [PRIMARY]
SET ANSI_PADDING ON
ALTER TABLE [dbo].[IncidentFormReview] ADD [DCID] [varchar](25) NULL
ALTER TABLE [dbo].[IncidentFormReview] ADD [DCStatus] [varchar](20) NULL
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[IncidentFormReview]') AND name = N'PK_IncidentFormReview')
ALTER TABLE [dbo].[IncidentFormReview] ADD  CONSTRAINT [PK_IncidentFormReview] PRIMARY KEY CLUSTERED 
(
	[IncidentReviewID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[IncidentFormExplaination]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IncidentFormExplaination]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[IncidentFormExplaination](
	[FormExplainationID] [int] IDENTITY(1,1) NOT NULL,
	[IncidentID] [int] NOT NULL,
	[ExplanedOnFormID] [int] NOT NULL,
	[ExplanedFormID] [int] NOT NULL,
	[RptId] [varchar](20) NOT NULL,
	[RptStatus] [varchar](20) NOT NULL,
	[UpdatedBy] [varchar](20) NULL,
	[UpdatedOn] [datetime] NULL,
	[CreatedBy] [varchar](20) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[IncidentReviewId] [int] NULL,
 CONSTRAINT [PK_IncidentFormExplaination] PRIMARY KEY CLUSTERED 
(
	[FormExplainationID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[IncidentFormData]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IncidentFormData]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[IncidentFormData](
	[FormDataID] [int] IDENTITY(1,1) NOT NULL,
	[IncidentID] [int] NULL,
	[EmpID] [varchar](20) NULL,
	[FormID] [int] NOT NULL,
	[UserRoleId] [int] NOT NULL,
	[XmlData] [xml] NULL,
	[CreatedOn] [datetime] NULL,
	[CreatedBy] [varchar](20) NULL,
	[UpdateOn] [datetime] NULL,
	[UpdateBy] [varchar](20) NULL,
	[Status] [varchar](25) NOT NULL,
 CONSTRAINT [PK_IncidentFormData] PRIMARY KEY CLUSTERED 
(
	[FormDataID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[IncidentDeputyForms]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IncidentDeputyForms]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[IncidentDeputyForms](
	[DeputyFormId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NOT NULL,
	[FormId] [int] NOT NULL,
	[DeputyEmpId] [varchar](20) NOT NULL,
	[SergeantEmpId] [varchar](20) NOT NULL,
	[SergeantStatus] [varchar](25) NOT NULL,
	[FormStatus] [varchar](25) NOT NULL,
 CONSTRAINT [PK_IncidentDeputyForms] PRIMARY KEY CLUSTERED 
(
	[DeputyFormId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[IncidentCFRTFlow]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IncidentCFRTFlow]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[IncidentCFRTFlow](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NOT NULL,
	[CFRTID] [varchar](25) NOT NULL,
	[CFRCID] [varchar](25) NOT NULL,
	[CRFCEmailId] [varchar](200) NOT NULL,
	[CRFCStatus] [varchar](20) NOT NULL,
	[CreatedBy] [varchar](25) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
 CONSTRAINT [PK_IncidentCFRTFlow] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[IncidentCategoryForm]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IncidentCategoryForm]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[IncidentCategoryForm](
	[CategoryFormID] [int] IDENTITY(1,1) NOT NULL,
	[IncidentID] [int] NOT NULL,
	[IncidentCategoryId] [int] NOT NULL,
	[FormID] [int] NOT NULL,
	[Status] [varchar](5) NOT NULL,
 CONSTRAINT [PK_IncidentCategoryForm] PRIMARY KEY CLUSTERED 
(
	[CategoryFormID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[IncidentCanineDeployment]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IncidentCanineDeployment]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[IncidentCanineDeployment](
	[IncidentCanineDeploymentId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NULL,
	[Area] [char](2) NULL,
	[Building] [char](2) NULL,
	[TOSOther] [char](2) NULL,
	[ApprehendingSuspect] [char](2) NULL,
	[ConductingSearch] [char](2) NULL,
	[ProtectingHandler] [char](2) NULL,
	[BOWOtherReason] [char](2) NULL,
	[Bite] [char](2) NULL,
	[TOIOther] [char](2) NULL,
	[BYAeroUnit] [char](2) NULL,
	[ByRadioCar] [char](2) NULL,
	[English] [char](2) NULL,
	[Spanish] [char](2) NULL,
	[Recorded] [char](2) NULL,
	[AnnouncementsNoneReason] [char](100) NULL,
	[AnnouncementMadeby] [char](2) NULL,
	[AnnouncementMadebyReason] [char](100) NULL,
	[CriminalHistory] [varchar](500) NULL,
	[Notifications] [varchar](500) NULL,
	[CreatedBy] [varchar](25) NULL,
	[CreatedOn] [datetime] NULL,
 CONSTRAINT [PK_IncidentCanineDeployment] PRIMARY KEY CLUSTERED 
(
	[IncidentCanineDeploymentId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[IncidentBusinessAddress]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IncidentBusinessAddress]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[IncidentBusinessAddress](
	[IncidentBusinessID] [int] IDENTITY(1,1) NOT NULL,
	[IncidentID] [int] NOT NULL,
	[Name] [varchar](50) NULL,
	[AddressNumber] [varchar](10) NOT NULL,
	[Street] [varchar](50) NULL,
	[City] [varchar](50) NULL,
	[Zip] [varchar](20) NULL,
	[CreatedBy] [varchar](20) NULL,
	[CreatedOn] [datetime] NULL,
 CONSTRAINT [PK_IncidentBusinessAddress] PRIMARY KEY CLUSTERED 
(
	[IncidentBusinessID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[IAB_RolledOut]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IAB_RolledOut]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[IAB_RolledOut](
	[IAB_RolledOutId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NULL,
	[UserId] [int] NULL,
 CONSTRAINT [PK_IAB_RolledOut] PRIMARY KEY CLUSTERED 
(
	[IAB_RolledOutId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[Address]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Address]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Address](
	[AddressId] [int] IDENTITY(1,1) NOT NULL,
	[AddressNumber] [varchar](500) NULL,
	[City] [varchar](50) NULL,
	[StationFacility] [varchar](150) NULL,
	[ZipCode] [varchar](50) NULL,
	[State] [varchar](50) NULL,
	[AddressTypeId] [int] NOT NULL,
	[Street] [varchar](100) NULL,
	[IncidentId] [int] NULL,
 CONSTRAINT [PK_Address] PRIMARY KEY CLUSTERED 
(
	[AddressId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[FormReviewRank]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FormReviewRank]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[FormReviewRank](
	[ReviewRankId] [int] IDENTITY(1,1) NOT NULL,
	[FormId] [int] NOT NULL,
	[ReviewRank] [int] NOT NULL,
	[Active] [bit] NOT NULL,
 CONSTRAINT [PK_FormReviewRank] PRIMARY KEY CLUSTERED 
(
	[ReviewRankId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[FormPermisssion]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FormPermisssion]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[FormPermisssion](
	[FormPermissionId] [int] IDENTITY(1,1) NOT NULL,
	[RoleId] [int] NOT NULL,
	[FormId] [int] NOT NULL,
	[IsViewOnly] [bit] NOT NULL,
 CONSTRAINT [PK_FormPermisssion] PRIMARY KEY CLUSTERED 
(
	[FormPermissionId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[FormApprovalorReject]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FormApprovalorReject]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[FormApprovalorReject](
	[ApprovalId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NOT NULL,
	[FormId] [int] NOT NULL,
	[ApproverRole] [varchar](10) NULL,
	[ActionBy] [varchar](20) NULL,
	[Name] [varchar](50) NULL,
	[FormFilledBy] [varchar](20) NULL,
	[IsApproved] [bit] NULL,
	[ActionDate] [datetime] NULL,
	[CreatedDate] [datetime] NULL
) ON [PRIMARY]
SET ANSI_PADDING OFF
ALTER TABLE [dbo].[FormApprovalorReject] ADD [EmployeeNo] [varchar](20) NULL
ALTER TABLE [dbo].[FormApprovalorReject] ADD [Assignment] [varchar](50) NULL
ALTER TABLE [dbo].[FormApprovalorReject] ADD [SRD] [varchar](50) NULL
ALTER TABLE [dbo].[FormApprovalorReject] ADD [Active] [bit] NULL
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[FormApprovalorReject]') AND name = N'PK_FormApprovalorReject')
ALTER TABLE [dbo].[FormApprovalorReject] ADD  CONSTRAINT [PK_FormApprovalorReject] PRIMARY KEY CLUSTERED 
(
	[ApprovalId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ChargeCode]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ChargeCode]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ChargeCode](
	[ChargeCodeId] [int] IDENTITY(1,1) NOT NULL,
	[CodeNumber] [varchar](20) NULL,
	[ChargeCodeTypeId] [int] NULL,
 CONSTRAINT [PK_ChargeCode] PRIMARY KEY CLUSTERED 
(
	[ChargeCodeId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[UofChildForm]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UofChildForm]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UofChildForm](
	[ChildFormId] [int] IDENTITY(1,1) NOT NULL,
	[ChildFormName] [varchar](250) NOT NULL,
	[ChildFormCode] [varchar](250) NOT NULL,
	[ChildFormDescription] [varchar](500) NULL,
	[FormId] [int] NOT NULL,
 CONSTRAINT [PK_UofChildForm] PRIMARY KEY CLUSTERED 
(
	[ChildFormId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[UoF_ChangeRole]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UoF_ChangeRole]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UoF_ChangeRole](
	[RoleId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NOT NULL,
	[URN] [varchar](20) NOT NULL,
	[EmployeeId] [varchar](20) NOT NULL,
	[Name] [varchar](50) NOT NULL,
	[ForceRank] [varchar](50) NOT NULL,
	[UoFRank] [varchar](50) NOT NULL,
	[ValidStill] [date] NOT NULL,
	[Active] [bit] NOT NULL,
	[CreatedOn] [date] NOT NULL,
	[CreatedBy] [varchar](20) NOT NULL,
 CONSTRAINT [PK_UoF_ChangeRole] PRIMARY KEY CLUSTERED 
(
	[RoleId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ReviewComments]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReviewComments]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ReviewComments](
	[ReviewCommentId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NOT NULL,
	[FormId] [int] NOT NULL,
	[ReviewComments] [varchar](max) NOT NULL,
	[CommentedBy] [varchar](25) NOT NULL,
	[AddressedBy] [varchar](25) NULL,
	[CreatedOn] [datetime] NOT NULL,
	[Status] [varchar](10) NOT NULL,
 CONSTRAINT [PK_ReviewComments] PRIMARY KEY CLUSTERED 
(
	[ReviewCommentId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[EmailNotifications]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EmailNotifications]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EmailNotifications](
	[EmailNotificationId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NOT NULL,
	[EmployeeNumber] [varchar](25) NULL,
	[Department] [varchar](100) NULL,
	[EmailId] [varchar](250) NOT NULL,
	[Sent] [bit] NULL,
	[Responded] [bit] NULL,
	[SentOn] [datetime] NOT NULL,
	[RespondedOn] [datetime] NULL,
	[Status] [varchar](20) NULL,
 CONSTRAINT [PK_EmailNotifications] PRIMARY KEY CLUSTERED 
(
	[EmailNotificationId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[User]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[User]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[User](
	[UserId] [int] IDENTITY(1,1) NOT NULL,
	[ForceEmployeeId] [varchar](20) NULL,
	[UserDetailId] [int] NOT NULL,
	[UserTypeId] [int] NOT NULL,
	[Active] [bit] NOT NULL,
 CONSTRAINT [PK_User] PRIMARY KEY CLUSTERED 
(
	[UserId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[UserContact]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserContact]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UserContact](
	[UserContactId] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [int] NULL,
	[ContactId] [int] NULL,
 CONSTRAINT [PK_UserContact] PRIMARY KEY CLUSTERED 
(
	[UserContactId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[UserAddress]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserAddress]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UserAddress](
	[UserAddressId] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [int] NOT NULL,
	[AddressId] [int] NOT NULL,
 CONSTRAINT [PK_UserAddress] PRIMARY KEY CLUSTERED 
(
	[UserAddressId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[ReturnComments]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReturnComments]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ReturnComments](
	[ReturnId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentReviewID] [int] NOT NULL,
	[EmployeeNumber] [varchar](25) NULL,
	[Comments] [varchar](max) NULL,
	[CreatedOn] [datetime] NULL,
	[Updatedby] [varchar](20) NULL,
	[UpdatedOn] [datetime] NULL,
	[CreatedBy] [varchar](20) NULL,
	[Status] [varchar](10) NULL,
 CONSTRAINT [PK_ReturnComments] PRIMARY KEY CLUSTERED 
(
	[ReturnId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[CFRT_RolledOut]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CFRT_RolledOut]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CFRT_RolledOut](
	[CFRT_RolledOutId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NULL,
	[UserId] [int] NULL,
 CONSTRAINT [PK_CFRT_RolledOut] PRIMARY KEY CLUSTERED 
(
	[CFRT_RolledOutId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[IncidentUser]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IncidentUser]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[IncidentUser](
	[IncidentUserId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NULL,
	[UserId] [int] NULL,
	[UserTypeId] [int] NULL,
	[ReviewerId] [varchar](20) NULL,
	[Createdon] [datetime] NULL,
 CONSTRAINT [PK_IncidentUser] PRIMARY KEY CLUSTERED 
(
	[IncidentUserId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[InmateInjury]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[InmateInjury]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[InmateInjury](
	[InmateInjuryId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentUserId] [int] NOT NULL,
	[IncidentId] [int] NOT NULL,
	[InmateInjuryXML] [text] NOT NULL,
	[Status] [varchar](50) NULL,
 CONSTRAINT [PK_InmateInjury_1] PRIMARY KEY CLUSTERED 
(
	[InmateInjuryId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ForceOnSuspect]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ForceOnSuspect]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ForceOnSuspect](
	[ForceOnSuspectId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentUserId] [int] NULL,
	[ForceId] [int] NULL,
 CONSTRAINT [PK_ForceOnSuspect] PRIMARY KEY CLUSTERED 
(
	[ForceOnSuspectId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[IncidentUserCopy]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IncidentUserCopy]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[IncidentUserCopy](
	[IncidentUserCopyId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentUserId] [int] NULL,
	[CopyToUserId] [int] NULL,
 CONSTRAINT [PK_IncidentUserCopy] PRIMARY KEY CLUSTERED 
(
	[IncidentUserCopyId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[IncidentUserChargeCode]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IncidentUserChargeCode]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[IncidentUserChargeCode](
	[IncidentUserChargeCodeId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentUserId] [int] NULL,
	[ChargeCodeId] [int] NULL,
 CONSTRAINT [PK_IncidentUserChargeCode] PRIMARY KEY CLUSTERED 
(
	[IncidentUserChargeCodeId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[IncidentUserWitness]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IncidentUserWitness]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[IncidentUserWitness](
	[IncidentUserWitnessId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentUserId] [int] NULL,
	[IsWitness] [char](2) NULL,
	[IsPresent] [char](2) NULL,
	[WitnessIntAwayfromInmates] [char](2) NULL,
	[ShiftType] [varchar](5) NULL
) ON [PRIMARY]
SET ANSI_PADDING ON
ALTER TABLE [dbo].[IncidentUserWitness] ADD [InmateType] [varchar](3) NULL
ALTER TABLE [dbo].[IncidentUserWitness] ADD [TransorRefuse] [varchar](2) NULL
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[IncidentUserWitness]') AND name = N'PK_IncidentUserWitness')
ALTER TABLE [dbo].[IncidentUserWitness] ADD  CONSTRAINT [PK_IncidentUserWitness] PRIMARY KEY CLUSTERED 
(
	[IncidentUserWitnessId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[IncidentUserSuspect]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IncidentUserSuspect]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[IncidentUserSuspect](
	[IncidentUserSuspectId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentUserId] [int] NULL,
	[BookingNumber] [varchar](10) NULL,
	[Armed] [varchar](10) NULL,
	[AkaLastname] [varchar](20) NULL,
	[AkaFirstname] [varchar](20) NULL,
	[AkaMiddleName] [varchar](20) NULL,
	[PrimaryPhno] [varchar](20) NULL,
	[SecondaryPhno] [varchar](20) NULL,
	[PhoneMode] [char](2) NULL,
	[PrimaryChargCode] [varchar](100) NULL,
	[SecondaryChargCode] [varchar](100) NULL,
	[CivilianResistance] [varchar](20) NULL,
	[Lifethreatening] [char](2) NULL,
	[Assulative] [char](2) NULL,
	[Perceivedarmed] [varchar](20) NULL,
	[CivilianConfirmedarmed] [varchar](20) NULL,
	[CivilianInjurySeverity] [varchar](20) NULL,
	[forecasting] [char](2) NULL,
	[TypeofForce] [varchar](100) NULL,
	[TypeOfInjury] [varchar](100) NULL,
	[SafetyChairUsed] [char](2) NULL,
	[CriminalHistory] [char](2) NULL,
	[TreatedOnScene] [char](2) NULL,
	[HospitalAdmission] [char](2) NULL,
	[InmatePhysicallyAssaultive] [char](2) NULL,
	[InmateRecalcitrant] [char](2) NULL,
	[InmateonInmateViolenceProvoked] [char](2) NULL,
	[InmateonInmateViolence] [char](2) NULL,
	[MultiPointRestraintsUsed] [char](2) NULL,
	[OthertypesofRestraints] [char](2) NULL,
	[MedicalRecordschecked] [char](2) NULL,
	[MedicalRestraintsUsed] [char](2) NULL,
	[forceusedasDiscipline] [char](2) NULL,
	[CorporalPunishment] [char](2) NULL,
	[cellExtraction] [char](2) NULL,
	[Extractionordered] [char](2) NULL,
	[InmateHarassed] [char](2) NULL,
	[SuspectInterviewedAwayfromInmates] [char](2) NULL,
	[TransorRefuse] [char](2) NULL,
	[OtherplannedUoF] [char](2) NULL,
	[UnderInfluence] [char](2) NULL,
	[Substance] [varchar](20) NULL,
	[factorinForce] [char](2) NULL,
	[LOCATIONOFFORCE] [varchar](100) NULL,
	[FORCEUSED] [varchar](100) NULL
) ON [PRIMARY]
SET ANSI_PADDING OFF
ALTER TABLE [dbo].[IncidentUserSuspect] ADD [PPhMode] [varchar](5) NULL
ALTER TABLE [dbo].[IncidentUserSuspect] ADD [SPhMode] [varchar](5) NULL
SET ANSI_PADDING ON
ALTER TABLE [dbo].[IncidentUserSuspect] ADD [CoronerCaseNumber] [varchar](15) NULL
ALTER TABLE [dbo].[IncidentUserSuspect] ADD [IsMentalHistory] [varchar](2) NULL
ALTER TABLE [dbo].[IncidentUserSuspect] ADD [SuspectConfArmedOther] [varchar](100) NULL
SET ANSI_PADDING OFF
ALTER TABLE [dbo].[IncidentUserSuspect] ADD [IspregnantInmate] [varchar](2) NULL
ALTER TABLE [dbo].[IncidentUserSuspect] ADD [SpecialHandling] [varchar](100) NULL
ALTER TABLE [dbo].[IncidentUserSuspect] ADD [SecurityLevel] [varchar](100) NULL
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[IncidentUserSuspect]') AND name = N'PK_IncidentUserSuspect')
ALTER TABLE [dbo].[IncidentUserSuspect] ADD  CONSTRAINT [PK_IncidentUserSuspect] PRIMARY KEY CLUSTERED 
(
	[IncidentUserSuspectId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[IncidentUserInvolved]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IncidentUserInvolved]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[IncidentUserInvolved](
	[IncidentUserInvolvedId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentUserId] [int] NULL,
	[TypeOfForce] [varchar](20) NULL,
	[InjurySeverity] [varchar](20) NULL,
	[Isforecasting] [char](2) NULL,
	[IndForceUsed] [varchar](250) NULL,
	[IndividualCatId] [int] NULL,
	[IsDirected] [char](2) NULL,
	[DirectedEmplId] [varchar](20) NULL,
	[IsRescue] [char](2) NULL,
	[IsMedicalAssist] [char](2) NULL,
	[IsInjured] [char](2) NULL,
	[IsTreated] [char](2) NULL,
	[IsAdmitted] [char](2) NULL,
	[Facility] [varchar](250) NULL,
	[CoronerCaseId] [varchar](20) NULL,
	[DateOfBirth] [date] NULL,
	[EmployeeItemNumber] [varchar](20) NULL,
	[DepartmentHireDate] [datetime] NULL,
	[LastPromotionDate] [datetime] NULL,
	[DepartmentTenureInDays] [int] NULL,
	[RankTenureIndays] [int] NULL,
	[IsEmployeeEscortSuspect] [char](2) NULL
) ON [PRIMARY]
SET ANSI_PADDING OFF
ALTER TABLE [dbo].[IncidentUserInvolved] ADD [DVERT] [char](2) NULL
ALTER TABLE [dbo].[IncidentUserInvolved] ADD [InvolvementType] [char](2) NULL
ALTER TABLE [dbo].[IncidentUserInvolved] ADD [ShiftType] [varchar](5) NULL
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[IncidentUserInvolved]') AND name = N'PK_IncidentUserInvolved')
ALTER TABLE [dbo].[IncidentUserInvolved] ADD  CONSTRAINT [PK_IncidentUserInvolved] PRIMARY KEY CLUSTERED 
(
	[IncidentUserInvolvedId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[IncidentUserInterview]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IncidentUserInterview]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[IncidentUserInterview](
	[IncidentUserInterviewId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentUserId] [int] NULL,
	[InterviewDate] [datetime] NULL,
	[IsAudioTape] [char](2) NULL,
	[IsVideoType] [char](2) NULL,
	[IsInjuryPhoto] [char](2) NULL,
	[IsHearingAdmits] [char](2) NULL
) ON [PRIMARY]
SET ANSI_PADDING OFF
ALTER TABLE [dbo].[IncidentUserInterview] ADD [InterviewTime] [varchar](10) NULL
ALTER TABLE [dbo].[IncidentUserInterview] ADD [AudioPath] [varchar](100) NULL
ALTER TABLE [dbo].[IncidentUserInterview] ADD [VideoPath] [varchar](100) NULL
ALTER TABLE [dbo].[IncidentUserInterview] ADD [PhotosPath] [varchar](100) NULL
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[IncidentUserInterview]') AND name = N'PK_IncidentUserInterview')
ALTER TABLE [dbo].[IncidentUserInterview] ADD  CONSTRAINT [PK_IncidentUserInterview] PRIMARY KEY CLUSTERED 
(
	[IncidentUserInterviewId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Treatment]    Script Date: 05/30/2017 22:53:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Treatment]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Treatment](
	[TreatmentId] [int] IDENTITY(1,1) NOT NULL,
	[HospitalId] [int] NULL,
	[AddressId] [int] NULL,
	[TreatedBy] [varchar](15) NULL,
	[TreatedUnit] [varchar](15) NULL,
	[CoronerCaseNumber] [varchar](15) NULL,
	[IsMentalHistory] [char](2) NULL,
	[PhoneNumber] [varchar](15) NULL,
	[IncidentUserSuspectId] [int] NULL,
 CONSTRAINT [PK_Treatment] PRIMARY KEY CLUSTERED 
(
	[TreatmentId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Default [DF_ArtifactsInformation_UplodedDate]    Script Date: 05/30/2017 22:53:56 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_ArtifactsInformation_UplodedDate]') AND parent_object_id = OBJECT_ID(N'[dbo].[ArtifactsInformation]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_ArtifactsInformation_UplodedDate]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[ArtifactsInformation] ADD  CONSTRAINT [DF_ArtifactsInformation_UplodedDate]  DEFAULT (getdate()) FOR [UplodedDate]
END


End
GO
/****** Object:  Default [DF_IncidentSergeant_CreatedOn]    Script Date: 05/30/2017 22:53:56 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_IncidentSergeant_CreatedOn]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentSergeant]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_IncidentSergeant_CreatedOn]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[IncidentSergeant] ADD  CONSTRAINT [DF_IncidentSergeant_CreatedOn]  DEFAULT (getdate()) FOR [CreatedOn]
END


End
GO
/****** Object:  Default [DF__IncidentF__FormD__00200768]    Script Date: 05/30/2017 22:53:56 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF__IncidentF__FormD__00200768]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentFormReview]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF__IncidentF__FormD__00200768]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[IncidentFormReview] ADD  DEFAULT ((0)) FOR [FormDataID]
END


End
GO
/****** Object:  Default [DF__IncidentF__Incid__7F2BE32F]    Script Date: 05/30/2017 22:53:56 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF__IncidentF__Incid__7F2BE32F]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentFormExplaination]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF__IncidentF__Incid__7F2BE32F]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[IncidentFormExplaination] ADD  DEFAULT ((0)) FOR [IncidentReviewId]
END


End
GO
/****** Object:  Default [DF_FormReviewRank_Status]    Script Date: 05/30/2017 22:53:56 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_FormReviewRank_Status]') AND parent_object_id = OBJECT_ID(N'[dbo].[FormReviewRank]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_FormReviewRank_Status]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[FormReviewRank] ADD  CONSTRAINT [DF_FormReviewRank_Status]  DEFAULT ((0)) FOR [Active]
END


End
GO
/****** Object:  Default [DF_FormPermisssion_IsViewOnly]    Script Date: 05/30/2017 22:53:56 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_FormPermisssion_IsViewOnly]') AND parent_object_id = OBJECT_ID(N'[dbo].[FormPermisssion]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_FormPermisssion_IsViewOnly]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[FormPermisssion] ADD  CONSTRAINT [DF_FormPermisssion_IsViewOnly]  DEFAULT ((0)) FOR [IsViewOnly]
END


End
GO
/****** Object:  ForeignKey [FK_IncidentStatisticalData_Incident]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentStatisticalData_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentStatisticalData]'))
ALTER TABLE [dbo].[IncidentStatisticalData]  WITH CHECK ADD  CONSTRAINT [FK_IncidentStatisticalData_Incident] FOREIGN KEY([IncidentId])
REFERENCES [dbo].[Incident] ([IncidentId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentStatisticalData_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentStatisticalData]'))
ALTER TABLE [dbo].[IncidentStatisticalData] CHECK CONSTRAINT [FK_IncidentStatisticalData_Incident]
GO
/****** Object:  ForeignKey [FK_IncidentSergeant_IncidentSergeant]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentSergeant_IncidentSergeant]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentSergeant]'))
ALTER TABLE [dbo].[IncidentSergeant]  WITH CHECK ADD  CONSTRAINT [FK_IncidentSergeant_IncidentSergeant] FOREIGN KEY([IncidentId])
REFERENCES [dbo].[Incident] ([IncidentId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentSergeant_IncidentSergeant]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentSergeant]'))
ALTER TABLE [dbo].[IncidentSergeant] CHECK CONSTRAINT [FK_IncidentSergeant_IncidentSergeant]
GO
/****** Object:  ForeignKey [FK_IncidentRank_Incident]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentRank_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentRank]'))
ALTER TABLE [dbo].[IncidentRank]  WITH CHECK ADD  CONSTRAINT [FK_IncidentRank_Incident] FOREIGN KEY([IncidentId])
REFERENCES [dbo].[Incident] ([IncidentId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentRank_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentRank]'))
ALTER TABLE [dbo].[IncidentRank] CHECK CONSTRAINT [FK_IncidentRank_Incident]
GO
/****** Object:  ForeignKey [FK_IncidentPlanned_Incident]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentPlanned_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentPlannedForce]'))
ALTER TABLE [dbo].[IncidentPlannedForce]  WITH CHECK ADD  CONSTRAINT [FK_IncidentPlanned_Incident] FOREIGN KEY([IncidentId])
REFERENCES [dbo].[Incident] ([IncidentId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentPlanned_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentPlannedForce]'))
ALTER TABLE [dbo].[IncidentPlannedForce] CHECK CONSTRAINT [FK_IncidentPlanned_Incident]
GO
/****** Object:  ForeignKey [FK_IncidentMedicalUser_Incident]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentMedicalUser_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentMedicalUser]'))
ALTER TABLE [dbo].[IncidentMedicalUser]  WITH CHECK ADD  CONSTRAINT [FK_IncidentMedicalUser_Incident] FOREIGN KEY([IncidentId])
REFERENCES [dbo].[Incident] ([IncidentId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentMedicalUser_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentMedicalUser]'))
ALTER TABLE [dbo].[IncidentMedicalUser] CHECK CONSTRAINT [FK_IncidentMedicalUser_Incident]
GO
/****** Object:  ForeignKey [FK_IncidentInvestigationOfficer_Incident]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentInvestigationOfficer_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentInvestigationOfficer]'))
ALTER TABLE [dbo].[IncidentInvestigationOfficer]  WITH CHECK ADD  CONSTRAINT [FK_IncidentInvestigationOfficer_Incident] FOREIGN KEY([IncidentId])
REFERENCES [dbo].[Incident] ([IncidentId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentInvestigationOfficer_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentInvestigationOfficer]'))
ALTER TABLE [dbo].[IncidentInvestigationOfficer] CHECK CONSTRAINT [FK_IncidentInvestigationOfficer_Incident]
GO
/****** Object:  ForeignKey [FK_IncidentFormReview_Incident]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentFormReview_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentFormReview]'))
ALTER TABLE [dbo].[IncidentFormReview]  WITH CHECK ADD  CONSTRAINT [FK_IncidentFormReview_Incident] FOREIGN KEY([IncidentID])
REFERENCES [dbo].[Incident] ([IncidentId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentFormReview_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentFormReview]'))
ALTER TABLE [dbo].[IncidentFormReview] CHECK CONSTRAINT [FK_IncidentFormReview_Incident]
GO
/****** Object:  ForeignKey [FK_IncidentFormReview_UofForm]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentFormReview_UofForm]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentFormReview]'))
ALTER TABLE [dbo].[IncidentFormReview]  WITH CHECK ADD  CONSTRAINT [FK_IncidentFormReview_UofForm] FOREIGN KEY([FormId])
REFERENCES [dbo].[UofForm] ([FormId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentFormReview_UofForm]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentFormReview]'))
ALTER TABLE [dbo].[IncidentFormReview] CHECK CONSTRAINT [FK_IncidentFormReview_UofForm]
GO
/****** Object:  ForeignKey [FK_IncidentFormExplaination_Incident]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentFormExplaination_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentFormExplaination]'))
ALTER TABLE [dbo].[IncidentFormExplaination]  WITH CHECK ADD  CONSTRAINT [FK_IncidentFormExplaination_Incident] FOREIGN KEY([IncidentID])
REFERENCES [dbo].[Incident] ([IncidentId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentFormExplaination_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentFormExplaination]'))
ALTER TABLE [dbo].[IncidentFormExplaination] CHECK CONSTRAINT [FK_IncidentFormExplaination_Incident]
GO
/****** Object:  ForeignKey [FK_IncidentFormExplaination_UofForm]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentFormExplaination_UofForm]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentFormExplaination]'))
ALTER TABLE [dbo].[IncidentFormExplaination]  WITH CHECK ADD  CONSTRAINT [FK_IncidentFormExplaination_UofForm] FOREIGN KEY([ExplanedOnFormID])
REFERENCES [dbo].[UofForm] ([FormId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentFormExplaination_UofForm]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentFormExplaination]'))
ALTER TABLE [dbo].[IncidentFormExplaination] CHECK CONSTRAINT [FK_IncidentFormExplaination_UofForm]
GO
/****** Object:  ForeignKey [FK_IncidentFormExplaination_UofForm1]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentFormExplaination_UofForm1]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentFormExplaination]'))
ALTER TABLE [dbo].[IncidentFormExplaination]  WITH CHECK ADD  CONSTRAINT [FK_IncidentFormExplaination_UofForm1] FOREIGN KEY([ExplanedFormID])
REFERENCES [dbo].[UofForm] ([FormId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentFormExplaination_UofForm1]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentFormExplaination]'))
ALTER TABLE [dbo].[IncidentFormExplaination] CHECK CONSTRAINT [FK_IncidentFormExplaination_UofForm1]
GO
/****** Object:  ForeignKey [FK_IncidentFormData_UofForm]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentFormData_UofForm]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentFormData]'))
ALTER TABLE [dbo].[IncidentFormData]  WITH CHECK ADD  CONSTRAINT [FK_IncidentFormData_UofForm] FOREIGN KEY([FormID])
REFERENCES [dbo].[UofForm] ([FormId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentFormData_UofForm]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentFormData]'))
ALTER TABLE [dbo].[IncidentFormData] CHECK CONSTRAINT [FK_IncidentFormData_UofForm]
GO
/****** Object:  ForeignKey [FK_IncidentFormData_UserRole]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentFormData_UserRole]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentFormData]'))
ALTER TABLE [dbo].[IncidentFormData]  WITH CHECK ADD  CONSTRAINT [FK_IncidentFormData_UserRole] FOREIGN KEY([UserRoleId])
REFERENCES [dbo].[UserRole] ([RoleId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentFormData_UserRole]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentFormData]'))
ALTER TABLE [dbo].[IncidentFormData] CHECK CONSTRAINT [FK_IncidentFormData_UserRole]
GO
/****** Object:  ForeignKey [FK_IncidentDeputyForms_Incident]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentDeputyForms_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentDeputyForms]'))
ALTER TABLE [dbo].[IncidentDeputyForms]  WITH CHECK ADD  CONSTRAINT [FK_IncidentDeputyForms_Incident] FOREIGN KEY([IncidentId])
REFERENCES [dbo].[Incident] ([IncidentId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentDeputyForms_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentDeputyForms]'))
ALTER TABLE [dbo].[IncidentDeputyForms] CHECK CONSTRAINT [FK_IncidentDeputyForms_Incident]
GO
/****** Object:  ForeignKey [FK_IncidentDeputyForms_UofForm]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentDeputyForms_UofForm]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentDeputyForms]'))
ALTER TABLE [dbo].[IncidentDeputyForms]  WITH CHECK ADD  CONSTRAINT [FK_IncidentDeputyForms_UofForm] FOREIGN KEY([FormId])
REFERENCES [dbo].[UofForm] ([FormId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentDeputyForms_UofForm]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentDeputyForms]'))
ALTER TABLE [dbo].[IncidentDeputyForms] CHECK CONSTRAINT [FK_IncidentDeputyForms_UofForm]
GO
/****** Object:  ForeignKey [FK_IncidentCFRTFlow_Incident]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentCFRTFlow_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentCFRTFlow]'))
ALTER TABLE [dbo].[IncidentCFRTFlow]  WITH CHECK ADD  CONSTRAINT [FK_IncidentCFRTFlow_Incident] FOREIGN KEY([IncidentId])
REFERENCES [dbo].[Incident] ([IncidentId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentCFRTFlow_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentCFRTFlow]'))
ALTER TABLE [dbo].[IncidentCFRTFlow] CHECK CONSTRAINT [FK_IncidentCFRTFlow_Incident]
GO
/****** Object:  ForeignKey [FK_IncidentCategoryForm_IncidentCategoryForm]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentCategoryForm_IncidentCategoryForm]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentCategoryForm]'))
ALTER TABLE [dbo].[IncidentCategoryForm]  WITH CHECK ADD  CONSTRAINT [FK_IncidentCategoryForm_IncidentCategoryForm] FOREIGN KEY([IncidentID])
REFERENCES [dbo].[Incident] ([IncidentId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentCategoryForm_IncidentCategoryForm]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentCategoryForm]'))
ALTER TABLE [dbo].[IncidentCategoryForm] CHECK CONSTRAINT [FK_IncidentCategoryForm_IncidentCategoryForm]
GO
/****** Object:  ForeignKey [FK_IncidentCanineDeployment_Incident]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentCanineDeployment_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentCanineDeployment]'))
ALTER TABLE [dbo].[IncidentCanineDeployment]  WITH CHECK ADD  CONSTRAINT [FK_IncidentCanineDeployment_Incident] FOREIGN KEY([IncidentId])
REFERENCES [dbo].[Incident] ([IncidentId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentCanineDeployment_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentCanineDeployment]'))
ALTER TABLE [dbo].[IncidentCanineDeployment] CHECK CONSTRAINT [FK_IncidentCanineDeployment_Incident]
GO
/****** Object:  ForeignKey [FK_IncidentBusinessAddress_Incident]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentBusinessAddress_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentBusinessAddress]'))
ALTER TABLE [dbo].[IncidentBusinessAddress]  WITH CHECK ADD  CONSTRAINT [FK_IncidentBusinessAddress_Incident] FOREIGN KEY([IncidentID])
REFERENCES [dbo].[Incident] ([IncidentId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentBusinessAddress_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentBusinessAddress]'))
ALTER TABLE [dbo].[IncidentBusinessAddress] CHECK CONSTRAINT [FK_IncidentBusinessAddress_Incident]
GO
/****** Object:  ForeignKey [FK_IAB_RolledOut_Incident]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IAB_RolledOut_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IAB_RolledOut]'))
ALTER TABLE [dbo].[IAB_RolledOut]  WITH CHECK ADD  CONSTRAINT [FK_IAB_RolledOut_Incident] FOREIGN KEY([IncidentId])
REFERENCES [dbo].[Incident] ([IncidentId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IAB_RolledOut_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IAB_RolledOut]'))
ALTER TABLE [dbo].[IAB_RolledOut] CHECK CONSTRAINT [FK_IAB_RolledOut_Incident]
GO
/****** Object:  ForeignKey [FK_Address_AddressType]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Address_AddressType]') AND parent_object_id = OBJECT_ID(N'[dbo].[Address]'))
ALTER TABLE [dbo].[Address]  WITH CHECK ADD  CONSTRAINT [FK_Address_AddressType] FOREIGN KEY([AddressTypeId])
REFERENCES [dbo].[AddressType] ([AddressTypeId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Address_AddressType]') AND parent_object_id = OBJECT_ID(N'[dbo].[Address]'))
ALTER TABLE [dbo].[Address] CHECK CONSTRAINT [FK_Address_AddressType]
GO
/****** Object:  ForeignKey [FK_Incident_Address]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Incident_Address]') AND parent_object_id = OBJECT_ID(N'[dbo].[Address]'))
ALTER TABLE [dbo].[Address]  WITH CHECK ADD  CONSTRAINT [FK_Incident_Address] FOREIGN KEY([IncidentId])
REFERENCES [dbo].[Incident] ([IncidentId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Incident_Address]') AND parent_object_id = OBJECT_ID(N'[dbo].[Address]'))
ALTER TABLE [dbo].[Address] CHECK CONSTRAINT [FK_Incident_Address]
GO
/****** Object:  ForeignKey [FK_FormReviewRank_FormReviewRank]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_FormReviewRank_FormReviewRank]') AND parent_object_id = OBJECT_ID(N'[dbo].[FormReviewRank]'))
ALTER TABLE [dbo].[FormReviewRank]  WITH CHECK ADD  CONSTRAINT [FK_FormReviewRank_FormReviewRank] FOREIGN KEY([FormId])
REFERENCES [dbo].[UofForm] ([FormId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_FormReviewRank_FormReviewRank]') AND parent_object_id = OBJECT_ID(N'[dbo].[FormReviewRank]'))
ALTER TABLE [dbo].[FormReviewRank] CHECK CONSTRAINT [FK_FormReviewRank_FormReviewRank]
GO
/****** Object:  ForeignKey [FK_FormPermisssion_UofForm]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_FormPermisssion_UofForm]') AND parent_object_id = OBJECT_ID(N'[dbo].[FormPermisssion]'))
ALTER TABLE [dbo].[FormPermisssion]  WITH CHECK ADD  CONSTRAINT [FK_FormPermisssion_UofForm] FOREIGN KEY([FormId])
REFERENCES [dbo].[UofForm] ([FormId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_FormPermisssion_UofForm]') AND parent_object_id = OBJECT_ID(N'[dbo].[FormPermisssion]'))
ALTER TABLE [dbo].[FormPermisssion] CHECK CONSTRAINT [FK_FormPermisssion_UofForm]
GO
/****** Object:  ForeignKey [FK_FormPermisssion_UserRole]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_FormPermisssion_UserRole]') AND parent_object_id = OBJECT_ID(N'[dbo].[FormPermisssion]'))
ALTER TABLE [dbo].[FormPermisssion]  WITH CHECK ADD  CONSTRAINT [FK_FormPermisssion_UserRole] FOREIGN KEY([RoleId])
REFERENCES [dbo].[UserRole] ([RoleId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_FormPermisssion_UserRole]') AND parent_object_id = OBJECT_ID(N'[dbo].[FormPermisssion]'))
ALTER TABLE [dbo].[FormPermisssion] CHECK CONSTRAINT [FK_FormPermisssion_UserRole]
GO
/****** Object:  ForeignKey [FK_FormApprovalorReject_Incident]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_FormApprovalorReject_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[FormApprovalorReject]'))
ALTER TABLE [dbo].[FormApprovalorReject]  WITH CHECK ADD  CONSTRAINT [FK_FormApprovalorReject_Incident] FOREIGN KEY([IncidentId])
REFERENCES [dbo].[Incident] ([IncidentId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_FormApprovalorReject_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[FormApprovalorReject]'))
ALTER TABLE [dbo].[FormApprovalorReject] CHECK CONSTRAINT [FK_FormApprovalorReject_Incident]
GO
/****** Object:  ForeignKey [FK_FormApprovalorReject_UofForm]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_FormApprovalorReject_UofForm]') AND parent_object_id = OBJECT_ID(N'[dbo].[FormApprovalorReject]'))
ALTER TABLE [dbo].[FormApprovalorReject]  WITH CHECK ADD  CONSTRAINT [FK_FormApprovalorReject_UofForm] FOREIGN KEY([FormId])
REFERENCES [dbo].[UofForm] ([FormId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_FormApprovalorReject_UofForm]') AND parent_object_id = OBJECT_ID(N'[dbo].[FormApprovalorReject]'))
ALTER TABLE [dbo].[FormApprovalorReject] CHECK CONSTRAINT [FK_FormApprovalorReject_UofForm]
GO
/****** Object:  ForeignKey [FK_ChargeCode_ChargeCodeType]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ChargeCode_ChargeCodeType]') AND parent_object_id = OBJECT_ID(N'[dbo].[ChargeCode]'))
ALTER TABLE [dbo].[ChargeCode]  WITH CHECK ADD  CONSTRAINT [FK_ChargeCode_ChargeCodeType] FOREIGN KEY([ChargeCodeTypeId])
REFERENCES [dbo].[ChargeCodeType] ([ChargeCodeTypeId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ChargeCode_ChargeCodeType]') AND parent_object_id = OBJECT_ID(N'[dbo].[ChargeCode]'))
ALTER TABLE [dbo].[ChargeCode] CHECK CONSTRAINT [FK_ChargeCode_ChargeCodeType]
GO
/****** Object:  ForeignKey [FK_UofChildForm_UofForm]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UofChildForm_UofForm]') AND parent_object_id = OBJECT_ID(N'[dbo].[UofChildForm]'))
ALTER TABLE [dbo].[UofChildForm]  WITH CHECK ADD  CONSTRAINT [FK_UofChildForm_UofForm] FOREIGN KEY([FormId])
REFERENCES [dbo].[UofForm] ([FormId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UofChildForm_UofForm]') AND parent_object_id = OBJECT_ID(N'[dbo].[UofChildForm]'))
ALTER TABLE [dbo].[UofChildForm] CHECK CONSTRAINT [FK_UofChildForm_UofForm]
GO
/****** Object:  ForeignKey [FK_UoF_ChangeRole_Incident]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UoF_ChangeRole_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[UoF_ChangeRole]'))
ALTER TABLE [dbo].[UoF_ChangeRole]  WITH CHECK ADD  CONSTRAINT [FK_UoF_ChangeRole_Incident] FOREIGN KEY([IncidentId])
REFERENCES [dbo].[Incident] ([IncidentId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UoF_ChangeRole_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[UoF_ChangeRole]'))
ALTER TABLE [dbo].[UoF_ChangeRole] CHECK CONSTRAINT [FK_UoF_ChangeRole_Incident]
GO
/****** Object:  ForeignKey [FK_ReviewComments_Incident]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ReviewComments_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[ReviewComments]'))
ALTER TABLE [dbo].[ReviewComments]  WITH CHECK ADD  CONSTRAINT [FK_ReviewComments_Incident] FOREIGN KEY([IncidentId])
REFERENCES [dbo].[Incident] ([IncidentId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ReviewComments_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[ReviewComments]'))
ALTER TABLE [dbo].[ReviewComments] CHECK CONSTRAINT [FK_ReviewComments_Incident]
GO
/****** Object:  ForeignKey [FK_ReviewComments_UofForm]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ReviewComments_UofForm]') AND parent_object_id = OBJECT_ID(N'[dbo].[ReviewComments]'))
ALTER TABLE [dbo].[ReviewComments]  WITH CHECK ADD  CONSTRAINT [FK_ReviewComments_UofForm] FOREIGN KEY([FormId])
REFERENCES [dbo].[UofForm] ([FormId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ReviewComments_UofForm]') AND parent_object_id = OBJECT_ID(N'[dbo].[ReviewComments]'))
ALTER TABLE [dbo].[ReviewComments] CHECK CONSTRAINT [FK_ReviewComments_UofForm]
GO
/****** Object:  ForeignKey [FK_EmailNotifications_Incident]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_EmailNotifications_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[EmailNotifications]'))
ALTER TABLE [dbo].[EmailNotifications]  WITH CHECK ADD  CONSTRAINT [FK_EmailNotifications_Incident] FOREIGN KEY([IncidentId])
REFERENCES [dbo].[Incident] ([IncidentId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_EmailNotifications_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[EmailNotifications]'))
ALTER TABLE [dbo].[EmailNotifications] CHECK CONSTRAINT [FK_EmailNotifications_Incident]
GO
/****** Object:  ForeignKey [FK_User_UserDetail]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_User_UserDetail]') AND parent_object_id = OBJECT_ID(N'[dbo].[User]'))
ALTER TABLE [dbo].[User]  WITH CHECK ADD  CONSTRAINT [FK_User_UserDetail] FOREIGN KEY([UserDetailId])
REFERENCES [dbo].[UserDetail] ([UserDetailId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_User_UserDetail]') AND parent_object_id = OBJECT_ID(N'[dbo].[User]'))
ALTER TABLE [dbo].[User] CHECK CONSTRAINT [FK_User_UserDetail]
GO
/****** Object:  ForeignKey [FK_User_UserType]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_User_UserType]') AND parent_object_id = OBJECT_ID(N'[dbo].[User]'))
ALTER TABLE [dbo].[User]  WITH CHECK ADD  CONSTRAINT [FK_User_UserType] FOREIGN KEY([UserTypeId])
REFERENCES [dbo].[UserType] ([UserTypeId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_User_UserType]') AND parent_object_id = OBJECT_ID(N'[dbo].[User]'))
ALTER TABLE [dbo].[User] CHECK CONSTRAINT [FK_User_UserType]
GO
/****** Object:  ForeignKey [FK_UserContact_Contact]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserContact_Contact]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserContact]'))
ALTER TABLE [dbo].[UserContact]  WITH CHECK ADD  CONSTRAINT [FK_UserContact_Contact] FOREIGN KEY([ContactId])
REFERENCES [dbo].[Contact] ([ContactId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserContact_Contact]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserContact]'))
ALTER TABLE [dbo].[UserContact] CHECK CONSTRAINT [FK_UserContact_Contact]
GO
/****** Object:  ForeignKey [FK_UserContact_User]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserContact_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserContact]'))
ALTER TABLE [dbo].[UserContact]  WITH CHECK ADD  CONSTRAINT [FK_UserContact_User] FOREIGN KEY([UserId])
REFERENCES [dbo].[User] ([UserId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserContact_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserContact]'))
ALTER TABLE [dbo].[UserContact] CHECK CONSTRAINT [FK_UserContact_User]
GO
/****** Object:  ForeignKey [FK_UserAddress_Address]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserAddress_Address]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserAddress]'))
ALTER TABLE [dbo].[UserAddress]  WITH CHECK ADD  CONSTRAINT [FK_UserAddress_Address] FOREIGN KEY([AddressId])
REFERENCES [dbo].[Address] ([AddressId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserAddress_Address]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserAddress]'))
ALTER TABLE [dbo].[UserAddress] CHECK CONSTRAINT [FK_UserAddress_Address]
GO
/****** Object:  ForeignKey [FK_UserAddress_User]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserAddress_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserAddress]'))
ALTER TABLE [dbo].[UserAddress]  WITH CHECK ADD  CONSTRAINT [FK_UserAddress_User] FOREIGN KEY([UserId])
REFERENCES [dbo].[User] ([UserId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UserAddress_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[UserAddress]'))
ALTER TABLE [dbo].[UserAddress] CHECK CONSTRAINT [FK_UserAddress_User]
GO
/****** Object:  ForeignKey [FK_ReturnComments_IncidentFormReview]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ReturnComments_IncidentFormReview]') AND parent_object_id = OBJECT_ID(N'[dbo].[ReturnComments]'))
ALTER TABLE [dbo].[ReturnComments]  WITH CHECK ADD  CONSTRAINT [FK_ReturnComments_IncidentFormReview] FOREIGN KEY([IncidentReviewID])
REFERENCES [dbo].[IncidentFormReview] ([IncidentReviewID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ReturnComments_IncidentFormReview]') AND parent_object_id = OBJECT_ID(N'[dbo].[ReturnComments]'))
ALTER TABLE [dbo].[ReturnComments] CHECK CONSTRAINT [FK_ReturnComments_IncidentFormReview]
GO
/****** Object:  ForeignKey [FK_CFRT_RolledOut_Incident]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_CFRT_RolledOut_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[CFRT_RolledOut]'))
ALTER TABLE [dbo].[CFRT_RolledOut]  WITH CHECK ADD  CONSTRAINT [FK_CFRT_RolledOut_Incident] FOREIGN KEY([IncidentId])
REFERENCES [dbo].[Incident] ([IncidentId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_CFRT_RolledOut_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[CFRT_RolledOut]'))
ALTER TABLE [dbo].[CFRT_RolledOut] CHECK CONSTRAINT [FK_CFRT_RolledOut_Incident]
GO
/****** Object:  ForeignKey [FK_CFRT_RolledOut_User]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_CFRT_RolledOut_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[CFRT_RolledOut]'))
ALTER TABLE [dbo].[CFRT_RolledOut]  WITH CHECK ADD  CONSTRAINT [FK_CFRT_RolledOut_User] FOREIGN KEY([UserId])
REFERENCES [dbo].[User] ([UserId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_CFRT_RolledOut_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[CFRT_RolledOut]'))
ALTER TABLE [dbo].[CFRT_RolledOut] CHECK CONSTRAINT [FK_CFRT_RolledOut_User]
GO
/****** Object:  ForeignKey [FK_IncidentUser_Incident]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentUser_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentUser]'))
ALTER TABLE [dbo].[IncidentUser]  WITH CHECK ADD  CONSTRAINT [FK_IncidentUser_Incident] FOREIGN KEY([IncidentId])
REFERENCES [dbo].[Incident] ([IncidentId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentUser_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentUser]'))
ALTER TABLE [dbo].[IncidentUser] CHECK CONSTRAINT [FK_IncidentUser_Incident]
GO
/****** Object:  ForeignKey [FK_IncidentUser_User]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentUser_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentUser]'))
ALTER TABLE [dbo].[IncidentUser]  WITH CHECK ADD  CONSTRAINT [FK_IncidentUser_User] FOREIGN KEY([UserId])
REFERENCES [dbo].[User] ([UserId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentUser_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentUser]'))
ALTER TABLE [dbo].[IncidentUser] CHECK CONSTRAINT [FK_IncidentUser_User]
GO
/****** Object:  ForeignKey [FK_IncidentUser_UserType]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentUser_UserType]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentUser]'))
ALTER TABLE [dbo].[IncidentUser]  WITH CHECK ADD  CONSTRAINT [FK_IncidentUser_UserType] FOREIGN KEY([UserTypeId])
REFERENCES [dbo].[UserType] ([UserTypeId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentUser_UserType]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentUser]'))
ALTER TABLE [dbo].[IncidentUser] CHECK CONSTRAINT [FK_IncidentUser_UserType]
GO
/****** Object:  ForeignKey [FK_InmateInjury_Incident]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_InmateInjury_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[InmateInjury]'))
ALTER TABLE [dbo].[InmateInjury]  WITH CHECK ADD  CONSTRAINT [FK_InmateInjury_Incident] FOREIGN KEY([IncidentId])
REFERENCES [dbo].[Incident] ([IncidentId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_InmateInjury_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[InmateInjury]'))
ALTER TABLE [dbo].[InmateInjury] CHECK CONSTRAINT [FK_InmateInjury_Incident]
GO
/****** Object:  ForeignKey [FK_InmateInjury_IncidentUser]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_InmateInjury_IncidentUser]') AND parent_object_id = OBJECT_ID(N'[dbo].[InmateInjury]'))
ALTER TABLE [dbo].[InmateInjury]  WITH CHECK ADD  CONSTRAINT [FK_InmateInjury_IncidentUser] FOREIGN KEY([IncidentUserId])
REFERENCES [dbo].[IncidentUser] ([IncidentUserId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_InmateInjury_IncidentUser]') AND parent_object_id = OBJECT_ID(N'[dbo].[InmateInjury]'))
ALTER TABLE [dbo].[InmateInjury] CHECK CONSTRAINT [FK_InmateInjury_IncidentUser]
GO
/****** Object:  ForeignKey [FK_ForceOnSuspect_IncidentUser]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ForceOnSuspect_IncidentUser]') AND parent_object_id = OBJECT_ID(N'[dbo].[ForceOnSuspect]'))
ALTER TABLE [dbo].[ForceOnSuspect]  WITH CHECK ADD  CONSTRAINT [FK_ForceOnSuspect_IncidentUser] FOREIGN KEY([IncidentUserId])
REFERENCES [dbo].[IncidentUser] ([IncidentUserId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ForceOnSuspect_IncidentUser]') AND parent_object_id = OBJECT_ID(N'[dbo].[ForceOnSuspect]'))
ALTER TABLE [dbo].[ForceOnSuspect] CHECK CONSTRAINT [FK_ForceOnSuspect_IncidentUser]
GO
/****** Object:  ForeignKey [FK_IncidentUserCopy_IncidentUser]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentUserCopy_IncidentUser]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentUserCopy]'))
ALTER TABLE [dbo].[IncidentUserCopy]  WITH CHECK ADD  CONSTRAINT [FK_IncidentUserCopy_IncidentUser] FOREIGN KEY([IncidentUserId])
REFERENCES [dbo].[IncidentUser] ([IncidentUserId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentUserCopy_IncidentUser]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentUserCopy]'))
ALTER TABLE [dbo].[IncidentUserCopy] CHECK CONSTRAINT [FK_IncidentUserCopy_IncidentUser]
GO
/****** Object:  ForeignKey [FK_IncidentUserChargeCode_ChargeCode]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentUserChargeCode_ChargeCode]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentUserChargeCode]'))
ALTER TABLE [dbo].[IncidentUserChargeCode]  WITH CHECK ADD  CONSTRAINT [FK_IncidentUserChargeCode_ChargeCode] FOREIGN KEY([ChargeCodeId])
REFERENCES [dbo].[ChargeCode] ([ChargeCodeId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentUserChargeCode_ChargeCode]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentUserChargeCode]'))
ALTER TABLE [dbo].[IncidentUserChargeCode] CHECK CONSTRAINT [FK_IncidentUserChargeCode_ChargeCode]
GO
/****** Object:  ForeignKey [FK_IncidentUserChargeCode_IncidentUser]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentUserChargeCode_IncidentUser]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentUserChargeCode]'))
ALTER TABLE [dbo].[IncidentUserChargeCode]  WITH CHECK ADD  CONSTRAINT [FK_IncidentUserChargeCode_IncidentUser] FOREIGN KEY([IncidentUserId])
REFERENCES [dbo].[IncidentUser] ([IncidentUserId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentUserChargeCode_IncidentUser]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentUserChargeCode]'))
ALTER TABLE [dbo].[IncidentUserChargeCode] CHECK CONSTRAINT [FK_IncidentUserChargeCode_IncidentUser]
GO
/****** Object:  ForeignKey [FK_IncidentUserWitness_IncidentUser]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentUserWitness_IncidentUser]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentUserWitness]'))
ALTER TABLE [dbo].[IncidentUserWitness]  WITH CHECK ADD  CONSTRAINT [FK_IncidentUserWitness_IncidentUser] FOREIGN KEY([IncidentUserId])
REFERENCES [dbo].[IncidentUser] ([IncidentUserId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentUserWitness_IncidentUser]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentUserWitness]'))
ALTER TABLE [dbo].[IncidentUserWitness] CHECK CONSTRAINT [FK_IncidentUserWitness_IncidentUser]
GO
/****** Object:  ForeignKey [FK_IncidentUserSuspect_IncidentUser]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentUserSuspect_IncidentUser]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentUserSuspect]'))
ALTER TABLE [dbo].[IncidentUserSuspect]  WITH CHECK ADD  CONSTRAINT [FK_IncidentUserSuspect_IncidentUser] FOREIGN KEY([IncidentUserId])
REFERENCES [dbo].[IncidentUser] ([IncidentUserId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentUserSuspect_IncidentUser]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentUserSuspect]'))
ALTER TABLE [dbo].[IncidentUserSuspect] CHECK CONSTRAINT [FK_IncidentUserSuspect_IncidentUser]
GO
/****** Object:  ForeignKey [FK_IncidentUserInvolved_IncidentUser]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentUserInvolved_IncidentUser]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentUserInvolved]'))
ALTER TABLE [dbo].[IncidentUserInvolved]  WITH CHECK ADD  CONSTRAINT [FK_IncidentUserInvolved_IncidentUser] FOREIGN KEY([IncidentUserId])
REFERENCES [dbo].[IncidentUser] ([IncidentUserId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentUserInvolved_IncidentUser]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentUserInvolved]'))
ALTER TABLE [dbo].[IncidentUserInvolved] CHECK CONSTRAINT [FK_IncidentUserInvolved_IncidentUser]
GO
/****** Object:  ForeignKey [FK_IncidentUserInterview_IncidentUser]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentUserInterview_IncidentUser]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentUserInterview]'))
ALTER TABLE [dbo].[IncidentUserInterview]  WITH CHECK ADD  CONSTRAINT [FK_IncidentUserInterview_IncidentUser] FOREIGN KEY([IncidentUserId])
REFERENCES [dbo].[IncidentUser] ([IncidentUserId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentUserInterview_IncidentUser]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentUserInterview]'))
ALTER TABLE [dbo].[IncidentUserInterview] CHECK CONSTRAINT [FK_IncidentUserInterview_IncidentUser]
GO
/****** Object:  ForeignKey [FK_Treatment_Address]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Treatment_Address]') AND parent_object_id = OBJECT_ID(N'[dbo].[Treatment]'))
ALTER TABLE [dbo].[Treatment]  WITH CHECK ADD  CONSTRAINT [FK_Treatment_Address] FOREIGN KEY([AddressId])
REFERENCES [dbo].[Address] ([AddressId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Treatment_Address]') AND parent_object_id = OBJECT_ID(N'[dbo].[Treatment]'))
ALTER TABLE [dbo].[Treatment] CHECK CONSTRAINT [FK_Treatment_Address]
GO
/****** Object:  ForeignKey [FK_Treatment_IncidentUserSuspect]    Script Date: 05/30/2017 22:53:56 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Treatment_IncidentUserSuspect]') AND parent_object_id = OBJECT_ID(N'[dbo].[Treatment]'))
ALTER TABLE [dbo].[Treatment]  WITH CHECK ADD  CONSTRAINT [FK_Treatment_IncidentUserSuspect] FOREIGN KEY([IncidentUserSuspectId])
REFERENCES [dbo].[IncidentUserSuspect] ([IncidentUserSuspectId])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Treatment_IncidentUserSuspect]') AND parent_object_id = OBJECT_ID(N'[dbo].[Treatment]'))
ALTER TABLE [dbo].[Treatment] CHECK CONSTRAINT [FK_Treatment_IncidentUserSuspect]
GO
