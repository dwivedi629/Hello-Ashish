--DROP TABLE dbo.IncidentPlannedForce
GO
IF COL_LENGTH('Incident','MHS') IS NULL
 BEGIN
 ALTER TABLE [dbo].[Incident] ADD [MHS] [varchar](2) NULL
 END
GO
IF COL_LENGTH('Incident','MHSReason') IS NULL
 BEGIN
 ALTER TABLE [dbo].[Incident] ADD [MHSReason] [varchar](500) NULL
 END
GO
IF COL_LENGTH('Incident','PFData') IS NULL
 BEGIN
 ALTER TABLE [dbo].[Incident] ADD [PFData] [varchar](50) NULL
 END
GO
IF COL_LENGTH('Incident','MedicalLife') IS NULL
 BEGIN
 ALTER TABLE [dbo].[Incident] ADD [MedicalLife] [varchar](2) NULL
 END
GO
IF COL_LENGTH('Incident','MedRcdPrior') IS NULL
 BEGIN
 ALTER TABLE [dbo].[Incident] ADD [MedRcdPrior] [varchar](2) NULL
 END
GO
IF COL_LENGTH('Incident','PlanAltered') IS NULL
 BEGIN
 ALTER TABLE [dbo].[Incident] ADD [PlanAltered] [varchar](2) NULL
 END
GO
GO

/****** Object:  Table [dbo].[LookupArmed]    Script Date: 03/08/2017 11:56:32 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupArmed]') AND type in (N'U'))
DROP TABLE [dbo].[LookupArmed]
GO



/****** Object:  Table [dbo].[LookupArmed]    Script Date: 03/08/2017 11:56:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[LookupArmed](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](7) NOT NULL,
	[Name] [varchar](100) NOT NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO
INSERT [dbo].[LookupArmed] ([Code], [Name]) VALUES (N'BS', N'Blade or Stabbing Instrument')
INSERT [dbo].[LookupArmed] ([Code], [Name]) VALUES (N'CH', N'Chemical')
INSERT [dbo].[LookupArmed] ([Code], [Name]) VALUES (N'EX', N'Explosive')
INSERT [dbo].[LookupArmed] ([Code], [Name]) VALUES (N'FH', N'Firearm (Handgun)')
INSERT [dbo].[LookupArmed] ([Code], [Name]) VALUES (N'FO', N'Firearm (Other)')
INSERT [dbo].[LookupArmed] ([Code], [Name]) VALUES (N'FR', N'Firearm (Replica)')
INSERT [dbo].[LookupArmed] ([Code], [Name]) VALUES (N'FRI', N'Firearm (Rifle)')
INSERT [dbo].[LookupArmed] ([Code], [Name]) VALUES (N'FS', N'Firearm (Shotgun)')
INSERT [dbo].[LookupArmed] ([Code], [Name]) VALUES (N'NA', N'Not Armed')
INSERT [dbo].[LookupArmed] ([Code], [Name]) VALUES (N'ODW', N'Other Dangerous Weapon')
INSERT [dbo].[LookupArmed] ([Code], [Name]) VALUES (N'OWB', N'Other Weapon: Blunt')
INSERT [dbo].[LookupArmed] ([Code], [Name]) VALUES (N'OWE', N'Other Weapon: Edged')
INSERT [dbo].[LookupArmed] ([Code], [Name]) VALUES (N'TE', N'Taser')


