IF COL_LENGTH('Incident','PPINo') IS NULL
 BEGIN
 ALTER TABLE [dbo].[Incident] ADD [PPINo] [varchar](20) NULL
 END
GO
IF COL_LENGTH('Incident','eLots') IS NULL
 BEGIN
 ALTER TABLE [dbo].[Incident] ADD [eLots] [varchar](20) NULL
 END
GO
--INSERT [dbo].[LookupDress] ([Code], [Name]) VALUES (N'SG', N'Suicide Gown or No Clothes')
--INSERT [dbo].[LookupConfirmedArmed] ([Code], [Name]) VALUES (N'OTH', N'Other')

IF COL_LENGTH('IncidentUserSuspect','TypeOfInjury') IS NOT NULL
BEGIN
ALTER TABLE [IncidentUserSuspect] ALTER COLUMN [TypeOfInjury] varchar(100)
 END
GO
IF COL_LENGTH('IncidentUserSuspect','LOCATIONOFFORCE') IS NOT NULL
BEGIN
ALTER TABLE [IncidentUserSuspect] ALTER COLUMN [LOCATIONOFFORCE] varchar(100)
 END
GO
IF COL_LENGTH('IncidentUserSuspect','SuspectConfArmedOther') IS NULL
 BEGIN
 ALTER TABLE [dbo].[IncidentUserSuspect] ADD [SuspectConfArmedOther] [varchar](100) NULL
 END
GO
ALTER TABLE [IncidentStatisticalData] ALTER COLUMN [InjuryType] varchar(50) NULL
GO
ALTER TABLE [IncidentStatisticalData] ALTER COLUMN [BodyPartInvolved] varchar(50) NULL
GO
IF COL_LENGTH('IncidentUserSuspect','TypeofForce') IS NOT NULL
BEGIN
ALTER TABLE [IncidentUserSuspect] ALTER COLUMN [TypeofForce] varchar(100)
 END
GO