
CREATE TABLE [dbo].[LookupBureaus](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Identifier] [varchar](20) NOT NULL,
	[Name] [varchar](200) NOT NULL,
 CONSTRAINT [PK_LookupBureaus] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF

GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Bureau of Labor Relations & Compliance', N'15724')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Psychological Services Bureau', N'15732')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Training Bureau', N'15737')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Facilities Services Bureau', N'15739')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Facilities Planning Bureau', N'15744')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Training Academy', N'15747')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'S.T.A.R. Unit', N'15800')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Office of the Sheriff', N'15715')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Office of the Undersheriff', N'15716')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Office of the Assistant Sheriff I', N'15717')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Executive Planning', N'15719')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Sheriff Headquarters Bureau', N'15861')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Audit & Accountability Command', N'15862')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Administrative Services Division Headquarters', N'15720')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Personnel Administration Bureau', N'15722')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Special Position', N'15725')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Financial Programs', N'15728')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Contract Law Enforcement Bureau', N'15734')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Fiscal Administration', N'15736')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Major Crimes Bureau', N'15735')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Detective Division Administrative Headquarters', N'15748')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Homicide Bureau', N'15750')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Special Victims Bureau', N'15751')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Narcotics Bureau', N'15753')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Fraud & Cyber Crimes Bureau', N'15755')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Vehicle Theft Program', N'15811')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Human Trafficking Bureau', N'15823')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Technical Services Administration', N'15756')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Communications & Fleet Management Bureau', N'15757')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Record & Identification Bureau', N'15758')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Data Systems Bureau', N'15759')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Scientific Services Bureau', N'15760')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Park & City Administrative Headquarters', N'15804')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'County Services Bureau', N'15809')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Parks Bureau', N'15813')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Risk Management', N'15718')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Internal Criminal Investigations Bureau', N'15727')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Internal Affairs Bureau', N'15733')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Advocacy Unit', N'15801')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Professional Standards Division Administrative Hea', N'16101')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Medical Services Bureau', N'16405')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Men''s Central Jail', N'16201')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Inmate Reception Center', N'16203')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'General Population Administrative Headquarters', N'16204')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Custody Investigative Services', N'16208')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Population Management Bureau', N'16406')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Pitchess Detention Center - East', N'16951')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Laundry', N'16953')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Pitchess Detention Center - North', N'16954')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'North County Correctional Facility', N'16962')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Pitchess Detention Center - South', N'16964')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Custody Support Services Bureau', N'16207')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Custody Services Administrative Headquarters', N'16801')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Custody Training & Standards Bureau', N'16837')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Education Based Incarceration / Inmate Services Bu', N'16209')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Custody Compliance & Sustainability Bureau', N'16211')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Specialized Programs Administrative Headquarters', N'16510')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Inmate Services Bureau', N'16650')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Mira Loma Detention Facility', N'16750')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Inmate Services Bureau - Jail Enterprise Unit', N'16955')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Food Services', N'16963')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Century Regional Detention Facility', N'16965')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Twin Towers Correctional Facility', N'16966')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Court Services Transportation Bureau', N'16956')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Court Services Headquarters', N'16957')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Court Services Central', N'16958')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Court Services East', N'16959')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Court Services West', N'16960')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Civil Management Bureau', N'16967')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Metrolink Bureau', N'15808')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Transit Policing Division Headquarters', N'17101')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Central Operations Bureau', N'17102')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Transit Bureau North', N'17103')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Transit Bureau South', N'17104')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'North Patrol Division Headquarters', N'15749')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Lancaster Station', N'15764')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Malibu Lost Hills Station', N'15770')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Santa Clarita Valley Station', N'15771')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'West Hollywood Station', N'15772')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Palmdale Station', N'15812')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Central Patrol Divisions Headquarters', N'15754')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'South Los Angeles Station', N'15769')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Avalon Station', N'15776')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'East Los Angeles Station', N'15777')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Marina Del Rey Station', N'15806')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Century Station', N'15810')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Compton Station', N'15816')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Carson Station', N'15766')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Lomita Station', N'15768')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Lakewood Station', N'15780')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Norwalk Station', N'15781')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Pico Rivera Station', N'15782')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Cerritos Station', N'15824')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'South Patrol Division Headquarters', N'15942')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Crescenta Valley Station', N'15765')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Altadena Station', N'15775')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Industry Station', N'15779')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'San Dimas Station', N'15783')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Temple Station', N'15785')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Walnut Station', N'15787')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'East Patrol Division Headquarters', N'15803')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Special Operations Headquarters', N'15761')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Operation Safe Streets Bureau', N'15763')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Aero Bureau', N'15774')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Emergency Operations Bureau', N'15778')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Special Enforcement Bureau', N'15784')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Reserve Forces Bureau', N'15790')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'CLP', N'15827')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Community College Services', N'15794')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Parking Enforcement Detail', N'15814')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Community Partnerships Bureau', N'15819')
GO
INSERT [dbo].[LookupBureaus] ([Name], [Identifier]) VALUES (N'Countywide Services Division Headquarters', N'15859')
GO
IF COL_LENGTH('userdetail','EmailId') IS NULL
 BEGIN
 ALTER TABLE [dbo].[userdetail] ADD [EmailId] [varchar](200) NULL
 END
GO
IF COL_LENGTH('Incident','InvestigatorDirectedId') IS NULL
 BEGIN
 ALTER TABLE [dbo].[Incident] ADD [InvestigatorDirectedId] [varchar](20) NULL
 END
GO
IF COL_LENGTH('Incident','PRReason') IS NULL
 BEGIN
 ALTER TABLE [dbo].[Incident] ADD [PRReason] [varchar](max) NULL
 END
GO
INSERT INTO UserType (TypeName) VALUES('InvestigatorDirected')
GO
/****** Object:  Table [dbo].[IncidentPlannedForce]    Script Date: 01/07/2017 22:06:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[IncidentPlannedForce](
	[PlannedForceId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NOT NULL,
	[Extraction] [varchar](2) NULL,
	[UoFPlanned] [varchar](2) NULL,
	[MHS] [varchar](2) NULL,
	[MHSReason] [varchar](500) NULL,
	[MedicalFile] [varchar](2) NULL,
	[Investienter] [nvarchar](2) NULL,
	[InvestiExplain] [varchar](500) NULL,
 CONSTRAINT [PK_IncidentPlanned] PRIMARY KEY CLUSTERED 
(
	[PlannedForceId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[IncidentPlannedForce]  WITH CHECK ADD  CONSTRAINT [FK_IncidentPlanned_Incident] FOREIGN KEY([IncidentId])
REFERENCES [dbo].[Incident] ([IncidentId])
GO

ALTER TABLE [dbo].[IncidentPlannedForce] CHECK CONSTRAINT [FK_IncidentPlanned_Incident]
GO
IF COL_LENGTH('IncidentUserSuspect','IspregnantInmate') IS NULL
 BEGIN
 ALTER TABLE [dbo].[IncidentUserSuspect] ADD [IspregnantInmate] [varchar](2) NULL
 END
GO
IF COL_LENGTH('IncidentUserSuspect','SpecialHandling') IS NULL
 BEGIN
 ALTER TABLE [dbo].[IncidentUserSuspect] ADD [SpecialHandling] [varchar](100) NULL
 END
GO
IF COL_LENGTH('IncidentUserSuspect','EmailId') IS NULL
 BEGIN
 ALTER TABLE [dbo].[IncidentUserSuspect] ADD [SecurityLevel] [varchar](100) NULL
 END
GO