sp_rename 'Incident.Bureau', 'IncidentLocationName', 'COLUMN';
GO
ALTER TABLE IncidentFormData
ALTER COLUMN CreatedBy varchar(20);
GO
ALTER TABLE IncidentFormData
ALTER COLUMN UpdateBy varchar(20);
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_FormApprovalorReject_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[FormApprovalorReject]'))
ALTER TABLE [dbo].[FormApprovalorReject] DROP CONSTRAINT [FK_FormApprovalorReject_Incident]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_FormApprovalorReject_UofForm]') AND parent_object_id = OBJECT_ID(N'[dbo].[FormApprovalorReject]'))
ALTER TABLE [dbo].[FormApprovalorReject] DROP CONSTRAINT [FK_FormApprovalorReject_UofForm]
GO


GO

/****** Object:  Table [dbo].[FormApprovalorReject]    Script Date: 02/19/2017 14:41:27 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FormApprovalorReject]') AND type in (N'U'))
DROP TABLE [dbo].[FormApprovalorReject]
GO


GO

/****** Object:  Table [dbo].[FormApprovalorReject]    Script Date: 02/19/2017 14:41:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[FormApprovalorReject](
	[ApprovalId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NOT NULL,
	[FormId] [int] NOT NULL,
	[ApproverRole] [varchar](10) NULL,
	[ActionBy] [varchar](20) NULL,
	[Name] [varchar](50) NULL,
	[FormFilledBy] [varchar](20) NULL,
	[IsApproved] [bit] NULL,
	[ActionDate] [date] NULL,
	[CreatedDate] [datetime] NULL,
 CONSTRAINT [PK_FormApprovalorReject] PRIMARY KEY CLUSTERED 
(
	[ApprovalId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[FormApprovalorReject]  WITH CHECK ADD  CONSTRAINT [FK_FormApprovalorReject_Incident] FOREIGN KEY([IncidentId])
REFERENCES [dbo].[Incident] ([IncidentId])
GO

ALTER TABLE [dbo].[FormApprovalorReject] CHECK CONSTRAINT [FK_FormApprovalorReject_Incident]
GO

ALTER TABLE [dbo].[FormApprovalorReject]  WITH CHECK ADD  CONSTRAINT [FK_FormApprovalorReject_UofForm] FOREIGN KEY([FormId])
REFERENCES [dbo].[UofForm] ([FormId])
GO

ALTER TABLE [dbo].[FormApprovalorReject] CHECK CONSTRAINT [FK_FormApprovalorReject_UofForm]
GO
INSERT [dbo].[UserType] ([TypeName]) VALUES (N'Sergeant')
GO

ALTER TABLE Treatment
DROP CONSTRAINT FK_Treatment_Hospital
GO

/****** Object:  Table [dbo].[Hospital]    Script Date: 2/19/2017 9:47:21 PM ******/
DROP TABLE [dbo].[Hospital]
GO

/****** Object:  Table [dbo].[Hospital]    Script Date: 2/19/2017 9:47:21 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Hospital](
	[HospitalId] [int] IDENTITY(1,1) NOT NULL,
	[RecdTreatmentAt] [varchar](150) NULL,
	[HospitalAdmissionBy] [varchar](150) NULL,
	[HospitalAddress] [varchar](500) NULL,
	[HospitalPhone] [varchar](50) NULL,
	[IncidentUserSuspectId] [int] NULL,
 CONSTRAINT [PK_Hospital] PRIMARY KEY CLUSTERED 
(
	[HospitalId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


