IF COL_LENGTH('Incident','ReferenceNo') IS NULL
 BEGIN
 ALTER TABLE [dbo].[Incident] ADD [ReferenceNo] [varchar](50) NULL
 END
GO
