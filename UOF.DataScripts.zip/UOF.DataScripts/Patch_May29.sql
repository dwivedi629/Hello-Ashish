UPDATE UserRole SET RoleCode='MED', [RANK]=9 WHERE RoleId=3
GO
DELETE UserRole WHERE RoleId=12
GO

/**************Medical User Table Sript****************/

GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentMedicalUser_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentMedicalUser]'))
ALTER TABLE [dbo].[IncidentMedicalUser] DROP CONSTRAINT [FK_IncidentMedicalUser_Incident]
GO


GO

/****** Object:  Table [dbo].[IncidentMedicalUser]    Script Date: 05/28/2017 17:02:07 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IncidentMedicalUser]') AND type in (N'U'))
DROP TABLE [dbo].[IncidentMedicalUser]
GO


GO

/****** Object:  Table [dbo].[IncidentMedicalUser]    Script Date: 05/28/2017 17:02:07 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[IncidentMedicalUser](
	[MedicalId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NOT NULL,
	[EmpId] [varchar](20) NOT NULL,
	[FormId] [int] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [varchar](20) NOT NULL,
	[Active] [bit] NOT NULL,
 CONSTRAINT [PK_IncidentMedicalUser] PRIMARY KEY CLUSTERED 
(
	[MedicalId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[IncidentMedicalUser]  WITH CHECK ADD  CONSTRAINT [FK_IncidentMedicalUser_Incident] FOREIGN KEY([IncidentId])
REFERENCES [dbo].[Incident] ([IncidentId])
GO

ALTER TABLE [dbo].[IncidentMedicalUser] CHECK CONSTRAINT [FK_IncidentMedicalUser_Incident]
GO





