USE [UseofForce]
GO
/****** Object:  Table [dbo].[LookupSpecialHandle]    Script Date: 01/29/2017 11:28:34 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupSpecialHandle]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LookupSpecialHandle](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](5) NOT NULL,
	[Name] [varchar](100) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
SET IDENTITY_INSERT [dbo].[LookupSpecialHandle] ON
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (1, N'A', N'Sergeant Escorts')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (2, N'B', N'Threats')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (3, N'C', N' Protective Custody')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (4, N'D', N' Deaf/Hard of Hearing')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (5, N'E', N'Escape Risk')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (6, N'F', N'Fragile')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (7, N'G', N'Lebsian Gay Bisexual transgender Intersex LGBTI')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (8, N'H', N'Highly dangerous')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (9, N'I', N'Visually Impaired')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (10, N'J', N'AB 109/PC 1170(h)')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (11, N'K', N' Keep-Always')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (12, N'K-1', N'Law Enforcement Yellow Wristband')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (13, N'K-2', N'Keep always another inmate')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (14, N'K-3', N'Keep always another inmate')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (15, N'K-4', N'Keep always another inmate')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (16, N'K-5', N'Keep always another inmate')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (17, N'K-6', N'Administrative Segregation')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (18, N'K-7', N'Administrative Segregation for pre-arraigned inmates')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (19, N'K-8', N'Pregnant')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (20, N'K-10', N'High Jail Security Risk')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (21, N'L', N'Leg Chain')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (22, N'M', N'mental')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (23, N'N', N'No telephone')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (24, N'O', N'cautious')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (25, N'P', N'Psychotropic Meditation')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (26, N'Q', N'Reserved')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (27, N'R', N' HOH/CST Priority')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (28, N'S', N'Suicidal')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (29, N'T', N'Contempt of Court')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (30, N'U', N'Prosthetic,Crutches, or Wlaker')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (31, N'V', N'Noteworthy inmates')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (32, N'W', N'Wheelchair')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (33, N'X', N'Sexually violent Predator-SVP')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (34, N'Y', N'Inmate arrested for 288 P.C. Charge')
INSERT [dbo].[LookupSpecialHandle] ([ID], [Code], [Name]) VALUES (35, N'Z', N'Condemned Prisoner')
SET IDENTITY_INSERT [dbo].[LookupSpecialHandle] OFF
/****** Object:  Table [dbo].[LookupSecurityLevel]    Script Date: 01/29/2017 11:28:34 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupSecurityLevel]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LookupSecurityLevel](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](5) NOT NULL,
	[Name] [varchar](100) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
SET IDENTITY_INSERT [dbo].[LookupSecurityLevel] ON
INSERT [dbo].[LookupSecurityLevel] ([ID], [Code], [Name]) VALUES (1, N'1', N'Minimum')
INSERT [dbo].[LookupSecurityLevel] ([ID], [Code], [Name]) VALUES (2, N'2', N'Minimum')
INSERT [dbo].[LookupSecurityLevel] ([ID], [Code], [Name]) VALUES (3, N'3', N'Minimum')
INSERT [dbo].[LookupSecurityLevel] ([ID], [Code], [Name]) VALUES (4, N'4', N'Minimum')
INSERT [dbo].[LookupSecurityLevel] ([ID], [Code], [Name]) VALUES (5, N'5', N'Medium')
INSERT [dbo].[LookupSecurityLevel] ([ID], [Code], [Name]) VALUES (6, N'6', N'Medium')
INSERT [dbo].[LookupSecurityLevel] ([ID], [Code], [Name]) VALUES (7, N'7', N'Medium')
INSERT [dbo].[LookupSecurityLevel] ([ID], [Code], [Name]) VALUES (8, N'8', N'Maximum')
INSERT [dbo].[LookupSecurityLevel] ([ID], [Code], [Name]) VALUES (9, N'9', N'Maximum')
INSERT [dbo].[LookupSecurityLevel] ([ID], [Code], [Name]) VALUES (10, N'U', N'Unknown')
SET IDENTITY_INSERT [dbo].[LookupSecurityLevel] OFF
GO
INSERT INTO [dbo].[LookupLocationofForce](Code,Name) VALUES('SMY','Small Management Yard')
GO
GO
/****** Object:  Table [dbo].[LookupInmateDress]    Script Date: 01/29/2017 15:24:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LookupInmateDress]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LookupInmateDress](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](5) NOT NULL,
	[Name] [varchar](100) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
SET IDENTITY_INSERT [dbo].[LookupInmateDress] ON
INSERT [dbo].[LookupInmateDress] ([ID], [Code], [Name]) VALUES (1, N'IU', N'Inmate Uniform')
SET IDENTITY_INSERT [dbo].[LookupInmateDress] OFF
