GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UoF_ChangeRole_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[UoF_ChangeRole]'))
ALTER TABLE [dbo].[UoF_ChangeRole] DROP CONSTRAINT [FK_UoF_ChangeRole_Incident]
GO


GO

/****** Object:  Table [dbo].[UoF_ChangeRole]    Script Date: 04/26/2017 08:07:00 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UoF_ChangeRole]') AND type in (N'U'))
DROP TABLE [dbo].[UoF_ChangeRole]
GO


GO

/****** Object:  Table [dbo].[UoF_ChangeRole]    Script Date: 04/26/2017 08:07:00 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[UoF_ChangeRole](
	[RoleId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NOT NULL,
	[URN] [varchar](20) NOT NULL,
	[EmployeeId] [varchar](20) NOT NULL,
	[Name] [varchar](50) NOT NULL,
	[ForceRank] [varchar](50) NOT NULL,
	[UoFRank] [varchar](50) NOT NULL,
	[ValidStill] [date] NOT NULL,
	[Active] [bit] NOT NULL,
	[CreatedOn] [date] NOT NULL,
	[CreatedBy] [varchar](20) NOT NULL,
 CONSTRAINT [PK_UoF_ChangeRole] PRIMARY KEY CLUSTERED 
(
	[RoleId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[UoF_ChangeRole]  WITH CHECK ADD  CONSTRAINT [FK_UoF_ChangeRole_Incident] FOREIGN KEY([IncidentId])
REFERENCES [dbo].[Incident] ([IncidentId])
GO

ALTER TABLE [dbo].[UoF_ChangeRole] CHECK CONSTRAINT [FK_UoF_ChangeRole_Incident]
GO


GO

/****** Object:  Table [dbo].[AT_ChangeOwner]    Script Date: 05/01/2017 11:59:20 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AT_ChangeOwner]') AND type in (N'U'))
DROP TABLE [dbo].[AT_ChangeOwner]
GO


GO

/****** Object:  Table [dbo].[AT_ChangeOwner]    Script Date: 05/01/2017 11:59:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[AT_ChangeOwner](
	[OwnerId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NOT NULL,
	[FormId] [int] NOT NULL,
	[ExistingEmpId] [varchar](20) NOT NULL,
	[ChangedEmpId] [varchar](20) NOT NULL,
	[CreatedBy] [varchar](20) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
 CONSTRAINT [PK_AuditTrail_CO] PRIMARY KEY CLUSTERED 
(
	[OwnerId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentInvestigationOfficer_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentInvestigationOfficer]'))
ALTER TABLE [dbo].[IncidentInvestigationOfficer] DROP CONSTRAINT [FK_IncidentInvestigationOfficer_Incident]
GO


GO

/****** Object:  Table [dbo].[IncidentInvestigationOfficer]    Script Date: 05/02/2017 22:02:36 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IncidentInvestigationOfficer]') AND type in (N'U'))
DROP TABLE [dbo].[IncidentInvestigationOfficer]
GO


GO

/****** Object:  Table [dbo].[IncidentInvestigationOfficer]    Script Date: 05/02/2017 22:02:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[IncidentInvestigationOfficer](
	[InvestId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NOT NULL,
	[EmployeeId] [varchar](20) NOT NULL,
	[FirstName] [varchar](20) NOT NULL,
	[LastName] [varchar](20) NOT NULL,
	[Rank] [varchar](20) NOT NULL,
	[IsLock] [bit] NOT NULL,
	[Status] [nchar](10) NOT NULL,
 CONSTRAINT [PK_IncidentInvestigationOfficer] PRIMARY KEY CLUSTERED 
(
	[InvestId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[IncidentInvestigationOfficer]  WITH CHECK ADD  CONSTRAINT [FK_IncidentInvestigationOfficer_Incident] FOREIGN KEY([IncidentId])
REFERENCES [dbo].[Incident] ([IncidentId])
GO

ALTER TABLE [dbo].[IncidentInvestigationOfficer] CHECK CONSTRAINT [FK_IncidentInvestigationOfficer_Incident]
GO
GO

GO

GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentRank_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentRank]'))
ALTER TABLE [dbo].[IncidentRank] DROP CONSTRAINT [FK_IncidentRank_Incident]
GO


GO

/****** Object:  Table [dbo].[IncidentRank]    Script Date: 05/07/2017 20:08:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IncidentRank]') AND type in (N'U'))
DROP TABLE [dbo].[IncidentRank]
GO


GO

/****** Object:  Table [dbo].[IncidentRank]    Script Date: 05/07/2017 20:08:06 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[IncidentRank](
	[IncidentRankId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NOT NULL,
	[Rank] [int] NOT NULL,
	[AssignedUserId] [varchar](20) NULL,
 CONSTRAINT [PK_IncidentRank] PRIMARY KEY CLUSTERED 
(
	[IncidentRankId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[IncidentRank]  WITH CHECK ADD  CONSTRAINT [FK_IncidentRank_Incident] FOREIGN KEY([IncidentId])
REFERENCES [dbo].[Incident] ([IncidentId])
GO

ALTER TABLE [dbo].[IncidentRank] CHECK CONSTRAINT [FK_IncidentRank_Incident]
GO
SET ANSI_PADDING OFF
GO
IF COL_LENGTH('UserRole','Rank') IS NULL
 BEGIN
 ALTER TABLE [dbo].[UserRole] ADD [Rank] int 
 END
GO
IF COL_LENGTH('FormApprovalorReject','EmployeeNo') IS NULL
 BEGIN
 ALTER TABLE [dbo].[FormApprovalorReject] ADD EmployeeNo varchar(20) null 
 END
GO

IF COL_LENGTH('FormApprovalorReject','Assignment') IS NULL
 BEGIN
 ALTER TABLE [dbo].[FormApprovalorReject] ADD Assignment varchar(50) null  
 END
GO

IF COL_LENGTH('FormApprovalorReject','SRD') IS NULL
 BEGIN
 ALTER TABLE [dbo].[FormApprovalorReject] ADD SRD varchar(50) null  
 END
GO
ALTER TABLE [dbo].[FormApprovalorReject] ALTER COLUMN ActionDate datetime;

IF COL_LENGTH('FormApprovalorReject','Active') IS NULL
 BEGIN
 ALTER TABLE [dbo].[FormApprovalorReject] ADD Active bit null  
 END
GO

exec sp_rename 'IncidentWorkflow.AddlSergeants','ChiefStatus','COLUMN' 
GO
IF COL_LENGTH('IncidentWorkflow','DeputyStatus') IS NULL
 BEGIN
 ALTER TABLE [dbo].[IncidentWorkflow] ADD DeputyStatus  varchar(25) null  
 END
GO
UPDATE [dbo].[UserRole] SET [RANK]=2 WHERE [RoleId]=1
GO
UPDATE [dbo].[UserRole] SET [RANK]=1 WHERE [RoleId]=2
GO
UPDATE [dbo].[UserRole] SET [RANK]=3 WHERE [RoleId]=4
GO
UPDATE [dbo].[UserRole] SET [RANK]=4 WHERE [RoleId]=5
GO
UPDATE [dbo].[UserRole] SET [RANK]=5 WHERE [RoleId]=6
GO
UPDATE [dbo].[UserRole] SET [RANK]=6 WHERE [RoleId]=8
GO
UPDATE [dbo].[UserRole] SET [RANK]=7 WHERE [RoleId]=10
GO
UPDATE [dbo].[UserRole] SET [RANK]=8 WHERE [RoleId]=11
GO

/****** Object:  Table [dbo].[FormReviewRank]    Script Date: 05/09/2017 15:53:57 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FormReviewRank](
	[ReviewRankId] [int] IDENTITY(1,1) NOT NULL,
	[FormId] [int] NOT NULL,
	[ReviewRank] [int] NOT NULL,
	[Active] [bit] NOT NULL,
 CONSTRAINT [PK_FormReviewRank] PRIMARY KEY CLUSTERED 
(
	[ReviewRankId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[FormReviewRank] ON
INSERT [dbo].[FormReviewRank] ([ReviewRankId], [FormId], [ReviewRank], [Active]) VALUES (1, 10, 3, 1)
INSERT [dbo].[FormReviewRank] ([ReviewRankId], [FormId], [ReviewRank], [Active]) VALUES (2, 11, 3, 1)
INSERT [dbo].[FormReviewRank] ([ReviewRankId], [FormId], [ReviewRank], [Active]) VALUES (3, 12, 3, 1)
INSERT [dbo].[FormReviewRank] ([ReviewRankId], [FormId], [ReviewRank], [Active]) VALUES (4, 14, 3, 1)
INSERT [dbo].[FormReviewRank] ([ReviewRankId], [FormId], [ReviewRank], [Active]) VALUES (6, 16, 2, 1)
INSERT [dbo].[FormReviewRank] ([ReviewRankId], [FormId], [ReviewRank], [Active]) VALUES (7, 17, 2, 1)
INSERT [dbo].[FormReviewRank] ([ReviewRankId], [FormId], [ReviewRank], [Active]) VALUES (8, 18, 2, 1)
INSERT [dbo].[FormReviewRank] ([ReviewRankId], [FormId], [ReviewRank], [Active]) VALUES (9, 19, 2, 1)
INSERT [dbo].[FormReviewRank] ([ReviewRankId], [FormId], [ReviewRank], [Active]) VALUES (10, 20, 2, 1)
INSERT [dbo].[FormReviewRank] ([ReviewRankId], [FormId], [ReviewRank], [Active]) VALUES (11, 21, 2, 1)
INSERT [dbo].[FormReviewRank] ([ReviewRankId], [FormId], [ReviewRank], [Active]) VALUES (12, 22, 2, 1)
INSERT [dbo].[FormReviewRank] ([ReviewRankId], [FormId], [ReviewRank], [Active]) VALUES (13, 23, 4, 1)
INSERT [dbo].[FormReviewRank] ([ReviewRankId], [FormId], [ReviewRank], [Active]) VALUES (14, 24, 2, 1)
INSERT [dbo].[FormReviewRank] ([ReviewRankId], [FormId], [ReviewRank], [Active]) VALUES (15, 26, 5, 1)
INSERT [dbo].[FormReviewRank] ([ReviewRankId], [FormId], [ReviewRank], [Active]) VALUES (16, 30, 6, 1)
SET IDENTITY_INSERT [dbo].[FormReviewRank] OFF
/****** Object:  Default [DF_FormReviewRank_Status]    Script Date: 05/09/2017 15:53:57 ******/
ALTER TABLE [dbo].[FormReviewRank] ADD  CONSTRAINT [DF_FormReviewRank_Status]  DEFAULT ((0)) FOR [Active]
GO
/****** Object:  ForeignKey [FK_FormReviewRank_FormReviewRank]    Script Date: 05/09/2017 15:53:57 ******/
ALTER TABLE [dbo].[FormReviewRank]  WITH CHECK ADD  CONSTRAINT [FK_FormReviewRank_FormReviewRank] FOREIGN KEY([FormId])
REFERENCES [dbo].[UofForm] ([FormId])
GO
ALTER TABLE [dbo].[FormReviewRank] CHECK CONSTRAINT [FK_FormReviewRank_FormReviewRank]
GO

IF COL_LENGTH('IncidentFormReview','DCID') IS NULL
BEGIN
ALTER TABLE [dbo].[IncidentFormReview] ADD [DCID] varchar(25) NULL
END
GO
IF COL_LENGTH('IncidentFormReview','DCStatus') IS NULL
BEGIN
ALTER TABLE [dbo].[IncidentFormReview] ADD [DCStatus] varchar(20) NULL
END
GO
IF COL_LENGTH('IncidentWorkflow','DCID') IS NULL
BEGIN
ALTER TABLE [dbo].[IncidentWorkflow] ADD [DCID] varchar(25) NULL
END
GO
ALTER TABLE IncidentWorkflow DROP COLUMN ChiefStatus;
GO
IF COL_LENGTH('IncidentWorkflow','DCStatus') IS NULL
BEGIN
ALTER TABLE [dbo].[IncidentWorkflow] ADD [DCStatus] varchar(20) NULL
END
GO
INSERT INTO USERTYPE VALUES('Chief')



/**************Medical User Table Sript****************/

GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_IncidentMedicalUser_Incident]') AND parent_object_id = OBJECT_ID(N'[dbo].[IncidentMedicalUser]'))
ALTER TABLE [dbo].[IncidentMedicalUser] DROP CONSTRAINT [FK_IncidentMedicalUser_Incident]
GO


GO

/****** Object:  Table [dbo].[IncidentMedicalUser]    Script Date: 05/28/2017 17:02:07 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IncidentMedicalUser]') AND type in (N'U'))
DROP TABLE [dbo].[IncidentMedicalUser]
GO


GO

/****** Object:  Table [dbo].[IncidentMedicalUser]    Script Date: 05/28/2017 17:02:07 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[IncidentMedicalUser](
	[MedicalId] [int] IDENTITY(1,1) NOT NULL,
	[IncidentId] [int] NOT NULL,
	[EmpId] [varchar](20) NOT NULL,
	[FormId] [int] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [varchar](20) NOT NULL,
	[Active] [bit] NOT NULL,
 CONSTRAINT [PK_IncidentMedicalUser] PRIMARY KEY CLUSTERED 
(
	[MedicalId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[IncidentMedicalUser]  WITH CHECK ADD  CONSTRAINT [FK_IncidentMedicalUser_Incident] FOREIGN KEY([IncidentId])
REFERENCES [dbo].[Incident] ([IncidentId])
GO

ALTER TABLE [dbo].[IncidentMedicalUser] CHECK CONSTRAINT [FK_IncidentMedicalUser_Incident]
GO





