﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
   public class ArtifactEntity
    {
       public Int32 ArtifactId { get; set; }

       public Int32 IncidentId { get; set; }

       public String FileName { get; set; }

       public DateTime UploadedDate { get; set; }
    }
}
