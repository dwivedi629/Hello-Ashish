﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class SupplementalModel : IEntityBusinessModel
    {
        public int IncidentReviewId { get; set; }
        public bool IsOnlySave { get; set; }
        public int FormDataId { get; set; }
        public int IncidentID { get; set; }
        public string EmpId { get; set; }
        public int FormID { get; set; }
        public int UserRoleId { get; set; }
        public string UserRole { get; set; }
        public bool isApproval { get; set; }
        public string SubmitedId { get; set; }
        public string Date { get; set; }
        public string File { get; set; }
        public string Action { get; set; }
        public string Code { get; set; }
        public string Narrative { get; set; }
        public string EmployeeId { get; set; }
        public string By { get; set; }
        public string Approved { get; set; }
        public string Assigned { get; set; }
        public string Secretary { get; set; }
        public string ActionType { get; set; }
        public string RejectComments { get; set; }
        public List<Narratives> Narratives { get; set; }
        public List<SupNarratives> SupNarratives { get; set; }
        public bool LockMode { get; set; }
    }

    public class SupNarratives
    {
        public string CodeId { get; set; }
        public string CodeNarrative { get; set; }
    }
    public class Narratives
    {
        public string NarrativeDate { get; set; }
        public string NarrativeFile { get; set; }
        public string NarrativeAction { get; set; }
        public string Reason { get; set; }
    }
}
