﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class SupervisorsReportBusinessModel : IEntityBusinessModel
    {
        public Category1 Category1 { get; set; }
        public int IncidentID { get; set; }
        public bool IsOnlySave { get; set; }
        public string EmpId { get; set; }
        public int FormID { get; set; }
        public int UserRoleId { get; set; }
        public string UserRole { get; set; }
        public int IncidentReviewId { get; set; }
        public int formDataId { get; set; }
    }

    public class Category1
    {
        public string BriefSceneDescription { get; set; }
        public bool chkChemicalAgent { get; set; }
        public bool chkControlTechniques { get; set; }
        public bool chkHobble { get; set; }
        public bool chkTakedowns { get; set; }
        public string DescribeThreat { get; set; }
        public string Debriefing { get; set; }
        public string MechanicalRestraintsYN { get; set; }
        //public bool YMechanicalRestraints { get; set; }
        //public bool NMechanicalRestraints { get; set; }
        public bool HandcuffsMechanicalRestraints { get; set; }
        public bool WaistChainMechanicalRestraints { get; set; }
        public bool HobbleRestraintMechanicalRestraints { get; set; }
        public bool SafetyChairMechanicalRestraints { get; set; }
        public bool WheelchairMechanicalRestraints { get; set; }
        public bool FixedObjectMechanicalRestraints { get; set; }
        public bool chkIncidentReview1 { get; set; }
        public bool chkIncidentReview2 { get; set; }
        public bool chkIncidentReview3 { get; set; }
        public bool chkIncidentReview4 { get; set; }
        public bool chkIncidentReview5 { get; set; }
        public bool chkIncidentReview6 { get; set; }
        public bool chkIncidentReview7 { get; set; }
        public bool chkIncidentReview8 { get; set; }
        public bool chkIncidentReview9 { get; set; }
        public bool chkIncidentReview10 { get; set; }
        public bool chkIncidentReview11 { get; set; }
        public bool chkIncidentReview12 { get; set; }
        public string chkIncidentReview13 { get; set; }
        public bool ThreatMedicalOrder { get; set; }
        public bool ThreatCourtOrder { get; set; }
        public bool ThreatPassiveResistance { get; set; }
        public bool ThreatActiveResistanceverbal { get; set; }
        public bool ThreatActiveResistancephysical { get; set; }
        public bool ThreatAssaultiveOthers { get; set; }
        public bool ThreatAssaultiveLawenforcement { get; set; }
        public bool ThreatOther { get; set; }
        public string ThreatOtherTextbox { get; set; }
        public bool Standing { get; set; }
        public bool Walking { get; set; }
        public bool Running { get; set; }
        public bool Sitting { get; set; }
        public bool Kneeling { get; set; }
        public bool Lying { get; set; }
        public bool BOther { get; set; }
        public string BOtherReason { get; set; }

        public bool AggressiveStance { get; set; }
        public bool Pushing { get; set; }
        public bool Pulling { get; set; }
        public bool Grabbing { get; set; }
        public bool Spitting { get; set; }
        public bool Punching { get; set; }
        public bool Kicking { get; set; }
        public bool Fighting { get; set; }
        public bool Lunging { get; set; }
        public bool POther { get; set; }
        public string POtherReason { get; set; }

        public bool VerbalCommands { get; set; }
        public bool SupervisorRequested { get; set; }
        public bool SupervisorPresent { get; set; }
        public bool BackupRequested { get; set; }
        public bool FOther { get; set; }
        public string FOtherReason { get; set; }
        public string RejectComments { get; set; }
    }


}
