﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class UoFNarrativeEntityModel : IEntityBusinessModel
    {
        public int IncidentReviewId { get; set; }
        public int formDataId { get; set; }
        public int IncidentID { get; set; }
        public string EmpId { get; set; }
        public int FormID { get; set; }
        public bool IsOnlySave { get; set; }
        public int UserRoleId { get; set; }
        public string UserRole { get; set; }
        public IncidentInformation incidentInformation { get; set; }
        public Forcemitigation forceMitigation { get; set; }
        public Reported reported { get; set; }
        public Notification notification { get; set; }
        public Witness witness { get; set; }
        public WC wc { get; set; }
        public Medical medical { get; set; }
        public Training training { get; set; }
        public CaseStatus caseStatus { get; set; }
        public string RejectComments { get; set; }

    }
    public class IncidentInformation
    {
        public string SceneDescription { get; set; }
        public bool MedicalOrder { get; set; }
        public bool CourtOrder { get; set; }
        public bool PassiveResistance { get; set; }
        public bool ActiveverbalResistance { get; set; }
        public bool ActivephysicalResistance { get; set; }
        public bool LawEnforcement { get; set; }
        public bool SeriousBodilyInjury { get; set; }
        public bool AssaultiveOthers { get; set; }
        public bool DeathTowardOthers { get; set; }
        public bool OtherThreats { get; set; }

        public bool ChemicalAgent { get; set; }
        public bool Pepperball { get; set; }
        public bool PersonalWeapon { get; set; }
        public bool TaserApplication { get; set; }
        public bool ControlTechniques { get; set; }
        public bool Takedown { get; set; }
        public bool ImpactWeapon { get; set; }
        public bool Stunbag { get; set; }
        public bool CarotidRestraint { get; set; }
        public bool Personnelk9 { get; set; }
        public bool Firearm { get; set; }
        public bool PersonnelOther { get; set; }

        public bool ForceUsedNo { get; set; }
        public bool Handcuffs { get; set; }
        public bool HobbleRestraint { get; set; }
        public bool SafetyChair { get; set; }
        public bool FixedObject { get; set; }
        public bool WaistChain { get; set; }
        public bool TARP { get; set; }
        public bool Wheelchair { get; set; }
        public bool Mechanicalk9 { get; set; }

        public string DescribeType { get; set; }
        public string ThreatDescription { get; set; }
        public bool MechanicalOthers { get; set; }
        public string OtherThreatsReason { get; set; }
        public string PersonnelOtherReason { get; set; }
        public string MechanicalOthersReason { get; set; }

        public bool suspectArmed { get; set; }
        public string suspectArmedReason { get; set; }
        public bool Struck { get; set; }
        public string StruckReason { get; set; }
        public bool Kicked { get; set; }
    }

    public class Forcemitigation
    {
        public bool VerbalCommands { get; set; }
        public bool SupervisorRequested { get; set; }
        public bool SupervisorPresent { get; set; }
        public bool BackUp { get; set; }
        public bool MitigationOthers { get; set; }
        public string MitigationOthersReason { get; set; }

        public bool LastResort { get; set; }
        public bool InvolvedMinforce { get; set; }
        public bool Forceterminated { get; set; }
        public bool Noevidenceofprovocation { get; set; }
        public bool Noevidenceofforce { get; set; }
        public bool Noevidenceofexcessiveforce { get; set; }
        public string ExcessiveforceReason { get; set; }
        public bool StaffMembers { get; set; }
        public bool Noevidenceofunreasonable { get; set; }
        public bool chemicalsORelectronicdevices { get; set; }
        public bool DepartmentMembers { get; set; }
        public bool Extentpossible { get; set; }
        public bool Inmatewascontrolled { get; set; }
        public bool Inmatewascarried { get; set; }

        public bool UseofSafetyChair { get; set; }
        public bool UseofMultiPoint { get; set; }
    }

    public class Reported
    {

        public string ForceReportingYN { get; set; }
        public string ForceReportingNoReason { get; set; }
        public string WrittenReportYN { get; set; }
        public string WrittenReportNoReason { get; set; }
        public string InconsistenciesDocYN { get; set; }
        public string InconsistenciesDocYesReason { get; set; }
        public string AdmonishmentYN { get; set; }
        public string AdmonishmentNoReason { get; set; }

        public string DeptMemberYN { get; set; }
        public string DeptMemberReason { get; set; }
        public string DMUsingForceYN { get; set; }
        public string DMUsingForceReason { get; set; }

        //public bool ForceReportingYN { get; set; }
        //public bool ForceReportingNo { get; set; }
        //public bool WrittenReportYes { get; set; }
        //public bool WrittenReportNo { get; set; }
        //public bool InconsistenciesDocYes { get; set; }
        //public bool InconsistenciesDocNo { get; set; }
        //public bool AdmonishmentYes { get; set; }
        //public bool AdmonishmentNo { get; set; }
        //public bool AdmonishmentNA { get; set; }

        //public string WrittenReportNoReason { get; set; }
        //public string InconsistenciesDocYesReason { get; set; }
        //public string AdmonishmentNoReason { get; set; }
        //public string ForceReportingNoReason { get; set; }
    }
    public class Notification
    {
        //public bool NotificationsToIABYes { get; set; }
        //public bool NotificationsToIABNo { get; set; }
        //public bool NotificationsToIABNA { get; set; }
        //public string NotificationsToIABNoReason { get; set; }

        //public bool NotificationsToCFRTYes { get; set; }
        //public bool NotificationsToCFRTNo { get; set; }
        //public bool NotificationsToCFRTNA { get; set; }
        //public string NotificationsToCFRTNoReason { get; set; }

        public string NotificationsToIABYN { get; set; }
        public string NotificationsToIABNoReason { get; set; }

        public string NotificationsToCFRTYN { get; set; }
        public string NotificationsToCFRTNoReason { get; set; }
    }

    public class Witness
    {
        public string WitnessInterview { get; set; }
        public string InmateWitYN { get; set; }
        public string InmateWitReason { get; set; }
    }

    public class WC
    {
        public string PersonnelInvolvedYN { get; set; }
        public string PersonnelInvolvedYesReason { get; set; }
        public string SuspectStatement { get; set; }
        public string PerInvolvedYN { get; set; }
        public string PerInvolvedReason { get; set; }
    }

    public class Medical
    {
        public string SuspectInjuredYes { get; set; }
        public string SuspectInjuredNo { get; set; }


        public string SuspectInjuredYN { get; set; }
        public string SuspectAllegedYN { get; set; }
        public string SuspectReceiveYN { get; set; }
        public string MedicalTreatmentYN { get; set; }
        public string SuspectTransportedYN { get; set; }
        public string InjuriesDocumentedYN { get; set; }
        public string InjuriesAppearsConsistentYN { get; set; }
        public string SuspectKnowsInjuriesYN { get; set; }
        public string InvolvedEmpInjConsistentYN { get; set; }
        public string InjuriesWereNotBelivedYN { get; set; }
        //public bool InjuriesDocumentedNo { get; set; }
        //public bool InjuriesDocumentedNA { get; set; }
        //public bool InjuriesAppearsConsistentYes { get; set; }
        //public bool InjuriesAppearsConsistentNo { get; set; }
        //public bool InjuriesAppearsConsistentNA { get; set; }
        //public bool SuspectKnowsInjuriesYes { get; set; }
        //public bool SuspectKnowsInjuriesNo { get; set; }
        //public bool SuspectKnowsInjuriesUnknown { get; set; }
        //public bool InvolvedEmpInjConsistentYes { get; set; }
        //public bool InvolvedEmpInjConsistentNo { get; set; }
        //public bool InvolvedEmpInjConsistentNA { get; set; }
        //public bool InjuriesWereNotBelivedYes { get; set; }
        //public bool InjuriesWereNotBelivedNo { get; set; }
        //public bool InjuriesWereNotBelivedNA { get; set; }

        public string SuspectAllegedYesReason { get; set; }
        public string SuspectInjuredYesReason { get; set; }
        public string SuspectReceiveNoReason { get; set; }
        public string MedicalTreatmentNoReason { get; set; }
        public string SuspectTransportedNoReason { get; set; }
        public string InjuriesDocumentedNoReason { get; set; }
        public string InjuriesAppearsConsistentNoReason { get; set; }
        public string SuspectKnowsInjuriesYesReason { get; set; }
        public string InvolvedEmpInjConsistentNoReason { get; set; }
        public string InjuriesWereNotBelivedYesReason { get; set; }

        public string InjuriesAddtionalYN { get; set; }
        public string InjuriesAddtionalReason { get; set; }

    }
    public class Training
    {
        public string OtherForceOptions { get; set; }
        public string Reassessment { get; set; }
        public string TrainingRecommendations { get; set; }
        public string WeaponsUsedNoReason { get; set; }
        public string WeaponsAppDeptNoReason { get; set; }
        public string WeaponsAppDeptNAReason { get; set; }
        public string WeaponsUsedNAReason { get; set; }
        public string PersonTrainedNoReason { get; set; }
        public string PersonTrainedNAReason { get; set; }
        public string IncidentDebriefingNoReason { get; set; }
        public string ListAnyEquipment { get; set; }
        public string OtherTopics { get; set; }

        public string WeaponsUsedYN { get; set; }
        public string WeaponsAppDeptYN { get; set; }
        public string PersonTrainedYN { get; set; }
        public string IncidentDebriefingYN { get; set; }
        //public bool WeaponsAppDeptNo { get; set; }
        //public bool WeaponsAppDeptNA { get; set; }
        //public bool PersonTrainedYes { get; set; }
        //public bool PersonTrainedNo { get; set; }
        //public bool PersonTrainedNA { get; set; }
        //public bool IncidentDebriefingYes { get; set; }
        //public bool IncidentDebriefingNo { get; set; }

       


    }

    public class CaseStatus
    {
        public string CaseNumber { get; set; }
        public string DateFiled { get; set; }
        public string Charges { get; set; }
        public bool SubmittedToAttorneyYes { get; set; }
        public bool SubmittedToAttorneyNo { get; set; }
        public string SubmittedToAttorneyNoReason { get; set; }
        public string CaseDisposition { get; set; }
        public string RejectComments { get; set; }
    }
}
