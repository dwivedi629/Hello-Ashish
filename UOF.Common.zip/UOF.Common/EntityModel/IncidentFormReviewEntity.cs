﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class IncidentFormReviewEntity
    {
        public Int32 IncidentReviewID { get; set; }

        public Int32 IncidentID { get; set; }

        public Int32 FormId { get; set; }

        public String SubmittedEmpId { get; set; }

        public String SubmitteduserRole { get; set; }

        public String SergeantId { get; set; }

        public String ReviewerRole { get; set; }

        public String SergeantStatus { get; set; }

        public String WCID { get; set; }

        public String WCStatus { get; set; }
        
        public String UCID { get; set; }

        public String UCStatus { get; set; }

        public String CMID { get; set; }

        public String CMStatus { get; set; }

        public String CFRTID { get; set; }

        public String CFRTStatus { get; set; }

        public String CFRCID { get; set; }

        public String CFRCStatus { get; set; }

        public String SubmittedStatus { get; set; }

        public bool isAssignForms { get; set; }

        public bool isApproveOrReject { get; set; }

        public bool isTempSave { get; set; }

        public int FormDataId { get; set; }
        public String DCID { get; set; }
        public String DCStatus { get; set; }

        public int loggedInRank { get; set; }
    }
}
