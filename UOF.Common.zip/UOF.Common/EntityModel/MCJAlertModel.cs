﻿namespace UOF.Common.EntityModel
{
    public class MCJAlertModel
    {
        public int UserRoleId { get; set; }
        public int FormId { get; set; }
        public int IncidentId { get; set; }
        public string Attention { get; set; }
        public string URN { get; set; }
        public string Reference { get; set; }
        public string eLOTS { get; set; }
        public string Date { get; set; }
        public string Time { get; set; }
        public string Location { get; set; }
        public string Subject { get; set; }
        public string BookingNo { get; set; }
        public string SuspectName { get; set; }
        public string SuspectMailId { get; set; }
        public string SuspectSPHDL { get; set; }
        public string By { get; set; }
        public string ByName { get; set; }
        public string ByMailId { get; set; }
        public string DeputyID { get; set; }
        public string DeputyName { get; set; }
        public string DeputyMailId { get; set; }
        public string Synopsis { get; set; }
        public string SupervisorID { get; set; }
        public string SupervisorName { get; set; }
        public string SupervisorMailId { get; set; }
        public string Weapons { get; set; }
        public string Summary { get; set; }
        public bool CodeYN { get; set; }
        public bool PrunoYN { get; set; }
        public bool PillYN { get; set; }
        public string LoggedId { get; set; }
        public string LoggedRole { get; set; }
        public string RejectComments { get; set; }
    }
}
