﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class SignatureModel
    {
        public Int32 SignatureId { get; set; }

        public String EmployeeNumber { get; set; }

        public Byte[] Signature { get; set; }

        public String Status { get; set; }
    }
}
