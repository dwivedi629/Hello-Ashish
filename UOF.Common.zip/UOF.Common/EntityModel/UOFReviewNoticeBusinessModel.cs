﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class UOFReviewNoticeBusinessModel : IEntityBusinessModel
    {
        public int IncidentID { get; set; }
        public bool IsOnlySave { get; set; }
        public int FormID { get; set; }
        public int UserRoleId { get; set; }
        public string UserRole { get; set; }
        public string EmpId { get; set; }
        public string ReportingEmployee { get; set; }
        public int ReportingForm { get; set; }
        public string URN { get; set; }
        public string IncidentDate { get; set; }
        public string ReviewerSubmitionDate { get; set; }
        public bool MemoClarification { get; set; }
        public bool MemoAddInfo { get; set; }
        public bool MemoGramaticalErrors { get; set; }
        public bool Corrections { get; set; }
        public bool MemoOther { get; set; }
        public string MemoComments { get; set; }
        public string ReviewerId { get; set; }
        public string ReviewerName { get; set; }
        public string ReviewerSignature { get; set; }
        public string ReviewerTitle { get; set; }
        public string ReviewerDate { get; set; }
        public string RejectComments { get; set; }
        public bool isLockMode { get; set; }
    }


}
