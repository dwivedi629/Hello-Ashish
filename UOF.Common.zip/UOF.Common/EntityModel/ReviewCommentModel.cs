﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class ReviewCommentModel
    {
        public Int32 ReviewCommentId { get; set; }

        public Int32 IncidentId { get; set; }

        public Int32 FormId { get; set; }

        public String ReviewComments { get; set; }

        public String CommentedBy { get; set; }

        public String SubmitedId { get; set; }

        public DateTime CreatedOn { get; set; }

        public String Status { get; set; }

    }
}
