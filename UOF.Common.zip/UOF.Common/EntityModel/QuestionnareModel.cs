﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UOF.Common.EntityModel
{
    #region Dont Delete the code as this cod eis for questionnare part demo " Ashish"
    public class QuestionnareModel
    {
        public string ID { get; set; }
        public string Type { get; set; }
        public string Answer { get; set; }
        

    }

    public class QuestionSet
    {
        public List<QuestionnareModel> lstQuestionModel { get; set; }
    }

#endregion
}