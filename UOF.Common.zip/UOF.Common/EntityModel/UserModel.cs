﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class UserModel
    {
        public string DateOfBirth { get; set; }
        public string DepartmentHireDate { get; set; }
        public string DepartmentTenure { get; set; }
        public string DisplayName { get; set; }
        public string EmailAddress { get; set; }
        public string EmployeeNumber { get; set; }
        public string Error { get; set; }
        public string FirstName { get; set; }
        public string ItemNumber { get; set; }
        public string LastName { get; set; }
        public string LastPromotion { get; set; }
        public string MiddleName { get; set; }
        public string OnItemDate { get; set; }
        public string Race { get; set; }
        public string Rank { get; set; }
        public string RankAbrev { get; set; }
        public string RankTenure { get; set; }
        public string Sex { get; set; }
        public bool Success { get; set; }
        public string UnitOfAssignment { get; set; }
        public string UnitOfAssignmentShort { get; set; }
        public string UserName { get; set; }
        public string UoFUserRole { get; set; }
        public List<string> groups { get; set; }
    }
}
