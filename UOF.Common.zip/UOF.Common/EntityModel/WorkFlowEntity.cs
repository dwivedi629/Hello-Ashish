﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class WorkFlowEntity
    {

        public Int32 IncidentId { get; set; }

        public String SergeantID { get; set; }

        public String DeputyStatus { get; set; }

        public String DCID { get; set; }

        public String ChiefStatus { get; set; }

        public String SergeantStatus { get; set; }

        public String WCID { get; set; }

        public String WCStatus { get; set; }

        public String UCID { get; set; }

        public String UCStatus { get; set; }

        public String CFRCID { get; set; }

        public String CFRCStatus { get; set; }

        public String CFRTID { get; set; }

        public String CFRTStatus { get; set; }

        public String CMID { get; set; }

        public String CMStatus { get; set; }



    }
}
