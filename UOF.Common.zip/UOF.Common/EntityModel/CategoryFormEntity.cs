﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class CategoryFormEntity
    {

        public int CategoryFormID { get; set; }
        public int IncidentID { get; set; }
        public int IncidentCategoryId { get; set; }
        public int FormID { get; set; }
        public string Status { get; set; }
    }
}
