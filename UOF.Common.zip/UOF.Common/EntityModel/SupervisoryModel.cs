﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class SupervisoryModel : IEntityBusinessModel
    {
        public IncidentEntity Incident { get; set; }
        public List<InvolvedUserEntity> Involved { get; set; }
        public List<SuspectUserEntity> Suspects { get; set; }
        public List<WitnessUserEntity> EmpWitness { get; set; }
        public List<WitnessUserEntity> NonEmpWitness { get; set; }
        public List<WitnessUserEntity> Dupties { get; set; }
        public List<StatisticalEntity> Statisticals { get; set; }
        public CanineEntity Canine { get; set; }
    }
}
