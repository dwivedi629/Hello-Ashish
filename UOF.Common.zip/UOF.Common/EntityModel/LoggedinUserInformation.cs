﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public static class LoggedinUserInformation
    {
        public static int RoleID { get; set; }
        public static string RoleCode { get; set; }
        public static int IncidentID { get; set; }
        public static int EmpID { get; set; }
        public static string RoleName { get; set; }
        public static List<string> Forms { get; set; }

    }
}
