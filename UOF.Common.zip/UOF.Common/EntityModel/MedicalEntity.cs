﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class MedicalEntity : IEntityBusinessModel
    {
        public int IncidentReviewId { get; set; }
        public int formDataId { get; set; }
        public int IncidentID { get; set; }
        public string EmpId { get; set; }
        public int FormID { get; set; }
        public string UserRole { get; set; } // holds the logged in user role
        public int UserRoleId { get; set; }
        public bool isApproval { get; set; }
        public bool isMedical { get; set; }
        public bool IsOnlySave { get; set; }
        public string SubmitedId { get; set; }
        public UniformInformation uniformInformation { get; set; }
        public IncidentInfo incidentInformation { get; set; }
        public InmateInformation inmateInformation { get; set; }
        public EscortInformation escortInformation { get; set; }
        public SupervisorInformation supervisorInformation { get; set; }
        public MedicalInformation medicalInformation { get; set; }
        public DiagnosisInformation diagnosisInformation { get; set; }
    }
    public class UniformInformation
    {
        public string URN { get; set; }
        public string ReferenceNumber { get; set; }
    }
    public class InmateInformation
    {
        public string InmateName { get; set; }
        public string BookingNumber { get; set; }
        public string InmateAge { get; set; }
        public string Sex { get; set; }
        public string InmateRace { get; set; }
        public string InmateDOB { get; set; }
        public string HousingFacility { get; set; }
        public string InmateBarrack { get; set; }
        public string InmateCell { get; set; }
        public bool InmateSegregation { get; set; }
        public bool InmateGeneralPopulation { get; set; }
        public bool InmateMentalHealthHousing { get; set; }
        public bool InmateMedicalHousing { get; set; }
        public bool InmateDiscipline { get; set; }
        public string InmateSegregationReason { get; set; }
        public string ImageURL { get; set; }
    }
    public class IncidentInfo
    {
        public string IncidentLocation { get; set; }
        public string IncidentTypeOfLocation { get; set; }
        public string IncidentDate { get; set; }
        public string IncidentTime { get; set; }
        public string IntiatedNo { get; set; }
        public string IntiatedName { get; set; }
        public string IntiatedDate { get; set; }

    }
    public class EscortInformation
    {
        public bool InmateEscorted { get; set; }
        public bool InmateTransported { get; set; }
        public string EscortFacility { get; set; }
        public string EscortNumber { get; set; }

        public string EscortNameAndNumber { get; set; }
        public string EscortTime { get; set; }
        public string EstTime { get; set; }
        public string EstFacility { get; set; }
        public string EstNumber { get; set; }
        public string EstNameAndNumber { get; set; }

        public string TransportedHospital { get; set; }
        public string TransportedMedia { get; set; }
        public string EscortedNumber { get; set; }
        public string EscortedNameAndNumber { get; set; }
        public string EscortedDate { get; set; }
        public string EscortedTime { get; set; }

        public string EstedNumber { get; set; }
        public string EstedNameAndNumber { get; set; }
        public string EstedDate { get; set; }
        public string EstedTime { get; set; }
        public string InmateTreatedby { get; set; }
        public string InmateTreatedDate { get; set; }
        public string InmateTreatedTime { get; set; }
        public string InmateReturnedFacility { get; set; }
        public string InmateAdmitted { get; set; }
        public string InmateOther { get; set; }
        public string InmateOtherReason { get; set; }
        public string InmateReturnedDate { get; set; }
        public string InmateReturnedTime { get; set; }
    }
    public class SupervisorInformation
    {
        public string SupervisorName { get; set; }
        public string SupervisorEmployeeNumber { get; set; }
        public string SupervisorAssesmentDate { get; set; }
        public string SupervisorAssesmentTime { get; set; }
        public bool InmateInvolved { get; set; }
        public bool InmateAlleged { get; set; }
        public bool InmatePriorToDuring { get; set; }
        public bool ChemicalAgent { get; set; }
        public bool ControlHolds { get; set; }
        public bool Takedown { get; set; }
        public bool PersonalWeapons { get; set; }
        public bool TaserApplication { get; set; }
        public bool ImpactWeapon { get; set; }
        public bool Stunbag { get; set; }
        public bool PepperballGun { get; set; }
        public bool CarotidRestraint { get; set; }
        public bool k9 { get; set; }
        public bool Firearm { get; set; }
        public string OtherForce { get; set; }
        public string AllegedUOFHandledby { get; set; }
        public string AllegedUOFHandledbyName { get; set; }
        public string UnderFileNumber { get; set; }
        public string SupervisoryURN { get; set; }
        public string SupReferenceNumber { get; set; }
        public string BriefDescription { get; set; }

    }
    public class MedicalInformation
    {
        public string EvaluatedBy { get; set; }
        public string EvaluatedEmployeeNumber { get; set; }
        public string DateEvaluated { get; set; }
        public string TimeEvaluated { get; set; }
        public string MedicalAssessment { get; set; }
        public bool VisibleYes { get; set; }
        public bool VisibleNo { get; set; }
        public string SprayExposureYN { get; set; }
        //public bool SprayExposureNo { get; set; }
        public string DecontaminatedYN { get; set; }
        //public bool DecontaminatedNo { get; set; }
        public string FollowUpTreatmentYN { get; set; }
        //public bool RefusedMedicalTreatmentNo { get; set; }
        public string RefusalVideotapedYN { get; set; }
        //public bool RefusalVideotapedNo { get; set; }
        public string RefusedMedicalTreatmentYN { get; set; }
        //public bool FollowUpTreatmentNo { get; set; }
        public bool Abrasion { get; set; }
        public bool Active { get; set; }
        public bool Bruise { get; set; }
        public bool Deformity { get; set; }
        public bool Dried { get; set; }
        public bool Cut { get; set; }
        public bool OC { get; set; }
        public bool Complaint { get; set; }
        public bool Protrusion { get; set; }
        public bool Puncture { get; set; }
        public bool Reddened { get; set; }
        public bool Skin { get; set; }
        public bool Swollen { get; set; }
        public bool Other1 { get; set; }
        public bool Other2 { get; set; }
        public bool Other3 { get; set; }
    }
    public class DiagnosisInformation
    {
        public bool sec { get; set; }
        public string OutsideTreatedBy { get; set; }
        public string OutsideTreatedByName { get; set; }
        public string OutsideEmployeeNumber { get; set; }
        public string OutsideDateTreated { get; set; }
        public string OutsideTimeTreated { get; set; }
        public bool OutsideAppearsYes { get; set; }
        public bool OutsideAppearsNo { get; set; }
        public string OutsideDescription { get; set; }
        public bool OutsideInfluenceYes { get; set; }
        public bool OutsideInfluenceNo { get; set; }
        public bool OutsideInfluenceUnable { get; set; }

        public bool OutsideTreatementYes { get; set; }
        public bool OutsideTreatementNo { get; set; }

        public bool OutsideAdmited { get; set; }
        public bool OutsideCustodyfacility { get; set; }
        public bool OutsideMediaRadiocar { get; set; }
        public bool OutsideMediaAmbulance { get; set; }

        public bool OutsideSuicideYes { get; set; }
        public bool OutsideSuicideNo { get; set; }
        public bool DischargeForm { get; set; }
        public bool FollowupTreatment { get; set; }
        public bool FollowupTreatmentYes { get; set; }
        public bool FollowupTreatmentNo { get; set; }
        public string WatchCommander { get; set; }
        public string EmployeeNumber { get; set; }
        public string RejectComments { get; set; }
    }
}
