﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class IncidentStatusDetail
    {
        public int ReviewId { get; set; }
        public Int32? FromDataId { get; set; }
        public string URN { get; set; }
        public int IncidentId { get; set; }
        public int FormId { get; set; }
        public string FormName { get; set; }
        public string EmployeeID { get; set; }
        public string Role { get; set; }
        public int RoleId { get; set; }
        public string Status { get; set; }
        public string FormStatus { get; set; }
        public string Assign { get; set; }
        public String ReviewerRole { get; set; }
        public String ReviewerUserId { get; set; }
        public String SergeantId { get; set; }
        public String SergeantStatus { get; set; }
        public String WCID { get; set; }
        public String WCStatus { get; set; }
        public String UCID { get; set; }
        public String UCStatus { get; set; }
        public String CMID { get; set; }
        public String CMStatus { get; set; }
        public String CFRTID { get; set; }
        public String CFRTStatus { get; set; }
        public String CFRCID { get; set; }
        public String CFRCStatus { get; set; }
        public String SubmittedStatus { get; set; }
        public String DeputyStatus { get; set; }
        public String FirstName { get; set; }
        public String LastName { get; set; }
        public bool isOwner { get; set; }
        public string isInvestigationOfficer { get; set; }
        public String DCID { get; set; }
        public String DCStatus { get; set; }
    }
}
