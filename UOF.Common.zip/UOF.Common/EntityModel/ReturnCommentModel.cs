﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class ReturnCommentModel
    {
        public Int32 ReturnId { get; set; }

        public Int32 IncidentReviewID { get; set; }

        public String EmployeeNumber { get; set; }

        public String Comments { get; set; }

        public DateTime? CreatedOn { get; set; }

        public int IncidentId { get; set; }
        public int FormId { get; set; }
        public string FormSubmitedId { get; set; }

    }
}
