﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class WitnessUserEntity : UserDetailEntity
    {
       
        public int IncidentUserWitnessId { get; set; }
        public int IncidentUserId { get; set; }
        public int IncidentId { get; set; }
        public int UserId { get; set; }
        public bool Active { get; set; }
        public string EmployeeId { get; set; }
        public string WitnessIntAwayfromInmates { get; set; }
        public string IsWitness { get; set; }
        public string IsPresent { get; set; }
        public string ShiftType { get; set; }
    }
}
