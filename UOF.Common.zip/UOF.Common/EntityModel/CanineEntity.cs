﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class CanineEntity
    {
        public Int32 IncidentCanineDeploymentId { get; set; }
        public string Mode { get; set; }
        public Int32? IncidentId { get; set; }
        public bool Area { get; set; }
        public bool Building { get; set; }
        public bool TOSOther { get; set; }
        public bool ApprehendingSuspect { get; set; }
        public bool ConductingSearch { get; set; }
        public bool ProtectingHandler { get; set; }
        public string BOWOtherReason { get; set; }
        public bool Bite { get; set; }
        public bool TOIOther { get; set; }

        public bool BYAeroUnit { get; set; }
        public bool ByRadioCar { get; set; }
        public bool English { get; set; }
        public bool Spanish { get; set; }
        public bool Recorded { get; set; }

        public bool AnnouncementsBy { get; set; }
        public bool AnnouncementsIn { get; set; }
        public string AnnouncementsNoneReason { get; set; }
        public bool AnnouncementMadeby { get; set; }
        public string AnnouncementMadebyReason { get; set; }
        public string CriminalHistory { get; set; }
        public string Notifications { get; set; }
        public string LoggedId { get; set; }
        public List<HandlerEntity> Handlers { get; set; }
    }
}
