﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class HandlerEntity
    {
        public Int32 HandlerId { get; set; }

        public Int32 IncidentCanineDeploymentId { get; set; }

        public string HandlerNumber { get; set; }

        public string HandlerName { get; set; }

        public string HandlerType { get; set; }

        public string CanineNumber { get; set; }

        public string UnitNumber { get; set; }
    }
}
