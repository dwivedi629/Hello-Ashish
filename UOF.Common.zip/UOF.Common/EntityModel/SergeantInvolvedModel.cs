﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class SergeantInvolvedModel
    {
        public Int32 SergeantInvolvedId { get; set; }

        public Int32 IncidentId { get; set; }

        public String InvolvedEmplId { get; set; }

        public String SergeantId { get; set; }

        public String Createdby { get; set; }

        public DateTime CreatedOn { get; set; }


    }
}
