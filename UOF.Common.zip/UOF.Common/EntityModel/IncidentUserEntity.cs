﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class IncidentUserEntity : UserDetailEntity
    {
        public int IncidentUserId { get; set; }
        public int IncidentId { get; set; }
        public int UserId { get; set; }
        public string ForceEmployeeId { get; set; }
        public string PreviousId { get; set; }
        public bool Active { get; set; }
        public string SergeantId { get; set; }

        public DateTime? CreatedOn { get; set; }
    }
}
