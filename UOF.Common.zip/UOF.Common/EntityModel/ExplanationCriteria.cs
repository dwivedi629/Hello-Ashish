﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class ExplanationCriteria
    {
        public string userId { get; set; }
        public string userRole { get; set; }
        public int incidentId { get; set; }
        public int formId { get; set; }
    }
    public class ParameterCriteria
    {
        public int IncidentReviewId { get; set; }
        public string employeeId { get; set; }
        public int incidentId { get; set; }
        public int formId { get; set; }
        public int formDataId { get; set; }
        public bool report { get; set; }
        public string reviewerId { get; set; }
    }
}
