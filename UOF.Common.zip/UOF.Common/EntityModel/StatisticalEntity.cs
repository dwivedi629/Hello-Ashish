﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class StatisticalEntity
    {
        public int IncidentUserForceId { get; set; }
        public int IncidentId { get; set; }
        public string ForcedUsedById { get; set; }
        public string ForcedUsedByName { get; set; }
        public string ForcedUsedAgainstId { get; set; }
        public string ForcedUsedAgainstName { get; set; }
        public string MethodCode { get; set; }
        public string InjuryTypeCode { get; set; }
        public string BodyPartInvolvedCode { get; set; }
        public string LoggedId { get; set; }
    }
}
