﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class UserDetailEntity : AddressEntity
    {
        public string Mode { get; set; }
        
        public string ForceUserId { get; set; }
        public int UserTypeId { get; set; }
        public int UserDetailId { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string Rank { get; set; } //Changed
        public string Sex { get; set; }
        public string Race { get; set; }
        public string Dress { get; set; } //added
        public string Height { get; set; }
        public string Weight { get; set; }
        public Int32? Age { get; set; }
        public string Shift { get; set; } // changed
        public string ShiftType { get; set; } // changed
        public string UnitOfAssignment { get; set; }
        public string WorkAssignment { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string PrimaryPhone { get;set;}
        public string SecondaryPhone { get; set; }
        public string Name
        {
            get
            {
                return FirstName + " " + MiddleName + " " + LastName;
            }
        }
        public string ReviewerId { get; set; }
        public string LoggedId { get; set; }
        public string EmailId { get; set; }
        public string UserRole { get; set; }

        public string BookingNum { get; set; } //Inmate Witness
        public string InmateType { get; set; }//Inmate Witness
        public string TransorRefuse { get; set; }//Inmate Witness
        public bool IsOnlySave { get; set; }
        public bool isFormAssign { get; set; }
    }
}
