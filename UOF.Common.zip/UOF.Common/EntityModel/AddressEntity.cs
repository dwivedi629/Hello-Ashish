﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class AddressEntity : BaseEntity
    {
        public int AddressId { get; set; }
        public string AddressNumber { get; set; }
        public string Street{ get; set; }
        public string City { get; set; }
        public string ZipCode { get; set; }
        public string StationFacility { get; set; }
        public string State { get; set; }
        public int AddressTypeId { get; set; }

        public string PrimaryPhone { get; set; }

        public string SecondaryPhone { get; set; }
        public int IncidentId { get; set; }
    }

    public class TempModel
    {
        //public string MyProperty { get; set; }
        //public string MyProperty { get; set; }
        //public string MyProperty { get; set; }
        //public string MyProperty { get; set; }
        //public string MyProperty { get; set; }
        //public string MyProperty { get; set; }
        //public string MyProperty { get; set; }
        //public string MyProperty { get; set; }
        //public string MyProperty { get; set; }
        //public string MyProperty { get; set; }
        //public string MyProperty { get; set; }

    }
}
