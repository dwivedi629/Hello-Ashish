﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class ReviewEntity
    {
        public Int32 DeputyFormId { get; set; }

        public Int32 IncidentId { get; set; }

        public Int32 FormId { get; set; }

        public String DeputyEmpId { get; set; }
        
        public String SergeantEmpId { get; set; }

        public String SergeantStatus { get; set; }

        public String FormStatus { get; set; }

        public string isApprove { get; set; }

        public String ReviewerReviewId { get; set; }

        public String ReviewerRole { get; set; }

        public String ReviewerStatus { get; set; }

        public string LoggedId { get; set; }

        public string Comment { get; set; }

        public int IncidentReviewId { get; set; }

        public string EmployeeNo { get; set; }

        public string Assignment { get; set; }

        public string SRD { get; set; }

        public string ActionDate { get; set; }

        public bool isSRForm { get; set; }
    }
}
