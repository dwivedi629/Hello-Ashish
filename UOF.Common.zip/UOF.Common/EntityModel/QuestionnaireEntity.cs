﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class QuestionnaireEntity : BaseEntity
    {
        public int UserTypeQuestionnaireId { get; set; }
        public Nullable<int> UserTypeId { get; set; }
        public Nullable<int> QuestionnaireId { get; set; }
        public Nullable<int> QuestionnaireGroupId { get; set; }
        public Nullable<bool> Active { get; set; }

        public int UserTypeQuestionnaireSubId { get; set; }
        public Nullable<int> SubQuestionnaireId { get; set; }

        //public int QuestionnaireId { get; set; }
        public string Question { get; set; }

        //public int SubQuestionnaireId { get; set; }
        public string SubQuestion { get; set; }

        public string GroupName { get; set; }
    }
}
