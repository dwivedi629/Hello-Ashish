﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class LookupData
    {
        #region Stats Data Info
       
        public List<LookupEntity> MethodsInfo { get; set; }

        #endregion

        #region Incident Detail info
        public List<LookupEntity> CustodyEventsInfo { get; set; }
        public List<LookupEntity> CitiesInfo { get; set; }
        public List<LookupEntity> ContactTypesInfo { get; set; }
        public List<LookupEntity> InjuriesInfo { get; set; }
        public List<LookupEntity> StationInfo { get; set; }
        public List<LookupEntity> StagingInfo { get; set; }
       
        #endregion

        #region Common Detail
        public List<LookupEntity> BodyPartInfo { get; set; }
        public List<LookupEntity> LocationofForceInfo { get; set; }
        public List<LookupEntity> ResistanceInfo { get; set; }
        public List<LookupEntity> PerceivedArmedInfo { get; set; }

        #endregion

        #region Suspect info
        public List<LookupEntity> DressInfo { get; set; }
        public List<LookupEntity> SergeantInfo { get; set; }
        public List<LookupEntity> GenderInfo { get; set; }
        public List<LookupEntity> SubstanceInfo { get; set; }
        public List<LookupEntity> RacesInfo { get; set; }
        public List<LookupEntity> ArmedInfo { get; set; }
        public List<LookupEntity> ConfirmedArmedInfo { get; set; }
        public List<LookupEntity> CivilianInjurySeverityInfo { get; set; }
        public List<LookupEntity> SuspectLocationofForceInfo { get; set; }
        public List<LookupEntity> SecurityInfo { get; set; }
        public List<LookupEntity> SpecialHandleInfo { get; set; }

        #endregion

        public List<LookupEntity> FaciltiesInfo { get; set; }
        public List<LookupEntity> InjurySeveritiesInfo { get; set; }

        public List<LookupEntity> FormNames { get; set; }
        public List<LookupEntity> InvolvedUsers { get; set; }

        public List<LookupEntity> BureausInfo { get; set; }

        public List<LookupEntity> GroupInfoforIR { get; set; }

    }
}
