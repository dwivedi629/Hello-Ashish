﻿
using System.Collections.Generic;

namespace UOF.Common.EntityModel
{
    public class IncidentAlertModel
    {
        public int UserRoleId { get; set; }
        public int FormId { get; set; }
        public int IncidentId { get; set; }
        public string Attention { get; set; }
        public string URN { get; set; }
        public string Reference { get; set; }
        public string eLOTS { get; set; }
        public string Date { get; set; }
        public string Time { get; set; }
        public string Location { get; set; }
        public string TypeOfIncident { get; set; }
        public string TypeofForce { get; set; }
        public string DirectedYN { get; set; }
        public string DirectedId { get; set; }
        public string DirectedName { get; set; }
        public string DirectedMailId { get; set; }
        public string WCID { get; set; }
        public string WCName { get; set; }
        public string WCMailId { get; set; }
        public string SerID { get; set; }
        public string SerName { get; set; }
        public string SerMailId { get; set; }
        public string Synopsis { get; set; }
        public string MentalHistoryYN { get; set; }
        public string MentalHealthYN { get; set; }
        public string IncidentCategory { get; set; }
        public bool HandheldYN { get; set; }
        //public string HandheldId { get; set; }
        //public string HandheldName { get; set; }
        //public string HandheldMailId { get; set; }
        public bool CCTVYN { get; set; }
        //public string CCTVId { get; set; }
        public string CCTVLocation { get; set; }
       // public string CCTVMailId { get; set; }
        public bool CFRTYN { get; set; }
        public string CFRTID { get; set; }
        public string CFRTName { get; set; }
        public string CFRTMailId { get; set; }
        public bool CFRTRolloutYN { get; set; }
        public string CFRTRolloutID { get; set; }
        public string CFRTRolloutName { get; set; }
        public string CFRTRollMailId { get; set; }
        public bool IABYN { get; set; }
        public string IABID { get; set; }
        public string IABName { get; set; }
        public string IABMailId { get; set; }
        public bool HomicideYN { get; set; }
        public string HomicideID { get; set; }
        public string HomicideName { get; set; }
        public string HomicidelMailId { get; set; }
        public List<InvolvedSuspect> InvolvedSuspect { get; set; }
        public List<InvolvedEmployee> InvolvedEmployee { get; set; }
        public string LoggedId { get; set; }
        public string LoggedRole { get; set; }
        public string RejectComments { get; set; }
        public bool CodeYN { get; set; }
        public bool PrunoYN { get; set; }
        public bool PillYN { get; set; }
    }
    public class InvolvedSuspect {
        public string BookNum { get; set; }
        public string Name { get; set; }
        public string MailId { get; set; }
        public string Injuries { get; set; }
        
    }
    public class InvolvedEmployee {
        public string EmpNum { get; set; }
        public string Name { get; set; }
        public string Injuries { get; set; }
    }
}
