﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class TrackingModel
    {
        public int IncidentReviewId { get; set; }
        public int formDataId { get; set; }
        public int IncidentID { get; set; }
        public string EmpId { get; set; }
        public int FormID { get; set; }
        public int UserRoleId { get; set; }
        public string UserRole { get; set; }
        public bool Cat1 { get; set; }
        public bool Cat2 { get; set; }
        public bool Cat3 { get; set; }
        public bool ForceTypeIdOC { get; set; }
        public bool ForceTypeIdPK { get; set; }
        public bool ForceTypeIdTR { get; set; }
        public bool ForceTypeIdCT { get; set; }
        public bool ForceTypeIdTT { get; set; }
        public bool ForceTypeIdST { get; set; }
        public bool ForceTypeIdCR { get; set; }
        public bool ForceTypeIdFH { get; set; }
        public bool Directed { get; set; }
        public bool Medical { get; set; }
        public bool MedicalOther { get; set; }
        public bool Rescue { get; set; }
        public bool CFRTRolloutEmployees { get; set; }
        public bool IABRolloutEmployees { get; set; }
        public bool CCTVcoverage { get; set; }
        public bool AllegationForce { get; set; }
        public bool OtherVideos { get; set; }
        public bool Others { get; set; }
        public string Station { get; set; }
        public string eLOTS { get; set; }
        public string FileNumber { get; set; }
        public string ReferenceNumber { get; set; }
        public string IncidentDate { get; set; }
        public string HandlingSupervisor { get; set; }
        public string ReviewingSupervisor { get; set; }
        public string SubmittedtoOperations { get; set; }
        public string SubmittedtoCFRT { get; set; }
        public string SubmittedtoCommander { get; set; }
        public string SubmittedtoDiscovery { get; set; }

        public bool isSupervisorySubmitted { get; set; }
        public bool isSHR438Submitted { get; set; }
        public bool isSHR49Submitted { get; set; }
        public bool isTimecopySubmitted { get; set; }
        public bool isUOFMemoSubmitted { get; set; }
        public bool isInmateRptSubmitted { get; set; }
        public bool isCDSubmitted { get; set; }
        public bool isPhotographsSubmitted { get; set; }
        public bool isTeaserDownloadedSubmitted { get; set; }
        public bool isOtherDocsSubmitted { get; set; }
        public bool isSuppRptSubmitted { get; set; }

        public bool isWCReviewSubmitted { get; set; }
        public bool isUCReviewSubmitted { get; set; }
        public bool isCMReviewSubmitted { get; set; }

        public string isWCReviewDate { get; set; }
        public string isUCReviewDate { get; set; }
        public string isCMReviewDate { get; set; }
        public string comments { get; set; }


    }
}
