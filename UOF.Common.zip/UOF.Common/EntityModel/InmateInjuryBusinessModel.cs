﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UOF.Common.EntityModel
{
    public class InmateInjuryBusinessModel : IEntityBusinessModel
    {
        public int IncidentReviewId { get; set; }
        public int formDataId { get; set; }
        public int IncidentID { get; set; }
        public int FormID { get; set; }
        public string EmpId { get; set; }
        public int UserRoleId { get; set; }
        public string UserRole { get; set; }
        public bool isApproval { get; set; }
        public bool isMedical { get; set; }
        public bool IsOnlySave { get; set; }
        public string SubmitedId { get; set; }
        public MSH msh { get; set; }
        public MSIL msil { get; set; }
        public incidentInformation incidentInformation { get; set; }
        public incidentNarrative incidentNarrative { get; set; }
        public inmateInformation inmateInformation { get; set; }
        public inmateStatement inmateStatement { get; set; }
        public wittnessStatement wittnessStatement { get; set; }

    }
    public class MSH
    {
        public bool applicable { get; set; }
        public string MSHTreatedBy { get; set; }
        public string MSHEmployeeNumber { get; set; }
        public string MSHDateTreated { get; set; }
        public string MSHTimeTreated { get; set; }
        public bool MSSickOrIllY { get; set; }
        public bool MSSickOrIllN { get; set; }
        public bool MSchkDiagonsisY { get; set; }
        public bool MSchkDiagonsisN { get; set; }
        public bool MSinjuredY { get; set; }
        public bool MSinjuredN { get; set; }
        public bool MSdescriptionY { get; set; }
        public bool MSdescriptionN { get; set; }
        public bool MSfinalDiagnosticY { get; set; }
        public bool MSfinalDiagnosticN { get; set; }
        public bool MSAdmittedY { get; set; }
        public bool MSAdmittedN { get; set; }
        public bool MSradioCare { get; set; }
        public bool MSambulance { get; set; }
        public bool MSsafetyCell { get; set; }
        public bool MSlowBunk { get; set; }
        public bool MSobservationY { get; set; }
        public bool MSobservationN { get; set; }
        public bool MSPrecautionsY { get; set; }
        public bool MSPrecautionsN { get; set; }
        public bool MShospitalDischarge { get; set; }
        public bool MStreatmentRecommended { get; set; }
        public bool MStreatmentRecommendedY { get; set; }
        public bool MStreatmentRecommendedN { get; set; }
        public string TransferredTo { get; set; }
        public string Communicable { get; set; }
        public bool hospitalDischarge { get; set; }
        public bool Communicabledisease { get; set; }
        public string BookDoctor { get; set; }

        public string MSHEmployeeNumber2 { get; set; }
        public string MSHTreatedBy2 { get; set; }
        public string MSHDateTreated2 { get; set; }
        public string MSHTimeTreated2 { get; set; }
        public string DiagDescriptionInjuryExplanation { get; set; }
    }
    public class MSIL
    {
        public string TreatedBy { get; set; }
        public string EmployeeNumber { get; set; }
        public string DateTreated { get; set; }
        public string TimeTreated { get; set; }
        public string MSIncidentNarrative { get; set; }
        public bool Injury { get; set; }
        public bool Illness { get; set; }
        public bool ConsistentYes { get; set; }
        public bool ConsistentNo { get; set; }
        public bool FollowupYes { get; set; }
        public bool FollowupNo { get; set; }
        public bool RC { get; set; }
        public bool Ambulance { get; set; }
        public bool Paramedics { get; set; }
    }
    public class incidentInformation
    {
        public string IncidentLocation { get; set; }
        public string TypeOfLocation { get; set; }
        public string IncidentDate { get; set; }
        public string IncidentTime { get; set; }
        public bool SickOrIllY { get; set; }
        public bool SickOrIllN { get; set; }
        public bool InjuredY { get; set; }
        public bool InjuredN { get; set; }
        public bool ForeOrAllegationY { get; set; }
        public bool ForeOrAllegationN { get; set; }
        public string PersonContacted { get; set; }
        public string FinalDiagnosisBy { get; set; }
        public string FinalDiagnosisDateTime { get; set; }
        public string FinalDiagnosis { get; set; }
        public bool Accident { get; set; }
        public bool furtherInvestigation { get; set; }
        public string InvestigationURN { get; set; }
        public bool Alone { get; set; }
        public bool Segregated { get; set; }
        public bool WithOthers { get; set; }
        public bool wasEscorted { get; set; }
        public string EscortedToClinic { get; set; }
        public string EscortedToAt { get; set; }
        public bool wasTransported { get; set; }
        public string TransportedToClinic { get; set; }
        public string TransportedToAt { get; set; }
        public bool wasEscortedBy { get; set; }
        public string EscortedByClinic { get; set; }
        public string EscortedByAt { get; set; }
        public string SeenByClinic { get; set; }
        public string AdmittedToEmerRoom { get; set; }
        public string SeenByAt { get; set; }
        public string SeenByAtHours { get; set; }
        public string EscortedBy { get; set; }
        public bool InmateTreatedBy { get; set; }
        public string OtherInmateDisposition { get; set; }
        public string EscortingPersonnelEID { get; set; }
        public string EscortingPersonnelName { get; set; }
        public string DeputyEscortingtoHospitalDate { get; set; }
        public string DoctorTreatedDate { get; set; }
        public string DoctorTreatedTime { get; set; }
        public bool chkReturnedtoFacility { get; set; }
        public bool chkOther { get; set; }
        public bool chkAdmittedtoHospital { get; set; }
        public string InmateDispoDate { get; set; }
        public string InmateDispoTime { get; set; }
        

    }
    public class incidentNarrative
    {
        public string IncidentNarrative_EmployeeNumber { get; set; }
        public string IncidentNarrative_NameOfSergeant { get; set; }
        public string IncidentNarrative_Date { get; set; }
        public string IncidentNarrative { get; set; }
        public string SubmittedBy_EmployeeNumber { get; set; }
        public string SubmittedBy_NameOfSergeant { get; set; }
        public string SubmittedBy_Date { get; set; }
        public string ApprovedBy_EmployeeNumber { get; set; }
        public string ApprovedBy_NameOfSergeant { get; set; }
        public string ApprovedBy_Date { get; set; }
        public bool chkInmateInterviewed { get; set; }
        public bool chkNoAllegationForce { get; set; }
        public string SergeantNotesNarrative { get; set; }
    }
    public class inmateInformation
    {
        public string PersonNotified { get; set; }
        public string URN { get; set; }
        public string ReferenceNumber { get; set; }
        public string BookingNumber { get; set; }
        public string EmployeeName { get; set; }
        public string Race { get; set; }
        public string Sex { get; set; }
        public string DateOfBirth { get; set; }
        public string HousingFacility { get; set; }
        public string Barrack { get; set; }
        public string Cell { get; set; }
        public string TypeOfHousing { get; set; }
        public string Segregation { get; set; }
        public bool chkGeneralPopulation { get; set; }
        public bool chkMentalHealthHousing { get; set; }
        public bool chkMedicalHousing { get; set; }
        public bool chkDiscipline { get; set; }
        public bool chkSegregation { get; set; }

    }
    public class inmateStatement
    {
        public string InmateStatement { get; set; }
        public string Refused { get; set; }
        public string Incapacitated { get; set; }
        public string InmateSignature { get; set; }
        //Incapacitated { get; set; }
    }
    public class wittnessStatement
    {
        public string WTBookingNumber { get; set; }
        public string WTName { get; set; }
        public string WTHousingLocation { get; set; }
        public string WitnessStatement { get; set; }
        public string WCEmpNumber { get; set; }
        public string WCName { get; set; }
        public string WCLog { get; set; }
        public string Quality { get; set; }
        public string NotifiedBy { get; set; }
        public bool Telephone { get; set; }
        public bool Email { get; set; }
        public string RejectComments { get; set; }
        public string QANurseEmployeeNumber { get; set; }
    }
}