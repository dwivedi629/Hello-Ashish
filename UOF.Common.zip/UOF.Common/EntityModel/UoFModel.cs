﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class UoFModel
    {
        public IncidentEntity IncidentDetails { get; set; }
        public UserModel UserDetails { get; set; }
        public List<UserAccess> UserAccess { get; set; }
        public string WC { get; set; }
        public string InvestSupervisor { get; set; }
        public string OnDutySupervisor { get; set; }
        public bool isDeletePermission { get; set; }

    }
}
