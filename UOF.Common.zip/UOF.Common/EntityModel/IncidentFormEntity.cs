﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class IncidentFormEntity
    {
        public Int32 FormDataID { get; set; }

        public Int32? IncidentID { get; set; }

        public String EmpID { get; set; }

        public Int32 FormID { get; set; }

        public Int32 UserRoleId { get; set; }

        public String XmlData { get; set; }

        public DateTime? CreatedOn { get; set; }

        public Int32? CreatedBy { get; set; }

        public DateTime? UpdateOn { get; set; }

        public Int32? UpdateBy { get; set; }

        public String Status { get; set; }

    }
}
