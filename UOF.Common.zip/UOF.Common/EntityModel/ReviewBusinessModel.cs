﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class ReviewBusinessModel 
    {

        public string ID { get; set; }
        public string Type { get; set; }
        public string Answer { get; set; }
        public string Observer { get; set; }
    }

    public class ReviewsResponse : IEntityBusinessModel
    {
        public List<ReviewBusinessModel> ReviewBusinessModel { get; set; }
        public int IncidentID { get; set; }
        public int FormID { get; set; }
        public int UserRoleId { get; set; }
        public string UserRole { get; set; }
        public string EmpId { get; set; }
        public int IncidentReviewId { get; set; }
        public int formDataId { get; set; }
        public bool IsOnlySave { get; set; }
    }
}
