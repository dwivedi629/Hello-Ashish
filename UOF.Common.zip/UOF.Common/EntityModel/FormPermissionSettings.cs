﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
   public class FormPermissionSettings
    {
        public Int32 FormPermissionId { get; set; }
        public Int32 RoleId { get; set; }
        public Int32 FormId { get; set; }
        public Boolean IsViewOnly { get; set; }
        public bool IsFormChecked { get; set; }
        public string FormCode { get; set; }
    }
}
