﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class UserAccess
    {
        public Int32 FormId { get; set; }
        public String FormName { get; set; }
        public String FormCode { get; set; }
        public Int32? IncidentId { get; set; }
        public bool isFormEntered { get; set; }
        
    }
}
