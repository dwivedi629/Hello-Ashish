﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{

    public class AssignForm
    {
        public string Mode { get; set; }
        public int IncidentId { get; set; }
        public string URN { get; set; }
        public System.DateTime Date { get; set; }
        public string LoggedId { get; set; }
        public string LoggedRole { get; set; }
        public List<Assignment> Assignment { get; set; }
        public List<Assignment> DeletedUsers { get; set; }
        

    }

    public class Assignment
    {
        public int ID { get; set; }
        public string EmployeeId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Rank { get; set; }
        public string MailId { get; set; }
        public string FormIds { get; set; }
        public int instanceCnt { get; set; }
        public bool InvolvedEmployee { get; set; }
        public bool EmployeeWitness { get; set; }
        public int IncidentId { get; set; }
        public string EmpRole { get; set; }
        public bool isIRExist { get; set; }
        public bool isIRwithCACSExist { get; set; }
        public string customIRRule { get; set; }
        public string customRule { get; set; }
    }
}
