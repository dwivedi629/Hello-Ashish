﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
  public  class FormsNameSettings
    {
        public Int32 FormId { get; set; }
        public String FormName { get; set; }
        public String FormCode { get; set; }
        public String Description { get; set; }
        public String Text { get; set; }
        public bool isFormChecked { get; set; }
        public bool isViewOnly { get; set; }
        public int ParentId { get; set; }
        public String ActionName { get; set; }
        public String ControllerName { get; set; }
        public Boolean? IsMenuItem { get; set; }
        public Boolean? IsSettingItem { get; set; }
    }
}
