﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class IABModel : IEntityBusinessModel
    {
        public int IncidentReviewId { get; set; }
        public int formDataId { get; set; }
        public string UserRole { get; set; }
        public int IncidentID { get; set; }
        public string EmpID { get; set; }
        public int FormID { get; set; }
        public int UserRoleId { get; set; }
        public bool IsOnlySave { get; set; }
        public bool Allshootings { get; set; }
        public bool Allincidents { get; set; }
        public bool Hospitalizations { get; set; }
        public bool Skeletal { get; set; }
        public bool Category2or3 { get; set; }
        public bool Alllargeparty { get; set; }
        public bool Injury { get; set; }
        public bool Departmentmember { get; set; }
        public bool Kick { get; set; }
        public bool Caninebites { get; set; }
        public bool Kneestrike { get; set; }
        public bool SRT { get; set; }
        public bool Anydeath { get; set; }
        public bool Inmatedeaths { get; set; }
        public bool Departmentpersonnel { get; set; }
        public bool RelievedofDuty { get; set; }
        public bool Arrest { get; set; }
        public string Station { get; set; }
        public string IncidentDate { get; set; }
        public string IncidentTime { get; set; }
        public string IncidentLocation { get; set; }
        public string City { get; set; }
        public string URN { get; set; }
        public string IABLieutenantNotified { get; set; }
        public string NotificationDate { get; set; }
        public string NotificationTime { get; set; }
        public string IABNotifiedby { get; set; }
        public string FormCompletedby { get; set; }
        public string InvestigatingAgency { get; set; }
        public string AgencyRptNum { get; set; }
        public string Charges { get; set; }
        public bool AccidentalDischarge { get; set; }
        public bool ShotsFiredatAnimals { get; set; }
        public string BreedofAnimal { get; set; }
        public bool killed { get; set; }
        public bool wounded { get; set; }
        public bool missed { get; set; }
        public string NumberofShots { get; set; }
        public string TypeofAmmo { get; set; }
        public string BrandofFirearm { get; set; }
        public string DepartmentissuedWeapon { get; set; }
        public bool Abrasions { get; set; }
        public bool EyeInjury { get; set; }
        public bool Deceased { get; set; }
        public bool Head { get; set; }
        public bool MinorSkeletal { get; set; }
        public bool Sutures { get; set; }
        public bool Other { get; set; }
        public bool NoneObserved { get; set; }
        public string FacilityName { get; set; }
        public string ApprovedforBooking { get; set; }
        public bool Vehicle { get; set; }
        public bool Foot { get; set; }
        public bool Both { get; set; }
        public string Synopsis { get; set; }
        public string OnDutyOffDuty { get; set; }
        public string AcademyIssuedConversion { get; set; }
        public string AlcoholDrugsInvolved { get; set; }
        public string WeaponMountedLight { get; set; }
        public string WeaponMountedLaser { get; set; }
        public string SurefireDGSwitch { get; set; }
        public string Clothing { get; set; }
        public string InjuriesYN { get; set; }
        public string PropertyDamage { get; set; }
        public string UDOccurance { get; set; }
        public string NumberofRoundsRecovered { get; set; }
        
        public List<InvolvedPersons> InvolvedPersons { get; set; }
        public List<InvolvedLASDPersonnel> InvolvedLASDPersonnel { get; set; }
        public string RejectComments { get; set; }
        public string IABLieutenantNotifiedId { get; set; }
        public string IABLieutenantNotifiedName { get; set; }
        public string IABNotifiedId { get; set; }
        public string FormCompletedId { get; set; }
    }
    public class InvolvedLASDPersonnel
    {
        public string StatusID { get; set; }
        public string EmpNum { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string Rank { get; set; }
        public string UOA { get; set; }
        public string ILPGender { get; set; }
        public string ILPAge { get; set; }
        public string OffDuty { get; set; }

    }
    public class InvolvedPersons
    {
        public string OStatusID { get; set; }
        public string OBook { get; set; }
        public string OLastName { get; set; }
        public string OFirstName { get; set; }
        public string OSex { get; set; }
        public string ORace { get; set; }
        public string ODOB { get; set; }
    }
   
}
