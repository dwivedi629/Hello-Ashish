﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class OperationsForceReview : IEntityBusinessModel
    {
        public int IncidentReviewId { get; set; }
        public bool IsOnlySave { get; set; }
        public int formDataId { get; set; }
        public int IncidentID { get; set; }
        public int FormID { get; set; }
        public int UserRoleId { get; set; }
        public string UserRole { get; set; }
        public string EmpId { get; set; }
        public string Time { get; set; }
        public string URN { get; set; }
        public string Facility { get; set; }
        public string Reference { get; set; }
        public string Location { get; set; }
        public string eLots { get; set; }
        public bool ForceNotification { get; set; }
        public bool SupervisorReport { get; set; }
        public bool ForceMemo { get; set; }
        public bool MedicalReport { get; set; }
        public bool InService { get; set; }
        public bool AudioVideoOfInterviews { get; set; }
        public bool AudioVideoOfincidentScene { get; set; }
        public bool IABNotification { get; set; }
        public bool IncidentReport { get; set; }
        public bool InmateAssaultSheet { get; set; }
        public bool MentalHealth { get; set; }
        public bool SafetyChair { get; set; }
        public bool TaserDownload { get; set; }
        public bool InmateExtraction { get; set; }
        public bool DormPurge { get; set; }
        public bool OtherRelevantDocuments { get; set; }
        public string Other { get; set; }
        public string RejectComments { get; set; }
    }
}
