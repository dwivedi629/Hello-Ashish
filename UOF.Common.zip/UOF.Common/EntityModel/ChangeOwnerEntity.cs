﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class ChangeOwnerModel
    {
        public Int32 OwnerId { get; set; }
        public Int32 IncidentId { get; set; }
        public Int32 IncidentReviewId { get; set; }
        public Int32 FormId { get; set; }
        public string ExistingEmpId { get; set; }
        public string ChangedEmpId { get; set; }
        public string ChangedEmpLastName { get; set; }
        public string ChangedEmmFirstName { get; set; }
        public string ChangedEmpRank { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public string EmailId { get; set; }
        public string owner { get; set; }
        public int UserTypeId { get; set; }
        public bool isCFRT { get; set; }

    }
}
