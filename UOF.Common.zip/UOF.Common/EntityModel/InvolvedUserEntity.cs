﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class InvolvedUserEntity : UserDetailEntity
    {
        public int IncidentUserInvolvedId { get; set; }
        public Int32? IncidentUserId { get; set; }
        public Int32? IncidentId { get; set; }
        public string EmployeeId { get; set; }
        public string UserRole { get; set; }
        public bool Active { get; set; }

        public string TypeOfForce { get; set; } //added
        public string InjurySeverity { get; set; }  //added
        public string Isforecasting { get; set; }  //added
        public string IndForceUsed { get; set; }
        public Int32? IndividualCatId { get; set; }
        public bool IsDirected { get; set; }
        public bool IsRescue { get; set; }
        public bool IsMedicalAssist { get; set; }
        public bool IsInjured { get; set; }
        public bool IsTreated { get; set; }
        public bool IsAdmitted { get; set; }
        public string Facility { get; set; }
        public string CoronerCaseId { get; set; } //changed
        public string EmployeeItemNumber { get; set; }
        public DateTime? DepartmentHireDate { get; set; }
        public DateTime? LastPromotionDate { get; set; }
        public Int32? DepartmentTenureInDays { get; set; }
        public Int32? RankTenureIndays { get; set; }
        public string IsEmployeeEscortSuspect { get; set; }
        public string SelectedDress { get; set; }
        public string DirectedEmpId { get; set; }
        public string DirectedLastName { get; set; }
        public string DirectedFirstName { get; set; }
        public string DirectedRank { get; set; }
        public string DirectedEmailId { get; set; }
        public string ITA { get; set; }
        public string RM { get; set; }
        public string ShiftType { get; set; }
        public bool DVert { get; set; }
        public string InvolType { get; set; }
    }
}
