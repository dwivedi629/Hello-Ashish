﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class DeputyIncidentReportBusinessModel : IEntityBusinessModel
    {
        public int IncidentReviewId { get; set; }
        public int formDataId { get; set; }
        public int IncidentID { get; set; }
        public int FormID { get; set; }
        public string EmpId { get; set; }
        public int UserRoleId { get; set; }
        public string UserRole { get; set; }
        public bool isApproval { get; set; }
        public bool IsOnlySave { get; set; }
        public string SubmitedId { get; set; }
        public narrative narrative { get; set; }
        public List<VictimModel> VictimModel { get; set; }
        public List<SuspectModel> SuspectModel { get; set; }
        public deputy deputy { get; set; }
        public List<VehicleModel> VehicleModel { get; set; }
        public Screening Screening { get; set; }
        public Narrative Narrative { get; set; }
        public property property { get; set; }
    }

    public class narrative
    {
        public bool active { get; set; }
        public bool inactive { get; set; }
        public bool pending { get; set; }
        public string IncidentAction { get; set; }
        public bool noncriminal { get; set; }
        public string NumberOfAdultArrests { get; set; }
        public string NumberOfSubjectDetentions { get; set; }
        public string URN { get; set; }
        public string TAG { get; set; }
        public string CallTime { get; set; }

        public bool ASAP { get; set; }
        public string ASAPText { get; set; }
        public bool FirearmRelated { get; set; }
        public bool GangRelated { get; set; }
        public bool CyberCrime { get; set; }
        public bool CyberrelatedCrime { get; set; }
        public bool CyberrelatedIncident { get; set; }
        public bool ChkOther { get; set; }
        public string ChkOtherTextValue { get; set; }
        public string DateTimeDayOfOccurrence { get; set; }
        public bool PrintsRequested { get; set; }
        public bool PrintsCompleted { get; set; }
        public string RequestedName { get; set; }
        public string By { get; set; }
        public string Time { get; set; }
        public string LocationOfOccurrence { get; set; }
        public string BusinessName { get; set; }
        public List<ClasificationItems> ClasificationItems { get; set; }
    }
    public class ClasificationItems
    {
        public string Classification1LevelStatCode { get; set; }
        public string Classification2LevelStatCode { get; set; }
        public string Classification3LevelStatCode { get; set; }
    }



    public class VictimModel
    {
        public string VictimSerialNumber { get; set; }
        public string VictimCode { get; set; }
        public string VictimCodeText { get; set; }
        public bool isAdult { get; set; }
        public bool isBusiness { get; set; }
        public string VictimIndex { get; set; }
        public string VictimCount { get; set; }
        public string VictimLastName { get; set; }
        public string VictimFirstName { get; set; }
        public string VictimMiddleName { get; set; }
        public string VictimSex { get; set; }
        public string VictimRace { get; set; }
        public string VictimEthnicOrigin { get; set; }
        public string VictimDOB { get; set; }
        public string VictimAge { get; set; }
        public string VictimDriverLicense { get; set; }
        public string VictimState { get; set; }
        public string VictimResidenseState { get; set; }
        public string VictimResidenseAddress { get; set; }
        public string VictimResidenseCity { get; set; }
        public string VictimResidenseZip { get; set; }
        public string VictimResidensePhone { get; set; }
        public string VictimBusinessAddress { get; set; }
        public string VictimBusinessCity { get; set; }
        public string VictimBusinessState { get; set; }
        public string VictimBusinessZip { get; set; }
        public string VictimBusinessPhone { get; set; }
        public string VictimEmailAddress { get; set; }
        public string VictimSocialNetworkingAccount { get; set; }
        public string VictimCellPhone { get; set; }
        public string VictimClassificationNumber { get; set; }
        public string VictimDesirousOfProsecution { get; set; }
        public string VictimSexCrimeDesirousOfConfidentiality { get; set; }
        public string VictimEnglishSpeaking { get; set; }
        public string VictimEnglishSpeakingTextValue { get; set; }
        public string vof1 { get; set; }
        public string vof2 { get; set; }
        public string vof3 { get; set; }
        public string vof4 { get; set; }
        public string vof5 { get; set; }
    }
    public class SuspectModel
    {
        public string SuspectSerialNumber { get; set; }
        public string SuspectCode { get; set; }
        public string SuspectCodeText { get; set; }
        public string SuspectIndex { get; set; }
        public string SuspectCount { get; set; }
        public string SuspectLastName { get; set; }
        public string SuspectMiddleName { get; set; }
        public string SuspectFirstName { get; set; }
        public string SuspectDOB { get; set; }
        public string SuspectAge { get; set; }
        public string SuspectDriverLicense { get; set; }
        public string SuspectState { get; set; }
        public string SuspectSex { get; set; }
        public string SuspectRace { get; set; }
        public string SuspectEthnicOrigin { get; set; }
        public string SuspectHair { get; set; }
        public string SuspectEyes { get; set; }
        public string SuspectHGT { get; set; }
        public string SuspectWGT { get; set; }
        public string SuspectCellPhone { get; set; }
        public string SuspectResidenseAddress { get; set; }
        public string SuspectResidenseCity { get; set; }
        public string SuspectResidenseState { get; set; }
        public string SuspectResidenseZip { get; set; }
        public string SuspectResidensePhone { get; set; }
        public string SuspectBusinessAddress { get; set; }
        public string SuspectBusinessCity { get; set; }
        public string SuspectBusinessState { get; set; }
        public string SuspectBusinessZip { get; set; }
        public string SuspectBusinessPhone { get; set; }
        public string SuspectAka { get; set; }
        public string SuspectEmailAddress { get; set; }
        public string SuspectSocialNetworkingAccount { get; set; }
        public string SuspectEnglishSpeaking { get; set; }
        public string SuspectEnglishSpeakingTextValue { get; set; }
        public string SuspectMonikar { get; set; }
        public string SuspectCharge { get; set; }
        public string SuspectBookingNumber { get; set; }
        public string SuspectDetainedCite { get; set; }
    }
    public class deputy
    {
        public string Deputy1 { get; set; }
        public string Deputy1EmployeeNumber { get; set; }
        public string Deputy1SwornExperience { get; set; }
        public string Deputy1Station { get; set; }
        public string Deputy1UnitORCar { get; set; }
        public string Deputy1Shift { get; set; }
        public string Deputy1PCD { get; set; }
        public string Deputy1VacationDates { get; set; }
        public string HQNotificationRequested { get; set; }
        public string HQNotificationRequestedTextValue { get; set; }
        public string HQNotificationDeputy { get; set; }
        public string HQNotificationDateORTime { get; set; }
        public string SuspectFieldReleaseDeputy { get; set; }
        public string SuspectFieldReleaseDeputyName { get; set; }
        public string SuspectFieldReleaseDeputyDate { get; set; }
        public string Deputy2 { get; set; }
        public string Deputy2EmployeeNumber2 { get; set; }
        public string Deputy2SwornExperience { get; set; }
        public string Deputy2VacationDates { get; set; }
        public string Deputy2Approved { get; set; }
        public string Deputy2ApprovedEmployeeNumber { get; set; }
        public string Deputy2ApprovedDateORTime { get; set; }
        public string Deputy2Assignment { get; set; }
        public string SpecialRequestDistribution { get; set; }
        public string CrimeBroadcastBy { get; set; }
        public string CrimeBroadcastName { get; set; }
        public string CrimeBroadcastDateORTime { get; set; }
        public string CrimeBroadcastSecretary { get; set; }
    }
    public class VehicleModel
    {
        public string VehicleSerialNumber { get; set; }
        public string VehicleForVictimNumber { get; set; }
        public string VehicleForSuspectNumber { get; set; }
        public string VehicleLicenseNumber { get; set; }
        public string VehicleLicenseNumberState { get; set; }
        public string VehicleRegisteredOwner { get; set; }
        //public bool ChpYes { get; set; }
        //public bool ChpNo { get; set; }
        public string ChpRdoYesNo { get; set; }
        public string VehicleYear { get; set; }
        public string VehicleMake { get; set; }
        public string VehicleModelDetail { get; set; }
        public string VehicleBodyType { get; set; }
        public string VehicleColor { get; set; }
        public string VehicleIdentifyingFeatures { get; set; }
        public string VehicleSelectedStatus { get; set; }
        public string VehicleSelectedStatusValue { get; set; }
        public string VehicleGarageNameANDPhone { get; set; }
        public string VehicleDescriptionOfDamage { get; set; }
    }
    public class Screening
    {
        public bool SuspectInCustodyYes { get; set; }
        public bool SuspectInCustodyNo { get; set; }
        public bool SuspectNamkedKnownYes { get; set; }
        public bool SuspectNamkedKnownNo { get; set; }
        public bool UniqueSuspectIdentifiersYes { get; set; }
        public bool UniqueSuspectIdentifiersNo { get; set; }
        public bool VehicleincustodyYes { get; set; }
        public bool VehicleincustodyNo { get; set; }
        public bool UniqueVehicleIdentifiersYes { get; set; }
        public bool UniqueVehicleIdentifiersNo { get; set; }
        public bool WriterReviewerDiscretionYes { get; set; }
        public bool WriterReviewerDiscretionNo { get; set; }
    }
    public class Narrative
    {
        public string IncidentNarrative { get; set; }
    }

    public class property
    {
        public string PropertyReleasedToNumber { get; set; }
        public string RejectComments { get; set; }
        public List<PropertyData> PropertyData { get; set; }
    }
    public class PropertyData
    {
        public string PropertyCodeNumber { get; set; }
        public string PropertyItemNumber { get; set; }
        public string PropertyQuantityNumber { get; set; }
        public string PropertyDescription { get; set; }
        public string PropertySerialNumber { get; set; }
        public string PropertyValueNumber { get; set; }
    }
}
