﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class ChangeRoleEntity
    {
        public Int32 RoleId { get; set; }

        public Int32 IncidentId { get; set; }

        public String URN { get; set; }

        public String EmployeeId { get; set; }

        public String Name { get; set; }

        public String ForceRank { get; set; }

        public String UoFRank { get; set; }

        public DateTime ValidStill { get; set; }

        public Boolean Active { get; set; }

        public DateTime CreatedOn { get; set; }

        public String CreatedBy { get; set; }

        public string loggedId { get; set; }

    }
}
