﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class CAModel
    {
        public int IncidentReviewId { get; set; }
        public int formDataId { get; set; }
        public int IncidentID { get; set; }
        public string EmpId { get; set; }
        public int FormID { get; set; }
        public bool IsOnlySave { get; set; }
        public int UserRoleId { get; set; }
        public string UserRole { get; set; }
        public string RejectComments { get; set; }
        public string Name { get; set; }
        public string Department { get; set; }
        public string Subject { get; set; }
        public string DepId { get; set; }
        public string URN { get; set; }
        public string Employee { get; set; }
        public string SuspectSubject { get; set; }
        public string SName { get; set; }
        public bool SuspectedGangMember { get; set; }
        public string NameofGang { get; set; }
        public bool SuspectedGangMember_1 { get; set; }

        public string NameofGang_1 { get; set; }
        public List<CDItems> CDItems { get; set; }
        public List<BPSectionOne> BPSectionOne { get; set; }
        public List<SBPItem> SBPItem { get; set; }
    }

    public class CDItems
    {
        public string ItemTypeId { get; set; }
        public string Description { get; set; }
        public string ItmTypeId { get; set; }
        public string Descp { get; set; }
    }
    public class BPSectionOne
    {
        public string Left { get; set; }
        public string Right { get; set; }
        public string BPItemUNK { get; set; }
        public string BP { get; set; }
        public string Marks { get; set; }
    }
    public class SBPItem
    {
        public string sLeft { get; set; }
        public string sRight { get; set; }
        public string SBPItemUNK { get; set; }
        public string sBP { get; set; }
        public string sMarks { get; set; }
    }
    public class CAEntity : IEntityBusinessModel
    {
        public List<ReviewBusinessModel> ReviewBusinessModel { get; set; }
        public CAModel Model { get; set; }
    }

}
