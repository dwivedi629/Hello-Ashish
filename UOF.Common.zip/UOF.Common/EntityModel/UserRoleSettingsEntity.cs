﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
   public class UserRoleSettingsEntity
    {
       public string Description { get; set; }
       public string RoleCode { get; set; }
       public int RoleId { get; set; }
       public string RoleName { get; set; }
       public bool ReadOnly { get; set; }
       public int Rank { get; set; }
    }
}
