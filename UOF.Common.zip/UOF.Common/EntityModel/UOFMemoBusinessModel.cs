﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class UOFMemo : IEntityBusinessModel
    {
        public int IncidentReviewId { get; set; }
        public int FormDataId { get; set; }
        public int IncidentID { get; set; }
        public string EmpId { get; set; }
        public int FormID { get; set; }
        public int UserRoleId { get; set; }
        public string UserRole { get; set; }
        public bool IsOnlySave { get; set; }
        public string File { get; set; }
        public string ReferenceFile { get; set; }
        public string DeputyPW { get; set; }
        //public bool WitnessDeputy { get; set; }
        public string EmployeeID { get; set; }
        public string DeputyLastName { get; set; }
        public List<MemoItems> MemoItems { get; set; }
        public string Date { get; set; }
        public string Time { get; set; }
        public string LocationOfOccurrence { get; set; }
        public string Narrative { get; set; }
        public string RejectComments { get; set; }
        public string WrittenEmployeeNumber { get; set; }
        public string WrittenByName { get; set; }
        public string FacilityName { get; set; }
        public string Shift { get; set; }

        public string ApprovedEmployeeNumber { get; set; }
        public string ApprovedByName { get; set; }
        public string ApprovedMemodate { get; set; }
        public string ApprovedTime { get; set; }
    }
    public class MemoItems
    {
        public string BookingNumber { get; set; }
        public string InvolvedInmates { get; set; }
    }
}
