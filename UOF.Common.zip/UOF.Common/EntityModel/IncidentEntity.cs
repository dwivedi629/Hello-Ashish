﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class IncidentEntity : AddressEntity, ICloneable
    {
        public IncidentEntity()
        {
            foreach (PropertyInfo f in this.GetType().GetProperties())
            {
                foreach (Attribute attr in f.GetCustomAttributes(true))
                {
                    if (attr is DefaultValueAttribute)
                    {
                        DefaultValueAttribute dv = (DefaultValueAttribute)attr;
                        f.SetValue(this, dv.Value, null);
                    }
                }
            }

        }
        object ICloneable.Clone()
        {
            return this.Clone();
        }
        public IncidentEntity Clone()
        {
            return (IncidentEntity)this.MemberwiseClone();
        }
        public bool IsOnlySave { get; set; }
        public int IncidentId { get; set; }
        public string URN { get; set; }
        public System.DateTime IncidentDate { get; set; }
        public string currentMode { get; set; }
        public string ContactTypeId { get; set; } // change
        public string CustodyEventId { get; set; } // change
        public string CTOthers { get; set; } // change
        public string Perceivedarmed { get; set; }
        [DefaultValue("N")]
        public string IsAdminInvestigation { get; set; }
        public Int32? IncidentCategoryId { get; set; }
        public string ForceTypeId { get; set; }
        [DefaultValue("N")]
        public string IsDeptyInjury { get; set; }
        [DefaultValue("N")]
        public string IsSuspectInjury { get; set; }
        [DefaultValue("N")]
        public string IsUnderlyingArrest { get; set; }
        [DefaultValue("N")]
        public string IsUnderlyingCrime { get; set; }
        [DefaultValue("N")]
        public string IsOnK12Campus { get; set; }
        [DefaultValue("N")]
        public string IsByFootPursuit { get; set; }
        [DefaultValue("N")]
        public string IsByVehiclePursuit { get; set; }
        [DefaultValue("N")]
        public string IsReactiveForce { get; set; }
        [DefaultValue("N")]
        public string IsPlannedForce { get; set; }
        [DefaultValue("N")]
        public string IsInmateInjuryReportWritten { get; set; }
        [DefaultValue("N")]
        public string IsMedicalStaffPresent { get; set; }
        [DefaultValue("N")]
        public string IsMentalHealthPresent { get; set; }
        [DefaultValue("N")]
        public string IsSuperVisorPresent { get; set; }
        [DefaultValue("NA")]
        public string IsMedicalRecordChecked { get; set; }
        [DefaultValue("NA")]
        public string IsExtractionOrderByMedical { get; set; }
        [DefaultValue("NA")]
        public string IsMentalHealthProfessional { get; set; }
        [DefaultValue("NA")]
        public string IsDepartmentSignAdmonishmentAndNotedChangesInReport { get; set; }
        [DefaultValue("NA")]
        public string IsInvestigatorDirectedTheForce { get; set; }
        [DefaultValue("NA")]
        public string IsInvestigatorParticipatedInTheForce { get; set; }
        [DefaultValue("NA")]
        public string IsInvestigatorPlannedTheForce { get; set; }
        [DefaultValue("NA")]
        public string IsDepartmentMembersSeparated { get; set; }
        [DefaultValue("N")]
        public string IsPPIReviewCompleted { get; set; }
        public string EmpId { get; set; }
        public string PersonNotified { get; set; }
        [DefaultValue("N")]
        public string IsStaffEscortInvolvedInmates { get; set; }
        [DefaultValue("N")]
        public string IsVideoInReport { get; set; }
        [DefaultValue("N")]
        public string IsCCTVCoverage { get; set; }
        [DefaultValue("N")]
        public string IsVideoShooted { get; set; }
        [DefaultValue("N")]
        public string IsVideoOfIncident { get; set; }
        [DefaultValue("N")]
        public string IsIABNotified { get; set; }
        public string IABNotifiedUserId { get; set; }
        public string IABNotifiedEmailId { get; set; }
        [DefaultValue("N")]
        public string IsIABRollOut { get; set; }
        public string IABRolloutEmployees { get; set; }
        [DefaultValue("N")]
        public string IsIABHandling { get; set; }
        public string IABHandlingUserId { get; set; }
        public string IABHandlingFirstName { get; set; } //viewmodel
        public string IABHandlingLastName { get; set; }//viewmodel
        public string IABHandlingRank { get; set; }//viewmodel
        public string IABHandlingEmailId { get; set; }//viewmodel
        [DefaultValue("N")]
        public string IsCFRTNotified { get; set; }
        public string CFRTNotifiedUserId { get; set; }
        public string CFRTNotifiedFirstName { get; set; } //viewmodel
        public string CFRTNotifiedLastName { get; set; }//viewmodel
        public string CFRTNotifiedRank { get; set; }//viewmodel
        public string CFRTNotifiedEmailId { get; set; }//viewmodel
        [DefaultValue("N")]
        public string IsCFRTHandling { get; set; }
        public string CFRTHandlingUserId { get; set; }
        public string CFRTHandlingEmailId { get; set; }//viewmodel
        [DefaultValue("N")]
        public string IsCFRTRollOut { get; set; }
        public string CFRTRolloutEmployees { get; set; }
        public string IncidentName { get; set; }
        [DefaultValue("N")]
        public string IsResultedInArrest { get; set; }
        [DefaultValue("N")]
        public string IsResultedInCrimeReport { get; set; }
        public string Location { get; set; }
        public string LevelofResistance { get; set; }
        public string SelectedCity { get; set; }
        public string IncidentApprovalStatus { get; set; }
        public DateTime? IncidentCreateDate { get; set; }
        public string Time { get; set; }
        public string CiviliansUnderlyingArrest { get; set; }
        public string CiviliansUnderlyingCrime { get; set; }
        public string PrimaryAgency { get; set; }
        public string AssaulatedofficersNumber { get; set; }
        public string ExperiencedUOFNumber { get; set; }
        public string DeputyUOFNumber { get; set; }
        public string DeputyAssaulatedNumber { get; set; }
        public string DeputyPresentonScene { get; set; }
        public string SelectedCivilianResistance { get; set; }
        public string SelectedCivilianConfirmedarmed { get; set; }
        public string Forecasting { get; set; }
        public string CCTVcoverage { get; set; }
        public string HandheldVideoofIncident { get; set; }
        public string ForceLocation { get; set; }
        public string Lifethreatening { get; set; }
        public string Assulative { get; set; }
        public string CFRTHandlingFirstName { get; set; }
        public string CFRTHandlingLastName { get; set; }
        public string CFRTHandlingRank { get; set; }
        [DefaultValue("NA")]
        public string PFPlannedUoF { get; set; }
        [DefaultValue("NA")]
        public string PFExtraction { get; set; }

        [DefaultValue(false)]
        public bool IsDeleted { get; set; }

        public List<IncidentStatusDetail> IncidentStatus { get; set; }
        
        public UserDetailEntity UserDetails { get; set; }
        //Business fields
        public string BusinessName { get; set; }
        public string BusinessZipCode { get; set; }
        public string BusinessCity { get; set; }
        public string BusinessStreet { get; set; }
        public string BusinessAddressNumber { get; set; }

        public string ExtractionEmpId { get; set; }
        public string MentalHealthEmpId { get; set; }
        public string MentalHealthEmpName { get; set; }
        public string CCTVNoReason { get; set; }
        public string CCTVExtracted { get; set; }
        public string VideoShootedNoReason { get; set; }
        public string IncidentLocationName { get; set; }
        public string Station { get; set; }
        //public string Facility { get; set; }
        public string Staging { get; set; }
        public string PPINo { get; set; }
        public string eLOTS { get; set; }
        public string elotsYN { get; set; }
        public string elotsNoReason { get; set; }

        public string SupervisorDirectedId { get; set; }
        public string SupervisorDirectedFirstName { get; set; }
        public string SupervisorDirectedLastName { get; set; }
        public string SupervisorDirectedRank { get; set; }
        public string SupervisorDirectedMailId { get; set; }
        
        public string PRReason { get; set; }
        public string ReferenceNo { get; set; }
        public string UserStatusOnIncident { get; set; } //to hold users status on the incident
        public WorkFlowEntity WorkFlowStatus { get; set; }
        public string MHS { get; set; }
        public string MHSReason { get; set; }
        public string PFData { get; set; }
        public string MedicalLife { get; set; }
        public string MedRcdPrior { get; set; }
        public string PlanAltered { get; set; }
        public string InvestOfficerId { get; set; }
        public bool isSRApproved { get; set; }
        public int incidentRank { get; set; }
    }

    
    public class AdditionalSergeantModel
    {
        public int AddlSergeantId { get; set; }
        public int IncidentId { get; set; }
        public string EmployeeNumber { get; set; }
        public string Name { get; set; }
        public string SergeantType { get; set; }
        public string CreateBy { get; set; }
        public DateTime CreateOn { get; set; }
    }

}
