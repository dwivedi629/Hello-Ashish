﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class EmailNotificationModel
    {
        public Int32 EmailNotificationId { get; set; }

        public Int32 IncidentId { get; set; }

        public string ToEmployeeId { get; set; }

        public Int32 FormId { get; set; }

        public String EmployeeNumber { get; set; }

        public String EmailId { get; set; }

        public String Department { get; set; }

        public Boolean? Sent { get; set; }

        public Boolean? Responded { get; set; }

        public String Status { get; set; }

        public DateTime SentOn { get; set; }

        public DateTime? RespondedOn { get; set; }

        public List<LookupEntity> AssignedForms { get; set; }

        public string comments { get; set; }

        public string URN { get; set; }

        public string ExplanationFormName { get; set; }

        public string UoFbaseURL { get; set; }

    }
}
