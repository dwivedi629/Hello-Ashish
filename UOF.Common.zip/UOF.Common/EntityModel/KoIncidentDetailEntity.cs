﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class KoIncidentDetailEntity
    {
        //Incident
        public int URN { get; set; }
        public DateTime Date { get; set; }
        public DateTime Time { get; set; }
        public string SelectedLocation { get; set; }
        public int AddressNo { get; set; }
        public string Street { get; set; }
        public string City { get; set; }
        public string BussinessName { get; set; }
        public int Zip { get; set; }
        public string SelectedCity { get; set; }
        public string selectedFacility { get; set; }
        public string FootPursuit { get; set; }
        public string VehiclePursuit { get; set; }
        public string AdminInvestigation { get; set; }
        public string IncidentCategory { get; set; }
        public string DeputyInjury { get; set; }
        public string SuspectInjury { get; set; }
        public string UnderlyingArrest { get; set; }
        public string UnderlyingCrime { get; set; }
        public string K12Campus { get; set; }
        public string selectedResistance { get; set; }
        public string CiviliansUnderlyingArrest { get; set; }
        public string CiviliansUnderlyingCrime { get; set; }
        public string selectedDress { get; set; }
        public string PrimaryAgency { get; set; }
        public string selectedReason { get; set; }
        public int assaulatedofficersNumber { get; set; }
        public int experiencedUOFNumber { get; set; }
        public int DeputyUOFNumber { get; set; }
        public int DeputyAssaulatedNumber { get; set; }
        public string DeputyPresentonScene { get; set; }
        public string selectedCivilianResistance { get; set; }
        public string selectedPerceivedarmed { get; set; }
        public string selectedCivilianConfirmedarmed { get; set; }
        public string selectedLocationofForce { get; set; }
        public string forecasting { get; set; }
        public string IBANotified { get; set; }
        public int IABHandlingEmployeeId { get; set; }
        public string IABHandlingFirstName { get; set; }
        public string IABHandlingLastName { get; set; }
        public int IABHandlingRank { get; set; }
        public string IABRollout { get; set; }
        public string IABRolloutEmployees { get; set; }
        public string CFRTNotified { get; set; }
        public int CFRTNotifiedEmployeeId { get; set; }
        public string CFRTNotifiedFirstName { get; set; }
        public string CFRTNotifiedLastName { get; set; }
        public int CFRTNotifiedRank { get; set; }
        public string CFRTRollout { get; set; }
        public string CFRTRolloutEmployees { get; set; }
        public int EmployeeId { get; set; }
        public string PersonNotified { get; set; }
        public string ReactiveForce { get; set; }
        public string PlannedForce { get; set; }
        public string InmateInjuryReportWritten { get; set; }
        public string MedicalStaffPresent { get; set; }
        public string DepartmentofMentalHealthPresent { get; set; }
        public string SupervisorPresent { get; set; }
        public string Medicalrecordschecked { get; set; }
        public string Extractionorderedbymedicalormentalhealthprovider { get; set; }
        public string WasaMentalHealthProfessional { get; set; }
        public string Videosignadmonishmentandnotechangesinreport { get; set; }
        public string InvestigatingSupervisordirecttheforce { get; set; }
        public string Investigatingsupervisorparticipateintheforce { get; set; }
        public string Investigatingsupervisorplantheforce { get; set; }
        public string WereDepartmentmembersseparateduntiltheirreportswerecompleted { get; set; }
        public string Didanyofthestaffinvolvedintheuseofforceescorttheinvolvedinmate { get; set; }
        public string Lifethreatening { get; set; }
        public string Assulative { get; set; }
        public string CCTVcoverage { get; set; }
        public string HandheldVideoofIncident { get; set; }
        public string CFRTHandling { get; set; }
        public int CFRTHandlingEmployeeId { get; set; }
        public string CFRTHandlingFirstName { get; set; }
        public string CFRTHandlingLastName { get; set; }
        public int CFRTHandlingRank { get; set; }
        public string IABHandling { get; set; }
       

        //Agency
        public string AgencyORI { get; set; }
        public string AgencyNCIC { get; set; }
        public string AgencyNIBRSCode { get; set; }
        public string AgencyName { get; set; }
        public string AgencyCounty { get; set; }
        public string PFExtraction { get; set; }
        public string PFPlannedUoF { get; set; }
    }
}
