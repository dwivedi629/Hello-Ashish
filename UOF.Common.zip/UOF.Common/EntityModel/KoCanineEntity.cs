﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
     public class KoCanineEntity
    {
         //Canine
        public int PrimaryHandlerNumber { get; set; }
        public string PrimaryHandlerName { get; set; }
        public string PrimaryHandlerCanine { get; set; }
        public string PrimaryHandlerUnit { get; set; }
        public int AssistHandlerNumber { get; set; }
        public string AssistHandlerName { get; set; }
        public string AssistHandlerCanine { get; set; }
        public string AssistHandlerUnit { get; set; }
        public string AssistHandlerNumber_One { get; set; }
        public string AssistHandlerName_One { get; set; }
        public string AssistHandlerCanine_One { get; set; }
        public string AssistHandlerUnit_One { get; set; }
        public string Area { get; set; }
        public string Building { get; set; }
        public string TOSOther { get; set; }
        public string TOSOtherReason { get; set; }
        public string ApprehendingSuspect { get; set; }
        public string ConductingSearch { get; set; }
        public string ProtectingHandler { get; set; }
        public string BOWOther { get; set; }
        public string BOWOtherReason { get; set; }
        public string Bite { get; set; }
        public string TOIOther { get; set; }
        public string TOIOtherReason { get; set; }
        public string Announcements { get; set; }
        public string AnnouncementswereMade { get; set; }
        public string None_Reason { get; set; }
        public string Announcementmadeby { get; set; }
        public string AnnouncementMadeBY_Reason { get; set; }
        public string AnnouncementReason { get; set; }
        public string BYAeroUnit { get; set; }
        public string ByRadioCar { get; set; }
        public string English { get; set; }
        public string Spanish { get; set; }
        public string Recorded { get; set; }
        public string CriminalHistory { get; set; }
        public string Notifications { get; set; }
    }
}
