﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class CSEntity : IEntityBusinessModel
    {
        public int IncidentReviewId { get; set; }
        public int formDataId { get; set; }
        public int IncidentID { get; set; }
        public bool IsOnlySave { get; set; }
        public string EmpId { get; set; }
        public int FormID { get; set; }
        public int UserRoleId { get; set; }
        public string UserRole { get; set; }
        public List<CSVictimModel> CSVictimModel { get; set; }
        public List<SupectModel> SupectModel { get; set; }
        public List<ReviewBusinessModel> ReviewBusinessModel { get; set; }
        public List<VictimData> VictimData { get; set; }
        public List<VictimMarksData> VictimMarksData { get; set; }
        public List<SuspectData> SuspectData { get; set; }
        public List<SuspectMarksData> SuspectMarksData { get; set; }
        public string RejectComments { get; set; }
    }
    public class VictimData
    {
        public string VictimNo { get; set; }
        public string VictimName { get; set; }
        public string HousingFacility { get; set; }
        public string Barrack { get; set; }
        public string Cell { get; set; }
    }
    public class VictimMarksData
    {
        public string VictimNo { get; set; }
        public string SMT { get; set; }
        public string LR { get; set; }
        public string BP { get; set; }
        public string Desc { get; set; }
    }
    public class SuspectData
    {
        public string sSupsectNo { get; set; }
        public string sSuspectName { get; set; }
        public string sHousingFacility { get; set; }
        public string sBarrack { get; set; }
        public string sCell { get; set; }
    }
    public class SuspectMarksData
    {
        public string sSuspectNum { get; set; }
        public string sSMT { get; set; }
        public string sLR { get; set; }
        public string sBP { get; set; }
        public string sDesc { get; set; }
    }
    public class SupectModel
    {

        public string ID { get; set; }
        public string Type { get; set; }
        public string Answer { get; set; }
        public string Observer { get; set; }
    }
    public class CSVictimModel
    {

        public string ID { get; set; }
        public string Type { get; set; }
        public string Answer { get; set; }
        public string Observer { get; set; }
    }

}
