﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.EntityModel
{
    public class SuspectUserEntity : UserDetailEntity
    {
        public int IncidentUserSuspectId { get; set; }
        public int IncidentId { get; set; }
        public Int32? IncidentUserId { get; set; }
        public int UserId { get; set; }
        public bool Active { get; set; }

        public string BookingNumber { get; set; }
        public string Armed { get; set; }
        //public string LastName { get; set; }
        //public string FirstName { get; set; }
        //public string MiddleName { get; set; }
        public string AkaLastname { get; set; }
        public string AkaFirstname { get; set; }
        public string AkaMiddleName { get; set; }
        //public string Sex { get; set; }
        //public string Dress { get; set; }
        //public string Race { get; set; }
        //public string Dress { get; set; }
        //public string Age { get; set; }
        //public string Height { get; set; }
        //public string Weight { get; set; }
        //public string Street { get; set; }
        //public string City { get; set; }
        //public string State { get; set; }
        //public string ZipCode { get; set; }
        //public string DateOfBirth { get; set; }
        public string PrimaryPhno { get; set; }
        public string SecondaryPhno { get; set; }
        public string PhoneMode { get; set; }
        public string PPhMode { get; set; }
        public string SPhMode { get; set; }
        public string PrimaryChargCode { get; set; }
        public string SecondaryChargCode { get; set; }
        public string CivilianResistance { get; set; }
        public string Lifethreatening { get; set; }
        public string Assulative { get; set; }
        public string Perceivedarmed { get; set; }
        public string CivilianConfirmedarmed { get; set; }
        public string CivilianInjurySeverity { get; set; }
        public string forecasting { get; set; }
        public string TypeofForce { get; set; }
        public string TypeOfInjury { get; set; }
        public string SafetyChairUsed { get; set; }
        public string CriminalHistory { get; set; }
        public string TreatedOnScene { get; set; }
        public string HospitalAdmission { get; set; }
        public string InmatePhysicallyAssaultive { get; set; }
        public string InmateRecalcitrant { get; set; }
        public string InmateonInmateViolenceProvoked { get; set; }
        public string InmateonInmateViolence { get; set; }
        public string MultiPointRestraintsUsed { get; set; }
        public string OthertypesofRestraints { get; set; }
        public string MedicalRecordschecked { get; set; }
        public string MedicalRestraintsUsed { get; set; }
        public string forceusedasDiscipline { get; set; }
        public string CorporalPunishment { get; set; }
        public string cellExtraction { get; set; }
        public string Extractionordered { get; set; }
        public string InmateHarassed { get; set; }
        public string SuspectInterviewedAwayfromInmates { get; set; }
        public string TransorRefuse { get; set; }
        public string OtherplannedUoF { get; set; }
        public string UnderInfluence { get; set; }
        public string Substance { get; set; }
        public string factorinForce { get; set; }
        public string SuspectLOC { get; set; }
        public string ForceUsed { get; set; }
        public string SuspectConfArmedOther { get; set; }
        //Planned Force
        public string PFExtraction { get; set; }
        public string PFPlannedUoF { get; set; }
        //Hospital Admission
        public int HospitalId { get; set; }
        public string RecdTreatmentAt { get; set; }
        public string CornerCase { get; set; }
        public string MentalHistory { get; set; }
        public string BY { get; set; }
        public string HospitalAddress { get; set; }
        public string HospitalPhone { get; set; }
        //Treated
        public int TreatmentId { get; set; }
        public string TreatedName { get; set; }
        public string TreatedUnit { get; set; }
        public string TreatedPhone { get; set; }
        //Suspect Interview
        public string Interview { get; set; }
        public DateTime? InterviewDate { get; set; }
        public string InterviewTime { get; set; }
        public string Audiotape { get; set; }
        public string AudioTapePath { get; set; }
        public string Videotape { get; set; }
        public string VideoTapePath { get; set; }
        public string PhotosofInjuries { get; set; }
        public string InjuryPhotosPath { get; set; }
        public string Announcements { get; set; }

        public string IspregnantInmate { get; set; }
        public string SpecialHandle { get; set; }
        public string SecurityLevel { get; set; }
    }
}
