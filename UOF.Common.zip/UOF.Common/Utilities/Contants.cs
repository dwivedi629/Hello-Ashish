﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UOF.Common.Utilities
{
    public class Constants
    {
        public enum IncidentStatus
        {
            Unknown,
            AtDeputy,
            AtSergeant,
            AtWatchCommander,
            AtUnitCommander,
            AtCommander,
            AtChief,
            AtIAB,
            AtCFRT,
            SuperAdmin,
            CFRTCompleted,
            Completed
        }
        public enum UserType
        {
            Unknown,
            InvolvedEmployee,
            Suspect,
            EmployeeWitness,
            NonEmpWitness,
            WatchCommander,
            UnitCommander,
            Commander,
            OnDuty,
            Supervisor,
            InvestigatorDirected,
            AssignedUser,
            Sergeant,
            Chief

        }
        public enum AddressType
        {
            Unknown,
            Incident,
            User,
        }
        public enum Mode
        {
            Unknown,
            Add,
            Edit,
        }
        public enum UOFForms
        {

            UseofForceNarrativeReport = 10,
            Cat1ChemicalAgent = 11,
            CustodyDivisionForceReviewChecklist = 12,
            UseofForcePackageTrackingSheet = 13,
            UseofForceCategoryOneIncidents = 14,
            UseofForceReviewNotice = 15,
            IncidentReport = 16,
            MedicalReport = 17,
            CrimeAnalysisSupplementalForm = 18,
            InmateInjuryIllness = 19,
            DeputysUseofForceMemorandum = 20,
            CustodyServicesDivisionCrimeAnalysisSupplemental = 21,
            DeputySupplementalReport = 22,
            WatchCommanderUseofForceReview = 23,
            IABMandatoryForm = 24,
            WCUseofForceReviewNotice = 25,
            UnitCommanderUseoFForceReview = 26,
            UCUseofForceReviewNotice = 27,
            CommanderUseofForceReview = 30,
            CMUseofForceReviewNotice = 31,
            SupervisoryReport = 48

        }
        public enum UserRoles
        {
            Unknown,
            SGT,
            DSG,
            MS,
            WC,
            CAPT,
            CMDR,
            CA,
            DC,
            DI,
            SuperAdmin,
            CFRT,
            MED,
            

        }

        public enum Status
        {
            Unknown,
            DON,
            PND,
            UPD,
            Pending,
            NotReady,
            Completed,
            Return,
            Rejected,
            Deleted,

        }
        public enum ContactTypes
        {
            Unknown,
            Home,
            Work,
            Cell,
            Phone1,
            Phone2
        }
        public static string GetFormName(int formId)
        {
            string formName = string.Empty;
            switch (formId)
            {
                case 10:
                    formName = Constants.UOFForms.UseofForceNarrativeReport.ToString();
                    break;
                case 11:
                    formName = Constants.UOFForms.Cat1ChemicalAgent.ToString();
                    break;
                case 12:
                    formName = Constants.UOFForms.CustodyDivisionForceReviewChecklist.ToString();
                    break;
                case 13:
                    formName = Constants.UOFForms.UseofForcePackageTrackingSheet.ToString();
                    break;
                case 14:
                    formName = Constants.UOFForms.UseofForceCategoryOneIncidents.ToString();
                    break;
                case 15:
                    formName = Constants.UOFForms.UseofForceReviewNotice.ToString();
                    break;
                case 16:
                    formName = Constants.UOFForms.IncidentReport.ToString();
                    break;
                case 17:
                    formName = Constants.UOFForms.MedicalReport.ToString();
                    break;
                case 18:
                    formName = Constants.UOFForms.CrimeAnalysisSupplementalForm.ToString();
                    break;
                case 19:
                    formName = Constants.UOFForms.InmateInjuryIllness.ToString();
                    break;
                case 20:
                    formName = Constants.UOFForms.DeputysUseofForceMemorandum.ToString();
                    break;
                case 21:
                    formName = Constants.UOFForms.CustodyServicesDivisionCrimeAnalysisSupplemental.ToString();
                    break;
                case 22:
                    formName = Constants.UOFForms.DeputySupplementalReport.ToString();
                    break;
                case 23:
                    formName = Constants.UOFForms.WatchCommanderUseofForceReview.ToString();
                    break;
                case 24:
                    formName = Constants.UOFForms.IABMandatoryForm.ToString();
                    break;
                case 25:
                    formName = Constants.UOFForms.WCUseofForceReviewNotice.ToString();
                    break;
                case 26:
                    formName = Constants.UOFForms.UnitCommanderUseoFForceReview.ToString();
                    break;
                case 27:
                    formName = Constants.UOFForms.UCUseofForceReviewNotice.ToString();
                    break;
                case 30:
                    formName = Constants.UOFForms.CommanderUseofForceReview.ToString();
                    break;

                case 31:
                    formName = Constants.UOFForms.CMUseofForceReviewNotice.ToString();
                    break;
            }
            return formName;
        }
    }
}
