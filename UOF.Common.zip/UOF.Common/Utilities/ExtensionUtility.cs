﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace UOF.Common.Utilities
{
    /// <summary>
    /// This is an extension method to XML
    /// </summary>
    public static class ExtensionUtility
    {

        /// <summary>
        /// Extension method to serialize the model to XML
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string Serialize<T>(this T value)
        {
            if (value == null)
            {
                return string.Empty;
            }
            try
            {
                var xmlserializer = new XmlSerializer(typeof(T));
                var stringWriter = new StringWriter();
                using (var writer = XmlWriter.Create(stringWriter))
                {
                    xmlserializer.Serialize(writer, value);
                    return stringWriter.ToString();
                }
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred", ex);
            }
        }


        /// <summary>
        /// Extension method that takes objects and serialized them.
        /// </summary>
        /// <typeparam name="T">The type of the object to be serialized.</typeparam>
        /// <param name="source">The object to be serialized.</param>
        /// <returns>A string that represents the serialized XML.</returns>
        public static string SerializeXML<T>(this T source) where T : class, new()
        {
            var serializer = new XmlSerializer(typeof(T));
            using (var writer = new StringWriter())
            {
                serializer.Serialize(writer, source);
                return writer.ToString();
            }
        }


        /// <summary>
        /// Extension method to string which attempts to deserialize XML with the same name as the source string.
        /// </summary>
        /// <typeparam name="T">The type which to be deserialized to.</typeparam>
        /// <param name="XML">The source string</param>
        /// <returns>The deserialized object, or null if unsuccessful.</returns>
        
        public static T Deserialize<T>(this string XML) where T : class, new()
        {
            var serializer = new XmlSerializer(typeof(T));
            using (var reader = new StringReader(XML))
            {
                try { return (T)serializer.Deserialize(reader); }
                catch { return null; } // Could not be deserialized to this type.
            }
        }


        //how to use
        //for eg 

        //1  string xml = foo.Serialize(); serialization
        //string savestring;

        //public void Save()
        //{
        //    savestring = mySerializableObject.SerializeXML<MySerializableClass>();
        //}

        //public void Load()
        //{
        //mySerializableObject = savestring.Deserialize();
        //}
    }
}
