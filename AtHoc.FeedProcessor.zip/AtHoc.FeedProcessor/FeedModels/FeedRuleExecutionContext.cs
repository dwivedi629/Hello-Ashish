﻿using AtHoc.FeedProcessor.Interface;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Events;
using System.Collections.Generic;
using System;
namespace AtHoc.FeedProcessor.FeedModels
{
    /// <summary>
    /// Object model for Feed Rule Execution Context
    /// </summary>
    public class FeedRuleExecutionContext
    {
        public IFeedData Event { get; set; }
        public IDictionary<string, CustomAttribute> AlertCustomAttribute { get; set; }
        public IFeedProcessorDataAccess ProcessorRepository { get; set; }
        public string SystemUrl { get; set; }
        public Dictionary<int, FeedExecutionStatus> RuleExecutionStatus { get; set; }

    }

    public class FeedExecutionStatus
    {       
        public int AlertId{get; set;}

        public int Feed_Queue_Id { get; set; }

        public int Rule_Id { get; set; }

        public bool Feed_Status { get; set; }

        public string ErrorMessage { get; set; }

        public DateTime CreatedDate { get; set; }
    }
}
