﻿using System;

namespace AtHoc.FeedProcessor.FeedModels
{
    public class FeedSource
    {
        public int Id { get; set; }
        public string Label { get; set; }      
        public string Type { get; set; }
        public int ProviderID { get; set; }
        public int GroupId { get; set; }
      
    }
}
