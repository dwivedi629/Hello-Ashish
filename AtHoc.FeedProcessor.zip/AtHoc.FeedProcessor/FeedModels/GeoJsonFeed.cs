﻿using AtHoc.FeedProcessor.Interface;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace AtHoc.FeedProcessor.FeedModels
{
    public class GeoJsonFeed
    {
        public List<object> context { get; set; }
        public string type { get; set; }
        public List<AlertEntry> features { get; set; }
        public string title { get; set; }
    }
    public class AlertEntry : IFeedData
    {
        public string id { get; set; }
        public string type { get; set; }
        public Geometry geometry { get; set; }
        public Alert properties { get; set; }

        public object GetData()
        {
            return this;
        }
    }
    public class Geometry
    {
        public string type { get; set; }
        public List<List<List<Double>>> coordinates { get; set; }
    }
    public class Alert
    {
        public string type { get; set; }
        public string id { get; set; }
        public string areaDesc { get; set; }
        public Geocode geocode { get; set; }
        public List<string> references { get; set; }
        public DateTime sent { get; set; }
        public DateTime effective { get; set; }
        public DateTime onset { get; set; }
        public DateTime expires { get; set; }
        public DateTime ends { get; set; }
        public string status { get; set; }
        public string messageType { get; set; }
        public string category { get; set; }
        public string severity { get; set; }
        public string certainty { get; set; }
        public string urgency { get; set; }
        
        [JsonProperty("event")]
        public string Event { get; set; }
        public string sender { get; set; }
        public string headline { get; set; }
        public string description { get; set; }
        public string instruction { get; set; }
        public string response { get; set; }
        public Parameters parameters { get; set; }
    }
    public class Geocode
    {
        public List<string> UGC { get; set; }
        public List<string> SAME { get; set; }
    }
    public class Parameters
    {
        public List<string> VTEC { get; set; }
        public List<string> EASORG { get; set; }
        public List<string> PIL { get; set; }
        public List<string> BLOCKCHANNEL { get; set; }
        public List<DateTime> eventEndingTime { get; set; }
    }
}
