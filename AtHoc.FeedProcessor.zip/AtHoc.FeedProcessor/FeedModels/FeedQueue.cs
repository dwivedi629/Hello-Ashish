﻿using System;

namespace AtHoc.FeedProcessor.FeedModels
{
    public class FeedQueue
    {
        public int Id { get; set; }

        public int FeedSourceId { get; set; }
        public string FeedItem { get; set; }


    }
}
