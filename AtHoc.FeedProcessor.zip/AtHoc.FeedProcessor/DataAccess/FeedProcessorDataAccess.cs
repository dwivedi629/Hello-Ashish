﻿using System.Linq;
using AtHoc.Data;
using AtHoc.Diagnostics;
using AtHoc.FeedProcessor.FeedModels;
using AtHoc.FeedProcessor.Interface;
using Microsoft.SqlServer.Server;
using RuleModel = AtHoc.IWS.Business.Domain.RuleModel;
using AtHoc.IWS.Business.Domain.RuleModel.Spec;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.Entities.Rule.Enum;
using AtHoc.FeedProcessor.FeedHandlers.GeoJson;
namespace AtHoc.FeedProcessor.DataAccess
{
    public class FeedProcessorDataAccess : IFeedProcessorDataAccess
    {
        #region Variables

        private static string _sysUrl = string.Empty;
        private readonly RuleModel.IRuleFacade _ruleFacade;
        private readonly ICustomAttributeFacade _customAttributeFacade;
        #endregion

        public FeedProcessorDataAccess(RuleModel.IRuleFacade ruleFacade, ICustomAttributeFacade customAttributeFacade)
        {
            _ruleFacade = ruleFacade;
            _customAttributeFacade = customAttributeFacade;
        }

        #region DB Queries
        private const string GetFeedSourcesQuery = @"SELECT source.ID, source.FEED_LABEL, source.FEED_TYPE, source.PROVIDER_ID, groupMap.GROUP_ID FROM FEED_SOURCE_TAB AS source WITH (nolock) 
                                                        INNER JOIN [FEED_SOURCE_GROUP_MAPPING_TAB] AS groupMap WITH (nolock) ON source.ID = groupMap.FEED_SOURCE_ID
                                                        WHERE ENABLED ='Y'";
        private const string GetScenarioDataQuery = @"SELECT bse.UPDATED_BY,scn.COMMON_NAME from ALT_SCENARIO_TAB scn WITH (NOLOCK) INNER JOIN ALT_BASE_TAB bse  WITH (NOLOCK) on scn.ALERT_ID=bse.ALERT_ID where scn.SCENARIO_ID = @ScenarioId";
        private const string UpdateQueueStatusQuery = @"UPDATE [dbo].[FEED_QUEUE_TAB] SET STATUS = @Status , UPDATED_ON = GETDATE() WHERE ID = @QueueId";
        private const string GetSystemUrlQuery = @"select URL from SYS_SYSTEM_TAB";
        private const string GetFeedExecutionStatusQuery = @"SELECT FEED_QUEUE_ID,RULE_ID FROM dbo.FEED_QUEUE_EXECUTION_STATUS_TAB WITH (NOLOCK)";
        

        private const string FeedExecutionDataTable = "FEED_QUEUE_EXECUTION_STATUS_TAB";

        #endregion

        public IList<FeedSource> GetFeedSources()
        {
            var feedSources = new List<FeedSource>();
            using (var connection = new NgadDatabase())
            {
                connection.CommandType = CommandType.Text;
                using (var reader = connection.ExecuteReader(GetFeedSourcesQuery))
                {
                    while (reader.Read())
                    {
                        var feedSource = new FeedSource();

                        feedSource.Id = reader.GetValue<int>("ID");
                        feedSource.Label = reader.GetValue<string>("FEED_LABEL");
                        feedSource.Type = reader.GetValue<string>("FEED_TYPE").ToUpper();
                        feedSource.ProviderID = reader.GetValue<int>("PROVIDER_ID");
                        feedSource.GroupId = reader.GetValue<int>("GROUP_ID");

                        feedSources.Add(feedSource);
                    }
                }

                return feedSources;
            }
        }

        public IList<FeedQueue> GetFeedData()
        {
            var feedProcessorData = new List<FeedQueue>();
            using (SqlDatabase connection = new NgadDatabase())
            {
                connection.CommandType = CommandType.StoredProcedure;

                using (SqlDataReader reader = connection.ExecuteReader("dbo.GET_FEED_DATA"))
                {
                    while (reader.Read())
                    {
                        var feedData = new FeedQueue();
                        try
                        {
                            feedData.Id = reader.GetValue<int>("ID");
                            feedData.FeedSourceId = reader.GetValue<int>("FEED_SOURCE_ID");
                            feedData.FeedItem = reader.GetValue<string>("FEED_ITEM");

                            feedProcessorData.Add(feedData);
                        }
                        catch (Exception ex)
                        {
                            EventLogger.WriteError("Exception occurred in FeedProcessor", ex);
                        }
                    }
                }

                return feedProcessorData;
            }
        }

        /// <summary>
        /// getting the scenario common name and updateby last
        /// </summary>
        /// <param name="scenarioId"></param>
        /// <returns></returns>
        public ScenarioDetailPayloadModel GetScenarioDetail(int scenarioId)
        {
            var scenarioDetail = new ScenarioDetailPayloadModel();
            using (SqlDatabase connection = new NgadDatabase())
            {
                connection.CommandType = CommandType.Text;
                var param = new SqlParameter() { ParameterName = "@ScenarioId", Value = scenarioId };
                connection.AddParameter(param);

                using (SqlDataReader reader = connection.ExecuteReader(GetScenarioDataQuery))
                {
                    while (reader.Read())
                    {
                        scenarioDetail.ScenarioCommonName = reader.GetValue<string>("COMMON_NAME");
                        scenarioDetail.ScenarioPublishedBy = reader.GetValue<int>("UPDATED_BY");
                    }

                }

                return scenarioDetail;
            }
        }

        public List<RuleModel.Rule> GetAllFeedRules(int providerId, bool loadRuleCriterias = true)
        {
            return _ruleFacade.GetFeedRules(new RuleSpec { ProviderId = providerId, LoadRuleCriterias = loadRuleCriterias }, FeedTypes.WAM,
                        RuleTypes.INCOMING_FEED_RULE_PROCESSING.ToString()).ToList();
        }

        public IDictionary<string, CustomAttribute> GetCustomAttributes(int providerId, string[] commonNames)
        {
            try
            {
                var attributeSet = _customAttributeFacade.GetCustomAttributesBySpec(
                            new CustomAttributeSpec
                            {
                                ProviderId = providerId,
                                CommonNames = commonNames
                            }).ToDictionary(a => a.CommonName);

                return attributeSet;
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("FeedProcessor => Error while getting rule attributes for ProviderID");
                return new Dictionary<string, CustomAttribute>();
            }
        }

        public void UpdateQueueStatus(int queueId, string status)
        {
            using (var connection = new NgadDatabase())
            {
                connection.AddParameter("QueueId", queueId);
                connection.AddParameter("Status", status);

                connection.CommandType = CommandType.Text;
                connection.ExecuteNonQuery(UpdateQueueStatusQuery);
            }
        }

        public string GetSystemUrl()
        {
            if (string.IsNullOrEmpty(_sysUrl))
            {
                using (SqlDatabase connection = new NgadDatabase())
                {
                    connection.CommandType = CommandType.Text;

                    using (SqlDataReader reader = connection.ExecuteReader(GetSystemUrlQuery))
                    {
                        while (reader.Read())
                        {
                            _sysUrl = reader.GetValue<string>("URL");
                        }
                    }
                }

            }
            return _sysUrl;

        }

        public void InsertFeedExecutionStatus(Dictionary<int, FeedExecutionStatus> ExecuteStatus, int FeedQueue_Id)
        {

            var table = new DataTable();

            using (var connection = new NgadDatabase())
            {
                var adapter = connection.ExecuteDataAdapter(string.Format("SELECT TOP 1 * FROM {0}", FeedExecutionDataTable));
                adapter.FillSchema(table, SchemaType.Mapped);

                foreach (var feedExecutionStatus in ExecuteStatus.Values)
                {

                    var row = table.NewRow();

                    row["ALERT_ID"] = feedExecutionStatus.AlertId;
                    row["FEED_QUEUE_ID"] = FeedQueue_Id;
                    row["RULE_ID"] = feedExecutionStatus.Rule_Id;
                    row["FEED_STATUS"] = (feedExecutionStatus.Feed_Status ? "DON" : "ERR");
                    row["ERROR_MESSAGE"] = feedExecutionStatus.ErrorMessage;
                    row["CREATED_ON"] = DateTime.Now;
                    table.Rows.Add(row);
                }

                connection.BulkCopyTimeout = 600;
                connection.BulkCopy(FeedExecutionDataTable, table);
            }


        }

        public IList<FeedExecutionStatus> GetFeedExecutionStatus()
        {
            var feedExecutionStatus = new List<FeedExecutionStatus>();
            
            using (var connection = new NgadDatabase())
            {
                connection.CommandType = CommandType.Text;                
                using (var reader = connection.ExecuteReader(GetFeedExecutionStatusQuery))
                {
                    while (reader.Read())
                    {
                        var feedExecution = new FeedExecutionStatus();

                        feedExecution.Feed_Queue_Id = reader.GetValue<int>("FEED_QUEUE_ID");
                        feedExecution.Rule_Id = reader.GetValue<int>("RULE_ID");


                        feedExecutionStatus.Add(feedExecution);
                    }
                }

                return feedExecutionStatus;
            }
        }
    }
}
