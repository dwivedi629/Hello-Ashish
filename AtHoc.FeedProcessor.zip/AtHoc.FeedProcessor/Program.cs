﻿using AtHoc.Infrastructure.Ioc;
using AtHoc.Infrastructure.Ioc.SimpleInjector;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Log.EventLog;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Ioc;

namespace AtHoc.FeedProcessor
{
    public class Program
    {
        public static void Main(string[] args)
        {
            LoadServiceLocator();

            var processor = new FeedProcessor();
            processor.StartFeeder();

            // Display the number of command line arguments:
            System.Console.WriteLine(args.Length);


        }

        private static void LoadServiceLocator()
        {
            if (ServiceLocator.Current != null) return;

            ServiceLocator.Current = new SimpleInjectorServiceLocator();
            ServiceLocator.Current.Register<ILogService, AtHocEventLogger>(ServiceLifecycle.Singleton);
            ServiceLocator.Current.Register<IRuntimeContext, ProxyRuntimeContext>(ServiceLifecycle.Singleton);
            ServiceLocator.Current.LoadAll();

            var serviceLoader = new AtHocServiceLoader();
            serviceLoader.Load(ServiceLocator.Current);
        }
    }
}
