﻿using AtHoc.FeedProcessor.FeedModels;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.RuleModel;
using System;
using System.ComponentModel;
using System.Linq;

namespace AtHoc.FeedProcessor.FeedHandlers.GeoJson
{
    /// <summary>
    /// Implementation of IRuleOperandProvider for WAM Feed information
    /// </summary>
    public class WamOperandProvider : IRuleOperandProvider
    {
        
        #region VARIABLES
        private const string ATTRIBUTE_EVENT_COUNTY = "WAM-COUNTY";
        private const string ATTRIBUTE_EVENT_SEARCH_KEYWORD = "WAM-SEARCH-KEYWORD";
        private const string ATTRIBUTE_EVENT_SEVERITY = "WAM-SEVERITY";
        private const string ATTRIBUTE_EVENT_TYPE = "WAM-EVENT-TYPE";
        private const string ATTRIBUTE_MESSAGE_TYPE = "WAM-MESSAGE-TYPE";

        #endregion


        /// <summary>
        /// Get Operand value (e.g. WAM County, Event Type, Severity)
        /// </summary>
        /// <typeparam name="T"> Type of Operand</typeparam>
        /// <param name="operandName">Name of Operand i.e. County, Type, Severity</param>
        /// <param name="executionContext">Execution Context i.e. FeedRuleExecutionContext</param>
        /// <returns></returns>
        public T GetOperandValue<T>(string operandName, object executionContext)
        {
            var feedRuleExecutionContext = (FeedRuleExecutionContext)executionContext;
            var eventFeed = (AlertEntry)feedRuleExecutionContext.Event.GetData();

            if (operandName == ATTRIBUTE_EVENT_COUNTY)
            {
                return (T)((object)string.Join(",", eventFeed.properties.geocode.SAME.Select(s => s).ToList()));
            }

            if (operandName == ATTRIBUTE_EVENT_SEARCH_KEYWORD)
            {
                return (T)((object)string.Concat(Convert.ToString(eventFeed.properties.Event), " ", eventFeed.properties.headline, " ", eventFeed.properties.description));
            }

            if (operandName == ATTRIBUTE_EVENT_SEVERITY)
            {
                return (T)((object)ParseAlertSeverity(eventFeed.properties.severity));
            }
            if (operandName == ATTRIBUTE_EVENT_TYPE)
            {
                return (T)((object)string.Concat(Convert.ToString(eventFeed.properties.Event), " ", eventFeed.properties.headline, " ", eventFeed.properties.description));
            }

            if (operandName == ATTRIBUTE_MESSAGE_TYPE)
            {
                return (T)((object)string.Concat(Convert.ToString(eventFeed.properties.Event), " ", eventFeed.properties.headline));
            }

            return default(T);
        }

        /// <summary>
        /// Get Operand Type of Given operand name 
        /// </summary>
        /// <param name="operandName">Operand Name e.g. Title</param>
        /// <param name="executionContext">Execution Context i.e. FeedRuleExecutionContext</param>
        /// <returns> CustomAttributeDataType e.g. String, Numeric, MultivalueList</returns>
        public CustomAttributeDataType? GetOperandType(string operandName, object executionContext)
        {
            var feedRuleExecutionContext = (FeedRuleExecutionContext)executionContext;
            var alertCustomAttributes = feedRuleExecutionContext.AlertCustomAttribute;
            CustomAttribute attribute;
            if (alertCustomAttributes.TryGetValue(operandName, out attribute))
            {
                return attribute.AttributeTypeId;
            }
            return null;
        }

        private string ParseAlertSeverity(string priority)
        {
            return Enum.Parse(typeof(Priority), priority).ToString();
        }

    }

    public enum Priority
    {
        [Description("Priority_Extreme")]
        Extreme,
        [Description("Priority_Severe")]
        Severe,
        [Description("Priority_Moderate")]
        Moderate,
        [Description("Priority_Minor")]
        Minor,
        [Description("Priority_Unknown")]
        Unknown
    }

}
