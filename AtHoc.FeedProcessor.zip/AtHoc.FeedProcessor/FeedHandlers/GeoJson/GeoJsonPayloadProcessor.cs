﻿using AtHoc.Diagnostics;
using AtHoc.FeedProcessor.FeedModels;
using AtHoc.FeedProcessor.Interface;
using AtHoc.IWS.Business.Domain.RuleModel;
using AtHoc.IWS.SSA.Business.Dictionaries;
using AtHoc.IWS.SSA.Business.Facades;
using AtHoc.IWS.SSA.Dictionaries;
using System;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using AtHoc.Publishing;
using System.Linq;
using AtHoc.IWS.Map;
using AtHoc.Infrastructure.Ioc;
using AtHoc.IWS.Business.Domain.Map;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Business.Domain.Users.Impl.Search;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Context;
using AtHoc.Devices;

namespace AtHoc.FeedProcessor.FeedHandlers.GeoJson
{
    public class GeoJsonPayloadProcessor : IRuleActionExecutor
    {
        private const string WAMHeadLinePlaceHolder = @"$FeedHeadline$";
        private const string WAMEventPlaceHolder = @"$FeedEvent$";
        private const string WAMDescPlaceHolder = @"$FeedDescription$";
        private const string WAMInstructionPlaceHolder = @"$FeedInstruction$";
        private const string WAMEffectivePlaceHolder = @"$FeedEffective$";
        private const string WAMExpiresPlaceHolder = @"$FeedExpires$";
        private const string WAMSenderPlaceHolder = @"$FeedSenderName$";
        public bool ExecuteAction(Rule matchedRule, RuleAction action, object runtimeContext)
        {

            object objectScenario;
            int scenarioId = 0;
            object objectIsGeo;
            int alertId = 0;
            int feedQueueId = 0;
            bool isActionExecuted = false;
            ScenarioDetailPayloadModel scenarioDetail = null;
            IFeedProcessorDataAccess processorRepository = null;
            string message = string.Empty;
            FeedRuleExecutionContext feedRuleExecutionContext = null;
            FeedExecutionStatus feedExecutionStatus = null;

            try
            {
                feedRuleExecutionContext = (FeedRuleExecutionContext)runtimeContext;
                if (feedRuleExecutionContext == null || feedRuleExecutionContext.Event == null)
                {
                    EventLogger.WriteError(String.Format("ExecuteAction=>feedRuleExecutionContext object is null."));
                    return false;
                }

                //Try to get Scenario Id from ActionValue object.
                if (action.ActionValues.TryGetValue(RuleAction.RuleActionParameterKeys.SCENARIO_ID, out objectScenario))
                {
                    //Parse scenarioId - make sure it is valid integer. Log error if not valid integer.
                    if (!int.TryParse(objectScenario.ToString(), out scenarioId))
                    {
                        EventLogger.WriteWarning(string.Format("Unable to parse ScenarioId for Rule Action - Rule Name =>{0}", matchedRule.Name));
                        scenarioId = 0;
                    }
                }

                //Try to get GEOENABLED flag
                if (action.ActionValues.TryGetValue(RuleAction.RuleActionParameterKeys.GEOENABLED, out objectIsGeo))
                {
                    if (String.IsNullOrEmpty(objectIsGeo.ToString()))
                    {
                        EventLogger.WriteWarning(string.Format("Unable to parse GEOENABLED for Rule Action - Rule Name =>{0}", matchedRule.Name));
                        matchedRule.GeoEnabled = "N";
                    }
                    else
                        matchedRule.GeoEnabled = objectIsGeo.ToString();
                }

                processorRepository = feedRuleExecutionContext.ProcessorRepository;
                //Try to get Scenario Detail;
                if (processorRepository != null)
                {
                    scenarioDetail = processorRepository.GetScenarioDetail(scenarioId);
                }

                //Getting the feed data
                var jsonData = feedRuleExecutionContext.Event.GetData() as AlertEntry;


                //Posting the payload to publish the alert
                alertId = this.PublishAlert(matchedRule, scenarioDetail, jsonData);

                if (alertId > 0)
                    isActionExecuted = true;

                //logging the error message if any during publish 
                if (!isActionExecuted)
                {
                    message = String.Format("Could not send an alert for Rule Id {0}", matchedRule.Id);
                    EventLogger.WriteError(message);
                }
            }
            catch (Exception ex)
            {
                message = String.Format("Could not send an alert for Rule Id {0}" + " " + ex, matchedRule.Id);
                EventLogger.WriteError(message);
                isActionExecuted = false;
            }

            if (feedRuleExecutionContext != null)
            {
                feedExecutionStatus = new FeedExecutionStatus() { Rule_Id = matchedRule.Id, AlertId = alertId, ErrorMessage = message, Feed_Queue_Id = 0, Feed_Status = isActionExecuted, CreatedDate = DateTime.Now };


                if (!feedRuleExecutionContext.RuleExecutionStatus.ContainsKey(matchedRule.Id))
                {
                    feedRuleExecutionContext.RuleExecutionStatus.Add(matchedRule.Id, feedExecutionStatus);
                }
                else
                {
                    feedRuleExecutionContext.RuleExecutionStatus[matchedRule.Id] = feedExecutionStatus;
                }
            }
            return isActionExecuted;
        }

        /// <summary>
        /// constructing location data
        /// </summary>
        /// <param name="jsonData"></param>
        /// <returns></returns>
        private JObject GetLocationData(AlertEntry jsonData, int objectId = 0)
        {
            var alert = JObject.FromObject(jsonData);
            var geoLocation = new JObject();
            var features = new JArray();
            var feature = new JObject
            {
                {"geometry", alert["geometry"]},
                {"type", alert["type"]},
                {"properties",objectId==0
                    ? JValue.Parse("{\"status\":\"add\",\"color\":{\"r\":0,\"g\":255,\"b\":255,\"a\":0.45},\"border\":{\"b\":255,\"g\":255,\"r\":0,\"a\":1},\"TEMPKEY\":0}")
                    : JValue.Parse("{\"status\":\"add\",\"color\":{\"r\":0,\"g\":255,\"b\":255,\"a\":0.45},\"border\":{\"b\":255,\"g\":255,\"r\":0,\"a\":1},\"OBJECTID\":\""+objectId+"\",\"TEMPKEY\":0}")}
            };
            geoLocation.Add("type", "FeatureCollection");
            geoLocation.Add("features", features);
            features.Add(feature);
            return geoLocation;
        }

        /// <summary>
        /// Publishes alert
        /// </summary>
        /// <param name="liveEvent"></param>
        /// <param name="timeIntervalToIgnoreDuplicate"></param>
        private int PublishAlert(Rule matchedRule, ScenarioDetailPayloadModel scenarioDetail, AlertEntry jsonData)
        {
            int alertId = 0;
            var scnearioManager = new ScenarioManager(matchedRule.ProviderId, 1);
            var scenario = scnearioManager.GetScenario(scenarioDetail.ScenarioCommonName);
            var userFacade = ServiceLocator.Resolve<IUserFacade>();


            //create alert from scenario
            var alertManager = new AlertManager(matchedRule.ProviderId, scenario.UpdatedBy);
            var alert = alertManager.CreateAlertFromScenario(scenario.ScenarioId);

            //use event id as alert AUID id
            if (alert == null)
            {
                return alertId;
            }
            //Get the WAM Attributes
            var WAMAttribute = WAMAttributes(jsonData);

            //Set the Alert Header          
            alert.AlertSpec.Content.Header = ReplaceWAMPlaceholderInText(alert.AlertSpec.Content.Header, jsonData, WAMAttribute);
            alert.AlertSpec.Content.Header.Truncate(100);

            //Set the alert Body           
            alert.AlertSpec.Content.Body = ReplaceWAMPlaceholderInText(alert.AlertSpec.Content.Body, jsonData, WAMAttribute);
            alert.AlertSpec.Content.Body.Truncate(4000);
            alert.Auid = Guid.NewGuid().ToString();
            //If GeoEnabled=="N" - the map and geo targeting settings of the original alert template would be used in the triggered alert.
            if (matchedRule.GeoEnabled == "Y")
            {

                //Getting the location data(geoJSON) to set the OBJECTID
                var geoLocation = jsonData.geometry != null ? this.GetLocationData(jsonData).ToString() : "";

                //check for the geolocation null
                if (!string.IsNullOrWhiteSpace(geoLocation))
                {
                    //Get the object ID based on the coordinate and set in the existing geoJson
                    var objectId = this.GetObjectID(matchedRule.ProviderId, geoLocation);
                    geoLocation = this.GetLocationData(jsonData, objectId).ToString();
                }

                //setthe final geoLocation data to the alert content
                alert.AlertSpec.Content.Location = geoLocation;

                //Get the Attachment id for Geo data
                var geoAttachmentId = SetGeoJson(alert, geoLocation, matchedRule.ProviderId);

                //Setting the Targeting critera for Geo Data
                if (alert.AlertSpec.Targeting.TargetUsersByArea)
                {
                    foreach (var criteria in alert.AlertSpec.Targeting.TargetingCriteria.ToList())
                    {
                        if (criteria.NodeType == SearchNodeType.Geo || criteria.NodeType == SearchNodeType.OrgGeo)
                        {
                            alert.AlertSpec.Targeting.TargetingCriteria.Remove(criteria);
                        }
                    }
                }

                if (alert.AlertSpec.Targeting.TargetOrganizationsByArea)
                {
                    int deviceId = GetConnectDevice();
                    var fc = new FeatureCollection(geoLocation);
                    var numOfPolygon = 0;
                    if (fc.Features != null || fc.Features.Count > 0)
                    {
                        var geoCriteriaList = new List<GeoCriteria>();

                        foreach (var f in fc.Features)
                        {
                            if (f.Geometry.Type == IWS.Map.Geometry.Type.Polygon || f.Geometry.Type == IWS.Map.Geometry.Type.MultiPolygon)
                            {
                                numOfPolygon++;
                                geoCriteriaList.Add(new GeoCriteria(0, CriteriaOperator.IsInsideArea, f.Attributes["OBJECTID"].ToString()));
                            }
                        }

                        if (numOfPolygon > 0)
                        {
                            var srchArgs = new UserSearchArgs(false, true, true)
                            {
                                ProviderId = matchedRule.ProviderId,
                                ProviderCriteria = UserSearchHelper.GetProviderCriteria(matchedRule.ProviderId),
                                OperatorCriteria = UserSearchHelper.GetOperatorUserBaseCriteria(0, matchedRule.ProviderId)
                            };

                            var userOperatorCriteria = UserSearchHelper.GetUserOperatorCriteria(false);

                            var statusAttributeId = userFacade.GetStatusAttributeId();
                            var statusValueIds = userFacade.GetStatusValueIds(new[] { "VLD" });
                            var statusCriteria = UserSearchHelper.GetUserStatusCriteria(statusAttributeId, statusValueIds);

                            var customCriteria = UserSearchHelper.GetCustomCriteria(new[] {new List<GenericCriteria>
                                                        {
                                                            new DeviceCriteria(deviceId, CriteriaOperator.IsNotEmpty, 0)
                                                        }});

                            var geoCriteria = UserSearchHelper.GetIncludeGeographyCriteria(geoCriteriaList, matchedRule.ProviderId);

                            srchArgs.TargetCriteria = customCriteria & geoCriteria & userOperatorCriteria & statusCriteria;
                            var geoSearchedOrgs = userFacade.SearchUsersByContext(srchArgs);
                            if(geoSearchedOrgs.Users.Any() && geoSearchedOrgs.Users.Count > 0)
                            {
                                var searchCreteria = alert.AlertSpec.Targeting.TargetingCriteria.Where(x => x.NodeType == SearchNodeType.OrgUser).ToArray();
                                foreach (var item in searchCreteria)
                                {
                                    alert.AlertSpec.Targeting.TargetingCriteria.Remove(item);
                                }
                            }
                            foreach (var org in geoSearchedOrgs.Users)
                            {
                                alert.AlertSpec.Targeting.TargetingCriteria.Add(new SearchCriteria
                                {
                                    IsBlocked = false,
                                    NodeType = SearchNodeType.OrgUser,
                                    SearchCriteriaID = org.Id
                                });
                            }
                        }
                    }
                }
            }

            alert.IsReadyForPublish = true;
            alertManager.PublishAlertWithoutValidation(alert);
            alertId = alert.AlertId;
            return alertId;
        }

        private int GetConnectDevice()
        {
            int deviceId=0;
            var deviceManager = new Devices.DeviceManager(0);
            var device = deviceManager.GetDevice("UAP-IAC");
            if (device != null)
            {
                deviceId = device.Id;
            }
            return deviceId;
        }
        internal void SetTargetOrgByAreaCriteria(AlertBase alertBase)
        {
            var areaAttachment = alertBase.AlertSpec.Advanced.GetAttachments().FirstOrDefault(a => a.AttachmentType.Equals(AttachmentType.Spatial) &&
                                                                                                   a.AttachmentSubType.Equals(AttachmentSubType.Location));
            if (areaAttachment == null) return;

            if (alertBase.AlertSpec.Targeting.TargetingCriteria == null)
                alertBase.AlertSpec.Targeting.TargetingCriteria = new List<ISearchCriteria>();
            alertBase.AlertSpec.Targeting.TargetingCriteria.Add(new SearchCriteria { NodeType = SearchNodeType.OrgGeo, IsBlocked = false, SearchCriteriaID = areaAttachment.AttachmentId });
        }

        /// <summary>
        /// Get the Object ID for the Geo Json
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="geoJson"></param>
        /// <returns></returns>
        private int GetObjectID(int providerId, string geoJson)
        {
            var spatialId = 0;
            var _apFacade = ServiceLocator.Resolve<IMapFacade>();
            var featureCollection = new FeatureCollection(geoJson);

            if (featureCollection.Features == null || featureCollection.Features.Count == 0)
            {
                return 0;
            }
            foreach (var feature in featureCollection.Features)
            {
                var wkt = feature.Geometry.Wkt;
                if (string.IsNullOrEmpty(wkt) || !feature.Attributes.ContainsKey("TEMPKEY"))
                {
                    continue;
                }

                if (feature.Attributes.ContainsKey("OBJECTID"))
                {
                    spatialId = Convert.ToInt32(feature.Attributes["OBJECTID"]);
                    _apFacade.CreateShapeInSharedLayer(providerId, wkt, spatialId);
                }
                else
                {
                    spatialId = _apFacade.CreateShapeInSharedLayer(providerId, wkt, 0);
                }
            }
            return spatialId;
        }

        /// <summary>
        /// Setting the GeoJson data
        /// </summary>
        /// <param name="alertBase"></param>
        /// <param name="geoJson"></param>
        /// <param name="providerId"></param>
        /// <param name="operatorId"></param>
        /// <returns></returns>
        private int SetGeoJson(AlertBase alertBase, string geoJson, int providerId, int operatorId = 0)
        {
            //remove existing geojson from the alert created from scenario
            var attachments = alertBase.AlertSpec.Advanced.GetAttachments(AttachmentType.Spatial);

            foreach (var attachment in attachments.ToList())
            {
                alertBase.AlertSpec.Advanced.RemoveAttachments(attachment.AttachmentType, attachment.AttachmentId, AttachmentSubType.Location);
            }
            var mapMgr = ManagerFactory.Instance.CreateMapManager();
            mapMgr.ProviderId = providerId;
            mapMgr.OperatorId = operatorId;

            // geolocation
            AtHoc.IWS.SSA.Business.MapLayer mapLayer;
            // create new map layer to save GeoJson
            mapLayer = new AtHoc.IWS.SSA.Business.MapLayer
            {
                ProviderId = providerId,
                UpdatedBy = operatorId,
                LayerName = alertBase.AlertSpec.Content.Header,  //!string.IsNullOrEmpty(model.Content.Title) ? model.Content.Title : model.EntityId.ToString(),
                Type = MapLayerSourceType.AlertResponse,
                IsTemp = false,
                IsReadOnly = true,
                VisibilityLevel = (int)VisibilityLevelType.Alerting,
                GeoJson = geoJson
            };

            // create or update the MapLayer 
            mapMgr.SaveMapLayers(new List<AtHoc.IWS.SSA.Business.MapLayer>() { mapLayer });

            // add attachment to alert spec    
            if (mapLayer.MapLayerId > 0)
            {
                alertBase.AlertSpec.Advanced.AddAttachment(new AlertAttachment(AttachmentType.Spatial, mapLayer.MapLayerId, AttachmentSubType.Location));
            }

            return mapLayer.MapLayerId;
        }


        private List<KeyValuePair<string, string>> WAMAttributes(AlertEntry jsonData)
        {
            var WAMAttributes = new List<KeyValuePair<string, string>>();
            WAMAttributes.Add(new KeyValuePair<string, string>(WAMHeadLinePlaceHolder, jsonData.properties.headline));
            WAMAttributes.Add(new KeyValuePair<string, string>(WAMEventPlaceHolder, jsonData.properties.Event));
            WAMAttributes.Add(new KeyValuePair<string, string>(WAMDescPlaceHolder, jsonData.properties.description));
            WAMAttributes.Add(new KeyValuePair<string, string>(WAMInstructionPlaceHolder, jsonData.properties.instruction));
            WAMAttributes.Add(new KeyValuePair<string, string>(WAMEffectivePlaceHolder, jsonData.properties.effective.ToString()));
            WAMAttributes.Add(new KeyValuePair<string, string>(WAMExpiresPlaceHolder, jsonData.properties.expires.ToString()));
            WAMAttributes.Add(new KeyValuePair<string, string>(WAMSenderPlaceHolder, jsonData.properties.sender));

            return WAMAttributes;

        }

        private static string ReplaceWAMPlaceholderInText(string text, AlertEntry jsonData, List<KeyValuePair<string, string>> WAMAttributes)
        {
            //Replace with WAM custom placeholder
            foreach (var placeholder in WAMAttributes)
            {
                var key = placeholder.Key;

                if (!text.Contains(key)) continue;
                text = text.Replace(key, placeholder.Value ?? string.Empty);
            }
            return text;
        }
    }

    /// <summary>
    /// Implementation of IRuleExecutionProvider for Event
    /// Add list of action and associated executor in dictionary 
    /// </summary>
    public class GeoJsonExecutionProvider : IRuleExecutionProvider
    {
        /// <summary>
        /// Get Action action for Event. i.e. PublishAlertByScenario or Delegate Responses
        /// </summary>
        /// <returns></returns>
        public IDictionary<AtHoc.IWS.Business.Domain.Entities.Rule.Enum.ActionType, IRuleActionExecutor> GetRuleActionExecutionSet()
        {
            var dictionaryRuleActionExecutionSet = new Dictionary<AtHoc.IWS.Business.Domain.Entities.Rule.Enum.ActionType, IRuleActionExecutor>();
            dictionaryRuleActionExecutionSet.Add(AtHoc.IWS.Business.Domain.Entities.Rule.Enum.ActionType.ExecuteScenario, new GeoJsonPayloadProcessor());

            return dictionaryRuleActionExecutionSet;
        }
    }
    public static class stringExtention
    {
        public static string Truncate(this string value, int maxChars)
        {
            return (!string.IsNullOrWhiteSpace(value) ? (value.Length <= maxChars ? value : value.Substring(0, maxChars)) : "");
        }
    }

    public class ScenarioDetailPayloadModel
    {
        public string ScenarioCommonName { get; set; }
        public int ScenarioPublishedBy { get; set; }
    }
}
