﻿using AtHoc.Diagnostics;
using AtHoc.FeedProcessor.FeedHandlers.GeoJson;
using AtHoc.FeedProcessor.FeedModels;
using AtHoc.FeedProcessor.Interface;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.RuleModel;
using AtHoc.IWS.Business.Domain.RuleProcessor;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;

namespace AtHoc.FeedProcessor.FeedHandlers
{
    public class GeoJsonHandler : IFeedHandler
    {
        private readonly IRuleProcessor _ruleProcessor;
        private readonly IFeedProcessorDataAccess _processorRepository;
        public IRuleExecutionProvider EventRuleExecutionProvider { get; set; }


        public GeoJsonHandler(IFeedProcessorDataAccess processorRepository, IRuleProcessor ruleProcessor)
        {
            _processorRepository = processorRepository;
            _ruleProcessor = ruleProcessor;
            //should This be dependency injected, as it is specific to Geo json only
            EventRuleExecutionProvider = new GeoJsonExecutionProvider();
        }

        public string HandlerKey
        {
            get { return "GEOJSON"; }
        }


        /// <summary>
        /// Start processing Rules by first match it and then execute
        /// </summary>
        /// <param name="queue"></param>
        /// <param name="feedSource"></param>
        /// <param name="rules"></param>
        /// <returns></returns>
        public bool StartProcessing(FeedQueue queue, FeedSource feedSource, List<Rule> rules)
        {
            bool success = true;
            try
            {
                var ruleSet = GetRuleSets(rules);

                //Get the Custom Attribute of EntityType Rule Alert 
                var customAttributes = GetCustomAttributes(feedSource.ProviderID);

                //TO-DO - Need to remove hardcoded dependency. This should be feed source driven
                //This should be dependency injected
                IRuleOperandProvider operandProvider = new WamOperandProvider();


                //If no attributes found for provider,then metadata is not availble. Make sure PRV_ATTRIBUTE_TAB is populate with required attribute for provider
                if (customAttributes.Count == 0)
                {
                    EventLogger.WriteError(string.Format("No Custom Attribute found for Provider Id - {0} - Atribute CommonNames are [ALERT-TITLE,ALERT-BODY,ALERT-SEVERITY,ALERT-TYPE,ALERT-SOURCE-ORGANIZATION].", 0));
                    return false;
                }

                var settings = new JsonSerializerSettings
                {
                    NullValueHandling = NullValueHandling.Ignore,
                    MissingMemberHandling = MissingMemberHandling.Ignore,
                };

                //Set the Execution Context.
                var eventExecutionContext = new FeedRuleExecutionContext
                {
                    Event = JsonConvert.DeserializeObject<AlertEntry>(queue.FeedItem, settings),
                    AlertCustomAttribute = customAttributes,
                    ProcessorRepository = _processorRepository,
                    SystemUrl = _processorRepository.GetSystemUrl(),
                    RuleExecutionStatus = new Dictionary<int, FeedExecutionStatus>()

                };

                List<Rule> matchingRules;

                _ruleProcessor.Init(ruleSet, operandProvider, EventRuleExecutionProvider);

                //Execute the Rule based upon execution context. Here Execution Context is FeedRuleExecutionContext.
                success = _ruleProcessor.Execute(eventExecutionContext, out matchingRules);


                if (eventExecutionContext.RuleExecutionStatus.Count > 0 && (eventExecutionContext.RuleExecutionStatus.Where(w => w.Value.Feed_Status == false).Any()))
                    success = false;
                if (!success)
                {
                    EventLogger.WriteError(string.Format("GeoJsonHandler => Unable to Evaluate Rules - {0}. ProviderId {1}", string.Join(",", ruleSet.Select(a => a.Name).ToArray()), 0));
                }
               
                // Insert Feed History records
                if (eventExecutionContext.RuleExecutionStatus != null && eventExecutionContext.RuleExecutionStatus.Count>0)
                {                  
                    _processorRepository.InsertFeedExecutionStatus(eventExecutionContext.RuleExecutionStatus, queue.Id);
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("GeoJsonHandler => Unable to Evaluate Rules -"), ex);
                return false;
            }

            return success;
        }

        /// <summary>
        /// Return the sender name. in this case it will be sender organization .
        /// </summary>
        /// <param name="ruleSet"></param>
        /// <returns>List of Rule from Cache.</returns>
        private List<Rule> GetRuleSets(List<Rule> ruleSet)
        {
            try
            {
               
                foreach (var ruleCriteria in from rule in ruleSet from ruleCriteria in rule.Criterias where ruleCriteria.AttributeName == "WAM-COUNTY" select ruleCriteria)
                {
                    var counties = ruleCriteria.AttributeValue.Select(s => s.Split(',')).FirstOrDefault();
                    if (counties != null)
                    {
                        //TO-DO - If FIPS code is 5 digit then only add 0 before value.
                        ruleCriteria.AttributeValue = counties.Select(x => x.Split('-')).Select(x => GetCode(x[2])).ToList();
                    }
                }

                return ruleSet;
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("GeoJsonHandler => Error while getting Rules for ProviderID", ex);
                return new List<Rule>();
            }

        }

        private string GetCode(string code)
        {
            if (code != "")
            {
                for (int i = 0; i < 6 - code.Length; i++)
                {
                    code = "0" + code;
                }
            }
            return code;
        }

        private IDictionary<string, CustomAttribute> GetCustomAttributes(int providerId)
        {
            return _processorRepository.GetCustomAttributes(providerId,
                new[] { "WAM-COUNTY", "WAM-SEARCH-KEYWORD", "WAM-EVENT-TYPE", "WAM-SEVERITY","WAM-MESSAGE-TYPE" });
        }

    }




}
