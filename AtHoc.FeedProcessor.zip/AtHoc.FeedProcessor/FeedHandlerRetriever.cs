﻿using AtHoc.FeedProcessor.DataAccess;
using AtHoc.FeedProcessor.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using AtHoc.IWS.Business.Domain.RuleProcessor;

namespace AtHoc.FeedProcessor
{
    public static class FeedHandlerRetriever
    {
        public static IEnumerable<IFeedHandler> GetFeedHandlers(IFeedProcessorDataAccess feedProcessor)
        {
            var feedHandlers = Assembly.GetExecutingAssembly().GetExportedTypes().Where(
                                t => typeof(IFeedHandler).IsAssignableFrom(t) && t.IsClass)
                                .Select(x => Activator.CreateInstance(x, feedProcessor, new RuleProcessor()))
                                .Cast<IFeedHandler>();

            return feedHandlers;
        }
    }
}
