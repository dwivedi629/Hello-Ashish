﻿using AtHoc.FeedProcessor.FeedHandlers.GeoJson;
using AtHoc.FeedProcessor.FeedModels;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.RuleModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.FeedProcessor.Interface
{
    public interface IFeedProcessorDataAccess
    {
        string GetSystemUrl();
        IList<FeedQueue> GetFeedData();
        IList<FeedSource> GetFeedSources();
        List<Rule> GetAllFeedRules(int providerId, bool loadRuleCriterias = true);
        IDictionary<string, CustomAttribute> GetCustomAttributes(int providerId, string[] commonNames);
        void UpdateQueueStatus(int queueId, string status);
        ScenarioDetailPayloadModel GetScenarioDetail(int scenarioId);

        void InsertFeedExecutionStatus(Dictionary<int, FeedExecutionStatus> feedExecutionStatus, int FeedQueue_Id);

        IList<FeedExecutionStatus> GetFeedExecutionStatus();
        
    }
}