﻿
namespace AtHoc.FeedProcessor.Interface
{
    public interface IFeedData
    {
        object GetData();
    }
}
