﻿using AtHoc.FeedProcessor.FeedModels;
using AtHoc.IWS.Business.Domain.RuleModel;
using System.Collections.Generic;

namespace AtHoc.FeedProcessor.Interface
{
    public interface IFeedHandler
    {
        string HandlerKey { get; }
        bool StartProcessing(FeedQueue queue, FeedSource feedSource, List<Rule> rules);

    }
}
