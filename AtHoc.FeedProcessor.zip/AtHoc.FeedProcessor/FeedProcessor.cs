﻿using System.Collections.ObjectModel;
using System.Threading.Tasks;
using AtHoc.Diagnostics;
using AtHoc.FeedProcessor.DataAccess;
using AtHoc.FeedProcessor.FeedModels;
using AtHoc.FeedProcessor.Interface;
using AtHoc.Infrastructure.Ioc;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.RuleModel;
using AtHoc.IWS.Business.Domain.RuleProcessor;
using System;
using System.Collections.Generic;
using System.Linq;

namespace AtHoc.FeedProcessor
{
    public class FeedProcessor
    {
        private IEnumerable<FeedQueue> _feedData;
        private IEnumerable<FeedSource> _feedSources;
        private IList<FeedExecutionStatus> _feedExecutionStatusData;
        private IEnumerable<IFeedHandler> _feedHandlers;
        private readonly IFeedProcessorDataAccess _processorRepository;
        private readonly IDictionary<int, List<Rule>> _rulesDictionary;
        
        public FeedProcessor()
        {
            var ruleFacade = ServiceLocator.Resolve<IRuleFacade>();
            var customAttributeFacade = ServiceLocator.Resolve<ICustomAttributeFacade>();
            _processorRepository = new FeedProcessorDataAccess(ruleFacade, customAttributeFacade);
                
            _rulesDictionary = new Dictionary<int, List<Rule>>();
        }

        public FeedProcessor(IFeedProcessorDataAccess processorRepository)
        {
            _processorRepository = processorRepository;
            _rulesDictionary = new Dictionary<int, List<Rule>>();
        }

        public void StartFeeder()
        {
            try
            {
                _feedSources = _processorRepository.GetFeedSources();

                if (_feedSources != null && _feedSources.Any())
                {
                    //To get the Feed Data for Feed processing
                    _feedData = _processorRepository.GetFeedData();

                    //To get feed execution status data w.r.t queueId
                    _feedExecutionStatusData = _processorRepository.GetFeedExecutionStatus().ToList();

                    if (_feedData != null && _feedData.Any())
                    {

                        _feedHandlers = GetFeedHandlers();

                        foreach (var sourceId in _feedData.Select(s => s.FeedSourceId).Distinct())
                        {
                            var source = _feedSources.FirstOrDefault(w => w.Id == sourceId);
                            if (source != null)
                            {
                                if (!_rulesDictionary.ContainsKey(source.ProviderID))
                                {
                                    _rulesDictionary.Add(source.ProviderID,
                                        _processorRepository.GetAllFeedRules(source.ProviderID));
                                }
                            }
                        }

                        //Process records parallely
                        Parallel.ForEach(_feedData, StartProcessing);

                    }
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Exception occurred in FeedProcessor", ex);
            }
        }

        protected virtual IEnumerable<IFeedHandler> GetFeedHandlers()
        {
            return FeedHandlerRetriever.GetFeedHandlers(_processorRepository);
        }

        /// <summary>
        /// Finds the appropriate feed handler for the input feed source type and initiates the processing.
        /// </summary>
        private void StartProcessing(FeedQueue queue)
        {
            var isQueueProcessed = false;
           
            try
            {
                var feedSource = _feedSources.FirstOrDefault(w => w.Id == queue.FeedSourceId);
                if (feedSource != null)
                {
                    var feedHandler = _feedHandlers.FirstOrDefault(x => x.HandlerKey.Equals(feedSource.Type));
                    if (feedHandler != null)
                    {
                        var rules = _rulesDictionary.ContainsKey(feedSource.ProviderID) ? _rulesDictionary[feedSource.ProviderID] : _processorRepository.GetAllFeedRules(feedSource.ProviderID);
                        
                        if (rules != null && rules.Any())
                        {
                            var myRules = rules.Where(w => w.GroupId == feedSource.GroupId).Select(s => new Rule(s)).ToList();
                                                   

                            if (myRules.Any())
                            {
                                //What ever rules not exist in Feed Execution status table that rules we are filtering and sending it for Feed Processing
                                if (_feedExecutionStatusData.Count > 0)
                                {
                                    myRules = myRules.Where(x => !_feedExecutionStatusData.Any(y => y.Feed_Queue_Id == queue.Id && y.Rule_Id == x.Id)).ToList();
                                }
                                //If any rules are there then only we need to process the feed.
                                if (myRules.Any())
                                {
                                    //Start processing queue
                                    var status = feedHandler.StartProcessing(queue, feedSource, myRules.ToList());

                                    _processorRepository.UpdateQueueStatus(queue.Id, status ? "DON" : "ERR");
                                    isQueueProcessed = true;
                                }
                            }
                        }
                    }
                }
                if (!isQueueProcessed)
                {
                    _processorRepository.UpdateQueueStatus(queue.Id, "DON");
                }
            }
            catch (Exception ex)
            {
                _processorRepository.UpdateQueueStatus(queue.Id, "ERR");
                EventLogger.WriteError("Exception occurred in FeedProcessor", ex);
            }
        }


    }
}
