import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: '<h1>Hello test1123</h1>',
})
export class AppComponent  {  }
