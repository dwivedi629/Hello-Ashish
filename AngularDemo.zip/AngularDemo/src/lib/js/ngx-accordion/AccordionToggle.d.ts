import { AccordionGroup } from "./AccordionGroup";
export declare class AccordionToggle {
    private accordionGroup;
    constructor(accordionGroup: AccordionGroup);
    onClick(): void;
}
