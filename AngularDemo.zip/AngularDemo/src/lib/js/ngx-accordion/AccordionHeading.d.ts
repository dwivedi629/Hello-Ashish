export declare class AccordionHeading {
}
