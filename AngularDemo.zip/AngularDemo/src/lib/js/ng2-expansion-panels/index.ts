export { ExpansionPanelsModule } from './dist/modules/ng2-expansion-panels.module';
