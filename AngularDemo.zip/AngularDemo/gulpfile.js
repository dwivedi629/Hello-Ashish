﻿
/*
This file is the main entry point for defining Gulp tasks and using Gulp plugins.
Click here to learn more. https://go.microsoft.com/fwlink/?LinkId=518007
*/

var gulp = require('gulp'),
    flatten = require('gulp-flatten'),
    del = require("del");
sass = require('gulp-sass');
var webroot = "./src/";

gulp.task("Lib", function () {

    var files;

    // systemjs
    files = [
        "./node_modules/core-js/client/shim.min.js",
        "./node_modules/core-js/client/shim.min.js.map",
        "./node_modules/zone.js/dist/zone.js",
        "./node_modules/reflect-metadata/Reflect.js",
        "./node_modules/reflect-metadata/Reflect.js.map",
        "./node_modules/systemjs/dist/system.src.js"
    ];
    gulp.src(files, { base: "." })
        .pipe(flatten())
        .pipe(gulp.dest(webroot + "lib/js/systemjs"));

    // angular & material
    files = [
        "./node_modules/@angular/animations/bundles/animations.umd.js?(.map)",
        "./node_modules/@angular/animations/bundles/animations-browser.umd.js?(.map)",
        "./node_modules/@angular/core/bundles/core.umd.js?(.map)",
        "./node_modules/@angular/common/bundles/common.umd.js?(.map)",
        "./node_modules/@angular/compiler/bundles/compiler.umd.js?(.map)",
        "./node_modules/@angular/cdk/bundles/cdk.umd.js?(.map)",
        "./node_modules/@angular/platform-browser/bundles/platform-browser.umd.js?(.map)",
        "./node_modules/@angular/platform-browser/bundles/platform-browser-animations.umd.js?(.map)",
        "./node_modules/@angular/platform-browser-dynamic/bundles/platform-browser-dynamic.umd.js?(.map)",
        "./node_modules/@angular/http/bundles/http.umd.js?(.map)",
        "./node_modules/@angular/router/bundles/router.umd.js?(.map)",
        "./node_modules/@angular/forms/bundles/forms.umd.js?(.map)",
        "./node_modules/@angular/material/bundles/material.umd.js?(.map)",
        "./node_modules/@angular/flex-layout/bundles/flex-layout.umd.js?(.map)"
    ];
    gulp.src(files, { base: "." })
        .pipe(flatten())
        .pipe(gulp.dest(webroot + "lib/js/@angular"));

    // angular material css
    files = [
        "./node_modules/@angular/material/prebuilt-themes/indigo-pink.css"
    ];
    gulp.src(files, { base: "." })
        .pipe(flatten())
        .pipe(gulp.dest(webroot + "lib/css/@angular"));

    // copy rx
    gulp.src(["./node_modules/rxjs/**/*.js", "./node_modules/rxjs/**/*.js.map"], { base: "./node_modules/rxjs" })
        .pipe(gulp.dest(webroot + "lib/js/rxjs"));

    // copy hammerjs
    gulp.src(["./node_modules/hammerjs/hammer.js"], { base: "./node_modules/hammerjs" })
        .pipe(gulp.dest(webroot + "lib/js/hammerjs"));

    // copy ngx-datatable
    gulp.src(["./node_modules/@swimlane/**/*.js", "./node_modules/@swimlane/**/*.js.map"], { base: "./node_modules/@swimlane" })
        .pipe(gulp.dest(webroot + "lib/js/ngx-datatable"));

    // ngx-datatable css
    gulp.src(["./node_modules/@swimlane/ngx-datatable/release/themes/material.css",
        "./node_modules/@swimlane/ngx-datatable/release/index.css",
        "./node_modules/@swimlane/ngx-datatable/release/assets/icons.css"], { base: "." })
        .pipe(flatten())
        .pipe(gulp.dest(webroot + "lib/css/ngx-datatable"));

    // ngx-datatable fonts
    gulp.src(["./node_modules/@swimlane/ngx-datatable/release/assets/fonts/data-table.woff",
        "./node_modules/@swimlane/ngx-datatable/release/assets/fonts/data-table.ttf "], { base: "." })
        .pipe(flatten())
        .pipe(gulp.dest(webroot + "lib/css/ngx-datatable/fonts"));

    // copy ngx-accordion
    gulp.src(["./node_modules/ngx-accordion/*"], { base: "./node_modules/ngx-accordion" })
        .pipe(gulp.dest(webroot + "lib/js/ngx-accordion"));

    // copy ng2-expansion-panels
    gulp.src(["./node_modules/ng2-expansion-panels/**/*"], { base: "./node_modules/ng2-expansion-panels" })
        .pipe(gulp.dest(webroot + "lib/js/ng2-expansion-panels"));



    //copy ng2filter-pipe
    gulp.src(["./node_modules/ng2-filter-pipe/**/*"], { base: "./node_modules/ng2-filter-pipe" })
        .pipe(gulp.dest(webroot + "lib/js/ng2-filter-pipe"));

    //copy angular2 masonary

    gulp.src(["./node_modules/angular2-masonry/**/*"], { base: "./node_modules/angular2-masonry" })
        .pipe(gulp.dest(webroot + "lib/js/angular2-masonry"));
    gulp.src(["./node_modules/masonry-layout/**/*"], { base: "./node_modules/masonry-layout" })
        .pipe(gulp.dest(webroot + "lib/js/masonry-layout"));

});


gulp.task("cleanjs", function () {
    del(["./src/app/**/*.js?(.map)", '!./src/**/systemjs.config.js']);
});
