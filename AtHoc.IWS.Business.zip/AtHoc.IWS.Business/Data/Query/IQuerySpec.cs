﻿using System.Collections.Generic;

namespace AtHoc.IWS.Business.Data
{
	public interface IQuerySpec
	{
		ICriteria Criterias { get; set; }

		IEnumerable<string> Columns { get; set; }
	}
}
