﻿using System.Collections.Generic;

namespace AtHoc.IWS.Business.Data
{
	public class ViewDependency
	{
		public string Alias { get; set; }

		public string Column { get; set; }
	}

	public class View
	{
		public enum Type
		{
			Nullable,
			NotNullable
		}

		public enum ContentType
		{
			Static,
			Dynamic
		}

		private readonly IList<ViewDependency> _dependencies = new List<ViewDependency>();

		public Type ViewType { get; set; }

		public ContentType ViewContentType { get; set; }

		public string Name { get; set; }

		public string IndexHint { get; set; }

		public string Definition { get; set; }

		public string Alias { get; set; }

		public IEnumerable<ViewDependency> Dependencies
		{
			get { return _dependencies; }
		}

		public View AddDependency(string alias, string column)
		{
			_dependencies.Add(new ViewDependency { Alias = alias, Column = column});
			return this;
		}
	}
}
