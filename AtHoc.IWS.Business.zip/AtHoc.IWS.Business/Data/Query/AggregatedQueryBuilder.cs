﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AtHoc.IWS.Business.Data
{
	public class AggregatedQueryBuilder : QueryBuilder
	{
		private readonly StringBuilder _resultBuilder = new StringBuilder();

		public AggregatedQueryBuilder(IQueryConfiguration configuration, StringBuilder sqlBuilder, IValueResolver valueResolver)
			: base(configuration, sqlBuilder, valueResolver) { }

		protected override bool ColumnValidForSelection(string columnName)
		{
			var column = _configuration.GetColumnByName(columnName);
			return column != null && column.Type != QueryColumnType.Regular;
		}

		protected override StringBuilder BuiderToFinalize()
		{
			return _resultBuilder;
		}

		protected override void BuildWhere(StringBuilder queryBuilder)
		{
			base.BuildWhere(queryBuilder);
			BuildGroupBy(queryBuilder);
			_resultBuilder.Append(queryBuilder);
		}

		protected override ICriteriaBuilder CreateCriteriaBuilder(StringBuilder queryBuilder, IQueryConfiguration configuration, IValueResolver valueResolver)
		{
			return new AggregatedCriteriaBuilder(queryBuilder, configuration, valueResolver);
		}

		private void BuildGroupBy(StringBuilder sqlBuilder)
		{
			var aggregatedColumns = _configuration.GetAggregationColumns();
			if (!aggregatedColumns.Any())
			{
				throw new ApplicationException("Configuration doesn`t have aggregated columns.");
			}
			sqlBuilder.AppendLine();
			sqlBuilder.AppendLine("	group by");
			sqlBuilder.Append("		");
			var columnList = aggregatedColumns.ToList();
			columnList.ForEach(c => BuildAggregatedColumn(sqlBuilder, c, columnList));
		}

		private void BuildAggregatedColumn(StringBuilder sqlBuilder, QueryColumn queryColumn, IEnumerable<QueryColumn> aggregationColumnList)
		{
			var column = _configuration.BuildQueryColumn(queryColumn.Name);
			sqlBuilder.Append(column);
			if (queryColumn != aggregationColumnList.Last())
				sqlBuilder.Append(", ");
		}
	}
}
