﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Database;

namespace AtHoc.IWS.Business.Data
{
	public abstract class BaseQueryBuilder : IQueryBuilder
	{
		protected readonly IQueryConfiguration _configuration;
		protected StringBuilder _sqlBuilder;
		protected readonly IValueResolver _valueResolver;
		private readonly StringBuilder _queryBuilder = new StringBuilder();

#warning Hack. Remove after using SqlBilder API.
		public bool UseStartSelect = true;
		public bool SelectDisctinct = false;
		public bool UseDummySelect = false;
		public bool CountModeOn = false;

		protected BaseQueryBuilder(IQueryConfiguration configuration, StringBuilder sqlBuilder, IValueResolver valueResolver)
		{
			_configuration = configuration;
			_sqlBuilder = sqlBuilder;
			_valueResolver = valueResolver;
		}

		public void Build()
		{
			BuildSelect(_queryBuilder);
			BuildFrom(_queryBuilder);
			BuildWhere(_queryBuilder);
			_sqlBuilder.Append(BuiderToFinalize());
		}

		protected virtual StringBuilder BuiderToFinalize()
		{
			return _queryBuilder;
		}

		protected abstract bool ColumnValidForSelection(string columnName);

		protected virtual ICriteriaBuilder CreateCriteriaBuilder(StringBuilder queryBuilder, IQueryConfiguration configuration, IValueResolver valueResolver)
		{
			return new CriteriaBuilder(queryBuilder, configuration, valueResolver);
		}

		protected virtual void BuildWhere(StringBuilder queryBuilder)
		{
			if (_configuration.Criteria == null || !_configuration.Criteria.Any())
				return;
			queryBuilder.AppendLine();
			StartWhereSection(queryBuilder);
			var criteriaBuilder = CreateCriteriaBuilder(queryBuilder, _configuration, _valueResolver);
			criteriaBuilder.Build(_configuration.Criteria);
		}

		public bool WhereClauseReady { get; private set; }

		protected void StartWhereSection(StringBuilder queryBuilder)
		{
			WhereClauseReady = true;
			queryBuilder.AppendLine("where");
			queryBuilder.Append("	");
		}

		private void BuildSelect(StringBuilder builder)
		{
			if (UseStartSelect)
				builder.AppendLine("	select");

			if (UseDummySelect)
			{
				builder.Append("1 as c");
				return;
			}

			var usedColumns = _configuration.UsedColumns().Where(ColumnValidForSelection).ToArray();
			foreach (var columnName in usedColumns)
			{
				var queryColumn = _configuration.BuildQueryColumn(columnName);
				var column = _configuration.GetColumnByName(columnName);
				var queryColumnAlias = DbUtils.AddBrackets(column.OutputAlias.HasValue() ? DbUtils.Escape(column.OutputAlias) : DbUtils.Escape(columnName));

				builder.AppendFormat("		{0} as {1}", queryColumn, queryColumnAlias);
				
				if (columnName != usedColumns.Last())
					builder.Append(",");
				builder.AppendLine();
			}
		}

		private void BuildFrom(StringBuilder builder)
		{
			builder.AppendLine("	from");
			var views = _configuration.GetViewsToJoin(_configuration.UsedColumns(ignoreSelectColumns: CountModeOn));
			foreach (var view in views)
			{
				if (view.Dependencies.Any())
					JoinView(builder, view);
				else
					builder.AppendFormat("		{0}", GetViewDefinitionForQuery(view));
			}
		}

		private void JoinView(StringBuilder builder, View view)
		{
			builder.AppendLine();
			var joinOperation = view.ViewType == View.Type.NotNullable ? "join" : "left join";
			builder.AppendFormat("		{0} {1} on ", joinOperation, GetViewDefinitionForQuery(view));
			ApplyViewDependencies(builder, view, _configuration);
		}

		private static string GetViewDefinitionForQuery(View view)
		{
			var hintStatement = String.Empty;
			if (view.ViewContentType == View.ContentType.Static)
			{
				var hintsBuilder = new StringBuilder();
				hintsBuilder.Append("with (nolock");
				if (view.IndexHint.HasValue())
					hintsBuilder.AppendFormat(" index({0})", view.IndexHint);
				hintsBuilder.Append(")");
				hintStatement = hintsBuilder.ToString();
			}

			return String.Format("{0} {1} {2}", view.Definition, view.Alias, hintStatement);
		}

		internal static void ApplyViewDependencies(StringBuilder builder, View view, IQueryConfiguration configuration)
		{
			if (!view.Dependencies.Any())
			{
				throw new ApplicationException(String.Format("View '{0}' has no dependencies defined.", view.Name));
			}
			foreach (var dependency in view.Dependencies)
			{
				builder.AppendFormat("{0}.{2} = {1}.{2}", view.Alias, dependency.Alias, dependency.Column);
				if (dependency != view.Dependencies.Last())
					builder.Append(" and ");
			}
		}
	}
}
