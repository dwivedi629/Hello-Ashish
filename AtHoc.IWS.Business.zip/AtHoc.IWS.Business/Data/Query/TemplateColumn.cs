﻿using System;

using AtHoc.Infrastructure;

namespace AtHoc.IWS.Business.Data
{
	public class TemplateColumn : QueryColumn
	{
		public string SourceAlias { get; set; }

		public string SourceColumn { get; set; }

		public string ValueAlias { get; set; }

		public string ValueColumn { get; set; }

		public string Template { get; set; }

		public object CriteriaValue { get; set; }

#warning Remove to concrete builder
		public override string ToQueryString(string viewAlias)
		{
			if (SourceAlias.HasValue())
			{
				viewAlias = SourceAlias;
			}
			var queryColumn = String.Concat(viewAlias, ".[", SourceColumn, "]");
			if (!String.IsNullOrEmpty(Template))
			{
				queryColumn = String.Format(Template, queryColumn, CriteriaValue, ValueAlias, ValueColumn);
			}
			return queryColumn;
		}
	}
}
