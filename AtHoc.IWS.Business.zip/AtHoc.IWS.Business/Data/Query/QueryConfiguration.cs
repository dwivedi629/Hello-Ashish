﻿using System;
using System.Collections.Generic;
using System.Linq;

using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;
using AtHoc.IWS.Business.Domain.Users.Search;

namespace AtHoc.IWS.Business.Data
{
	public class QueryConfiguration : IQueryConfiguration
	{
		public QueryConfiguration(ICriteria criteria)
		{
			Views = new List<View>();
			Columns = new List<QueryColumn>();
			Criteria = criteria;
		}

		public ICriteria Criteria { get; set; }

		public ICollection<View> Views { get; set; }

		public ICollection<QueryColumn> Columns { get; set; }

		public View AddView(string name, string alias, string definition, View.Type viewType = View.Type.NotNullable,
							View.ContentType viewContentType = View.ContentType.Static, string indexHint = null)
		{
			var viewExisting = Views.SingleOrDefault(v => v.Name == name);
			if (viewExisting != null)
				return viewExisting;

			var view = new View
			{
				Alias = alias,
				Name = name,
				Definition = definition,
				ViewType = viewType,
				ViewContentType = viewContentType,
				IndexHint = indexHint
			};
			Views.Add(view);
			return view;
		}

		public void AddFilterColumn(string columnName, string view, FilterType filterType,
									ICriteriaConfigurationBuilder configurationBuilder)
		{
			AddColumn(new TemplateColumn
			{
				Name = columnName,
				View = view,
				FilterType = filterType,
				Type = QueryColumnType.FilterOnly,
				ConfigurationBuilder = configurationBuilder
			});
		}

		public void AddColumn(QueryColumn column)
		{
			if (Columns.All(c => c.Name != column.Name))
				Columns.Add(column);
		}

		public void AddColumn(string columnName, string view, string outputAlias = null)
		{
			AddColumn(new QueryColumn {Name = columnName, View = view, Type = QueryColumnType.Regular, OutputAlias = outputAlias});
		}

		public void AddAggregationColumn(string columnName, string view)
		{
			AddColumn(new QueryColumn {Name = columnName, View = view, Type = QueryColumnType.Aggregation});
		}

		public QueryColumn GetColumnByName(string columnName)
		{
		    if (string.IsNullOrEmpty(columnName))
		        return null;

            string resolvedColumnName;
            switch (columnName.ToUpper())
            {
                case AttributeResultSetNames.UserName:
                    resolvedColumnName = AttributeCommonNames.UserName;
                    break;
                default:
                    resolvedColumnName = columnName;
                    break;
            }

            Func<QueryColumn, bool> predicate = c => String.Equals(c.Name, resolvedColumnName, StringComparison.CurrentCultureIgnoreCase);

			if (Columns.Count(predicate) > 1)
                throw new ApplicationException("Column {0} specified more then once.".FormatWith(resolvedColumnName));

			return Columns.SingleOrDefault(predicate);
		}

		public string BuildQueryColumn(string columnName)
		{
			var column = GetColumnByName(columnName);
			if (Views.All(v => v.Name != column.View))
				throw new ApplicationException(String.Format("The configuration doesn`t have definition of view '{0}'", column.View));

			var view = GetViewByName(column.View);
			return column.ToQueryString(view.Alias);
		}

		public bool HasView(string viewName)
		{
			return Views.Any(v => v.Name == viewName);
		}

		public IEnumerable<string> UsedColumns(IEnumerable<string> outputColumns = null, bool ignoreSelectColumns = false)
		{
			var result = new List<string>();

			if (outputColumns != null)
				result.AddRange(outputColumns);
			else if (!ignoreSelectColumns)
				result.AddRange(Columns.Select(c => c.Name));

			GetUsedColumnsInCriteria(Criteria, result);
			var columns = result.Distinct(StringComparer.InvariantCultureIgnoreCase);

			if (!columns.Any())
				throw new ApplicationException("The configuration is invalid. Check selection and criteria columns definition.");

			return columns;
		}

		public static void GetUsedColumnsInCriteria(IEnumerable<ICriteria> criterias, IList<string> result)
		{
			if (criterias == null) return;
			foreach (var criteria in criterias)
			{
				if (!(criteria is GroupCriteria))
					result.Add(criteria.Name);
				GetUsedColumnsInCriteria(criteria, result);
			}
		}

		public IEnumerable<View> GetViewsToJoin(IEnumerable<string> columns)
		{
			var usedViewsNames = GetUsedViewsInColumns(columns, true);
			var usedViews = Views.Where(v => usedViewsNames.Contains(v.Name)).ToList();
			GetViewsToJoinProcess(usedViews);
			return usedViews;
		}

		private static void GetViewsToJoinProcess(List<View> usedViews)
		{
			for (var i = 0; i < usedViews.Count; i++)
			{
				var view = usedViews[i];
				var viewDependencies = usedViews.Where(v => v.Dependencies.Any(d => d.Alias == view.Alias) && v.Name != view.Name);

				var indexToRemove = usedViews.IndexOf(view);
				GetIndexToRemove(usedViews, viewDependencies, ref indexToRemove);

				var viewIndex = usedViews.IndexOf(view);
				if (viewIndex == indexToRemove) continue;

				var viewToMove = usedViews[indexToRemove];
				usedViews[indexToRemove] = view;
				usedViews[viewIndex] = viewToMove;

				GetViewsToJoinProcess(usedViews);
			}
		}

		private static void GetIndexToRemove(IList<View> usedViews, IEnumerable<View> viewDependencies, ref int indexToRemove)
		{
			foreach (var viewDependency in viewDependencies)
			{
				var dependencyView = usedViews.SingleOrDefault(v => v.Alias == viewDependency.Alias);
				var index = usedViews.IndexOf(dependencyView);
				index = index == -1 ? 0 : index;
				if (indexToRemove > index)
					indexToRemove = index;
			}
		}

		public IEnumerable<string> GetUsedViewsInColumns(IEnumerable<string> columns, bool selectionOnly = false)
		{
			var result = new List<string>();
			foreach (var column in Columns)
			{
				if (selectionOnly && column.Type == QueryColumnType.FilterOnly && column.FilterType == FilterType.Exists)
					continue;

				if (columns.Contains(column.Name, StringComparer.InvariantCultureIgnoreCase))
				{
					var viewToAdd = column is TemplateColumn ? (column as TemplateColumn).View : column.View;
					if (!result.Contains(column.View))
						result.Add(viewToAdd);
				}
			}
			return result;
		}

		public IEnumerable<QueryColumn> GetAggregationColumns()
		{
			return Columns.Where(c => c.Type == QueryColumnType.Aggregation);
		}

		public bool IsQueryAggregated()
		{
			return GetAggregationColumns().Any();
		}

		public View GetViewByName(string viewName)
		{
			if (!HasView(viewName))
			{
				throw new ApplicationException(String.Format("The view '{0}' is not defined.", viewName));
			}
			return Views.Single(v => v.Name == viewName);
		}
	}
}