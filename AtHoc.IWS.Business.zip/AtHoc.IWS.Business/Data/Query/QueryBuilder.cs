﻿using System.Text;

namespace AtHoc.IWS.Business.Data
{
	public class QueryBuilder : BaseQueryBuilder
	{
		public QueryBuilder(IQueryConfiguration configuration, StringBuilder sqlBuilder, IValueResolver valueResolver)
			: base(configuration, sqlBuilder, valueResolver) { }

		protected override bool ColumnValidForSelection(string columnName)
		{
			var column = _configuration.GetColumnByName(columnName);
			return column != null && column.Type != QueryColumnType.FilterOnly;
		}
	}
}
