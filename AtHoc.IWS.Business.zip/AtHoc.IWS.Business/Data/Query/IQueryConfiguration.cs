﻿using System.Collections.Generic;

using AtHoc.IWS.Business.Domain.Users.Search;

namespace AtHoc.IWS.Business.Data
{
	public interface IQueryConfiguration
	{
		ICollection<View> Views { get; set; }

		ICollection<QueryColumn> Columns { get; set; }

		ICriteria Criteria { get; set; }

		View AddView(string name, string alias, string definition, View.Type viewType = View.Type.NotNullable,
					View.ContentType viewContentType = View.ContentType.Static, string indexHint = null);

		void AddColumn(QueryColumn column);

		void AddAggregationColumn(string columnName, string view);

		void AddColumn(string columnName, string view, string outputAlias = null);

		void AddFilterColumn(string columnName, string view, FilterType filterType,
							ICriteriaConfigurationBuilder configurationBuilder = null);

		IEnumerable<View> GetViewsToJoin(IEnumerable<string> columns);

		QueryColumn GetColumnByName(string columnName);

		string BuildQueryColumn(string columnName);

		IEnumerable<string> GetUsedViewsInColumns(IEnumerable<string> columns, bool selectionOnly = false);

		IEnumerable<QueryColumn> GetAggregationColumns();

		bool IsQueryAggregated();

		View GetViewByName(string viewName);

		bool HasView(string viewName);

		IEnumerable<string> UsedColumns(IEnumerable<string> outputColumns = null, bool ignoreSelectColumns = false);
	}
}