﻿using System.Collections.Generic;

using AtHoc.Infrastructure.Entity;

namespace AtHoc.IWS.Business.Data
{
	public class QuerySpec : EntitySpec, IQuerySpec
	{
		public ICriteria Criterias { get; set; }

		public IEnumerable<string> Columns { get; set; }
	}
}
