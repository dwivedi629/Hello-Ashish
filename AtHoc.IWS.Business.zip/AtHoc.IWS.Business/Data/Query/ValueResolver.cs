﻿using System;
using System.Collections;
using System.Collections.Generic;

using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Sql;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Business.Domain.Users.Impl.Search;

namespace AtHoc.IWS.Business.Data
{
	public class ValueResolver : IValueResolver
	{
	    public ValueResolver()
	    {
	        IgnoreTempTable = false;
	    }

        public bool IgnoreTempTable { get; set; }

		public virtual string Resolve(ICriteriaParameter parameter)
		{
			var conditionOperator = parameter.Operator;
			if (!(conditionOperator == ConditionOperator.Empty || conditionOperator == ConditionOperator.NotEmpty) && parameter.Value == null)
				throw new ApplicationException("Parameter value is not defined.");

			var result = String.Empty;
			var value = parameter.Value;

			if (value == null)
				result = ResolveEmpty(parameter);

			if (value is string)
				result = ResolveString(parameter);

			if (value.IsNumber())
				result = ResolveNumber(parameter);

			if (value is DateTime)
				result = ResolveDateTime(parameter);

			if (value is IEnumerable && (conditionOperator == ConditionOperator.In || conditionOperator == ConditionOperator.NotIn))
				result = ResolveArray(parameter, IgnoreTempTable);

			if (result == null)
				throw new NotImplementedException(String.Format("The resolving of type '{0}' and operation '{1}' is not supported.'", parameter.Value.GetType().Name, conditionOperator));

			return result;
		}

		public virtual string BuildValueCondition(string columnName, ICriteriaParameter parameter)
		{
            var criteriaParameter = parameter as AttributeCriteriaParameter;
            if (criteriaParameter != null)
            {
                if (criteriaParameter.AttributeType == CustomAttributeDataType.String && criteriaParameter.Operator == ConditionOperator.Empty)
                    return String.Format("isnull({0}, '') = ''", columnName);
                else if (criteriaParameter.AttributeType == CustomAttributeDataType.String && criteriaParameter.Operator == ConditionOperator.NotEmpty)
                    return String.Format("isnull({0}, '') <> ''", columnName);
            }

			return String.Format("{0} {1}", columnName, Resolve(parameter));
		}

		private static string ResolveArray(ICriteriaParameter parameter, bool ignoreTempTable = false)
		{
			var array = (IEnumerable) parameter.Value;
			var parameters = new List<object>();
			foreach (var parameterObj in array)
			{
				if (parameterObj is string)
					parameters.Add(String.Concat("'", parameterObj, "'"));
				else
					parameters.Add(parameterObj);
			}
			var operation = parameter.Operator == ConditionOperator.In ? "in" : "not in";

			var paramsStr = parameter.MustBeHandledByTempTable(ignoreTempTable)
				? "select * from {0}".FormatWith(parameter.GetTempTableName())
				: parameters.Join();

			return " {0} ({1})".FormatWith(operation, paramsStr);
		}

		protected static string CreateEquals(object value, bool useQuotes = false)
		{
			return CreateCondition(value, "=", useQuotes);
		}

		protected static string CreateNotEquals(object value, bool useQuotes = false)
		{
			return CreateCondition(value, "!=", useQuotes);
		}

		protected static string CreateLessThan(object value, bool useQuotes = false)
		{
			return CreateCondition(value, "<", useQuotes);
		}

		protected static string CreateLessThanEquals(object value, bool useQuotes = false)
		{
			return CreateCondition(value, "<=", useQuotes);
		}

		protected static string CreateGreaterThan(object value, bool useQuotes = false)
		{
			return CreateCondition(value, ">", useQuotes);
		}

		protected static string CreateGreaterThanEquals(object value, bool useQuotes = false)
		{
			return CreateCondition(value, ">=", useQuotes);
		}

		protected static string CreateCondition(object value, string condition, bool useQuotes)
		{
			return useQuotes ? String.Concat(condition, " '", value, "'") : String.Concat(condition, " ", value);
		}

		protected static string CreateEmpty()
		{
			return "is null";
		}

		protected static string CreateNotEmpty()
		{
			return "is not null";
		}

		private string ResolveEmpty(ICriteriaParameter parameter)
		{
			switch (parameter.Operator)
			{
				case ConditionOperator.Empty:
					return CreateEmpty();
				case ConditionOperator.NotEmpty:
					return CreateNotEmpty();
				default:
					return null;
			}
		}

		protected string ResolveString(ICriteriaParameter parameter)
		{
			var parameterValue = String.Empty;
		    var parameterValueForLike = String.Empty;
		    if (parameter.Value != null)
		    {
		        parameterValue = SqlBuilder.EscapeValue(parameter.Value.ToString());
		        parameterValueForLike = SqlBuilder.EscapeValueForSqlLike(parameter.Value.ToString());
		    }


		    switch (parameter.Operator)
			{
				case ConditionOperator.Equals:
					return String.Concat("= N'", parameterValue, "'");
				case ConditionOperator.NotEquals:
					return String.Concat("!= N'", parameterValue, "'");
				case ConditionOperator.StartsWith:
					return String.Concat("like N'", parameterValueForLike, "%'");
				case ConditionOperator.EndsWith:
					return String.Concat("like N'%", parameterValueForLike, "'");
				case ConditionOperator.Contains:
					return String.Concat("like N'%", parameterValueForLike, "%'");
				case ConditionOperator.NotContains:
					return String.Concat("not like N'%", parameterValueForLike, "%'");
				case ConditionOperator.NotStartsWith:
					return String.Format("like N'[^{0}]%{0}%'",parameterValue);
				case ConditionOperator.Empty:
					return CreateEmpty();
				case ConditionOperator.NotEmpty:
					return CreateNotEmpty();
				default:
					return null;
			}
		}

		protected string ResolveNumber(ICriteriaParameter parameter)
		{
			switch (parameter.Operator)
			{
				case ConditionOperator.Equals:
					return CreateEquals(parameter.Value);
				case ConditionOperator.NotEquals:
					return CreateNotEquals(parameter.Value);
				case ConditionOperator.GreaterThan:
					return CreateGreaterThan(parameter.Value);
				case ConditionOperator.LessThan:
					return CreateLessThan(parameter.Value);
				case ConditionOperator.GreaterThanEquals:
					return CreateGreaterThanEquals(parameter.Value);
				case ConditionOperator.LessThanEquals:
					return CreateLessThanEquals(parameter.Value);
				case ConditionOperator.Empty:
					return CreateEmpty();
				case ConditionOperator.NotEmpty:
					return CreateNotEmpty();
				default:
					return null;
			}
		}

		protected string ResolveDateTime(ICriteriaParameter parameter)
		{
			switch (parameter.Operator)
			{
				case ConditionOperator.Equals:
					return CreateEquals(parameter.Value, true);
				case ConditionOperator.NotEquals:
					return CreateNotEquals(parameter.Value, true);
				case ConditionOperator.LessThan:
					return CreateLessThan(parameter.Value, true);
				case ConditionOperator.LessThanEquals:
					return CreateLessThanEquals(parameter.Value, true);
				case ConditionOperator.GreaterThan:
					return CreateGreaterThan(parameter.Value, true);
				case ConditionOperator.GreaterThanEquals:
					return CreateGreaterThanEquals(parameter.Value, true);
				case ConditionOperator.Empty:
					return CreateEmpty();
				case ConditionOperator.NotEmpty:
					return CreateNotEmpty();
				default:
					return null;
			}
		}
	}
}
