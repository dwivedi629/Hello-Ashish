﻿using System;

using AtHoc.Infrastructure.Database;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.Users.Search;

namespace AtHoc.IWS.Business.Data
{
	public class QueryColumn : NamedObject
	{
		public QueryColumn()
		{
			Type = QueryColumnType.Regular;
			FilterType = FilterType.Exists;
		}

		public ICriteriaConfigurationBuilder ConfigurationBuilder { get; set; }

		public FilterType FilterType { get; set; }

		public string View { get; set; }

		public QueryColumnType Type { get; set; }

		public string OutputAlias { get; set; }

		public virtual string GetColumnWithAlias(string viewAlias)
		{
			var columnName = DbUtils.Refine(Name);
			return String.Concat(viewAlias, ".", columnName);
		}

		public virtual string ToQueryString(string viewAlias)
		{
			return GetColumnWithAlias(viewAlias);
		}
	}
}
