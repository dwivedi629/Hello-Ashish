﻿namespace AtHoc.IWS.Business.Data
{
	public interface IValueResolver
	{
		string Resolve(ICriteriaParameter parameter);

		string BuildValueCondition(string columnName, ICriteriaParameter parameter);
	}
}