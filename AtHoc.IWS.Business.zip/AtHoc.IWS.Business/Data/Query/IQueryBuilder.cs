﻿namespace AtHoc.IWS.Business.Data
{
	public interface IQueryBuilder
	{
		void Build();
	}
}
