﻿namespace AtHoc.IWS.Business.Data
{
	public interface ICriteriaBuilder
	{
		void Build(ICriteria criterias);
	}
}