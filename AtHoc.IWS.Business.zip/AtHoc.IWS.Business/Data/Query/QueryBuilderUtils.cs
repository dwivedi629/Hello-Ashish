﻿using System.Linq;
using System.Collections.Generic;

using AtHoc.Infrastructure;

namespace AtHoc.IWS.Business.Data
{
	internal static class QueryBuilderUtils
	{
		internal static IEnumerable<string> GetUsedViews(IQueryConfiguration configuration, IQuerySpec spec)
		{
			var result = new List<string>();
			result.AddRange(configuration.GetUsedViewsInColumns(spec.Columns));
			GetUsedViewTypesInCriterias(configuration, spec.Criterias, result);
			//GetUsedViewTypesInCriterias(configuration, spec.AggregationCriterias, result);
			return result.Distinct();
		}

		internal static IEnumerable<string> GetUsedViewsForSelect(IQueryConfiguration configuration, IQuerySpec spec)
		{
			var result = new List<string>();
			result.AddRange(configuration.GetUsedViewsInColumns(spec.Columns));
			//GetUsedViewTypesInCriterias(configuration, spec.Criteria, result);
			//GetUsedViewTypesInCriterias(configuration, spec.AggregationCriterias, result);
			return result.Distinct();
		}

		internal static void GetUsedViewTypesInCriterias(IQueryConfiguration configuration, IEnumerable<ICriteria> criterias, ICollection<string> result)
		{
			if (criterias == null) return;
			foreach (var criteria in criterias)
			{
				if (criteria.Name.HasValue())
				{
					var columnViewDescriptor = configuration.GetColumnByName(criteria.Name);
					result.Add(columnViewDescriptor.View);
				}
				GetUsedViewTypesInCriterias(configuration, criteria, result);
			}
		}
}
}
