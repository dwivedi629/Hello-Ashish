﻿namespace AtHoc.IWS.Business.Data
{
	public enum QueryColumnType
	{
		Regular,

		Aggregated,
	
		Aggregation,
		
		FilterOnly
	}

	public enum FilterType
	{
		Match,

		Exists
	}
}
