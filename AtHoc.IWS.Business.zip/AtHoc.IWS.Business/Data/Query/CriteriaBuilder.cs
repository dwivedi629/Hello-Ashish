﻿using System;
using System.Linq;
using System.Runtime.Caching;
using System.Text;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;
using AtHoc.IWS.Business.Domain.Users.Search;

namespace AtHoc.IWS.Business.Data
{
	public abstract class BaseCriteriaBuilder : ICriteriaBuilder
	{
		protected readonly StringBuilder _sqlBuilder;
		protected readonly IQueryConfiguration _queryConfiguration;
		protected readonly IValueResolver _criteriaResolver;

		protected BaseCriteriaBuilder(StringBuilder sqlBuilder, IQueryConfiguration queryConfiguration, IValueResolver criteriaResolver)
		{
			_sqlBuilder = sqlBuilder;
			_queryConfiguration = queryConfiguration;
			_criteriaResolver = criteriaResolver;
		}

		public virtual void Build(ICriteria criterias)
		{
			if (criterias == null || !criterias.Any())
				return;

			var groupCriteria = criterias as IGroupCriteria;
			if (groupCriteria != null)
			{
				_sqlBuilder.Append("(");
			}
			foreach (var childCriteria in criterias)
			{
				if (HandleFilterTemplate(criterias, childCriteria, groupCriteria)) continue;

				if (!(childCriteria is GroupCriteria))
					BuildChildCriteria(childCriteria);

				Build(childCriteria);

				if (childCriteria != criterias.Last())
					_sqlBuilder.AppendFormat(" {0} ", groupCriteria.GroupOperator);
			}
			if (groupCriteria != null)
			{
				_sqlBuilder.Append(")");
			}
		}

		private bool HandleFilterTemplate(ICriteria criterias, ICriteria childCriteria, IGroupCriteria groupCriteria)
		{
			var column = _queryConfiguration.GetColumnByName(childCriteria.Name);
			if (column is TemplateColumn && groupCriteria != null)
			{
				var templateColumn = column as TemplateColumn;
				if (templateColumn.ConfigurationBuilder != null)
				{
					ApplyFilterTemplate(childCriteria, templateColumn);
					if (childCriteria != criterias.Last())
						_sqlBuilder.AppendFormat(" {0} ", groupCriteria.GroupOperator);
					return true;
				}
			}
			return false;
		}

		private void ApplyFilterTemplate(ICriteria childCriteria, TemplateColumn templateColumn)
		{
			var filterSqlTextBuilder = new StringBuilder();
			var queryConfiguration = templateColumn.ConfigurationBuilder.Build(childCriteria);
			var filterSqlBuilder = new QueryBuilder(queryConfiguration, filterSqlTextBuilder, _criteriaResolver) { UseDummySelect = true };
			filterSqlBuilder.Build();
			HandleParameterComparison(childCriteria);
			_sqlBuilder.Append(filterSqlTextBuilder);
			var dependencyView = _queryConfiguration.GetViewByName(templateColumn.View);
			_sqlBuilder.AppendLine();
			_sqlBuilder.AppendLine(filterSqlBuilder.WhereClauseReady ? "and" : "where");
			BaseQueryBuilder.ApplyViewDependencies(_sqlBuilder, dependencyView, _queryConfiguration);
			_sqlBuilder.Append("	)");
		}

#warning Refactor below...
		[Obsolete("Hack solution")]
		private void HandleParameterComparison(ICriteria childCriteria)
		{
			if (childCriteria.Parameter == null || childCriteria.Parameter.ParameterComparison == CriteriaParameterComparison.Exists)
				_sqlBuilder.Append("EXISTS (");
			else if (childCriteria.Parameter.ParameterComparison == CriteriaParameterComparison.NotExists)
				_sqlBuilder.Append("NOT EXISTS (");
			else
				throw new ApplicationException("Wrong parameter comparison type for exists statement.");
		}

		protected void WriteChildCriteria(ICriteria criteria)
		{
#warning Remove below...
			var column = _queryConfiguration.GetColumnByName(criteria.Name);
			if (column.Type == QueryColumnType.FilterOnly)
			{
				WriteFilterOnlyColumn(criteria, column);
				return;
			}
			var columnName = _queryConfiguration.BuildQueryColumn(criteria.Name);
			_sqlBuilder.AppendFormat(_criteriaResolver.BuildValueCondition(columnName, criteria.Parameter));
		}

		private void WriteFilterOnlyColumn(ICriteria criteria, QueryColumn column)
		{
			var view = _queryConfiguration.GetViewByName(column.View);
			var columnName = String.Format("{0}.{1}", view.Alias, column.Name);
			var filterStatement = _criteriaResolver.BuildValueCondition(columnName, criteria.Parameter);
			if (column.FilterType == FilterType.Exists)
			{
				if (!view.Dependencies.Any())
				{
					throw new ApplicationException("No dependencies for filter column.");
				}
				HandleParameterComparison(criteria);
				_sqlBuilder.AppendFormat("SELECT 1 FROM {0} {1} WHERE {2} and ",
					view.Definition, view.Alias, filterStatement);
				BaseQueryBuilder.ApplyViewDependencies(_sqlBuilder, view, _queryConfiguration);
				_sqlBuilder.Append(")");
			}
			else
			{
				_sqlBuilder.Append(filterStatement);
			}
		}

		protected abstract void BuildChildCriteria(ICriteria criteria);
	}


	public class AggregatedCriteriaBuilder : BaseCriteriaBuilder
	{
		public AggregatedCriteriaBuilder(StringBuilder sqlBuilder, IQueryConfiguration queryConfiguration, IValueResolver criteriaResolver)
				: base(sqlBuilder, queryConfiguration, criteriaResolver) { }

		protected override void BuildChildCriteria(ICriteria criteria)
		{
			var column = _queryConfiguration.GetColumnByName(criteria.Name);
			//if (column.Type == QueryColumnType.Aggregated)
				WriteChildCriteria(criteria);
		}
	}

	public class CriteriaBuilder : BaseCriteriaBuilder
	{
		public CriteriaBuilder(StringBuilder sqlBuilder, IQueryConfiguration queryConfiguration, IValueResolver criteriaResolver)
			: base(sqlBuilder, queryConfiguration, criteriaResolver) { }

		protected override void BuildChildCriteria(ICriteria criteria)
		{
			if (criteria is GroupCriteria)
				return;

			var queryColumn = _queryConfiguration.GetColumnByName(criteria.Name);

			if (queryColumn == null)
			{
				throw new ApplicationException(
					String.Format("The configuration doesn`t have information for column with name '{0}'.", criteria.Name));
			}

			if (queryColumn.Type == QueryColumnType.Aggregated)
				return;

			WriteChildCriteria(criteria);
		}
	}
}
