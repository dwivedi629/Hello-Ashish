﻿using AtHoc.Infrastructure.Service;

using AtHoc.IWS.Business.Database;

namespace AtHoc.IWS.Business.Data
{
	public abstract class BaseNgaddataService<TResult, TParameter> : BaseContextService<TResult, TParameter, INgaddataContext>
		where TParameter : class
	{
		protected override INgaddataContext CreateContext()
		{
			return AtHocDbContextFactory.CreateFactory().CreateNgaddataContext();
		}
	}
}