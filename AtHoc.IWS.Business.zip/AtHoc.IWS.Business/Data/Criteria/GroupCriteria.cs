﻿using System.Linq;

using AtHoc.Infrastructure.Data;

namespace AtHoc.IWS.Business.Data
{
	public class GroupCriteria : Criteria, IGroupCriteria
	{
		protected GroupCriteria(GroupOperator groupOperator, params ICriteria[] criterias)
			: base(criterias)
		{
			GroupOperator = groupOperator;
		}

		public virtual bool HasValue()
		{
			return base._criterias.Any();
		}

		public GroupOperator GroupOperator { get; set; }

		static public ICriteria And(params ICriteria[] criterias)
		{
			return CreateCriteria(GroupOperator.And, criterias);
		}

		static public ICriteria Or(params ICriteria[] criterias)
		{
			return CreateCriteria(GroupOperator.Or, criterias);
		}

		static public ICriteria CreateCriteria(GroupOperator groupOperator, params ICriteria[] criterias)
		{
			return new GroupCriteria(groupOperator, criterias);
		}
	}
}
