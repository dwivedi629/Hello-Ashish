﻿using System.Linq;
using System.Collections.Generic;

using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Data;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.Users.Search;

namespace AtHoc.IWS.Business.Data
{
	public class Criteria : NamedObject, ICriteria 
	{
		protected readonly List<ICriteria> _criterias = new List<ICriteria>();

		protected Criteria(params ICriteria[] criterias)
		{
			_criterias.AddRange(criterias.Where(criteria => criteria != null));
		}

		protected Criteria(string name, ICriteriaParameter parameter)
		{
			Name = name;
			Parameter = parameter;
		}

		public virtual bool HasParameter()
		{
			return Parameter != null;
		}

		public ICriteriaParameter Parameter { get; set; }

		public IEnumerator<ICriteria> GetEnumerator()
		{
			return _criterias.GetEnumerator();
		}

		public ICriteria Add(params ICriteria[] criterias)
		{
			_criterias.AddRange(criterias);
			return this;
		}

		System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
		{
			return _criterias.GetEnumerator();
		}

		public static ICriteria CreateCriteria(string name, ICriteriaParameter parameter, bool useEmptyValueHandling = true)
		{
			var actualCriteria = new Criteria(name, parameter);
			var emptyCriteria = new Criteria(name, new AttributeCriteriaParameter(ConditionOperator.Empty));
			return CreateCriteria(parameter, actualCriteria, emptyCriteria, useEmptyValueHandling);
		}

		public static ICriteria CreateCriteria(
			ICriteriaParameter parameter,
			ICriteria actualCriteria,
			ICriteria emptyCriteria,
			bool useEmptyValueHandling = true)
		{
			if (useEmptyValueHandling)
				if (parameter.Operator == ConditionOperator.NotEquals || parameter.Operator == ConditionOperator.NotContains)
					if (parameter.Value is string || parameter.Value.IsNumber())
						return GroupCriteria.Or(
							emptyCriteria,
							actualCriteria
							);

			return actualCriteria;
		}
	}
}
