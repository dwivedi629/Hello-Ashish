﻿using AtHoc.Infrastructure.Data;

namespace AtHoc.IWS.Business.Data
{
	public interface IGroupCriteria : ICriteria
	{
		GroupOperator GroupOperator { get; set; }
	}
}
