﻿using System;

using AtHoc.Infrastructure.Data;

namespace AtHoc.IWS.Business.Data
{
	public class CriteriaParameter : ICriteriaParameter
	{
		protected CriteriaParameter()
		{
			UniqueId = Guid.NewGuid().ToString().Replace("-", String.Empty);
		}

		protected CriteriaParameter(object value, ConditionOperator condition = ConditionOperator.Equals) : this()
		{
			Value = value;
			Operator = condition;
			ParameterComparison = CriteriaParameterComparison.Exists;
		}

		public object Value { get; set; }

		public ConditionOperator Operator { get; set; }

		public CriteriaParameterComparison ParameterComparison { get; set; }

		public string UniqueId { get; set; }
	}
}
