﻿using System.Security.Cryptography.X509Certificates;

using AtHoc.Infrastructure.Data;

namespace AtHoc.IWS.Business.Data
{
	public enum CriteriaParameterComparison
	{
		Match,
		Exists,
		NotExists
	}

	public interface ICriteriaParameter
	{
		object Value { get; set; }

		ConditionOperator Operator { get; set; }

		CriteriaParameterComparison ParameterComparison { get; set; }

		string UniqueId { get; set; }
	}
}