﻿using System.Collections.Generic;
using AtHoc.IWS.Business.Domain;

namespace AtHoc.IWS.Business.Data
{
	public interface ICriteria : INamedObject, IEnumerable<ICriteria>
	{
		ICriteria Add(params ICriteria[] criterias);

		ICriteriaParameter Parameter { get; set; }

		bool HasParameter();
	}
}
