﻿namespace AtHoc.IWS.Business.Data
{
	public enum CriteriaParameterComparison
	{
		Match,

		Exists,

		NotExists
	}
}
