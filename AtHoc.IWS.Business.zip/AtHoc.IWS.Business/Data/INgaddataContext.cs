﻿using AtHoc.Infrastructure.Database;

using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.Audit;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Business.Domain.RuleModel;
using AtHoc.IWS.Business.Domain.SelfService;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Business.Domain.Impl;
using AtHoc.IWS.Business.Domain.Users;
using AtHoc.IWS.Business.Domain.Users.Impl;
using AtHoc.IWS.Business.Domain.VirtualSystem;
using AtHoc.IWS.Business.Domain.PageLayout;
using AtHoc.IWS.Business.Domain.Devices;
using AtHoc.IWS.Business.Cache;
using AtHoc.IWS.Business.Shedule;
using AtHoc.IWS.Business.Domain.Settings.Impl;

namespace AtHoc.IWS.Business.Data
{
    public interface INgaddataContext : IDbContext
    {
        IVirtualSystemRepository VirtualSystemRepository { get; set; }

        IOperatorUserRepository OperatorUserRepository { get; set; }

        IEndUserRepository EndUserRepository { get; set; }

        ICustomAttributeRepository CustomAttributeRepository { get; set; }

        ICustomAttributeValueRepository CustomAttributeValueRepository { get; set; }

        ICustomViewRepository CustomViewRepository { get; set; }

        ICustomViewDeleteRepository CustomViewDeleteRepository { get; set; }

        IHierarchyRepository HierarchyRepository { get; set; }

        IPageLayoutRepository PageLayoutRepository { get; set; }

        IDeviceRepository DeviceRepository { get; set; }

        IDeviceGroupRepository DeviceGroupRepository { get; set; }

        IAlertChannelRepository AlertChannelRepository { get; set; }

        IOperatorAccessRepository OperatorAccessRepository { get; set; }

        IDistributionListRepository DistributionListRepository { get; set; }

        IDistributionListItemRepositiory DistributionListItemRepository { get; set; }

        IDistributionListDependencyRepositiory DistributionListDependencyRepositiory { get; set; }

        IEndUserSearchRepository EndUserSearchRepository { get; set; }

        IEndUserSearchCountRepository EndUserSearchCountRepository { get; set; }

        IPagerCarrierRepository PagerCarrierRepository { get; set; }

        IAttributeValueRepository AttributeValueRepository { get; set; }

        ICacheinfoRepository CacheinfoRepository { get; set; }

        IDeviceAddressRepository DeviceAddressRepository { get; set; }

        IOperatorChannelRepository OperatorChannelRepository { get; set; }

        IOperatorUserRoleRepository OperatorUserRoleRepository { get; set; }

        IOperatorUserBaseRepository OperatorUserBaseRepository { get; set; }

        IOperatorRoleRepository OperatorRoleRepository { get; set; }

        IEndUserEntityRepository EndUserEntityRepository { get; set; }

        IOperatorEntityAccessRepository OperatorEntityAccessRepository { get; set; }

        IOperatorAuditRepository OperatorAuditRepository { get; set; }

        IActivityFeedRepository ActivityFeedRepository { get; set; }

        IAccountabilityActivityFeedRepository AccountabilityActivityFeedRepository { get; set; }

        IAlertRecipientDeviceRepository AlertRecipientDeviceRepository { get; set; }

        IProviderConfigurationRepository ProviderConfigurationRepository { get; set; }

        ICustomAttributeTargetingRepository CustomAttributeTargetingRepository { get; set; }

        IUserImportStatusRepository UserImportStatusRepository { get; set; }

        IUserImportDataRepository UserImportDataRepository { get; set; }

        IScheduledEventRepository ScheduledEventRepository { get; set; }

        IScheduleRepository ScheduleRepository { get; set; }

        IOperatorVPSAccessRepository OperatorVPSAccessRepository { get; set; }

        IGlobalSecurityPolicyRepository GlobalSecurityPolicyRepository { get; set; }

        ISecurityPolicyRepository SecurityPolicyRepository { get; set; }

        IDistributionListFolderRepository DistributionListFolderDbRepository { get; set; }

        ILocalSystemRepository LocalSystemRepository { get; set; }

        IPagerCarrierEntityRepository PagerCarrierEntityRepository { get; set; }

        IUserSearchRepository UserSearchRepository { get; set; }

        ISelfServiceAccountRepository SelfServiceAccountRepository { get; set; }

        IScenarioRepository ScenarioRepository { get; set; }

        ISelfServiceRepository SelfServiceRepository { get; set; }

        IDeliveryTemplateRepository DeliveryTemplateRepository { get; set; }

        IProviderRepository ProviderRepository { get; set; }

        IAudioFileRepository AudioFileRepository { get; set; }
        IRuleRepository RuleRepository { get; set; }
        IDisableDeleteEndUsersRepository DisableDeleteEndUsersRepository { get; set; }

        IUserGeoValueDBRepository UserGeoValueDBRepository { get; set; }
    }
}
