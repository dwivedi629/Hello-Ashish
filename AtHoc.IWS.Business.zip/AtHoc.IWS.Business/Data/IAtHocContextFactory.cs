﻿using System;

using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Factory;

namespace AtHoc.IWS.Business.Data
{
	public interface IAtHocContextFactory : IFactory<IUnitOfWork, Type>
	{
		INgaddataContext CreateNgaddataContext();
	}
}