﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Context;

namespace AtHoc.IWS.Business.Data.SearchSpec
{
    public class AutoDisableDeleteSpec
    {
        public int OperatorId { get; set; }

        public int ProviderId { get; set; }

        public string PurgeInterval { get; set; }

        public AutoDisableDeleteMode DisableDeleteMode { get; set; }
        public Provider Provider { get; set; }

       
          
           

       
    }

    public enum AutoDisableDeleteMode
    {
        Disable=1,
        Delete=2
    }
   
}
