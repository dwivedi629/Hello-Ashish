﻿using System;
using System.Collections.Generic;
using System.Data.Odbc;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Publishing;

namespace AtHoc.IWS.Business.Data.SearchSpec
{
    public class AlertSearchSpec : BaseSearchSpec
    {
        public int OperatorId { get; set; }
        public int ProviderId { get; set; }


        private string _searchText = "";

        public string SearchText
        {
            get { return (_searchText ==null) ? "": _searchText; }
            set { _searchText = value; }
        }

        private List<string> _statusFilter = new List<string>();

        public  List<string> StatusFilter
        {
            get { return _statusFilter; }
            set { _statusFilter = value; }
        }

        public String FromDateString { get; set; }

        public String ToDateString { get; set; }

        public DateTime? FromDate { get; set; }
        
        public DateTime? ToDate { get; set; }

        public int ChannelId
        {
            get { return _channelId; }
            set { _channelId = value; }
        }

        public string Publisher
        {
            get { return _publisher; }
            set { _publisher = value; }
        }

        public IList<int?> Severities
        {
            get { return _severity; }
            set { _severity = value; } 
        }


        public IList<int?> Events
        {
            get { return _event; } 
            set { _event = value; } 
        }


        private IList<int?> _severity = new List<int?>();
        private IList<int?> _event = new List<int?>() ;

        private int _channelId = -1;

        private string _publisher = "";

    }
}
