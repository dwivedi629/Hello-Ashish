﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Data.SearchSpec
{
    public class UserAttributeSearchSpec : BaseSearchSpec
    {
        public int OperatorId { get; set; }

        public int ProviderId { get; set; }

        private string[] _searchText = null;

        public string[] SearchText
        {
            get { return _searchText; }
            set { _searchText = value; }
        }

        public IEnumerable<CustomAttributeDataType?> SelectedAttributeTypes { get; set; }

        public bool CurrentOrganizationAttributesOnly { get; set; }
        public bool OtherOrganizationAttributesOnly { get; set; }
        public string Locale { get; set; }

        public CustomAttributeType _entityId = CustomAttributeType.User;
        public CustomAttributeType EntityId { get { return _entityId; } set { _entityId = value; } }
        public List<string> ExcludeCommonNames { get; set; }


    }
}
