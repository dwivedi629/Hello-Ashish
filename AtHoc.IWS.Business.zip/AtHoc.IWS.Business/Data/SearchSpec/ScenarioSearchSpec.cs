﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Data.SearchSpec
{
    public class ScenarioSearchSpec : BaseSearchSpec
    {
        private string _searchText = "";
        private bool _excludeSysScenario = false;

        public string SearchText
        {
            get { return (_searchText ==null) ? "": _searchText; }
            set { _searchText = value; }
        }

        private bool _quickOnly = false;

        public bool QuickOnly
        {
            get { return _quickOnly; }
            set { _quickOnly = value; }
        }

        private bool _regularOnly = false;

        public bool RegularOnly
        {
            get { return _regularOnly; }
            set { _regularOnly = value; }
        }

        private bool _recurrentOnly = false;


        public bool RecurrentOnly
        {
            get { return _recurrentOnly; }
            set { _recurrentOnly = value; }
        }

        private bool _nonRecurrentOnly = false;

        public bool NonRecurrentOnly
        {
            get { return _nonRecurrentOnly; }
            set { _nonRecurrentOnly = value; }
        }

        private int _channelId = -1;

        public int ChannelId
        {
            get { return _channelId; }
            set { _channelId = value; }
        }

        public bool ExcludeSystemScenarios
        {
            get { return _excludeSysScenario; }
            set { _excludeSysScenario = value; }
        }

        //todo: I have no idea why we are having this pattern??? 
        private string _commonName = "";
        public string CommonName 
        {
            get { return _commonName; }
            set { _commonName = value; }
        }

    }
}
