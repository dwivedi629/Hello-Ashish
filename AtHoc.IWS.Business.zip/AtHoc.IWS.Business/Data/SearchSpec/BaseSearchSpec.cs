﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Data.SearchSpec
{
    //this is created based on data posted back from kendo Grid
    public class BaseSearchSpec
    {
        public List<KendoSortOrder> Sort { get; set; }
        public int Page { get; set; }
        public int PageSize { get; set; }
    }

    public class KendoSortOrder
    {
        public string Field { get; set; }

        public string Dir { get; set; }
    }
}
