﻿using System.Linq;
using AtHoc.Infrastructure.Domain;
using AtHoc.Infrastructure.Extensions;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Data;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Users.Spec;
using System.Collections.Generic;

namespace AtHoc.IWS.Business.Domain.Authorization.Impl
{
    public class AuthFacade : FacadeBase<IAtHocContextFactory>, IAuthFacade
    {
        private readonly IOperatorDetailsFacade _operatorFacade;

        public AuthFacade(IAtHocContextFactory contextFactory, IOperatorDetailsFacade operatorFacade)
            : base(contextFactory)
        {
            _operatorFacade = operatorFacade;
        }

        public bool HasAccess(OperatorUser operatorUser, int providerId, SystemObject systemObject, ActionType actionType)
        {
            if (operatorUser == null)
                return false;

            operatorUser.OperatorAccess = _operatorFacade.GetOperatorAccess(new OperatorAccessSpec { OperatorId = operatorUser.Id, ProviderId = providerId });

            //Modify operator access list based on feature matrix
            operatorUser.OperatorAccess = ModifyOperatorAccessIfRequire(operatorUser.OperatorAccess);

            return operatorUser.OperatorAccess != null && operatorUser.HasPermission(systemObject, actionType);
        }

        public bool HasAccess(IEnumerable<OperatorAccess> operatorAccess, SystemObject systemObject, ActionType actionType)
        {
            if (operatorAccess == null)
                return false;

            //Modify operator access list based on feature matrix
            operatorAccess = ModifyOperatorAccessIfRequire(operatorAccess);

            return operatorAccess.HasPermission(systemObject, actionType);
        }
        
        public bool HasAccess(int operatorId, int providerId, SystemObject systemObject, ActionType actionType)
        {
            var operatorUser = _operatorFacade.GetOperatorUserBySpec(new OperatorUserSpec { OperatorId = operatorId, ExcludeDeleted = true });
            return HasAccess(operatorUser, providerId, systemObject, actionType);
        }

        private IEnumerable<OperatorAccess> ModifyOperatorAccessIfRequire(IEnumerable<OperatorAccess> operatorAccess)
        {
            //Removing objectIds from Operator's acccess list based on feature matrix
            if (RuntimeContext.Provider.FeatureMatrix.ObjectIdsToRemove != null)
            {
                var objectIdsToRemove = RuntimeContext.Provider.FeatureMatrix.ObjectIdsToRemove.ToList();
                operatorAccess = operatorAccess.ToList().Where(x => !objectIdsToRemove.Contains(x.ObjectId)).ToList();
            }
            return operatorAccess;
        }
    }
}