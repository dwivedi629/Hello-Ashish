﻿using AtHoc.IWS.Business.Domain.Authorization.Impl;
using AtHoc.IWS.Business.Domain.Entities;
using System.Collections.Generic;

namespace AtHoc.IWS.Business.Domain.Authorization
{
    public interface IAuthFacade
    {
        bool HasAccess(OperatorUser operatorUser, int providerId, SystemObject systemObject, ActionType actionType);

        bool HasAccess(int operatorId, int providerId, SystemObject systemObject, ActionType actionType);

        bool HasAccess(IEnumerable<OperatorAccess> opeatorAccess, SystemObject systemObject, ActionType actionType);

    }
}
