﻿using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Reports
{
    /// <summary>
    /// A generic interface for system level reports
    /// </summary>
    public interface IUserReportsFacade
    {
        DeviceContactInformation GetContactInfo(int providerId, int sessionid, List<int> deviceIds, int totalUsersCount);

    }
}
