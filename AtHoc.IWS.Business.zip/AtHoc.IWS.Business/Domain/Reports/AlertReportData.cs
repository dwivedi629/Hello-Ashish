﻿using System.Collections;
using System.Collections.Generic;
using AtHoc.Publishing;
using System;

namespace AtHoc.IWS.Business.Domain.Reports
{
    /// <summary>
    /// Correspond to the different tabs on the UI
    /// </summary>
    public enum ReportType
    {
        Summary = 0,
        Detail 
    }

    /// <summary>
    /// Correspond to the different views: summary, detail etc.
    /// </summary>
    public enum Dimension
    {
        USER = 0,
        ORG,
        MASS //Mass device
    }

    /// <summary>
    /// This class captures the output of RPT_ALERT_TRACKING which may contain two result sets
    /// One for general summary and one for responses and their counts
    /// </summary>
    public class AlertTrackingResult
    {
        /// <summary>
        /// Alert status Live/Ended
        /// </summary>
        public string Status { get; internal set; }
        public DateTime RemainingTime { get; internal set; }
        public IEnumerable<AlertTrackingSummary> Summary { get; set; }
        public IEnumerable<AlertTrackingResponseSummary> Responses { get; set; }
    }

    public abstract class AlertTrackingSummaryBase
    {
        public int Alert_ID { get; set; }
        public string Rpt_For { get; set; }
        public string By_Dim { get; set; }
        /// <summary>
        /// This field will be used for the org hrchy report
        /// </summary>
        public int? Parent_Dim { get; set; }
    }

    /// <summary>
    /// This class captures the 1st output dataset of RPT_ALERT_TRACKING
    /// </summary>
    public class AlertTrackingSummary : AlertTrackingSummaryBase
    {
        public int? Tgt { get; set; }
        public int? Sent { get; set; }
        public int? Not_Sent { get; set; }
        public int? Ack { get; set; }
        public int? No_Response { get; set; }
        /// <summary>
        /// The response count for the fill count
        /// </summary>
        public int? Fill_Count { get; set; }
        /// <summary>
        /// The response count above the fill count
        /// </summary>
        public int? Above_Fill_Count { get; set; }
        /// <summary>
        /// Is any response considered for the fill count 'Y/N'
        /// </summary>
        public string Any_Fill_Count { get; set; }
    }

    /// <summary>
    /// This class captures the 2nd output dataset of RPT_ALERT_TRACKING
    /// </summary>
    public class AlertTrackingResponseSummary : AlertTrackingSummaryBase
    {
        public int Response_Id { get; set; }
        public string Response_Text { get; set; }
        public int Count { get; set; }
        /// <summary>
        /// Does the response have a fill count 'Y/N'
        /// </summary>
        public string Is_Fill_Count { get; set; }
    }

}