﻿using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Reports
{
    public enum SnapShotReportType
    {
        OnlineUserCount = 0,
        MessagesSent
    }
    /// <summary>
    /// A generic interface for system level reports
    /// </summary>
    public interface ISystemReportsFacade
    {
        /// <summary>
        /// Gets the semi-hourly snap shot report data
        /// </summary>
        /// <param name="numDataPoints">number of data points (default is 48 i.e. 24 hours)</param>
        /// <returns></returns>
        IEnumerable<SnapShotReportItem> GetSnapShotReportData(SnapShotReportType type, Provider provider);
        /// <summary>
        /// Gets the semi-hourly recipient sent count
        /// </summary>
        /// <param name="numDataPoints">number of data points (default is 48 i.e. 24 hours)</param>
        /// <returns></returns>
        IEnumerable<SnapShotReportItem> GetRecipientSentCount(int numDataPoints = 48);

        #region Commneted the code as not being used, and to resolve the circular refrence of the Reporting Project,removing the refrence
        /// <summary>
        /// Gets the device coverage summary report data
        /// </summary>
        /// <returns></returns>
        //DeviceCoverageSummary GetDeviceCoverageSummary();

        #endregion
    }
}
