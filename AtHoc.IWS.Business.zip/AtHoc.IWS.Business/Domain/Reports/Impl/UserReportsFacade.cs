﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Data;
using AtHoc.Data;
using AtHoc.Publishing;
using AtHoc.IWS.Business.Domain.Devices.Impl;
using AtHoc.IWS.Business.Domain.Devices;
using AtHoc.IWS.Business.Domain.Devices.Spec;
using AtHoc.Targeting;
using System.Xml;
//using AtHoc.Reports;
using System.Data.SqlClient;
using System.Data;
using System.Data.Entity.Infrastructure;

namespace AtHoc.IWS.Business.Domain.Reports.Impl
{
    public class UserReportsFacade : IUserReportsFacade
    {
        public DeviceContactInformation GetContactInfo(int providerId, int sessionId, List<int> deviceIds,int totalUsersCount) {

            DeviceContactInformation deviceContactInfo = new DeviceContactInformation();
            deviceContactInfo.ContactInfo = new List<ContactInfoPerDevice>();

            using (var db = new AtHocDbContext())
            {
                db.Database.Initialize(force: false);
                // Set DB timeout 600 seconds since generating report may take longer.
                db.Database.CommandTimeout = 600;

                // Create a SQL command to execute the sproc 
                var cmd = db.Database.Connection.CreateCommand();
                cmd.CommandText = "[dbo].[RPT_USER_ATTRIBUTE_SUMMARY]";
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@in_attributeIdCSV", string.Join(",", deviceIds)));
                cmd.Parameters.Add(new SqlParameter("@in_sessionId", sessionId));
                cmd.Parameters.Add(new SqlParameter("@in_providerId", providerId));
                cmd.Parameters.Add(new SqlParameter("@in_reportType", "DEVICE"));
                cmd.Parameters.Add(new SqlParameter("@debugflag", false));
                SqlParameter p_usersFoundCount;
                p_usersFoundCount = new SqlParameter("@totalUsers", SqlDbType.Int);
                p_usersFoundCount.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(p_usersFoundCount);

                db.Database.Connection.Open();

                var reader = cmd.ExecuteReader();

                reader.NextResult();
                reader.NextResult();
                reader.NextResult();


                var resultRawData = (((IObjectContextAdapter)db)
                    .ObjectContext
                    .Translate<AlertReportRawData>(reader)).ToList();


                deviceContactInfo.TotalCount = totalUsersCount;

                foreach (AlertReportRawData data in resultRawData)
                { 

                    int id;
                    if (int.TryParse(data.ColumnId, out id)) //ignore "totalUsers" and other non-device
                    {
                        deviceContactInfo.ContactInfo.Add(new ContactInfoPerDevice(id, data.TotalCount, totalUsersCount));
                    }
                    else if (data.ColumnId == "totalCovered") 
                    {
                        deviceContactInfo.TotalCovered = data.TotalCount;
                        deviceContactInfo.TotalNotCovered = totalUsersCount - data.TotalCount;
                    }
                }

            }


            return deviceContactInfo;      
        }

    }
}
