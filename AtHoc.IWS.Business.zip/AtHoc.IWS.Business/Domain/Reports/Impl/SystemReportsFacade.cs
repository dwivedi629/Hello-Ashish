﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Data;
using AtHoc.Data;
using AtHoc.Publishing;
using AtHoc.IWS.Business.Domain.Devices.Impl;
using AtHoc.IWS.Business.Domain.Devices;
using AtHoc.IWS.Business.Domain.Devices.Spec;
using AtHoc.Targeting;
using System.Xml;


namespace AtHoc.IWS.Business.Domain.Reports.Impl
{
    public class SystemReportsFacade : ISystemReportsFacade
    {
        #region Commneted the code as not being used, and to resolve the circular refrence of the Reporting Project,removing the refrence
        
        //public DeviceCoverageSummary GetDeviceCoverageSummary()
        //{
        //    DeviceCoverageSummary ret = new DeviceCoverageSummary();
        //    var context = AtHocDbContextFactory.CreateFactory();
        //    IDeviceFacade deviceFacade = new DeviceFacade(context);
        //    //get all devices for the VPS...
        //    var devices = deviceFacade.GetDevicesBySpec(new DeviceSpec() { ProviderId = RuntimeContext.ProviderId },RuntimeContext.Provider.BaseLocale);
        //    //looking up the mobile app device ID by common name...
        //    string deviceId = devices.FirstOrDefault(d => d.CommonName == "mobileNotification") != null ? devices.FirstOrDefault(d => d.CommonName == "mobileNotification").Id.ToString() : "-1";

        //    TargetingManager tm = new TargetingManager(RuntimeContext.ProviderId);
        //    XmlDocument targetXmlDoc = new XmlDocument();
        //    targetXmlDoc.LoadXml("<targeting><allUserBaseNodeSelected isBlocked=\"N\">Y</allUserBaseNodeSelected></targeting>");
        //    int sid, dCnt;
        //    //this call is simply made to obtain a user search session ID...
        //    tm.GetTargetedUserCount(targetXmlDoc, RuntimeContext.OperatorId, 0, out sid, out dCnt);
        //    var reportObj = new ReportGenerator();
        //    var ids = devices.Select(d => d.Id);
        //    //now get the device coverage inforamtion with that session ID...
        //    ReportData deviceSummaryData = reportObj.GetUserDeviceCoverageSummaryOverall(RuntimeContext.ProviderId, string.Join(",", ids), sid, targetXmlDoc, RuntimeContext.OperatorId);
        //    ret.MobileAppUserCount = deviceSummaryData.RootRow.DataEntries.FirstOrDefault(e => e.Id.ToString() == deviceId) != null ? Convert.ToInt32(deviceSummaryData.RootRow.DataEntries.FirstOrDefault(e => e.Id.ToString() == deviceId).Value) : 0;
        //    string totalUsersId = "totalUsers";
        //    int totalUsers = deviceSummaryData.RootRow.DataEntries.FirstOrDefault(e => e.Id.ToString() == totalUsersId) != null ? Convert.ToInt32(deviceSummaryData.RootRow.DataEntries.FirstOrDefault(e => e.Id.ToString() == totalUsersId).Value) : 0;
        //    string totalCoveredId = "totalCovered";
        //    int totalCovered = deviceSummaryData.RootRow.DataEntries.FirstOrDefault(e => e.Id.ToString() == totalCoveredId) != null ? Convert.ToInt32(deviceSummaryData.RootRow.DataEntries.FirstOrDefault(e => e.Id.ToString() == totalCoveredId).Value) : 0;
        //    ret.NoDeviceUserCount = totalUsers - totalCovered;

        //    return ret;
        //} 

        #endregion

        public IEnumerable<SnapShotReportItem> GetRecipientSentCount(int numDataPoints = 48)
        {
            var criteria = new AtHoc.Data.Criteria();

            DateTime systime = RuntimeContext.Provider.CurrentSystemTime();
            //get alerts for the last 24 hrs
            criteria.Add(Junction.Between("startDate", systime.AddDays(-1), systime));
            criteria.AddOrder("startDate", System.Data.SqlClient.SortOrder.Ascending);

            var am = new AlertManager(RuntimeContext.ProviderId, RuntimeContext.OperatorId);
            var data = am.GetAlerts(criteria).GetList();

            //to expand the window, change 48 to 96 and go back one day from system date
            var ret = from offset in Enumerable.Range(1, numDataPoints)
                      let ts = systime.Date.AddMinutes(30 * offset)
                      select new SnapShotReportItem
                      {
                          TimeStamp = RuntimeContext.Provider.SystemToVpsTime(ts),
                          TimeStampFormatted = RuntimeContext.Provider.SystemToVpsDateTimeFormated(ts),
                          //roll up the sent count into a 30 minute bucket.
                          Value = data.Count(d => (ts - d.StartTime).TotalMinutes > 0 && (ts - d.StartTime).TotalMinutes < 30) > 0 ? data.Where(d => (ts - d.StartTime).TotalMinutes > 0 && (ts - d.StartTime).TotalMinutes < 30).Sum(d => d.Tracking.Sent) : 0
                      };

            return ret;
        }

        public IEnumerable<SnapShotReportItem> GetSnapShotReportData(SnapShotReportType type, Provider provider)
        {
            using (var repo = new EntityFrameworkRepository(new AtHocDbContext()))
            {
                DateTime systime = provider.CurrentSystemTime();
                var rs = repo.RunQuery<SnapShotReportItemRaw>(
                    "ngoladata.dbo.GET_SNAPSHOT_TRACKING @providerId, @activityType",
                    provider.Id,
                    type == SnapShotReportType.MessagesSent ? "MESSAGE SENT" : "ONLINE USERS"
                    ).ToList();

                var ret = from r in rs
                          let t = provider.SystemToVpsTime(r.last_update_datetime)
                          select new SnapShotReportItem
                          {
                              TimeStamp = t,// vpsTime,
                              TimeStampFormatted = t.ToString(provider.GetDateTimeFormat()),
                              Value = r.snapshot_count
                          };

                return ret.ToList().OrderBy(i => i.TimeStamp);
            }
        }
    }
}
