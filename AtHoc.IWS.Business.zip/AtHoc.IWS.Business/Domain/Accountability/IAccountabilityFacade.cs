﻿using System;
using System.Collections.Generic;
using AtHoc.Data;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Accountability.Specs;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Entities.Accountability;
using AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel;
using AtHoc.IWS.Business.Domain.Users.Impl;
using AtHoc.IWS.Business.Domain.Users.Search;
using System.Linq;
using AtHoc.IWS.Business.Domain.Accountability.Impl;
using AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel;
using AtHoc.Utilities;

namespace AtHoc.IWS.Business.Domain.Accountability
{
    public interface IAccountabilityFacade
    {
        #region template methods
        /// <summary>
        /// To get templates.
        /// </summary>
        /// <param name="templateSpec">template spec.</param>
        /// <param name="operatorId">operator Id.</param>
        /// <param name="isLoadBase">is load base details.</param>
        /// <returns>templates.</returns>
        IEnumerable<AccountabilityTemplate> GetTemplates(int operatorId, AccountabilityTemplateSpec templateSpec, bool isLoadBase);
        /// <summary>
        /// To get the template.
        /// </summary>
        /// <param name="templateId">template Id.</param>
        /// <param name="providerId">provider Id.</param>
        /// <param name="operatorId">operator Id.</param>
        /// <returns>template details.</returns>
        AccountabilityTemplate GetTemplate(int providerId, int operatorId, int templateId);
        /// <summary>
        /// TO create the template.
        /// </summary>
        /// <param name="templateDetails">template details.</param>
        /// <param name="operatorId">operator Id.</param>
        /// <returns>templte Id.</returns>
        int CreateTemplate(int operatorId, AccountabilityTemplate templateDetails);
        /// <summary>
        /// To update the template.
        /// </summary>
        /// <param name="templateDetails">template details.</param>
        /// <param name="operatorId">operator Id.</param>
        /// <returns>accountability template.</returns>
        bool UpdateTemplate(int operatorId, AccountabilityTemplate templateDetails);

        /// <summary>
        /// Duplicate the template.
        /// </summary>
        /// <param name="templateId">template Id.</param>
        /// <param name="providerId">provider Id.</param>
        /// <param name="operatorId">operator Id.</param>
        /// <returns>accountability template.</returns>
        AccountabilityTemplate DuplicateTemplate(int providerId, int operatorId, int templateId);

        /// <summary>
        /// To delete the template.
        /// </summary>
        /// <param name="ids">template Ids.</param>
        /// <param name="providerId">provider Id.</param>
        /// <param name="operatorId">operator Id.</param>       
        /// <returns></returns>
        bool DeleteTemplates(int providerId, int operatorId, IEnumerable<int> ids);
        #endregion
        #region event methods

        //IPaged<AccountabilityEvent> GetEvents(AccountabilityEventSpec eventSpec);
        /// <summary>
        /// To get events.
        /// </summary>
        /// <param name="eventSpec">event spec.</param>
        /// <returns>events.</returns>
        /// <summary>
        /// To get event.
        /// </summary>
        /// <param name="eventId">event Id.</param>
        /// <param name="providerId">provider Id.</param>
        /// <param name="operatorId">operator Id.</param>
        /// <param name="includeReminderEvents"></param>
        /// <param name="spec"></param>
        /// <returns>event details.</returns>
        IEnumerable<AccountabilityEventSearchResult> GetEventsForMap(AccountabilityEventSearchSpec spec);

        AccountabilityEvent GetEvent(AccountabilityEventSpec eventSpec);
        IEnumerable<AccountabilityEventAlert> GetAccountabilityEventAlerts(int eventid, bool includedetails = false);

        /// <summary>
        /// To create the event from template.
        /// </summary>

        /// <param name="operatorId">operatorId.</param>
        /// <param name="providerContext">Provider Context</param>
        /// <param name="actTemplate">accountability template.</param>
        /// <returns>event Id.</returns>
        int CreateEvent(int operatorId, IProviderContext providerContext, AccountabilityTemplate actTemplate);
        

        /// <summary>
        /// To end events.
        /// </summary>
        /// <param name="providerId">provider Id.</param>
        /// <param name="operatorId">operator Id.</param>
        /// <param name="ids">evnet ids.</param>
        /// <returns>true-if end action is successful.</returns>
        bool EndEvents(int providerId, int operatorId, IEnumerable<int> ids);

        /// <summary>
        /// To delete events.
        /// </summary>
        /// <param name="providerId">provider Id.</param>
        /// <param name="operatorId">operator Id.</param>
        /// <param name="ids">event ids.</param>
        /// <returns>true - if deletion is successful.</returns>
        bool DeleteEvents(int providerId, int operatorId, IEnumerable<int> ids);

        /// <summary>
        /// To gets Provider Id  based on Event Id
        /// </summary>
        /// <param name="eventId"></param>
        /// <returns></returns>
        int GetEventProviderId(int providerId, int eventId);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="eventId"></param>
        /// <param name="providerId"></param>
        /// <returns></returns>
        IEnumerable<AccountabilityEventStatusAttribute> GetEventStatusAttributeList(int eventId, int providerId);
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        IQueryable<AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel.AccountabilityEventUserStatusEntity> GetEventUserStatusAttributes();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userStatusList"></param>
        /// <param name="providerId"></param>
        /// <param name="baseLocale"></param>
        /// <returns></returns>
        bool UpdateUsersStatus(UserStatusUpdateSpec userStatusList, int providerId, string baseLocale);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="field"></param>
        /// <param name="systemPlaceholders"></param>
        /// <param name="accountabilityStartDatePlaceHolderDisplayName"></param>
        /// <param name="accountabilityStartDatePlaceHolderValue"></param>
        /// <returns></returns>
        string ReplacePlaceHoldersForPreviewMessage(string field, IEnumerable<PlaceHolder> systemPlaceholders, string accountabilityStartDatePlaceHolderDisplayName,
            string accountabilityStartDatePlaceHolderValue);
      
        /// <summary>Checks if an event is valid.</summary>
        /// <param name="eventId">Event id.</param>
        /// <param name="providerId">Provider Id.</param>
        /// <param name="operatorId">Operator Id.</param>
        /// <returns>True if event is valid.</returns>
        bool CheckEventValidity(int eventId, int providerId, int operatorId,string locale);
        #endregion

        #region Background Job

        /// <summary>
        /// Method to Process Accountability task -Submits the job for Event End, Reminder, Receipient Recompute
        /// </summary>
        /// <param name="jobType"></param>
        /// <param name="enableLog"></param>
        void ProcessAccountabilityJob(AccountabilityEventJobPickupType jobType, bool enableLog = false);

        /// <summary>
        /// Process Accountability Event End task
        /// </summary>
        /// <param name="eventId"></param>
        /// <param name="operatorId"></param>
        void ProcessEventToEnd(int eventId,int operatorId);

        /// <summary>
        /// Process Accountability Event Reminder alert task
        /// </summary>
        /// <param name="eventId"></param>
        /// <param name="operatorId"></param>
        void ProcessReminderAlert(int eventId, int operatorId);

        /// <summary>
        /// Process Accountability Event Start alert task
        /// </summary>
        /// <param name="eventId"></param>
        /// <param name="operatorId"></param>
        void ProcessStartAlert(int eventId, int operatorId);

        /// <summary>
        /// Process Accountability Event - Receipient recomputation task
        /// </summary>
        /// <param name="eventId"></param>
        /// <param name="operatorId"></param>
        void ProcessReceipientRecompute(int eventId, int operatorId);

        void ProcessStatusUpdateAttributes();

        void ProcessEventTrackingSummary(int acctEventId);

        #endregion

        #region Event Summary and Report
        EventStatusModel GetEventStatus(EventStatusSpec spec);

        /// <summary>
        /// Get Session Id - Call this method only if Operator has restricted user base.
        /// </summary>
        /// <param name="spec"></param>
        /// <returns>Session ID Integer</returns>
        //int GetSessionId(EventReporingSpec spec);
        void GetEventStatusByOrg(EventStatusByOrgSpec spec, bool isEnterprise, out List<EventOrganizationReport> data, out List<EventOrganizationHierarchy> hierarchyBreadcrumbNodes);

        /// <summary>
        /// Get Accountability Summary model
        /// </summary>
        /// <param name="eventId">event id</param>
        /// <param name="sliceByDuration">Duration i.e slice by Min,hour,day</param>
        /// <param name="startTime">event start time</param>
        /// <param name="endTime">event endtime</param>
        /// <returns>Object of type AccountabilityEventSummaryModel</returns>
        AccountabilityEventSummaryModel GetEventResponsesOvertime(int eventId, int providerId, int operatorId, string baseLocale, TimeSpan sliceByDuration, DateTime startTime, DateTime endTime);

        /// <summary>
        /// Get accountability search results.
        /// </summary>
        /// <param name="spec">Search specs.</param>
        /// <returns>Search results.</returns>
        IPaged<AccountabilityEventSearchResult> GetAccountabilitySearchResult(AccountabilityEventSearchSpec spec);

        IEnumerable<Tuple<int, IDictionary<int, string>>> GetAccountabilityEventPublishers(int providerId);

        IEnumerable<Tuple<int, IEnumerable<CustomAttribute>>> GetStatusAttibutes(int providerId, string baseLocale);

        IDictionary<int, string> GetSubOrganizationsWithNames(int providerId);

        /// <summary>
        /// Change Event and Associated alert (live) end datetime
        /// </summary>
        /// <param name="eventId">Event Id</param>
        /// <param name="newDate">Updated Date</param>
        /// <param name="providerId">Provider Id</param>
        /// <param name="operatorId">Operator Id</param>
        void ChangeEventEndDate(int eventId, DateTime newDate, int providerId, int operatorId);

        #endregion

        int GetUserSessionId(IProviderContext providerContext, IOperatorContext operatorContext, int[] eventId, bool includeSubVps = true);
    }
}
