﻿using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Entities;
using System;
using System.Collections.Generic;

namespace AtHoc.IWS.Business.Domain.Accountability
{
    public interface IAccountabilityFacadeCache
    {
        IEnumerable<Tuple<int, IDictionary<int, string>>> GetSetEventPublishers(int providerId, Func<IEnumerable<Tuple<int, IDictionary<int, string>>>> getOperatorList);

        int GetSetSessionId(int eventId, int operatorId, Func<int> getValueCallbackFunc);

        IEnumerable<Tuple<int, IEnumerable<CustomAttribute>>> GetSetStatusAttibutes(int providerId, Func<IEnumerable<Tuple<int, IEnumerable<CustomAttribute>>>> getValueCallbackFunc);

        IDictionary<int, string> GetSetSubOrganizations(int providerId, Func<IDictionary<int, string>> getOperatorList);

        IProviderContext GetProviderContext(int providerId, Func<IProviderContext> getValueCallbackFunc);
    }
}
