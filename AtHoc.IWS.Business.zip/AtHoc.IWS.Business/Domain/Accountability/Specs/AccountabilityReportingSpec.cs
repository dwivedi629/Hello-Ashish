﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Accountability.Specs
{   
    public class EventReporingSpec
    {
        public List<int> EventIds { get; set; }
        public int ProviderId { get; set; }
        public int OperatorId { get; set; }
        public string BaseLocale { get; set; }
        public int SessionId { get; set; }
    }

    public class EventStatusSpec : EventReporingSpec
    {        
    }

    public class EventStatusByOrgSpec : EventReporingSpec
    {        
        public int HierarchyId { get; set; }        
    }        
}
