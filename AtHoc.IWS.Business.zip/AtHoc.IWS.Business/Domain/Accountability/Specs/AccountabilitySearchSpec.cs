﻿
namespace AtHoc.IWS.Business.Domain.Accountability.Specs
{
    public class AccountabilitySearchSpec
    {
        public string EventIds { get; set; }
        public string NameString { get; set; }
        public string Severity { get; set; }
        public string Status { get; set; }
        public int OperatorId { get; set; }
        public int AttributeId { get; set; }
        public string VpsIds { get; set; }
        public bool IncludeSubVps { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public int DebugFlag { get; set; }
    }
}
