﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Entity;
using AtHoc.IWS.Business.Domain.Users.Search;

namespace AtHoc.IWS.Business.Domain.Accountability.Specs
{
    public class EventBasedTargetingSpec : EntitySpec
    {
        public EventBasedTargetingSpec()
        {
            IncludeOperatorCriteria = true;
        }

        public int ProviderId { get; set; }
        public int? OperatorId { get; set; }
        public IEnumerable<int> AccountabilityEventId { get; set; }
        public bool IncludeOperatorCriteria { get; set; }
        public EventCriteriaOperator EventCriteriaOperator { get; set; }
        public IEnumerable<string> ResponseList { get; set; }
        public List<string> UserAttributes { get; set; }

    }


}
