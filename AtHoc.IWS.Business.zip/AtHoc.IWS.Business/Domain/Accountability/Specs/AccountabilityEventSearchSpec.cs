﻿
using System.ComponentModel.DataAnnotations;

namespace AtHoc.IWS.Business.Domain.Accountability.Specs
{
    //todo: rename this class, no need to repeat Accountability prefix
    //todo: types should be more specific (EventIds should be int[])
    public class AccountabilityEventSearchSpec
    {
        public AccountabilityEventSearchSpec()
        {
            IncludeSubVps = false;
        }
        [DisplayFormat(ConvertEmptyStringToNull = false)]
        public int[] EventIds { get; set; }
        
        public string[] SearchStrings { get; set; }

        [DisplayFormat(ConvertEmptyStringToNull = false)]
        public int[] Severity { get; set; }

        [DisplayFormat(ConvertEmptyStringToNull = false)]
        public string[] Status { get; set; }

        [DisplayFormat(ConvertEmptyStringToNull = false)]
        public int OperatorId { get; set; }

        [DisplayFormat(ConvertEmptyStringToNull = false)]
        public int[] AttributeId { get; set; }

        [DisplayFormat(ConvertEmptyStringToNull = false)]
        public int ProviderId { get; set; }

        public bool IncludeSubVps { get; set; }

        [DisplayFormat(ConvertEmptyStringToNull = false)]
        public string StartDate { get; set; }

        [DisplayFormat(ConvertEmptyStringToNull = false)]
        public string EndDate { get; set; }

        public int DebugFlag { get; set; }

        public int? Page { get; set; }
        public int PageSize { get; set; }
        public string OrderBy { get; set; }
        public bool OrderAsc { get; set; }

        public int QuickFilterValue { get; set; }
        public string VpsIds { get; set; }
        public string VpsId { get; set; }

    }
}
