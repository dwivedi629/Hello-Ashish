﻿using System;
using AtHoc.Utilities;

namespace AtHoc.IWS.Business.Domain.Accountability.Specs
{
   public  class AccountabilityTemplateSpec
    {
       public AccountabilityTemplateSpec()
       {
           OrderBy = "Name";
           OrderAsc = true;
       }

        public string Name { get; set; }
        public string Description { get; set; }
        public string CommonName { get; set; }
        public string Status { get; set; }
        public int TemplateId { get; set; }
        public int UserBaseAlertId { get; set; }
        public int? OperatorScenarioId { get; set; }
        public int? Page { get; set; }
        public int PageSize { get; set; }
        
        public string OrderBy { get; set; }
        public bool OrderAsc { get; set; }
        public int? OperatorId { get; set; }
        public int ProviderId { get; set; }
        public int? IsArchieved { get; set; }
        public DateTime? DateRangeFrom { get; set; }
        public DateTime? DateRangeTo { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public string Locale { get; set; }
        public string[] SearchStrings { get; set; }
        public Func<DateTime,DateTime> FuncVpsToUtcTime { get; set; } 
    }
}
