﻿using System;
using System.Collections.Generic;
using AtHoc.Infrastructure.Entity;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.Accountability.Specs
{
    public class AccountabilityEventSpec : EntitySpec
    {
        public AccountabilityEventSpec()
        {
            OrderBy = "CreatedOn";
            OrderAsc = false;
            IncludeReminderAlertDetails = false;
            IncludeEventStatistics = false;
        }

        public string Name { get; set; }
        public string Description { get; set; }
        public List<int> EventIds { get; set; }
        public int TemplateId { get; set; }
        public int? OperatorMasterAlertId { get; set; }
        public int? UserMasterAlertId { get; set; }
        public int? Page { get; set; }
       // public new int PageSize { get; set; }
        public string OrderBy { get; set; }
        public bool OrderAsc { get; set; }
        public int? OperatorId { get; set; }
        public int ProviderId { get; set; }
        public bool IsArchieved { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }

        public DateTime? DateRangeFrom { get; set; }
        public DateTime? DateRangeTo { get; set; }
        public int? UpdatedBy { get; set; }
        public bool IsLoadBaseDetails { get; set; }

        public bool IncludeReminderAlertDetails { get; set; }

        //Set to true, if events list need to populate (CountOfUserAffected, CountOfUserWithResponse, CountOfUserWithNoResponse)
        public bool IncludeEventStatistics { get; set; }

        public AccountabilityEventStatus? Status { get; set; }

        public string[] SearchStrings { get; set; }
    }
}
