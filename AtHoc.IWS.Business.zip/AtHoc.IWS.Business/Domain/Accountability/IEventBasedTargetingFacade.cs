﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Domain.Accountability.Specs;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Users.Search;

namespace AtHoc.IWS.Business.Domain.Accountability
{
    public interface IEventBasedTargetingFacade
    {
        ContextSearchResult GetEventBasedTargetingRecipient(EventBasedTargetingSpec eventBasedTargetingSpec);
    }
}
