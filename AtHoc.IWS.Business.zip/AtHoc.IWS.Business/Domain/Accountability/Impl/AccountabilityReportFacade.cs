﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Linq.Dynamic;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Diagnostics;
using AtHoc.Global.Resources;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Accountability.Specs;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel;
using AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel;
using AtHoc.IWS.Business.Domain.Publishing.Impl;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.Systems;
using AtHoc.IWS.Business.Domain.Users.Impl.Search;

namespace AtHoc.IWS.Business.Domain.Accountability.Impl
{
    public partial class AccountabilityFacade
    {


        public int GetUserSessionId(IProviderContext providerContext, IOperatorContext operatorContext, int[] eventIds, bool includeSubVps = true)
        {
            var durationcache = AtHocSystem.Local.Configuration.GetValue("ACCT_RECIPIENT_DB_CACHE_EXPIRY_TIME");
            int sessionDuration = 0;
            if (!string.IsNullOrEmpty(durationcache))
            {
                if (!int.TryParse(durationcache, out sessionDuration))
                {
                    EventLogger.WriteWarning("ACCT_RECIPIENT_DB_CACHE_EXPIRY_TIME key is missing from GLB_CONFIG_KEY");
                }
            }


            var ebtCriteria = new EventBasedCriteria(eventIds, EventCriteriaOperator.TARGETED);
            var criteria = ebtCriteria.ToSearchCriterias();
            var alertAdapter = new AlertAdapter();
            var srchArgs = alertAdapter.GetUserSearchArgs(criteria, providerContext.ProviderId, providerContext.BaseLocale, operatorContext.OperatorId, includeSubVps,true);
            srchArgs.Options.EnableSession = true;
            srchArgs.Options.GetUsers = true;
            srchArgs.Options.GetCountsOnly = true;
            srchArgs.Options.ReuseSessionDuration = sessionDuration; //5 Min session caching time. 
            // For Enterprise with subvps
            if (operatorContext.ProviderId>0 && operatorContext.ProviderId != providerContext.ProviderId)
                srchArgs.OperatorCriteria = UserSearchHelper.GetOperatorUserBaseCriteria(operatorContext.OperatorId,
                  operatorContext.ProviderId);
            var sUser = _userFacade.SearchUsersByContext(srchArgs);
            if (sUser.SessionId == 0)
            {
                EventLogger.WriteWarning("Session Id cannot be null, if operator has restriced user base.");
            }
            return sUser.SessionId;
        }
        public EventStatusModel GetEventStatus(EventStatusSpec spec)
        {

            var providerContext = new ProviderContext();
            providerContext.ProviderId = spec.ProviderId;
            providerContext.BaseLocale = spec.BaseLocale;

            var operatorContext = new OperatorContext();
            operatorContext.OperatorId = spec.OperatorId;

            
            var resultSet = new AccountabilityReportModel();
            var isRestricted = _userFacade.HasRestrictedUserBase(spec.OperatorId);
            if (spec.SessionId == 0 || !_userFacade.IsUserSearchSessionValid(spec.SessionId))
            {
                var userSearchSessionId = GetUserSessionId(providerContext, operatorContext, spec.EventIds.ToArray());
                spec.SessionId = userSearchSessionId;

            }
            int totalUserCount;
            int totalAffectedUsersCount;


           
            var entitymodels = _accountabilityRepository.GetEventStatusTracking(spec.EventIds[0], spec.SessionId, "Status", "UpdatedFrom", out totalUserCount, out totalAffectedUsersCount);
            resultSet.StatusTrackingModels = entitymodels;
            resultSet.StatusTrackingModelsTotalUsers = totalUserCount;

            var status = resultSet;

            EventStatusModel model = new EventStatusModel()
            {
                EventIds = spec.EventIds,
                SessionId = status.SessionId,
                TotalResponses = new EventStatusEntryModel() { ResponseId = 0 }

            };

            //set the total number of users of event.
            model.TotalUsers = status.StatusTrackingModelsTotalUsers;
            model.TotalAffectedUsers = totalAffectedUsersCount;
            model.IsRestricted = isRestricted;
            // now build the model            
            Dictionary<int, EventStatusEntryModel> responseModels = new Dictionary<int, EventStatusEntryModel>();
            //get response option names
            var responseOptions = GetEventStatusAttributeList(spec.EventIds[0], spec.ProviderId).ToList();
            foreach (var response in responseOptions)
            {
                responseModels.Add(response.SortOrder, new EventStatusEntryModel()
                {
                    ResponseId = response.SortOrder,
                    ResponsesByOperator = 0,
                    Responses = 0,
                    ResponsesByUser = 0,
                    StatusAttribute = response
                });
            }

            foreach (var trackingModel in status.StatusTrackingModels)
            {
                int responseId;
                if (!int.TryParse(trackingModel.GroupBy.ToString(), out responseId))
                {
                    throw new Exception(IWSResources.PA_Event_EventStatusTrack_Fail_Error_Message);
                }

                bool isOperator = "Operator".Equals(trackingModel.SubGroupBy.ToString(), StringComparison.InvariantCultureIgnoreCase);
                //bool isUser = "Self".Equals(trackingModel.SubGroupBy.ToString(), StringComparison.InvariantCultureIgnoreCase) || "Alert Tracking".Equals(trackingModel.SubGroupBy.ToString(), StringComparison.InvariantCultureIgnoreCase);
                bool isUser = !isOperator;

                EventStatusEntryModel entry = null;
                if (responseId == 0)
                {
                    // 0 represent the Total number of No Response
                    var noResponseTotal = trackingModel.UsersCount;
                    model.TotalResponses.Responses = model.TotalUsers - noResponseTotal;
                }
                else
                {
                    if (!responseModels.TryGetValue(responseId, out entry))
                    {
                        throw new Exception(string.Format("Failed to load resposne statsus, response {0} was not found in model", responseId));
                    }
                    // now set the value               
                    if (isUser)
                    {
                        entry.ResponsesByUser += trackingModel.UsersCount;
                    }
                    else
                    {
                        entry.ResponsesByOperator += trackingModel.UsersCount;
                    }
                }
            }

            var totalResponses = 0;
            var totalResponsesByUser = 0;
            var totalResponsesByOperator = 0;
            foreach (var entry in responseModels.Values)
            {
                entry.Responses = entry.ResponsesByOperator + entry.ResponsesByUser;
                totalResponses += entry.Responses;
                totalResponsesByUser += entry.ResponsesByUser;
                totalResponsesByOperator += entry.ResponsesByOperator;
            }

            model.TotalResponses.Responses = totalResponses;
            model.TotalResponses.ResponsesByOperator = totalResponsesByOperator;
            model.TotalResponses.ResponsesByUser = totalResponsesByUser;
            if (model.TotalResponses.Responses != totalResponses)
            {
                // this is just another checksum test.
                EventLogger.WriteError(string.Format("Mismatch total responses: sum of all response by id: {0} while SP return {1}", totalResponses, model.TotalResponses.Responses));
            }
            model.StatusByResponse = responseModels.Values.ToList();
            return model;
        }

        public void GetEventStatusByOrg(EventStatusByOrgSpec spec, bool isEnterprise, out List<EventOrganizationReport> data, out List<EventOrganizationHierarchy> hierarchyBreadcrumbNodes)
        {
            var eventOrganizationReportEntries = new List<EventOrganizationReport>();
            var hierarchy = new List<EventOrganizationHierarchy>();

            //var isRestricted = _userFacade.HasRestrictedUserBase(spec.OperatorId);

            if (spec.SessionId == 0 || !_userFacade.IsUserSearchSessionValid(spec.SessionId))
            {
                var providerContext = new ProviderContext { BaseLocale = spec.BaseLocale, ProviderId = spec.ProviderId };
                var operatorContext = new OperatorContext { OperatorId = spec.OperatorId };
                spec.SessionId = GetUserSessionId(providerContext, operatorContext, spec.EventIds.ToArray());
               
            }

            var entitymodels = _accountabilityRepository.GetEventStatusTrackingByOrg(spec.EventIds[0], spec.SessionId, isEnterprise, spec.ProviderId);
            var hierarchyModel = entitymodels.ToList();

            var nodeLevelHierarchy = new List<AccountabilityEventStatusTrackingByOrgReportModel>();

            if (spec.HierarchyId != 0)
            {
                var childList = new List<AccountabilityEventStatusTrackingByOrgReportModel>();
                var parentList = new List<AccountabilityEventStatusTrackingByOrgReportModel>();
                var originalRoot = hierarchyModel.First(or => or.OrgPath.Equals("/"));
                var root = new AccountabilityEventStatusTrackingByOrgReportModel();
                root.Org = originalRoot.Org;
                root.OrgId = 0;
                root.OrgPath = originalRoot.OrgPath;
                root.ParentNode = originalRoot.ParentNode;
                root.ParentNodeId = originalRoot.ParentNodeId;
                root.SeqId = originalRoot.SeqId;
                root.Status = originalRoot.Status;
                root.TreeDepth = originalRoot.TreeDepth;
                root.TreeDepthFromLeaf = originalRoot.TreeDepthFromLeaf;
                root.UsersCount = originalRoot.UsersCount;
                parentList.Add(root);
                parentList.First().OrgId = 0;
                childList.AddRange(hierarchyModel.Where(h => h.OrgId == spec.HierarchyId));
                GetChildren(spec.HierarchyId, hierarchyModel, ref childList);
                GetNodeLevelHierarchy(spec.HierarchyId, hierarchyModel, ref parentList);
                parentList.Add(hierarchyModel.First(h => h.OrgId == spec.HierarchyId));
                hierarchyModel = childList;
                nodeLevelHierarchy = parentList;
            }

            #region Add data for UI model

            hierarchyModel.ForEach(hierarchyNode =>
            {
                if (!eventOrganizationReportEntries.Any(d => d.Id == hierarchyNode.OrgId))
                {
                    eventOrganizationReportEntries.Add(new EventOrganizationReport
                    {
                        Id = hierarchyNode.OrgId,
                        Name = hierarchyNode.Org,
                        ParentId = hierarchyNode.ParentNodeId.Value,
                        HasChildren = hierarchyModel.Select(h => h.ParentNodeId).Contains(hierarchyNode.OrgId),
                        Depth = hierarchyNode.TreeDepth,
                        SortOrder = hierarchyNode.SeqId
                    });
                }

                var item = eventOrganizationReportEntries.First(d => d.Id == hierarchyNode.OrgId);
                CalculateUserStatus(hierarchyNode.Status.ToString(), hierarchyNode.UsersCount, ref item);
            });

            CalculateParentNodeUserStatus(ref eventOrganizationReportEntries);

            //Removing leaf nodes with 0 user count.
            data = eventOrganizationReportEntries.Where(node => node.TotalCount > 0).ToList();

            //Showing only two levels
            var depth = data.OrderBy(d => d.Depth).First().Depth;
            data = data.Where(d => d.Depth <= depth + 2).ToList();

            if (spec.HierarchyId != 0)
            {
                data.First(d => d.Id == spec.HierarchyId).ParentId = 0;
            }

            // Add agreetated row for total users in case of VPS hierarchy
            if (isEnterprise && data.All(x => x.ParentId == 1))
            {
                var totalRow = new EventOrganizationReport();
                totalRow.Depth = 1;
                totalRow.HasChildren = true;
                totalRow.Id = 1;
                totalRow.Name = IWSResources.AtHoc_User_Search_AllUsers;
                totalRow.ParentId = 0;
                totalRow.TotalCount = data.Select(x => x.TotalCount).Aggregate((a, b) => a + b);
                totalRow.ResponseValues = GetTotalCount(data.Select(x => x.ResponseValues));
                totalRow.SortOrder = 0;
                data.Add(totalRow);
            }

            #endregion

            #region Add hierarchy for breadcrumb

            if (nodeLevelHierarchy.Any())
            {
                nodeLevelHierarchy.ForEach(h => hierarchy.Add(new EventOrganizationHierarchy
                {
                    Id = h.OrgId.ToString(CultureInfo.InvariantCulture),
                    Name = h.Org
                }));

                hierarchyBreadcrumbNodes = (hierarchy.Select(h => new
                {
                    h.Id,
                    h.Name
                })).Distinct().Select(x => new EventOrganizationHierarchy
                {
                    Id = x.Id,
                    Name = x.Name
                }).ToList();
            }
            else
            {
                hierarchyBreadcrumbNodes = new List<EventOrganizationHierarchy>();
            }

            #endregion
        }

        private Dictionary<string, int> GetTotalCount(IEnumerable<Dictionary<string, int>> responseValues)
        {
            var totalCount = new Dictionary<string, int>();

            foreach (var responseValue in responseValues)
            {
                foreach (var statusResponse in responseValue)
                {
                    if (totalCount.ContainsKey(statusResponse.Key))
                    {
                        totalCount[statusResponse.Key] += statusResponse.Value;
                    }
                    else
                    {
                        totalCount.Add(statusResponse.Key, statusResponse.Value);
                    }
                }
            }

            return totalCount;
        }

        private void GetNodeLevelHierarchy(int id,
            List<AccountabilityEventStatusTrackingByOrgReportModel> hierarchyModel,
            ref List<AccountabilityEventStatusTrackingByOrgReportModel> list)
        {
            var item = hierarchyModel.First(h => h.OrgId == id);
            var parent = hierarchyModel.First(h => h.OrgId == item.ParentNodeId);

            if (parent.ParentNodeId != 0)
            {
                list.Add(parent);
                GetNodeLevelHierarchy(parent.OrgId, hierarchyModel, ref list);
            }
        }

        private void GetChildren(int id,
            List<AccountabilityEventStatusTrackingByOrgReportModel> hierarchyModel,
            ref List<AccountabilityEventStatusTrackingByOrgReportModel> list)
        {
            foreach (var item in hierarchyModel)
            {
                if (item.ParentNodeId == id)
                {
                    if (!list.Contains(item))
                    {
                        list.Add(item);
                    }

                    GetChildren(item.OrgId, hierarchyModel, ref list);
                }
            }
        }

        /// <summary>Calculate response for the hierarchy.</summary>
        /// <param name="list">Hierarchy list.</param>
        private void CalculateParentNodeUserStatus(ref List<EventOrganizationReport> list)
        {
            foreach (var leaf in list)
            {
                if (leaf.ResponseValues != null)
                {
                    foreach (var status in leaf.ResponseValues)
                    {
                        CalculateResponseCount(leaf.ParentId, status, ref list);
                    }
                }
            }
        }

        /// <summary>Calculate response for the parent.</summary>
        /// <param name="leafParentId">Id of parent node.</param>
        /// <param name="status">User status.</param>
        /// <param name="list">Hierarchy List.</param>
        private void CalculateResponseCount(int leafParentId, KeyValuePair<string, int> status,
            ref List<EventOrganizationReport> list)
        {
            var statusKey = status.Key.ToString();

            if (list.Any(l => l.Id == leafParentId))
            {
                var leafParent = list.First(l => l.Id == leafParentId);

                if (leafParent.ResponseValues.ContainsKey(statusKey))
                    leafParent.ResponseValues[statusKey] += status.Value;
                else if (leafParent.ResponseValues != null)
                    leafParent.ResponseValues.Add(status.Key.ToString(), status.Value);
                else
                    leafParent.ResponseValues = new Dictionary<string, int> { { statusKey, status.Value } };

                leafParent.TotalCount += status.Value;
                CalculateResponseCount(leafParent.ParentId, status, ref list);
            }
        }

        /// <summary>Calculates User Status for initial hierarchy nodes.</summary>
        /// <param name="status">Status.</param>
        /// <param name="userCount">Count of users.</param>
        /// <param name="item">Hierarchy node.</param>
        /// <returns></returns>
        private void CalculateUserStatus(string status, int userCount, ref EventOrganizationReport item)
        {
            if (item.ResponseValues == null)
                item.ResponseValues = new Dictionary<string, int> { { status, userCount } };
            else if (item.ResponseValues.ContainsKey(status))
                item.ResponseValues[status] += userCount;
            else
                item.ResponseValues.Add(status, userCount);

            item.TotalCount += userCount;
        }

        #region Responses Overtime



        
        /// <summary>
        /// Get Accountability Summary model
        /// </summary>
        /// <param name="eventId">event id</param>
        /// <param name="baseLocale"></param>
        /// <param name="sliceByDuration">Duration i.e slice by Min,hour,day</param>
        /// <param name="startTime">event start time</param>
        /// <param name="endTime">event endtime</param>
        /// <param name="providerId"></param>
        /// <param name="operatorId"></param>
        /// <returns>Object of type AccountabilityEventSummaryModel</returns>
        public AccountabilityEventSummaryModel GetEventResponsesOvertime(int eventId, int providerId, int operatorId, string baseLocale, TimeSpan sliceByDuration, DateTime startTime, DateTime endTime)
        {

            int[] userIds = new int[] { };
            if (_userFacade.HasRestrictedUserBase(operatorId))
            {
                var usersByUbp = GetReceipientsByUserBasedPermission(eventId, providerId, operatorId, baseLocale);
                userIds = usersByUbp.Select(e => e.Id).ToArray();
            }

            var timeSpanMarkerSet = GetEventOvertime(sliceByDuration, startTime, endTime);
            var eventSummaryModel = new AccountabilityEventSummaryModel();
            eventSummaryModel.EventSummaryUserWithResponseCountModel = GetEventSummaryUserWithResponseCountModel(eventId, userIds, timeSpanMarkerSet);
            return eventSummaryModel;
        }

        private IEnumerable<UserSearchResultItem> GetReceipientsByUserBasedPermission(int eventId, int providerId, int operatorId, string baseLocale)
        {
            var ebtCriteria = new EventBasedCriteria(new[] { eventId }, EventCriteriaOperator.TARGETED);
            var criteria = ebtCriteria.ToSearchCriterias();
            var alertAdapter = new AlertAdapter();
            var srchArgs = alertAdapter.GetUserSearchArgs(criteria, providerId, baseLocale, operatorId);
            srchArgs.Options.EnableSession = false;
            srchArgs.Options.GetUsers = true;
            var sUser = _userFacade.SearchUsersByContext(srchArgs);
            return sUser.Users;
        }
        private List<AccountabilityEventSummaryUserWithResponseCountModel> GetEventSummaryUserWithResponseCountModel(int eventId, int[] userIds, IEnumerable<Tuple<DateTime, DateTime, string>> timeSpanMarkerSet)
        {
            var resultSet = new List<AccountabilityEventSummaryUserWithResponseCountModel>();
            var entity = _accountabilityRepository.GetEventRecipients(eventId);
            List<AccountabilityEventRecipientBase> filteredEntity;
            if (userIds != null && userIds.Length > 0)
            {
                filteredEntity = entity.Where(e => userIds.Contains(e.UserId)).ToList();
            }
            else
            {
                filteredEntity = entity.ToList();
            }
            foreach (var tuple in timeSpanMarkerSet)
            {
                var stTime = tuple.Item1;
                var edTime = tuple.Item2;
                var userCount = filteredEntity.Count(e => e.StatusUpdatedOn.HasValue && e.StatusUpdatedOn >= stTime && e.StatusUpdatedOn <= edTime);
                var userWithResponse = new AccountabilityEventSummaryUserWithResponseCountModel();
                userWithResponse.GroupStartTime = stTime; //Start Time
                userWithResponse.GroupEndTime = edTime; //End Time
                userWithResponse.GroupName = tuple.Item3; //Group name
                userWithResponse.UserCount = userCount;

                resultSet.Add(userWithResponse);
            }
            return resultSet;
        }

        private static IEnumerable<Tuple<DateTime, DateTime, string>> GetEventOvertime(TimeSpan sliceByduration, DateTime startTime, DateTime endTime)
        {
            var setOfEventOvertime = new HashSet<Tuple<DateTime, DateTime, string>>();
            if (sliceByduration < TimeSpan.FromSeconds(1))
            {
                EventLogger.WriteError(string.Format("Can't calculate GetEventOvertime, bad sliceByduration parameter, value is less than a sec {0}", sliceByduration));
                return setOfEventOvertime;
            }
            if (endTime < startTime)
            {
                EventLogger.WriteError(string.Format("startTime can't be later than the end time"));
                return setOfEventOvertime;
            }

            var _startTime = startTime;
            var _endTime = startTime + sliceByduration;

            if (sliceByduration.TotalSeconds * 100 < (endTime - _endTime).TotalSeconds)
            {
                // we can't have more than 100 slices
                EventLogger.WriteError(string.Format("slice can't be more than 100th of the time diff"));
                return setOfEventOvertime;
            }

            while (_endTime <= endTime)
            {
                var groupName = string.Format("{0} {1}", _startTime.ToLongDateString(), _startTime.ToLongTimeString());
                setOfEventOvertime.Add(new Tuple<DateTime, DateTime, string>(_startTime, _endTime, groupName));
                _startTime += sliceByduration;
                _endTime += sliceByduration;
            }
            return setOfEventOvertime;
        }

        private IQueryable<AccountabilityEventEntity> ApplyFiltersToEventEntities(IQueryable<AccountabilityEventEntity> events, AccountabilityEventSpec eventSpec)
        {
            //Filter by Provider Id
            if (eventSpec.ProviderId > 0)
            {
                events = events.Where(e => e.ProviderId == eventSpec.ProviderId);
            }

            //Filter by status
            if (eventSpec.Status.HasValue)
            {
                events = events.Where(e => e.Status == eventSpec.Status.ToString());
            }

            if (!eventSpec.Status.HasValue)
            {
                var actStr = AccountabilityEventStatus.Deleted.ToString();
                // Filter deleted events
                events = events.Where(e => (!actStr.Equals(e.Status)));

            }

            if (eventSpec.SearchStrings != null && eventSpec.SearchStrings.Any())
            {
                events = events.Where(e => eventSpec.SearchStrings.All(s => e.Name.Contains(s) || e.Description.Contains(s)));
            }

            if (eventSpec.DateRangeFrom.HasValue)
            {
                var tempFrom = DateTime.SpecifyKind(eventSpec.DateRangeFrom.Value, DateTimeKind.Unspecified);
                DateTime? dtFrom = RuntimeContext.Provider.VpsToUtcTime(tempFrom);
                events = events.Where(e => (e.CreatedOn >= dtFrom.Value));
            }
            if (eventSpec.DateRangeTo.HasValue)
            {
                var tempTo = DateTime.SpecifyKind(eventSpec.DateRangeTo.Value, DateTimeKind.Unspecified);
                DateTime? dtTo = RuntimeContext.Provider.VpsToUtcTime(tempTo);
                events = events.Where(e => (e.CreatedOn <= dtTo.Value));
            }
            return events;
        }
        private IQueryable<AccountabilityEventEntity> ApplySortingAndPagingToEventEntities(IQueryable<AccountabilityEventEntity> events, AccountabilityEventSpec eventSpec)
        {
            if (!string.IsNullOrEmpty(eventSpec.OrderBy))
            {
                if (string.Equals(eventSpec.OrderBy, "StartedByName", StringComparison.OrdinalIgnoreCase))
                {
                    eventSpec.OrderBy = "PublishedByUserName";
                }

                string orderbystring = (eventSpec.OrderAsc
                       ? string.Format("{0} ASC ", eventSpec.OrderBy)
                       : string.Format("{0} DESC", eventSpec.OrderBy));

                events = events.OrderBy(orderbystring);
            }

            if (eventSpec.Page.HasValue)
            {
                events = eventSpec.Page.Value == 1 ? events.Take(eventSpec.PageSize) : events.Skip((eventSpec.Page.Value - 1) * eventSpec.PageSize).Take(eventSpec.PageSize);
            }



            return events;
        }
        #endregion
    }
}
