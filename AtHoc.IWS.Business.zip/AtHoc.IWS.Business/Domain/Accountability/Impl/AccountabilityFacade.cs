﻿using System.Web.Script.Serialization;
using AtHoc.Data;
using AtHoc.Diagnostics;
using AtHoc.Global.Resources;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Log;
using AtHoc.IWS.Business.Common.Interface;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Data.SearchSpec;
using AtHoc.IWS.Business.Domain.Accountability.Specs;
using AtHoc.IWS.Business.Domain.Audit;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.IWS.Business.Domain.Devices;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel;
using AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Business.Domain.Publishing.Impl;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Settings.Impl;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Business.Domain.VirtualSystem;
using AtHoc.Operators;
using AtHoc.Publishing;
using AtHoc.Publishing.Configuration;
using AtHoc.Publishing.Interfaces;
using AtHoc.Systems;
using AtHoc.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Linq.Dynamic;
using System.Text;
using Newtonsoft.Json;
using OperationAuditor = AtHoc.IWS.Business.Domain.Audit.OperationAuditor;


namespace AtHoc.IWS.Business.Domain.Accountability.Impl
{
    public partial class AccountabilityFacade : IAccountabilityFacade
    {
        #region template metohds
        private readonly IAccountabilityRepository _accountabilityRepository;
        private readonly IUserFacade _userFacade;
        private readonly IAlertFacade _alertFacade;
        private readonly IScenarioFacade _scenarioFacade;
        private readonly IDeviceFacade _deviceFacade;
        private readonly ICustomAttributeFacade _customAttributeFacade;
        private readonly ICustomAttributeCache _customAttributeCache;
        public readonly IPlaceHolderFacade _placeholderFacade;
        private readonly ILogService _logService;
        private readonly IAccountabilityFacadeCache _accountabilityFacadeCache;
        private readonly IVirtualSystemFacade _virtualSystemFacade;
        private readonly ILanguageFacade _languageFacade;
        private bool _isLogInformationEnable;
        private string _logInfoContent;

        # region Constructor
        public AccountabilityFacade(IAccountabilityRepository accountabilityRepository, IAlertFacade alertFacade,
            IUserFacade userFacade, IScenarioFacade scenarioFacade, IDeviceFacade deviceFacade,
            ICustomAttributeFacade customAttributeFacade, IPlaceHolderFacade placeholderFacade,
            ICustomAttributeCache customAttributeCache, IAccountabilityFacadeCache accountabilityFacadeCache, IVirtualSystemFacade virtualSystemFacade, ILanguageFacade languageFacade)
        {
            _accountabilityRepository = accountabilityRepository;
            _alertFacade = alertFacade;
            _userFacade = userFacade;
            _scenarioFacade = scenarioFacade;
            _deviceFacade = deviceFacade;
            _customAttributeFacade = customAttributeFacade;
            _placeholderFacade = placeholderFacade;
            _customAttributeCache = customAttributeCache;
            _accountabilityFacadeCache = accountabilityFacadeCache;
            _virtualSystemFacade = virtualSystemFacade;
            _languageFacade = languageFacade;
        }
        #endregion


        /// <summary>
        /// To get templates.
        /// </summary>
        /// <param name="templateSpec">template spec.</param>
        /// <param name="operatorId">operator Id.</param>
        /// <param name="isLoadBase">is load base details.</param>
        /// <returns>templates.</returns>
        public IEnumerable<AccountabilityTemplate> GetTemplates(int operatorId, AccountabilityTemplateSpec templateSpec, bool isLoadBase)
        {
            var actStr = AccountabilityTemplateStatus.Active.GetDescription();


            var templates = _accountabilityRepository.GetTemplates().Where(a => a.ShowInUi == "Y");

            // show only active
            templates = templates.Where(e => (actStr.Equals(e.Status, StringComparison.InvariantCultureIgnoreCase)));

            if (templateSpec.ProviderId > 0)
            {
                templates = templates.Where(e => e.ProviderId == templateSpec.ProviderId);
            }

            // search by name or description
            if (templateSpec.SearchStrings != null && templateSpec.SearchStrings.Any())
            {
                templates = templates.Where(e => templateSpec.SearchStrings.All(s => e.Name.Contains(s) || e.Description.Contains(s)));
            }

            if (!string.IsNullOrEmpty(templateSpec.CommonName))
            {
                templates = templates.Where(e => e.CommonName == templateSpec.CommonName);
            }


            if (templateSpec.DateRangeFrom.HasValue)
            {
                var tempFrom = DateTime.SpecifyKind(templateSpec.DateRangeFrom.Value, DateTimeKind.Unspecified);
                DateTime? dtFrom = templateSpec.FuncVpsToUtcTime(tempFrom);
                templates = templates.Where(e => (e.CreatedOn >= dtFrom.Value));
            }
            if (templateSpec.DateRangeTo.HasValue)
            {
                var tempTo = DateTime.SpecifyKind(templateSpec.DateRangeTo.Value, DateTimeKind.Unspecified);
                DateTime? dtTo = templateSpec.FuncVpsToUtcTime(tempTo);
                templates = templates.Where(e => (e.CreatedOn <= dtTo.Value));
            }

            if (!string.IsNullOrEmpty(templateSpec.OrderBy))
            {
                string orderbystring = (templateSpec.OrderAsc
                       ? string.Format("{0} ASC ", templateSpec.OrderBy)
                       : string.Format("{0} DESC", templateSpec.OrderBy));
                templates = templates.OrderBy(orderbystring);
            }

            if (templateSpec.Page.HasValue)
            {
                templates = templates.Skip((templateSpec.Page.Value - 1) * templateSpec.PageSize);
            }

            var list = new List<AccountabilityTemplate>();
            foreach (var template in templates.ToList())
            {
                var templateDetails = new AccountabilityTemplate()
                {
                    AlertId = template.UserAlertBaseId,
                    ProviderId = template.ProviderId
                };
                templateDetails.FromEntity(template);

                if (isLoadBase)
                {
                    var alertBaseMgr = new AlertBaseManager(templateSpec.ProviderId, operatorId);
                    alertBaseMgr.DeserializeAlertSpecification(templateDetails);
                }
                list.Add(templateDetails);
            }


            ResolveTemplateUserNames(list);


            return list;
        }


        /// <summary>
        /// To get the template.
        /// </summary>
        /// <param name="templateId">template Id.</param>
        /// <param name="providerId">provider Id.</param>
        /// <param name="operatorId">operator Id.</param>
        /// <returns>template details.</returns>
        public AccountabilityTemplate GetTemplate(int providerId, int operatorId, int templateId)
        {
            bool isNewTemplate = templateId == 0;
            var alertBaseMgr = new AlertBaseManager(providerId, operatorId);
            try
            {
                AccountabilityTemplateEntity acctTemplate = null;
                if (isNewTemplate)
                {
                    acctTemplate = _accountabilityRepository.GetTemplates().FirstOrDefault(t => t.ProviderId == providerId && t.CommonName == "ACCOUNT-BASE");
                }
                else
                {
                    acctTemplate = _accountabilityRepository.GetTemplates().FirstOrDefault(t => t.ProviderId == providerId && t.TemplateId == templateId);
                }

                if (acctTemplate == null)
                {
                    EventLogger.WriteError(string.Format("Accountability Template not found. TemplateId={0},ProviderId={1}, IsNew={2}", templateId, providerId, isNewTemplate));
                    return null;
                }

                var templateDetails = new AccountabilityTemplate
                {
                    AlertId = acctTemplate.UserAlertBaseId,
                    ProviderId = acctTemplate.ProviderId
                };

                alertBaseMgr.DeserializeAlertSpecification(templateDetails);
                //Operator alert Base 
                if (acctTemplate.OperatorAlertBaseId != null && acctTemplate.OperatorAlertBaseId > 0)
                {
                    templateDetails.OperatorAlertBase = new AccountabilityAlertBase { AlertId = (int)acctTemplate.OperatorAlertBaseId };
                    alertBaseMgr.DeserializeAlertSpecification(templateDetails.OperatorAlertBase);
                }

                templateDetails.FromEntity(acctTemplate);
                templateDetails.RecipientRefreshIntervalDuration = templateDetails.RecipientRefreshIntervalDuration ??
                                                                   GetDefaultRecipientRefreshInterval();

                var templateList = new List<AccountabilityTemplate> { templateDetails };
                if (isNewTemplate)
                {
                    templateDetails.CreatedBy = 0;
                    templateDetails.UpdatedBy = 0;
                    templateDetails.UpdatedOn = DateTime.MinValue;
                    templateDetails.CreatedOn = DateTime.MinValue;
                    templateDetails.TemplateId = 0;
                    templateDetails.CommonName = string.Empty;

                }
                else
                {
                    ResolveTemplateUserNames(templateList);
                }

                return templateDetails;
            }

            catch (Exception ex)
            {
                EventLogger.WriteError(ex);
                return null;
            }
        }


        /// <summary>
        /// To create the template.
        /// </summary>
        /// <param name="templateDetails">template details.</param>
        /// <param name="operatorId">operator Id.</param>
        /// <returns>templte Id.</returns>
        public int CreateTemplate(int operatorId, AccountabilityTemplate templateDetails)
        {
            var alertBaseMgr = new AlertBaseManager(templateDetails.ProviderId, operatorId);
            try
            {
                templateDetails.Status = AccountabilityTemplateStatus.Active.GetDescription();
                templateDetails.UpdatedBy = operatorId;
                templateDetails.UpdatedOn = DateTimeConverter.GetSystemTime(); //save DB time
                templateDetails.CreatedBy = operatorId;
                templateDetails.CreatedOn = DateTimeConverter.GetSystemTime(); //save DB time
                if (templateDetails.RecipientRefreshIntervalDuration == null || templateDetails.RecipientRefreshIntervalDuration.Value <= 0)
                {
                    templateDetails.RecipientRefreshIntervalDuration = GetDefaultRecipientRefreshInterval(); //Set default 2 Min.
                }

                if (string.IsNullOrEmpty(templateDetails.CommonName))
                {
                    templateDetails.CommonName = Guid.NewGuid().ToString();
                }

                using (var ngadDb = new NgadDatabase())
                {

                    // we need to save the scenario settings as well
                    int publishLayoutConfigId = PublishLayoutConfiguration.Save(templateDetails.PublishLayoutConfig);
                    templateDetails.AlertId = 0;//make sure to create new alert base
                    alertBaseMgr.SerializeAlertSpecification(templateDetails, ngadDb);

                    //Supervisor Alert 
                    //if (templateDetails.OperatorAlertBaseId != null && templateDetails.OperatorAlertBase != null)
                    if (templateDetails.OperatorAlertBase != null)
                    {
                        templateDetails.OperatorAlertBase.AlertId = 0;//make sure to create new alert base
                        alertBaseMgr.SerializeAlertSpecification(templateDetails.OperatorAlertBase, ngadDb);
                    }

                }
                var templateEntity = templateDetails.ToEntity();
                var templateId = _accountabilityRepository.CreateTemplate(templateEntity);

                //Make an audit log entry
                var auditSpec = new AuditSpec(operatorId, templateDetails.ProviderId)
                {
                    Action = ServiceAction.AccountabilityTemplateCreated,
                    ObjectType = EntityType.AccountabilityTemplate,
                    ObjectName = templateEntity.Name,
                    ObjectIds = new List<int>() { templateId }
                };
                OperationAuditor.LogAction(auditSpec);

                return templateId;
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Error while creating accountability Template", ex);
                return -1;
            }
        }

        /// <summary>
        /// To update the template.
        /// </summary>
        /// <param name="templateDetails">template details.</param>
        /// <param name="operatorId">operator Id.</param>
        /// <returns>accountability template.</returns>
        public bool UpdateTemplate(int operatorId, AccountabilityTemplate templateDetails)
        {
            if (templateDetails.RecipientRefreshIntervalDuration == null || templateDetails.RecipientRefreshIntervalDuration.Value <= 0)
            {
                templateDetails.RecipientRefreshIntervalDuration = GetDefaultRecipientRefreshInterval(); //Set default 2 Min.
            }

            var alertBaseMgr = new AlertBaseManager(templateDetails.ProviderId, operatorId);
            try
            {
                PublishLayoutConfiguration.Save(templateDetails.PublishLayoutConfig);
                templateDetails.UpdatedBy = operatorId;
                templateDetails.UpdatedOn = DateTimeConverter.GetSystemTime();
                using (var ngadDb = new NgadDatabase())
                {
                    alertBaseMgr.SerializeAlertSpecification(templateDetails, ngadDb);

                    if (templateDetails.OperatorAlertBase != null)
                    {

                        alertBaseMgr.SerializeAlertSpecification(templateDetails.OperatorAlertBase, ngadDb);
                    }
                }
                var templateEntity = templateDetails.ToEntity();
                var updateOperationResult = _accountabilityRepository.UpdateTemplate(templateEntity);

                if (updateOperationResult)
                {
                    //Make an audit log entry
                    var auditSpec = new AuditSpec(operatorId, templateDetails.ProviderId)
                    {
                        Action = ServiceAction.AccountabilityTemplateUpdated,
                        ObjectType = EntityType.AccountabilityTemplate,
                        ObjectName = templateDetails.Name,
                        ObjectIds = new List<int>() { templateDetails.TemplateId }
                    };
                    OperationAuditor.LogAction(auditSpec);
                }

                return updateOperationResult;
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Error while updating Accountability Template", ex);
                return false;
            }
        }

        /// <summary>
        /// Duplicate the template.
        /// </summary>
        /// <param name="templateId">template Id.</param>
        /// <param name="providerId">provider Id.</param>
        /// <param name="operatorId">operator Id.</param>
        /// <returns>accountability template.</returns>
        public AccountabilityTemplate DuplicateTemplate(int providerId, int operatorId, int templateId)
        {
            if (templateId == 0)
            {
                throw new ArgumentNullException("templateId", string.Format(IWSResources.PA_Template_Duplicate_ID_ZERO_Error_Message));
            }

            var alertBaseMgr = new AlertBaseManager(providerId, operatorId);
            try
            {
                //IQueryable of Templates
                var templates = _accountabilityRepository.GetTemplates();
                if (templates == null)
                {
                    throw new Exception(IWSResources.PA_Template_Duplicate_IQInstance_Null_Error_Message);
                }

                var acctTemplate = templates.FirstOrDefault(t => t.ProviderId == providerId && t.TemplateId == templateId);
                if (acctTemplate == null)
                {
                    throw new Exception(IWSResources.PA_Template_Duplicate_IQInstance_Null_Error_Message);
                }

                var templateDetails = new AccountabilityTemplate
                {
                    AlertId = acctTemplate.UserAlertBaseId,
                    ProviderId = acctTemplate.ProviderId
                };
                //Operator alert Base 
                if (acctTemplate.OperatorAlertBaseId != null && acctTemplate.OperatorAlertBaseId > 0)
                {
                    templateDetails.OperatorAlertBase = new AccountabilityAlertBase { AlertId = (int)acctTemplate.OperatorAlertBaseId };
                    alertBaseMgr.DeserializeAlertSpecification(templateDetails.OperatorAlertBase);
                }

                alertBaseMgr.DeserializeAlertSpecification(templateDetails);

                templateDetails.FromEntity(acctTemplate);
                templateDetails.RecipientRefreshIntervalDuration = templateDetails.RecipientRefreshIntervalDuration ??
                                                                   GetDefaultRecipientRefreshInterval();
                return templateDetails;
            }

            catch (Exception ex)
            {
                EventLogger.WriteError("Error while duplicating Accountability Template", ex);
                return null;
            }


        }

        /// <summary>
        /// To delete the template.
        /// </summary>
        /// <param name="ids">template Ids.</param>
        /// <param name="providerId">provider Id.</param>
        /// <param name="operatorId">operator Id.</param>
        /// <returns></returns>
        public bool DeleteTemplates(int providerId, int operatorId, IEnumerable<int> ids)
        {
            var templateIds = ids as int[] ?? ids.ToArray();
            if (!templateIds.Any())
            {
                throw new ArgumentNullException("ids");
            }
            try
            {
               var templates = _accountabilityRepository.DeleteTemplates(operatorId, templateIds);

                foreach (var templateEntity in templates)
                {
                    var auditSpec = new AuditSpec();
                    auditSpec.Action = ServiceAction.AccountabilityTemplateDeleted;
                    auditSpec.ObjectType = EntityType.AccountabilityTemplate;
                    auditSpec.OperatorId = operatorId;
                    auditSpec.ObjectName = templateEntity.Name;
                    auditSpec.ProviderId = providerId;
                    auditSpec.ObjectIds = new List<int>() { templateEntity.TemplateId };

                    OperationAuditor.LogAction(auditSpec);
                }

                return true;
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Error while deleting Accountability Template", ex);
                return false;

            }
        }

        #endregion

        #region event methods

        /// <summary>
        /// To get events.
        /// </summary>
        /// <param name="eventSpec">event spec.</param>
        /// <returns>events.</returns>
        public IPaged<AccountabilityEvent> GetEvents(AccountabilityEventSpec eventSpec)
        {
            if (!eventSpec.OperatorId.HasValue)
            {
                throw new ArgumentNullException("eventSpec.OperatorId");
            }
            if (eventSpec.ProviderId == 0)
            {
                throw new ArgumentNullException("eventSpec.ProviderId");
            }

            var pagedEvents = new Paged<AccountabilityEvent>();

            //[Sequence:1]
            //Get Events raw query from dbcontext
            var events = _accountabilityRepository.GetEventsIncludeAll();

            //[Sequence:2]
            //Apply filter to event query.
            events = ApplyFiltersToEventEntities(events, eventSpec);

            //[Sequence:3]
            //if pagesize is provided, then get the total could
            if (eventSpec.Page != null)
            {
                pagedEvents.SetTotalCount(events.Count());
            }

            //[Sequence:4]
            events = ApplySortingAndPagingToEventEntities(events, eventSpec);

            var eventList = new List<AccountabilityEvent>();

            var alertBaseMgr = new AlertBaseManager(eventSpec.ProviderId, eventSpec.OperatorId.Value);
            var userIds = new HashSet<int>();
            foreach (var eventEntity in events)
            {
                var actEvent = new AccountabilityEvent();

                actEvent.FromEntity(eventEntity, !eventSpec.IncludeReminderAlertDetails, eventSpec.IncludeEventStatistics);

                if (eventSpec.IsLoadBaseDetails)
                {
                    alertBaseMgr.DeserializeAlertSpecificationForAccountability(actEvent);
                }
                userIds.Add(actEvent.CreatedBy);
                userIds.Add(actEvent.UpdatedBy);
                userIds.Add(actEvent.StartedBy.GetValueOrDefault());
                userIds.Add(actEvent.EndedBy.GetValueOrDefault());

                eventList.Add(actEvent);
            }

            var evtIds = events.Select(e => e.EventId).ToArray();
            if (eventSpec.IncludeReminderAlertDetails)
            {

                var evtAlertDetails = _accountabilityRepository.GetEventAlertDetails(evtIds).ToDictionary(e => e.AlertId);

                foreach (var accountabilityEvent in eventList)
                {
                    foreach (var alert in accountabilityEvent.AssociatedAlerts)
                    {
                        AccountabilityEventAlert detail;
                        if (evtAlertDetails.TryGetValue(alert.AlertId, out detail))
                        {
                            alert.AlertStatus = detail.AlertStatus;
                            alert.AlertTitle = detail.AlertTitle;
                            alert.AlertBody = detail.AlertBody;
                            alert.PublishedOn = detail.PublishedOn;
                            alert.TotalUser = detail.TotalUser;
                        }
                    }
                }

            }

            ResolveEventUserNames(eventList, userIds);

            pagedEvents.SetList(eventList);
            if (eventSpec.Page != null) pagedEvents.SetCurrentPageNumber(eventSpec.Page.Value);
            pagedEvents.SetPageSize(eventSpec.PageSize);
            return pagedEvents;
        }

        public IEnumerable<AccountabilityEventSearchResult> GetEventsForMap(AccountabilityEventSearchSpec eventSpec)
        {
            var events = GetAccountabilitySearchResult(eventSpec);
            var liveEvents = events.GetList();

            var accountabilityEventSearchResults = liveEvents as AccountabilityEventSearchResult[] ?? liveEvents.ToArray();
            if (liveEvents != null && accountabilityEventSearchResults.Any())
            {
                var allAlertBaseId = from eventEntity in accountabilityEventSearchResults
                                     select eventEntity.AlertBaseId;

                var alertBaseMgr = new AlertBaseManager(eventSpec.ProviderId, eventSpec.OperatorId);
                var locationData = alertBaseMgr.GetGeoLocation(allAlertBaseId);

                if (locationData != null && locationData.Any())
                {
                    foreach (var evt in accountabilityEventSearchResults)
                    {
                        if (locationData.ContainsKey(evt.AlertBaseId))
                        {
                            var geoJson = locationData[evt.AlertBaseId];
                            if (string.IsNullOrEmpty(geoJson))
                                continue;

                            evt.GeoJson = locationData[evt.AlertBaseId];
                            yield return evt;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Get Accountability Event
        /// </summary>
        /// <param name="eventSpec">Object of type AccountabilityEventSpec </param>
        /// <returns>event details.</returns>
        public AccountabilityEvent GetEvent(AccountabilityEventSpec eventSpec)
        {
            if (!eventSpec.OperatorId.HasValue)
            {
                throw new ArgumentNullException("eventSpec", @"Operator Id cannot be NULL or Empty");
            }
            if (eventSpec.ProviderId == 0)
            {
                throw new ArgumentNullException("eventSpec", @"Provider Id cannot be NULL or Empty");
            }

            try
            {
                var eventEntity = _accountabilityRepository.GetEvent(eventSpec.EventIds[0], !eventSpec.IncludeReminderAlertDetails);
                if (eventEntity == null)
                    throw new Exception(string.Format("No Event found in the system with ID: {0}", eventSpec.EventIds[0]));

                var allVps = GetAllVpsIds(eventSpec.ProviderId);
                if (!allVps.Contains(eventEntity.ProviderId))
                    throw new Exception(string.Format("No Event found in the system or within subsystems with ID: {0}",
                        eventEntity.EventId));

                var actEvent = new AccountabilityEvent
                {
                    AlertId = eventEntity.UserAlertBaseId,
                    ProviderId = eventEntity.ProviderId
                };
                var alertBaseMgr = new AlertBaseManager(eventEntity.ProviderId, eventSpec.OperatorId.Value);
                if (eventSpec.IsLoadBaseDetails)
                {
                    // Changed provider Id to eventEntity provider Id as this would hold subvps provider Id
                    alertBaseMgr.DeserializeAlertSpecificationForAccountability(actEvent);
                    //Supervisor Alert
                    if (eventEntity.OperatorAlertBaseId != null)
                    {
                        actEvent.OperatorAlertBase = new AccountabilityAlertBase { AlertId = (int)eventEntity.OperatorAlertBaseId };
                        alertBaseMgr.DeserializeAlertSpecificationForAccountability(actEvent.OperatorAlertBase);
                    }

                }
                var vpsTimeFormat = alertBaseMgr.Provider.CurrentDateTime.ToString(alertBaseMgr.Provider.TimeFormatString);
                actEvent.FromEntity(eventEntity, !eventSpec.IncludeReminderAlertDetails, eventSpec.IncludeEventStatistics);
                if (actEvent.FirstAlertUserMessage != null)
                {
                    actEvent.FirstAlertUserMessage.Title = ReplaceEventPlaceHolder(actEvent.FirstAlertUserMessage.Title, eventSpec.BaseLocale, actEvent.AlertSpec, vpsTimeFormat);
                    actEvent.FirstAlertUserMessage.Title = ReplacePlaceHolders(actEvent.FirstAlertUserMessage.Title, actEvent, eventSpec.OperatorId.Value);
                }
                if (actEvent.FirstAlertOperatorMessage != null)
                {
                    actEvent.FirstAlertOperatorMessage.Title = ReplaceEventPlaceHolder(actEvent.FirstAlertOperatorMessage.Title, eventSpec.BaseLocale, actEvent.AlertSpec, vpsTimeFormat);
                    actEvent.FirstAlertOperatorMessage.Title = ReplacePlaceHolders(actEvent.FirstAlertOperatorMessage.Title, actEvent, eventSpec.OperatorId.Value);
                }
                if (actEvent.ReminderAlertUserMessage != null)
                {
                    actEvent.ReminderAlertUserMessage.Title = ReplaceEventPlaceHolder(actEvent.ReminderAlertUserMessage.Title, eventSpec.BaseLocale, actEvent.AlertSpec, vpsTimeFormat);
                    actEvent.ReminderAlertUserMessage.Title = ReplacePlaceHolders(actEvent.ReminderAlertUserMessage.Title, actEvent, eventSpec.OperatorId.Value);
                }
                if (actEvent.CloseAlertUserMessage != null)
                {
                    actEvent.CloseAlertUserMessage.Title = ReplaceEventPlaceHolder(actEvent.CloseAlertUserMessage.Title, eventSpec.BaseLocale, actEvent.AlertSpec, vpsTimeFormat);
                    actEvent.CloseAlertUserMessage.Title = ReplacePlaceHolders(actEvent.CloseAlertUserMessage.Title, actEvent, eventSpec.OperatorId.Value);
                }
                if (actEvent.CloseAlertOperatorMessage != null)
                {
                    actEvent.CloseAlertOperatorMessage.Title = ReplaceEventPlaceHolder(actEvent.CloseAlertOperatorMessage.Title, eventSpec.BaseLocale, actEvent.AlertSpec, vpsTimeFormat);
                    actEvent.CloseAlertOperatorMessage.Title = ReplacePlaceHolders(actEvent.CloseAlertOperatorMessage.Title, actEvent, eventSpec.OperatorId.Value);
                }
                var userIds = new HashSet<int>();
                userIds.Add(actEvent.CreatedBy);
                userIds.Add(actEvent.UpdatedBy);
                userIds.Add(actEvent.StartedBy.GetValueOrDefault());
                userIds.Add(actEvent.EndedBy.GetValueOrDefault());

                if (eventSpec.IncludeReminderAlertDetails)
                {

                    IList<AccountabilityEventAlert> eventAlertQuery;
                    eventAlertQuery = _accountabilityRepository.GetEventAlertDetails(new[] { eventSpec.EventIds[0] });
                    actEvent.AssociatedAlerts = eventAlertQuery.ToList();
                }

                ResolveEventUserNames(new List<AccountabilityEvent>() { actEvent }, userIds);

                return actEvent;
            }

            catch (Exception ex)
            {
                var json = new JavaScriptSerializer().Serialize(eventSpec);
                EventLogger.WriteError(string.Format("Error while fetching Event : JSON string for i/p payload is {0}.", json), ex);
                throw;
            }
        }
        public IEnumerable<AccountabilityEventAlert> GetAccountabilityEventAlerts(int eventid, bool includedetails = false)
        {
            var resultSet = new List<AccountabilityEventAlert>();
            //_accountabilityRepository.GetEventOvertimeMessageSentEntity();
            return resultSet;
        }
        /// <summary>
        /// To create the event.
        /// </summary>
        /// <param name="actTemplate">accountability template.</param>
        /// <param name="operatorId">operatorId.</param>
        /// <param name="providerContext"></param>
        /// <returns>event Id.</returns>
        public int CreateEvent(int operatorId, IProviderContext providerContext, AccountabilityTemplate actTemplate)
        {
            int accountabilityEventId = -1;
            bool isSuccess = true;
            if (actTemplate == null)
            {
                throw new ArgumentNullException("actTemplate", @"AccountabilityTemplate actTemplate cannot be null while creating event");
            }

            EventLogger.WriteInformation(string.Format("PUBLISH-EVENT-CHECKPOINT-{0} on Time - {1}", 3, DateTime.Now));
            var alertBaseMgr = new AlertBaseManager(providerContext.ProviderId, operatorId);

            var currentSystemTime = DateTimeConverter.GetSystemTime();
            try
            {
                var actEvent = new AccountabilityEvent();
                using (var ngadDb = new NgadDatabase())
                {

                    actTemplate.CopyTo(actEvent, operatorId);

                    //Make sure to save publish layout config. For every new alert - there will be new config id
                    PublishLayoutConfiguration.Save(actEvent.PublishLayoutConfig);
                    alertBaseMgr.SerializeAlertSpecification(actEvent, ngadDb);

                    //Operator Alert 
                    if (actTemplate.OperatorAlertBase != null)
                    {
                        actEvent.OperatorAlertBase = new AccountabilityAlertBase();
                        actTemplate.CopyTo(actEvent.OperatorAlertBase, operatorId);
                        //Set the Operator targeting 
                        actTemplate.OperatorAlertBase.AlertSpec.Targeting.CopyTo(actEvent.OperatorAlertBase.AlertSpec.Targeting);

                        PublishLayoutConfiguration.Save(actEvent.OperatorAlertBase.PublishLayoutConfig);
                        alertBaseMgr.SerializeAlertSpecification(actEvent.OperatorAlertBase, ngadDb);

                    }

                }


                if (actTemplate.RecipientRefreshIntervalDuration == null || actTemplate.RecipientRefreshIntervalDuration.Value == 0)
                {
                    actTemplate.RecipientRefreshIntervalDuration = GetDefaultRecipientRefreshInterval();
                }
                //Populate Event property from template object.
                actEvent.FromTemplate(actTemplate);
                actEvent.Status = AccountabilityEventStatus.Publishing;
                actEvent.CreatedOn = currentSystemTime;
                actEvent.UpdatedOn = currentSystemTime;
                actEvent.CreatedBy = operatorId;
                actEvent.UpdatedBy = operatorId;

                //resolving event name and description placeholders...
                actEvent.AlertSpec.Content.Header = ReplacePlaceHolders(actEvent.AlertSpec.Content.Header, actEvent, operatorId);
                actEvent.AlertSpec.Content.Body = ReplacePlaceHolders(actEvent.AlertSpec.Content.Body, actEvent, operatorId);

                //resolving user message title and body placeholders...
                var vpsTimeFormat = alertBaseMgr.Provider.CurrentDateTime.ToString(alertBaseMgr.Provider.TimeFormatString);
                actEvent.FirstAlertUserMessage.Title = ReplaceEventPlaceHolder(actEvent.FirstAlertUserMessage.Title, actEvent.Locale.LocaleCode, actEvent.AlertSpec, vpsTimeFormat);
                actEvent.FirstAlertUserMessage.Body = ReplaceEventPlaceHolder(actEvent.FirstAlertUserMessage.Body, actEvent.Locale.LocaleCode, actEvent.AlertSpec, vpsTimeFormat);
                actEvent.ReminderAlertUserMessage.Title = ReplaceEventPlaceHolder(actEvent.ReminderAlertUserMessage.Title, actEvent.Locale.LocaleCode, actEvent.AlertSpec, vpsTimeFormat);
                actEvent.ReminderAlertUserMessage.Body = ReplaceEventPlaceHolder(actEvent.ReminderAlertUserMessage.Body, actEvent.Locale.LocaleCode, actEvent.AlertSpec, vpsTimeFormat);
                actEvent.CloseAlertUserMessage.Title = ReplaceEventPlaceHolder(actEvent.CloseAlertUserMessage.Title, actEvent.Locale.LocaleCode, actEvent.AlertSpec, vpsTimeFormat);
                actEvent.CloseAlertUserMessage.Body = ReplaceEventPlaceHolder(actEvent.CloseAlertUserMessage.Body, actEvent.Locale.LocaleCode, actEvent.AlertSpec, vpsTimeFormat);

                //resolving officer message title and body placeholders...
                actEvent.FirstAlertOperatorMessage.Title = ReplaceEventPlaceHolder(actEvent.FirstAlertOperatorMessage.Title, actEvent.Locale.LocaleCode, actEvent.AlertSpec, vpsTimeFormat);
                actEvent.FirstAlertOperatorMessage.Body = ReplaceEventPlaceHolder(actEvent.FirstAlertOperatorMessage.Body, actEvent.Locale.LocaleCode, actEvent.AlertSpec, vpsTimeFormat);
                actEvent.CloseAlertOperatorMessage.Title = ReplaceEventPlaceHolder(actEvent.CloseAlertOperatorMessage.Title, actEvent.Locale.LocaleCode, actEvent.AlertSpec, vpsTimeFormat);
                actEvent.CloseAlertOperatorMessage.Body = ReplaceEventPlaceHolder(actEvent.CloseAlertOperatorMessage.Body, actEvent.Locale.LocaleCode, actEvent.AlertSpec, vpsTimeFormat);

                var acctEventEtity = actEvent.ToEntity();
                acctEventEtity.EventUniqueId = Guid.NewGuid().ToString();

                EventLogger.WriteInformation(string.Format("PUBLISH-EVENT-CHECKPOINT-{0} on Time - {1}", 4, DateTime.Now));
                //Create event.
                accountabilityEventId = _accountabilityRepository.CreateEvent(acctEventEtity);

                //Make an audit log entry
                var auditSpec = new AuditSpec(operatorId, acctEventEtity.ProviderId)
                {
                    Action = ServiceAction.AccountabilityEventCreated,
                    ObjectType = EntityType.AccountabilityEvent,
                    ObjectName = acctEventEtity.Name,
                    ObjectIds = new List<int>() { accountabilityEventId }
                };
                OperationAuditor.LogAction(auditSpec);

                //Make sure to update the EventAlertMapID - otherwise MAP ID FROM ACCT_TEMPLATE_ALERT_MAP_TAB will be used.
                var tempMapEntity =
                    acctEventEtity.AccountabilityEventAlertMapEntities.FirstOrDefault(
                        e => e.AlertInitType == AccountabilityEventAlertType.Start.ToString() && e.AlertType == AccountabilityEventUserType.User.GetDescription());
                if (tempMapEntity != null)
                {
                    actEvent.FirstAlertUserMessage.MessageId = tempMapEntity.Id;
                }
                if (actEvent.FirstAlertOperatorMessage != null)
                {
                    var tempOprMapEntity =
                   acctEventEtity.AccountabilityEventAlertMapEntities.FirstOrDefault(
                       e => e.AlertInitType == AccountabilityEventAlertType.Start.ToString() && e.AlertType == AccountabilityEventUserType.Operator.GetDescription());
                    if (tempOprMapEntity != null)
                    {
                        actEvent.FirstAlertOperatorMessage.MessageId = tempOprMapEntity.Id;
                    }
                }
                actEvent.EventId = accountabilityEventId;
                //Set the Event User Status.
                SetEventUserStatus(accountabilityEventId, actTemplate.AlertSpec.Content.ResponseOptionsAttributeID);

                //set the event pickup schedule.
                var alertRepeatDuration = actEvent.ReminderAlertUserMessage != null
                    ? actEvent.ReminderAlertUserMessage.AlertRepeatDuration
                    : null;

                SetEventPickupSchedule(accountabilityEventId, acctEventEtity.StartDate, actEvent.RecipientRefreshIntervalDuration,
                    alertRepeatDuration);
                EventLogger.WriteInformation(string.Format("PUBLISH-EVENT-CHECKPOINT-{0} on Time - {1}", 5, DateTime.Now));

                if (actEvent.AlertSpec == null || actEvent.AlertSpec.Targeting == null || actEvent.AlertSpec.Targeting.TargetingCriteria == null)
                {
                    throw new Exception("Event alert targeting criteria cannot be null.");
                }

                //Populate Event Recipient - For start event - All user belongs to Alert Targeting should be populated. No need to specify EBT criteria.
                PopulateEventRecipient(actEvent, operatorId, providerContext);
                EventLogger.WriteInformation(string.Format("PUBLISH-EVENT-CHECKPOINT-{0} on Time - {1}", 6, DateTime.Now));
                var eventIds = new List<int> { actEvent.EventId };
                _accountabilityRepository.UpdateEventStatus(operatorId, eventIds, AccountabilityEventStatus.Live);


               // ProcessStartAlert(actEvent.EventId, operatorId);

                SubmitJob(AccountabilityEventJobPickupType.Start, actEvent.EventId, operatorId);
                EventLogger.WriteInformation(string.Format("PUBLISH-EVENT-CHECKPOINT-{0} on Time - {1}", 7, DateTime.Now));
                //Make an audit log entry
                auditSpec.Action = ServiceAction.AccountabilityEventPublished;
                OperationAuditor.LogAction(auditSpec);
            }
            catch (Exception ex)
            {
                var json = new JavaScriptSerializer().Serialize(actTemplate);
                EventLogger.WriteError(string.Format("Error while Creating Event - JSON For input payload is => {0}", json), ex);
                isSuccess = false;
            }
            finally
            {
                //If event is already create, and error occurs after creation, make sure to delete such entry.
                if (accountabilityEventId > 0 && !isSuccess)
                {
                    var eventsToEnd = new int[] { accountabilityEventId };
                    _accountabilityRepository.UpdateEventStatus(operatorId, eventsToEnd,
                        AccountabilityEventStatus.Deleted);
                    accountabilityEventId = -1;
                }
            }
            return accountabilityEventId;
        }



        private int ConstructAndPublishAlert(int operatorId, AlertManager alertManager, AccountabilityEvent acctEventForGeneralInfo,
            AlertBase userOrOperatoralertBase, AccountabilityMessage messsage, bool clearResponseOptions,
            Priority priority, IList<ISearchCriteria> targetingCriteria, string vpsTimeFormat, DateTime startTime, DateTime? endTime, string moreInfoUrl, AlertAttachment alertAttachment, string provideDefalutLocaleCode)
        {
            var strReplacedPlaceholderTitle = ReplaceEventPlaceHolder(messsage.Title, provideDefalutLocaleCode, userOrOperatoralertBase.AlertSpec, vpsTimeFormat);
            var strReplacedPlaceholderBody = ReplaceEventPlaceHolder(messsage.Body, provideDefalutLocaleCode, userOrOperatoralertBase.AlertSpec, vpsTimeFormat);
            userOrOperatoralertBase.AlertSpec.Content.Header = strReplacedPlaceholderTitle;
            userOrOperatoralertBase.AlertSpec.Content.Body = strReplacedPlaceholderBody;
            userOrOperatoralertBase.AlertSpec.Priority = priority;

            var alert = alertManager.CreateAlertFromAccountabilityEvent(userOrOperatoralertBase, operatorId);
            if (clearResponseOptions)
            {
                alert.AlertSpec.Content.ResponseOptions.Clear();
                alert.AlertSpec.Content.ResponseOptionsAttributeID = 0;
            }

            alert.AlertSpec.Targeting.TargetingCriteria = targetingCriteria;
            alert.Origin.ScenarioId = acctEventForGeneralInfo.TemplateId;
            alert.Origin.ScenarioName = acctEventForGeneralInfo.Name;
            alert.CreatedBy = acctEventForGeneralInfo.CreatedBy;
            alert.UpdatedBy = acctEventForGeneralInfo.UpdatedBy;

            //To support UAP integration, it needs to pass eventId as a part of Attachment.
            alert.AlertSpec.Advanced.AddAttachment(alertAttachment);
            alert.StartTime = startTime;
            if (endTime.HasValue)
            {
                alert.EndTime = endTime.Value;
            }

            if (!string.IsNullOrEmpty(moreInfoUrl))
            {
                alert.AlertSpec.Content.Url = moreInfoUrl;
            }


            int accountabilityEventAlertId = 0;

            alertManager.SaveAlert(alert, false, false, new SaveAlertListenerImpl(new Action<int>((alertId) =>
            {
                EventLogger.WriteVerbose(string.Format("Call back execution - Alert ID ={0}, EventId ={1}, Message ID ={2} ", alertId, acctEventForGeneralInfo.EventId, messsage.MessageId));
                accountabilityEventAlertId = _accountabilityRepository.CreateEventAlert(new AccountabilityEventAlertEntity
                {
                    AlertId = alertId,
                    EventId = acctEventForGeneralInfo.EventId,
                    AccountabilityEventAlertMapId = messsage.MessageId
                });
            })));

            return accountabilityEventAlertId;


        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="operatorId"></param>
        /// <param name="actEventType"></param>
        /// <param name="actEvent"></param>
        /// <param name="vpsCurrentDateTime"></param>
        /// <param name="vpsTimeFormat"></param>
        /// <param name="publishAsync"></param>
        /// <returns>User Event Alert Id, Operator Event Alert id -> mapped to ACCT_EVENT_ALERT_TAB</returns>
        private Tuple<int, int> PublishEventAlert(int providerId, int operatorId, AccountabilityEventAlertType actEventType, AccountabilityEvent actEvent, DateTime vpsCurrentDateTime, string vpsTimeFormat, bool publishAsync, string provideDefalutLocaleCode)
        {

            var alertManager = new AlertManager(providerId, operatorId);

            int userEventAlertId = 0;
            int operatorEventAlertId = 0;

            bool clearUserResponsesOptions = false;
            var userPriority = actEvent.AlertSpec.Priority;
            var operatorPriority = actEvent.AlertSpec.Priority;
            AccountabilityMessage userMessage = null;
            AccountabilityMessage operatorMessage = null;
            EventBasedCriteria userEbt = null;

            switch (actEventType)
            {
                case AccountabilityEventAlertType.Start:
                    userMessage = actEvent.FirstAlertUserMessage;
                    operatorMessage = actEvent.FirstAlertOperatorMessage;
                    userEbt = new EventBasedCriteria(new[] { actEvent.EventId }, EventCriteriaOperator.NORESPONSE);
                    break;
                case AccountabilityEventAlertType.Reminder:
                    userMessage = actEvent.ReminderAlertUserMessage;
                    userEbt = new EventBasedCriteria(new[] { actEvent.EventId }, EventCriteriaOperator.NORESPONSE);
                    break;
                case AccountabilityEventAlertType.Close:
                    userMessage = actEvent.CloseAlertUserMessage;
                    operatorMessage = actEvent.CloseAlertOperatorMessage;
                    clearUserResponsesOptions = true;
                    userPriority = operatorPriority = Priority.Informational;
                    userEbt = new EventBasedCriteria(new[] { actEvent.EventId }, EventCriteriaOperator.TARGETED);
                    break;
            }

            bool sendUserAlert = userMessage != null && userMessage.IsEnabled;

            //Make sure operator should get reminder alert. Similarly, if marked to send Operator Message then send.
            bool sendOperatorAlert = actEventType != AccountabilityEventAlertType.Reminder && operatorMessage != null && operatorMessage.IsEnabled && (actEvent.OperatorAlertBaseId.GetValueOrDefault() > 0);
            var eventAttachtment = new AlertAttachment(AttachmentType.PAEvent, actEvent.EventId, AttachmentSubType.None);
            if (sendUserAlert)
            {
                DateTime? endTime = null;
                if (actEventType == AccountabilityEventAlertType.Close)
                {
                    endTime = vpsCurrentDateTime.AddMinutes(30); //Set endtime for ending alert - 30 min from now.                                        
                }
                else
                {
                    endTime = actEvent.EndDate;
                }

                userEventAlertId = ConstructAndPublishAlert(operatorId, alertManager, actEvent, actEvent, userMessage, clearUserResponsesOptions, userPriority, userEbt.ToSearchCriterias(), vpsTimeFormat, vpsCurrentDateTime, endTime, string.Empty, eventAttachtment, provideDefalutLocaleCode);
            }

            if (sendOperatorAlert)
            {
                DateTime? endTime = null;
                if (actEventType == AccountabilityEventAlertType.Close)
                {
                    endTime = vpsCurrentDateTime.AddMinutes(30); //Set endtime for ending alert - 30 min from now.                                        
                }

                var url = ConfigurationManager.GetURL() + "/AtHoc-IWS/Account/Events?id=" + actEvent.EventId + "&providerId=" + providerId + "&tab=users";
                operatorEventAlertId = ConstructAndPublishAlert(operatorId, alertManager, actEvent, actEvent.OperatorAlertBase, operatorMessage, true,
                    operatorPriority, actEvent.OperatorAlertBase.AlertSpec.Targeting.TargetingCriteria, vpsTimeFormat, vpsCurrentDateTime, endTime, url, eventAttachtment, provideDefalutLocaleCode);

            }

            return new Tuple<int, int>(userEventAlertId, operatorEventAlertId);


        }


        /// <summary>Checks if an event is valid.</summary>
        /// <param name="eventId">Event id.</param>
        /// <param name="providerId">Provider Id.</param>
        /// <param name="operatorId">Operator Id.</param>
        /// <returns>True if event is valid.</returns>
        public bool CheckEventValidity(int eventId, int providerId, int operatorId, string locale)
        {
            var eventSpec = new AccountabilityEventSpec
            {
                EventIds = new List<int>() { eventId },
                ProviderId = providerId,
                OperatorId = operatorId,
                IncludeReminderAlertDetails = false,
                IncludeEventStatistics = false,
                IsLoadBaseDetails = false,
                BaseLocale = locale
            };

            try
            {
                var accountabilityEvent = GetEvent(eventSpec);
                return accountabilityEvent != null;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        /// <summary>
        /// To set the Event Pickup Schedule.
        /// </summary>
        /// <param name="eventId">event Id.</param>
        /// <param name="eventTime">event time.</param>
        /// <param name="alertRepeatInterval">alert repeat interval.</param>
        /// <param name="recipientRecomputeDuration">recipient recompute duration.</param>
        private void SetEventPickupSchedule(int eventId, DateTime eventTime, Duration recipientRecomputeDuration, Duration alertRepeatInterval)
        {

            var dbSetAccountabilityEventPickupScheduleEntity = new List<AccountabilityEventPickupScheduleEntity>();


            if (alertRepeatInterval != null)
            {
                var reminderActionEntity = new AccountabilityEventPickupScheduleEntity { EventId = eventId };
                reminderActionEntity.PickupActionType = AccountabilityEventJobPickupType.Reminder.GetDescription();
                reminderActionEntity.NextRunTime = alertRepeatInterval.GetEndTime(eventTime);
                //actionEntity.UserAlertReminderNextSendTime = alertRepeatInterval.GetEndTime(eventTime);
                dbSetAccountabilityEventPickupScheduleEntity.Add(reminderActionEntity);
            }


            if (recipientRecomputeDuration != null)
            {
                var recomputeUserEntity = new AccountabilityEventPickupScheduleEntity { EventId = eventId };
                recomputeUserEntity.PickupActionType = AccountabilityEventJobPickupType.Recompute.GetDescription();
                recomputeUserEntity.NextRunTime = recipientRecomputeDuration.GetEndTime(eventTime);
                dbSetAccountabilityEventPickupScheduleEntity.Add(recomputeUserEntity);
                // actionEntity.EventRecipientNextRecomputeTime = recipientRecomputeDuration.GetEndTime(eventTime);
            }
            else
            {
                EventLogger.WriteError("Recompute Recipient Duration cannot be null. Method: SetEventPickupSchedule");
            }

            _accountabilityRepository.AddEventPickupSchedule(dbSetAccountabilityEventPickupScheduleEntity);
        }

        private string ReplacePlaceHolders(string field, AccountabilityEvent accountabilityEvent, int operatorId)
        {
            var sysPlaceholders = new SystemPlaceholders();
            //get system placeholders
            var systemPlaceholders = _placeholderFacade.GetSystemPlaceHolders(sysPlaceholders,
                accountabilityEvent.ProviderId, operatorId);
            field = ReplaceSystemPlaceholderInText(field, systemPlaceholders);

            return field;
        }
        private static string ReplaceSystemPlaceholderInText(string text, IEnumerable<PlaceHolder> systemPlaceHolders)
        {

            //Replace with system placeholder
            if (text.Contains("[[") && text.Contains("]]"))
            {
                if (systemPlaceHolders != null)
                {
                    foreach (var placeholder in systemPlaceHolders)
                    {
                        var key = string.Format("[[{0}]]", placeholder.Name);
                        if (!text.Contains(key)) continue;
                        var defaultValue = placeholder.Values.FirstOrDefault(v => v.IsDefault);
                        text = text.Replace(key, defaultValue != null ? defaultValue.Value : string.Empty);
                    }
                }
            }

            return text;
        }

        /// <summary>
        /// Replace Placeholder for Message Preview
        /// </summary>
        /// <param name="field"></param>
        /// <param name="systemPlaceholders"></param>
        /// <param name="accountabilityStartDatePlaceHolderDisplayName"></param>
        /// <param name="accountabilityStartDatePlaceHolderValue"></param>
        /// <returns></returns>
        public string ReplacePlaceHoldersForPreviewMessage(string field, IEnumerable<PlaceHolder> systemPlaceholders, string accountabilityStartDatePlaceHolderDisplayName, string accountabilityStartDatePlaceHolderValue)
        {
            field = ReplaceSystemPlaceholderInText(field, systemPlaceholders);
            field = field.Replace(accountabilityStartDatePlaceHolderDisplayName, accountabilityStartDatePlaceHolderValue);
            return field;
        }

        /// <summary>
        /// To replace Event PlaceHolders.
        /// </summary>
        /// <param name="field">field.</param>
        /// <param name="starTime">event start time.</param>
        /// <param name="localeCode"></param>
        /// <param name="accountabilityEvent"></param>
        /// <param name="vpsTimeFormat"></param>
        /// <returns>filed with resolved placeholder value.</returns>
        private string ReplaceEventPlaceHolder(string field, string localeCode, AlertSpecification alertSpec, string vpsTimeFormat)
        {
            //var alertSpec = accountabilityEvent.AlertSpec;
            var eventPlaceholders = _placeholderFacade.GetEventPlaceholders(localeCode);
            field = field.Replace(eventPlaceholders.Single(e => e.EventPlaceholderId == AccountabilityEventPlaceHolders.AccountabilityName.ToString()).EventPlaceholderDisplayName, alertSpec.Content.Header);
            field = field.Replace(eventPlaceholders.Single(e => e.EventPlaceholderId == AccountabilityEventPlaceHolders.AccountabilityDescription.ToString()).EventPlaceholderDisplayName, alertSpec.Content.Body);
            field = field.Replace(eventPlaceholders.Single(e => e.EventPlaceholderId == AccountabilityEventPlaceHolders.AccountabilityStartTime.ToString()).EventPlaceholderDisplayName, vpsTimeFormat);
            return field;
        }
        /// <summary>
        /// To set the Event User Status.
        /// </summary>
        /// <param name="eventId">event Id .</param>
        /// <param name="attributeId">status attribute Id.</param>
        private void SetEventUserStatus(int eventId, int attributeId)
        {
            var spec = new CustomAttributeSpec() { Ids = new[] { attributeId }, ApplyFeatureMatrix = false, IncludeValues = true };
            var statusAttribute = _customAttributeFacade.GetCustomAttributesBySpec(spec);

            if (statusAttribute == null) return;
            var userStatusList = statusAttribute.First().Values.ToDictionary(attributeValue => attributeValue.ValueId,
                attributeValue => attributeValue.SortOrder != null ? (int)attributeValue.SortOrder : 0);
            _accountabilityRepository.SetEventUserStatus(eventId, attributeId, userStatusList);
        }

        /// <summary>
        /// To end events.
        /// </summary>
        /// <param name="providerId">provider Id.</param>
        /// <param name="operatorId">operator Id.</param>
        /// <param name="ids">evnet ids.</param>
        /// <returns>true-if end action is successful.</returns>
        public bool EndEvents(int providerId, int operatorId, IEnumerable<int> ids)
        {

            try
            {
                var eventIds = ids as IList<int> ?? ids.ToList();

                foreach (var eventId in eventIds)
                {
                    SubmitJob(AccountabilityEventJobPickupType.TrackingSummary, eventId, operatorId);
                    SubmitJob(AccountabilityEventJobPickupType.End, eventId, operatorId);
                }

                //Mark event for ended.
                _accountabilityRepository.UpdateEventStatus(operatorId, eventIds, AccountabilityEventStatus.Ended);

                //Make an audit log entry
                var auditSpec = new AuditSpec(operatorId, providerId)
                {
                    Action = ServiceAction.AccountabilityEventEnded,
                    ObjectType = EntityType.AccountabilityEvent,
                    ObjectName = "PA Event Ended",
                    ObjectIds = eventIds
                };
                OperationAuditor.LogAction(auditSpec);
                return true;

            }
            catch (Exception ex)
            {
                EventLogger.WriteError(IWSResources.PA_Event_End_Error_Message, ex);
                return false;
            }
        }

        public int GetEventProviderId(int providerId, int eventId)
        {
            try
            {
                return _accountabilityRepository.GetEventProviderId(providerId, eventId);
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("GetEventProviderId", ex);
                return -1;
            }
        }
        /// <summary>
        /// To delete events.
        /// </summary>
        /// <param name="providerId">provider Id.</param>
        /// <param name="operatorId">operator Id.</param>
        /// <param name="ids">event ids.</param>
        /// <returns>true - if deletion is successful.</returns>
        public bool DeleteEvents(int providerId, int operatorId, IEnumerable<int> ids)
        {
            var eventIds = ids as int[] ?? ids.ToArray();
            if (eventIds.Length == 0)
            {
                throw new ArgumentException(@"Ids", @"Event ID list cannot be null or empty");
            }
            try
            {
                _accountabilityRepository.UpdateEventStatus(operatorId, eventIds, AccountabilityEventStatus.Deleted);
                var auditSpec = new AuditSpec(operatorId, providerId)
                {
                    Action = ServiceAction.AccountabilityEventDeleted,
                    ObjectType = EntityType.AccountabilityEvent,
                    ObjectName = "Multiple Event Ids",
                    ObjectIds = eventIds
                };
                OperationAuditor.LogAction(auditSpec);

                return true;
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("Error While Deleting Accountability Events - Ids = {0}", eventIds), ex);
                return false;
            }
        }


        /// <summary>
        /// Event based criteria to block the users to exclude from targeted user list
        /// </summary>
        /// <param name="acctEvent">Object of type AccountabilityEvent</param>
        /// <param name="operatorId">Operator Id</param>
        /// <param name="providerContext"></param>
        /// <param name="isBackgroundJob">Who is calling is this method? Background job.</param>
        /// <returns></returns>
        private void PopulateEventRecipient(AccountabilityEvent acctEvent, int operatorId, IProviderContext providerContext, bool isBackgroundJob = false)
        {
            try
            {
                var currentSystemTime = DateTimeConverter.GetSystemTime();
                bool includePastStatus = false;
                DateTime? pastDuration = null;
                if (acctEvent.PastStatusValidityDuration != null && acctEvent.PastStatusValidityDuration.Value > 0)
                {
                    var durationValue = acctEvent.PastStatusValidityDuration.Value; //Always takes negative to consider past date.
                    pastDuration = new Duration(acctEvent.PastStatusValidityDuration.Unit, -durationValue).GetEndTime(acctEvent.StartDate);
                    includePastStatus = true;
                }

                var itemsToAdd = new List<AccountabilityEventRecipientEntity>();

                var existingRecipients = new Dictionary<int, AccountabilityEventRecipientBase>();
                if (isBackgroundJob)
                {
                    //Get exisiting recipient list from db. This is required to avoid any duplication.
                    existingRecipients = _accountabilityRepository.GetEventRecipients(acctEvent.EventId).ToDictionary(e => e.UserId);
                }

                //In case - event has to include the user status from past date, then extended attribute for user attribute needs to pull in from
                // database. Adding extended atteibute to usr_search procedure is heavy, so get exended attribute only needed.
                
                if (includePastStatus)
                {
                    var statusAttributeId = acctEvent.AlertSpec.Content.ResponseOptionsAttributeID;
                    CustomAttribute statusAttribute = _customAttributeCache.Get(acctEvent.ProviderId, providerContext.BaseLocale).GetById(statusAttributeId);
                    var extendedAttributeList = GetCommonNameWithExtendedAttribute(statusAttribute.CommonName);
                    var userList = GetEventRecipientsWithStatusDetails(acctEvent, operatorId, statusAttribute, providerContext.BaseLocale, true);
                    itemsToAdd = GetUsersWithExtendedProperty(acctEvent.EventId, currentSystemTime, userList, extendedAttributeList, statusAttribute.CommonName, pastDuration.Value, existingRecipients);
                }
                else
                {
                    var userList = GetEventRecipientsWithStatusDetails(acctEvent, operatorId, null, providerContext.BaseLocale, false);
                   //below logic will exclude the users which is already exist in database.
                    itemsToAdd.AddRange(from user in userList where !existingRecipients.ContainsKey(user.Id) select new AccountabilityEventRecipientEntity {UserId = user.Id, EventId = acctEvent.EventId, CreatedOn = currentSystemTime, UserStatusAttributeId = 0, IsExcluded = "N"});
                }

                if (!itemsToAdd.Any()) {
                    return;
                }

                _accountabilityRepository.AddUpdateEventRecipients(acctEvent.EventId, itemsToAdd);
                if (isBackgroundJob)
                {
                    //this call is being made to invalidate the cache. This cache is being used by USR_SEARCH_WITHIN_SESSION for PA Module
                    _userFacade.UpdateUserSearchSessionValidity(providerContext, false);
                }
               
            }
            catch (Exception ex)
            {
                var jsonPayload = new JavaScriptSerializer().Serialize(acctEvent);
                EventLogger.WriteError(
                    string.Format("Error while populating Accountability Event Recipient. OperatorId ={0}" +
                                  ", IsBackGroundProcess={1}, Payload ={2}", operatorId, isBackgroundJob, jsonPayload), ex);
                
            }
        }


        private List<AccountabilityEventRecipientEntity> GetUsersWithExtendedProperty(int eventId, DateTime currentSystemDateTime, IEnumerable<UserSearchResultItem> userSearchResultItems, IDictionary<string, string> extendedAttributeList, string commonName, DateTime pastDuration, Dictionary<int, AccountabilityEventRecipientBase> existingRecipients)
        {
            var itemsToAdd = new List<AccountabilityEventRecipientEntity>();
            
            var strextendedUpdatedOn = extendedAttributeList[AttributeCommonNames.UpdatedOn];
            var strextendedUpdatedFrom = extendedAttributeList[AttributeCommonNames.UpdatedFrom];
            var strextendedUpdatedBy = extendedAttributeList[AttributeCommonNames.UpdatedBy];
            var strextendedValueId = extendedAttributeList[AttributeCommonNames.ValueId];

            var attributeValueIdLookup = _accountabilityRepository.GetEventUserStatusAttributes().Where(e => e.EventId == eventId).ToDictionary(e => e.UserStatusAttributeValueId);

            foreach (var user in userSearchResultItems.Where(user => existingRecipients != null && (!existingRecipients.ContainsKey(user.Id))))
            {
                DateTime statusupdatedon;
                string tempupdatedon;
                user.UserAttributes.TryGetValue(strextendedUpdatedOn, out tempupdatedon);
                DateTime.TryParse(tempupdatedon, out statusupdatedon);

                if (statusupdatedon >= pastDuration)
                {

                    string tempupdatedfrom;
                    user.UserAttributes.TryGetValue(strextendedUpdatedFrom, out tempupdatedfrom);
                    var item = new AccountabilityEventRecipientEntity
                    {
                        EventId = eventId,
                        UserId = user.Id,
                        CreatedOn = currentSystemDateTime,
                        IsExcluded = "N"
                    };

                    int updatedBy;
                    if (Int32.TryParse(user.UserAttributes[strextendedUpdatedBy], out updatedBy))
                    {
                        item.UpdatedBy = updatedBy;
                    }

                    string tempvalueId;
                    user.UserAttributes.TryGetValue(strextendedValueId, out tempvalueId); //Attribute Value ID
                    int attributeValueId;
                    if (int.TryParse(tempvalueId, out attributeValueId))
                    {
                        AccountabilityEventUserStatusEntity tempStatusEntity;
                        attributeValueIdLookup.TryGetValue(attributeValueId, out tempStatusEntity);
                        if (tempStatusEntity != null)
                        {
                            item.UserStatusAttributeId = tempStatusEntity.UserStatusOrderId;
                        }
                    }

                    item.StatusUpdatedOn = statusupdatedon;
                    item.UpdateFrom = tempupdatedfrom;

                    itemsToAdd.Add(item);

                }
                else
                {
                    itemsToAdd.Add(new AccountabilityEventRecipientEntity { UserId = user.Id, EventId = eventId, CreatedOn = currentSystemDateTime, UserStatusAttributeId = 0, IsExcluded = "N" });
                }
            }
            return itemsToAdd;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="accountabilityEvent"></param>
        /// <param name="providerId"></param>
        /// <param name="operatorId"></param>
        /// <param name="eventBasedCriteria">Event based criteria to block the users to exclude from targeted user list</param>
        /// <returns></returns>

        public IQueryable<AccountabilityEventUserStatusEntity> GetEventUserStatusAttributes()
        {
            var userStatusEntities = _accountabilityRepository.GetEventUserStatusAttributes();
            return userStatusEntities;
        }
        public IEnumerable<AccountabilityEventStatusAttribute> GetEventStatusAttributeList(int eventId, int providerId)
        {

            var userStatusAttributeList = _accountabilityRepository.GetEventStatusAttributeList(eventId, providerId).OrderBy(e => e.SortOrder).ToList();
            return userStatusAttributeList;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userStatusList"></param>
        /// <param name="providerId"></param>
        /// <param name="baseLocale"></param>
        /// <returns></returns>
        public bool UpdateUsersStatus(UserStatusUpdateSpec userStatusList, int providerId, string baseLocale)
        {
            if (userStatusList == null)
            {
                throw new ArgumentNullException("userStatusList");
            }

            bool retVal = false;
            try
            {
                retVal = _accountabilityRepository.UpdateUsersStatus(userStatusList);
                var auditSpec = new AuditSpec(userStatusList.OperatorId, providerId)
                {
                    Action = ServiceAction.UserStatusUpdated,
                    ObjectType = EntityType.EndUsers,
                    ObjectName = "PA_AFFECTED_USER",
                    ObjectIds = new[] { userStatusList.UserIds[0] }, // Need to log only one entry per batch
                    AdditionalInfo = GetAdditionalInfo(userStatusList, baseLocale)
                };

                OperationAuditor.LogAction(auditSpec);

            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Error while updating user status.", ex);
            }
            return retVal;
        }

        private string GetAdditionalInfo(UserStatusUpdateSpec userStatusList, string baseLocale)
        {
            var spec = new CustomAttributeValueSpec()
            {
                AttributeId = userStatusList.AttributeId,
                BaseLocale = baseLocale
            };

            var attributeValue = _customAttributeFacade.GetCustomAttributeValuesBySpec(spec);

            string updateStatusValue = null;
            var customAttributeValue = attributeValue.FirstOrDefault(v => v.ValueId == userStatusList.ValueId);
            if (customAttributeValue != null)
            {
                updateStatusValue = customAttributeValue.ValueName;
            }

            var additionalInfo = new StringBuilder();
            additionalInfo.Append(string.Format(IWSResources.NEW_STATUS, updateStatusValue ?? IWSResources.NO_RESPONSE));
            additionalInfo.Append(Environment.NewLine);
            additionalInfo.Append(string.Format(IWSResources.COMMENTS, userStatusList.Comments));
            additionalInfo.Append(Environment.NewLine);
            additionalInfo.Append(string.Format(IWSResources.USER_IDS, string.Join(",", userStatusList.UserIds)));

            return additionalInfo.ToString();
        }

        /// <summary>
        /// Change Event and Associated alert (live) end datetime
        /// </summary>
        /// <param name="eventId">Event Id</param>
        /// <param name="newDate">Updated Date</param>
        /// <param name="providerId">Provider Id</param>
        /// <param name="operatorId">Operator Id</param>
        public void ChangeEventEndDate(int eventId, DateTime newDate, int providerId, int operatorId)
        {
            _accountabilityRepository.ChangeEventEndDate(eventId, newDate);
            var e = _accountabilityRepository.GetEvent(eventId, false);
            //update the end time for all existing alerts in the event.
            foreach (var a in e.AccountabilityEventAlertEntities)
            {
                _alertFacade.End(a.AlertId, operatorId, providerId, newDate);
            }
        }

        #endregion

        #region private

        private IEnumerable<UserSearchResultItem> GetEventRecipientsWithStatusDetails(AccountabilityEvent accountabilityEvent, int operatorId, CustomAttribute statusAttribute, string locale, bool includePastStatus)
        {

            IList<UserSearchResultItem> users = null;
            try
            {
                var alertAdapter = new AlertAdapter();
                var srchArgs = alertAdapter.GetUserSearchArgs(accountabilityEvent.AlertSpec.Targeting.TargetingCriteria, accountabilityEvent.ProviderId, locale, operatorId);
                //Block such user, who has any response.
                srchArgs.BlockCriteria = srchArgs.BlockCriteria | new EventBasedCriteria(new[] { accountabilityEvent.EventId }, EventCriteriaOperator.ANYRESPONSE);
                if (includePastStatus && statusAttribute != null)
                {
                    //To get user status and status updated on fields in search result
                    var extendedAttributes = GetCommonNameWithExtendedAttribute(statusAttribute.CommonName);
                    srchArgs.AttributeNames = extendedAttributes.Values.ToList();

                }
                srchArgs.Options.GetUsers = true;
                srchArgs.Paging.UsersPerPage = int.MaxValue;
                //
                //Individual User Targeting is handled in TargetingCriteria - thus won't require to specify. If specify, then blocked user criteria won't block the user from CSV ie targetusers. Frameworks doesn't support currently.
                //srchArgs.TargetUsers = null;
                //Get the net result
                var sUser = _userFacade.SearchUsersByContext(srchArgs);
                users = sUser.Users;
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Error while getting recipients with status details", ex);
            }
            return users;
        }

        private IDictionary<string, string> GetCommonNameWithExtendedAttribute(string commonName)
        {
            var dictOfattributes = new Dictionary<string, string>();
            dictOfattributes.Add(AttributeCommonNames.UpdatedOn, string.Format("{0}:{1}", commonName, AttributeCommonNames.UpdatedOn));
            dictOfattributes.Add(AttributeCommonNames.ValueId, string.Format("{0}:{1}", commonName, AttributeCommonNames.ValueId));
            dictOfattributes.Add(AttributeCommonNames.UpdatedBy, string.Format("{0}:{1}", commonName, AttributeCommonNames.UpdatedBy));
            dictOfattributes.Add(AttributeCommonNames.UpdatedFrom, string.Format("{0}:{1}", commonName, AttributeCommonNames.UpdatedFrom));
            dictOfattributes.Add(AttributeCommonNames.Comments, string.Format("{0}:{1}", commonName, AttributeCommonNames.Comments));
            return dictOfattributes;
        }
        private Duration GetDefaultRecipientRefreshInterval()
        {
            Duration recipientRefreshIntervalinMinute = null;
            var tempInterval = AtHocSystem.Local.Configuration.GetValue("ACCOUNTABILITY-RECIPIENT-UPDATE-INTERVAL");
            int tempInteger = 0;
            if (tempInterval != null && int.TryParse(tempInterval, out tempInteger))
            {
                recipientRefreshIntervalinMinute = new Duration(DurationUnit.Second, tempInteger);
            }
            else
            {
                EventLogger.WriteWarning("Missing key OR Invalid entry in GLB_CONFIG. Key ='ACCOUNTABILITY-RECIPIENT-UPDATE-INTERVAL'. Default 60 second has been used");
                recipientRefreshIntervalinMinute = new Duration(DurationUnit.Second, 60);
            }
            return recipientRefreshIntervalinMinute;
        }
        private void ResolveEventUserNames(List<AccountabilityEvent> events, HashSet<int> userIds)
        {
            IDictionary<int, string> userNames = ResolveUserNames(userIds.ToList());
            events.ForEach(actEvent =>
            {
                var userDisplayName = "";
                if (userNames.TryGetValue(actEvent.CreatedBy, out userDisplayName))
                {
                    actEvent.CreatedByName = userDisplayName;
                }

                if (userNames.TryGetValue(actEvent.UpdatedBy, out userDisplayName))
                {
                    actEvent.UpdatedByName = userDisplayName;
                }

                if (actEvent.StartedBy != null && userNames.TryGetValue(actEvent.StartedBy.Value, out userDisplayName))
                {
                    actEvent.StartedByName = userDisplayName;
                }

                if (actEvent.EndedBy != null && userNames.TryGetValue(actEvent.UpdatedBy, out userDisplayName))
                {
                    actEvent.EndedByName = userDisplayName;
                }
            });
        }
        private void ResolveTemplateUserNames(List<AccountabilityTemplate> templates)
        {
            var userIds = new HashSet<int>();
            userIds.UnionWith(templates.Select(e => e.CreatedBy));
            userIds.UnionWith(templates.Select(e => e.UpdatedBy));


            IDictionary<int, string> userNames = ResolveUserNames(userIds.ToList());
            templates.ForEach(template =>
            {
                var userDisplayName = "";
                if (userNames.TryGetValue(template.CreatedBy, out userDisplayName))
                {
                    template.CreatedByName = userDisplayName;
                }

                if (userNames.TryGetValue(template.UpdatedBy, out userDisplayName))
                {
                    template.UpdatedByName = userDisplayName;
                }
            });
        }

        private IDictionary<int, string> ResolveUserNames(List<int> userIds)
        {
            var attributeList = new List<string> { "DISPLAYNAME", "FIRSTNAME", "LASTNAME", "LOGIN_ID" };
            IDictionary<int, string> disaplyNameById = new Dictionary<int, string>();

            if (userIds.Count == 0)
            {
                return disaplyNameById;
            }
            var users = _userFacade.GetSystemUsersByIds(userIds, attributeList, null);
            foreach (var user in users)
            {
                disaplyNameById.Add(user.Id, user.GetDisplayName());
            }

            return disaplyNameById;
        }
        #endregion



        /// <summary>
        /// Get accountability search results.
        /// </summary>
        /// <param name="spec">Search specs.</param>
        /// <returns>Search results.</returns>
        public IPaged<AccountabilityEventSearchResult> GetAccountabilitySearchResult(AccountabilityEventSearchSpec spec)
        {
            if (spec.Status == null || spec.Status.Length == 0)
            {
                //Fetch only Ended and live event.
                spec.Status = new[] { "Ended,Live" };
            }
            return _accountabilityRepository.GetAccountabilitySearchResult(spec);
        }


        #region Cached
        public IEnumerable<Tuple<int, IDictionary<int, string>>> GetAccountabilityEventPublishers(int providerId)
        {
            // check cache first
            var cachedList = _accountabilityFacadeCache.GetSetEventPublishers(providerId, () =>
            {
                var allVps = GetAllVpsIds(providerId);

                var allEvents = from evt in _accountabilityRepository.GetEventsIncludeAll()
                                where
                                    evt.Status != AccountabilityEventStatus.Deleted.ToString() && evt.PublishedByUserId != null &&
                                    allVps.Contains(evt.ProviderId)
                                select new { evt.ProviderId, evt.PublishedByUserId };

                var results = (from evt in allEvents
                               group evt.PublishedByUserId by evt.ProviderId into g
                               select new
                               {
                                   ProviderId = g.Key,
                                   UserIds = g.Select(x => (int)x).Distinct().ToList()
                               }).ToList();

                var allUserIds = results.SelectMany(x => x.UserIds).Distinct().ToList();
                var resolvedUserNames = ResolveUserNames(allUserIds);

                var accountabilityPublishers = from res in results
                                               let userNames = resolvedUserNames.Where(x => res.UserIds.Contains(x.Key))
                                                   .ToDictionary(x => x.Key, x => x.Value)
                                               select new Tuple<int, IDictionary<int, string>>(res.ProviderId, userNames);

                return accountabilityPublishers;
            });

            return cachedList;
        }


        public IEnumerable<Tuple<int, IEnumerable<CustomAttribute>>> GetStatusAttibutes(int providerId, string baseLocale)
        {
            var cachedList = _accountabilityFacadeCache.GetSetStatusAttibutes(providerId, () =>
            {
                var statusAttributesPerVps =
                    _accountabilityRepository.GetUniqueStatusAttributesPerVps(GetAllVpsIds(providerId));

                var statusAttributeList = from vpsId in statusAttributesPerVps
                                          let allAttributes = _customAttributeCache.Get(vpsId.Key, baseLocale).GetByIds(vpsId.Value)
                                          select new Tuple<int, IEnumerable<CustomAttribute>>(vpsId.Key, allAttributes);

                return statusAttributeList;
            });

            return cachedList;
        }

        private List<int> GetAllVpsIds(int providerId)
        {
            // IWS-26999 feature is moved to 92 release so commenting it for now
            var subVpsIds = GetSubOrganizationsWithNames(providerId);
            var allVpsId = new List<int> { providerId };
            allVpsId.AddRange(subVpsIds.Keys);

            return allVpsId;
        }

        public IDictionary<int, string> GetSubOrganizationsWithNames(int providerId)
        {
            return _accountabilityFacadeCache.GetSetSubOrganizations(providerId, () => _virtualSystemFacade.GetSubVirtualSystemsWithNames(providerId));
        }

        #endregion


    }



}
