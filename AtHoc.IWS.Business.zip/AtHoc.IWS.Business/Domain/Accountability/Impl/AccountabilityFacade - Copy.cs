﻿using System.Collections;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls.Expressions;
using AtHoc.Data;
using AtHoc.Data.Specification;
using AtHoc.Diagnostics;
using AtHoc.Global.Resources;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Ioc;
using AtHoc.Infrastructure.Ioc.SimpleInjector;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Log.EventLog;
using AtHoc.Infrastructure.Sql;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Data.SearchSpec;
using AtHoc.IWS.Business.Domain.Accountability.Specs;
using AtHoc.IWS.Business.Domain.Audit;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.IWS.Business.Domain.Devices;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel;
using AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel;
using AtHoc.IWS.Business.Domain.Organization.Impl;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Business.Domain.Publishing.Impl;
using AtHoc.IWS.Business.Domain.Settings.Impl;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.IWS.Business.Domain.VirtualSystem;
using AtHoc.IWS.Business.Ioc;
using AtHoc.IWS.Business.Shedule;
using AtHoc.MediaServices;
using AtHoc.Publishing;
using AtHoc.Publishing.Configuration;
using AtHoc.Publishing.Service;
using AtHoc.Systems;
using AtHoc.Utilities;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Linq.Dynamic;
using AtHoc.IWS.Business.Helper;


namespace AtHoc.IWS.Business.Domain.Accountability.Impl
{
    public partial class AccountabilityFacade : IAccountabilityFacade
    {
        #region template metohds
        private readonly IAccountabilityRepository _accountabilityRepository;
        private readonly IUserFacade _userFacade;
        private readonly IAlertFacade _alertFacade;
        private readonly IScenarioFacade _scenarioFacade;
        private readonly IDeviceFacade _deviceFacade;
        private readonly ICustomAttributeFacade _customAttributeFacade;
        private readonly ICustomAttributeCache _customAttributeCache;
        public readonly IPlaceHolderFacade _placeholderFacade;
        private readonly ILogService _logService;
        private readonly IAccountabilityFacadeCache _accountabilityFacadeCache;
        private readonly IVirtualSystemFacade _virtualSystemFacade;
       // private readonly IScheduleFacade _scheduleFacade;
        private bool _isLogInformationEnable;
        private string _logInfoContent;

        # region Constructor
        public AccountabilityFacade(IAccountabilityRepository accountabilityRepository, IAlertFacade alertFacade,
            IUserFacade userFacade, IScenarioFacade scenarioFacade, IDeviceFacade deviceFacade,
            ICustomAttributeFacade customAttributeFacade, IPlaceHolderFacade placeholderFacade,
            ICustomAttributeCache customAttributeCache, IAccountabilityFacadeCache accountabilityFacadeCache, IVirtualSystemFacade virtualSystemFacade)
        {
            _accountabilityRepository = accountabilityRepository;
            _alertFacade = alertFacade;
            _userFacade = userFacade;
            _scenarioFacade = scenarioFacade;
            _deviceFacade = deviceFacade;
            _customAttributeFacade = customAttributeFacade;
            _placeholderFacade = placeholderFacade;
            _customAttributeCache = customAttributeCache;
            _accountabilityFacadeCache = accountabilityFacadeCache;
            _virtualSystemFacade = virtualSystemFacade;
            //_scheduleFacade = scheduleFacade;
        }
        #endregion


        /// <summary>
        /// To get templates.
        /// </summary>
        /// <param name="templateSpec">template spec.</param>
        /// <param name="operatorId">operator Id.</param>
        /// <param name="isLoadBase">is load base details.</param>
        /// <returns>templates.</returns>
        public IEnumerable<AccountabilityTemplate> GetTemplates(int operatorId, AccountabilityTemplateSpec templateSpec, bool isLoadBase)
        {
            var actStr = AccountabilityTemplateStatus.Active.GetDescription();
            var alertBaseMgr = new AlertBaseManager(templateSpec.ProviderId, operatorId);

            var templates = _accountabilityRepository.GetTemplates().Where(a => a.ProviderId == templateSpec.ProviderId);

            // show only active
            templates = templates.Where(e => (actStr.Equals(e.Status, StringComparison.InvariantCultureIgnoreCase)));

            // search by name or description
            if (templateSpec.SearchStrings != null && templateSpec.SearchStrings.Any())
            {
                templates = templates.Where(e => templateSpec.SearchStrings.All(s => e.Name.Contains(s) || e.Description.Contains(s)));
            }

            if (templateSpec.DateRangeFrom.HasValue)
            {
                var tempFrom = DateTime.SpecifyKind(templateSpec.DateRangeFrom.Value, DateTimeKind.Unspecified);
                DateTime? dtFrom = RuntimeContext.Provider.VpsToUtcTime(tempFrom);
                templates = templates.Where(e => (e.CreatedOn >= dtFrom.Value));
            }
            if (templateSpec.DateRangeTo.HasValue)
            {
                var tempTo = DateTime.SpecifyKind(templateSpec.DateRangeTo.Value, DateTimeKind.Unspecified);
                DateTime? dtTo = RuntimeContext.Provider.VpsToUtcTime(tempTo);
                templates = templates.Where(e => (e.CreatedOn <= dtTo.Value));
            }

            if (!string.IsNullOrEmpty(templateSpec.OrderBy))
            {
                string orderbystring = (templateSpec.OrderAsc
                       ? string.Format("{0} ASC ", templateSpec.OrderBy)
                       : string.Format("{0} DESC", templateSpec.OrderBy));
                templates = templates.OrderBy(orderbystring);
            }

            if (templateSpec.Page.HasValue)
            {
                templates = templates.Skip((templateSpec.Page.Value - 1) * templateSpec.PageSize);
            }

            var list = new List<AccountabilityTemplate>();
            foreach (var template in templates.ToList())
            {
                var templateDetails = new AccountabilityTemplate()
                {
                    AlertId = template.UserAlertBaseId,
                    ProviderId = template.ProviderId
                };
                templateDetails.FromEntity(template);

                if (isLoadBase)
                    alertBaseMgr.DeserializeAlertSpecification(templateDetails);
                list.Add(templateDetails);
            }


            ResolveTemplateUserNames(list);


            return list;
        }

        /// <summary>
        /// To get the template.
        /// </summary>
        /// <param name="templateId">template Id.</param>
        /// <param name="providerId">provider Id.</param>
        /// <param name="operatorId">operator Id.</param>
        /// <returns>template details.</returns>
        public AccountabilityTemplate GetTemplate(int providerId, int operatorId, int templateId)
        {
            if (templateId == 0)
            {
                return GetNewTemplate(providerId, operatorId);
            }

            var alertBaseMgr = new AlertBaseManager(providerId, operatorId);
            try
            {
                //IQueryable of Templates
                var templates = _accountabilityRepository.GetTemplates();
                if (templates == null) return null;

                var acctTemplate = templates.FirstOrDefault(t => t.ProviderId == providerId && t.TemplateId == templateId);
                if (acctTemplate == null)
                {
                    throw new Exception(string.Format("No Template found in the system with ID: {0} for Provider: {1}",
                        templateId,
                        providerId));
                }

                var templateDetails = new AccountabilityTemplate
                {
                    AlertId = acctTemplate.UserAlertBaseId,
                    ProviderId = acctTemplate.ProviderId
                };

                alertBaseMgr.DeserializeAlertSpecification(templateDetails);
                //Operator alert Base 
                if (acctTemplate.OperatorAlertBaseId != null && acctTemplate.OperatorAlertBaseId > 0)
                {
                    templateDetails.OperatorAlertBase = new AccountabilityAlertBase { AlertId = (int)acctTemplate.OperatorAlertBaseId };
                    alertBaseMgr.DeserializeAlertSpecification(templateDetails.OperatorAlertBase);
                }

                templateDetails.FromEntity(acctTemplate);
                templateDetails.RecipientRefreshIntervalDuration = templateDetails.RecipientRefreshIntervalDuration ??
                                                                   GetDefaultRecipientRefreshInterval();

                var templateList = new List<AccountabilityTemplate> { templateDetails };
                ResolveTemplateUserNames(templateList);

                return templateDetails;
            }

            catch (Exception ex)
            {
                EventLogger.WriteError(ex);
                throw;
            }
        }

        private AccountabilityTemplate GetNewTemplate(int providerId, int operatorId)
        {
            //var baseScenarioId = 8240; // todo: define per VPS 
            string baseScenarioCommonName = "ACCOUNT-BASE";
            var scenarios = _scenarioFacade.GetScenarios(providerId, operatorId,
                new ScenarioSearchSpec() { CommonName = baseScenarioCommonName }).ToList();
            Alert alert;
            if (scenarios.Count == 0)
            {
                LogService.Current.Error(
                    () =>
                        string.Format(
                            IWSResources.PA_Template_CreateTemplate_ScenarioNotFound_Message,
                            baseScenarioCommonName));
                alert = _alertFacade.CreateAlert(providerId, operatorId);
                //return null;
            }
            else
            {
                alert = _alertFacade.CreateAlertFromScenario(providerId, operatorId, scenarios[0].ScenarioId);
            }

            if (alert == null)
            {
                LogService.Current.Error(() => string.Format(IWSResources.PA_Template_CreateTemplate_Failed_Messagess, baseScenarioCommonName));
                return null;
            }

            var template = new AccountabilityTemplate();
            alert.CopyTo(template);

            var eventPlaceholders = _placeholderFacade.GetEventPlaceholders(template.Locale.LocaleCode);
            // Event Title
            var eventTitle =
                eventPlaceholders.Single(e => e.EventPlaceholderId == AccountabilityEventPlaceHolders.AccountabilityName.ToString()).EventPlaceholderDisplayName;
            //Event Description
            var eventDescription =
                eventPlaceholders.Single(e => e.EventPlaceholderId == AccountabilityEventPlaceHolders.AccountabilityDescription.ToString()).EventPlaceholderDisplayName;
            //Event Start Time
            var eventStartTime =
               eventPlaceholders.Single(e => e.EventPlaceholderId == AccountabilityEventPlaceHolders.AccountabilityStartTime.ToString()).EventPlaceholderDisplayName;

            // default values for new template
            template.Name = IWSResources.PA_Template_DefaultName;

            // IWS - 26241
            //template.Description = IWSResources.PA_Template_Details_Description_WaterMark_Text;
            template.PastStatusValidityDuration = new Duration(DurationUnit.Hour, 0);
            var defaultRefreshDuration = GetDefaultRecipientRefreshInterval();
            if (defaultRefreshDuration != null)
            {
                template.RecipientRefreshIntervalDuration = defaultRefreshDuration; //Set default 2 Min.
            }
            template.FirstAlertUserMessage = new AccountabilityMessage()
           {
               Title = eventTitle,
               Body = eventDescription,
               IsEnabled = true,
           };
            template.ReminderAlertUserMessage = new AccountabilityMessage()
            {
                Title = string.Format(IWSResources.PA_Event_Reminder_Subject_Text, eventTitle),
                Body = string.Format(IWSResources.PA_Event_Reminder_Body_Text, eventStartTime, eventDescription),
                IsEnabled = true,
                AlertRepeatDuration = new Duration(DurationUnit.Minute, 30)
            };
            template.CloseAlertUserMessage = new AccountabilityMessage()
            {
                Title = string.Format(IWSResources.PA_Event_EndAlert_Subject_Text, eventTitle),
                Body = string.Format(IWSResources.PA_Event_EndAlert_Body_Text, eventDescription),
                IsEnabled = true
            };
            template.FirstAlertOperatorMessage = new AccountabilityMessage()
            {
                Title = string.Format(IWSResources.PA_Event_Start_Operator_Alert_Subject_Text, eventTitle),
                Body = string.Format(IWSResources.PA_Event_Start_Operator_Alert_Body_Text, eventDescription),
                IsEnabled = true,
            };
            template.CloseAlertOperatorMessage = new AccountabilityMessage()
            {
                Title = string.Format(IWSResources.PA_Event_End_Operator_Alert_Subject_Text, eventTitle),
                Body = string.Format(IWSResources.PA_Event_End_Operator_Alert_Body_Text, eventDescription),
                IsEnabled = true
            };
            return template;
        }

        /// <summary>
        /// To create the template.
        /// </summary>
        /// <param name="templateDetails">template details.</param>
        /// <param name="operatorId">operator Id.</param>
        /// <returns>templte Id.</returns>
        public int CreateTemplate(int operatorId, AccountabilityTemplate templateDetails)
        {
            var alertBaseMgr = new AlertBaseManager(templateDetails.ProviderId, operatorId);
            try
            {
                templateDetails.Status = AccountabilityTemplateStatus.Active.GetDescription();
                templateDetails.UpdatedBy = operatorId;
                templateDetails.UpdatedOn = DateTimeConverter.GetSystemTime(); //save DB time
                templateDetails.CreatedBy = operatorId;
                templateDetails.CreatedOn = DateTimeConverter.GetSystemTime(); //save DB time
                if (templateDetails.RecipientRefreshIntervalDuration == null || templateDetails.RecipientRefreshIntervalDuration.Value <= 0)
                {
                    templateDetails.RecipientRefreshIntervalDuration = GetDefaultRecipientRefreshInterval(); //Set default 2 Min.
                }

                if (string.IsNullOrEmpty(templateDetails.CommonName))
                {
                    templateDetails.CommonName = Guid.NewGuid().ToString();
                }

                using (var ngadDb = new NgadDatabase())
                {

                    // we need to save the scenario settings as well
                    int publishLayoutConfigId = PublishLayoutConfiguration.Save(templateDetails.PublishLayoutConfig);
                    templateDetails.AlertId = 0;//make sure to create new alert base
                    alertBaseMgr.SerializeAlertSpecification(templateDetails, ngadDb);

                    //Supervisor Alert 
                    if (templateDetails.OperatorAlertBaseId != null && templateDetails.OperatorAlertBase != null)
                    {
                        templateDetails.CopyTo(templateDetails.OperatorAlertBase, operatorId);
                        templateDetails.OperatorAlertBase.AlertId = 0;//make sure to create new alert base
                        alertBaseMgr.SerializeAlertSpecification(templateDetails.OperatorAlertBase, ngadDb);
                    }

                }
                var templateEntity = templateDetails.ToEntity();
                var templateId = _accountabilityRepository.CreateTemplate(templateEntity);

                //Make an audit log entry
                var auditSpec = new AuditSpec(operatorId, templateDetails.ProviderId)
                {
                    Action = ServiceAction.AccountabilityTemplateCreated,
                    ObjectType = EntityType.AccountabilityTemplate,
                    ObjectName = templateEntity.Name,
                    ObjectIds = new List<int>() { templateId }
                };
                OperationAuditor.LogAction(auditSpec);

                return templateId;
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(IWSResources.PA_Template_Create_Error_Message, ex);
                return -1;
            }
        }

        /// <summary>
        /// To update the template.
        /// </summary>
        /// <param name="templateDetails">template details.</param>
        /// <param name="operatorId">operator Id.</param>
        /// <returns>accountability template.</returns>
        public bool UpdateTemplate(int operatorId, AccountabilityTemplate templateDetails)
        {
            if (templateDetails.RecipientRefreshIntervalDuration == null || templateDetails.RecipientRefreshIntervalDuration.Value <= 0)
            {
                templateDetails.RecipientRefreshIntervalDuration = GetDefaultRecipientRefreshInterval(); //Set default 2 Min.
            }

            var alertBaseMgr = new AlertBaseManager(templateDetails.ProviderId, operatorId);
            try
            {
                PublishLayoutConfiguration.Save(templateDetails.PublishLayoutConfig);
                templateDetails.UpdatedBy = operatorId;
                templateDetails.UpdatedOn = DateTimeConverter.GetSystemTime();
                using (var ngadDb = new NgadDatabase())
                {
                    alertBaseMgr.SerializeAlertSpecification(templateDetails, ngadDb);
                }
                var templateEntity = templateDetails.ToEntity();
                var updateOperationResult = _accountabilityRepository.UpdateTemplate(templateEntity);

                if (updateOperationResult)
                {
                    //Make an audit log entry
                    var auditSpec = new AuditSpec(operatorId, templateDetails.ProviderId)
                    {
                        Action = ServiceAction.AccountabilityTemplateUpdated,
                        ObjectType = EntityType.AccountabilityTemplate,
                        ObjectName = templateDetails.Name,
                        ObjectIds = new List<int>() { templateDetails.TemplateId }
                    };
                    OperationAuditor.LogAction(auditSpec);
                }

                return updateOperationResult;
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(IWSResources.PA_Template_Update_Error_Message, ex);
                return false;
            }
        }

        /// <summary>
        /// Duplicate the template.
        /// </summary>
        /// <param name="templateId">template Id.</param>
        /// <param name="providerId">provider Id.</param>
        /// <param name="operatorId">operator Id.</param>
        /// <returns>accountability template.</returns>
        public AccountabilityTemplate DuplicateTemplate(int providerId, int operatorId, int templateId)
        {
            if (templateId == 0)
            {
                throw new ArgumentNullException("templateId", string.Format(IWSResources.PA_Template_Duplicate_ID_ZERO_Error_Message));
            }

            var alertBaseMgr = new AlertBaseManager(providerId, operatorId);
            try
            {
                //IQueryable of Templates
                var templates = _accountabilityRepository.GetTemplates();
                if (templates == null)
                {
                    throw new Exception(IWSResources.PA_Template_Duplicate_IQInstance_Null_Error_Message);
                }

                var acctTemplate = templates.FirstOrDefault(t => t.ProviderId == providerId && t.TemplateId == templateId);
                if (acctTemplate == null)
                {
                    throw new Exception(IWSResources.PA_Template_Duplicate_IQInstance_Null_Error_Message);
                }

                var templateDetails = new AccountabilityTemplate
                {
                    AlertId = acctTemplate.UserAlertBaseId,
                    ProviderId = acctTemplate.ProviderId
                };
                alertBaseMgr.DeserializeAlertSpecification(templateDetails);

                templateDetails.FromEntity(acctTemplate);
                templateDetails.RecipientRefreshIntervalDuration = templateDetails.RecipientRefreshIntervalDuration ??
                                                                   GetDefaultRecipientRefreshInterval();
                return templateDetails;
            }

            catch (Exception ex)
            {
                EventLogger.WriteError(ex);
                return null;
            }


        }

        /// <summary>
        /// To delete the template.
        /// </summary>
        /// <param name="ids">template Ids.</param>
        /// <param name="providerId">provider Id.</param>
        /// <param name="operatorId">operator Id.</param>
        /// <returns></returns>
        public bool DeleteTemplates(int providerId, int operatorId, IEnumerable<int> ids)
        {
            var templateIds = ids as int[] ?? ids.ToArray();
            if (!templateIds.Any())
            {
                throw new ArgumentNullException("ids");
            }
            try
            {
                var templates = _accountabilityRepository.DeleteTemplates(operatorId, templateIds);

                foreach (var templateEntity in templates)
                {
                    var auditSpec = new AuditSpec();
                    auditSpec.Action = ServiceAction.AccountabilityTemplateDeleted;
                    auditSpec.ObjectType = EntityType.AccountabilityTemplate;
                    auditSpec.OperatorId = operatorId;
                    auditSpec.ObjectName = templateEntity.Name;
                    auditSpec.ProviderId = providerId;
                    auditSpec.ObjectIds = new List<int>() { templateEntity.TemplateId };

                    OperationAuditor.LogAction(auditSpec);
                }
                return true;
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format(IWSResources.PA_Template_Delete_Rules_Error_Message), ex);
                return false;

            }
        }

        #endregion

        #region event methods

        /// <summary>
        /// To get events.
        /// </summary>
        /// <param name="eventSpec">event spec.</param>
        /// <returns>events.</returns>
        public IPaged<AccountabilityEvent> GetEvents(AccountabilityEventSpec eventSpec)
        {
            if (!eventSpec.OperatorId.HasValue)
            {
                throw new ArgumentNullException(IWSResources.PA_Event_EventSpec_ErrorTitle, IWSResources.PA_Event_EventSpec_OperatorIdNull_ErrorBody);
            }
            if (eventSpec.ProviderId == 0)
            {
                throw new ArgumentNullException(IWSResources.PA_Event_EventSpec_ErrorTitle, IWSResources.PA_Event_EventSpec_ProviderIdNull_ErrorBody);
            }

            var pagedEvents = new Paged<AccountabilityEvent>();

            //[Sequence:1]
            //Get Events raw query from dbcontext
            var events = _accountabilityRepository.GetEventsIncludeAll();

            //[Sequence:2]
            //Apply filter to event query.
            events = ApplyFiltersToEventEntities(events, eventSpec);

            //[Sequence:3]
            //if pagesize is provided, then get the total could
            if (eventSpec.Page != null)
            {
                pagedEvents.SetTotalCount(events.Count());
            }

            //[Sequence:4]
            events = ApplySortingAndPagingToEventEntities(events, eventSpec);

            var eventList = new List<AccountabilityEvent>();

            var alertBaseMgr = new AlertBaseManager(eventSpec.ProviderId, eventSpec.OperatorId.Value);
            var userIds = new HashSet<int>();
            foreach (var eventEntity in events)
            {
                var actEvent = new AccountabilityEvent();

                actEvent.FromEntity(eventEntity, !eventSpec.IncludeReminderAlertDetails, eventSpec.IncludeEventStatistics);

                if (eventSpec.IsLoadBaseDetails)
                {
                    alertBaseMgr.DeserializeAlertSpecificationForAccountability(actEvent);
                }
                userIds.Add(actEvent.CreatedBy);
                userIds.Add(actEvent.UpdatedBy);
                userIds.Add(actEvent.StartedBy.GetValueOrDefault());
                userIds.Add(actEvent.EndedBy.GetValueOrDefault());

                eventList.Add(actEvent);
            }

            var evtIds = events.Select(e => e.EventId).ToArray();
            if (eventSpec.IncludeReminderAlertDetails)
            {

                var evtAlertDetails = _accountabilityRepository.GetEventAlertDetails(evtIds).ToDictionary(e => e.AlertId);
                foreach (var accountabilityEvent in eventList)
                {
                    foreach (var alert in accountabilityEvent.AssociatedAlerts)
                    {
                        AccountabilityEventAlert detail;
                        if (evtAlertDetails.TryGetValue(alert.AlertId, out detail))
                        {
                            alert.AlertStatus = detail.AlertStatus;
                            alert.AlertTitle = detail.AlertTitle;
                            alert.AlertBody = detail.AlertBody;
                            alert.PublishedOn = detail.PublishedOn;
                            alert.TotalUser = detail.TotalUser;
                        }
                    }
                }

            }

            ResolveEventUserNames(eventList, userIds);

            pagedEvents.SetList(eventList);
            if (eventSpec.Page != null) pagedEvents.SetCurrentPageNumber(eventSpec.Page.Value);
            pagedEvents.SetPageSize(eventSpec.PageSize);
            return pagedEvents;
        }


        /// <summary>
        /// Get Accountability Event
        /// </summary>
        /// <param name="eventSpec">Object of type AccountabilityEventSpec </param>
        /// <returns>event details.</returns>
        public AccountabilityEvent GetEvent(AccountabilityEventSpec eventSpec)
        {
            if (!eventSpec.OperatorId.HasValue)
            {
                throw new ArgumentNullException(IWSResources.PA_Event_EventSpec_ErrorTitle, IWSResources.PA_Event_EventSpec_OperatorIdNull_ErrorBody);
            }
            if (eventSpec.ProviderId == 0)
            {
                throw new ArgumentNullException(IWSResources.PA_Event_EventSpec_ErrorTitle, IWSResources.PA_Event_EventSpec_ProviderIdNull_ErrorBody);
            }

            var alertBaseMgr = new AlertBaseManager(eventSpec.ProviderId, eventSpec.OperatorId.Value);
            try
            {
                var eventEntity = _accountabilityRepository.GetEvent(eventSpec.EventId, !eventSpec.IncludeReminderAlertDetails);
                if (eventEntity == null)
                    throw new Exception(string.Format("No Event found in the system with ID: {0}", eventSpec.EventId));

                if (eventEntity.ProviderId != eventSpec.ProviderId)
                    throw new Exception(string.Format("No Event found in the system with ID: {0} for Provider: {1}",
                        eventEntity.EventId,
                        eventSpec.ProviderId));

                var actEvent = new AccountabilityEvent
                {
                    AlertId = eventEntity.UserAlertBaseId,
                    ProviderId = eventEntity.ProviderId
                };
                if (eventSpec.IsLoadBaseDetails)
                {
                    alertBaseMgr.DeserializeAlertSpecificationForAccountability(actEvent);
                    //Supervisor Alert
                    if (eventEntity.OperatorAlertBaseId != null)
                    {
                        actEvent.OperatorAlertBase = new AccountabilityAlertBase { AlertId = (int)eventEntity.OperatorAlertBaseId };
                        alertBaseMgr.DeserializeAlertSpecificationForAccountability(actEvent.OperatorAlertBase);
                    }
                }
                actEvent.FromEntity(eventEntity, !eventSpec.IncludeReminderAlertDetails, eventSpec.IncludeEventStatistics);

                var userIds = new HashSet<int>();
                userIds.Add(actEvent.CreatedBy);
                userIds.Add(actEvent.UpdatedBy);
                userIds.Add(actEvent.StartedBy.GetValueOrDefault());
                userIds.Add(actEvent.EndedBy.GetValueOrDefault());

                if (eventSpec.IncludeReminderAlertDetails)
                {

                    IQueryable<AccountabilityEventAlert> eventAlertQuery;
                    if (_userFacade.HasRestrictedUserBase(eventSpec.OperatorId.Value))
                    {
                        int sessionId = 0;
                        sessionId = GetSessionId(new EventStatusSpec { BaseLocale = eventSpec.BaseLocale, ProviderId = eventSpec.ProviderId, EventId = eventSpec.EventId, OperatorId = eventSpec.OperatorId.Value, SessionId = sessionId });
                        eventAlertQuery = _accountabilityRepository.GetEventAlertDetails(eventSpec.EventId, sessionId);
                    }
                    else
                    {
                        eventAlertQuery = _accountabilityRepository.GetEventAlertDetails(new[] { eventSpec.EventId });
                    }

                    var evtAlertDetails = eventAlertQuery.ToDictionary(e => e.AlertId);
                    foreach (var alert in actEvent.AssociatedAlerts)
                    {
                        AccountabilityEventAlert detail;
                        if (evtAlertDetails.TryGetValue(alert.AlertId, out detail))
                        {
                            alert.AlertStatus = detail.AlertStatus;
                            alert.AlertTitle = detail.AlertTitle;
                            alert.AlertBody = detail.AlertBody;
                            alert.PublishedOn = detail.PublishedOn;
                            alert.TotalUser = detail.TotalUser;
                            alert.AlertType = detail.AlertType;
                        }
                    }
                }

                ResolveEventUserNames(new List<AccountabilityEvent>() { actEvent }, userIds);

                return actEvent;
            }

            catch (Exception ex)
            {
                EventLogger.WriteError(ex);
                throw;
            }
        }
        public IEnumerable<AccountabilityEventAlert> GetAccountabilityEventAlerts(int eventid, bool includedetails = false)
        {
            var resultSet = new List<AccountabilityEventAlert>();
            //_accountabilityRepository.GetEventOvertimeMessageSentEntity();
            return resultSet;
        }
        /// <summary>
        /// To create the event.
        /// </summary>
        /// <param name="actTemplate">accountability template.</param>
        /// <param name="operatorId">operatorId.</param>
        /// <param name="providerId"></param>
        /// <returns>event Id.</returns>
        public int CreateEvent(int operatorId, int providerId, AccountabilityTemplate actTemplate)
        {
            int accountabilityEventId = -1;
            bool isSuccess = true;
            if (actTemplate == null)
            {
                throw new ArgumentNullException("actTemplate", @"AccountabilityTemplate actTemplate cannot be null while creating event");
            }

            var alertBaseMgr = new AlertBaseManager(providerId, operatorId);
            var currentVpsTime = alertBaseMgr.Provider.DateTimeConverter.SystemToVps(DateTime.Now);
            try
            {
                var actEvent = new AccountabilityEvent();
                using (var ngadDb = new NgadDatabase())
                {
                    actTemplate.CopyTo(actEvent, operatorId);
                    alertBaseMgr.SerializeAlertSpecification(actEvent, ngadDb);

                    //Operator Alert 
                    if (actTemplate.OperatorAlertBase != null)
                    {
                        actEvent.OperatorAlertBase = new AccountabilityAlertBase();
                        actTemplate.CopyTo(actEvent.OperatorAlertBase, operatorId);
                        alertBaseMgr.SerializeAlertSpecification(actEvent.OperatorAlertBase, ngadDb);

                    }

                }
                var createdTime = DateTimeConverter.GetSystemTime(); //save DB time


                if (actTemplate.RecipientRefreshIntervalDuration == null || actTemplate.RecipientRefreshIntervalDuration.Value == 0)
                {
                    actTemplate.RecipientRefreshIntervalDuration = GetDefaultRecipientRefreshInterval();
                }
                //Populate Event property from template object.
                actEvent.FromTemplate(actTemplate);
                actEvent.Status = AccountabilityEventStatus.Publishing;
                actEvent.CreatedOn = createdTime;
                actEvent.UpdatedOn = createdTime;
                actEvent.CreatedBy = operatorId;
                actEvent.UpdatedBy = operatorId;
                actEvent.AlertSpec.Content.Header = ReplacePlaceHolders(actEvent.AlertSpec.Content.Header, actEvent);
                actEvent.AlertSpec.Content.Body = ReplacePlaceHolders(actEvent.AlertSpec.Content.Body, actEvent);
                var acctEventEtity = actEvent.ToEntity();
                acctEventEtity.EventUniqueId = Guid.NewGuid().ToString();

                //Create event.
                accountabilityEventId = _accountabilityRepository.CreateEvent(acctEventEtity);

                //Make an audit log entry
                var auditSpec = new AuditSpec(operatorId, acctEventEtity.ProviderId)
                {
                    Action = ServiceAction.AccountabilityEventCreated,
                    ObjectType = EntityType.AccountabilityEvent,
                    ObjectName = acctEventEtity.Name,
                    ObjectIds = new List<int>() { accountabilityEventId }
                };
                OperationAuditor.LogAction(auditSpec);

                //Make sure to update the EventAlertMapID - otherwise MAP ID FROM ACCT_TEMPLATE_ALERT_MAP_TAB will be used.
                var tempMapEntity =
                    acctEventEtity.AccountabilityEventAlertMapEntities.First(
                        e => e.AlertInitType == AccountabilityEventAlertType.Start.ToString() && e.AlertType == AccountabilityEventUserType.User.GetDescription());
                if (tempMapEntity != null)
                {
                    actEvent.FirstAlertUserMessage.MessageId = tempMapEntity.Id;
                }
                if (actEvent.FirstAlertOperatorMessage!=null)
                {
                     var tempOprMapEntity =
                    acctEventEtity.AccountabilityEventAlertMapEntities.First(
                        e => e.AlertInitType == AccountabilityEventAlertType.Start.ToString() && e.AlertType == AccountabilityEventUserType.Operator.GetDescription());
                     if (tempOprMapEntity != null)
                {
                    actEvent.FirstAlertOperatorMessage.MessageId = tempOprMapEntity.Id;
                }
                }
                actEvent.EventId = accountabilityEventId;
                //Set the Event User Status.
                SetEventUserStatus(accountabilityEventId, actTemplate.AlertSpec.Content.ResponseOptionsAttributeID);

                //set the event pickup schedule.
                var alertRepeatDuration = actEvent.ReminderAlertUserMessage != null
                    ? actEvent.ReminderAlertUserMessage.AlertRepeatDuration
                    : null;

                SetEventPickupSchedule(accountabilityEventId, acctEventEtity.StartDate, actEvent.RecipientRefreshIntervalDuration,
                    alertRepeatDuration);

                //Populate Event Recipient - For start event - All user belongs to Alert Targeting should be populated. No need to specify EBT criteria.
                PopulateEventRecipient(actEvent, operatorId, false);

                //publish event if starttime is now.
                if (actEvent.StartDate <= DateTime.Now)
                {
                    PublishEventAlert(providerId, operatorId, AccountabilityEventAlertType.Start, actEvent, currentVpsTime,true);
                    //Update the Event Status to Live .
                    var eventIds = new List<int> { actEvent.EventId };
                    _accountabilityRepository.UpdateEventStatus(operatorId, eventIds, AccountabilityEventStatus.Live);

                    //Make an audit log entry
                    auditSpec.Action = ServiceAction.AccountabilityEventPublished;
                    OperationAuditor.LogAction(auditSpec);
                }


            }
            catch (Exception ex)
            {
                EventLogger.WriteError(IWSResources.PA_Event_Publish_Error_Message, ex);
                isSuccess = false;
            }
            finally
            {
                //If event is already create, and error occurs after creation, make sure to delete such entry.
                if (accountabilityEventId > 0 && !isSuccess)
                {
                    var eventsToEnd = new int[] { accountabilityEventId };
                    _accountabilityRepository.UpdateEventStatus(operatorId, eventsToEnd,
                        AccountabilityEventStatus.Deleted);
                    accountabilityEventId = -1;
                }
            }
            return accountabilityEventId;
        }



        /// <summary>
        /// To publish the event.
        /// </summary>
        /// <param name="providerId">provider Id.</param>
        /// <param name="operatorId">operator Id.</param>
        /// <param name="actEventType">Accountability event type.</param>
        /// <param name="actEvent">acctuntability event.</param>
        /// <returns></returns>
        private Tuple<int, int> PublishEventAlert(int providerId, int operatorId, AccountabilityEventAlertType actEventType, AccountabilityEvent actEvent, DateTime currentVpsTime, bool publishAsync)
        {
            var eventAlertMapId = 0;
            var oprEventAlertMapId = 0;
            var sendAlert = false;
            var excludeResponses = false;
            switch (actEventType)
            {
                case AccountabilityEventAlertType.Close:
                    if (actEvent.CloseAlertUserMessage != null && actEvent.CloseAlertUserMessage.IsEnabled)
                    {
                        sendAlert = true;

                        actEvent.AlertSpec.Content.Header = ReplaceEventPlaceHolder(actEvent.CloseAlertUserMessage.Title, actEvent, actEvent.StartDate);
                        actEvent.AlertSpec.Content.Body = ReplaceEventPlaceHolder(actEvent.CloseAlertUserMessage.Body, actEvent, actEvent.StartDate);
                        actEvent.AlertSpec.Content.ResponseOptions = null;
                        actEvent.AlertSpec.Content.ResponseOptionsAttributeID = 0;
                        actEvent.AlertSpec.Priority = Priority.Informational;
                        eventAlertMapId = actEvent.CloseAlertUserMessage.MessageId;
                    }
                    //Operator alert message
                    if (actEvent.OperatorAlertBase != null && actEvent.CloseAlertOperatorMessage != null && actEvent.CloseAlertOperatorMessage.IsEnabled)
                    {
                        sendAlert = true;
                        actEvent.OperatorAlertBase.AlertSpec.Content.Header = ReplaceEventPlaceHolder(actEvent.CloseAlertOperatorMessage.Title, actEvent, actEvent.StartDate);
                        actEvent.OperatorAlertBase.AlertSpec.Content.Body = ReplaceEventPlaceHolder(actEvent.CloseAlertOperatorMessage.Body, actEvent, actEvent.StartDate);
                        actEvent.OperatorAlertBase.AlertSpec.Content.ResponseOptions = null;
                        actEvent.OperatorAlertBase.AlertSpec.Content.ResponseOptionsAttributeID = 0;
                        actEvent.OperatorAlertBase.AlertSpec.Priority = Priority.Informational;
                        oprEventAlertMapId = actEvent.CloseAlertOperatorMessage.MessageId;
                    }
                    break;
                case AccountabilityEventAlertType.Start:
                    if (actEvent.FirstAlertUserMessage != null && actEvent.FirstAlertUserMessage.IsEnabled)
                    {
                        sendAlert = true;

                        actEvent.AlertSpec.Content.Header = ReplaceEventPlaceHolder(actEvent.FirstAlertUserMessage.Title, actEvent, actEvent.StartDate);
                        actEvent.AlertSpec.Content.Body = ReplaceEventPlaceHolder(actEvent.FirstAlertUserMessage.Body, actEvent, actEvent.StartDate);
                        eventAlertMapId = actEvent.FirstAlertUserMessage.MessageId;
                    }
                    //Operator alert message
                    if (actEvent.OperatorAlertBase != null && actEvent.FirstAlertOperatorMessage != null && actEvent.FirstAlertOperatorMessage.IsEnabled)
                    {
                        sendAlert = true;

                        actEvent.OperatorAlertBase.AlertSpec.Content.Header = ReplaceEventPlaceHolder(actEvent.FirstAlertOperatorMessage.Title, actEvent, actEvent.StartDate);
                        actEvent.OperatorAlertBase.AlertSpec.Content.Body = ReplaceEventPlaceHolder(actEvent.FirstAlertOperatorMessage.Body, actEvent, actEvent.StartDate);
                        oprEventAlertMapId = actEvent.FirstAlertOperatorMessage.MessageId;
                    }
                    break;
                case AccountabilityEventAlertType.Reminder:
                    if (actEvent.ReminderAlertUserMessage != null && actEvent.ReminderAlertUserMessage.IsEnabled)
                    {
                        sendAlert = true;
                        actEvent.AlertSpec.Content.Header = ReplaceEventPlaceHolder(actEvent.ReminderAlertUserMessage.Title, actEvent, actEvent.StartDate);
                        actEvent.AlertSpec.Content.Body = ReplaceEventPlaceHolder(actEvent.ReminderAlertUserMessage.Body, actEvent, actEvent.StartDate);
                        eventAlertMapId = actEvent.ReminderAlertUserMessage.MessageId;

                    }
                    break;
            }
            if (!sendAlert)
            {
                return null;
            }

            //create event alert obj.
            var alertManager = new AlertManager(providerId, operatorId);
            var alert = alertManager.CreateAlertFromAccountabilityEvent((AlertBase)actEvent, operatorId);
            alert.Origin.ScenarioId = actEvent.TemplateId;
            alert.Origin.ScenarioName = actEvent.Name;
            alert.CreatedBy = actEvent.CreatedBy;
            alert.UpdatedBy = actEvent.UpdatedBy;
            Alert operatorAlert = null;
            //Create alert obj for operator alert.
            if (actEvent.OperatorAlertBase != null)
            {
                operatorAlert = alertManager.CreateAlertFromAccountabilityEvent(actEvent.OperatorAlertBase, operatorId);
                operatorAlert.Origin.ScenarioId = actEvent.TemplateId;
                operatorAlert.Origin.ScenarioName = actEvent.Name;
                operatorAlert.CreatedBy = actEvent.CreatedBy;
                operatorAlert.UpdatedBy = actEvent.UpdatedBy;
                operatorAlert.AlertSpec.Targeting.TargetingCriteria = actEvent.OperatorAlertBase.AlertSpec.Targeting.TargetingCriteria;
                operatorAlert.AlertSpec.Content.ResponseOptions = null;
                operatorAlert.AlertSpec.Content.Url = ConfigurationManager.GetURL() + "/AtHoc-IWS/Account/Events?id=" + actEvent.EventId + "&providerId=" + providerId + "&tab=users";
            }

            if (actEventType == AccountabilityEventAlertType.Close)
            {
                var endTime = currentVpsTime.AddMinutes(30); //Set endtime for ending alert - 30 min from now.
                var ebtTargeted = new EventBasedCriteria(new[] { actEvent.EventId }, EventCriteriaOperator.TARGETED);
                alert.AlertSpec.Targeting.TargetingCriteria = ebtTargeted.ToSearchCriterias();
                alert.EndTime = endTime;
                //operator alert endtime 
                if (actEvent.OperatorAlertBase != null && operatorAlert != null)
                {
                    operatorAlert.EndTime = endTime;
                }
            }
            else if (actEventType == AccountabilityEventAlertType.Start || actEventType == AccountabilityEventAlertType.Reminder)
            {
                var ebtTargeted = new EventBasedCriteria(new[] { actEvent.EventId }, EventCriteriaOperator.NORESPONSE);
                alert.AlertSpec.Targeting.TargetingCriteria = ebtTargeted.ToSearchCriterias();
            }

            //To support UAP integration, it needs to pass eventId as a part of Attachment.
            var eventAttachtment = new AlertAttachment(AttachmentType.PAEvent, actEvent.EventId, AttachmentSubType.None);
            alert.AlertSpec.Advanced.AddAttachment(eventAttachtment);
            // publish the alert. 
            alertManager.SaveAlert(alert, false, publishAsync); //Send User Alert Asynchronously
            //add event alert entry.
            var actEventAlert = new AccountabilityEventAlertEntity
            {
                AlertId = alert.AlertId,
                EventId = actEvent.EventId,
                AccountabilityEventAlertMapId = eventAlertMapId
            };
            var actEventAlertId = _accountabilityRepository.CreateEventAlert(actEventAlert);
            //publish operator alert
            var actOprEventAlertId = 0;
            if (operatorAlert != null)
            {
                alertManager.SaveAlert(operatorAlert, false, publishAsync); //Send Operator Alert Asynchronously
                var actOprEventAlert = new AccountabilityEventAlertEntity
                {
                    AlertId = operatorAlert.AlertId,
                    EventId = actEvent.EventId,
                    AccountabilityEventAlertMapId = oprEventAlertMapId
                };
                actOprEventAlertId = _accountabilityRepository.CreateEventAlert(actOprEventAlert);
            }

            return new Tuple<int, int>(actEventAlertId, actOprEventAlertId);
        }

        /// <summary>Checks if an event is valid.</summary>
        /// <param name="eventId">Event id.</param>
        /// <param name="providerId">Provider Id.</param>
        /// <param name="operatorId">Operator Id.</param>
        /// <returns>True if event is valid.</returns>
        public bool CheckEventValidity(int eventId, int providerId, int operatorId)
        {
            var eventSpec = new AccountabilityEventSpec
            {
                EventId = eventId,
                ProviderId = providerId,
                OperatorId = operatorId,
                IncludeReminderAlertDetails = false,
                IncludeEventStatistics = false,
                IsLoadBaseDetails = false
            };

            try
            {
                var accountabilityEvent = GetEvent(eventSpec);
                return accountabilityEvent != null;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        /// <summary>
        /// To set the Event Pickup Schedule.
        /// </summary>
        /// <param name="eventId">event Id.</param>
        /// <param name="eventTime">event time.</param>
        /// <param name="alertRepeatInterval">alert repeat interval.</param>
        /// <param name="recipientRecomputeDuration">recipient recompute duration.</param>
        private void SetEventPickupSchedule(int eventId, DateTime eventTime, Duration recipientRecomputeDuration, Duration alertRepeatInterval)
        {

            var dbSetAccountabilityEventPickupScheduleEntity = new List<AccountabilityEventPickupScheduleEntity>();


            if (alertRepeatInterval != null)
            {
                var reminderActionEntity = new AccountabilityEventPickupScheduleEntity { EventId = eventId };
                reminderActionEntity.PickupActionType = AccountabilityEventJobPickupType.Reminder.GetDescription();
                reminderActionEntity.NextRunTime = alertRepeatInterval.GetEndTime(eventTime);
                //actionEntity.UserAlertReminderNextSendTime = alertRepeatInterval.GetEndTime(eventTime);
                dbSetAccountabilityEventPickupScheduleEntity.Add(reminderActionEntity);
            }


            if (recipientRecomputeDuration != null)
            {
                var recomputeUserEntity = new AccountabilityEventPickupScheduleEntity { EventId = eventId };
                recomputeUserEntity.PickupActionType = AccountabilityEventJobPickupType.Recompute.GetDescription();
                recomputeUserEntity.NextRunTime = recipientRecomputeDuration.GetEndTime(eventTime);
                dbSetAccountabilityEventPickupScheduleEntity.Add(recomputeUserEntity);
                // actionEntity.EventRecipientNextRecomputeTime = recipientRecomputeDuration.GetEndTime(eventTime);
            }
            else
            {
                EventLogger.WriteError("Recompute Recipient Duration cannot be null. Method: SetEventPickupSchedule");
            }

            _accountabilityRepository.AddEventPickupSchedule(dbSetAccountabilityEventPickupScheduleEntity);
        }

        private string ReplacePlaceHolders(string field, AccountabilityEvent accountabilityEvent)
        {
            var sysPlaceholders = new SystemPlaceholders();
            //get system placeholders
            var systemPlaceholders = _placeholderFacade.GetSystemPlaceHolders(sysPlaceholders,
                accountabilityEvent.ProviderId, 1);
            field = ReplaceSystemPlaceholderInText(field, systemPlaceholders);

            return field;
        }
        private static string ReplaceSystemPlaceholderInText(string text, IEnumerable<PlaceHolder> systemPlaceHolders)
        {

            //Replace with system placeholder
            if (text.Contains("[[") && text.Contains("]]"))
            {
                if (systemPlaceHolders != null)
                {
                    foreach (var placeholder in systemPlaceHolders)
                    {
                        var key = string.Format("[[{0}]]", placeholder.Name);
                        if (!text.Contains(key)) continue;
                        var defaultValue = placeholder.Values.FirstOrDefault(v => v.IsDefault);
                        text = text.Replace(key, defaultValue != null ? defaultValue.Value : string.Empty);
                    }
                }
            }

            return text;
        }

        /// <summary>
        /// Replace Placeholder for Message Preview
        /// </summary>
        /// <param name="field"></param>
        /// <param name="systemPlaceholders"></param>
        /// <param name="accountabilityStartDatePlaceHolderDisplayName"></param>
        /// <param name="accountabilityStartDatePlaceHolderValue"></param>
        /// <returns></returns>
        public string ReplacePlaceHoldersForPreviewMessage(string field, IEnumerable<PlaceHolder> systemPlaceholders, string accountabilityStartDatePlaceHolderDisplayName, string accountabilityStartDatePlaceHolderValue)
        {
            field = ReplaceSystemPlaceholderInText(field, systemPlaceholders);
            field = field.Replace(accountabilityStartDatePlaceHolderDisplayName, accountabilityStartDatePlaceHolderValue);
            return field;
        }

        /// <summary>
        /// To replace Event PlaceHolders.
        /// </summary>
        /// <param name="field">field.</param>
        /// <param name="starTime">event start time.</param>
        /// <param name="alertSpec">alertspecification.</param>
        /// <param name="accountabilityEvent"></param>
        /// <returns>filed with resolved placeholder value.</returns>
        private string ReplaceEventPlaceHolder(string field, AccountabilityEvent accountabilityEvent, DateTime starTime)
        {
            var alertSpec = accountabilityEvent.AlertSpec;
            var eventPlaceholders = _placeholderFacade.GetEventPlaceholders(accountabilityEvent.Locale.LocaleCode);
            field = field.Replace(eventPlaceholders.Single(e => e.EventPlaceholderId == AccountabilityEventPlaceHolders.AccountabilityName.ToString()).EventPlaceholderDisplayName, alertSpec.Content.Header);
            field = field.Replace(eventPlaceholders.Single(e => e.EventPlaceholderId == AccountabilityEventPlaceHolders.AccountabilityDescription.ToString()).EventPlaceholderDisplayName, alertSpec.Content.Body);
            field = field.Replace(eventPlaceholders.Single(e => e.EventPlaceholderId == AccountabilityEventPlaceHolders.AccountabilityStartTime.ToString()).EventPlaceholderDisplayName, starTime.ToString(CultureInfo.InvariantCulture));
            return field;
        }
        /// <summary>
        /// To set the Event User Status.
        /// </summary>
        /// <param name="eventId">event Id .</param>
        /// <param name="attributeId">status attribute Id.</param>
        private void SetEventUserStatus(int eventId, int attributeId)
        {
            var spec = new CustomAttributeSpec() { Ids = new[] { attributeId }, ApplyFeatureMatrix = false, IncludeValues = true };
            var statusAttribute = _customAttributeFacade.GetCustomAttributesBySpec(spec);

            if (statusAttribute == null) return;
            var userStatusList = statusAttribute.First().Values.ToDictionary(attributeValue => attributeValue.ValueId,
                attributeValue => attributeValue.SortOrder != null ? (int)attributeValue.SortOrder : 0);
            _accountabilityRepository.SetEventUserStatus(eventId, attributeId, userStatusList);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="actEvent"></param>
        /// <param name="operatorId"></param>
        /// <returns></returns>
        private Alert CreateAlertFromEvent(AccountabilityEvent actEvent, int operatorId = 0)
        {
            using (new MethodScope(actEvent))
            {
                try
                {
                    var alertBaseMgr = new AlertBaseManager(actEvent.ProviderId, operatorId);
                    var alert = new Alert();
                    var alertBase = ((AlertBase)actEvent);
                    alertBase.CopyTo(alert, operatorId);
                    alert.Origin.ProviderName = alertBaseMgr.Provider.Name;
                    alert.Origin.ScenarioId = actEvent.TemplateId;
                    alert.Origin.ScenarioName = actEvent.Name;
                    alert.CreatedBy = actEvent.UpdatedBy;
                    alert.UpdatedBy = actEvent.UpdatedBy;
                    return alert;

                }
                catch (Exception ex)
                {
                    EventLogger.WriteError(ex);
                    throw;
                }
            }
        }


        /// <summary>
        /// To update the event.
        /// </summary>
        /// <param name="operatorId">operatorId.</param>
        /// <param name="acctEvent">AccoutabilityEvent obj.></param>
        /// <returns>true if updated successfully.</returns>
        public bool UpdateEvent(int operatorId, AccountabilityEvent acctEvent)
        {
            var alertBaseMgr = new AlertBaseManager(acctEvent.ProviderId, operatorId);
            try
            {
                acctEvent.UpdatedBy = operatorId;
                using (var ngadDb = new NgadDatabase())
                {
                    alertBaseMgr.SerializeAlertSpecification(acctEvent, ngadDb);
                }
                var eventEntity = acctEvent.ToEntity();
                var updateOperationResult = _accountabilityRepository.UpdateEvent(eventEntity);

                if (updateOperationResult)
                {
                    //Make an audit log entry
                    var auditSpec = new AuditSpec(operatorId, acctEvent.ProviderId)
                    {
                        Action = ServiceAction.AccountabilityEventUpdated,
                        ObjectType = EntityType.AccountabilityEvent,
                        ObjectName = acctEvent.Name,
                        ObjectIds = new List<int>() { acctEvent.EventId }
                    };
                    OperationAuditor.LogAction(auditSpec);
                }

                return updateOperationResult;
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(IWSResources.PA_Event_Update_Error_Message, ex);
                return false;
            }
        }

        /// <summary>
        /// To end events.
        /// </summary>
        /// <param name="providerId">provider Id.</param>
        /// <param name="operatorId">operator Id.</param>
        /// <param name="ids">evnet ids.</param>
        /// <returns>true-if end action is successful.</returns>
        public bool EndEvents(int providerId, int operatorId, IEnumerable<int> ids)
        {

            try
            {
                var eventIds = ids as IList<int> ?? ids.ToList();


                var eventList = _accountabilityRepository.GetEventsIncludeAll().Where(e => eventIds.Contains(e.EventId));

                var alertBaseMgr = new AlertBaseManager(providerId, operatorId);
                var currentVpsTime = alertBaseMgr.Provider.DateTimeConverter.SystemToVps(DateTime.Now);
                foreach (var eventEntity in eventList)
                {
                    var actEvent = new AccountabilityEvent();
                    actEvent.FromEntity(eventEntity, includeReminders: true);
                    alertBaseMgr.DeserializeAlertSpecification(actEvent);
                    PublishEventAlert(providerId, operatorId, AccountabilityEventAlertType.Close, actEvent, currentVpsTime,true);
                    var arrayOfAlertId = eventEntity.AccountabilityEventAlertEntities.Where(e => e.AccountabilityEventAlertMap.AlertInitType != "Close").Select(e => e.AlertId).ToArray();
                    if (arrayOfAlertId.Length > 0)
                    {
                        foreach (var alertId in arrayOfAlertId)
                        {
                            _alertFacade.End(alertId, operatorId, eventEntity.ProviderId, DateTimeConverter.GetSystemTime());
                        }

                    }
                }

                _accountabilityRepository.UpdateEventStatus(operatorId, eventIds, AccountabilityEventStatus.Ended);

                //Make an audit log entry
                var auditSpec = new AuditSpec(operatorId, providerId)
                {
                    Action = ServiceAction.AccountabilityEventEnded,
                    ObjectType = EntityType.AccountabilityEvent,
                    ObjectName = "PA Event Ended",
                    ObjectIds = eventIds
                };
                OperationAuditor.LogAction(auditSpec);
                return true;

            }
            catch (Exception ex)
            {
                EventLogger.WriteError(IWSResources.PA_Event_End_Error_Message, ex);
                return false;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="eventId"></param>
        /// <returns></returns>
        public int GetEventProviderId(int providerId, int eventId)
        {
            try
            {
                return _accountabilityRepository.GetEventProviderId(providerId, eventId);
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("GetEventProviderId", ex);
                return -1;
            }
        }

        /// <summary>
        /// To delete events.
        /// </summary>
        /// <param name="providerId">provider Id.</param>
        /// <param name="operatorId">operator Id.</param>
        /// <param name="ids">event ids.</param>
        /// <returns>true - if deletion is successful.</returns>
        public bool DeleteEvents(int providerId, int operatorId, IEnumerable<int> ids)
        {
            try
            {
                var eventIds = ids as int[] ?? ids.ToArray();
                var updatedEventList = _accountabilityRepository.UpdateEventStatus(operatorId, eventIds, AccountabilityEventStatus.Deleted);
                var alertids = _accountabilityRepository.GetEventsAlertIds(ids);
                _alertFacade.End(operatorId, providerId, alertids);
                var deleteOperationResult = false;

                if (updatedEventList != null)
                {
                    foreach (var eventEntity in updatedEventList)
                    {
                        //Make an audit log entry
                        var auditSpec = new AuditSpec(operatorId, providerId)
                        {
                            Action = ServiceAction.AccountabilityEventDeleted,
                            ObjectType = EntityType.AccountabilityEvent,
                            ObjectName = eventEntity.Name,
                            ObjectIds = new List<int>() { eventEntity.EventId }
                        };
                        OperationAuditor.LogAction(auditSpec);
                    }

                    deleteOperationResult = true;
                }

                return deleteOperationResult;
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(IWSResources.PA_Event_Delete_Error_Message, ex);
                return false;
            }
        }

        public void AddUpdateEventRecipient()
        {
            //get event by id
            //get targeted user by event_alert_base_id
            //
        }


        /// <summary>
        /// Event based criteria to block the users to exclude from targeted user list
        /// </summary>
        /// <param name="accountabilityEvent">Object of type AccountabilityEvent</param>
        /// <param name="operatorId">Operator Id</param>
        /// <param name="isBackgroundJob">Who is calling is this method? Background job.</param>
        /// <returns></returns>
        public bool PopulateEventRecipient(AccountabilityEvent accountabilityEvent, int operatorId, bool isBackgroundJob = false)
        {
            # region Check for Object null reference before proceeding
            if (accountabilityEvent == null)
            {
                throw new ArgumentNullException(IWSResources.PA_Event_Event_ErrorTitle);
            }

            if (accountabilityEvent.AlertSpec == null || accountabilityEvent.AlertSpec.Targeting == null ||
                accountabilityEvent.AlertSpec.Targeting.TargetingCriteria == null)
            {
                throw new Exception(IWSResources.PA_Event_TargetCriteriaNull_Error_Message);
            }
            # endregion

            int providerId = accountabilityEvent.ProviderId;
            int eventId = accountabilityEvent.EventId;
            var statusAttributeId = accountabilityEvent.AlertSpec.Content.ResponseOptionsAttributeID;
            var locale = LanguageManager.GetProviderLocale(providerId);
            var statusAttribute = _customAttributeCache.Get(providerId, locale).GetById(statusAttributeId);

            //Get Targeted User's 
            var userList = GetEventRecipientsWithStatusDetails(accountabilityEvent, operatorId, statusAttribute, locale);
            //Check if user is there based on targeting criteria minus blocked criteria i.e. PAEVENT - ANYRESPONSE
            var userSearchResultItems = userList as UserSearchResultItem[] ?? userList.ToArray();
            if (!userSearchResultItems.Any())
            {
                return true;
            }

            var extendedAttributeList = GetCommonNameWithExtendedAttribute(statusAttribute.CommonName);
            //Attribute valueids and sort order ids
            var attributeValueIdLookup = _accountabilityRepository.GetEventUserStatusAttributes().Where(e => e.EventId == accountabilityEvent.EventId).ToDictionary(e => e.UserStatusAttributeValueId);

            DateTime? pastDuration = null;
            if (accountabilityEvent.PastStatusValidityDuration != null && accountabilityEvent.PastStatusValidityDuration.Value > 0)
            {
                var durationValue = accountabilityEvent.PastStatusValidityDuration.Value; //Always takes negative to consider past date.
                var eventStartTime = accountabilityEvent.StartDate;
                pastDuration = new Duration(accountabilityEvent.PastStatusValidityDuration.Unit, -durationValue).GetEndTime(eventStartTime);
            }

            bool includePastStatus = !(pastDuration == null);
            var dictofRecipientEntityToAdd = new Dictionary<int, AccountabilityEventRecipientEntity>();
            var strextendedUpdatedOn = extendedAttributeList[AttributeCommonNames.UpdatedOn];
            var strextendedUpdatedFrom = extendedAttributeList[AttributeCommonNames.UpdatedFrom];
            var strextendedUpdatedBy = extendedAttributeList[AttributeCommonNames.UpdatedBy];
            var strextendedValueId = extendedAttributeList[AttributeCommonNames.ValueId];

            var existingRecipients = new Dictionary<int, AccountabilityEventRecipientBase>();
            if (isBackgroundJob)
            {
                var recipients = _accountabilityRepository.GetEventRecipients(eventId).ToList();
                //Get user which has no status
                existingRecipients = recipients.ToDictionary(eu => eu.UserId);
            }

            foreach (var user in userSearchResultItems)
            {
                DateTime statusupdatedon;
                string tempupdatedon;
                user.UserAttributes.TryGetValue(strextendedUpdatedOn, out tempupdatedon);
                DateTime.TryParse(tempupdatedon, out statusupdatedon);
                var recipientEntity = new AccountabilityEventRecipientEntity();
                recipientEntity.EventId = eventId;
                recipientEntity.UserId = user.Id;
                recipientEntity.CreatedOn = DateTimeConverter.GetSystemTime();
                recipientEntity.UserStatusAttributeId = 0;
                recipientEntity.IsExcluded = "N";
                if (includePastStatus)
                {
                    if (statusupdatedon >= pastDuration)
                    {
                        recipientEntity.StatusUpdatedOn = statusupdatedon;
                        string tempupdatedfrom;
                        user.UserAttributes.TryGetValue(strextendedUpdatedFrom, out tempupdatedfrom);
                        recipientEntity.UpdateFrom = tempupdatedfrom;
                        int updatedBy;
                        if (Int32.TryParse(user.UserAttributes[strextendedUpdatedBy], out updatedBy))
                        {
                            recipientEntity.UpdatedBy = updatedBy;
                        }

                        string tempvalueId;
                        user.UserAttributes.TryGetValue(strextendedValueId, out tempvalueId);
                        int attributeValueId;
                        if (int.TryParse(tempvalueId, out attributeValueId))
                        {
                            AccountabilityEventUserStatusEntity tempStatusEntity;
                            attributeValueIdLookup.TryGetValue(attributeValueId, out tempStatusEntity);
                            if (tempStatusEntity != null)
                            {
                                recipientEntity.UserStatusAttributeId = tempStatusEntity.UserStatusOrderId;
                            }
                        }
                    }
                }

                if (isBackgroundJob)
                {
                    //
                    if (!existingRecipients.ContainsKey(user.Id))
                    {
                        //make sure the user search is not pulling 
                        if (!dictofRecipientEntityToAdd.ContainsKey(user.Id))
                        {
                            dictofRecipientEntityToAdd.Add(user.Id, recipientEntity);
                        }
                    }
                }
                else
                {
                    dictofRecipientEntityToAdd.Add(user.Id, recipientEntity);
                }
            }

            //If there is any user to insert or update then only call addupdaterecipient
            if (dictofRecipientEntityToAdd.Any())
            {
                bool retVal = _accountabilityRepository.AddUpdateEventRecipients(eventId, dictofRecipientEntityToAdd.Values.ToList());
                return retVal;
            }
            return true;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="accountabilityEvent"></param>
        /// <param name="providerId"></param>
        /// <param name="operatorId"></param>
        /// <param name="eventBasedCriteria">Event based criteria to block the users to exclude from targeted user list</param>
        /// <returns></returns>

        private string GetDurationUnitString(Duration duration)
        {
            string unitFormat = string.Empty;
            switch (duration.Unit)
            {
                case DurationUnit.Day:
                    unitFormat = "D";
                    break;
                case DurationUnit.Hour:
                    unitFormat = "H";
                    break;
                case DurationUnit.Minute:
                    unitFormat = "M";
                    break;
                case DurationUnit.Second:
                    unitFormat = "S";
                    break;
                case DurationUnit.Week:
                    unitFormat = "W";
                    break;

            }
            return unitFormat;
        }
        public IQueryable<AccountabilityEventUserStatusEntity> GetEventUserStatusAttributes()
        {
            var userStatusEntities = _accountabilityRepository.GetEventUserStatusAttributes();
            return userStatusEntities;
        }
        public IEnumerable<AccountabilityEventStatusAttribute> GetEventStatusAttributeList(int eventId, int providerId)
        {

            // var valueIds = _accountabilityRepository.GetEventUserStatusAttributes().Where(e => e.EventId == eventId).Select(e=>e.UserStatusAttributeValueId);
            //// var cachedCustomAttribute = _customAttributeCache.Get(providerId, "en-US");
            // var valueCache= _customAttributeValueCache.Get(providerId, "en-US");
            // var statusAttribute =valueCache.GetByIds(valueIds);
            //var attributeValues = from v in statusAttribute let vSortOrder = v.SortOrder where vSortOrder != null select new AccountabilityEventStatusAttribute{AttributeId = v.AttributeId,CommonName = v.CommonName,SortOrder = vSortOrder.Value,ValueId = v.ValueId,ValueName = v.ValueName};
            // return attributeValues;

            var userStatusAttributeList = _accountabilityRepository.GetEventStatusAttributeList(eventId, providerId).OrderBy(e => e.SortOrder).ToList();
            return userStatusAttributeList;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userStatusList"></param>
        /// <param name="providerId"></param>
        /// <param name="baseLocale"></param>
        /// <returns></returns>
        public bool UpdateUsersStatus(UserStatusUpdateSpec userStatusList, int providerId, string baseLocale)
        {
            if (userStatusList == null)
            {
                throw new ArgumentNullException("userStatusList");
            }

            bool retVal = false;
            try
            {
                retVal = _accountabilityRepository.UpdateUsersStatus(userStatusList);
                var auditSpec = new AuditSpec(userStatusList.OperatorId, providerId)
                {
                    Action = ServiceAction.UserStatusUpdated,
                    ObjectType = EntityType.EndUsers,
                    ObjectName = "PA_AFFECTED_USER",
                    ObjectIds = userStatusList.UserIds
                };
                OperationAuditor.LogAction(auditSpec);

            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Error while updating user status.", ex);
            }
            return retVal;
        }
        #endregion

        #region private

        private IEnumerable<UserSearchResultItem> GetEventRecipientsWithStatusDetails(AccountabilityEvent accountabilityEvent, int operatorId, CustomAttribute statusAttribute, string locale)
        {
            var alertAdapter = new AlertAdapter();
            var srchArgs = alertAdapter.GetUserSearchArgs(accountabilityEvent.AlertSpec.Targeting.TargetingCriteria, accountabilityEvent.ProviderId, locale, operatorId);
            //Block such user, who has any response.
            srchArgs.BlockCriteria = new EventBasedCriteria(new[] { accountabilityEvent.EventId }, EventCriteriaOperator.ANYRESPONSE);
            //To get user status and status updated on fields in search result
            var extendedAttributes = GetCommonNameWithExtendedAttribute(statusAttribute.CommonName);
            srchArgs.AttributeNames = extendedAttributes.Values.ToList();
            srchArgs.Options.GetUsers = true;
            srchArgs.Paging.UsersPerPage = int.MaxValue;

            //
            //Individual User Targeting is handled in TargetingCriteria - thus won't require to specify. If specify, then blocked user criteria won't block the user from CSV ie targetusers. Frameworks doesn't support currently.
            //srchArgs.TargetUsers = null;
            //Get the net result
            var sUser = _userFacade.SearchUsersByContext(srchArgs);
            return sUser.Users;
        }


        private IDictionary<string, string> GetCommonNameWithExtendedAttribute(string commonName)
        {
            var dictOfattributes = new Dictionary<string, string>();
            dictOfattributes.Add(AttributeCommonNames.UpdatedOn, string.Format("{0}:{1}", commonName, AttributeCommonNames.UpdatedOn));
            dictOfattributes.Add(AttributeCommonNames.ValueId, string.Format("{0}:{1}", commonName, AttributeCommonNames.ValueId));
            dictOfattributes.Add(AttributeCommonNames.UpdatedBy, string.Format("{0}:{1}", commonName, AttributeCommonNames.UpdatedBy));
            dictOfattributes.Add(AttributeCommonNames.UpdatedFrom, string.Format("{0}:{1}", commonName, AttributeCommonNames.UpdatedFrom));
            dictOfattributes.Add(AttributeCommonNames.Comments, string.Format("{0}:{1}", commonName, AttributeCommonNames.Comments));
            return dictOfattributes;
        }
        private Duration GetDefaultRecipientRefreshInterval()
        {
            Duration recipientRefreshIntervalinMinute = null;
            var tempInterval = AtHocSystem.Local.Configuration.GetValue("ACCOUNTABILITY-RECIPIENT-UPDATE-INTERVAL");
            int tempInteger = 0;
            if (tempInterval != null && int.TryParse(tempInterval, out tempInteger))
            {
                recipientRefreshIntervalinMinute = new Duration(DurationUnit.Second, tempInteger);
            }
            else
            {
                EventLogger.WriteError(IWSResources.PA_Event_UpdateIntervalParse_Error_Message);
                recipientRefreshIntervalinMinute = new Duration(DurationUnit.Second, 60);
            }
            return recipientRefreshIntervalinMinute;
        }
        private void ResolveEventUserNames(List<AccountabilityEvent> events, HashSet<int> userIds)
        {
            IDictionary<int, string> userNames = ResolveUserNames(userIds.ToList());
            events.ForEach(actEvent =>
            {
                var userDisplayName = "";
                if (userNames.TryGetValue(actEvent.CreatedBy, out userDisplayName))
                {
                    actEvent.CreatedByName = userDisplayName;
                }

                if (userNames.TryGetValue(actEvent.UpdatedBy, out userDisplayName))
                {
                    actEvent.UpdatedByName = userDisplayName;
                }

                if (actEvent.StartedBy != null && userNames.TryGetValue(actEvent.StartedBy.Value, out userDisplayName))
                {
                    actEvent.StartedByName = userDisplayName;
                }

                if (actEvent.EndedBy != null && userNames.TryGetValue(actEvent.UpdatedBy, out userDisplayName))
                {
                    actEvent.EndedByName = userDisplayName;
                }
            });
        }
        private void ResolveTemplateUserNames(List<AccountabilityTemplate> templates)
        {
            var userIds = new HashSet<int>();
            userIds.UnionWith(templates.Select(e => e.CreatedBy));
            userIds.UnionWith(templates.Select(e => e.UpdatedBy));


            IDictionary<int, string> userNames = ResolveUserNames(userIds.ToList());
            templates.ForEach(template =>
            {
                var userDisplayName = "";
                if (userNames.TryGetValue(template.CreatedBy, out userDisplayName))
                {
                    template.CreatedByName = userDisplayName;
                }

                if (userNames.TryGetValue(template.UpdatedBy, out userDisplayName))
                {
                    template.UpdatedByName = userDisplayName;
                }
            });
        }

        private IDictionary<int, string> ResolveUserNames(List<int> userIds)
        {
            var attributeList = new List<string> { "DISPLAYNAME", "FIRSTNAME", "LASTNAME", "LOGIN_ID" };
            IDictionary<int, string> disaplyNameById = new Dictionary<int, string>();

            if (userIds.Count == 0)
            {
                return disaplyNameById;
            }
            var users = _userFacade.GetSystemUsersByIds(userIds, attributeList, null);
            foreach (var user in users)
            {
                disaplyNameById.Add(user.Id, user.GetDisplayName());
            }

            return disaplyNameById;
        }
        #endregion

        #region Reporting Module

        private int GetSessionId(EventReporingSpec spec)
        {
            var ebtCriteria = new EventBasedCriteria(new[] { spec.EventId }, EventCriteriaOperator.TARGETED);
            var criteria = ebtCriteria.ToSearchCriterias();
            var alertAdapter = new AlertAdapter();
            var srchArgs = alertAdapter.GetUserSearchArgs(criteria, spec.ProviderId, spec.BaseLocale, spec.OperatorId);
            srchArgs.Options.EnableSession = true;
            srchArgs.Options.GetUsers = true;
            var sUser = _userFacade.SearchUsersByContext(srchArgs);
            return sUser.SessionId;
        }

        public EventStatusModel GetEventStatus(EventStatusSpec spec)
        {
            if (spec.SessionId == 0)
            {
                spec.SessionId = GetSessionId(spec);
            }

            if (spec.SessionId == 0)
            {
                throw new Exception(IWSResources.PA_Event_ReportModel_SessionId_Null_Error_Message);
            }
            var resultSet = new AccountabilityReportModel();
            var isRestricted = _userFacade.HasRestrictedUserBase(spec.OperatorId);
            int totalUserCount;
            int totalAffectedUsersCount;

            //TODO: Spec.EventId should be of type List<int>
            var entitymodels = _accountabilityRepository.GetEventStatusTracking(new List<int> { spec.EventId }, spec.SessionId,
                "Status", "UpdatedFrom", out totalUserCount, out totalAffectedUsersCount);
            resultSet.StatusTrackingModels = entitymodels;
            resultSet.StatusTrackingModelsTotalUsers = totalUserCount;

            var status = resultSet;

            EventStatusModel model = new EventStatusModel()
            {
                EventId = spec.EventId,
                SessionId = status.SessionId,
                TotalResponses = new EventStatusEntryModel() { ResponseId = 0 }

            };

            //set the total number of users of event.
            model.TotalUsers = status.StatusTrackingModelsTotalUsers;
            model.TotalAffectedUsers = totalAffectedUsersCount;
            model.IsRestricted = isRestricted;
            // now build the model            
            Dictionary<int, EventStatusEntryModel> responseModels = new Dictionary<int, EventStatusEntryModel>();
            //get response option names
            var responseOptions = GetEventStatusAttributeList(spec.EventId, spec.ProviderId).ToList();
            foreach (var response in responseOptions)
            {
                responseModels.Add(response.SortOrder, new EventStatusEntryModel()
                {
                    ResponseId = response.SortOrder,
                    ResponsesByOperator = 0,
                    Responses = 0,
                    ResponsesByUser = 0,
                    StatusAttribute = response
                });
            }

            foreach (var trackingModel in status.StatusTrackingModels)
            {
                int responseId;
                if (!int.TryParse(trackingModel.GroupBy.ToString(), out responseId))
                {
                    throw new Exception(IWSResources.PA_Event_EventStatusTrack_Fail_Error_Message);
                }

                bool isOperator = "Operator".Equals(trackingModel.SubGroupBy.ToString(), StringComparison.InvariantCultureIgnoreCase);
                //bool isUser = "Self".Equals(trackingModel.SubGroupBy.ToString(), StringComparison.InvariantCultureIgnoreCase) || "Alert Tracking".Equals(trackingModel.SubGroupBy.ToString(), StringComparison.InvariantCultureIgnoreCase);
                bool isUser = !isOperator;

                EventStatusEntryModel entry = null;
                if (responseId == 0)
                {
                    // 0 represent the Total number of No Response
                    var noResponseTotal = trackingModel.UsersCount;
                    model.TotalResponses.Responses = model.TotalUsers - noResponseTotal;
                }
                else
                {
                    if (!responseModels.TryGetValue(responseId, out entry))
                    {
                        throw new Exception(string.Format("Failed to load resposne statsus, response {0} was not found in model", responseId));
                    }
                    // now set the value               
                    if (isUser)
                    {
                        entry.ResponsesByUser += trackingModel.UsersCount;
                    }
                    else
                    {
                        entry.ResponsesByOperator += trackingModel.UsersCount;
                    }
                }
            }

            var totalResponses = 0;
            var totalResponsesByUser = 0;
            var totalResponsesByOperator = 0;
            foreach (var entry in responseModels.Values)
            {
                entry.Responses = entry.ResponsesByOperator + entry.ResponsesByUser;
                totalResponses += entry.Responses;
                totalResponsesByUser += entry.ResponsesByUser;
                totalResponsesByOperator += entry.ResponsesByOperator;
            }

            model.TotalResponses.Responses = totalResponses;
            model.TotalResponses.ResponsesByOperator = totalResponsesByOperator;
            model.TotalResponses.ResponsesByUser = totalResponsesByUser;
            if (model.TotalResponses.Responses != totalResponses)
            {
                // this is just another checksum test.
                EventLogger.WriteError(string.Format("Mismatch total responses: sum of all response by id: {0} while SP return {1}", totalResponses, model.TotalResponses.Responses));
            }
            model.StatusByResponse = responseModels.Values.ToList();
            return model;
        }




        public void GetEventStatusByOrg(EventStatusByOrgSpec spec, bool isEnterprise, out List<EventOrganizationReport> data, out List<EventOrganizationHierarchy> hierarchyBreadcrumbNodes)
        {
            var eventOrganizationReportEntries = new List<EventOrganizationReport>();
            var hierarchy = new List<EventOrganizationHierarchy>();

            if (spec.SessionId == 0)
            {
                spec.SessionId = GetSessionId(spec);
            }

            if (spec.SessionId == 0)
            {
                throw new Exception("Session Id cannot be null while getting EventStatusTracking report data. Method: GetAccountabilityStatusTrackingByOrgReportModel()");
            }

            var entitymodels = _accountabilityRepository.GetEventStatusTrackingByOrg(new List<int> { spec.EventId }, spec.SessionId, isEnterprise, spec.ProviderId);
            var hierarchyModel = entitymodels.ToList();
            var t = from a in hierarchyModel
                    join parent in hierarchyModel on a.ParentNodeId equals parent.OrgId
                    select a;

            var nodeLevelHierarchy = new List<AccountabilityEventStatusTrackingByOrgReportModel>();

            if (spec.HierarchyId != 0)
            {
                var childList = new List<AccountabilityEventStatusTrackingByOrgReportModel>();
                var parentList = new List<AccountabilityEventStatusTrackingByOrgReportModel>();
                var originalRoot = hierarchyModel.First(or => or.OrgPath.Equals("/"));
                var root = new AccountabilityEventStatusTrackingByOrgReportModel();
                root.Org = originalRoot.Org;
                root.OrgId = 0;
                root.OrgPath = originalRoot.OrgPath;
                root.ParentNode = originalRoot.ParentNode;
                root.ParentNodeId = originalRoot.ParentNodeId;
                root.SeqId = originalRoot.SeqId;
                root.Status = originalRoot.Status;
                root.TreeDepth = originalRoot.TreeDepth;
                root.TreeDepthFromLeaf = originalRoot.TreeDepthFromLeaf;
                root.UsersCount = originalRoot.UsersCount;
                parentList.Add(root);
                parentList.First().OrgId = 0;
                childList.AddRange(hierarchyModel.Where(h => h.OrgId == spec.HierarchyId));
                GetChildren(spec.HierarchyId, hierarchyModel, ref childList);
                GetNodeLevelHierarchy(spec.HierarchyId, hierarchyModel, ref parentList);
                parentList.Add(hierarchyModel.First(h => h.OrgId == spec.HierarchyId));
                hierarchyModel = childList;
                nodeLevelHierarchy = parentList;
            }

            #region Add data for UI model

            hierarchyModel.ForEach(hierarchyNode =>
            {
                if (!eventOrganizationReportEntries.Any(d => d.Id == hierarchyNode.OrgId))
                {
                    eventOrganizationReportEntries.Add(new EventOrganizationReport
                    {
                        Id = hierarchyNode.OrgId,
                        Name = hierarchyNode.Org,
                        ParentId = hierarchyNode.ParentNodeId.Value,
                        HasChildren = hierarchyModel.Select(h => h.ParentNodeId).Contains(hierarchyNode.OrgId),
                        Depth = hierarchyNode.TreeDepth,
                        SortOrder = hierarchyNode.SeqId
                    });
                }

                var item = eventOrganizationReportEntries.First(d => d.Id == hierarchyNode.OrgId);
                CalculateUserStatus(hierarchyNode.Status.ToString(), hierarchyNode.UsersCount, ref item);
            });

            CalculateParentNodeUserStatus(ref eventOrganizationReportEntries);

            //Removing leaf nodes with 0 user count.
            data = eventOrganizationReportEntries.Where(node => node.TotalCount > 0).ToList();

            //Showing only two levels
            var depth = data.OrderBy(d => d.Depth).First().Depth;
            data = data.Where(d => d.Depth <= depth + 2).ToList();

            if (spec.HierarchyId != 0)
            {
                data.First(d => d.Id == spec.HierarchyId).ParentId = 0;
            }

            // Add agreetated row for total users in case of VPS hierarchy
            if (isEnterprise && data.All(x => x.ParentId == 1))
            {
                var totalRow = new EventOrganizationReport();
                totalRow.Depth = 1;
                totalRow.HasChildren = true;
                totalRow.Id = 1;
                totalRow.Name = "All Users";
                totalRow.ParentId = 0;
                totalRow.TotalCount = data.Select(x => x.TotalCount).Aggregate((a, b) => a + b);
                totalRow.ResponseValues = GetTotalCount(data.Select(x => x.ResponseValues));
                totalRow.SortOrder = 0;
                data.Add(totalRow);
            }

            #endregion

            #region Add hierarchy for breadcrumb

            if (nodeLevelHierarchy.Any())
            {
                nodeLevelHierarchy.ForEach(h => hierarchy.Add(new EventOrganizationHierarchy
                {
                    Id = h.OrgId.ToString(CultureInfo.InvariantCulture),
                    Name = h.Org
                }));

                hierarchyBreadcrumbNodes = (hierarchy.Select(h => new
                {
                    h.Id,
                    h.Name
                })).Distinct().Select(x => new EventOrganizationHierarchy
                {
                    Id = x.Id,
                    Name = x.Name
                }).ToList();
            }
            else
            {
                hierarchyBreadcrumbNodes = new List<EventOrganizationHierarchy>();
            }

            #endregion
        }

        private Dictionary<string, int> GetTotalCount(IEnumerable<Dictionary<string, int>> responseValues)
        {
            var totalCount = new Dictionary<string, int>();

            foreach (var responseValue in responseValues)
            {
                foreach (var statusResponse in responseValue)
                {
                    if (totalCount.ContainsKey(statusResponse.Key))
                    {
                        totalCount[statusResponse.Key] += statusResponse.Value;
                    }
                    else
                    {
                        totalCount.Add(statusResponse.Key, statusResponse.Value);
                    }
                }
            }

            return totalCount;
        }

        private void GetNodeLevelHierarchy(int id,
            List<AccountabilityEventStatusTrackingByOrgReportModel> hierarchyModel,
            ref List<AccountabilityEventStatusTrackingByOrgReportModel> list)
        {
            var item = hierarchyModel.First(h => h.OrgId == id);
            var parent = hierarchyModel.First(h => h.OrgId == item.ParentNodeId);

            if (parent.ParentNodeId != 0)
            {
                list.Add(parent);
                GetNodeLevelHierarchy(parent.OrgId, hierarchyModel, ref list);
            }
        }

        private void GetChildren(int id,
            List<AccountabilityEventStatusTrackingByOrgReportModel> hierarchyModel,
            ref List<AccountabilityEventStatusTrackingByOrgReportModel> list)
        {
            foreach (var item in hierarchyModel)
            {
                if (item.ParentNodeId == id)
                {
                    if (!list.Contains(item))
                    {
                        list.Add(item);
                    }

                    GetChildren(item.OrgId, hierarchyModel, ref list);
                }
            }
        }

        /// <summary>Calculate response for the hierarchy.</summary>
        /// <param name="list">Hierarchy list.</param>
        private void CalculateParentNodeUserStatus(ref List<EventOrganizationReport> list)
        {
            foreach (var leaf in list)
            {
                if (leaf.ResponseValues != null)
                {
                    foreach (var status in leaf.ResponseValues)
                    {
                        CalculateResponseCount(leaf.ParentId, status, ref list);
                    }
                }
            }
        }

        /// <summary>Calculate response for the parent.</summary>
        /// <param name="leafParentId">Id of parent node.</param>
        /// <param name="status">User status.</param>
        /// <param name="list">Hierarchy List.</param>
        private void CalculateResponseCount(int leafParentId, KeyValuePair<string, int> status,
            ref List<EventOrganizationReport> list)
        {
            var statusKey = status.Key.ToString();

            if (list.Any(l => l.Id == leafParentId))
            {
                var leafParent = list.First(l => l.Id == leafParentId);

                if (leafParent.ResponseValues.ContainsKey(statusKey))
                    leafParent.ResponseValues[statusKey] += status.Value;
                else if (leafParent.ResponseValues != null)
                    leafParent.ResponseValues.Add(status.Key.ToString(), status.Value);
                else
                    leafParent.ResponseValues = new Dictionary<string, int> { { statusKey, status.Value } };

                leafParent.TotalCount += status.Value;
                CalculateResponseCount(leafParent.ParentId, status, ref list);
            }
        }

        /// <summary>Calculates User Status for initial hierarchy nodes.</summary>
        /// <param name="status">Status.</param>
        /// <param name="userCount">Count of users.</param>
        /// <param name="item">Hierarchy node.</param>
        /// <returns></returns>
        private void CalculateUserStatus(string status, int userCount, ref EventOrganizationReport item)
        {
            if (item.ResponseValues == null)
                item.ResponseValues = new Dictionary<string, int> { { status, userCount } };
            else if (item.ResponseValues.ContainsKey(status))
                item.ResponseValues[status] += userCount;
            else
                item.ResponseValues.Add(status, userCount);

            item.TotalCount += userCount;
        }

        /// <summary>
        /// Get accountability search results.
        /// </summary>
        /// <param name="spec">Search specs.</param>
        /// <returns>Search results.</returns>
        public IPaged<AccountabilityEventSearchResult> GetAccountabilitySearchResult(AccountabilityEventSearchSpec spec)
        {
            return _accountabilityRepository.GetAccountabilitySearchResult(spec);
        }

        #endregion

        #region Responses Overtime


        /// <summary>
        /// Get Accountability Summary model
        /// </summary>
        /// <param name="eventId">event id</param>
        /// <param name="baseLocale"></param>
        /// <param name="sliceByDuration">Duration i.e slice by Min,hour,day</param>
        /// <param name="startTime">event start time</param>
        /// <param name="endTime">event endtime</param>
        /// <param name="providerId"></param>
        /// <param name="operatorId"></param>
        /// <returns>Object of type AccountabilityEventSummaryModel</returns>
        public AccountabilityEventSummaryModel GetEventResponsesOvertime(int eventId, int providerId, int operatorId, string baseLocale, TimeSpan sliceByDuration, DateTime startTime, DateTime endTime)
        {

            int[] userIds = new int[] { };
            if (_userFacade.HasRestrictedUserBase(operatorId))
            {
                var usersByUbp = GetReceipientsByUserBasedPermission(eventId, providerId, operatorId, baseLocale);
                userIds = usersByUbp.Select(e => e.Id).ToArray();
            }

            var timeSpanMarkerSet = GetEventOvertime(sliceByDuration, startTime, endTime);
            var eventSummaryModel = new AccountabilityEventSummaryModel();
            eventSummaryModel.EventSummaryUserWithResponseCountModel = GetEventSummaryUserWithResponseCountModel(eventId, userIds, timeSpanMarkerSet);
            return eventSummaryModel;
        }

        private IEnumerable<UserSearchResultItem> GetReceipientsByUserBasedPermission(int eventId, int providerId, int operatorId, string baseLocale)
        {
            var ebtCriteria = new EventBasedCriteria(new[] { eventId }, EventCriteriaOperator.TARGETED);
            var criteria = ebtCriteria.ToSearchCriterias();
            var alertAdapter = new AlertAdapter();
            var srchArgs = alertAdapter.GetUserSearchArgs(criteria, providerId, baseLocale, operatorId);
            srchArgs.Options.EnableSession = false;
            srchArgs.Options.GetUsers = true;
            var sUser = _userFacade.SearchUsersByContext(srchArgs);
            return sUser.Users;
        }
        private List<AccountabilityEventSummaryUserWithResponseCountModel> GetEventSummaryUserWithResponseCountModel(int eventId, int[] userIds, IEnumerable<Tuple<DateTime, DateTime, string>> timeSpanMarkerSet)
        {
            var resultSet = new List<AccountabilityEventSummaryUserWithResponseCountModel>();
            var entity = _accountabilityRepository.GetEventRecipients(eventId);
            List<AccountabilityEventRecipientBase> filteredEntity;
            if (userIds != null && userIds.Length > 0)
            {
                filteredEntity = entity.Where(e => userIds.Contains(e.UserId)).ToList();
            }
            else
            {
                filteredEntity = entity.ToList();
            }
            foreach (var tuple in timeSpanMarkerSet)
            {
                var stTime = tuple.Item1;
                var edTime = tuple.Item2;
                var userCount = filteredEntity.Count(e => e.StatusUpdatedOn.HasValue && e.StatusUpdatedOn >= stTime && e.StatusUpdatedOn <= edTime);
                var userWithResponse = new AccountabilityEventSummaryUserWithResponseCountModel();
                userWithResponse.GroupStartTime = stTime; //Start Time
                userWithResponse.GroupEndTime = edTime; //End Time
                userWithResponse.GroupName = tuple.Item3; //Group name
                userWithResponse.UserCount = userCount;

                resultSet.Add(userWithResponse);
            }
            return resultSet;
        }

        private static IEnumerable<Tuple<DateTime, DateTime, string>> GetEventOvertime(TimeSpan sliceByduration, DateTime startTime, DateTime endTime)
        {
            var setOfEventOvertime = new HashSet<Tuple<DateTime, DateTime, string>>();
            if (sliceByduration < TimeSpan.FromSeconds(1))
            {
                EventLogger.WriteError(string.Format("Can't calculate GetEventOvertime, bad sliceByduration parameter, value is less than a sec {0}", sliceByduration));
                return setOfEventOvertime;
            }
            if (endTime < startTime)
            {
                EventLogger.WriteError(string.Format("startTime can't be later than the end time"));
                return setOfEventOvertime;
            }

            var _startTime = startTime;
            var _endTime = startTime + sliceByduration;

            if (sliceByduration.TotalSeconds * 100 < (endTime - _endTime).TotalSeconds)
            {
                // we can't have more than 100 slices
                EventLogger.WriteError(string.Format("slice can't be more than 100th of the time diff"));
                return setOfEventOvertime;
            }

            while (_endTime <= endTime)
            {
                var groupName = string.Format("{0} {1}", _startTime.ToLongDateString(), _startTime.ToLongTimeString());
                setOfEventOvertime.Add(new Tuple<DateTime, DateTime, string>(_startTime, _endTime, groupName));
                _startTime += sliceByduration;
                _endTime += sliceByduration;
            }
            return setOfEventOvertime;
        }

        private IQueryable<AccountabilityEventEntity> ApplyFiltersToEventEntities(IQueryable<AccountabilityEventEntity> events, AccountabilityEventSpec eventSpec)
        {
            //Filter by Provider Id
            if (eventSpec.ProviderId > 0)
            {
                events = events.Where(e => e.ProviderId == eventSpec.ProviderId);
            }

            //Filter by status
            if (eventSpec.Status.HasValue)
            {
                events = events.Where(e => e.Status == eventSpec.Status.ToString());
            }

            if (!eventSpec.Status.HasValue)
            {
                var actStr = AccountabilityEventStatus.Deleted.ToString();
                // Filter deleted events
                events = events.Where(e => (!actStr.Equals(e.Status)));

            }

            if (eventSpec.SearchStrings != null && eventSpec.SearchStrings.Any())
            {
                events = events.Where(e => eventSpec.SearchStrings.All(s => e.Name.Contains(s) || e.Description.Contains(s)));
            }

            if (eventSpec.DateRangeFrom.HasValue)
            {
                var tempFrom = DateTime.SpecifyKind(eventSpec.DateRangeFrom.Value, DateTimeKind.Unspecified);
                DateTime? dtFrom = RuntimeContext.Provider.VpsToUtcTime(tempFrom);
                events = events.Where(e => (e.CreatedOn >= dtFrom.Value));
            }
            if (eventSpec.DateRangeTo.HasValue)
            {
                var tempTo = DateTime.SpecifyKind(eventSpec.DateRangeTo.Value, DateTimeKind.Unspecified);
                DateTime? dtTo = RuntimeContext.Provider.VpsToUtcTime(tempTo);
                events = events.Where(e => (e.CreatedOn <= dtTo.Value));
            }
            return events;
        }
        private IQueryable<AccountabilityEventEntity> ApplySortingAndPagingToEventEntities(IQueryable<AccountabilityEventEntity> events, AccountabilityEventSpec eventSpec)
        {
            if (!string.IsNullOrEmpty(eventSpec.OrderBy))
            {
                if (string.Equals(eventSpec.OrderBy, "StartedByName", StringComparison.OrdinalIgnoreCase))
                {
                    eventSpec.OrderBy = "PublishedByUserName";
                }

                string orderbystring = (eventSpec.OrderAsc
                       ? string.Format("{0} ASC ", eventSpec.OrderBy)
                       : string.Format("{0} DESC", eventSpec.OrderBy));

                events = events.OrderBy(orderbystring);
            }

            if (eventSpec.Page.HasValue)
            {
                events = eventSpec.Page.Value == 1 ? events.Take(eventSpec.PageSize) : events.Skip((eventSpec.Page.Value - 1) * eventSpec.PageSize).Take(eventSpec.PageSize);
            }



            return events;
        }

        #endregion

        #region Cached
        public IEnumerable<Tuple<int, IDictionary<int, string>>> GetAccountabilityEventPublishers(int providerId)
        {
            // check cache first
            var cachedList = _accountabilityFacadeCache.GetSetEventPublishers(providerId, () =>
            {
                var allVps = GetAllVpsIds(providerId);

                var allEvents = from evt in _accountabilityRepository.GetEventsIncludeAll()
                                where
                                    evt.Status != AccountabilityEventStatus.Deleted.ToString() && evt.PublishedByUserId != null &&
                                    allVps.Contains(evt.ProviderId)
                                select new { evt.ProviderId, evt.PublishedByUserId };

                var results = (from evt in allEvents
                               group evt.PublishedByUserId by evt.ProviderId into g
                               select new
                               {
                                   ProviderId = g.Key,
                                   UserIds = g.Select(x => (int)x).Distinct().ToList()
                               }).ToList();

                var allUserIds = results.SelectMany(x => x.UserIds).Distinct().ToList();
                var resolvedUserNames = ResolveUserNames(allUserIds);

                var accountabilityPublishers = from res in results
                                               let userNames = resolvedUserNames.Where(x => res.UserIds.Contains(x.Key))
                                                   .ToDictionary(x => x.Key, x => x.Value)
                                               select new Tuple<int, IDictionary<int, string>>(res.ProviderId, userNames);

                return accountabilityPublishers;
            });

            return cachedList;
        }

        public int GetSessionId(int eventId, int operatorId)
        {
            var sessionId = _accountabilityFacadeCache.GetSetSessionId(eventId, operatorId, () =>
            {
                var spec = new EventStatusByOrgSpec
                {
                    EventId = eventId,
                    OperatorId = operatorId,
                };

                return GetSessionId(spec);
            });

            return sessionId;
        }

        public IEnumerable<Tuple<int, IEnumerable<CustomAttribute>>> GetStatusAttibutes(int providerId, string baseLocale)
        {
            var cachedList = _accountabilityFacadeCache.GetSetStatusAttibutes(providerId, () =>
            {
                var statusAttributesPerVps =
                    _accountabilityRepository.GetUniqueStatusAttributesPerVps(GetAllVpsIds(providerId));

                var allAttributesId = statusAttributesPerVps.SelectMany(x => x.Value).Distinct();
                var allAttributes = _customAttributeCache.Get(providerId, baseLocale).GetByIds(allAttributesId);

                var statusAttributeList = from vpsId in statusAttributesPerVps
                                          let uniqueStatusAttributes = allAttributes.Where(x => x != null && vpsId.Value.Contains(x.Id))
                                          select new Tuple<int, IEnumerable<CustomAttribute>>(vpsId.Key, uniqueStatusAttributes);

                return statusAttributeList;
            });

            return cachedList;
        }

        private List<int> GetAllVpsIds(int providerId)
        {
            var subVpsIds = GetSubOrganizationsWithNames(providerId);
            var allVpsId = new List<int> { providerId };
            allVpsId.AddRange(subVpsIds.Keys);

            return allVpsId;
        }

        public IDictionary<int, string> GetSubOrganizationsWithNames(int providerId)
        {
            return _accountabilityFacadeCache.GetSetSubOrganizations(providerId, () => _virtualSystemFacade.GetSubVirtualSystemsWithNames(providerId));
        }

        #endregion
    }

    #region Extension Class
    public static class AccountabilityExtensions
    {
        public static EventBasedCriteria ToEventBasedCriteria(this List<ISearchCriteria> targetingCriteria)
        {
            var ebtCriteria = new EventBasedCriteria();

            if (targetingCriteria == null || targetingCriteria.Where(t => t.NodeType.Equals(SearchNodeType.EbtQuery)).ToList().Count < 1)
                return null;

            var queryCriteria = targetingCriteria.FirstOrDefault(t => t.NodeType.Equals(SearchNodeType.EbtQuery));
            if (queryCriteria != null)
            {
                if (queryCriteria.SearchQueries != null)
                {
                    var eventQuery = (SearchQuery)queryCriteria.SearchQueries.FirstOrDefault();
                    var eventCriteriaOperator = (int)eventQuery.AccountabilityOperator;
                    ebtCriteria.Id = (int)eventQuery.QueryEntityID;
                    ebtCriteria.EventIds = new[] { (int)eventQuery.QueryEntityID };
                    ebtCriteria.Operator = (EventCriteriaOperator)Enum.Parse(typeof(EventCriteriaOperator), eventCriteriaOperator.ToString());

                    if (eventQuery.SearchValueCollections != null && eventQuery.SearchValueCollections.Any())
                    {
                        var responseList = eventQuery.SearchValueCollections.Select(v => v.SearchValue);
                        ebtCriteria.Value = responseList;
                    }
                }
            }
            return ebtCriteria;
        }

        public static List<ISearchCriteria> ToSearchCriterias(this EventBasedCriteria eventBasedCriteria, bool blocked = false)
        {
            AccountabilityOperator accountabilityOperator = (AccountabilityOperator)((int)eventBasedCriteria.Operator);
            var searchCriteriaList = new List<ISearchCriteria>();

            var newCriteria = new SearchCriteria
            {
                NodeType = SearchNodeType.EbtQuery,
                IsBlocked = blocked,
                SearchValue = string.Empty,
                SearchQueries = new List<SearchQuery>()
            };
            var eventQuery = new SearchQuery
            {
                QueryType = SearchQueryType.PAEvent,
                QueryEntityID = eventBasedCriteria.EventIds.ToArray()[0],
                AccountabilityOperator = accountabilityOperator,
                SearchValueCollections = new List<SearchValueCollection>()
            };

            if (accountabilityOperator == AccountabilityOperator.MULTIPLERESPONSE && eventBasedCriteria.Value != null)
            {
                var responseList = (IEnumerable<string>)eventBasedCriteria.Value;
                foreach (var response in responseList)
                {
                    eventQuery.SearchValueCollections.Add(new SearchValueCollection { SearchValue = response });
                }
            }
            else
            {
                eventQuery.SearchValueCollections.Add(new SearchValueCollection { SearchValue = string.Empty });
            }


            newCriteria.SearchQueries.Add(eventQuery);
            searchCriteriaList.Add(newCriteria);
            return searchCriteriaList;
        }

        public static ISearchCriteria ToSearchCriteria(this EventBasedCriteria eventBasedCriteria, bool blocked = false)
        {
            var accountabilityOperator = (AccountabilityOperator)((int)eventBasedCriteria.Operator);
            //var searchCriteriaList = new List<ISearchCriteria>();

            var newCriteria = new SearchCriteria
            {
                NodeType = SearchNodeType.EbtQuery,
                IsBlocked = blocked,
                SearchValue = string.Empty,
                SearchQueries = new List<SearchQuery>()
            };
            var eventQuery = new SearchQuery
            {
                QueryType = SearchQueryType.PAEvent,
                QueryEntityID = eventBasedCriteria.EventIds.ToArray()[0],
                AccountabilityOperator = accountabilityOperator,
                SearchValueCollections = new List<SearchValueCollection>()
            };

            if (accountabilityOperator == AccountabilityOperator.MULTIPLERESPONSE && eventBasedCriteria.Value != null)
            {
                var responseList = (IEnumerable<string>)eventBasedCriteria.Value;
                foreach (var response in responseList)
                {
                    eventQuery.SearchValueCollections.Add(new SearchValueCollection { SearchValue = response });
                }
            }
            else
            {
                eventQuery.SearchValueCollections.Add(new SearchValueCollection { SearchValue = string.Empty });
            }

            newCriteria.SearchQueries.Add(eventQuery);

            return newCriteria;
        }
    }

    #endregion
}
