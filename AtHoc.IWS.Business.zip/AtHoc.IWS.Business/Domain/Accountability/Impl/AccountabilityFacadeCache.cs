﻿using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.Runtime;
using AtHoc.Systems;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;

namespace AtHoc.IWS.Business.Domain.Accountability.Impl
{
    public class AccountabilityFacadeCache : IAccountabilityFacadeCache
    {
        const string OperatorPublishedCacheName = "Accountability.OperatorPublished";
        const string OperatorPublishedCachePolicyName = "CACHE_POLICY_OPERATOR_PUBLISHED";
        const int OperatorPublishedCacheDefaultPolicy = 60;   // 1 min     

        const string SeesionIdCacheName = "Accountability.SessionId";
        const string SeesionIdCachePolicyName = "CACHE_POLICY_SESSIONID";
        const int SeesionIdCacheDefaultPolicy = 30;   // 0.5 min  

        const string StatusAttributeCacheName = "Accountability.StatusAttribute";
        const string StatusAttributeCachePolicyName = "CACHE_POLICY_STATUSATTRIBUTE";
        const int StatusAttributeCacheDefaultPolicy = 60;   // 1 min 

        const string SubVpsCacheName = "Accountability.SubVps";
        const string SubVpsCachePolicyName = "CACHE_POLICY_SUBVPS";
        const int SubVpsCacheDefaultPolicy = 2 * 60;   // 2 min 

        private const string ProviderContextCacheName = "Accountability.ProviderContext";
        private const string ProviderContextPolicyName = "CACHE_POLICY_PROVIDERCONTEXT";
        private const int ProviderContextDefaultPolicy = 2*60;// 2 min

        static readonly object cacheLock = new object();

        /// <summary>
        /// Following cache will retrun the list of Unique Operater that have published event
        /// </summary>
        /// <param name="providerId">Provider ID</param>
        /// <param name="getValueCallbackFunc"></param>
        public IEnumerable<Tuple<int, IDictionary<int, string>>> GetSetEventPublishers(int providerId, Func<IEnumerable<Tuple<int, IDictionary<int, string>>>> getValueCallbackFunc)
        {
            string cacheKey = string.Format("provider-{0}", providerId);
            return GetSetObjectCache(OperatorPublishedCacheName, cacheKey, OperatorPublishedCachePolicyName, OperatorPublishedCacheDefaultPolicy, getValueCallbackFunc);
        }

        public IProviderContext GetProviderContext(int providerId, Func<IProviderContext> getValueCallbackFunc)
        {
            string cacheKey = string.Format("provider-{0}", providerId);
            return GetSetObjectCache(OperatorPublishedCacheName, cacheKey, OperatorPublishedCachePolicyName, OperatorPublishedCacheDefaultPolicy, getValueCallbackFunc);
        }
        /// <summary>
        /// This method return session id per event
        /// </summary>
        /// <param name="eventId"></param>
        /// <param name="operatorId"></param>
        /// <param name="getValueCallbackFunc"></param>
        /// <returns></returns>
        public int GetSetSessionId(int eventId, int operatorId, Func<int> getValueCallbackFunc)
        {
            string cacheKey = string.Format("{0}-{1}", eventId, operatorId);
            return GetSetObjectCache(SeesionIdCacheName, cacheKey, SeesionIdCachePolicyName, SeesionIdCacheDefaultPolicy, getValueCallbackFunc);
        }

        /// <summary>
        /// Returns status custome attribute list 
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="getValueCallbackFunc"></param>
        /// <returns></returns>
        public IEnumerable<Tuple<int, IEnumerable<CustomAttribute>>> GetSetStatusAttibutes(int providerId, Func<IEnumerable<Tuple<int, IEnumerable<CustomAttribute>>>> getValueCallbackFunc)
        {
            string cacheKey = string.Format("provider-{0}", providerId);
            return GetSetObjectCache(StatusAttributeCacheName, cacheKey, StatusAttributeCachePolicyName, StatusAttributeCacheDefaultPolicy, getValueCallbackFunc);
        }

        public IDictionary<int, string> GetSetSubOrganizations(int providerId, Func<IDictionary<int, string>> getValueCallbackFunc)
        {
            string cacheKey = string.Format("provider-{0}", providerId);
            return GetSetObjectCache(SubVpsCacheName, cacheKey, SubVpsCachePolicyName, SubVpsCacheDefaultPolicy, getValueCallbackFunc);
        }

        private T GetSetObjectCache<T>(string cacheName, string cacheKey, string cachePolicyName, int defaultExpirationPolicy, Func<T> getValueCallbackFunc)
        {
            IProcessCache cache = GetOrCreateCache(cacheName, cachePolicyName, defaultExpirationPolicy);
            
            T container;
            if (!cache.TryGet(cacheKey, out container))
            {
                lock (cacheLock)
                {
                    if (!cache.TryGet(cacheKey, out container))
                    {
                        container = getValueCallbackFunc();
                        if (container != null)
                        {
                            // put configuration in cache
                            cache.Set(cacheKey, container);
                        }
                    }
                }
            }

            return container;
        }

        private static IProcessCache GetOrCreateCache(string cacheName, string cachePolicyName, int defaultPolicy = 0)
        {
            // TODO: this should be re-factored to use file pased cache definitions
            var cache = AtHocRuntime.ProcessCacheManager.GetCache(cacheName);
            if (cache == null)
            {
                lock (cacheLock)
                {
                    cache = AtHocRuntime.ProcessCacheManager.GetCache(cacheName);
                    if (cache == null)
                    {
                        // TODO: need to convert this to come from cache.confg file

                        // TODO: get values from database configuration table use these as defaults
                        var cachePolicyString = AtHocSystem.Local.Configuration.GetValue(cachePolicyName);
                        var cachePolicy = !string.IsNullOrEmpty(cachePolicyString)
                            ? Int32.Parse(cachePolicyString)
                            : defaultPolicy;
                        if (cachePolicy < 0) cachePolicy = 0;

                        var isEnabled = cachePolicy > 0;
                        var defaultExpiration = TimeSpan.FromSeconds(cachePolicy);
                        var pollingInterval = TimeSpan.FromSeconds(5);
                        const ExpirationType defaultExpirationType = ExpirationType.Absolute;
                        const int cacheMemoryLimitMegabytes = 20;
                        const int physicalMemoryLimitPercentage = 0;

                        var configuration = new ProcessCacheConfiguration
                        {
                            IsEnabled = isEnabled,
                            DefaultExpirationType = defaultExpirationType,
                            DefaultExpiration = defaultExpiration,
                            PollingInterval = pollingInterval,
                            PhysicalMemoryLimitPercentage = physicalMemoryLimitPercentage,
                            CacheMemoryLimitMegabytes = cacheMemoryLimitMegabytes,
                            Name = cacheName
                        };
                        cache = AtHocRuntime.ProcessCacheManager.CreateCache(configuration);
                        // TODO: in the future when this is automatuically read from the config file
                        //      we should log an error if the cache is not found.
                        //      hard error fail.
                        //EventLogger.WriteWarning("Missing Cache Configuration: " + cacheName);
                    }
                }
            }

            return cache;
        }
    }
}
