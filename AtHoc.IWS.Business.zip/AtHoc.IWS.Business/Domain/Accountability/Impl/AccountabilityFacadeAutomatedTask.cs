﻿using System.Diagnostics;
using AtHoc.Diagnostics;
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Data.SearchSpec;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel;
using AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel;
using AtHoc.IWS.Business.Shedule;
using AtHoc.IWS.Business.Shedule.Impl;
using AtHoc.Publishing;
using AtHoc.Utilities;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Core;
using System.Linq;

namespace AtHoc.IWS.Business.Domain.Accountability.Impl
{
    public partial class AccountabilityFacade
    {
        private DateTime _jobPickupTime = DateTime.Now;


        /// <summary>
        /// This method is called from Regular Scheduled job
        /// </summary>
        /// <param name="jobType"></param>
        /// <param name="enableLog">For troubleshooting, pass true; Default is false</param>
        public void ProcessAccountabilityJob(AccountabilityEventJobPickupType jobType, bool enableLog = false)
        {
            var currentSystemDateTime = DateTimeConverter.GetSystemTime();
            //maintain job pickup time
            _jobPickupTime = DateTime.Now;
            _isLogInformationEnable = enableLog;
            int operatorId = 1; //Default Operator - athoc admin
            try
            {
                //Get Live events
                if (jobType == AccountabilityEventJobPickupType.End)
                {
                    string liveStatus = AccountabilityEventStatus.Live.ToString();
                    //get live events for endtime already crossed or euqal to now.
                    var endEventquery = from e in _accountabilityRepository.GetEvents().AsNoTracking()
                                        where e.Status == liveStatus && e.EndDate <= currentSystemDateTime
                                        select e.EventId;

                    int[] eventIds = endEventquery.ToArray();
                    if (eventIds.Length > 0)
                    {
                        _logInfoContent += string.Format("PA Event End. Count - {0}. Executed on {1}", eventIds.Length, DateTime.Now);

                        foreach (var eventId in endEventquery)
                        {
                            //Before ending the event, make sure to run tracking summary job.
                            SubmitJob(AccountabilityEventJobPickupType.TrackingSummary, eventId, operatorId);

                            SubmitJob(AccountabilityEventJobPickupType.End, eventId, operatorId);
                        }

                        //Make sure the event is marked as ended.
                        _accountabilityRepository.UpdateEventStatus(operatorId, eventIds, AccountabilityEventStatus.Ended);

                    }

                }

                else if (jobType == AccountabilityEventJobPickupType.Recompute)
                {
                    var liveEventIds = _accountabilityRepository.GetLiveEventsForPickupType(jobType);

                    if (liveEventIds.Length > 0)
                    {


                        foreach (var eventId in liveEventIds)
                        {
                            SubmitJob(AccountabilityEventJobPickupType.Recompute, eventId);
                        }
                    }
                }

                else if (jobType == AccountabilityEventJobPickupType.Reminder)
                {
                    var liveEventIds = _accountabilityRepository.GetLiveEventsForPickupType(jobType);
                    if (liveEventIds.Length > 0)
                    {
                        _logInfoContent += string.Format(" Reminder - Event count {0} on {1}.", liveEventIds.Length, DateTime.Now);

                        foreach (var eventId in liveEventIds)
                        {
                            _logInfoContent += string.Format(" Reminder Job Submitted - Event ID {0} on {1}.", eventId, DateTime.Now);
                            SubmitJob(AccountabilityEventJobPickupType.Reminder, eventId, operatorId);
                            
                        }
                    }
                }
                else if (jobType == AccountabilityEventJobPickupType.StatusAttribute)
                {
                    ProcessStatusUpdateAttributes();
                }
                else if (jobType == AccountabilityEventJobPickupType.TrackingSummary)
                {
                    string liveStatus = AccountabilityEventStatus.Live.ToString();
                    //get live events for endtime already crossed or euqal to now.
                    var eventquery = from e in _accountabilityRepository.GetEvents().AsNoTracking()
                                     where e.Status == liveStatus
                                     select e.EventId;
                    foreach (var eventId in eventquery)
                    {
                        SubmitJob(AccountabilityEventJobPickupType.TrackingSummary, eventId);
                    }
                }

            }
            catch (Exception ex)
            {
                _logInfoContent += string.Format("ERROR OCCURED on {0}, see event logger for more description",
                    DateTime.Now);
                EventLogger.WriteError("Error in ProcessAccountabilityJob", ex);

            }
            finally
            {
                //Log Event
                if (_isLogInformationEnable && !string.IsNullOrEmpty(_logInfoContent))
                {
                    EventLogger.WriteInformation(_logInfoContent);
                }
            }
        }
        public void ProcessEventToEnd(int accteventId, int operatorId)
        {
            var eventEntity = _accountabilityRepository.GetEventsIncludeAll().FirstOrDefault(e => e.EventId == accteventId);
            var sendAlertToOperator = false;
            if (eventEntity == null)
            {
                var ex = new ObjectNotFoundException(string.Format("Unable to find accountability id for eventId = {0} with Status = Live",
                        accteventId));
                EventLogger.WriteError("Error while ending accountability event", ex);
                return;
            }


            try
            {
                var accountabilityEvent = new AccountabilityEvent();
                accountabilityEvent.FromEntity(eventEntity, true);

                if (eventEntity.OperatorAlertBaseId.GetValueOrDefault() > 0)
                {
                    sendAlertToOperator = true;
                }


                var alertBaseManager = DeserializeAccountabilityAlertBase(accountabilityEvent, eventEntity.ProviderId, operatorId, sendAlertToOperator);
                var vpsCurrentDateTime = alertBaseManager.Provider.CurrentDateTime;
                
                var vpsCurrentTimeFormat = alertBaseManager.Provider.CurrentDateTime.ToString(alertBaseManager.Provider.TimeFormatString);
                var result = PublishEventAlert(eventEntity.ProviderId, operatorId, AccountabilityEventAlertType.Close, accountabilityEvent, vpsCurrentDateTime, vpsCurrentTimeFormat, false, alertBaseManager.Provider.DefaultLocale.LocaleCode);

                //var eventIds = new[] { accteventId };
                //_accountabilityRepository.UpdateEventStatus(operatorId, eventIds, AccountabilityEventStatus.Ended);


                if (eventEntity.AccountabilityEventAlertEntities != null)
                {
                    var arrayOfAlertId = eventEntity.AccountabilityEventAlertEntities.Where(e => e.AccountabilityEventAlertMap.AlertInitType != "Close").Select(e => e.AlertId).ToArray();
                    if (arrayOfAlertId.Length > 0)
                    {
                        EventLogger.WriteInformation(string.Format("Event-Alert-Ending->AlertIds={0}", string.Join(",", arrayOfAlertId)));
                        foreach (var alertId in arrayOfAlertId)
                        {
                            _alertFacade.End(alertId, operatorId, eventEntity.ProviderId, DateTimeConverter.GetSystemTime());
                        }

                    }
                }

                EventLogger.WriteInformation(string.Format("PA Ended - ID = {0} on {1}", eventEntity.EventId, DateTimeConverter.GetSystemTime()));


            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Error while end event", ex);
            }



        }
        public void ProcessReceipientRecompute(int accteventId, int operatorId)
        {
            var eventEntity = _accountabilityRepository.GetEventsIncludeAll().FirstOrDefault(e => e.EventId == accteventId && e.Status == AccountabilityEventStatus.Live.ToString());
            if (eventEntity == null)
            {
                var ex = new ObjectNotFoundException(string.Format("Unable to find accountability id for eventId = {0} and Status = {1}. Event might have just ended.",
                        accteventId, AccountabilityEventStatus.Live.ToString()));
                EventLogger.WriteWarning("While recomputing accountability event -", ex);
                return;
            }

            try
            {
                var providerId = eventEntity.ProviderId;

                //Below function is used as callback while getting the value from cache
                Func<IProviderContext> funcGetProviderContext = () =>
                {
                    IProviderContext tempProviderContext = new ProviderContext();
                    tempProviderContext.ProviderId = providerId;
                    tempProviderContext.BaseLocale = _languageFacade.GetProviderLocale(providerId);
                    return tempProviderContext;
                };

                var providerContext = _accountabilityFacadeCache.GetProviderContext(providerId, funcGetProviderContext);

                var alertBaseMgr = new AlertBaseManager(providerId, operatorId);
                var accountabilityEvent = new AccountabilityEvent();
                accountabilityEvent.FromEntity(eventEntity, false);
                alertBaseMgr.DeserializeAlertSpecificationForAccountability(accountabilityEvent);

                //To recompute - targeting criteria should be from initial alert, so that if any new user is affected, then they should be counted as part of accountability
                PopulateEventRecipient(accountabilityEvent, eventEntity.UpdatedBy, providerContext, isBackgroundJob: true);
                SetNextComputationTime(eventEntity, AccountabilityEventJobPickupType.Recompute);

            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Error while executing recipients", ex);
            }


        }
        public void ProcessReminderAlert(int accteventId, int operatorId)
        {
            var eventEntity = _accountabilityRepository.GetEventsIncludeAll().FirstOrDefault(e => e.EventId == accteventId && e.Status == AccountabilityEventStatus.Live.ToString());
            if (eventEntity == null)
            {
                var ex = new ObjectNotFoundException(string.Format("Unable to find accountability id for eventId = {0} and Status = {1}. Event might have just ended.",
                        accteventId, AccountabilityEventStatus.Live.ToString()));
                EventLogger.WriteWarning("While sending reminder alert for accountability event -", ex);
                return;
            }

            try
            {
                var providerId = eventEntity.ProviderId;
                operatorId = eventEntity.CreatedBy;
                var alertBaseMgr = new AlertBaseManager(providerId, operatorId);
                var accountabilityEvent = new AccountabilityEvent();
                accountabilityEvent.FromEntity(eventEntity, true);
                alertBaseMgr.DeserializeAlertSpecification(accountabilityEvent);
                var vpsTimeFormat = alertBaseMgr.Provider.CurrentDateTime.ToString(alertBaseMgr.Provider.TimeFormatString);
                var vpsCurrentDateTime = alertBaseMgr.Provider.CurrentDateTime;
                if (accountabilityEvent.EndDate != null)
                    accountabilityEvent.EndDate = accountabilityEvent.EndDate.Value.AddSeconds(alertBaseMgr.Provider.TimeZoneOffsetToVPS * 3600);
                PublishEventAlert(eventEntity.ProviderId, eventEntity.UpdatedBy, AccountabilityEventAlertType.Reminder, accountabilityEvent, vpsCurrentDateTime, vpsTimeFormat, false, alertBaseMgr.Provider.DefaultLocale.LocaleCode);
                SetNextComputationTime(eventEntity, AccountabilityEventJobPickupType.Reminder);


            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Error while sending reminder alert", ex);
            }


        }

        public void ProcessStartAlert(int accteventId, int operatorId)
        {
            var eventEntity = _accountabilityRepository.GetEventsIncludeAll().FirstOrDefault(e => e.EventId == accteventId);

            if (eventEntity == null)
            {
                var ex = new ObjectNotFoundException(string.Format("Unable to find accountability id for eventId = {0}",
                        accteventId));
                EventLogger.WriteError("Error while starting accountability event", ex);
                return;
            }
            if (eventEntity.Status == AccountabilityEventStatus.Deleted.ToString() || eventEntity.Status == AccountabilityEventStatus.Ended.ToString())
            {
                var errormessage = string.Format("Cannot start the event. Event id = {0}, the status is already marked as {1}", accteventId,
                    eventEntity.Status);
                EventLogger.WriteWarning(errormessage);
                return;
            }
            try
            {

                var providerId = eventEntity.ProviderId;
                var accountabilityEvent = new AccountabilityEvent();
                var sendAlertToOperator = eventEntity.OperatorAlertBaseId.GetValueOrDefault() > 0;

                accountabilityEvent.FromEntity(eventEntity, true);
                var alertBaseManager = DeserializeAccountabilityAlertBase(accountabilityEvent, providerId, operatorId, sendAlertToOperator);
                var vpsTimeFormat = alertBaseManager.Provider.CurrentDateTime.ToString(alertBaseManager.Provider.TimeFormatString);
                var vpsCurrentDateTime = alertBaseManager.Provider.CurrentDateTime;
               
                if (accountabilityEvent.EndDate != null)
                    accountabilityEvent.EndDate = accountabilityEvent.EndDate.Value.AddSeconds(alertBaseManager.Provider.TimeZoneOffsetToVPS * 3600);

                PublishEventAlert(eventEntity.ProviderId, eventEntity.UpdatedBy, AccountabilityEventAlertType.Start, accountabilityEvent, vpsCurrentDateTime, vpsTimeFormat, false, alertBaseManager.Provider.DefaultLocale.LocaleCode);
                //var eventIds = new List<int> { accteventId };
                //_accountabilityRepository.UpdateEventStatus(operatorId, eventIds, AccountabilityEventStatus.Live);

            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Error while sending start alert", ex);

            }
        }

        public void ProcessStatusUpdateAttributes()
        {
            //call the sp to update event status
            if (!_accountabilityRepository.UpdateEventStatus())
            {
                var errormessage = string.Format("Failed to updated the recipient tab via background job.");
                EventLogger.WriteError(errormessage);
            }
        }

        public void ProcessEventTrackingSummary(int eventId)
        {
            try
            {
                _accountabilityRepository.UpdateAlertSummary(eventId);
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("UpdateAlertSummary failed " ));
            }

        }
        private AlertBaseManager DeserializeAccountabilityAlertBase(AccountabilityEvent accountabilityEvent, int providerId, int operatorId, bool includeOperatorAlertBase)
        {
            var alertBaseMgr = new AlertBaseManager(providerId, operatorId);
            alertBaseMgr.DeserializeAlertSpecification(accountabilityEvent);
            if (!includeOperatorAlertBase) return alertBaseMgr;
            accountabilityEvent.OperatorAlertBase = new AccountabilityAlertBase { AlertId = accountabilityEvent.OperatorAlertBaseId.GetValueOrDefault(), ProviderId = providerId };
            alertBaseMgr.DeserializeAlertSpecification(accountabilityEvent.OperatorAlertBase);
            return alertBaseMgr;
        }

        /// <summary>
        /// Set Next Computation time for Reminder and Recipient update
        /// </summary>
        /// <param name="acctEvent"></param>
        /// <param name="jtype">job type</param>
        private void SetNextComputationTime(AccountabilityEventEntity acctEvent, AccountabilityEventJobPickupType jtype)
        {
            var jobTypeDescription = jtype.GetDescription();
            if (jtype == AccountabilityEventJobPickupType.Recompute)
            {
                var durationValue = acctEvent.EventRecipientRefreshIntervalValue.GetValueOrDefault();
                if (durationValue >= 0)
                {
                    var nextexecutionduration = new Duration(acctEvent.EventRecipientRefreshIntervalUnit, durationValue); //Evaluate Duration
                    var evtScheduleEntity = GetEventPickupScheduleEntity(acctEvent.EventId, nextexecutionduration, jobTypeDescription); //Calculate next pick up time
                    SetEventPickupScheduleEntity(acctEvent.EventId, evtScheduleEntity.NextRunTime, jtype);

                }
            }
            else if (jtype == AccountabilityEventJobPickupType.Reminder)
            {
                var eventToSetNextCompute = _accountabilityRepository.GetEventAlertMapEntities()
                    .FirstOrDefault(e => e.EventId == acctEvent.EventId && e.AlertInitType == AccountabilityEventAlertType.Reminder.ToString() && e.IsEnabled == "Y");


                if (eventToSetNextCompute != null && eventToSetNextCompute.AlertRepeatDurationValue > 0)
                {
                    var nextexecutionduration = new Duration(eventToSetNextCompute.AlertRepeatDurationUnit, eventToSetNextCompute.AlertRepeatDurationValue);
                    var evtScheduleEntity = GetEventPickupScheduleEntity(eventToSetNextCompute.EventId, nextexecutionduration, jobTypeDescription);
                    SetEventPickupScheduleEntity(acctEvent.EventId, evtScheduleEntity.NextRunTime, jtype);

                }

            }

        }

        /// <summary>
        /// Build AccountabilityEventPickupScheduleEntity object
        /// </summary>
        /// <param name="eventId"></param>
        /// <param name="nextexecutionduration"></param>
        /// <param name="pickupActionType"></param>
        /// <returns></returns>
        private AccountabilityEventPickupScheduleEntity GetEventPickupScheduleEntity(int eventId, Duration nextexecutionduration, string pickupActionType)
        {
            var currentSystemDateTime = DateTimeConverter.GetSystemTime();
            var evtScheduleEntity = new AccountabilityEventPickupScheduleEntity { EventId = eventId };
            evtScheduleEntity.PickupActionType = pickupActionType;
            evtScheduleEntity.NextRunTime = nextexecutionduration.GetEndTime(currentSystemDateTime);
            return evtScheduleEntity;
        }
        private bool SetEventPickupScheduleEntity(int eventId, DateTime nextexecutionduration, AccountabilityEventJobPickupType pickupActionType)
        {
            return _accountabilityRepository.UpdateEventPickupSchedule(eventId, nextexecutionduration, pickupActionType);
        }

        private void SubmitJob(AccountabilityEventJobPickupType jobType, int acctEventId, int operatorId = 1)
        {

            var schEntity = new ScheduledEntity();
            schEntity.DbAdminLoginRequired = "N";
            schEntity.Payload = GetPayload(jobType, acctEventId, operatorId);
            schEntity.RunOn = DateTimeConverter.GetSystemTimeAsSeconds();
            schEntity.TimeoutInterval = 300;
            short priority = 5; //7 being high and min number being lowest priority.
            switch (jobType)
            {
                case AccountabilityEventJobPickupType.Start:
                    priority = 7; //7 is high
                    break;
                case AccountabilityEventJobPickupType.Recompute:
                    priority = 5;
                    break;
                case AccountabilityEventJobPickupType.Reminder:
                    priority = 6;
                    break;
                case AccountabilityEventJobPickupType.End:
                    priority = 6;
                    break;
                case AccountabilityEventJobPickupType.StatusAttribute:
                    priority = 6;
                    break;
                case AccountabilityEventJobPickupType.TrackingSummary:
                    priority = 6;
                    break;
            }
            schEntity.Priority = priority;
            try
            {
                IScheduleFacade scheduleFacade = new ScheduleFacade(null);
                var jobDetails = scheduleFacade.CreateJob(schEntity, ScheduleType.Single);
                _accountabilityRepository.UpdateEventPickupScheduleJobId(acctEventId, jobDetails.Id, jobType.ToString());
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("Error while submitting job - Payload => {0}", schEntity.Payload), ex);
            }

        }

        private string GetPayload(AccountabilityEventJobPickupType jobType, int eventId, int operatorId)
        {
            const string methodName = "ExecuteJob";
            const string payloadTemplate = "<PAYLOAD PLATFORM=\"DOTNET\">" +
                                           "<PACKAGE SOURCE=\"AtHoc.IWS.Business, Version=1.0.0.0, Culture=neutral, PublicKeyToken=148270b0172fe65b\" LOCATION=\"GAC\">AtHoc.IWS.Business.Domain.Accountability.Impl</PACKAGE>" +
                                           "<CLASS>AccountabilityEventProcessor</CLASS> <METHOD>{0}</METHOD> <PARAMETERS><PARAM TYPE=\"Integer\" VALUE=\"{1}\" /><PARAM TYPE=\"Integer\" VALUE=\"{2}\" /><PARAM TYPE=\"Integer\" VALUE=\"{3}\" /></PARAMETERS></PAYLOAD>";
            string resultPayload = string.Format(payloadTemplate, methodName, (int)jobType, eventId, operatorId);
            return resultPayload;
        }


    }


}
