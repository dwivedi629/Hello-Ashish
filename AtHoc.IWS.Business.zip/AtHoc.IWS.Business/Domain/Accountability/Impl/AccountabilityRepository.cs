﻿using System;
using System.CodeDom;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.Entity;
using System.Data.Entity.Migrations;
using System.Data.SqlClient;
using System.Drawing.Text;
using System.Linq;
using System.Linq.Dynamic;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Data;
using AtHoc.Data.Specification;
using AtHoc.Diagnostics;
using AtHoc.Global.Resources;
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.Accountability.Specs;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Entities.Accountability;
using AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.Publishing;
using AtHoc.Utilities;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;

namespace AtHoc.IWS.Business.Domain.Accountability.Impl
{
    public class AccountabilityRepository : IAccountabilityRepository
    {
        #region template methods

        /// <summary>
        /// To get templates.
        /// </summary>
        /// <returns>accountability templates.</returns>
        public IQueryable<AccountabilityTemplateEntity> GetTemplates()
        {
            try
            {
                //Obtain Data Source
                var context = new AtHocDbContext();

                //Build query
                var templates = context.AccountabilityTemplateEntities.Include(e => e.Events);
                return templates;

            }
            catch (Exception ex)
            {
                EventLogger.WriteError("failed to get Accountability Templates", ex);
                return null;
            }
        }

        /// <summary>
        /// To get template.
        /// </summary>
        /// <param name="templateId">template Id.</param>
        /// <returns>accountability template.</returns>
        public AccountabilityTemplateEntity GetTemplate(int templateId)
        {
            try
            {
                using (var context = new AtHocDbContext())
                {
                    var templateDetails =
                        context.AccountabilityTemplateEntities.FirstOrDefault(a => a.TemplateId == templateId);
                    if (templateDetails != null) return templateDetails;
                    EventLogger.WriteError(
                        string.Format(
                            "Failed to get accountability template, failed to find template id: {0}",
                            templateId));
                    return null;
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("failed to get Accountability Template", ex);
                return null;
            }
        }

        /// <summary>
        /// To create the template.
        /// </summary>
        /// <param name="templateDetails">template details.</param>
        /// <returns>template Id.</returns>
        public int CreateTemplate(AccountabilityTemplateEntity templateDetails)
        {
            try
            {
                using (var context = new AtHocDbContext())
                {
                    var templateToCreate = context.AccountabilityTemplateEntities.Add(templateDetails);
                    context.SaveChanges();
                    return templateToCreate.TemplateId;
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Error in Create the Accountability Template", ex);
                return -1;
            }
        }

        /// <summary>
        /// To update the template.
        /// </summary>
        /// <param name="templateDetails">template details.</param>
        /// <returns>true if updated successfully.</returns>
        public bool UpdateTemplate(AccountabilityTemplateEntity templateDetails)
        {
            try
            {
                using (var context = new AtHocDbContext())
                {
                    var templateToUpdate =
                        context.AccountabilityTemplateEntities.FirstOrDefault(
                            a => a.TemplateId == templateDetails.TemplateId);
                    if (templateToUpdate == null)
                    {
                        EventLogger.WriteError(
                            string.Format("Failed to Update accountability template, failed to find template id: {0}",
                                templateDetails.TemplateId));
                        return false;
                    }

                    templateToUpdate.Name = templateDetails.Name;
                    templateToUpdate.Description = templateDetails.Description;
                    templateToUpdate.OperatorAlertBaseId = templateDetails.OperatorAlertBaseId;
                    //templateToUpdate.TemplateAlertMapEntities = templateToUpdate.TemplateAlertMapEntities;
                    templateToUpdate.PastStatusValidityDurationUnit = templateDetails.PastStatusValidityDurationUnit;
                    templateToUpdate.PastStatusValidityDurationValue = templateDetails.PastStatusValidityDurationValue;
                    templateToUpdate.EventRecipientRefreshIntervalUnit =
                        templateDetails.EventRecipientRefreshIntervalUnit;
                    templateToUpdate.EventRecipientRefreshIntervalValue =
                        templateDetails.EventRecipientRefreshIntervalValue;

                    foreach (var alertMapEntity in templateDetails.TemplateAlertMapEntities)
                    {
                        var alertMapEnt =
                            templateToUpdate.TemplateAlertMapEntities.FirstOrDefault(x => x.Id == alertMapEntity.Id);
                        if (alertMapEnt != null)
                        {
                            alertMapEnt.Body = alertMapEntity.Body;
                            alertMapEnt.Title = alertMapEntity.Title;
                            alertMapEnt.IsEnabled = alertMapEntity.IsEnabled;
                            alertMapEnt.AlertRepeatDurationUnit = alertMapEntity.AlertRepeatDurationUnit;
                            alertMapEnt.AlertRepeatDurationValue = alertMapEntity.AlertRepeatDurationValue;
                        }
                    }

                    //if (templateDetails.TemplateAlertMapEntities != null &&
                    //    templateDetails.TemplateAlertMapEntities.Any())
                    //{
                    //    templateToUpdate.TemplateAlertMapEntities = templateDetails.TemplateAlertMapEntities;
                    //}

                    templateToUpdate.UpdatedBy = templateDetails.UpdatedBy;
                    templateToUpdate.UpdatedOn = templateDetails.UpdatedOn;
                    //templateToUpdate.Status = templateDetails.Status;
                    context.SaveChanges();

                    return true;
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("failed to Update Accountability Template", ex);
                return false;
            }
        }

        /// <summary>
        /// To delete the template.
        /// </summary>
        /// <param name="ids">template Ids.</param>
        /// <param name="operatorId">operator Id.</param>
        /// <returns>true if deleted successfully.</returns>
        public IEnumerable<AccountabilityTemplateEntity> DeleteTemplates(int operatorId, IEnumerable<int> ids)
        {
            if (ids.Count() == 0)
            {
                throw new ArgumentNullException();
            }
            try
            {
                using (var context = new AtHocDbContext())
                {
                    var templates = context.AccountabilityTemplateEntities.Where(a => ids.Contains(a.TemplateId));
                    foreach (var template in templates.ToList())
                    {
                        template.UpdatedOn = DateTimeConverter.GetSystemTime();
                        template.UpdatedBy = operatorId;
                        template.Status = AccountabilityTemplateStatus.Deleted.GetDescription();
                        // status-'DEL' represents the virtual deletion of the template.                        
                    }
                    /*templates.ForEach(a =>
                    {
                        a.Status = "DEL"; // status-'DEL' represents the virtual deletion of the template.
                        a.UpdatedOn = DateTime.Now;
                        a.UpdatedBy = operatorId;
                    });*/
                    context.SaveChanges();
                    return templates.ToList();
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("failed to Delete Accountability Template", ex);
                throw;
            }
        }

        #endregion

        #region entity methods

        /// <summary>
        /// To get events.
        /// </summary>
        /// <returns>events.</returns>
        public IQueryable<AccountabilityEventEntity> GetEventsIncludeAll()
        {
            try
            {
                //Obtain Data Source
                var context = new AtHocDbContext();

                //Build query
                var query = context.AccountabilityEventEntities
                    .Include(e => e.AccountabilityEventAlertMapEntities)
                    .Include(e => e.AccountabilityEventSummaryTrackingEntity)
                    .Include(e => e.AccountabilityEventAlertEntities);

                return query;

            }
            catch (Exception ex)
            {
                EventLogger.WriteError("failed to get Accountability Events", ex);
                return null;
            }

        }

        /// <summary>
        /// To get events.
        /// </summary>
        /// <returns>events.</returns>
        public IQueryable<AccountabilityEventEntity> GetEvents(IEnumerable<string> listOfEntitiesToInclude = null)
        {
            try
            {
                //Obtain Data Source
                var context = new AtHocDbContext();

                //Build query
                var query = context.AccountabilityEventEntities;
                if (listOfEntitiesToInclude != null)
                {
                    foreach (var entityName in listOfEntitiesToInclude)
                    {
                        query.Include(entityName);
                    }
                }
                return query;

            }
            catch (Exception ex)
            {
                EventLogger.WriteError("failed to get Accountability Events", ex);
                return null;
            }

        }

        /// <summary>
        /// To get accountability  event.
        /// </summary>
        /// <param name="eventId">event Id.</param>
        /// <param name="includeReminderAlerts"></param>
        /// <returns>Event Details.</returns>
        public AccountabilityEventEntity GetEvent(int eventId, bool includeReminderAlerts)
        {
            try
            {
                //Obtain Data Source
                var context = new AtHocDbContext();
                //Build query
                //todo: please fix that!
                //var eventEntity = !includeReminderAlerts ? context.AccountabilityEventEntities.FirstOrDefault(a => a.EventId == eventId) : context.AccountabilityEventEntities.Include("ReminderAlerts").FirstOrDefault(a => a.EventId == eventId);                
                var eventEntity = context.AccountabilityEventEntities
                    .Include(e => e.AccountabilityEventAlertMapEntities)
                    .Include(e => e.AccountabilityEventSummaryTrackingEntity)
                    .Include(e => e.AccountabilityEventAlertEntities)

                    .FirstOrDefault(a => a.EventId == eventId);
                return eventEntity;
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("failed to get Accountability Event", ex);
                return null;
            }
        }

        /// <summary>
        /// To create event.
        /// </summary>
        /// <param name="actEvent">evnet object.</param>
        /// <returns>event id.</returns>
        public int CreateEvent(AccountabilityEventEntity actEvent)
        {
            try
            {
                using (var context = new AtHocDbContext())
                {

                    var eventToCreate = context.AccountabilityEventEntities.Add(actEvent);
                    if (actEvent.AccountabilityEventAlertMapEntities != null)
                    {
                        foreach (var eventAlertMapEntity in actEvent.AccountabilityEventAlertMapEntities)
                        {
                            context.AccountabilityEventAlertMapEntities.Add(eventAlertMapEntity);
                        }
                    }
                    context.SaveChanges();
                    return eventToCreate.EventId;
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Error in Create Accountability Event", ex);
                return -1;
            }
        }

        /// <summary>
        /// To set the event user status.
        /// </summary>
        /// <param name="eventId">eventId.</param>
        /// <param name="attributeId"></param>
        /// <param name="userStatusList">userStatusList.</param>
        public void SetEventUserStatus(int eventId, int attributeId, Dictionary<int, int> userStatusList)
        {
            try
            {
                //Obtain Data Source
                var context = new AtHocDbContext();

                //Build query
                foreach (
                    var newUserStatus in userStatusList.Select(userStatus => new AccountabilityEventUserStatusEntity
                    {
                        EventId = eventId,
                        UserStatusOrderId = userStatus.Value,
                        UserStatusAttributeValueId = userStatus.Key,
                        UserStatusAttributeId = attributeId

                    }))
                {
                    context.AccountabilityEventUserStatusEntities.Add(newUserStatus);

                }
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("failed to set Event Usr Status", ex);
            }
        }

        /// <summary>
        /// To update Accountability Event. 
        /// </summary>
        /// <param name="eventEntity">event Entity.</param>
        /// <returns>true-if updated successfully.</returns>
        public bool UpdateEvent(AccountabilityEventEntity eventEntity)
        {
            try
            {
                using (var context = new AtHocDbContext())
                {
                    var eventToUpdate =
                        context.AccountabilityEventEntities.FirstOrDefault(a => a.EventId == eventEntity.EventId);
                    if (eventToUpdate == null)
                    {
                        EventLogger.WriteError(
                            string.Format(
                                "Failed to Update accountability event, failed to find event id: {0}",
                                eventEntity.EventId));
                        return false;
                    }

                    eventToUpdate.Name = eventEntity.Name;
                    eventToUpdate.StartDate = eventEntity.StartDate;
                    eventToUpdate.EndDate = eventEntity.EndDate;
                    eventToUpdate.PublishedOn = eventEntity.PublishedOn;
                    eventToUpdate.PublishedByUserId = eventEntity.PublishedByUserId;

                    eventToUpdate.EndedByUserId = eventEntity.EndedByUserId;
                    eventToUpdate.EndedOn = eventEntity.EndedOn;
                    if (eventEntity.AccountabilityEventAlertMapEntities != null &&
                        eventEntity.AccountabilityEventAlertMapEntities.Any())
                    {
                        foreach (var alertMapEntity in eventEntity.AccountabilityEventAlertMapEntities)
                        {
                            var alertMapEnt =
                                eventToUpdate.AccountabilityEventAlertMapEntities.FirstOrDefault(
                                    x => x.Id == alertMapEntity.Id);
                            if (alertMapEnt == null) continue;
                            alertMapEnt.Body = alertMapEntity.Body;
                            alertMapEnt.Title = alertMapEntity.Title;
                            alertMapEnt.IsEnabled = alertMapEntity.IsEnabled;
                            alertMapEnt.AlertRepeatDurationUnit = alertMapEntity.AlertRepeatDurationUnit;
                            alertMapEnt.AlertRepeatDurationValue = alertMapEntity.AlertRepeatDurationValue;
                        }
                    }

                    eventToUpdate.PastStatusValidityDurationUnit = eventEntity.PastStatusValidityDurationUnit;
                    eventToUpdate.PastStatusValidityDurationValue = eventEntity.PastStatusValidityDurationValue;
                    eventToUpdate.EventRecipientRefreshIntervalUnit = eventEntity.EventRecipientRefreshIntervalUnit;
                    eventToUpdate.EventRecipientRefreshIntervalValue = eventEntity.EventRecipientRefreshIntervalValue;

                    eventToUpdate.UpdatedOn = DateTimeConverter.GetSystemTime();
                    eventToUpdate.UpdatedBy = eventEntity.UpdatedBy;

                    context.SaveChanges();

                    return true;
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("failed to Update Accountability Event", ex);
                return false;
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="operatorId"></param>
        /// <param name="ids"></param>
        /// <param name="actEventStatus"></param>
        /// <returns></returns>
        public IEnumerable<AccountabilityEventEntity> UpdateEventStatus(int operatorId, IEnumerable<int> ids,
            AccountabilityEventStatus actEventStatus)
        {
            var eventids = ids as int[] ?? ids.ToArray();
            if (!eventids.Any())
            {
                throw new ArgumentNullException();
            }
            try
            {
                var currentTime = DateTimeConverter.GetSystemTime();

                using (var context = new AtHocDbContext())
                {
                    var events = context.AccountabilityEventEntities.Where(a => eventids.Contains(a.EventId));
                    foreach (var eventEntity in events.ToList())
                    {
                        switch (actEventStatus)
                        {
                            case AccountabilityEventStatus.Live:
                            case AccountabilityEventStatus.Publishing:
                                eventEntity.Status = actEventStatus.ToString();
                                eventEntity.PublishedOn = currentTime;
                                eventEntity.PublishedByUserId = operatorId;
                                break;
                            case AccountabilityEventStatus.Ended:
                            case AccountabilityEventStatus.Deleted:
                                eventEntity.Status = actEventStatus.ToString();
                                eventEntity.EndedOn = currentTime;
                                eventEntity.EndedByUserId = operatorId;
                                break;

                        }
                    }
                    context.SaveChanges();
                    return events.ToList(); //TODO:WHy do we need to return this.?
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("failed to update the event status", ex);
                return null;
            }
        }


        /// <summary>
        /// Get IQueryable of AccountabilityEventPickupScheduleEntity
        /// </summary>
        /// <param name="includeAccountabilityEvent">Default:True - Include AccountabilityEvent Entity</param>
        /// <returns>IQueryable of AccountabilityEventPickupScheduleEntity</returns>
        public IQueryable<AccountabilityEventPickupScheduleEntity> GetEventPickupScheduleEntity(
            bool includeAccountabilityEvent = true)
        {
            try
            {
                //Obtain Data Source
                var context = new AtHocDbContext();

                //Build query
                if (includeAccountabilityEvent)
                {
                    var actEvents = context.AccountabilityEventPickupScheduleEntities.Include(e => e.AccountabilityEvent);
                    return actEvents;
                }
                else
                {
                    var actEvents = context.AccountabilityEventPickupScheduleEntities;
                    return actEvents;
                }

            }
            catch (Exception ex)
            {
                EventLogger.WriteError("failed to get Accountability Events Pickup Entity", ex);
                return null;
            }

        }


        /// <summary>
        /// To update next alert time.
        /// </summary>
        /// <param name="acctEventPickupScheduleEntity">Acct Event Pickup Schedule Obj.</param>
        /// <returns>true is update transaction is successful.</returns>
        public bool AddEventPickupSchedule(List<AccountabilityEventPickupScheduleEntity> acctEventPickupScheduleEntity)
        {
            if (acctEventPickupScheduleEntity == null || acctEventPickupScheduleEntity.Count == 0)
            {
                throw new ArgumentNullException("acctEventPickupScheduleEntity");
            }

            try
            {

                using (var context = new AtHocDbContext())
                {
                    context.AccountabilityEventPickupScheduleEntities.AddRange(acctEventPickupScheduleEntity);
                    context.SaveChanges();

                    return true;
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("failed to Update Accountability Event pickup time", ex);
                return false;
            }
        }

        /// <summary>
        /// To update next alert time.
        /// </summary>
        /// <param name="eventId"></param>
        /// <param name="acctEventPickupScheduleEntity">Acct Event Pickup Schedule Obj.</param>
        /// <returns>true is update transaction is successful.</returns>

        public IEnumerable<AccountabilityEventRecipientBase> GetEventRecipients(int eventId)
        {
            try
            {
                object[] parameters = { eventId };

                using (var context = new AtHocDbContext())
                {
                    var resultSet = context.Database.SqlQuery<AccountabilityEventRecipientBase>("ACCT_EVENT_GET_RECIPIENT_BASE {0}", parameters).ToList();
                    return resultSet;
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("failed to get Accountability Recipients", ex);
                return null;
            }
        }

        public bool UpdateEventRecipients(AccountabilityEvent accountabilityEvent, List<UserSearchResultItem> users)
        {
            try
            {
                using (var context = new AtHocDbContext())
                {
                    const int batchSize = 500;
                    int iUpdateCounter = 0;

                    context.Configuration.AutoDetectChangesEnabled = false;
                    context.Configuration.ValidateOnSaveEnabled = false;

                    users.ForEach(user =>
                    {
                        int updatedBy;
                        Int32.TryParse(user.UserAttributes[AttributeCommonNames.UpdatedBy], out updatedBy);
                        int statusid;
                        Int32.TryParse(user.UserAttributes[AttributeCommonNames.StatusId], out statusid);

                        DateTime statusupdatedon;
                        DateTime.TryParse(user.UserAttributes[AttributeCommonNames.UpdatedOn], out statusupdatedon);

                        var entityToUpdate =
                            context.AccountabilityEventRecipientEntities.FirstOrDefault(
                                e => e.EventId == accountabilityEvent.EventId && e.UserId == user.Id);
                        bool isNewUser = entityToUpdate == null;

                        var entity = new AccountabilityEventRecipientEntity()
                        {
                            EventId = accountabilityEvent.EventId,
                            UserId = user.Id,
                            UserStatusAttributeId = statusid,
                            StatusUpdatedOn = statusupdatedon == DateTime.MinValue ? (DateTime?)null : statusupdatedon,
                            UpdatedBy = updatedBy,
                            UpdateFrom = user.UserAttributes[AttributeCommonNames.UpdatedFrom],
                            Comments = user.UserAttributes[AttributeCommonNames.Comments],
                            CreatedOn = DateTimeConverter.GetSystemTime(),
                            IsExcluded = "N"
                        };


                        if (entityToUpdate != null)
                        {
                            entityToUpdate.UserStatusAttributeId = entity.UserStatusAttributeId;
                            entityToUpdate.StatusUpdatedOn = statusupdatedon == DateTime.MinValue
                                ? (DateTime?)null
                                : statusupdatedon;
                            entityToUpdate.UpdatedBy = updatedBy;
                            entityToUpdate.UpdateFrom = user.UserAttributes[AttributeCommonNames.UpdatedFrom];
                            entityToUpdate.Comments = user.UserAttributes[AttributeCommonNames.Comments];
                            context.Entry(entityToUpdate).State = EntityState.Modified;

                        }
                        else
                        {
                            context.AccountabilityEventRecipientEntities.Add(entity);
                        }

                        iUpdateCounter++;
                        if (iUpdateCounter % batchSize == 0)
                        {
                            context.SaveChanges();
                            iUpdateCounter = 0;
                        }
                    });
                    context.SaveChanges();
                }

            }
            catch (Exception ex)
            {
                EventLogger.WriteError(
                    string.Format(
                        "Error in method: UpdateEventRecipients(AccountabilityEvent accountabilityEvent, ContextSearchResult userSearchResult)",
                        ex));
                throw;
            }

            return true;
        }

        /// <summary>
        /// Add / exclude/include affected user
        /// </summary>
        /// <param name="eventId">Accountability Event Id</param>
        /// <param name="itemsToAdd"> List of users to add</param>
        /// <param name="includeList">User ids to set as ISEXCLUDE='N'</param>
        /// <param name="excludeList">User ids to set as ISEXCLUDE='Y'</param>
        /// <returns></returns>
        public bool AddUpdateEventRecipients(int eventId, List<AccountabilityEventRecipientEntity> itemsToAdd)
        {
            var context = new AtHocDbContext();
            var connectionString = context.Database.Connection.ConnectionString;

            using (var sqlConnection = new SqlConnection(connectionString))
            {
                sqlConnection.Open();

                using (var bulkCopy = new SqlBulkCopy(connectionString))
                {
                    bulkCopy.BatchSize = 10000;
                    bulkCopy.DestinationTableName = "dbo.ACCT_EVENT_RECIPIENT_TAB";
                    bulkCopy.ColumnMappings.Add("EventId", "ACCT_EVENT_ID");
                    bulkCopy.ColumnMappings.Add("UserId", "USER_ID");
                    bulkCopy.ColumnMappings.Add("UserStatusAttributeId", "USER_ACCT_STATUS_ID");
                    bulkCopy.ColumnMappings.Add("StatusUpdatedOn", "STATUS_UPDATED_ON");
                    bulkCopy.ColumnMappings.Add("CreatedOn", "CREATED_ON");
                    bulkCopy.ColumnMappings.Add("UpdatedBy", "UPDATED_BY");
                    bulkCopy.ColumnMappings.Add("UpdateFrom", "UPDATED_FROM");
                    bulkCopy.ColumnMappings.Add("Comments", "COMMENTS");
                    bulkCopy.ColumnMappings.Add("IsExcluded", "IS_EXCLUDED");
                    bulkCopy.WriteToServer(ToDataTable(itemsToAdd));
                }
            }

            return true;
        }

        private static DataTable ToDataTable(List<AccountabilityEventRecipientEntity> items)
        {
            DataTable dataTable = new DataTable(typeof(AccountabilityEventRecipientEntity).Name);

            //Get all the properties
            PropertyInfo[] Props = typeof(AccountabilityEventRecipientEntity).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Defining type of data column gives proper data table 
                var type = (prop.PropertyType.IsGenericType && prop.PropertyType.GetGenericTypeDefinition() == typeof(Nullable<>) ? Nullable.GetUnderlyingType(prop.PropertyType) : prop.PropertyType);
                //Setting column names as Property names
                dataTable.Columns.Add(prop.Name, type);
            }

            foreach (AccountabilityEventRecipientEntity item in items)
            {
                dataTable.Rows.Add(item.AccountabilityEvent,
                    item.Id,
                    item.EventId,
                    item.UserId,
                    item.UserStatusAttributeId,
                    item.StatusUpdatedOn,
                    item.CreatedOn,
                    item.UpdatedBy,
                    item.UpdateFrom,
                    item.Comments,
                    item.IsExcluded);
            }

            //put a breakpoint here and check datatable
            return dataTable;
        }

        public IQueryable<AccountabilityEventStatusAttribute> GetEventStatusAttributeList(int eventId, int providerId)
        {
            var context = new AtHocDbContext();
            object[] parameters = { providerId, eventId };
            var sql =
                @" select b.ATTRIBUTE_ID AttributeId,b.VALUE_ID ValueId, b.COMMON_NAME CommonName, c.VALUE_NAME ValueName, b.SORT_ORDER SortOrder
                                    from dbo.prv_attribute_value_tab b with (nolock) 
                                    inner join dbo.prv_attribute_value_locale_tab c with (nolock)  
                                    on b.attribute_id = c.attribute_id and b.value_id = c.value_id 
                                    and c.locale_code = (select locale_code from prv_locale_tab with (nolock) where provider_id ={0} and ISNULL(IS_DEFAULT,'N') = 'Y')
                                    where  b.value_id in (Select USER_ACCT_ATTRIBUTE_VALUE_ID from  ACCT_EVENT_USER_STATUS_TAB with (nolock) 
                                    where [ACCT_EVENT_ID]={1})";
            var statusQuery = context.Database
                .SqlQuery<AccountabilityEventStatusAttribute>(sql, parameters).AsQueryable();
            return statusQuery;

        }

        public IDictionary<int, IEnumerable<AccountabilityEventStatusAttributePerEvent>> GetEventStatusAttributeListPerEvent(List<int> eventIds, int providerId)
        {
            var context = new AtHocDbContext();
            object[] parameters = { };
            var sql =
                @" select d.ACCT_EVENT_ID as EventId, b.value_id, b.ATTRIBUTE_ID AttributeId,b.VALUE_ID ValueId, b.COMMON_NAME CommonName, c.VALUE_NAME ValueName, b.SORT_ORDER SortOrder
                                    from dbo.prv_attribute_value_tab b with (nolock) 
                                    inner join dbo.prv_attribute_value_locale_tab c with (nolock)  
                                    on b.attribute_id = c.attribute_id and b.value_id = c.value_id 
									inner join dbo.ACCT_EVENT_USER_STATUS_TAB d with (nolock)
                                    on b.value_id = d.USER_ACCT_ATTRIBUTE_VALUE_ID
                                    and c.locale_code = (select locale_code from prv_locale_tab with (nolock) where provider_id ={0} and ISNULL(IS_DEFAULT,'N') = 'Y')
                                    where [ACCT_EVENT_ID] IN ({1})";

            var evtId = string.Join(",", eventIds);

            sql = string.Format(sql, providerId, evtId);

            var statusQuery = context.Database
                .SqlQuery<AccountabilityEventStatusAttributePerEvent>(sql, parameters).AsQueryable();

            var statusResult = statusQuery.GroupBy(g => g.EventId).ToDictionary(g => g.Key, g => g.AsEnumerable());

            return statusResult;
        }

        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="operatorId"></param>
        /// <param name="ids"></param>
        /// <param name="valueId"></param>
        /// /// <param name="attributeId"></param>
        /// <param name="userStatusList"></param>
        /// <returns></returns>
        public bool UpdateUsersStatus(UserStatusUpdateSpec userStatusList)
        {
            if (userStatusList == null)
            {
                throw new ArgumentNullException("userStatusList");
            }
            try
            {
                var userIds = string.Join(",", userStatusList.UserIds);
                using (var ngadDb = new NgadDatabase())
                {
                    ngadDb.AddParameter(new SqlParameter("@tgtUsersList", userIds));
                    ngadDb.AddParameter(new SqlParameter("@attributeId", userStatusList.AttributeId));
                    ngadDb.AddParameter(new SqlParameter("@valueId", userStatusList.ValueId));
                    ngadDb.AddParameter(new SqlParameter("@updatedBy", userStatusList.UpdatedBy));
                    ngadDb.AddParameter(new SqlParameter("@comments", userStatusList.Comments ?? string.Empty));
                    ngadDb.AddParameter(new SqlParameter("@updatedFrom", userStatusList.UpdatedFrom ?? string.Empty));
                    ngadDb.AddParameter(new SqlParameter("@acctEventId", userStatusList.EventId));
                    ngadDb.CommandType = CommandType.StoredProcedure;
                    ngadDb.ExecuteNonQuery("dbo.USER_ATTRIBUTE_STATUS_UPDATE");
                }

                return true;
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Error while updating user status.", ex);
                return false;
            }
        }

        public IDictionary<int, DateTime> GetEventBaseTemplateForEvents(Int32[] templateIds)
        {
            try
            {
                var context = new AtHocDbContext();
                var actEvents = context.AccountabilityEventEntities.ToList();

                IDictionary<int, DateTime> templateLastPublished = new Dictionary<int, DateTime>();
                for (int i = 0; i < templateIds.Length; i++)
                {
                    var relatedEvents = actEvents.FindAll(a => a.TemplateId == templateIds[i]);
                    if (relatedEvents.Count > 0)
                    {
                        var firstPublishedEvent = relatedEvents.OrderBy(a => a.StartDate).Last();
                        templateLastPublished.Add(templateIds[i], firstPublishedEvent.StartDate);
                    }
                }

                return templateLastPublished;


            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Failed to get Accountability Events", ex);
                return null;
            }

        }

        #endregion

        #region eventAlert Methods

        /// <summary>
        /// To create Accountability Event Alert.
        /// </summary>
        /// <param name="actEventAlert">AccountabilityEventAlert obj.</param>
        /// <returns>Event alert Id.</returns>
        public int CreateEventAlert(AccountabilityEventAlertEntity actEventAlert)
        {
            try
            {
                using (var context = new AtHocDbContext())
                {
                    var eventAlertToCreate = context.AccountabilityEventAlertEntities.Add(actEventAlert);
                    context.SaveChanges();
                    return eventAlertToCreate.Id;
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Error in Create Accountability Event Alert", ex);
                return -1;
            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="eventId"></param>
        /// <returns></returns>
        public int GetLastEventAlertId(int eventId)
        {
            try
            {
                using (var context = new AtHocDbContext())
                {
                    var lastAlert = context.AccountabilityEventAlertEntities.FirstOrDefault(e => e.EventId == eventId);
                    if (lastAlert != null)
                    {
                        var lastAlertId = lastAlert.AlertId;
                        return lastAlertId;
                    }
                    return 0;
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Error in Get Last Accountability Event AlertId", ex);
                return -1;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="eventIds"></param>
        /// <returns></returns>
        public List<int> GetEventsAlertIds(IEnumerable<int> eventIds)
        {
            try
            {
                using (var context = new AtHocDbContext())
                {
                    var alertIds = context.AccountabilityEventAlertEntities.Where(a => eventIds.Contains(a.EventId)).Select(t => t.AlertId);

                    return alertIds.ToList();
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Error in Get Accountability Events AlertIds", ex);
                return null;
            }
        }


        /// <summary>
        /// Get Alert Type e.g. (Start, Reminder, Close) for Event Alert. Used in UAP Agent
        /// </summary>
        /// <param name="alertId">Alert Id</param>
        /// <returns></returns>
        public AccountabilityAlertMapEntity GetAlertTypeByAlertId(int alertId)
        {

            var context = new AtHocDbContext();
            object[] parameters = { alertId };
            var sql = @" SELECT AMT.ALERT_INIT_TYPE as AlertInitType ,AMT.ALERT_TYPE as AlertType FROM ACCT_EVENT_ALERT_MAP_TAB AMT WITH (NOLOCK) INNER JOIN ACCT_EVENT_ALERT_TAB AT WITH (NOLOCK) ON AMT.ID = AT.EVENT_ALERT_MAP_ID WHERE ALERT_ID = {0}";
            var alertTypeQuery = context.Database
                .SqlQuery<AccountabilityAlertMapEntity>(sql, parameters).FirstOrDefault();
            if (alertTypeQuery != null)
            {
                return alertTypeQuery;
            }

            EventLogger.WriteError(string.Format("Unable to get AlertType for AlertId = {0}", alertId));
            return null;
        }
        public int GetEventProviderId(int providerId, int eventId)
        {

            var context = new AtHocDbContext();
            object[] parameters = { providerId, eventId };
            //var sql = @" SELECT isNull(PT.PROVIDER_ID,0) AS PROVIDER_ID FROM PRV_PROVIDER_TAB PT (NOLOCK) INNER JOIN ACCT_EVENT_TAB AT (NOLOCK) ON AT.PROVIDER_ID = PT.PROVIDER_ID WHERE AT.ACCT_EVENT_ID  = {0}  AND PT.IS_ENT='N'";
            //            var sql = @" SELECT CASE WHEN ISNULL(ENT_PROVIDER_ID,0)>0  AND AT.PROVIDER_ID={0} THEN 0 WHEN ISNULL(ENT_PROVIDER_ID,0)>0  AND AT.PROVIDER_ID<>{0}  THEN
            //                         AT.PROVIDER_ID WHEN ISNULL(ENT_PROVIDER_ID,0)=0  AND AT.PROVIDER_ID={0}  THEN 0 END FROM PRV_PROVIDER_TAB pt INNER JOIN ACCT_EVENT_TAB AT (NOLOCK) ON AT.PROVIDER_ID = PT.PROVIDER_ID
            //                         WHERE AT.ACCT_EVENT_ID  = {1}";

            var sql = @" SELECT CASE WHEN ISNULL(ENT_PROVIDER_ID,0)>0  AND AT.PROVIDER_ID={0} THEN 0 WHEN ISNULL(ENT_PROVIDER_ID,0)>0  AND AT.PROVIDER_ID<>{0} 
                         AND(select count(*) from PRV_GET_CHILD_PROVIDER_LIST({0}) CHPRVLST where AT.PROVIDER_ID=CHPRVLST.PROVIDER_ID)>0 THEN  AT.PROVIDER_ID
                         WHEN ISNULL(ENT_PROVIDER_ID,0)=0  AND AT.PROVIDER_ID={0} THEN 0 ELSE -1 END FROM PRV_PROVIDER_TAB pt WITH (NOLOCK) INNER JOIN ACCT_EVENT_TAB AT WITH (NOLOCK) ON AT.PROVIDER_ID = PT.PROVIDER_ID
                         WHERE AT.ACCT_EVENT_ID  = {1}";
            int alertTypeQuery = context.Database.SqlQuery<int>(sql, parameters).FirstOrDefault();
            if (alertTypeQuery != null)
            {
                return alertTypeQuery;
            }

            EventLogger.WriteError(string.Format("Unable to get Provider Id for Event Id = {0}", eventId));
            return 0;
        }



        #endregion

        #region Event UserAttribute methods
        /// <summary>
        /// To get templates.
        /// </summary>
        /// <returns>accountability templates.</returns>
        public IQueryable<AccountabilityEventUserStatusEntity> GetEventUserStatusAttributes()
        {
            try
            {
                //Obtain Data Source
                var context = new AtHocDbContext();

                //Build query
                var userStatusEntities = context.AccountabilityEventUserStatusEntities;
                return userStatusEntities;

            }
            catch (Exception ex)
            {
                EventLogger.WriteError("failed to get Accountability EventUserStatusEntities", ex);
                return null;
            }
        }

        public IQueryable<AccountabilityEventAlertMapEntity> GetEventAlertMapEntities()
        {
            try
            {
                //Obtain Data Source
                var context = new AtHocDbContext();

                //Build query
                var entities = context.AccountabilityEventAlertMapEntities;
                return entities;

            }
            catch (Exception ex)
            {
                EventLogger.WriteError("failed to get AccountabilityEventAlertMapEntities", ex);
                return null;
            }
        }


        public Int64 CreateEventUserStatusAttribute(AccountabilityEventUserStatusEntity eventUserStatusDetails)
        {
            try
            {
                using (var context = new AtHocDbContext())
                {
                    var eventUserStatusCreate = context.AccountabilityEventUserStatusEntities.Add(eventUserStatusDetails);
                    context.SaveChanges();
                    return eventUserStatusCreate.Id;
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Error in Create the Accountability Event User Status Entities", ex);
                return -1;
            }
        }

        /// <summary>
        /// To update the Event user status attribute.
        /// </summary>
        /// <param name="eventUserStatusDetails">Event user status attribute details.</param>
        /// <returns>true if updated successfully.</returns>
        public bool UpdateEventUserStatusAttribute(AccountabilityEventUserStatusEntity eventUserStatusDetails)
        {
            try
            {
                using (var context = new AtHocDbContext())
                {
                    var entityToUpdate =
                        context.AccountabilityEventUserStatusEntities.FirstOrDefault(a => a.Id == eventUserStatusDetails.Id);
                    if (entityToUpdate == null)
                    {
                        EventLogger.WriteError(string.Format("Failed to Update accountability event user status attribute, failed to find  id: {0}", eventUserStatusDetails.Id));
                        return false;
                    }

                    entityToUpdate.UserStatusOrderId = eventUserStatusDetails.UserStatusOrderId;
                    entityToUpdate.UserStatusAttributeValueId = eventUserStatusDetails.UserStatusAttributeValueId;

                    context.SaveChanges();

                    return true;
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("failed to Update Accountability event user status attribute", ex);
                return false;
            }
        }

        /// <summary>
        /// This method is used by BG jobs inorder to update event recipient table absed on user status updates
        /// </summary>
        /// <returns></returns>
        public bool UpdateEventStatus()
        {

            using (var context = new AtHocDbContext())
            {
                using (context.Database.Connection)
                {
                    context.Database.Connection.Open();
                    DbCommand cmd = context.Database.Connection.CreateCommand();
                    cmd.CommandText = "ACCT_EVENT_UPDATE_RECIPIENTS_STATUS";
                    cmd.CommandTimeout = 600; //set for 10 min. And let background job decide if it has to timeout before 10 min.
                    cmd.CommandType = CommandType.StoredProcedure;
                    
                    try
                    {
                        cmd.ExecuteNonQuery();
                        return true;
                    }
                    catch (Exception e)
                    {
                        EventLogger.WriteError("Failed to update the event status", e);
                    }
                    return false;
                }
            }

            return false;
        }
        #endregion

        #region Reporting and Analysis

        public IEnumerable<AccountabilityEventStatusTrackingReportModel> GetEventStatusTracking(int eventId, int sessionId, string groupBy, string subGroupBy, out int totalUserCount, out int totalAffectedUsers)
        {
            var resultSet = new List<AccountabilityEventStatusTrackingReportModel>();
            var paramAcctEventId = new SqlParameter("@acctEventId", SqlDbType.Int) { Value = eventId };
            var paramGroupBy = new SqlParameter("@groupBy", SqlDbType.NVarChar) { Value = groupBy };
            var paramSubGroupBy = new SqlParameter("@subGroupBy", SqlDbType.NVarChar) { Value = subGroupBy };
            var paramSessionId = new SqlParameter("@sessionId", SqlDbType.Int) { Value = sessionId };
            var totalUsers = new SqlParameter("@totalUsers", SqlDbType.Int) { Direction = ParameterDirection.Output };
            var totalAffectedUsersCount = new SqlParameter("@totalRecipientUsers", SqlDbType.Int) { Direction = ParameterDirection.Output };

            using (var context = new AtHocDbContext())
            {
                using (context.Database.Connection)
                {
                    context.Database.Connection.Open();
                    DbCommand cmd = context.Database.Connection.CreateCommand();
                    cmd.CommandText = "RPT_ACCT_STATUS_TRACKING";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(paramAcctEventId);
                    cmd.Parameters.Add(paramGroupBy);
                    cmd.Parameters.Add(paramSubGroupBy);
                    cmd.Parameters.Add(paramSessionId);
                    cmd.Parameters.Add(totalUsers);
                    cmd.Parameters.Add(totalAffectedUsersCount);

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var evt = new AccountabilityEventStatusTrackingReportModel();
                            evt.EventId = Convert.ToInt32(reader["ACCT_EVENT_ID"]);
                            evt.GroupBy = Convert.ToString(reader["GROUP_BY"]);
                            evt.SubGroupBy = Convert.ToString(reader["SUB_GROUP_BY"]);
                            evt.UsersCount = Convert.ToInt32(reader["USERS_COUNT"]);
                            resultSet.Add(evt);
                        }
                    }
                }

                totalUserCount = 0;
                totalAffectedUsers = 0;
                // for some reason there are old events that gets wierd value here. Maybe corrupted events ot something.
                try
                {
                    totalUserCount = (int)totalUsers.Value;
                    totalAffectedUsers = (int)totalAffectedUsersCount.Value;
                }
                catch (Exception e)
                {
                    EventLogger.WriteError("Failed to cast totalUser Count to int");
                }

                return resultSet;
            }
        }

        public IEnumerable<AccountabilityEventStatusTrackingByOrgReportModel> GetEventStatusTrackingByOrg(int eventId, int sessionId, bool isEnterprise, int providerId)
        {
            var resultSet = new List<AccountabilityEventStatusTrackingByOrgReportModel>();
            var vpsResultset = new List<AccountabilityEventStatusTrackingByOrgReportModel>();
            var paramAcctEventId = new SqlParameter("@acctEventId", SqlDbType.Int) { Value = eventId };
            var paramSessionId = new SqlParameter("@sessionId", SqlDbType.Int) { Value = sessionId };
            var totalUsers = new SqlParameter("@totalUsers", SqlDbType.Int) { Direction = ParameterDirection.Output };

            using (var context = new AtHocDbContext())
            {
                using (context.Database.Connection)
                {
                    context.Database.Connection.Open();
                    DbCommand cmd = context.Database.Connection.CreateCommand();

                    #region Code for getting Vps hierarchy

                    if (isEnterprise)
                    {
                        cmd.CommandText = "RPT_ACCT_VPS_STATUS_TRACKING";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(paramAcctEventId);
                        cmd.Parameters.Add(paramSessionId);

                        using (var reader = cmd.ExecuteReader())
                        {
                            int i = 2;

                            while (reader.Read())
                            {
                                var evt = new AccountabilityEventStatusTrackingByOrgReportModel();
                                evt.SeqId = Convert.ToInt32(reader["VPSID"]) == providerId ? 1 : i;
                                evt.OrgId = Convert.ToInt32(reader["VPSID"]);
                                evt.Org = Convert.ToString(reader["VPS NAME"]);
                                evt.OrgPath = string.Empty;
                                evt.ParentNodeId = 1;
                                evt.ParentNode = string.Empty;
                                evt.TreeDepth = 2;
                                evt.TreeDepthFromLeaf = 0;
                                evt.Status = reader["STATUS"] as int? ?? default(int);
                                evt.UsersCount = Convert.ToInt32(reader["USERS_COUNT"]);
                                resultSet.Add(evt);
                            }
                        }

                        if (resultSet.Count > 1 && resultSet.Any(x => x.OrgId != resultSet.First().OrgId))
                        {
                            return resultSet;
                        }

                        vpsResultset = new List<AccountabilityEventStatusTrackingByOrgReportModel>(resultSet);
                        cmd.Parameters.Clear();
                        resultSet.Clear();
                    }

                    #endregion

                    #region Code for getting org hierarchy

                    cmd.CommandText = "RPT_ACCT_ORG_STATUS_TRACKING";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(paramAcctEventId);
                    cmd.Parameters.Add(paramSessionId);
                    cmd.Parameters.Add(totalUsers);

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var evt = new AccountabilityEventStatusTrackingByOrgReportModel();
                            evt.SeqId = Convert.ToInt32(reader["SEQID"]);
                            evt.OrgId = Convert.ToInt32(reader["ID"]);
                            evt.Org = Convert.ToString(reader["ORG"]);
                            evt.OrgPath = Convert.ToString(reader["ORG_PATH"]);

                            evt.ParentNodeId = reader["PARENT_NODE_ID"] as int? ?? default(int);
                            evt.ParentNode = Convert.ToString(reader["PARENT_NODE"]);
                            evt.TreeDepth = Convert.ToInt32(reader["DEPTH"]);
                            evt.TreeDepthFromLeaf = Convert.ToInt32(reader["DEPTH_FROM_LEAF"]);
                            evt.Status = reader["STATUS"] as int? ?? default(int);
                            evt.UsersCount = Convert.ToInt32(reader["USERS_COUNT"]);
                            resultSet.Add(evt);
                        }
                    }

                    #endregion
                }

                if (resultSet.Any(r => r.UsersCount > 0))
                {
                    return resultSet;
                }

                EventLogger.WriteError(
                    string.Format("Error in SP {0}. Parameters: EventId: {1}, SessionId: {2}, providerId: {3}", "RPT_ACCT_ORG_STATUS_TRACKING", eventId, sessionId, providerId));
                return vpsResultset;
            }
        }



        public IEnumerable<AccountabilityEventSummaryResponseTracking> GetEventSummaryResponseTracking(int[] eventIds)
        {
            using (var ctx = new AtHocDbContext())
            {
                return GetEventResponseTracking(eventIds, ctx);
            }
        }

        private IEnumerable<AccountabilityEventSummaryResponseTracking> GetEventResponseTracking(int[] eventIds, DbContext ctx)
        {
            if (eventIds.Length == 0)
            {
                throw new ArgumentNullException("eventIds");
            }
            var ids = string.Join(",", eventIds);

            string sql = string.Format(@" SELECT ACCT_EVENT_ID as EventId,USER_ACCT_STATUS_ID as StatusId,RESPONSE_TEXT as ResponseText
                    ,RESPONSE_COUNT as ResponseCount,UPDATED_ON as UpdatedOn 
                    FROM dbo.ACCT_EVENT_SUMMARY_RESPONSE_TRACKING_TAB with (nolock) WHERE ACCT_EVENT_ID IN ({0})", ids);
            return ctx.Database
                   .SqlQuery<AccountabilityEventSummaryResponseTracking>(sql).ToList();
        }

        public IEnumerable<AccountabilityEventSummaryByMessageSent> GetEventOvertimeMessageSentEntity(int eventId)
        {
            if (eventId == 0)
            {
                throw new ArgumentNullException("eventId");
            }
            var context = new AtHocDbContext();
            object[] parameters = { eventId };
            var sql = @" SELECT A.ALERT_ID as AlertId,AEM.ALERT_INIT_TYPE as AlertInitType, A.PUBLISHED_ON as PublishedTime From ALT_ALERT_TAB A with (nolock) 
                INNER JOIN ACCT_EVENT_ALERT_TAB AE with (nolock) ON AE.ALERT_ID = A.ALERT_ID
                INNER JOIN ACCT_EVENT_ALERT_MAP_TAB AEM with (nolock) ON AEM.ID = AE.EVENT_ALERT_MAP_ID
                WHERE AE.ACCT_EVENT_ID = {0}  ";
            var statusQuery = context.Database
                   .SqlQuery<AccountabilityEventSummaryByMessageSent>(sql, parameters).AsQueryable();
            return statusQuery;
        }

        public IList<AccountabilityEventAlert> GetEventAlertDetails(int[] eventIds)
        {

            if (eventIds.Length == 0)
            {
                throw new ArgumentNullException("eventIds");
            }
            var csveventId = string.Join(",", eventIds);
            const string rawsqlQuery = @"SELECT A.ACCT_EVENT_ID AS EVENTID, EAM.ALERT_INIT_TYPE AS ALERTINITTYPE
                , A.ALERT_ID AS ALERTID, B.CONTENT_TITLE AS ALERTTITLE
                , B.CONTENT_BODY AS ALERTBODY, EAM.ALERT_TYPE AS ALERTTYPE,C.STATUS AS ALERTSTATUS
                , C.PUBLISHED_ON AS PUBLISHEDON, C.START_DATE AS STARTDATE
                , ISNULL(E.TGT, 0) AS TOTALUSER,ISNULL(E.NOT_SENT,0) AS ERRORCOUNT 
                FROM ACCT_EVENT_TAB EVT (NOLOCK)
                INNER JOIN  ACCT_EVENT_ALERT_MAP_TAB EAM (NOLOCK) ON EVT.ACCT_EVENT_ID=EAM.ACCT_EVENT_ID
                INNER JOIN  ACCT_EVENT_ALERT_TAB A (NOLOCK) ON A.EVENT_ALERT_MAP_ID=EAM.ID
                INNER JOIN ALT_BASE_TAB B (NOLOCK) ON A.ALERT_ID=B.ALERT_ID
                INNER JOIN ALT_ALERT_TAB C (NOLOCK) ON A.ALERT_ID=C.ALERT_ID 
                LEFT JOIN NGOLADATA.DBO.OLP_ALERT_SUMMARY_TRACKING_TAB E (NOLOCK) ON A.ALERT_ID=E.ALERT_ID AND E.BY_DIM='USER'
                WHERE A.ACCT_EVENT_ID IN ({0})";
            var finalsqlQuery = string.Format(rawsqlQuery, csveventId);
            var context = new AtHocDbContext();
            object[] parameters = { };

            var statusQuery = context.Database
                   .SqlQuery<AccountabilityEventAlert>(finalsqlQuery, parameters).ToList();
            return statusQuery;
        }
        

        /// <summary>
        /// Get accountability search results.
        /// </summary>
        /// <param name="spec">Search specs.</param>
        /// <returns>Search results.</returns>
        public IPaged<AccountabilityEventSearchResult> GetAccountabilitySearchResult(AccountabilityEventSearchSpec spec)
        {
            var resultSet = new List<AccountabilityEventSearchResult>();

            string eventIds = "";
            if (spec.EventIds != null)
            {
                eventIds = spec.EventIds.Join(",");
            }
            var paramAcctEventIds = new SqlParameter("@acctEventIds", SqlDbType.NVarChar) { Value = eventIds };

            string searchStrings = "";
            if (spec.SearchStrings != null)
            {
                searchStrings = spec.SearchStrings.Join(",");
            }
            var paramNameString = new SqlParameter("@nameString", SqlDbType.NVarChar) { Value = searchStrings };

            string severities = "";
            if (spec.Severity != null)
            {
                severities = spec.Severity.Join(",");
            }
            var paramSeverity = new SqlParameter("@severity", SqlDbType.NVarChar) { Value = severities };

            string status = "";
            if (spec.Status != null)
            {
                status = spec.Status.Join(",");
            }
            var paramStatus = new SqlParameter("@status", SqlDbType.NVarChar) { Value = status };

            string operatorId = "";
            if (spec.OperatorId > 0)
            {
                operatorId = spec.OperatorId.ToString();
            }
            var paramOperatorId = new SqlParameter("@operatorId", SqlDbType.NVarChar) { Value = operatorId };

            string attributeIds = "";
            if (spec.AttributeId != null)
            {
                attributeIds = spec.AttributeId.Join(",");
            }
            var paramAttributeId = new SqlParameter("@attributeId", SqlDbType.NVarChar) { Value = attributeIds };
           
            var paramVpsIds = new SqlParameter("@vpsIds", SqlDbType.NVarChar) { Value = spec.VpsIds};

            var paramIncludeSubVps = new SqlParameter("@includeSubVps", SqlDbType.Bit) { Value = spec.IncludeSubVps };
            var paramStartDate = new SqlParameter("@startDate", SqlDbType.NVarChar) { Value = spec.StartDate };
            var paramEndDate = new SqlParameter("@endDate", SqlDbType.NVarChar) { Value = spec.EndDate };
            var paramSortColumn = new SqlParameter("@sortColumn", SqlDbType.NVarChar) { Value = spec.OrderBy };
            var paramSortOrder = new SqlParameter("@sortOrder", SqlDbType.Bit) { Value = spec.OrderAsc ? 0 : 1 };
            var paramPage = new SqlParameter("@page", SqlDbType.Int) { Value = spec.Page };
            var paramRecordsPerPage = new SqlParameter("@recordsPerPage", SqlDbType.Int) { Value = spec.PageSize };
            var paramDebugFlag = new SqlParameter("@debugFlag", SqlDbType.Int) { Value = spec.DebugFlag };

            using (var context = new AtHocDbContext())
            {
                using (context.Database.Connection)
                {
                    context.Database.Connection.Open();
                    DbCommand cmd = context.Database.Connection.CreateCommand();
                    cmd.CommandText = "ACCT_EVENT_SEARCH_EVENTS_INFO";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(paramAcctEventIds);
                    cmd.Parameters.Add(paramNameString);
                    cmd.Parameters.Add(paramSeverity);
                    cmd.Parameters.Add(paramStatus);
                    cmd.Parameters.Add(paramOperatorId);
                    cmd.Parameters.Add(paramAttributeId);
                    cmd.Parameters.Add(paramVpsIds);
                    cmd.Parameters.Add(paramIncludeSubVps);
                    cmd.Parameters.Add(paramStartDate);
                    cmd.Parameters.Add(paramEndDate);
                    cmd.Parameters.Add(paramSortColumn);
                    cmd.Parameters.Add(paramSortOrder);
                    cmd.Parameters.Add(paramPage);

                    if (spec.PageSize != 0)
                    {
                        cmd.Parameters.Add(paramRecordsPerPage);
                    }

                    cmd.Parameters.Add(paramDebugFlag);
                    var totalCount = 0;
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var evt = new AccountabilityEventSearchResult();
                            var eventId = Convert.ToInt32(reader["EventId"]);
                            evt.EventId = eventId;
                            evt.EventName = Convert.ToString(reader["EventName"]);
                            evt.EventDescription = Convert.ToString(reader["EventDescription"]);
                            evt.AlertBaseId = Convert.ToInt32(reader["AlertBaseId"]);
                            evt.StatusAttributeId = Convert.ToInt32(reader["StatusAttributeId"]);
                            evt.StatusAttributeName = Convert.ToString(reader["StatusAttributeName"]);
                            evt.CreatedBy = Convert.ToInt32(reader["CreatedById"]);
                            evt.CreatedByName = Convert.ToString(reader["CreatedBy"]);
                            evt.Status = Convert.ToString(reader["STATUS"]);
                            evt.UpdatedBy = Convert.ToInt32(reader["UpdatedById"]);
                            evt.UpdatedByName = Convert.ToString(reader["UpdateBy"]);
                            evt.CreatedOn = Convert.ToDateTime(reader["CreatedOn"]);
                            evt.UpdatedOn = Convert.ToDateTime(reader["UpdatedOn"]);
                            evt.Priority = Convert.ToInt32(reader["PRIORITY"]);
                            evt.ProviderId = Convert.ToInt32(reader["ProviderId"]);
                            evt.ProviderName = Convert.ToString(reader["ProviderName"]);
                            evt.StartedBy = Convert.ToInt32(reader["StartedBy"]);
                            evt.StartedByName = Convert.ToString(reader["PublishedBy"]);
                            evt.StartedOn = Convert.ToDateTime(reader["StartedOn"]);
                            evt.EndDate = Convert.ToDateTime(reader["EndDate"]);
                            evt.Affected = reader["Affected"] == DBNull.Value ? 0 : Convert.ToInt32(reader["Affected"]);
                            evt.UsersResponded = reader["UsersResponded"] == DBNull.Value ? 0 : Convert.ToInt32(reader["UsersResponded"]);
                            evt.UsersNotResponded = reader["UsersNotResponded"] == DBNull.Value ? 0 : Convert.ToInt32(reader["UsersNotResponded"]); ;
                            totalCount = Convert.ToInt32(reader["TotalCount"]);

                            resultSet.Add(evt);
                        }
                    }

                    //IWS-26417 adding event responses to the live events on homepage...
                    if (resultSet.Any())
                    {
                        AttachTrackingDetails(resultSet, context);
                    }
                    
                    var pagedResult = new Paged<AccountabilityEventSearchResult>();
                    pagedResult.SetList(resultSet);
                    pagedResult.SetTotalCount(totalCount);
                    if (spec.Page != null) pagedResult.SetCurrentPageNumber(spec.Page.Value);
                    pagedResult.SetPageSize(spec.PageSize);
                    return pagedResult;
                }
            }
        }

        /// <summary>
        /// Attach the event responses to a list of events
        /// </summary>
        /// <param name="results"></param>
        /// <param name="ctx"></param>
        private void AttachTrackingDetails(IEnumerable<AccountabilityEventSearchResult> results, DbContext ctx)
        {
            var ids = results.Select(r => r.EventId).ToArray();
            var responses = GetEventResponseTracking(ids, ctx);

            foreach (var r in results)
            {
                r.Responses = responses.Where(res => res.EventId == r.EventId);
            }
        }
        #endregion

        #region Background Job

        public void UpdateAlertSummary(int eventId)
        {
            const string updatesummary = "ACCT_EVENT_UPDATE_TRACKING_SUMMARY";
            try
            {
                using (var database = new NgadDatabase())
                {
                    database.AddParameter("@AcctEventId", eventId);
                    database.CommandType = CommandType.StoredProcedure;
                    database.ExecuteNonQuery(updatesummary);
                }
            }
            catch (Exception ex)
            {
                string message =
                    string.Format(
                        "ACCT_EVENT_ID:{0} - Exception occur in Get Update Accountability Event summary criteria to process batch",
                        eventId);
                EventLogger.WriteError(message, ex);
            }
        }
        public bool UpdateEventPickupSchedule(
          List<AccountabilityEventPickupScheduleEntity> acctEventPickupScheduleEntity)
        {
            if (acctEventPickupScheduleEntity == null || acctEventPickupScheduleEntity.Count == 0)
            {
                throw new ArgumentNullException("acctEventPickupScheduleEntity");
            }

            int[] eventIds = acctEventPickupScheduleEntity.Select(e => e.EventId).ToArray();

            try
            {
                using (var context = new AtHocDbContext())
                {
                    var entitiesToUpdate =
                        context.AccountabilityEventPickupScheduleEntities.Where(e => eventIds.Contains(e.EventId));

                    foreach (var entity in entitiesToUpdate)
                    {
                        entity.NextRunTime = GetNextRuntime(acctEventPickupScheduleEntity, entity);
                    }
                    context.SaveChanges();
                    return true;
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("failed to Update Accountability Event pickup time", ex);
                return false;
            }
        }


        public bool UpdateEventPickupSchedule(int eventId, DateTime nextPickupTime, AccountabilityEventJobPickupType jobpickupType)
        {
            var jobTypeDescription = jobpickupType.GetDescription();
            try
            {
                using (var context = new AtHocDbContext())
                {
                    var entitiesToUpdate = context.AccountabilityEventPickupScheduleEntities.FirstOrDefault(e => e.EventId == eventId && e.PickupActionType == jobTypeDescription);
                    if (entitiesToUpdate != null)
                    {
                        entitiesToUpdate.NextRunTime = nextPickupTime;
                    }
                    context.SaveChanges();
                    return true;
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("failed to Set Accountability Event pickup time", ex);
                return false;
            }
        }

        public void UpdateEventPickupScheduleJobId(int eventId, int jobId, string jobType)
        {
            string updatejobId = string.Format("UPDATE [dbo].[ACCT_EVENT_PICKUP_SCHEDULE_TAB] SET JOB_ID = {0} WHERE ACCT_EVENT_ID ={1} AND PICKUP_ACTION='{2}' ", jobId, eventId, jobType);
            try
            {
                using (var database = new NgadDatabase())
                {
                    database.CommandType = CommandType.Text;
                    database.ExecuteNonQuery(updatejobId);
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Unable to update Event Pickup Schedule Job Id", ex);
            }
        }
        private static DateTime GetNextRuntime(IEnumerable<AccountabilityEventPickupScheduleEntity> lookupFrom,
            AccountabilityEventPickupScheduleEntity lookupValue)
        {
            var eventId = lookupValue.EventId;
            var jobType = lookupValue.PickupActionType;
            var currentTime = lookupValue.NextRunTime;

            var entity = lookupFrom.FirstOrDefault(e => e.EventId == eventId && e.PickupActionType == jobType);
            if (entity != null)
            {
                currentTime = entity.NextRunTime;
            }
            return currentTime;
        }
        public int[] GetLiveEventsForPickupType(AccountabilityEventJobPickupType jobpickupType)
        {
            string liveStatus = AccountabilityEventStatus.Live.ToString();
            var pickupdescription = jobpickupType.GetDescription();

            object[] parameters = { liveStatus, pickupdescription };
            //Below query will return the live event id for given job type.It will also make sure the job is not running for given job type and eventid
            var sql = "SELECT E.ACCT_EVENT_ID FROM ACCT_EVENT_TAB (NOLOCK) E WHERE EXISTS(" +
                      "SELECT 1 FROM [dbo].[ACCT_EVENT_PICKUP_SCHEDULE_TAB] (NOLOCK) EP " +
                        "WHERE E.ACCT_EVENT_ID = EP.ACCT_EVENT_ID AND EP.PICKUP_ACTION ={1} AND EP.NEXT_RUN_TIME <= GETDATE()" +
                      " AND (EP.JOB_ID IS NULL OR NOT EXISTS (SELECT 1 FROM SCD_EVENT_TAB (NOLOCK) S WHERE S.JOB_ID = EP.JOB_ID )) )" +
                      " AND E.STATUS ={0} ";

            using (var context = new AtHocDbContext())
            {
                var statusQuery = context.Database
              .SqlQuery<int>(sql, parameters).AsQueryable();
                return statusQuery.ToArray();
            }
        }
        public void SetAlertEndTime(int alertId, int operatorId, DateTime endTime)
        {

            try
            {
                using (var ngadDb = new NgadDatabase())
                {
                    ngadDb.AddParameter(new SqlParameter("@alertId", alertId));
                    ngadDb.AddParameter(new SqlParameter("@startDate", DBNull.Value));
                    ngadDb.AddParameter(new SqlParameter("@endDate", endTime));
                    ngadDb.AddParameter(new SqlParameter("@operatorId", operatorId));
                    ngadDb.CommandType = CommandType.StoredProcedure;
                    ngadDb.ExecuteNonQuery("dbo.ALT_SET_ALERT_DATE");
                }

            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Error while updating user status.", ex);

            }
        }


        #endregion

        public IDictionary<int, List<int>> GetUniqueStatusAttributesPerVps(List<int> providerIds)
        {
            if (providerIds.Count == 0)
            {
                throw new ArgumentNullException("providerIds");
            }
            var csvEventIds = string.Join(",", providerIds);

            const string rawsqlQuery = @"SELECT distinct AE.PROVIDER_ID as ProviderId,A.RESPONSE_BASED_ATTRIBUTE_ID as ResponseAttributeId From ALT_BASE_TAB A with (nolock) 
                INNER JOIN ACCT_EVENT_TAB AE with (nolock) ON AE.ACCT_BASE_ID = A.ALERT_ID 
                WHERE AE.PROVIDER_ID in ({0}) AND AE.STATUS != 'Deleted'";

            var finalsqlQuery = string.Format(rawsqlQuery, csvEventIds);
            var context = new AtHocDbContext();
            object[] parameters = { };

            var statusQuery = context.Database
                   .SqlQuery<AccountabilityUserPerProvider>(finalsqlQuery, parameters);

            var statusAttributesPerVp = statusQuery
                                    .GroupBy(o => o.ProviderId, o => o.ResponseAttributeId)
                                    .ToDictionary(g => g.Key, g => g.ToList());

            return statusAttributesPerVp;
        }

        /// <summary>
        /// Change the event's end time
        /// </summary>
        /// <param name="eventId"></param>
        /// <param name="newDate">newDate should be in system time</param>
        public void ChangeEventEndDate(int eventId, DateTime newDate)
        {
            try
            {
                using (var ctx = new AtHocDbContext())
                {
                    var ev = ctx.AccountabilityEventEntities.SingleOrDefault(e => e.EventId == eventId);
                    if (ev == null)
                        throw new Exception("Event not found.");
                    ev.EndDate = newDate;//End Date will be stored in system time
                    ctx.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(ex);
                throw;
            }
        }
    }
}
