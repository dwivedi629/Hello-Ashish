﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.Publishing;

namespace AtHoc.IWS.Business.Domain.Accountability.Impl
{
    public static class AccountabilityExtensions
    {
        public static EventBasedCriteria ToEventBasedCriteria(this List<ISearchCriteria> targetingCriteria)
        {
            var ebtCriteria = new EventBasedCriteria();

            if (targetingCriteria == null || targetingCriteria.Where(t => t.NodeType.Equals(SearchNodeType.EbtQuery)).ToList().Count < 1)
                return null;

            var queryCriteria = targetingCriteria.FirstOrDefault(t => t.NodeType.Equals(SearchNodeType.EbtQuery));
            if (queryCriteria != null)
            {
                if (queryCriteria.SearchQueries != null)
                {
                    var eventQuery = (SearchQuery)queryCriteria.SearchQueries.FirstOrDefault();
                    var eventCriteriaOperator = (int)eventQuery.AccountabilityOperator;
                    ebtCriteria.Id = (int)eventQuery.QueryEntityID;
                    ebtCriteria.EventIds = new[] { (int)eventQuery.QueryEntityID };
                    ebtCriteria.EventCriteriaOperator = (EventCriteriaOperator)Enum.Parse(typeof(EventCriteriaOperator), eventCriteriaOperator.ToString());

                    if (eventQuery.SearchValueCollections != null && eventQuery.SearchValueCollections.Any())
                    {
                        var responseList = eventQuery.SearchValueCollections.Select(v => v.SearchValue);
                        ebtCriteria.Value = responseList;
                    }
                }
            }
            return ebtCriteria;
        }

        public static List<ISearchCriteria> ToSearchCriterias(this EventBasedCriteria eventBasedCriteria, bool blocked = false)
        {
            AccountabilityOperator accountabilityOperator = (AccountabilityOperator)((int)eventBasedCriteria.EventCriteriaOperator);
            var searchCriteriaList = new List<ISearchCriteria>();

            var newCriteria = new SearchCriteria
            {
                NodeType = SearchNodeType.EbtQuery,
                IsBlocked = blocked,
                SearchValue = string.Empty,
                SearchQueries = new List<SearchQuery>()
            };
            var eventQuery = new SearchQuery
            {
                QueryType = SearchQueryType.PAEvent,
                QueryEntityID = eventBasedCriteria.EventIds.ToArray()[0],
                AccountabilityOperator = accountabilityOperator,
                SearchValueCollections = new List<SearchValueCollection>()
            };

            if (accountabilityOperator == AccountabilityOperator.MULTIPLERESPONSE && eventBasedCriteria.Value != null)
            {
                var responseList = (IEnumerable<string>)eventBasedCriteria.Value;
                foreach (var response in responseList)
                {
                    eventQuery.SearchValueCollections.Add(new SearchValueCollection { SearchValue = response });
                }
            }
            else
            {
                eventQuery.SearchValueCollections.Add(new SearchValueCollection { SearchValue = string.Empty });
            }


            newCriteria.SearchQueries.Add(eventQuery);
            searchCriteriaList.Add(newCriteria);
            return searchCriteriaList;
        }

        public static ISearchCriteria ToSearchCriteria(this EventBasedCriteria eventBasedCriteria, bool blocked = false)
        {
            var accountabilityOperator = (AccountabilityOperator)((int)eventBasedCriteria.EventCriteriaOperator);
            //var searchCriteriaList = new List<ISearchCriteria>();

            var newCriteria = new SearchCriteria
            {
                NodeType = SearchNodeType.EbtQuery,
                IsBlocked = blocked,
                SearchValue = string.Empty,
                SearchQueries = new List<SearchQuery>()
            };
            var eventQuery = new SearchQuery
            {
                QueryType = SearchQueryType.PAEvent,
                QueryEntityID = eventBasedCriteria.EventIds.ToArray()[0],
                AccountabilityOperator = accountabilityOperator,
                SearchValueCollections = new List<SearchValueCollection>()
            };

            if (accountabilityOperator == AccountabilityOperator.MULTIPLERESPONSE && eventBasedCriteria.Value != null)
            {
                var responseList = (IEnumerable<string>)eventBasedCriteria.Value;
                foreach (var response in responseList)
                {
                    eventQuery.SearchValueCollections.Add(new SearchValueCollection { SearchValue = response });
                }
            }
            else
            {
                eventQuery.SearchValueCollections.Add(new SearchValueCollection { SearchValue = string.Empty });
            }

            newCriteria.SearchQueries.Add(eventQuery);

            return newCriteria;
        }
    }

}
