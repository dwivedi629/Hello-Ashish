﻿using System.Linq;
using AtHoc.IWS.Business.Domain.Accountability.Specs;
using AtHoc.IWS.Business.Domain.Users.Impl.Search;
using AtHoc.IWS.Business.Domain.Users.Search;
using System;

// ReSharper disable once CheckNamespace
namespace AtHoc.IWS.Business.Domain.Accountability
{
    public class EventBasedTargetingFacade : IEventBasedTargetingFacade
    {
        private readonly IUserFacade _userFacade;
        public EventBasedTargetingFacade(IUserFacade userFacade)
        {
            _userFacade = userFacade;

        }

        public ContextSearchResult GetEventBasedTargetingRecipient(EventBasedTargetingSpec eventBasedTargetingSpec)
        {
            if (eventBasedTargetingSpec == null)
            {
                throw new ArgumentNullException("eventBasedTargetingSpec", @"EventBasedTargetingSpec cannot be null");
            }

            if (eventBasedTargetingSpec.EventCriteriaOperator == EventCriteriaOperator.MULTIPLERESPONSE && eventBasedTargetingSpec.ResponseList == null)
            {
                throw new ArgumentException(@"eventBasedTargetingSpec.CommmaSeparatedResponseList", "For " + "eventBasedTargetingSpec.EventCriteriaOperator == EventCriteriaOperator.MULTIPLERESPONSE, the 'CommaSeparatedResponseList' param cannot be empty.");
            }

            var providerId = eventBasedTargetingSpec.ProviderId;
            var operatorId = eventBasedTargetingSpec.OperatorId;

            //Get event based criteria
            var eventBasedCriteria = new EventBasedCriteria(eventBasedTargetingSpec.AccountabilityEventId, eventBasedTargetingSpec.EventCriteriaOperator, eventBasedTargetingSpec.ResponseList);


            //Instantiate and prepare provider criteria
            var srchArgs = new UserSearchArgs(getCountsOnly: false, getUsers: true, getMassDevices: false)
            {
                ProviderId = providerId,
                ProviderCriteria = UserSearchHelper.GetProviderCriteria(providerId)

            };

            //Make sure to include operator criteria for operator user base.
            if (eventBasedTargetingSpec.IncludeOperatorCriteria && operatorId.HasValue)
            {
                srchArgs.OperatorCriteria = UserSearchHelper.GetOperatorUserBaseCriteria(operatorId.Value, providerId);
            }


            if (eventBasedTargetingSpec.UserAttributes != null && eventBasedTargetingSpec.UserAttributes.Any())
            {
                srchArgs.AttributeNames = eventBasedTargetingSpec.UserAttributes;
            }

            srchArgs.TargetCriteria = eventBasedCriteria;
            srchArgs.Options.GetUsers = true;

            var sUser = _userFacade.SearchUsersByContext(srchArgs);

            return sUser;
        }
    }




}
