﻿using System.Threading;
using AtHoc.Diagnostics;
using AtHoc.Infrastructure.Ioc;
using AtHoc.Infrastructure.Ioc.SimpleInjector;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Log.EventLog;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Organization.Impl;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Settings.Impl;
using System;
using System.Collections.Generic;
using AtHoc.IWS.Business.Ioc;

namespace AtHoc.IWS.Business.Domain.Accountability.Impl
{

    /// <summary>
    /// Class to support methods for Accountability Event Schedule Job.
    /// </summary>
    public class AccountabilityEventProcessor
    {
        static AccountabilityEventProcessor()
        {
			//All regular schedular job must initialize the service locator like below.
			//OrganizationFacade, AccountabilityEventProcessor, AutoDisableDeleteProcess
            //if (ServiceLocator.Current == null)
            //{
            //    string message = "Init servicelocator from AccountabilityEventProcessor";
            //    EventLogger.WriteInformation(new Exception(message));
            //    var serviceLoader = new AtHocServiceLoader();
            //    serviceLoader.LoadAll();
            //    if (ServiceLocator.Current != null)
            //    {
            //        ServiceLocator.Current.Register<IRuntimeContext, StandAloneRuntimeContext>(ServiceLifecycle.Singleton);
            //    }
            //}

            //RegularSchedularServiceInitializer.Init();
        }


        /// <summary>
        /// Process Accountability End Event task - This method is being called from Regular Scheduler job.
        /// Payload is stored in SCD_SCHEDULE_TAB
        /// </summary>
        /// <param name="enablelog">true: If detail log needs to be write for debugging</param>
        public void ProcessAccountabilityTask_EndEvent(bool enablelog = false)
        {
            var accountabilityFacade = ServiceLocator.Resolve<IAccountabilityFacade>();
            accountabilityFacade.ProcessAccountabilityJob(AccountabilityEventJobPickupType.End, enablelog);

        }

        /// <summary>
        /// Process Accountability Event Reminder alert task - This method is being called from Regular Scheduler job.
        /// Payload is stored in SCD_SCHEDULE_TAB
        /// </summary>
        /// <param name="enablelog">true: If detail log needs to be write for debugging</param>
        public void ProcessAccountabilityTask_ReminderEvent(bool enablelog = false)
        {
            var accountabilityFacade = ServiceLocator.Resolve<IAccountabilityFacade>();
            accountabilityFacade.ProcessAccountabilityJob(AccountabilityEventJobPickupType.Reminder, enablelog);
        }

        /// <summary>
        /// Process Accountability Event - Recipient recompuation task - This method is being called from Regular Scheduler job.
        /// Payload is stored in SCD_SCHEDULE_TAB
        /// </summary>
        /// <param name="enablelog">true: If detail log needs to be write for debugging</param>
        public void ProcessAccountabilityTask_RecomputeRecipient(bool enablelog = false)
        {
            var accountabilityFacade = ServiceLocator.Resolve<IAccountabilityFacade>();
            accountabilityFacade.ProcessAccountabilityJob(AccountabilityEventJobPickupType.Recompute, enablelog);
        }

        /// <summary>
        /// Process Accountability Event - Recipient recompuation task - This method is being called from Regular Scheduler job.
        /// Payload is stored in SCD_SCHEDULE_TAB
        /// </summary>
        /// <param name="enablelog">true: If detail log needs to be write for debugging</param>
        public void ProcessAccountabilityTask_UpdateStatusAttribute(bool enablelog = false)
        {
            var accountabilityFacade = ServiceLocator.Resolve<IAccountabilityFacade>();
            accountabilityFacade.ProcessAccountabilityJob(AccountabilityEventJobPickupType.StatusAttribute, enablelog);
        }

        public void ProcessAccountabilityTask_EventTrackingSummary(bool enablelog = false)
        {
            var accountabilityFacade = ServiceLocator.Resolve<IAccountabilityFacade>();
            accountabilityFacade.ProcessAccountabilityJob(AccountabilityEventJobPickupType.TrackingSummary, enablelog);
        }


        /// <summary>
        /// This Method will execute by Regular Scheduler to process accoutability event related task. This payload is being submitted by ProcessAccountabilityTask_* methods in AccountabilityEventProcessor class.
        /// </summary>
        /// <param name="jobType">1 - AccountabilityEventJobPickupType.Recompute, 2 - AccountabilityEventJobPickupType.Reminder, 3 - AccountabilityEventJobPickupType.End</param>
        /// <param name="acctEventId">Accountability Event Id</param>
        /// <param name="operatorId">Default 1 - athoc admin</param>
        public void ExecuteJob(int jobType, int acctEventId, int operatorId = 1)
        {

            AccountabilityEventJobPickupType jType;
            var result = Enum.TryParse(jobType.ToString(), out jType);
            if (result == false)
            {
                EventLogger.WriteError("Unable to parse enum of type AccountabilityEventJobPickupType - Method ExecuteJob.");
                return;
            }
            var accountabilityFacade = ServiceLocator.Resolve<IAccountabilityFacade>();
            switch (jType)
            {
                case AccountabilityEventJobPickupType.End:
                    accountabilityFacade.ProcessEventToEnd(acctEventId, operatorId);
                    break;
                case AccountabilityEventJobPickupType.Recompute:
                    accountabilityFacade.ProcessReceipientRecompute(acctEventId, operatorId);
                    break;
                case AccountabilityEventJobPickupType.Reminder:
                    accountabilityFacade.ProcessReminderAlert(acctEventId, operatorId);
                    break;
                case AccountabilityEventJobPickupType.Start:
                    accountabilityFacade.ProcessStartAlert(acctEventId, operatorId);
                    break;
                case AccountabilityEventJobPickupType.StatusAttribute:
                    accountabilityFacade.ProcessStatusUpdateAttributes();
                    break;
                case AccountabilityEventJobPickupType.TrackingSummary:
                    accountabilityFacade.ProcessEventTrackingSummary(acctEventId);
                    break;
            }
        }


        /// <summary>
        /// This method will get use to generate error while executing from Regular Schedular.
        /// This is for testing retry logic.
        /// </summary>
        public void ThrowError(double seconds = 0)
        {
            if (seconds > 0)
            {
                var milliseconds = TimeSpan.FromSeconds(seconds).Milliseconds;
                Thread.Sleep(milliseconds);
                EventLogger.WriteInformation(string.Format("Thread slept for {0} seconds", seconds));
            }
            var ex = new Exception("This is for testing purpose. Regular schedular - generate error");
            EventLogger.WriteError(ex);
            throw ex;
        }
    }

    /// <summary>
    /// Standalone instance of IRuntimeContext - Required to inject dependency
    /// </summary>
    public class AccountabilityRuntimeContext : IRuntimeContext
    {
        public AccountabilityRuntimeContext()
        {

            Provider = new Provider { Id = 1, BaseLocale = "en-US" };
            Operator = new OperatorUser
            {
                Id = 1,
                Username = "athocadmin",
                OperatorAccess = new List<OperatorAccess>
				{
					new OperatorAccess { ActionType = ActionType.Modify, ObjectId = (int) SystemObject.Organization },
					new OperatorAccess { ActionType = ActionType.View, ObjectId = (int) SystemObject.Organization}
				}
            };
        }

        public Provider Provider { get; private set; }

        public OperatorUser Operator { get; private set; }
        public User LoggedOnUser { get; private set; }

        public OperatorUser RefreshedOperatorContext() { return null; }

        public Provider RefreshedProviderContext() { return null; }

    }


}
