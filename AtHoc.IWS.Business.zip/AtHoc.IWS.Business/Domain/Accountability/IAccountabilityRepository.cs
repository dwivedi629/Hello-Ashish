﻿using System;
using System.Collections.Generic;
using System.Linq;
using AtHoc.Data;
using AtHoc.IWS.Business.Domain.Accountability.Specs;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Entities.Accountability;
using AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel;
using AtHoc.Publishing;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel;

namespace AtHoc.IWS.Business.Domain.Accountability
{
    public interface IAccountabilityRepository
    {

        #region template methods

        /// <summary>
        /// To get templates.
        /// </summary>
        /// <returns>templates.</returns>
        IQueryable<AccountabilityTemplateEntity> GetTemplates();

        /// <summary>
        /// To get template.
        /// </summary>
        /// <param name="templateId">template Id.</param>
        /// <returns>accountability template.</returns>
        AccountabilityTemplateEntity GetTemplate(int templateId);

        /// <summary>
        /// To create the template.
        /// </summary>
        /// <param name="templateDetails">template details.</param>
        /// <returns>template Id.</returns>
        int CreateTemplate(AccountabilityTemplateEntity templateDetails);
        /// <summary>
        /// To update the template.
        /// </summary>
        /// <param name="templateDetails">template details.</param>
        /// <returns>true if updated successfully.</returns>
        bool UpdateTemplate(AccountabilityTemplateEntity templateDetails);

        /// <summary>
        /// To delete the template.
        /// </summary>
        /// <param name="operatorId">operator Id.</param>        
        /// <param name="ids">template Ids.</param>
        /// <returns>true if deleted successfully.</returns>
        IEnumerable<AccountabilityTemplateEntity> DeleteTemplates(int operatorId, IEnumerable<int> ids);
        #endregion

        #region event methods

        /// <summary>
        /// To get events.
        /// </summary>
        /// <returns>events.</returns>
        IQueryable<AccountabilityEventEntity> GetEventsIncludeAll();

        /// <summary>
        /// Get IQuerable of AccountabilityEventEntity
        /// </summary>
        /// <param name="listOfEntitiesToInclude">Collection of relative enties which needs to include while query. (Lazy loading)</param>
        /// <returns></returns>
        IQueryable<AccountabilityEventEntity> GetEvents(IEnumerable<string> listOfEntitiesToInclude = null);
        /// <summary>
        /// To get accountability  event.
        /// </summary>
        /// <param name="eventId">event Id.</param>
        /// <param name="includeReminderAlerts">includeReminderAlerts.</param>
        /// <returns>Event Details.</returns>
        AccountabilityEventEntity GetEvent(int eventId, bool includeReminderAlerts);

        /// <summary>
        /// To get selected event provider id.
        /// </summary>
        /// <param name="eventId">eventId</param>
        /// <returns>ProviderId</returns>
        int GetEventProviderId(int providerId, int eventId);

        /// <summary>
        /// To create event.
        /// </summary>
        /// <param name="actEvent">evnet object.</param>
        /// <returns>event id.</returns>
        int CreateEvent(AccountabilityEventEntity actEvent);

        bool UpdateEvent(AccountabilityEventEntity eventEntity);

        void UpdateAlertSummary(int eventId);
        /// <summary>
        /// To update the event status.
        /// </summary>
        /// <param name="operatorId">operatorId.</param>
        /// <param name="ids">event ids.</param>
        /// <param name="actEventStatus">event status.</param>
        /// <returns>events.</returns>
        IEnumerable<AccountabilityEventEntity> UpdateEventStatus(int operatorId, IEnumerable<int> ids,
            AccountabilityEventStatus actEventStatus);

        /// <summary>
        /// To set the event pickup time.
        /// </summary>
        /// <param name="acctEventPickupScheduleEntity">Acct Event Pickup Schedule Obj.</param>
        /// <returns>true is update transaction is successful.</returns>
        bool AddEventPickupSchedule(List<AccountabilityEventPickupScheduleEntity> acctEventPickupScheduleEntity);

        int[] GetLiveEventsForPickupType(AccountabilityEventJobPickupType jobpickupType);

        bool UpdateEventPickupSchedule(List<AccountabilityEventPickupScheduleEntity> acctEventPickupScheduleEntity);

        bool UpdateEventPickupSchedule(int eventId, DateTime nextPickupTime, AccountabilityEventJobPickupType pickupType);

        void UpdateEventPickupScheduleJobId(int eventId, int jobId, string jobType);
        /// <summary>
        /// Get IQueryable of AccountabilityEventPickupScheduleEntity
        /// </summary>
        /// <param name="includeAccountabilityEvent">Default:True - Include AccountabilityEvent Entity</param>
        /// <returns>IQueryable of AccountabilityEventPickupScheduleEntity</returns>
        IQueryable<AccountabilityEventPickupScheduleEntity> GetEventPickupScheduleEntity(bool includeAccountabilityEvent = true);

        /// <summary>
        /// To set the event user status.
        /// </summary>
        /// <param name="eventId">eventId.</param>
        /// <param name="attributeId"></param>
        /// <param name="userStatusList">userStatusList.</param>
        void SetEventUserStatus(int eventId, int attributeId, Dictionary<int, int> userStatusList);

       
        //bool UpdateEventRecipients(AccountabilityEvent accountabilityEvent, ContextSearchResult userSearchResult);

        /// <summary>
        /// Add / exclude/include affected user
        /// </summary>
        /// <param name="eventId">Accountability Event Id</param>
        /// <param name="itemsToAdd"> List of users to add</param>

        /// <returns></returns>
        bool AddUpdateEventRecipients(int eventId, List<AccountabilityEventRecipientEntity> itemsToAdd);
        bool UpdateEventRecipients(AccountabilityEvent accountabilityEvent, List<UserSearchResultItem> users);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="eventId"></param>
        /// <param name="providerId"></param>
        /// <returns></returns>
        IQueryable<AccountabilityEventStatusAttribute> GetEventStatusAttributeList(int eventId, int providerId);

        /// <summary>
        /// To update the event users status.
        /// </summary>
        /// <param name="operatorId">operatorId.</param>
        /// <param name="ids">users ids.</param>
        /// <param name="attributeId">attribute Id</param>
        /// <param name="valueId">attribute Id</param>
        /// <returns></returns>
        bool UpdateUsersStatus(UserStatusUpdateSpec userStatusList);

        IDictionary<int, DateTime> GetEventBaseTemplateForEvents(Int32[] templateIds);

       #endregion

        IEnumerable<AccountabilityEventRecipientBase> GetEventRecipients(int eventId);

        #region eventalert methods
        /// <summary>
        /// 
        /// </summary>
        /// <param name="actEventAlert"></param>
        /// <returns></returns>

        int CreateEventAlert(AccountabilityEventAlertEntity actEventAlert);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="eventId"></param>
        /// <returns></returns>
        int GetLastEventAlertId(int eventId);


        IQueryable<AccountabilityEventAlertMapEntity> GetEventAlertMapEntities();

        IList<AccountabilityEventAlert> GetEventAlertDetails(int[] eventIds);

       // IQueryable<AccountabilityEventAlert> GetEventAlertDetails(int eventId, int sessionId);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="eventIds"></param>
        /// <returns></returns>
        List<int> GetEventsAlertIds(IEnumerable<int> eventIds);

        #endregion

        #region Event UserAttribute methods
        IQueryable<AccountabilityEventUserStatusEntity> GetEventUserStatusAttributes();
        long CreateEventUserStatusAttribute(AccountabilityEventUserStatusEntity eventUserStatusDetails);
        bool UpdateEventUserStatusAttribute(AccountabilityEventUserStatusEntity eventUserStatusDetails);
        #endregion
        IEnumerable<AccountabilityEventStatusTrackingReportModel> GetEventStatusTracking(int eventId, int sessionId, string groupBy, string subGroupBy, out int totalUserCount, out int totalAffectedUsers);
        IEnumerable<AccountabilityEventStatusTrackingByOrgReportModel> GetEventStatusTrackingByOrg(int eventId, int sessionId, bool isEnterprise, int providerId);
        IEnumerable<AccountabilityEventSummaryResponseTracking> GetEventSummaryResponseTracking(int[] eventIds);
        IEnumerable<AccountabilityEventSummaryByMessageSent> GetEventOvertimeMessageSentEntity(int eventId);

        /// <summary>
        /// Get accountability search results.
        /// </summary>
        /// <param name="spec">Search specs.</param>
        /// <returns>Search results.</returns>
        IPaged<AccountabilityEventSearchResult> GetAccountabilitySearchResult(AccountabilityEventSearchSpec spec);

        void SetAlertEndTime(int alertId, int operatorId, DateTime endTime);

        IDictionary<int, List<int>> GetUniqueStatusAttributesPerVps(List<int> providerIds);

        void ChangeEventEndDate(int eventId, DateTime newDate);

        IDictionary<int, IEnumerable<AccountabilityEventStatusAttributePerEvent>> GetEventStatusAttributeListPerEvent(List<int> eventIds, int providerIds);

        bool UpdateEventStatus();
    }
}
