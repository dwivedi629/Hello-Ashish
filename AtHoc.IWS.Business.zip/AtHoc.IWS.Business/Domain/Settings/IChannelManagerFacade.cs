﻿using System.Collections.Generic;
using AtHoc.IWS.Business.Domain.Settings.Model;

namespace AtHoc.IWS.Business.Domain.Settings
{
    public interface IChannelManagerFacade
    {
        IEnumerable<ChannelSettingsList> GetChannelList(ChannelCriteria criteriaSpec, string locale);
        
        //Update Channel
        bool UpdateChannel(ChannelSettingsModel channelsettingsmodel, int OperatorId);

        //Delete Channel(s)
        bool DeleteChannel(ChannelCriteria criteriaSpec);

        bool DeleteFolder(int intChannelId, int ProviderId, int OperatorId);

        // get Channel Details
        ChannelSettingsModel GetChannelDetails(ChannelCriteria criteriaSpec, string locale);
          
        //check channel dependency with alert
        List<int> IsAlertAssociated(List<int> channelIds);

        //check  channel name is duplicate or not
        bool IsUniqueFolderName(int providerid, int ChannelId, string strName);

        //Update Channel status 
        bool UpdateChannelStatus(ChannelCriteria criteriaSpec);

        List<ChannelDependencyList> GetDependencyList(int ChannelId);
        bool IsSystemFolder(int ChannelId);
    }
}
