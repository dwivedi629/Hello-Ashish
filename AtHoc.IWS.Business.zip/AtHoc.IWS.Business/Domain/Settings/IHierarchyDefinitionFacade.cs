﻿using System.Collections.Generic;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.Settings
{
    public interface IHierarchyDefinitionFacade
    {
        PdlListModel GetHierarchy(HierarchySpec hierarchySpec);

        bool SaveNode(HierarchySpec hierarchySpec);

        bool AddNode(HierarchySpec hierarchySpec);

        bool DeleteNode(HierarchySpec hierarchySpec);

        bool IsValidHierarchyName(string HierarchyName, int HierarchyId, int providerId);
    }
}
