﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Settings
{
    public interface IAuditActionFacade
    {
        IEnumerable<AuditAction> GetAuditActionsByEntityId(string entityId);
    }
}
