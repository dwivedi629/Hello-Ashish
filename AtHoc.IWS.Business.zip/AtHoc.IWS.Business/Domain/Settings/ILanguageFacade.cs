﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Domain.Settings.Model;

namespace AtHoc.IWS.Business.Domain.Settings
{
   public  interface ILanguageFacade
    {
       IEnumerable<Language> GetLanguages();
       string GetProviderLocale(int providerId);
       IEnumerable<Language> GetOperatorEnabledLanguages();
       IEnumerable<Language> GetDeliveryEnabledLanguages(int providerId);
       IEnumerable<Language> GetDeliveryEnabledLanguagesByHierarchy(int providerId);
    }
}
