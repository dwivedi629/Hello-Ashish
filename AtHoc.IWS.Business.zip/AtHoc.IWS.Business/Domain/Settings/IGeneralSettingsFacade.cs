﻿using System.Collections.Generic;
using System.IO;
using AtHoc.MediaServices;

namespace AtHoc.IWS.Business.Domain.Settings
{
    public interface IGeneralSettingsFacade
    {
        GeneralSettings GetGeneralSettings(int providerId);
        bool UpdateGeneralSettings(GeneralSettings data, int operatorId);
        bool IsOrgCodeExists(int providerId, string orgCode);
        bool IsVirtualNameExists(GeneralSettings data);
    }
}
