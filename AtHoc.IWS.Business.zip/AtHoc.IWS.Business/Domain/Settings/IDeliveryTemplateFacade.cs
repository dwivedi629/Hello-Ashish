﻿
using System.Collections.Generic;
using System.IO;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.MediaServices;
namespace AtHoc.IWS.Business.Domain.Settings
{
    public interface IDeliveryTemplateFacade
    {
       IEnumerable<DeviceGroupSettings> GetDeviceGroups(string locale);
        IEnumerable<DeliveryTemplateModel> GetDeliveryTemplates(DeliveryTemplateCriteria criteriaSpec, string locale);
        TemplateDetailsModel GetTemplateDetails(int templateId, int providerId, string locale, bool isPublishing, string commonName ="");
        DeliveryTemplateModel GetDeliveryTemplateDetails(int templateId, string locale);
        bool SaveDeliveryTemplateData(TemplateDetailsModel templateData);
        bool SaveTemplateWithImageData(Stream mMediaData, MediaInfo mMedia, TemplateDetailsModel templateData);

        bool DeleteDeliveryTemplate(List<DeliveryTemplateModel> templateIds, int providerId, int operatorId);
        bool DuplicateDeliveryTemplate(List<DeliveryTemplateModel> templateIds, int providerId, int operatorId, string localeCode);
        bool IsValidCommonName(TemplateDetailsModel templateData);
        bool IsValidTemplateName(TemplateDetailsModel templateData, ref string strErrorMessage);
        string GetCustomImage(string sGuidValue, string sImageType, int providerId);
        bool CreateDeliveryTemplate(TemplateDetailsModel deliveryTemplateData, int providerId, int operatorId);
        TemplateDetailsModel GetTemplateStyleSheet(int deviceGroupId, int providerId, string localeCode);
        string GetTemplateDefinition(TemplateDetailsModel data, int providerId, string imageData = "");

        bool IsValidXslt(TemplateDetailsModel data, string xslt);
    }
}
