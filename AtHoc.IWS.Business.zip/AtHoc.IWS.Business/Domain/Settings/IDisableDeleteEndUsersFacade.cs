﻿using System.Collections.Generic;
using System.IO;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.MediaServices;
using AtHoc.SelfService;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.IWS.Business.Domain.Audit;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Business.Data.SearchSpec;

namespace AtHoc.IWS.Business.Domain.Settings
{
    public interface IDisableDeleteEndUsersFacade
    {

        /// <summary>
        /// getting the disable and delete users job information
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="isFromDisable"></param>
        /// <returns></returns>
        DisableDeleteEndUsersModel GetDisableExecutionJobInfo(AutoDisableDeleteSpec autoDisableDeleteSpec);

        /// <summary>
        /// getting the disable and delete users job information
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="isFromDisable"></param>
        /// <returns></returns>
        DisableDeleteEndUsersModel GetDeleteExecutionJobInfo(AutoDisableDeleteSpec autoDisableDeleteSpec);

        /// <summary>
        /// Getting the Audit data for the disable and delete 
        /// </summary>
        /// <param name="AuditID"></param>
        /// <returns></returns>
        DisableDeleteEndUsersModel GetAuditData(int AuditID);

        /// <summary>
        /// updating the audit log
        /// </summary>
        /// <param name="spec"></param>
        /// <param name="AuditID"></param>
        /// <returns></returns>
        bool UpdateAuditLog(AuditSpec spec, int AuditID);

        void UpdateOperatorAuditLog(ServiceAction serviceAction, AutoDisableDeleteSpec spec);

    }
}
