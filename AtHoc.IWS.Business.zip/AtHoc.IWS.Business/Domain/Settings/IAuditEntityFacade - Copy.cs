﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Domain.Settings.Model;

namespace AtHoc.IWS.Business.Domain.Settings
{
    public interface IAuditEntityFacade
    {
        IEnumerable<AuditEntity> GetAuditEntities();
    }
}
