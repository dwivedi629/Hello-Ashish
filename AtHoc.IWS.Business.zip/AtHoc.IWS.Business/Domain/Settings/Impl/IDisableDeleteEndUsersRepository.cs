﻿using System.Collections.Generic;
using System.IO;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.MediaServices;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Audit;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Business.Data.SearchSpec;
namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public interface IDisableDeleteEndUsersRepository
    {
        /// <summary>
        /// getting the disable and delete users job information
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="isFromDisable"></param>
        /// <returns></returns>
        DisableDeleteEndUsersModel GetDisableDeleteLastExecutionJobInfo(AutoDisableDeleteSpec autoDisableDeleteSpec);

        /// <summary>
        /// Getting the Audit data for the disable and delete 
        /// </summary>
        /// <param name="AuditID"></param>
        /// <returns></returns>
         DisableDeleteEndUsersModel GetAuditData(int AuditID);

        /// <summary>
         /// updating the audit log
        /// </summary>
        /// <param name="spec"></param>
        /// <param name="AuditID"></param>
        /// <returns></returns>
         bool UpdateAuditLog(AuditSpec spec, int AuditID);
    }
}
