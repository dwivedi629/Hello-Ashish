﻿using System.Collections.Generic;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.Infrastructure.Data;
using AtHoc.Publishing;
namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public interface IAudioFileRepository 
    {
        IEnumerable<AudioFileSettingsModel> GetAudioFileData(AudioSearchCriteria criteria);

        AudioFileSettingsModel GetAudioFileDataById(int audioFileId,int providerId);

        int SaveAudioFileData(AudioFileSettingsModel audioFileData, int operatorId);

        bool UpdateAudioFileData(AudioFileSettingsModel audioFileData, int operatorId);

        bool DeleteAudioFiles(int[] audioFileIds, int providerId, int userId);

        int GetNewAudioFileId();

        byte[] DownloadAudioFile(int audioId);

        bool UploadAudioFile(byte[] data, int audioId);

        bool IsAudioNameExists(AudioFileSettingsModel audio);

        bool IsAudioCommonNameExists(AudioFileSettingsModel audio);

        List<AudioDefaultSeverities> GetDefaultAudioSeverityData(int? providerId);
        IEnumerable<AudioFileModel> GetAudioList(AudioSearchCriteria spec);

    }
}
