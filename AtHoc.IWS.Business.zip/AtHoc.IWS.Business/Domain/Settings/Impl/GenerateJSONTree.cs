﻿using System;
using System.Collections.Generic;
using System.Linq;
using AtHoc.IWS.Business.Configurations;
namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public class GenerateJsonTree
    {
        int _mainNode;
        int _childquantity;
        int _myflag;
        int _tempcount;
        string _strTreeView = string.Empty;
        IEnumerable<PdlListModel> _data ;
        int _parentId=-1;
       
        public string GetGenerateJsonTree(int hierarchytype, IEnumerable<PdlListModel> data)
        {
            _data = data;
            _strTreeView = Treeview(0, "", 0, 0);
            return _strTreeView;
        }
        public string Treeview(int itemId, string mystr, int childPos, int flag)
        {
            var querylist = new List<PdlListModel>();

            if (flag == 0)
            {

                querylist = (from m in _data
                             where m.ParentListId == _parentId
                             select m).ToList();
                _mainNode = querylist.Count;
                if (_mainNode > 0)
                    mystr += "[";
                else
                    mystr += "[]";
            }
            if (flag == 1)
            {

                querylist = (from m in _data
                             where m.ParentListId == itemId
                             select m).ToList();
                _mainNode = querylist.Count;
                mystr += ",items:[";
            }

            int pos = 1;
            foreach (var item in querylist)
            {
                _myflag = 0;
                //Check this parent has child or not 
                var querylistParent = (from m in _data
                                   where m.ParentListId == item.ListId
                                   select m).ToList();
                _childquantity = querylistParent.Count;

                var imgUrlList = _childquantity > 0 ? Constants.Groupimg : Constants.Individualimg;
                mystr += "{ListId:\"" + item.ListId + "\",Name:\"" + item.Name + "\",CommonName:\"" + item.CommonName + "\",ParentListId:\"" + item.ParentListId + "\",HierarchyId:\"" + item.HierarchyId + "\",NewListId:\"\",NewParentListId:\"\",expanded:true,Lineage:\"" + item.Lineage + "\" ,imageUrl:\"" + imgUrlList + "\",Status:\"\"";
                //If Parent Has Child again call Treeview with new parameter
                if (_childquantity > 0)
                {
                    mystr = Treeview(item.ListId, mystr, pos, 1);

                }
                //No Child and No Last Node
                else if (_childquantity == 0 && pos < querylist.Count)
                {
                    mystr += "},";
                }
                //No Child and Last Node
                else if (_childquantity == 0 && pos == querylist.Count)
                {

                    int fcheck2 ;
                    int fcheck3;
                    var counter = 0;
                    var flagbreak = 0;
                    int currentparent;
                    currentparent = Convert.ToInt32(item.ParentListId);
                    int coun;
                    _tempcount = 0;
                    while (currentparent != _parentId)
                    {
                        //count parent of parent

                        fcheck2 = 0;
                        fcheck3 = 0;
                       var  parentquery = (from m in _data
                                       where m.ListId == currentparent
                                       select m).ToList();
                        var rep2 = (from h in parentquery select new { h.ParentListId }).First();

                        //put {[ up to end

                        //list of child
                       var childlistquery = (from m in _data
                                          where m.ParentListId == currentparent
                                          select m).ToList();


                        foreach (var item22 in childlistquery)
                        {


                            if (mystr.Contains(Convert.ToString(item22.ListId)))
                            {

                                if (item22.ParentListId == currentparent)
                                {
                                    fcheck3 += 1;
                                    if (fcheck3 == 1)
                                    {
                                        counter += 1;
                                    }
                                }

                            }
                            else
                            {

                                _myflag = 1;
                                if (item22.ParentListId == currentparent)
                                {
                                    fcheck2 += 1;
                                    if (fcheck2 == 1)
                                    {
                                        counter -= 1;
                                        flagbreak = 1;

                                    }
                                }

                            }
                        }

                        var result55 = (from h in parentquery select new { h.ListId }).First();
                        coun = Convert.ToInt32(result55.ListId);
                        _tempcount = Convert.ToInt32(coun);
                        currentparent = Convert.ToInt32(rep2.ParentListId);
                        if (flagbreak == 1)
                        {
                            break;
                        }

                    }

                    for (int i2 = 0; i2 < counter; i2++)
                    {
                        mystr += "}]";
                    }

                   var lastchild = (from m in _data
                                 where m.ParentListId == item.ParentListId
                                 select m).ToList();

                   var  lastparent = (from m in _data
                                  where m.ParentListId == _parentId
                                  select m).ToList();

                    if (lastchild.Count > 0)
                    {
                        var resultLastChild = (from h in lastchild select new { h.ListId }).Last();
                        var resultLastParent = (from h in lastparent select new { h.ListId }).Last();
                        int mycount = Convert.ToInt32(_tempcount);
                        if (item.ListId == resultLastChild.ListId && mycount == resultLastParent.ListId && _myflag == 0)
                        {
                            mystr += "}]";
                        }
                        else if (item.ListId == resultLastChild.ListId && mycount == resultLastParent.ListId && _myflag == 1)
                        {
                            mystr += "},";
                        }
                        else if (item.ListId == resultLastChild.ListId && mycount != resultLastParent.ListId)
                        {
                            mystr += "},";
                        }

                    }
                    //  finish }]
                    //  finish }]
                    else if (lastchild.Count == 0 && item.ParentListId == _parentId)
                    {
                        mystr += "}]";
                    }
                }
                pos++;
            }


            return mystr;
        }
    }
}
