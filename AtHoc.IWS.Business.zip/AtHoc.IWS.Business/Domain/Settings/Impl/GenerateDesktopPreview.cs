﻿using System;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading;
using System.Web;
using AtHoc.Global.Resources;

using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Settings.Model;
using System.Xml.Xsl;
using System.Xml;
using System.Xml.Linq;
using AtHoc.IWS.Business.Configurations;
using AtHoc.Systems;
using Constants = AtHoc.IWS.Business.Configurations.Constants;


namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public class GenerateDesktopPreview
    {


        /// To Resize HTML
        /// <summary>  </summary>        
        /// <param name="html">string</param>
        /// <param name="width">int</param>
        /// <param name="height">int</param>
        /// <param name="fullScreen">bool</param>
        /// <returns>string</returns>
        /// 
        /// 
        public string ResizeHtml(string html, int? width, int? height, string fullScreen)
        {
            html = html.Replace("</html>", "");
            return fullScreen.Equals("Y") ? string.Format(@"{0}<script type='text/javascript'>moveTo(0,0); resizeTo(screen.availWidth, screen.availHeight);</script></html>", html) : string.Format(@"{0}<script type='text/javascript'>resizeTo('{1}', '{2}');</script></html>",
                html, width, height + 54);
        }

        public string UpdateTemplateXsltData(TemplateDetailsModel deliveryTemplateData)
        {
            // Based upon latest templateUIDefinition, reconstruct the template XSLT.
            XmlNode oldStyleNode = null;

            string htmlStyleString = string.Empty;
            XmlAttribute attrNode = null;

            var xsltData = new XmlDocument();
            if (deliveryTemplateData.standardXslt != null)
                xsltData.LoadXml(deliveryTemplateData.standardXslt);

            var uiStyle = new XmlDocument();
            if ((deliveryTemplateData.xmlConfiguration != null) && (deliveryTemplateData.xmlConfiguration != ""))
                uiStyle.LoadXml(setDisplayProperties(deliveryTemplateData));

            if (((XmlNode)xsltData.SelectSingleNode("//style[@id='ATHOC']")) != null)
                oldStyleNode = ((XmlNode)xsltData.SelectSingleNode("//style[@id='ATHOC']"));
            if (uiStyle.ChildNodes[uiStyle.ChildNodes.Count - 1] != null)
            {
                foreach (XmlNode tempStyleNode in uiStyle.ChildNodes[uiStyle.ChildNodes.Count - 1].ChildNodes)
                    htmlStyleString = htmlStyleString + Constants.LineBreak + GetHtmlStyle(tempStyleNode);
            }
            //create new Style Element
            var newStyleNode = xsltData.CreateNode(XmlNodeType.Element, "style", "");
            newStyleNode.InnerText = htmlStyleString;
            attrNode = xsltData.CreateAttribute("type");
            attrNode.Value = "text/css";
            newStyleNode.Attributes.SetNamedItem(attrNode);
            attrNode = xsltData.CreateAttribute("id");
            attrNode.Value = "ATHOC";
            newStyleNode.Attributes.SetNamedItem(attrNode);
            if (oldStyleNode != null)
            {
                var parentNode = oldStyleNode.ParentNode;
                if (parentNode != null)
                    parentNode.ReplaceChild(newStyleNode, oldStyleNode);
            }

            var targetUrlNodes = xsltData.SelectNodes("//input[@class[. = 'atTargetUrl']]");
            if (targetUrlNodes != null)
            {
                foreach (XmlNode targetUrlNode in targetUrlNodes)
                {
                    if (targetUrlNode.Attributes != null)
                        foreach (XmlAttribute urlAttribute in targetUrlNode.Attributes)
                        {
                            if (urlAttribute.Name == "type")
                            {
                                var ntempStyleNode = uiStyle.SelectSingleNode("//atTargetUrl/displayMode");
                                if (ntempStyleNode != null)
                                    urlAttribute.InnerText = ntempStyleNode.InnerText;
                                else
                                    urlAttribute.InnerText = "text";
                            }
                            else if (urlAttribute.Name == "value")
                            {
                                var ntempStyleNode = uiStyle.SelectSingleNode("//atTargetUrl/displayLabel");
                                if (ntempStyleNode != null)
                                    urlAttribute.InnerText = ntempStyleNode.InnerText;
                                else
                                    urlAttribute.InnerText = "Click here to get additional information";
                            }
                        }
                }
            } // if statement

            AdjustLogoImageSource(xsltData, uiStyle, deliveryTemplateData);
            return xsltData.InnerXml;
        }


        public string AdvanceTemplateXsltData(TemplateDetailsModel deliveryTemplateData)
        {

            var xsltData = new XmlDocument();
            if (deliveryTemplateData.templateDefinition != null)
                xsltData.LoadXml(deliveryTemplateData.templateDefinition);

            var imageSource = string.Empty;

            if (string.IsNullOrEmpty(deliveryTemplateData.templateImageLogo))
                imageSource = "data:image/gif;base64," + GetDefaultImage();
            else
                imageSource = "data:image/gif;base64," + deliveryTemplateData.templateImageLogo;

            var imageParentNode = xsltData.SelectSingleNode("//td[@class='atImageTopLeft']");
            if (imageParentNode != null)
            {
                var imageXslNode = imageParentNode.SelectSingleNode("img").FirstChild;
                if (imageXslNode != null)
                    if (!string.IsNullOrEmpty(imageSource))
                        imageXslNode.InnerText = imageSource;
                    else
                    {
                        imageParentNode.InnerText = "";
                        imageParentNode.Attributes.RemoveNamedItem("style");
                    }
            }

            imageParentNode = xsltData.SelectSingleNode("//td[@class='atImageBottomLeft']");
            if (imageParentNode != null)
            {
                imageParentNode.InnerText = "";
                if (imageParentNode.Attributes != null) imageParentNode.Attributes.RemoveNamedItem("style");
            }
            imageParentNode = xsltData.SelectSingleNode("//td[@class='atImageBottomRight']");
            if (imageParentNode != null)
            {
                imageParentNode.InnerText = "";
                if (imageParentNode.Attributes != null) imageParentNode.Attributes.RemoveNamedItem("style");
            }

            switch (deliveryTemplateData.imageDisplay.ToLower())
            {
                case "none":
                    imageParentNode = xsltData.SelectSingleNode("//td[@class='atImageTopLeft']");
                    if (imageParentNode != null)
                    {
                        imageParentNode.InnerText = "";
                        if (imageParentNode.Attributes != null) imageParentNode.Attributes.RemoveNamedItem("style");
                    }
                    imageParentNode = xsltData.SelectSingleNode("//td[@class='atImageTopRight']");
                    if (imageParentNode != null)
                    {
                        imageParentNode.InnerText = "";
                        if (imageParentNode.Attributes != null) imageParentNode.Attributes.RemoveNamedItem("style");
                    }

                    break;
                case "topright":
                    imageParentNode = xsltData.SelectSingleNode("//td[@class='atImageTopLeft']");
                    if (imageParentNode != null)
                    {
                        imageParentNode.InnerText = "";
                        if (imageParentNode.Attributes != null) imageParentNode.Attributes.RemoveNamedItem("style");
                    }
                    break;

                case "topleft":

                    imageParentNode = xsltData.SelectSingleNode("//td[@class='atImageTopRight']");
                    if (imageParentNode != null)
                    {
                        imageParentNode.InnerText = "";
                        if (imageParentNode.Attributes != null) imageParentNode.Attributes.RemoveNamedItem("style");
                    }
                    break;
            }
        

            return xsltData.InnerXml;
        }
        private static void AdjustLogoImageSource(XmlDocument xsltData, XmlDocument uiStyle, TemplateDetailsModel deliveryTemplateData)
        {
            var imageSource = string.Empty;
            var imageParentNode = xsltData.SelectSingleNode("//td[@class='atImage" + deliveryTemplateData.imageDisplay + "']");
            var atImageNode = uiStyle.SelectSingleNode("//atImage");

            if (atImageNode != null)
            {
                if (string.IsNullOrEmpty(deliveryTemplateData.templateImageLogo))
                    imageSource = "data:image/gif;base64," + GetDefaultImage();
                else
                    imageSource = "data:image/gif;base64," + deliveryTemplateData.templateImageLogo;
            }

            if (imageParentNode != null)
            {
                var imageXslNode = imageParentNode.SelectSingleNode("img").FirstChild;
                if (imageXslNode != null)
                    if (!string.IsNullOrEmpty(imageSource))
                        imageXslNode.InnerText = imageSource;
                    else
                    {
                        imageParentNode.InnerText = "";
                        if (imageParentNode.Attributes != null) imageParentNode.Attributes.RemoveNamedItem("style");
                    }
            }

            imageParentNode = xsltData.SelectSingleNode("//td[@class='atImageBottomLeft']");
            if (imageParentNode != null)
            {
                imageParentNode.InnerText = "";
                if (imageParentNode.Attributes != null) imageParentNode.Attributes.RemoveNamedItem("style");
            }
            imageParentNode = xsltData.SelectSingleNode("//td[@class='atImageBottomRight']");
            if (imageParentNode != null)
            {
                imageParentNode.InnerText = "";
                if (imageParentNode.Attributes != null) imageParentNode.Attributes.RemoveNamedItem("style");
            }

            switch (deliveryTemplateData.imageDisplay.ToLower())
            {
                case "none":
                    imageParentNode = xsltData.SelectSingleNode("//td[@class='atImageTopLeft']");
                    if (imageParentNode != null)
                    {
                        imageParentNode.InnerText = "";
                        if (imageParentNode.Attributes != null) imageParentNode.Attributes.RemoveNamedItem("style");
                    }
                    imageParentNode = xsltData.SelectSingleNode("//td[@class='atImageTopRight']");
                    if (imageParentNode != null)
                    {
                        imageParentNode.InnerText = "";
                        if (imageParentNode.Attributes != null) imageParentNode.Attributes.RemoveNamedItem("style");
                    }
                    
                    break;
                case "topright":
                    imageParentNode = xsltData.SelectSingleNode("//td[@class='atImageTopLeft']");
                    if (imageParentNode != null)
                    {
                        imageParentNode.InnerText = "";
                        if (imageParentNode.Attributes != null) imageParentNode.Attributes.RemoveNamedItem("style");
                    }
                    break;

                case "topleft":

                    imageParentNode = xsltData.SelectSingleNode("//td[@class='atImageTopRight']");
                    if (imageParentNode != null)
                    {
                        imageParentNode.InnerText = "";
                        if (imageParentNode.Attributes != null) imageParentNode.Attributes.RemoveNamedItem("style");
                    }
                    break;
            }
        }

        private static string GetImageStyleNode(XmlNode tempStyleNode, string strPosition)
        {
            var retStr = string.Empty;
            if (tempStyleNode != null)
            {
                retStr = "." + tempStyleNode.Name + strPosition + "{" + Constants.LineBreak;
                var tempNode = tempStyleNode.SelectSingleNode("position");
                if (tempNode != null)
                {
                    if (tempNode.InnerText == strPosition)
                        retStr = retStr + "display:''" + Constants.LineBreak;
                    else
                        retStr = retStr + "display: none;" + Constants.LineBreak;
                }
                else
                    retStr = retStr + "display: none;" + Constants.LineBreak;
                retStr = retStr + "background-repeat: no-repeat;" + Constants.LineBreak;
                retStr = retStr + "}" + Constants.LineBreak;
            }
            return retStr;

        }
        private static string GetHtmlStyle(XmlNode tempStyleNode)
        {

            var paddingStr = string.Empty;
            var retStr = string.Empty;
            if (tempStyleNode == null)
                return retStr;
            if (tempStyleNode.Name == "atImage")
            {
                retStr = retStr + GetImageStyleNode(tempStyleNode, "TopLeft");
                retStr = retStr + GetImageStyleNode(tempStyleNode, "TopRight");
                retStr = retStr + GetImageStyleNode(tempStyleNode, "BottomLeft");
                retStr = retStr + GetImageStyleNode(tempStyleNode, "BottomRight");
                return retStr;
            }

            retStr = "." + tempStyleNode.Name + "{";
            foreach (XmlNode childNode in tempStyleNode.ChildNodes)
            {
                if (childNode.Name == "padding")
                {
                    var tempNode = childNode.SelectSingleNode("topLeft");
                    if (tempNode != null)
                        paddingStr = paddingStr + "0 ";
                    else
                        paddingStr = " ";
                    tempNode = childNode.SelectSingleNode("topRight");
                    if (tempNode != null)
                        paddingStr = paddingStr + "0 ";
                    else
                        paddingStr = " ";
                    tempNode = childNode.SelectSingleNode("bottomLeft");
                    if (tempNode != null)
                        paddingStr = paddingStr + "0 ";
                    else
                        paddingStr = " ";

                    tempNode = childNode.SelectSingleNode("bottomRight");
                    if (tempNode != null)
                        paddingStr = paddingStr + "0 ";
                    else
                        paddingStr = " ";
                    retStr = retStr + "\t" + childNode.Name + ": " + paddingStr + ";" + Constants.LineBreak;
                }
                else
                {

                    foreach (XmlNode ntempNode in childNode.ChildNodes)
                    {
                        if (ntempNode.NodeType == XmlNodeType.Element)
                            retStr = retStr + "\t" + childNode.Name + "-" + ntempNode.Name + ": " + ntempNode.InnerText + ((childNode.Name + "-" + ntempNode.Name).ToLower().Equals("font-size") ? "px" : "") + ";" + Constants.LineBreak;
                        else
                            retStr = retStr + "\t" + childNode.Name + ": " + childNode.InnerText + ";" + Constants.LineBreak;
                    }
                }
            }
            retStr = retStr + "}" + Constants.LineBreak;

            return retStr;
        }



        /// <summary>
        /// To parse Template Definition and assign attributes values to model
        /// </summary>
        /// <param name="tdata"></param>
        /// <returns>TemplateDetailsModel</returns>
        public TemplateDetailsModel ParseTemplateDefinition(TemplateDetailsModel tdata)
        {
            if (tdata.xmlConfiguration != "")
            {
                var xDocConfig = XDocument.Parse(tdata.xmlConfiguration);
                var xConfig = xDocConfig.Element("Configuration");
                if (xConfig == null)
                    return tdata;

                #region "atBody style settings"

                var xAtBody = xConfig.Element("atBody");
                if (xAtBody != null)
                    tdata.templateBackgroundColor = xAtBody.Element("background") != null ? xAtBody.Element("background").Element("color").Value : string.Empty;

                var xAtBorder = xConfig.Element("atBorder");
                if (xAtBorder != null && xAtBorder.Element("border") != null)
                {
                    tdata.templateBorderColor = xAtBorder.Element("border").Element("color").Value;
                    tdata.templateBorderSize = xAtBorder.Element("border").Element("width").Value.ToLower().Replace("pt", "");
                }
                var xAtContent = xConfig.Element("atContent");
                if (xAtContent != null)
                {
                    tdata.bodyDisplay = xAtContent.Element("display").Value == "true" ? "1" : "0";
                    tdata.bodyColor = xAtContent.Element("color").Value;
                    if (xAtContent.Element("font") != null)
                    {
                        if (xAtContent.Element("font").Element("weight") != null)
                            tdata.bodyFontType = xAtContent.Element("font").Element("weight").Value;
                        if (xAtContent.Element("font").Element("family") != null)
                            tdata.bodyFont = xAtContent.Element("font").Element("family").Value;
                        if (xAtContent.Element("font").Element("size") != null)
                            tdata.bodySize = xAtContent.Element("font").Element("size").Value.ToLower().Replace("pt", "");
                    }
                }

                #endregion "atBody style settings"
                #region "atHeader style settings"

                var xAtHeader = xConfig.Element("atHeader");
                if (xAtHeader != null)
                {
                    tdata.titleDisplay = xAtHeader.Element("display").Value == "true" ? "1" : "0";
                    tdata.titleColor = xAtHeader.Element("color").Value;
                    if (xAtHeader.Element("font") != null)
                    {
                        if (xAtHeader.Element("font").Element("weight") != null)
                            tdata.titleFontType = xAtHeader.Element("font").Element("weight").Value;
                        if (xAtHeader.Element("font").Element("family") != null)
                            tdata.titleFont = xAtHeader.Element("font").Element("family").Value;
                        if (xAtHeader.Element("font").Element("size") != null)
                            tdata.titleSize = xAtHeader.Element("font").Element("size").Value.ToLower().Replace("pt", "");
                    }
                }

                #endregion "atHeader style settings"
                #region "atPublishedBy style settings"

                var xPublishedBy = xConfig.Element("atPublishedBy");
                if (xPublishedBy != null)
                {
                    tdata.publishedByDisplay = xPublishedBy.Element("display").Value == "true" ? "1" : "0";
                    tdata.publishedByColor = xPublishedBy.Element("color").Value;
                    if (xAtContent.Element("font") != null)
                    {
                        if (xPublishedBy.Element("font").Element("weight") != null)
                            tdata.publishedByFontType = xPublishedBy.Element("font").Element("weight").Value;
                        if (xPublishedBy.Element("font").Element("family") != null)
                            tdata.publishedByFont = xPublishedBy.Element("font").Element("family").Value;
                        if (xPublishedBy.Element("font").Element("size") != null)
                            tdata.publishedBySize = xPublishedBy.Element("font").Element("size").Value.ToLower().Replace("pt", "");
                    }
                }

                #endregion "atPublishedBy style settings"
                #region "atPublishedOn style settings"

                var xPublishedOn = xConfig.Element("atPublishedOn");
                if (xPublishedOn != null)
                {
                    tdata.publishedOnDisplay = xPublishedOn.Element("display").Value == "true" ? "1" : "0";
                    tdata.publishedOnColor = xPublishedOn.Element("color").Value;
                    if (xAtContent.Element("font") != null)
                    {
                        if (xPublishedOn.Element("font").Element("weight") != null)
                            tdata.publishedOnFontType = xPublishedOn.Element("font").Element("weight").Value;
                        if (xPublishedOn.Element("font").Element("family") != null)
                            tdata.publishedOnFont = xPublishedOn.Element("font").Element("family").Value;
                        if (xPublishedOn.Element("font").Element("size") != null)
                            tdata.publishedOnSize = xPublishedOn.Element("font").Element("size").Value.ToLower().Replace("pt", "");
                    }
                }

                #endregion "atPublishedOn"
                #region "atImage style settings"

                var xAtImage = xConfig.Element("atImage");
                if (xAtImage != null)
                {
                    var ximgOption = xAtImage.Element("type");
                    if (ximgOption != null)
                        tdata.imgOption = ximgOption.Value;
                    var ximageDisplay = xAtImage.Element("position");
                    if (ximageDisplay != null)
                        tdata.imageDisplay = ximageDisplay.Value;
                    if (!string.Equals(tdata.imgOption, "SYSTEM"))
                        tdata.imagePath = xAtImage.Element("imageName").Value;
                }

                #endregion "atImage style settings"
                #region "atRenderingBehavior style settings"

                var xRenderBehavior = xConfig.Element("atRenderingBehavior");
                if (xRenderBehavior != null)
                {
                    if (!string.IsNullOrEmpty((xRenderBehavior.Element("timeout").Value)))
                        tdata.timeOut = int.Parse(xRenderBehavior.Element("timeout").Value);
                    tdata.popupLocation = xRenderBehavior.Element("root").Value;
                    if (!string.IsNullOrEmpty((xRenderBehavior.Element("width").Value)))
                        tdata.width = int.Parse(xRenderBehavior.Element("width").Value);
                    if (!string.IsNullOrEmpty((xRenderBehavior.Element("height").Value)))
                        tdata.height = int.Parse(xRenderBehavior.Element("height").Value);
                    if (!string.IsNullOrEmpty((xRenderBehavior.Element("leftOffset").Value)))
                        tdata.leftOffset = int.Parse(xRenderBehavior.Element("leftOffset").Value);
                    if (!string.IsNullOrEmpty((xRenderBehavior.Element("topOffset").Value)))
                        tdata.topOffset = int.Parse(xRenderBehavior.Element("topOffset").Value);
                    tdata.motionOn = xRenderBehavior.Element("motionOn").Value ?? "";
                    tdata.motionOff = xRenderBehavior.Element("motionOff").Value ?? "";
                    if (!string.IsNullOrEmpty(xRenderBehavior.Element("motionStep").Value))
                        tdata.motionStep = int.Parse(xRenderBehavior.Element("motionStep").Value);
                    if (!string.IsNullOrEmpty(xRenderBehavior.Element("motionInterval").Value))
                        tdata.motionInterval = int.Parse(xRenderBehavior.Element("motionInterval").Value);
                    if (!string.IsNullOrEmpty(xRenderBehavior.Element("timeoutValue").Value))
                        tdata.timeOutValue = int.Parse(xRenderBehavior.Element("timeoutValue").Value);
                    if (!string.IsNullOrEmpty(xRenderBehavior.Element("timeoutUnit").Value))
                        tdata.timeOutUnit = xRenderBehavior.Element("timeoutUnit").Value;
                    tdata.fullScreenYN = xRenderBehavior.Element("fullScreen").Value;
                    tdata.useAdvancedStyle = xRenderBehavior.Element("useAdvancedStyle").Value;
                    //tdata.status = xRenderBehavior.Element("status").Value;
                    if (xRenderBehavior.Element("audioId") != null)
                        tdata.audioId = xRenderBehavior.Element("audioId").Value;
                    if (xRenderBehavior.Element("templateGuid") != null)
                        tdata.templateImageGuid = xRenderBehavior.Element("templateGuid").Value;
                }

                #endregion "atRenderingBehavior style settings"


            }
            else
            {
                tdata.fullScreenYN = "Y";
                tdata.timeOutValue = Constants.DefaultTimeOutValue;
                tdata.imgOption = "CUSTOM";
                tdata.useAdvancedStyle = "N";

            }

            tdata.width = ((tdata.fullScreenYN == "Y" || tdata.width == null) ? Constants.DefaultWidth : tdata.width);
            tdata.height = ((tdata.fullScreenYN == "Y" || tdata.height == null) ? Constants.DefaultHeight : tdata.height);
            return tdata;

        }


        public string CreateTemplateDataXml(TemplateDetailsModel deliveryTemplateData)
        {
            if (deliveryTemplateData.xmlConfiguration != null)
            {
                var xDocConfig = XDocument.Parse(deliveryTemplateData.xmlConfiguration);
                var xConfig = xDocConfig.Element("Configuration");

                if (xConfig == null)
                    return string.Empty;

                #region"atBody Assignment"

                var xAtBody = xConfig.Element("atBody");
                if (xAtBody != null)
                    if (xAtBody.Element("background") != null)
                        if (xAtBody.Element("background").Element("color") != null)
                            xAtBody.Element("background").Element("color").Value =
                                deliveryTemplateData.templateBackgroundColor;

                var xAtContent = xConfig.Element("atContent");
                if (xAtContent != null)
                {
                    var xAtContentFont = xAtContent.Element("font");
                    if (xAtContentFont != null)
                    {
                        if (xAtContentFont.Element("style") != null)
                        {
                            if (deliveryTemplateData.IsPreview == true)
                                xAtContentFont.Element("style").Value = deliveryTemplateData.bodyFontType.ToLower().Contains("italic") ? "italic" : "normal";
                            else
                                xAtContentFont.Element("style").Value = deliveryTemplateData.bodyFontType;
                        }
                        if (xAtContentFont.Element("weight") != null)
                        {
                            if (deliveryTemplateData.IsPreview == true)
                                xAtContentFont.Element("weight").Value = deliveryTemplateData.bodyFontType.ToLower().Contains("bold") ? "bold" : "normal";
                            else
                                xAtContentFont.Element("weight").Value = deliveryTemplateData.bodyFontType;
                        }


                        if (xAtContentFont.Element("family") != null)
                            xAtContentFont.Element("family").Value = deliveryTemplateData.bodyFont;

                        if (xAtContentFont.Element("size") != null)
                            xAtContentFont.Element("size").Value = deliveryTemplateData.bodySize;
                        if (xAtContent.Element("display") != null)
                        {
                            if (deliveryTemplateData.IsPreview == true)
                                xAtContent.Element("display").Value = deliveryTemplateData.bodyDisplay == "1" ? "none" : "block";
                            else
                                xAtContent.Element("display").Value = deliveryTemplateData.bodyDisplay == "1"
                                    ? "true"
                                    : "false";
                        }
                        if (xAtContent.Element("color") != null)
                            xAtContent.Element("color").Value = deliveryTemplateData.bodyColor;
                    }
                }

                #endregion"atBody Assignment"

                #region"atBorder Assignment"

                var xAtBorder = xConfig.Element("atBorder");
                if (xAtBorder != null)
                {
                    var xAtBorderborder = xAtBorder.Element("border");
                    if (xAtBorderborder != null)
                    {
                        if (xAtBorderborder.Element("width") != null)
                            xAtBorderborder.Element("width").Value = deliveryTemplateData.templateBorderSize;

                        if (xAtBorderborder.Element("color") != null)
                            xAtBorderborder.Element("color").Value = deliveryTemplateData.templateBorderColor;
                    }

                }

                #endregion"atBorder Assignment"

                #region"atHeader Assignment"

                var xAtHeader = xConfig.Element("atHeader");
                if (xAtHeader != null)
                {

                    if (xAtHeader.Element("display") != null)
                    {
                        if (deliveryTemplateData.IsPreview == true)
                            xAtHeader.Element("display").Value = deliveryTemplateData.titleDisplay == "1" ? "none" : "block";
                        else
                            xAtHeader.Element("display").Value = deliveryTemplateData.titleDisplay == "1" ? "true" : "false";
                    }
                    if (xAtHeader.Element("color") != null)
                        xAtHeader.Element("color").Value = deliveryTemplateData.titleColor;
                    var xAtHeaderFont = xAtHeader.Element("font");
                    if (xAtHeaderFont != null)
                    {
                        if (xAtHeaderFont.Element("style") != null)
                        {
                            if (deliveryTemplateData.IsPreview == true)
                                xAtHeaderFont.Element("style").Value = deliveryTemplateData.titleFontType.ToLower().Contains("italic") ? "italic" : "normal";
                            else
                                xAtHeaderFont.Element("style").Value = deliveryTemplateData.titleFontType;
                        }

                        if (xAtHeaderFont.Element("weight") != null)
                        {
                            if (deliveryTemplateData.IsPreview == true)
                                xAtHeaderFont.Element("weight").Value = deliveryTemplateData.titleFontType.ToLower().Contains("bold") ? "bold" : "normal";
                            else
                                xAtHeaderFont.Element("weight").Value = deliveryTemplateData.titleFontType;
                        }
                        if (xAtHeaderFont.Element("family") != null)
                            xAtHeaderFont.Element("family").Value = deliveryTemplateData.titleFont;

                        if (xAtHeaderFont.Element("size") != null)
                            xAtHeaderFont.Element("size").Value = deliveryTemplateData.titleSize;
                    }
                }

                #endregion"atHeader Assignment"

                #region"atPublishedBy Assignment"

                var xAtPublishedBy = xConfig.Element("atPublishedBy");
                if (xAtPublishedBy != null)
                {

                    if (xAtPublishedBy.Element("display") != null)
                    {
                        if (deliveryTemplateData.IsPreview == true)
                            xAtPublishedBy.Element("display").Value = deliveryTemplateData.publishedByDisplay == "1" ? "none" : "block";
                        else
                            xAtPublishedBy.Element("display").Value = deliveryTemplateData.publishedByDisplay == "1"
                                ? "true"
                                : "false";
                    }
                    if (xAtPublishedBy.Element("color") != null)
                        xAtPublishedBy.Element("color").Value = deliveryTemplateData.publishedByColor;
                    var xAtPublishedByFont = xAtPublishedBy.Element("font");
                    if (xAtPublishedByFont != null)
                    {
                        if (xAtPublishedByFont.Element("style") != null)
                        {
                            if (deliveryTemplateData.IsPreview == true)
                                xAtPublishedByFont.Element("style").Value = deliveryTemplateData.publishedByFontType.ToLower().Contains("italic") ? "italic" : "normal";
                            else
                                xAtPublishedByFont.Element("style").Value = deliveryTemplateData.publishedByFontType;
                        }

                        if (xAtPublishedByFont.Element("weight") != null)
                        {
                            if (deliveryTemplateData.IsPreview == true)
                                xAtPublishedByFont.Element("weight").Value = deliveryTemplateData.publishedByFontType.ToLower().Contains("bold") ? "bold" : "normal";
                            else
                                xAtPublishedByFont.Element("weight").Value = deliveryTemplateData.publishedByFontType;
                        }


                        if (xAtPublishedByFont.Element("family") != null)
                            xAtPublishedByFont.Element("family").Value = deliveryTemplateData.publishedByFont;

                        if (xAtPublishedByFont.Element("size") != null)
                            xAtPublishedByFont.Element("size").Value = deliveryTemplateData.publishedBySize;
                    }
                }

                #endregion"atPublishedBy Assignment"

                #region"atPublishedOn Assignment"

                var xAtPublishedOn = xConfig.Element("atPublishedOn");
                if (xAtPublishedOn.Element("font") != null)
                {

                    if (xAtPublishedOn.Element("display") != null)
                    {
                        if (deliveryTemplateData.IsPreview == true)
                            xAtPublishedOn.Element("display").Value = deliveryTemplateData.publishedOnDisplay == "1" ? "none" : "block";
                        else
                            xAtPublishedOn.Element("display").Value = deliveryTemplateData.publishedOnDisplay == "1"
                                ? "true"
                                : "false";
                    }
                    if (xAtPublishedOn.Element("color") != null)
                        xAtPublishedOn.Element("color").Value = deliveryTemplateData.publishedOnColor;

                    if (xAtPublishedOn.Element("font").Element("style") != null)
                    {
                        if (deliveryTemplateData.IsPreview == true)
                            xAtPublishedOn.Element("font").Element("style").Value = deliveryTemplateData.publishedOnFontType.ToLower().Contains("italic") ? "italic" : "normal";
                        else
                            xAtPublishedOn.Element("font").Element("style").Value = deliveryTemplateData.publishedOnFontType;
                    }

                    if (xAtPublishedOn.Element("font").Element("weight") != null)
                    {
                        if (deliveryTemplateData.IsPreview == true)
                            xAtPublishedOn.Element("font").Element("weight").Value = deliveryTemplateData.publishedOnFontType.ToLower().Contains("bold") ? "bold" : "normal";
                        else
                            xAtPublishedOn.Element("font").Element("weight").Value = deliveryTemplateData.publishedOnFontType;
                    }
                    //if (xAtPublishedOn.Element("font").Element("weight") != null)
                    //    xAtPublishedOn.Element("font").Element("weight").Value = deliveryTemplateData.publishedOnFontType;

                    if (xAtPublishedOn.Element("font").Element("family") != null)
                        xAtPublishedOn.Element("font").Element("family").Value = deliveryTemplateData.publishedOnFont;

                    if (xAtPublishedOn.Element("font").Element("size") != null)
                        xAtPublishedOn.Element("font").Element("size").Value = deliveryTemplateData.publishedOnSize;
                }

                #endregion"atPublishedOn Assignment"

                #region"atImage Assignment"

                var xAtImage = xConfig.Element("atImage");
                if (xAtImage != null)
                {
                    if (xAtImage.Element("type") != null)
                        xAtImage.Element("type").Value = deliveryTemplateData.imgOption;
                    if (xAtImage.Element("position") != null)
                        xAtImage.Element("position").Value = deliveryTemplateData.imageDisplay;
                    if (xAtImage.Element("imageName") != null && (deliveryTemplateData.imgOption != "SYSTEM") &&
                        deliveryTemplateData.imagePath != null)
                        xAtImage.Element("imageName").Value =
                            deliveryTemplateData.imagePath.Substring(deliveryTemplateData.imagePath.LastIndexOf("\\") + 1,
                                deliveryTemplateData.imagePath.Length);
                }

                #endregion"atImage Assignment"
                #region "atRenderingBehavior style settings"

                var xAtRenderingBehavior = xConfig.Element("atRenderingBehavior");

                if (xAtRenderingBehavior.Element("timeout") != null)
                    xAtRenderingBehavior.Element("timeout").Value = Convert.ToString((deliveryTemplateData.timeOut));

                if (xAtRenderingBehavior.Element("root") != null)
                    xAtRenderingBehavior.Element("root").Value = deliveryTemplateData.popupLocation;

                if (xAtRenderingBehavior.Element("width") != null)
                    xAtRenderingBehavior.Element("width").Value = deliveryTemplateData.width.ToString();

                if (xAtRenderingBehavior.Element("height") != null)
                    xAtRenderingBehavior.Element("height").Value = deliveryTemplateData.height.ToString();

                if (xAtRenderingBehavior.Element("leftOffset") != null)
                    xAtRenderingBehavior.Element("leftOffset").Value = deliveryTemplateData.leftOffset.ToString();

                if (xAtRenderingBehavior.Element("topOffset") != null)
                    xAtRenderingBehavior.Element("topOffset").Value = deliveryTemplateData.topOffset.ToString();

                if (xAtRenderingBehavior.Element("motionOn") != null)
                    xAtRenderingBehavior.Element("motionOn").Value = Convert.ToString(deliveryTemplateData.motionOn);

                if (xAtRenderingBehavior.Element("motionOff") != null)
                    xAtRenderingBehavior.Element("motionOff").Value = Convert.ToString(deliveryTemplateData.motionOff);

                if (xAtRenderingBehavior.Element("motionStep") != null)
                    xAtRenderingBehavior.Element("motionStep").Value = "";

                if (xAtRenderingBehavior.Element("motionInterval") != null)
                    xAtRenderingBehavior.Element("motionInterval").Value = "";

                if (xAtRenderingBehavior.Element("audioId") != null)
                    xAtRenderingBehavior.Element("audioId").Value = "0";

                if (xAtRenderingBehavior.Element("templateGuid") != null && deliveryTemplateData.templateImageGuid != null)
                    xAtRenderingBehavior.Element("templateGuid").Value = Convert.ToString(deliveryTemplateData.templateImageGuid);
                else
                    xAtRenderingBehavior.Element("templateGuid").Value = "";

                if ((xAtRenderingBehavior.Element("description") != null) && deliveryTemplateData.description != null)
                    xAtRenderingBehavior.Element("description").Value = Convert.ToString(deliveryTemplateData.description);

                if (xAtRenderingBehavior.Element("timeoutUnit") != null)
                    xAtRenderingBehavior.Element("timeoutUnit").Value = Convert.ToString(deliveryTemplateData.timeOutUnit);

                if (xAtRenderingBehavior.Element("timeoutValue") != null)
                    xAtRenderingBehavior.Element("timeoutValue").Value = Convert.ToString(deliveryTemplateData.timeOutValue);

                /* if (xAtRenderingBehavior.Element("status") != null)
                     xAtRenderingBehavior.Element("status").Value = "";*/

                if (xAtRenderingBehavior.Element("fullScreen") != null)
                    xAtRenderingBehavior.Element("fullScreen").Value = Convert.ToString(deliveryTemplateData.fullScreenYN);

                if (xAtRenderingBehavior.Element("useAdvancedStyle") != null)
                    xAtRenderingBehavior.Element("useAdvancedStyle").Value = Convert.ToString(deliveryTemplateData.useAdvancedStyle);

                #endregion "atRenderingBehavior style settings"
                return Convert.ToString(xDocConfig.ToString());
            }
            else
            {
                return "";
            }

        }

        private static string GetDefaultImage()
        {
            var imagePath = string.Concat(AtHocSystem.Local.DirPathApplication, "\\wwwroot", Constants.DefaultBlankImage);

            FileStream fileStream = new FileStream(imagePath, FileMode.Open, FileAccess.Read);
            byte[] data = new byte[(int)fileStream.Length];
            fileStream.Read(data, 0, data.Length);
            return Convert.ToBase64String(data);
        }

        public string GenerateDesktopReview(string xlst, string strXmlPath, string strproviderName, string severity, string Locale)
        {
            var previewXml = string.Concat(AtHocSystem.Local.DirPathApplication, "\\wwwroot\\", Constants.DesktopPopupXml);
            previewXml = previewXml.Replace("/", "\\");


            if (string.IsNullOrEmpty(strXmlPath))
                strXmlPath = previewXml;

            // get notifier action
            using (StringWriter html = new StringWriter())
            {
                var transform = new XslCompiledTransform();
                var args = new XsltArgumentList();
                // transform args
                args.AddExtensionObject(Constants.XlsName, new TabIndexer());
                // load the xslt
                using (var sReader = new StringReader(xlst))
                {
                    using (var xReader = new XmlTextReader(sReader))
                    {
                        transform.Load(xReader);
                    }
                }
                var xDoc = new XmlDocument();
                xDoc.Load(strXmlPath);
                var selectSingleNode = xDoc.SelectSingleNode("//data/organizationName");
                if (selectSingleNode != null)
                    selectSingleNode.InnerText = strproviderName;

                selectSingleNode = xDoc.SelectSingleNode("//data/severity");
                if (selectSingleNode != null)
                    selectSingleNode.InnerText = severity;

                selectSingleNode = xDoc.SelectSingleNode("//data/type");
                if (selectSingleNode != null)
                    selectSingleNode.InnerText = IWSResources.ResourceManager.GetString(selectSingleNode.InnerText, new CultureInfo(Locale));

                selectSingleNode = xDoc.SelectSingleNode("//data/text/text1");
                if (selectSingleNode != null)
                    selectSingleNode.InnerText = IWSResources.ResourceManager.GetString(selectSingleNode.InnerText, new CultureInfo(Locale));

                selectSingleNode = xDoc.SelectSingleNode("//data/text/text2");
                if (selectSingleNode != null)
                    selectSingleNode.InnerText = IWSResources.ResourceManager.GetString(selectSingleNode.InnerText, new CultureInfo(Locale));

                selectSingleNode = xDoc.SelectSingleNode("//data/text/text3");
                if (selectSingleNode != null)
                    selectSingleNode.InnerText = IWSResources.ResourceManager.GetString(selectSingleNode.InnerText, new CultureInfo(Locale));

                XmlNodeList xnList = xDoc.SelectNodes("//data/responseOptions/responseOption/responseText");
                foreach (XmlNode xn in xnList)
                {
                    if (xn != null)
                        xn.InnerText = IWSResources.ResourceManager.GetString(xn.InnerText, new CultureInfo(Locale));
                }

                selectSingleNode = xDoc.SelectSingleNode("//data/publishedBy");
                if (selectSingleNode != null)
                    selectSingleNode.InnerText = IWSResources.ResourceManager.GetString(selectSingleNode.InnerText, new CultureInfo(Locale));

                xnList = xDoc.SelectNodes("//data/actions/action");
                foreach (XmlNode xn in xnList)
                {
                    if (xn["title"] != null)
                        xn["title"].InnerText = IWSResources.ResourceManager.GetString(selectSingleNode.InnerText, new CultureInfo(Locale));
                }
                selectSingleNode = xDoc.SelectSingleNode("//data/imageUrl");
                if (selectSingleNode != null)
                    selectSingleNode.InnerText = AtHocSystem.Local.BaseUrl;
                selectSingleNode = xDoc.SelectSingleNode("//data/location");
                if (selectSingleNode != null)
                    selectSingleNode.InnerText = AtHocSystem.Local.BaseUrl+ "/" + Constants.SelfServiceUrl + "/" +RuntimeContext.ProviderId;

                // transform the result
                using (var sReader = new StringReader(xDoc.InnerXml))
                {
                    using (var xReader = new XmlTextReader(sReader))
                    {
                        transform.Transform(xReader, args, html);

                    }
                }
                var returnHtml = html.ToString().Replace("<title></title>", "<title>" + GetResourceString("Desktop_Popup_Preview_Title") + "</title>");
                /*    returnHtml = ResizeHtml(returnHtml, templateData.width ?? 0, templateData.height ?? 0,
                        templateData.fullScreenYN ?? "Y"); */
                return returnHtml;
            }
        }

        public string GenerateEmailReview(string xlst, string strXmlPath, string strproviderName, string severity, string locale)
        {
            var previewXml = string.Concat(AtHocSystem.Local.DirPathApplication, "\\wwwroot\\", Constants.EmailTemplateXml);
            previewXml = previewXml.Replace("/", "\\");
            if (string.IsNullOrEmpty(strXmlPath))
                strXmlPath = previewXml;
            var args = GetEmailTemplateArgumentList(strXmlPath, strproviderName, severity, locale);

            // get notifier action
            using (StringWriter html = new StringWriter())
            {
                var transform = new XslCompiledTransform();
                using (var sReader = new StringReader(xlst))
                {
                    using (var xReader = new XmlTextReader(sReader))
                    {
                        transform.Load(xReader);
                    }
                }

                var xDoc = new XmlDocument();
                xDoc.LoadXml("<dummy>dum</dummy>");

                using (var sReader = new StringReader(xDoc.InnerXml))
                {
                    using (var xReader = new XmlTextReader(sReader))
                    {
                        transform.Transform(xReader, args, html);

                    }
                }
                var returnHtml = html.ToString().Replace("<title></title>", "<title>Email Template Preview</title>");
                var startPos = returnHtml.IndexOf("<html>", System.StringComparison.Ordinal);
                var endPos = returnHtml.IndexOf("</html>", System.StringComparison.Ordinal);
                return returnHtml.Substring(startPos, endPos - startPos);
            }
        }

        public XsltArgumentList GetEmailTemplateArgumentList(string strXmlPath, string strproviderName, string severity, string locale)
        {
            var args = new XsltArgumentList();
            var xDoc = new XmlDocument();
            xDoc.Load(strXmlPath);

            var selectSingleNode = xDoc.SelectSingleNode("//data/recipientname");
            if (selectSingleNode != null)
                args.AddParam("RecipientName", "", IWSResources.ResourceManager.GetString(selectSingleNode.InnerText, new CultureInfo(locale)));
            else
                args.AddParam("RecipientName", "", "");

            selectSingleNode = xDoc.SelectSingleNode("//data/messagetitle");
            if (selectSingleNode != null)
                args.AddParam("MessageTitle", "", IWSResources.ResourceManager.GetString(selectSingleNode.InnerText, new CultureInfo(locale)));
            else
                args.AddParam("MessageTitle", "", "");

            selectSingleNode = xDoc.SelectSingleNode("//data/messagebody");
            if (selectSingleNode != null)
                args.AddParam("MessageBody", "", IWSResources.ResourceManager.GetString(selectSingleNode.InnerText, new CultureInfo(locale)));
            else
                args.AddParam("MessageBody", "", "");

            selectSingleNode = xDoc.SelectSingleNode("//data/systemname");
            if (selectSingleNode != null)
                args.AddParam("SystemName", "", strproviderName);
            else
                args.AddParam("SystemName", "", "");




            selectSingleNode = xDoc.SelectSingleNode("//data/vpsname");
            if (selectSingleNode != null)
                args.AddParam("VpsName", "", strproviderName);
            else
                args.AddParam("VpsName", "", "");


            selectSingleNode = xDoc.SelectSingleNode("//data/publishedby");
            if (selectSingleNode != null)
                args.AddParam("PlubishedBy", "", IWSResources.ResourceManager.GetString(selectSingleNode.InnerText, new CultureInfo(locale)));
            else
                args.AddParam("PlubishedBy", "", "");


            selectSingleNode = xDoc.SelectSingleNode("//data/publishedat");
            if (selectSingleNode != null)
                args.AddParam("PublishedAt", "", selectSingleNode.InnerText);
            else
                args.AddParam("PublishedAt", "", "");

            selectSingleNode = xDoc.SelectSingleNode("//data/targeturl");
            if (selectSingleNode != null)
                args.AddParam("TargetUrl", "", selectSingleNode.InnerText);
            else
                args.AddParam("TargetUrl", "", "");

            selectSingleNode = xDoc.SelectSingleNode("//data/systemurl");
            if (selectSingleNode != null)
                args.AddParam("SystemUrl", "", selectSingleNode.InnerText);
            else
                args.AddParam("SystemUrl", "", "");

            selectSingleNode = xDoc.SelectSingleNode("//data/selfserviceurl");

            selectSingleNode = xDoc.SelectSingleNode("//data/selfserviceurl");

            if (selectSingleNode != null)
                args.AddParam("SelfServiceUrl", "", ConfigurationManager.GetURL() + Constants.SelfServiceUrl + "/" + RuntimeContext.ProviderId);

            selectSingleNode = xDoc.SelectSingleNode("//data/type");
            if (selectSingleNode != null)
                args.AddParam("Type", "", IWSResources.ResourceManager.GetString(selectSingleNode.InnerText, new CultureInfo(locale)));
            else
                args.AddParam("Type", "", "");


            selectSingleNode = xDoc.SelectSingleNode("//data/severity");
            if (selectSingleNode != null)
                args.AddParam("Severity", "", severity);


            XmlNodeList xnList = xDoc.SelectNodes("//data/responseoptions/responseoption");

            if (xnList != null)
            {
                StringBuilder sb = new StringBuilder();
                var responseOptionId = 0;
                foreach (XmlNode xn in xnList)
                {
                    sb.Append(string.Format("{0}. {1} ", responseOptionId + 1, IWSResources.ResourceManager.GetString(xn["responsetext"].InnerText.Replace('|', '/'), new CultureInfo(locale))));
                    sb.Append("|");
                    responseOptionId++;

                }
                args.AddParam("ResponseOptions", "", sb.ToString());
            }
            else
                args.AddParam("ResponseOptions", "", "");


            selectSingleNode = xDoc.SelectSingleNode("//data/responseinstruction");
            if (selectSingleNode != null)
                args.AddParam("ResponseInstruction", "", IWSResources.ResourceManager.GetString(selectSingleNode.InnerText, new CultureInfo(locale)));
            else
                args.AddParam("ResponseInstruction", "", "");


            selectSingleNode = xDoc.SelectSingleNode("//data/link");
            if (selectSingleNode != null)
                args.AddParam("Link", "", selectSingleNode.InnerText);
            else
                args.AddParam("Link", "", "");
            return args;
        }

        public string setDisplayProperties(TemplateDetailsModel deliveryTemplateData)
        {
            if (deliveryTemplateData.xmlConfiguration != null)
            {
                var xDocConfig = XDocument.Parse(deliveryTemplateData.xmlConfiguration);
                var xConfig = xDocConfig.Element("Configuration");

                if (xConfig == null)
                    return string.Empty;

                #region"atBody Assignment"


                var xAtContent = xConfig.Element("atContent");
                if (xAtContent != null)
                {
                    if (xAtContent.Element("display") != null)
                        xAtContent.Element("display").Value = deliveryTemplateData.bodyDisplay == "1" ? "none" : "table-cell";

                }

                #endregion"atBody Assignment"

                #region"atHeader Assignment"

                var xAtHeader = xConfig.Element("atHeader");
                if (xAtHeader != null)
                {

                    if (xAtHeader.Element("display") != null)
                    {
                        xAtHeader.Element("display").Value = deliveryTemplateData.titleDisplay == "1" ? "none" : "block";
                    }
                }

                #endregion"atHeader Assignment"

                #region"atPublishedBy Assignment"

                var xAtPublishedBy = xConfig.Element("atPublishedBy");
                if (xAtPublishedBy != null)
                {

                    if (xAtPublishedBy.Element("display") != null)
                    {
                        xAtPublishedBy.Element("display").Value = deliveryTemplateData.publishedByDisplay == "1" ? "none" : "table-cell";
                    }

                }

                #endregion"atPublishedBy Assignment"

                #region"atPublishedOn Assignment"

                var xAtPublishedOn = xConfig.Element("atPublishedOn");
                if (xAtPublishedOn.Element("font") != null)
                {

                    if (xAtPublishedOn.Element("display") != null)
                    {
                        xAtPublishedOn.Element("display").Value = deliveryTemplateData.publishedOnDisplay == "1" ? "none" : "table-cell";
                    }

                }

                #endregion"atPublishedOn Assignment"


                return Convert.ToString(xDocConfig.ToString());
            }

            return string.Empty;
        }

        public static string GetResourceString(string strDescription)
        {
            var resource = new System.Resources.ResourceManager(Constants.resourceAssembly, typeof(IWSResources).Assembly);
            return resource.GetString(strDescription, Thread.CurrentThread.CurrentUICulture);
        }

    

    }
}
