﻿namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public interface ISecurityPolicyRepository
    {
       
        GlobalSecuritySettings GetSecurityPolicy();
        SecurityPolicyModel GetSecurityPolicySettings(int providerId);
        int SaveSecurityPolicySettings(SecurityPolicyModel securitydata);
        bool InsertSecurityPolicySettings(SecurityPolicyModel securitydata);
        bool DeleteSecurityPolicySettings(SecurityPolicyModel securitydata);
        bool UpdateEnforcePassword(int providerId, int operatorId);
    }
}
