﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Database;
using AtHoc.Infrastructure.Sql;
using AtHoc.IWS.Business.Database;

namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public class OperatorAuditRepository1 : IOperatorAuditRepository1
    {
        public IEnumerable<OperatorAuditModel> GetOperatorAuditDetails(int providerId,string operatorName,string fromDate,string toDate,string entiryId,string actionId ) 
        {
            using (var repository = new EntityFrameworkRepository(new AtHocDbContext()))
            {
                repository.RunQuery<OperatorAuditModel>("", null).AsQueryable();
               
            }
            using(var context=new AtHocDbContext())
            {
                
            }
            return new List<OperatorAuditModel>();
        }
    }
}
