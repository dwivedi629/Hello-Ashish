﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public interface IAuditEntityRepository
    {
        IEnumerable<AuditEntity> GetAuditEntities();
    }
}
