﻿using System;
using System.Linq;
using System.Collections.Generic;
using AtHoc.Infrastructure.Sql;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Configurations;
using AtHoc.Data;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Settings.SqlQueries;

namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public class HierarchyDefinitionRepository : IHierarchyDefinitionRepository
    {

        public IEnumerable<PdlListModel> GetHierarchy(HierarchySpec hierarchySpec)
        {

            var hierarchy = GetHierarchyDetails(hierarchySpec.ProviderId, hierarchySpec.HierarchySearchType);

            using (var context = new AtHocDbContext())
            {
                var data = context.PldListSettings.Where(p => p.ProviderId == hierarchySpec.ProviderId && p.HierarchyId == hierarchy.HierarchyId && p.ListType == Constants.TreeType && p.Status != "DEL").OrderBy(p => p.SortOrder)
                    .Select(p => new PdlListModel { ProviderId = p.ProviderId, Name = p.Name.Trim(), CommonName = p.CommonName.Trim(), HierarchyId = p.HierarchyId, ListId = p.ListId, ParentListId = p.ParentListId, Lineage = p.Lineage, OldLineage = p.Lineage + p.Name.Trim() + "/" }).ToList();


                data.Add(new PdlListModel { ProviderId = hierarchy.ProviderId, Name = hierarchy.Name.Trim(), CommonName = hierarchy.CommonName.Trim(), HierarchyId = hierarchy.HierarchyId, ListId = 0, ParentListId = -1 });
                return data;
            }

        }

        public bool SaveNode(HierarchySpec hierarchySpec)
        {
            using (var context = new AtHocDbContext())
            {
                foreach (var item in hierarchySpec.NodeList)
                {
                    if (item.Name != null)
                    {
                        var pdlitem = new PdlListSettings
                        {
                            ListId = item.ListId,
                            ParentListId = item.ParentListId,
                            ProviderId = hierarchySpec.ProviderId,
                            CommonName = item.CommonName.Trim(),
                            CreatedOn = DateTimeConverter.GetSystemTimeAsSeconds(),
                            CreatedBy = hierarchySpec.OperatorId,
                            HierarchyId = item.HierarchyId,
                            Lineage = item.Lineage,
                            ListType = item.ListType,
                            Name = item.Name.Trim(),
                            Description = "",
                            Defintion = "",
                            IsSychronized = "N",
                            SyncSoruce = "N",
                            EditLevel = 2,
                            Metastore = "",
                            FromSubProvider = "N",
                            IsSystem = "N",
                            IsAvailableFromMap = "N",
                            IsExtended = "N",
                            Status = "ACT",
                            SortOrder = item.SortOrder,
                        };
                        if (item.Status == "M" || item.Status == "D")
                        {
                            var savedata = context.PldListSettings.FirstOrDefault(p => p.ProviderId == hierarchySpec.ProviderId && p.ListId == item.ListId && p.HierarchyId == item.HierarchyId);
                            if (savedata != null)
                            {
                                savedata.Name = item.Name.Trim();
                                savedata.CommonName = item.CommonName.Trim();
                                savedata.ParentListId = item.ParentListId;
                                savedata.Lineage = item.Lineage;
                                savedata.SortOrder = item.SortOrder;
                                savedata.Status = "ACT";
                                savedata.UdpateOn = DateTimeConverter.GetSystemTimeAsSeconds();
                                savedata.UpdatedBy = hierarchySpec.OperatorId;
                                context.Entry(savedata).State = item.Status == "D" ? System.Data.Entity.EntityState.Deleted : System.Data.Entity.EntityState.Modified;
                            }
                            else
                            {
                                if (item.ListId == 0)
                                {
                                    var data = context.PldHierarchySettings.FirstOrDefault(p => p.HierarchyId == item.HierarchyId);
                                    data.Name = item.Name;

                                    context.Entry(data).State = System.Data.Entity.EntityState.Modified;
                                    //update attribute name
                                    UpdateHierarchyAttributeName(hierarchySpec, item.Name);

                                }

                            }


                            //For Organization to update Lineage
                            if ((item.Status == "M" || item.Status == "D"))
                            {
                                if (((item.OldLineage != null) && (item.OldLineage != "/")))
                                {
                                    if (item.OldLineage != item.Lineage)
                                    {
                                        if (hierarchySpec.HierarchySearchType == HierarchySearchType.Organization)
                                        {
                                            object[] parameters =
                                            {
                                                item.HierarchyId, item.OldLineage,(item.Status == "D") ? item.Lineage : item.Lineage + item.Name + "/"
                                            };
                                            context.Database.ExecuteSqlCommand("USR_SET_LINEAGE {0},  {1}, {2}",
                                                parameters);
                                            context.SaveChanges();
                                        }

                                        if (hierarchySpec.HierarchySearchType == HierarchySearchType.DistributionList)
                                        {
                                            context.Database.ExecuteSqlCommand(" UPDATE  PDL_LIST_TAB  SET LINEAGE={0} WHERE HIERARCHY_ID={1} and LINEAGE={2}", (item.Status == "D") ? item.Lineage : item.Lineage + item.Name + "/", item.HierarchyId, item.OldLineage);
                                        }
                                    }
                                }
                            }

                        }
                        if (item.Status == "N")
                        {
                            pdlitem.ListId = GetMaxListId();
                            item.ListId = pdlitem.ListId;

                            if (pdlitem.ParentListId <= 0)
                            {
                                var firstOrDefault = (from pdl in hierarchySpec.NodeList
                                                      where pdl.NewListId == item.NewParentListId
                                                      select pdl).FirstOrDefault();
                                if (firstOrDefault != null)
                                {
                                    pdlitem.ParentListId = firstOrDefault.ListId;
                                }
                                else
                                    pdlitem.ParentListId = Convert.ToInt32(item.NewParentListId);

                                item.ParentListId = pdlitem.ParentListId;
                                item.NewParentListId = System.Convert.ToString(pdlitem.ParentListId);
                            }
                            context.PldListSettings.Add(pdlitem);
                        }

                    }
                }
                context.SaveChanges();
                return true;
            }
        }

        public bool DeleteNode(HierarchySpec hierarchySpec)
        {
            using (var context = new AtHocDbContext())
            {
                var savedata = context.PldListSettings.FirstOrDefault(p => p.ProviderId == hierarchySpec.Node.ProviderId && p.HierarchyId == hierarchySpec.Node.HierarchyId && p.ListId == hierarchySpec.Node.ListId);
                if (savedata != null)
                {
                    context.Entry(savedata).State = System.Data.Entity.EntityState.Deleted;
                }
                foreach (var record in context.PldListSettings.Where(p => p.ProviderId == hierarchySpec.Node.ProviderId && p.HierarchyId == hierarchySpec.Node.HierarchyId && p.ParentListId == hierarchySpec.Node.ListId).ToList())
                {
                    record.ParentListId = hierarchySpec.Node.ParentListId ?? 0;
                }
                context.SaveChanges();
                return true;
            }
        }

        public bool AddNode(HierarchySpec hierarchySpec)
        {

            using (var context = new AtHocDbContext())
            {
                var savedata = context.PldListSettings.FirstOrDefault(p => p.ProviderId == hierarchySpec.Node.ProviderId && p.HierarchyId == hierarchySpec.Node.HierarchyId && p.ListId == hierarchySpec.Node.ParentListId);
                if (savedata != null)
                {

                    var newPdlListSettings = new PdlListSettings
                     {
                         ListId = GetMaxListId(),
                         ProviderId = hierarchySpec.Node.ProviderId,
                         Name = hierarchySpec.Node.Name,
                         ListType = savedata.ListType,
                         CommonName = hierarchySpec.Node.CommonName,
                         Description = savedata.Description,
                         Defintion = savedata.Defintion,
                         AttributeId = savedata.AttributeId,
                         IsSychronized = savedata.IsSychronized,
                         SyncSoruce = savedata.SyncSoruce,
                         EditLevel = savedata.EditLevel,
                         HierarchyId = savedata.HierarchyId,
                         Lineage = savedata.Lineage,
                         ParentListId = hierarchySpec.Node.ParentListId,
                         Status = savedata.Status,
                         Metastore = savedata.Metastore,
                         CreatedBy = savedata.CreatedBy,
                         CreatedOn = savedata.CreatedOn,
                         UpdatedBy = savedata.UpdatedBy,
                         UdpateOn = savedata.UdpateOn,
                         FromSubProvider = savedata.FromSubProvider,
                         IsSystem = savedata.IsSystem,
                         IsAvailableFromMap = savedata.IsAvailableFromMap,
                         IsExtended = savedata.IsExtended
                     };
                    context.PldListSettings.Add(newPdlListSettings);
                    context.SaveChanges();
                }
                else
                {
                    var newPdlListSettings = new PdlListSettings
                    {
                        ListId = GetMaxListId(),
                        ProviderId = hierarchySpec.Node.ProviderId,
                        Name = hierarchySpec.Node.Name,
                        ListType = "TREE",
                        CommonName = hierarchySpec.Node.CommonName,
                        IsSychronized = "N",
                        SyncSoruce = "",
                        EditLevel = 2,
                        HierarchyId = hierarchySpec.Node.HierarchyId,
                        Lineage = "/",
                        ParentListId = hierarchySpec.Node.ParentListId,
                        Status = "ORG",
                        FromSubProvider = "N",
                        IsSystem = "N",
                        IsAvailableFromMap = "N",
                        IsExtended = "N",
                    };
                    context.PldListSettings.Add(newPdlListSettings);
                    context.SaveChanges();
                }


                return true;
            }

        }
        public int GetMaxListId()
        {

            return SequenceHelper.GetSequence("TREELISTID");

        }

        public int GetHierarchyType(int providerId, HierarchySearchType hierarchyType)
        {
            using (var context = new AtHocDbContext())
            {

                var data = context.PldHierarchySettings.FirstOrDefault(p => p.ProviderId == providerId && p.Name.Contains(hierarchyType.ToString()));

                return data != null ? data.HierarchyId : 0;
            }
        }

        public PldHierarchySettings GetHierarchyDetails(int providerId, HierarchySearchType hierarchyType)
        {
            var data = new PldHierarchySettings();
            using (var context = new AtHocDbContext())
            {
                switch (hierarchyType)
                {
                    case HierarchySearchType.Organization:      // Organization Hierarchy
                        data = context.PldHierarchySettings.FirstOrDefault(p => p.ProviderId == providerId && p.HierarchyType == HierarchyType.ORG.ToString() && p.AvailableList == "N" && p.Status != "DEL");
                        break;
                    case HierarchySearchType.DistributionList:  // Distribution List
                        data = context.PldHierarchySettings.FirstOrDefault(p => p.ProviderId == providerId && p.HierarchyType == HierarchyType.ORG.ToString() && p.AvailableList == "Y" && p.Status != "DEL");
                        break;
                    case HierarchySearchType.IpList:            // IP List
                        data = context.PldHierarchySettings.FirstOrDefault(p => p.ProviderId == providerId && p.HierarchyType == HierarchyType.LOC.ToString() && p.Status != "DEL");
                        break;
                }
            }
            return data;
        }

        public bool IsValidHierarchyName(string HierarchyName, int HierarchyId, int providerId)
        {
            var isValid = false;
            using (var acontext = new AtHocDbContext())
            {
                string str = String.Format(SettingsSqlQueries.CheckHierarchyName, HierarchyName.Replace("'", "''").Trim(), HierarchyId, providerId);
                int count = acontext.Database.SqlQuery<int>(str).FirstOrDefault();
                if (count > 0)
                    isValid = true;
            }
            return isValid;
        }


        public void UpdateHierarchyAttributeName(HierarchySpec hierarchySpec, string attributeName)
        {
            using (var context = new AtHocDbContext())
            {
                var attributeId =
                    context.Database.SqlQuery<int>(SettingsSqlQueries.GetHierarchyAttributeId(hierarchySpec.ProviderId, (int) hierarchySpec.HierarchySearchType))
                        .AsQueryable()
                        .FirstOrDefault();
                var exists =
                    context.Database.SqlQuery<int>(SettingsSqlQueries.VerifyHierarchyName(attributeId, hierarchySpec.LocalCode)).AsQueryable().FirstOrDefault();
                context.Database.ExecuteSqlCommand(exists > 0
                    ? SettingsSqlQueries.UpdateHierarchyName(attributeId, attributeName, hierarchySpec.OperatorId,
                        hierarchySpec.LocalCode)
                    : SettingsSqlQueries.InsertHierarchyName(attributeId, attributeName, hierarchySpec.OperatorId,
                        hierarchySpec.LocalCode));
            }
        }
    }
}

