﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public class AuditActionFacade:IAuditActionFacade
    {
        IAuditActionRepository _auditActionRepository;
        public AuditActionFacade(IAuditActionRepository auditActionRepository)
        {
            _auditActionRepository = auditActionRepository;
        }

        public IEnumerable<AuditAction> GetAuditActionsByEntityId(string entityId)
        {
            return _auditActionRepository.GetAuditActionsByEntityId(entityId);
        }
    }
}
