﻿using System.Collections.Generic;
using System.IO;
using AtHoc.Infrastructure.Data;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.MediaServices;
using AtHoc.IWS.Business.Domain.Events;
using AtHoc.Publishing;
using System;

namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public interface IDeliveryTemplateRepository : IRepository<DeliveryTemplateModel, DeliveryTemplateCriteria> 
    {
        IEnumerable<DeliveryTemplateModel> GetDeliveryTemplates(DeliveryTemplateCriteria criteriaSpec);

        string UpdateLogoImage(Stream mediaData, MediaInfo wMediaInfo);
        IEnumerable<DeviceGroupSettings> GetDeviceGroups();
        TemplateDetailsModel GetTemplateDetails(int templateId);
        String GetDefautTemplateDefinitionBySeverity(int providerId, Priority severity, int deviceId);

        string GetDefaultTemplateId(int providerId, Priority severity, int deviceId, string locale);
        TemplateDetailsModel GetTemplateByCommonNane(string commonName);

        bool SaveDeliveryTemplateData(TemplateDetailsModel templateData);
    
        bool DeleteDeliveryTemplate(List<DeliveryTemplateModel> templateIds, int providerId);

        bool DuplicateDeliveryTemplate(List<DeliveryTemplateModel> templateIds, int providerId, int operatorId, string localeCode);

        bool IsValidCommonName(TemplateDetailsModel templateData);

        bool IsValidTemplateName(TemplateDetailsModel templateData);
        string GetCustomImage(string sGuidValue, string sImageType, int providerId);

        bool CreateDeliveryTemplate(TemplateDetailsModel templateData, int providerId, int operatorId);

        TemplateDetailsModel GetTemplateStyelSheet(int deviceGroupId, int providerId, string localeCode);

        ProviderSettings GetVPSDetails(int? providerId);
        DeliveryTemplateSettings GetLocaleDefaultDefinition(string locale, int deviceGroupId);
    }
}