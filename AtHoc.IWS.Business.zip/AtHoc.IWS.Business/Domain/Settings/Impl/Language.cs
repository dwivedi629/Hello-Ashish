﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Meta;

namespace AtHoc.IWS.Business.Domain.Settings.Model
{
   public  class Language
    {
        [MetaProperty(ColumnName = "LANGUAGE_LCID", DbTypeName = "nvarchar", MaxLength = 100, IsKey = true)]
       public string LanguageLCId { get; set; }

        [MetaProperty(ColumnName = "LANGUAGE_NAME", DbTypeName = "nvarchar", MaxLength = 100, IsKey = true)]
        public string LanguageName { get; set; }

        [MetaProperty(ColumnName = "LOCALE_CODE", DbTypeName = "nvarchar", MaxLength = 100, IsKey = true)]
        public string LocalCode { get; set; }

        [MetaProperty(ColumnName = "DEFAULT_DATE_FORMAT", DbTypeName = "nvarchar", MaxLength = 100, IsKey = true)]
        public string DefaultDateFormat { get; set; }

        [MetaProperty(ColumnName = "DEFAULT_TIME_FORMAT", DbTypeName = "nvarchar", MaxLength = 100, IsKey = true)]
        public string DefaultTimeFormat { get; set; }
        [MetaProperty(ColumnName = "ENABLE_FOR_OPERATOR_YN", DbTypeName = "nvarchar", MaxLength = 1, IsKey = true)]
        public string EnableForOperatorYN { get; set; }

        [MetaProperty(ColumnName = "DEFAULT_TIME_ZONE", DbTypeName = "nvarchar", MaxLength = 100, IsKey = true)]
        public string DefaultTimeZone{ get; set; }
      
    }
}
