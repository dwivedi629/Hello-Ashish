﻿using System.Collections.Generic;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public interface IHierarchyDefinitionRepository
    {
        IEnumerable<PdlListModel> GetHierarchy(HierarchySpec hierarchySpec);
        int GetHierarchyType(int providerId, HierarchySearchType hierarchyType);
        bool SaveNode(HierarchySpec hierarchySpec);
        bool AddNode(HierarchySpec hierarchySpec);
        bool DeleteNode(HierarchySpec hierarchySpec);
        bool IsValidHierarchyName(string HierarchyName, int HierarchyId, int providerId);
    }
}
