﻿using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Domain.Settings;

namespace AtHoc.IWS.Business.Mappings
{
    public class AudioFilesMapping : EntityTypeConfiguration<AudioFileSettings>
    {
        public AudioFilesMapping()
        {
            ToTable("CAT_AUDIO_TAB");
            HasKey(e => e.AudioId);
            Property(e => e.AudioId).HasColumnName("AUDIO_ID").HasDatabaseGeneratedOption(System.ComponentModel.DataAnnotations.Schema.DatabaseGeneratedOption.None);
            Property(e => e.AudioName).HasColumnName("AUDIO_NAME");
            Property(e => e.AudioGuid).HasColumnName("AUDIO_GUID");
            Property(e => e.ProviderId).HasColumnName("PROVIDER_ID");
            Property(e => e.AudioCommonName).HasColumnName("AUDIO_COMMON_NAME");
            Property(e => e.Description).HasColumnName("DESCRIPTION");
            Property(e => e.AudioBlob).HasColumnName("AUDIO_BLOB");
            Property(e => e.Format).HasColumnName("FORMAT");
            Property(e => e.Status).HasColumnName("STATUS");
            Property(e => e.LastUpdate).HasColumnName("LAST_UPDATE");
            Property(e => e.AudioType).HasColumnName("AUDIO_TYPE");
            Property(e => e.AudioText).HasColumnName("AUDIO_TEXT");
            Property(e => e.EntityType).HasColumnName("ENTITY_TYPE");
            Property(e => e.EntityId).HasColumnName("ENTITY_ID");
            Property(e => e.FileName).HasColumnName("FILE_NAME");
            Property(e => e.UpdatedBy).HasColumnName("UPDATED_BY");
            Property(e => e.CreatedBy).HasColumnName("CREATED_BY");
            Property(e => e.CreatedOn).HasColumnName("CREATED_ON");    

        }

     
    }
}
