﻿using System;
using System.Collections.Generic;
using AtHoc.IWS.Business.Configurations;
using System.Linq;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Audit;

namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public class HierarchyDefinitionFacade : IHierarchyDefinitionFacade
    {
       private readonly IHierarchyDefinitionRepository _hierarchyDefinitionrepository;
       private readonly GenerateJsonTree _treedata =new GenerateJsonTree();
   
       public HierarchyDefinitionFacade(IHierarchyDefinitionRepository hierarchyDefinitionrepository)
        {
            _hierarchyDefinitionrepository = hierarchyDefinitionrepository;
        }


       public PdlListModel GetHierarchy(HierarchySpec hierarchySpec)
       {
           IEnumerable<PdlListModel> data = _hierarchyDefinitionrepository.GetHierarchy(hierarchySpec);
           //return _treedata.GetGenerateJsonTree(hierarchytype, data);

           var hNode = (from m in data
                        where m.ListId == 0
                        select m).FirstOrDefault();           

           SetHierarchyTree(hNode, data);
           return hNode;
       }

        /// <summary>
        /// To format datasource to build tree
        /// </summary>
        /// <param name="hNode">Root node</param>
        /// <param name="data">data from database</param>
       private void SetHierarchyTree(PdlListModel hNode, IEnumerable<PdlListModel> data)
       {
           var hierarchyNodes = (from m in data
                            where m.ParentListId == hNode.ListId
                            select m).ToList();
           hNode.imageUrl = hierarchyNodes.Any() ? Constants.Groupimg : Constants.Individualimg;

           foreach (var xNode in hierarchyNodes)
           {
               if (!hNode.HasChildren)
                   hNode.Children = new List<PdlListModel>();

               hNode.Children.Add(xNode);

               var cList = (from m in data
                            where m.ParentListId == xNode.ListId
                            select m).ToList();
              
               xNode.imageUrl = cList.Any() ? Constants.Groupimg : Constants.Individualimg; 

               if (cList.Any())
               {                  
                   SetHierarchyTree(xNode, data);
               }              
           }
       }

       public bool SaveNode(HierarchySpec hierarchySpec)
       {
           bool blResult = _hierarchyDefinitionrepository.SaveNode(hierarchySpec);
           if (blResult && hierarchySpec.HierarchySearchType == HierarchySearchType.DistributionList)
           {
               //filtering the data to find the root node name
               var data = hierarchySpec.NodeList.Where(p => p.ListId == 0).AsQueryable();
               string rootNodeName;
               if (data.Any())
                   rootNodeName = data.ToList()[0].Name;
               else
                   rootNodeName = hierarchySpec.NodeList[0].Name;
               //default action status is Update
               var auditActionType = hierarchySpec.HierarchySearchType == HierarchySearchType.DistributionList ? ServiceAction.DistributionListUpdated : ServiceAction.LocationHierarchyUpdated;
               
               //Deleted status: check any Active Nodes are not there except Deleted Nodes
               if (!hierarchySpec.NodeList.Where(p => p.ListId != 0 && (p.Status == "M" || p.Status == "N")).Any() && hierarchySpec.NodeList.Where(p => p.Status == "D").Any())
                   auditActionType = hierarchySpec.HierarchySearchType == HierarchySearchType.DistributionList ? ServiceAction.DistributionListDeleted : ServiceAction.LocationHierarchyDeleted;
               //Created status: check only Added Nodes are exists
               else if (!hierarchySpec.NodeList.Where(p => p.ListId != 0 && (p.Status == "M" || p.Status == "D")).Any() && hierarchySpec.NodeList.Where(p => p.Status == "N").Any())
                   auditActionType = hierarchySpec.HierarchySearchType == HierarchySearchType.DistributionList ? ServiceAction.DistributionListCreated : ServiceAction.LocationHierarchyCreated;
               
               //Hierarcy Audit Log for each save                
               var auditSpec = new AuditSpec(hierarchySpec.OperatorId, hierarchySpec.ProviderId)
               {
                   Action = auditActionType,
                   ObjectType = (hierarchySpec.HierarchySearchType == HierarchySearchType.DistributionList ? EntityType.DistributionListHierarchy : EntityType.LocationHierarchy),
                   ObjectName = rootNodeName
               };
               OperationAuditor.LogAction(auditSpec);              
           }
           return blResult;
       }



       public bool DeleteNode(HierarchySpec hierarchySpec)
       {
           return _hierarchyDefinitionrepository.DeleteNode(hierarchySpec);

       }

       public bool AddNode(HierarchySpec hierarchySpec)
       {
           return _hierarchyDefinitionrepository.AddNode(hierarchySpec);
       }
        
       public bool IsValidHierarchyName(string HierarchyName, int HierarchyId, int providerId)
        {
            var blResult = _hierarchyDefinitionrepository.IsValidHierarchyName(HierarchyName,HierarchyId,providerId);
            return blResult;
        }
   
    }
}
