﻿using System.Collections.Generic;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Audit;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.Global.Resources.Interfaces;

namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public class ChannelManagerFacade : IChannelManagerFacade
    {

        private readonly IChannelManagerRepository _channelManagerRepository;
        IGlobalEntityLocaleFacade _globalEntityLocaleFacade;

        public ChannelManagerFacade(IChannelManagerRepository channelManagerRepository,IGlobalEntityLocaleFacade globalEntityLocaleFacade)
        {
            _channelManagerRepository = channelManagerRepository;
            _globalEntityLocaleFacade = globalEntityLocaleFacade;
        }

        /// <summary>
        /// Get Channel List based on search criteria
        /// </summary>
        /// <param name="criteriaSpec"></param>
        /// <returns>List of Channels</returns> 
        public IEnumerable<ChannelSettingsList> GetChannelList(ChannelCriteria criteriaSpec, string locale)
        {
            return _globalEntityLocaleFacade.GetLocalizedEntity(_channelManagerRepository.GetChannelList(criteriaSpec, locale), locale);
        }

        /// <summary>
        /// This method is used to Update Chennel Status
        /// </summary>
        /// <param name="criteriaSpec"></param>
        /// <returns>bool</returns>
        public bool UpdateChannelStatus(ChannelCriteria criteriaSpec)
        {
            bool blResult = _channelManagerRepository.UpdateChannelStatus(criteriaSpec);
            if (blResult)
            {
                //Record this action in Audit log
                var auditSpec = new AuditSpec(criteriaSpec.OperatorId, criteriaSpec.ProviderId)
                {
                    Action = (criteriaSpec.IsEnabled ? ServiceAction.SvcEnabled : ServiceAction.SvcDisabled),
                    ObjectType = EntityType.ServiceChannel,
                    ObjectName = criteriaSpec.ChannelIds.Count + " Folder record(s) were " + (criteriaSpec.IsEnabled ? "enabled" : "disabled")
                };
                OperationAuditor.LogAction(auditSpec);

            }
            return blResult;
        }

        /// <summary>
        /// This method is used to Update Chennel Status
        /// </summary>
        /// <param name="criteriaSpec"></param>
        /// <returns>bool</returns>
        public bool UpdateChannel(ChannelSettingsModel channelsettingsmodel, int OperatorId)
        {
            bool blResult = _channelManagerRepository.UpdateChannel(channelsettingsmodel, OperatorId);
            if (blResult)
            {
                //Record this action in Audit log
                var auditSpec = new AuditSpec(OperatorId, channelsettingsmodel.ChannelSettings.Provider_Id)
                {
                    Action = (channelsettingsmodel.ChannelSettings.Channel_Id > 0 ? ServiceAction.SvcUpdated : ServiceAction.SvcCreated),
                    ObjectType = EntityType.ServiceChannel,
                    ObjectName = channelsettingsmodel.ChannelSettings.Name
                };
                OperationAuditor.LogAction(auditSpec);

            }
            return blResult;
        }

        /// <summary>
        /// This method is used to delete the channel
        /// </summary>
        /// <param name="channelCriteria"></param>
        /// <returns></returns>
        public bool DeleteChannel(ChannelCriteria criteriaSpec)
        {
            bool blResult = _channelManagerRepository.DeleteChannel(criteriaSpec);
            if (blResult)
            {
                //Record this action in Audit log
                var auditSpec = new AuditSpec(criteriaSpec.OperatorId, criteriaSpec.ProviderId)
                {
                    Action = ServiceAction.SvcDeleted,
                    ObjectType = EntityType.ServiceChannel,
                    ObjectName = criteriaSpec.ChannelIds.Count + " Folder record(s) were deleted"
                };
                OperationAuditor.LogAction(auditSpec);

            }
            return blResult;
        }


        public bool DeleteFolder(int intChannelId,int ProviderId,int OperatorId)
        {
            bool blResult = _channelManagerRepository.DeleteFolder(intChannelId, ProviderId, OperatorId);
            if (blResult)
            {
                //Record this action in Audit log
                var auditSpec = new AuditSpec(OperatorId, ProviderId)
                {
                    Action = ServiceAction.SvcDeleted,
                    ObjectType = EntityType.ServiceChannel,
                    ObjectName =  "1 Folder record(s) were deleted"
                };
                OperationAuditor.LogAction(auditSpec);

            }
            return blResult;
        }

        /// <summary>
        /// This method will get Channel Details
        /// </summary>
        /// <param name="criteriaSpec"></param>
        /// <returns>ChannelSettingsModel</returns>
        public ChannelSettingsModel GetChannelDetails(ChannelCriteria criteriaSpec, string locale)
        {
            var channelSettingModel = _channelManagerRepository.GetChannelDetails(criteriaSpec);
            channelSettingModel.ChannelSettings = _globalEntityLocaleFacade.GetLocalizedEntity(channelSettingModel.ChannelSettings, locale);
            return channelSettingModel;
        }
        

        /// <summary>
        /// This method will check the dependencies between channel and alert
        /// </summary>
        /// <param name="channelIds">set of channel ids</param>
        /// <returns>List<int></returns>
        public List<int> IsAlertAssociated(List<int> channelIds)
        {
            return _channelManagerRepository.IsAlertAssociated(channelIds);
        }

       /// <summary>
       ///  To check whether channel name exists in Database with same name
       /// </summary>
       /// <param name="providerid"></param>
       /// <param name="ChannelId"></param>
       /// <param name="strName"></param>
       /// <returns>bool</returns>
        public bool IsUniqueFolderName(int providerid, int ChannelId, string strName)
        {
            return _channelManagerRepository.IsUniqueFolderName(providerid, ChannelId, strName);
        }

        
        public List<ChannelDependencyList> GetDependencyList(int ChannelId)
        {
            var channelSettingModel = _channelManagerRepository.GetDependencyList(ChannelId);           
            return channelSettingModel;
        }

        public bool IsSystemFolder(int channelId)
        {
            var flag = _channelManagerRepository.IsSystemFolder(channelId);           
            return flag;
        }
        
    }
}
