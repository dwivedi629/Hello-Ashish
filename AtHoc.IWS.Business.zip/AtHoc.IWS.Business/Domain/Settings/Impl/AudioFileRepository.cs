﻿using System;
using System.Collections.Generic;
using System.Linq;
using AtHoc.Data;
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Business.Domain.Events;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Settings.SqlQueries;
using AtHoc.Infrastructure.Extensions;
namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public class AudioFileRepository : IAudioFileRepository
    {

        /// <summary>
        /// Get audio files based on search criteria
        /// </summary>
        /// <param name="criteria">AudioSearchCriteria object </param>
        /// <returns>List of AudioFileSettingsModel</returns>
        ///
        public IEnumerable<AudioFileSettingsModel> GetAudioFileData(AudioSearchCriteria criteria)
        {
            using (var repository = new EntityFrameworkRepository(new AtHocDbContext()))
            {
                var data = repository.RunQuery<AudioFileSettingsModel>(
                    SettingsSqlQueries.GetAudioFileQuery(criteria.SearchString),
                    criteria.ProviderId).AsQueryable().ToList().Select(p => new AudioFileSettingsModel
                    {
                        AudioId = p.AudioId,
                        AudioName = p.AudioName,
                        Description = (p.Description ?? string.Empty),
                        AudioType = p.AudioType,
                        AudioCommonName = p.AudioCommonName,
                        AudioScope = p.AudioScope,
                        AudioOwner = p.ProviderId != criteria.ProviderId,
                        AudioSize = p.AudioBlob.Length / 1024,
                        Severity = p.Severity,
                        DefaultSeverity = p.DefaultSeverity,
                        Locale = p.Locale
                    });
                return data;
            }

        }


      /// <summary>
      /// Get Audio by Id
      /// </summary>
      /// <param name="audioFileId"></param>
      /// <param name="providerId"></param>
      /// <returns></returns>
        public AudioFileSettingsModel GetAudioFileDataById(int audioFileId, int providerId)
        {
            using (var db = new AtHocDbContext())
            {
                var audio = db.AudioFileSettings.FirstOrDefault(p => p.Audio_Id == audioFileId);
                return (new AudioFileSettingsModel
                {
                    AudioId = audio.Audio_Id,
                    AudioName = audio.Audio_Name,
                    Description = audio.Description,
                    AudioType = audio.Audio_Type,
                    AudioSize = (audio.Audio_Blob.Length) / 1024,
                    AudioOwner = audio.Provider_Id != providerId,
                    Severity = audio.Severity,
                    DefaultSeverity = audio.Default_Severity
                });
            }
        }

       /// <summary>
       /// Saving the audio fil data
       /// </summary>
       /// <param name="audioFileData"></param>
       /// <param name="operatorId"></param>
       /// <returns></returns>
        public int SaveAudioFileData(AudioFileSettingsModel audioFileData, int operatorId)
        {
            int audioId = 0;
            using (var db = new AtHocDbContext())
            {
                audioId = audioFileData.AudioId = GetNewAudioFileId();
                db.AudioFileSettings.Add(new AudioFileSettings
                {
                    Audio_Id = audioFileData.AudioId,
                    Audio_Name = audioFileData.AudioName,
                    Audio_Common_Name = audioFileData.AudioCommonName,
                    Audio_Guid = Guid.NewGuid().ToString(),
                    Audio_Blob = audioFileData.AudioBlob,
                    Provider_Id = audioFileData.ProviderId,
                    Format = Constants.AudioFormat,
                    Status = Constants.AudioStatus,
                    Description = audioFileData.Description,
                    Audio_Type = audioFileData.AudioType,
                    Entity_Type = Constants.AudioEntityType,
                    Created_On = DateTimeConverter.GetSystemTimeAsSeconds(),
                    Created_By = operatorId,
                    Severity = audioFileData.Severity ?? Severity.Unknown.ToString(),
                    Default_Severity = audioFileData.DefaultSeverity,
                    Locale_code = audioFileData.Locale,

                });
                db.SaveChanges();
                //reseting the default severity 
                if (audioFileData.DefaultSeverity == SettingsYN.Y.ToString())
                    UpdateAudioSeverityExists(audioFileData.Severity, audioFileData.AudioId, audioFileData.ProviderId, audioFileData.Locale);

            }
            return audioId;
        }

        /// <summary>
        /// Updating audio file
        /// </summary>
        /// <param name="audioFileData">AudioFileSettingsModel object</param>
        /// <returns>bool  true/false</returns>
        public bool UpdateAudioFileData(AudioFileSettingsModel audioFileData, int operatorId)
        {
            bool blSuccess = false;
            AudioFileSettings audio;
            using (var db = new AtHocDbContext())
            {
                audio = db.AudioFileSettings.FirstOrDefault(p => p.Audio_Id == audioFileData.AudioId);
                if (audio != null)
                {
                    audio.Audio_Name = audioFileData.AudioName;
                    audio.Description = audioFileData.Description;
                    audio.Audio_Common_Name = audioFileData.AudioCommonName;
                    if (audioFileData.AudioBlob != null)
                        audio.Audio_Blob = audioFileData.AudioBlob;
                    audio.Last_Update = DateTimeConverter.GetSystemTimeAsSeconds();
                    audio.Updated_By = operatorId;
                    audio.Severity = audioFileData.Severity;
                    audio.Default_Severity = audioFileData.DefaultSeverity.ToLower() == "true" ? "Y" : "N";
                    audio.Locale_code = audioFileData.Locale;
                    if (audio.Default_Severity == SettingsYN.Y.ToString())
                        UpdateAudioSeverityExists(audioFileData.Severity, audioFileData.AudioId,
                            audioFileData.ProviderId, audioFileData.Locale);
                    db.Entry(audio).State = System.Data.Entity.EntityState.Modified;
                    db.SaveChanges();
                    blSuccess = true;
                }
            }
            return blSuccess;
        }

        /// <summary>
        /// Deleting the audio files
        /// </summary>
        /// <param name="audioFileIds">Audio file ids</param>
        /// <param name="providerId">Provider Id</param>
        /// <param name="userId">User Id</param>
        /// <returns>bool true/false</returns>
        public bool DeleteAudioFiles(int[] audioFileIds, int providerId, int userId)
        {

            using (var db = new AtHocDbContext())
            {
                var audios = db.AudioFileSettings.Where(p => audioFileIds.Contains(p.Audio_Id) && p.Provider_Id == providerId).ToList();
                if (audios != null)
                {
                    audios.ForEach(p => { p.Status = "DEL"; p.Updated_By = userId; });
                    db.SaveChanges();
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Get New audioId of audio file
        /// </summary>
        /// <returns>New AUdio Id</returns>
        public int GetNewAudioFileId()
        {
            return SequenceHelper.GetSequence("AUDIO");
        }

        /// <summary>
        /// Get audio content by audioId
        /// </summary>
        /// <param name="audioId">Audio Id</param>
        /// <returns>Audio content in byes</returns>
        public byte[] DownloadAudioFile(int audioId)
        {
            using (var db = new AtHocDbContext())
            {
                var audioFileSettings = db.AudioFileSettings.SingleOrDefault(n => n.Audio_Id == audioId);
                if (audioFileSettings != null)
                {
                    var content = audioFileSettings.Audio_Blob;
                    return content;
                }
            }
            return null;
        }

        /// <summary>
        /// Ssaving audio file content 
        /// </summary>
        /// <param name="data">Content in bytes </param>
        /// <param name="audioId">Audio Id </param>
        /// <returns>bool true/false</returns>
        public bool UploadAudioFile(byte[] data, int audioId)
        {
            using (var db = new AtHocDbContext())
            {
                var audio = db.AudioFileSettings.FirstOrDefault(p => p.Audio_Id == audioId);
                if (audio != null)
                {
                    audio.Audio_Blob = data;
                    db.Entry(audio).State = System.Data.Entity.EntityState.Modified;
                    db.SaveChanges();
                   return true;
                }
            }
            return false;
        }

       /// <summary>
       /// 
       /// </summary>
       /// <param name="audio"></param>
       /// <returns></returns>
        public bool IsAudioNameExists(AudioFileSettingsModel audio)
        {
            using (var db = new AtHocDbContext())
            {
                using (var repository = new EntityFrameworkRepository(new AtHocDbContext()))
                {
                    var result = repository.RunQuery<int>(
                       SettingsSqlQueries.CheckAudioName,
                        audio.AudioName, audio.AudioId, audio.ProviderId).ToList();

                    if (EnumerableExtensions.HasValue(result) && result.FirstOrDefault() > 0)
                        return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Check audio common name is already existed
        /// </summary>
        /// <param name="name">Audio Common name </param>
        /// <returns>bool true/false</returns>
        public bool IsAudioCommonNameExists(AudioFileSettingsModel audio)
        {
            using (var repository = new EntityFrameworkRepository(new AtHocDbContext()))
            {
                var result = repository.RunQuery<int>(
                       SettingsSqlQueries.CheckAudioCommonName,
                        audio.AudioCommonName, audio.AudioId, audio.ProviderId).ToList();

                if (EnumerableExtensions.HasValue(result) && result.FirstOrDefault() > 0)
                    return  true;

            }
            return false;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="spec"></param>
        /// <returns></returns>
        public IEnumerable<AudioFileModel> GetAudioList(AudioSearchCriteria spec)
        {
            using (var dbContext = new AtHocDbContext())
            {

                object[] parameters = { spec.ProviderId, spec.SearchString.Join("|"), 0, 0,  spec.FilterByLocale ? 1 : 0,
                        (spec.OrderBy != null) ? spec.OrderBy.ToString() : "ASC" };
                var audioData = dbContext.Database
                    .SqlQuery<AudioFileModel>("DLV_GET_AUDIO_LIST {0},{1},{2},{3},{4},{5}", parameters)
                    .ToList();
                return audioData;

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Severity"></param>
        /// <param name="AudioId"></param>
        /// <param name="ProviderId"></param>
        /// <param name="LocaleCode"></param>
        public void UpdateAudioSeverityExists(string Severity, int AudioId, int? ProviderId, string LocaleCode)
        {
            using (var db = new AtHocDbContext())
            {
                var data = LocaleCode.ToUpper().Equals("ANY") ? db.AudioFileSettings.Where(p => p.Audio_Id != AudioId && p.Provider_Id == ProviderId && p.Severity == Severity && p.Default_Severity == SettingsYN.Y.ToString()) : db.AudioFileSettings.Where(p => p.Audio_Id != AudioId && p.Provider_Id == ProviderId && p.Severity == Severity && (p.Locale_code == LocaleCode || p.Locale_code == "Any") && p.Default_Severity == SettingsYN.Y.ToString());
                foreach (var audioFileSettings in data)
                {
                    audioFileSettings.Default_Severity = SettingsYN.N.ToString();
                    db.Entry(audioFileSettings).State = System.Data.Entity.EntityState.Modified;
                }
                db.SaveChanges();
            }

        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="providerId"></param>
        /// <returns></returns>
        public List<AudioDefaultSeverities> GetDefaultAudioSeverityData(int? providerId)
        {
            using (var repository = new AtHocDbContext())
            {
                var data = repository.Database.SqlQuery<AudioDefaultSeverities>(SettingsSqlQueries.GetDefaultAudioSeverityData(providerId)).ToList();

                return data;
            }
        }



    }
}
