﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.MediaServices;
using AtHoc.IWS.Business.Domain.Audit;

namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public class GeneralSettingsFacade:IGeneralSettingsFacade
    {
        private readonly IProviderRepository _providerrepository;

        public GeneralSettingsFacade(IProviderRepository providerrepository)
        {
            _providerrepository = providerrepository;
        }

        public GeneralSettings GetGeneralSettings(int providerId) 
        {
            return _providerrepository.GetGeneralSettings(providerId); 
        }
        public bool UpdateGeneralSettings(GeneralSettings data,  int operatorId)
        {
            bool blResult = _providerrepository.UpdateGeneralSettings(data);

            if (blResult)
            {
                var auditSpec = new AuditSpec(operatorId, data.ProviderId)
                {
                    Action = ServiceAction.UpdatedGeneralSettings,
                    ObjectType = EntityType.GeneralSettings,
                    ObjectName = data.ProviderName
                };
                OperationAuditor.LogAction(auditSpec);
            }

            return blResult;
        }

        public bool IsOrgCodeExists(int providerId, string orgCode)
        {
            return _providerrepository.IsOrgCodeExists(providerId, orgCode);
        }

        public bool IsVirtualNameExists(GeneralSettings data)
        {
            return _providerrepository.IsVirtualNameExists(data);
        }
    }
}
