﻿using System;
using System.Globalization;
using System.Linq;
using System.IO;
using System.Collections.Generic;
using AtHoc.Infrastructure.Database;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Settings.SqlQueries;
using AtHoc.Diagnostics;
using AtHoc.MediaServices;
using IUnitOfWork = AtHoc.Infrastructure.Data.IUnitOfWork;
using AtHoc.IWS.Business.Domain.Events;
using AtHoc.Publishing;
using System.Drawing;

namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public class DeliveryTemplateRepository : DbRepository<DeliveryTemplateModel, DeliveryTemplateCriteria>, IDeliveryTemplateRepository
    {
        public DeliveryTemplateRepository(IUnitOfWork context) : base(context) { }

        /// <summary>
        /// Get delivery Templates based on search criteria
        /// </summary>
        /// <param name="criteriaSpec"></param>
        /// <returns>List of DeliveryTemplateModel</returns>
        public IEnumerable<DeliveryTemplateModel> GetDeliveryTemplates(DeliveryTemplateCriteria criteriaSpec)
        {
            using (var dbContext = new AtHocDbContext())
            {
                var commonName = string.IsNullOrEmpty(criteriaSpec.DeviceGroupCommonName) ? string.Empty : criteriaSpec.DeviceGroupCommonName;
                object[] parameters = { criteriaSpec.ProviderId, criteriaSpec.DeviceGroupId, 0 };
                var deliveryQuery = dbContext.Database
                    .SqlQuery<DeliveryTemplateModel>("TPL_GET_DELIVERY_TEMPLATE_LIST {0},{1},{2}", parameters).AsQueryable();

                if (!string.IsNullOrEmpty(criteriaSpec.SearchString))
                    deliveryQuery = deliveryQuery
                        .Where(p => (p.Name.ToUpper().Contains(criteriaSpec.SearchString.ToUpper().Trim())));
                else if (!string.IsNullOrEmpty(criteriaSpec.DeviceGroupCommonName))
                    deliveryQuery = deliveryQuery
                        .Where(p => string.Equals(p.Device_Group_Common_Name, commonName));

                if (criteriaSpec.DefaultTemplateOnly)
                {
                    deliveryQuery = deliveryQuery
                        .Where(p => p.Default_Severity=="Y");
                }

                var deliveryList = deliveryQuery
                    .Select(
                        p =>
                            new DeliveryTemplateModel
                            {
                                Provider_Id = p.Provider_Id,
                                Template_Id = p.Template_Id,
                                Name = p.Name,
                                Device_Group_Name = p.Device_Group_Name,
                                Device_Group_Id = p.Device_Group_Id,
                                Device_Group_Common_Name = p.Device_Group_Common_Name,
                                Is_Standard = (p.Provider_Id == 3 ? "Standard" : "Common"),
                                Description = p.Description,
                                Scope = p.Scope,
                                IsOwner = (p.updated_by != null)
                                    ? (p.updated_by == criteriaSpec.OperatorId)
                                    : (criteriaSpec.OperatorId == p.created_by),
                                AlertStatus = (p.AlertStatus ?? SettingsYN.N.ToString()),
                                Severity = p.Severity??Severity.Unknown.ToString(),
                                Default_Severity = p.Default_Severity,
                                Locale_Code = p.Locale_Code,
                                Common_Name=p.Common_Name
                            }).ToList();

                return deliveryList;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<DeviceGroupSettings> GetDeviceGroups()
        {
            using (var db = new AtHocDbContext())
            {
                var data = db.DeviceGroupSettings.Where(p => Constants.DeviceGroupNames.Contains(p.DeviceGroupCommonName)).ToList();
                return data;
            }
        }

        /// <summary>
        /// Get DelveryTemplates by templateId
        /// </summary>
        /// <param name="templateId">templateId</param>
        /// <returns>TemplateDetailsModel object</returns>
        public TemplateDetailsModel GetTemplateDetails(int templateId)
        {
            using (var db = new AtHocDbContext())
            {
                var data = db.DeliveryTemplateSettings.FirstOrDefault(p => p.TemplateId == templateId);
                if (data == null)
                    return null;

                var gdata = db.DeviceGroupSettings.Where((p => p.DeviceGroupId == data.DeviceGroupId)).FirstOrDefault();

                return GetTemplateDetailsModel(data, gdata);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="severity"></param>
        /// <param name="deviceId"></param>
        /// <returns></returns>
        public String GetDefautTemplateDefinitionBySeverity(int providerId, Priority severity, int deviceId)
        {
            using (var db = new AtHocDbContext())
            {
              var data = db.Database
                    .SqlQuery<String>("select DEFINITION from dbo.TPL_GET_DEFAULT_TEMPLATE({0}, {1}, {2})", providerId, severity.ToString(), deviceId).AsQueryable().FirstOrDefault();
                return data;

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="severity"></param>
        /// <param name="deviceId"></param>
        /// <param name="locale"></param>
        /// <returns></returns>
        public string GetDefaultTemplateId(int providerId, Priority severity, int deviceId,string locale)
        {
            using (var db = new AtHocDbContext())
            {
                var data = db.Database
                    .SqlQuery<String>("select TEMPLATE_ID from dbo.TPL_GET_DEFAULT_TEMPLATE({0},{1},{2},{3})", providerId, severity.ToString(), deviceId, locale).AsQueryable().FirstOrDefault();
                return data;

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="commonName"></param>
        /// <returns></returns>
        public TemplateDetailsModel GetTemplateByCommonNane(string commonName)
        {
            using (var db = new AtHocDbContext())
            {
                var data = db.DeliveryTemplateSettings.FirstOrDefault(p => p.CommonName == commonName);
                if (data == null)
                    return null;

                var gdata = db.DeviceGroupSettings.Where((p => p.DeviceGroupId == data.DeviceGroupId)).FirstOrDefault();

                return GetTemplateDetailsModel(data, gdata);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="gdata"></param>
        /// <returns></returns>
        private TemplateDetailsModel GetTemplateDetailsModel(DeliveryTemplateSettings data, DeviceGroupSettings gdata)
        {
            return new TemplateDetailsModel
            {
                deviceGroupId = data.DeviceGroupId,
                templateId = data.TemplateId,
                providerId = data.ProviderId,
                name = data.Name,
                templateCommonName = data.CommonName,
                description = data.Description,
                templateDefinition = data.Definition,
                xmlConfiguration = data.XMLConfiguration,
                createdBy = (data.CreatedBy != null) ? data.CreatedBy.ToString() : string.Empty,
                updatedBy = (data.UpdatedBy != null) ? data.UpdatedBy.ToString() : string.Empty,
                createdOn = (data.CreatedOn != null) ? data.CreatedOn.ToString() : string.Empty,
                updatedOn = (data.UpdatedOn != null) ? data.UpdatedOn.ToString() : string.Empty,
                IsDesktopTemplate = (gdata != null && String.Equals(gdata.DeviceGroupCommonName, Constants.DesktopGroupCommonName, StringComparison.CurrentCultureIgnoreCase)),
                IsEmailTemplate = (gdata != null && String.Equals(gdata.DeviceGroupCommonName, Constants.EmailGroupCommonName, StringComparison.CurrentCultureIgnoreCase)),
                deviceGroupCommonName = gdata != null ? gdata.DeviceGroupCommonName : string.Empty,
                useAdvancedStyle = (gdata != null && String.Equals(gdata.DeviceGroupCommonName, Constants.DesktopGroupCommonName, StringComparison.CurrentCultureIgnoreCase)) ? SettingsYN.N.ToString() : SettingsYN.Y.ToString(),
                Severity = (data.Severity != null) ? data.Severity.ToString(CultureInfo.InvariantCulture) : Severity.Unknown.ToString(),
                DefaultSeverity = data.DefaultSeverity != null && data.DefaultSeverity.Equals(SettingsYN.Y.ToString()),
                TemplateDefaultSeverities = GetDefaultSeverityData(data.DeviceGroupId, data.ProviderId),
                LocaleCode = data.LocaleCode
            };

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="deviceGroupId"></param>
        /// <param name="providerId"></param>
        /// <returns></returns>
        public List<TemplateDefaultSeverities> GetDefaultSeverityData(int deviceGroupId, int? providerId)
        {
            using (var repository = new EntityFrameworkRepository(new AtHocDbContext()))
            {
                var data = repository.RunQuery<TemplateDefaultSeverities>(SettingsSqlQueries.GetDefaultSeverityData(deviceGroupId, providerId)).ToList();

                return data;
            }
        }

        /// <summary>
        /// saving Delivery Template
        /// </summary>
        /// <param name="deliveryTemplateData">NotifierTemplateModel object</param>
        /// <returns>bool  true/false</returns>
        public bool SaveDeliveryTemplateData(TemplateDetailsModel deliveryTemplateData)
        {
            bool blSuccess = false;
            using (var db = new AtHocDbContext())
            {
                var gdata = db.DeviceGroupSettings.Where((p => p.DeviceGroupId == deliveryTemplateData.deviceGroupId)).FirstOrDefault();
                var data = db.DeliveryTemplateSettings.FirstOrDefault(p => p.TemplateId == deliveryTemplateData.templateId);
                if (data != null)
                {
                    data.Definition = deliveryTemplateData.templateDefinition;
                    data.Name = deliveryTemplateData.name.Trim();
                    data.CommonName = deliveryTemplateData.templateCommonName.Trim();
                    if (deliveryTemplateData.description != null)
                        data.Description = deliveryTemplateData.description.Trim();
                    if (gdata != null)
                    {
                        if (gdata.DeviceGroupCommonName == Constants.DesktopGroupCommonName)
                            data.XMLConfiguration = deliveryTemplateData.xmlConfiguration;
                    }
                    data.Severity = deliveryTemplateData.Severity;
                    data.DefaultSeverity = deliveryTemplateData.DefaultSeverity ? SettingsYN.Y.ToString() : SettingsYN.N.ToString();
                    data.UpdatedOn = DateTimeConverter.GetSystemTime();
                    data.UpdatedBy = deliveryTemplateData.operatorId;
                    if (data.DefaultSeverity == SettingsYN.Y.ToString())
                    UpdateSeverityExists(deliveryTemplateData.Severity, deliveryTemplateData.deviceGroupId, deliveryTemplateData.templateId, deliveryTemplateData.providerId,deliveryTemplateData.LocaleCode);
                    data.LocaleCode = deliveryTemplateData.LocaleCode;
                    db.Entry(data).State = System.Data.Entity.EntityState.Modified;
                    db.SaveChanges();
                    blSuccess = true;
                }
            }
            return blSuccess;
        }

        /// <summary>
        /// Deleting the delivery Templates
        /// </summary>
        /// <param name="templateIds">templateIds</param>
        /// <param name="providerId">Provider Id</param>        
        /// <returns>bool true/false</returns>
        public bool DeleteDeliveryTemplate(List<DeliveryTemplateModel> templateIds, int providerId)
        {
            bool blSuccess = false;
            using (var db = new AtHocDbContext())
            {
                #region "Modify Notifier Template Data"
                var ndata = templateIds.Select(x => x.Template_Id).ToArray();
                if (ndata.Length > 0)
                {
                    var ndeletedata = db.DeliveryTemplateSettings.Where(p => ndata.Contains(p.TemplateId) && p.ProviderId == providerId).ToList();
                    if (ndeletedata.Count > 0)
                    {
                        foreach (DeliveryTemplateSettings item in ndeletedata)
                        {
                            item.status = "DEL";
                            db.Entry(item).State = System.Data.Entity.EntityState.Modified;
                        }
                        db.SaveChanges();
                        blSuccess = true;
                    }
                }
                #endregion "Modify Notifier Template Data"

            }
            return blSuccess;
        }

        /// <summary>
        /// Duplicate the delivery Templates
        /// </summary>
        /// <param name="templateIds">templateIds</param>
        /// <param name="providerId">Provider Id</param>        
        /// /// <param name="operatorId">Operator Id</param> 
        /// <returns>bool true/false</returns>
        public bool DuplicateDeliveryTemplate(List<DeliveryTemplateModel> templateIds, int providerId, int operatorId, string localeCode)
        {
            var ddata = templateIds.ToList();
            #region " Duplicate Delivery Template data"
            using (var db = new AtHocDbContext())
            {
                if (ddata.Count > 0)
                {
                    var dCreatedata = (from a in db.DeliveryTemplateSettings select a).AsEnumerable().Where(a => ddata.Any(j => j.Template_Id == a.TemplateId));
                    foreach (var item in dCreatedata)
                        CreateDuplicateDeviceTemplate(item, providerId, operatorId, localeCode);
                    return true;
                }
            }
            #endregion " Duplicate Delivery Template data"

            return false;
        }

        /// <summary>
        ///To get max templateId from DB
        /// </summary>
        /// <returns>int</returns>
        public int GetMaxTemplateId()
        {

            return AtHoc.Data.SequenceHelper.GetSequence("DEVICETEMPLATE");

        }

        /// To Create Duplicate Desktop Template Data in Database
        /// <summary></summary>
        /// <param name="data">DeliveryTemplateSettings object</param>
        /// <param name="providerId">Provider Id</param>        
        /// <param name="operatorId">Operator Id</param> 
        /// <returns></returns>
        public void CreateDuplicateDeviceTemplate(DeliveryTemplateSettings data, int providerId, int operatorId, string localeCode)
        {
            using (var context = new AtHocDbContext())
            {
                if (data != null)
                {
                    var newTemplateId = GetMaxTemplateId();
                    if ((data.Name.Contains('#')) && (data.Name.Contains(data.TemplateId.ToString())))
                        data.Name = ((data.Name.Substring(0, data.Name.LastIndexOf('#') == -1 ? data.Name.Length : data.Name.LastIndexOf('#'))) + " #" + newTemplateId);
                    else
                        data.Name = data.Name + " #" + newTemplateId;
                    data.TemplateId = newTemplateId;
                    data.CommonName = (data.Name.Replace(" ", "-"));
                    data.ProviderId = providerId;
                    data.CreatedBy = operatorId;
                    data.CreatedOn = DateTimeConverter.GetDateTimeFromSeconds(DateTimeConverter.GetSystemTimeAsSeconds());

                    if (data.DefaultSeverity.Equals(SettingsYN.Y.ToString()))
                    UpdateSeverityExists(data.Severity, data.DeviceGroupId, data.TemplateId, data.ProviderId,data.LocaleCode);
                    context.DeliveryTemplateSettings.Add(data);
                    context.SaveChanges();
                }

            }

        }

        /// <summary>
        /// To check whether common name exists in Database with same name
        /// </summary>
        /// <param name="templateData">IsValidCommonName object</param>        
        /// <returns>bool</returns>
        public bool IsValidCommonName(TemplateDetailsModel templateData)
        {
            var isValid = false;
            using (var acontext = new AtHocDbContext())
            {
                var str = String.Format(SettingsSqlQueries.CheckTemplateCommonName, templateData.templateId, templateData.templateCommonName.Replace("'", "''").Trim(), templateData.providerId, templateData.deviceGroupId);
                var count = acontext.Database.SqlQuery<int>(str).FirstOrDefault();
                if (count > 0)
                    isValid = true;
            }
            return isValid;
        }

        /// <summary>
        /// To check whether Template name exists in Database with same name
        /// </summary>
        /// <param name="templateData">NotifierTemplateModel object</param>        
        /// <returns>bool</returns>
        public bool IsValidTemplateName(TemplateDetailsModel templateData)
        {
            var isValid = false;
            using (var acontext = new AtHocDbContext())
            {
                var str = String.Format(SettingsSqlQueries.CheckTemplateName, templateData.name.Replace("'", "''").Trim(), templateData.templateId, templateData.providerId,templateData.deviceGroupId);
                var count = acontext.Database.SqlQuery<int>(str).FirstOrDefault();
                if (count > 0)
                    isValid = true;
            }
            return isValid;
        }

        /// <summary>
        /// get System or Custom Image data from the media database
        /// </summary>
        /// <param name="sGuidValue"></param>
        /// <param name="sImageType"></param>
        /// <param name="providerId"></param>
        /// <returns>string</returns>
        public string GetCustomImage(string sGuidValue, string sImageType, int providerId)
        {
            var logoStr = string.Empty;
            try
            {
                if (IsSystemDefaultImage(sImageType))
                {
                    using (var acontext = new AtHocDbContext())
                    {
                        sGuidValue = (from p in acontext.ProviderSettings
                                      where p.ProviderId == providerId
                                      select p.AlertImageId).FirstOrDefault();
                    }
                }

                // VPS does not have a logo
                if (string.IsNullOrEmpty(sGuidValue))
                    return string.Empty;

                MediaService svc = MediaService.Instance;
                var imgMedia = svc.GetMedia(new Guid(sGuidValue));
                // get the image as stream

                if (imgMedia != null)
                {
                    var imgStream = imgMedia.MediaContent.GetContent(); // convert back to Base64 string 
                    var base64Stream = new MemoryStream(); 
                    imgStream.CopyTo(base64Stream);
                    logoStr = ImageResize(base64Stream.ToArray());
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("unable to retrieve custom image in Delivery Template page.", ex);
            }
            return logoStr;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="imageType"></param>
        /// <returns></returns>
        private static bool IsSystemDefaultImage(string imageType)
        {
            return !string.IsNullOrEmpty(imageType) && imageType == "SYSTEM";
        }

        /// <summary>
        /// Save New DeliveryTemplateData in  database
        /// </summary>
        /// <param name="deliveryTemplateData">NotifierTemplateModel object</param>
        /// <param name="providerId">Provider Id</param>        
        /// <param name="operatorId">Operator Id</param> 
        /// <returns>bool</returns>
        public bool CreateDeliveryTemplate(TemplateDetailsModel deliveryTemplateData, int providerId, int operatorId)
        {

            using (var context = new AtHocDbContext())
            {
                if (deliveryTemplateData != null)
                {
                    var data = new DeliveryTemplateSettings
                    {
                        TemplateId = GetMaxTemplateId(),
                        DeviceGroupId = deliveryTemplateData.deviceGroupId,
                        DeviceId = deliveryTemplateData.deviceId,
                        ProviderId = providerId,
                        Name = deliveryTemplateData.name.Trim(),
                        CommonName = deliveryTemplateData.templateCommonName.Trim(),
                        Definition = deliveryTemplateData.templateDefinition,
                        Description = deliveryTemplateData.description,
                        XMLConfiguration = deliveryTemplateData.xmlConfiguration,
                        CreatedBy = operatorId,
                        CreatedOn = DateTimeConverter.GetDateTimeFromSeconds(DateTimeConverter.GetSystemTimeAsSeconds()),
                        status = SettingsStatus.ACT.ToString(),
                        Severity = deliveryTemplateData.Severity,
                        DefaultSeverity = deliveryTemplateData.DefaultSeverity ? SettingsYN.Y.ToString() : SettingsYN.N.ToString(),
                        LocaleCode = deliveryTemplateData.LocaleCode
                    };
                    if (data.DefaultSeverity.Equals(SettingsYN.Y.ToString()))
                        UpdateSeverityExists(deliveryTemplateData.Severity, deliveryTemplateData.deviceGroupId, deliveryTemplateData.DefaultTemplateId, deliveryTemplateData.providerId,deliveryTemplateData.LocaleCode);

                    context.DeliveryTemplateSettings.Add(data);
                    context.SaveChanges();
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="deviceGroupId"></param>
        /// <param name="providerId"></param>
        /// <param name="localeCode"></param>
        /// <returns></returns>
        public TemplateDetailsModel GetTemplateStyelSheet(int deviceGroupId, int providerId, string localeCode)
        {
            var rdata = new TemplateDetailsModel();
            using (var acontext = new AtHocDbContext())
            {
                var gdata = acontext.DeviceGroupSettings.Where((p => p.DeviceGroupId == deviceGroupId )).FirstOrDefault();

                if (gdata != null)
                {
                    rdata.deviceGroupId = gdata.DeviceGroupId;
                    rdata.deviceGroupCommonName = gdata.DeviceGroupCommonName;
                    rdata.deviceGroupName = gdata.DeviceGroupName;
                    rdata.providerId = providerId;
                    rdata.templateDefinition = string.Empty;
                    rdata.xmlConfiguration = string.Empty;
                    rdata.timeOutValue = Constants.DefaultTimeOutValue;
                    rdata.width = Constants.DefaultWidth;
                    rdata.height = Constants.DefaultHeight;
                    rdata.leftOffset = Constants.DefaultLeftOffset;
                    rdata.topOffset = Constants.DefaultTopOffset;
                    rdata.fullScreenYN = SettingsYN.Y.ToString();
                    rdata.titleColor = Constants.DefaultColor;
                    rdata.bodyColor = Constants.DefaultColor;
                    rdata.publishedByColor = Constants.DefaultColor;
                    rdata.publishedOnColor = Constants.DefaultColor;
                    rdata.templateBorderColor = Constants.DefaultColor;
                    rdata.templateBackgroundColor = Constants.DefaultBackGroundColor;
                    rdata.bodySize = Constants.DefaultFontSize;
                    rdata.publishedBySize = Constants.DefaultFontSize;
                    rdata.publishedOnSize = Constants.DefaultFontSize;
                    rdata.titleSize = Constants.DefaultTitleFontSize;
                    rdata.imgOption = Constants.CustomImageOption;
                    rdata.Severity = Severity.Unknown.ToString();
                    rdata.DefaultSeverity = false;
                    rdata.LocaleCode = Constants.DefaultLocale;
                    rdata.TemplateDefaultSeverities = GetDefaultSeverityData(rdata.deviceGroupId, rdata.providerId);
                    rdata.useAdvancedStyle = gdata.DeviceGroupCommonName == Constants.DesktopGroupCommonName ? SettingsYN.N.ToString() : SettingsYN.Y.ToString();
                    rdata.IsDesktopTemplate = (gdata.DeviceGroupCommonName == Constants.DesktopGroupCommonName);
                    rdata.IsEmailTemplate = (gdata.DeviceGroupCommonName == Constants.EmailGroupCommonName) ;
                    var data = GetLocaleDefaultDefinition(localeCode, deviceGroupId);
                    if (data != null)
                    {
                        rdata.templateDefinition = data.Definition;
                        rdata.xmlConfiguration = data.XMLConfiguration;
                    }
                }

            }
            return rdata;
        }

        /// <summary>
        /// To Update Logo Image w.r.t media Data & Media info in Db
        /// </summary>              
        /// <param name="mediaData">mediaData</param> 
        /// <param name="wMediaInfo">MediaInfo object</param>                
        /// <returns>string</returns>
        public string UpdateLogoImage(Stream mediaData, MediaInfo wMediaInfo)
        {
            Guid mediaId;
            var service = new MediaService();
            // create media content
            var content = service.CreateMedia(wMediaInfo, out mediaId);
            content.SetContent(mediaData);
            return Convert.ToString(mediaId);

        }

      /// <summary>
      /// 
      /// </summary>
      /// <param name="severity"></param>
      /// <param name="deviceGroupId"></param>
      /// <param name="defTemplateId"></param>
      /// <param name="providerId"></param>
      /// <param name="localeCode"></param>
        public void UpdateSeverityExists(string severity, int deviceGroupId, int defTemplateId, int? providerId ,string localeCode)
        {

            using (var db = new AtHocDbContext())
            {
                var data = db.DeliveryTemplateSettings.FirstOrDefault(p => p.TemplateId != defTemplateId && p.DeviceGroupId == deviceGroupId && p.ProviderId == providerId && p.Severity == severity && p.LocaleCode == localeCode && p.DefaultSeverity == SettingsYN.Y.ToString());
                if (data != null)
                {
                    data.DefaultSeverity = SettingsYN.N.ToString();
                    db.Entry(data).State = System.Data.Entity.EntityState.Modified;
                    db.SaveChanges();
                }
            }


        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="providerId"></param>
        /// <returns></returns>
        public ProviderSettings GetVPSDetails(int? providerId)
        {
            using (var db = new AtHocDbContext())
            {
                var providerData = db.ProviderSettings.FirstOrDefault(x => x.ProviderId == providerId);
                return providerData;
            }

        }

        public DeliveryTemplateSettings GetLocaleDefaultDefinition(string locale, int deviceGroupId)
        {
            using (var db = new AtHocDbContext())
            {
                var data = db.DeliveryTemplateSettings.FirstOrDefault(x => x.ProviderId == Constants.SystemVps && x.LocaleCode == locale && x.IsStandardTemplate=="Y" && x.DeviceGroupId==deviceGroupId );
                return data;
            }
        }

        public string ImageResize(byte[] data)
        {
            using (var ms = new MemoryStream(data))
            {
                var image = Image.FromStream(ms);
                var ratioX = (double)80 / image.Width;
                var ratioY = (double)72 / image.Height;
                var ratio = Math.Min(ratioX, ratioY);
                var width = (int)(image.Width * ratio);
                var height = (int)(image.Height * ratio);
                var newImage = new Bitmap(width, height);
                Graphics.FromImage(newImage).DrawImage(image, 0, 0, width, height);
                var bmp = new Bitmap(newImage);
                var converter = new ImageConverter();
                var bmpdata = (byte[])converter.ConvertTo(bmp, typeof(byte[]));
                return Convert.ToBase64String(bmpdata);
            }
        }

    }
}