﻿using System;
using System.Data;
using System.Linq;
using System.Collections.Generic;
using AtHoc.Data;
using AtHoc.Infrastructure.Sql;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Users;
using AtHoc.IWS.Business.Domain.Settings.SqlQueries;

namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public class ChannelManagerRepository : IChannelManagerRepository
    {

        /// <summary>
        /// Get Channel List based on search criteria
        /// </summary>
        /// <param name="criteriaSpec"></param>
        /// <returns>List of Channels</returns> 
        public IEnumerable<ChannelSettingsList> GetChannelList(ChannelCriteria criteriaSpec, string locale)
        {
            var channelData = new List<ChannelSettingsList>();
            channelData.AddRange(this.GetChannelsData(criteriaSpec, locale));
            return channelData;


        }

        /// <summary>
        /// This method is used to get all channels based on parameter value
        /// </summary>
        /// <returns>list of channels</returns>
        private IEnumerable<ChannelSettingsList> GetChannelsData(ChannelCriteria criteriaSpec, string locale)
        {

            using (var dbContext = new AtHocDbContext())
            {

                // Get all channels records
                var channelQuery = dbContext.Database.SqlQuery<ChannelSettingsList>(SettingsSqlQueries.getFolderQuery(criteriaSpec.ProviderId, 
                    criteriaSpec.OperatorId, SettingsSqlQueries.BuildPillsCondition(criteriaSpec.SearchString, " A.NAME "), 
                    locale, SettingsSqlQueries.BuildPillsCondition(criteriaSpec.SearchString, " ELT.ENTITY_VALUE "))).AsQueryable();

                var channelList = channelQuery
                    .Select(
                        p =>
                            new ChannelSettingsList
                            {
                                Meta_Store = p.Meta_Store,
                                Channel_Id = p.Channel_Id,
                                Common_Name = p.Common_Name,
                                Name = p.Name,
                                Provider_Name = p.Provider_Name,
                                Description = p.Description,
                                IsOwner = (p.Updated_By != null && p.Updated_By != 0) ? (p.Updated_By == criteriaSpec.OperatorId) : (criteriaSpec.OperatorId == p.Created_By),
                                Status = p.Status.Equals("ACT") ? "Enabled" : "Disabled",
                                Provider_Id = p.Provider_Id,
                                Created_On = p.Created_On,
                                Updated_On = p.Updated_On
                            }).Where(x => x.Status != "DEL").ToList();
                return channelList;
            }
        }

        /// <summary>
        /// This method is used to Update Chennel Status
        /// </summary>
        /// <param name="criteriaSpec"></param>
        /// <returns>bool</returns>
        public bool UpdateChannelStatus(ChannelCriteria criteriaSpec)
        {
            bool blSuccess = false;
            using (var db = new AtHocDbContext())
            {
                // Get existing record
                var gdata = db.ChannelSettings.Where(p => criteriaSpec.ChannelIds.Contains(p.Channel_Id)).ToList();
                // Update the record
                foreach (ChannelSettings data in gdata)
                    if (data != null)
                    {

                        data.Updated_On = DateTimeConverter.GetSystemTime();
                        data.Updated_By = criteriaSpec.OperatorId;
                        data.Status = criteriaSpec.IsEnabled ? "ACT" : "DSB";
                        db.Entry(data).State = System.Data.Entity.EntityState.Modified;
                        db.SaveChanges();
                        blSuccess = true;
                    }
            }
            return blSuccess;
        }

        /// <summary>
        /// This method is used to Delete Channel(s)
        /// </summary>
        /// <param name="criteriaSpec"></param>
        /// <returns>bool</returns>
        public bool DeleteChannel(ChannelCriteria criteriaSpec)
        {
            bool blSuccess = false;
            using (var db = new AtHocDbContext())
            {
                //Get existing record
                var gdata = db.ChannelSettings.Where(p => criteriaSpec.ChannelIds.Contains(p.Channel_Id)).ToList();
                // Delete the record
                foreach (ChannelSettings data in gdata)
                    if (data != null)
                    {
                        data.Status = "DEL";
                        db.Entry(data).State = System.Data.Entity.EntityState.Modified;
                        db.SaveChanges();
                        blSuccess = true;
                    }
            }
            return blSuccess;
        }

        /// <summary>
        /// This method will get Channel Details
        /// </summary>
        /// <param name="criteriaSpec"></param>
        /// <returns>ChannelSettingsModel</returns>
        public ChannelSettingsModel GetChannelDetails(ChannelCriteria criteriaSpec)
        {
            var channelSettings = new ChannelSettings();
            if (criteriaSpec.ChannelIds.Any())
            {
                using (var ngadDb = new NgadDatabase())
                {
                    //setting param
                    ngadDb.AddParameter("@providerId", criteriaSpec.ProviderId);
                    ngadDb.AddParameter("@operatorId", criteriaSpec.OperatorId);
                    ngadDb.AddParameter("@searchStr", criteriaSpec.SearchString);
                    ngadDb.AddParameter("@channelIdCsv", string.Join(",", criteriaSpec.ChannelIds));
                    ngadDb.AddParameter("@commonName", "");
                    ngadDb.CommandType = CommandType.StoredProcedure;
                    //Execute procedure
                    var row = ngadDb.ExecuteDataRow(@"ALT_CHANNEL_GET_BASIC_DETAILS");

                    //Creating object according to required field on UI
                    if (row != null)
                    {
                        channelSettings = new ChannelSettings
                        {
                            Channel_Id = Convert.ToInt32(row["CHANNEL_ID"].ToString()),
                            Common_Name = row["COMMON_NAME"].ToString(),
                            Name = row["NAME"].ToString(),
                            Description = row["DESCRIPTION"].ToString(),
                            Status = row["STATUS"].ToString().Equals("ACT") ? "Enabled" : "Disabled",
                            Updated_On = Convert.ToDateTime(row["UPDATED_ON"]),
                            Updated_By = Convert.ToInt32(row["UPDATED_BY"]),
                            Created_On = Convert.ToDateTime(row["CREATED_ON"]),
                            Created_By = Convert.ToInt32(row["CREATED_BY"]),
                            UpdatedByUsername = row["UPDATED_BY_USERNAME"].ToString(),
                            CreatedByUsername = row["CREATED_BY_USERNAME"].ToString(),
                            Meta_Store = Convert.ToString(row["Meta_Store"]),
                            Provider_Id = Convert.ToInt32(row["Provider_Id"]),
                            IsOwner = Convert.ToInt32(row["UPDATED_BY"]) != 0 ? (Convert.ToInt32(row["UPDATED_BY"]) == criteriaSpec.OperatorId) : (criteriaSpec.OperatorId == Convert.ToInt32(row["CREATED_BY"])),
                        };
                    }

                }
            }
            return new ChannelSettingsModel { ChannelSettings = channelSettings, ChannelGroupPermissions = null, ChannelGroups = null };
        }

        /// <summary>
        /// This method will Update Channel Details
        /// </summary>
        /// <param name="channelsettingsmodel"></param>
        /// <param name="OperatorId"></param>
        /// <returns>bool</returns>
        public bool UpdateChannel(ChannelSettingsModel channelsettingsmodel, int OperatorId)
        {
            bool blSuccess = false;
            var newChannelPermission = string.Empty;
            var lChannelId = 0;

            using (var ngadDb = new NgadDatabase())
            {

                if (channelsettingsmodel.ChannelSettings.Channel_Id > 0)
                    lChannelId = channelsettingsmodel.ChannelSettings.Channel_Id;
                else
                    newChannelPermission = "Mandatory";
                //get all attribute values
                var mnAcuAttributeValueId = GetProviderAcuGroupId(channelsettingsmodel.ChannelSettings.Provider_Id);
                ngadDb.AddParameter("@providerId", channelsettingsmodel.ChannelSettings.Provider_Id);
                ngadDb.AddParameter("@name", channelsettingsmodel.ChannelSettings.Name);
                ngadDb.AddParameter("@description", channelsettingsmodel.ChannelSettings.Description);
                ngadDb.AddParameter("@status",
                    channelsettingsmodel.ChannelSettings.Status.Equals("Enabled") ? "ACT" : "DSB");
                ngadDb.AddParameter("@commonName", channelsettingsmodel.ChannelSettings.Common_Name);
                ngadDb.AddParameter("@metaStore", channelsettingsmodel.ChannelSettings.Meta_Store);
                ngadDb.AddParameter("@operatorId", OperatorId);
                ngadDb.AddParameter("@attributeValueId", mnAcuAttributeValueId);
                ngadDb.AddParameter("@permissionLevel", newChannelPermission);
                var sysTime = ngadDb.AddParameter("@systemDate", DateTimeConverter.GetSystemTime());
                sysTime.DbType = DbType.DateTime2;
                //Set out parameters
                var ChannelId = ngadDb.AddParameter("@channelId", SqlDbType.Int, ParameterDirection.InputOutput);
                ChannelId.Value = lChannelId;
                ngadDb.CommandType = CommandType.StoredProcedure;
                ngadDb.ExecuteNonQuery(@"dbo.ALT_SET_CHANNEL_DETAILS");
                lChannelId = (int)ChannelId.Value;

                var groupIdCsv = string.Empty;
                var permissionLevelCsv = string.Empty;

                if (channelsettingsmodel.ChannelGroupPermissions != null)
                {
                    using (var ngadDbGroup = new NgadDatabase())
                    {
                        foreach (var group in channelsettingsmodel.ChannelGroupPermissions)
                        {
                            groupIdCsv = groupIdCsv + "," + group.ChannelGroups.GroupId;
                            if (group.GroupPermissions.isMandatory)
                                permissionLevelCsv = permissionLevelCsv + ",Mandatory";
                            if (group.GroupPermissions.isBlocked)
                                permissionLevelCsv = permissionLevelCsv + ",Blocked";
                            if (group.GroupPermissions.isDefault)
                                permissionLevelCsv = permissionLevelCsv + ",Default";
                            if (group.GroupPermissions.isOptional)
                                permissionLevelCsv = permissionLevelCsv + ",Optional";
                        }

                        ngadDbGroup.AddParameter("@channelId", lChannelId);
                        ngadDbGroup.AddParameter("@attributeValueIdCsv", groupIdCsv.Trim(','));
                        ngadDbGroup.AddParameter("@permissionLevelCsv", permissionLevelCsv.Trim(','));
                        ngadDbGroup.CommandType = CommandType.StoredProcedure;
                        ngadDbGroup.ExecuteNonQuery(@"dbo.ALT_SET_CHANNEL_PERMISSION");
                    }
                }
            }
            blSuccess = true;

            return blSuccess;
        }

        /// <summary>
        /// This method will get Provider Group Id
        /// </summary>
        /// <param name="providerId"></param>
        /// <returns>int</returns>
        public int GetProviderAcuGroupId(int providerId)
        {
            var acuAttributeValueId = 0;
            using (var ngadDb = new NgadDatabase())
            {
                const string providerAcuGroupSql = "select dbo.Get_Provider_Attribute_ValueID(@providerId,@attributeCommonName,@valueCommonName)";
                ngadDb.AddParameter("@providerId", SqlDbType.Int, providerId);
                ngadDb.AddParameter("@attributeCommonName", SqlDbType.VarChar, "SYSTEM-GROUPS");
                ngadDb.AddParameter("@valueCommonName", SqlDbType.VarChar, "ACU");

                ngadDb.CommandType = CommandType.Text;
                var row = ngadDb.ExecuteDataRow(providerAcuGroupSql);
                if (row != null)
                    acuAttributeValueId = int.Parse(row[0].ToString());
            }


            return acuAttributeValueId;
        }

        /// <summary>
        /// This method will check the dependencies between channel and alert
        /// </summary>
        /// <param name="channelIds">set of channel ids</param>
        /// <returns>List<int></returns>
        public List<int> IsAlertAssociated(List<int> channelIds)
        {
            List<int> associatedIds = new List<int>();
            using (var repository = new EntityFrameworkRepository(new AtHocDbContext()))
            {
                foreach (var item in channelIds)
                {
                    //checking if any channels dependent on alert
                    int isFound = repository.RunQuery<int>(SettingsSqlQueries.getAlertDependencyWithChannel(item)).
                        FirstOrDefault<int>();
                    if (isFound > 0)
                        associatedIds.Add(item);
                }
            }

            return associatedIds;
        }

        /// <summary>
        /// To check whether channel name exists in Database with same name
        /// </summary>
        /// <param name="templateData">IsUniqueFolderName object</param>        
        /// <returns>bool</returns>
        public bool IsUniqueFolderName(int providerid, int ChannelId, string strName)
        {
            var isValid = false;
            using (var acontext = new AtHocDbContext())
            {
                string str = String.Format(SettingsSqlQueries.CheckFolderUniqueName, providerid, ChannelId, strName.Replace("'", "''"));
                int count = acontext.Database.SqlQuery<int>(str).FirstOrDefault();
                if (count > 0)
                    isValid = true;
            }
            return isValid;
        }

        public bool IsSystemFolder(int ChannelId)
        {
            var isValid = false;
            using (var acontext = new AtHocDbContext())
            {
                string str = String.Format(SettingsSqlQueries.CheckIsSystemFolder, ChannelId);
                int count = acontext.Database.SqlQuery<int>(str).FirstOrDefault();
                if (count > 0)
                    isValid = true;
            }
            return isValid;
        }

        public List<ChannelDependencyList> GetDependencyList(int ChannelId)
        { 
            List<ChannelDependencyList> dependencyList = new List<ChannelDependencyList>();
             using (var ngadDb = new NgadDatabase())
                {
                    //setting param
                    ngadDb.AddParameter("@channelId",  ChannelId);
                    ngadDb.AddParameter("@includeLiveAndEndedAlert", 0);
                 
                    ngadDb.CommandType = CommandType.StoredProcedure;
                    //Execute procedure
                    var dt = ngadDb.ExecuteDataTable(@"DPN_ALERT_CHANNEL_CHECK");
                    //Creating object according to required field on UI
                    if (dt != null)
                    {
                        foreach(DataRow row in dt.Rows)
                        {
                            dependencyList.Add(
                                            new ChannelDependencyList
                                            {
                                               
                                                Id = Convert.ToInt32(row["ID"].ToString()),
                                                Type  = row["Type"].ToString(),
                                                Name = row["Name"].ToString(),
                                                OrgName = row["Organization"].ToString()                          
                                               
                                            });
                        }
                    } 
             }
             return dependencyList;
        }
        public bool DeleteFolder(int intChannelId, int ProviderId, int OperatorId)
        {
            bool isDeleteSuccess = false;
            using (var ngadDb = new NgadDatabase())
            {
                //setting param
                ngadDb.AddParameter("@channelId", intChannelId);
                ngadDb.AddParameter("@operatorId", OperatorId);

                ngadDb.CommandType = CommandType.StoredProcedure;
                //Execute procedure
                var result = ngadDb.ExecuteNonQuery(@"DPN_ALERT_CHANNEL_DELETE");
                isDeleteSuccess= result!=-1 ? true : false;
              
            }
            return isDeleteSuccess;
        }
       
    }

}