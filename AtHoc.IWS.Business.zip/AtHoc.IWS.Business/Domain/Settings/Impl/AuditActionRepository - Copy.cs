﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Configurations;

namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public class AuditActionRepository: IAuditActionRepository
    {
        public IEnumerable<AuditAction> GetAuditActionsByEntityId(string entityId)
        { 
            using(var db= new AtHocDbContext())
            {
                return db.AuditAction.Where(o => o.ActionId.Substring(0,3).Equals(entityId)).ToList();
            }
        }
    }
}
