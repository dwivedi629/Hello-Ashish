﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Domain.Settings.Model;

namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public interface IOperatorAuditRepository1
    {
        IEnumerable<OperatorAuditModel> GetOperatorAuditDetails(int providerId, string operatorName, string fromDate, string toDate, string entiryId, string actionId);

    }
}
