﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Settings.Model;

namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public interface ITargetingSettingsRepository
    {
        List<TargetingSettingsModel> GetTargetingSettings(int providerId);
        bool SaveTargetingSettings(List<TargetingSettingsModel> targetingSettings,int providerId,bool bridgeValue);
        bool GetCallBridgeSetting(int providerId);
        int FindHierarchyDisplayOrder(int providerId);
    }
}
