﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Domain.Settings.Model;

namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
  public   class LanguageFacade : ILanguageFacade
  {
      private readonly ILanguageRepository _languageRepository;

      public LanguageFacade(ILanguageRepository languageRepository)
        {
            _languageRepository = languageRepository;
        }

      public  string GetProviderLocale(int providerId)
      {
            var data = _languageRepository.GetProviderLocale(providerId);
          return data;
      }
      public IEnumerable<Language> GetLanguages()
      {

          var data = _languageRepository.GetLanguages();
          return data;

      }
      public IEnumerable<Language> GetOperatorEnabledLanguages()
      {
          var data = _languageRepository.GetOperatorEnabledLanguages();
          return data;
      }
      public IEnumerable<Language> GetDeliveryEnabledLanguages(int providerId)
      {
          var data = _languageRepository.GetDeliveryEnabledLanguages(providerId);
          return data;
      }

      public IEnumerable<Language> GetDeliveryEnabledLanguagesByHierarchy(int providerId)
      {
          var data = _languageRepository.GetDeliveryEnabledLanguagesByHierarchy(providerId);
          return data;
      }
    }
}
