﻿using System.Collections.Generic;
using System.Linq;
using AtHoc.d911.Model.Web;
using AtHoc.Infrastructure.Ioc;
using AtHoc.Infrastructure.Ioc.SimpleInjector;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Settings.SqlQueries;

namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
  public  class LanguageManager
    {
      private readonly ILanguageRepository _languageRepository;
     
      
     /// <summary>
     /// /
     /// </summary>
     /// <param name="providerId"></param>
     /// <returns></returns>
      public static string GetProviderLocale(int providerId)
      {
          if (ServiceLocator.Current == null)
          {
              ServiceLocator.Current = new SimpleInjectorServiceLocator();
              ServiceLocator.Current.LoadAll();
          }
          using (var dbContext = new AtHocDbContext())
          {
              var resultValue = dbContext.Database.SqlQuery<string>(SettingsSqlQueries.GetProviderLocale(providerId)).ToList().FirstOrDefault();
              return resultValue;
          }
      }
      
      /// <summary>
      /// 
      /// </summary>
      /// <returns></returns>
      public static  List<Language> GetOperatorEnabledLanguages()
      {
          if (ServiceLocator.Current == null)
          {
              ServiceLocator.Current = new SimpleInjectorServiceLocator();
              ServiceLocator.Current.LoadAll();
          }
          using (var db = new AtHocDbContext())
          {
              var data = db.Language.Where(e => e.EnableForOperatorYN.ToUpper().Equals("Y"));
              return data.ToList();
              }
      }
    }
}
