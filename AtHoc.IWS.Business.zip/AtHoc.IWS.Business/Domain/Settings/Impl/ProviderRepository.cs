﻿using System;
using System.Linq;
using System.IO;
using System.Data.Entity;
using System.Collections.Generic;
using AtHoc.Data;
using AtHoc.Infrastructure.Log;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Settings.SqlQueries;
using AtHoc.MediaServices;
using AtHoc.Infrastructure.Extensions;
using AtHoc.ComProviders;
using System.Xml;
using AtHoc.Operators;
using AtHoc.VirtualSystems.Duplication;
using FeatureMatrix = AtHoc.IWS.Business.Domain.Settings.Model;
namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public class ProviderRepository : IProviderRepository
    {
        private readonly ILogService _logService;
        private IEnumerable<bool> _enumerable;
        private const int sysProviderId = 3;

        public ProviderRepository(ILogService logService)  
        {
         
            _logService = logService;
            
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<ProviderSettingsModel> GetProviderData()
        {
            using (var db = new AtHocDbContext())
            {
                return db.ProviderSettings.Select(p => new ProviderSettingsModel { ProviderId = p.ProviderId, ProviderName = p.ProviderName, ProvideType = p.ProviderTypeId, ProviderStatus = p.ProviderStatusId }).ToList();
            }
        }

        /// <summary>
        /// This method is to get all provider number for organization manager
        /// </summary>
        /// <returns>collection of providers</returns>
        public IEnumerable<ProviderSettingsModel> GetOrganizationList(int providerId, Entities.VPSType operatorType, List<string> strSearchText)
        {
            // return null;
            // return null;
            using (var db = new AtHocDbContext())
            {

                var objsysParam = new AtDacSysParamsInterop();

                var result = db.ProviderSettings.Where(t => (t.IsEnt != "" || t.IsEnt != null) && (t.ProviderId != sysProviderId)).Select(p => new ProviderSettingsModel { ProviderId = p.ProviderId, ProviderName = p.ProviderName, ProviderStatus = p.ProviderStatusId, EntProviderId = (p.EntProviderId.HasValue ? p.EntProviderId.Value : 0), CreatedOn = p.LaunchDate.Value, IsEnterprise = (p.IsEnt == "Y" ? true : false), ProductStatus = p.ProductStatus, DisplayName = p.DisplayName, HomeURL = p.ProviderUrl }).ToList();


                // This will work only for enterprise
                if (Entities.VPSType.System != operatorType)
                    result = result.Where(p => ((p.EntProviderId == providerId) && (p.IsEnterprise == false))).ToList();
                else // This will work only for system vps login
                    result = result.Where(p => (p.IsEnterprise == true)).ToList();

                // Set provider Type and Time zone.
                result.ToList<ProviderSettingsModel>().ForEach(a =>
                {
                    a.ProvideType = (
                            GetProviderType(a.ProviderId)
                        );
                    a.TimeZone = (
                         objsysParam.TimeZoneName(objsysParam.TimeZoneId(a.ProviderId))
                     );
                    a.DefaultLocale = GetProviderLocale(a.ProviderId);
                });


                // This is for search functionality
                if (strSearchText != null && strSearchText.Count > 0)
                    result = this.SearchOrgInfo(strSearchText, result);

                return result;
            }
        }

        /// <summary>
        /// To get the provider list of Enterprice VPS.
        /// </summary>
        /// <param name="providerId">Ent provider Id.</param>
        /// <returns>ProviderList.</returns>
        public Dictionary<int, string> GetEnterpriseProviderList(int providerId)
        {
            using (var db = new AtHocDbContext())
            {

                var providerList =
                    db.ProviderSettings.Where(t => (t.EntProviderId == providerId || t.ProviderId == providerId))
                        .ToDictionary(p => p.ProviderId, p => p.ProviderName);

                return providerList;
            }
           
        }
        /// <summary>
        /// This method will be used to search the provider details based on search text.
        /// </summary>
        /// <param name="searchString"></param>
        /// <param name="provideInfo"></param>
        /// <returns>Collection of records</returns>
        private List<ProviderSettingsModel> SearchOrgInfo(List<String> searchString, IEnumerable<ProviderSettingsModel> provideInfo)
        {
            #region local variables
            List<ProviderSettingsModel> _provideInfo = new List<ProviderSettingsModel>();
            int count = 0;
            int childCount = 0;
            #endregion 
            while (searchString.Count > count)
            {
                var strFilter = searchString[count];
                var arrFilter = new List<string>();
                arrFilter.AddRange(strFilter.Split(','));
                provideInfo = provideInfo.Where(o => arrFilter.Any(y => o.ProviderName.ToLower().Contains(y.ToLower().Trim()) || o.ProviderId.ToString().Contains(y.ToLower().Trim())));
                count++;
            }
            _provideInfo = provideInfo.ToList<ProviderSettingsModel>();
            return _provideInfo;
        }


        /// <summary>
        /// This method will use to get provideer type
        /// </summary>
        /// <param name="providerId"></param>
        /// <returns></returns>
        private string GetProviderType(int providerId)
        {
            using (var repository = new EntityFrameworkRepository(new AtHocDbContext()))
            {
                var result = repository.RunQuery<String>(
                       SettingsSqlQueries.GetProviderType, providerId).ToList();

                if (EnumerableExtensions.HasValue(result))
                    return result.FirstOrDefault();

            }

            return string.Empty;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="providersettings"></param>
        /// <returns></returns>
        public bool SaveSubAccountManagers(ProviderSettingsModel providersettings)
        {
            using (var context = new AtHocDbContext())
            {
                var providerdata = context.ProviderSettings.FirstOrDefault(x => x.ProviderId == providersettings.ProviderId);
                if (providerdata != null)
                {
                    providerdata.ProviderName = providersettings.ProviderName;
                    context.Entry(providerdata).State = EntityState.Modified;
                    context.SaveChanges();
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="providerId"></param>
        /// <returns></returns>
        public bool CreateDuplicateSubAccountManagers(int providerId)
        {
            using (var context = new AtHocDbContext())
            {
                var providerdata =
                    context.ProviderSettings.Where(x => x.ProviderId == providerId)
                        .AsNoTracking()
                        .FirstOrDefault();
                if (providerdata != null)
                {
                    var newProvider = new ProviderSettings
                    {
                        ProviderName = "Copy of" + providerdata.ProviderName,
                        ProviderId = GetMaxProviderId(),
                        ProductStatus = "",
                        ProviderGuid = Guid.NewGuid().ToString(),
                        IsForceClientUpdate = providerdata.IsForceClientUpdate,
                        IsSystrayVisible = providerdata.IsSystrayVisible,
                        IsCorporate = providerdata.IsCorporate,
                        IsDemo = providerdata.IsDemo,
                        StyleVersion = providerdata.StyleVersion,
                        IsSpsDirect = providerdata.IsSpsDirect,
                        IsQueSignOn = providerdata.IsQueSignOn,
                        ProviderTypeId = providerdata.ProviderTypeId,
                        ProviderUrl = providerdata.ProviderUrl,
                        ProviderStatusId = providerdata.ProviderStatusId,
                    };
                    context.ProviderSettings.Add(newProvider);
                    context.SaveChanges();
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="providerName"></param>
        /// <returns></returns>
        public bool CreateSubAccountManagers(string providerName)
        {

            using (var context = new AtHocDbContext())
            {
                #region "inserting new subaccountmanager settings in the PROVIDER_SYS_TAB"
                var providerdata = context.ProviderSettings.Where(x => x.ProviderId == 5).AsNoTracking().FirstOrDefault();


                if (providerdata != null)
                {
                    var newProvider = new ProviderSettings
                   {
                       ProviderName = providerName,
                       ProviderId = GetMaxProviderId(),
                       ProductStatus = string.Empty,
                       ProviderGuid = Guid.NewGuid().ToString(),
                       IsForceClientUpdate = providerdata.IsForceClientUpdate,
                       IsSystrayVisible = providerdata.IsSystrayVisible,
                       IsCorporate = providerdata.IsCorporate,
                       IsDemo = providerdata.IsDemo,
                       StyleVersion = providerdata.StyleVersion,
                       IsSpsDirect = providerdata.IsSpsDirect,
                       IsQueSignOn = providerdata.IsQueSignOn,
                       ProviderTypeId = providerdata.ProviderTypeId,
                       ProviderUrl = providerdata.ProviderUrl,
                       ProviderStatusId = providerdata.ProviderStatusId,
                   };


                    context.ProviderSettings.Add(newProvider);
                    context.SaveChanges();

                    return true;

                }
                #endregion "inserting new subaccountmanager settings in the PROVIDER_SYS_TAB"

            }
            return false;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public int GetMaxProviderId()
        {
            using (var context = new AtHocDbContext())
            {
                var maxProviderId = context.ProviderSettings.Select(r => r.ProviderId).Max();
                return (maxProviderId + 1);
            }
        }



        /// <summary>
        /// Get general settings data based on providerId
        /// </summary>
        /// <param name="providerId">ProviderId</param>
        /// <returns></returns>
        public GeneralSettings GetGeneralSettings(int providerId)
        {
            var generalSettings = new GeneralSettings();
            using (var db = new AtHocDbContext())
            {
                var providerData = db.ProviderSettings.FirstOrDefault(x => x.ProviderId == providerId);
                generalSettings.ProviderId = providerId;
                if (providerData != null)
                {
                    generalSettings.ProviderName = providerData.ProviderName;
                    generalSettings.SelfServiceUrl = ConfigurationManager.GetURL();
                    generalSettings.SelfServiceUrl += Constants.SelfServiceUrl;
                    generalSettings.DisplayName = providerData.DisplayName;
                    generalSettings.DateFormat = providerData.DateFormat;
                    generalSettings.TimeFormat = providerData.TimeFormat;
                    generalSettings.WebImageId = providerData.WebImageId;
                    generalSettings.AlertImageId = providerData.AlertImageId;
                    generalSettings.RegisterName = Constants.Registration;
                    generalSettings.IsEnterpriseWithSubs = IsEnterpriseWithSubs(providerId);
                }
                var pcs =
                    db.ProviderConfigurationSetting.FirstOrDefault(
                        x => x.ProviderId == providerId && x.Keyname == Constants.IsUserUniqueAcrossEnterprise);
                if (pcs!=null && pcs.Value == "True")
                    generalSettings.IsUserUniqueAcrossEnterprise = true;

                var providerExtendedData = db.ProviderExtendedSettings.FirstOrDefault(x => x.ProviderId == providerId);
                if (providerExtendedData != null)
                {
                    generalSettings.WelcomeMesssage = providerExtendedData.WelcomeMessage;
                    generalSettings.InformationBanner = providerExtendedData.InformationBanner;
                    generalSettings.TimeZoneRegionId = providerExtendedData.TimeZoneRegionId;
                    generalSettings.WebImageText = providerExtendedData.WebImageAlternateText;
                    generalSettings.SupportEmail = providerExtendedData.SupportEmail;
                    generalSettings.TermsConditionsUrl = providerExtendedData.TermsAndConditionsLink;
                    generalSettings.CallId = providerExtendedData.CallerId;
                    generalSettings.CountryCode = providerExtendedData.CountryCode;
                    generalSettings.OrgCode = providerExtendedData.OrgCode;
                    generalSettings.IsoCountryCode = providerExtendedData.IsoCountryCode;
                    generalSettings.SSSecurityDisclaimerText = string.IsNullOrEmpty(providerExtendedData.SSSecurityDisclaimerText) ? "" : providerExtendedData.SSSecurityDisclaimerText;
                   //generalSettings.SSSecurityDisclaimerEnabled = !string.IsNullOrEmpty(providerExtendedData.SSSecurityDisclaimerEnabled) && providerExtendedData.SSSecurityDisclaimerEnabled.ToUpper().Equals("Y");
                    if (providerData != null && providerData.IsSelfRegistration.ToUpper().Equals("Y") && providerExtendedData.SsAuthOption.ToUpper().Equals(Constants.AtHocUser))
                        generalSettings.IsAuthUser = true;
                }
                // Get Language Settings
                generalSettings.EnabledLanguages = GetEnabledLanguages(providerId);
            }
            return generalSettings;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="providerId"></param>
        /// <returns></returns>
        public List<EnableLanguage> GetEnabledLanguages(int providerId)
        {
            using (var dbContext = new AtHocDbContext())
            {
                var resultValue = dbContext.Database.SqlQuery<EnableLanguage>(SettingsSqlQueries.GetEnabledLanguages(providerId)).ToList();
                return resultValue;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="languageXml"></param>
        /// <param name="enabledlanguages"></param>
        /// <returns></returns>
        public string setLanguageSettings(string languageXml, List<EnableLanguage> enabledlanguages)
        {
            var xsltData = new XmlDocument();
            xsltData.LoadXml(languageXml);

            foreach (var language in enabledlanguages)
            {
                var node = xsltData.SelectSingleNode(string.Format("/languages/language [code='{0}']/enableForPublish", language.Code));
                if (node != null)
                    node.InnerText = language.IsEnabled ? "Y" : "N";
            }

            return xsltData.InnerXml;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="languageXml"></param>
        /// <returns></returns>
        public List<EnableLanguage> GetLanguageSettings(string languageXml)
        {
            var xsltData = new XmlDocument();
            xsltData.LoadXml(languageXml);
            var languages = new List<EnableLanguage>();
            var languageNodes = (XmlNode)xsltData.SelectSingleNode("//languages");
            if (languageNodes != null && languageNodes.ChildNodes.Count > 0)
            {
                foreach (XmlNode tempNode in languageNodes.ChildNodes)
                {
                    if (tempNode.SelectSingleNode("code") != null)
                    {
                        var codeNode = tempNode.SelectSingleNode("code");
                        var nameNode = tempNode.SelectSingleNode("displayName");
                        var publishNode = tempNode.SelectSingleNode("enableForPublish");
                        var enableForPublish = publishNode != null && (publishNode.InnerText == "Y" ? true : false);
                        if (codeNode != null)
                        {
                            var language = new EnableLanguage();
                            language.Name = nameNode.InnerText;
                            language.Code = codeNode.InnerText;
                            language.IsEnabled = enableForPublish;
                            languages.Add(language);
                        }
                      
                    }
                }
            }

            return languages;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public bool UpdateGeneralSettings(GeneralSettings data)
        {
            using (var db = new AtHocDbContext())
            {
                var providerData = db.ProviderSettings.FirstOrDefault(x => x.ProviderId == data.ProviderId);
                if (providerData != null)
                {
                    providerData.ProviderName = data.ProviderName;
                    providerData.DisplayName = data.DisplayName;
                    providerData.DateFormat = data.DateFormat;
                    providerData.TimeFormat = data.TimeFormat;
                    providerData.ProviderVersion = GetProviderVersion();
                    db.Entry(providerData).State = EntityState.Modified;
                    var providerExtendedData = db.ProviderExtendedSettings.FirstOrDefault(x => x.ProviderId == data.ProviderId);
                    if (providerExtendedData != null)
                    {
                        providerExtendedData.SupportEmail = data.SupportEmail;
                        providerExtendedData.WelcomeMessage = data.WelcomeMesssage ?? string.Empty;
                        providerExtendedData.InformationBanner = data.InformationBanner;
                        providerExtendedData.TimeZoneRegionId = data.TimeZoneRegionId;
                        providerExtendedData.WebImageAlternateText = data.WebImageText ?? string.Empty;
                        providerExtendedData.DisplayLogoOnWebApp = "Y";
                        providerExtendedData.OrgCode = data.OrgCode ?? string.Empty;
                        providerExtendedData.CountryCode = (data.CountryCode != null) ? data.CountryCode : "+1";
                        providerExtendedData.CallerId = data.CallId;
                        providerExtendedData.IsoCountryCode = data.IsoCountryCode;
                        providerExtendedData.SSSecurityDisclaimerText = data.SSSecurityDisclaimerText;
                      //providerExtendedData.SSSecurityDisclaimerEnabled = data.SSSecurityDisclaimerEnabled?"Y":"N";
                        db.Entry(providerData).State = EntityState.Modified;
                    }
                    var enableLanguages = data.EnabledLanguages.Where(x => x.IsEnabled).Select(p => p.Code).ToArray();
                    var providerLocaleData = db.ProviderLocaleSettings.Where(x => x.ProviderId == data.ProviderId && enableLanguages.Contains(x.LocaleCode)).ToList();
                    if (providerLocaleData.Count > 0)
                    {
                        foreach (ProviderLocaleSettings item in providerLocaleData)
                        {
                            item.EnablePublish = "Y";
                            db.Entry(item).State = EntityState.Modified;
                        }
                    }
                    if (data.WebImageData != null)
                        providerData.WebImageId = UpdateLogoImage(data.WebImageData, data.WebImageType, data.WebImageExtension);
                    if (data.AlertImageData != null)
                        providerData.AlertImageId = UpdateLogoImage(data.AlertImageData, data.AlertImageType,
                            data.AlertImageExtension);

                    var pcs = db.ProviderConfigurationSetting.FirstOrDefault(e => e.ProviderId == data.ProviderId && e.Keyname == Constants.IsUserUniqueAcrossEnterprise);
                    if (pcs != null)
                    {
                        pcs.Value = data.IsUserUniqueAcrossEnterprise ? "True" : "False";
                        db.Entry(pcs).State = System.Data.Entity.EntityState.Modified;
                        db.SaveChanges();
                    }
                    else
                    {
                        if (data.IsUserUniqueAcrossEnterprise && data.IsEnterpriseWithSubs)
                        {
                            var pc = new ProviderConfigurationSettings();
                            pc.ProviderId = data.ProviderId;
                            pc.GroupId = "Features Matrix";
                            pc.Keyname = "IsUserUniqueAcrossEnterprise";
                            pc.Value = "True";
                            db.Entry(pc).State = System.Data.Entity.EntityState.Added;
                            db.SaveChanges();
                        }
                    }
                }

                db.SaveChanges();
                return true;
            }
        }

        /// <summary>
        /// Check Oraganization code is already existed
        /// </summary>
        /// <param name="providerId">IsOrgCodeExists Setting</param>
        /// /// <param name="orgCode">General Setting</param>
        /// <returns>true/false</returns>
        public bool IsOrgCodeExists(int providerId, string orgCode)
        {
            using (var repository = new EntityFrameworkRepository(new AtHocDbContext()))
            {
                var result = repository.RunQuery<int>(
                       SettingsSqlQueries.CheckOrgCode,
                       orgCode, providerId).ToList();

                if (EnumerableExtensions.HasValue(result) && result.FirstOrDefault() > 0)
                    return true;
            }

            return false;
        }

        /// <summary>
        /// Check Providername is already existed
        /// </summary>
        /// <param name="data">General Setting</param>
        /// <returns>true/false</returns>
        public bool IsVirtualNameExists(GeneralSettings data)
        {
            bool blSuccess = false;

            using (var repository = new EntityFrameworkRepository(new AtHocDbContext()))
            {
                var result = repository.RunQuery<int>(
                       SettingsSqlQueries.CheckVirtualName,
                        data.ProviderName, data.ProviderId).ToList();

                if (EnumerableExtensions.HasValue(result) && result.FirstOrDefault() > 0)
                    blSuccess = true;

            }
            return blSuccess;
        }

        /// <summary>
        /// Check Providername is already existed
        /// </summary>
        /// <param name="data">General Setting</param>
        /// <returns>true/false</returns>
        private string GetFinalOrgName(OrgManagerSettings data)
        {
            #region local variable
            var providerObj = new ProviderManager();
            int count = 0, dupPid = 0;
            string suffix = string.Empty, finalClientName = string.Empty;
            #endregion

            finalClientName = data.OrgName.Trim();
            // Take the Provider Id
            dupPid = providerObj.GetProviderId(finalClientName);

            while (dupPid > 0)
            {
                if (count == 0)
                    suffix = "";
                else
                    suffix = " " + count;
                // Adding suffix here
                finalClientName = data.OrgName + suffix;
                // Agian checking provider Id, If it duplicate or not.
                dupPid = providerObj.GetProviderId(finalClientName);
                count = count + 1;
            }
            providerObj = null;
            // Returning final provider name
            return finalClientName;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="providerId"></param>
        /// <returns></returns>
        public Model.FeatureMatrix GetFeatureMatrix(int providerId)
        {
            using (var repository = new EntityFrameworkRepository(new AtHocDbContext()))
            {
                var response = repository.RunQuery<Model.FeatureResponse>("dbo.PRV_GET_FEATURES_MATRIX @providerId", providerId).ToList();

                var featureMatrix = new Model.FeatureMatrix();
                try
                {
                    if (response.HasValue())
                    {
                        featureMatrix.IsGroupBlockingSupported = (response.FirstOrDefault(r => r.Key_Name == "IsGroupBlockingSupported") != null) && string.Equals(response.First(r => r.Key_Name == "IsGroupBlockingSupported").Value, "true", StringComparison.InvariantCultureIgnoreCase);
                        featureMatrix.IsAdvancedQuerySupported = (response.FirstOrDefault(r => r.Key_Name == "IsAdvancedQuerySupported") != null) && string.Equals(response.First(r => r.Key_Name == "IsAdvancedQuerySupported").Value, "true", StringComparison.InvariantCultureIgnoreCase);
                        featureMatrix.IsIndividualUserTargetingSupported = (response.FirstOrDefault(r => r.Key_Name == "IsIndividualUserTargetingSupported") != null) && string.Equals(response.First(r => r.Key_Name == "IsIndividualUserTargetingSupported").Value, "true", StringComparison.InvariantCultureIgnoreCase);
                        featureMatrix.IsTargetByAreaSupported = (response.FirstOrDefault(r => r.Key_Name == "IsTargetByAreaSupported") != null) && string.Equals(response.First(r => r.Key_Name == "IsTargetByAreaSupported").Value, "true", StringComparison.InvariantCultureIgnoreCase);
                        featureMatrix.IsDropboxSupported = (response.FirstOrDefault(r => r.Key_Name == "IsDropboxSupported") != null) && string.Equals(response.First(r => r.Key_Name == "IsDropboxSupported").Value, "true", StringComparison.InvariantCultureIgnoreCase);
                        featureMatrix.IsMassDeviceTargetSupported = (response.FirstOrDefault(r => r.Key_Name == "IsMassDeviceTargetSupported") != null) && string.Equals(response.First(r => r.Key_Name == "IsMassDeviceTargetSupported").Value, "true", StringComparison.InvariantCultureIgnoreCase);
                        featureMatrix.IsCallbridgeOptionSupported = (response.FirstOrDefault(r => r.Key_Name == "IsCallbridgeOptionSupported") != null) && string.Equals(response.First(r => r.Key_Name == "IsCallbridgeOptionSupported").Value, "true", StringComparison.InvariantCultureIgnoreCase);
                        featureMatrix.IsSchedulingSupported = (response.FirstOrDefault(r => r.Key_Name == "IsSchedulingSupported") != null) && string.Equals(response.First(r => r.Key_Name == "IsSchedulingSupported").Value, "true", StringComparison.InvariantCultureIgnoreCase);
                        featureMatrix.IsTestAlertSupported = (response.FirstOrDefault(r => r.Key_Name == "IsTestAlertSupported") != null) && string.Equals(response.First(r => r.Key_Name == "IsTestAlertSupported").Value, "true", StringComparison.InvariantCultureIgnoreCase);
                        featureMatrix.IsPrintAlertSupported = (response.FirstOrDefault(r => r.Key_Name == "IsPrintAlertSupported") != null) && string.Equals(response.First(r => r.Key_Name == "IsPrintAlertSupported").Value, "true", StringComparison.InvariantCultureIgnoreCase);
                        featureMatrix.IsDeviceOptionSupported = (response.FirstOrDefault(r => r.Key_Name == "IsDeviceOptionSupported") != null) && string.Equals(response.First(r => r.Key_Name == "IsDeviceOptionSupported").Value, "true", StringComparison.InvariantCultureIgnoreCase);
                        featureMatrix.IsAlertTemplateSettingSupported = (response.FirstOrDefault(r => r.Key_Name == "IsAlertTemplateSettingSupported") != null) && string.Equals(response.First(r => r.Key_Name == "IsAlertTemplateSettingSupported").Value, "true", StringComparison.InvariantCultureIgnoreCase);
                        featureMatrix.IsPlaceholderSupported = (response.FirstOrDefault(r => r.Key_Name == "IsPlaceholderSupported") != null) && string.Equals(response.First(r => r.Key_Name == "IsPlaceholderSupported").Value, "true", StringComparison.InvariantCultureIgnoreCase);
                        featureMatrix.IsDeviceDeliveryOrderSupported = (response.FirstOrDefault(r => r.Key_Name == "IsDeviceDeliveryOrderSupported") != null) && string.Equals(response.First(r => r.Key_Name == "IsDeviceDeliveryOrderSupported").Value, "true", StringComparison.InvariantCultureIgnoreCase);
                        featureMatrix.IsChannelSupported = (response.FirstOrDefault(r => r.Key_Name == "IsChannelSupported") != null) && string.Equals(response.First(r => r.Key_Name == "IsChannelSupported").Value, "true", StringComparison.InvariantCultureIgnoreCase);
                        featureMatrix.IsRecordedAudioSupported = (response.FirstOrDefault(r => r.Key_Name == "IsRecordedAudioSupported") != null) && string.Equals(response.First(r => r.Key_Name == "IsRecordedAudioSupported").Value, "true", StringComparison.InvariantCultureIgnoreCase);
                        featureMatrix.IsEmergencyCommunitySupported = (response.FirstOrDefault(r => r.Key_Name == "IsEmergencyCommunitySupported") != null) && string.Equals(response.First(r => r.Key_Name == "IsEmergencyCommunitySupported").Value, "true", StringComparison.InvariantCultureIgnoreCase);
                        featureMatrix.IsEnterpriseManagementSupported = (response.FirstOrDefault(r => r.Key_Name == "IsEnterpriseManagementSupported") != null) && string.Equals(response.First(r => r.Key_Name == "IsEnterpriseManagementSupported").Value, "true", StringComparison.InvariantCultureIgnoreCase);
                        featureMatrix.IsOrgHierarchySupported = (response.FirstOrDefault(r => r.Key_Name == "IsOrgHierarchySupported") != null) && string.Equals(response.First(r => r.Key_Name == "IsOrgHierarchySupported").Value, "true", StringComparison.InvariantCultureIgnoreCase);
                        featureMatrix.IsFillCountSupported = (response.FirstOrDefault(r => r.Key_Name == "IsFillCountSupported") != null) && string.Equals(response.First(r => r.Key_Name == "IsFillCountSupported").Value, "true", StringComparison.InvariantCultureIgnoreCase);
                        featureMatrix.IsActivityLogSupported = (response.FirstOrDefault(r => r.Key_Name == "IsActivityLogSupported") != null) && string.Equals(response.First(r => r.Key_Name == "IsActivityLogSupported").Value, "true", StringComparison.InvariantCultureIgnoreCase);
                        featureMatrix.IsAccountabilitySupported = (response.FirstOrDefault(r => r.Key_Name == "IsAccountabilitySupported") != null) && string.Equals(response.First(r => r.Key_Name == "IsAccountabilitySupported").Value, "true", StringComparison.InvariantCultureIgnoreCase);
                        featureMatrix.IsSSASupported = (response.FirstOrDefault(r => r.Key_Name == "IsSSASupported") != null) && string.Equals(response.First(r => r.Key_Name == "IsSSASupported").Value, "true", StringComparison.InvariantCultureIgnoreCase);
                        featureMatrix.IsUserUniqueAcrossEnterprise = (response.FirstOrDefault(r => r.Key_Name == "IsUserUniqueAcrossEnterprise") != null) && string.Equals(response.First(r => r.Key_Name == "IsUserUniqueAcrossEnterprise").Value, "true", StringComparison.InvariantCultureIgnoreCase);
                        featureMatrix.IsWAMSupported = (response.FirstOrDefault(r => r.Key_Name == "IsWAMSupported") != null) && string.Equals(response.First(r => r.Key_Name == "IsWAMSupported").Value, "true", StringComparison.InvariantCultureIgnoreCase);
                        featureMatrix.EnableDeviceOptionCache = (response.FirstOrDefault(r => r.Key_Name == "EnableDeviceOptionCache") != null) && string.Equals(response.First(r => r.Key_Name == "EnableDeviceOptionCache").Value, "true", StringComparison.InvariantCultureIgnoreCase);
                    }


                    if (!featureMatrix.IsSSASupported)
                    {
                        featureMatrix.ObjectIdsToRemove = new List<int> { SystemObjectId.SSAMap };
                    }

                    //TODO: Replace above code with below when we implement feature matrix properly as below is more efficient 

                    //var objectIdsToRemove = new List<int>();
                    //var objectIdsToInculde = new List<int>();

                    //foreach (var res in response)
                    //{
                    //    var keyName = res.Key_Name;
                    //    if (!string.IsNullOrEmpty(keyName))
                    //    {
                    //        switch (keyName)
                    //        {
                    //            case "IsAccountabilitySupported":
                    //                featureMatrix.IsAccountabilitySupported = string.Equals(res.Value, "true", StringComparison.InvariantCultureIgnoreCase);
                    //                break;
                    //            case "IsActivityLogSupported":
                    //                featureMatrix.IsActivityLogSupported = string.Equals(res.Value, "true", StringComparison.InvariantCultureIgnoreCase);
                    //                break;
                    //            case "IsAdvancedQuerySupported":
                    //                featureMatrix.IsAdvancedQuerySupported = string.Equals(res.Value, "true", StringComparison.InvariantCultureIgnoreCase);
                    //                break;
                    //            case "IsAlertTemplateSettingSupported":
                    //                featureMatrix.IsAlertTemplateSettingSupported = string.Equals(res.Value, "true", StringComparison.InvariantCultureIgnoreCase);
                    //                break;
                    //            case "IsCallbridgeOptionSupported":
                    //                featureMatrix.IsCallbridgeOptionSupported = string.Equals(res.Value, "true", StringComparison.InvariantCultureIgnoreCase);
                    //                break;
                    //            case "IsChannelSupported":
                    //                featureMatrix.IsChannelSupported = string.Equals(res.Value, "true", StringComparison.InvariantCultureIgnoreCase);
                    //                break;
                    //            case "IsDeviceDeliveryOrderSupported":
                    //                featureMatrix.IsDeviceDeliveryOrderSupported = string.Equals(res.Value, "true", StringComparison.InvariantCultureIgnoreCase);
                    //                break;
                    //            case "IsDeviceOptionSupported":
                    //                featureMatrix.IsDeviceOptionSupported = string.Equals(res.Value, "true", StringComparison.InvariantCultureIgnoreCase);
                    //                break;
                    //            case "IsDropboxSupported":
                    //                featureMatrix.IsDropboxSupported = string.Equals(res.Value, "true", StringComparison.InvariantCultureIgnoreCase);
                    //                break;
                    //            case "IsFillCountSupported":
                    //                featureMatrix.IsFillCountSupported = string.Equals(res.Value, "true", StringComparison.InvariantCultureIgnoreCase);
                    //                break;
                    //            case "IsGroupBlockingSupported":
                    //                featureMatrix.IsGroupBlockingSupported = string.Equals(res.Value, "true", StringComparison.InvariantCultureIgnoreCase);
                    //                break;
                    //            case "IsIndividualUserTargetingSupported":
                    //                featureMatrix.IsIndividualUserTargetingSupported = string.Equals(res.Value, "true", StringComparison.InvariantCultureIgnoreCase);
                    //                break;
                    //            case "IsMassDeviceTargetSupported":
                    //                featureMatrix.IsMassDeviceTargetSupported = string.Equals(res.Value, "true", StringComparison.InvariantCultureIgnoreCase);
                    //                break;
                    //            case "IsPlaceholderSupported":
                    //                featureMatrix.IsPlaceholderSupported = string.Equals(res.Value, "true", StringComparison.InvariantCultureIgnoreCase);
                    //                break;
                    //            case "IsPrintAlertSupported":
                    //                featureMatrix.IsPrintAlertSupported = string.Equals(res.Value, "true", StringComparison.InvariantCultureIgnoreCase);
                    //                break;
                    //            case "IsRecordedAudioSupported":
                    //                featureMatrix.IsRecordedAudioSupported = string.Equals(res.Value, "true", StringComparison.InvariantCultureIgnoreCase);
                    //                break;
                    //            case "IsSchedulingSupported":
                    //                featureMatrix.IsSchedulingSupported = string.Equals(res.Value, "true", StringComparison.InvariantCultureIgnoreCase);
                    //                break;
                    //            case "IsTargetByAreaSupported":
                    //                featureMatrix.IsTargetByAreaSupported = string.Equals(res.Value, "true", StringComparison.InvariantCultureIgnoreCase);
                    //                break;
                    //            case "IsTestAlertSupported":
                    //                featureMatrix.IsTestAlertSupported = string.Equals(res.Value, "true", StringComparison.InvariantCultureIgnoreCase);
                    //                break;
                    //            case "IsEmergencyCommunitySupported":
                    //                featureMatrix.IsEmergencyCommunitySupported = string.Equals(res.Value, "true", StringComparison.InvariantCultureIgnoreCase);
                    //                break;
                    //            case "IsEnterpriseManagementSupported":
                    //                featureMatrix.IsEnterpriseManagementSupported = string.Equals(res.Value, "true", StringComparison.InvariantCultureIgnoreCase);
                    //                break;
                    //            case "IsOrgHierarchySupported":
                    //                featureMatrix.IsOrgHierarchySupported = string.Equals(res.Value, "true", StringComparison.InvariantCultureIgnoreCase);
                    //                break;
                    //        }
                    //    }

                    //    if (res.Object_Exclude.HasValue() && res.Object_Id != null)
                    //    {
                    //        if (string.Equals(res.Object_Exclude, "Y", StringComparison.InvariantCultureIgnoreCase))
                    //        {
                    //            objectIdsToRemove.Add((int) res.Object_Id);
                    //        }
                    //        else if (string.Equals(res.Object_Exclude, "N", StringComparison.InvariantCultureIgnoreCase))
                    //        {
                    //            objectIdsToInculde.Add((int)res.Object_Id);
                    //        }
                    //    }
                    //}

                    //featureMatrix.ObjectIdsToRemove = objectIdsToRemove;
                    //featureMatrix.ObjectIdsToInculde = objectIdsToInculde;
                }
                catch (Exception ex)
                {
                    _logService.Error(() => ex);
                }

                return featureMatrix;
            }
        }

        public VirtualSystems.FeatureMatrix GetFeatureMatrixForVirtualSystem(int providerId)
        {
            var featureMatrixProvider = GetFeatureMatrix(providerId);

            var featureMatrixVirtualSystem = new VirtualSystems.FeatureMatrix
            {
                IsGroupBlockingSupported = featureMatrixProvider.IsGroupBlockingSupported,
                IsAdvancedQuerySupported = featureMatrixProvider.IsAdvancedQuerySupported,
                IsIndividualUserTargetingSupported = featureMatrixProvider.IsIndividualUserTargetingSupported,
                IsTargetByAreaSupported = featureMatrixProvider.IsTargetByAreaSupported,
                IsDropboxSupported = featureMatrixProvider.IsDropboxSupported,
                IsMassDeviceTargetSupported = featureMatrixProvider.IsMassDeviceTargetSupported,
                IsCallbridgeOptionSupported = featureMatrixProvider.IsCallbridgeOptionSupported,
                IsSchedulingSupported = featureMatrixProvider.IsSchedulingSupported,
                IsTestAlertSupported = featureMatrixProvider.IsTestAlertSupported,
                IsPrintAlertSupported = featureMatrixProvider.IsPrintAlertSupported,
                IsDeviceOptionSupported = featureMatrixProvider.IsDeviceOptionSupported,
                IsAlertTemplateSettingSupported = featureMatrixProvider.IsAlertTemplateSettingSupported,
                IsPlaceholderSupported = featureMatrixProvider.IsPlaceholderSupported,
                IsDeviceDeliveryOrderSupported = featureMatrixProvider.IsDeviceDeliveryOrderSupported,
                IsChannelSupported = featureMatrixProvider.IsChannelSupported,
                IsRecordedAudioSupported = featureMatrixProvider.IsRecordedAudioSupported,
                IsEmergencyCommunitySupported = featureMatrixProvider.IsEmergencyCommunitySupported,
                IsEnterpriseManagementSupported = featureMatrixProvider.IsEnterpriseManagementSupported,
                IsOrgHierarchySupported = featureMatrixProvider.IsOrgHierarchySupported,
                IsFillCountSupported = featureMatrixProvider.IsFillCountSupported,
                IsActivityLogSupported = featureMatrixProvider.IsActivityLogSupported,
                IsAccountabilitySupported = featureMatrixProvider.IsAccountabilitySupported,
                IsUserUniqueAcrossEnterprise = featureMatrixProvider.IsUserUniqueAcrossEnterprise,
                IsSSASupported = featureMatrixProvider.IsSSASupported,
                ObjectIdsToRemove = featureMatrixProvider.ObjectIdsToRemove
            };

            return featureMatrixVirtualSystem;
        }
        /// <summary>
        /// Get source path by image type
        /// </summary>
        /// <param name="imgType"></param>
        /// <returns></returns>
        public string GetSource(string imgType)
        {
            switch (imgType)
            {
                case "image/png":
                    return Constants.IconPath;

                case "image/gif":
                    return Constants.LogoPath;

                case "image/jpeg":
                    return Constants.DesktopPath;
            }
            return string.Empty;
        }

        /// <summary>
        /// To upload image 
        /// </summary>
        /// <param name="mediaData">UpdateLogoImage</param>
        /// <param name="wMediaInfo">UpdateLogoImage</param>
        /// <returns></returns>
        public string UpdateLogoImage(string imageData, string imageType, string imageExtension)
        {

            var myByteArray = Convert.FromBase64String(imageData);
            var stream = new MemoryStream();
            stream.Write(myByteArray, 0, myByteArray.Length);

            var wMediaInfo = new MediaInfo
            {
                Source = Constants.WebSource,
                Description = string.Empty,
                AllowWebAccess = true,
                ContentType = imageType,
                ContentLength = myByteArray.Length,
                Extension = imageExtension,
                Height = 0,
                Width = 0,
                Rotation = 0
            };

            var service = new MediaService();
            Guid mediaId;
            // create media content
            var content = service.CreateMedia(wMediaInfo, out mediaId);
            content.SetContent(stream);
            return mediaId.ToString();

        }

        /// <summary>
        /// This method will use for either New organizatio/sub-org/Basic adding or duplicating these
        /// </summary>
        /// <param name="data">Param of general settings</param>
        /// <returns>true/false</returns>
        public bool SaveOrganization(OrgManagerSettings data)
        {
            var newProviderId = 0;

            using (var context = new AtHocDbContext())
            {
               
                //check the uniquness of provider name, if found duplicate then add number to make unique.
                data.OrgName = this.GetFinalOrgName(data);

                // Get the source provider based on VPS type and Locale
                int srcTemplateId;
                var orgType = (OrgTypes)Enum.Parse(typeof(OrgTypes), data.OrgType);
                if (!data.IsDuplicate)
                {
                    if (data.OrgType == OrgTypes.TPL_SUB.ToString())
                        srcTemplateId = data.EnterpriseProviderId;
                    else
                        srcTemplateId=GetSourceTemplateProvider(orgType, data.ProviderLocale);
                }
                else
                {

                    srcTemplateId = data.ProviderId;
                }
                // Create VPS using  respective templates
                using (var vpsDuplicate = new Duplicator(AtHocDatabase.Ngad.AdoConnString(), AtHocDatabase.Ngad.AdoConnString()))
                {
                    newProviderId = vpsDuplicate.VpsCopy(srcTemplateId, data.OrgName, string.Empty, data.OperatorId, data.IsEnterprise, data.EnterpriseProviderId, !data.IsDuplicate);
                }

                //After successful creation of organization we need to assign roles to the logged in operator w.r.t to Organzation Type on newly created organization
                if (newProviderId > 0)
                {
                    var providerMgr = new ProviderManager();
                    if (data.OrgType.ToLower() == OrgTypes.TPL_ENT.ToString().ToLower() || data.OrgType.ToLower() == OrgTypes.TPL_SUB.ToString().ToLower())
                        providerMgr.SetOperatorAdminRole(newProviderId, data.OperatorId);
                    else if (data.OrgType.ToLower() == OrgTypes.TPL_BAS.ToString().ToLower())
                        providerMgr.SetAffiliateAdminRole(newProviderId, data.OperatorId);
                }
            }

            return newProviderId > 0;
        }

        /// <summary>
        /// This method is used to get all oprators based on provider Id
        /// </summary>
        /// <param name="providerId">provider id</param>
        /// <returns>List of oprators name</returns>
        public List<ProviderOperators> GetProviderOperators(int providerId, int role, int operatorId)
        {
            using (var dbContext = new AtHocDbContext())
            {
                return dbContext.Database.SqlQuery<ProviderOperators>(SettingsSqlQueries.GetProviderOperators(operatorId, role, providerId)).ToList();
            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="providerId"></param>
        /// <returns></returns>
        public string GetProviderLocale(int providerId)
        {
            using (var dbContext = new AtHocDbContext())
            {
                return dbContext.Database.SqlQuery<string>(SettingsSqlQueries.GetProviderLocale(providerId)).ToList().FirstOrDefault();
            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="orgType"></param>
        /// <param name="baseLocale"></param>
        /// <returns></returns>
        public int GetSourceTemplateProvider(OrgTypes orgType, string baseLocale)
        {
            var providerId = 0;
            using (var dbContext = new AtHocDbContext())
            {
                providerId = dbContext.Database.SqlQuery<int>(SettingsSqlQueries.GetSourceTemplateProvider(orgType, baseLocale)).AsQueryable().FirstOrDefault();
            }
            return providerId;
        }

        /// <summary>
        /// This method is used for update the user role
        /// </summary>
        /// <param name="operatorId"></param>
        /// <param name="orgName"></param>
        private void UpdateUserRoleTab(int operatorId, string orgName)
        {
            using (var dbContext = new AtHocDbContext())
            {
                dbContext.Database.ExecuteSqlCommand(SettingsSqlQueries.GetUpdateUserRoleQuery, operatorId, orgName);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="withAdminPrivilegeOnly"></param>
        /// <returns></returns>
        public List<ProviderList> GetProviderList(int userId, int withAdminPrivilegeOnly = 0)
        {
            using (var dbContext = new AtHocDbContext())
            {
                var data = dbContext.Database
                     .SqlQuery<ProviderList>("dbo.UPS_GET_PROVIDER_LIST {0},{1}", userId, withAdminPrivilegeOnly);
                return data.ToList();
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public int GetProviderVersion()
        {

            var result = 0;
            using (var dbContext = new AtHocDbContext())
            {
                result = dbContext.Database.SqlQuery<int>(SettingsSqlQueries.GetProviderVersion()).AsQueryable().FirstOrDefault();
            }
            return result;
        }

        public bool IsEnterpriseWithSubs(int providerId)

        {
            var result = 0;
            using (var dbContext = new AtHocDbContext())
            {
                result = dbContext.Database.SqlQuery<int>(SettingsSqlQueries.GetEnterpriseWithSubStatus(providerId)).AsQueryable().FirstOrDefault();
            }
            return result>0;
        }

        public string GetProviderName(int providerId)
        {
            using (var db = new AtHocDbContext())
            {

                var providerName =
                    db.ProviderSettings.Single(x => x.ProviderId == providerId).ProviderName;
                return providerName;
            }
        }
       
    }
}
