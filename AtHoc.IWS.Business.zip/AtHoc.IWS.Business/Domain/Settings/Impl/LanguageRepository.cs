﻿using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.Settings.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Domain.Settings.SqlQueries;

namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
   public  class LanguageRepository : ILanguageRepository
   {


       public  string GetProviderLocale(int providerId)
       {
           using (var dbContext = new AtHocDbContext())
           {
               var resultValue = dbContext.Database.SqlQuery<string>(SettingsSqlQueries.GetProviderLocale(providerId)).ToList().FirstOrDefault();
               return resultValue;
           }
       }
       public IEnumerable<Language> GetLanguages()
       {
           using (var db = new AtHocDbContext())
           {
               var data = db.Language;
               return data.ToList();
           }
       }
       public IEnumerable<Language> GetOperatorEnabledLanguages()
       {
           using (var db = new AtHocDbContext())
           {
               var data = db.Language.Where(e=>e.EnableForOperatorYN.ToUpper().Equals("Y"));
               return data.ToList();

             
           }
       }
       public IEnumerable<Language> GetDeliveryEnabledLanguages(int providerId)
       {
           using (var dbContext = new AtHocDbContext())
           {
               var resultValue = dbContext.Database.SqlQuery<Language>(SettingsSqlQueries.GetDeliveryEnabledLanguages(providerId)).ToList();
               return resultValue;
           }
       }

       public IEnumerable<Language> GetDeliveryEnabledLanguagesByHierarchy(int providerId)
       {
           using (var dbContext = new AtHocDbContext())
           {
               var resultValue = dbContext.Database.SqlQuery<Language>(SettingsSqlQueries.GetDeliveryEnabledLanguagesByHierarchy(providerId)).ToList();
               return resultValue;
           }
       }
    }

}
