﻿using System.Collections.Generic;
using System.IO;
using AtHoc.Infrastructure.Data;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.MediaServices;

namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public interface IAgentRepository
    {
        //Get Agent Manager List
        IEnumerable<AgentSettingsList> GetAgentDetails(AgentCriteria criteriaSpec);
        
        //Get Agent Manager Details
        AgentSettings GetAgentManagerDetails(int AgentId);

        //Delete Agent Manager
        bool DeleteAgentManagerDetails(AgentCriteria criteriaSpec);

        //check Agent is associated with any channels 
        List<int> IsAgentAssociated(List<int> agentIds);

        //Save Agent Manager Data
        bool SaveAgentData(AgentSettings agentData);

        //Validate Common Name
        bool IsValidCommonName(int providerid,int AgentId, string strCommonName);
    }
}