﻿using System.Collections.Generic;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Entities;
namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public interface IProviderRepository
    {
        IEnumerable<ProviderSettingsModel> GetProviderData();
        GeneralSettings GetGeneralSettings(int providerId);
        bool UpdateGeneralSettings(GeneralSettings data);
        bool IsOrgCodeExists(int providerId, string orgCode);
        bool IsVirtualNameExists(GeneralSettings data);
        FeatureMatrix GetFeatureMatrix(int providerId);
        VirtualSystems.FeatureMatrix GetFeatureMatrixForVirtualSystem(int providerId);
        bool SaveOrganization(OrgManagerSettings data);
        List<ProviderOperators> GetProviderOperators(int providerId, int role, int operatorId);
        string GetProviderLocale(int providerId);
        IEnumerable<ProviderSettingsModel> GetOrganizationList(int providerId, VPSType operatorType, List<string> strSearchText);
        List<ProviderList> GetProviderList(int userId, int withAdminPrivilegeOnly = 0);
        bool IsEnterpriseWithSubs(int providerId);
        /// <summary>
        /// To get the provider list of Enterprice VPS.
        /// </summary>
        /// <param name="providerId">Ent provider Id.</param>
        /// <returns>ProviderList.</returns>
        Dictionary<int, string> GetEnterpriseProviderList(int providerId);

        string GetProviderName(int providerId);
    }
}
