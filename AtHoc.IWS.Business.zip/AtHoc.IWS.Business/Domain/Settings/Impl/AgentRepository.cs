﻿using System;
using System.Linq;
using System.IO;
using System.Collections.Generic;
using AtHoc.Infrastructure.Database;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Settings.SqlQueries;
using AtHoc.Diagnostics;
using AtHoc.MediaServices;
using AtHoc.Systems;
using IUnitOfWork = AtHoc.Infrastructure.Data.IUnitOfWork;

namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public class AgentRepository : IAgentRepository
    {
        /// <summary>
        /// Get Agent List based on search criteria
        /// </summary>
        /// <param name="criteriaSpec"></param>
        /// <returns>List Agent details</returns>
        public IEnumerable<AgentSettingsList> GetAgentDetails(AgentCriteria criteriaSpec)
        {

            var agentData = new List<AgentSettingsList>();
            agentData.AddRange(this.GetAgentData(criteriaSpec)); 
            return agentData;
        }

        /// <summary>
        /// Get Agent List based on search criteria
        /// </summary>
        /// <param name="searchText"></param>
        /// <param name="criteriaSpec"></param>
        /// <returns>List of Agent Details</returns>
        private IEnumerable<AgentSettingsList> GetAgentData(AgentCriteria criteriaSpec)
        {
            var data = new List<AgentSettingsList>();
            using (var repository = new EntityFrameworkRepository(new AtHocDbContext()))
            {

                var agentQuery = repository.RunQuery<AgentSettingsList>(SettingsSqlQueries.getAgentQuery(criteriaSpec.ProviderId, SettingsSqlQueries.BuildPillsCondition(criteriaSpec.SearchString, "A.AGENT_NAME"))).AsQueryable();
                data = agentQuery.Select(
                      p => new AgentSettingsList
                      {
                          agentId = p.agentId,
                          agentName = p.agentName,
                          agentcommonName = p.agentcommonName,
                          agentType = p.agentType,
                          engineId = p.engineId,
                          engineLocationId = p.engineLocationId,
                          agentowner = p.Scope,
                          providerId = p.providerId,
                          defaultButtonId = -1,
                          updatedOn = p.updatedOn,
                          metastore= p.metastore,
                          channelpreferencesURL = p.channelpreferencesURL,
                          IsOwner = (p.updatedBy != null)
                                   ? (p.updatedBy == criteriaSpec.OperatorId)
                                   : (criteriaSpec.OperatorId == p.createdBy)
                      }
                      ).ToList();

                return (data);
            }
        }

        /// <summary>
        /// This method is used to filter the Agents
        /// </summary>
        /// <param name="searchText"></param>
        /// <returns>string</returns>
        private string filterString(string searchText)
        {

            string strSearch = string.Empty;
            var arrText = searchText.Split('$');
            int count = 0;
            while (arrText.Length > count)
            {
                if (count == 0)
                    strSearch = "A.AGENT_NAME like '%" + arrText[count].Replace("'", "''") + "%'";
                else
                    strSearch += " AND A.AGENT_NAME like '%" + arrText[count].Replace("'", "''") + "%'";
                count++;
            }

            if (arrText.Length == 0)
                strSearch = "A.AGENT_NAME like '%" + searchText.Replace("'", "''") + "%'";

            return strSearch;
        }

        /// <summary>
        /// Get AgentDetails by AgentId
        /// </summary>
        /// <param name="templateId">templateId</param>
        /// <returns>AgentSettings object</returns>
        public AgentSettings GetAgentManagerDetails(int AgentId)
        {
            using (var db = new AtHocDbContext())
            {
                var data = db.AgentSettings.FirstOrDefault(p => p.agentId == AgentId);

                if (data == null)
                    return new AgentSettings();
                return data;
            }
        }

        /// <summary>
        /// Deleting the Agent Manager Details
        /// </summary>
        /// <param name="templateIds">AgentIds</param>
        /// <param name="providerId">Provider Id</param>        
        /// <returns>bool true/false</returns>
        public bool DeleteAgentManagerDetails(AgentCriteria criteriaSpec)
        {
            bool blSuccess = false;
            using (var db = new AtHocDbContext())
            {
                var ndeletedata = db.AgentSettings.Where(p => criteriaSpec.AgentIds.Contains(p.agentId)).ToList();
                foreach (AgentSettings item in ndeletedata)
                {
                    db.Entry(item).State = System.Data.Entity.EntityState.Deleted;
                }
                db.SaveChanges();
                blSuccess = true;
            }
            return blSuccess;
        }

        /// <summary>
        /// This method will check the agent id is associated with any channels or not
        /// </summary>
        /// <returns>List<int> </returns>
        public List<int> IsAgentAssociated(List<int> agentIds)
        {
            List<int> associatedId = new List<int>();
            using (var repository = new EntityFrameworkRepository(new AtHocDbContext()))
            {
                foreach (var item in agentIds)
                {
                    int isFound = repository.RunQuery<int>(SettingsSqlQueries.getAgentDependencyCount(item)).
                        FirstOrDefault<int>();
                    if (isFound > 0)
                        associatedId.Add(item);
                }
            }

            return associatedId;
        }

        /// <summary>
        /// To check whether common name exists in Database with same name
        /// </summary>
        /// <param name="templateData">IsValidCommonName object</param>        
        /// <returns>bool</returns>
        public bool IsValidCommonName(int providerid, int AgentId, string strCommonName)
        {
            var isValid = false;
            using (var acontext = new AtHocDbContext())
            {
                string str = String.Format(SettingsSqlQueries.CheckAgentCommonName, providerid, AgentId, strCommonName.Replace("'", "''"));
                int count = acontext.Database.SqlQuery<int>(str).FirstOrDefault();
                if (count > 0)
                    isValid = true;
            }
            return isValid;
        }

        /// <summary>
        /// To Save the Agent Details
        /// </summary>
        /// <param name="agentData"></param>
        /// <returns>bool</returns>
        public bool SaveAgentData(AgentSettings agentData)
        {
            bool blSuccess = false;

            using (var db = new AtHocDbContext())
            {
                if (agentData.agentId == 0)
                {
                    agentData.agentId = GetMaxAgentId();
                    agentData.createdOn = DateTimeConverter.GetSystemTimeAsSeconds();
                    agentData.updatedOn = DateTimeConverter.GetSystemTimeAsSeconds();
                    agentData.agentGuid = Guid.NewGuid().ToString();
                    db.AgentSettings.Add(agentData);
                    db.SaveChanges();
                    blSuccess = true;
                }
                else
                {
                    agentData.updatedOn = DateTimeConverter.GetSystemTimeAsSeconds();
                    db.Entry(agentData).State = System.Data.Entity.EntityState.Modified;
                    db.SaveChanges();
                    blSuccess = true;
                }
            }
            return blSuccess;
        }

        /// <summary>
        /// To get the Max Agent Id from db
        /// </summary>
        /// <returns></returns>
        public int GetMaxAgentId()
        {
            return AtHoc.Data.SequenceHelper.GetSequence("AGENTID");
        }

    }
}