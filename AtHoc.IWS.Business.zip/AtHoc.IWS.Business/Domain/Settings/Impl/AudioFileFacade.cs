﻿using System;
using System.Collections.Generic;
using System.Linq;
using AtHoc.Global.Resources.Interfaces;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Audit;
using AtHoc.IWS.Business.Domain.Entities;


namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public class AudioFileFacade : IAudioFileFacade
    {

        private readonly IAudioFileRepository _audioFilerepository;
        private readonly IGlobalEntityLocaleFacade _globalEntityLocaleFasFacade;
        public AudioFileFacade(IAudioFileRepository audioRepository, IGlobalEntityLocaleFacade globalEntityLocaleFacade)
        {
            _audioFilerepository = audioRepository;
            _globalEntityLocaleFasFacade = globalEntityLocaleFacade;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="criteria"></param>
        /// <returns></returns>
        public IEnumerable<AudioFileSettingsModel> GetAudioFileData(AudioSearchCriteria criteria)
        {
            var data = _audioFilerepository.GetAudioFileData(criteria);
            return data;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="spec"></param>
        /// <returns></returns>
        public IEnumerable<AudioFileModel> GetAudioList(AudioSearchCriteria spec)
        {
            var audioData = _audioFilerepository.GetAudioList(spec);
            var localizedAudioData = _globalEntityLocaleFasFacade.GetLocalizedEntity(audioData, spec.Locale);
            return localizedAudioData;

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="audioFileId"></param>
        /// <param name="providerId"></param>
        /// <returns></returns>
        public AudioFileSettingsModel GetAudioFileDataById(int audioFileId, int providerId)
        {
            var data = _audioFilerepository.GetAudioFileDataById(audioFileId, providerId);
            return data;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="audioFileData"></param>
        /// <param name="operatorId"></param>
        /// <returns></returns>
        public int SaveAudioFileData(AudioFileSettingsModel audioFileData, int operatorId)
        {
            var blResult = _audioFilerepository.SaveAudioFileData(audioFileData, operatorId);

            if (blResult > 0)
            {
                var auditSpec = new AuditSpec(operatorId, audioFileData.ProviderId)
                {
                    Action = ServiceAction.AudioCreated,
                    ObjectType = EntityType.Audio,
                    ObjectName = audioFileData.AudioName
                };
                OperationAuditor.LogAction(auditSpec);
            }
            return blResult;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="audioFileData"></param>
        /// <param name="operatorId"></param>
        /// <returns></returns>
        public bool UpdateAudioFileData(AudioFileSettingsModel audioFileData, int operatorId)
        {
            var blResult = _audioFilerepository.UpdateAudioFileData(audioFileData, operatorId);

            if (!blResult) return false;
            var auditSpec = new AuditSpec(operatorId, audioFileData.ProviderId)
            {
                Action = ServiceAction.AudioUpdated,
                ObjectType = EntityType.Audio,
                ObjectName = audioFileData.AudioName
            };
            OperationAuditor.LogAction(auditSpec);
            return true;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="audioFileIds"></param>
        /// <param name="providerId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public bool DeleteAudioFiles(int[] audioFileIds, int providerId, int userId)
        {
            var blResult = _audioFilerepository.DeleteAudioFiles(audioFileIds, providerId, userId);
            var audioName = string.Empty;
            if (!blResult) return false;
            if (audioFileIds.Count() == 1)
                audioName = GetAudioFileDataById(audioFileIds[0], providerId).AudioName;
            var auditSpec = new AuditSpec(userId, providerId)
            {
                Action = ServiceAction.AudioDeleted,
                ObjectType = EntityType.Audio,
                ObjectName = audioFileIds.Count() == 1 ? audioName + " Deleted" : audioFileIds.Count() + " audio records were deleted"
            };
            OperationAuditor.LogAction(auditSpec);
            return true;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public int GetNewAudioFileId()
        {
            var blResult = _audioFilerepository.GetNewAudioFileId();
            return blResult;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="audioId"></param>
        /// <returns></returns>
        public byte[] DownloadAudioFile(int audioId)
        {
            var content = _audioFilerepository.DownloadAudioFile(audioId);
            return content;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="audioId"></param>
        /// <returns></returns>
        public bool UploadAudioFile(byte[] data, int audioId)
        {
            var blResult = _audioFilerepository.UploadAudioFile(data, audioId);
            return blResult;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="audio"></param>
        /// <returns></returns>
        public bool IsAudioNameExists(AudioFileSettingsModel audio)
        {
            var blResult = _audioFilerepository.IsAudioNameExists(audio);
            return blResult;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="audio"></param>
        /// <returns></returns>
        public bool IsAudioCommonNameExists(AudioFileSettingsModel audio)
        {
            var blResult = _audioFilerepository.IsAudioCommonNameExists(audio);
            return blResult;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="providerId"></param>
        /// <returns></returns>
        public List<AudioDefaultSeverities> GetDefaultAudioSeverityData(int? providerId)
        {
            var data = _audioFilerepository.GetDefaultAudioSeverityData(providerId);
            return data;
        }

    }
}
