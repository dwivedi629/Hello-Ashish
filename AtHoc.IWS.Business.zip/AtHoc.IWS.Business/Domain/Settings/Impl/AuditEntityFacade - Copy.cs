﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public class AuditEntityFacade :IAuditEntityFacade
    {
        public readonly IAuditEntityRepository _auditEntityRepository;
        public AuditEntityFacade(IAuditEntityRepository auditEntityRepository) 
        {
            _auditEntityRepository = auditEntityRepository;
        }

        public IEnumerable<AuditEntity> GetAuditEntities()
        {
            return _auditEntityRepository.GetAuditEntities();
        }
    }
}
