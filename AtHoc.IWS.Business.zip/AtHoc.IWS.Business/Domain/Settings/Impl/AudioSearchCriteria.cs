﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Settings.Model
{
   public  class AudioSearchCriteria
    {
       
        public bool  IsAudioPublic { get; set; }
        public string SearchString { get; set; }
    }
}
