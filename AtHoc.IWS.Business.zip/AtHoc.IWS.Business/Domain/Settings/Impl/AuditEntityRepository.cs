﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Extensions;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Configurations;

namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public class AuditEntityRepository : IAuditEntityRepository
    {

        public AuditEntityRepository() 
        {

        }
        public IEnumerable<AuditEntity> GetAuditEntities()
        {
            using (var db = new AtHocDbContext())
            {
                return db.AuditEntity.Select(o=> o).OrderBy(i=>i.ObjectName).ToList();
            }
        }
    }
}
