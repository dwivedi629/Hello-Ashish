﻿using System.Collections.Generic;
using AtHoc.IWS.Business.Domain.Settings.Model;
namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public interface IWeatherModuleRepository
    {
        List<GeoCodes> GetAllGeoCodeList(WeatherModuleCriteria objCriteria);

        WeatherModuleSettings GetAlertingPreferenceInfo(WeatherModuleCriteria objCriteria);

        void SaveWeatherInformations(WeatherModuleSettings data);
        List<GeoCodes> GetAllStateList();
        GeoCodesData GetAllZipGeoCodeList(string stateCode, string zipCode, int pageIndex, int pageSize, string sortBy, string sortOrder);
    }
}
