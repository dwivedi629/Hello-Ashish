﻿using System;
using System.Collections.Generic;
using System.Linq;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Audit;
using AtHoc.IWS.Business.Domain.Entities;


namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public class ProviderFacade : IProviderFacade
    {
        private readonly IProviderRepository _providerrepository;
        public ProviderFacade(IProviderRepository providerrepository)
        {
            _providerrepository = providerrepository;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<ProviderSettingsModel> GetProviderData()
        {
            var data = _providerrepository.GetProviderData();

            return data;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="providerId"></param>
        /// <returns></returns>
        public string GetProviderLocale(int providerId)
        {
            var data = _providerrepository.GetProviderLocale(providerId);

            return data;
        }

        public bool IsEnterpriseWithSubs(int providerId)
        {
            var data = _providerrepository.IsEnterpriseWithSubs(providerId);

            return data;
        }
       

        /// <summary>
        /// 
        /// </summary>
        /// <param name="providerId"></param>
        /// <returns></returns>
        public FeatureMatrix GetFeatureMatrix(int providerId)
        {
            return _providerrepository.GetFeatureMatrix(providerId);
        }

        public VirtualSystems.FeatureMatrix GetFeatureMatrixForVirtualSystem(int providerId)
        {
            return _providerrepository.GetFeatureMatrixForVirtualSystem(providerId);
        }

        /// <summary>
        /// This method will use for either New organizatio/sub-org/Basic adding or duplicating these
        /// // by using organization manager.
        /// </summary>
        /// <param name="data">Param of general settings</param>
        /// <returns>true/false</returns>
        public bool SaveOrganizationManager(OrgManagerSettings data)
        {
            var result = false;
            result =  _providerrepository.SaveOrganization(data);
            if (result)
            {                
                var auditSpec = new AuditSpec(data.OperatorId, data.LoggedInProviderId)
                {
                    Action = data.IsDuplicate ? ServiceAction.OrganizationDuplicated : ServiceAction.OrganizationCreated,
                    ObjectType = EntityType.VirtualSystem,
                    ObjectName = "Provider Name : " + data.OrgName + " has been saved successfully."
                };
                OperationAuditor.LogAction(auditSpec);
            }
            return result;
        }

      /// <summary>
      /// 
      /// </summary>
      /// <param name="providerId"></param>
      /// <param name="role"></param>
      /// <param name="operatorId"></param>
      /// <returns></returns>
        public List<ProviderOperators> GetProviderOperators(int providerId, int role, int operatorId)
        {
            return _providerrepository.GetProviderOperators(providerId, role,operatorId);
        }

         /// <summary>
        /// This method is to get all provider number for organization manager
        /// </summary>
        /// <returns>collection of providers</returns>
        public IEnumerable<ProviderSettingsModel> GetOrganizationList(int providerId, VPSType operatorType, List<String> strSearchText)
        {
            return _providerrepository.GetOrganizationList(providerId, operatorType, strSearchText);

        }

        public List<ProviderList> GetProviderList(int userId)
        {
            return _providerrepository.GetProviderList(userId);
        }

        /// <summary>
        /// To get the provider list of Enterprice VPS.
        /// </summary>
        /// <param name="providerId">Ent provider Id.</param>
        /// <returns>ProviderList.</returns>
        public Dictionary<int, string> GetEnterpriseProviderList(int providerId)
        {
            return _providerrepository.GetEnterpriseProviderList(providerId);
        }

        public string GetProviderName(int providerId)
        {
            return _providerrepository.GetProviderName(providerId);
        }
    }
}
