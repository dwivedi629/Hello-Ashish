﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Xml.Linq;
using AtHoc.Infrastructure.Domain;
using AtHoc.IWS.Business.Data;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Audit;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Configurations;
using AtHoc.MediaServices;
using AtHoc.Global.Resources.Implementations;
using AtHoc.Global.Resources.Interfaces;
using AtHoc.IWS.Business.Context;

namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public class AgentFacade : IAgentFacade
    {
        private readonly IAgentRepository _agentmanagerrepository;
        IGlobalEntityLocaleFacade _globalEntityLocaleFacade;

        public AgentFacade(IAgentRepository alertmanagerrepository, IGlobalEntityLocaleFacade globalEntityLocaleFacade)
        {
            _agentmanagerrepository = alertmanagerrepository;
            _globalEntityLocaleFacade = globalEntityLocaleFacade;
        }

        /// <summary>
        /// Get Agent List based on search criteria
        /// </summary>
        /// <param name="criteriaSpec"></param>
        /// <param name="locale">Locale code.</param>
        /// <returns>List Agent details</returns>
        public IEnumerable<AgentSettingsList> GetAgentDetails(AgentCriteria criteriaSpec, string locale)
        {
            var data = _agentmanagerrepository.GetAgentDetails(criteriaSpec).ToList();
            var localizedAgentDetails = _globalEntityLocaleFacade.GetLocalizedEntity(data, locale);
            return localizedAgentDetails;
        }

        /// <summary>
        /// This method will check the agent id is associated with any channels or not
        /// </summary>
        /// <returns>List<int> </returns>
        public List<int> IsAgentAssociated(List<int> agentIds)
        {
            return _agentmanagerrepository.IsAgentAssociated(agentIds);
        }

        /// <summary>
        /// Get AgentDetails by AgentId
        /// </summary>
        /// <param name="templateId">templateId</param>
        /// <param name="locale">Locale code.</param>
        /// <returns>AgentSettings object</returns>
        public AgentSettings GetAgentManagerDetails(int AgentId, string locale)
        {
            var data = _agentmanagerrepository.GetAgentManagerDetails(AgentId);
            var Agentdata = new AgentSettings
            {
                agentId = data.agentId,
                agentType = data.agentType,
                agentName = data.agentName,
                agentGuid = data.agentGuid,
                engineId = data.engineId,
                engineLocationId = data.engineLocationId,
                providerId = data.providerId,
                addUrl = data.addUrl,
                updateUrl = data.updateUrl,
                deleteURL = data.deleteURL,
                agentcommonName = data.agentcommonName,
                configURL = data.configURL,
                statusURL = data.statusURL,
                channelpreferencesURL = data.channelpreferencesURL,
                defaultButtonId = data.defaultButtonId,
                createdBy = data.createdBy,
                createdOn = data.createdOn,
                updatedOn = data.updatedOn,
                updatedBy = data.updatedBy,
                removechannelpreferencesURL = data.removechannelpreferencesURL,
                metastore = data.metastore
            };

            var localizedAgentManagerDetails = _globalEntityLocaleFacade.GetLocalizedEntity(Agentdata, locale);
            return localizedAgentManagerDetails;            
        }

        /// <summary>
        /// Deleting the Agent Manager Details
        /// </summary>
        /// <param name="templateIds">AgentIds</param>
        /// <param name="providerId">Provider Id</param>        
        /// <returns>bool true/false</returns>
        public bool DeleteAgentManagerDetails(AgentCriteria criteriaSpec, int userId)
        {
            var blResult = _agentmanagerrepository.DeleteAgentManagerDetails(criteriaSpec);
            var AgentName = string.Empty;
            if (blResult)
            {
                
                var auditSpec = new AuditSpec(userId, criteriaSpec.ProviderId)
                {
                    Action = ServiceAction.AgentDeleted,
                    ObjectType = EntityType.AgentEntity,
                    ObjectName = criteriaSpec.AgentIds.Count() + " Agent record(s) were deleted"
                };
                OperationAuditor.LogAction(auditSpec);
            }
            return blResult;
        }

        /// <summary>
        /// To Save the Agent Details
        /// </summary>
        /// <param name="agentData"></param>
        /// <returns>bool</returns>
        public bool SaveAgentData(AgentSettings agentData)
        {
            var blResult = _agentmanagerrepository.SaveAgentData(agentData);
            if (blResult)
            {
               
                var auditSpec = new AuditSpec(agentData.operatorId, agentData.providerId)
                {
                    Action = agentData.CreatedByUsername !=null ? ServiceAction.AgentUpdated : ServiceAction.AgentCreated,
                    ObjectType = EntityType.AgentEntity,
                    ObjectName = agentData.agentName
                };
                OperationAuditor.LogAction(auditSpec);
            }
            return blResult;
        }

        /// <summary>
        /// To check whether common name exists in Database with same name
        /// </summary>
        /// <param name="templateData">IsValidCommonName object</param>        
        /// <returns>bool</returns>
        public bool IsValidCommonName(int providerid, int AgentId, string strCommonName)
        {
            var blResult = _agentmanagerrepository.IsValidCommonName(providerid,AgentId, strCommonName);
            return blResult;
        }

    }
}
