﻿
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Audit;
using AtHoc.Infrastructure.Domain;
using AtHoc.IWS.Business.Data;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Data.SearchSpec;

namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public class DisableDeleteEndUsersFacade : FacadeBase<IAtHocContextFactory>, IDisableDeleteEndUsersFacade//,FacadeBase<IAtHocContextFactory>,
    {
        public DisableDeleteEndUsersFacade() : base(AtHocDbContextFactory.CreateFactory()) { }

        /// <summary>
        /// this method is used to get the disabled/deleted users info
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="isFromDisable"></param>
        /// <returns></returns>
        public DisableDeleteEndUsersModel GetDisableExecutionJobInfo(AutoDisableDeleteSpec autoDisableDeleteSpec)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.DisableDeleteEndUsersRepository.GetDisableDeleteLastExecutionJobInfo(autoDisableDeleteSpec);
            }
        }


        /// <summary>
        /// this method is used to get the disabled/deleted users info
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="isFromDisable"></param>
        /// <returns></returns>
        public DisableDeleteEndUsersModel GetDeleteExecutionJobInfo(AutoDisableDeleteSpec autoDisableDeleteSpec)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.DisableDeleteEndUsersRepository.GetDisableDeleteLastExecutionJobInfo(autoDisableDeleteSpec);
            }
        }

        /// <summary>
        /// getting the audit data
        /// </summary>
        /// <param name="AuditID"></param>
        /// <returns></returns>
        public DisableDeleteEndUsersModel GetAuditData(int AuditID)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.DisableDeleteEndUsersRepository.GetAuditData(AuditID);
            }
        }
        
        
        /// <summary>
        /// updating the audit data
        /// </summary>
        /// <param name="spec"></param>
        /// <param name="AuditID"></param>
        /// <returns></returns>
        public bool UpdateAuditLog(AuditSpec spec, int AuditID)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.DisableDeleteEndUsersRepository.UpdateAuditLog(spec, AuditID);
            }
        }

        public void UpdateOperatorAuditLog(ServiceAction serviceAction, AutoDisableDeleteSpec spec)
        {
            var auditSpec = new AuditSpec(spec.OperatorId, spec.ProviderId){
                        Action = serviceAction,
                        ObjectType = EntityType.AutoDisableDelete,
                        
                    };

            switch (serviceAction)
            {
                case  ServiceAction.AutoDisableDeleteUpdated:
                    auditSpec.ObjectName = "Auto Disable Delete : " + spec.Provider.ProviderName +
                                           " has been saved successfully.";
                    break;

                     case  ServiceAction.AutoDisableJobAction:
                    auditSpec.ObjectName = "Auto Disable Job has been submitted for immediate action.";
                    break;

                     case  ServiceAction.AutoDeleteJobAction:
                    auditSpec.ObjectName = "Auto Delete Job has been submitted for immediate action.";
                    break;

            }
           
            OperationAuditor.LogAction(auditSpec);     
            
        }
        
    }
}
