﻿using System.Collections.Generic;
using AtHoc.IWS.Business.Domain.Settings.Model;
namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public interface IChannelManagerRepository
    {
        IEnumerable<ChannelSettingsList> GetChannelList(ChannelCriteria criteriaSpec, string locale);
        
        //Update Channel Status 
        bool UpdateChannelStatus(ChannelCriteria criteriaSpec);

         //Update Channel details
        bool UpdateChannel(ChannelSettingsModel channelsettingsmodel, int OperatorId);

        //Delete Channel(s)
        bool DeleteChannel(ChannelCriteria criteriaSpec);

        bool DeleteFolder(int intChannelId, int ProviderId, int OperatorId);

        //get Channel details
        ChannelSettingsModel GetChannelDetails(ChannelCriteria criteriaSpec);
         
        //check channel dependency with alert
        List<int> IsAlertAssociated(List<int> channelIds);

        //check  channel name is duplicate or not
        bool IsUniqueFolderName(int providerid, int ChannelId, string strName);
        List<ChannelDependencyList> GetDependencyList(int ChannelId);
        bool IsSystemFolder(int ChannelId);
    }
}
