﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Domain.Settings.Model;

namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public class OperatorAuditFacade1 : IOperatorAuditFacade1
    {
        public readonly IOperatorAuditRepository1 _operatorAuditRepository;

        public OperatorAuditFacade1(IOperatorAuditRepository1 operatorAuditRepository) 
        {
            _operatorAuditRepository = operatorAuditRepository;
        }
        public IEnumerable<OperatorAuditModel> GetOperatorAuditDetails(int providerId, string operatorName, string fromDate, string toDate, string entiryId, string actionId) 
        {
            return _operatorAuditRepository.GetOperatorAuditDetails(providerId, operatorName, fromDate, toDate, entiryId, actionId);
        }

    }
}
