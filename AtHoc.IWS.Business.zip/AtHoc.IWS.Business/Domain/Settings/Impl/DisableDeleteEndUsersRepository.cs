﻿using System;
using System.Linq;
using System.IO;
using System.Data.Entity;
using System.Collections.Generic;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Sql;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Settings.SqlQueries;
using AtHoc.MediaServices;
using AtHoc.Infrastructure.Extensions;
using AtHoc.Systems;
using AtHoc.ComProviders;
using AtHoc.VirtualSystems;
using System.Xml;
using AtHoc.Operators;
using AtHoc.Operators.Entity;
using AtHoc.IWS.Business.Domain.Users.Impl;
using AtHoc.IWS.Business.Domain.Users.Spec;
using System.Data;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Audit;
using AtHoc.Utilities;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.Global.Resources;
using AtHoc.IWS.Business.Data.SearchSpec;

namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public class DisableDeleteEndUsersRepository : IDisableDeleteEndUsersRepository
    {


        /// <summary>
        /// getting the disable and delete users job information
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="isFromDisable"></param>
        /// <returns></returns>
        public DisableDeleteEndUsersModel GetDisableDeleteLastExecutionJobInfo(AutoDisableDeleteSpec autoDisableDeleteSpec)
        {
            var model = new DisableDeleteEndUsersModel();
            string sourceName = string.Empty;
            int scheduleJobId = 0;
            if (autoDisableDeleteSpec.DisableDeleteMode == AutoDisableDeleteMode.Disable)
            {
                sourceName = AttributeCommonNames.DisableDistListCommonName;
                scheduleJobId = AttributeCommonNames.AutoDisableJobId; 
            }
            else
            {
                sourceName = AttributeCommonNames.DeleteDistListCommonName;
                scheduleJobId = AttributeCommonNames.AutoDeleteJobId;
            }
            using (var dbContext = new NgaddataDbContext())
            {
                var parameters = new List<SqlParameter>
                {
                    new SqlParameter("@Source", sourceName),
                    new SqlParameter("@ProviderId",autoDisableDeleteSpec.Provider.Id ),
                };
                using (var lastJobReader = dbContext.ExecuteDataReader(SqlProviderQueries.LastExecutionSelectSql, parameters))
                {
                    if (lastJobReader.Read())
                    {
                        model.LastExecutionTime = DateTime.Parse(lastJobReader.GetValue(lastJobReader.GetOrdinal("LastExecutionTime")).ToString());
                        model.LastJobExecutionTime = autoDisableDeleteSpec.Provider.SystemToVpsDateTimeFormated(Convert.ToDateTime(model.LastExecutionTime));//RuntimeContext.Provider.GetDateTimeFormat());
                        model.AuditId = Int32.Parse(lastJobReader.GetValue(lastJobReader.GetOrdinal("AuditId")).ToString());
                        model.LastExecutionStatus = lastJobReader.GetValue(lastJobReader.GetOrdinal("LastExecutionStatus")).ToString();
                    }
                }
                
                
                var nextJobparameters = new List<SqlParameter>
                {
                    new SqlParameter("@scheduleJobId", scheduleJobId),
                };
                
                using (var nextJobReader = dbContext.ExecuteDataReader(SqlProviderQueries.ScheduledJobSelectSql, nextJobparameters))
                {
                    if (nextJobReader.Read())
                    {
                        model.NextExecutionTime = DateTime.Parse(nextJobReader.GetValue(nextJobReader.GetOrdinal("NextExecutionTime")).ToString());
                        model.NextJobExecutionTime = autoDisableDeleteSpec.Provider.SystemToVpsDateTimeFormated(Convert.ToDateTime(model.NextExecutionTime));//model.NextExecutionTime.ToString(RuntimeContext.Provider.GetDateTimeFormat());
                        model.IntervalUnit = !string.IsNullOrWhiteSpace(nextJobReader.GetValue(nextJobReader.GetOrdinal("IntervalUnit")).ToString()) ? nextJobReader.GetValue(nextJobReader.GetOrdinal("IntervalUnit")).ToString() : "SEC";
                        Duration IntervalDuration = new Duration(model.IntervalUnit, Int32.Parse(nextJobReader.GetValue(nextJobReader.GetOrdinal("IntervalValue")).ToString()));
                        model.Interval = FormatDurationInDays(IntervalDuration);
                    }
                    
                }
                
            }
            return model;
        }




        /// <summary>
        /// formatting the days
        /// </summary>
        /// <param name="secs"></param>
        /// <returns></returns>
        private string FormatDurationInDays(Duration secs)
        {
            TimeSpan ts = new TimeSpan(0, 0, secs.GetSeconds());
            //as per the jeff comment implemented if days are greater than 1 the its Days otherwise Day.
            return ts.Days > 1 ? string.Format("{0} " + IWSResources.DisableDeleteEndUsers_Intervals, ts.Days) : string.Format("{0} " + IWSResources.DisableDeleteEndUsers_Interval, ts.Days);

        }

        /// <summary>
        /// Getting the Audit data for the disable and delete 
        /// </summary>
        /// <param name="AuditID"></param>
        /// <returns></returns>
        public DisableDeleteEndUsersModel GetAuditData(int AuditID)
        {
            var model = new DisableDeleteEndUsersModel();
            using (var dbContext = new NgaddataDbContext())
            {
                var parameters = new List<SqlParameter>
                {
                    new SqlParameter("@AuditId", AuditID),
                };
                var result = dbContext.ExecuteScalar(SqlProviderQueries.GetAuditLog, parameters);
                if (result != null)
                {
                    model.AdditionalInformation = result.ToString();
                }
                return model;
            }
        }

        /// <summary>
        /// updating the audit log
        /// </summary>
        /// <param name="spec"></param>
        /// <param name="AuditID"></param>
        /// <returns></returns>
        public bool UpdateAuditLog(AuditSpec spec, int AuditID)
        {
            using (var dbContext = new NgaddataDbContext())
            {
                var parameters = new List<SqlParameter>
                {
                    new SqlParameter("@AdditionalInfo", spec.AdditionalInfo),
                    new SqlParameter("@Status", spec.Status),
                    new SqlParameter("@AuditId", AuditID)
                };
                var result = dbContext.ExecuteNonQuery(SqlProviderQueries.UpdateAuditLog, parameters);
                if (result > 0)
                {
                    return true;
                }
            }
            return true;
        }
    }
}
