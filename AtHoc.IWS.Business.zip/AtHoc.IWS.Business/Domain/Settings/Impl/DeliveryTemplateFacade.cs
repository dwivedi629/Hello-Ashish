﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Xml.Linq;
using AtHoc.Infrastructure.Domain;
using AtHoc.IWS.Business.Data;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Audit;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Configurations;
using AtHoc.MediaServices;
using AtHoc.IWS.Business.Domain.Events;
using AtHoc.Publishing;
using AtHoc.Global.Resources.Implementations;
using AtHoc.Global.Resources.Interfaces;
using AtHoc.IWS.Business.Context;
using AtHoc.Global.Resources;

namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public class DeliveryTemplateFacade : FacadeBase<IAtHocContextFactory>, IDeliveryTemplateFacade
    {
        private readonly IDeliveryTemplateRepository _deliverTemplatedrepository;
        private readonly GenerateDesktopPreview _generateDesktopPreview;
        private IGlobalEntityLocaleFacade _globalEntityLocaleFacade;

        public DeliveryTemplateFacade(IGlobalEntityLocaleFacade globalEntityLocaleFacade)
            : base(AtHocDbContextFactory.CreateFactory())
        {
            _globalEntityLocaleFacade = globalEntityLocaleFacade;
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                _deliverTemplatedrepository = context.DeliveryTemplateRepository;
                _generateDesktopPreview = new GenerateDesktopPreview();
            }
        }

        public IEnumerable<DeviceGroupSettings> GetDeviceGroups(string locale)
        {
            var data = _globalEntityLocaleFacade.GetLocalizedEntity(_deliverTemplatedrepository.GetDeviceGroups(), locale);
            return data;
        }

        public IEnumerable<DeliveryTemplateModel> GetDeliveryTemplates(DeliveryTemplateCriteria criteriaSpec, string locale)
        {
            IEnumerable<DeliveryTemplateModel> data = null;
            if (_globalEntityLocaleFacade != null)
            {
                data = _globalEntityLocaleFacade.GetLocalizedEntity(_deliverTemplatedrepository.GetDeliveryTemplates(criteriaSpec), locale);
            }
            else
            {
                data = _deliverTemplatedrepository.GetDeliveryTemplates(criteriaSpec);
            }
            
            return data;
        }
        public DeliveryTemplateModel GetDeliveryTemplateDetails(int templateId,string locale)
        {
            var data = _deliverTemplatedrepository.GetTemplateDetails(templateId);
            var templatedata = new DeliveryTemplateModel
            {
                Device_Group_Id = data.deviceGroupId,
                Template_Id = data.templateId,
                Provider_Id = data.providerId,
                Name = data.name,
                Common_Name = data.templateCommonName,
                Device_Group_Name = data.deviceGroupName,
                Description = data.description,
                Device_Id = data.deviceId,
                TemplateDefinition = GetTemplateDefinition(data, data.providerId.HasValue ? data.providerId.Value : 0, string.Empty),
            };

            if (_globalEntityLocaleFacade != null)
            {
                return _globalEntityLocaleFacade.GetLocalizedEntity(templatedata, locale);
            }
            return templatedata;
        }

        
        public TemplateDetailsModel GetTemplateDetails(int templateId, int providerId, string locale, bool isPublishing = true, string commonName = "")
        {
            if (commonName.Length == 0)
            {
                TemplateDetailsModel data=null;
                if (_globalEntityLocaleFacade != null)
                {
                    data = _globalEntityLocaleFacade.GetLocalizedEntity(_deliverTemplatedrepository.GetTemplateDetails(templateId), locale);
                }
                else
                {
                    data = _deliverTemplatedrepository.GetTemplateDetails(templateId);
                }

                if (data.IsDesktopTemplate.HasValue && !data.IsDesktopTemplate.Value)
                    return data;

                data = _generateDesktopPreview.ParseTemplateDefinition(data);
                data.vpsImageId = _deliverTemplatedrepository.GetVPSDetails(providerId).AlertImageId;
                data.standardXslt = _deliverTemplatedrepository.GetLocaleDefaultDefinition(data.LocaleCode, data.deviceGroupId).Definition; 
                if (isPublishing)
                    data.templateDefinition = GetTemplateDefinition(data, providerId, string.Empty);

                return data;
            }
            else {

                TemplateDetailsModel data = null;
                if (_globalEntityLocaleFacade != null)
                {
                    data = _globalEntityLocaleFacade.GetLocalizedEntity(_deliverTemplatedrepository.GetTemplateByCommonNane(commonName), locale);
                }
                else
                {
                    data = _deliverTemplatedrepository.GetTemplateByCommonNane(commonName);
                }                
                return data;       
            }

        }

        public String GetDefautTemplateDefinitionBySeverity(int providerId, Priority severity, int deviceId)
        {
            return _deliverTemplatedrepository.GetDefautTemplateDefinitionBySeverity(providerId, severity, deviceId);
          
        }


        public bool SaveTemplateWithImageData(Stream mMediaData, MediaInfo mMedia, TemplateDetailsModel templateData)
        {
            //Upload image to media database
            if (mMediaData != null)
                templateData.templateImageGuid = _deliverTemplatedrepository.UpdateLogoImage(mMediaData, mMedia);
            //Modify the XML Configuration as per UI changes.
            templateData.xmlConfiguration = _generateDesktopPreview.CreateTemplateDataXml(templateData);
            // save for existing data
            var result = templateData.templateId > 0 ? SaveDeliveryTemplateData(templateData) : _deliverTemplatedrepository.CreateDeliveryTemplate(templateData, Convert.ToInt32(templateData.providerId), templateData.operatorId);
            if (result)
            {
                var auditSpec = new AuditSpec(templateData.operatorId, templateData.providerId)
                {
                    Action = templateData.templateId > 0 ? ServiceAction.DeliveryTemplateUpdated : ServiceAction.DeliveryTemplateCreated,
                    ObjectType = EntityType.DeliveryTemplate,
                    ObjectName = templateData.name
                };
                OperationAuditor.LogAction(auditSpec);
            }
            return result;
        }
        public bool SaveDeliveryTemplateData(TemplateDetailsModel templateData)
        {
            // if it is desktop template then create XML Configuration from the model parameters
            if (templateData.deviceGroupCommonName == Constants.DesktopGroupCommonName)
            {
                if ((templateData.imgOption != Constants.CustomImageOption) && (templateData.templateImageGuid != null))
                    templateData.templateImageGuid = null;
                templateData.xmlConfiguration = _generateDesktopPreview.CreateTemplateDataXml(templateData);
            }

            var blResult = _deliverTemplatedrepository.SaveDeliveryTemplateData(templateData);
            if (blResult)
            {
                var auditSpec = new AuditSpec(templateData.operatorId, templateData.providerId)
                {
                    Action = ServiceAction.DeliveryTemplateUpdated,
                    ObjectType = EntityType.DeliveryTemplate,
                    ObjectName = templateData.name
                };
                OperationAuditor.LogAction(auditSpec);
            }
            return blResult;
        }
        public bool IsValidCommonName(TemplateDetailsModel templateData)
        {
            var blResult = _deliverTemplatedrepository.IsValidCommonName(templateData);
            return blResult;
        }
        public bool IsValidTemplateName(TemplateDetailsModel templateData,ref string strErrorMessage)
        {
            var blResult = false;
            if (templateData.name.IndexOfAny(Constants.InvalidCharacterSet.ToCharArray()) != -1)
            {
                strErrorMessage = IWSResources.DeliveryTemplate_Name_Special_Chars;
                blResult = true;
            }
            else
            {
                strErrorMessage = IWSResources.DeliveryTemplate_Name_AlreadyExists;
                blResult = _deliverTemplatedrepository.IsValidTemplateName(templateData);
            }

            return blResult;
        }
        public string GetCustomImage(string sGuidValue, string sImageType, int providerId)
        {

            var strResult = _deliverTemplatedrepository.GetCustomImage(sGuidValue, sImageType, providerId);
            return strResult;
        }
        public bool DeleteDeliveryTemplate(List<DeliveryTemplateModel> templateIds, int providerId, int userId)
        {

            var blResult = _deliverTemplatedrepository.DeleteDeliveryTemplate(templateIds, providerId);
            var deliveryTemplateName = string.Empty;
            if (blResult)
            {
                if (templateIds.Count() == 1)
                    deliveryTemplateName = templateIds[0].Name;
                var auditSpec = new AuditSpec(userId, providerId)
                {
                    Action = ServiceAction.DeliveryTemplateDeleted,
                    ObjectType = EntityType.DeliveryTemplate,
                    ObjectName = templateIds.Count() == 1 ? deliveryTemplateName : templateIds.Count() + " deliveryTemplate records were deleted"
                };
                OperationAuditor.LogAction(auditSpec);
            }
            return blResult;
        }
        public bool DuplicateDeliveryTemplate(List<DeliveryTemplateModel> templateIds, int providerId, int userId,string localeCode)
        {
            var blResult = _deliverTemplatedrepository.DuplicateDeliveryTemplate(templateIds, providerId, userId, localeCode);
            if (blResult)
            {
                // Update Audit log as per transcation type
                var auditSpec = new AuditSpec(userId, providerId)
                {
                    Action = ServiceAction.DeliveryTemplateDuplicated,
                    ObjectType = EntityType.DeliveryTemplate,
                    ObjectName = templateIds.Count() == 1 ? templateIds[0].Name : templateIds.Count() + " deliveryTemplate records were duplicated"
                };
                OperationAuditor.LogAction(auditSpec);
            }
            return blResult;
        }
        public bool CreateDeliveryTemplate(TemplateDetailsModel deliveryTemplateData, int providerId, int operatorId)
        {
            //Create the XML Configuration as per UI changes.
            if (deliveryTemplateData.deviceGroupCommonName == Constants.DesktopGroupCommonName)
                deliveryTemplateData.xmlConfiguration = _generateDesktopPreview.CreateTemplateDataXml(deliveryTemplateData);
            // Create Delivery Template
            var blResult = _deliverTemplatedrepository.CreateDeliveryTemplate(deliveryTemplateData, providerId, operatorId);
            if (blResult)
            {
                // Update Audit log as per transcation type
                var auditSpec = new AuditSpec(operatorId, providerId)
                {
                    Action = ServiceAction.DeliveryTemplateCreated,
                    ObjectType = EntityType.DeliveryTemplate,
                    ObjectName = deliveryTemplateData.name
                };
                OperationAuditor.LogAction(auditSpec);
            }
            return blResult;
        }
        public TemplateDetailsModel GetTemplateStyleSheet(int deviceGroupId, int providerId,string localeCode)
        {
            var data = _deliverTemplatedrepository.GetTemplateStyelSheet(deviceGroupId, providerId, localeCode);
            data.vpsImageId = _deliverTemplatedrepository.GetVPSDetails(data.providerId).AlertImageId;
            return data;
        }

        public string GetTemplateDefinition(TemplateDetailsModel data, int providerId, string imageData = "")
        {
            if (data.useAdvancedStyle == "N")
            {
               // data.standardXslt = _deliverTemplatedrepository.GetLocaleDefaultDefinition(data.LocaleCode, data.deviceGroupId).Definition;
                data.standardXslt = data.templateDefinition;
                data.xmlConfiguration = _generateDesktopPreview.CreateTemplateDataXml(data);
                data.templateImageLogo = string.IsNullOrEmpty(imageData) ? GetCustomImage(data.templateImageGuid, data.imgOption, providerId) : imageData;
                data.templateDefinition = _generateDesktopPreview.UpdateTemplateXsltData(data);
            }
            else
            {
                data.width = data.width ?? Constants.DefaultWidth;
                data.height = data.height ?? Constants.DefaultHeight;
                data.templateImageLogo = GetCustomImage(data.templateImageGuid, "SYSTEM", providerId);
                data.templateDefinition = _generateDesktopPreview.AdvanceTemplateXsltData(data);
            }
            return data.templateDefinition;
        }


        public bool IsValidXslt(TemplateDetailsModel templateData, string xslt)
        {
            try
            {
                if (templateData.IsDesktopTemplate.HasValue)
                {
                    if (templateData.IsDesktopTemplate.Value)
                    {
                        _generateDesktopPreview.GenerateDesktopReview(xslt, string.Empty, string.Empty, templateData.Severity, templateData.LocaleCode);
                        return true;
                    }

                    // check if XSLT template can be loaded as valid XML
                    if (xslt.Contains("xsl:stylesheet"))
                    {
                        XElement.Parse(xslt);
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                return false;
            }
            return false;
        }

    }
}
