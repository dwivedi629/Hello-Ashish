﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Domain.Settings.Model;
namespace AtHoc.IWS.Business.Domain.Settings
{
    public interface ISystemRepository
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        SystemSetting GetSystemData();

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        GlobalSecuritySettings GetGlobalSecurityData();
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
         List<GlobalConfigurationSettings> GetGlobalConfigData();
        /// <summary>
        /// 
        /// </summary>
        /// <param name="systemsettingsdetails"></param>
        /// <returns></returns>
       
         bool SaveSystemSettings(SystemSettingsModel systemsettingsdetails);
      

    }
}
