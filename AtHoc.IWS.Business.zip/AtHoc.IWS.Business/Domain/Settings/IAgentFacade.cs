﻿
using System.Collections.Generic;
using System.IO;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.MediaServices;
namespace AtHoc.IWS.Business.Domain.Settings
{
    public interface IAgentFacade
    {
        //Get Agent Manager List
        IEnumerable<AgentSettingsList> GetAgentDetails(AgentCriteria criteriaSpec, string locale);
        //Get Agent Manager Detail
        AgentSettings GetAgentManagerDetails(int AgentId, string locale);

        //Delete Agent Manager
        bool DeleteAgentManagerDetails(AgentCriteria criteriaSpec, int userId);

        //Save Agent Manager Data
        bool SaveAgentData(AgentSettings agentData);

        //check Agent is associated with any channels
        List<int> IsAgentAssociated(List<int> agentIds);

        //Validate Common Name
        bool IsValidCommonName(int providerid, int AgentId, string strCommonName);
    }
}
