﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Domain.Settings.Model;
namespace AtHoc.IWS.Business.Domain.Settings
{
   public interface IAudioFileFacade
    {
       IEnumerable<AudioFileSettingsModel> GetAudioFileData(AudioSearchCriteria criteria);
       IEnumerable<AudioFileModel> GetAudioList(AudioSearchCriteria spec);
        
       AudioFileSettingsModel GetAudioFileDataById(int audioFileId,int providerId);

       int SaveAudioFileData(AudioFileSettingsModel audioFileData, int operatorId);

       bool UpdateAudioFileData(AudioFileSettingsModel audioFileData, int operatorId);

       int GetNewAudioFileId();

       bool DeleteAudioFiles(int[] audioFileIds, int providerId, int userId);

       byte[] DownloadAudioFile(int audioId);

       bool UploadAudioFile(byte[] data, int audioId);

       bool IsAudioNameExists(AudioFileSettingsModel audio);

       bool IsAudioCommonNameExists(AudioFileSettingsModel audio);

       List<AudioDefaultSeverities> GetDefaultAudioSeverityData(int? providerId);

    }
}
