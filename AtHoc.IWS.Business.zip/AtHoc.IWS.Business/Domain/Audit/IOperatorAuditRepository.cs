﻿using AtHoc.Infrastructure.Data;
using AtHoc.IWS.Business.Domain.Entities;
using System.Collections.Generic;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Settings;

namespace AtHoc.IWS.Business.Domain.Audit
{
	public interface IOperatorAuditRepository : IRepository<OperatorAudit, AuditSpec> 
    {
        IEnumerable<OperatorAuditModel> GetOperatorAuditDetails(int providerId, string operatorName, string fromDate, string toDate, string entiryId, string actionId);
        IEnumerable<AuditEntity> GetAuditEntities();
        IEnumerable<AuditAction> GetAuditActionsByEntityId(string entityId);    
    }
}
