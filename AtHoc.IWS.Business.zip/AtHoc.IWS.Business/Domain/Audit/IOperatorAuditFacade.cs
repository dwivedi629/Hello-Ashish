﻿using System.Collections.Generic;
using AtHoc.IWS.Business.Domain.Audit.Impl;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Settings;

namespace AtHoc.IWS.Business.Domain.Audit
{
	public interface IOperatorAuditFacade
	{
		AuditResult LogAction(AuditSpec spec);

		IEnumerable<OperatorAudit> GetAuditEventsBySpec(AuditSpec spec);

		OperatorAudit GetAuditEventBySpec(AuditSpec spec);

		void DeleteAuditEvent(AuditSpec spec);

		IEnumerable<OperatorAudit> GetFailedLoginAttempts(AuditSpec spec);
        IEnumerable<OperatorAuditModel> GetOperatorAuditDetails(int providerId, string operatorName, string fromDate, string toDate, string entiryId, string actionId);
        IEnumerable<AuditEntity> GetAuditEntities();
        IEnumerable<AuditAction> GetAuditActionsByEntityId(string entityId);

	}
}