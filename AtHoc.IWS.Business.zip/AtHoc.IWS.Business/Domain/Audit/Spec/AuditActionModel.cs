﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Audit
{
    public class AuditActionModel
    {
        public string ActionId { get; set; }
        public string ActionName { get; set; }
        public string DisplayControlSetting { get; set; }

    }
}
