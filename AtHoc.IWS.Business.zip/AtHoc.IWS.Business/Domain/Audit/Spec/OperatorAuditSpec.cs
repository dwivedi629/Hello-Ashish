﻿using System;
using System.Collections.Generic;
using System.Linq;

using AtHoc.Infrastructure.Entity;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.Audit
{
	public class AuditSpec : EntitySpec
	{
		public AuditSpec()
		{
			ObjectIds = Enumerable.Empty<int>();
		}

		public AuditSpec(int? operatorId, int? providerId) : this()
		{
			OperatorId = operatorId;
			ProviderId = providerId;
		}

		public int? OperatorId { get; set; }

		public int? ProviderId { get; set; }

		public ServiceAction? Action { get; set; }

		public EntityType? ObjectType { get; set; }

		public string ObjectName { get; set; }

		public IEnumerable<int> ObjectIds { get; set; }

		public string Source { get; set; }

		public string AdditionalInfo { get; set; }

		public string Status { get; set; }

		public int? ActionDateTime { get; set; }

		[Obsolete]
		public int? AuditId { get; set; }

		[Obsolete]
		public string ServerName { get; set; }

		public string Username { get; set; }
	}
}
