﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Audit
{
    public class AuditEntity
    {
        public string ObjectId { get; set; }
        public string ObjectName { get; set; }
        public string DisplayControlSetting { get; set; }

    }
}
