﻿using System.Linq;

using AtHoc.IWS.Business.Data;
using AtHoc.Infrastructure.Domain;

namespace AtHoc.IWS.Business.Domain.Audit
{
	public class AuditFacade : FacadeBase<IAtHocContextFactory>, IAuditFacade
	{
		public AuditFacade(IAtHocContextFactory contextFactory) : base(contextFactory) { }

		public int LogAction(IAuditActionSpec spec)
		{
			return new OperationAuditor(spec).LogAction();
		}

		public AuditEvent GetAuditEventBySpec(AuditEventSpec spec)
		{
			using (var context = ContextFactory.CreateNgaddataContext())
			{
				return context.AuditEventRepository.FindBySpec(spec).SingleOrDefault();
			}
		}

		public void DeleteAuditEvent(AuditEventSpec spec)
		{
			using (var context = ContextFactory.CreateNgaddataContext())
			{
				context.AuditEventRepository.DeleteBySpec(spec);
			}
		}
	}
}
