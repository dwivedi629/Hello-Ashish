﻿using System;
using System.ComponentModel;

namespace AtHoc.IWS.Business.Domain.Audit
{
	public enum AuditedAction
	{
		#region Alert
		[Description("AMC00")]
		CreatedPublished,

		[Description("AMC02")]
		AlertActivated,

		[Description("AMC10")]
		CreatedStandby,

		[Description("AMC11")]
		CreatedScheduled,

		[Description("AMC12")]
		AlertPublished,

		[Description("AMC01")]
		PublishedFromQap,

		[Description("AMC21")]
		MovedtoUserArchive,

		[Description("AMC22")]
		MovedtoSystemArchive,

		//[Description("AMC21")]
		//AlertEnded,

		[Description("AMC90")]
		AlertDeleted,

		[Description("AMC20")]
		AlertUpdated,

		#endregion Alert

		#region Scenario
		[Description("SCN00")]
		ScenarioCreated,

		[Description("SCN90")]
		ScenarioDeleted,

		[Description("SCN20")]
		ScenarioUpdated,
		#endregion Scenario

		#region Audio
		[Description("AUD00")]
		AudioCreated,

		[Description("AUD90")]
		AudioDeleted,

		[Description("AUD20")]
		AudioUpdated,
		#endregion Audio

		#region Button
		[Description("BTN00")]
		ButtonCreated,

		[Description("BTN01")]
		ButtonDuplicated,

		[Description("BTN90")]
		ButtonDeleted,

		[Description("BTN20")]
		ButtonUpdated,
		#endregion Button

		#region DeliveryTemplate
		[Description("TPL00")]
		DeliveryTemplateCreated,

		[Description("TPL01")]
		DeliveryTemplateDuplicated,

		[Description("TPL20")]
		DeliveryTemplateUpdated,

		[Description("TPL90")]
		DeliveryTemplateDeleted,
		#endregion DeliveryTemplate

		#region Feed
		[Description("DUP00")]
		FeedPublished,
		#endregion Feed

		#region Gateway
		[Description("DGS20")]
		GatewayUpdated,
		#endregion Gateway

		#region User

		[Description("USR00")]
		UserCreated,

		[Description("USR10")]
		UserEnablingFailed,

		[Description("USR11")]
		UserDisablingFailed,

		[Description("USR21")]
		UserDisabled,

		[Description("USR22")]
		UserEnabled,

		[Description("USR20")]
		UserUpdated,

		[Description("USR30")]
		UserExport,

		[Description("USR40")]
		UserImport,

		[Description("USR41")]
		UserCancelImport,

		[Description("USR50")]
		UserBatchDeleted,

		[Description("USR51")]
		UserBatchDisabled,

		[Description("USR23")]
		EndUserDeleted,
		#endregion User

		#region System
		[Description("CAT20")]
		SystemCatalogUpdated,

		[Description("PRV20")]
		SystemProviderUpdated,
		#endregion System

		#region Group
		[Description("GRS00")]
		GroupSetCreated,

		[Description("GRS20")]
		GroupSetUpdated,

		[Description("GRS90")]
		GroupSetDeleted,
		#endregion Group

		#region LiveUpdate
		[Description("LUA00")]
		LiveUpdateActivate,

		[Description("LUA22")]
		LiveUpdateAbort,

		[Description("LUA01")]
		LiveUpdateDuplicate,

		[Description("LUA20")]
		LiveUpdate,
		#endregion LiveUpdate

		#region Svc
		[Description("SRV10")]
		SvcDisabled,

		[Description("SRV00")]
		SvcCreated,

		[Description("SRV02")]
		SvcEnabled,

		[Description("SRV20")]
		SvcUpdated,

		[Description("SRV90")]
		SvcDeleted,
		#endregion Svc

		#region ToolBar
		[Description("TLB02")]
		ToolBarSaveAsDraft,

		[Description("TLB01")]
		ToolBarSaveAndUpdate,

		[Description("TLB00")]
		ToolBarPublish,
		#endregion ToolBar

		#region Operator
		[Description("OPR00")]
		OperatorCreated,

		[Description("OPR01")]
		OperatorActivated,

		[Description("OPR02")]
		OperatorSuspended,

		[Description("OPR03")]
		OperatorLocked,

		[Description("OPR10")]
		OperatorCreationFailed,

		[Description("OPR20")]
		OperatorUpdated,

		[Description("OPR90")]
		OperatorDeleted,
		#endregion Operator

		#region Password
		[Description("OPR21")]
		PasswordChanged,

		[Description("OPR11")]
		PasswordChangeErrorPasswordIncorrect,

		[Description("OPR12")]
		PasswordChangeErrorPasswordInvalid,

		[Description("OPR13")]
		PasswordChangeErrorPasswordTooSimilar,

		[Description("OPR14")]
		PasswordChangeErrorPasswordSame,

		[Description("OPR15")]
		PasswordChangeErrorNoMinimumTime,

		[Description("OPR16")]
		PasswordChangeErrorMinCharChange,

		[Description("OPR19")]
		PasswordChangeUnknownError,

		[Description("OPR31")]
		PasswordChangeAccountExpired,

		[Description("OPR32")]
		PasswordChangeAccountSuspendedOrLocked,
		#endregion Password

		#region CustomAttribute
		[Description("CFM00")]
		CustomAttributeCreated,

		[Description("CFM20")]
		CustomAttributeUpdated,

		[Description("CFM90")]
		CustomAttributeDeleted,

		[Description("CFM25")]
		CustomAttributeCleared,
		#endregion CustomAttribute

		#region DistributionList
		[Description("DLM00")]
		DistributionListCreated,

		[Description("DLM01")]
		DistributionListDuplicated,

		[Description("DLM20")]
		DistributionListUpdated,

		[Description("DLM90")]
		DistributionListDeleted,

		[Description("DLM40")]
		DistributionListImported,

		#endregion DistributionList

		#region Login
		[Description("LOG00")]
		LoginSuccess,

		[Description("LOG01")]
		LoginSuccessPasswordExpired,

		[Description("LOG11")]
		LoginFailedWrongUsername,

		[Description("LOG12")]
		LoginFailedWrongPassword,

		[Description("LOG13")]
		LoginFailedSessionExpired,

		[Description("LOG14")]
		LoginFailedAccountLocked,

		[Description("LOG15")]
		LoginFailedAccountSuspended,

		[Description("LOG16")]
		LoginFailedAccountExpired,

		[Description("LOG17")]
		LoginFailedPasswordReset,

		[Description("LOG18")]
		LoginFailedPasswordExpired,

		[Description("LOG30")]
		LoginFailedNoSdkAccess,

		[Description("LOG19")]
		LoginFailedOtherReason,
		#endregion Login

		#region Logout
		[Description("LOG02")]
		LogoutSuccessful,

		[Description("LOG03")]
		LogoutTimedOut,

		[Description("LOG04")]
		LogoutMaxSessionLimit,
		#endregion Logout

		#region Agent
		[Description("AGT00")]
		AgentCreated,

		[Description("AGT01")]
		AgentDuplicated,

		[Description("AGT20")]
		AgentUpdated,

		[Description("AGT90")]
		AgentDeleted,
		#endregion Agent

		#region Device
		[Description("DVC02")]
		DeviceEnabled,

		[Description("DVC10")]
		DeviceDisabled,

		[Description("DVC20")]
		DeviceUpdated,
		#endregion Device

		#region Vps
		[Description("PRV00")]
		VpsEnter,

		[Description("PRV01")]
		VpsExit,
		#endregion Vps

		#region CascadingVps
		[Description("SVP00")]
		CascadingVpsCreated,

		[Description("SVP20")]
		CascadingVpsUpdated,

		[Description("SVP90")]
		CascadingVpsRemoved,
		#endregion

		#region DbArchival
		[Description("ARV00")]
		DbArchivalStarted,

		[Description("ARV01")]
		DbArchivalArchived,
		#endregion

		#region Monitor
		[Description("MTR00")]
		MonitorCreated,

		[Description("MTR20")]
		MonitorUpdated,

		[Description("MTR90")]
		MonitorDeleted,
		#endregion

		#region PlaceHolder
		[Description("PLH01")]
		PlaceHolderCreated,

		[Description("PLH02")]
		PlaceHolderUpdated,

		[Description("PLH03")]
		PlaceHolderDeleted,
		#endregion

		#region Map
		[Description("MAP01")]
		MapSetupUpdated,

		[Description("MAP11")]
		MapShapeCreated,

		[Description("MAP12")]
		MapShapeUpdated,

		[Description("MAP13")]
		MapShapeDeleted,
		#endregion

		#region System
		[Description("SYS01")]
		SystemSetupUpdated,

		[Description("SYS02")]
		SecurityPolicyUpdated,
		#endregion System

		#region Ssa
		[Description("SSA00")]
		SsaSsaSetupUpdated,

		[Description("SSA01")]
		SsaActivityLogCreated,

		[Description("SSA02")]
		SsaActivityLogClosed
		#endregion
	}
}
