﻿using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Database;
using AtHoc.Infrastructure.Sql;

namespace AtHoc.IWS.Business.Domain.Audit
{
	public class AuditEventDbRepository : DbRepository<AuditEvent, AuditEventSpec>, IAuditEventRepository
	{
		public AuditEventDbRepository(IUnitOfWork context) : base(context) {}

		protected override void TranslateSpec(AuditEventSpec spec, SqlBuilder builder, bool query)
		{
			builder.SelectAll<AuditEvent>();
			builder.From(builder.Table<AuditEvent>());

			if (spec.AuditId.HasValue)
				builder.Where(builder.Condition(AuditEvent.Meta.AuditId, ConditionOperator.Equals, spec.AuditId.Value));
		}
	}
}
