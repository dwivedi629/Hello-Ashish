﻿using System.Collections.Generic;
using System.Linq;
using AtHoc.Infrastructure.Domain;
using AtHoc.IWS.Business.Data;
using AtHoc.IWS.Business.Domain.Audit.Impl;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Settings.Model;

namespace AtHoc.IWS.Business.Domain.Audit
{
	public class OperatorAuditFacade : FacadeBase<IAtHocContextFactory>, IOperatorAuditFacade
	{
		public OperatorAuditFacade(IAtHocContextFactory contextFactory) : base(contextFactory) { }

		public AuditResult LogAction(AuditSpec spec)
		{
			return new OperationAuditor(spec).LogAction();
		}

		public OperatorAudit GetAuditEventBySpec(AuditSpec spec)
		{
			using (var context = ContextFactory.CreateNgaddataContext())
			{
				return context.OperatorAuditRepository.FindBySpec(spec).SingleOrDefault();
			}
		}

		public IEnumerable<OperatorAudit> GetAuditEventsBySpec(AuditSpec spec)
		{
			using (var context = ContextFactory.CreateNgaddataContext())
			{
				return context.OperatorAuditRepository.FindBySpec(spec);
			}
		}

		public void DeleteAuditEvent(AuditSpec spec)
		{
			using (var context = ContextFactory.CreateNgaddataContext())
			{
				context.OperatorAuditRepository.DeleteBySpec(spec);
			}
		}

		public IEnumerable<OperatorAudit> GetFailedLoginAttempts(AuditSpec spec)
		{
			spec.Action = ServiceAction.LoginFailedWrongPassword;
			spec.OrderBy = OperatorAudit.Meta.ActionTimestamp;
			spec.OrderAsc = false;
			return this.GetAuditEventsBySpec(spec);
		}

        public IEnumerable<OperatorAuditModel> GetOperatorAuditDetails(int providerId, string operatorName, string fromDate, string toDate, string entiryId, string actionId)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.OperatorAuditRepository.GetOperatorAuditDetails(providerId, operatorName, fromDate, toDate, entiryId, actionId);
            }            
        }

        public IEnumerable<AuditEntity> GetAuditEntities()
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.OperatorAuditRepository.GetAuditEntities();
            }
        }

        public IEnumerable<AuditAction> GetAuditActionsByEntityId(string entityId)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.OperatorAuditRepository.GetAuditActionsByEntityId(entityId);
            }
        }
	}
}
