﻿using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Database;
using AtHoc.Infrastructure.Sql;
using System.Collections.Generic;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Database;
using System.Linq;
using AtHoc.IWS.Business.Domain.Settings.Model;

namespace AtHoc.IWS.Business.Domain.Audit
{
	public class OperatorAuditDbRepository : DbRepository<OperatorAudit, AuditSpec>, IOperatorAuditRepository
	{
		public OperatorAuditDbRepository(IUnitOfWork context) : base(context) {}

		protected override void TranslateSpec(AuditSpec spec, SqlBuilder builder, bool query)
		{
			builder.SelectAll<OperatorAudit>();
			builder.From(query ? "UPS_AUDIT_TAB with (nolock)" : builder.Table<OperatorAudit>());

			if (spec.AuditId.HasValue)
				builder.Where(builder.Condition(OperatorAudit.Meta.AuditId, ConditionOperator.Equals, spec.AuditId.Value));

			if (spec.Action.HasValue)
				builder.Where(builder.Condition(
					OperatorAudit.Meta.ActionId, ConditionOperator.Equals, EnumUtils<ServiceAction>.GetDescriptionByValue(spec.Action.Value)));

			if (spec.ActionDateTime.HasValue)
				builder.Where(builder.Condition(OperatorAudit.Meta.ActionTimestamp, ConditionOperator.GreaterThanEquals, spec.ActionDateTime.Value));

			if (spec.OperatorId.HasValue)
				builder.Where(builder.Condition(OperatorAudit.Meta.UserId, ConditionOperator.Equals, spec.OperatorId.Value));

			if (spec.ProviderId.HasValue)
				builder.Where(builder.Condition(OperatorAudit.Meta.ProviderId, ConditionOperator.Equals, spec.ProviderId.Value));
		}

        public IEnumerable<OperatorAuditModel> GetOperatorAuditDetails(int providerId,string operatorName,string fromDate,string toDate,string entityId,string actionId )
        {           
            object[] parameters = { providerId, operatorName ,fromDate,toDate,entityId,actionId};
            IEnumerable<OperatorAuditModel> data = null;
            using (var repository = new EntityFrameworkRepository(new AtHocDbContext()))
            {
                 data = repository.RunQuery<OperatorAuditModel>(
                 "dbo.OPR_AUDIT_TRAIL_DETAILS @providerId , @operatorName , @fromDate , @toDate , @entityId , @actions ",parameters).ToList();
            }
            return data;
        }

        public IEnumerable<AuditEntity> GetAuditEntities()
        {
            using (var db = new AtHocDbContext())
            {
                return db.AuditEntity.Select(o => o).OrderBy(i => i.ObjectName).ToList();
            }
        }

        public IEnumerable<AuditAction> GetAuditActionsByEntityId(string entityId)
        { 
            using(var db= new AtHocDbContext())
            {
                return db.AuditAction.Where(o => o.ActionId.Substring(0,3).Equals(entityId)).OrderBy(i=>i.ActionName).ToList();
            }
        }
	}
}