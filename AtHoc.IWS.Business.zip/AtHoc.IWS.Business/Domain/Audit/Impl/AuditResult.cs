﻿using AtHoc.Infrastructure.Domain;

namespace AtHoc.IWS.Business.Domain.Audit.Impl
{
	public class AuditResult : ActionResult<int?> { }
}
