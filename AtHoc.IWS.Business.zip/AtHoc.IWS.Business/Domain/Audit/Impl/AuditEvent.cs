﻿using System.ComponentModel.DataAnnotations;

using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;

namespace AtHoc.IWS.Business.Domain.Audit
{
	[MetadataType(typeof (AuditEventMeta))]
	[MetaObject(TableName = "UPS_AUDIT_TAB")]
	public class AuditEvent : EntityBase
	{
		[MetaProperty(ColumnName = "AUDIT_ID", DbTypeName = "int")]
		[Required]
		public virtual int AuditId
		{
			get { return Get<int>("AuditId"); }
			set { Set("AuditId", value); }
		}

		[MetaProperty(ColumnName = "USER_ID", DbTypeName = "int")]
		[Required]
		public virtual int UserId
		{
			get { return Get<int>("UserId"); }
			set { Set("UserId", value); }
		}

		[MetaProperty(ColumnName = "USERNAME", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
		public virtual string UserName
		{
			get { return Get<string>("UserName"); }
			set { Set("UserName", value); }
		}

		[MetaProperty(ColumnName = "PROVIDER_ID", DbTypeName = "int")]
		[Required]
		public virtual int ProviderId
		{
			get { return Get<int>("ProviderId"); }
			set { Set("ProviderId", value); }
		}

		[MetaProperty(ColumnName = "ACTION_ID", DbTypeName = "nvarchar", MaxLength = 10, AutoTrim = true)]
		[MaxLength(10)]
		public virtual string ActionId
		{
			get { return Get<string>("ActionId"); }
			set { Set("ActionId", value); }
		}

		[MetaProperty(ColumnName = "ACTION_TIMESTAMP", DbTypeName = "int")]
		[Required]
		public virtual int ActionTimeStamp
		{
			get { return Get<int>("ActionTimeStamp"); }
			set { Set("ActionTimeStamp", value); }
		}

		[MetaProperty(ColumnName = "ACTION_DATE", DbTypeName = "int")]
		[Required]
		public virtual int ActionDate
		{
			get { return Get<int>("ActionDate"); }
			set { Set("ActionDate", value); }
		}

		[MetaProperty(ColumnName = "OBJECT_TYPE", DbTypeName = "nvarchar", MaxLength = 10, AutoTrim = true)]
		[MaxLength(10)]
		public virtual string ObjectType
		{
			get { return Get<string>("ObjectType"); }
			set { Set("ObjectType", value); }
		}

		[MetaProperty(ColumnName = "OBJECT_ID", DbTypeName = "int")]
		[Required]
		public virtual int ObjectId
		{
			get { return Get<int>("ObjectId"); }
			set { Set("ObjectId", value); }
		}

		[MetaProperty(ColumnName = "OBJECT_NAME", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string ObjectName
		{
			get { return Get<string>("ObjectName"); }
			set { Set("ObjectName", value); }
		}

		[MetaProperty(ColumnName = "CLIENT_IP", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string ClientIp
		{
			get { return Get<string>("ClientIp"); }
			set { Set("ClientIp", value); }
		}

		[MetaProperty(ColumnName = "SOURCE", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
		public virtual string Source
		{
			get { return Get<string>("Source"); }
			set { Set("Source", value); }
		}

		[MetaProperty(ColumnName = "SERVER_NAME", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
		public virtual string ServerName
		{
			get { return Get<string>("ServerName"); }
			set { Set("ServerName", value); }
		}

		[MetaProperty(ColumnName = "ADDITIONAL_INFO", DbTypeName = "nvarchar", AutoTrim = true)]
		public virtual string AdditionalInfo
		{
			get { return Get<string>("AdditionalInfo"); }
			set { Set("AdditionalInfo", value); }
		}

		[MetaProperty(ColumnName = "STATUS", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string Status
		{
			get { return Get<string>("Status"); }
			set { Set("Status", value); }
		}

		#region Properties

		public class Meta
		{
			public static readonly MetaProperty AuditId = MetaObject.Get(typeof (AuditEvent))["AuditId"];

			public static readonly MetaProperty UserId = MetaObject.Get(typeof (AuditEvent))["UserId"];

			public static readonly MetaProperty UserName = MetaObject.Get(typeof (AuditEvent))["UserName"];

			public static readonly MetaProperty ProviderId = MetaObject.Get(typeof (AuditEvent))["ProviderId"];

			public static readonly MetaProperty ActionId = MetaObject.Get(typeof (AuditEvent))["ActionId"];

			public static readonly MetaProperty ActionTimeStamp = MetaObject.Get(typeof (AuditEvent))["ActionTimeStamp"];

			public static readonly MetaProperty ActionDate = MetaObject.Get(typeof (AuditEvent))["ActionDate"];

			public static readonly MetaProperty ObjectType = MetaObject.Get(typeof (AuditEvent))["ObjectType"];

			public static readonly MetaProperty ObjectId = MetaObject.Get(typeof (AuditEvent))["ObjectId"];

			public static readonly MetaProperty ObjectName = MetaObject.Get(typeof (AuditEvent))["ObjectName"];

			public static readonly MetaProperty ClientIp = MetaObject.Get(typeof (AuditEvent))["ClientIp"];

			public static readonly MetaProperty Source = MetaObject.Get(typeof (AuditEvent))["Source"];

			public static readonly MetaProperty ServerName = MetaObject.Get(typeof (AuditEvent))["ServerName"];

			public static readonly MetaProperty AdditionalInfo = MetaObject.Get(typeof (AuditEvent))["AdditionalInfo"];

			public static readonly MetaProperty Status = MetaObject.Get(typeof (AuditEvent))["Status"];
		}

		#endregion Properties
	}

	#region AuditEventMeta

	public class AuditEventMeta
	{
	}

	#endregion AuditEventMeta
}