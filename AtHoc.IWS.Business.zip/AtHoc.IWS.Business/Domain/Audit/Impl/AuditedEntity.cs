﻿using System.ComponentModel;

namespace AtHoc.IWS.Business.Domain.Audit
{
	public enum AuditedEntity
	{
		[Description("AMC")]
		Alert,

		[Description("SCN")]
		Scenario,

		[Description("ARV")]
		DbArchive,

		[Description("PRV")]
		VirtualSystem,

		[Description("LOG")]
		LoginAttempt,

		[Description("MTR")]
		Monitor,

		[Description("DGS")]
		DeliveryGateway,

		[Description("USR")]
		EndUsers,

		[Description("SSA")]
		Ssa,

		[Description("MAP")]
		Map,

		[Description("PLH")]
		PlaceHoder,

		[Description("SYS")]
		System,

		[Description("OPR")]
		Operator,

		[Description("CFM")]
		CustomFieldManager,

		[Description("DLM")]
		DistributionListManager,

		[Description("SRV")]
		ServiceChannel,

		[Description("TPL")]
		DeliveryTemplate,

		[Description("AGT")]
		AgentEntity,

		[Description("AUD")]
		Audio,

		[Description("SVP")]
		SubProvider
	}
}
