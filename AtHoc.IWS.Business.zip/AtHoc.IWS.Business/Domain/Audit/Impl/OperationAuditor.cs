﻿using System;
using System.Linq;

using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Resources;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Audit.Impl;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Users.Impl;
using AtHoc.IWS.Business.Domain.Users.Spec;

namespace AtHoc.IWS.Business.Domain.Audit
{
	internal class OperationAuditor
	{
		private readonly AuditSpec _spec;

		internal OperationAuditor(AuditSpec spec)
		{
			_spec = spec;
		}

	    internal static void LogAction(AuditSpec spec)
	    {
	        new OperationAuditor(spec).LogAction();
	    }

		internal static void LogAction(ServiceAction action, EntityType entityType, string objectName)
		{
			new OperationAuditor(new AuditSpec
				{
					Action = action,
					ObjectType = entityType,
					ObjectName = objectName
				}
			).LogAction();
		}

		internal AuditResult LogAction()
		{
			int? resultValue = null;
			var messages = new Messages();

			if (!_spec.Action.HasValue)
				messages.CreateErrorMessage("Audit: Action type is not provided");

			if (!_spec.ObjectType.HasValue)
				messages.CreateErrorMessage("Audit: Object type is not provided");

			if (!messages.HasErrors() && RuntimeContext.Operator.HasValue())
			{
			    if (_spec.OperatorId.HasValue && _spec.OperatorId > 0)
			    {
			        string operatorName;
			        if (!string.IsNullOrEmpty(_spec.Username))
			            operatorName = _spec.Username;
			        else
			        {
					    var operatorUser = new UserFacade().GetOperatorUserBySpec(new OperatorUserSpec {OperatorId = _spec.OperatorId.Value});
			            operatorName = operatorUser.Username;
			        }

				    var providerId = _spec.ProviderId.HasValue ? _spec.ProviderId.Value : RuntimeContext.Provider.Id;

				    resultValue = Operators.OperationAuditor.LogAction(
				        operatorName,
				        providerId,
				        EnumUtils<ServiceAction>.GetDescriptionByValue(_spec.Action.Value),
				        EnumUtils<EntityType>.GetDescriptionByValue(_spec.ObjectType.Value),
				        _spec.ObjectName,
				        _spec.ObjectIds.ToArray(),
				        _spec.Source,
				        _spec.AdditionalInfo
				        );				    
				}
			}

			return new AuditResult {Messages = messages, Value = resultValue};
		}

		#region Pegasus implementation
		/*
		internal int LogAction()
		{
			if (!_spec.ProviderId.HasValue)
			{
				throw new ApplicationException("Can`t log action, no provider ID specified.");
			}

			if (!_spec.UserId.HasValue && _spec.OperatorUsername.HasValue())
			{
				throw new ApplicationException("Can`t log action, no operator ID or name specified.");
			}

			if (_spec.UserId.HasValue)
			{
				ValidateOperator(new OperatorUserSpec { OperatorId = _spec.UserId });
			}

			if (_spec.OperatorUsername.HasValue())
			{
				ValidateOperator(new OperatorUserSpec {UserName = _spec.OperatorUsername});
			}

			return ProcessLogAction();
		}

		#region Private

		private void ValidateOperator(OperatorUserSpec spec)
		{
			var userFacade = ServiceLocator.Resolve<IOperatorDetailsFacade>();
			var op = userFacade.GetOperatorUserBySpec(spec);
			if (op == null)
			{
				throw new ApplicationException("Can`t log action, invalid operator cridentials.");
			}
		}

		private int ProcessLogAction()
		{
			var contextFactory = ServiceLocator.Resolve<IAtHocContextFactory>();
			using (var context = contextFactory.CreateNgaddataContext())
			{
				context.UseTransaction = true;
				//DateTime currDateTime = AtHocSystem.Local.CurrentDateTime; <- ???
				var currDateTime = DateTime.Now;
				var actionTimestamp = currDateTime;
				var actionDate = currDateTime.Date;

				int auditId;
				if (_spec.ObjectIds.HasValue())
				{
					auditId = new SequenceHelper(context).GetSequence("AUDIT", _spec.ObjectIds.Count());
					foreach (var objectId in _spec.ObjectIds)
					{
						SaveAuditLog(context, auditId, actionTimestamp, actionDate);
						if (objectId != _spec.ObjectIds.Last())
						{
							auditId++;
						}
					}
				}
				else
				{
					auditId = new SequenceHelper(context).GetSequence("AUDIT");
					SaveAuditLog(context, auditId, actionTimestamp, actionDate);
				}
				context.Commit();
				return auditId;
			}
		}

		private void SaveAuditLog(INgaddataContext context, int auditId, DateTime actionTimestamp, DateTime actionDate)
		{
			var auditEvent = new OperatorAudit
			{
				ActionDate = actionDate,
				ActionId = _spec.Action.Value,
				ActionDateTime = actionTimestamp,
				AdditionalInfo = _spec.AdditionalInfo,
				AuditId = auditId,
				ClientIp = _spec.ClientIp,
				ProviderId = _spec.ProviderId.Value,
				ObjectType = _spec.ObjectType.Value,
				ObjectName = _spec.ObjectName,
				Source = _spec.Source,
				ServerName = _spec.ServerName,
				Status = _spec.Status
			};

			if (_spec.UserId.HasValue)
				auditEvent.UserId = _spec.UserId.Value;

			if (_spec.OperatorUsername.HasValue())
				auditEvent.Username = _spec.OperatorUsername;

			if (_spec.ObjectId.HasValue)
				auditEvent.ObjectId = _spec.ObjectId.Value;

			context.OperatorAuditRepository.Save(auditEvent);
		}

		#endregion Private
 * */
		#endregion Pegasus implementation
	}
}