﻿using System.Collections.Generic;

using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.Audit
{
	public interface IAuditActionSpec
	{
		int? AuditId { get; set; }

		int? OperatorId { get; }

		int? ProviderId { get; }

		int? ObjectId { get; }

		EntityType? ObjectType { get; }

		string ObjectName { get; }

		IEnumerable<int> ObjectIds { get; }

		string Source { get; }

		string AdditionalInfo { get; }

		string Status { get; }

		string ClientIp { get; }

		string ServerName { get; }

		string OperatorUsername { get; }

		ServiceAction Action { get; set; }
	}
}
