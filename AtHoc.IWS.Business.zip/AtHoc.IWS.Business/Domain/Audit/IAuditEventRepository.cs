﻿using AtHoc.Infrastructure.Data;

namespace AtHoc.IWS.Business.Domain.Audit
{
	public interface IAuditEventRepository : IRepository<AuditEvent, AuditEventSpec> { }
}
