﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using AtHoc.Data;
using AtHoc.Infrastructure.Log;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.SSA.Business;
using AtHoc.IWS.SSA.Business.Dictionaries;
using AtHoc.IWS.SSA.Business.Facades;
using AtHoc.IWS.SSA.Dictionaries;

namespace AtHoc.IWS.Business.Domain.Notification
{
    public class NotificationRepository : INotificationRepository
    {
        private static DateTime? _latestTimeShape = null;
        private static DateTime? _latestTimeEvent = null;
        private static DateTime? _latestTimeAlert = null;
        private static int? _latestTimeResponse = null;
        private static int? _latestTimePeople = null;
        private static DateTime? _latestTimeLayer = null;
      
        /// <summary>
        /// Get Notifications for all VPS
        /// </summary>
        /// <param name="lastPullTime"></param>
        /// <returns></returns>
        public IList<Notification> GetSignalRNotifications(ref DateTime ? lastPullTime )
        {
            var lstOfNotification = new List<Notification>();

            AtHoc.Infrastructure.Sql.SqlParameter paramSinceDateTime;
            if (lastPullTime.HasValue)
            {
                paramSinceDateTime =  new AtHoc.Infrastructure.Sql.SqlParameter("@sinceDateTime", lastPullTime.Value);
            }
            else
            {
                paramSinceDateTime = new AtHoc.Infrastructure.Sql.SqlParameter("@sinceDateTime", null);
            }
            using (var dbcontext = AtHocDbContextFactory.CreateFactory().CreateNgaddataContext())
            {
                var dtNotifications = dbcontext.ExecuteDataSet("EXEC SNR_GET_NOTIFICATION_UPDATES", paramSinceDateTime);
                if (dtNotifications != null && dtNotifications.Tables.Count ==2)
                {
                    //For some reason, OUT parameter is not giving value, thus using dataset to capture two recordset.
                    //table[1] - gives the List of Providers which has updates
                    //table[0] - gives the database utc time which is set to lastpulltime variable.
                    lstOfNotification = ConvertToNotificationModel(dtNotifications.Tables[1]);
                    lastPullTime = Convert.ToDateTime(dtNotifications.Tables[0].Rows[0][0]);
                }
                else
                {
                    LogService.Current.Error(() => "SignalR Notification: Stored Procedure SNR_GET_NOTIFICATION_UPDATES should return atleast 2 tables. ");
                }
            }
            
            return lstOfNotification;
        }

        public IList<MapLayer> GetActiveMapLayers(int providerId)
        {
            using (var context = new AtHocDbContext())
            {
                var mapLayers = context.MapLayers.Where(
                    x =>
                        x.ProviderId == providerId &&
                        x.Status != "DEL" && x.SortOrder >= 0 && !x.Name.ToLower().Equals("shared layer") 
                        &&
                        //only return maplayers with type polygon or multipolygon
                        x.ShapeNotifications.Any(
                            z =>
                                z.Geometry.SpatialTypeName.ToLower() == "polygon" ||
                                z.Geometry.SpatialTypeName.ToLower() == "multipolygon"));
                return mapLayers.ToList();
            }
       }

        public IList<ShapeNotification> GetShapesByLayerId(int layerId)
        {
            using (var context = new AtHocDbContext())
            {
                var mapLayer = context.MapLayers.FirstOrDefault(x=> x.Id == layerId);
                if (mapLayer == null)
                {
                    return null;
                }
                else
                {
                    return mapLayer.ShapeNotifications.ToList();
                }
            }
        }

	   

	    public int CreateOrUpdateShapeInSharedLayer(int providerId, string geoWkt,int spatialId = 0)
	    {
		    var mapLayerId = -1;
		    using (var context = new AtHocDbContext())
		    {
			    var mapLayer = context.MapLayers.FirstOrDefault(x => x.ProviderId == providerId &&
			                                                         x.Status != "DEL" && x.Name.ToLower().Equals("temporary locations"));
			    mapLayerId = mapLayer != null ? mapLayer.Id : -1;
		    }

		    if (mapLayerId >= 0)
		    {
			    using (var context = new NgadDatabase())
			    {

				    context.CommandType = CommandType.StoredProcedure;
				    context.AddParameter(new SqlParameter("@mapLayerId", mapLayerId));
				    context.AddParameter(new SqlParameter("@spatialName", "CustomLocation"));
				    context.AddParameter(new SqlParameter("@spatialWKT", geoWkt));
				    context.AddParameter(new SqlParameter("@description", "CustomLocation"));
				    context.AddParameter(new SqlParameter("@isMobileAccessable", false));
				    context.AddParameter(new SqlParameter("@visibilityLevel", (int) VisibilityLevelType.Public));
				    context.AddParameter(new SqlParameter("@shapeType", (int) MapLayerShapeType.Polygon));
				    var mapLayerSpatialIdParam = context.AddParameter("@mapLayerSpatialId", SqlDbType.Int,
					    ParameterDirection.InputOutput);
					mapLayerSpatialIdParam.Value = spatialId;
				    context.ExecuteNonQuery(StoredProcedure.SetMapLayerSpatialQuery);
				    return (int) mapLayerSpatialIdParam.Value;
			    }

		    }
		    return -1;
	    }

	    /// <summary>
        /// Convert Datatable model to Notifivation object model
        /// </summary>
        /// <param name="dtNotifications"></param>
        /// <returns></returns>
        private List<Notification> ConvertToNotificationModel(DataTable dtNotifications)
        {
            var lstOfNotification = new List<Notification>();
            foreach (DataRow dr in dtNotifications.Rows)
            {
                var notification = ConvertToNotificatoinModel(dr);
                lstOfNotification.Add(notification);
            }
            return lstOfNotification;
        }

        /// <summary>
        /// Convert Datarow to Object Model of type notification
        /// </summary>
        /// <param name="drNotification"></param>
        /// <returns></returns>
        private Notification ConvertToNotificatoinModel(DataRow drNotification)
        {
            var notification = new Notification();
            notification.ProviderId = Convert.ToInt32(drNotification["PROVIDER_ID"]);
            notification.LastUpdatedOn = Convert.ToDateTime(drNotification["LAST_UPDATED_ON"]);
            switch (drNotification["CONTEXT"].ToString())
            {
                case "MAP":
                    notification.ContentId = "map";
                    break;
                case "SHAPE":
                    notification.ContentId = "map";
                    break;
                case "EVENT":
                    notification.ContentId = "event";
                    break;
                case "ALERT":
                    notification.ContentId = "response";
                    break;
                case "ALERT_RESPONSE":
                    notification.ContentId = "response";
                    break;
                case "PEOPLE":
                    notification.ContentId = "people";
                    break;
                default:
                    notification.ContentId = string.Empty;
                    break;
                 
            }
            return notification;
        }

       
        public IList<Notification> GetShapeNotifications()
        {
            IList<Notification> notifications = new List<Notification>();
            if (!_latestTimeShape.HasValue)
            {
                var db = new AtHocDbContext();
                Func<ShapeNotification, DateTime> latestTimeFunc = x => x.UpdatedOn;
                _latestTimeShape = DateTime.UtcNow; // GetLastTimeStamp(db, db.ShapeNoticaNotifications, latestTimeFunc);
            }
            else
            {
                IList<ShapeNotification> latestUpdates = GetShapeNotifications(_latestTimeShape.Value);
                if (latestUpdates.Any())
                {
                    IList<int> existingProviderIds = new List<int>();
                    foreach (var update in latestUpdates)
                    {
                        if (!existingProviderIds.Contains(update.MapLayer.ProviderId))
                        {
                            existingProviderIds.Add(update.MapLayer.ProviderId);
                            notifications.Add(new Notification
                            {
                                ProviderId = update.MapLayer.ProviderId,
                                ContentId = "map"
                            });
                        }
                    }
                    _latestTimeShape = latestUpdates.Max(e => e.UpdatedOn);
                }
            }
            return notifications;
        }

        public IList<Notification> GetEventNotifications()
        {
            IList<Notification> notifications = new List<Notification>();
            if (!_latestTimeEvent.HasValue)
            {
                var db = new AtHocEventDbContext();
                Func<AtHoc.IWS.Business.Domain.Entities.Event, DateTime> latestTimeFunc = x => x.UpdatedOn;
                _latestTimeEvent = DateTime.UtcNow;//  GetLastTimeStamp(db, db.Events, latestTimeFunc);
            }
            else
            {
                IList<AtHoc.IWS.Business.Domain.Entities.Event> latestUpdates = GetEventNotifications(_latestTimeEvent.Value);
                if (latestUpdates.Any())
                {
                    IList<int> existingProviderIds = new List<int>();
                    foreach (var update in latestUpdates)
                    {
                        if (!existingProviderIds.Contains(update.EventCategory.ProviderId.Value))
                        {
                            existingProviderIds.Add(update.EventCategory.ProviderId.Value);
                            notifications.Add(new Notification
                            {
                                ProviderId = update.EventCategory.ProviderId.Value,
                                ContentId = "event"
                            });
                        }
                    }
                    _latestTimeEvent = latestUpdates.Max(e => e.UpdatedOn);
                }
            }
            return notifications;
        }

        public IList<Notification> GetAlertNotifications()
        {
            IList<Notification> notifications = new List<Notification>();
            if (!_latestTimeAlert.HasValue)
            {
                var db = new AtHocDbContext();
                Func<AlertNotification, DateTime> latestTimeFunc = x => (x.UpdatedOn.HasValue ? x.UpdatedOn.Value : new DateTime(2000, 1, 1));
                _latestTimeAlert = DateTime.UtcNow;//GetLastTimeStamp(db, db.AlertNoticaNotifications, latestTimeFunc);
            }
            else
            {
                IList<AlertNotification> latestUpdates = GetAlertNotifications(_latestTimeAlert.Value);
                if (latestUpdates.Any())
                {
                    IList<int> existingProviderIds = new List<int>();

                    foreach (var update in latestUpdates)
                    {
                        if (!existingProviderIds.Contains(update.ProviderId))
                        {
                            existingProviderIds.Add(update.ProviderId);
                            notifications.Add(new Notification
                            {
                                ProviderId = update.ProviderId,
                                ContentId = "response"
                            });
                        }
                    }

                    _latestTimeAlert = latestUpdates.Max(e => e.UpdatedOn);
                }
            }
            return notifications;
        }

        public IList<Notification> GetResponseNotifications()
        {
            IList<Notification> notifications = new List<Notification>();
            if (!_latestTimeResponse.HasValue)
            {
                using (var db = new AtHocDbContext())
                {
                    try
                    {
                        _latestTimeResponse = db.ResponseNoticaNotifications.Where(x => x.UpdatedOn.HasValue).Max(x => x.UpdatedOn.Value);
                    }
                    catch
                    {
                        _latestTimeResponse = null;
                    }
                }
            }
            else
            {
                IList<ResponseNotification> latestUpdates = GetResponseNotifications(_latestTimeResponse.Value);
                if (latestUpdates.Any())
                {
                    IList<int> existingProviderIds = new List<int>();

                    foreach (var update in latestUpdates)
                    {
                        if (!existingProviderIds.Contains(update.User.ProviderId))
                        {
                            existingProviderIds.Add(update.User.ProviderId);
                            notifications.Add(new Notification
                            {
                                ProviderId = update.User.ProviderId,
                                ContentId = "response"
                            });
                        }
                    }
                    _latestTimeResponse = latestUpdates.Max(e => e.UpdatedOn);
                }
            }
            return notifications;
        }

        public int GetLastKnownLocationAttrId()
        {
            LastLocation lastLocation;
            using (var db = new AtHocDbContext())
            {
                lastLocation = db.LastLocation.FirstOrDefault(x => x.AttributeName == "LAST-KNOWN-LOCATION");
            }
            return lastLocation.Id;
        }

        public IList<Notification> GetMapLayerNotifications()
        {
            IList<Notification> notifications = new List<Notification>();
            if (!_latestTimeLayer.HasValue)
            {
                var db = new AtHocDbContext();
                Func<MapLayer, DateTime> latestTimeFunc = x => (x.UpdatedOn.HasValue ? x.UpdatedOn.Value : new DateTime(2000, 1, 1));
                _latestTimeLayer = DateTime.UtcNow;//GetLastTimeStamp(db, db.MapLayers, latestTimeFunc);
            }
            else
            {
                IList<MapLayer> latestUpdates = GetMapLayerNotifications(_latestTimeLayer.Value);
                if (latestUpdates.Any())
                {
                    //IList<int> existingProviderIds = new List<int>();
                    string sourceType = "";
                    foreach (var update in latestUpdates)
                    {
                        switch (update.SourceType)
                        {
                            case 0:
                                sourceType = "map";
                                break;
                            case 2:
                                sourceType = "people";
                                break;
                        }
                        //if (!existingProviderIds.Contains(update.ProviderId))
                        //{
                            //existingProviderIds.Add(update.ProviderId);
                            notifications.Add(new Notification
                            {
                                ProviderId = update.ProviderId,
                                ContentId = sourceType
                            });
                        //}
                    }
                    _latestTimeLayer = latestUpdates.Max(e => e.UpdatedOn);
                }
            }
            return notifications;
        } 

        public IList<Notification> GetPeopleNotifications(int attributeId)
        {
            IList<Notification> notifications = new List<Notification>();
            if (!_latestTimePeople.HasValue)
            {
                using (var db = new AtHocDbContext())
                {
                    int latestTime = db.PeopleNotifications.Max(x => x.UpdatedOn);
                    _latestTimePeople = latestTime;
                }
            }
            else
            {
                IList<PeopleNotification> latestUpdates = GetPeopleNotifications(_latestTimePeople.Value, attributeId);
                if (latestUpdates.Any())
                {
                    IList<int> existingProviderIds = new List<int>();

                    foreach (var update in latestUpdates)
                    {
                        if (!existingProviderIds.Contains(update.User.ProviderId))
                        {
                            existingProviderIds.Add(update.User.ProviderId);
                            notifications.Add(new Notification
                            {
                                ProviderId = update.User.ProviderId,
                                ContentId = "people"
                            });
                        }
                    }
                    _latestTimePeople = latestUpdates.Max(e => e.UpdatedOn);
                }
            }
            return notifications;
        }

      
        private DateTime GetLastTimeStamp<T>(DbContext db, IEnumerable<T> events, Func<T, DateTime> query) where T: class 
        {
            using (db)
            {
                DateTime latestTime = events.Max(query);
                return latestTime;
            }
        }

        private IList<ShapeNotification> GetShapeNotifications(DateTime lastTime)
        {
            using (var db = new AtHocDbContext())
            {
                var latestUpdates = (db.ShapeNoticaNotifications.Include("MapLayer").Where(s => s.UpdatedOn > lastTime)).ToList();
                return latestUpdates;
            }
        }

        private IList<AtHoc.IWS.Business.Domain.Entities.Event> GetEventNotifications(DateTime lastTime)
        {
            using (var db = new AtHocEventDbContext())
            {
                var latestUpdates = (db.Events.Include("EventCategory").Where(s => s.UpdatedOn > lastTime)).ToList();
                return latestUpdates;
            }
        }

        private IList<AlertNotification> GetAlertNotifications(DateTime lastTime)
        {
            using (var db = new AtHocDbContext())
            {
                var latestUpdates = db.AlertNoticaNotifications.Where(s => s.UpdatedOn > lastTime).ToList();
                return latestUpdates;
            }
        }

        private IList<ResponseNotification> GetResponseNotifications(int lastTime)
        {
            using (var db = new AtHocDbContext())
            {
                // status == 3 means the user responded.
                var latestUpdates = db.ResponseNoticaNotifications.Include("User").Where(s => s.UpdatedOn.HasValue && s.UpdatedOn.Value > lastTime && s.Status.HasValue && s.Status.Value == 3).ToList();
                return latestUpdates;
            }
        }

        private IList<PeopleNotification> GetPeopleNotifications(int lastTime, int attributeId)
        {
            using (var db = new AtHocDbContext())
            {
                // status == 3 means the user responded.
                var latestUpdates = db.PeopleNotifications.Include("User").Where(s => s.UpdatedOn > lastTime && s.AttributeId == attributeId).ToList();
                return latestUpdates;
            }
        }
        private IList<MapLayer> GetMapLayerNotifications(DateTime lastTime)
        {
            using (var db = new AtHocDbContext())
            {
                var latestUpdates = db.MapLayers.Where(s => s.UpdatedOn > lastTime).ToList();
                return latestUpdates;
            }
        }
    }
}
