﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Notification
{
    public interface INotificationRepository
    {
        IList<Notification> GetShapeNotifications();
        IList<Notification> GetEventNotifications();
        IList<Notification> GetAlertNotifications();
        IList<Notification> GetResponseNotifications();
        IList<Notification> GetPeopleNotifications(int attributeId);
        int GetLastKnownLocationAttrId();
        IList<Notification> GetMapLayerNotifications();

        IList<Notification> GetSignalRNotifications(ref DateTime ? lastPullTime);

        IList<MapLayer> GetActiveMapLayers(int providerId);

        IList<ShapeNotification> GetShapesByLayerId(int layerId);

		int CreateOrUpdateShapeInSharedLayer(int providerId, string geoWkt, int spatialId = 0);
    }
}
