﻿using System.Collections.Generic;

using AtHoc.Infrastructure.Entity;

namespace AtHoc.IWS.Business.Domain.Publishing.Spec
{
	public class DistributionListDependencySpec : EntitySpec
	{
		//public int UserId { get; set; }

		public IEnumerable<int> ListIds { get; set; }

	    public int ProviderId { get; set; }
	}
}
