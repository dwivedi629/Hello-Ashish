﻿using System.Collections.Generic;

using AtHoc.Infrastructure.Entity;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.Publishing
{
	public class OperatorChannelSpec : EntitySpec
	{
		public int? ProviderId { get; set; }

		public int? OperatorId { get; set; }

		public int? ChannelId { get; set; }

		public IEnumerable<OperatorChannel> Channels { get; set; }

		public IEnumerable<OperatorUserRole> Roles { get; set; }
	}
}
