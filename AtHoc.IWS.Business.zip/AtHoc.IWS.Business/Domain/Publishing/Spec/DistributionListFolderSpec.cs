﻿using AtHoc.Infrastructure.Entity;

namespace AtHoc.IWS.Business.Domain.Publishing.Spec
{
	public class DistributionListFolderSpec : EntitySpec
	{
		public int? ParentListId { get; set; }

		public int? ChildListId { get; set; }
	}
}
