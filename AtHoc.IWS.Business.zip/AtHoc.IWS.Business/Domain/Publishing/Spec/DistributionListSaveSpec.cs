﻿using System.Linq;
using System.Collections.Generic;

using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Service;

namespace AtHoc.IWS.Business.Domain.Publishing
{
	public class DistributionListSaveSpec : BaseServiceSpec
	{
		public DistributionListSaveSpec()
		{
			UserIds = Enumerable.Empty<int>();
			ChildListsIds = Enumerable.Empty<int>();
		}

		public DistributionList List { get; set; }

		public IEnumerable<int> UserIds { get; set; }

		public IEnumerable<int> ChildListsIds { get; set; }
	}
}