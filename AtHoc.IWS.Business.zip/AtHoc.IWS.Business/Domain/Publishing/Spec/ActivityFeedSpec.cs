﻿using System;
using System.Collections;
using System.Collections.Generic;
using AtHoc.Infrastructure.Entity;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Spec;

namespace AtHoc.IWS.Business.Domain.Publishing
{
	public class ActivityFeedSpec : EntitySpec
	{
		public int? AlertId { get; set; }

		public int? UserId { get; set; }

		public int? ProviderId { get; set; }

        /// <summary>
        /// Free form text string. The search will be performed both on Alert Body and Title
        /// </summary>
		public string SearchString { get; set; }

        /// <summary>
        /// If you want the exact time. Not very userful
        /// </summary>
		public DateTime? EventTime { get; set; }

        /// <summary>
        /// Alert Sent Time End Date
        /// </summary>
		
        public DateTime? MaxEventTime { get; set; }
        /// <summary>
        /// Alert Sent Time Begin Date
        /// </summary>
		
        public DateTime? MinEventTime { get; set; }
        
        /// <summary>
        ///Activity Feed Type is either Alert or Alert Reponse. If you pass alert, you will only get one record for alert, if you pass
        /// AlertResponse, then you will get multiple rows with detail response which is used for activity timeline 
        /// </summary>

		public ActivityFeedType? EventType { get; set; }

        /// <summary>
        /// List of Event Category Ids that you want to do the search on
        /// </summary>
        public List<int> EventCategoryId { get; set; }

        /// <summary>
        /// Integer for Alert Severity that you want to search on
        /// </summary>
        public List<int> Severity { get; set; }

        /// <summary>
        /// Pass boolean value to get the alerts that have reply pending
        /// </summary>
        public bool? PendingReply { get; set; }

        /// <summary>
        /// Pass boolean value to get the alerts that are live or ended
        /// </summary>
        public bool? IsEnded { get; set; }

        public string SourceName { get; set; }






	}

}
