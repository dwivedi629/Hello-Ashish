﻿using System.Collections.Generic;

using AtHoc.Infrastructure.Entity;

using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Service;

namespace AtHoc.IWS.Business.Domain.Publishing
{
	public class DistributionListSpec : EntitySpec, IServiceSpec
	{
		public DistributionListSpec()
		{
			IncludeUserBase = false;
			IncludeLists = true;
		}

		public string Name { get; set; }

		public string CommonName { get; set; }

		public int? OperatorId { get; set; }

		public bool IncludeParentChildren { get; set; }

		public bool SelectFirstLevelRelatives { get; set; }

        public bool IncludeHierarchy { get; set; }

		public bool IncludeCustomAttribute { get; set; }

		public bool IncludeTranslatedDefinition { get; set; }

		public bool IncludeUserBase { get; set; }

		public bool IncludeLists { get; set; }

		public int? ProviderId { get; set; }

		public bool? IsCascaded { get; set; }

		public IEnumerable<ListItemType> DistributionListTypes { get; set; }

		public int? HierarchyId { get; set; }

		public IEnumerable<int> HierarchyIds { get; set; }

		public UserStatusType? Status { get; set; }

		public bool? ExcludeDeleted { get; set; }

		public int? ParentListId { get; set; }

		public string SearchStringStartsWith { get; set; }

		public string SearchStringContains { get; set; }

		public string SearchStringNotStartsWith { get; set; }

		public IEnumerable<int> Ids { get; set; }

		public int? Id { get; set; }

		public IEnumerable<string> ContainsLineages { get; set; }

		public IEnumerable<string> StartsWithLineages { get; set; }

		public IEnumerable<string> EndsWithLineages { get; set; }

		public string EqualLineage { get; set; }

		public IEnumerable<string> SearchStringsContains { get; set; }

		public IEnumerable<string> SearchStringsNotStartsWith { get; set; }

		public int? UserId { get; set; }

		public IEnumerable<int> ExcludeIds { get; set; }

		public bool? IsSystem { get; set; }

        public bool? IsTemporary { get; set; }

        public AccessType AccessType { get; set; }
	}
}