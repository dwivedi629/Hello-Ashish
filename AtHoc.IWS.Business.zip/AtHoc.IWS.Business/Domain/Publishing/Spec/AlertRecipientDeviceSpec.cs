﻿using AtHoc.Infrastructure.Entity;

namespace AtHoc.IWS.Business.Domain.Publishing
{
	public class AlertRecipientDeviceSpec : EntitySpec
	{
		public int? AlertId { get; set; }
	}
}
