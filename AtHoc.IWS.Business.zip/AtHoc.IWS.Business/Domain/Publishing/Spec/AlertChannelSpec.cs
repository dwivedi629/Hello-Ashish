﻿using AtHoc.Infrastructure.Entity;

namespace AtHoc.IWS.Business.Domain.Publishing
{
    public class AlertChannelSpec : EntitySpec
    {
        public AlertChannelSpec()
        {
            GetProvListonFail = true;
        }

        public int? ChannelId { get; set; }
        
        public string Search { get; set; }
        
        public int? ProviderId { get; set; }
        
        public string CommonName { get; set; }
        
        public int? OperatorId { get; set; }

        public bool? GetProvListonFail { get; set; }
    }
}
