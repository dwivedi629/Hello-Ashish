﻿using System.Collections.Generic;

using AtHoc.Infrastructure.Entity;

using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.Publishing.Spec
{
	public class DistributionListItemSpec : EntitySpec
	{
		public int? Id { get; set; }

		public int? UserId { get; set; }

		public int? ProviderId { get; set; }

		public bool? IsSystem { get; set; }

		public string CommonName { get; set; }

		public IEnumerable<string> ExcludeCommonNames { get; set; }

		public IEnumerable<int> ListIds { get; set; }

		public IEnumerable<int> ExcludeIds { get; set; }

		public int? ChildListId { get; set; }

		public string SearchString { get; set; }

		public IEnumerable<ListItemType> DistributionListTypes { get; set; }
	}
}
