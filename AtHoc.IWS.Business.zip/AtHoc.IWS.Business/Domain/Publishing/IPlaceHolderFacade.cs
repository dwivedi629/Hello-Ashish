﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Data;
using AtHoc.IWS.Business.Data.SearchSpec;
using AtHoc.IWS.Business.Domain.Entities;  
using AtHoc.Publishing.Service;

namespace AtHoc.IWS.Business.Domain.Publishing
{
    public interface IPlaceHolderFacade
    {
        /// <summary>
        /// To get the Placeholders in PlaceHolderSimpleItem model
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="operatorId"></param>
        /// <returns></returns>
        IEnumerable<AtHoc.IWS.Business.Domain.Entities.PlaceHolderSimpleItem> GetPlaceHolderList(int providerId, int operatorId);

        /// <summary>
        /// To get the Placeholder List model
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="operatorId"></param>
        /// <returns></returns>        
        IEnumerable<CustomAttribute> GetPlaceHolderByProvider(int providerId, int operatorId);

        IEnumerable<PlaceHolder> GetCustomerPlaceHolders(PlaceHoldersToAlertDto obj, int providerId, int operatorId);

        /// <summary>
        /// To get System Placeholders
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="operatorId"></param>
        /// <returns></returns>
        IEnumerable<PlaceHolder> GetSystemPlaceHolders(SystemPlaceholders systemPlaceholders, int providerId,
            int operatorId);

        IList<EventPlaceholders> GetEventPlaceholders(string locale);
    }
}
