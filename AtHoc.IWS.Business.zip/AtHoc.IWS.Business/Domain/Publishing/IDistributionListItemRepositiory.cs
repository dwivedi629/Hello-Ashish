﻿using AtHoc.Infrastructure.Data;

using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Publishing.Spec;

namespace AtHoc.IWS.Business.Domain.Publishing
{
	public interface IDistributionListItemRepositiory : IRepository<DistributionListItem, DistributionListItemSpec> {}
}