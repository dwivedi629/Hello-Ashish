﻿using System.Collections.Generic;
using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Resources;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.Publishing
{
    public interface IOperatorChannelRepository
    {
        IEnumerable<OperatorChannel> FindBySpec(OperatorChannelSpec spec);
        Messages DeleteBySpec(OperatorChannelSpec spec);
        Messages UpdateBySpec(OperatorChannelSpec spec);
        bool IsAlertFoldersUnrestricted(int userId, int providerId);
    }
}
