﻿using System;
using System.Data;
using AtHoc.Data;
using AtHoc.IWS.Business.Data.SearchSpec;
using AtHoc.IWS.Business.Domain.Entities;
using System.Collections.Generic;
using AtHoc.IWS.Business.Domain.Reports;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Targeting.Model;
using AtHoc.Publishing;
using System.Collections;


namespace AtHoc.IWS.Business.Domain.Publishing
{
    /// <summary>
    /// Alert Facade for services related to Alert
    /// </summary>
    public interface IAlertFacade
    {
        /// <summary>
        /// Gets data for the alert tracking summary data
        /// </summary>
        /// <param name="alertId"></param>
        /// <param name="type">summary or detail</param>
        /// <param name="dim">dimension: user, org, mass</param>
        /// <returns>object which contains summary header and response details</returns>
        AlertTrackingResult GetAlertTrackingSummary(int alertId, ReportType type, Dimension dim);

        ArrayList GetAlertReportData(int providerId, AlertReportCriteria reportCriteria);

        DataTable GetTargetUserBase(ResultBasedTargetingCriteria rbtCriteria);

        IPaged<DtoAlert> GetAlerts(AlertSearchSpec spec);

        List<ResponseOption> GetAlertResponseOptions(int alertId);

        IList<Language> GetSupportedLanguages(int providerId);

        bool CanModifyPerUserbase(int operatorId, int providerId, IEnumerable<int> list, ref List<int> unmodifiableAlerts);

        bool Delete(int operatorId, int providerId, IEnumerable<int> list);

        bool End(int operatorId, int providerId, IEnumerable<int> list);

        //Set Alert End time
        bool End(int alertId, int operatorId, int providerId, DateTime endTime);
        Alert GetAlert(int id, int providerId, int operatorId);
        Alert DuplicateAlert(int id, int providerId, int operatorId);
        Alert CreateAlert(int providerId, int operatorId);
        Alert CreateAlertFromScenario(int providerId, int operatorId, int scenarioId);
        bool SaveAlert(int providerId, int operatorId, Alert alert);
        bool StandbyAlert(int providerId, int operatorId, Alert alert);
        bool PublishAlert(int providerId, int operatorId, Alert alert);
        /// <summary>
        /// Returns all publisher/operator names for the given provider
        /// </summary>
        /// <param name="providerId">Providerid</param>
        /// <returns>List of publisher names</returns>
        IList<string> GetPublisherByProviderId(int providerId);

        IEnumerable<DtoAlert> GetAlertsForMap(AlertSearchSpec eventSpec, bool getEventAlert = false);

        int GetMapAlertCount(IEnumerable<int> alertIds, bool isEvent);
    }
}
