﻿using System.Collections.Generic;
using AtHoc.IWS.Business.Data.SearchSpec;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.Publishing
{
    public interface IScenarioRepository
    {
        IEnumerable<Scenario> GetScenarios(int providerId, int operatorId, ScenarioSearchSpec spec);
    }
}
