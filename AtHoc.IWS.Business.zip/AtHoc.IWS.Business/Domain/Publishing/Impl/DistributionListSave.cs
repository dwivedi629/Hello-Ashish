﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Xml;

using AtHoc.IWS.Business.Domain.Authorization;
using AtHoc.IWS.Business.Domain.Publishing.Spec;
using AtHoc.IWS.Business.Domain.Users.Impl;

using AtHoc.Infrastructure.Domain;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Data;

using AtHoc.IWS.Business.Data;
using AtHoc.IWS.Business.Service;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.Global.Resources;

namespace AtHoc.IWS.Business.Domain.Publishing.Impl
{
    public class DistributionListSave : NgaddataService<bool, DistributionListSaveSpec>
    {
        private bool _isListNew;

        protected override void ProcessServiceParameter(INgaddataContext context, DistributionListSaveSpec spec, IServiceResult<bool> result)
        {
            var list = spec.List;
            _isListNew = spec.List.IsNew;
            if (!spec.OperatorId.HasValue)
                result.Messages.CreateErrorMessage("Operator id is not provided");
            else if (list.ProviderId == 0)
                result.Messages.CreateErrorMessage("List provider id is not set");
            else if (!list.Lineage.HasValue())
                result.Messages.CreateErrorMessage("List lineage is not set");
            else if (!list.HierarchyId.HasValue)
                result.Messages.CreateErrorMessage("List hierarchy id is not set");
            else
                ValidateListName(list, context, result.Messages);

            if (result.IsValid)
                PreprocessDistributionList(context, spec, result, list);

            if (result.IsValid)
            {
                UpdateCustomAttribute(context, list);
                result.Messages.Add(context.DistributionListRepository.Save(list, true));
            }

            if (!result.IsValid) return;

            if (list.ListType == ListItemType.Static && !IsCascadedList(list))
                AssignUsersToStaticList(context, spec, list);

            if (list.ListType == ListItemType.Ip)
                SaveIpDetails(context, spec, list);

            AssignChildListsToList(context, spec, list);
            AddUserPermissionsOnList(context, spec, list);

            result.ActionType = _isListNew ? ServiceAction.DistributionListCreated : ServiceAction.DistributionListUpdated;
            result.EntityType = EntityType.DistributionListManager;
            result.OutputContext = list.Name;
        }

#warning Refactor using repositories after release...
        private void SaveIpDetails(INgaddataContext context, DistributionListSaveSpec spec, DistributionList list)
        {
            if (!_isListNew)
            {
                const string DELETE_SQL = "DELETE FROM PDL_IP_DETAIL_TAB WHERE LIST_ID = @listId";
                var query = new DbQuery(context, DELETE_SQL);
                query.AddParameter("listId", list.Id);
                query.Execute();
            }

            if (!list.Definition.HasValue()) return;

            var ipXml = new XmlDocument();
            ipXml.LoadXml(list.Definition);
            foreach (XmlNode addressNode in ipXml.SelectNodes("ipListDefinition/address"))
            {
                const string SAVE_SQL =
                    @"INSERT INTO PDL_IP_DETAIL_TAB
						(LIST_ID, RANGE_FROM, RANGE_TO, SUBNET_MASK, PADDED_RANGE_FROM, PADDED_RANGE_TO)
					VALUES (@listId, @ip1, @ip2, @type, dbo.GET_PADDED_IP_ADDRESS(@paddedip1), dbo.GET_PADDED_IP_ADDRESS(@paddedip2))";
                var query = new DbQuery(context, SAVE_SQL);
                query.AddParameter("listId", list.Id);
                query.AddParameter("ip1", addressNode.SelectSingleNode("address1").InnerText);
                query.AddParameter("ip2", addressNode.SelectSingleNode("address2").InnerText);
                query.AddParameter("type", addressNode.Attributes.GetNamedItem("type").InnerText);
                query.AddParameter("paddedip1", addressNode.SelectSingleNode("translatedAddress1").InnerText);
                query.AddParameter("paddedip2", addressNode.SelectSingleNode("translatedAddress2").InnerText);
                query.Execute();
            }
        }

        private static bool IsCascadedList(DistributionList list)
        {
            return !string.IsNullOrWhiteSpace(list.FromSubProvider) && list.FromSubProvider == "Y";
        }

        private void UpdateCustomAttribute(INgaddataContext context, DistributionList list)
        {
            if (_isListNew || IsCascadedList(list) || list.ListType != ListItemType.Static)
                return;

            var customAttribute = context.CustomAttributeRepository.FindById(Convert.ToInt32(list.Definition));

            var staticListAttribute = new CustomAttributeModel
            {
                ProviderId = customAttribute.ProviderId,
                Id = customAttribute.Id,
                EntityId = customAttribute.EntityId,
                Name = list.Name,
                CommonName = list.CommonName,
                AttributeTypeId = (int)CustomAttributeDataType.Checkbox,
                DefaultValue = String.Empty,
                IsMandatory = customAttribute.IsMandatory,
                IsSystem = customAttribute.IsSystemAttribute,
                Description = String.Empty,
                IsEncrypted = customAttribute.IsEncrypted,
                EditLevel = customAttribute.EditLevel??2,
                CreatedOn = customAttribute.ToString(),
                CreatedBy = Convert.ToString(customAttribute.CreatedBy),
                HelpText = String.Empty,
                IsStandard = customAttribute.IsStandard,
                SupportsHistory = customAttribute.SupportsHistoricalValues,
                PickListValuesCSV="YES",
                IconId = 0
            };

            context.CustomAttributeRepository.SaveAttribute(staticListAttribute);
        }

        private static void AssignChildListsToList(INgaddataContext context, DistributionListSaveSpec spec, DistributionList list)
        {
            context.DistributionListFolderDbRepository.DeleteBySpec(
                    new DistributionListFolderSpec { ParentListId = list.Id }
                );

            if (!spec.ChildListsIds.HasValue())
                return;

            var sortOrder = 1;
            foreach (var childListId in spec.ChildListsIds)
            {
                context.DistributionListFolderDbRepository.Save(
                    new DistributionListFolder
                    {
                        ParentListId = list.Id,
                        ChildListId = childListId,
                        SortOrder = sortOrder
                    });
                sortOrder++;
            }
        }

        private void AddUserPermissionsOnList(INgaddataContext context, DistributionListSaveSpec spec, DistributionList list)
        {
            if (!_isListNew) return;

            var user = UserManager.GetUser(
                    new SystemUserSpec
                    {
                        HasAccessList = true,
                        HasChannels = false,
                        HasDistributionLists = false,
                        HasEndUser = false,
                        HasPermissions = true,
                        HasRoles = false,
                        HasUserBase = false,
                        OperatorId = spec.OperatorId,
                        ProviderId = spec.ProviderId.HasValue ? spec.ProviderId.Value : 0
                    }
                );

            if (user.IsManagableAccessListUnrestricted()) return;

            var operatorAccess = user.OperatorAccess.ToArray();
            if (operatorAccess.HasPermission(SystemObject.DistributionLists, ActionType.Modify))
                AddUserListPermission(context, spec, list, "MGT");
            if (operatorAccess.HasPermission(SystemObject.DistributionLists, ActionType.Publish))
                AddUserListPermission(context, spec, list, "TRG");
        }

        private static void AddUserListPermission(INgaddataContext context, DistributionListSaveSpec spec, DistributionList list, string accessType)
        {
            var entityAccess = new OperatorEntityAccess
            {
                ProviderId = list.ProviderId,
                UserId = spec.OperatorId.Value,
                AccessType = accessType,
                EntityId = list.Id,
                EntityType = "LST"
            };
            context.OperatorEntityAccessRepository.Save(entityAccess);
        }

        private static void PreprocessDistributionList(INgaddataContext context, DistributionListSaveSpec spec, IActionResult<bool> result, DistributionList list)
        {
            if (list.IsNew)
            {
                list.UpdatedBy = list.CreatedBy = spec.OperatorId;
                list.UpdatedOn = list.CreatedOn = DateTimeConverter.GetSystemTimeAsSeconds();
                list.Status = DistributionListStatusType.Active;

                if (!list.IsSystem.HasValue())
                    list.IsSystem = "N";

                if (list.ListType == ListItemType.Static)
                    CreateStaticListCustomAttribute(context, spec, result, list);
            }
            else
            {
                list.UpdatedBy = spec.OperatorId;
                list.UpdatedOn = DateTimeConverter.GetSystemTimeAsSeconds();
            }

            // TBD: Enterprise Alerting implementation (default to N)
            list.IsExtended = "N";
        }

        private static void CreateStaticListCustomAttribute(INgaddataContext context, DistributionListSaveSpec spec, IActionResult<bool> result, DistributionList list)
        {
            var staticListAttribute = new CustomAttributeModel
            {
                ProviderId = list.ProviderId,
                EntityId = "USER",
                Name = list.Name,
                CommonName = list.CommonName,
                AttributeTypeId = (int)CustomAttributeDataType.Checkbox,
                DefaultValue = String.Empty,
                IsMandatory = "N",
                IsSystem = "Y",
                Description = String.Empty,
                IsEncrypted = "N",
                EditLevel = 2,
                CreatedOn = Convert.ToString(DateTimeConverter.GetSystemTimeAsSeconds()),
                CreatedBy = Convert.ToString(spec.OperatorId),
                HelpText = String.Empty,
                IsStandard = "N",
                SupportsHistory = "N",
                IconId = 0
            };
            staticListAttribute.Id = context.CustomAttributeRepository.SaveAttribute(staticListAttribute);
            list.Id = staticListAttribute.Id;
            list.AttributeId = staticListAttribute.Id;
            list.Definition = staticListAttribute.Id.ToString(CultureInfo.InvariantCulture);

        }

        private static void AssignUsersToStaticList(INgaddataContext context, DistributionListSaveSpec spec, DistributionList list)
        {
            int staticListValueId = 0;
            var staticListAttribute =
                context.CustomAttributeRepository.SingleOrDefaultBySpec(new CustomAttributeSpec
                {
                    ProviderId = list.ProviderId,
                    Id = Convert.ToInt32(list.Definition),
                    BaseLocale = spec.BaseLocale
                });

            var staticListAttributeValue =
                context.CustomAttributeValueRepository.SingleOrDefaultBySpec(new CustomAttributeValueSpec
                {
                    AttributeId = staticListAttribute.Id,
                    CommonName = "YES",
                    BaseLocale = spec.BaseLocale
                });

            if (staticListAttributeValue == null)
            {
                //var cbAttributeValue = CreateCheckboxAttributeValue(context, "Yes", staticListAttribute.Id, spec.OperatorId);
                //context.CustomAttributeValueRepository.Save(cbAttributeValue);
                //staticListAttributeValue = cbAttributeValue;
                var cbAttributeValue = CreateCheckboxAttributeValue(context, "Yes", staticListAttribute.Id,
                    spec.OperatorId, list.ProviderId, spec.BaseLocale);
                cbAttributeValue.ProviderId = list.ProviderId;
                context.CustomAttributeValueRepository.SaveCustomAttributeValue(cbAttributeValue);
                staticListValueId = cbAttributeValue.ValueId.HasValue ? cbAttributeValue.ValueId.Value : 0;

            }
            else
            {
                staticListValueId = staticListAttributeValue.ValueId;
            }

            context.AttributeValueRepository.DeleteBySpec(new AttributeValueSpec
            {
                ProviderId = list.ProviderId,
                ValueId = staticListValueId
            });

            if (spec.UserIds == null)
                return;

#warning Same code as UserManager has. Refactor into buld processor....
            var pageIndex = 0;
            var pageSize = AtHocConfigService.Current.UserBulkUpdatePageSize;
            IEnumerable<int> userIdsPage;
            var systemTime = DateTimeConverter.GetSystemTimeAsSeconds();
            while ((userIdsPage = spec.UserIds.Skip(pageIndex * pageSize).Take(pageSize)).HasValue())
            {
                var proc = new StoredProcedure(context, "PDL_STATIC_USER_ASSOCIATE");
                proc.AddParameter("tgtUsersList", userIdsPage.Join());
                proc.AddParameter("attributeId", staticListAttribute.Id);
                proc.AddParameter("valueId", staticListValueId);
                proc.AddParameter("updatedOn", systemTime);
                proc.AddParameter("updatedBy", spec.OperatorId);
                proc.Execute();
                pageIndex++;
            }
        }

        private static CustomAttributeValueModel CreateCheckboxAttributeValue(INgaddataContext context, string valueName, int attributeId, int? operatorId, int providerId, string locale)
        {
            var newAttributeValueId = new SequenceHelper(context).GetSequence("ATTRIBUTEVALUEID");
           
           
            return new CustomAttributeValueModel
                   {
                       AttributeId = attributeId,
                       CommonName = valueName.ToUpper(),
                       ValueName = valueName,
                       UpdatedBy = operatorId,
                       UpdatedOn = DateTimeConverter.GetSystemTimeAsSeconds(),
                       ValueId = newAttributeValueId,
                       Priority = 0,
                       CheckUpdateInterval = 0,
                       Locale = locale
           
            };
        }

        private static void ValidateListName(DistributionList list, INgaddataContext context, Messages messages)
        {
            var listCountSpec = new DistributionListSpec { Id = list.Id, Name = list.Name, CommonName = list.CommonName, ProviderId = list.ProviderId, ExcludeDeleted = true };
            var message = context.DistributionListRepository.VerifyDLName(listCountSpec);

            switch (message)
            {
                case DistributionListNameVerificationMessage.NewDLNameMatchesExistingDLName:
                    messages.CreateErrorMessage(IWSResources.DistributionList_Message_NewDLNameMatchesExistingDLName.FormatWith(list.Name));
                    break;
                case DistributionListNameVerificationMessage.NewDLNameMatchesExistingDLCommonName:
                    messages.CreateErrorMessage(IWSResources.DistributionList_Message_NewDLNameMatchesExistingDLCommonName.FormatWith(list.Name));
                    break;
                case DistributionListNameVerificationMessage.NewDLCommonNameMatchesExistingDLName:
                    messages.CreateErrorMessage(IWSResources.DistributionList_Message_NewDLCommonNameMatchesExistingDLName.FormatWith(list.CommonName));
                    break;
                case DistributionListNameVerificationMessage.NewDLCommonNameMatchesExistingDLCommonName:
                    messages.CreateErrorMessage(IWSResources.DistributionList_Message_NewDLCommonNameMatchesExistingDLCommonName.FormatWith(list.CommonName));
                    break;
                case DistributionListNameVerificationMessage.NewDLNameMatchesExistingAttributeName:
                    messages.CreateErrorMessage(IWSResources.DistributionList_Message_NewDLNameMatchesExistingAttributeName.FormatWith(list.Name));
                    break;
                case DistributionListNameVerificationMessage.NewDLNameMatchesExistingAttributeCommonName:
                    messages.CreateErrorMessage(IWSResources.DistributionList_Message_NewDLNameMatchesExistingAttributeCommonName.FormatWith(list.Name));
                    break;
                case DistributionListNameVerificationMessage.NewDLCommonNameMatchesExistingAttributeName:
                    messages.CreateErrorMessage(IWSResources.DistributionList_Message_NewDLCommonNameMatchesExistingAttributeName.FormatWith(list.CommonName));
                    break;
                case DistributionListNameVerificationMessage.NewDLCommonNameMatchesExistingAttributeCommonName:
                    messages.CreateErrorMessage(IWSResources.DistributionList_Message_NewDLCommonNameMatchesExistingAttributeCommonName.FormatWith(list.CommonName));
                    break;
            }

            if (list.Name.Trim().Length > 128)
                messages.CreateErrorMessage(IWSResources.DistributionList_Message_NewDLNameLength);

            if (list.CommonName.Trim().Length > 128)
                messages.CreateErrorMessage(IWSResources.DistributionList_Message_NewDLCommonNameLength);
        }
    }
}
