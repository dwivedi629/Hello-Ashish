﻿using AtHoc.Infrastructure.Domain;
using AtHoc.IWS.Business.Data;

namespace AtHoc.IWS.Business.Domain.Publishing
{
	public class AlertChannelFacade : FacadeBase<IAtHocContextFactory> {}
}
