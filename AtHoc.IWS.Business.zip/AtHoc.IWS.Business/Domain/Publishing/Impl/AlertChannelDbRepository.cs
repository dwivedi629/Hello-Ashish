﻿using System.Collections.Generic;
using System.Text;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Database;
using AtHoc.Infrastructure.Sql;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.Publishing
{
    public class AlertChannelDbRepository : DbRepository<AlertChannel, AlertChannelSpec>, IAlertChannelRepository
    {
        public AlertChannelDbRepository(IUnitOfWork context) : base(context) {}

        protected override void TranslateSpec(AlertChannelSpec spec, SqlBuilder builder, bool query)
        {
            var providerParameter = new SqlParameter("providerId", spec.ProviderId == null ? 0 : spec.ProviderId.Value);
            builder.Select("*");
            builder.From("dbo.ALT_CHANNEL_TAB c with (nolock)");
            builder.Where("c.status <> 'DEL'");

            if (spec.OperatorId.HasValue)
            {
                builder.InnerJoin("dbo.ups_content_filter_tab b with (nolock) on b.object_id = c.channel_id");
                builder.InnerJoin("dbo.ups_user_role_tab a with (nolock) on a.content_filter_id = b.content_filter_id");
                builder.Where("cast(a.provider_filter as int) in (select PROVIDER_ID from dbo.PRV_GET_PROVIDER_HIERARCHY_LIST(@providerId))", providerParameter);
                builder.Where("a.user_id = @operatorId", "operatorId", spec.OperatorId.Value);
                builder.Where("b.object_type = 'SRV'");
            }
            else
            {
                providerParameter = new SqlParameter("providerId", spec.ProviderId == null ? 0 : spec.ProviderId.Value);
                builder.Where("c.PROVIDER_ID in (select PROVIDER_ID from dbo.PRV_GET_PROVIDER_HIERARCHY_LIST(@providerId))", providerParameter);
            }

            if (spec.CommonName.HasValue())
            {
                builder.Where("c.COMMON_NAME = @commonName", "commonName", spec.CommonName);
            }
        }
    }
}
