﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Web;
using AtHoc.Data;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Domain;
using AtHoc.Infrastructure.Meta;
using AtHoc.IWS.Business.Data;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.Systems;
using LocalSystem = AtHoc.Systems.LocalSystem;
using AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel;
using AtHoc.Infrastructure.Sql;
using System.Data;


namespace AtHoc.IWS.Business.Domain.Publishing
{
    public class ActivityFeedFacade : FacadeBase<IAtHocContextFactory>, IActivityFeedFacade
    {
        public IEnumerable<ActivityFeed> GetActivityFeedsBySpec(ActivityFeedSpec spec)
        {
            using (var context = AtHocDbContextFactory.CreateFactory().CreateNgaddataContext())
            {
                return context.ActivityFeedRepository.FindBySpec(spec);
            }
        }

        public int GetActivityFeedsCountBySpec(ActivityFeedSpec spec)
        {
            using (var context = AtHocDbContextFactory.CreateFactory().CreateNgaddataContext())
            {
                return context.ActivityFeedRepository.CountBySpec(spec);
            }
        }

        public ActivityFeed GetActivityFeedBySpec(ActivityFeedSpec spec)
        {
            if (!spec.AlertId.HasValue || !spec.UserId.HasValue)
                throw new ApplicationException("EventId and UserId must be set to get single ActivityFeed object.");
            return GetActivityFeedsBySpec(spec).SingleOrDefault();
        }

        public PagingInfo<ActivityFeed> GetActivityFeedItemsPage(ActivityFeedSpec spec)
        {
            using (var context = AtHocDbContextFactory.CreateFactory().CreateNgaddataContext())
            {
                return context.ActivityFeedRepository.GetPagingInfo(spec);
            }
        }

        public PagingInfo<AccountabilityActivityFeed> GetAccountabilityActivityFeedItemsPage(ActivityFeedSpec spec)
        {
            using (var context = AtHocDbContextFactory.CreateFactory().CreateNgaddataContext())
            {
                return context.AccountabilityActivityFeedRepository.GetPagingInfo(spec);
            }
        }

        public bool SaveAlertResponseOptionToDB(int alertId, int userId, string responesText, string clientIp = "", string userAgent = "", string serverIp = "")
        {
            const string storedProc = "exec dbo.OLP_INSERT_TRACKING @system_date={0}, @system_c_ip={1}, @system_user_agent={2}, @system_s_ip={3}, @application_user_Id={4}, @application_request_type={5}, @application_device_Id={6}, @application_message_Id={7},@application_market_message={8}";
            using (var context = new NgoladataDbContext())
            {
                context.Database.ExecuteSqlCommand(storedProc, AtHocSystem.Local.CurrentDateTime.AddSeconds(-1).ToString(), clientIp, userAgent, serverIp, userId, "MESSAGE SENT", 10, alertId, "");
                context.Database.ExecuteSqlCommand(storedProc, AtHocSystem.Local.CurrentDateTime.ToString(), clientIp, userAgent, serverIp, userId,
                    "MESSAGE CLICKED", 10, alertId, responesText);
            }
            return true;
        }


        public List<UserAccountabilityEventAlert> GetUserAlertsForAccountabilityEvent(int userId, int accoutabilityEventId)
        {
            var listUserEventAlerts = new List<UserAccountabilityEventAlert>();

            using (var context = AtHocDbContextFactory.CreateFactory().CreateNgaddataContext())
            {
                var sqlParams = new List<SqlParameter>
                        {
                            new SqlParameter("@userId", userId),
                            new SqlParameter("@eventId", accoutabilityEventId)
                        };

                IDataReader reader = context.ExecuteDataReader("exec dbo.USR_ACTIVITY_ACCT_EVENT_DETAILS", sqlParams);
                reader.NextResult();
                while (reader.Read())
                {
                    var alert = new UserAccountabilityEventAlert
                    {
                        AlertId = Convert.ToInt32(reader["ALERT_ID"]),
                        Title = reader["TITLE"].ToString(),
                        Body = reader["BODY"].ToString(),
                        PublishedOn = Convert.ToDateTime(reader["PUBLISHED_ON"])
                    };

                    listUserEventAlerts.Add(alert);
                }      
            }
            return listUserEventAlerts;
        }
        public AccountabilityEventDetail GetUserAccountabilityActivityFeed(int userId, int accoutabilityEventId)
        {
            var accountabilityEventDetail = new AccountabilityEventDetail();

            using (var context = AtHocDbContextFactory.CreateFactory().CreateNgaddataContext())
            {
                var sqlParams = new List<SqlParameter>
                        {
                            new SqlParameter("@userId", userId),
                            new SqlParameter("@eventId", accoutabilityEventId)
                        };

                IDataReader reader = context.ExecuteDataReader("exec dbo.USR_ACTIVITY_ACCT_EVENT_DETAILS", sqlParams);
               			
                while (reader.Read())
                {
                    var accountabilityActivityFeed = new AccountabilityActivityFeed();
                    accountabilityActivityFeed.UserId = Convert.ToInt32(reader["USER_ID"]);
                    accountabilityActivityFeed.EventId = Convert.ToInt32(reader["EVENT_ID"]);
                    accountabilityActivityFeed.ProviderId = Convert.ToInt32(reader["PROVIDER_ID"]);
                    accountabilityActivityFeed.EventType = Convert.ToString(reader["EVENT_TYPE"]);
                    accountabilityActivityFeed.Title = Convert.ToString(reader["TITLE"]);
                    accountabilityActivityFeed.Body = Convert.ToString(reader["BODY"]);
                    accountabilityActivityFeed.EventTime = reader["EVENT_TIME"] != null ? Convert.ToDateTime(reader["EVENT_TIME"]) : (DateTime?)null;
                    accountabilityActivityFeed.ResponseDate = reader["RESPONSE_DATE"] != null ? Convert.ToDateTime(reader["RESPONSE_DATE"]) : (DateTime?)null;
                    accountabilityActivityFeed.Status = Convert.ToString(reader["STATUS"]);
                    accountabilityActivityFeed.Publisher = Convert.ToString(reader["PUBLISHER"]);
                    
                    accountabilityActivityFeed.DeliveryStatus = reader["DELIVERY_STATE"] != null ? EnumUtils<AlertDeliveryStatus>.GetValueByDescription(reader["DELIVERY_STATE"].ToString()) : (AlertDeliveryStatus?)null;
                    
                    accountabilityActivityFeed.DeviceAddress = Convert.ToString(reader["DEVICE_ADDRESS"]);
                    accountabilityActivityFeed.DeviceName =  Convert.ToString(reader["DEVICE_NAME"]);
                    accountabilityActivityFeed.DeviceCommonName = Convert.ToString(reader["DEVICE_COMMON_NAME"]);
                    accountabilityActivityFeed.RespondedText = Convert.ToString(reader["RESPONDED_TEXT"]);
                    accountabilityActivityFeed.NoResponse = reader["NO_RESPONSE"] != null ? Convert.ToInt32(reader["NO_RESPONSE"]) :(int?)null;
                    accountabilityActivityFeed.Sent = reader["SENT"] != null ? Convert.ToInt32(reader["SENT"]) :(int?)null;
                    accountabilityActivityFeed.IsFirstResponded =  Convert.ToInt32(reader["IS_FIRST_RESPONDED"]);
                    accountabilityActivityFeed.DeliveryStateCode = Convert.ToString(reader["DELIVERY_STATE_CODE"]);
                    accountabilityActivityFeed.DeliveryState =  Convert.ToString(reader["DELIVERY_STATE"]);
                    accountabilityActivityFeed.EventCategoryId = reader["EVENT_CATEGORY_ID"] != null ? Convert.ToInt32(reader["EVENT_CATEGORY_ID"]) :(int?)null;
                    accountabilityActivityFeed.EndedOn = reader["ENDED_ON"] != null && !(reader["ENDED_ON"] is DBNull) ? Convert.ToDateTime(reader["ENDED_ON"]) : (DateTime?)null;
                    accountabilityActivityFeed.MoreInfoUrl =  Convert.ToString(reader["CONTENT_URL"]);
                    accountabilityActivityFeed.Priority =  reader["PRIORITY"] != null ? Convert.ToInt32(reader["PRIORITY"]) :(int?)null;
                    accountabilityActivityFeed.EventCategoryName = Convert.ToString(reader["EVENT_CATEGORY_NAME"]);
                    accountabilityActivityFeed.EventCategoryImageId = reader["IMAGE_ID"] != null ? Convert.ToInt32(reader["IMAGE_ID"]) :(int?)null;
                    accountabilityActivityFeed.ResponseOptionsXml = Convert.ToString(reader["RESPONSE_OPTIONS"]);
                    accountabilityActivityFeed.GeoJson = Convert.ToString(reader["GEO_JSON"]);
                    accountabilityActivityFeed.EventAlertsCount = Convert.ToInt32(reader["EVENT_ALERTS_COUNT"]);
                    accountabilityActivityFeed.StatusUpdatedBy = Convert.ToString(reader["RESPONSE_UPDATED_FROM"]);
                   
                    accountabilityEventDetail.AccountabilityActivityFeed = accountabilityActivityFeed;
                }
                reader.NextResult();
                var listUserEventAlerts = new List<UserAccountabilityEventAlert>();
                while (reader.Read())
                {
                    var alert = new UserAccountabilityEventAlert
                    {
                        AlertId = Convert.ToInt32(reader["ALERT_ID"]),
                        Title = reader["TITLE"].ToString(),
                        Body = reader["BODY"].ToString(),
                        PublishedOn = Convert.ToDateTime(reader["PUBLISHED_ON"])
                    };

                    listUserEventAlerts.Add(alert);
                }
                accountabilityEventDetail.UserAccountabilityEventAlerts = listUserEventAlerts;
            }
            return accountabilityEventDetail;
        }           
    }               
}                   
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    