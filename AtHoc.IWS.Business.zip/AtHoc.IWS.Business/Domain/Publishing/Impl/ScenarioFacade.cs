﻿using System;
using System.Collections.Generic;
using System.Configuration;
using AtHoc.Data;
using AtHoc.Infrastructure.Domain;
using AtHoc.IWS.Business.Data;
using AtHoc.IWS.Business.Database;
using System.Linq;
using AtHoc.IWS.Business.Data.SearchSpec;
using AtHoc.Publishing;
using Scenario = AtHoc.IWS.Business.Domain.Entities.Scenario;


namespace AtHoc.IWS.Business.Domain.Publishing
{
    public class ScenarioFacade : FacadeBase<IAtHocContextFactory>, IScenarioFacade
    {
        public ScenarioFacade() : base(AtHocDbContextFactory.CreateFactory()) { }

        public AtHoc.Publishing.Scenario GetScenario(int scenarioId, int provideId, int operatorId)
        {
            var manager = new ScenarioManager(provideId, operatorId);
            return manager.GetScenario(scenarioId);
        }

        public AtHoc.Publishing.Scenario CreateScenario(int providerId, int operatorId)
        {
            var manager = new ScenarioManager(providerId, operatorId);
            return manager.CreateScenario();
        }

        public AtHoc.Publishing.Scenario DuplicateScenario(int id, int providerId, int operatorId)
        {
            var manager = new ScenarioManager(providerId, operatorId);
            return manager.CreateScenarioFromScenario(id);
        }

        public IEnumerable<Scenario> GetScenarios(int providerId, int operatorId, ScenarioSearchSpec spec)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                var scenarios = context.ScenarioRepository.GetScenarios(providerId, operatorId, spec);
                if (spec.ExcludeSystemScenarios)
                {
                    return scenarios.Where(s => !IsSystemScenario(s.CommonName));
                }
                return scenarios;
            }
        }

        public bool SaveScenario(int provideId, int operatorId, AtHoc.Publishing.Scenario scenario)
        {
            if (scenario.ScenarioId == 0 || string.IsNullOrWhiteSpace(scenario.CommonName))
            {
                scenario.CommonName = Guid.NewGuid().ToString();
            }

            var manager = new ScenarioManager(provideId, operatorId);
            manager.SaveScenario(scenario);
            return true;
        }

        public void DeleteScenarios(int providerId, int operatorId, int[] scenarioIds)
        {
            var manager = new ScenarioManager(providerId, operatorId);
            foreach (int item in scenarioIds)
            {
                AtHoc.Publishing.Scenario scenario = manager.GetScenario(item);
                if (scenario != null)
                {
                    manager.DeleteScenario(scenario);
                }
            }
        }


        //for now we are harcoding by common name. we may refactor this when we refactor middletier
        public bool IsSystemScenario(string commonName)
        {
            return (commonName == "WELCOME-MESSAGE"
                  || commonName == "SSA-ACTION-TEAM-NOTIFICATION"
                  || commonName == "SSA-ACTION-TEAM-NOTIFICATION-QUIET"
                  || commonName == "SSA-END-USER-NOTIFICATION"
                  || commonName == "[NEW-SCENARIO-TEMPLATE]"
                  || commonName == "[NEW-ALERT-TEMPLATE]"
                  || commonName == "SILENT-TEST-ALERT"
                  || commonName == "INBOUND-STANDARD"
                  || commonName == "INBOUND-CONNECT"
                  || commonName == "INBOUND-OTHER");
        }

    }
}