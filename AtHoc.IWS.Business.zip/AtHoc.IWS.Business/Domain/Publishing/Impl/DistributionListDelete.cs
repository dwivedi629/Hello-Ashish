﻿using System;
using System.IO.Ports;
using System.Linq;
using System.Collections.Generic;

using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Data;

using AtHoc.IWS.Business.Data;
using AtHoc.IWS.Business.Domain.Audit;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Service;

namespace AtHoc.IWS.Business.Domain.Publishing.Impl
{
	public class DistributionListDelete : NgaddataService<bool, DistributionListSpec>
	{
		protected override void ProcessServiceParameter(INgaddataContext context, DistributionListSpec spec, IServiceResult<bool> result)
		{
			if (!spec.Ids.HasValue())
				throw new ApplicationException("Spec has no Ids");

			if (!spec.OperatorId.HasValue)
				throw new ApplicationException("Operator Id is not provided.");

			foreach (var listId in spec.Ids)
				DeleteDistributionList(context, spec, result, listId);
		}

		private void DeleteDistributionList(INgaddataContext context, DistributionListSpec spec, IServiceResult<bool> result, int listId)
		{
			var listSpec = new DistributionListSpec {Id = listId, ExcludeDeleted = true};
			var existingList = context.DistributionListRepository.FindBySpec(listSpec).SingleOrDefault();

			if (existingList == null)
				throw new ApplicationException("Can`t delete distribution list with id {0}. List doesn`t exists.".FormatWith(listId));

			var storedProcedure = new StoredProcedure(context, "DPN_DIST_LIST_DELETE");
			storedProcedure.AddParameter("operatorId", spec.OperatorId.Value);
			storedProcedure.AddParameter("listId", listId);
			storedProcedure.Execute();
			VerifyDistributionListDeleted(context, result, listId, listSpec);

		    if (spec.IsTemporary.HasValue && !spec.IsTemporary.Value)
		    {
		        var auditSpec = new AuditSpec(spec.OperatorId, spec.ProviderId)
		                        {
		                            Action = ServiceAction.DistributionListDeleted,
		                            ObjectType = EntityType.DistributionListManager,
		                            ObjectName = existingList.Name
		                        };
		        OperationAuditor.LogAction(auditSpec);
		    }
		}

		private static void VerifyDistributionListDeleted(INgaddataContext context, IServiceResult<bool> result, int listId, DistributionListSpec listSpec)
		{
			var deletedList = context.DistributionListRepository.FindBySpec(listSpec).SingleOrDefault();
			if (deletedList != null)
				throw new ApplicationException("Can`t delete distribution list with id {0}".FormatWith(listId));
		}

		private static void DeleteStaticDistributionListAttribute(INgaddataContext context, DistributionList existingList)
		{
			var attribute = context.CustomAttributeRepository.FindById(Convert.ToInt32(existingList.Definition));           
            if (attribute != null)
		    {
		        attribute.Status = EnumUtils<UserStatusType>.GetDescriptionByValue(UserStatusType.Deleted);
		        context.CustomAttributeRepository.Save(attribute);
		    }

		}
	}
}
