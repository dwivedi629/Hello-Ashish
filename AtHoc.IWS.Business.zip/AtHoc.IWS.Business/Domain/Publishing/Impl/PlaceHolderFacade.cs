﻿using System;
using System.Collections.Generic;
using System.Globalization;
using AtHoc.d911;
using AtHoc.Global.Resources.Interfaces;
using AtHoc.Infrastructure.Domain;
using AtHoc.IWS.Business.Data;
using System.Linq;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.Infrastructure.Ioc;
using AtHoc.Publishing.Service;

namespace AtHoc.IWS.Business.Domain.Publishing.Impl
{
    public class PlaceHolderFacade : FacadeBase<IAtHocContextFactory>, IPlaceHolderFacade
    {
        private readonly ICustomAttributeFacade _customAttributeFacade;
        private readonly IGlobalEntityLocaleFacade _globalEntityLocaleFacade;
        internal const int ConsSystemVpsId = 3;

        /// <summary>
        /// Placeholder Facade
        /// </summary>
        /// <param name="contextFactory"></param>
        public PlaceHolderFacade(IAtHocContextFactory contextFactory)
            : base(contextFactory)
        {
            _customAttributeFacade = ServiceLocator.Resolve<ICustomAttributeFacade>();
            _globalEntityLocaleFacade = ServiceLocator.Resolve<IGlobalEntityLocaleFacade>();
        }

        /// <summary>
        /// To get the Placeholders
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="operatorId"></param>
        /// <returns></returns>
        public IEnumerable<CustomAttribute> GetPlaceHolderByProvider(int providerId, int operatorId)
        {
            var placeHolders = _customAttributeFacade.GetCustomAttributesBySpec(new CustomAttributeSpec
              {
                  ProviderId = providerId,
                  OperatorId = operatorId,
                  IncludeValues = true,
                  BaseLocale = RuntimeContext.Provider.BaseLocale,
                  Status = UserStatusType.Active,
                  EntityType = new List<CustomAttributeType> { CustomAttributeType.Placeholder },
              }).ToList();

            return placeHolders;

        }

        /// <summary>
        /// To get the Placeholders in PlaceHolderSimpleItem model
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="operatorId"></param>
        /// <returns></returns>
        public IEnumerable<Entities.PlaceHolderSimpleItem> GetPlaceHolderList(int providerId, int operatorId)
        {
            var placeHolders = GetPlaceHolderByProvider(providerId, operatorId);
            return placeHolders.Select(x => new Entities.PlaceHolderSimpleItem { Id = x.Id, Name = x.AttributeName, IsSystem = x.ProviderId == ConsSystemVpsId });
        }

        /// <summary>
        /// To get System Placeholders
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="operatorId"></param>
        /// <returns></returns>
        public IEnumerable<PlaceHolder> GetSystemPlaceHolders(SystemPlaceholders systemPlaceholders, int providerId, int operatorId)
        {
            var systemInfo = AtHoc.Publishing.PlaceHolders.PlaceHolderSystem.GetSystemInfo(operatorId, providerId);
            //Get the Placeholders and filter for system
            var pData = GetPlaceHolderByProvider(providerId, operatorId).Where(x => x.ProviderId == ConsSystemVpsId);
            //prepare placeholder model
            var placeHolders = pData.Select(x => new PlaceHolder { Name = x.AttributeName, DefaultText = ((x.AttributeTypeId == CustomAttributeDataType.MultiPicklist || x.AttributeTypeId == CustomAttributeDataType.Picklist) ? (x.Values != null ? string.Join(",", x.Values.Where(y => y.ValueId.ToString() == x.DefaultValue).ToArray().Select(a => a.ValueName)) : string.Empty) : x.DefaultValue), Id = x.Id, CommonName = x.CommonName, DefaultValue = x.DefaultValue, ControlType = GetPlaceholderControlType(x.AttributeTypeId), IsStandard = x.IsStandard }).ToList();
            //prepare system attribute values
            //update the placeholder values
            foreach (var placeHolder in placeHolders)
            {
                var values = new List<PlaceHolderValue>();
                if (!systemInfo.ContainsKey(placeHolder.CommonName))
                {
                    values.Add(new PlaceHolderValue { Id = 0, Name = "Default", IsDefault = true, Value = (placeHolder.ControlType == PlaceHolderControlType.MultiSelection || placeHolder.ControlType == PlaceHolderControlType.SingleSelection) ? placeHolder.DefaultText : (!string.IsNullOrEmpty(placeHolder.DefaultValue) ? placeHolder.DefaultValue : "") });
                    placeHolder.Values = values;
                    continue;
                }
                var value = systemInfo[placeHolder.CommonName];
                values.Add(new PlaceHolderValue { Id = 0, Name = "Default", IsDefault = true, Value = value });
                placeHolder.Values = values;
            }
            return placeHolders;
        }

        /// <summary>
        /// To get the Custom Placeholders
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="providerId"></param>
        /// <param name="operatorId"></param>
        /// <returns></returns>
        public IEnumerable<PlaceHolder> GetCustomerPlaceHolders(PlaceHoldersToAlertDto obj, int providerId, int operatorId)
        {
            var list = obj.PlaceHoldersToAlertMap.ToList().OrderBy(p => p.SortOrder);
            var result = new List<PlaceHolder>();
            var phData = (from x in GetPlaceHolderByProvider(providerId, operatorId).ToList()
                          where list.Any(li => li.AttributeId == x.Id) && x.ProviderId != ConsSystemVpsId
                          select
                new PlaceHolder
                {
                    CommonName = x.CommonName,
                    Name = x.AttributeName,
                    ControlType = GetPlaceholderControlType(x.AttributeTypeId),
                    DisplayLines = x.TextLineNumbers.HasValue ? x.TextLineNumbers.GetValueOrDefault() : 0,
                    DisplayType = x.IsSystemAttribute == "Y" ? PlaceHolderType.System : PlaceHolderType.Custom,
                    Id = x.Id,
                    MaximumLength = string.IsNullOrEmpty(x.MaxValue) ? 0 : Convert.ToInt32(x.MaxValue),
                    MinimumLength = string.IsNullOrEmpty(x.MinValue) ? 0 : Convert.ToInt32(x.MinValue),
                    Values = (x.Values == null ? new List<PlaceHolderValue> { new PlaceHolderValue { Id = 0, Name = "default", Value = (string.IsNullOrEmpty(x.DefaultValue) ? "" : x.DefaultValue) } } : x.Values.Select(y => new PlaceHolderValue { Id = y.ValueId, Name = y.ValueName, Value = y.ValueName, IsDefault = (x.DefaultValue.Contains(y.ValueId.ToString(CultureInfo.InvariantCulture))) }).ToList()),
                    DefaultText = ((x.AttributeTypeId == CustomAttributeDataType.MultiPicklist || x.AttributeTypeId == CustomAttributeDataType.Picklist) ? (x.Values != null ? string.Join(",", x.Values.Where(y => y.ValueId.ToString() == x.DefaultValue).ToArray().Select(a => a.ValueName)) : string.Empty) : x.DefaultValue),
                    DefaultValue = string.IsNullOrEmpty(x.DefaultValue) ? "" : x.DefaultValue,
                    IsStandard = x.IsStandard
                }
               ).ToList();
            result.AddRange(phData);
            return result;
        }

        private PlaceHolderControlType GetPlaceholderControlType(CustomAttributeDataType? custAttributeDataType)
        {
            switch (custAttributeDataType)
            {
                case CustomAttributeDataType.Memo:
                    return PlaceHolderControlType.Memo;
                case CustomAttributeDataType.Date:
                    return PlaceHolderControlType.Date;
                case CustomAttributeDataType.DateTime:
                    return PlaceHolderControlType.DateTime;
                case CustomAttributeDataType.Picklist:
                    return PlaceHolderControlType.SingleSelection;
                case CustomAttributeDataType.MultiPicklist:
                    return PlaceHolderControlType.MultiSelection;
                case CustomAttributeDataType.Time:
                    return PlaceHolderControlType.Time;
                default:
                    return PlaceHolderControlType.Text;
            }
        }

        public IList<EventPlaceholders> GetEventPlaceholders(string locale)
        {
            if (string.IsNullOrEmpty(locale))
                locale = "en-US";
            var placeHolderList = (from AccountabilityEventPlaceHolders p in Enum.GetValues(typeof(AccountabilityEventPlaceHolders))

                                   select
                                       new EventPlaceholders()
                                       {
                                           EventPlaceholderId = p.ToString(CultureInfo.InvariantCulture),
                                           EventPlaceholderName = p.Description()
                                       }).ToList();
            return
                _globalEntityLocaleFacade.GetLocalizedEntity(placeHolderList, locale).Select(p => new EventPlaceholders()
                                       {
                                           EventPlaceholderId = p.EventPlaceholderId,
                                           EventPlaceholderName = p.EventPlaceholderName,
                                           EventPlaceholderDisplayName = "[[" + p.EventPlaceholderName + "]]",
                                       }).ToList();
        }
    }
}
