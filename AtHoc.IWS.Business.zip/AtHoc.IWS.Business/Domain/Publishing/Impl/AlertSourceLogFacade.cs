﻿using AtHoc.Infrastructure.Log;
using AtHoc.IWS.Business.Context;
using System;
using System.Collections.Generic;

namespace AtHoc.IWS.Business.Domain.Publishing.Impl
{
    public class AlertSourceLogFacade : IAlertSourceLogFacade
    {
        private readonly IAlertSourceLogRepository _alertSourceLogRepository;
        private readonly ILogService _logService;

        /// <summary>
        /// Construtor
        /// </summary>
        /// <param name="alertSourceLogRepository"> Instance of AlertSourceLogRepository</param>
        /// <param name="logService">Instance of Log Service</param>
        public AlertSourceLogFacade(IAlertSourceLogRepository alertSourceLogRepository, ILogService logService)
        {
            _alertSourceLogRepository = alertSourceLogRepository;
            _logService = logService;
        }

        /// <summary>
        /// Create Alert Source Log
        /// </summary>
        /// <param name="alertSourceLogLog">Instance of AlertSourceLog type.</param>
        /// <returns>Boolean</returns>
        public bool CreateAlertSourceLog(Entities.AlertSourceLog alertSourceLogLog)
        {
            bool result;
            try
            {
                if (alertSourceLogLog.CreatedBy == 0)
                    alertSourceLogLog.CreatedBy = RuntimeContext.OperatorId;
                result = _alertSourceLogRepository.Create(alertSourceLogLog);
            }
            catch (Exception ex)
            {
                //Log the error at facade level.
                _logService.Error(() => ex.Message);
                result = false;
            }
            return result;

        }

        /// <summary>
        /// Get the list of All Logs.
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Entities.AlertSourceLog> GetAlertSourceLogs()
        {
            throw new NotImplementedException();
        }
    }
}
