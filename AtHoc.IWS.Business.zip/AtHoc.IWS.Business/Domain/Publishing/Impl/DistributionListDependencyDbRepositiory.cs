﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Database;
using AtHoc.Infrastructure.Sql;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Publishing.Spec;

namespace AtHoc.IWS.Business.Domain.Publishing.Impl
{
	public class DistributionListDependencyDbRepositiory : DbRepository<DistributionListDependency, DistributionListDependencySpec>, IDistributionListDependencyRepositiory
	{
		public DistributionListDependencyDbRepositiory(IUnitOfWork context) : base(context) {}

        public override IEnumerable<DistributionListDependency> FindBySpec(DistributionListDependencySpec spec)
	    {
            var distributionListDependencyList = new List<DistributionListDependency>();

            var parameters = new List<SqlParameter>();
            const string getDistributionListDependency = @"exec DPN_DIST_LIST_CHECK";

            parameters.Add(new SqlParameter("idList", String.Join(",", spec.ListIds)));
            parameters.Add(new SqlParameter("providerId", spec.ProviderId));

            var dataTable = Context.ExecuteDataTable(getDistributionListDependency, parameters);

            foreach (DataRow row in dataTable.Rows)
            {
                var dependencyType = row["DependencyType"].ConvertTo<string>();
                var dependencyTypeId = EnumUtils<DistributionListDependencyType>.GetValueByDescription(dependencyType);
                var listId = row["ListID"].ConvertTo<int>();
                var listName = row["ListName"].ConvertTo<string>();
                var dependentId = row["DependentID"].ConvertTo<int>();
                var dependentName = row["DependentName"].ConvertTo<string>();
                distributionListDependencyList.Add(new DistributionListDependency { DependencyType = dependencyTypeId, ListId = listId, ListName = listName, DependentId = dependentId, DependentName = dependentName });
            }

	        return distributionListDependencyList;
	    }
	}
}
