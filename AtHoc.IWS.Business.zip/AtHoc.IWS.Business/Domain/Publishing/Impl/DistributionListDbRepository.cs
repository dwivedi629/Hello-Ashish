﻿using AtHoc.d911;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Database;
using AtHoc.Infrastructure.Sql;
using AtHoc.IWS.Business.Data;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Users.Search;
using System;
using System.Collections.Generic;
using System.Linq;


namespace AtHoc.IWS.Business.Domain.Publishing
{
	public class DistributionListDbRepository : DbRepository<DistributionList, DistributionListSpec>, IDistributionListRepository
	{
		private CustomAttributeLookup _customAttributeLookup;

		public DistributionListDbRepository(INgaddataContext context) : base(context) { }

		public override IEnumerable<DistributionList> FindBySpec(DistributionListSpec spec)
		{
			var distributionLists = base.FindBySpec(spec);

			if (spec.IncludeParentChildren)
			{
				distributionLists = distributionLists.ToArray();
				var lookup = distributionLists.ToLookup(x => x.Id);

				foreach (var item in distributionLists)
				{
					if (item.ParentListId.HasValue &&
						lookup.Contains(item.ParentListId.Value))
					{
						var parent = lookup[item.ParentListId.Value].SingleOrDefault();
						item.ParentList = parent;

						if (parent.Children == null)
							parent.Children = new List<DistributionList>();

						parent.Children.Add(item);
					}
				}
				return distributionLists.Where(x => x.ParentList == null);
			}
			return distributionLists;
		}

		protected override void TranslateSpec(DistributionListSpec spec, SqlBuilder builder, bool query)
		{
			builder.SelectAll<DistributionList>("a");
			builder.From(builder.Table<DistributionList>("a"));

		    if (spec.AccessType != (AccessType) 0)
		    {
		        if (!spec.OperatorId.HasValue)
		            throw new ApplicationException("Operator id should be provided to check distribution list permissions.");

		        if (!spec.ProviderId.HasValue)
		            throw new ApplicationException("Provider id should be provided to check distribution list permissions.");

		        if (spec.AccessType == AccessType.Target)
		            builder.Where(
                        "EXISTS ( SELECT 1 FROM UPS_ENTITY_ACCESS_TAB a WITH (NOLOCK) WHERE (ACCESS_TYPE = 'TRG' AND ENTITY_TYPE = 'LST' AND (ENTITY_ID = -1 OR (ENTITY_ID = LIST_ID)) AND a.USER_ID = @USER_ID AND " +
		                "a.PROVIDER_ID = @providerIdExtra) " +
		                "OR (@isEntityAccessUnrestricted = 'N'))",
		                new SqlParameter("USER_ID", spec.OperatorId.Value),
		                new SqlParameter("providerIdExtra", spec.ProviderId.Value),
		                new SqlParameter("isEntityAccessUnrestricted",
		                    IsEntityAccessUnrestricted(spec.OperatorId.Value, spec.ProviderId.Value))
		                );
		        else if (spec.AccessType == AccessType.Manage)
		            builder.Where(
                        "EXISTS ( SELECT 1 FROM UPS_ENTITY_ACCESS_TAB a WITH (NOLOCK) WHERE (ACCESS_TYPE = 'MGT' AND ENTITY_TYPE = 'LST' AND (ENTITY_ID = -1 OR (ENTITY_ID = LIST_ID)) AND a.USER_ID = @USER_ID AND " +
		                "a.PROVIDER_ID = @providerIdExtra) " +
		                "OR (@isEntityAccessUnrestricted = 'N'))",
		                new SqlParameter("USER_ID", spec.OperatorId.Value),
		                new SqlParameter("providerIdExtra", spec.ProviderId.Value),
		                new SqlParameter("isEntityAccessUnrestricted",
		                    IsEntityAccessUnrestricted(spec.OperatorId.Value, spec.ProviderId.Value))
		                );
		    }

		    if (spec.IncludeHierarchy ||
				spec.IncludeCustomAttribute)
			{
				builder.SelectAll<Hierarchy>("b", postfix: "1");
				builder.InnerJoin("{0} on {1} = {2}"
					.FormatWith(builder.Table<Hierarchy>("b"),
								builder.Column<Hierarchy>("Id", "b"),
								builder.Column<DistributionList>("HierarchyId", "a")));
			}

			if (spec.IncludeCustomAttribute)
			{
				builder.SelectAll<CustomAttribute>("c", postfix: "2");
				builder.InnerJoin("{0} on {1} = {2} and c.PROVIDER_ID = a.PROVIDER_ID"
					.FormatWith(builder.Table<CustomAttribute>("c"),
								builder.Column<CustomAttribute>("CommonName", "c"),
								builder.Column<Hierarchy>("CommonName", "b")));
			}

			if (spec.IsCascaded.HasValue)
				builder.Where(builder.Condition(DistributionList.Meta.FromSubProvider, ConditionOperator.EqualsWithIsNull, spec.IsCascaded.Value ? "Y" : "N", "a"));

			if (spec.IncludeTranslatedDefinition)
				builder.Select("dbo.USR_TRANSLATE_SEARCH_CRITERIA(definition, 0) as TranslatedDefinition", true);

			if (spec.ProviderId.HasValue)
                builder.Where("a.PROVIDER_ID = @providerId2", new SqlParameter("providerId2", spec.ProviderId.Value));
                

			if (spec.HierarchyId.HasValue)
				builder.Where(builder.Condition(DistributionList.Meta.HierarchyId, ConditionOperator.Equals, spec.HierarchyId.Value, "a"));

			if (spec.HierarchyIds != null && spec.HierarchyIds.Any())
				builder.Where(builder.Condition(DistributionList.Meta.HierarchyId, ConditionOperator.In, spec.HierarchyIds, "a"));

			if (spec.DistributionListTypes != null && spec.DistributionListTypes.Any())
				builder.Where(builder.Condition(DistributionList.Meta.ListType, ConditionOperator.In, spec.DistributionListTypes, "a"));

			if (spec.Status.HasValue)
				builder.Where(builder.Condition(DistributionList.Meta.Status, ConditionOperator.Equals, spec.Status.Value, "a"));

			if (spec.ExcludeDeleted.HasValue && spec.ExcludeDeleted.Value)
				builder.Where(builder.Condition(DistributionList.Meta.Status, ConditionOperator.NotEqualsWithIsNull, DistributionListStatusType.Deleted, "a"));

			if (spec.ParentListId.HasValue)
				builder.Where(builder.Condition(DistributionList.Meta.ParentListId, ConditionOperator.Equals, spec.ParentListId.Value, "a"));

			if (spec.Name.HasValue())
				builder.Where(builder.Condition(DistributionList.Meta.Name, ConditionOperator.Equals, spec.Name, "a"));
			else if (spec.SearchStringContains.IsNotNullOrEmpty())
				builder.Where(builder.Condition(DistributionList.Meta.Name, ConditionOperator.Contains, spec.SearchStringContains, "a"));

			if (spec.SearchStringsContains.HasValue())
			{
				builder.StartWhereGroup(GroupOperator.Or);
				foreach (var value in spec.SearchStringsContains)
				{
					builder.Where(builder.Condition(DistributionList.Meta.Name, ConditionOperator.Contains, value, "a"));
				}
				builder.EndWhereGroup();
			}

			if (spec.SearchStringNotStartsWith.HasValue())
				builder.Where(builder.Condition(DistributionList.Meta.Name, ConditionOperator.NotStartsWith, spec.SearchStringNotStartsWith, "a"));

			if (spec.SearchStringsNotStartsWith.HasValue())
			{
				builder.StartWhereGroup(GroupOperator.Or);
				foreach (var value in spec.SearchStringsNotStartsWith)
				{
					builder.Where(builder.Condition(DistributionList.Meta.Name, ConditionOperator.NotStartsWith, value, "a"));
				}
				builder.EndWhereGroup();
			}

			if (spec.SearchStringStartsWith.HasValue())
				builder.Where(builder.Condition(DistributionList.Meta.Name, ConditionOperator.StartsWith, spec.SearchStringStartsWith, "a"));

			if (spec.Id.HasValue)
				builder.Where(builder.Condition(DistributionList.Meta.Id, ConditionOperator.Equals, spec.Id.Value, "a"));
			else if (spec.Ids.HasValue())
				builder.Where(builder.Condition(DistributionList.Meta.Id, ConditionOperator.In, spec.Ids, "a"));

			if (spec.ExcludeIds.HasValue())
				builder.Where(builder.Condition(DistributionList.Meta.Id, ConditionOperator.NotIn, spec.ExcludeIds, "a"));

			if (spec.CommonName.HasValue())
				builder.Where(builder.Condition(DistributionList.Meta.CommonName, ConditionOperator.Equals, spec.CommonName, "a"));

			if (spec.ContainsLineages.HasValue())
			{
				builder.StartWhereGroup(GroupOperator.Or);
				foreach (var lineage in spec.ContainsLineages)
				{
					builder.Where(builder.Condition(DistributionList.Meta.Lineage, ConditionOperator.Contains, lineage, "a"));
				}
				builder.EndWhereGroup();
			}

			if (spec.StartsWithLineages.HasValue())
			{
				builder.StartWhereGroup(GroupOperator.Or);
				foreach (var lineage in spec.StartsWithLineages)
				{
					builder.Where(builder.Condition(DistributionList.Meta.Lineage, ConditionOperator.StartsWith, lineage, "a"));
				}
				builder.EndWhereGroup();
			}

			if (spec.EndsWithLineages.HasValue())
			{
				builder.StartWhereGroup(GroupOperator.Or);
				foreach (var lineage in spec.EndsWithLineages)
				{
					builder.Where(builder.Condition(DistributionList.Meta.Lineage, ConditionOperator.EndsWith, lineage, "a"));
				}
				builder.EndWhereGroup();
			}

			if (spec.EqualLineage.HasValue())
				builder.Where(builder.Condition(DistributionList.Meta.Lineage, ConditionOperator.Equals, spec.EqualLineage, "a"));

			if (spec.IncludeUserBase)
			{
				var context = (INgaddataContext) Context;
				_customAttributeLookup = new CustomAttributeLookup(
							context.CustomAttributeRepository.FindBySpec(new CustomAttributeSpec { ProviderId = spec.ProviderId })
				);
			}

			if (!spec.IncludeLists) //omit distribution list
				builder.Where(builder.Condition(DistributionList.Meta.ListType, ConditionOperator.Equals, ListItemType.Tree, "a"));

			if (spec.IsSystem.HasValue)
				builder.Where(builder.Condition(DistributionList.Meta.IsSystem, ConditionOperator.Equals, spec.IsSystem.Value, "a"));
		}

		protected override bool OnItemDataBound(DistributionListSpec spec, DistributionList obj, DbResultItem resultItem, SqlMapperContext mapContext)
		{
			if (spec.IncludeHierarchy)
			{
				obj.Hierarchy = this.Context.Map.Translate<Hierarchy>(resultItem, mapContext);
				if (spec.IncludeCustomAttribute)
					obj.Hierarchy.CustomAttribute = this.Context.Map.Translate<CustomAttribute>(resultItem, mapContext);
			}

			if (spec.IncludeTranslatedDefinition)
			{
				obj.TranslatedDefinition = resultItem["TranslatedDefinition"].ConvertTo<string>();
				this.Context.Map.CompleteTranslation(resultItem, mapContext);
			}

			if (spec.IncludeUserBase && obj.Definition.HasValue())
			{
				if (obj.ListType == ListItemType.Dynamic)
				{
					obj.UserBase = AttrCriteria.DynamicList(_customAttributeLookup, obj.Definition);
				}
				if (obj.ListType == ListItemType.Static)
				{
					obj.UserBase = AttrCriteria.StaticList(_customAttributeLookup, obj.Definition);
				}
			}

			return true;
		}

        public string IsEntityAccessUnrestricted(int userId, int providerId)
        {
            const string sql = @"SELECT dbo.OPR_IS_DIST_LIST_RESTRICTABLE(@userId, @providerId)";
            var query = new DbQuery(Context, sql);
            query.AddParameter("userId", userId);
            query.AddParameter("providerId", providerId);
            return query.ExecuteScalar<string>();
        }

        public IEnumerable<DistributionList> GetChildrenNodes(DistributionListSpec spec)
        {
            var parameters = new List<SqlParameter>();
            var sql = GetChildrenNodesStoreProc(spec, parameters);

            return Context.Query<DistributionList>(sql, parameters);

        }

	    public IEnumerable<int> GetNestedStaticListIds(int listId)
	    {
	        var list = new List<int>();
	        var parameters = new List<SqlParameter> {new SqlParameter("@listID", listId)};
	        const string sql = @"SELECT LIST_ID FROM dbo.GET_LIST_NESTED_LISTS(@listID)";
	        var reader = Context.ExecuteDataReader(sql, parameters);
	        while (reader.Read())
	        {
	            list.Add((Int32)reader["LIST_ID"]);
	        }
	        return list;

	    } 

        private string GetChildrenNodesStoreProc(DistributionListSpec spec, List<SqlParameter> parameters)
        {
            const string sql = @"exec USR_GET_HIERARCHY_CHILDREN_NODES";

            if (spec.ProviderId.HasValue)
            {
                parameters.Add(new SqlParameter("providerId", spec.ProviderId.Value));
            }

            if (spec.HierarchyId.HasValue)
            {
                parameters.Add(new SqlParameter("hierarchyId", spec.HierarchyId.Value));
            }

            parameters.Add(new SqlParameter("parentLineage", spec.EqualLineage));
 

            parameters.Add(new SqlParameter("includeLists", spec.IncludeLists));


            
            return sql;
        }

	    public DistributionListNameVerificationMessage VerifyDLName(DistributionListSpec spec)
	    {
            var parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@DLNAME", spec.Name));
            parameters.Add(new SqlParameter("@DLCOMMONNAME", spec.CommonName));
            parameters.Add(new SqlParameter("@PROVIDER_ID", spec.ProviderId));
            parameters.Add(new SqlParameter("@DLID", spec.Id));

            const string query = @"IF (@DLID IS NULL) -- NEW DL
                                BEGIN
	                                IF EXISTS (SELECT 0 FROM PDL_LIST_TAB WITH (NOLOCK) WHERE PROVIDER_ID = @PROVIDER_ID AND [STATUS] != 'DEL' AND NAME = @DLNAME) SELECT 'NewDLNameMatchesExistingDLName' AS Message
	                                ELSE IF EXISTS (SELECT 0 FROM PDL_LIST_TAB WITH (NOLOCK) WHERE PROVIDER_ID = @PROVIDER_ID AND [STATUS] != 'DEL' AND COMMON_NAME= @DLNAME) SELECT 'NewDLNameMatchesExistingDLCommonName' AS Message
	                                ELSE IF EXISTS (SELECT 0 FROM PDL_LIST_TAB WITH (NOLOCK) WHERE PROVIDER_ID = @PROVIDER_ID AND [STATUS] != 'DEL' AND NAME= @DLCOMMONNAME) SELECT 'NewDLCommonNameMatchesExistingDLName' AS Message
	                                ELSE IF EXISTS (SELECT 0 FROM PDL_LIST_TAB WITH (NOLOCK) WHERE PROVIDER_ID = @PROVIDER_ID AND [STATUS] != 'DEL' AND COMMON_NAME= @DLCOMMONNAME) SELECT 'NewDLCommonNameMatchesExistingDLCommonName' AS Message
	                                ELSE IF EXISTS (SELECT 0 FROM PRV_GET_ATTRIBUTES(@PROVIDER_ID) WHERE ATTRIBUTE_NAME = @DLNAME AND ATTRIBUTE_ID NOT IN (SELECT CAST([DEFINITION] AS INT) FROM PDL_LIST_TAB WITH (NOLOCK) WHERE PROVIDER_ID = @PROVIDER_ID AND LIST_TYPE = 'STATIC')) SELECT 'NewDLNameMatchesExistingAttributeName' AS Message
	                                ELSE IF EXISTS (SELECT 0 FROM PRV_GET_ATTRIBUTES(@PROVIDER_ID) WHERE COMMON_NAME = @DLNAME AND ATTRIBUTE_ID NOT IN (SELECT CAST([DEFINITION] AS INT) FROM PDL_LIST_TAB WITH (NOLOCK) WHERE PROVIDER_ID = @PROVIDER_ID AND LIST_TYPE = 'STATIC')) SELECT 'NewDLNameMatchesExistingAttributeCommonName' AS Message
	                                ELSE IF EXISTS (SELECT 0 FROM PRV_GET_ATTRIBUTES(@PROVIDER_ID) WHERE ATTRIBUTE_NAME = @DLCOMMONNAME AND ATTRIBUTE_ID NOT IN (SELECT CAST([DEFINITION] AS INT) FROM PDL_LIST_TAB WITH (NOLOCK) WHERE PROVIDER_ID = @PROVIDER_ID AND LIST_TYPE = 'STATIC')) SELECT 'NewDLCommonNameMatchesExistingAttributeName' AS Message
	                                ELSE IF EXISTS (SELECT 0 FROM PRV_GET_ATTRIBUTES(@PROVIDER_ID) WHERE COMMON_NAME = @DLCOMMONNAME AND ATTRIBUTE_ID NOT IN (SELECT CAST([DEFINITION] AS INT) FROM PDL_LIST_TAB WITH (NOLOCK) WHERE PROVIDER_ID = @PROVIDER_ID AND LIST_TYPE = 'STATIC')) SELECT 'NewDLCommonNameMatchesExistingAttributeCommonName' AS Message
	                                ELSE SELECT 'DLNameAndDLCommonNameAreValid' AS Message
                                END
                                ELSE -- EXISTING DL
                                BEGIN
	                                IF EXISTS (SELECT 0 FROM PDL_LIST_TAB WITH (NOLOCK) WHERE PROVIDER_ID = @PROVIDER_ID AND [STATUS] != 'DEL' AND NAME = @DLNAME AND LIST_ID != @DLID) SELECT 'NewDLNameMatchesExistingDLName' AS Message
	                                ELSE IF EXISTS (SELECT 0 FROM PDL_LIST_TAB WITH (NOLOCK) WHERE PROVIDER_ID = @PROVIDER_ID AND [STATUS] != 'DEL' AND COMMON_NAME= @DLNAME AND LIST_ID != @DLID) SELECT 'NewDLNameMatchesExistingDLCommonName' AS Message
	                                ELSE IF EXISTS (SELECT 0 FROM PDL_LIST_TAB WITH (NOLOCK) WHERE PROVIDER_ID = @PROVIDER_ID AND [STATUS] != 'DEL' AND NAME= @DLCOMMONNAME AND LIST_ID != @DLID) SELECT 'NewDLCommonNameMatchesExistingDLName' AS Message
	                                ELSE IF EXISTS (SELECT 0 FROM PDL_LIST_TAB WITH (NOLOCK) WHERE PROVIDER_ID = @PROVIDER_ID AND [STATUS] != 'DEL' AND COMMON_NAME= @DLCOMMONNAME AND LIST_ID != @DLID) SELECT 'NewDLCommonNameMatchesExistingDLCommonName' AS Message
	                                ELSE IF EXISTS (SELECT 0 FROM PRV_GET_ATTRIBUTES(@PROVIDER_ID) WHERE ATTRIBUTE_NAME = @DLNAME AND ATTRIBUTE_ID NOT IN (SELECT CAST([DEFINITION] AS INT) FROM PDL_LIST_TAB WITH (NOLOCK) WHERE PROVIDER_ID = @PROVIDER_ID AND LIST_TYPE = 'STATIC')) SELECT 'NewDLNameMatchesExistingAttributeName' AS Message
	                                ELSE IF EXISTS (SELECT 0 FROM PRV_GET_ATTRIBUTES(@PROVIDER_ID) WHERE COMMON_NAME = @DLNAME AND ATTRIBUTE_ID NOT IN (SELECT CAST([DEFINITION] AS INT) FROM PDL_LIST_TAB WITH (NOLOCK) WHERE PROVIDER_ID = @PROVIDER_ID AND LIST_TYPE = 'STATIC')) SELECT 'NewDLNameMatchesExistingAttributeCommonName' AS Message
	                                ELSE IF EXISTS (SELECT 0 FROM PRV_GET_ATTRIBUTES(@PROVIDER_ID) WHERE ATTRIBUTE_NAME = @DLCOMMONNAME AND ATTRIBUTE_ID NOT IN (SELECT CAST([DEFINITION] AS INT) FROM PDL_LIST_TAB WITH (NOLOCK) WHERE PROVIDER_ID = @PROVIDER_ID AND LIST_TYPE = 'STATIC')) SELECT 'NewDLCommonNameMatchesExistingAttributeName' AS Message
	                                ELSE IF EXISTS (SELECT 0 FROM PRV_GET_ATTRIBUTES(@PROVIDER_ID) WHERE COMMON_NAME = @DLCOMMONNAME AND ATTRIBUTE_ID NOT IN (SELECT CAST([DEFINITION] AS INT) FROM PDL_LIST_TAB WITH (NOLOCK) WHERE PROVIDER_ID = @PROVIDER_ID AND LIST_TYPE = 'STATIC')) SELECT 'NewDLCommonNameMatchesExistingAttributeCommonName' AS Message
	                                ELSE SELECT 'DLNameAndDLCommonNameAreValid' As Message
                                END";

            var messageDR = Context.ExecuteDataReader(query, parameters);
            var message = DistributionListNameVerificationMessage.DLNameAndDLCommonNameAreValid;

            if (messageDR.Read())
            {
                DistributionListNameVerificationMessage result;
                if (Enum.TryParse(messageDR["Message"].ToString(), out result))
                     message = result;
            }
            messageDR.Close();
	        
            return message;
	    }
	}
}
