﻿using AtHoc.Data;
using AtHoc.Diagnostics;
using AtHoc.IWS.Business.Data.SearchSpec;
using AtHoc.IWS.Business.Domain.Audit;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Reports;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Targeting.Model;
using AtHoc.Publishing;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using ResponseOption = AtHoc.Publishing.ResponseOption;

namespace AtHoc.IWS.Business.Domain.Publishing
{
    public class AlertFacade : IAlertFacade, IAlertReportDataRepository
    {
        private readonly IAlertReportDataRepository _alertReportDataRepository;
        private readonly IAlertRepository _alertRepository;
        private readonly ILanguageFacade _languageFacade;
        
        public AlertFacade(IAlertReportDataRepository alertReportDataRepository, ILanguageFacade languageFacade)
        {
            _alertReportDataRepository = alertReportDataRepository;
            _alertRepository = new AlertRepository();
            _languageFacade = languageFacade;
        }

        public DataTable GetTargetUserBase(ResultBasedTargetingCriteria rbtCriteria)
        {
            return _alertReportDataRepository.GetTargetUserBase(rbtCriteria);
        }

        public AlertTrackingResult GetAlertTrackingSummary(int alertId, ReportType type = ReportType.Summary,
            Dimension dim = Dimension.USER)
        {
            return _alertReportDataRepository.GetAlertTrackingSummary(alertId, type, dim);
        }

        public ArrayList GetAlertReportData(int providerId, AlertReportCriteria reportCriteria)
        {
            return _alertReportDataRepository.GetAlertReportData(providerId, reportCriteria);
        }


        public IPaged<DtoAlert> GetAlerts(AlertSearchSpec spec)
        {
            ICriteria criteria = new Criteria();

            //criteria = criteria
            //    .Add(Disjunction.Contains("channelname", "")
            //    .Add(Disjunction.Contains("alerttitle", ""))
            //    .Add(Disjunction.Contains("publisher", "")));


            if (spec.StatusFilter.Count != 0)
            {
                var slist = from s in spec.StatusFilter
                    select Enum.Parse(typeof(AlertStatus), s, true);
                criteria.Add(Junction.In("status", slist));
            }

            criteria.Add(Junction.Contains("alerttitle", spec.SearchText));

            if (spec.FromDate != null && spec.ToDate != null)
            {
                criteria.Add(Junction.Between("startdate", spec.FromDate, spec.ToDate));
            }
            else if (spec.FromDate != null) //to date is empty 
            {
                criteria.Add(Junction.Between("startdate", spec.FromDate, DateTime.MaxValue));
            }
            else if (spec.ToDate != null) //from date is empty 
            {
                criteria.Add(Junction.Between("startdate", (DateTime) SqlDateTime.MinValue, spec.ToDate));
            }

            if (spec.ChannelId != -1)
            {
                criteria.Add(Junction.Eq("channelid", spec.ChannelId));
            }

            if (!string.IsNullOrEmpty(spec.Publisher))
            {
                criteria.Add(Junction.Eq("publisher", spec.Publisher));
            }

            if (spec.Severities.Count != 0)
            {
                criteria.Add(Junction.In("severity", ((IEnumerable) spec.Severities).Cast<Object>()));
            }
            if (spec.Events.Count != 0)
            {
                criteria.Add(Junction.In("event", ((IEnumerable) spec.Events).Cast<Object>()));
            }

            criteria.AddOrder(getSortName(spec.Sort), convertSortOrder(spec.Sort)).SetPageNumber(spec.Page);

            if (spec.PageSize != 0)
            {
                criteria.SetPageSize(spec.PageSize);
            }

            var am = new AlertManager(spec.ProviderId, spec.OperatorId);
            return am.GetAlerts(criteria);
        }


        public IList<Language> GetSupportedLanguages(int providerId)
        {

            return _languageFacade.GetDeliveryEnabledLanguages(providerId).ToList();
        }

        private string getSortName(List<KendoSortOrder> sortOrder)
        {
            string defaultSort = "startdate";
            if (sortOrder == null || sortOrder.Count == 0)
                return defaultSort;

            switch (sortOrder.FirstOrDefault().Field.ToLower())
            {
                case "title":
                    return "alerttitle";
                case "start":
                    return "startdate";
                case "status":
                    return "status";
                case "publisher":
                    return "publisher";
                default:
                    return defaultSort;
            }
        }

        private SortOrder convertSortOrder(List<KendoSortOrder> sortOrder)
        {
            if (sortOrder == null || sortOrder.Count == 0)
                return SortOrder.Ascending;

            switch (sortOrder.First().Dir)
            {
                case "desc":
                    return SortOrder.Descending;
                default:
                    return SortOrder.Ascending;
            }
        }

        public bool CanModifyPerUserbase(int operatorId, int providerId, IEnumerable<int> list,
            ref List<int> unmodifiableAlerts)
        {
            bool canModify = true;

            AlertManager manager = new AlertManager(providerId, operatorId);

            foreach (int item in list)
            {
                Alert alert = manager.GetAlert(item);

                if (alert != null)
                {
                    if (!alert.AllowAlertUpdate(operatorId))
                    {
                        canModify = false;
                        unmodifiableAlerts.Add(alert.AlertId);
                    }
                }
            }
            return canModify;
        }

        public bool Delete(int operatorId, int providerId, IEnumerable<int> list)
        {
            var manager = new AlertManager(providerId, operatorId);

            foreach (int item in list)
            {
                var alert = manager.GetAlert(item);

                if (alert != null)
                {
                    if (!alert.AllowAlertUpdate(operatorId))
                    {
                        return false;
                    }
                    manager.DeleteAlert(alert);
                }
            }
            return true;
        }

        public bool End(int operatorId, int providerId, IEnumerable<int> list)
        {
            var manager = new AlertManager(providerId, operatorId);

            foreach (var item in list)
            {
                var alert = manager.GetAlert(item);
                if (alert != null)
                {
                    if (!alert.AllowAlertUpdate(operatorId))
                    {
                        return false;
                    }
                    manager.EndAlert(alert);
                }
            }
            return true;
        }

        public bool End(int alertId, int operatorId, int providerId, DateTime endTime)
        {
            try
            {
                var manager = new AlertManager(providerId, operatorId);
                manager.EndAlert(alertId, operatorId, endTime);
                return true;
            }
            catch (Exception ex)
            {
               EventLogger.WriteError("Error while ending alert",ex);
               return false;
            }
           
        }
        public Alert GetAlert(int id, int providerId, int operatorId)
        {
            var manager = new AlertManager(providerId, operatorId);
            return manager.GetAlert(id);
        }

        public Alert DuplicateAlert(int id, int providerId, int operatorId)
        {
            var manager = new AlertManager(providerId, operatorId);
            return manager.CreateAlertFromAlert(id, true);
        }

        public Alert CreateAlert(int providerId, int operatorId)
        {
            var manager = new AlertManager(providerId, operatorId);
            return manager.CreateAlert();
        }

        public Alert CreateAlertFromScenario(int providerId, int operatorId, int scenarioId)
        {
            var manager = new AlertManager(providerId, operatorId);
            return (scenarioId == 0) ? manager.CreateAlert() : manager.CreateAlertFromScenario(scenarioId, operatorId);
        }

        public bool SaveAlert(int providerId, int operatorId, Alert alert)
        {
            var manager = new AlertManager(providerId, operatorId);
            manager.SaveAlert(alert);
            return true;
        }

        public bool StandbyAlert(int providerId, int operatorId, Alert alert)
        {
            var manager = new AlertManager(providerId, operatorId);  
            manager.StandbyAlert(alert); 
            return true;
        }

        public bool PublishAlert(int providerId, int operatorId, Alert alert)
        {
            var manager = new AlertManager(providerId, operatorId);
            alert.IsReadyForPublish = true;
            var auditSpec = new AuditSpec(operatorId, providerId)
            {
                Action = ServiceAction.AlertPublished,
                ObjectType = EntityType.Alert,
                ObjectName = alert.Name
            };
            if (alert.Status == AlertStatus.Standby)
            {
                manager.PublishStandbyAlert(alert);
            }
            else
            {
                manager.SaveAlert(alert);
                auditSpec.Action = ServiceAction.CreatedPublished;
                //OperationAuditor.LogAction(auditSpec);
            }
            auditSpec.Action = ServiceAction.AlertPublished;
            //OperationAuditor.LogAction(auditSpec);

            return true;
        }

        public List<ResponseOption> GetAlertResponseOptions(int alertId)
        {
            var reponseOptionsList = new List<ResponseOption>();
            var am = new AlertManager();
            var alert = am.GetAlert(alertId);
            var alertSpecification = alert.AlertSpec;
            var resList = alertSpecification.Content.ResponseOptions;


            if (resList.Count > 0)
            {
                for (var i = 0; i < resList.Count; i++)
                {
                    reponseOptionsList.Add(resList[i]);
                }
            }
            else
            {
                reponseOptionsList.Add(new ResponseOption("Acknowledge"));
            }
            
            return reponseOptionsList;
        }

        /// <summary>
        /// Returns List of publisher for a given providerid
        /// </summary>
        /// <param name="providerId">ProviderId</param>
        /// <returns>List of publisher name</returns>
        public IList<string> GetPublisherByProviderId(int providerId)
        {
            return _alertRepository.GetPublisher(providerId);
        }

        public int GetMapAlertCount(IEnumerable<int> alertIds, bool isEvent)
        {
            return AlertBaseManager.GetGeoLocationCount(alertIds, isEvent);
        }

        public IEnumerable<DtoAlert> GetAlertsForMap(AlertSearchSpec alertSpec, bool getEventAlert = false)
        {
            var alerts = GetAlerts(alertSpec);
            
            var liveAlerts = getEventAlert == true
                ? alerts.GetList().Where(alert => alert.OriginType == OriginType.EventBased)
                : alerts.GetList().Where(alert => alert.OriginType != OriginType.EventBased);

            var alertSearchResults = liveAlerts as DtoAlert[] ?? liveAlerts.ToArray();
            if (liveAlerts != null && alertSearchResults.Any())
            {
                var allAlertBaseId = from eventEntity in alertSearchResults
                                     select eventEntity.Id;

                var alertBaseMgr = new AlertBaseManager(alertSpec.ProviderId, alertSpec.OperatorId);
                var locationData = alertBaseMgr.GetGeoLocation(allAlertBaseId);

                if (locationData != null && locationData.Any())
                {
                    foreach (var evt in alertSearchResults)
                    {
                        if (locationData.ContainsKey(evt.Id))
                        {
                            var geoJson = locationData[evt.Id];
                            if (string.IsNullOrEmpty(geoJson))
                                continue;

                            evt.GeoJson = locationData[evt.Id];
                            yield return evt;
                        }
                    }
                }
            }
        }
    }
}