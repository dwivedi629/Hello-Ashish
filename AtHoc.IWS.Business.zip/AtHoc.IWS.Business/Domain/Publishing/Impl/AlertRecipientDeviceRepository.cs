﻿using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Database;
using AtHoc.Infrastructure.Sql;

using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.Publishing
{
	public class AlertRecipientDeviceDbRepository : DbRepository<AlertRecipientDevice, AlertRecipientDeviceSpec>, IAlertRecipientDeviceRepository
	{
		public AlertRecipientDeviceDbRepository(IUnitOfWork context) : base(context) {}

		protected override void TranslateSpec(AlertRecipientDeviceSpec spec, SqlBuilder builder, bool query)
		{
			builder.SelectAll<AlertRecipientDevice>();
			builder.From(builder.Table<AlertRecipientDevice>());

			if (spec.AlertId.HasValue)
				builder.Where(builder.Condition(AlertRecipientDevice.Meta.AlertId, ConditionOperator.Equals, spec.AlertId.Value));
		}
	}
}
