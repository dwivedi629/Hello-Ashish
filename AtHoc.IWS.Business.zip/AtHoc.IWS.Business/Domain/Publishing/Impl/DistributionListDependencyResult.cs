﻿using System.Collections.Generic;

using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.Publishing.Impl
{
	public class DistributionListDependencyResult
	{
		public int DependentListCount { get; internal set; }

		public int IndependentListCount { get; internal set; }

		public IEnumerable<DistributionListDependency> Dependencies { get; internal set; }
	}
}
