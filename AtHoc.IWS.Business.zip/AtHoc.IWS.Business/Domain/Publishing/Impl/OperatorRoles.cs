﻿using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.Publishing.Impl
{
    public static class OperatorRoles
    {
        public const int OrganizationAdmin = (int)Roles.Administrator;
        public const int SDKUser = (int)Entities.Roles.SDKUser;
        public const int AlertPublisher = (int)Roles.AdvancedAlertPublisher;
        public const int DraftAlertCreator = (int)Roles.DraftAlertCreator;
        public const int DistributionListsManager = (int)Roles.DistributionListsManager;
        public const int EndUsersManager = (int)Roles.EndUsersManager;
        public const int ReportManager = (int)Roles.ReportViewer;
        public const int DownloadExportFile = (int)Roles.DownloadExportFile;
        public const int SSAViewer = (int)Roles.SSAViewer;
        public const int SSAOperator = (int)Roles.SSAOperator;
        public const int AdvancedAlertManager = (int)Roles.AdvancedAlertManager;
        public const int SystemAdmin = (int)Roles.SystemAdmin;
        public const int ConnectAgreementManager = (int)Roles.ConnectAgreementManager;
        public const int Operator = (int)Roles.Operator;
        public const int Admin = (int)Roles.Admin;
        public static int[] ChannelRoles = { OrganizationAdmin,
                                               SDKUser,
                                               AlertPublisher,
                                               DraftAlertCreator,
                                               DistributionListsManager,
                                               EndUsersManager,
                                               ReportManager,
                                               DownloadExportFile,
                                               SSAViewer,
                                               SSAOperator,
                                               AdvancedAlertManager,
                                               SystemAdmin,
                                               ConnectAgreementManager,
                                               Operator,
                                               Admin
                                           };
    }
}
