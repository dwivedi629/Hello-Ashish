﻿using System.Linq;
using System.Web;
using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Database;
using System;
using System.Collections.Generic;
using AtHoc.Infrastructure.Sql;
using AtHoc.IWS.Business.Data.SearchSpec;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.Runtime;
using Dapper;


namespace AtHoc.IWS.Business.Domain.Publishing.Impl
{
    public class ScenarioDbRepository : IScenarioRepository
    {
        protected DbContext Context { get; set; }

        public ScenarioDbRepository(IUnitOfWork context)
        {
            Context = context as DbContext;
        }

        public IEnumerable<Scenario> GetScenarios(int providerId, int operatorId, ScenarioSearchSpec spec)
        {
            const string getUsersByEmail = @"EXEC [dbo].[SCN_GET_BASIC_DETAILS]";

            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@in_providerId", providerId),
                new SqlParameter("@in_operatorId", operatorId),
                new SqlParameter("@in_channelId", spec.ChannelId == -1 ? 0 : spec.ChannelId),
                new SqlParameter("@in_includeDisabledChannels", false),
                new SqlParameter("@in_includeDisabledScenarios", true),
                new SqlParameter("@in_onlyAvailableInHomePage", spec.QuickOnly),
                new SqlParameter("@in_keywords", spec.SearchText),
                new SqlParameter("@in_includeRecurringOnly", spec.RecurrentOnly),
                new SqlParameter("@in_scenarioId", 0),
                new SqlParameter("@in_commonName", spec.CommonName),
            };

            var reader = Context.ExecuteDataReader(getUsersByEmail, parameters);
            var scenarios = new List<Scenario>();
            while (reader.Read())
            {
                var scenario = new Scenario
                {
                    AlertBody = reader["CONTENT_BODY"].ToString(),
                    AlertTitle = reader["CONTENT_TITLE"].ToString(),
                    ChannelName = reader["CHANNELNAME"].ToString(),
                    Description = reader["DESCRIPTION"].ToString(),
                    Enabled = reader["STATUS"].ToString() == "ACT",
                    IsDefaultforNewAlert = reader["IS_DEFAULT_FOR_NEW_ALERT"].ToString() == "Y",
                    IsDefaultforNewScenario = reader["IS_DEFAULT_FOR_NEW_SCENARIO"].ToString() == "Y",
                    IsQuickPublish = reader["VISIBLE_IN_HOME_PAGE"].ToString() == "Y",
                    IsReadyForPublish = reader["IS_READY_FOR_PUBLISH"].ToString() == "Y",
                    IsRecurringScenario = reader["IS_RECURRING_SCENARIO"].ToString() == "Y",
                    Name = reader["NAME"].ToString(),
                    NextRecurrence = String.IsNullOrEmpty(reader["NEXT_RECURRENCE"].ToString()) ? (DateTime?)null : DateTime.Parse(reader["NEXT_RECURRENCE"].ToString()),
                    PublishedOn = String.IsNullOrEmpty(reader["LAST_PUBLISHED_TIMESTAMP"].ToString()) ? (DateTime?)null : DateTime.Parse(reader["LAST_PUBLISHED_TIMESTAMP"].ToString()),
                    ScenarioId = Int32.Parse(reader["SCENARIO_ID"].ToString()),
                    CommonName = reader["COMMON_NAME"].ToString(),
                    UpdatedBy = reader["UPDATED_BY_USERNAME"].ToString()
                };

                scenarios.Add(scenario);
            }
            return scenarios;
        }
    }
}