﻿using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Database;
using AtHoc.Infrastructure.Sql;

using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Publishing.Spec;

namespace AtHoc.IWS.Business.Domain.Publishing.Impl
{
	public class DistributionListFolderDbRepository : DbRepository<DistributionListFolder, DistributionListFolderSpec>, IDistributionListFolderRepository
	{
		public DistributionListFolderDbRepository(IUnitOfWork context) : base(context) {}

		protected override void TranslateSpec(DistributionListFolderSpec spec, SqlBuilder builder, bool query)
		{
			builder.SelectAll<DistributionListFolder>();
			builder.From(builder.Table<DistributionListFolder>());

			if (spec.ChildListId.HasValue)
				builder.Where(builder.Condition(DistributionListFolder.Meta.ChildListId, ConditionOperator.Equals, spec.ChildListId));

			if (spec.ParentListId.HasValue)
				builder.Where(builder.Condition(DistributionListFolder.Meta.ParentListId, ConditionOperator.Equals, spec.ParentListId));
		}
	}
}
