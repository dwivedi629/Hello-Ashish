﻿using AtHoc.Data;
using AtHoc.IWS.Business.Data.SearchSpec;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Targeting.Model;
using AtHoc.Publishing;
using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
//using AtHoc.Reports;
using AtHoc.Systems;
using AtHoc.VirtualSystems;
using AtHoc.IWS.Business.Domain.Audit;
using System.Data;
using System.Collections;
using AtHoc.IWS.Business.Domain.Reports;

namespace AtHoc.IWS.Business.Domain.Publishing
{
    public class AlertReportDataRepository : IAlertReportDataRepository
    {
        public ArrayList GetAlertReportData(int providerId, AlertReportCriteria reportCriteria)
        {
            var reportData = new ArrayList();
            using (var db = new AtHocDbContext())
            {
                // If using Code First we need to make sure the model is built before we open the connection 
                // This isn't required for models created with the EF Designer 
                db.Database.Initialize(force: false);
                // Create a SQL command to execute the sproc 
                var cmd = db.Database.Connection.CreateCommand();
                cmd.CommandText = "[dbo].[RPT_USER_ATTRIBUTE_DETAILS]";
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@in_attributeType", reportCriteria.AttributeType));
                cmd.Parameters.Add(new SqlParameter("@in_attributeIdCSV", reportCriteria.AttributeIdCSV));
                cmd.Parameters.Add(new SqlParameter("@in_cachedUsersSessionId", reportCriteria.CachedUsersSessionId));
                cmd.Parameters.Add(new SqlParameter("@in_providerId", reportCriteria.ProviderId));
                cmd.Parameters.Add(new SqlParameter("@in_entityIdFilter", reportCriteria.EntityIdFilter));
                cmd.Parameters.Add(new SqlParameter("@in_hrchyType", reportCriteria.HrchyType));
                cmd.Parameters.Add(new SqlParameter("@in_hrchyNodeId", reportCriteria.HrchyNodeId));
                cmd.Parameters.Add(new SqlParameter("@in_includeChildren", reportCriteria.IncludeChildren));
                cmd.Parameters.Add(new SqlParameter("@in_getCoveredByAttributeUsers", reportCriteria.GetCoveredByAttributeUsers));
                cmd.Parameters.Add(new SqlParameter("@in_getNOTCoveredByAttributeUsers", reportCriteria.GetNOTCoveredByAttributeUsers));
                cmd.Parameters.Add(new SqlParameter("@in_getTotalUsers", reportCriteria.GetTotalUsers == -1 ? 1 : 0));
                cmd.Parameters.Add(new SqlParameter("@in_getTotalCoveredUsers", reportCriteria.GetTotalCoveredUsers == 1 ? 1 : 0));
                cmd.Parameters.Add(new SqlParameter("@in_getTotalNOTCoveredUsers", reportCriteria.GetTotalNOTCoveredUsers == 0 ? 1 : 0));
                cmd.Parameters.Add(new SqlParameter("@in_getDevices", reportCriteria.GetDevices));
                cmd.Parameters.Add(new SqlParameter("@in_sortBy", reportCriteria.SortBy));
                cmd.Parameters.Add(new SqlParameter("@in_isSortAsc", reportCriteria.IsSortAsc=="ASC"?1:0));
                cmd.Parameters.Add(new SqlParameter("@in_pageNumber", reportCriteria.PageNumber));
                cmd.Parameters.Add(new SqlParameter("@in_rowsPerPage", reportCriteria.RowsPerPage));
                cmd.Parameters.Add(new SqlParameter("@in_adjustTimeZone", reportCriteria.AdjustTimeZone));
                cmd.Parameters.Add(new SqlParameter("@in_debugflag", reportCriteria.Debugflag));
                cmd.Parameters.Add(new SqlParameter("@in_getAttributes", reportCriteria.GetAttributes));
                cmd.Parameters.Add(new SqlParameter("@totalUsers",""));
                cmd.Parameters.Add(new SqlParameter("@usersRetrieved", ""));
                cmd.Parameters.Add(new SqlParameter("@attributeSearchValue", reportCriteria.AttributeSearchValue));
                db.Database.Connection.Open();

                var reader = cmd.ExecuteReader();
            
                var alertReportRawData = new List<AlertUserListRawData>();
                while (reader.Read())
                {
                    alertReportRawData.Add(GetRawRecord(reader));

                }
                reader.NextResult();
                var alertReportColumns = new List<AlertUserListColumn>();
                while (reader.Read())
                {
                    var  t=(from s in  alertReportRawData
                            where s.ColumnId==Convert.ToInt16(reader.GetValue<string>("column_id"))
                              select s.ColumnId).ToList();

                    if ((!reader.IsDBNull(reader.GetOrdinal("column_view_id"))) || (!reader.IsDBNull(reader.GetOrdinal("column_common_name"))) || t.Count>0)
                     {
                            alertReportColumns.Add(GetColumnRecord(reader));
                     }

                }

                reader.NextResult();
                reader.NextResult();
                while (reader.Read())
                { 
                    reportCriteria.TotalUsers=reader.GetValue<int>("totalUsers");
                }

                var reportRowData = (from clm in alertReportColumns
                                  join raw in alertReportRawData
                                  on clm.ColumnId equals raw.ColumnId //join on columnId
                                  where  raw.ColumnId != null
                                  select new AlertUserListData 
                                  {
                                      ColumnId = clm.ColumnId.ToString(),
                                      ColumnName = clm.ColumnName,
                                      ColumnValue = raw.ColumnValue,
                                      ColumnOrder=raw.ColumnOrder,
                                      ColumnRecord=raw.RecordNum,
                                      ColumnViewId=clm.ColumnViewId,
                                  }).ToList();

                db.Database.Connection.Close();

                reportData.Add(reportRowData);
                reportData.Add(alertReportColumns);
                reportData.Add(reportCriteria.TotalUsers);

                return reportData;
            }
        }

        public  AlertUserListColumn GetColumnRecord(IDataRecord reader)
        {
           
            var record = new AlertUserListColumn()
            {
                ColumnId = Convert.ToInt32(reader.GetValue<string>("column_id")),
                ColumnName = reader.GetValue<string>("column_name"),
                ColumnCommonName = reader.GetValue<string>("column_common_name"),
                ColumnDataType = reader.GetValue<string>("column_data_type"),
                ColumnExportName = reader.GetValue<string>("column_export_name"),
                ColumnOrder = reader.GetValue<int>("column_order"),
                ColumnType = reader.GetValue<string>("column_type"),
                ColumnViewId = reader.GetValue<int>("column_view_id"),
            };

            return record;

        }


        public AlertUserListRawData GetRawRecord(IDataRecord reader)
        {

            var record = new AlertUserListRawData()
            {
                ColumnId = Convert.ToInt32(reader.GetValue<string>("value_id")),
                ColumnValue = reader.GetValue<string>("value"),
                ColumnType = reader.GetValue<string>("value_type"),
                ColumnDataType = reader.GetValue<string>("column_data_type"),
                ColumnOrder = reader.GetValue<int>("column_order"),
                RecordNum = reader.GetValue<int>("record_num"),

            };

            return record;

        }

        public IPaged<DtoAlert> GetAlerts(AlertSearchSpec spec)
        {
            ICriteria criteria = new AtHoc.Data.Criteria();

            //criteria = criteria
            //    .Add(Disjunction.Contains("channelname", "")
            //    .Add(Disjunction.Contains("alerttitle", ""))
            //    .Add(Disjunction.Contains("publisher", "")));


            if (spec.StatusFilter.Count != 0)
            {
                //var bleh = new[] { "Live" };
                var slist = from s in spec.StatusFilter
                            select Enum.Parse(typeof(AlertStatus), s, true);
                criteria.Add(Junction.In("status", slist));
            }

            criteria.Add(Junction.Contains("alerttitle", spec.SearchText));

            if (spec.FromDate != null && spec.ToDate != null)
            {
                criteria.Add(Junction.Between("startdate", spec.FromDate, spec.ToDate));
            }
            else if (spec.FromDate != null) //to date is empty 
            {
                criteria.Add(Junction.Between("startdate", spec.FromDate, DateTime.MaxValue));
            }
            else if (spec.ToDate != null) //from date is empty 
            {
                criteria.Add(Junction.Between("startdate", (DateTime)SqlDateTime.MinValue, spec.ToDate));
            }

            if (spec.ChannelId != -1)
            {
                criteria.Add(Junction.Eq("channelid", spec.ChannelId));
            }

            if (spec.Publisher != null && spec.Publisher.Length != 0)
            {
                criteria.Add(Junction.Eq("publisher", spec.Publisher));
            }
            /*            else
                        {
                            criteria = criteria
                                .Add(Disjunction.Contains("channelname", "")
                                .Add(Disjunction.Contains("alerttitle", spec.SearchText))
                                .Add(Disjunction.Contains("publisher", "")));
                        }
                        */
            criteria.AddOrder(getSortName(spec.Sort), convertSortOrder(spec.Sort))
                .SetPageNumber(spec.Page);

            if (spec.PageSize != 0)
            {
                criteria.SetPageSize(spec.PageSize);
            }

            //             .SetPageSize(spec.PageSize);

            AlertManager am = new AlertManager(spec.ProviderId, spec.OperatorId);
            return am.GetAlerts(criteria);

        }


        public IList<LocaleInfo> GetSupportedLanguages(int providerId)
        {
            var vmService = new VirtualSystemService();
            var vm = vmService.GetById(providerId);
            return vm.SupportedLocales.Where(locale => (locale.EnabledforPublish)).ToList();
        }

        private string getSortName(List<KendoSortOrder> sortOrder)
        {
            string defaultSort = "startdate";
            if (sortOrder == null || sortOrder.Count == 0)
                return defaultSort;

            switch (sortOrder.FirstOrDefault().Field.ToLower())
            {
                case "title": return "alerttitle";
                case "start": return "startdate";
                case "status": return "status";
                case "publisher": return "publisher";
                default: return defaultSort;
            }
        }

        private SortOrder convertSortOrder(List<KendoSortOrder> sortOrder)
        {
            if (sortOrder == null || sortOrder.Count == 0)
                return SortOrder.Ascending;

            switch (sortOrder.First().Dir)
            {
                case "desc": return SortOrder.Descending;
                default: return SortOrder.Ascending;
            }
        }

        public bool CanModifyPerUserbase(int operatorId, int providerId, IEnumerable<int> list, ref List<int> unmodifiableAlerts)
        {
            bool canModify = true;

            AlertManager manager = new AlertManager(providerId, operatorId);

            foreach (int item in list)
            {
                Alert alert = manager.GetAlert(item);

                if (alert != null)
                {
                    if (!alert.AllowAlertUpdate(operatorId))
                    {
                        canModify = false;
                        unmodifiableAlerts.Add(alert.AlertId);
                    }
                }
            }
            return canModify;
        }

        public bool Delete(int operatorId, int providerId, IEnumerable<int> list)
        {
            var manager = new AlertManager(providerId, operatorId);

            foreach (int item in list)
            {
                var alert = manager.GetAlert(item);

                if (alert != null)
                {
                    if (!alert.AllowAlertUpdate(operatorId))
                    {
                        return false;
                    }
                    manager.DeleteAlert(alert);
                }
            }
            return true;
        }

        public bool End(int operatorId, int providerId, IEnumerable<int> list)
        {
            var manager = new AlertManager(providerId, operatorId);

            foreach (var item in list)
            {
                var alert = manager.GetAlert(item);
                if (alert != null)
                {
                    if (!alert.AllowAlertUpdate(operatorId))
                    {
                        return false;
                    }
                    manager.EndAlert(alert);
                }
            }
            return true;
        }

        public Alert GetAlert(int id, int providerId, int operatorId)
        {
            var manager = new AlertManager(providerId, operatorId);
            return manager.GetAlert(id);
        }

        public Alert DuplicateAlert(int id, int providerId, int operatorId)
        {
            var manager = new AlertManager(providerId, operatorId);
            return manager.CreateAlertFromAlert(id, true);
        }

        public Alert CreateAlert(int providerId, int operatorId)
        {
            var manager = new AlertManager(providerId, operatorId);
            return manager.CreateAlert();
        }

        public Alert CreateAlertFromScenario(int providerId, int operatorId, int scenarioId)
        {
            var manager = new AlertManager(providerId, operatorId);
            return (scenarioId == 0) ? manager.CreateAlert() : manager.CreateAlertFromScenario(scenarioId, operatorId);
        }

        public bool SaveAlert(int providerId, int operatorId, Alert alert)
        {
            var manager = new AlertManager(providerId, operatorId);
            manager.SaveAlert(alert);
            return true;
        }

        public bool StandbyAlert(int providerId, int operatorId, Alert alert)
        {
            var manager = new AlertManager(providerId, operatorId);
            manager.StandbyAlert(alert);
            var auditSpec = new AuditSpec(operatorId, providerId)
            {
                Action = ServiceAction.CreatedStandby,
                ObjectType = EntityType.Alert,
                ObjectName = alert.Name
            };
            OperationAuditor.LogAction(auditSpec);
            return true;
        }

        public bool PublishAlert(int providerId, int operatorId, Alert alert)
        {
            var manager = new AlertManager(providerId, operatorId);
            alert.IsReadyForPublish = true;
            var auditSpec = new AuditSpec(operatorId, providerId)
            {
                Action = ServiceAction.AlertPublished,
                ObjectType = EntityType.Alert,
                ObjectName = alert.Name
            };
            if (alert.Status == AlertStatus.Standby)
            {
                manager.PublishStandbyAlert(alert);
            }
            else
            {
                manager.SaveAlert(alert);
                auditSpec.Action = ServiceAction.CreatedPublished;
                OperationAuditor.LogAction(auditSpec);
            }
            auditSpec.Action = ServiceAction.AlertPublished;
            OperationAuditor.LogAction(auditSpec);

            return true;
        }

        public DataTable GetTargetUserBase( 
                              ResultBasedTargetingCriteria rbtCriteria
                            )
        {
            using (var ngadDB = new NgadDatabase())
            {
                // Set DB timeout 600 seconds since generating report may take longer.
                ngadDB.CommandTimeout = 1200;
                ngadDB.CommandType = CommandType.StoredProcedure;
                ngadDB.AddParameter("@altCriteria", SqlDbType.VarChar, rbtCriteria.AlertCriteria);
                ngadDB.AddParameter("@tgtCriteria", SqlDbType.VarChar, rbtCriteria.TargetCriteria);
                ngadDB.AddParameter("@getUsers", SqlDbType.Int, rbtCriteria.GetUsers);
                ngadDB.AddParameter("@getMassDevices", SqlDbType.Int, rbtCriteria.GetMassDevices);
                ngadDB.AddParameter("@getCountsOnly", SqlDbType.Int, rbtCriteria.GetCountsOnly);
                //ngadDB.AddParameter("@useCommonNames", SqlDbType.Int, rbtCriteria.UseCommonNames);
                ngadDB.AddParameter("@deviceNames", SqlDbType.VarChar, rbtCriteria.DeviceNames);
                ngadDB.AddParameter("@usersPerPage", SqlDbType.Int, rbtCriteria.UsersPerPage);
                ngadDB.AddParameter("@pageNo", SqlDbType.Int, rbtCriteria.PageNo);
                ngadDB.AddParameter("@sortColumn",SqlDbType.VarChar, rbtCriteria.SortColumn);
                ngadDB.AddParameter("@isAsc", SqlDbType.Int, rbtCriteria.IsAsc);
                ngadDB.AddParameter("@debugLevel", SqlDbType.Int, rbtCriteria.DebugLevel);
                DataSet ds = ngadDB.ExecuteDataSet(@"dbo.USR_SEARCH_WITHIN_ALERT");
                return ds.Tables[0];
            }
        }

   
        public List<ResponseOption> GetAlertResponseOptions(int alertId)
        {
            var reponseOptionsList = new List<ResponseOption>();
            var am = new AlertManager();
            var alert = am.GetAlert(alertId);
            var alertSpecification = alert.AlertSpec;
            var resList = alertSpecification.Content.ResponseOptions;


            if (resList.Count > 0)
            {
                for (var i = 0; i < resList.Count; i++)
                {
                    reponseOptionsList.Add(resList[i]);
                }
            }
            else
            {
                reponseOptionsList.Add(new ResponseOption("Acknowledge"));
            }

            return reponseOptionsList;
        }


        public Reports.AlertTrackingResult GetAlertTrackingSummary(int alertId, Reports.ReportType type, Reports.Dimension dim)
        {
            using (var db = new AtHocDbContext())
            {
                // If using Code First we need to make sure the model is built before we open the connection 
                // This isn't required for models created with the EF Designer 
                db.Database.Initialize(force: false);

                AlertTrackingResult ret = new AlertTrackingResult();

                var rp = new EntityFrameworkRepository(db);

                 var values = rp.RunQuery<AlertTrackingResult>(
                        "select Status, ISNULL(Ended_On, End_Date) as RemainingTime from [dbo].[ALT_ALERT_TAB] WITH (NOLOCK) where alert_id = @alertid",
                        alertId).SingleOrDefault();
                 ret.Status = values.Status;
                 ret.RemainingTime = values.RemainingTime;
              

                // Create a SQL command to execute the sproc 
                var cmd = db.Database.Connection.CreateCommand();
                cmd.CommandText = "[dbo].[RPT_ALERT_TRACKING]";
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@alertId", alertId));
                cmd.Parameters.Add(new SqlParameter("@reportFor", type.ToString()));
                cmd.Parameters.Add(new SqlParameter("@byDim", dim.ToString()));

                db.Database.Connection.Open();

                var reader = cmd.ExecuteReader();

                var header = (((IObjectContextAdapter)db)
                    .ObjectContext
                    .Translate<AlertTrackingSummary>(reader)).ToList();
                ret.Summary = header;
                // Move to the 2nd result set and read 
                reader.NextResult();

                var responses = (((IObjectContextAdapter)db)
                    .ObjectContext
                    .Translate<AlertTrackingResponseSummary>(reader)).ToList();
                ret.Responses = responses;

                db.Database.Connection.Close();

                return ret;
            }
        }
    }
}