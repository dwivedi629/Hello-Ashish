﻿using System;

using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Database;
using AtHoc.Infrastructure.Sql;

using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Publishing.Spec;

namespace AtHoc.IWS.Business.Domain.Publishing.Impl
{
	public class DistributionListItemDbRepositiory : DbRepository<DistributionListItem, DistributionListItemSpec>, IDistributionListItemRepositiory
	{
		public DistributionListItemDbRepositiory(IUnitOfWork context) : base(context) {}

		protected override void TranslateSpec(DistributionListItemSpec spec, SqlBuilder builder, bool query)
		{
			builder.SelectAll<DistributionListItem>("l");
			builder.From(builder.Table<DistributionListItem>("l"));

			if (!spec.UserId.HasValue)
				throw new ApplicationException("User Id is not set for DistributionListItemSpec");

			if (!spec.ProviderId.HasValue)
				throw new ApplicationException("Provider Id is not set for DistributionListItemSpec");

			builder.Where(
                "EXISTS ( SELECT 1 FROM UPS_ENTITY_ACCESS_TAB a WITH (NOLOCK) WHERE (ACCESS_TYPE = 'MGT' AND ENTITY_TYPE = 'LST' AND (ENTITY_ID = -1 OR (ENTITY_ID = LIST_ID)) " +
                "AND a.USER_ID = @USER_ID AND a.PROVIDER_ID = @PROVIDER_ID) OR @isEntityAccessUnrestricted = 'N')",
				new SqlParameter("USER_ID", spec.UserId.Value),
				new SqlParameter("PROVIDER_ID", spec.ProviderId.Value),
                new SqlParameter("isEntityAccessUnrestricted", IsEntityAccessUnrestricted(spec.UserId.Value, spec.ProviderId.Value))
				);

			if (spec.Id.HasValue)
				builder.Where(builder.Condition(DistributionListItem.Meta.Id, ConditionOperator.Equals, spec.Id.Value));

			if (spec.ProviderId.HasValue)
				builder.Where(builder.Condition(DistributionListItem.Meta.ProviderId, ConditionOperator.Equals, spec.ProviderId.Value));

			if (spec.IsSystem.HasValue)
				builder.Where(builder.Condition(DistributionListItem.Meta.IsSystem, ConditionOperator.Equals, spec.IsSystem.Value ? "Y" : "N"));

			if (spec.CommonName.HasValue())
				builder.Where(builder.Condition(DistributionListItem.Meta.CommonName, ConditionOperator.Equals, spec.CommonName));
			else if (spec.ExcludeCommonNames.HasValue())
				builder.Where(builder.Condition(DistributionListItem.Meta.CommonName, ConditionOperator.NotIn, spec.ExcludeCommonNames));

			if (spec.ListIds.HasValue())
				builder.Where(builder.Condition(DistributionListItem.Meta.Id, ConditionOperator.In, spec.ListIds));

			if (spec.ExcludeIds.HasValue())
				builder.Where(builder.Condition(DistributionListItem.Meta.Id, ConditionOperator.NotIn, spec.ExcludeIds));

			if (spec.DistributionListTypes.HasValue())
				builder.Where(builder.Condition(DistributionListItem.Meta.ListType, ConditionOperator.In, spec.DistributionListTypes));

			if (spec.SearchString.HasValue())
				builder.Where(builder.Condition(DistributionListItem.Meta.Name, ConditionOperator.Contains, spec.SearchString));

			if (spec.ChildListId.HasValue)
			{
				builder.Where("EXISTS (SELECT 1 FROM PDL_LIST_TAB c WITH (NOLOCK) WHERE c.PARENT_LIST_ID = l.LIST_ID and c.LIST_ID =  @childId)", new SqlParameter("childId", spec.ChildListId));
			}
		}

        public string IsEntityAccessUnrestricted(int userId, int providerId)
        {
            const string sql = @"SELECT dbo.OPR_IS_DIST_LIST_RESTRICTABLE(@userId, @providerId)";
            var query = new DbQuery(Context, sql);
            query.AddParameter("userId", userId);
            query.AddParameter("providerId", providerId);
            return query.ExecuteScalar<string>();
        }
	}
}
