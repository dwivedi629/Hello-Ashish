﻿using System.Linq;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Database;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Sql;

using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.Publishing
{
	public class ActivityFeedDbRepository : DbRepository<ActivityFeed, ActivityFeedSpec>, IActivityFeedRepository
	{
		public ActivityFeedDbRepository(IUnitOfWork context) : base(context) { }

		protected override void TranslateSpec(ActivityFeedSpec spec, SqlBuilder builder, bool query)
		{
			builder.SelectAll<ActivityFeed>();
            builder.From("dbo.USR_ACTIVITY_FEED(@userId, @eventId, @eventType) a", 
                new SqlParameter("userId", spec.UserId.Value),
                new SqlParameter("eventId", spec.AlertId.HasValue ? spec.AlertId.Value : 0),
                new SqlParameter("eventType", EnumUtils<ActivityFeedType>.GetDescriptionByValue(spec.EventType.Value) ));
			//builder.From(builder.Table<ActivityFeed>());

			

			if (spec.EventTime.HasValue)
				builder.Where(builder.Condition(ActivityFeed.Meta.EventTime, ConditionOperator.Equals, spec.EventTime));
			else
			{
				if (spec.MaxEventTime.HasValue)
					builder.Where(builder.Condition(ActivityFeed.Meta.EventTime, ConditionOperator.LessThan, spec.MaxEventTime));

				if (spec.MinEventTime.HasValue)
					builder.Where(builder.Condition(ActivityFeed.Meta.EventTime, ConditionOperator.GreaterThan, spec.MinEventTime));
			}


		    if (spec.SearchString.HasValue())
		    {
		        builder.StartWhereGroup(GroupOperator.Or);
		       /* builder.Where(builder.Condition(ActivityFeed.Meta.EventType, ConditionOperator.Contains, spec.SearchString));
		        builder.Where(builder.Condition(ActivityFeed.Meta.DeliveryState, ConditionOperator.Contains, spec.SearchString));
		        builder.Where(builder.Condition(ActivityFeed.Meta.DeviceAddress, ConditionOperator.Contains, spec.SearchString));
		        builder.Where(builder.Condition(ActivityFeed.Meta.DeviceCommonName, ConditionOperator.Contains,
		            spec.SearchString));
		        //builder.Where(builder.Condition(ActivityFeed.Meta.EventTime, ConditionOperator.Contains, spec.SearchString));
		        builder.Where(builder.Condition(ActivityFeed.Meta.Publisher, ConditionOperator.Contains, spec.SearchString));
		        builder.Where(builder.Condition(ActivityFeed.Meta.RespondedText, ConditionOperator.Contains, spec.SearchString));
		        builder.Where(builder.Condition(ActivityFeed.Meta.Status, ConditionOperator.Contains, spec.SearchString)); */
		        builder.Where(builder.Condition(ActivityFeed.Meta.Title, ConditionOperator.Contains, spec.SearchString));
		        builder.Where(builder.Condition(ActivityFeed.Meta.Body, ConditionOperator.Contains, spec.SearchString));
		        builder.EndWhereGroup();
		    }

		    if (spec.IsEnded.HasValue)
		    {
		        builder.Where(spec.IsEnded.Value == false ? " Status='Live'" : "Status='Ended'");
		    }

		    if (spec.PendingReply.HasValue)
		    {
		        if (spec.PendingReply.Value)
		        {
		            builder.Where("(ISNULL(Delivery_State,'')!='Responded' AND Status='Live')");
		        }
		        else
		        {
                    builder.Where("(ISNULL(Delivery_State,'')='Responded')");
		        }

		    }

		    if (spec.EventCategoryId.HasValue())
		    {
                builder.Where(builder.Condition(ActivityFeed.Meta.EventCategoryId,ConditionOperator.In,spec.EventCategoryId));
		    }

		    if (spec.Severity.HasValue())
		    {
		        builder.Where(builder.Condition(ActivityFeed.Meta.Priority, ConditionOperator.In, spec.Severity));
		    }

		    if (spec.SourceName.HasValue())
		    {
		        builder.Where(builder.Condition(ActivityFeed.Meta.Publisher, ConditionOperator.Contains, spec.SourceName));
		    }

		   
		}
	}
}
