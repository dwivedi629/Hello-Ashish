﻿using System;
using System.Linq;
using System.Collections.Generic;

using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Data;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Data;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;
using AtHoc.IWS.Business.Domain.Devices.Impl;
using AtHoc.IWS.Business.Domain.Devices.Spec;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Publishing.Impl;
using AtHoc.IWS.Business.Domain.Publishing.Spec;
using AtHoc.IWS.Business.Domain.Users.Impl;
using AtHoc.IWS.Business.Domain.Users.Impl.Search;
using AtHoc.IWS.Business.Domain.Users.Search;

namespace AtHoc.IWS.Business.Domain.Publishing
{
	internal static class DistributionListManager
	{

        internal static IEnumerable<UserSearchResultItem> GetDistributionListUsers(CustomAttributeLookup customAttributeLookup, DistributionListSpec spec,string locale, bool includeNestedListsUsers = false)
		{
			using (var context = AtHocDbContextFactory.CreateFactory().CreateNgaddataContext())
			{
                var srchArgsV2 = CreateUserSearchArgsV2ByDistributionList(context, spec, locale);

			    var userFacade = new UserFacade();

                var distributionList = context.DistributionListRepository.SingleOrDefaultBySpec(spec);
                switch (distributionList.ListType)
                {
                    case ListItemType.Dynamic:
                    case ListItemType.Static:
                        // LISTS TO INCLUDE (Dynamic Lists, Static Lists, Tree)
                        //While retreving the distribution list members, it should not consider the nested distributionlist
                        srchArgsV2.TargetCriteria = (includeNestedListsUsers) ? UserSearchHelper.GetListCriteria(RuntimeContext.ProviderId, new[] { distributionList.Id }) : UserSearchHelper.GetListCriteria(RuntimeContext.ProviderId, new[] { distributionList.Id }, null, null, false);
                        break;
                    default:
                        throw new ApplicationException("Invalid distribution list type '{0}' to get user count.".FormatWith(distributionList.ListType));
                }

                var statusAttributeId = userFacade.GetStatusAttributeId();
                var statusValueIds = userFacade.GetStatusValueIds(new[] { "VLD", "DSB" });
                var statusCriteria = UserSearchHelper.GetUserStatusCriteria(statusAttributeId, statusValueIds);

                srchArgsV2.TargetCriteria = srchArgsV2.TargetCriteria & statusCriteria;

                var resultV2 = userFacade.SearchUsersByContext(srchArgsV2);
                return resultV2.Users;
			}
		}

        internal static ContextSearchResult GetDistributionListUserSearchResult(CustomAttributeLookup customAttributeLookup, DistributionListSpec spec, string locale, bool allUsers = false)
		{
			using (var context = AtHocDbContextFactory.CreateFactory().CreateNgaddataContext())
			{
                if (!spec.OperatorId.HasValue) throw new ApplicationException("Can`t create spec for DL user search. The operator id is not set.");

                if (!spec.ProviderId.HasValue) throw new ApplicationException("Can`t create spec for DL user search. The provider id is not set.");

                var srchArgsV2 = CreateUserSearchArgsV2ByDistributionList(context, spec, locale);
			    srchArgsV2.Options.GetCountsOnly = true;

                var userFacade = new UserFacade();

                var distributionList = context.DistributionListRepository.SingleOrDefaultBySpec(spec);
                switch (distributionList.ListType)
                {
                    case ListItemType.Dynamic:
                    case ListItemType.Static:
                        // LISTS TO INCLUDE (Dynamic Lists, Static Lists, Tree)
                        srchArgsV2.TargetCriteria = !allUsers ? UserSearchHelper.GetListCriteria(RuntimeContext.ProviderId, new[] { distributionList.Id }, null, null, false) : UserSearchHelper.GetListCriteria(RuntimeContext.ProviderId, new[] { distributionList.Id }, null, null);
                        break;
                    default:
                        throw new ApplicationException("Invalid distribution list type '{0}' to get user count.".FormatWith(distributionList.ListType));
                }

                var statusAttributeId = userFacade.GetStatusAttributeId();
                var statusValueIds = userFacade.GetStatusValueIds(new[] { "VLD", "DSB" });
                var statusCriteria = UserSearchHelper.GetUserStatusCriteria(statusAttributeId, statusValueIds);

                srchArgsV2.TargetCriteria = srchArgsV2.TargetCriteria & statusCriteria;

                return userFacade.SearchUsersByContext(srchArgsV2);
            }
		}
        
        private static UserSearchArgs CreateUserSearchArgsV2ByDistributionList(INgaddataContext context,
	        DistributionListSpec spec, string locale)
	    {
            var srchArgsV2 = new UserSearchArgs(false, true, false)
            {
                AttributeNames = new List<string>
	            {
	                AttributeCommonNames.UserName,
	                AttributeCommonNames.FirstName,
	                AttributeCommonNames.DisplayName,
	                AttributeCommonNames.LastName
	            },
                DeviceNames = null,
                ProviderId = RuntimeContext.ProviderId,
                ChannelId = 0,
                ProviderCriteria = UserSearchHelper.GetProviderCriteria(RuntimeContext.ProviderId),
                OperatorCriteria = UserSearchHelper.GetOperatorUserBaseCriteria(RuntimeContext.OperatorId, RuntimeContext.ProviderId),
                Paging = { PageNo = 1, IsAsc = true, SortColumn = "", UsersPerPage = int.MaxValue }
            };

            return srchArgsV2;
	    }

		internal static DistributionListDependencyResult GetDistributionListDependencyResult(DistributionListDependencySpec spec)
		{
			using (var context = AtHocDbContextFactory.CreateFactory().CreateNgaddataContext())
			{
                var result = new DistributionListDependencyResult
                {
                    Dependencies = context.DistributionListDependencyRepositiory.FindBySpec(spec)
                };

			    var dependentIds = result.Dependencies.Select(d => d.ListId).Distinct();
                result.DependentListCount = dependentIds.Count();
                result.IndependentListCount = spec.ListIds.Count() - result.DependentListCount;

                return result;
			}
		}

#warning Refactor below....
        internal static IEnumerable<int> GetStaticListChildIds(DistributionListSpec spec, bool includeAllLevel = false)
		{
			#region sql
			const string sql = @"
WITH tree (
	CHILD_LIST_ID
	,PARENT_LIST_ID
	,Hierarchy
	)
AS (
	SELECT
		CHILD_LIST_ID
		,PARENT_LIST_ID
		,cast(PARENT_LIST_ID as varchar(max)) as Name
	FROM PDL_LIST_FOLDER_TAB a with (nolock)
	where
		PARENT_LIST_ID = @listId	
	
	UNION ALL
	
	SELECT
		a.CHILD_LIST_ID
		,a.PARENT_LIST_ID
		,b.Hierarchy + ',' +  cast(a.PARENT_LIST_ID as varchar(50)) as Hierarchy
	FROM PDL_LIST_FOLDER_TAB a with (nolock)
	INNER JOIN tree b
		ON a.PARENT_LIST_ID = b.CHILD_LIST_ID
	)
SELECT 
	CHILD_LIST_ID
	,Hierarchy + ',' +  cast(CHILD_LIST_ID as varchar(50)) as Hierarchy
FROM
	tree";
			#endregion sql

            #region includeAllLevelSql
            const string includeAllLevelSql = @"
declare @list nvarchar(max)
WITH tree (
	CHILD_LIST_ID
	,PARENT_LIST_ID
	)
AS (
	SELECT
		CHILD_LIST_ID
		,PARENT_LIST_ID
	FROM PDL_LIST_FOLDER_TAB a with (nolock)
	where
		PARENT_LIST_ID = @listId
	
	UNION ALL
	
	SELECT
		a.CHILD_LIST_ID
		,a.PARENT_LIST_ID
	FROM PDL_LIST_FOLDER_TAB a with (nolock)
	INNER JOIN tree b
		ON a.PARENT_LIST_ID = b. CHILD_LIST_ID
		
	)

SELECT @list = isnull(@list + ',', '')  + cast(child_LIST_ID as nvarchar(100))
FROM
	tree

select (CASE WHEN @list IS NULL THEN '' ELSE @list END) as Hierarchy";
            #endregion

            if (includeAllLevel) return GetStaticListDependentIds(includeAllLevelSql, spec);
            return GetStaticListDependentIds(sql, spec);
		}

		internal static IEnumerable<int> GetStaticListParentIds(DistributionListSpec spec, bool includeAllLevel = false)
		{
			#region sql
			const string sql = @"
WITH tree (
	CHILD_LIST_ID
	,PARENT_LIST_ID
	,Hierarchy
	)
AS (
	SELECT
		CHILD_LIST_ID
		,PARENT_LIST_ID
		,cast(PARENT_LIST_ID as varchar(max)) as Name
	FROM PDL_LIST_FOLDER_TAB a WITH (NOLOCK)
	where
		CHILD_LIST_ID = @listId
	
	UNION ALL
	
	SELECT
		a.CHILD_LIST_ID
		,a.PARENT_LIST_ID
		,b.Hierarchy + ',' +  cast(a.PARENT_LIST_ID as varchar(50)) as Hierarchy
	FROM PDL_LIST_FOLDER_TAB a WITH (NOLOCK)
	INNER JOIN tree b
		ON a.PARENT_LIST_ID = b.CHILD_LIST_ID
	)
SELECT 
	CHILD_LIST_ID
	,Hierarchy + ',' +  cast(CHILD_LIST_ID as varchar(50)) as Hierarchy
FROM
	tree";
			#endregion sql

            #region includeAllLevelSql
            const string includeAllLevelSql = @"
declare @list nvarchar(max)
WITH tree (
	CHILD_LIST_ID
	,PARENT_LIST_ID
	)
AS (
	SELECT
		CHILD_LIST_ID
		,PARENT_LIST_ID
	FROM PDL_LIST_FOLDER_TAB a WITH (NOLOCK)
	where
		CHILD_LIST_ID = @listId
	
	UNION ALL
	
	SELECT
		a.CHILD_LIST_ID
		,a.PARENT_LIST_ID
	FROM PDL_LIST_FOLDER_TAB a WITH (NOLOCK)
	INNER JOIN tree b
		ON a.CHILD_LIST_ID = b.PARENT_LIST_ID
		
	)

SELECT @list = isnull(@list + ',', '')  + cast(PARENT_LIST_ID as nvarchar(100))
FROM
	tree

select (CASE WHEN @list IS NULL THEN '' ELSE @list END) as Hierarchy";
            #endregion

		    if (includeAllLevel) return GetStaticListDependentIds(includeAllLevelSql, spec);
		    return GetStaticListDependentIds(sql, spec);
		}

		private static IEnumerable<int> GetStaticListDependentIds(string sql, DistributionListSpec spec)
		{
			using (var context = AtHocDbContextFactory.CreateFactory().CreateNgaddataContext())
			{
				var query = new DbQuery(context, sql);
				query.AddParameter("listId", spec.Id);
				var result = new List<int>();
				foreach (var value in query.SelectColumnValues<string>("Hierarchy").ToArray())
				{
					result.AddRange(value.Split<int>());
				}
				return result.Distinct().Where(v => spec.Id != null && v != spec.Id.Value);
			}
		}

		internal static IEnumerable<int> GetStaticListFirstLevelChildIds(DistributionListSpec spec)
		{
			using (var context = AtHocDbContextFactory.CreateFactory().CreateNgaddataContext())
			{
                var query = new DbQuery(context, "select CHILD_LIST_ID from PDL_LIST_FOLDER_TAB with (nolock) where PARENT_LIST_ID = @parentList");
				query.AddParameter("parentList", spec.Id);
				return query.SelectColumnValues<int>("CHILD_LIST_ID");
			}
		}

		internal static string GetDistributionItemPath(DistributionListSpec spec)
		{
			using (var context = AtHocDbContextFactory.CreateFactory().CreateNgaddataContext())
			{
			    if (spec.Id == null) throw new AppDomainUnloadedException("No valid distribution item Id was provided.");
			    var hierarchy = context.HierarchyRepository.FindById(spec.Id.Value);

			    if (hierarchy != null) return String.Concat("/", hierarchy.Name);

			    var list = context.DistributionListRepository.FindById(spec.Id.Value);

			    if (list != null) return list.Lineage;
			    throw new AppDomainUnloadedException("No valid distribution item Id was provided.");
			}
		}
	}
}
