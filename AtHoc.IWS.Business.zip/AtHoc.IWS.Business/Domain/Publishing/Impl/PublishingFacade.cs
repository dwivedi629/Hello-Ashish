﻿using System.Linq;
using System.Collections.Generic;

using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Domain;

using AtHoc.IWS.Business.Data;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Publishing.Impl;
using AtHoc.IWS.Business.Domain.Publishing.Spec;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Business.Service;
using AtHoc.Publishing.Service; 

namespace AtHoc.IWS.Business.Domain.Publishing
{
	public class PublishingFacade : FacadeBase<IAtHocContextFactory>, IPublishingFacade
	{
		public PublishingFacade(IAtHocContextFactory contextFactory) : base(contextFactory) {}

		[Security(SystemObject.DistributionLists, ActionType.Modify)]
		public IServiceResult<bool> DeleteDistributionList(DistributionListSpec spec, bool isTemporaryList = false)
		{
		    spec.IsTemporary = isTemporaryList;
			return new DistributionListDelete().Process(spec);
			//return FacadeService<bool, DistributionListSpec>.CallService(spec, new DistributionListDelete());
		}

		public IEnumerable<DistributionList> GetDistributionLists(DistributionListSpec spec)
		{
			using (var context = ContextFactory.CreateNgaddataContext())
			{
				return context.DistributionListRepository.FindBySpec(spec);
			}
		}

		public int GetDistributionListsCount(DistributionListSpec spec)
		{
			using (var context = ContextFactory.CreateNgaddataContext())
			{
				return context.DistributionListRepository.CountBySpec(spec);
			}
		}

		public DistributionList GetDistributionList(DistributionListSpec spec)
		{
			return GetDistributionLists(spec).SingleOrDefault();
		}

        public ContextSearchResult GetDistributionListUserSearchResult(CustomAttributeLookup customAttributeLookup, DistributionListSpec spec, string locale, bool allUsers = false)
		{
			return DistributionListManager.GetDistributionListUserSearchResult(customAttributeLookup, spec, locale , allUsers);
		}

        public IEnumerable<UserSearchResultItem> GetDistributionListUsers(CustomAttributeLookup customAttributeLookup, DistributionListSpec spec, string locale, bool includeNestedListsUsers = false)
		{
            return DistributionListManager.GetDistributionListUsers(customAttributeLookup, spec,locale, includeNestedListsUsers);
		}

        public IEnumerable<int> GetDistributionListUsersIds(CustomAttributeLookup customAttributeLookup, DistributionListSpec spec, string locale, bool includeNestedListsUsers = false)
		{
            return GetDistributionListUsers(customAttributeLookup, spec,locale, includeNestedListsUsers).Select(u => u.Id);
		}

		public IEnumerable<DistributionListItem> GetDistributionListItems(DistributionListItemSpec spec)
		{
			using (var context = ContextFactory.CreateNgaddataContext())
			{
				return context.DistributionListItemRepository.FindBySpec(spec);
			}
		}

		public PagingInfo<DistributionListItem> GetDistributionListItemsPage(DistributionListItemSpec spec)
		{
			using (var context = ContextFactory.CreateNgaddataContext())
			{
				return context.DistributionListItemRepository.GetPagingInfo(spec);
			}
		}

		public IEnumerable<int> GetDistributionListIds(DistributionListItemSpec spec)
		{
			using (var context = ContextFactory.CreateNgaddataContext())
			{
				return context.DistributionListItemRepository.FindBySpec(spec).Select(i => i.Id);
			}
		}

		public IEnumerable<DistributionListDependency> GetDistributionListDependencies(DistributionListDependencySpec spec)
		{
			using (var context = ContextFactory.CreateNgaddataContext())
			{
				return context.DistributionListDependencyRepositiory.FindBySpec(spec);
			}
		}

		public DistributionListDependencyResult GetDistributionListDependencyResult(DistributionListDependencySpec spec)
		{
			return DistributionListManager.GetDistributionListDependencyResult(spec);
		}

		public bool CheckDistribuionListUnique(DistributionListSpec spec)
		{
			using (var context = ContextFactory.CreateNgaddataContext())
			{
				return context.DistributionListRepository.CountBySpec(spec) == 0;
			}
		}
		
		[Security(SystemObject.DistributionLists, ActionType.Modify)]
		public IServiceResult<bool> SaveDistributionList(DistributionListSaveSpec spec)
		{
		    var auditList = !string.IsNullOrEmpty(spec.List.Name) && !spec.List.Name.ToUpper().Contains("TEMP_STATIC");		    
			return FacadeService<bool, DistributionListSaveSpec>.CallService(spec, new DistributionListSave(), auditList);
		}

		public IEnumerable<int> GetStaticListChildIds(DistributionListSpec spec, bool includeAllLevel = false)
		{
			return DistributionListManager.GetStaticListChildIds(spec, includeAllLevel);
		}

		public IEnumerable<int> GetStaticListFirstLevelChildIds(DistributionListSpec spec)
		{
			return DistributionListManager.GetStaticListFirstLevelChildIds(spec);
		}

        public IEnumerable<int> GetStaticListParentIds(DistributionListSpec spec, bool includeAllLevel = false)
		{
			return DistributionListManager.GetStaticListParentIds(spec, includeAllLevel);
		}

		public string GetDistributionItemPath(DistributionListSpec spec)
		{
			return DistributionListManager.GetDistributionItemPath(spec);
		}

		public IEnumerable<DistributionList> GetChildrenNodes(DistributionListSpec spec)
		{
			using (var context = ContextFactory.CreateNgaddataContext())
			{
				return context.DistributionListRepository.GetChildrenNodes(spec);
			}
		}
         
	    public IEnumerable<int> GetNestedStaticListIds(int listId)
	    {
	        using (var context = ContextFactory.CreateNgaddataContext())
	        {
	            return context.DistributionListRepository.GetNestedStaticListIds(listId);
	        }
	        
	    } 
    }
}