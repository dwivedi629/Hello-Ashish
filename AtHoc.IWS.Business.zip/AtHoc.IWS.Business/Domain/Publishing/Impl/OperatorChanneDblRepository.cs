﻿using System;
using System.Linq;
using System.Collections.Generic;

using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Database;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Sql;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Publishing.Impl;

namespace AtHoc.IWS.Business.Domain.Publishing
{
#warning Refactor below...
    public class OperatorChannelDbRepository : IOperatorChannelRepository
    {
        protected DbContext Context { get; set; }

        public OperatorChannelDbRepository(IUnitOfWork context)
        {
            Context = context as DbContext;
        }

        /// <summary>
        /// Get channels list. In current implementation all channel roles has same channel list, so getting distinction of whatever existing.
        /// </summary>
        /// <param name="spec"></param>
        /// <returns></returns>
        public IEnumerable<OperatorChannel> FindBySpec(OperatorChannelSpec spec)
        {
            VerifySpec(spec);
            const string sql = @"exec OPR_GET_ALERT_FOLDER_DEFINITION";
            var query = new DbQuery(Context, sql);
            query.AddParameter("v_userid", spec.OperatorId.Value);
            query.AddParameter("v_provider_id", spec.ProviderId.Value);
            var alertFolderList = query.SelectColumnValues<int>("OBJECT_ID").Distinct();
            return alertFolderList.Select(id => new OperatorChannel { ChannelId = id, UserId = spec.OperatorId.Value });
        }

        public Messages DeleteBySpec(OperatorChannelSpec spec)
        {
            var messages = new Messages();
            try
            {
                #region sql
                const string sql =
                    @"delete from ups_content_filter_tab
					where
						content_filter_id in (
							select
								content_filter_id
							from
								ups_user_role_tab WITH (nolock)
							where
								role_id in ({0})
								and user_id = @userId
								and provider_filter = @providerId
						)";
                #endregion sql

                var query = new DbQuery(Context, sql.FormatWith(OperatorRoles.ChannelRoles.Join()));
                query.AddParameter("userId", spec.OperatorId.Value);
                query.AddParameter("providerId", spec.ProviderId.Value);
                query.Execute();
            }
            catch (Exception ex)
            {
                messages.CreateErrorMessage(ex);
            }
            return messages;
        }

        /// <summary>
        /// In current implementation all channel roles has same channel list.
        /// </summary>
        /// <param name="spec"></param>
        /// <returns></returns>
        public Messages UpdateBySpec(OperatorChannelSpec spec)
        {
            var messages = new Messages();
            try
            {
                VerifySpec(spec);
                var channelRoles = spec.Roles.Where(r => OperatorRoles.ChannelRoles.Contains(r.RoleId));
                foreach (var role in channelRoles)
                {
                    var newContentFilterId = new SequenceHelper(Context).GetSequence("MSFILTER");
                    SetContentFilterToRole(spec, newContentFilterId, role.RoleId);
                    SetContentFilterToChannels(spec.Channels, newContentFilterId);
                }
            }
            catch (Exception ex)
            {
                messages.CreateErrorMessage(ex);
            }
            return messages;
        }

        public bool IsAlertFoldersUnrestricted(int userId, int providerId)
        {
            const string sql = @"SELECT dbo.OPR_IS_ALERT_FOLDER_RESTRICTABLE(@v_userid, @v_provider_id)";
            var query = new DbQuery(Context, sql);
            query.AddParameter("v_userid", userId);
            query.AddParameter("v_provider_id", providerId);
            var isAlertFoldersUnrestricted = (query.ExecuteScalar<Char>() == 'N');
            return isAlertFoldersUnrestricted;
        }

        private void SetContentFilterToChannels(IEnumerable<OperatorChannel> channels, int newContentFilterId)
        {
            #region sql
            const string sql =
                @"insert into ups_content_filter_tab
					(content_filter_id, object_id, object_type)
				values
					(@contentFilterId, @channelId, 'SRV')";
            #endregion sql

            foreach (var channel in channels)
            {
                var query = new DbQuery(Context, sql);
                query.AddParameter("contentFilterId", newContentFilterId);
                query.AddParameter("channelId", channel.ChannelId);
                query.Execute();
            }
        }

        private void SetContentFilterToRole(OperatorChannelSpec spec, int newContentFilterId, int roleId)
        {
            #region sql
            const string sql =
                @"update ups_user_role_tab
					set content_filter_id = @contentFilterId
				where
					user_id = @userId
					and role_id = @roleId
					and provider_filter = @providerId";
            #endregion sql

            var query = new DbQuery(Context, sql);
            query.AddParameter("userId", spec.OperatorId.Value);
            query.AddParameter("contentFilterId", newContentFilterId);
            query.AddParameter("providerId", spec.ProviderId.Value);
            query.AddParameter("roleId", roleId);
            query.Execute();
        }

        private static void VerifySpec(OperatorChannelSpec spec)
        {
            if (!spec.OperatorId.HasValue)
                throw new ApplicationException("Operator id is not set");

            if (!spec.ProviderId.HasValue)
                throw new ApplicationException("Provider id is not set");
        }
    }
}
