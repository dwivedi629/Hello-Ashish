using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using AtHoc.Data;
using AtHoc.Delivery.Utilities;
using AtHoc.Diagnostics;
using AtHoc.Infrastructure.Ioc;
using AtHoc.IWS.Business.Common.Interface;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Events;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Targeting.Impl;
using AtHoc.IWS.Business.Domain.Targeting.Spec;
using AtHoc.IWS.Business.Domain.Users.Impl;
using AtHoc.IWS.Business.Domain.Users.Impl.Search;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.SSA.Business;
using AtHoc.IWS.SSA.Business.Facades;
using AtHoc.IWS.SSA.Dictionaries;
using AtHoc.Publishing;
using AtHoc.Systems;
using AtHoc.IWS.Business.Domain.Users;


namespace AtHoc.IWS.Business.Domain.Publishing.Impl
{
    public class AlertAdapter : IAlertAdapter
    {
        public UserSearchArgs GetUserSearchArgs(IList<ISearchCriteria> searchCriteria, int providerId, string providerLocale, int operatorId, bool includeSubVps = true, bool includeDisableDeleteUsers = false)
        {
            var srchArgsV2 = new UserSearchArgs(false, false, false)
            {
                ProviderId = providerId,
                ProviderCriteria = UserSearchHelper.GetProviderCriteria(providerId, includeSubVps),
                AttributeNames = new List<string>(),
                OperatorCriteria = UserSearchHelper.GetOperatorUserBaseCriteria(operatorId, providerId),
                TargetAllUserBase = searchCriteria.Count < 1 || searchCriteria.FirstOrDefault(c => c.NodeType.Equals(SearchNodeType.AllUserBase)) != null,
            };

            srchArgsV2.TargetCriteria = UserSearchHelper.GetOperatorUserBaseCriteria(operatorId, providerId);

            var userFacade = new UserFacade();
            var statusValueIds = userFacade.GetStatusValueIds(includeDisableDeleteUsers ? new[] { "VLD", "DEL", "DSB" } : new[] { "VLD" });
            var statusAttributeId = userFacade.GetStatusAttributeId();


            var statusCriteria = UserSearchHelper.GetUserStatusCriteria(statusAttributeId, statusValueIds);

            ExpressionElement includeGeoCriteria = null;

            // target by area
            if (searchCriteria.Any(c => c.NodeType.Equals(SearchNodeType.Geo)))
            {
                var geoCriteria = searchCriteria.FirstOrDefault(c => c.NodeType.Equals(SearchNodeType.Geo));
                if (geoCriteria != null)
                {
                    var locationWkt = GetLocationAsWkt(geoCriteria, providerId);
                    if (!string.IsNullOrEmpty(locationWkt))
                    {
                        var geoCriteriaList = (from geoLocation in locationWkt.Split('|')
                                               where !string.IsNullOrEmpty(geoLocation)
                                               select new GeoCriteria(0, CriteriaOperator.IsInsideArea, geoLocation)).ToList();
                        includeGeoCriteria = UserSearchHelper.GetIncludeGeographyCriteria(geoCriteriaList, providerId);
                    }
                }
            }


            // target orgs - filter out any disconnected orgs

            // distribution lists
            var includeLists = searchCriteria.Where(
                c => c.NodeType.Equals(SearchNodeType.StaticList) || c.NodeType.Equals(SearchNodeType.DynamicList))
                .Where(c => c.IsBlocked.HasValue && !c.IsBlocked.Value)
                .Select(c => c.SearchCriteriaID).ToList();

            var excludeLists = searchCriteria.Where(
                c => c.NodeType.Equals(SearchNodeType.StaticList) || c.NodeType.Equals(SearchNodeType.DynamicList))
                .Where(c => c.IsBlocked.HasValue && c.IsBlocked.Value)
                .Select(c => c.SearchCriteriaID).ToList();

            // End Users (IUT), Connect Endpoints, Mass Device Endpoints
            var individualUserIdCriteria = UserSearchHelper.GetIndividualUserIdCriteria(new List<int>(searchCriteria.Where(
                c => c.NodeType.Equals(SearchNodeType.User))
                .Where(c => c.IsBlocked.HasValue && !c.IsBlocked.Value)
                .Select(c => c.SearchCriteriaID)));

            srchArgsV2.TargetUsers = new List<int>(searchCriteria.Where(
                c => c.NodeType.Equals(SearchNodeType.User))
                .Where(c => c.IsBlocked.HasValue && !c.IsBlocked.Value)
                .Select(c => c.SearchCriteriaID));

            srchArgsV2.BlockUsers = new List<int>(searchCriteria.Where(
                c => c.NodeType.Equals(SearchNodeType.User))
                .Where(c => c.IsBlocked.HasValue && c.IsBlocked.Value)
                .Select(c => c.SearchCriteriaID));


            // group by attribute
            var includeGroupsList = new List<GenericCriteria>();
            ExpressionElement includeGroupsCriteria = null;
            foreach (var attr in searchCriteria.Where(c => c.NodeType.Equals(SearchNodeType.Attribute) && c.IsBlocked.HasValue && !c.IsBlocked.Value))
            {
                var attrCriteria = new AttributeCriteria(attr.SearchCriteriaID, CriteriaOperator.IsNotEmpty, 0);
                includeGroupsList.Add(attrCriteria);
                includeGroupsCriteria = includeGroupsCriteria | UserSearchHelper.GetGroupsCriteria(new[] { new List<GenericCriteria> { attrCriteria } });
            }
            var excludeGroupsList = new List<GenericCriteria>();
            foreach (var attr in searchCriteria.Where(c => c.NodeType.Equals(SearchNodeType.Attribute) && c.IsBlocked.HasValue && c.IsBlocked.Value))
            {
                excludeGroupsList.Add(new AttributeCriteria(attr.SearchCriteriaID, CriteriaOperator.IsNotEmpty, 0));
            }

            // group by attribute values
            var includeGroups = GetAttributeGroups(searchCriteria.Where(c => c.NodeType.Equals(SearchNodeType.AttributeValue) && c.IsBlocked.HasValue && !c.IsBlocked.Value).ToList());
            foreach (var group in includeGroups)
            {
                var attrCriteria = new AttributeCriteria(group.Key, CriteriaOperator.Equals, string.Join(",", group.Value));
                includeGroupsList.Add(attrCriteria);
                includeGroupsCriteria = includeGroupsCriteria | UserSearchHelper.GetGroupsCriteria(new[] { new List<GenericCriteria> { attrCriteria } });
            }
            var excludeGroups = GetAttributeGroups(searchCriteria.Where(c => c.NodeType.Equals(SearchNodeType.AttributeValue) && c.IsBlocked.HasValue && c.IsBlocked.Value).ToList());
            foreach (var group in excludeGroups)
            {
                excludeGroupsList.Add(new AttributeCriteria(group.Key, CriteriaOperator.Equals, String.Join(",", group.Value)));
            }

            var blockedGroupsCriteria = UserSearchHelper.GetExcludeGroupsCriteria(excludeGroupsList);

            var childHierarchies = (searchCriteria.Where(
                c => c.NodeType.Equals(SearchNodeType.ListHrchy) || c.NodeType.Equals(SearchNodeType.OrgHrchy))
                .Where(c => c.IsBlocked.HasValue && !c.IsBlocked.Value && !c.SearchValue.Equals("/"))).Select(c => c.SearchCriteriaID).ToList();

            var rootNodes = (searchCriteria.Where(
                c => c.NodeType.Equals(SearchNodeType.ListHrchy) || c.NodeType.Equals(SearchNodeType.OrgHrchy))
                .Where(c => c.IsBlocked.HasValue && !c.IsBlocked.Value && c.SearchValue.Equals("/"))).Select(c => c.SearchCriteriaID);

            var childHierarchiesBlocked = (searchCriteria.Where(
               c => c.NodeType.Equals(SearchNodeType.ListHrchy) || c.NodeType.Equals(SearchNodeType.OrgHrchy))
               .Where(c => c.IsBlocked.HasValue && c.IsBlocked.Value && !c.SearchValue.Equals("/"))).Select(c => c.SearchCriteriaID).ToList();

            var rootNodesBlocked = (searchCriteria.Where(
                c => c.NodeType.Equals(SearchNodeType.ListHrchy) || c.NodeType.Equals(SearchNodeType.OrgHrchy))
                .Where(c => c.IsBlocked.HasValue && c.IsBlocked.Value && c.SearchValue.Equals("/"))).Select(c => c.SearchCriteriaID);


            // org and distribution list hierarchies
            var includeHierarchiesCriteria = UserSearchHelper.GetHierarchyCriteria(providerId, providerLocale, rootNodes, providerId, operatorId, AccessType.Target);

            includeLists.AddRange(childHierarchies);
            var includeListsCriteria = UserSearchHelper.GetListCriteria(providerId, includeLists, providerId, operatorId, accessType: AccessType.Target);

            var blockHierarchiesCriteria = UserSearchHelper.GetHierarchyCriteria(providerId, providerLocale, rootNodesBlocked, providerId, operatorId, AccessType.Target);

            excludeLists.AddRange(childHierarchiesBlocked);
            var blockedListsCriteria = UserSearchHelper.GetListCriteria(providerId, excludeLists, providerId, operatorId, accessType: AccessType.Target);


            // target by advanced query
            ExpressionElement customCriteria = null;
            var advQueryCriteria = GetAdvancedQueryCriteria(searchCriteria.Where(c => c.NodeType.Equals(SearchNodeType.Query)).ToList());

            var ebtqueryCriteria = GetEventBasedCriteria(searchCriteria.Where(c => c.NodeType.Equals(SearchNodeType.EbtQuery)).ToList());
            var ebtForBlock = GetEbtForBlocked(searchCriteria.Where(c => c.NodeType.Equals(SearchNodeType.EbtQuery)).ToList());

            if (advQueryCriteria != null && advQueryCriteria.Count > 0)
            {
                customCriteria = UserSearchHelper.GetCustomCriteria(new[] { advQueryCriteria });
            }

            if (srchArgsV2.TargetAllUserBase == false && includeListsCriteria == null && includeHierarchiesCriteria == null && includeGroupsCriteria == null && customCriteria == null && includeGeoCriteria == null && individualUserIdCriteria == null && ebtqueryCriteria == null) return null;

            //if PA Event - Always precedent EBT
            if (ebtqueryCriteria != null)
            {
                srchArgsV2.TargetCriteria = ebtqueryCriteria & statusCriteria;
            }
            else if (srchArgsV2.TargetAllUserBase)
            {
                srchArgsV2.TargetCriteria = statusCriteria;
            }
            else
            {
                if (individualUserIdCriteria != null && (includeListsCriteria == null && includeHierarchiesCriteria == null && includeGroupsCriteria == null && customCriteria == null && includeGeoCriteria == null))
                {
                    srchArgsV2.TargetCriteria = individualUserIdCriteria & statusCriteria;
                }
                else
                {
                    srchArgsV2.TargetCriteria = (includeListsCriteria | includeHierarchiesCriteria | includeGroupsCriteria | customCriteria | includeGeoCriteria | ebtqueryCriteria) & statusCriteria;
                }
            }

            
            //Block criteria
            if (ebtForBlock != null)
            {
                srchArgsV2.BlockCriteria = ebtForBlock;
            }
            else
            {
                srchArgsV2.BlockCriteria = blockedListsCriteria | blockHierarchiesCriteria | blockedGroupsCriteria;
            }


            return srchArgsV2;
        }

        private static EventBasedCriteria GetEventBasedCriteria(List<ISearchCriteria> targetingCriteria)
        {
            EventBasedCriteria ebtCriteria = null;

            if (targetingCriteria == null ||
                targetingCriteria.Where(t => t.NodeType.Equals(SearchNodeType.EbtQuery)).ToList().Count < 1)
                return null;

            var qryCriteria = targetingCriteria.FirstOrDefault(t => t.NodeType.Equals(SearchNodeType.EbtQuery) && (t.IsBlocked.GetValueOrDefault() == false));
            if (qryCriteria != null)
            {
                if (qryCriteria.SearchQueries != null)
                {
                    var eventQuery = qryCriteria.SearchQueries.FirstOrDefault();
                    var eventCriteriaOperator = (int)eventQuery.AccountabilityOperator;
                    ebtCriteria = new EventBasedCriteria();
                    ebtCriteria.Id = (int)eventQuery.QueryEntityID;
                    ebtCriteria.EventIds = eventQuery.EventIds;
                    ebtCriteria.EventCriteriaOperator = (EventCriteriaOperator)Enum.Parse(typeof(EventCriteriaOperator), eventCriteriaOperator.ToString());

                    if (eventQuery.SearchValueCollections != null && eventQuery.SearchValueCollections.Any())
                    {
                        var responseList = eventQuery.SearchValueCollections.Select(v => v.SearchValue);
                        ebtCriteria.Value = responseList;
                    }
                }
            }
            return ebtCriteria;
        }
        private static EventBasedCriteria GetEbtForBlocked(List<ISearchCriteria> targetingCriteria)
        {
            EventBasedCriteria ebtCriteria = null;

            if (targetingCriteria == null ||
                targetingCriteria.Where(t => t.NodeType.Equals(SearchNodeType.EbtQuery)).ToList().Count < 1)
                return null;

            var qryCriteria = targetingCriteria.FirstOrDefault(t => t.NodeType.Equals(SearchNodeType.EbtQuery) && (t.IsBlocked.GetValueOrDefault()));
            if (qryCriteria != null)
            {
                if (qryCriteria.SearchQueries != null)
                {
                    var eventQuery = (SearchQuery)qryCriteria.SearchQueries.FirstOrDefault();
                    var eventCriteriaOperator = (int)eventQuery.AccountabilityOperator;

                    ebtCriteria = new EventBasedCriteria();

                    ebtCriteria.Id = (int)eventQuery.QueryEntityID;
                    ebtCriteria.EventCriteriaOperator = (EventCriteriaOperator)Enum.Parse(typeof(EventCriteriaOperator), eventCriteriaOperator.ToString());
                    ebtCriteria.EventIds = eventQuery.EventIds;

                    if (eventQuery.SearchValueCollections != null && eventQuery.SearchValueCollections.Any())
                    {
                        var responseList = eventQuery.SearchValueCollections.Select(v => v.SearchValue);
                        ebtCriteria.Value = responseList;
                    }
                }
            }
            return ebtCriteria;
        }
        private static string GetLocationAsWkt(ISearchCriteria searchCriteria, int providerId)
        {
            var locationId = string.Empty;
            var mapLayerId = searchCriteria.SearchCriteriaID;

            var mapMgr = ManagerFactory.Instance.CreateMapManager();
            mapMgr.ProviderId = providerId;
            var alertLocationLayer = mapMgr.GetMapLayer(mapLayerId,
                new MapFilterCriteria()
                {
                    ProviderId = providerId,
                    MapLayerType = MapLayerSourceType.Alert,
                    NonPeopleLayersOnly = false
                });

			if (alertLocationLayer == null) return locationId;
			if (string.IsNullOrEmpty(alertLocationLayer.GeoJson)) return locationId;

			var objectIdList = LocationConverter.GetLocationIdList(alertLocationLayer.GeoJson);
			if (objectIdList != null && objectIdList.Count > 0)
				locationId = string.Join("|", objectIdList);

			return locationId;
        }

        private static Dictionary<int, List<int>> GetAttributeGroups(List<ISearchCriteria> searchCriteria)
        {
            var attributeGroups = new Dictionary<int, List<int>>();
            foreach (var groupCriteria in searchCriteria)
            {
                var attributeId = GetAttributeId(groupCriteria.SearchCriteriaID);
                if (attributeId <= 0) continue;

                if (!attributeGroups.ContainsKey(attributeId))
                    attributeGroups.Add(attributeId, new List<int> { groupCriteria.SearchCriteriaID });
                else
                    attributeGroups[attributeId].Add(groupCriteria.SearchCriteriaID);
            }
            return attributeGroups;
        }

        private static List<GenericCriteria> GetAdvancedQueryCriteria(List<ISearchCriteria> searchCriteria)
        {
            var advQueryCriteria = new List<GenericCriteria>();
            foreach (var queryCriteria in searchCriteria)
            {

                foreach (var searchQuery in queryCriteria.SearchQueries)
                {
                    CriteriaType criteriaType;
                    switch (searchQuery.QueryType)
                    {
                        case SearchQueryType.Attribute:
                            criteriaType = CriteriaType.ATTRIBUTE;
                            break;
                        case SearchQueryType.Device:
                            criteriaType = CriteriaType.DEVICE;
                            break;
                        case SearchQueryType.OperatorRole:
                            criteriaType = CriteriaType.ROLE;
                            break;
                        case SearchQueryType.VirtualSystem:
                            criteriaType = CriteriaType.VPS;
                            break;
                        case SearchQueryType.Alert:
                            criteriaType = CriteriaType.ALERT;
                            break;
                        default:
                            criteriaType = CriteriaType.ATTRIBUTE;
                            break;
                    }

                    GenericCriteria criteria;
                    if (searchQuery.QueryType.Equals(SearchQueryType.Attribute))
                    {
                        criteria = CreateAttributeCriteria(searchQuery, criteriaType);
                    }
                    else if (searchQuery.QueryType.Equals(SearchQueryType.Alert))
                    {
                        criteria = CreateAlertCriteria(searchQuery, queryCriteria.SearchValue, queryCriteria.SearchCriteriaID);
                    }
                    else if (searchQuery.QueryType.Equals(SearchQueryType.PAEvent))
                    {
                        criteria = CreateEventCriteria(searchQuery, queryCriteria.SearchValue);
                    }
                    else
                    {
                        criteria = CreateOtherCriteria(searchQuery, criteriaType);
                    }
                    advQueryCriteria.Add(criteria);
                }
            }
            return advQueryCriteria;
        }

        /// <summary>
        /// RBT for PA Event
        /// </summary>
        /// <param name="searchQuery"></param>
        /// <param name="querySearchValue"></param>
        /// <returns></returns>
        private static GenericCriteria CreateEventCriteria(SearchQuery searchQuery, string querySearchValue)
        {
            var queryOperator = new List<string>();
            var queryEventOperator = searchQuery.AccountabilityOperator.GetValueOrDefault();
            GenericCriteria rbtCriterion;

            // Incase of individual responses
            if (searchQuery.SearchValueCollections != null && searchQuery.SearchValueCollections.Any())
            {
                var searchValues = searchQuery.SearchValueCollections.ToList().Select(v => v.SearchValue);
                queryOperator.AddRange(searchValues.ToList());
            }

            // Below condition will only triggered in case of MULTIPLERESPONSE
            if (((EventCriteriaOperator)queryEventOperator) == EventCriteriaOperator.MULTIPLERESPONSE)
            {
                rbtCriterion = new EventBasedCriteria(new[] {searchQuery.QueryEntityID.GetValueOrDefault()},
                    EventCriteriaOperator.MULTIPLERESPONSE, queryOperator);
            }
            else
                // This condition will be triggered in case of NoResponse, AnyResponse, Targeted
            {
                rbtCriterion = new EventBasedCriteria(new[] { searchQuery.QueryEntityID.GetValueOrDefault() }, ((EventCriteriaOperator)queryEventOperator));
            }
            return rbtCriterion;
        }
        /// <summary>
        /// RBT for Regular Alert
        /// </summary>
        /// <param name="searchQuery"></param>
        /// <param name="querySearchValue"></param>
        /// <param name="fillCountType"></param>
        /// <returns></returns>
        private static GenericCriteria CreateAlertCriteria(SearchQuery searchQuery, string querySearchValue, int fillCountType = -1)
        {
            var queryOperator = searchQuery.AlertOperator.GetValueOrDefault();
            var deviceIds = new List<int>();
            var rbtCriterion = new GenericCriteria();
            if (!String.IsNullOrEmpty(querySearchValue))
            {
                int selectedDeviceId = 0;
                Int32.TryParse(querySearchValue, out selectedDeviceId);
                if (selectedDeviceId > 0)
                    deviceIds = new List<int> { selectedDeviceId };

            }
            if (fillCountType > -1)
                rbtCriterion = new ResultBasedCriteria(searchQuery.QueryEntityID.GetValueOrDefault(), queryOperator.ToString(), ((ResultBasedCriteriaOperator)fillCountType).ToString(), deviceIds);
            else

                rbtCriterion = new AlertCriteria(searchQuery.QueryEntityID.GetValueOrDefault(), queryOperator.ToString(), deviceIds);
            return rbtCriterion;
        }

        private static GenericCriteria CreateOtherCriteria(SearchQuery searchQuery, CriteriaType criteriaType)
        {
            var queryOperator = (int)searchQuery.Operator.GetValueOrDefault();
            var criteria = new GenericCriteria(criteriaType, searchQuery.QueryEntityID.GetValueOrDefault(), queryOperator, null);
            var searchValues = searchQuery.SearchValueCollections.ToList().Select(v => v.SearchValue);
            criteria.Value = string.Join(",", searchValues);
            return criteria;
        }

        private static GenericCriteria CreateAttributeCriteria(SearchQuery searchQuery, CriteriaType criteriaType)
        {
            var queryOperator = (int)searchQuery.Operator.GetValueOrDefault();
            var criteria = new GenericCriteria(criteriaType, searchQuery.QueryEntityID.GetValueOrDefault(), queryOperator, null);
            var searchValues = searchQuery.SearchValueCollections.ToList().Select(v => v.SearchValue);

            var attributeType = GetAttributeType(searchQuery.QueryEntityID.GetValueOrDefault());
            switch (attributeType)
            {
                case "Picklist":
                case "Multi-Picklist":
                case "Checkbox":
                    criteria.Value = (queryOperator == 11 || queryOperator == 12)
                        ? "0"
                        : string.Join(",", searchValues);
                    break;
                case "Number":
                case "String":
                case "Memo":
                case "Date":
                case "DateTime":
                case "Path":
                    criteria.Value = string.Join(",", searchValues);
                    break;
                case "Geography":
                    var locationWkt = string.Empty;
                    if (searchValues.ToList().Count > 0 && !string.IsNullOrEmpty(searchValues.ToList()[0]))
                    {
                        var wktList = LocationConverter.GetLocationIdList(searchValues.ToList()[0]);
                        if (wktList != null && wktList.Count > 0)
                            locationWkt = string.Join("|", wktList);

                        criteria.Value = locationWkt;
                    }
                    else
                    {
                        criteria.Value = string.Empty;
                    }
                    break;
                default:
                    criteria.Value = string.Join(",", searchValues);
                    break;
            }
            return criteria;
        }

        private static int GetAttributeId(int attributeValueId)
        {
            var attributeId = 0;
            using (var ngadDb = new NgadDatabase())
            {
                const string hierAttribSql = "select ATTRIBUTE_ID from PRV_ATTRIBUTE_VALUE_TAB with (nolock) where VALUE_ID = @attribValueId";
                ngadDb.AddParameter("attribValueId", SqlDbType.Int, attributeValueId);
                ngadDb.CommandType = CommandType.Text;
                var row = ngadDb.ExecuteDataRow(hierAttribSql);
                if (row != null)
                    attributeId = int.Parse(row["ATTRIBUTE_ID"].ToString());
            }
            return attributeId;
        }

        private static string GetAttributeType(int attributeId)
        {
            using (var ngadDb = new NgadDatabase())
            {
                const string attrTypeSql = @"select ATTRIBUTE_TYPE from PRV_ATTRIBUTE_TAB a with (nolock) 
inner join GLB_ATTRIBUTE_TYPE_TAB t with (nolock) on a.ATTRIBUTE_TYPE_ID = t.ATTRIBUTE_TYPE_ID 
where a.ATTRIBUTE_ID = @attributeId";
                ngadDb.AddParameter("attributeId", SqlDbType.Int, attributeId);
                ngadDb.CommandType = CommandType.Text;
                var row = ngadDb.ExecuteDataRow(attrTypeSql);
                if (row != null)
                    return row["ATTRIBUTE_TYPE"].ToString();
            }
            return string.Empty;
        }

        /// <summary>
        /// Updates searchcriteria based on target flags
        /// </summary>
        /// <param name="alertBase"></param>
        /// <param name="searchCriteria"></param>
        /// <param name="providerId"></param>
        private IList<ISearchCriteria> UpdateTargetOrganization(AlertBase alertBase, IList<ISearchCriteria> searchCriteria, int providerId)
        {
            var newSearchCriteria = searchCriteria;
            if (searchCriteria.Any(c => c.NodeType.Equals(SearchNodeType.OrgGeo)) || searchCriteria.Any(c => c.NodeType.Equals(SearchNodeType.OrgUser)))
            {

                var massDeviceFacade = new MassDeviceTargetingFacade();
                var orgEndpoints = massDeviceFacade.GetMassDeviceEndpoints(new MassDeviceTargetingSpec
                {
                    DeviceCommonName = AtHocSystem.Local.ConnectDeviceCommonName,
                    ProviderId = providerId
                });
                if (orgEndpoints != null && orgEndpoints.Count > 0)
                {
                    var activeOrgIds = orgEndpoints.Select(o => o.UserId).ToList();
                    var targetedOrgdIds = searchCriteria.Where(c => c.NodeType.Equals(SearchNodeType.OrgUser)).Select(c => c.SearchCriteriaID).ToList();
                    var disconnectedOrgIds = targetedOrgdIds.Except(activeOrgIds).ToList();
                    if (disconnectedOrgIds.Count > 0)
                    {
                        newSearchCriteria = searchCriteria.Where(c => !disconnectedOrgIds.Contains(c.SearchCriteriaID)).ToList();
                    }
                    if (alertBase.AlertSpec.Targeting.TargetAllOrganizations)
                    {
                        //insert newly connected orgs
                        var newlyConnectedOrgIds = activeOrgIds.Except(targetedOrgdIds).ToList();
                        if (newlyConnectedOrgIds.Count > 0)
                        {
                            foreach (var newlyConnectedOrgId in newlyConnectedOrgIds)
                            {
                                var newEndPoint = orgEndpoints.First(s => s.UserId.Equals(newlyConnectedOrgId));
                                if (newEndPoint != null)
                                {
                                    newSearchCriteria.Add(new SearchCriteria()
                                    {
                                        SearchCriteriaID = newEndPoint.UserId,
                                        NodeType = SearchNodeType.OrgUser,
                                        SearchValue = newEndPoint.DisplayName,
                                        IsBlocked = false
                                    });

                                }
                            }
                        }
                    }
                }
            }
            return newSearchCriteria;


        }



        private int PopulateAlertRecipients(AlertBase alert, int providerId, string providerLocale, int operatorId)
        {
            // create search args from targeting criteria
            var searchCriteria = alert.AlertSpec.Targeting.TargetingCriteria;
            if (!alert.AlertSpec.Targeting.TargetAllUserBase && (searchCriteria == null || searchCriteria.Count < 1))
                return -1;
            searchCriteria = UpdateTargetOrganization(alert, searchCriteria, providerId);

            var srchArgs = GetUserSearchArgs(searchCriteria, providerId, providerLocale, operatorId);
            var massUsers = searchCriteria.Where(c => c.NodeType.Equals(SearchNodeType.MassUser))
                .Select(c => c.SearchCriteriaID);
            var orgUsers = searchCriteria.Where(c => c.NodeType.Equals(SearchNodeType.OrgUser))
                .Select(c => c.SearchCriteriaID);

            // get search args in V2 format
            // var srchArgs = UserSearchV2ModelAdapter.Convert(srchArgs, providerId, operatorId);
            if (srchArgs == null && (massUsers == null || !massUsers.Any()) && (orgUsers == null || !orgUsers.Any())) return -1;

            // call alert populate recipient SP            
            using (var ngadDb = new NgadDatabase())
            {
                var recipientsCount = new SqlParameter("@totalRecipients", SqlDbType.Int) { Direction = ParameterDirection.Output };
                var errorString = new SqlParameter("@errorDesc", SqlDbType.NVarChar, 4000) { Direction = ParameterDirection.Output };

                ngadDb.AddParameter(new SqlParameter("@alertId", alert.AlertId));
                ngadDb.AddParameter(new SqlParameter("@prvCriteria", (srchArgs != null && srchArgs.ProviderCriteria != null) ? srchArgs.ProviderCriteria.ToString() : string.Empty));
                ngadDb.AddParameter(new SqlParameter("@oprCriteria", (srchArgs != null  && srchArgs.OperatorCriteria != null) ? srchArgs.OperatorCriteria.ToString() : string.Empty));
                ngadDb.AddParameter(new SqlParameter("@tgtCriteria", (srchArgs != null && srchArgs.TargetCriteria != null) ? QuickFixCriteriaDefinitions(srchArgs.TargetCriteria.ToString()) : string.Empty));
                ngadDb.AddParameter(new SqlParameter("@tgtUsersCsv", (srchArgs != null && srchArgs.TargetUsers != null) ? srchArgs.TargetUsers.CsvParamString() : string.Empty));
                ngadDb.AddParameter(new SqlParameter("@tgtMassUsersCsv", massUsers != null ? massUsers.CsvParamString() : string.Empty));
                ngadDb.AddParameter(new SqlParameter("@tgtOrgUsersCsv", orgUsers != null ? orgUsers.CsvParamString() : string.Empty));
                ngadDb.AddParameter(new SqlParameter("@blkCriteria", (srchArgs != null && srchArgs.BlockCriteria != null) ? srchArgs.BlockCriteria.ToString() : string.Empty));
                ngadDb.AddParameter(new SqlParameter("@blkUsersCsv", (srchArgs != null && srchArgs.BlockUsers != null) ? srchArgs.BlockUsers.CsvParamString() : string.Empty));
                ngadDb.AddParameter(recipientsCount);
                ngadDb.AddParameter(errorString);
                if (srchArgs != null) ngadDb.AddParameter(new SqlParameter("@debugLevel", srchArgs.Options.DebugLevel));

                ngadDb.CommandType = CommandType.StoredProcedure;
                ngadDb.ExecuteNonQuery("dbo.ALT_POPULATE_RECIPIENTS");
                ngadDb.CommitTransaction();

                return (int)recipientsCount.Value;
            }
        }

        private void PopulateAlertBatch(int alertId, bool isRegularAlert, bool isMassDevice)
        {
            using (var ngadDb = new NgadDatabase())
            {
                ngadDb.AddParameter(new SqlParameter("@alertId", alertId));
                ngadDb.AddParameter(new SqlParameter("@forRegularUsers", isRegularAlert));
                ngadDb.AddParameter(new SqlParameter("@massDeviceUsers", isMassDevice));
                ngadDb.CommandType = CommandType.StoredProcedure;
                ngadDb.ExecuteNonQuery("dbo.DLV_BATCH_GENERATE");
            }
        }

        public int PopulateRecipients(int alertId, int providerId, string providerLocale, int operatorId)
        {
            var alertManager = new AlertManager(providerId, operatorId);
            var alert = alertManager.GetAlert(alertId);

            if (alert == null) return -1;

            return PopulateAlertRecipients(alert, providerId, providerLocale, operatorId);
        }


        public void PopulateBatch(int alertId, bool isRegularAlert, bool isMassDevice)
        {
            PopulateAlertBatch(alertId, isRegularAlert, isMassDevice);
        }

        public void OnAlertPubished(int alertId, int providerId, int operatorId)
        {
            //
            try
            {
                var alertManager = new AlertManager();
                var alert = alertManager.GetAlert(alertId);

                if (alert == null)
                {
                    EventLogger.WriteError(string.Format("Failed to get alert from id: {0}", alertId));
                    return;
                }

                var providerFacade = ServiceLocator.Resolve<IProviderFacade>();
                var featureMatrix = providerFacade.GetFeatureMatrix(providerId);
                if (!featureMatrix.IsActivityLogSupported) return;
                var eventFacade = ServiceLocator.Resolve<IEventFacade>();
                eventFacade.CreateEvent(alert, providerId, operatorId);
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(ex);
            }
        }

        private string QuickFixCriteriaDefinitions(string criteriaString)
        {
            criteriaString = UserSearchHelper.ReplaceDesktopDeviceCriteria(criteriaString);
            criteriaString = UserSearchHelper.ReplaceMobileDeviceCriteria(criteriaString);

            return criteriaString;
        }
    }
}
