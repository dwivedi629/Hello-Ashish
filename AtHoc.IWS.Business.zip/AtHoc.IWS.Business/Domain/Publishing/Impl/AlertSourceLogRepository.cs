﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.Publishing.Impl
{
   public class AlertSourceLogRepository:IAlertSourceLogRepository
    {
       /// <summary>
       /// Create Alert Source Log. e.g. WHO, WHERE, WHEN
       /// </summary>
       /// <param name="alertSourceLog">Inputs of type AlertSourceLog</param>
       /// <returns>Boolean</returns>
        public bool Create(AlertSourceLog alertSourceLog)
        {
            using (var db = new AtHocDbContext())
                {
                    // Create a SQL command to execute the sproc 
                    var cmd = db.Database.Connection.CreateCommand();
                    cmd.CommandText = "[dbo].[ALT_SET_SOURCE_LOG]";
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@alertId", alertSourceLog.AlertId));
                    cmd.Parameters.Add(new SqlParameter("@entity", alertSourceLog.Entity));
                    cmd.Parameters.Add(new SqlParameter("@entityId", alertSourceLog.EntityId));
                    cmd.Parameters.Add(new SqlParameter("@createdBy", alertSourceLog.CreatedBy));
                    db.Database.Connection.Open();
                    var count = cmd.ExecuteNonQuery();
                    db.Database.Connection.Close();
                    return true;
                }
            }


       /// <summary>
       /// Get List of Alert Source logs.
       /// </summary>
       /// <returns></returns>
        public IEnumerable<Entities.AlertSourceLog> GetAlertSourceLogs()
        {
            throw new NotImplementedException();
        }
    }
}
