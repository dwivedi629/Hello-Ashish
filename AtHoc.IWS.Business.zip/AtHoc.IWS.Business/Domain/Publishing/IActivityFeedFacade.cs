﻿using System.Collections.Generic;
using AtHoc.Infrastructure.Data;
using AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.Publishing
{
	public interface IActivityFeedFacade
	{
		IEnumerable<ActivityFeed> GetActivityFeedsBySpec(ActivityFeedSpec spec);

		int GetActivityFeedsCountBySpec(ActivityFeedSpec spec);

		ActivityFeed GetActivityFeedBySpec(ActivityFeedSpec spec);

	    PagingInfo<ActivityFeed> GetActivityFeedItemsPage(ActivityFeedSpec spec);

        bool SaveAlertResponseOptionToDB(int alertId, int userId, string responesText, string clientIp, string userAgent, string serverIp);

	    List<UserAccountabilityEventAlert> GetUserAlertsForAccountabilityEvent(int userId, int accoutabilityEventId);

	    PagingInfo<AccountabilityActivityFeed> GetAccountabilityActivityFeedItemsPage(ActivityFeedSpec spec);

	    AccountabilityEventDetail GetUserAccountabilityActivityFeed(int userId, int accoutabilityEventId);
	}
}