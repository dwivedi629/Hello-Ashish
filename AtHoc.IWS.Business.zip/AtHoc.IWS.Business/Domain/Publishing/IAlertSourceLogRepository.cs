﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Publishing.Impl;

namespace AtHoc.IWS.Business.Domain.Publishing
{
    public interface IAlertSourceLogRepository
    {
        bool Create(AlertSourceLog alertSourceLog);
        IEnumerable<AlertSourceLog> GetAlertSourceLogs();
    }
}
