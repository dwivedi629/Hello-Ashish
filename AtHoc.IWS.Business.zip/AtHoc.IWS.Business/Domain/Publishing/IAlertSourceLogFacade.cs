﻿using System.Collections.Generic;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.Publishing
{
    public interface IAlertSourceLogFacade
    {
        /// <summary>
        /// Create Alert Source Log
        /// </summary>
        /// <param name="alertSourceLogLog">Instance of AlertSourceLog type.</param>
        /// <returns>Boolean</returns>
        bool CreateAlertSourceLog(AlertSourceLog alertSourceLogLog);

        /// <summary>
        /// Get List of Alert Source Logs
        /// </summary>
        /// <returns></returns>
        IEnumerable<AlertSourceLog> GetAlertSourceLogs ();

    }
}
