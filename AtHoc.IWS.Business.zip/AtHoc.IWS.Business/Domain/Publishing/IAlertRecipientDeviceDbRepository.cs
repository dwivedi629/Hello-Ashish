﻿using AtHoc.Infrastructure.Data;

using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.Publishing
{
	public interface IAlertRecipientDeviceRepository : IRepository<AlertRecipientDevice, AlertRecipientDeviceSpec> { }
}