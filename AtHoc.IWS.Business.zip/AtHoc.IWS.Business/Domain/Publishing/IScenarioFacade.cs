﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Data;
using AtHoc.IWS.Business.Data.SearchSpec;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.Publishing
{
    /// <summary>
    /// Scenario Facade, currently wrapper over ScenarioManager in Athoc.Publishing
    /// </summary>
    public interface IScenarioFacade
    {
        /// <summary>
        /// Get Scenario Detail by Id, Provider and Operator
        /// </summary>
        /// <param name="scenarioId">Scenario Id</param>
        /// <param name="provideId">Provider/VPS Id</param>
        /// <param name="operatorId">Logged in Operator Id</param>
        /// <returns></returns>
        AtHoc.Publishing.Scenario GetScenario(int scenarioId, int provideId, int operatorId);

        IEnumerable<Scenario> GetScenarios(int providerId, int operatorId, ScenarioSearchSpec spec);

        AtHoc.Publishing.Scenario CreateScenario(int provideId, int operatorId);

        bool SaveScenario(int provideId, int operatorId, AtHoc.Publishing.Scenario scenario);

        void DeleteScenarios(int providerId, int operatorId, int[] scenarioIds);
        bool IsSystemScenario(string commonName);

        AtHoc.Publishing.Scenario DuplicateScenario(int id, int providerId, int operatorId);
    }
}
