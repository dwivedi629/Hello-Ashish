﻿using AtHoc.Infrastructure.Data;

namespace AtHoc.IWS.Business.Domain.Publishing
{
	public interface IActivityFeedRepository : IRepository<ActivityFeed, ActivityFeedSpec> { }
}