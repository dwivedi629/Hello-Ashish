﻿using System.Collections.Generic;
using AtHoc.Infrastructure.Data;
using System.Data;
using AtHoc.IWS.Business.Domain.Entities;
using System.Collections;
using AtHoc.IWS.Business.Domain.Targeting.Model;
using AtHoc.IWS.Business.Domain.Reports;

namespace AtHoc.IWS.Business.Domain.Publishing
{
	public interface IAlertReportDataRepository
	{
        ArrayList GetAlertReportData(int providerId, AlertReportCriteria reportCriteria);

	    DataTable GetTargetUserBase(ResultBasedTargetingCriteria rbtCriteria );

        /// <summary>
        /// Gets data for the alert tracking summary data
        /// </summary>
        /// <param name="alertId"></param>
        /// <param name="type">summary or detail</param>
        /// <param name="dim">dimension: user, org, mass</param>
        /// <returns>object which contains summary header and response details</returns>
        AlertTrackingResult GetAlertTrackingSummary(int alertId, ReportType type, Dimension dim);
	}
}
