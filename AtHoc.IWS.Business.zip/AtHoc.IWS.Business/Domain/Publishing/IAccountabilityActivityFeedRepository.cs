﻿using AtHoc.Infrastructure.Data;
using AtHoc.IWS.Business.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Publishing
{
    public interface IAccountabilityActivityFeedRepository : IRepository<AccountabilityActivityFeed, ActivityFeedSpec> { }    
}
