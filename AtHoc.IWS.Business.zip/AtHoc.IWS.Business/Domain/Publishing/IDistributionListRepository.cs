﻿using AtHoc.Infrastructure.Data;

using AtHoc.IWS.Business.Domain.Entities;
using System.Collections.Generic;


namespace AtHoc.IWS.Business.Domain.Publishing
{
	public interface IDistributionListRepository : IRepository<DistributionList, DistributionListSpec> {

        IEnumerable<DistributionList> GetChildrenNodes(DistributionListSpec spec);
	    IEnumerable<int> GetNestedStaticListIds(int listId);
        DistributionListNameVerificationMessage VerifyDLName(DistributionListSpec spec);
	}
}
