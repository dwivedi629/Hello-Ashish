using System.Collections.Generic;

using AtHoc.Infrastructure.Data;

using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Publishing.Impl;
using AtHoc.IWS.Business.Domain.Publishing.Spec;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Business.Service;
using AtHoc.Publishing.Service; 

namespace AtHoc.IWS.Business.Domain.Publishing
{
	public interface IPublishingFacade
	{
		IServiceResult<bool> DeleteDistributionList(DistributionListSpec spec, bool isTemporaryList = false);

		IEnumerable<DistributionList> GetDistributionLists(DistributionListSpec spec);

		DistributionList GetDistributionList(DistributionListSpec spec);

		IEnumerable<DistributionListItem> GetDistributionListItems(DistributionListItemSpec spec);

		int GetDistributionListsCount(DistributionListSpec spec);

		IEnumerable<DistributionList> GetChildrenNodes(DistributionListSpec spec);

        ContextSearchResult GetDistributionListUserSearchResult(CustomAttributeLookup customAttributeLookup, DistributionListSpec spec, string locale, bool allUsers = false);

        IEnumerable<UserSearchResultItem> GetDistributionListUsers(CustomAttributeLookup customAttributeLookup, DistributionListSpec spec, string locale, bool includeNestedListsUsers = false);

        IEnumerable<int> GetDistributionListUsersIds(CustomAttributeLookup customAttributeLookup, DistributionListSpec spec, string locale, bool includeNestedListsUsers = false);

		PagingInfo<DistributionListItem> GetDistributionListItemsPage(DistributionListItemSpec spec);

		IEnumerable<int> GetDistributionListIds(DistributionListItemSpec spec);

		IEnumerable<DistributionListDependency> GetDistributionListDependencies(DistributionListDependencySpec spec);

		DistributionListDependencyResult GetDistributionListDependencyResult(DistributionListDependencySpec spec);

		bool CheckDistribuionListUnique(DistributionListSpec spec);

		IServiceResult<bool> SaveDistributionList(DistributionListSaveSpec list);

        IEnumerable<int> GetStaticListChildIds(DistributionListSpec spec, bool includeAllLevel = false);

		IEnumerable<int> GetStaticListParentIds(DistributionListSpec spec, bool includeAllLevel = false);

		IEnumerable<int> GetStaticListFirstLevelChildIds(DistributionListSpec spec);

		string GetDistributionItemPath(DistributionListSpec spec);
         

	    IEnumerable<int> GetNestedStaticListIds(int listId);



	}
}