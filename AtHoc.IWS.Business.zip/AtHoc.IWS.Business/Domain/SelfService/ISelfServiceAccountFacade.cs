﻿using System.Collections.Generic;
using AtHoc.IWS.Business.Domain.SelfService.DTO;
using AtHoc.IWS.Business.Service;

namespace AtHoc.IWS.Business.Domain.SelfService
{
    /// <summary>
    /// Scenario Facade, currently wrapper over ScenarioManager in Athoc.Publishing
    /// </summary>
    public interface ISelfServiceAccountFacade
    {
        /// <summary>
        /// This method sends a username recovery email to the given user email address
        /// 1. Get (top) UserID from Email Address (for sending unique URL email)
        /// 2. Send Username Recovery Email
        /// </summary>
        /// <param name="email">User's Email ID</param>
        /// <param name="providerId">Provider ID</param>
        /// <returns>RecoveryRequestStatus Enumeration</returns>
        RecoveryRequestStatus RecoverUsername(string email, string provider, int? providerId);

        /// <summary>
        /// This method sends a password recovery email to the given user email address
        /// 1. Get (top) UserID from Email Address (for sending unique URL email)
        /// 2. Generate Unique URL Infrastructure
        /// 3. Send Password Recovery Email
        /// </summary>
        /// <param name="email">User's Email ID</param>
        /// <param name="providerId">Provider ID</param>
        /// <returns>RecoveryRequestStatus Enumeration</returns>
        RecoveryRequestStatus RecoverPassword(string email, string provider, int? providerId);

       

        /// <summary>
        /// Validates the Recovery Key
        /// </summary>
        /// <param name="key">The Unique Recovery Key</param>
        /// <returns>RecoveryKeyStatus Enumeration</returns>
        RecoveryKeyStatus ValidateRecoveryKey(string key);

        
        /// <summary>
        /// Gets all the UserIDs associated with the email tagged with the Recovery Key
        /// UserID(s) look up from Email Address (should return all Usernames + Status)
        /// </summary>
        /// <param name="key">The Unique Recovery Key</param>
        /// <param name="providerId">Provider ID</param>
        /// <returns>Returns a set of Users or 0 users if no active users found</returns>
        IEnumerable<User> GetUsersByRecoveryKey(string key, int? providerId);

        IServiceResult<bool> UpdatePassword(int userId, string newPassword, string key, int providerId);

        IEnumerable<User> GetUsersByEmail(string email, int? providerId);

        bool PasswordMatch(LoginUserDetails userDetails, LoginPasswordInfo pwInfo, string password);
    }
}
