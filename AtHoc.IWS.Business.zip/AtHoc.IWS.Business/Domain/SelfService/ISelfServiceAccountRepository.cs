﻿using System.Collections.Generic;
using AtHoc.IWS.Business.Domain.SelfService.DTO;

namespace AtHoc.IWS.Business.Domain.SelfService
{
    public interface ISelfServiceAccountRepository
    {
        IEnumerable<User> GetUsersByEmail(string email, int? providerId);

        User GetUserById(int userId, string email = null);

        int? GetEventCategoryId(int providerId, string categoryName);

        string GenerateUniqueKey();

        bool SaveUsernameRecoveryRequest(string email, int userId, int? providerId);

        bool SavePasswordRecoveryRequest(string email, int userId, string key, int? providerId);

        RecoveryKeyStatus ValidateRecoveryKey(string key);

        IEnumerable<User> GetUsersByRecoveryKey(string key, int? providerId);

        bool LogPasswordUpdate(string key);

        bool IsOperator(int userId, int providerId);
    }
}
