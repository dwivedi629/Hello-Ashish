﻿using System.Collections.Generic;
using AtHoc.IWS.Business.Domain.SelfService.DTO;

namespace AtHoc.IWS.Business.Domain.SelfService
{
    public interface ICredentialRecoveryRepository
    {
        IEnumerable<User> GetUsersByEmail(string email, int? providerId);

        User GetUserById(int userId, string email = null);

        string GenerateUniqueKey();

        bool SaveUsernameRecoveryRequest(string email, int userId, int? providerId);

        bool SavePasswordRecoveryRequest(string email, int userId, string key, int? providerId);

        RecoveryKeyStatus ValidateRecoveryKey(string key);

        IEnumerable<User> GetUsersByRecoveryKey(string key, int? providerId);

        bool LogPasswordUpdate(string key);
    }
}
