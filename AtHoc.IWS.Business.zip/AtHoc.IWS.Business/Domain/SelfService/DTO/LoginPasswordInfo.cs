﻿namespace AtHoc.IWS.Business.Domain.SelfService.DTO
{
    public class LoginPasswordInfo
    {
        public int Id { get; set; }
        public string Password { get; set; }
        public string UserRandomId { get; set; }
    }
}