

namespace AtHoc.IWS.Business.Domain.SelfService.DTO
{
    public class DesktopSessionSearchArgs
    {
        #region Constructor

        public DesktopSessionSearchArgs()
        {

        }

        public DesktopSessionSearchArgs(int userId, long sessionId)
        {
            UserId = userId;
            SessionId = sessionId;
        }

        #endregion

        #region Properties

        public int UserId { get; set; }

        public long SessionId { get; set; }

        #endregion
    }

    public class DesktopSessionSearchResult
    {
        public int UserId { get; set; }
        public long SessionId { get; set; }
        public string SessionStatus { get; set; }
        public string LogonType { get; set; }
        public string IpAddress { get; set; }
        public string ClientVersion { get; set; }
        public int ProviderId { get; set; }
    }
}
