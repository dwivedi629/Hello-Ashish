
namespace AtHoc.IWS.Business.Domain.SelfService.DTO
{
    public class User
    {
        #region Constructor

        public User()
        {
            
        }

        public User(int userId, string username, string status, string email)
        {
            UserId = userId;
            Username = username;
            Status = status;
            Email = email;
        }

        #endregion

        #region Properties

        public int UserId { get; set; }

        public string Usertype { get; set; }

        public string Username { get; set; }

        public int ProviderId { get; set; }

        public string ProviderName { get; set; }

        public string Status { get; set; }

        public string Email { get; set; }

        public int DeviceId { get; set; }
    
        #endregion
    }

    public enum RecoveryRequestStatus
    {
        EmailNotFound = -1,
        RequestRegisteredSuccessfully = 0,
        RequestRegistrationFailure = 1,
        EmailSendFailure = 2

    }

    public enum RecoveryKeyStatus
    {
        KeyNotFound = -1,
        KeyValidated = 0,
        KeyExpired = 1,
        KeyAlreadyUsed = 2
    }
}
