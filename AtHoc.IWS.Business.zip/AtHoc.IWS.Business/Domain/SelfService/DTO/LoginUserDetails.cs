﻿namespace AtHoc.IWS.Business.Domain.SelfService.DTO
{
    public class LoginUserDetails
    {
        public int Id { get; set; }
        public int ProviderId { get; set; }
        public string UserName { get; set; }
        public string DisplayName { get; set; }
        public string Status { get; set; }
    }
}