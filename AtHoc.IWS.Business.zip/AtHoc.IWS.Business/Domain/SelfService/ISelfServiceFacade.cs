﻿
using AtHoc.IWS.Business.Domain.SelfService.DTO;

namespace AtHoc.IWS.Business.Domain.SelfService
{
    public interface ISelfServiceFacade
    {
        DesktopSessionSearchResult GetDesktopSession(DesktopSessionSearchArgs args);

        int? GetProviderIdByUsername(int enterpriseProviderId, string username);
        int? GetUserIdByUsername(int providerId, string username, bool isEnterpriseUniquessCheckEnabled = false);
        int? GetUserIdByMappingId(int providerId, string mappingId, bool isEnterpriseUniquessCheckEnabled = false);
        string GetUserTypeByUserId(int userId);
        string GetUserTokenByUserId(int userId);
        string GetUsernameByUserId(int userId);
        void SetUserTypeForUserId(int userId, string type);
        int? GetProviderIdForUserId(int userId);
        string GetSSDisclaimer(int providerId);
        string GetOrgCodeByProviderId(int providerId);
        int? GetProviderIdByOrgCode(string orgCode);
        dynamic GetSelfServiceAuthOptions(int providerId);
        T GetUserAttributeValue<T>(int userId, string commonName, int? providerId = 3);
        int CreateSelfServiceWebSession(int userId, string clientIp);
        void UpdateSelfServiceLastLoggedOnTime(int userId);
        LoginUserDetails GetUserDetailsforSelfServiceLogin(int userId);
        LoginPasswordInfo GetUserPasswordInfoforSelfServiceLogin(int userId);
        bool GetEnterpriseUniquenessStatus(int providerId);
    }
}