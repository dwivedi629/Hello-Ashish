﻿using System.Globalization;
using System.Web.UI;
using AtHoc.Infrastructure.Domain;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Business.Data;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.SelfService.DTO;
using AtHoc.IWS.Business.Domain.Users.Impl;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.IWS.Business.Service;
using AtHoc.Operators;
using AtHoc.Publishing;
using AtHoc.Security;
using AtHoc.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using User = AtHoc.IWS.Business.Domain.SelfService.DTO.User;
using AtHoc.Devices;
using AtHoc.IWS.Business.Adapter;
using AtHoc.IWS.Business.Domain.Settings.Impl;
using AtHoc.Global.Resources;
using AtHoc.IWS.Business.Helper;

namespace AtHoc.IWS.Business.Domain.SelfService.Impl
{
    public class SelfServiceAccountFacade : FacadeBase<IAtHocContextFactory>, ISelfServiceAccountFacade
    {
        private const string EventCategory_Other = "Other";
        public SelfServiceAccountFacade() : base(AtHocDbContextFactory.CreateFactory()) { }

        /// <summary>
        /// This method sends a username recovery email to the given user email address
        /// 1. Get (top) UserID from Email Address (for sending unique URL email)
        /// 2. Send Username Recovery Email
        /// </summary>
        /// <param name="email">User's Email ID</param>
        /// <param name="providerId">Provider ID</param>
        /// <returns>NULL if email not found, TRUE if email sent, FALSE if email sending generic error</returns>
        public RecoveryRequestStatus RecoverUsername(string email, string provider, int? providerId)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                var users = GetUsersByEmail(email, providerId).GroupBy(x => new { x.UserId, x.Username, x.ProviderId, x.ProviderName, x.Status });
                var activeUsers = users.Where(u => u.Key.Status == "VLD").ToList();
                if (activeUsers.Count == 0) return RecoveryRequestStatus.EmailNotFound;

                var usernames = activeUsers.Aggregate("", (current, user) => current + (user.Key.Username + " (" + user.Key.ProviderId + " - " + user.Key.ProviderName + ")" + Environment.NewLine));

                var activeUser = context.SelfServiceAccountRepository.GetUserById(activeUsers[0].Key.UserId, email);

                if (context.SelfServiceAccountRepository.SaveUsernameRecoveryRequest(email, activeUser.UserId, providerId))
                {
                    
                    SendMail(activeUser, String.Empty, usernames,"ForgotUsername_Email_Header","ForgotUsername_Email_SingleUser_Body");
                                     
                    OperationAuditor.LogAction(activeUser.UserId, activeUser.ProviderId, Infrastructure.EnumUtils<ServiceAction>.GetDescriptionByValue(ServiceAction.SelfServiceForgotUsernameEmailSent), AtHoc.Infrastructure.EnumUtils<EntityType>.GetDescriptionByValue(EntityType.SelfService), activeUser.Username, activeUser.UserId, "MS", email);

                    return RecoveryRequestStatus.RequestRegisteredSuccessfully;
                }

                return RecoveryRequestStatus.RequestRegistrationFailure;
            }
        }

        /// <summary>
        /// This method sends a password recovery email to the given user email address
        /// 1. Get (top) UserID from Email Address (for sending unique URL email)
        /// 2. Generate Unique URL Infrastructure
        /// 3. Send Password Recovery Email
        /// </summary>
        /// <param name="email">User's Email ID</param>
        /// <param name="providerId">Provider ID</param>
        /// <returns>NULL if email not found, TRUE if email sent, FALSE if email sending generic error</returns>
        public RecoveryRequestStatus RecoverPassword(string email, string provider, int? providerId)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                var users = GetUsersByEmail(email, providerId);
                var activeUsers = users.Where(u => u.Status == "VLD").ToList();
                if (activeUsers.Count == 0) return RecoveryRequestStatus.EmailNotFound;

                var key = context.SelfServiceAccountRepository.GenerateUniqueKey();

                if (context.SelfServiceAccountRepository.SavePasswordRecoveryRequest(email, activeUsers[0].UserId, key, providerId))
                {

                    SendMail(activeUsers[0], ConfigurationManager.GetURL() + "/SelfService/ValidateKey/" + key + (providerId == null ? "" : "/" + providerId), "", "ForgotPassword_Email_Header", "ForgotPassword_Email_Body");
                    
                    OperationAuditor.LogAction(activeUsers[0].UserId, activeUsers[0].ProviderId, Infrastructure.EnumUtils<ServiceAction>.GetDescriptionByValue(ServiceAction.SelfServiceForgotPasswordEmailSent), Infrastructure.EnumUtils<EntityType>.GetDescriptionByValue(EntityType.SelfService), activeUsers[0].Username, activeUsers[0].UserId, "MS", email);

                    return RecoveryRequestStatus.RequestRegisteredSuccessfully;
                }

                return RecoveryRequestStatus.RequestRegistrationFailure;
            }
        }

        private void SendMail(User activeUser,string url, string usernames, string headerResourceLabel, string bodyResourceLabel)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                var alertManager = new AlertManager(activeUser.ProviderId, 1);
                var alert = alertManager.CreateAlert();

                String locale = ProviderHelper.GetProviderLocale(activeUser.ProviderId); 

                string header = IWSResources.ResourceManager.GetString(headerResourceLabel, CultureInfo.GetCultureInfo(locale));

                string body = IWSResources.ResourceManager.GetString(bodyResourceLabel, CultureInfo.GetCultureInfo(locale));

                if (usernames.Length != 0) //add username for forgot username flow
                {
                    body += Environment.NewLine + usernames;
                }

                alert.AlertSpec.Content.Header = header;
                alert.AlertSpec.Content.Body = body;
                
                //set content locale to passed locale (which would pick right severity text, etc
                alert.Locale = new AtHoc.Systems.LocaleInfo(locale);

                if (!string.IsNullOrEmpty(url)) alert.AlertSpec.Content.Url = url;
                else
                    alert.AlertSpec.Content.Url = "";
                alert.AlertSpec.Content.ResponseOptions = null;
                alert.AlertSpec.Targeting.Reset();
                AddUserTargeting(alert.AlertSpec.Targeting, activeUser.UserId);
                alert.AlertSpec.Delivery.RemoveAllDevices();
                alert.AlertSpec.Delivery.TargetDevice(activeUser.DeviceId);
                
                setDeviceOptionsForForgotEmail(activeUser.ProviderId, activeUser.DeviceId, ref alert,locale);

                alert.PublishAtCurrentTime = true;
                alert.AlertSpec.LiveDuration.Unit = DurationUnit.Minute;
                alert.AlertSpec.LiveDuration.Value = 15;
                alert.AlertSpec.Priority = Priority.High;
                alert.SetStatus(AlertStatus.Scheduled);
                alert.IsReadyForPublish = true;
                alert.Origin.Type = OriginType.Test;
                alert.AlertSpec.EventCategoryId = context.SelfServiceAccountRepository.GetEventCategoryId(activeUser.ProviderId, EventCategory_Other);
                alertManager.PublishAlert(alert);
            }
        }

        private void setDeviceOptionsForForgotEmail(int providerId, int deviceId, ref Alert alert, string locale)
        {
            var dm = new DeviceManager(providerId);
            var providerDevices = dm.GetDevices(true, true);
            var extension = providerDevices.First(d => d.Id == deviceId).Group.Extension;
            

            var template = DeliveryTemplateAdapter.GetTemplateByCommonNane("Email-Template-Forgot-Password_" + locale, providerId);
            int templateId = 0;
            if (template != null)
            {
                templateId = template.templateId;
            }
            Dictionary<string, string> deviceOptions =
                new Dictionary<string, string>();
            deviceOptions.Add("AlertExtension.DeviceGroup.Template.DeliveryTemplateType", "Custom");
            deviceOptions.Add("AlertExtension.DeviceGroup.Template.DeliveryTemplateType.Custom.Id", templateId.ToString());
            deviceOptions.Add("AlertExtension.DeviceGroup.EMail.Source", "HeaderBody");
            deviceOptions.Add("AlertExtension.DeviceGroup.EMail.Source.Custom.Title", "");
            deviceOptions.Add("AlertExtension.DeviceGroup.EMail.Source.Custom.Body", "");
            alert.AlertSpec.Delivery.CustomOption.FillValuesFromDictionary(extension, deviceOptions);
        
        }

        private static void AddUserTargeting(TargetingSpecification spec, int userId)
        {
            if (spec.TargetingCriteria == null)
                spec.TargetingCriteria = new List<ISearchCriteria>();

            spec.TargetingCriteria.Add(new SearchCriteria { IsBlocked = false, NodeType = SearchNodeType.User, SearchCriteriaID = userId });
        }

        /// <summary>
        /// Validates the Recovery Key
        /// </summary>
        /// <param name="key">The Unique Recovery Key</param>
        /// <returns>NULL if the key is not found or invalid, TRUE if key is valid, FALSE if key is expired</returns>
        public RecoveryKeyStatus ValidateRecoveryKey(string key)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.SelfServiceAccountRepository.ValidateRecoveryKey(key);
            }
        }

        /// <summary>
        /// Gets all the UserIDs associated with the email tagged with the Recovery Key
        /// UserID(s) look up from Email Address (should return all Usernames + Status)
        /// </summary>
        /// <param name="key">The Unique Recovery Key</param>
        /// <param name="providerId">ProviderID</param>
        /// <returns>Returns a set of Users or 0 users if no active users found or NULL if key is expired</returns>
        public IEnumerable<User> GetUsersByRecoveryKey(string key, int? providerId)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                if (context.SelfServiceAccountRepository.ValidateRecoveryKey(key) == RecoveryKeyStatus.KeyValidated)
                {
                    var users = context.SelfServiceAccountRepository.GetUsersByRecoveryKey(key, providerId).GroupBy(x => new { x.UserId, x.Username, x.ProviderId, x.ProviderName, x.Status }).ToList();
                    var activeUsers = users.Where(u => u.Key.Status == "VLD").Select(y => new User()
                    {
                        UserId = y.Key.UserId,
                        Username = y.Key.Username,
                        ProviderId = y.Key.ProviderId,
                        ProviderName = y.Key.ProviderName,
                        Status = y.Key.Status
                    }).ToList();

                    if (users.Count > 0)
                        OperationAuditor.LogAction(activeUsers[0].UserId, activeUsers[0].ProviderId, AtHoc.Infrastructure.EnumUtils<ServiceAction>.GetDescriptionByValue(ServiceAction.PasswordRecoveryKeyValidated), AtHoc.Infrastructure.EnumUtils<EntityType>.GetDescriptionByValue(EntityType.Operator), activeUsers[0].Username, activeUsers[0].UserId, "MS", key);
                    if (users.Count > 0 && activeUsers.Count == 0)
                        OperationAuditor.LogAction(users[0].Key.UserId, users[0].Key.ProviderId, AtHoc.Infrastructure.EnumUtils<ServiceAction>.GetDescriptionByValue(ServiceAction.NoActiveUsersFoundForPasswordChange), AtHoc.Infrastructure.EnumUtils<EntityType>.GetDescriptionByValue(EntityType.Operator), users[0].Key.Username, users[0].Key.UserId, "MS", key);
                    else
                        OperationAuditor.LogAction(activeUsers[0].UserId, activeUsers[0].ProviderId, AtHoc.Infrastructure.EnumUtils<ServiceAction>.GetDescriptionByValue(ServiceAction.ActiveUsersPageAccessedForPasswordChange), AtHoc.Infrastructure.EnumUtils<EntityType>.GetDescriptionByValue(EntityType.Operator), activeUsers[0].Username, activeUsers[0].UserId, "MS", key);
                    
                    return activeUsers;
                }
                return null;
            }
        }

        public IServiceResult<bool> UpdatePassword(int userId, string newPassword, string key, int providerId)
        {
            IServiceResult<bool> result = new ServiceResult<bool>();
            var ignoreRulesList = new List<PasswordResetIgnoreRules> { PasswordResetIgnoreRules.UpdateFrequency };
            var userFacade = new UserFacade();

            using (var context = ContextFactory.CreateNgaddataContext())
            {
                var operatorUser = context.OperatorUserRepository.FindBySpec(new OperatorUserSpec { UserId = userId }).SingleOrDefault();
                if (operatorUser != null)
                {
                    operatorUser.Password = newPassword;

                    UserSave.SaveUserWithPassword(context, result, operatorUser, false, "", ignoreRulesList);

                    //Unlocking the operator on password reset
                    if (operatorUser.AccessLocked.ToUpper() == "YES") OperatorManager.UpdateOperatorAttributeValue(userId, "ACCESS_LOCKED", "No");

                    if (result.IsValid && key != null) context.SelfServiceAccountRepository.LogPasswordUpdate(key);

                    var user = context.SelfServiceAccountRepository.GetUserById(userId);
                    OperationAuditor.LogAction(user.UserId, user.ProviderId, Infrastructure.EnumUtils<ServiceAction>.GetDescriptionByValue(ServiceAction.PasswordChanged), Infrastructure.EnumUtils<EntityType>.GetDescriptionByValue(EntityType.Operator), user.Username, user.UserId, "MS", key);
                }
                else
                {
                    var userUpdateResult = userFacade.UpdatePassword(userId, newPassword, "");
                    if (userUpdateResult.IsValid)
                    {
                        if (key != null) context.SelfServiceAccountRepository.LogPasswordUpdate(key);

                        var user = new UserFacade().GetUserBySpec(new UserSpec { UserId = userId });
                        if (user != null && user.ProviderId.HasValue)
                        {
                            OperationAuditor.LogAction(user.Id, user.ProviderId.Value, Infrastructure.EnumUtils<ServiceAction>.GetDescriptionByValue(ServiceAction.PasswordChanged), Infrastructure.EnumUtils<EntityType>.GetDescriptionByValue(EntityType.EndUsers), user.UserName, user.Id, "MS", key);
                        }
                    }
                    else
                    {
                        return userUpdateResult;
                    }
                }
            }

            return result;
        }

        public IEnumerable<User> GetUsersByEmail(string email, int? providerId)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.SelfServiceAccountRepository.GetUsersByEmail(email, providerId);
            }
        }

        public bool PasswordMatch(LoginUserDetails userDetails, LoginPasswordInfo pwInfo, string password)
        {
            if (pwInfo == null) return false;
            if (pwInfo.UserRandomId == null) return false;
            if (pwInfo.Password == null) return false;
            if (PasswordHasher.MatchPassword(pwInfo.Password, pwInfo.UserRandomId, userDetails.Id.ToString(CultureInfo.InvariantCulture), password)) return true;
            if (PasswordHasher.MatchPassword(pwInfo.Password, pwInfo.UserRandomId, userDetails.UserName, password)) return true;

            return false;
        }

    }
}