﻿using AtHoc.Infrastructure.Domain;
using AtHoc.IWS.Business.Data;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.SelfService.DTO;

namespace AtHoc.IWS.Business.Domain.SelfService.Impl
{
    public partial class SelfServiceFacade : FacadeBase<IAtHocContextFactory>, ISelfServiceFacade
    {
        public SelfServiceFacade() : base(AtHocDbContextFactory.CreateFactory()) { }

        public static readonly int SelfServiceDeviceId = 10;

        public DesktopSessionSearchResult GetDesktopSession(DesktopSessionSearchArgs args)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.SelfServiceRepository.GetDesktopSession(args);
            }
        }

        public int? GetUserIdByUsername(int providerId, string username, bool isEnterpriseUniquessCheckEnabled = false)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.SelfServiceRepository.GetUserIdByUsername(providerId, username, isEnterpriseUniquessCheckEnabled);
            }
        }

        public int? GetProviderIdByUsername(int enterpriseProviderId, string username)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.SelfServiceRepository.GetProviderIdByUsername(enterpriseProviderId, username);
            }
        }

        public int? GetUserIdByMappingId(int providerId, string mappingId, bool isEnterpriseUniquessCheckEnabled = false)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.SelfServiceRepository.GetUserIdByMappingId(providerId, mappingId, isEnterpriseUniquessCheckEnabled);
            }
        }

        public string GetUserTokenByUserId(int userId)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.SelfServiceRepository.GetUserTokenByUserId(userId);
            }
        }

        public int? GetProviderIdForUserId(int userId)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.SelfServiceRepository.GetProviderIdForUserId(userId);
            }
        }

        public string GetUserTypeByUserId(int userId)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.SelfServiceRepository.GetUserTypeByUserId(userId);
            }
        }

        public string GetUsernameByUserId(int userId)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.SelfServiceRepository.GetUsernameByUserId(userId);
            }
        }

        public void SetUserTypeForUserId(int userId, string type)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                context.SelfServiceRepository.SetUserTypeForUserId(userId, type);
            }
        }

        public string GetOrgCodeByProviderId(int providerId)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.SelfServiceRepository.GetOrgCodeByProviderId(providerId);
            }
        }

        public string GetSSDisclaimer(int providerId)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.SelfServiceRepository.GetSSDisclaimer(providerId);
            }
        }
        public int? GetProviderIdByOrgCode(string orgCode)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.SelfServiceRepository.GetProviderIdByOrgCode(orgCode);
            }
        }

        /// <summary>
        /// Gets Self Service Auth Options for the given ProviderID
        /// </summary>
        /// <param name="providerId"></param>
        /// <returns>
        /// [dynamic].IsSelfRegistration
        /// [dynamic].AuthType
        /// </returns>
        public dynamic GetSelfServiceAuthOptions(int providerId)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.SelfServiceRepository.GetSelfServiceAuthOptions(providerId);
            }
        }

        public T GetUserAttributeValue<T>(int userId, string commonName, int? providerId = 3)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.SelfServiceRepository.GetUserAttributeValue<T>(userId, commonName, providerId);
            }
        }

        public int CreateSelfServiceWebSession(int userId, string ip)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.SelfServiceRepository.CreateSelfServiceWebSession(userId, ip, SelfServiceDeviceId);
            }
        }

        public void UpdateSelfServiceLastLoggedOnTime(int userId)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                context.SelfServiceRepository.UpdateSelfServiceLastLoggedOnTime(userId);
            }
        }

        public LoginUserDetails GetUserDetailsforSelfServiceLogin(int userId)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.SelfServiceRepository.GetUserDetailsforSelfServiceLogin(userId);
            }
        }

        public LoginPasswordInfo GetUserPasswordInfoforSelfServiceLogin(int userId)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.SelfServiceRepository.GetUserPasswordInfoforSelfServiceLogin(userId);
            }
        }

        public bool GetEnterpriseUniquenessStatus(int providerId)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.SelfServiceRepository.GetEnterpriseUniquenessStatus(providerId);
            }
        }
    }
}
