﻿using AtHoc.Infrastructure.Domain;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Business.Data;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.SelfService.DTO;
using AtHoc.IWS.Business.Domain.Users.Impl;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.IWS.Business.Service;
using AtHoc.Operators;
using AtHoc.Publishing;
using AtHoc.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using User = AtHoc.IWS.Business.Domain.SelfService.DTO.User;

namespace AtHoc.IWS.Business.Domain.SelfService.Impl
{
    public class CredentialRecoveryFacade : FacadeBase<IAtHocContextFactory>, ICredentialRecoveryFacade
    {
        public CredentialRecoveryFacade() : base(AtHocDbContextFactory.CreateFactory()) { }

        /// <summary>
        /// This method sends a username recovery email to the given user email address
        /// 1. Get (top) UserID from Email Address (for sending unique URL email)
        /// 2. Send Username Recovery Email
        /// </summary>
        /// <param name="email">User's Email ID</param>
        /// <param name="providerId">Provider ID</param>
        /// <returns>NULL if email not found, TRUE if email sent, FALSE if email sending generic error</returns>
        public RecoveryRequestStatus RecoverUsername(string email,string provider, int? providerId)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                var users = GetUsersByEmail(email, providerId).GroupBy(x => new { x.UserId, x.Username, x.ProviderId, x.ProviderName, x.Status });
                var activeUsers = users.Where(u => u.Key.Status == "VLD").ToList();
                if (activeUsers.Count == 0) return RecoveryRequestStatus.EmailNotFound;

                var usernames = activeUsers.Aggregate("", (current, user) => current + (user.Key.Username + " (" + user.Key.ProviderId + " - " + user.Key.ProviderName + ")" + Environment.NewLine));

                var activeUser = context.CredentialRecoveryRepository.GetUserById(activeUsers[0].Key.UserId, email);

                if (context.CredentialRecoveryRepository.SaveUsernameRecoveryRequest(email, activeUser.UserId, providerId))
                {
                    var alertManager = new AlertManager(activeUser.ProviderId, 1);
                    var alert = alertManager.CreateAlert();
                    alert.AlertSpec.Content.Header = "Did you forget your username ?";

                    if (activeUsers.Count == 1) alert.AlertSpec.Content.Body = "Your username is : " + usernames;
                    else alert.AlertSpec.Content.Body = "Your usernames are : " + Environment.NewLine + Environment.NewLine + usernames;

                    alert.AlertSpec.Content.Url = ConfigurationManager.GetURL() + (provider == null ? "" : "/SelfService/" + provider);
                    alert.AlertSpec.Targeting.TargetingXml = XElement.Parse("<targeting><user id=\"" + activeUser.UserId + "\" isBlocked=\"N\" /></targeting>");
                    alert.AlertSpec.Delivery.RemoveAllDevices();
                    alert.AlertSpec.Delivery.TargetDevice(activeUser.DeviceId);
                    alert.PublishAtCurrentTime = true;
                    alert.AlertSpec.LiveDuration.Unit = DurationUnit.Minute;
                    alert.AlertSpec.LiveDuration.Value = 15;
                    alert.AlertSpec.Priority = Priority.High;
                    alert.SetStatus(AlertStatus.Scheduled);
                    alert.IsReadyForPublish = true;
                    alert.Origin.Type = OriginType.Test;
                    alertManager.PublishAlert(alert);

                    OperationAuditor.LogAction(activeUser.UserId, activeUser.ProviderId, Infrastructure.EnumUtils<ServiceAction>.GetDescriptionByValue(ServiceAction.SelfServiceForgotUsernameEmailSent), AtHoc.Infrastructure.EnumUtils<EntityType>.GetDescriptionByValue(EntityType.SelfService), activeUser.Username, activeUser.UserId, "MS", email);

                    return RecoveryRequestStatus.RequestRegisteredSuccessfully;
                }

                return RecoveryRequestStatus.RequestRegistrationFailure;
            }
        }

        /// <summary>
        /// This method sends a password recovery email to the given user email address
        /// 1. Get (top) UserID from Email Address (for sending unique URL email)
        /// 2. Generate Unique URL Infrastructure
        /// 3. Send Password Recovery Email
        /// </summary>
        /// <param name="email">User's Email ID</param>
        /// <param name="providerId">Provider ID</param>
        /// <returns>NULL if email not found, TRUE if email sent, FALSE if email sending generic error</returns>
        public RecoveryRequestStatus RecoverPassword(string email, string provider, int? providerId)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                var users = GetUsersByEmail(email, providerId);
                var activeUsers = users.Where(u => u.Status == "VLD").ToList();
                if (activeUsers.Count == 0) return RecoveryRequestStatus.EmailNotFound;
                
                var key = context.CredentialRecoveryRepository.GenerateUniqueKey();

                if (context.CredentialRecoveryRepository.SavePasswordRecoveryRequest(email, activeUsers[0].UserId, key, providerId))
                {
                    var alertManager = new AlertManager(activeUsers[0].ProviderId, 1);
                    var alert = alertManager.CreateAlert();
                    alert.AlertSpec.Content.Header = "Did you forget your password ?";
                    alert.AlertSpec.Content.Body = "Please click on the link below to reset your password.";
                    alert.AlertSpec.Content.Url = ConfigurationManager.GetURL() + "/SelfService/ValidateKey/" + key;
                    if (provider != null)
                        alert.AlertSpec.Content.Url += "/" + provider;
                    alert.AlertSpec.Targeting.TargetingXml = XElement.Parse("<targeting><user id=\"" + activeUsers[0].UserId + "\" isBlocked=\"N\" /></targeting>");
                    alert.AlertSpec.Delivery.RemoveAllDevices();
                    alert.AlertSpec.Delivery.TargetDevice(activeUsers[0].DeviceId);
                    alert.PublishAtCurrentTime = true;
                    alert.AlertSpec.LiveDuration.Unit = DurationUnit.Minute;
                    alert.AlertSpec.LiveDuration.Value = 15;
                    alert.AlertSpec.Priority = Priority.High;
                    alert.SetStatus(AlertStatus.Scheduled);
                    alert.IsReadyForPublish = true;
                    alert.Origin.Type = OriginType.Test;
                    alertManager.PublishAlert(alert);

                    OperationAuditor.LogAction(activeUsers[0].UserId, activeUsers[0].ProviderId, Infrastructure.EnumUtils<ServiceAction>.GetDescriptionByValue(ServiceAction.SelfServiceForgotPasswordEmailSent), Infrastructure.EnumUtils<EntityType>.GetDescriptionByValue(EntityType.SelfService), activeUsers[0].Username, activeUsers[0].UserId, "MS", email);

                    return RecoveryRequestStatus.RequestRegisteredSuccessfully;
                }

                return RecoveryRequestStatus.RequestRegistrationFailure;
            }
        }

        /// <summary>
        /// Validates the Recovery Key
        /// </summary>
        /// <param name="key">The Unique Recovery Key</param>
        /// <returns>NULL if the key is not found or invalid, TRUE if key is valid, FALSE if key is expired</returns>
        public RecoveryKeyStatus ValidateRecoveryKey(string key)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.CredentialRecoveryRepository.ValidateRecoveryKey(key);
            }
        }

        /// <summary>
        /// Gets all the UserIDs associated with the email tagged with the Recovery Key
        /// UserID(s) look up from Email Address (should return all Usernames + Status)
        /// </summary>
        /// <param name="key">The Unique Recovery Key</param>
        /// <param name="providerId">ProviderID</param>
        /// <returns>Returns a set of Users or 0 users if no active users found or NULL if key is expired</returns>
        public IEnumerable<User> GetUsersByRecoveryKey(string key, int? providerId)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                if (context.CredentialRecoveryRepository.ValidateRecoveryKey(key) == RecoveryKeyStatus.KeyValidated)
                {
                    var users = context.CredentialRecoveryRepository.GetUsersByRecoveryKey(key, providerId).GroupBy(x => new { x.UserId, x.Username, x.ProviderId, x.ProviderName, x.Status }).ToList();
                    var activeUsers = users.Where(u => u.Key.Status == "VLD").Select(y => new User()
                    {
                        UserId = y.Key.UserId,
                        Username = y.Key.Username,
                        ProviderId = y.Key.ProviderId,
                        ProviderName = y.Key.ProviderName,
                        Status = y.Key.Status
                    }).ToList();

                    if (users.Count > 0)
                        OperationAuditor.LogAction(activeUsers[0].UserId, activeUsers[0].ProviderId, AtHoc.Infrastructure.EnumUtils<ServiceAction>.GetDescriptionByValue(ServiceAction.PasswordRecoveryKeyValidated), AtHoc.Infrastructure.EnumUtils<EntityType>.GetDescriptionByValue(EntityType.Operator), activeUsers[0].Username, activeUsers[0].UserId, "MS", key);
                    if (users.Count > 0 && activeUsers.Count == 0)
                        OperationAuditor.LogAction(users[0].Key.UserId, users[0].Key.ProviderId, AtHoc.Infrastructure.EnumUtils<ServiceAction>.GetDescriptionByValue(ServiceAction.NoActiveUsersFoundForPasswordChange), AtHoc.Infrastructure.EnumUtils<EntityType>.GetDescriptionByValue(EntityType.Operator), users[0].Key.Username, users[0].Key.UserId, "MS", key);
                    else
                        OperationAuditor.LogAction(activeUsers[0].UserId, activeUsers[0].ProviderId, AtHoc.Infrastructure.EnumUtils<ServiceAction>.GetDescriptionByValue(ServiceAction.ActiveUsersPageAccessedForPasswordChange), AtHoc.Infrastructure.EnumUtils<EntityType>.GetDescriptionByValue(EntityType.Operator), activeUsers[0].Username, activeUsers[0].UserId, "MS", key);
                    
                    return activeUsers;
                }
                return null;
            }
        }

        public IServiceResult<bool> UpdatePassword(int userId, string newPassword, string key)
        {
            IServiceResult<bool> result = new ServiceResult<bool>();
            var ignoreRulesList = new List<PasswordResetIgnoreRules> { PasswordResetIgnoreRules.UpdateFrequency };

            var userFacade = new UserFacade();

            using (var context = ContextFactory.CreateNgaddataContext())
            {
                var operatorUser = context.OperatorUserRepository.FindBySpec(new OperatorUserSpec {UserId = userId}).SingleOrDefault();

                if (operatorUser != null)
                {
                    operatorUser.Password = newPassword;

                    UserSave.SaveUserWithPassword(context, result, operatorUser, false, "", ignoreRulesList);

                    userFacade.UnLockOperator(new OperatorUserSpec {UserId = userId});
                    
                    if (result.IsValid && key != null) context.CredentialRecoveryRepository.LogPasswordUpdate(key);

                    var user = context.CredentialRecoveryRepository.GetUserById(userId);
                    OperationAuditor.LogAction(user.UserId, user.ProviderId, Infrastructure.EnumUtils<ServiceAction>.GetDescriptionByValue(ServiceAction.PasswordChanged),Infrastructure.EnumUtils<EntityType>.GetDescriptionByValue(EntityType.Operator),user.Username, user.UserId, "MS", key);
                }
                else
                {
                    var userUpdateResult = userFacade.UpdatePassword(userId, newPassword, "");
                    
                    if (userUpdateResult.IsValid)
                    {
                        if (key != null) context.CredentialRecoveryRepository.LogPasswordUpdate(key);

                        var user = new UserFacade().GetUserBySpec(new UserSpec { UserId = userId });

                        if (user != null && user.ProviderId.HasValue)
                        {
                            OperationAuditor.LogAction(user.Id, user.ProviderId.Value, Infrastructure.EnumUtils<ServiceAction>.GetDescriptionByValue(ServiceAction.PasswordChanged), Infrastructure.EnumUtils<EntityType>.GetDescriptionByValue(EntityType.EndUsers),user.UserName, user.Id, "MS", key);
                        }
                    }
                    else
                    {
                        return userUpdateResult;
                        
                    }
                }
            }

            return result;
        }

        public IEnumerable<User> GetUsersByEmail(string email, int? providerId)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.CredentialRecoveryRepository.GetUsersByEmail(email, providerId);
            }
        }
    }
}