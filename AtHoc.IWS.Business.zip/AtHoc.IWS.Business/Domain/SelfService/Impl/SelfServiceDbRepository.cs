﻿using System.Data;
using System.Dynamic;
using AtHoc.Infrastructure.Database;
using System;
using System.Collections.Generic;
using AtHoc.IWS.Business.Domain.SelfService.DTO;
using IUnitOfWork = AtHoc.Infrastructure.Data.IUnitOfWork;
using SqlParameter = AtHoc.Infrastructure.Sql.SqlParameter;

namespace AtHoc.IWS.Business.Domain.SelfService.Impl
{
    public class SelfServiceDbRepository : ISelfServiceRepository
    {
        protected DbContext Context { get; set; }

        public SelfServiceDbRepository(IUnitOfWork context)
        {
            Context = context as DbContext;
        }

        public DesktopSessionSearchResult GetDesktopSession(DesktopSessionSearchArgs args)
        {
            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@UserId", args.UserId),
                new SqlParameter("@SessionId", args.SessionId),
            };

            var reader = Context.ExecuteDataReader("SELECT USER_ID, SESSION_ID, SESSION_STATUS_ID, LOGON_TYPE_ID, IP_ADDRESS, CLIENT_VERSION, PROVIDER_ID FROM SSN_SESSION_TAB WITH (NOLOCK) WHERE USER_ID = @UserId AND SESSION_ID = @SessionId", parameters);

            DesktopSessionSearchResult searchResult = null;

            if (reader.Read())
            {
                searchResult = new DesktopSessionSearchResult
                {
                    UserId = Int32.Parse(reader["USER_ID"].ToString()),
                    SessionId = Int32.Parse(reader["SESSION_ID"].ToString()),
                    SessionStatus = reader["SESSION_STATUS_ID"].ToString(),
                    LogonType = reader["LOGON_TYPE_ID"].ToString(),
                    IpAddress = reader["IP_ADDRESS"].ToString(),
                    ClientVersion = reader["CLIENT_VERSION"].ToString(),
                    ProviderId = Int32.Parse(reader["PROVIDER_ID"].ToString())
                };
            }

            return searchResult;
        }

        public int? GetProviderIdByUsername(int providerId, string username)
        {
            var usernameParameter = new SqlParameter("in_username", username);
            var providerParameter = new SqlParameter("in_providerId", providerId);
            var logindIdParameter = new SqlParameter("useLoginId", 1);
            var inEnterpriseHierarchyParameter = new SqlParameter("inEnterpriseHierarchy", 1);

            var reader = Context.ExecuteDataReader("exec dbo.USR_CHECK_USERNAME", usernameParameter, providerParameter, logindIdParameter, inEnterpriseHierarchyParameter);
            if (reader.Read())
            {
                var userId = Int32.Parse(reader["PROVIDER_ID"].ToString());
                return userId;
            }
            return null;
        }

        public int? GetUserIdByUsername(int providerId, string username, bool isEnterpriseUniquessCheckEnabled = false)
        {
            var usernameParameter = new SqlParameter("in_username", username);
            var providerParameter = new SqlParameter("in_providerId", providerId);
            var logindIdParameter = new SqlParameter("useLoginId", 1);
            var inEnterpriseHierarchyParameter = new SqlParameter("@inEnterpriseHierarchy", Convert.ToInt32(isEnterpriseUniquessCheckEnabled));

            var reader = Context.ExecuteDataReader("exec dbo.USR_CHECK_USERNAME", usernameParameter, providerParameter, logindIdParameter, inEnterpriseHierarchyParameter);
            if (reader.Read())
            {
                var userId = Int32.Parse(reader["USER_ID"].ToString());
                return (int)userId;
            }

            return (int?)null;

        }

        public int? GetUserIdByMappingId(int providerId, string mappingId, bool isEnterpriseUniquessCheckEnabled = false)
        {
            var usernameParameter = new SqlParameter("in_username", mappingId);
            var providerParameter = new SqlParameter("in_providerId", providerId);
            var logindIdParameter = new SqlParameter("useLoginId", 0);
            var inEnterpriseHierarchyParameter = new SqlParameter("@inEnterpriseHierarchy", Convert.ToInt32(isEnterpriseUniquessCheckEnabled));

            var reader = Context.ExecuteDataReader("exec dbo.USR_CHECK_USERNAME", usernameParameter, providerParameter, logindIdParameter, inEnterpriseHierarchyParameter);
            if (reader.Read())
            {
                var userId = Int32.Parse(reader["USER_ID"].ToString());
                return (int)userId;
            }

            return (int?)null;            
             
        }

        public string GetUserTokenByUserId(int userId)
        {
            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@UserId", userId),
            };

            const string sql = @"SELECT TOKEN FROM USR_USER_TAB WITH (NOLOCK) WHERE USER_ID = @UserId";

            var token = Context.ExecuteScalar(sql, parameters);

            return token == null ? "" : token.ToString();
        }

        public int? GetProviderIdForUserId(int userId)
        {
            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@UserId", userId),
            };

            const string sql = @"SELECT PROVIDER_ID FROM USR_USER_TAB WITH (NOLOCK) WHERE USER_ID = @UserId";

            var providerId = Context.ExecuteScalar(sql, parameters);

            return providerId == null ? (int?)null : (int)providerId;
        }

       
        public string GetUserTypeByUserId(int userId)
        {
            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@UserId", userId),
            };

            const string sql = @"SELECT USER_TYPE_ID FROM USR_USER_TAB WITH (NOLOCK) WHERE USER_ID = @UserId";

            var status = Context.ExecuteScalar(sql, parameters);

            return status == null ? null : status.ToString();
        }

        public string GetUsernameByUserId(int userId)
        {
            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@UserId", userId),
            };

            const string sql = @"
            SELECT
	            uav.STRING_VALUE
            FROM
	            USR_USER_TAB uu WITH (NOLOCK)
	            INNER JOIN USR_ATTRIBUTE_VALUE_TAB uav WITH (NOLOCK) ON (uav.USER_ID = uu.USER_ID)
	            INNER JOIN PRV_ATTRIBUTE_TAB pa WITH (NOLOCK) ON (pa.ATTRIBUTE_ID = uav.ATTRIBUTE_ID)
            WHERE 
	            uu.USER_ID = @UserId
	            AND pa.COMMON_NAME = 'LOGIN_ID'
                AND pa.ENTITY_ID = 'USER'";

            var username = Context.ExecuteScalar(sql, parameters);

            return username == null ? null : username.ToString();
        }

        public void SetUserTypeForUserId(int userId, string type)
        {
            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@UserId", userId),
                new SqlParameter("@type", type)
            };

            const string sql = @"UPDATE USR_USER_TAB SET USER_TYPE_ID = @type WHERE USER_ID = @UserId";

            Context.ExecuteNonQuery(sql, parameters);
        }


        public string GetOrgCodeByProviderId(int providerId)
        {
            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@ProviderId", providerId),
            };

            const string sql = @"SELECT ORG_CODE FROM PRV_EXTENDED_PARAMS_TAB WITH (NOLOCK) WHERE PROVIDER_ID = @ProviderId";

            var orgCode = Context.ExecuteScalar(sql, parameters);

            return orgCode == null ? null : orgCode.ToString();
        }
        
       public string GetSSDisclaimer(int providerId)
        {
            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@ProviderId", providerId),
            };

            const string sql = @"select SS_SECURITY_DISCLAIMER_TEXT from [dbo].[PRV_EXTENDED_PARAMS_TAB] WITH (NOLOCK) where PROVIDER_ID= @ProviderId";

            var SSDisclaimer = Context.ExecuteScalar(sql, parameters);

            return SSDisclaimer == null ? null : SSDisclaimer.ToString();
        }
        public int? GetProviderIdByOrgCode(string orgCode)
        {
            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@OrgCode", orgCode),
            };

            const string sql = @"SELECT PROVIDER_ID FROM PRV_EXTENDED_PARAMS_TAB WITH (NOLOCK) WHERE ORG_CODE = @OrgCode";

            var providerId = Context.ExecuteScalar(sql, parameters);

            return providerId == null ? (int?)null : (int)providerId;
        }

        /// <summary>
        /// Gets Self Service Auth Options for the given ProviderID
        /// </summary>
        /// <param name="providerId"></param>
        /// <returns>
        /// [dynamic].IsSelfRegistration
        /// [dynamic].AuthType
        /// </returns>
        public dynamic GetSelfServiceAuthOptions(int providerId)
        {
            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@ProviderId", providerId),
            };

            const string sql = @"
                SELECT
	                P.IS_SELF_REGISTRATION, PE.SS_AUTH_OPTION, P.SELFSERVICE_AUTO_SELF_REGISTRATION
                FROM
	                PRV_PROVIDER_TAB P WITH (NOLOCK)
	                INNER JOIN PRV_EXTENDED_PARAMS_TAB PE  WITH (NOLOCK) ON (PE.PROVIDER_ID = P.PROVIDER_ID)
                WHERE
	                P.PROVIDER_ID = @ProviderId";

            var reader = Context.ExecuteDataReader(sql, parameters);

            if (reader.Read())
            {
                dynamic expandoObject = new ExpandoObject();

                expandoObject.IsSelfRegistration = (reader["IS_SELF_REGISTRATION"].ToString() == "Y");
                expandoObject.SelfServiceAutoSelfRegistration = (reader["SELFSERVICE_AUTO_SELF_REGISTRATION"].ToString() == "Y");
                expandoObject.AuthType = reader["SS_AUTH_OPTION"];

                return expandoObject;
            }

            return null;
        }

        public T GetUserAttributeValue<T>(int userId, string commonName, int? providerId = 3)
        {
            #region Attribute Types

            /*
            Number = 1,
            String = 2,
            Memo = 3,
            Date = 4,
            DateTime = 5,
            Picklist = 6,
            MultiPicklist = 7,
            Checkbox = 8,
            Path = 9,
            Geography = 10,
		    Time = 11
            */

            #endregion

            #region Attribute Details

            var prvAttributeParams = new List<SqlParameter>
            {
                new SqlParameter("@ProviderId", providerId),
                new SqlParameter("@CommonName", commonName),
            };

            dynamic prvAttribute = new ExpandoObject();

            using (var prvAttributeTab = Context.ExecuteDataReader("SELECT ATTRIBUTE_ID, ATTRIBUTE_TYPE_ID FROM PRV_ATTRIBUTE_TAB WITH (NOLOCK) WHERE COMMON_NAME = @CommonName AND ENTITY_ID = 'USER' AND PROVIDER_ID = @ProviderId", prvAttributeParams))
            {
                while (prvAttributeTab.Read())
                {
                    prvAttribute.AttributeId = prvAttributeTab["ATTRIBUTE_ID"];
                    prvAttribute.AttributeTypeId = prvAttributeTab["ATTRIBUTE_TYPE_ID"];
                }

                prvAttributeTab.Close();
            }

            #endregion

            #region User Value Details

            var usrValueParams = new List<SqlParameter>
            {
                new SqlParameter("@AttributeId", prvAttribute.AttributeId),
                new SqlParameter("@UserId", userId),
            };

            object usrAttributeValueTab = null;

            if (prvAttribute.AttributeTypeId == 1) // NUMBER
            {
                if (!(typeof(T) == typeof(int) || typeof(T) == typeof(int?))) throw new InvalidOperationException("Invalid datatype specified for given attribute type (expected int or int?)");
                usrAttributeValueTab = Context.ExecuteScalar("SELECT INTEGER_VALUE FROM USR_ATTRIBUTE_VALUE_TAB WITH (NOLOCK) WHERE ATTRIBUTE_ID = @AttributeId AND USER_ID = @UserId", usrValueParams);
            }
            else if (prvAttribute.AttributeTypeId == 2 || prvAttribute.AttributeTypeId == 9) // STRING
            {
                if (typeof(T) != typeof(string)) throw new InvalidOperationException("Invalid datatype specified for given attribute type (expected string)");
                usrAttributeValueTab = Context.ExecuteScalar("SELECT STRING_VALUE FROM USR_ATTRIBUTE_VALUE_TAB WITH (NOLOCK) WHERE ATTRIBUTE_ID = @AttributeId AND USER_ID = @UserId", usrValueParams);
            }
            else if (prvAttribute.AttributeTypeId == 3) // MEMO
            {
                if (typeof(T) != typeof(string)) throw new InvalidOperationException("Invalid datatype specified for given attribute type (expected string)");
                usrAttributeValueTab = Context.ExecuteScalar("SELECT MEMO_VALUE FROM USR_ATTRIBUTE_VALUE_TAB WITH (NOLOCK) WHERE ATTRIBUTE_ID = @AttributeId AND USER_ID = @UserId", usrValueParams);
            }
            else if (prvAttribute.AttributeTypeId == 4 || prvAttribute.AttributeTypeId == 5) // DATE, DATETIME
            {
                if (!(typeof(T) == typeof(DateTime) || typeof(T) == typeof(DateTime?))) throw new InvalidOperationException("Invalid datatype specified for given attribute type (expected datetime or datetime?)");
                usrAttributeValueTab = Context.ExecuteScalar("SELECT DATE_VALUE FROM USR_ATTRIBUTE_VALUE_TAB WITH (NOLOCK) WHERE ATTRIBUTE_ID = @AttributeId AND USER_ID = @UserId", usrValueParams);
            }
            else if (prvAttribute.AttributeTypeId == 6 || prvAttribute.AttributeTypeId == 8) // PICKLIST, CHECKBOX
            {
                if (!(typeof(T) == typeof(int) || typeof(T) == typeof(int?) || typeof(T) == typeof(bool) || typeof(T) == typeof(bool?) || typeof(T) == typeof(string))) throw new InvalidOperationException("Invalid datatype specified for given attribute type (expected int, int?, bool, bool? or string)");

                if (typeof(T) == typeof(int) || typeof(T) == typeof(int?))
                {
                    usrAttributeValueTab = Context.ExecuteScalar("SELECT pav.VALUE_ID FROM USR_ATTRIBUTE_VALUE_TAB uav WITH (NOLOCK) INNER JOIN PRV_ATTRIBUTE_VALUE_TAB pav WITH (NOLOCK) ON (pav.ATTRIBUTE_ID = uav.ATTRIBUTE_ID AND pav.VALUE_ID = uav.VALUE_ID) WHERE uav.USER_ID = @UserId AND uav.ATTRIBUTE_ID = @AttributeId", usrValueParams);
                }
                else if (typeof(T) == typeof(bool) || typeof(T) == typeof(bool?))
                {
                    if (prvAttribute.AttributeTypeId != 8) throw new InvalidOperationException("Invalid datatype specified for given attribute type (expected bool or bool?)");
                    usrAttributeValueTab = (Context.ExecuteScalar("SELECT pav.COMMON_NAME FROM USR_ATTRIBUTE_VALUE_TAB uav WITH (NOLOCK) INNER JOIN PRV_ATTRIBUTE_VALUE_TAB pav WITH (NOLOCK) ON (pav.ATTRIBUTE_ID = uav.ATTRIBUTE_ID AND pav.VALUE_ID = uav.VALUE_ID) WHERE uav.USER_ID = @UserId AND uav.ATTRIBUTE_ID = @AttributeId", usrValueParams).ToString() == "YES");
                }
                else if (typeof(T) == typeof(string))
                {
                    usrAttributeValueTab = Context.ExecuteScalar("SELECT pav.VALUE_NAME FROM USR_ATTRIBUTE_VALUE_TAB uav WITH (NOLOCK) INNER JOIN PRV_ATTRIBUTE_VALUE_TAB pav WITH (NOLOCK) ON (pav.ATTRIBUTE_ID = uav.ATTRIBUTE_ID AND pav.VALUE_ID = uav.VALUE_ID) WHERE uav.USER_ID = @UserId AND uav.ATTRIBUTE_ID = @AttributeId", usrValueParams);
                }
            }
            else if (prvAttribute.AttributeTypeId == 7) // MULTI-PICKLIST
            {
                throw new NotImplementedException();
            }
            else if (prvAttribute.AttributeTypeId == 10) // GEO
            {
                throw new NotImplementedException();
            }
            else if (prvAttribute.AttributeTypeId == 11) // TIME
            {
                throw new NotImplementedException();
            }

            #endregion

            #region Return Value or Default

            var t = typeof(T);
            t = Nullable.GetUnderlyingType(t) ?? t;
            return (usrAttributeValueTab == null || DBNull.Value.Equals(usrAttributeValueTab)) ? default(T) : (T)Convert.ChangeType(usrAttributeValueTab, t); //Coalesce to set the safe value using default(t) or the safe type.

            #endregion
        }

        public int CreateSelfServiceWebSession(int userId, string clientIp, int deviceId)
        {
            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@sessionId", 0, null, ParameterDirection.InputOutput),
                new SqlParameter("@userId", userId),
                new SqlParameter("@sessionType", "WEB"),
                new SqlParameter("@deviceId", deviceId),
                new SqlParameter("@deviceIP", clientIp)
            };

            Context.ExecuteStoredProcedure(@"dbo.USR_SESSION_SIGNON", parameters.ToArray());

            return (int)parameters[0].OutputValue;
        }

        public void UpdateSelfServiceLastLoggedOnTime(int userId)
        {
            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@UserId", userId),
            };

            const string sql = @"
DECLARE @ATTRIBUTE_ID INT = (SELECT ATTRIBUTE_ID FROM PRV_ATTRIBUTE_TAB WITH (NOLOCK) WHERE COMMON_NAME = 'SS-LAST-SIGNON' AND ENTITY_ID = 'USER')

IF EXISTS (select 0 from USR_ATTRIBUTE_VALUE_TAB WITH (NOLOCK) where [USER_ID] = @UserId AND ATTRIBUTE_ID = @ATTRIBUTE_ID) 
	UPDATE USR_ATTRIBUTE_VALUE_TAB
	SET
		UPDATED_ON = dbo.GET_DATE_AS_SECONDS(GETDATE()),
		UPDATED_BY = @UserId,
		DATE_VALUE = GETDATE()
	WHERE
		[USER_ID] = @UserId AND ATTRIBUTE_ID = @ATTRIBUTE_ID
ELSE
	INSERT INTO 
		USR_ATTRIBUTE_VALUE_TAB ([USER_ID], ATTRIBUTE_ID, UPDATED_ON, UPDATED_BY, DATE_VALUE) 
    VALUES (@UserId, @ATTRIBUTE_ID, dbo.GET_DATE_AS_SECONDS(GETDATE()), @UserId, GETDATE())
";

            Context.ExecuteNonQuery(sql, parameters);
        }

        public LoginUserDetails GetUserDetailsforSelfServiceLogin(int userId)
        {
            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@UserId", userId),
            };

            const string sql = @"
DECLARE @LOGIN_ID INT = (SELECT ATTRIBUTE_ID FROM PRV_ATTRIBUTE_TAB WITH (NOLOCK) WHERE COMMON_NAME = 'LOGIN_ID' AND ENTITY_ID = 'USER')
DECLARE @DISPLAYNAME INT = (SELECT ATTRIBUTE_ID FROM PRV_ATTRIBUTE_TAB WITH (NOLOCK) WHERE COMMON_NAME = 'DISPLAYNAME' AND ENTITY_ID = 'USER')
DECLARE @STATUS INT = (SELECT ATTRIBUTE_ID FROM PRV_ATTRIBUTE_TAB WITH (NOLOCK) WHERE COMMON_NAME = 'STATUS' AND ENTITY_ID = 'USER')

SELECT
	u.[USER_ID], u.PROVIDER_ID, uav_un.STRING_VALUE AS LOGIN_ID, uav_dn.STRING_VALUE AS DISPLAYNAME, pa_stsval.COMMON_NAME AS [STATUS]
FROM
	USR_USER_TAB u WITH (NOLOCK)
	LEFT OUTER JOIN USR_ATTRIBUTE_VALUE_TAB uav_un WITH (NOLOCK) ON (uav_un.USER_ID = u.USER_ID AND uav_un.ATTRIBUTE_ID = @LOGIN_ID)
	LEFT OUTER JOIN USR_ATTRIBUTE_VALUE_TAB uav_dn WITH (NOLOCK) ON (uav_dn.USER_ID = u.USER_ID AND uav_dn.ATTRIBUTE_ID = @DISPLAYNAME)
	LEFT OUTER JOIN USR_ATTRIBUTE_VALUE_TAB uav_sts WITH (NOLOCK) ON (uav_sts.USER_ID = u.USER_ID AND uav_sts.ATTRIBUTE_ID = @STATUS)
	LEFT OUTER JOIN PRV_ATTRIBUTE_VALUE_TAB pa_stsval WITH (NOLOCK) ON (pa_stsval.VALUE_ID = uav_sts.VALUE_ID)
WHERE
	u.[USER_ID] = @UserId";

            var reader = Context.ExecuteDataReader(sql, parameters);

            if (reader.Read())
            {
                var loginUserDetails = new LoginUserDetails
                {
                    Id = Int32.Parse(reader["USER_ID"].ToString()),
                    ProviderId = Int32.Parse(reader["PROVIDER_ID"].ToString()),
                    UserName = reader["LOGIN_ID"].ToString(),
                    DisplayName = reader["DISPLAYNAME"].ToString(),
                    Status = reader["STATUS"].ToString()
                };

                return loginUserDetails;
            }

            return null;
        }

        public LoginPasswordInfo GetUserPasswordInfoforSelfServiceLogin(int userId)
        {
            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@UserId", userId),
            };

            const string sql = @"
SELECT
	u.[USER_ID], uav_pw.STRING_VALUE AS USR_PSWD, uav_rnd.STRING_VALUE AS USER_RANDOM_ID
FROM
	USR_USER_TAB u WITH (NOLOCK)
	INNER JOIN USR_ATTRIBUTE_VALUE_TAB uav_pw WITH (NOLOCK) ON (uav_pw.USER_ID = u.USER_ID)
	INNER JOIN PRV_ATTRIBUTE_TAB pa_pw WITH (NOLOCK) ON (pa_pw.ATTRIBUTE_ID = uav_pw.ATTRIBUTE_ID)
	INNER JOIN USR_ATTRIBUTE_VALUE_TAB uav_rnd WITH (NOLOCK) ON (uav_rnd.USER_ID = u.USER_ID)
	INNER JOIN PRV_ATTRIBUTE_TAB pa_rnd WITH (NOLOCK) ON (pa_rnd.ATTRIBUTE_ID = uav_rnd.ATTRIBUTE_ID)
WHERE
	pa_pw.COMMON_NAME = 'USR_PSWD' AND pa_pw.ENTITY_ID = 'USER'
	AND pa_rnd.COMMON_NAME = 'USER_RANDOM_ID' AND pa_rnd.ENTITY_ID = 'USER'
	AND u.[USER_ID] = @UserId";

            var reader = Context.ExecuteDataReader(sql, parameters);

            if (reader.Read())
            {
                var loginPasswordInfo = new LoginPasswordInfo
                {
                    Id = Int32.Parse(reader["USER_ID"].ToString()),
                    Password = reader["USR_PSWD"].ToString(),
                    UserRandomId = reader["USER_RANDOM_ID"].ToString()
                };

                return loginPasswordInfo;
            }

            return null;
        }

        public bool GetEnterpriseUniquenessStatus(int providerId)
        {
            var isEnterpriseUniquenessEnabled = false;
            var providerParameter = new SqlParameter("@providerId", providerId);

            var reader = Context.ExecuteDataReader("exec dbo.PRV_GET_FEATURES_MATRIX", providerParameter);
            while (reader.Read())
            {
                if (reader["key_name"].Equals("IsUserUniqueAcrossEnterprise"))
                {
                    isEnterpriseUniquenessEnabled = reader["value"].ToString().ToLower().Equals("true", StringComparison.OrdinalIgnoreCase);
                    break;
                }
            }
            return isEnterpriseUniquenessEnabled;
        }
    }
}