﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Database;
using AtHoc.Infrastructure.Sql;
using AtHoc.IWS.Business.Domain.SelfService.DTO;
using Dapper;

namespace AtHoc.IWS.Business.Domain.SelfService.Impl
{
	public class CredentialRecoveryDbRepository : ICredentialRecoveryRepository
	{
        protected DbContext Context { get; set; }

        public CredentialRecoveryDbRepository(IUnitOfWork context)
	    {
	        Context = context as DbContext;
	    }

	    public IEnumerable<User> GetUsersByEmail(string email, int? providerId)
	    {
            var getUsersByEmail = @"SELECT DISTINCT
	            u.[USER_ID] AS UserId, CASE WHEN rr.[USER_ID] IS NOT NULL THEN 'OPR' ELSE 'USR' END AS Usertype, uav_un.STRING_VALUE AS Username, u.PROVIDER_ID as ProviderId, pp.PROVIDER_NAME as ProviderName, av_status.COMMON_NAME AS [Status], da.[ADDRESS] AS Email, da.DEVICE_ID as DeviceId
            FROM
	            USR_USER_TAB u
	            INNER JOIN USR_ATTRIBUTE_VALUE_TAB uav_un ON (uav_un.[USER_ID] = u.[USER_ID])
	            INNER JOIN PRV_ATTRIBUTE_TAB a_un ON (a_un.ATTRIBUTE_ID = uav_un.ATTRIBUTE_ID AND a_un.COMMON_NAME = 'LOGIN_ID')
	            INNER JOIN USR_ATTRIBUTE_VALUE_TAB uav_status ON (uav_status.[USER_ID] = u.[USER_ID])
	            INNER JOIN PRV_ATTRIBUTE_VALUE_TAB av_status ON (av_status.ATTRIBUTE_ID = uav_status.ATTRIBUTE_ID AND av_status.VALUE_ID = uav_status.VALUE_ID)
	            INNER JOIN PRV_ATTRIBUTE_TAB a_status ON (a_status.ATTRIBUTE_ID = av_status.ATTRIBUTE_ID AND a_status.COMMON_NAME = 'STATUS')
	            INNER JOIN USR_DEVICE_ADDRESS_TAB da ON (da.[USER_ID] = u.[USER_ID])
	            INNER JOIN DLV_DEVICE_TAB d ON (d.DEVICE_ID = da.DEVICE_ID)
	            INNER JOIN DLV_DEVICE_GROUP_TAB g ON (g.GROUP_ID = d.GROUP_ID AND g.COMMON_NAME = 'EMAIL')
                INNER JOIN PRV_PROVIDER_TAB pp ON (pp.PROVIDER_ID = u.PROVIDER_ID)
                LEFT OUTER JOIN UPS_USER_ROLE_TAB rr ON (rr.USER_ID = u.USER_ID)
            WHERE
	            da.[ADDRESS] = @Email
            ";

	        if (providerId.HasValue) // GET OPERATORS AND END USERS FOR GIVEN PROVIDER ID
	        {
	            getUsersByEmail += " AND pp.PROVIDER_ID = @ProviderID";
	        }
	        else // GET ONLY OPERATORS
	        {
                getUsersByEmail += " AND rr.USER_ID IS NOT NULL";
	        }

            getUsersByEmail += " ORDER BY uav_un.STRING_VALUE";

            return Context.connection.Query<User>(getUsersByEmail, new { Email = email, ProviderID = providerId });
	    }

        public User GetUserById(int userId, string email = null)
        {
            string getUserById = @"SELECT DISTINCT
	            u.[USER_ID] AS UserId, CASE WHEN rr.[USER_ID] IS NOT NULL THEN 'OPR' ELSE 'USR' END AS Usertype, uav_un.STRING_VALUE AS Username, u.PROVIDER_ID as ProviderId, pp.PROVIDER_NAME as ProviderName, av_status.COMMON_NAME AS [Status], da.[ADDRESS] AS Email, da.DEVICE_ID as DeviceId
            FROM
	            USR_USER_TAB u
	            INNER JOIN USR_ATTRIBUTE_VALUE_TAB uav_un ON (uav_un.[USER_ID] = u.[USER_ID])
	            INNER JOIN PRV_ATTRIBUTE_TAB a_un ON (a_un.ATTRIBUTE_ID = uav_un.ATTRIBUTE_ID AND a_un.COMMON_NAME = 'LOGIN_ID')
	            INNER JOIN USR_ATTRIBUTE_VALUE_TAB uav_status ON (uav_status.[USER_ID] = u.[USER_ID])
	            INNER JOIN PRV_ATTRIBUTE_VALUE_TAB av_status ON (av_status.ATTRIBUTE_ID = uav_status.ATTRIBUTE_ID AND av_status.VALUE_ID = uav_status.VALUE_ID)
	            INNER JOIN PRV_ATTRIBUTE_TAB a_status ON (a_status.ATTRIBUTE_ID = av_status.ATTRIBUTE_ID AND a_status.COMMON_NAME = 'STATUS')
	            INNER JOIN USR_DEVICE_ADDRESS_TAB da ON (da.[USER_ID] = u.[USER_ID])
	            INNER JOIN DLV_DEVICE_TAB d ON (d.DEVICE_ID = da.DEVICE_ID)
	            INNER JOIN DLV_DEVICE_GROUP_TAB g ON (g.GROUP_ID = d.GROUP_ID AND g.COMMON_NAME = 'EMAIL')
                INNER JOIN PRV_PROVIDER_TAB pp ON (pp.PROVIDER_ID = u.PROVIDER_ID)
                LEFT OUTER JOIN UPS_USER_ROLE_TAB rr ON (rr.USER_ID = u.USER_ID)
            WHERE
	            u.[USER_ID] = @UserId
            ";

            if (!String.IsNullOrEmpty(email))
            {
                getUserById += " AND da.[ADDRESS] = @Email";
            }

            return Context.connection.Query<User>(getUserById, new { UserId = userId, Email = email }).FirstOrDefault();
        }

	    public string GenerateUniqueKey()
	    {
	        return Guid.NewGuid().ToString();
	    }

        public bool SaveUsernameRecoveryRequest(string email, int userId, int? providerId)
        {
            const string requestUsernameRecovery = @"INSERT INTO [dbo].[USR_CREDENTIAL_RECOVERY_TAB]
            ([EMAIL],[USER_ID],[PROVIDER_ID],[REQUESTED_ON],[REQUEST_IP_ADDRESS],[RECOVERY_TYPE])
            VALUES (@EMAIL,@USER_ID,@PROVIDER_ID,@REQUESTED_ON,@REQUEST_IP_ADDRESS,@RECOVERY_TYPE)";

            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@EMAIL", email),
                new SqlParameter("@USER_ID", userId),
                new SqlParameter("@PROVIDER_ID", providerId),
                new SqlParameter("@REQUESTED_ON", DateTime.Now),
                new SqlParameter("@REQUEST_IP_ADDRESS", GetIP()),
                new SqlParameter("@RECOVERY_TYPE", "USERNAME"),
            };

            return Context.ExecuteNonQuery(requestUsernameRecovery, parameters) > 0;
        }

        public bool SavePasswordRecoveryRequest(string email, int userId, string key, int? providerId)
	    {
            const string requestPasswordRecovery = @"INSERT INTO [dbo].[USR_CREDENTIAL_RECOVERY_TAB]
            ([EMAIL],[USER_ID],[PROVIDER_ID],[REQUESTED_ON],[REQUEST_IP_ADDRESS],[RECOVERY_TYPE],[RECOVERY_KEY])
            VALUES (@EMAIL,@USER_ID,@PROVIDER_ID,@REQUESTED_ON,@REQUEST_IP_ADDRESS,@RECOVERY_TYPE,@RECOVERY_KEY)";

            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@EMAIL", email),
                new SqlParameter("@USER_ID", userId),
                new SqlParameter("@PROVIDER_ID", providerId),
                new SqlParameter("@REQUESTED_ON", DateTime.Now),
                new SqlParameter("@REQUEST_IP_ADDRESS", GetIP()),
                new SqlParameter("@RECOVERY_TYPE", "PASSWORD"),
                new SqlParameter("@RECOVERY_KEY", key),
            };

            return Context.ExecuteNonQuery(requestPasswordRecovery, parameters) > 0;
	    }

        public RecoveryKeyStatus ValidateRecoveryKey(string key)
	    {
	        var validated = RecoveryKeyStatus.KeyValidated;

	        const string validateKey = @"
                SELECT TOP 1
	                EMAIL, [USER_ID], REQUESTED_ON, RECOVERY_KEY, RESET_ON
                FROM
	                USR_CREDENTIAL_RECOVERY_TAB
                WHERE
	                [USER_ID] IN (SELECT [USER_ID] FROM USR_CREDENTIAL_RECOVERY_TAB WHERE RECOVERY_KEY = @Key)
	                AND RECOVERY_KEY IS NOT NULL
                ORDER BY
	                REQUESTED_ON DESC";

            var parameters = new List<SqlParameter> { new SqlParameter("@Key", key) };
            
            var keyDR = Context.ExecuteDataReader(validateKey, parameters);

	        if (keyDR.Read())
	        {
	            if (keyDR["RECOVERY_KEY"].ToString() != key)
	            {
	                validated = RecoveryKeyStatus.KeyExpired;
	            }
	            else if (((DateTime) keyDR["REQUESTED_ON"]).AddMinutes(15) < DateTime.Now)
	            {
	                validated = RecoveryKeyStatus.KeyExpired;
	            }
	            else if (keyDR["RESET_ON"] != DBNull.Value)
	            {
	                validated = RecoveryKeyStatus.KeyAlreadyUsed;
	            }
	        }
	        else
	        {
	            validated = RecoveryKeyStatus.KeyNotFound;
	        }

            keyDR.Close();

            return validated;
	    }

        public IEnumerable<User> GetUsersByRecoveryKey(string key, int? providerId)
	    {
            var getUsersByKey = @"SELECT DISTINCT
	            u.[USER_ID] AS UserId, CASE WHEN rr.[USER_ID] IS NOT NULL THEN 'OPR' ELSE 'USR' END AS Usertype, uav_un.STRING_VALUE AS Username, u.PROVIDER_ID as ProviderId, pp.PROVIDER_NAME as ProviderName, av_status.COMMON_NAME AS [Status], da.[ADDRESS] AS Email, da.DEVICE_ID as DeviceId
            FROM
	            USR_USER_TAB u
	            INNER JOIN USR_ATTRIBUTE_VALUE_TAB uav_un ON (uav_un.[USER_ID] = u.[USER_ID])
	            INNER JOIN PRV_ATTRIBUTE_TAB a_un ON (a_un.ATTRIBUTE_ID = uav_un.ATTRIBUTE_ID AND a_un.COMMON_NAME = 'LOGIN_ID')
	            INNER JOIN USR_ATTRIBUTE_VALUE_TAB uav_status ON (uav_status.[USER_ID] = u.[USER_ID])
	            INNER JOIN PRV_ATTRIBUTE_VALUE_TAB av_status ON (av_status.ATTRIBUTE_ID = uav_status.ATTRIBUTE_ID AND av_status.VALUE_ID = uav_status.VALUE_ID)
	            INNER JOIN PRV_ATTRIBUTE_TAB a_status ON (a_status.ATTRIBUTE_ID = av_status.ATTRIBUTE_ID AND a_status.COMMON_NAME = 'STATUS')
	            INNER JOIN USR_DEVICE_ADDRESS_TAB da ON (da.[USER_ID] = u.[USER_ID])
	            INNER JOIN DLV_DEVICE_TAB d ON (d.DEVICE_ID = da.DEVICE_ID)
	            INNER JOIN DLV_DEVICE_GROUP_TAB g ON (g.GROUP_ID = d.GROUP_ID AND g.COMMON_NAME = 'EMAIL')
	            INNER JOIN USR_CREDENTIAL_RECOVERY_TAB r ON (r.EMAIL = da.[ADDRESS])
                INNER JOIN PRV_PROVIDER_TAB pp ON (pp.PROVIDER_ID = u.PROVIDER_ID)
                LEFT OUTER JOIN UPS_USER_ROLE_TAB rr ON (rr.USER_ID = u.USER_ID)
            WHERE
	            r.RECOVERY_KEY = @Key";

            if (providerId.HasValue) // GET OPERATORS AND END USERS FOR GIVEN PROVIDER ID
            {
                getUsersByKey += " AND pp.PROVIDER_ID = @ProviderID";
            }
            else // GET ONLY OPERATORS
            {
                getUsersByKey += " AND rr.USER_ID IS NOT NULL";
            }

            getUsersByKey += " ORDER BY uav_un.STRING_VALUE";

            return Context.connection.Query<User>(getUsersByKey, new { Key = key, ProviderID = providerId });
	    }

        public bool LogPasswordUpdate(string key)
        {
            const string logPasswordUpdate = @"UPDATE
                USR_CREDENTIAL_RECOVERY_TAB
                SET RESET_ON = @RESET_ON, RESET_IP_ADDRESS = @RESET_IP_ADDRESS
                WHERE RECOVERY_KEY = @KEY";

            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@RESET_ON", DateTime.Now),
                new SqlParameter("@RESET_IP_ADDRESS", GetIP()),
                new SqlParameter("@KEY", key)
            };

            return Context.ExecuteNonQuery(logPasswordUpdate, parameters) == 1;
        }

        private static String GetIP()
        {
            try
            {
                var ip = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
                if (string.IsNullOrEmpty(ip)) ip = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
                return ip;
            }
            catch
            {
                return "0.0.0.0";
            }
            
        }
	}
}