﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.Notification;
using AtHoc.IWS.Map;
using Microsoft.Practices.Unity.InterceptionExtension;
using Type = AtHoc.IWS.Map.Geometry.Type;

namespace AtHoc.IWS.Business.Domain.Map.Impl
{
    public class MapFacade: IMapFacade
    {

        private readonly INotificationRepository _repository;


        public MapFacade(INotificationRepository repository)
        {
            _repository = repository;
        }
        public string InsertIntersectedCountyFips(string geoJsonStr)
        {
            var counties = PoliticalAreasFactory.CreatePoliticalAreas(PoliticalAreasFactory.AreaType.County);
            var inputFC = new FeatureCollection(geoJsonStr);
            foreach (var f in inputFC.Features)
            {
                if (f.Geometry.Type == Type.Point)
                {
                    continue;
                }
	            var objectId = Convert.ToInt32(f.Attributes["OBJECTID"].ToString());
				var fipsCollection = counties.Intersect(objectId);
				if (fipsCollection == null || fipsCollection.Count == 0)
                {
                    continue;
                } 
               
                f.AddProperty("fips", fipsCollection);
            }

            return inputFC.ToJsonString();
        }

        public string RemoveFips(string geoJsonStr)
        {
            var inputFC = new FeatureCollection(geoJsonStr);
            foreach (var f in inputFC.Features)
            {
                if (f.Geometry.Type == Type.Point)
                {
                    continue;
                }
                f.RemoveProperty("fips");
            }

            return inputFC.ToJsonString();
        }

        public IList<MapLayer> GetDisplayOnlyLayersMetadata(int providerId)
        {
            var mapLayers = _repository.GetActiveMapLayers(providerId);
            return  mapLayers.ToList();
        }

        public IList<MapLayer> GetSelectableLayersMetadata(int providerId)
        {
            var mapLayers = _repository.GetActiveMapLayers(providerId);
            return
                mapLayers.Where(x => string.IsNullOrEmpty(x.IsDisplayOnly) || x.IsDisplayOnly.ToLower() == "n").ToList();

        }

        public IList<ShapeNotification> GetShapesByLayerId(int providerId, int layerId)
        {
            return _repository.GetShapesByLayerId(layerId);
        }

		public int CreateShapeInSharedLayer(int providerId, string geographyWkt, int spatialId)
	    {
			return _repository.CreateOrUpdateShapeInSharedLayer(providerId, geographyWkt,spatialId);
	    }
    }
}
