﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Domain.Notification;
using AtHoc.IWS.Business.Mappings;

namespace AtHoc.IWS.Business.Domain.Map
{
    public interface IMapFacade
    {
        string InsertIntersectedCountyFips(string geoJsonStr);
        string RemoveFips(string geoJsonStr);

        IList<MapLayer> GetDisplayOnlyLayersMetadata(int providerId);

        IList<MapLayer> GetSelectableLayersMetadata(int providerId);

        IList<ShapeNotification> GetShapesByLayerId(int providerId, int layerId);


	    int CreateShapeInSharedLayer(int providerId, string geographyWkt,int spatialId);

    }
}
