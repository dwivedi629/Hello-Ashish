﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Map.Geometry;
using Type = AtHoc.IWS.Map.Geometry.Type;
using GeoJSON.Net;
using Newtonsoft.Json;

namespace AtHoc.IWS.Map
{
    public class Feature
    {
        internal Feature(IDictionary<string, object> attributes, IGeometry geometry)
        {
            Attributes = attributes;
            Geometry = geometry;
        }
        public IGeometry Geometry { get; set; }
        public IDictionary<string, object> Attributes { get; set; }
        public void AddProperty(string name, object value)
        {
            if (Attributes.ContainsKey(name))
            {
                Attributes[name] = value;
            }
            else
            {
                Attributes.Add(name, value);
            }
        }

        public void RemoveProperty(string name)
        {
            if (Attributes.ContainsKey(name))
            {
                Attributes.Remove(name);
            }
        }
    }

    public class FeatureCollection
    {
        public FeatureCollection()
        {
            Features = new Collection<Feature>();
        }
        public FeatureCollection(string geoJsonStr): this()
        {
            _fc = JsonConvert.DeserializeObject<GeoJSON.Net.Feature.FeatureCollection>(geoJsonStr);
            foreach (var f in _fc.Features)
            {
                var wkt = string.Empty;
                var type = Type.Point;
                var geoJsonType = f.Geometry.Type;
                switch (geoJsonType)
                {
                    case GeoJSONObjectType.Polygon:
                        wkt = ConvertToPolygonWkt(((GeoJSON.Net.Geometry.Polygon)f.Geometry).Coordinates);
                        type = Type.Polygon;
                        break;
                    case GeoJSONObjectType.MultiPolygon:
                        wkt = ConvertToMultiPolygonWkt(((GeoJSON.Net.Geometry.MultiPolygon)f.Geometry).Coordinates);
                        type = Type.MultiPolygon;
                        break;
                    case GeoJSONObjectType.Point:
                        wkt = ConvertToPointWkt((GeoJSON.Net.Geometry.Point)f.Geometry);
                        type = Type.Point;
                        break;
                    case GeoJSONObjectType.LineString:
                        break;
                }
                var geometry = new Geometry.Geometry(type, wkt);
                var feature = new Feature(f.Properties, geometry);
                Features.Add(feature);
            }
        }
        private readonly GeoJSON.Net.Feature.FeatureCollection _fc;
        public ICollection<Feature> Features { get; set; }
        public string ToJsonString()
        {
            var geoJsonStr = JsonConvert.SerializeObject(_fc, Formatting.None, new JsonSerializerSettings{NullValueHandling = NullValueHandling.Ignore});
            return geoJsonStr;
        }

        private static string ConvertToPointWkt(GeoJSON.Net.Geometry.Point point)
        {
            if (point == null)
                return null;
            var geoPosition = point.Coordinates as GeoJSON.Net.Geometry.GeographicPosition;
            if (geoPosition == null)
            {
                return null;
            }
            var pointWkt = new StringBuilder("POINT(");
            pointWkt.Append(geoPosition.Longitude + " " + geoPosition.Latitude);
            pointWkt.Append(")");
            return pointWkt.ToString();
        }
        private static string ConvertToPolygonWkt(ICollection<GeoJSON.Net.Geometry.LineString> coordinates)
        {
            if (coordinates == null || coordinates.Count < 1)
                return null;

            var polygonWkt = new StringBuilder("POLYGON(");
            polygonWkt.Append(GetCoordinatesWkt(coordinates));
            polygonWkt.Append(")");
            return polygonWkt.ToString();
        }

        private static string ConvertToMultiPolygonWkt(ICollection<GeoJSON.Net.Geometry.Polygon> polygons)
        {
            if (polygons == null || polygons.Count < 1)
                return null;

            var multiPolygonWkt = new StringBuilder("MULTIPOLYGON(");
            foreach (var polygon in polygons)
            {
                multiPolygonWkt.Append("(");
                multiPolygonWkt.Append(GetCoordinatesWkt(polygon.Coordinates));
                multiPolygonWkt.Append("),");
            }
            multiPolygonWkt.Remove(multiPolygonWkt.Length - 1, 1);  // remove trailing extra ","
            multiPolygonWkt.Append(")");
            return multiPolygonWkt.ToString();
        }

        private static string GetCoordinatesWkt(IEnumerable<GeoJSON.Net.Geometry.LineString> coordinates)
        {
            var coordWkt = new StringBuilder();
            foreach (var coordinate in coordinates)
            {
                coordWkt.Append("(");
                foreach (var position in coordinate.Coordinates)
                {

                    coordWkt.Append(((GeoJSON.Net.Geometry.GeographicPosition)position).Longitude);
                    coordWkt.Append(" ");
                    coordWkt.Append(((GeoJSON.Net.Geometry.GeographicPosition)position).Latitude);
                    coordWkt.Append(",");
                }
                coordWkt.Remove(coordWkt.Length - 1, 1); // remove trailing extra ", "
                coordWkt.Append(")");
                coordWkt.Append(",");
            }
            coordWkt.Remove(coordWkt.Length - 1, 1);
            return coordWkt.ToString();
        }
    }
}
