﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Map
{
    public class PoliticalAreasFactory
    {
        public enum AreaType
        {
            County, State
        }

        public static IPoliticalAreas CreatePoliticalAreas(AreaType type)
        {
            IPoliticalAreas areas = null;
            switch (type)
            {
                case AreaType.County:
                    areas = new Counties();
                    break;
            }
            return areas;
        }
    }
}
