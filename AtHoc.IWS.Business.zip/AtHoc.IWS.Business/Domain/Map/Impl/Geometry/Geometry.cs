﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity.Spatial;

namespace AtHoc.IWS.Map.Geometry
{
    public interface IGeometry
    {
        string Wkt { get; }
        DbGeography EfGeography { get; }
        //string GeoJsonGeometry { get; }
        Type Type { get; }
    }

    public class Geometry: IGeometry
    {
        public Geometry(Type type, string wkt)
        {
            Type = type;
            EfGeography = DbGeography.FromText(wkt);
            Wkt = wkt;
        }
        public Geometry(DbGeography geography)
        {
            EfGeography = geography;
            Wkt = geography.AsText();
        }
        public string Wkt { get; set; }
        public DbGeography EfGeography { get; set; }
        public Type Type { get; set; }
    }

    public enum Type
    {
        Point, Polygon, MultiPolygon
    }
}
