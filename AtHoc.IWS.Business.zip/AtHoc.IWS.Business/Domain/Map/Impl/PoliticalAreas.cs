﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Diagnostics;
using AtHoc.Infrastructure.Sql;
using AtHoc.IWS.Business.Database;
using System.Data.Entity.Spatial;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Map.Geometry;

namespace AtHoc.IWS.Map
{
    public enum PoliticalAreaType
    {
        UsCounty, UsState, Country
    }

    public interface IPoliticalAreas
    {
        PoliticalAreaType Type { get; }
        IList<Fips> Intersect(int spatialId);
    }
    public class Counties: IPoliticalAreas
    {
        public IList<Fips> Intersect(int spatialId)
        {
			object[] parameters = { spatialId };
	        try
	        {
		        using (var context = new AtHocDbContext())
		        {
			        var fipsCollection =
				        context.Database.SqlQuery<Fips>("GEO_GET_INTERSECTING_COUNTIES {0}", parameters).ToList();
			        fipsCollection.ForEach(o =>
			        {
				        o.code = "0" + o.code;
			        });
			        return fipsCollection;
		        }
	        }
	        catch (Exception ex)
	        {
				EventLogger.WriteError("failed to get Intersecting polygons", ex);
				return null; 
	        }
        }
        public PoliticalAreaType Type
        {
            get
            {
                return PoliticalAreaType.UsCounty;
            }
        }
    }
    public class Fips
    {
	    public Fips()
	    {
		    
	    }
        public Fips(string name, string code)
        {
            this.name = name;
            this.code = code;
        }

        //make public properties as lower case for json result
        public string name { get; set; }
        public string code { get; set; }
    }
}
