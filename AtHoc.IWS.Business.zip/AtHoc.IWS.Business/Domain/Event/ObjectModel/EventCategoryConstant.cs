﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Event.ObjectModel
{
    public static class EventCategoryConstant
    {
        public static class CommonName
        {

            public const string Accept = "ACCEPT";
            public const string Decline = "DECLINE";
            public const string Cancel = "CANCEL";
            public const string Invite = "INVITE";
            public const string Disconnect = "DISCONNECT";
            public const string Cbrne = "CBRNE";
            public const string Env = "ENV";
            public const string Geo = "GEO";
            public const string Health = "HEALTH";
            public const string Infra = "INFRA";
            public const string Met = "MET";
            public const string Other = "OTHER";
            public const string Rescue = "RESCUE";
            public const string Safety = "SAFETY";
            public const string Security = "SECURITY";
            public const string Transport = "TRANSPORT";
            public const string CapEventCategory = "CAP_EVENT_CATEGORY";
            public const string LogAlert = "ALERT_PUBLISH";
            public const string LogAlertEnded = "ALERT_END";
            public const string LogManual = "LOG_MANUAL";
        }
    }
}
