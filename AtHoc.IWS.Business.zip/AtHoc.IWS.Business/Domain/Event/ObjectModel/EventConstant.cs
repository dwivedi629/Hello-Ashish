﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Event.ObjectModel
{
    public static class EventConstant
    {
        public static class EventType
        {
            public const string Mass = "Mass";
            public const string HubComm = "HubComm";
            public const string Standard = "Standard";
            public const string Alert = "Alert";
            public const string Log = "Log";
            public const string Report = "Report";
            public const string Checkin = "Checkin";
            public const string Panic = "Panic";
        }

        public static class EventStatus 
        {
            public const string Active = "Act"; 
        }
        public static class EventSourceType
        {
            public const string Organization = "Organization";
            public const string User = "User";
        }



    }
}
