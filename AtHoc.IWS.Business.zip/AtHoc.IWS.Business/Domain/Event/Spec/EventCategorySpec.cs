﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Domain.Events;
using AtHoc.IWS.Business.Service;

namespace AtHoc.IWS.Business.Domain.Event.Spec
{
    public class EventCategorySpec
    {
        public EventCategorySpec()
        {
            ViewType = EventViewType.All;
        }
        public int? ProviderId { get; set; }
        public string CommonName { get; set; }

        public EventViewType ViewType { get; set; }
    }
}
