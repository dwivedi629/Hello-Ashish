﻿using System;
using System.Collections;
using System.Collections.Generic;
using AtHoc.Infrastructure.Entity;
using AtHoc.IWS.Business.Domain.Events;
using AtHoc.IWS.Business.Service;

namespace AtHoc.IWS.Business.Domain.Spec
{
    public class EventSpec : BaseServiceSpec
    {
        public EventSpec()
        {
            this.Page = null;
            this.PageSize = 15;
            ViewType = EventViewType.All;
        }
        public EventViewType ViewType { get; set; }

        public int? Page { get; set; }
        public int PageSize { get; set; }

        public string OrderBy { get; set; }

        public bool OrderAsc { get; set; }

        public string MsgTitle { get; set; }
        public string MsgBody { get; set; }

        public string SourceName { get; set; }

        public List<string> EventType { get; set; }

        public List<int> EventCategoryId { get; set; }
        public DateTime? DateRangeFrom { get; set; }
        public DateTime? DateRangeTo { get; set; }

        public List<int> Severity { get; set; }

        public bool? Reviewed { get; set; }
        public string ReviewedBy { get; set; }

        public List<int> Visibility { get; set; }

        public List<int> EventId { get; set; }

        public bool? PendingReply { get; set; }

        public bool? IsEnded { get; set; }

        public int? UserId { get; set; }

        public int? OperatorId { get; set; }

        public int? ProviderId { get; set; }

        public int? IsArchieved { get; set; }
        public DateTime ? CurrentSystemTimeToVps { get; set; }
        public DateTime ? CurrentDbUtc { get; set; }

        public Func<DateTime, DateTime> FuncVpsToUtcTime { get; set; }
        public bool OperatorIsTeamMember { get; set; }
        public int OperatorTeamId { get; set; }

        public AtHoc.IWS.Business.Domain.Entities.OperatorUser Operator { get; set; }

        public string Locale { get; set; }

        //This flag is used, if you want to include total count also.
        public bool IncludeTotalCount { get; set; }

        public bool IsLiveAlertOnly { get; set; }

        public List<int> EventCategoryIdsToIgnore { get; set; }
        public List<int> EventCategoryIdsToInclude { get; set; } 

    }
}
