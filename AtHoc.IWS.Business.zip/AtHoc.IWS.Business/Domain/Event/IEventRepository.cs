﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Resources;
using AtHoc.IWS.Business.Domain.Spec;
using models =AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Models;

namespace AtHoc.IWS.Business.Domain.Events
{
    public interface IEventRepository
    {
      
        int CreateEvent(models.EventEntity eventEntity);

        bool UpdateEvent(models.Event eventObj);
        
        List<models.EventEntity> GetEventEntities(EventSpec eventSpec);

        /// <summary>
        /// Get Event Details by Event ID
        /// </summary>
        /// <param name="eventId"></param>
        /// <returns></returns>
        models.Event GetEventById(int eventId);

        /// <summary>
        /// Get List of Event by Event IDs
        /// </summary>
        /// <param name="eventIds">List of Event Id</param>
        /// <returns>Collectoin of Events</returns>
        List<models.Event> GetEventByIds(List<int> eventIds);


        /// <summary>
        /// Get List of All Event
        /// </summary>
        /// <param name="includeEventCategory">Optional : Do you want to include associated Event Category?</param>
        /// <returns>List of Event</returns>
        IQueryable<models.Event> GetEventsFromDbView(bool includeEventCategory = false);


        /// <summary>
        /// Get Alert Responses for Events
        /// </summary>
        /// <param name="rowCount">No of records should be picked.</param>
        /// <returns>Collection of AlertResponseEntity</returns>
        List<models.AlertResponseEntity> GetAlertResponsesForEvents(int rowCount = 100);
        /// <summary>
        /// Set Is Responded Flag
        /// </summary>
        /// <param name="eventIds">List of Event IDs</param>
        /// <param name="isResponded">Boolean </param>
        /// <returns>Boolean Success/Fail</returns>
        bool SetEventResponseFlag(List<int> eventIds, bool isResponded);

        List<models.EventMedia> GetEventMediasByEventIds(List<int> eventIds);


        IEnumerable<models.EventDescription> GetEventDescriptionsByEventIds(List<int> eventIds);

        /// <summary>
        /// Get List of Event Categories
        /// </summary>
        /// <returns>Collection of Event Categories</returns>
        IEnumerable<models.EventCategory> GetEventCategories();

        /// <summary>
        /// Update Event Reviewed By.
        /// </summary>
        /// <param name="eventEntity">Object of type EventEntity</param>
        /// /// <param name="markReviewed">Reviewed/Unreviewed</param>
        /// <param name="operatorId"></param>
        /// <returns>Boolean</returns>
        Messages UpdateReviewStatus(List<models.EventEntity> eventEntity, bool markReviewed, int operatorId);

        /// <summary>
        /// Add Response to Event; Also mark Event as Responded
        /// </summary>
        /// <param name="eventDescriptions">List of Responses</param>
        /// <returns>Boolean</returns>
        bool AddEventResponseOption(List<models.EventDescription> eventDescriptions);

        /// <summary>
        /// Create Event Description entries
        /// </summary>
        /// <param name="eventDescription">Event Description</param>
        /// <param name="respondedOn">Date Time Responded ON</param>
        /// <returns>Messages</returns>
        Messages CreateEventDescription(models.EventDescription eventDescription, out DateTime respondedOn);

        

        bool DelegateToResponse(int eventId);


        /// <summary>
        /// Set the Flag for the Event for Any Action performed.
        /// </summary>
        /// <param name="eventId">Event Id</param>
        /// <param name="actionPerformed">e.g. ActionPerformed: Accepted/Declined</param>
        /// <param name="operatorId"></param>
        /// <returns>Boolean Success/Fail</returns>
        bool SetConnectActionFlag(int eventId, models.ActionPerformed actionPerformed,int operatorId);

        /// <summary>
        /// Set the Flag for the Event for Any Action performed.
        /// </summary>
        /// <param name="sourceOrgGuid"></param>
        /// <param name="actionPerformed"></param>
        /// <param name="operatorId"></param>
        /// <param name="providerId"></param>
        /// <returns></returns>
        bool SetConnectActionFlag(string sourceOrgGuid, models.ActionPerformed actionPerformed, int operatorId, int providerId);
    }
}
