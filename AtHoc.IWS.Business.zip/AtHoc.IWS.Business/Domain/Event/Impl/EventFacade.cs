﻿
# region USINGS
using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Objects;
using System.Linq;
using System.Linq.Dynamic;
using System.Web;
using AtHoc.d911.Model.Organization;
using AtHoc.Diagnostics;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Ioc;
using AtHoc.Infrastructure.Log;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Audit;
using AtHoc.IWS.Business.Domain.Event.Impl;
using AtHoc.IWS.Business.Domain.Event.ObjectModel;
using AtHoc.IWS.Business.Domain.Event.Spec;
using AtHoc.IWS.Business.Domain.Media;
using AtHoc.IWS.Business.Domain.Spec;
using AtHoc.IWS.Business.Service;
using AtHoc.IWS.SSA.Business;
using AtHoc.IWS.SSA.Dictionaries;
using AtHoc.Publishing;
using models = AtHoc.IWS.Business.Domain.Entities;
using AtHoc.Global.Resources.Interfaces;
#endregion

namespace AtHoc.IWS.Business.Domain.Events
{
    public class EventFacade : IEventFacade
    {
        #region FIELDS/VARIABLES
        private readonly IEventRepository _eventrepository;
        private readonly IMediaRepository _mediaRepository;
        private readonly ILogService _logService;
        private readonly IGlobalEntityLocaleFacade _globalEntityLocaleFacade;


        private const string MASS = "MASS";
        private const string HUBCOMM = "HUBCOMM";
        private const string ACTIVE = "ACT";
        private const string ORGANIZATION = "ORGANIZATION";
        private const string Alert = "Alert";
        private const string Log = "Log";
        #endregion

        # region CONSTRUCTOR

        public EventFacade(IEventRepository eventRepository, IMediaRepository mediaRepository, ILogService logService)
        {
            _eventrepository = eventRepository;
            _mediaRepository = mediaRepository;
            _logService = logService;
            _globalEntityLocaleFacade = _globalEntityLocaleFacade = ServiceLocator.Resolve<IGlobalEntityLocaleFacade>();
        }
        #endregion

        /// <summary>
        /// Get Events by Event Spec
        /// </summary>
        /// <param name="eventSpec">Object of Type EventSpec</param>
        /// <param name="includeMediaAttachments">True/False - Include Event Media attachment</param>
        /// <exception cref="ArgumentNullException"></exception>
        /// <returns>Collection of Event and Total Event Count</returns>
        public EventWrapper GetEventsBySpec(EventSpec eventSpec, bool includeMediaAttachments = false)
        {

            if (eventSpec == null)
            {
                throw new ArgumentNullException("eventSpec");
            }
            if (!eventSpec.ProviderId.HasValue)
            {
                throw new ArgumentNullException("eventSpec.ProviderId", @"ProviderId cannnot be null.");
            }

            var events = new EventWrapper();
            if (string.IsNullOrEmpty(eventSpec.OrderBy))
            {
                eventSpec.OrderBy = "CreatedOn";
            }

            //Check if incoming OrderBy value is genuine Property of Event.
            if (!string.IsNullOrEmpty(eventSpec.OrderBy) && !TypeExtensions.IsProperty<models.Event>(eventSpec.OrderBy))
            {
                _logService.Error(() => string.Format("{0} - Property does not belongs to Event Entity type. ", eventSpec.OrderBy));
                return events;

            }

            //First get all the event category for provider; Since there are around 13 categories per provider, it is ok to pull all.
            var evtCategories = GetEventCategoriesByProviderId(eventSpec.ProviderId.Value).ToList();

            //Build dictionary based on eventCategoryId
            events.EventCategories = evtCategories.ToDictionary(ec => ec.EventCategoryId);

            //var ecTypes = from a in evtCategories select (new {Type = a.EventCategoryType, Id = a.EventCategoryId});

            //If eventSpec.EventCategoryIdsToInclude is empty, that means caller did not send any event category id to include
            if (eventSpec.EventCategoryIdsToInclude == null)
            {
                eventSpec.EventCategoryIdsToInclude = new List<int>();
            }



            //if request is for activity log, then result should contain activity log related categories
            if (eventSpec.ViewType == EventViewType.Log)
            {

                var activityLogCategoryIds = evtCategories.Where(ec => ec.EventCategoryType.Equals("Alert", StringComparison.InvariantCultureIgnoreCase)
                    || ec.EventCategoryType.Equals("Log", StringComparison.InvariantCultureIgnoreCase)).Select(ec => ec.EventCategoryId);
                eventSpec.EventCategoryIdsToInclude.AddRange(activityLogCategoryIds);
            }
            else
            {
                //For Inbox - do not include activity log and mass category
                var inboxCategories = evtCategories.Where(ec => !ec.EventCategoryType.Equals("Alert", StringComparison.InvariantCultureIgnoreCase)
                    && !ec.EventCategoryType.Equals("Log", StringComparison.InvariantCultureIgnoreCase)
                    && !ec.EventCategoryType.Equals("Mass", StringComparison.InvariantCultureIgnoreCase)
                     && !ec.EventCategoryType.Equals("HubComm", StringComparison.InvariantCultureIgnoreCase)
                    ).Select(ec => ec.EventCategoryId);
                eventSpec.EventCategoryIdsToInclude.AddRange(inboxCategories);

                if (!eventSpec.IsLiveAlertOnly) //For not live alert then only include HubComm also
                {
                    var hubcommCategoryIds = evtCategories.Where(ec => ec.EventCategoryType.Equals("Hubcomm", StringComparison.InvariantCultureIgnoreCase)).Select(ec => ec.EventCategoryId);
                    eventSpec.EventCategoryIdsToInclude.AddRange(hubcommCategoryIds);
                }

            }

            events.Events = GetEventsFromDbView(eventSpec);



            //Do you want to include event media attachment
            if (includeMediaAttachments && eventSpec.ViewType != EventViewType.Log)
            {
                //Retrieve the list of EventID
                var listOfEventIds = events.Events.Data.Select(e => e.EventId).ToList();
                events.EventDescriptions = _eventrepository.GetEventDescriptionsByEventIds(listOfEventIds).ToList();
                //Retrieve the list of Event Media based on eventIds.
                var eventMedias = _eventrepository.GetEventMediasByEventIds(listOfEventIds);
                //Get EventMedia attachments.
                events.MediaAttachments = _mediaRepository.GetMediaAttachment<IEnumerable<models.EventMedia>>(eventMedias);
                events.EventMedias = eventMedias;

                var eventDescriptionLookup = events.EventDescriptions.ToLookup(x => x.EventId);
                var eventMediaLookup = events.EventMedias.ToLookup(x => x.EventId);
                foreach (var e in events.Events.Data)
                {
                    e.EventDescriptions = eventDescriptionLookup.Contains(e.EventId)
                            ? eventDescriptionLookup[e.EventId].ToList()
                            : new List<models.EventDescription>();

                    e.EventMedia = eventMediaLookup.Contains(e.EventId)
                        ? eventMediaLookup[e.EventId].ToList()
                        : new List<models.EventMedia>();

                }
            }


            return events;
        }

        /// <summary>
        /// Get Enumerable of Connect Request which required action
        /// </summary>
        /// <param name="providerId">Provider Id</param>
        /// <returns>IEnumerable</returns>
        public IEnumerable<models.Event> GetConnectRequest(int providerId)
        {
            var events = _eventrepository.GetEventsFromDbView();
            events = events.Where(e => e.ProviderId == providerId && e.LogicalId.Equals("INVITE", StringComparison.InvariantCultureIgnoreCase)
                     && e.ActionPerformed.Value == models.ActionPerformed.ConnectRequestActionRequired &&
                     e.ReviewedBy.HasValue == false);
            return events;
        }

        /// <summary>
        /// Get Connect Request (Invite) count
        /// </summary>
        /// <param name="providerId"></param>
        /// <returns></returns>
        public int GetConnectRequestCount(int providerId)
        {
            var events = _eventrepository.GetEventsFromDbView();
            var count = events.Count(e => e.ProviderId == providerId && e.LogicalId.Equals("INVITE", StringComparison.InvariantCultureIgnoreCase) && e.ActionPerformed.Value == models.ActionPerformed.ConnectRequestActionRequired && e.ReviewedBy.HasValue == false);
            return count;
        }

        /// <summary>
        /// To get the events count by spec.
        /// </summary>
        /// <param name="eventSpec">Event Spec.</param>
        /// <returns>Event count.</returns>
        public int GetEventCountBySpec(EventSpec eventSpec)
        {
            var events = GetEventsBySpecQuery(eventSpec);
            //Get Total Count of Events
            return events.Count();
        }

        private IQueryable<models.Event> GetEventsBySpecQuery(EventSpec eventSpec)
        {
            if (!eventSpec.CurrentDbUtc.HasValue)
            {
                throw new ArgumentNullException("eventSpec.CurrentDbUtc");
            }
            if (!eventSpec.ProviderId.HasValue)
            {
                throw new ArgumentNullException("eventSpec.ProviderId");
            }


            var currentDbUtc = eventSpec.CurrentDbUtc;
            var events = _eventrepository.GetEventsFromDbView();

            events = events.Where(e => e.ProviderId == eventSpec.ProviderId.Value && e.Status.Equals("ACT", StringComparison.OrdinalIgnoreCase)); //Get Only Active Events


            if (!string.IsNullOrEmpty(eventSpec.SourceName))
            {
                events = events.Where(e => e.SourceName.Contains(eventSpec.SourceName));
            }
            if (eventSpec.MsgBody != null)
            {
                //All events from mobile comes with empty type, we show only updates from mobile here.                     
                events = events.Where(e => ((string.IsNullOrEmpty(eventSpec.MsgTitle) || e.MsgTitle.Contains(eventSpec.MsgTitle))
                    || (string.IsNullOrEmpty(eventSpec.MsgBody) || e.MsgBody.Contains(eventSpec.MsgBody)
                    || e.EventDescriptions.Any(ed => ed.Description.Contains(eventSpec.MsgBody) & string.IsNullOrEmpty(ed.Type)))));
            }

            if (eventSpec.Visibility != null)
            {
                events = events.Where(e => eventSpec.Visibility.Contains(e.VisibilityLevel));
            }

            if (eventSpec.ViewType == EventViewType.Log)
            {

                events =
                    events.Where(ec => ec.EventCategoryType.Equals("Alert", StringComparison.InvariantCultureIgnoreCase)
                                       ||
                                       ec.EventCategoryType.Equals("Log", StringComparison.InvariantCultureIgnoreCase));

            }
            //Filter by Events Severity
            if (eventSpec.Severity != null)
            {
                events = events.Where(e => (e.Priority.HasValue && eventSpec.Severity.Contains(e.Priority.Value))
                    || (!e.Priority.HasValue && eventSpec.Severity.Contains(e.EventCategory.DefaultPriority.Value)));
            }



            //Filter by event type. Here event type is mapped to parent event Type i.e. EventCategory table.
            if (eventSpec.EventCategoryId != null)
            {
                events = events.Where(e => eventSpec.EventCategoryId.Contains(e.EventCategoryId.Value));
            }
            //Ignore the event category list
            if (eventSpec.EventCategoryIdsToIgnore != null && eventSpec.EventCategoryIdsToIgnore.Count > 0)
            {
                events = events.Where(e => !eventSpec.EventCategoryIdsToIgnore.Contains(e.EventCategoryId.Value));
            }
            //include the eventcategory list
            if (eventSpec.EventCategoryIdsToInclude != null && eventSpec.EventCategoryIdsToInclude.Count > 0)
            {
                events = events.Where(e => eventSpec.EventCategoryIdsToInclude.Contains(e.EventCategoryId.Value));
            }

            //Filter Events by IsReviewed or Not?
            if (eventSpec.Reviewed.HasValue && eventSpec.Reviewed.Value)
            {
                events = events.Where(e => e.ReviewedBy != null);
            }
            else if (eventSpec.Reviewed.HasValue && !eventSpec.Reviewed.Value)
            {
                events = events.Where(e => e.ReviewedBy == null);
            }


            //Check for IsPending Reply
            if (eventSpec.PendingReply.HasValue)
            {
                //Get events which has pending reply
                if (eventSpec.PendingReply.Value)
                {

                    events =
                        events.Where(
                            e =>
                                !e.IsResponded.Equals("Y", StringComparison.OrdinalIgnoreCase) &&
                                e.SourceType.Equals(ORGANIZATION, StringComparison.OrdinalIgnoreCase) &&
                                e.EventEnd.HasValue
                                && e.EventEnd.Value > currentDbUtc);
                }
                else
                {
                    events =
                        events.Where(
                            e =>
                                e.IsResponded.Equals("Y", StringComparison.OrdinalIgnoreCase));

                }
            }

            //Check for IsEnded
            if (eventSpec.IsEnded.HasValue)
            {

                if (eventSpec.IsEnded.Value)
                {
                    events =
                        events.Where(
                            e =>
                              e.EventEnd.HasValue && e.EventEnd.Value < currentDbUtc);
                }
                else
                {
                    //include which has not end date + if end date is available then compare with current date to end date.
                    events =
                        events.Where(
                            e => (e.EventEnd.HasValue == false) || (e.EventEnd.HasValue && e.EventEnd.Value > currentDbUtc));

                }

            }

            DateTime? dtFrom = eventSpec.DateRangeFrom;
            DateTime? dtTo = eventSpec.DateRangeTo;

            if (eventSpec.DateRangeFrom.HasValue)
            {
                var tempFrom = DateTime.SpecifyKind(eventSpec.DateRangeFrom.Value, DateTimeKind.Unspecified);

                //since the logic is not simple as it looks, preparing valid date time step by step (it could have been something like tempFrom.AddHours(-24).AddMinute(1);, but keeping readable)
                // i/p from date: 2016-09-20 08:45:00 -> o/p => 2016-09-20 00:00:00
                
                dtFrom = tempFrom.AddHours(-tempFrom.Hour); // substract (x) hour from param date, so that hour should start from 00
                dtFrom = dtFrom.Value.AddMinutes(-dtFrom.Value.Minute); // substract (x) minute from param date, so that minute should start from 00
                dtFrom = dtFrom.Value.AddSeconds(-dtFrom.Value.Second); // substract (x) seconds from param date, so that seconds should start from 00
                dtFrom = eventSpec.FuncVpsToUtcTime(dtFrom.Value); //now updated date to utc
                events = events.Where(e => (e.CreatedOn >= dtFrom));
            }
            if (eventSpec.DateRangeTo.HasValue)
            {
                var tempTo = DateTime.SpecifyKind(eventSpec.DateRangeTo.Value, DateTimeKind.Unspecified);
                // i/p from date: 2016-09-21 08:45:00 -> o/p => 2016-09-21 23:59:59

                var selectedVpsTime = new DateTime(tempTo.Year, tempTo.Month, tempTo.Day, 23, 59, 59); //build datetime object such that day, month, year should retain same. add 23 hr, 59 min and 59 sec to make range upto end of day.
                dtTo = eventSpec.FuncVpsToUtcTime(selectedVpsTime); //convert updated date to utc
                events = events.Where(e => (e.CreatedOn <= dtTo));
            }

            return events;
        }
        private PagingInfo<models.Event> GetEventsFromDbView(EventSpec eventSpec)
        {
            //Get Iqueryable.. Query is not executed yet.
            var events = GetEventsBySpecQuery(eventSpec);

            int eventsCount = 0;
            if (eventSpec.IncludeTotalCount) //Get Total Count, only IncludeTotalCount = true
            {
                //Get Total Count of Events
                eventsCount = events.Count();
            }


            //If no page number, then return all the events.
            if (!eventSpec.Page.HasValue)
            {
                return new PagingInfo<models.Event> { Count = eventsCount, Data = events.OrderByDescending(a => a.UpdatedOn).ToList() };
            }


            string orderbystring = (eventSpec.OrderAsc ? string.Format("{0} ASC ", eventSpec.OrderBy)
               : string.Format("{0} DESC", eventSpec.OrderBy));

            //Generate ORDERBY predicates
            events = eventSpec.Page.Value > 1 ?
                events.OrderBy(orderbystring).Skip((eventSpec.Page.Value - 1) * eventSpec.PageSize).Take(eventSpec.PageSize)
                : events.OrderBy(orderbystring).Take(eventSpec.PageSize);

            var lstOfEvent = events.ToList();

            return new PagingInfo<models.Event> { Count = eventsCount, Data = lstOfEvent };
        }
        public EventWrapper GetEventById(int eventId, bool includeMediaAttachments = false)
        {
            var events = new EventWrapper();

            //Check if incoming OrderBy value is genuine Property of Event.
            if (eventId <= 0)
            {
                throw new ArgumentNullException("eventId");
            }

            events.Event = _eventrepository.GetEventById(eventId);

            //Do you want to include event media attachment
            if (includeMediaAttachments)
            {
                //Retrieve the list of EventID
                var listOfEventIds = new List<int> { events.Event.EventId };

                //Retrieve the list of Event Media based on eventIds.
                var eventMedias = _eventrepository.GetEventMediasByEventIds(listOfEventIds);

                //Get EventMedia attachments.
                events.MediaAttachments = _mediaRepository.GetMediaAttachment<IEnumerable<models.EventMedia>>(eventMedias);
            }
            return events;
        }

        public int CreateEvent(models.Event eventObj)
        {
            if (eventObj.EventData == null)
            {
                eventObj.SetCustomData(new Dictionary<OrganizationEventCustomAttrIds, string>());
            }
            var eventEntity = new models.EventEntity()
            {
                EventCategoryId = eventObj.EventCategoryId,
                CreatedBy = eventObj.CreatedBy,
                CreatedOn = DateTime.UtcNow,
                EventTime = DateTime.UtcNow,
                UpdatedOn = DateTime.UtcNow,
                UpdatedBy = eventObj.UpdatedBy ?? 0,
                MsgBody = eventObj.MsgBody,
                MsgTitle = eventObj.MsgTitle ?? "",
                IsMobileAccessible = eventObj.IsMobileAccessible ?? "N",
                IsSystem = "N",
                Latitude = eventObj.Latitude ?? 0,
                Longitude = eventObj.Longitude ?? 0,
                UserId = eventObj.UserId ?? 0,
                Status = eventObj.Status ?? ACTIVE,
                Priority = eventObj.Priority ?? (int)Severity.Unknown,
                SourceType = eventObj.SourceType ?? "USER",
                SourceId = eventObj.SourceId,
                SourceName = eventObj.SourceName,
                VisibilityLevel = -2,
                EventData = eventObj.EventData,
                EventType = eventObj.EventType,
                GeoJson = eventObj.GeoJson
            };
            return _eventrepository.CreateEvent(eventEntity);
        }


        public int CreateEvent(Alert alert, int providerId, int operatorId)
        {

            try
            {
                var eventCategories = GetEventCategories(providerId);

                models.EventCategory sourceEventCategory = null;
                if (alert.AlertSpec.EventCategoryId != null && alert.AlertSpec.EventCategoryId > 0)
                {
                    sourceEventCategory = eventCategories.Find(eventCategory => eventCategory.EventCategoryId == alert.AlertSpec.EventCategoryId);
                }

                if (sourceEventCategory == null)
                {
                    sourceEventCategory = eventCategories.Find(eventCategory => eventCategory.EventCategoryType.Equals("Standard", StringComparison.InvariantCultureIgnoreCase) && eventCategory.CommonName.Equals("OTHER", StringComparison.InvariantCultureIgnoreCase));
                }


                var totalTargetedUsers = alert.TargetedUserCount;
                var targetedOrgdIds = alert.AlertSpec.Targeting.TargetingCriteria.Where(c => c.NodeType.Equals(SearchNodeType.OrgUser)).Select(c => c.SearchCriteriaID).ToList();

                var category = eventCategories.Find(eventCategory => eventCategory.EventCategoryType.Equals(EventRepository.ALERT, StringComparison.InvariantCultureIgnoreCase) && eventCategory.CommonName.Equals(EventCategoryConstant.CommonName.LogAlert, StringComparison.InvariantCultureIgnoreCase));

                // get the right category
                models.Event eventObj = new models.Event();
                eventObj.EventCategoryId = category.EventCategoryId;
                eventObj.CreatedBy = alert.CreatedBy;
                eventObj.CreatedOn = DateTime.UtcNow;
                //updatedEventObj.SourceId = alert.CreatedBy;
                eventObj.SourceName = alert.CreatedByName;
                eventObj.UserId = alert.CreatedBy;
                var targetCount = alert.TargetedUserCount;
                eventObj.MsgTitle = alert.AlertSpec.Content.Header;
                eventObj.MsgBody = alert.AlertSpec.Content.Body;
                eventObj.Priority = (int)alert.AlertSpec.Priority;
                eventObj.EventType = Alert;
                eventObj.GeoJson = GetLocationAsGeoJson(alert, providerId);
                Dictionary<OrganizationEventCustomAttrIds, string> attributes = new Dictionary<OrganizationEventCustomAttrIds, string>();
                attributes.Add(OrganizationEventCustomAttrIds.AlertTotalTargeted, totalTargetedUsers.ToString());
                attributes.Add(OrganizationEventCustomAttrIds.Url, alert.AlertSpec.Content.Url);
                attributes.Add(OrganizationEventCustomAttrIds.AlertId, alert.AlertId.ToString());
                attributes.Add(OrganizationEventCustomAttrIds.EventCategoryId, alert.AlertSpec.EventCategoryId.ToString());
                eventObj.SetCustomData(attributes);

                return CreateEvent(eventObj);
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("failed to create event from alert {0}", alert.AlertId), ex);
            }
            return -1;

        }

        public bool UpdateEvent(models.Event updatedEventObj)
        {
            if (updatedEventObj == null || updatedEventObj.EventId <= 0)
            {
                EventLogger.WriteError(string.Format("Failed to Update Event, missing eventId paramets: {0}",
                    updatedEventObj == null ? "null" : updatedEventObj.EventId.ToString()));
                return false;
            }

            models.Event currentEvent = _eventrepository.GetEventById(updatedEventObj.EventId);
            if (currentEvent == null || currentEvent.EventId <= 0)
            {
                EventLogger.WriteError(string.Format("Failed to Update Event, could not find event: {0}",
                    currentEvent == null ? "null" : currentEvent.EventId.ToString()));
                return false;
            }

            List<models.EventDescription> eventDescriptions = new List<models.EventDescription>();
            var updatedOn = DateTime.UtcNow;
            if (SetFieldUpdateDescription(currentEvent, currentEvent.MsgBody, updatedEventObj.MsgBody, eventDescriptions, EventDescriptionType.BodyUpdate, updatedOn))
            {
                currentEvent.MsgBody = updatedEventObj.MsgBody;
            }
            if (SetFieldUpdateDescription(currentEvent, currentEvent.MsgTitle, updatedEventObj.MsgTitle, eventDescriptions, EventDescriptionType.TitleUpdate, updatedOn))
            {
                currentEvent.MsgTitle = updatedEventObj.MsgTitle;
            }
            if (SetFieldUpdateDescription(currentEvent, currentEvent.Priority.ToString(), updatedEventObj.Priority.ToString(), eventDescriptions, EventDescriptionType.SeverityUpdate, updatedOn))
            {
                currentEvent.Priority = updatedEventObj.Priority;
            }

            // for the url we need to udpate the additional data   
            string existingUrlStr = currentEvent.GetCustomDataValue(OrganizationEventCustomAttrIds.Url);
            string newUrlStr = updatedEventObj.GetCustomDataValue(OrganizationEventCustomAttrIds.Url);
            if (SetFieldUpdateDescription(currentEvent, existingUrlStr, newUrlStr, eventDescriptions, EventDescriptionType.UrlUpdate, updatedOn))
            {
                currentEvent.SetCustomDataValue(OrganizationEventCustomAttrIds.Url, newUrlStr);
            }
            //currentEvent.UpdatedOn = RuntimeContext.Provider.SystemToVpsTime(DateTime.Now);
            currentEvent.UpdatedOn = DateTime.UtcNow;
            bool ret = _eventrepository.UpdateEvent(currentEvent);
            if (ret)
            {
                eventDescriptions.ForEach(eventDescription =>
                {
                    DateTime respondedOn;
                    _eventrepository.CreateEventDescription(eventDescription, out respondedOn);
                });
                return true;
            }

            return false;
        }

        private bool SetFieldUpdateDescription(models.Event currentEvent, string existingValue, string updateValue, List<models.EventDescription> eventDescriptions, string key, DateTime updatedOn)
        {
            if (existingValue == null)
            {
                existingValue = "";
            }
            if (updateValue == null)
            {
                updateValue = "";
            }
            if (!existingValue.Equals(updateValue))
            {
                // body was changed:
                var eventDescription = new models.EventDescription
                {
                    EventId = currentEvent.EventId,
                    Description = existingValue,
                    SourceId = RuntimeContext.Operator.Id,
                    SourceType = "USER",
                    Type = key,
                    UpdatedOn = updatedOn
                };
                eventDescriptions.Add(eventDescription);
                return true;
            }
            return false;
        }

        /// <summary>
        /// Get List of All Event
        /// </summary>
        /// <param name="includeEventCategory">Optional : Do you want to include associated Event Category?</param>
        /// <param name="includeEventDescription">Optional: Do  you want to include associated Event Description?</param>
        /// <param name="includeEventMedia">Optional: Do you want to include associated Media information</param>
        /// <returns>List of Event</returns>
        public List<models.Event> GetEvents(bool includeEventCategory = false, bool includeEventDescription = false, bool includeEventMedia = false)
        {
            return _eventrepository.GetEventsFromDbView(includeEventCategory).ToList();
        }

        /// <summary>
        /// Get List of Event Categories
        /// </summary>
        /// <returns>Collection of Event Categories</returns>
        public List<models.EventCategory> GetEventCategories(int providerId, EventViewType viewType = EventViewType.All)
        {
            var categories = _eventrepository.GetEventCategories();
            var categoryList = from ec in categories
                               where ec.ProviderId == providerId && ec.Status == "ACT"
                               where (viewType == EventViewType.Log ? EventRepository.LogViewTypes.Contains(ec.EventCategoryType, StringComparer.CurrentCultureIgnoreCase) : (viewType != EventViewType.Inbox || !EventRepository.LogViewTypes.Contains(ec.EventCategoryType, StringComparer.CurrentCultureIgnoreCase)))
                               orderby ec.EventCategoryType
                               select new models.EventCategory()
                               {
                                   EventCategoryId = ec.EventCategoryId,
                                   Name = ec.Name,
                                   EventCategoryType = ec.EventCategoryType,
                                   ImageId = ec.ImageId,
                                   LogicalId = ec.LogicalId,
                                   CommonName = ec.CommonName,
                               };
            return categoryList.ToList();



        }

        /// <summary>
        /// Get EventCategories by ProviderId, Common Name
        /// </summary>
        /// <param name="eventCategorySpec"></param>
        /// <returns></returns>
        public IEnumerable<models.EventCategory> GetEventCategories(EventCategorySpec eventCategorySpec, string localeCode)
        {
            var categories = _eventrepository.GetEventCategories();
            categories =
                categories.Where(ec => eventCategorySpec.ViewType == EventViewType.Log
                    ? EventRepository.LogViewTypes.Contains(ec.EventCategoryType, StringComparer.CurrentCultureIgnoreCase)
                    : (eventCategorySpec.ViewType == EventViewType.Inbox ? !EventRepository.LogViewTypes.Contains(ec.EventCategoryType, StringComparer.CurrentCultureIgnoreCase) : true));

            //filter by Provider Id
            if (eventCategorySpec.ProviderId.HasValue)
            {
                categories = categories.Where(ec => ec.ProviderId == eventCategorySpec.ProviderId.Value);
            }

            //filter by Common Name
            if (!string.IsNullOrEmpty(eventCategorySpec.CommonName))
            {
                categories = categories.Where(ec => eventCategorySpec.CommonName.Equals(ec.CommonName, StringComparison.OrdinalIgnoreCase));
            }

            categories = _globalEntityLocaleFacade.GetLocalizedEntity(categories.ToList(), localeCode);
            return categories;
        }

        private Dictionary<int, models.EventCategory> GetEventCategoriesByEventId(List<int?> eventCategoryIds)
        {
            if (eventCategoryIds == null) throw new ArgumentNullException("eventCategoryIds");
            return _eventrepository.GetEventCategories().Where(ec => eventCategoryIds.Contains(ec.EventCategoryId)).ToDictionary(ec => ec.EventCategoryId);
        }
        private IEnumerable<models.EventCategory> GetEventCategoriesByProviderId(int providerId)
        {
            if (providerId == 0) { throw new ArgumentNullException("providerId"); }
            return _eventrepository.GetEventCategories().Where(ec => ec.ProviderId == providerId);
        }
        /// <summary>
        /// Update Event Reviewed By.
        /// </summary>
        /// <param name="eventSpec">Object of type EventEntity</param>
        /// <returns>Boolean</returns>
        public bool UpdateReviewStatus(EventSpec eventSpec)
        {
            if (eventSpec == null)
            {
                throw new ArgumentNullException("eventSpec");
            }
            if (!eventSpec.Reviewed.HasValue)
            {
                throw new ApplicationException("EventSpec.Reviewed is null");
            }
            if (!eventSpec.OperatorId.HasValue)
            {
                // ReSharper disable once NotResolvedInText
                throw new ArgumentNullException("eventSpec.OperatorId cannot be null");
            }

            //Since EventSpec.Entity is list type, i can have single or multiple eventIDs to process.
            var lstOfEvents = new List<models.EventEntity>();
            foreach (var id in eventSpec.EventId)
            {
                var e = new models.EventEntity { EventId = id };
                lstOfEvents.Add(e);
            }
            var serviceResult = new ServiceResult<bool>();
            if (eventSpec.Reviewed.Value)
            {
                //Mark as Reviewed
                return UpdateEventMarkAsReviewed(lstOfEvents, serviceResult, eventSpec.OperatorId.Value);
            }
            else
            {
                //Mark as UnReviewed
                return UpdateEventMarkAsUnReviewed(lstOfEvents, serviceResult, eventSpec.OperatorId.Value);
            }
        }

        /// <summary>
        /// Update Event Table and mark as Reviewed
        /// </summary>
        /// <param name="lstOfEvents"></param>
        /// <param name="result"></param>
        /// <param name="operatorId"></param>
        /// <returns></returns>
        private bool UpdateEventMarkAsReviewed(List<models.EventEntity> lstOfEvents, IServiceResult<bool> result, int operatorId)
        {

            var lstOfEventIds = lstOfEvents.Select(e => e.EventId).ToList();
            var events = _eventrepository.GetEventByIds(lstOfEventIds);
            var eventNames = String.Join(",", events.Select(e => e.MsgTitle));
            result.ActionType = models.ServiceAction.EventMarkAsReviewed;
            result.EntityType = models.EntityType.Event;
            result.AddMessage(_eventrepository.UpdateReviewStatus(lstOfEvents, true, operatorId));
            result.OutputContext = eventNames;
            try
            {
                OperationAuditor.LogAction(models.ServiceAction.EventMarkAsReviewed, models.EntityType.Event, eventNames);
            }
            catch (Exception ex)
            {
                EventLogger.WriteWarning("Unable to create audit log", ex);
            }
            return result.IsValid;
        }

        /// <summary>
        /// Update Event Table and mark as UnReviewed
        /// </summary>
        /// <param name="lstOfEvents"></param>
        /// <param name="result"></param>
        /// <param name="operatorId"></param>
        /// <returns></returns>
        private bool UpdateEventMarkAsUnReviewed(List<models.EventEntity> lstOfEvents, IServiceResult<bool> result, int operatorId)
        {

            var lstOfEventIds = lstOfEvents.Select(e => e.EventId).ToList();
            var events = _eventrepository.GetEventByIds(lstOfEventIds);
            var eventNames = String.Join(",", events.Select(e => e.MsgTitle));
            result.ActionType = models.ServiceAction.EventMarkAsReviewed;
            result.EntityType = models.EntityType.Event;
            result.AddMessage(_eventrepository.UpdateReviewStatus(lstOfEvents, false, operatorId));
            result.OutputContext = eventNames;
            try
            {
                OperationAuditor.LogAction(models.ServiceAction.EventMarkAsReviewed, models.EntityType.Event, eventNames);
            }
            catch (Exception ex)
            {
                EventLogger.WriteWarning("Unable to create audit log", ex);
            }

            return result.IsValid;

        }

        /// <summary>
        /// Respond to Event
        /// </summary>
        /// <param name="eventDescription">Event Description</param>
        /// <param name="eventResponse">Event Response Enumeration</param>
        /// <param name="respondedOn">Event Responsed on DateTime (UTC)</param>
        /// <returns>Boolean</returns>
        public bool CreateEventDescription(models.EventDescription eventDescription, out EventResponse eventResponse, out DateTime respondedOn)
        {
            respondedOn = new DateTime();
            eventResponse = EventResponse.Successfull;
            //Check if Event is already responded
            var evt = _eventrepository.GetEventById(eventDescription.EventId);
            if (evt.IsResponded != null && evt.IsResponded.ToUpper() == "Y")
            {
                eventResponse = EventResponse.AlreadyResponded;  //Set "Event Already Responded message
                return false;
            }

            //Check if Event is already Ended

            if (evt.EventEnd.HasValue)
            {

                if (RuntimeContext.Provider.CurrentSystemTimeToVps() >= RuntimeContext.Provider.SystemToVpsTime(evt.EventEnd.Value))
                {
                    eventResponse = EventResponse.EventEnded; //Set "Event Already Ended message
                    return false;
                }
            }


            var result = new ServiceResult<bool>();
            result.ActionType = models.ServiceAction.EventDesciptionCreate;
            result.EntityType = models.EntityType.Event;
            eventDescription.UpdatedOn = DateTime.UtcNow;
            var messages = _eventrepository.CreateEventDescription(eventDescription, out respondedOn);
            result.AddMessage(messages);
            result.OutputContext = eventDescription.EventId.ToString();
            return result.IsValid;

        }

        public void DelegateToResponse(int eventId)
        {
            try
            {
                _eventrepository.DelegateToResponse(eventId);
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Error while Delegate to Response", ex);

            }

        }

        /// <summary>
        /// Set Connect Invitation Action Flag.
        /// </summary>
        /// <param name="eventId"></param>
        /// <param name="providerId"></param>
        /// <param name="operatorId"></param>
        /// <param name="actionPerformed"></param>
        /// <param name="sourceOrganizationGuid"></param>
        /// <returns></returns>
        public bool SetConnectActionFlag(int eventId, int providerId, int operatorId, models.ActionPerformed actionPerformed, string sourceOrganizationGuid = "")
        {
            try
            {

                if (eventId > 0)
                {
                    //This is the case when eventId is avaiable - Action from Inbox
                    return _eventrepository.SetConnectActionFlag(eventId, actionPerformed, operatorId);
                }
                else
                {
                    //This is the case when eventId is not avaiable, but sourceOrganizationGuid is avaiable - Action from Organization manager.
                    return _eventrepository.SetConnectActionFlag(sourceOrganizationGuid, actionPerformed, operatorId, providerId);
                }


            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Error while Setting Connect Action Flag.", ex);
                return false;
            }
        }

        /// <summary>
        /// To get GeoJson
        /// </summary>
        /// <param name="alertBase">alertBase.</param>
        /// <param name="providerId">providerId.</param>
        /// <returns>geoJson.</returns>
        private static string GetLocationAsGeoJson(AlertBase alertBase, int providerId)
        {
            if (alertBase.AlertSpec.Advanced == null)
                return string.Empty;

            var attachments = alertBase.AlertSpec.Advanced.GetAttachments(AttachmentType.Spatial, AttachmentSubType.Location);
            if (attachments == null || attachments.ToList().Count < 1)
                return string.Empty;

            // geolocation: get GeoJson from map layer ID
            var alertLocationLayer = GetLocationLayer(attachments.ToList()[0].AttachmentId, providerId);
            return (alertLocationLayer != null) ? alertLocationLayer.GeoJson : string.Empty;
        }

        /// <summary>
        /// To get geo Location Layer.
        /// </summary>
        /// <param name="attachmentId">attachmentId.</param>
        /// <param name="providerId">providerId.</param>
        /// <returns>mapLayer.</returns>
        private static MapLayer GetLocationLayer(int attachmentId, int providerId)
        {
            var mapManager = AtHoc.IWS.SSA.Business.Facades.ManagerFactory.Instance.CreateMapManager();
            mapManager.ProviderId = providerId;
            var alertLocationLayer = mapManager.GetMapLayer(attachmentId,
                new MapFilterCriteria()
                {
                    ProviderId = providerId,
                    MapLayerType = MapLayerSourceType.Alert,
                    NonPeopleLayersOnly = false
                });

            return alertLocationLayer;
        }


    }


}