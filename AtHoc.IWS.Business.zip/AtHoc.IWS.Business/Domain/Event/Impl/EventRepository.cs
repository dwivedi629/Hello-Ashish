﻿using System.Linq.Dynamic;
using AtHoc.Data.Specification;
using AtHoc.Diagnostics;
using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Resources;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.Spec;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
//using System.Linq.Dynamic;
using models = AtHoc.IWS.Business.Domain.Entities;
using SqlParameter = System.Data.SqlClient.SqlParameter;
using System.Data.Entity;


namespace AtHoc.IWS.Business.Domain.Events
{
    /// <summary>
    /// Repository for Event
    /// </summary>
    public class EventRepository : IEventRepository
    {
        public const string MASS = "MASS";
        public const string HUBCOMM = "HUBCOMM";
        public const string ACTIVE = "ACT";
        public const string ORGANIZATION = "ORGANIZATION";
        public const string LOG = "LOG";
        public const string ALERT = "ALERT";

        public static List<string> LogViewTypes { get; private set; }
        static EventRepository()
        {
            LogViewTypes = new List<string>();
            LogViewTypes.Add(LOG);
            LogViewTypes.Add(ALERT);
        }
       

        public int CreateEvent(models.EventEntity eventEntity)
        {
            try
            {
                using (var context = new AtHocEventDbContext())
                {                    
                    var eventToUpdate = context.EventEntities.Add(eventEntity);
                    context.SaveChanges();
                    return eventToUpdate.EventId;
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Error in AddEventResponseOption", ex);
                return -1;
            }
        }

        public bool UpdateEvent(models.Event eventObj)
        {
            try
            {                
                using (var context = new AtHocEventDbContext())
                {
                    var evntToUpdate = context.EventEntities.FirstOrDefault(a => a.EventId == eventObj.EventId);
                    if (evntToUpdate == null)
                    {
                        EventLogger.WriteError(string.Format("Failed to Update Event, failed to find event id: {0}",
                            eventObj.EventId));
                        return false;
                    }
                    
                    evntToUpdate.MsgBody = eventObj.MsgBody;                    
                    evntToUpdate.MsgTitle = eventObj.MsgTitle;
                    evntToUpdate.Priority = eventObj.Priority;
                    evntToUpdate.EventData = eventObj.EventData;
                    evntToUpdate.UpdatedOn = eventObj.UpdatedOn;
                    context.SaveChanges();

                    return true;
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("failed to UpdateEvent", ex);
                return false;
            }
        }

        /// <summary>
        /// Get List of Events.
        /// </summary>
        /// <param name="eventSpec">Parameters to filter events</param>
        /// <returns></returns>
        public List<models.EventEntity> GetEventEntities(EventSpec eventSpec)
        {
            using (var db = new AtHocEventDbContext())
            {
                var events = db.EventEntities.Where(e => true); //Will be always true - Doing it to use IQueriable overload
                if (eventSpec.EventId != null && eventSpec.EventId.Any())
                {
                    events = db.EventEntities.Where(e => eventSpec.EventId.Contains(e.EventId));
                }
                return events.ToList();
            }
        }
        /// <summary>
        /// Get List of All Event
        /// </summary>
        /// <param name="includeEventCategory">Optional : Do you want to include associated Event Category?</param>
        /// <returns>List of Event</returns>
        public System.Linq.IQueryable<models.Event> GetEventsFromDbView(bool includeEventCategory = false)
        {
            var context = new AtHocEventDbContext();
            var events = context.Events as System.Linq.IQueryable<models.Event>;
            if (includeEventCategory)
            {
               events = QueryableExtensions.Include(events, "EventCategory").AsNoTracking() ;
            }
           
            return events;

        }
        /// <summary>
        /// Get Alert Responses for Events
        /// </summary>
        /// <param name="rowCount">No of records should be picked.</param>
        /// <returns>Collection of AlertResponseEntity</returns>
        public List<models.AlertResponseEntity> GetAlertResponsesForEvents(int rowCount = 100)
        {
            using (var context = new AtHocEventDbContext())
            {
                var lstAlertResponseEntity =
                    context.Database.SqlQuery<models.AlertResponseEntity>("EXEC PROCESS_ALERT_RESPONSE_DELEGATION @p0", rowCount).ToList();
                return lstAlertResponseEntity;
            }
        }

        /// <summary>
        /// Get Event Details by EventID
        /// </summary>
        /// <param name="eventId"></param>
        /// <returns></returns>
        public models.Event GetEventById(int eventId)
        {
            using (var db = new AtHocEventDbContext())
            {
                var evnt = db.Events.Include("EventMedia").Include("EventDescriptions").Include("EventCategory")
                    .FirstOrDefault(e => e.EventId == eventId);
                return evnt;
            }
        }


        /// <summary>
        /// Get List of Event by Event IDs
        /// </summary>
        /// <param name="eventIds">List of Event Id</param>
        /// <returns>Collectoin of Events</returns>
        public List<models.Event> GetEventByIds(List<int> eventIds)
        {
            using (var db = new AtHocEventDbContext())
            {
                var evnt = db.Events.Include("EventMedia").Include("EventDescriptions").Include("EventCategory")
                    .Where(e => eventIds.Contains(e.EventId)).ToList();
                return evnt;
            }
        }
        /// <summary>
        /// Get Event Media by EventIds
        /// </summary>
        /// <param name="eventIds"></param>
        /// <returns></returns>
        public List<models.EventMedia> GetEventMediasByEventIds(List<int> eventIds)
        {
            using (var context = new AtHocEventDbContext())
            {
                var a = from m in context.EventMedias
                        where eventIds.Contains(m.EventId)
                        select m;
                return a.ToList();
            }
        }
        public IEnumerable<models.EventDescription> GetEventDescriptionsByEventIds(List<int> eventIds)
        {
            var context = new AtHocEventDbContext();
            var a = from m in context.EventDescriptions
                    where eventIds.Contains(m.EventId)
                    select m;
            return a;
        }




        /// <summary>
        /// Get List of Event Categories
        /// </summary>
        /// <returns>Collection of Event Categories</returns>
        public IEnumerable<models.EventCategory> GetEventCategories()
        {
            var context = new AtHocEventDbContext();
            return context.EventCategories;
            
        }

        /// <summary>
        /// Update Event Reviewed By.
        /// </summary>
        /// <param name="eventEntity">Object of type EventEntity</param>
        /// /// <param name="markReviewed">Reviewed/Unreviewed</param>
        /// <param name="operatorId"></param>
        /// <returns>Boolean</returns>
        public Messages UpdateReviewStatus(List<models.EventEntity> eventEntity, bool markReviewed,int operatorId)
        {
            var messages = new Messages();

            try
            {

                using (var context = new AtHocEventDbContext())
                {

                    //var ids = eventEntity.Select(e => e.EventId).ToList();
                    var eids = string.Join(",", eventEntity.Select(p => p.EventId.ToString()));

                    if (markReviewed)
                    {

                        context.Database.ExecuteSqlCommand(
                            "UPDATE DBO.EVT_EVENT_TAB " +
                            "SET REVIEWED_BY = @p0, " +
                            "REVIEWED_ON=getutcdate(), " +
                            "UPDATED_ON = getutcdate()  " +
                            "WHERE EVENT_ID IN (@p1)", operatorId, eids);
                    }
                    else
                    {
                        context.Database.ExecuteSqlCommand(
                            "UPDATE DBO.EVT_EVENT_TAB " +
                            "SET REVIEWED_BY = null, " +
                            "REVIEWED_ON= null, " +
                            "UPDATED_ON = getutcdate()  " +
                            "WHERE EVENT_ID IN (@p0)", eids);
                    }

                    messages.CreateSuccessMessage("Object has been updated.");
                }
            }
            catch (Exception ex)
            {

                messages.CreateErrorMessage(ex);
            }
            return messages;
        }

        /// <summary>
        /// Set Is Responded Flag
        /// </summary>
        /// <param name="eventIds">List of Event IDs</param>
        /// <param name="isResponded">Boolean </param>
        /// <returns>Boolean Success/Fail</returns>
        public bool SetEventResponseFlag(List<int> eventIds, bool isResponded)
        {
            try
            {
                using (var context = new AtHocEventDbContext())
                {
                    var evtids = string.Join(",", eventIds.ToArray()); //Get comma separed values
                    context.Database.ExecuteSqlCommand(
                        "UPDATE DBO.EVT_EVENT_TAB " +
                        "SET IS_RESPONDED = @p0, " +
                        "UPDATED_ON = getutcdate()  " +
                        "WHERE EVENT_ID IN (@p1)", isResponded ? "Y" : "N", evtids);
                    return true;
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Error in SetResponseFlag", ex);
                return false;
            }

        }

        public bool DelegateToResponse(int eventId)
        {
            try
            {
                using (var context = new AtHocEventDbContext())
                {
                    context.Database.ExecuteSqlCommand(
                        "UPDATE DBO.EVT_EVENT_TAB " +
                        "SET SUPPORTS_RESPONSE_TO_SENDER = @p0, " +
                        "UPDATED_ON = getutcdate()  " +
                        "WHERE EVENT_ID IN (@p1)", "Y", eventId);
                    return true;
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Error in SetResponseFlag", ex);
                throw;
            }

        }

        /// <summary>
        /// Set Is Connect Action Required
        /// </summary>
        /// <param name="eventId">List of Event IDs</param>
        
        /// <param name="actionPerformed"></param>
        /// <param name="operatorId"></param>
        /// <returns>Boolean Success/Fail</returns>
        public bool SetConnectActionFlag(int eventId,  models.ActionPerformed actionPerformed, int operatorId)
        {
            string updateQuery = string.Format("UPDATE DBO.EVT_EVENT_TAB " +
                        "SET ACTION_PERFORMED = {2}," +
                        "UPDATED_ON = getutcdate()," +
                        "REVIEWED_ON= {3}, " +
                        "REVIEWED_BY = {4}," +
                        "UPDATED_BY = {0}  " +
                        "WHERE EVENT_ID ={1}", operatorId, eventId, (int)actionPerformed
                        , (actionPerformed == models.ActionPerformed.ConnectRequestActionRequired ? "NULL" : "getutcdate()")
                        , (actionPerformed == models.ActionPerformed.ConnectRequestActionRequired ? "NULL" : operatorId.ToString()));

           
            try
            {
                using (var context = new AtHocEventDbContext())
                {
                    context.Database.ExecuteSqlCommand(updateQuery);
                    return true;
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("Error in SetConnectActionFlag method. update query is - {0}", updateQuery), ex);
                
                return false;
            }

        }

      
        /// <summary>
        /// Set the Flag for the Event for Any Action performed.
        /// </summary>
        /// <param name="sourceOrgGuid"></param>
        /// <param name="actionPerformed"></param>
        /// <param name="operatorId"></param>
        /// <param name="providerId"></param>
        /// <returns></returns>
        public bool SetConnectActionFlag(string sourceOrgGuid, models.ActionPerformed actionPerformed, int operatorId, int providerId)
        {
            string updateQuery =
                    string.Format("UPDATE " +
                                  "E SET E.UPDATED_BY ={0},E.UPDATED_ON = GETUTCDATE(),ACTION_PERFORMED ={1},REVIEWED_BY = {0},REVIEWED_ON = GETUTCDATE() " +
                        " FROM EVT_EVENT_TAB E INNER JOIN EVT_CATEGORY_TAB EC ON E.EVENT_CATEGORY_ID = EC.EVENT_CATEGORY_ID " +
                        " WHERE EC.PROVIDER_ID = {2} AND EC.COMMON_NAME ='INVITE' AND E.ACTION_PERFORMED ={3} AND E.SOURCE_ID ='{4}'"
                        , operatorId, (int)actionPerformed, providerId, (int)models.ActionPerformed.ConnectRequestActionRequired, sourceOrgGuid);
            try
            {
                
                using (var context = new AtHocEventDbContext())
                {
                    context.Database.ExecuteSqlCommand(updateQuery);
                    return true;
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("Error in SetConnectActionFlag method. update query is - {0}", updateQuery), ex);
                return false;
            }

        }

        /// <summary>
        /// Create Event Description entries
        /// </summary>
        /// <param name="eventDescription">Event Description</param>
        /// <param name="respondedOn">Date Time Responded ON</param>
        /// <returns>Messages</returns>
        public Messages CreateEventDescription(models.EventDescription eventDescription,  out DateTime respondedOn)
        {
            respondedOn = DateTime.UtcNow;
            var isResponded = EventDescriptionType.Response.Equals(eventDescription.Type, StringComparison.InvariantCultureIgnoreCase);
            var idParam = new SqlParameter { ParameterName = "EventId", Value = eventDescription.EventId, SqlDbType = SqlDbType.Int };
            var description = new SqlParameter { ParameterName = "Description", Value = eventDescription.Description, SqlDbType = SqlDbType.NVarChar };
            var sourceType = new SqlParameter { ParameterName = "SourceType", Value = eventDescription.SourceType, SqlDbType = SqlDbType.NVarChar };
            var sourceid = new SqlParameter { ParameterName = "SourceId", Value = eventDescription.SourceId, SqlDbType = SqlDbType.Int };
            var geoInfo = new SqlParameter { ParameterName = "GeoInfo", Value = DBNull.Value };
            var geoSymbol = new SqlParameter { ParameterName = "GeoSymbol", Value = DBNull.Value };
            var responsetype = new SqlParameter { ParameterName = "Type", Value = eventDescription.Type, SqlDbType = SqlDbType.NVarChar };
            var isRespondedParam = new SqlParameter { ParameterName = "IsResponded", Value = isResponded ? 'Y' : 'N', SqlDbType = SqlDbType.NVarChar };
            var createdOn = new SqlParameter { ParameterName = "Created_On", Value = eventDescription.UpdatedOn, SqlDbType = SqlDbType.DateTime };
            var updatedOn = new SqlParameter { ParameterName = "Updated_On", Value = eventDescription.UpdatedOn, SqlDbType = SqlDbType.DateTime };

            var messages = new Messages();
            try
            {
                using (var context = new AtHocEventDbContext())
                {
                    //Make sure to main the sequence of parameter as per the stored procedure.
                    var result = context.Database.ExecuteSqlCommand(
                         "SET_EVENT_DESCRIPTION @EventId,@Description,@SourceType,@SourceId,@GeoInfo,@GeoSymbol,@Type,@IsResponded,@Created_On,@Updated_On",
                         idParam, description, sourceType, sourceid, geoInfo, geoSymbol, responsetype, isRespondedParam, createdOn,updatedOn);
                    respondedOn = Convert.ToDateTime(createdOn.Value);
                    messages.CreateSuccessMessage("Object has been Created.");
                }
            }
            catch (Exception ex)
            {

                messages.CreateErrorMessage(ex);
            }
            return messages;
        }


        /// <summary>
        /// Add Response to Event; Also mark Event as Responded
        /// </summary>
        /// <param name="eventDescriptions">List of Responses</param>
        /// <returns>Boolean</returns>
        public bool AddEventResponseOption(List<models.EventDescription> eventDescriptions)
        {
            try
            {
                using (var context = new AtHocEventDbContext())
                {
                    foreach (var eventDescription in eventDescriptions)
                    {
                        context.EventDescriptions.Add(eventDescription);
                        var evntToUpdate = context.EventEntities.FirstOrDefault(a => a.EventId == eventDescription.EventId);

                        //Mark is responsed = Y
                        evntToUpdate.IsResponded = "Y";
                    }
                    context.SaveChanges();
                    return true;
                }

            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Error in AddEventResponseOption", ex);
                return false;
            }

        }
       

       
    }


}