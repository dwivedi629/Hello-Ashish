﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Event.Impl
{
    public class EventManager
    {
    }


    /// <summary>
    /// Enumeration for Event Response
    /// </summary>
    public enum EventResponse
    {
        [Description("Responded Successfully")]
        Successfull,

        [Description("Event Already Responded")]
        AlreadyResponded,

        [Description("Event Already Ended")]
        EventEnded
    }

    /// <summary>
    /// Event Response Option Container
    /// This class used as object model for Event Response option.
    /// e.g. Responseoption = [{\"OptionId\":\"0\",\"ResponseText\":\"yes\"},{\"OptionId\":\"1\",\"ResponseText\":\"may be\"},{\"OptionId\":\"2\",\"ResponseText\":\"no\"}]
    ///  </summary>
    public partial class EventResponseOption
    {
        /// <summary>
        /// Response Option ID
        /// </summary>
        public int OptionId { get; set; }

        /// <summary>
        /// Response Text
        /// </summary>
        public string ResponseText { get; set; }
    }
}
