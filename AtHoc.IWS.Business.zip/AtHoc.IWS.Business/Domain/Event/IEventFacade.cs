﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using AtHoc.IWS.Business.Domain.Event.Impl;
using AtHoc.IWS.Business.Domain.Event.Spec;
using AtHoc.IWS.Business.Domain.Spec;
using AtHoc.Publishing;
using models = AtHoc.IWS.Business.Domain.Entities;
// ReSharper disable once CheckNamespace
namespace AtHoc.IWS.Business.Domain.Events
{
    public interface IEventFacade
    {
        
        //PagingInfo<models.Event> GetEvents(EventSpec eventSpec, bool includeMediaAttachments = false);
        /// <summary>
        /// Get Events by Event Spec
        /// </summary>
        /// <param name="eventSpec">Object of Type EventSpec</param>
        /// <param name="includeMediaAttachments">True/False - Include Event Media attachment</param>
        /// <returns>Collection of Event and Total Event Count</returns>
        EventWrapper GetEventsBySpec(EventSpec eventSpec, bool includeMediaAttachments = false);


        EventWrapper GetEventById(int eventId, bool includeMediaAttachments = false);
        /// <summary>
        /// Get List of Event Categories
        /// </summary>
        /// <returns>Collection of Event Categories</returns>
        List<models.EventCategory> GetEventCategories(int providerId,EventViewType viewType = EventViewType.All);

        /// <summary>
        /// Create a new Event in teh system
        /// </summary>
        /// <param name="eventObj">new event</param>
        /// <returns></returns>
        int CreateEvent(models.Event eventObj);


        /// <summary>
        /// Create new event based on alert object
        /// </summary>
        /// <param name="alert">the alert object</param>
        /// <param name="operatorId"></param>
        int CreateEvent(Alert alert ,int providerId, int operatorId);

        /// <summary>
        /// Update Event
        /// </summary>
        /// <param name="updatedEventObj">updated event</param>
        /// <returns></returns>
        bool UpdateEvent(models.Event updatedEventObj);


        IEnumerable<models.EventCategory> GetEventCategories(EventCategorySpec eventCategorySpec, string localeCode);

        /// <summary>
        /// Update Event Review Status.
        /// </summary>
        /// <param name="eventSpec">Object of type Eventspec</param>
        /// <returns>Boolean</returns>
        bool UpdateReviewStatus(EventSpec eventSpec);

        /// <summary>
        /// Create Event Description entries
        /// </summary>
        /// <param name="eventDescription">Event Description</param>
        /// <param name="message">Success or Error Message</param>
        /// <returns>Messages</returns>
        bool CreateEventDescription(models.EventDescription eventDescription, out EventResponse eventResponse, out DateTime respondedOn);

        void DelegateToResponse(int eventId);

        /// <summary>
        /// Set the flag for Event - if action performed or not. e.g. Invite Accept/Declined.
        /// </summary>
        /// <param name="eventId">List of Event Ids </param>
        /// <param name="providerId">Action Performed by</param>
        /// <param name="operatorId"></param>
        /// <param name="actionPerformed"></param>
        /// <param name="sourceOrganizationGuid">Source Organization Guid for event.</param>
        /// <returns></returns>
        bool SetConnectActionFlag(int eventId,  int providerId,int operatorId, models.ActionPerformed actionPerformed, string sourceOrganizationGuid = "");

        /// <summary>
        /// Get Enumerable of Connect Request which required action
        /// </summary>
        /// <param name="providerId">Provider Id</param>
        /// <returns>IEnumerable</returns>
        IEnumerable<models.Event> GetConnectRequest(int providerId);
        /// <summary>
        /// Get Connect Request (Invite) count
        /// </summary>
        /// <param name="providerId"></param>
        /// <returns></returns>
        int GetConnectRequestCount(int providerId);

        /// <summary>
        /// To get the events count by spec.
        /// </summary>
        /// <param name="eventSpec">Event spec.</param>
        /// <returns>Event count.</returns>
        int GetEventCountBySpec(EventSpec eventSpec);

    }
    

    public enum EventViewType
    {
        All = 1,
        Inbox = 2,
        Log = 3
    }
    public enum Severity
    {
        [Display(Name = "High")]
        Extreme,
        [IgnoreDataMember]
        Severe,
        Moderate,
        [Display(Name = "Low")]
        Minor,
        Informational,
        Unknown
    }

    public class EventDescriptionType
    {
        public static string Response = "response";
        public static string BodyUpdate = "bodyUpdate";
        public static string TitleUpdate = "titleUpdate";
        public static string SeverityUpdate = "severityUpdate";
        public static string UrlUpdate = "urlUpdate";
    }

}
