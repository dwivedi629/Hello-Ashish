﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Event
{
    /// <summary>
    /// Defines properties for any target object (which could be event or shape object)
    /// that has media attachment. 
    /// </summary>
    public interface ITargetAttachment : ITimedObject
    {
        /// <summary>
        /// Target object id. 
        /// </summary>
        int TargetId { get; set; }

        /// <summary>
        /// Media unique identifier.
        /// </summary>
        Guid MediaGuid { get; set; }
    }

    public interface ITimedObject
    {
        DateTime CreatedOn { get; set; }

        DateTime UpdatedOn { get; set; }
    }
}
