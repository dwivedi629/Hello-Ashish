﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Domain.Event;
using AtHoc.IWS.Business.Models;
using AtHoc.IWS.Business.Domain.Entities;
namespace AtHoc.IWS.Business.Domain.Media
{
    public interface IMediaRepository
    {
        IEnumerable<AtHoc.IWS.Business.Domain.Entities.Media> GetMedias();

        /// <summary>
        /// Get the list of Attached Media for Event
        /// </summary>
        /// <returns>Collection of Media Thumbnail</returns>
        IEnumerable<AtHoc.IWS.Business.Domain.Entities.MediaThumbnail> GetMediaThumbnails();
        IEnumerable<AtHoc.IWS.Business.Domain.Entities.Media> GetMediasByMediaGuid(List<System.Guid> mediaGuids);
        List<AtHoc.IWS.Business.Domain.Entities.Media> GetMediaAttachment<T>(T target) where T : IEnumerable<ITargetAttachment>;


    }

    
}
