﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Events;
using models = AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.Media
{
    public class MediaFacade:IMediaFacade
    {
        private readonly IMediaRepository _repository;
        private readonly IEventRepository _eventRepository;

        public MediaFacade(IMediaRepository repository, IEventRepository eventRepository)
        {
            _repository = repository;
            _eventRepository = eventRepository;
        }

        public IEnumerable<models.Media> GetMediaList()
        {
            return _repository.GetMedias();
        }

        public IEnumerable<models.Media> GetMediaByEventIds(List<int> eventIds)
        {
            //Get MediaGuids from ngevent.dbo.eventMedia table
            var eventmedias = _eventRepository.GetEventMediasByEventIds(eventIds);
            var pid = RuntimeContext.ProviderId;
            var mediaGuids = eventmedias.Select(a => a.MediaId).ToList();
            return this.GetMediaByMediaGuids(mediaGuids);

        }


        public IEnumerable<models.Media> GetMediaByMediaGuids(List<Guid> mediaGuids)
        {
           return _repository.GetMediasByMediaGuid(mediaGuids);
        }


        
    }
}
