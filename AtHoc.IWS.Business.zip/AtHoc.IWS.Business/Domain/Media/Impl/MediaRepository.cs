﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.Event;
using AtHoc.IWS.Business.Models;
using AtHoc.Utilities;
using Microsoft.Practices.ObjectBuilder2;
using models = AtHoc.IWS.Business.Domain.Entities;
namespace AtHoc.IWS.Business.Domain.Media.Impl
{
    public class MediaRepository : IMediaRepository
    {
        public IEnumerable<models.Media> GetMedias()
        {
            using (var db = new AthocCommonDbContext())
            {
                var medias = db.Medias;// <AtHoc.IWS.Business.Models.Media>();
                return medias;
            }
        }


        /// <summary>
        /// Get the list of Attached Media for Event
        /// </summary>
        /// <returns>Collection of Media Thumbnail</returns>
        public IEnumerable<models.MediaThumbnail> GetMediaThumbnails()
        {
            using (var db = new AthocCommonDbContext())
            {
                var mediaThumbnails = db.MediaThumbnails;// <AtHoc.IWS.Business.Models.Media>();
                return mediaThumbnails;
            }
        }


        public IEnumerable<models.Media> GetMediasByMediaGuid(Guid mediaGuid)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<models.Media> GetMediasByMediaGuid(List<Guid> mediaGuids)
        {
            var medias = this.GetListOfMediaByMediaGuids(mediaGuids).ToList<models.Media>();
            medias.ForEach(a=>a.ParentMediaGuid = a.MediaGuid);

            var mt = this.GetListOfMediaFromMediaThumbnailByMediaGuids(mediaGuids).ToList<models.Media>(); //Media Thumbnails
            mt.ForEach(attachment => medias.Add(attachment));
            return medias;


        }

        private IEnumerable<models.Media> GetListOfMediaByMediaGuids(List<Guid> mediaGuids)
        {
            using (var context = new AthocCommonDbContext())
            {
                var mediaQuery = from media in context.Medias
                    // <-- querying the ngcommon.dbo.Media table
                    where mediaGuids.Contains(media.MediaGuid)
                    select media;
                                 //select new Models.Media
                                 //{
                                 //    MediaId = media.MediaId,
                                 //    MediaGuid = media.MediaGuid,
                                 //    Status = media.Status,
                                 //    MediaGroup = media.MediaGroup,
                                 //    ContentType = media.ContentType,
                                 //    FileName = media.FileName,
                                 //    Extension = media.Extension,
                                 //    Description = media.Description,
                                 //    Height = media.Height,
                                 //    Width = media.Width,
                                 //    AllowWebAccess = media.AllowWebAccess,
                                 //    Source = media.Source,
                                 //    CreatedOn = media.CreatedOn,
                                 //    UpdatedOn = media.UpdatedOn,
                                 //    CreatedBy = media.CreatedBy,
                                 //    UpdatedBy = media.UpdatedBy,
                                 //    ConvertTo = media.ConvertTo,
                                 //    Rotation = media.Rotation

                                 //};
                var mediaQueryResults = mediaQuery.ToList();

                return mediaQueryResults;
            }
        }

        private IEnumerable<models.Media> GetListOfMediaFromMediaThumbnailByMediaGuids(List<Guid> mediaGuids)
        {
            using (var context = new AthocCommonDbContext())
            {
                var mediaThumbnailAttachmentsQuery = from media1 in context.Medias
                    // <-- querying the ngcommon.dbo.Media table
                    join mediaData in context.MediaDatas on media1.MediaId equals mediaData.MediaId
                    // <-- join with ngcommon.dbo.MediaData table
                    join t in
                        from mediaThumbnail in context.MediaThumbnails
                        join media2 in context.Medias on mediaThumbnail.MediaId equals media2.MediaId
                        where mediaGuids.Contains(media2.MediaGuid)
                        select new {ThumbnailId = mediaThumbnail.ThumbnailMediaId, media2.MediaId, media2.MediaGuid}
                        on media1.MediaId equals t.ThumbnailId
                    select new
                    {
                        ParentMediaGuid = media1.MediaGuid,
                        MediaId = media1.MediaId,
                        MediaGuid = media1.MediaGuid,
                        Status = media1.Status,
                        MediaGroup = media1.MediaGroup,
                        ContentType = media1.ContentType,
                        FileName = media1.FileName,
                        Extension = media1.Extension,
                        Description = media1.Description,
                        Height = media1.Height,
                        Width = media1.Width,
                        AllowWebAccess = media1.AllowWebAccess,
                        Source = media1.Source,
                        CreatedOn = media1.CreatedOn,
                        UpdatedOn = media1.UpdatedOn,
                        CreatedBy = media1.CreatedBy,
                        UpdatedBy = media1.UpdatedBy,
                        ConvertTo = media1.ConvertTo,
                        Rotation = media1.Rotation

                    };
                List<models.Media> lstOfMedia = new List<models.Media>(); 
                foreach (var a in mediaThumbnailAttachmentsQuery.AsEnumerable())
                {
                    lstOfMedia.Add(new models.Media
                    {
                        ParentMediaGuid = a.MediaGuid,
                        MediaId = a.MediaId,
                        MediaGuid = a.MediaGuid,
                        Status = a.Status,
                        MediaGroup = a.MediaGroup,
                        ContentType = a.ContentType,
                        FileName = a.FileName,
                        Extension = a.Extension,
                        Description = a.Description,
                        Height = a.Height,
                        Width = a.Width,
                        AllowWebAccess = a.AllowWebAccess,
                        Source = a.Source,
                        CreatedOn = a.CreatedOn,
                        UpdatedOn = a.UpdatedOn,
                        CreatedBy = a.CreatedBy,
                        UpdatedBy = a.UpdatedBy,
                        ConvertTo = a.ConvertTo,
                        Rotation = a.Rotation
                    });
                }
                // System.Diagnostics.Debug.WriteLine(mediaThumbnailAttachmentsQuery);  // Parallel tasks will block each other so commit it out after debugging
                var thumbnailAttachmentsResults = mediaThumbnailAttachmentsQuery.ToList(); // execute this query
                return lstOfMedia.AsEnumerable();

            }
        }


        public List<models.Media> GetMediaAttachment<T>(T target) where T : IEnumerable<ITargetAttachment>
        {
            List<models.Media> mediaAttachmentsList;
            using (var context = new AthocCommonDbContext())
            {
                mediaAttachmentsList = GetMediaAttachments(target, context);
                var thumbnailAttachments = GetThumbnailAttachments(target, context);

                // add thumbnail attachments, if any, to the mediaAttachments class
                thumbnailAttachments.ForEach(thumbnailAttachment => mediaAttachmentsList.Add(thumbnailAttachment));
            }
            return mediaAttachmentsList;
        }

        private static List<models.Media> GetMediaAttachments<T>(T targetMediae, AthocCommonDbContext context)
            where T : IEnumerable<ITargetAttachment>
        {
            var mediaGuids = targetMediae.Select(target => target.MediaGuid).ToList();
            var mediaQuery = from media in context.Medias // <-- querying the ngcommon.dbo.Media table
                             join mediaData in context.MediaDatas // <-- join with ngcommon.dbo.MediaData table
                             on media.MediaId equals mediaData.MediaId
                             where mediaGuids.Contains(media.MediaGuid) 
                             select new
                             {
                                 // TargetId = Can't get the TargetId from the last join due to the linq-to-entities limitation.  
                                 // creates a Anonymous class here and the results stored in the mediaQueryResults in-memory.  
                                 // and (see below)....
                                 Checksum = mediaData.HashCode,
                                 media.ContentType,
                                 media.MediaGuid,
                                 media.MediaId,
                                 media.Description,
                                 media.Height,
                                 media.Width,
                                 media.Rotation
                             };
            // System.Diagnostics.Debug.WriteLine(mediaQuery);  // Parallel tasks will block each other so commit it out after debugging
            var mediaQueryResults = mediaQuery.ToList();

            // and.... join those 2 in-memory tables to produce the final MediaResult object to workaround the limitation.
            var mediaAttachmentsQuery = from mediaQueryResult in mediaQueryResults
                                        join inMemoryTargetMedia in targetMediae on mediaQueryResult.MediaGuid equals inMemoryTargetMedia.MediaGuid
                                        select new models.Media
                                        {
                                            Checksum = mediaQueryResult.Checksum,
                                            ContentType = mediaQueryResult.ContentType,
                                            TargetId = inMemoryTargetMedia.TargetId,
                                            MediaGuid = mediaQueryResult.MediaGuid,
                                            MediaId = mediaQueryResult.MediaId,
                                            CreatedOn = inMemoryTargetMedia.CreatedOn,
                                            AdditionalContentType = ConvertContentTypeToAdditionalContentType(mediaQueryResult.ContentType, false),
                                            Description = mediaQueryResult.Description,
                                            Height = mediaQueryResult.Height,
                                            Width = mediaQueryResult.Width,
                                            Rotation = mediaQueryResult.Rotation
                                            
                                        };
            var mediaAttachments = mediaAttachmentsQuery.ToList();
            return mediaAttachments;
        }

        private static List<models.Media> GetThumbnailAttachments<T>(T targetMediae, AthocCommonDbContext context)
            where T : IEnumerable<ITargetAttachment>
        {
            var mediaGuids = targetMediae.Select(em => em.MediaGuid).ToList();
            var mediaThumbnailAttachmentsQuery = from media1 in context.Medias // <-- querying the ngcommon.dbo.Media table
                                                 join mediaData in context.MediaDatas on media1.MediaId equals mediaData.MediaId // <-- join with ngcommon.dbo.MediaData table
                                                 join t in
                                                     from mediaThumbnail in context.MediaThumbnails
                                                     join media2 in context.Medias on mediaThumbnail.MediaId equals media2.MediaId
                                                     where mediaGuids.Contains(media2.MediaGuid)
                                                     select new { ThumbnailId = mediaThumbnail.ThumbnailMediaId, media2.MediaId, media2.MediaGuid }
                                                     on media1.MediaId equals t.ThumbnailId
                                                 select new
                                                 {
                                                     t.MediaId,
                                                     t.MediaGuid,
                                                     ThumbnailMediaId = media1.MediaId,
                                                     ThumbnailMediaGuid = media1.MediaGuid,
                                                     ThumbnailContent = media1.ContentType,
                                                     ThumbnailChecksum = mediaData.HashCode,
                                                     ThumbnailDescription = media1.Description,
                                                     Height = media1.Height,
                                                     Width = media1.Width,
                                                     Rotation = media1.Rotation
                                                 };
            // System.Diagnostics.Debug.WriteLine(mediaThumbnailAttachmentsQuery);  // Parallel tasks will block each other so commit it out after debugging
            var thumbnailAttachmentsResults = mediaThumbnailAttachmentsQuery.ToList(); // execute this query

            var thumbnailAttachmentsQuery =
                 from mediaThumbnailAttachment in
                     thumbnailAttachmentsResults.ToList()//.Where(md => md.ThumbnailDescription.StartingWord().ToLower() == "small").ToList() // my bad - we should have a column to indicate that this is small generated thumbnail, rather than asking developer to hard code the "small" string in the Description column.
                 join inMemoryMedia in targetMediae on mediaThumbnailAttachment.MediaGuid equals inMemoryMedia.MediaGuid
                 select new models.Media
                 {
                     ParentMediaGuid = mediaThumbnailAttachment.MediaGuid,
                     Checksum = mediaThumbnailAttachment.ThumbnailChecksum,
                     ContentType = mediaThumbnailAttachment.ThumbnailContent,
                     TargetId = inMemoryMedia.TargetId,
                     MediaGuid = mediaThumbnailAttachment.ThumbnailMediaGuid,
                     MediaId = mediaThumbnailAttachment.MediaId, //.ThumbnailMediaId, 2013-04-23
                     CreatedOn = inMemoryMedia.CreatedOn,
                     AdditionalContentType = ConvertContentTypeToAdditionalContentType(mediaThumbnailAttachment.ThumbnailContent, true),
                     Description = mediaThumbnailAttachment.ThumbnailDescription,
                     Height = mediaThumbnailAttachment.Height,
                     Width = mediaThumbnailAttachment.Width,
                     Rotation = mediaThumbnailAttachment.Rotation
                 };
            // System.Diagnostics.Debug.WriteLine(thumbnailAttachmentsQuery);   // Parallel tasks will block each other so commit it out after debugging
            var thumbnailAttachments = thumbnailAttachmentsQuery.ToList();
            return thumbnailAttachments;
        }

        private static MediaContentType ConvertContentTypeToAdditionalContentType(string contentType, bool isThumbnail)
        {
            // the input content type has 'image/jpeg, image/png, image/gif, video/mp4, video/3gp
            // the output should be 'Photo' for all content types starts with 'image', or 'Video' 
            // for 'video'; in addition if the isThumbnail is true, we return 'Thumbnail' to indicate 
            // this media is a thumbnail.
            switch (contentType.Split('/')[0].ToLower())
            {
                case "image":
                    return (isThumbnail) ? MediaContentType.Thumbnail : MediaContentType.Photo;
                case "video":
                    return (isThumbnail) ? MediaContentType.Thumbnail : MediaContentType.Video;
                default:
                    return MediaContentType.Unknown;
            }
        }
    }

}

