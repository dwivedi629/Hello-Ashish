﻿using System;
using System.Collections.Generic;
using AtHoc.IWS.Business.Models;
using models = AtHoc.IWS.Business.Domain.Entities;
namespace AtHoc.IWS.Business.Domain.Media
{
    public interface IMediaFacade
    {
        IEnumerable<models.Media> GetMediaList();

        IEnumerable<models.Media> GetMediaByEventIds(List<int> eventIds);

        IEnumerable<models.Media> GetMediaByMediaGuids(List<Guid> mediaGuids);

    }
}
