﻿using System.Collections.Generic;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using System.Security.Cryptography.X509Certificates;
using AtHoc.IWS.Business.Domain.RuleModel.Spec;
using AtHoc.Publishing;
using AtHoc.IWS.Business.Domain.Entities.Rule.Enum;

namespace AtHoc.IWS.Business.Domain.RuleModel
{
    public interface IRuleFacade
    {

        IEnumerable<Rule> Get(RuleSpec spec, string ruleType="");
        Rule Get(int ruleId, bool loadSearchCriteria = false, string ruleType="");

        IEnumerable<Rule> GetFeedRules(RuleSpec spec, FeedTypes feedType, string ruleType = "");
        int Save(Rule rule, SearchEntity searchEntity = null);
        bool Update(Rule rule, SearchEntity searchEntity = null);
        bool Delete(IEnumerable<int> ruleIds);
        bool ReOrder(ICollection<RuleOrder> ruleOrderValuePair);

        bool DeleteWeather(IEnumerable<int> ruleIds);
        //bool Execute(IList<Rule> ruleSet, IRuleOperandProvider operandProvider, int providerId, out List<RuleAction> actions);

        CustomAttributeLookup GetRuleAttributeLookup(string entityId = "ALERT");

    }

    /// <summary>
    /// Interface to Pass Rule Id and Sequence Order pair.
    /// </summary>
    public class RuleOrder
    {
        // Property declaration:
        public int RuleId{get;set;}
        public int Order{get;set;}
    }
}
