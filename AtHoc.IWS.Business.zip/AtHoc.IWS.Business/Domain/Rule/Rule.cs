﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Entities.Search;
using ActionType = AtHoc.IWS.Business.Domain.Entities.Rule.Enum.ActionType;


namespace AtHoc.IWS.Business.Domain.RuleModel
{
    /// <summary>
    /// Rule Business (Domain Model)
    /// </summary>
    public class Rule
    {
        //Default Constructor
        public Rule() { }
        
        /// <summary>
        /// Copy Constructor
        /// </summary>
        /// <param name="rule"></param>
        public Rule(Rule rule)
        {
            Id = rule.Id;
            ProviderId = rule.ProviderId;
            Name = rule.Name;
            Order = rule.Order;
            CriteriaEntityId = rule.CriteriaEntityId;
            StopProcessing = rule.StopProcessing;
            Criteria = rule.Criteria;
            IsStandard = rule.IsStandard;
            isEnable = rule.isEnable;
            GroupId = rule.GroupId;
            isWeatherModule = rule.isWeatherModule;
            WeatherCounty = rule.WeatherCounty;
            WeatherSeverityType = rule.WeatherSeverityType;
            WeatherEventType = rule.WeatherEventType;
            weatherKeywords = rule.weatherKeywords;
            Actions = rule.Actions.Select(s=> new RuleAction(s)).ToList();
            Criterias = rule.Criterias.Select(s => new RuleCriteria(s)).ToList();
            GeoEnabled = rule.GeoEnabled;
        }
        /// <summary>
        /// Rule Id
        /// </summary>
        public int Id { get; set; }

        public int ProviderId { get; set; }

        /// <summary>
        /// Rule Name
        /// </summary>
        public string Name { get; set; }

        public IList<RuleCriteria> Criterias { get; set; }

        /*1. Execute Scenario, 2. Delegate to Response Option*/
        public ICollection<RuleAction> Actions { get; set; }

        /// <summary>
        /// Rule Display/Execution Order
        /// </summary>
        public int Order { get; set; }

        /// <summary>
        /// Criteria Entity Id (Mapped to SEARCH_ENTITY_TAB => Id)
        /// </summary>
        public int CriteriaEntityId { get; set; }

        public bool StopProcessing { get; set; }

        public AtHoc.Publishing.SearchEntity Criteria { get; set; }

        public bool IsStandard { get; set; }

        public string isEnable { get; set; }
        public int? GroupId { get; set; }
        public bool isWeatherModule { get; set; }

        public string WeatherCounty { get; set; }
        public string WeatherSeverityType { get; set; }

        public string WeatherEventType { get; set; }
        public string weatherKeywords { get; set; }
        public string GeoEnabled { get; set; }
    }

    public class RuleCriteria
    {
        //Default Constructor
        public RuleCriteria() { }
        
        /// <summary>
        /// Copy Constructor
        /// </summary>
        /// <param name="criteria"></param>
        public RuleCriteria(RuleCriteria criteria)
        {
            Id = criteria.Id;
            AttributeName = criteria.AttributeName;
            AttributeType = criteria.AttributeType;
            Operator = criteria.Operator;
            AttributeValue = criteria.AttributeValue;
        }
        //"Title" Contains ('FIRE') AND Organization IS ('GUID1,GUID2')  AND Severity CONTAINS (1,2,3,4,5)

        /// <summary>
        /// Query Id => SEARCH_QUERY_TAB =>Id
        /// </summary>
        public int Id { get; set; }
        public string AttributeName { get; set; }
        public CustomAttributeDataType? AttributeType { get; set; }
        public SearchOperators Operator { get; set; }
        public IList<string> AttributeValue { get; set; }
    }


    public class RuleAction
    {
        //Default Constructor
        public RuleAction() { }
        
        /// <summary>
        /// Copy Constructor
        /// </summary>
        /// <param name="ruleAction"></param>
        public RuleAction(RuleAction ruleAction)
        {
            ActionId = ruleAction.ActionId;
            ActionName = ruleAction.ActionName;
            ActionContext = ruleAction.ActionContext;
            ActionValues = ruleAction.ActionValues;
        }

        /*1. Execute Scenario, 2. Delegate to Response Option*/
        public int ActionId { get; set; }
        public ActionType ActionName { get; set; }
        public string ActionContext { get; set; }
        public Dictionary<string, object> ActionValues { get; set; }

        public class RuleActionParameterKeys
        {
            public static string DELEGATE_RESPONSES = "DELEGATE_RESPONSES";
            public static string SCENARIO_ID = "SCENARIO_ID";
            public static string SCENARIO_COMMON_NAME = "SCENARIO_COMMON_NAME";
            public static string GEOENABLED = "IS_GEOENABLED";
        }
    }

}
