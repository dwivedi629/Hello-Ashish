﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AtHoc.IWS.Business.Domain.Entities;
using ActionType = AtHoc.IWS.Business.Domain.Entities.Rule.Enum.ActionType;

namespace AtHoc.IWS.Business.Domain.RuleModel
{
    public interface IRuleOperandProvider
    {
        T GetOperandValue<T>(string operandName, object executionContext);
        CustomAttributeDataType? GetOperandType(string operandName, object executionContext);
    }

    public interface IRuleExecutionProvider
    {
        IDictionary<ActionType, IRuleActionExecutor> GetRuleActionExecutionSet();        
    }


    public interface IRuleActionExecutor
    {
       bool ExecuteAction(Rule matchedRule, RuleAction action, Object runtimeContext);
    }


    


}
