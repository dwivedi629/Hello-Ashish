﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Entities.Search;


namespace AtHoc.IWS.Business.Domain.RuleModel
{
    public interface IRuleRepository
    {
        int Add(RuleEntity ruleEntity);
        int Update(RuleEntity ruleEntity, out bool isStatusUpdate);

        /// <summary>
        /// ReOrder Rule Sequence
        /// </summary>
        /// <param name="ruleSequence">Dictionary of Rule and SequenceOrder</param>
        /// <param name="updatedBy">UpdatedBy</param>
        List<RuleEntity> ReOrder(IEnumerable<RuleOrder> ruleSequence, int updatedBy);

        List<RuleEntity> Remove(IEnumerable<int> ruleId, int updatedBy);

        bool DeleteWeather(IEnumerable<int> ruleId);

        List<RuleEntity> GetDeleteWeatherDetails(IEnumerable<int> ruleId);
        IEnumerable<RuleEntity> GetRules();
        IEnumerable<RuleActionEntity> GetRuleActions();
        IEnumerable<SearchEntity> GetRuleSearchEntityId(int[] ruleIds, string searchEntityType);
    }
}
