﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.RuleModel.Spec
{
   public class RuleSpec
    {
       public int ProviderId { get; set; }
       public bool LoadSearchCriteria { get; set; }
       public int RuleId { get; set; }

       public string BaseLocale { get; set; }

       /// <summary>
       /// This property has been used by IncomingAlertRulePlugin.
       /// When true: that means RuleCriterias  collection in Rule instance should be retrieved.
       /// </summary>
       public bool LoadRuleCriterias { get; set; }
    }
}
