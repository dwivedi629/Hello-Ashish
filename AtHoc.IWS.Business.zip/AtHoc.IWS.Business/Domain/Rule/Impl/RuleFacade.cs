﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.d911.Model.Organization;
using AtHoc.Diagnostics;
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Audit;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.IWS.Business.Domain.RuleModel;
using AtHoc.IWS.Business.Domain.RuleModel.Spec;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Organization;
using AtHoc.IWS.Business.Domain.Organization.Impl;
using AtHoc.Global.Resources;
using AtHoc.Publishing;
using AtHoc.Utilities;
using System.Globalization;
using ActionType = AtHoc.IWS.Business.Domain.Entities.Rule.Enum.ActionType;
using SearchOperators = AtHoc.IWS.Business.Domain.Entities.Search.SearchOperators;
using RuleTypes = AtHoc.IWS.Business.Domain.Entities.Rule.Enum.RuleTypes;
using AtHoc.IWS.Business.Domain.Entities.Rule.Enum;

namespace AtHoc.IWS.Business.Domain.RuleModel.Impl
{
    public class RuleFacade : IRuleFacade
    {
        #region Constants And Fields
        private readonly IRuleRepository _ruleRepository;
        private readonly ISearchCriteriaRepository _searchCriteriaRepository;
        private readonly ICustomAttributeFacade _customAttributeFacade;
        private readonly ICustomAttributeCache _customAttributeCache;
        private readonly ICustomAttributeValueCache _customAttributeValueCache;

        private static IDictionary<int, CustomAttribute> RuleCustomAttribute { get; set; }
        private const string SEARCH_ENTITY_TYPE_RULE = "RULE";
        private const string SEARCH_ENTITY_TYPE_WAM = "WAM";
        public int ProviderId { get; set; }

        #endregion

        #region Constructor
        public RuleFacade(IRuleRepository ruleRepository, ISearchCriteriaRepository searchCriteriaRepository, ICustomAttributeFacade customAttributeFacade, ICustomAttributeCache customAttributeCache, ICustomAttributeValueCache customAttributeValueCache)
        {
            _ruleRepository = ruleRepository;
            _searchCriteriaRepository = searchCriteriaRepository;
            _customAttributeFacade = customAttributeFacade;
            _customAttributeCache = customAttributeCache;
            _customAttributeValueCache = customAttributeValueCache;
        }
        #endregion

        /// <summary>
        /// Get the List for Rules
        /// </summary>
        /// <param name="spec">Rule Spec</param>
        /// <param name="ruleType">Rule Types</param>
        /// <returns>Enumerable collection of Rule</returns>
        public IEnumerable<Rule> Get(RuleSpec spec, string ruleType = "")
        {
            if (string.IsNullOrEmpty(ruleType))
                ruleType = RuleTypes.INCOMING_ALERT_RULE.ToString();

            return GetData(spec, FeedTypes.WAM, ruleType);
        }

        public IEnumerable<Rule> GetFeedRules(RuleSpec spec,FeedTypes feedType ,string ruleType = "")
        {
            if (string.IsNullOrEmpty(ruleType))
                ruleType = RuleTypes.INCOMING_ALERT_RULE.ToString();
            
            return GetData(spec, feedType, ruleType);
        }

        /// <summary>
        /// Get the List for Rules
        /// </summary>
        /// <param name="spec">Rule Spec</param>
        /// <returns>Enumerable collection of Rule</returns>
        private IEnumerable<Rule> GetData(RuleSpec spec,FeedTypes feedType ,string ruleType = "")
        {


            try
            {
                if (spec == null || spec.ProviderId == 0)
                {
                    EventLogger.WriteError(string.Format("Error while getting Rule List  Provider Id cannot be null "));
                    return null;
                }
                ProviderId = spec.ProviderId;
                //Get Rules 
                IEnumerable<RuleEntity> rules;

                if(ruleType == RuleTypes.INCOMING_ALERT_RULE.ToString())
                {
                    rules =
                        _ruleRepository.GetRules()
                            .Where(a => a.IsActive == "Y" && a.ProviderId == spec.ProviderId && a.RuleType == ruleType);
                }
                else if (ruleType == RuleTypes.INCOMING_FEED_RULE_PROCESSING.ToString())
                {
                    rules = _ruleRepository.GetRules().Where(a => a.IsActive == "Y" && a.RuleType == RuleTypes.INCOMING_FEED_RULE.ToString());
                }
                else
                {
                    rules =
                        _ruleRepository.GetRules().Where(a => a.ProviderId == spec.ProviderId && a.RuleType == ruleType);
                }

                var ruleEntities = rules as RuleEntity[] ?? rules.ToArray();
                if (!ruleEntities.Any())
                {
                    EventLogger.WriteVerbose(string.Format("No Rule Found for Provider Id- {0}", spec.ProviderId));
                    return new List<Rule>();
                }
                var ruleIds = ruleEntities.Select(a => a.Id).ToArray();
                //Get SearchEntity for Rule
                var dictionarySearchEntityByRuleId = new Dictionary<int, Entities.Search.SearchEntity>();

                var searchEntities = _ruleRepository.GetRuleSearchEntityId(ruleIds, SEARCH_ENTITY_TYPE_RULE);
                //Build dictionary for SearchEntityObject with RuleId as Key
                foreach (var ent in searchEntities)
                {
                    dictionarySearchEntityByRuleId.Add(ent.EntityId, ent);
                }

                RuleCustomAttribute = (ruleType == RuleTypes.INCOMING_ALERT_RULE.ToString()) ? GetCustomAttributeForRule(ProviderId) :
                                        GetCustomAttributeForRule(ProviderId, feedType.ToString());
               
                var ruleList = new List<Rule>();
                foreach (var ruleEntity in ruleEntities)
                {
                    var list = searchEntities.Where(a => a.EntityId.Equals(ruleEntity.Id)).ToList();
                    var rulemodel = ConvertToRuleModel(ruleEntity, dictionarySearchEntityByRuleId, spec.LoadRuleCriterias, ruleType);
                    ruleList.Add(rulemodel);
                }

                return ruleList;

            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("Error while getting Rule List for Provider Id - {0}", spec.ProviderId), ex);
                return null;
            }

        }


        /// <summary>
        /// Get Rule by RuleId
        /// </summary>
        /// <param name="ruleId">Integer Rule Id</param>
        /// <param name="loadSearchCriteria"></param>
        /// <returns>Rule Model</returns>
        public Rule Get(int ruleId, bool loadSearchCriteria = false, string ruleType = "")
        {
            try
            {
                this.ProviderId = RuntimeContext.ProviderId;
                var ruleEntity = _ruleRepository.GetRules().FirstOrDefault(a => a.Id == ruleId);
                var searchEntities = _ruleRepository.GetRuleSearchEntityId(new[] { ruleId }, SEARCH_ENTITY_TYPE_RULE);
                var rule = ConvertToRuleModel(ruleEntity, searchEntities.ToDictionary(a => a.EntityId));
                if (!loadSearchCriteria)
                {
                    return rule;
                }
                var searchentity = _searchCriteriaRepository.GetSearchEntity(ruleId, SearchEntityType.Rule);
                rule.Criteria = searchentity;
                return rule;
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("Error while getting Rule => RuleId {0} ", ruleId), ex);
                return null;
            }
        }

        /// <summary>
        /// Save Rule
        /// </summary>
        /// <param name="rule"></param>
        /// <param name="searchEntity"></param>
        /// <returns>Int RuleId</returns>
        public int Save(Rule rule, AtHoc.Publishing.SearchEntity searchEntity = null)
        {
            int ruleId = 0;
            try
            {
                //Build Rule Entity Model
                var ruleEntity = new RuleEntity
                {
                    Name = rule.Name,
                    ProviderId = RuntimeContext.ProviderId,
                    IsActive = rule.isWeatherModule ? rule.isEnable : "Y",
                    IsStandard = "N",
                    Order = rule.Order,
                    StopProcessing = rule.StopProcessing,
                    CreatedBy = RuntimeContext.OperatorId,
                    UpdatedBy = RuntimeContext.OperatorId,
                    CreatedOn = DateTime.UtcNow,
                    UpdatedOn = DateTime.UtcNow,
                    RuleType = rule.isWeatherModule ? RuleTypes.INCOMING_FEED_RULE.ToString() : RuleTypes.INCOMING_ALERT_RULE.ToString(),
                    GroupId = rule.isWeatherModule ? 1 : 0
                };

                var ruleActionEntities = new List<RuleActionEntity>();
                foreach (var action in rule.Actions)
                {
                    var entityActionValues = new List<RuleActionValueEntity>();

                    if (action.ActionValues != null)
                    {
                        foreach (var actionValue in action.ActionValues)
                        {
                            var raValue = new RuleActionValueEntity();
                            raValue.ParameterKey = actionValue.Key;
                            raValue.ParameterValue = actionValue.Value.ToString();
                            entityActionValues.Add(raValue);
                        }
                    }
                    var ruleActionEntity = new RuleActionEntity
                    {
                        ActionType = action.ActionName,
                        ActionTypeContext = null,
                        RuleActionValueEntities = entityActionValues,
                        CreatedBy = RuntimeContext.OperatorId,
                        UpdatedBy = RuntimeContext.OperatorId,
                        CreatedOn = DateTime.UtcNow,
                        UpdatedOn = DateTime.UtcNow
                    };
                    ruleActionEntities.Add(ruleActionEntity);
                }
                ruleEntity.RuleActionEntities = ruleActionEntities;
                ruleId = _ruleRepository.Add(ruleEntity);

                //If Rule is saved, then save Rule Criteria
                if (ruleId > 0 && searchEntity != null)
                {
                    searchEntity.EntityID = ruleId;
                    searchEntity.EntityType = SearchEntityType.Rule;
                    searchEntity.ProviderID = RuntimeContext.ProviderId;
                    CreateSearchEntity(searchEntity);

                    if (rule.isWeatherModule)
                    {
                        this.UpdateAuditLog(ruleEntity.Name, ServiceAction.WeatherRuleCreated, EntityType.WeatherAlertRule);
                        this.UpdateAuditLog(ruleEntity.Name, rule.isEnable == "Y" ? ServiceAction.WeatherRuleEnabled:ServiceAction.WeatherRuleDisabled, EntityType.WeatherAlertRule);
                    }
                    else
                    {
                        this.UpdateAuditLog(ruleEntity.Name, ServiceAction.AlertRuleCreated, EntityType.AlertRule);
                    }
                }

            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("Error in RuleFacade => Save "), ex);
            }

            return ruleId;

        }



        /// <summary>
        /// Update Rules
        /// </summary>
        /// <param name="rule">Rule Model</param>
        /// <param name="searchEntity">SearchEntity</param>
        /// <returns>Boolean</returns>
        public bool Update(Rule rule, AtHoc.Publishing.SearchEntity searchEntity = null)
        {
            var ruleActionEntities = new List<RuleActionEntity>();
            try
            {
                var ruleEntity = new RuleEntity
                {
                    Id = rule.Id,
                    Name = rule.Name,
                    Order = rule.Order,
                    IsActive = rule.isWeatherModule ? rule.isEnable : "Y",
                    StopProcessing = rule.StopProcessing,
                    UpdatedBy = RuntimeContext.OperatorId,
                    UpdatedOn = DateTime.UtcNow
                };

                foreach (var action in rule.Actions)
                {
                    var entityActionValues = new List<RuleActionValueEntity>();

                    if (action.ActionValues != null)
                    {
                        foreach (var actionValue in action.ActionValues)
                        {
                            var raValue = new RuleActionValueEntity
                            {
                                ParameterKey = actionValue.Key,
                                ParameterValue = actionValue.Value.ToString()
                            };
                            entityActionValues.Add(raValue);
                        }

                    }
                    RuleActionEntity ruleActionEntity = new RuleActionEntity
                    {
                        ActionType = action.ActionName,
                        ActionTypeContext = null,
                        RuleActionValueEntities = entityActionValues,
                        CreatedBy = RuntimeContext.OperatorId,
                        UpdatedBy = RuntimeContext.OperatorId,
                        CreatedOn = DateTime.UtcNow,
                        UpdatedOn = DateTime.UtcNow
                    };
                    ruleActionEntities.Add(ruleActionEntity);
                }

                ruleEntity.RuleActionEntities = ruleActionEntities;
                bool isStatusUpdate = false;
                int ruleId = _ruleRepository.Update(ruleEntity,out isStatusUpdate);
                //Update Search Entity
                if (searchEntity != null)
                {
                    searchEntity.EntityID = ruleId;
                    searchEntity.EntityType = SearchEntityType.Rule;
                    searchEntity.ProviderID = RuntimeContext.ProviderId;
                    // CreateSearchEntity also remove the onld search entity.
                    // todo: check of criteria changed before re creating new entries.
                    CreateSearchEntity(searchEntity);
                    if (rule.isWeatherModule)
                    {
                        this.UpdateAuditLog(ruleEntity.Name,ServiceAction.WeatherRuleUpdated,EntityType.WeatherAlertRule);
                        if (isStatusUpdate)
                        {
                            this.UpdateAuditLog(ruleEntity.Name, rule.isEnable == "Y" ? ServiceAction.WeatherRuleEnabled : ServiceAction.WeatherRuleDisabled, EntityType.WeatherAlertRule); 
                        }
                    }
                    else
                    {
                        this.UpdateAuditLog(ruleEntity.Name, ServiceAction.AlertRuleUpdated, EntityType.AlertRule);
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("Error while deleting the Rules"), ex);
                return false;

            }
        }

        /// <summary>
        /// Generic method to update entry in log
        /// </summary>
        /// <param name="objName"></param>
        /// <param name="sAction"></param>
        /// <param name="objType"></param>
        private void UpdateAuditLog(string objName, ServiceAction sAction, EntityType objType)
        {
            var auditSpec = new AuditSpec();
            auditSpec.OperatorId = RuntimeContext.OperatorId;
            auditSpec.ProviderId = RuntimeContext.ProviderId;
            auditSpec.ObjectName = objName;
            auditSpec.Action = sAction;
            auditSpec.ObjectType = objType;
            OperationAuditor.LogAction(auditSpec);
        }


        /// <summary>
        /// Delete Rules
        /// </summary>
        /// <param name="ruleIds"> List of Rule Id</param>
        /// <returns>Boolean</returns>
        public bool Delete(IEnumerable<int> ruleIds)
        {
            if (ruleIds.Count() == 0)
            {
                throw new ArgumentNullException("ruleIds");
            }
            try
            {
                var rules = _ruleRepository.Remove(ruleIds, RuntimeContext.ProviderId);

                foreach (var ruleEntity in rules)
                {
                   this.UpdateAuditLog(ruleEntity.Name, ServiceAction.AlertRuleDeleted, EntityType.AlertRule);
                }



                return true;
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("Error while deleting the Rules"), ex);
                return false;

            }

        }

        /// <summary>
        /// Delete Weather
        /// </summary>
        /// <param name="ruleIds"> List of Rule Id</param>
        /// <returns>Boolean</returns>
        public bool DeleteWeather(IEnumerable<int> ruleIds)
        {
            if (ruleIds.Count() == 0)
            {
                throw new ArgumentNullException("ruleIds");
            }
            try
            {
                var rules = _ruleRepository.GetDeleteWeatherDetails(ruleIds);
                bool result = _ruleRepository.DeleteWeather(ruleIds);

                foreach (var ruleEntity in rules)
                {
                    this.UpdateAuditLog(ruleEntity.Name, ServiceAction.WeatherRuleDeleted, EntityType.WeatherAlertRule);
                }



                return true;
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("Error while deleting the Rules"), ex);
                return false;

            }

        }

        /// <summary>
        /// ReOrder the Rule Sequence
        /// </summary>
        /// <param name="ruleOrderValuePair">Dictionary of KeyValue paired with RuleId and Order</param>
        /// <returns>Boolean</returns>
        public bool ReOrder(ICollection<RuleOrder> ruleOrderValuePair)
        {
            if (ruleOrderValuePair == null)
            {
                throw new ArgumentNullException("ruleOrderValuePair");
            }

            try
            {
                var rules = _ruleRepository.ReOrder(ruleOrderValuePair, RuntimeContext.OperatorId);
                var ruleIds = string.Join(",", rules.Select(a => a.Id.ToString()));
                string auditObjectName = string.Format("Batch Rule Reordered - Rule Ids are {0}", ruleIds);
                this.UpdateAuditLog(auditObjectName, ServiceAction.AlertRuleReOrdered, EntityType.AlertRule);
                return true;
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("Error while Reorder the Rules"), ex);
                return false;
            }
        }


        public CustomAttributeLookup GetRuleAttributeLookup(string entityId = "ALERT")
        {
            var customAttributes = _customAttributeCache.Get(RuntimeContext.Provider.Id, RuntimeContext.Provider.BaseLocale, true)
                 .Where(
                     x =>
                         x.EntityId == entityId &&
                         x.AttributeTypeId != CustomAttributeDataType.Path &&
                         x.AttributeTypeId != CustomAttributeDataType.Memo &&
                         x.AttributeTypeId != CustomAttributeDataType.GeoLocation);

            // now set the values for the source organization (dynamic values)           

            // first get the connected organization (sent to us)
            if (entityId == "ALERT")
            {
                OrganizationFacade organizationFacade = new OrganizationFacade();
                if (organizationFacade.GetConnectivityStatus(RuntimeContext.ProviderId) != ConnectivityStatus.Connected)
                {
                    return new CustomAttributeLookup(customAttributes);
                }

                var connections = organizationFacade.GetConnections(RuntimeContext.ProviderId, true, false);
                if (connections == null)
                {
                    EventLogger.WriteError(string.Format("Error while get conections and build organization list"));
                    return new CustomAttributeLookup(customAttributes);
                }

                List<string> orgIds = connections.Agreements.Where(x => x.IsReceive).Select(x => x.OtherOrganizationGuid).ToList();

                var orgs = organizationFacade.GetOrganizations(RuntimeContext.ProviderId, new OrganizationSpec() { OrganizationGuidList = orgIds });
                if (orgs == null)
                {
                    EventLogger.WriteError(string.Format("Error while getting organization info"));
                    return new CustomAttributeLookup(customAttributes);
                }

                var sourceOrganizationAttr = customAttributes.FirstOrDefault(attr => attr.CommonName.Equals("ALERT-SOURCE-ORGANIZATION", StringComparison.InvariantCultureIgnoreCase));

                if (sourceOrganizationAttr == null)
                {
                    EventLogger.WriteError(string.Format("failed to get custom attr ALERT-SOURCE-ORGANIZATION "));
                    return new CustomAttributeLookup(customAttributes);
                };

                // first need to sort.                      
                sourceOrganizationAttr.Values = connections.Agreements.Where(x => x.IsReceive).Select(x =>
                {
                    OrganizationInfo orgInfo;
                    if (orgs.TryGetValue(x.OtherOrganizationGuid, out orgInfo))
                    {
                        return new CustomAttributeValue()
                        {
                            ValueName = orgInfo.Name,
                            CommonName = x.OtherOrganizationGuid
                        };
                    }
                    return null;
                }).OrderBy(x => x.ValueName);

                // assign value id AFTER sorting, teh ui sort by value id.
                int fakeValueId = 1;
                foreach (var value in sourceOrganizationAttr.Values)
                {
                    value.ValueId = fakeValueId++;
                }

            }
            return new CustomAttributeLookup(customAttributes);
        }

        /// <summary>
        /// Create Search Entity (Using API legacy API- AtHoc.Publishing project)
        /// </summary>
        /// <param name="entity"></param>
        private void CreateSearchEntity(SearchEntity entity)
        {
            _searchCriteriaRepository.CreateSearchEntity(entity);
        }

        private void UpdateSearchEntity(SearchEntity entity, int ruleId)
        {
            _searchCriteriaRepository.UpdateSearchEntity(entity, ruleId);
        }
        private void UpdateRuleCriteria(SearchEntity entity)
        {

        }

        private SearchEntity GetSearchEntity(int ruleId)
        {
            return _searchCriteriaRepository.GetSearchEntity(ruleId, SearchEntityType.Rule);
        }
        private Rule ConvertToRuleModel(RuleEntity ruleEntity, Dictionary<int, Entities.Search.SearchEntity> dictionarySearchEntityByRuleId, bool loadRuleCriteria = false, string ruleType = "")
        {
            Entities.Search.SearchEntity searchEntity;
            var rule = new Rule();
            if (ruleEntity != null)
            {
                rule.Id = ruleEntity.Id;
                rule.ProviderId = ruleEntity.ProviderId;
                rule.Name = ruleEntity.Name;
                //Make sure IsStandard is Not null or empty also it is set to 'Y' to identify as Standard Rule.
                rule.IsStandard = (!string.IsNullOrEmpty(ruleEntity.IsStandard) && ruleEntity.IsStandard == "Y");
                if (dictionarySearchEntityByRuleId.TryGetValue(ruleEntity.Id, out searchEntity))
                {
                    rule.CriteriaEntityId = searchEntity.Id;
                }
                rule.Order = ruleEntity.Order;
                rule.StopProcessing = ruleEntity.StopProcessing;
                rule.Actions = new List<RuleAction>();
                rule.isEnable = (ruleEntity.IsActive == "Y" ? "Yes" : "No");
                rule.GroupId = ruleEntity.GroupId;

                foreach (var actionEntity in ruleEntity.RuleActionEntities)
                {
                    var ruleAction = new RuleAction
                    {
                        ActionId = actionEntity.Id,
                        ActionName = actionEntity.ActionType
                    };
                    if (actionEntity.RuleActionValueEntities == null)
                    {
                        ruleAction.ActionValues = new Dictionary<string, object>();
                        rule.Actions.Add(ruleAction);
                        continue;
                    }
                    var dictActionValues = actionEntity.RuleActionValueEntities
                        .ToDictionary<RuleActionValueEntity, string, object>(ruleActionValueEntity => ruleActionValueEntity.ParameterKey, ruleActionValueEntity => ruleActionValueEntity.ParameterValue);
                    ruleAction.ActionValues = dictActionValues;
                    rule.Actions.Add(ruleAction);

                }

                if (loadRuleCriteria || ruleType == RuleTypes.INCOMING_FEED_RULE.ToString())
                {
                    var searchEntityForRule = GetSearchEntity(rule.Id);
                    if (searchEntityForRule != null)
                    {
                        var rulCriterias = GetRuleCriterias(searchEntityForRule);
                        if (rulCriterias == null)
                        {
                            EventLogger.WriteError(
                                string.Format("No Rule Criteria found for Rule Id {0} and Search Entity Id {1}", rule.Id,
                                    searchEntityForRule.ID));
                            rule.Criterias = new List<RuleCriteria>();
                        }
                        else
                        {
                            GetWAMDetails(rulCriterias, rule);
                        }
                        rule.Criterias = rulCriterias;
                    }
                }
            }

            return rule;
        }

        private void GetWAMDetails(IList<RuleCriteria> ruleCriterias, Rule rule)
        {
            if (ruleCriterias != null)
            {
                if (ruleCriterias.Where(x => x.AttributeName == "WAM-COUNTY").Any())
                {
                    var counties =
                        (ruleCriterias.FirstOrDefault(x => x.AttributeName == "WAM-COUNTY").AttributeValue).Where(
                            x => !String.IsNullOrEmpty(x)).Select(x => x.Split(',')).FirstOrDefault();
                    if (counties != null)
                    {
                        TextInfo textInfo = new CultureInfo("en-US", false).TextInfo;
                        var filterdCounty =
                            counties.Select(x => x.Split('-'))
                                .Select(x => (textInfo.ToTitleCase(x[1].ToLower())) + ' ' + '(' + x[0] + ')')
                                .ToList();
                        rule.WeatherCounty = string.Join(", ", filterdCounty);
                    }
                }

                if (ruleCriterias.Where(x => x.AttributeName == "WAM-SEVERITY").Any())
                    rule.WeatherSeverityType = string.Join(",",
                        ruleCriterias.FirstOrDefault(x => x.AttributeName == "WAM-SEVERITY").AttributeValue);
                if (ruleCriterias.Where(x => x.AttributeName == "WAM-EVENT-TYPE").Any())
                    rule.WeatherEventType = string.Join(",",
                        ruleCriterias.FirstOrDefault(x => x.AttributeName == "WAM-EVENT-TYPE").AttributeValue);
                if (ruleCriterias.Where(x => x.AttributeName == "WAM-SEARCH-KEYWORD").Any())
                    rule.weatherKeywords = string.Join(",",
                        ruleCriterias.FirstOrDefault(x => x.AttributeName == "WAM-SEARCH-KEYWORD").AttributeValue);
            }
        }

        /// <summary>
        /// Get the Rule Criterias by Search Entity Id. 
        /// </summary>
        /// <param name="searchEntity"></param>
        /// <returns>Collection of Rule Criteria Model</returns>
        private IList<RuleCriteria> GetRuleCriterias(SearchEntity searchEntity)
        {
            try
            {


                var ruleCriterias = new List<RuleCriteria>();
                if (searchEntity != null)
                {

                    foreach (var searchCriteria in searchEntity.SearchCriterias)
                    {
                        var searchQueries = searchCriteria.SearchQueries;
                        foreach (var searchQuery in searchQueries)
                        {
                            var ruleCriteria = new RuleCriteria();
                            ruleCriteria.Id = searchQuery.ID;
                            if (searchQuery.QueryEntityID != null)
                            {
                                CustomAttribute customAttributeForCommonName;
                                if (!RuleCustomAttribute.TryGetValue(searchQuery.QueryEntityID.Value, out customAttributeForCommonName))
                                {
                                    EventLogger.WriteError(string.Format("Unable to find CustomAttribute for Id = {0}", searchQuery.QueryEntityID.Value));
                                    continue;
                                }
                                ruleCriteria.AttributeName = customAttributeForCommonName.CommonName;


                                var customAttributeDataType = customAttributeForCommonName.AttributeTypeId;
                                if (customAttributeDataType != null)
                                    ruleCriteria.AttributeType = (AtHoc.IWS.Business.Domain.Entities.CustomAttributeDataType)customAttributeDataType;

                                if (searchQuery.Operator != null)
                                    ruleCriteria.Operator = (SearchOperators)searchQuery.Operator.Value;
                            }

                            if (ruleCriteria.AttributeType != null && ruleCriteria.AttributeType.Value == CustomAttributeDataType.MultiPicklist)
                            {
                                //For Attribute = ALERT-SOURCE-ORGANIZATION , Org Guids are stored directly in the SEARCH_QUERY_VALUES_TAB.
                                const string sourceOrganization = "ALERT-SOURCE-ORGANIZATION";
                                if (string.Equals(ruleCriteria.AttributeName, sourceOrganization, StringComparison.CurrentCultureIgnoreCase))
                                {
                                    ruleCriteria.AttributeValue =
                                    searchQuery.SearchValueCollections.Select(a => a.SearchValue).ToList();
                                }
                                else
                                {
                                    var attributeValueIds =
                                   searchQuery.SearchValueCollections.Select(a => Convert.ToInt32(a.SearchValue));
                                    ruleCriteria.AttributeValue =
                                        GetCustomeAttributeValues(ProviderId, attributeValueIds).Select(a => a.ValueName).ToList();
                                }
                            }
                            else if (ruleCriteria.AttributeType != null && ruleCriteria.AttributeType.Value == CustomAttributeDataType.String)
                            {
                                ruleCriteria.AttributeValue =
                                    searchQuery.SearchValueCollections.Select(a => a.SearchValue).ToList();
                            }
                            ruleCriterias.Add(ruleCriteria);
                        }
                    }
                }
                return ruleCriterias;
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Error in method => IList<RuleCriteria> GetRuleCriterias(SearchEntity searchEntity) ", ex);
                return null;
            }

        }
        private IDictionary<int, CustomAttribute> GetCustomAttributeForRule(int providerId, string entityId = "ALERT")
        {
            try
            {
                return _customAttributeCache.Get(providerId, RuntimeContext.Provider.BaseLocale).Where(a => a.EntityId.ToUpper() == entityId).ToDictionary(a => a.Id);
            }
            catch (Exception ex)
            {
                if (_customAttributeCache == null)
                {
                    EventLogger.WriteError(string.Format("Error in GetCustomAttributeForRule method. ICustomAttributeCache is not resolved."), ex);
                }
                throw;
            }

        }
        private CustomAttributeValueLookup GetCustomAttributeValueLookupForRule(int providerId)
        {

            return _customAttributeValueCache.Get(providerId, RuntimeContext.Provider.BaseLocale);
        }

        private IEnumerable<CustomAttributeValue> GetCustomeAttributeValues(int providerId, IEnumerable<int> attributeIds)
        {
            return GetCustomAttributeValueLookupForRule(providerId).GetByIds(attributeIds);
        }






    }
}
