﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Dynamic;
using AtHoc.Data;
using AtHoc.Diagnostics;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Entities.Search;
using Microsoft.Practices.ObjectBuilder2;
using System.Data;

namespace AtHoc.IWS.Business.Domain.RuleModel.Impl
{
    public class RuleRepository : IRuleRepository
    {
        public int Add(RuleEntity ruleEntity)
        {
            if (ruleEntity == null)
            {
                throw new ArgumentNullException();
            }



            try
            {
                using (var context = new AtHocDbContext())
                {

                    context.Rules.Add(ruleEntity);
                    context.SaveChanges();
                    return ruleEntity.Id;
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("Error in {0}, Method = {1}", "RuleRepository", "Add"), ex.InnerException ?? ex);
                throw;
            }

        }

        public int Update(RuleEntity paramRuleEntity, out bool isStatusUpdate)
        {
            if (paramRuleEntity == null)
            {
                throw new ArgumentNullException();
            }

            try
            {
                using (var context = new AtHocDbContext())
                {

                    var ruleEntity = context.Rules.Find(paramRuleEntity.Id);

                    //check the existing status of the rule
                    isStatusUpdate = ruleEntity.IsActive == paramRuleEntity.IsActive ? false : true;

                    var existingRuleAction = context.RuleActions.Where(a => a.RuleId == paramRuleEntity.Id);
                    var ruleActionIds = existingRuleAction.Select(b => b.Id);
                    var existingRuleActionValues = context.RuleActionValues.Where(a => ruleActionIds.Contains(a.RuleActionId.Value));

                    context.RuleActionValues.RemoveRange(existingRuleActionValues);
                    context.RuleActions.RemoveRange(ruleEntity.RuleActionEntities);

                    ruleEntity.Name = paramRuleEntity.Name;
                    ruleEntity.StopProcessing = paramRuleEntity.StopProcessing;
                    ruleEntity.UpdatedBy = paramRuleEntity.UpdatedBy;
                    ruleEntity.UpdatedOn = DateTime.UtcNow;
                    ruleEntity.IsActive = paramRuleEntity.IsActive;
                   

                    //ruleEntity.RuleActionEntities = null;
                    ruleEntity.RuleActionEntities = paramRuleEntity.RuleActionEntities;
                    context.SaveChanges();

                    return paramRuleEntity.Id;
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("Error in {0}, Method = {1}", "RuleRepository", "Add"), ex);
                throw;
            }
        }

        public List<RuleEntity> ReOrder(IEnumerable<RuleOrder> ruleSequence, int updatedBy)
        {
            try
            {
                using (var context = new AtHocDbContext())
                {
                    var ruleOrderDictionary = ruleSequence.ToDictionary(a => a.RuleId);
                    var ruleIds = ruleOrderDictionary.Keys;
                    var entities = context.Rules.Where(a => ruleIds.Contains(a.Id));
                    entities.ForEach(a =>
                    {
                        a.Order = ruleOrderDictionary[a.Id].Order;
                        a.UpdatedOn = DateTime.UtcNow;
                        a.UpdatedBy = updatedBy;
                    });
                    context.SaveChanges();
                    return entities.ToList();
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("Error while ReOrdering Rule"), ex);
                throw;
            }
        }

        /// <summary>
        /// Mark Rule as InActive (Soft Delete the rules)
        /// </summary>
        /// <param name="ruleIds"></param>
        /// <param name="updatedBy"></param>
        public List<RuleEntity> Remove(IEnumerable<int> ruleIds, int updatedBy)
        {
            if (ruleIds.Count() == 0)
            {
                throw new ArgumentNullException();
            }

            try
            {

                using (var context = new AtHocDbContext())
                {
                    var rules = context.Rules.Where(a => ruleIds.Contains(a.Id));
                    rules.ForEach(a =>
                    {
                        a.IsActive = "N";
                        a.UpdatedOn = DateTime.UtcNow;
                        a.UpdatedBy = updatedBy;

                    });
                    context.SaveChanges();
                    return rules.ToList();
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("Error in {0}, Method = {1}", "RuleRepository", "Remove"), ex);
                throw;
            }
        }



        public IEnumerable<RuleEntity> GetRules()
        {
            var context = new AtHocDbContext();
            return context.Rules.Include("RuleActionEntities").Include("RuleActionEntities.RuleActionValueEntities");
        }

        public IEnumerable<RuleActionEntity> GetRuleActions()
        {
            var context = new AtHocDbContext();
            return context.RuleActions.Include("RuleActionValueEntities");
        }



        public IEnumerable<SearchEntity> GetRuleSearchEntityId(int[] ruleIds, string searchEntityType)
        {
            var context = new AtHocDbContext();
            return context.SearchEntities.Where(a => ruleIds.Contains(a.EntityId) && a.EntityType.ToUpper() == searchEntityType.ToUpper());
        }

        public List<RuleEntity> GetDeleteWeatherDetails(IEnumerable<int> ruleIds)
        {
            if (ruleIds.Count() == 0)
            {
                throw new ArgumentNullException();
            }

            try
            {

                using (var context = new AtHocDbContext())
                {
                    var rules = context.Rules.Where(a => ruleIds.Contains(a.Id));
                    return rules.ToList();
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("Error in {0}, Method = {1}", "RuleRepository", "GetDeleteWeatherDetails"), ex);
                throw;
            }
        }
        public bool DeleteWeather(IEnumerable<int> ruleIds)
        {
            if (ruleIds.Count() == 0)
            {
                throw new ArgumentNullException();
            }

            try
            {
                int result = 0;
                using (NgadDatabase ngadDB = new NgadDatabase())
                {

                    //To delete Rule 
                    ngadDB.CommandType = CommandType.StoredProcedure;
                    ngadDB.AddParameter("@ruleIds", ruleIds.JoinStrings(","));
                    result = ngadDB.ExecuteNonQuery("ALT_DELETE_RULE");

                }
                return result > 0;

            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("Error in {0}, Method = {1}", "RuleRepository", "DeleteWeather"), ex);
                throw;
            }
        }
    }
}
