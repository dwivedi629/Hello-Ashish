﻿using AtHoc.Devices;
using System.Collections.Generic;

namespace AtHoc.IWS.Business.Domain.GlobalAlertExtension.Interfaces
{
    /// <summary>
    /// IGlobalAlertExtensionFacade Interface.
    /// </summary>
    public interface IGlobalAlertExtensionFacade
	{
        /// <summary>
        /// Get localized list of AlertExtensions.
        /// </summary>
        /// <param name="locale">Locale</param>
        /// <returns>Returns List of localized AlertExtension.</returns>
        List<AlertExtension> GetLocalizedGlobalAlertExtensionList(string locale);
	}

}