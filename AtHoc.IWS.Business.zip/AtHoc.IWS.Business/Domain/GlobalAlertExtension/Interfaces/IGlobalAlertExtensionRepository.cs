﻿using AtHoc.Devices;
using System.Collections.Generic;

namespace AtHoc.IWS.Business.Domain.GlobalAlertExtension.Interfaces
{
    /// <summary>
    /// IGlobalAlertExtensionCache Interface.
    /// </summary>
    public interface IGlobalAlertExtensionRepository 
	{
        /// <summary>
        /// Get the list of Alert Extensions.
        /// </summary>
        /// <returns>Returns List of AlertExtension.</returns>
        List<AlertExtension> GetLocalizedGlobalAlertExtensionList();
	}

}