﻿using AtHoc.Devices;
using AtHoc.IWS.Business.Domain.GlobalAlertExtension.Interfaces;
using AtHoc.Runtime;
using AtHoc.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace AtHoc.IWS.Business.Domain.GlobalAlertExtension.Impl
{

    public class GlobalAlertExtensionCacheManager
    {

        private readonly ProcessCache _globalAlertExtensionCache;
        private readonly IGlobalAlertExtensionRepository _globalAlertExtensionRepository;
        
        /// <summary>
        /// Default constructor of the class.
        /// </summary>
        /// <param name="globalAlertExtensionRepository"></param>
        public GlobalAlertExtensionCacheManager(IGlobalAlertExtensionRepository globalAlertExtensionRepository)
        {
            _globalAlertExtensionRepository = globalAlertExtensionRepository;

            // Default caching for AlertExtension is 4 Hours.
            var cacheDuration = System.Configuration.ConfigurationManager.AppSettings["AlertExtensionCacheDurationInHours"] ?? "4";
            var configuration = new ProcessCacheConfiguration
            {
                IsEnabled = true,
                DefaultExpiration = TimeSpan.FromHours(Int32.Parse(cacheDuration)),
                DefaultExpirationType = ExpirationType.Absolute,
                Name = "AlertExtensionCache",
                PollingInterval = TimeSpan.FromHours(Int32.Parse(cacheDuration))
            };
            _globalAlertExtensionCache = GlobalAlertExtensionProcessCache.GetInstanceProcessCache(configuration);
        }

        /// <summary>
        /// Get the list of Alert Extensions.
        /// </summary>
        /// <param name="locale">Key based on which localized AlertExtension list will be returned.</param>
        /// <returns>Returns List of Localized AlertExtension.</returns>
        public List<AlertExtension> GetGlobalAlertExtensionList(string locale)
        {
            if (!IsCacheAvailable(locale))
            {
                if (!SetAlertExtensionCache(locale)) return null;
            }

            var localisedList = new List<AlertExtension>();
            _globalAlertExtensionCache.TryGet(BuildCacheName(locale), out localisedList);
            return localisedList;
        }

        /// <summary>
        /// Holds logic to create Cache name depending on locale name
        /// It returns the Cache name for the given locale
        /// </summary>
        /// <param name="locale"></param>
        /// <returns></returns>
        private string BuildCacheName(string locale)
        {
            return string.Format("AlertExtensionCache_{0}", locale);
        }


        /// <summary>
        /// Reads data from the DB for given locale and stores it in Cache in Dcitionary format
        /// </summary>
        /// <param name="locale"></param>
        private bool SetAlertExtensionCache(string locale)
        {
            var alertExtensionListAllResources = _globalAlertExtensionRepository.GetLocalizedGlobalAlertExtensionList();
            if (!alertExtensionListAllResources.Any()) return false;

            var alertExtensionLocaleList = GetProviderLocaleResource(alertExtensionListAllResources, locale);
            _globalAlertExtensionCache.Set(BuildCacheName(locale), alertExtensionLocaleList);

            return true;
        }

        /// <summary>
        /// Keep only the resources based on locale and removes the other associates resources from resource list.
        /// </summary>
        /// <param name="alertExtensions">List of Alert Extensions</param>
        /// <param name="locale">Locale of provider</param>
        /// <returns>List of AlertExtension with resource defination based on locale.</returns>
        private List<AlertExtension> GetProviderLocaleResource(List<AlertExtension> alertExtensions, string locale)
        {
            foreach (var alertExtension in alertExtensions)
            {
                if (alertExtension.Definition != null)
                {
                    XElement definition = XElement.Parse(alertExtension.Definition.OuterXml);
                    // Search within the Resources node.
                    foreach (var resource in definition.Elements("Resources"))
                    {
                        // Search within the ResourceList node.
                        foreach (var resourceList in resource.Elements("ResourceList"))
                        {
                            // Comparing the XML locale with the provider locale.
                            if (resourceList.FirstAttribute.Value.ToUpper() != locale.ToUpper())
                            {
                                // Removing all the resource list, which are not for that locale.
                                resourceList.RemoveAll();
                            }
                        }
                    }
                    //Assign back the changed XML to original one.
                    alertExtension.Definition.InnerXml = definition.InnerXml();
                }
            }
            return alertExtensions;
        }

        /// <summary>
        /// Checks if locale specific cache available
        /// </summary>
        /// <param name="locale"></param>
        /// <returns></returns>
        private bool IsCacheAvailable(string locale)
        {
            return _globalAlertExtensionCache.Contains(BuildCacheName(locale));
        }

    }
}