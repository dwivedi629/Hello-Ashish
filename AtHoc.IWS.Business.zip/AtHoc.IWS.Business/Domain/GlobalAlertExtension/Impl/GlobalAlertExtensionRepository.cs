﻿using AtHoc.Devices;
using AtHoc.IWS.Business.Domain.GlobalAlertExtension.Interfaces;
using System.Collections.Generic;

namespace AtHoc.IWS.Business.Domain.GlobalAlertExtension.Impl
{

    public class GlobalAlertExtensionRepository : IGlobalAlertExtensionRepository
    {
        /// <summary>
        /// Get the list of localized Alert Extensions.
        /// </summary>
        /// <param name="locale">Key based on which cache will be identified.</param>
        /// <returns>Returns List of Localized AlertExtension.</returns>
        public List<AlertExtension> GetLocalizedGlobalAlertExtensionList()
        {
            return AlertExtension.GetAllAlertExtensions();
        }

    }
}