﻿using AtHoc.Devices;
using AtHoc.IWS.Business.Domain.GlobalAlertExtension.Interfaces;
using AtHoc.Runtime;
using AtHoc.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace AtHoc.IWS.Business.Domain.GlobalAlertExtension.Impl
{
    /// <summary>
    /// GlobalAlertExtensionProcessCache singleton class.
    /// </summary>
    public class GlobalAlertExtensionProcessCache
    {
        private static ProcessCache _processCache = null;

        public GlobalAlertExtensionProcessCache()
        {
        }

        /// <summary>
        /// Returns the current Instance for process cache.
        /// </summary>
        /// <param name="configuration"></param>
        /// <returns></returns>
        public static ProcessCache GetInstanceProcessCache(ProcessCacheConfiguration configuration)
        {
            if (_processCache == null)
            {
                _processCache = new ProcessCache(configuration);
            }
            return _processCache;
        }
    }
}