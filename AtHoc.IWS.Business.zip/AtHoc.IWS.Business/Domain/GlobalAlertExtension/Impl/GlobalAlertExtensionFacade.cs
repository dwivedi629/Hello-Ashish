﻿using AtHoc.Devices;
using AtHoc.IWS.Business.Domain.GlobalAlertExtension.Interfaces;
using System.Collections.Generic;

namespace AtHoc.IWS.Business.Domain.GlobalAlertExtension.Impl
{
    /// <summary>
    /// GlobalAlertExtenions Facade Class.
    /// </summary>
    public class GlobalAlertExtensionFacade: IGlobalAlertExtensionFacade
    {

        private readonly GlobalAlertExtensionCacheManager _globalAlertExtensionCacheManager = null;

        /// <summary>
        /// GlobalAlertExtensionFacade Constructor.
        /// </summary>
        /// <param name="globalAlertExtensionRepository"></param>
        public GlobalAlertExtensionFacade(IGlobalAlertExtensionRepository globalAlertExtensionRepository)
        {
            _globalAlertExtensionCacheManager = new GlobalAlertExtensionCacheManager(globalAlertExtensionRepository);
        }

        /// <summary>
        /// Get localized list of Alert Extensions.
        /// </summary>
        /// <param name="locale">Locale</param>
        /// <returns>Returns List of localized AlertExtension.</returns>
        public List<AlertExtension> GetLocalizedGlobalAlertExtensionList(string locale)
        {
            return _globalAlertExtensionCacheManager.GetGlobalAlertExtensionList(locale);
        }
    }
}