﻿using System.Collections.Generic;
using AtHoc.Infrastructure.Data;
using AtHoc.IWS.Business.Data.SearchSpec;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.Infrastructure.Resources;
using AtHoc.IWS.Business.Service;

namespace AtHoc.IWS.Business.Domain.CustomAttributes
{
#warning AB: Split Custom View API into separate interface.
    public interface ICustomAttributeFacade
    {
        IEnumerable<CustomAttribute> GetCustomAttributesBySpec(CustomAttributeSpec spec);

        CustomAttribute GetOrgHierarchyAttributeBySpec(int providerId);

        int GetOrgHierarchyAttributeId(int providerId);

        IEnumerable<CustomView> GetCustomViewsBySpec(CustomViewSpec spec);

        IEnumerable<CustomView> GetUserCustomViewsBySpec(CustomViewSpec spec);

        CustomView GetCustomViewBySpec(CustomViewSpec spec);

        IEnumerable<CustomAttributeValue> GetCustomAttributeValuesBySpec(CustomAttributeValueSpec spec);

        Messages AddCustomView(AddCustomViewSpec addCustomViewSpec);

        void RemoveCustomView(CustomViewSpec spec);

        void SaveCustomView(CustomView customView);

        IEnumerable<CustomAttributeQueryOperator> ReturnOperatorsForDataType(int dataTypeId);

        IEnumerable<CustomAttributeQueryOperator> GetOperands();

        IEnumerable<Entities.Targeting> GetCustomAttributeTargetingBySpec(CustomAttributeTargetingSpec spec);

        Messages SaveCustomView(SaveCustomViewSpec spec);

        PagingInfo<CustomAttribute> GetAttributesForList(UserAttributeSearchSpec spec);

        IEnumerable<CustomAttributeDeleteDependency> CheckDeleteDependencies(CustomAttributeDeleteDependencySpec spec);

        ServiceResult<IEnumerable<CustomAttributeDeleteDependency>> DeleteCustomAttribute(int operatorId, int providerId, int attributeId, string commonName, string userSectionName, string selfServiceSectionName , string entityId , string operatorName );

        IEnumerable<UserAttributeDataType> GetUserAttributeTypes();

        int ValidateAttributeName(int providerId, string attributeName);
        bool ValidateProviderAttributeId(int providerId, int attributeId,int attributeTypeId);
        int ValidateCommonName(int providerId, string commonName);
        Messages SaveCustomAttribute(CustomAttributeModel model,int providerId);
        Messages DeleteAttributeValues(int operatorId, int providerId, int attributeId, string attributeName = null,
            string entityId = null);
        Messages SetCustomAttributeDefaultValues(int operatorId, int providerId, int attributeId,
            string attributeName = null);
        Messages DeletePickListValues(int attributeId, int operatorId);
        Dictionary<string, string> GetReportDetails(int attributeId);
        ServiceResult<IEnumerable<CustomAttributeDeleteDependency>> DeletePickListValue(string operatorName,
            int providerId, int attributeId, int valueId, int operatorId);
        IEnumerable<CustomAttributeDeleteDependency> CheckPlaceholderDeleteDependencies(CustomAttributeDeleteDependencySpec spec);

        /// <summary>
        /// This function checks if the given attribute is a Status type attribute
        /// </summary>
        /// <param name="attribute"></param>
        /// <returns>Boolean value indicating if the given attribute is status attribute</returns>
        bool IsStatusAttribute(CustomAttribute attribute);
        Dictionary<string, object> CheckHierarchyDependencyList(CustomAttributeHierarchyDependencySpec spec);

    }
}
