﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.CustomAttributes
{
#warning Refactor by introducing common interface and havin generic lookup class...
	public class CustomAttributeLookup : IEnumerable<CustomAttribute>
	{
		private readonly IEnumerable<CustomAttribute> _customAttributes;
		private readonly ILookup<string, CustomAttribute> _customAttributeByCommonName;
		private readonly ILookup<string, CustomAttribute> _customAttributeByAttributeName;
		private readonly ILookup<int, CustomAttribute> _customAttributeByAttributeId;

		public CustomAttributeLookup(IEnumerable<CustomAttribute> customAttributes)
		{
			_customAttributes = customAttributes.ToArray();
			_customAttributeByCommonName = _customAttributes.ToLookup(x => x.CommonName, StringComparer.OrdinalIgnoreCase);
			_customAttributeByAttributeName = _customAttributes.ToLookup(x => x.AttributeName, StringComparer.OrdinalIgnoreCase);
			_customAttributeByAttributeId = _customAttributes.ToLookup(x => x.Id);
		}

		public CustomAttribute GetById(int id)
		{
			return _customAttributeByAttributeId[id].FirstOrDefault();
		}

		public IEnumerable<CustomAttribute> GetByIds(IEnumerable<int> ids)
		{
			return ids.Select(GetById);
		}

		public CustomAttribute GetByCommonName(string commonName)
		{
			return _customAttributeByCommonName[commonName].FirstOrDefault();
		}

		public IEnumerable<CustomAttribute> GetByCommonNames(string commonNames)
		{
			return GetByCommonNames(commonNames.Split(new[] {',', ' '}));
		}

		public IEnumerable<CustomAttribute> GetByCommonNames(IEnumerable<string> commonNames)
		{
			return _customAttributes.Where(a => commonNames.Contains(a.CommonName));
		}

		public CustomAttribute GetByAttributeName(string attributeName)
		{
			return _customAttributeByAttributeName[attributeName].FirstOrDefault();
		}

		public IEnumerator<CustomAttribute> GetEnumerator()
		{
			return _customAttributes.GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			return GetEnumerator();
		}
	}

	public class CustomAttributeValueLookup : IEnumerable<CustomAttributeValue>
	{
		private readonly IEnumerable<CustomAttributeValue> _customAttributeValues;
		private readonly ILookup<string, CustomAttributeValue> _customAttributeValuesByCommonName;
		private readonly ILookup<string, CustomAttributeValue> _customAttributeValuesByValueName;
		private readonly ILookup<int, CustomAttributeValue> _customAttributeValuesByAttributeId;

		public CustomAttributeValueLookup(IEnumerable<CustomAttributeValue> customAttributeValues)
		{
			_customAttributeValues = customAttributeValues.ToArray();
			_customAttributeValuesByCommonName = _customAttributeValues.ToLookup(x => x.CommonName, StringComparer.OrdinalIgnoreCase);
			_customAttributeValuesByValueName = _customAttributeValues.ToLookup(x => x.ValueName, StringComparer.OrdinalIgnoreCase);
			_customAttributeValuesByAttributeId = _customAttributeValues.ToLookup(x => x.ValueId);
		}

		public CustomAttributeValue GetById(int id)
		{
			return _customAttributeValuesByAttributeId[id].FirstOrDefault();
		}

		public IEnumerable<CustomAttributeValue> GetByIds(IEnumerable<int> ids)
		{
			return ids.Select(GetById);
		}

		public CustomAttributeValue GetByCommonName(string commonName, int attributeId)
		{
			return GetByCommonNames(commonName, attributeId).SingleOrDefault();
		}

		public IEnumerable<CustomAttributeValue> GetByCommonNames(string commonNames, int? attributeId = null)
		{
			return GetByCommonNames(commonNames.Split(new[] { ',', ' ' }), attributeId);
		}

		public IEnumerable<CustomAttributeValue> GetByCommonNames(IEnumerable<string> commonNames, int? attributeId = null)
		{
			var result = _customAttributeValues.Where(a => commonNames.Contains(a.CommonName));
			return attributeId == null ? result : result.Where(v => v.AttributeId == attributeId.Value);
		}

		public CustomAttributeValue GetByAttributeName(string attributeName)
		{
			return _customAttributeValuesByValueName[attributeName].FirstOrDefault();
		}

		public IEnumerator<CustomAttributeValue> GetEnumerator()
		{
			return _customAttributeValues.GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			return GetEnumerator();
		}
	}
}