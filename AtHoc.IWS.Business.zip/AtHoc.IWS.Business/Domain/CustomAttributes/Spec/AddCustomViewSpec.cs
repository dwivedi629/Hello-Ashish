﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.CustomAttributes.Spec
{
    public class AddCustomViewSpec
    {
        public int ProviderId { get; set; }

        public int OperatorId { get; set; }

        public int CurrentUserId { get; set; }
        
        public int CustomViewId { get; set; }

        public CustomViewType CustomViewType { get; set; }
        
        public CustomViewColumnType ColumnId { get; set; }
    }
}
