﻿using System.Collections.Generic;

using AtHoc.Infrastructure.Entity;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.CustomAttributes.Spec
{
	public class CustomViewSpec : EntitySpec
	{
		public IEnumerable<int> ViewIds { get; set; }

		public bool IncludeCustomAttribute { get; set; }

		public int? ProviderId { get; set; }

        public int? OperatorId { get; set; }

        public bool DefaultOnly { get; set; }

		public CustomViewType? CustomViewType { get; set; }

		public IEnumerable<CustomViewColumnType> CustomViewColumnTypes { get; set; } 

		public bool? IsPlaceholder { get; set; }

		public bool? IsMandatory { get; set; }

		public int? CustomAttributeId { get; set; }

        public int? EntityId { get; set; }

        public IEnumerable<int> EntityIds { get; set; }
	}
}
