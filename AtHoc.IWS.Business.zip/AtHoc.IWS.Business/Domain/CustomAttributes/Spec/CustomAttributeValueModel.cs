﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.CustomAttributes.Spec
{
    public class CustomAttributeValueModel
    {
        public int? ProviderId { get; set; }

        public int? AttributeId { get; set; }
        public int? ValueId { get; set; }
        public string ValueName { get; set; }
        public string Status { get; set; }
        public int Priority { get; set; }
        public string CommonName { get; set; }
        public int? UpdatedBy { get; set; }
        public int UpdatedOn { get; set; }
        public int CheckUpdateInterval { get; set; }

        public string Locale { get; set; }

    }
}
