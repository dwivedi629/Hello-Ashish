﻿using System.Collections.Generic;
using System.ComponentModel;
using AtHoc.Infrastructure.Entity;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.CustomAttributes.Spec
{
	public class CustomAttributeSpec : EntitySpec
	{
	    private bool _applyFeatureMatrix = true;
		public bool IncludeValues { get; set; }

		public bool IncludeTargeting { get; set; }

        public bool? ExcludeLists { get; set; }

        public IEnumerable<CustomAttributeType> EntityType { get; set; }

		public int? ProviderId { get; set; }

		public int OperatorId { get; set; }

		public CustomAttributeDataType? CustomAttributeDataType { get; set; }

        public IEnumerable<CustomAttributeDataType?> CustomAttributeDataTypes { get; set; }

		public IEnumerable<int> Ids { get; set; }

		public IEnumerable<int> ExcludeIds { get; set; }

		public bool? ExcludeDeleted { get; set; }

        public bool? ExcludeSystem { get; set; }

		public int? Id { get; set; }

		public string Name { get; set; }

		public string CommonName { get; set; }

		public IEnumerable<string> CommonNames { get; set; }

		public IEnumerable<string> AttributeNames { get; set; }

		public UserStatusType? Status { get; set; }

		public string[] SearchString { get; set; }

		public bool? IsTargetableGroup { get; set; }

		public bool? UseCommonNamesRestriction { get; set; }

        public string Locale { get; set; }

		public static IEnumerable<string> RestrictedCommonNames = new[] { "NPD", "ATHOC-GV-TYPE", "ATHOC-GV-KEYS" };

        public IEnumerable<string> ExcludeCommonNames { get; set; }
        

        public bool ApplyFeatureMatrix
        {
            get { return _applyFeatureMatrix; }
            set { _applyFeatureMatrix = value; }
        }
        public bool CurrentOrganizationAttributesOnly { get; set; }
        public bool OtherOrganizationAttributesOnly { get; set; }

	}
}