﻿using System.Collections.Generic;

using AtHoc.Infrastructure.Entity;

namespace AtHoc.IWS.Business.Domain.CustomAttributes.Spec
{
	public class CustomAttributeValueSpec : EntitySpec
	{
		public bool IncludeCustomAttribute { get; set; }

		public string SearchStringStartsWith { get; set; }

		public string SearchStringContains { get; set; }

		public int? ProviderId { get; set; }

		public IEnumerable<int> ValueIds { get; set; }

		public int? AttributeId { get; set; }

		public int? IntegerValue { get; set; }

		public string CommonName { get; set; }

		public IEnumerable<string> CommonNames { get; set; }
	}
}
