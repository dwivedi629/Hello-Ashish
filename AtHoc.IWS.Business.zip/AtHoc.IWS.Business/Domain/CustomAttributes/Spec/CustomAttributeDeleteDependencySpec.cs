﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Data.SearchSpec;

namespace AtHoc.IWS.Business.Domain.CustomAttributes.Spec
{
    public class CustomAttributeDeleteDependencySpec: BaseSearchSpec
    {
        public int UserAttributeId { get; set; }
        public int ProviderId { get; set; }
        public int ValueId { get; set; }
        
    }
    public class CustomAttributeHierarchyDependencySpec : BaseSearchSpec
    {
        public List<int> ListIds { get; set; }
    }

    public class CustomAttributeHierarchyDeleteList
    {
        public int ListId { get; set; }
        public int Count { get; set; }
    }
}
