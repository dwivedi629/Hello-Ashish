﻿using System.Collections.Generic;
using System.ComponentModel;
using AtHoc.Infrastructure.Entity;
using AtHoc.IWS.Business.Domain.Entities;
using System;

namespace AtHoc.IWS.Business.Domain.CustomAttributes.Spec
{
    public class CustomAttributeModel
    {
        public int? ProviderId { get; set; }
        public int OperatorId { get; set; }
        public string Name { get; set; }
        public string CommonName { get; set; }
        public string OldCommonName { get; set; }
        public string Locale { get; set; }
        public int AttributeTypeId { get; set; }
        public string AttributeType { get; set; }

        public string MinValue { get; set; }
        public string MaxValue { get; set; }
        public int EditLevel { get; set; }
        public string PickListValuesCSV { get; set; }
        public string ToolTip { get; set; }
        public string HelpText { get; set; }
        public string IsMandatory { get; set; }
        public string IsEncrypted { get; set; }
        public string SearchAllowed { get; set; }
        public string DisplayDropdown { get; set; }
        public string DefaultValue { get; set; }
        public string PicklistDelimiter { get; set; }
        public string IsStandard { get; set; }
        public string ReportName { get; set; }
        public string Description { get; set; }
        public string IsSystem { get; set; }
        public string SupportsHistory { get; set; }
        public int? IconId { get; set; }
        public string EntityId { get; set; }
        public string LocaleCode { get; set; }
        public string UserDetailsSectionName { get; set; }
        public string SelfServiceSectionName { get; set; }

        //public DateTime? EarliestAllowedDate { get; set; }
        //public DateTime? LatestAllowedDate { get; set; }

       // public int CreatedBy { get; set; }
        //public int UpdatedBy { get; set; }

        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedOn { get; set; }
        public string CreatedOn { get; set; }

        public string EarliestAllowedDate { get; set; }
        public string LatestAllowedDate { get; set; }      

        public int Id { get; set; }

        public string AttributeOrigin { get; set; }

        public string DefaultText { get; set; }

        public string LinesToShow { get; set; }
    }
}