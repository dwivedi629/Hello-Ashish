﻿using System.Collections.Generic;

using AtHoc.Infrastructure.Entity;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.CustomAttributes.Spec
{
    public class CustomAttributeTargetingSpec: EntitySpec
    {        
        public int? ProviderId { get; set; }

        public TargetingEntityType? TargetingEntityType { get; set; }

    }
}
