﻿using AtHoc.IWS.Business.Domain.Entities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.CustomAttributes
{
    public class CustomAttrbuteLocaleLookup : IEnumerable<CustomAttributeLocale>
    {
        private readonly IEnumerable<CustomAttributeLocale> _customLocaleAttributes;
        private readonly ILookup<int, CustomAttributeLocale> _customLocaleAttributeById;

        public CustomAttrbuteLocaleLookup(IEnumerable<CustomAttributeLocale> customLocaleAttributes)
		{
            _customLocaleAttributes = customLocaleAttributes.ToArray();
            _customLocaleAttributeById = customLocaleAttributes.ToLookup(x => x.AttributeId);
		}

        public CustomAttributeLocale GetById(int id)
		{
            return _customLocaleAttributeById[id].FirstOrDefault();
		}

        public IEnumerable<CustomAttributeLocale> GetByIds(IEnumerable<int> ids)
		{
			return ids.Select(GetById);
		}


        public IEnumerator<CustomAttributeLocale> GetEnumerator()
		{
			return _customLocaleAttributes.GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			return GetEnumerator();
		}
    }

    public class CustomAttributeLocaleValueLookup : IEnumerable<CustomAttributeValueLocale>
    {
        private readonly IEnumerable<CustomAttributeValueLocale> _customAttributeLocaleValues;
        private readonly ILookup<int, CustomAttributeValueLocale> _customAttributeLocaleValueById;

        public CustomAttributeLocaleValueLookup(IEnumerable<CustomAttributeValueLocale> customAttributeLocaleValues)
		{
            _customAttributeLocaleValues = customAttributeLocaleValues.ToArray();
            _customAttributeLocaleValueById = customAttributeLocaleValues.ToLookup(x => x.AttributeId);
		}

        public CustomAttributeValueLocale GetById(int id)
		{
            return _customAttributeLocaleValueById[id].FirstOrDefault();
		}

        public IEnumerable<CustomAttributeValueLocale> GetByIds(IEnumerable<int> ids)
		{
			return ids.Select(GetById);
		}


        public IEnumerator<CustomAttributeValueLocale> GetEnumerator()
		{
			return _customAttributeLocaleValues.GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			return GetEnumerator();
		}
    }
}
