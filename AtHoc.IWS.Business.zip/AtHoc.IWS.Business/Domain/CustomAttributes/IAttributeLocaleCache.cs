﻿using AtHoc.IWS.Business.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.CustomAttributes
{
    /// <summary>
    /// Interface for Custom Attribute Locale Cache.
    /// </summary>
    public interface IAttributeLocaleCache
    {
        /// <summary>
        /// Get the Custom Attributes locale from the cache.
        /// </summary>
        /// <param name="locale">Locale Name</param>
        /// <returns>List of CustomAttributeLocale</returns>
        IEnumerable<Entities.CustomAttributeLocale> GetAttributesForLocale(string locale);
    }

    /// <summary>
    /// Interface for Custom Attribute Locale Value Cache.
    /// </summary>
    public interface IAttributeLocaleValueCache
    {
        /// <summary>
        /// Get the Custom Attributes locale value from the cache.
        /// </summary>
        /// <param name="locale">Locale Name</param>
        /// <returns>List of CustomAttributeValueLocale</returns>
        IEnumerable<Entities.CustomAttributeValueLocale> GetAttributeValuesForLocale(string locale);

    }
}
