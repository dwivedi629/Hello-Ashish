﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.CustomAttributes
{
    public interface ICustomAttributeLocaleFacade
    {
        IEnumerable<CustomAttributeLocale> GetLocalizedCustomAttributes(string locale);
        IEnumerable<CustomAttributeValueLocale> GetLocalizedCustomAttributeValues(string locale);
        CustomAttributeLocale GetLocalizedCustomAttribute(int attributeId, string locale);
        CustomAttributeValueLocale GetLocalizedCustomAttributeWithValue(int attributeId, int valueId, string locale);
        void TransalateCustomAttributes(IEnumerable<CustomAttribute> customAttributes, string locale);
    }
}
