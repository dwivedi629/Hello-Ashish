﻿using AtHoc.Infrastructure.Data;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.CustomAttributes
{
    public interface ICustomAttributeTargetingRepository : IRepository<Entities.Targeting, CustomAttributeTargetingSpec> { }
}
