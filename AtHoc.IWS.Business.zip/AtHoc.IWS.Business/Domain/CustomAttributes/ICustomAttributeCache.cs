﻿using AtHoc.Infrastructure.Cache;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;

namespace AtHoc.IWS.Business.Domain.CustomAttributes
{
    public interface ICustomAttributeCache : ICustomCache<CustomAttributeLookup>
	{
		CustomAttributeLookup Get(int providerId, string baseLocale, bool hideMassDevices = true ,bool readFromCache = false);
	}

    public interface ICustomAttributeValueCache : ICustomCache<CustomAttributeValueLookup>
	{
        CustomAttributeValueLookup Get(int providerId, string baseLocale, bool readFromCache = false);
	}
}