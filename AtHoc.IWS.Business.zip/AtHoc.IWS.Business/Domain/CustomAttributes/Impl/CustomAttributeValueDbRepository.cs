﻿using System;
using System.Collections.Generic;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Database;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Sql;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.IWS.Business.Domain.Entities;


namespace AtHoc.IWS.Business.Domain.CustomAttributes.Impl
{
    public class CustomAttributeValueDbRepository : DbRepository<CustomAttributeValue, CustomAttributeValueSpec>, ICustomAttributeValueRepository
    {
        public CustomAttributeValueDbRepository(IUnitOfWork context) : base(context) { }

        protected override void TranslateSpec(CustomAttributeValueSpec spec, SqlBuilder builder, bool query)
        {
            if (spec.BaseLocale.IsNullOrEmpty()) throw new ApplicationException("Spec Must provide locale");
           // builder.SelectAll<CustomAttributeValue>("v");
            //builder.From(builder.Table<CustomAttributeValue>("v"));
            builder.Select("v.ATTRIBUTE_ID, v.VALUE_ID, l.VALUE_NAME, v.PRIORITY, v.COMMON_NAME, v.STATUS, v.CHECK_UPDATE_INTERVAL, v.UPDATED_ON, v.UPDATED_BY");
            builder.From("PRV_ATTRIBUTE_VALUE_TAB v WITH (NOLOCK)");
            builder.InnerJoin("PRV_ATTRIBUTE_VALUE_LOCALE_TAB l WITH (NOLOCK) on v.ATTRIBUTE_ID = l.ATTRIBUTE_ID AND v.VALUE_ID = l.VALUE_ID AND l.LOCALE_CODE=@vlocaleCode", new SqlParameter("vlocaleCode", spec.BaseLocale));
            

            if (spec.IncludeCustomAttribute)
            {
                builder.SelectAll<CustomAttribute>("b", "1");
                builder.InnerJoin("{0} on {1} = {2}".FormatWith(builder.Table<CustomAttribute>("a"),
                    builder.Column(CustomAttribute.Meta.Id),
                    builder.Column(CustomAttributeValue.Meta.AttributeId)));
            }

            if (spec.SearchStringStartsWith.IsNotNullOrEmpty())
                builder.Where(builder.Condition(CustomAttributeValue.Meta.ValueName, ConditionOperator.StartsWith, spec.SearchStringStartsWith, "v"));

            if (spec.SearchStringContains.IsNotNullOrEmpty())
                builder.Where(builder.Condition(CustomAttributeValue.Meta.ValueName, ConditionOperator.Contains, spec.SearchStringContains, "v"));

            if (spec.ProviderId.HasValue)
                builder.InnerJoin("dbo.PRV_GET_ATTRIBUTES(@providerId) a on v.ATTRIBUTE_ID = a.ATTRIBUTE_ID", new SqlParameter("providerId", spec.ProviderId == null ? 0 : spec.ProviderId.Value));

            if (spec.CommonName.HasValue())
                builder.Where(builder.Condition(CustomAttributeValue.Meta.CommonName, ConditionOperator.Equals, spec.CommonName, "v"));

            if (spec.CommonNames.HasValue())
                builder.Where(builder.Condition(CustomAttributeValue.Meta.CommonName, ConditionOperator.In, spec.CommonNames, "v"));

            if (spec.AttributeId.HasValue)
                builder.Where(builder.Condition(CustomAttributeValue.Meta.AttributeId, ConditionOperator.Equals, spec.AttributeId.Value, "v"));

            if (spec.ValueIds.HasValue())
                builder.Where(builder.Condition(CustomAttributeValue.Meta.ValueId, ConditionOperator.In, spec.ValueIds, "v"));

            base.TranslateSpec(spec, builder, query);
        }

        protected override bool OnItemDataBound(CustomAttributeValueSpec spec, CustomAttributeValue obj, DbResultItem resultItem, SqlMapperContext mapContext)
        {
            if (spec.IncludeCustomAttribute)
                obj.CustomAttribute = this.Context.Map.Translate<CustomAttribute>(resultItem, mapContext);

            return base.OnItemDataBound(spec, obj, resultItem, mapContext);
        }

        public new Messages Save(CustomAttributeValue obj, bool returnId = false)
        {
            throw new NotImplementedException("Call Save Method with CustomAttributeValueModel");
        }


        public void SaveCustomAttributeValue(CustomAttributeValueModel model)
        {
            var hasRows = false;
            var localeHasRows = false;
            const string sqlCheckIfExists = "SELECT 1 FROM dbo.PRV_ATTRIBUTE_VALUE_TAB WITH (NOLOCK) WHERE ATTRIBUTE_ID=@attributeId AND VALUE_ID=@ValueId";

            var checkParameters = new List<SqlParameter>
                {
                new SqlParameter("@AttributeId", model.AttributeId),
                new SqlParameter("@ValueId", model.ValueId)

            };

            var reader = Context.ExecuteDataReader(sqlCheckIfExists,checkParameters);
            hasRows = reader.HasRows;
            reader.Close();

            if (hasRows)
            {
                const string updateSql =
                    @"UPDATE dbo.PRV_ATTRIBUTE_VALUE_TAB SET UPDATED_ON=dbo.GET_DATE_AS_SECONDS(GETDATE()), UPDATED_BY=@UpdatedBy, COMMON_NAME=@CommonName WHERE ATTRIBUTE_ID=@AttributeId AND VALUE_ID=@ValueId";
                var updateParameters = new List<SqlParameter>
                {
                    new SqlParameter("@AttributeId", model.AttributeId),
                    new SqlParameter("@ValueId", model.ValueId),
                    new SqlParameter("@CommonName", model.CommonName),
                    new SqlParameter("@UpdatedBy", model.UpdatedBy),

                };
                Context.ExecuteNonQuery(updateSql,updateParameters);
            }
            else
            {
                const string sql =
                    @"INSERT INTO dbo.PRV_ATTRIBUTE_VALUE_TAB (ATTRIBUTE_ID,VALUE_ID,COMMON_NAME,UPDATED_ON,UPDATED_BY)
	                        VALUES (@AttributeId, @ValueId,@CommonName,dbo.GET_DATE_AS_SECONDS(GETDATE()),@UpdatedBy)";
                    var parameters = new List<SqlParameter>
                        {
                        new SqlParameter("@AttributeId", model.AttributeId),
                        new SqlParameter("@ValueId", model.ValueId),
                    new SqlParameter("@CommonName", model.CommonName),
                        new SqlParameter("@UpdatedBy", model.UpdatedBy),
                        };

                    Context.ExecuteNonQuery(sql, parameters);
            }

            const string sqlLocaleCheck = @"SELECT 1 FROM dbo.PRV_ATTRIBUTE_VALUE_LOCALE_TAB WITH (NOLOCK) WHERE ATTRIBUTE_ID = @AttributeId and VALUE_ID=@ValueId AND LOCALE_CODE=@LocaleCode";
            var localeCheckParameters = new List<SqlParameter>
            {
                new SqlParameter("@AttributeId", model.AttributeId),
                new SqlParameter("@ValueId", model.ValueId),
                new SqlParameter("@LocaleCode", model.Locale),
            };
            var localeReader = Context.ExecuteDataReader(sqlLocaleCheck, localeCheckParameters);
            localeHasRows = localeReader.HasRows;
            localeReader.Close();
            if (localeHasRows)
            {

                const string updateLocaleSql =
                    @"UPDATE dbo.PRV_ATTRIBUTE_VALUE_LOCALE_TAB SET VALUE_NAME=@ValueName, UPDATED_BY=@UpdatedBy, UPDATED_ON=dbo.GET_DATE_AS_SECONDS(GETDATE()) WHERE ATTRIBUTE_ID=@AttributeId AND VALUE_ID = @ValueId AND @LOCALE_CODE=@Locale";
                 var updateLocaleParameters = new List<SqlParameter>
                {
                    new SqlParameter("@AttributeId", model.AttributeId),
                    new SqlParameter("@ValueId", model.ValueId),
                    new SqlParameter("@LocaleCode", model.Locale),
                    new SqlParameter("@ValueName", model.ValueName),
                    new SqlParameter("@UpdatedBy", model.UpdatedBy),
                };
                Context.ExecuteNonQuery(updateLocaleSql,updateLocaleParameters);
            }
            else
            {
                 const string localesql =
                    @"INSERT INTO dbo.PRV_ATTRIBUTE_VALUE_LOCALE_TAB (ATTRIBUTE_ID, VALUE_ID, LOCALE_CODE, VALUE_NAME, UPDATED_ON, UPDATED_BY)
	                                           VALUES (@AttributeId, @ValueId, @LocaleCode,@ValueName,dbo.GET_DATE_AS_SECONDS(GETDATE()),@UpdatedBy)";
                var localeParameters = new List<SqlParameter>
                        {
                        new SqlParameter("@AttributeId", model.AttributeId),
                        new SqlParameter("@ValueId", model.ValueId),
                    new SqlParameter("@LocaleCode", model.Locale),
                    new SqlParameter("@ValueName", model.ValueName),
                        new SqlParameter("@UpdatedBy", model.UpdatedBy),
                        };

                Context.ExecuteNonQuery(localesql, localeParameters);
                
                }

            }
        }
    }

