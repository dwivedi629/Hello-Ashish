﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Database;
using AtHoc.Infrastructure.Sql;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.CustomAttributes.Impl
{
    public class CustomAttributeTargetingDbRepository : DbRepository<Entities.Targeting, CustomAttributeTargetingSpec>, ICustomAttributeTargetingRepository
	{
		public CustomAttributeTargetingDbRepository(IUnitOfWork context) : base(context) { }

		protected override void TranslateSpec(CustomAttributeTargetingSpec spec, SqlBuilder builder, bool query)
		{
            builder.SelectAll<Entities.Targeting>("a");
            builder.From(builder.Table<Entities.Targeting>("a"));
         
			if (spec.ProviderId.HasValue)
			{
				builder.Where("a.PROVIDER_ID = @providerId", new SqlParameter("providerId", spec.ProviderId.Value));
			}

			if (spec.TargetingEntityType.HasValue)
			{
                builder.Where(builder.Condition(Entities.Targeting.Meta.EntityType, ConditionOperator.Equals, spec.TargetingEntityType.Value.GetDescription(), "a"));
			}		

			base.TranslateSpec(spec, builder, query);
		}

	}
}
