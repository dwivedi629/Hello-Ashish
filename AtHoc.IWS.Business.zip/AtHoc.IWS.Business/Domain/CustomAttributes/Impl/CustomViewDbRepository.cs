﻿using System;
using System.Linq;
using System.Collections.Generic;

using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Database;
using AtHoc.Infrastructure.Sql;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.Infrastructure.Resources;

namespace AtHoc.IWS.Business.Domain.CustomAttributes.Impl
{
    public class CustomViewDbRepository : DbRepository<CustomView, CustomViewSpec>, ICustomViewRepository
    {
        public CustomViewDbRepository(IUnitOfWork context) : base(context) {}

        /// <summary>
        /// Delete by mutiple titles at a time, used from List Column Settings
        /// </summary>
        /// <param name="spec"></param>
        /// <returns></returns>
        public Messages DeleteByEntityIds(CustomViewSpec spec)
        {
            var messages = new Messages();
            var builder = this.Context.CreateSqlBuilder();
            var parameters = new List<SqlParameter>();
            //var sql = builder.NewSql("delete {0}<<from>> <<innerjoin>> <<leftjoin>> <<rightjoin>> <<where>>".FormatWith(builder.Table<CustomView>()));
            var sql = builder.NewSql("delete {0} <<from>> <<innerjoin>> <<leftjoin>> <<rightjoin>> <<where>>".FormatWith(builder.Table<CustomView>()));
            if (spec.EntityId.HasValue)
                builder.Where(builder.Condition(CustomView.Meta.EntityId, ConditionOperator.Equals, spec.EntityId.Value));

            if (spec.EntityIds.HasValue() && spec.EntityIds.Any())
                builder.Where(builder.Condition(CustomView.Meta.EntityId, ConditionOperator.In, spec.EntityIds));

            if (spec.ProviderId.HasValue)
            {
                builder.Where(builder.Condition(CustomView.Meta.ProviderId, ConditionOperator.Equals, spec.ProviderId.Value));
            }
            var deleted = this.Context.ExecuteNonQuery(builder.ToRawSql(sql), sql.Parameters);
            return messages;
        }

        protected override void TranslateSpec(CustomViewSpec spec, SqlBuilder builder, bool query)
        {
            builder.SelectAll<CustomView>("a");
            builder.From(builder.Table<CustomView>("a"));

			if (spec.ViewIds != null && spec.ViewIds.Any())
				builder.Where(builder.Condition(CustomView.Meta.ViewId, ConditionOperator.In, spec.ViewIds));

            if (spec.IncludeCustomAttribute ||
                spec.CustomAttributeId.HasValue)
            {
                if (spec.IncludeCustomAttribute)
                    builder.SelectAll<CustomAttribute>("b", postfix: "1");

                builder.InnerJoin("{0} on b.Attribute_Name = a.Title and b.Provider_Id = a.Provider_Id"
                    .FormatWith(builder.Table<CustomAttribute>("b")));

                if (spec.CustomAttributeId.HasValue)
                    builder.Where(builder.Condition(CustomAttribute.Meta.Id, ConditionOperator.Equals, spec.CustomAttributeId.Value, "b"));
            }

            if (spec.EntityId.HasValue)
                builder.Where(builder.Condition(CustomView.Meta.EntityId, ConditionOperator.Equals, spec.EntityId.Value));

            if (spec.EntityIds.HasValue() && spec.EntityIds.Any())
                builder.Where(builder.Condition(CustomView.Meta.EntityId, ConditionOperator.In, spec.EntityIds));
        
            if (spec.CustomViewType.HasValue)
                builder.Where(builder.Condition(CustomView.Meta.ViewType, ConditionOperator.Equals, spec.CustomViewType.Value, "a"));

            if (spec.ProviderId.HasValue)
                builder.Where(builder.Condition(CustomView.Meta.ProviderId, ConditionOperator.Equals, spec.ProviderId.Value, "a"));

            if (spec.DefaultOnly)
                builder.Where(builder.Condition(CustomView.Meta.OperatorId, ConditionOperator.Empty, null, "a"));
            else if (spec.OperatorId.HasValue)
                builder.Where(builder.Condition(CustomView.Meta.OperatorId, ConditionOperator.Equals, spec.OperatorId.Value, "a"));

            if (spec.CustomViewColumnTypes != null && spec.CustomViewColumnTypes.Any())
                builder.Where(builder.Condition(CustomView.Meta.Columnid, ConditionOperator.In, spec.CustomViewColumnTypes, "a"));
        }

        protected override bool OnItemDataBound(CustomViewSpec spec, CustomView obj, DbResultItem resultItem, SqlMapperContext mapContext)
        {
            if (spec.IncludeCustomAttribute)
                obj.CustomAttribute = this.Context.Map.Translate<CustomAttribute>(resultItem, mapContext);

            return true;
        }
    }


#warning Refactor Framework and remove code below. Now the same spec and translate spec using for multiple operations. The issue occurs when deletion when using table aliasing...
	public class CustomViewDbDeleteRepository : DbRepository<CustomView, CustomViewSpec>, ICustomViewDeleteRepository
	{
		public CustomViewDbDeleteRepository(IUnitOfWork context) : base(context) {}

		protected override void TranslateSpec(CustomViewSpec spec, SqlBuilder builder, bool query)
		{
			builder.SelectAll<CustomView>();
			builder.From(builder.Table<CustomView>());

			if (spec.ViewIds != null && spec.ViewIds.Any())
				builder.Where(builder.Condition(CustomView.Meta.ViewId, ConditionOperator.In, spec.ViewIds));

            if (spec.EntityId.HasValue)
                builder.Where(builder.Condition(CustomView.Meta.EntityId, ConditionOperator.Equals, spec.EntityId.Value));

            if (spec.EntityIds.HasValue() && spec.EntityIds.Any())
                builder.Where(builder.Condition(CustomView.Meta.EntityId, ConditionOperator.In, spec.EntityIds));

			if (spec.CustomViewType.HasValue)
				builder.Where(builder.Condition(CustomView.Meta.ViewType, ConditionOperator.Equals, spec.CustomViewType.Value));

			if (spec.ProviderId.HasValue)
				builder.Where(builder.Condition(CustomView.Meta.ProviderId, ConditionOperator.Equals, spec.ProviderId.Value));

            if (spec.OperatorId.HasValue)
                builder.Where(builder.Condition(CustomView.Meta.OperatorId, ConditionOperator.Equals, spec.OperatorId.Value));

			if (spec.CustomViewColumnTypes != null && spec.CustomViewColumnTypes.Any())
				builder.Where(builder.Condition(CustomView.Meta.Columnid, ConditionOperator.In, spec.CustomViewColumnTypes));
		}

		protected override bool OnItemDataBound(CustomViewSpec spec, CustomView obj, DbResultItem resultItem, SqlMapperContext mapContext)
		{
			throw new ApplicationException("That repository is only for deletion");
		}
	}

}
