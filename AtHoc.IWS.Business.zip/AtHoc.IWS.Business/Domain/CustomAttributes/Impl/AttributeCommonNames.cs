﻿namespace AtHoc.IWS.Business.Domain.CustomAttributes.Impl
{
	public static class AttributeCommonNames
	{
		public const string CreatedOn = "CREATEDON";

        public const string UserName = "LOGIN_ID";

        public const string FirstName = "FIRSTNAME";

        public const string LastName = "LASTNAME";

        public const string DisplayName = "DISPLAYNAME";

        public const string MassCommunication = "NPD";

        public const string SystemGroups = "SYSTEM-GROUPS";

        public const string OperatorName = "OPERATOR-USERNAME";

        public const string Status = "STATUS";

        public const string CurrentlyOnline = "DSW-IS-ONLINE";

        public const string Password = "USR_PSWD";

        public const string UserRandomId = "USER_RANDOM_ID";

        public const string PasswordUpdatedOn = "PASSWORD_UPDATED_ON";

        public const string SelfServiceLastSignOn = "SS-LAST-SIGNON";

	    public const string SelfServiceMyInfoUpdatedOn = "SS-MY-INFO-UPDATED-ON";

	    public const string SelfServiceMyDeviceInfoUpdatedOn = "SS-MY-DEVICE-INFO-UPDATED-ON";

        public const string MappingId = "MAPPING_ID";

	    public const string UserId = "USER_ID";

	    public const string ProviderId = "PROVIDER_ID";

        public const string OperatorRoles = "OPERATOR-ROLES";

        public const string SsaTeam = "SSA-TEAM";

	    public const string VirtualSystem = "VIRTUAL-SYSTEM";

        public const string Organizations = "ORGANIZATIONS";

	    public const string RoleCountOtherOrgs = "ROLECOUNT_OTHERORGS";

        //Disable Delete End Users Strings starts
        public const string AdditionInfoColums = "USER_ID,USERNAME,FIRSTNAME,LASTNAME,DISPLAYNAME,OLD_STATUS,NEW_STATUS,STATUS CHANGE COMMENTS";

        public const string StatusUser = "Status";

        public const string Do_not_Auto_Delete_User = "DO-NOT-AUTO-DELETE-USER";

        public const string Do_not_Auto_Disable_User = "DO-NOT-AUTO-DISABLE-USER";

        public const string PurgeUsers = "PURGE_DEL_END_USER";

        public const string DisableDistListCommonName = "AUTO-DISABLE-USERS";

        public const string DeleteDistListCommonName = "AUTO-DELETE-USERS";
        public const int AutoDisableJobId = 1010140;

        public const int AutoDeleteJobId = 1010139;
        

        public const string DisableActionName = "Disabled";

        public const string DeleteActionName = "Deleted";

        public const string FieldCommonName = "DO-NOT-AUTO-DELETE-USER";

        public const string NewUserStatus = "DEL-FULL";

	    public const string UserDisableStatus = "DSB";

        public const string StatusAttributeValue = "DEL";

        public const string ModifyUserSuccess = "Success";

        public const string ModifyUserFailure = "Failure";

        public const string ValidEnabledUsers = "VLD";

        public const string NO = "NO";

        public const string GeoLocation="GeoLocation";

	    public static readonly string[] ColumnHeaders = {"USER_ID","USERNAME","FIRSTNAME","LASTNAME","DISPLAYNAME","OLD_STATUS","NEW_STATUS","STATUS CHANGE COMMENTS"};
	    //Disable Delete End Users Strings ends


        public const string UpdatedOn = "UpdatedOn";
        public const string ValueId = "ValueId";
        public const string UpdatedBy = "UpdatedBy";
        public const string UpdatedFrom = "UpdatedFrom";
        public const string Comments = "Comments";
        public const string StatusId = "StatusId";
        public const string EventId = "EventId";
	    public const string PreventUserMove = "PREVENT-USER-MOVE";

        
	}

    public static class AttributeResultSetNames
    {
        public const string LoginId = "LOGIN_ID";
        public const string UserName = "USERNAME";
        public const string MappingId = "MAPPING_ID";
        public const string OperatorRoles = "Roles";
        public const string Organization = "Organization";
    }
}
