﻿using System;
using System.Collections.Generic;
using System.Linq;

using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Resources;
using AtHoc.IWS.Business.Data;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.CustomAttributes.Impl
{
    public class SaveCustomViewSpec
    {
        public SaveCustomViewSpec()
        {
            ViewType = CustomViewType.UserManagerV2;
        }

        public int Id { get; set; }

        public int? SequenceNo { get; set; }

        public string Action { get; set; }

        public CustomViewColumnType ColumnType { get; set; }

        public CustomAttributeLookup ProviderAttributes { get; set; }

        public IEnumerable<Device> AllDevices { get; set; }

        public CustomViewType ViewType { get; set; }

        public int ProviderId { get; set; }

        public int ViewId { get; set; }
        public int OperatorId { get; set; }

        public string ColumnKeyName { get; set; }
    }

    internal static class CustomViewManager
    {
        internal static Messages SaveCustomView(SaveCustomViewSpec spec)
        {
            var messages = new Messages();

            if (spec.Id <= 0 && spec.ColumnKeyName.IsNullOrEmpty())
            {
                messages.CreateErrorMessage("Custom view id is not set.");
                return messages;
            }

            using (var context = AtHocDbContextFactory.CreateFactory().CreateNgaddataContext())
            {
                context.UseTransaction = true;
                var userCustomViewsTupple = RefreshUserCustomView(context, spec);
                var userCustomViews = userCustomViewsTupple.Item1;
                var userCustomViewCreated = userCustomViewsTupple.Item2;
                switch (spec.Action)
                {
                    case "add":
                        var title = string.Empty;
                        int? entityId = null;
                        var columnid = CustomViewColumnType.CustomField;

                        if (spec.ColumnType == CustomViewColumnType.Role)
                        {
                            entityId = null;
                            columnid = CustomViewColumnType.Role;
                        }
                        else if (spec.ColumnType == CustomViewColumnType.OrgName)
                        {
                            entityId = null;
                            columnid = CustomViewColumnType.OrgName;
                        }
                        else if (spec.ColumnType == CustomViewColumnType.CustomField)
                        {
                            var customAttr = spec.ProviderAttributes.FirstOrDefault(c => c.Id == spec.Id);
                            if (customAttr != null)
                            {
                                entityId = customAttr.Id;
                                columnid = CustomViewColumnType.CustomField;
                            }
                        }
                        else if (spec.ColumnType == CustomViewColumnType.Device)
                        {
                            var attr = spec.AllDevices.FirstOrDefault(d => d.Id == spec.Id);
                            if (attr != null)
                            {
                                entityId = attr.Id;
                                columnid = CustomViewColumnType.Device;
                            }
                        }
                        var customView = new CustomView
                        {
                            ProviderId = spec.ProviderId,
                            ViewType = spec.ViewType,
                            Seq = spec.SequenceNo,
                            EntityId = entityId,
                            Columnid = columnid,
                            OperatorId = spec.OperatorId
                        };
                        context.CustomViewRepository.Save(customView, true);
                        break;

                    case "remove":
                        var viewSpec = new CustomViewSpec { ProviderId = spec.ProviderId, ViewIds = new[] { spec.ViewId } };
                        if (!userCustomViewCreated)
                        {
                            context.CustomViewDeleteRepository.DeleteBySpec(viewSpec);
                        }
                        break;
                }
                context.Commit();
            }

            return messages;
        }

        internal static Messages RemoveCustomView(int providerId, int currentUserId, int customViewId, CustomViewType customViewType, CustomViewColumnType columnId)
        {
            var messages = new Messages();

            if (providerId <= 0)
                throw new ArgumentException("providerId ({0})".FormatWith(providerId));

            if (currentUserId <= 0)
                throw new ArgumentException("currentUserId ({0})".FormatWith(currentUserId));

            if (customViewId <= 0)
                throw new ArgumentException("customAttributeId ({0})".FormatWith(customViewId));

            RemoveCustomViewBySpec(providerId, customViewId, customViewType, columnId);

            return messages;
        }

        private static void RemoveCustomViewBySpec(int providerId, int customViewId, CustomViewType customViewType, CustomViewColumnType customViewColumnType)
        {
            using (var context = AtHocDbContextFactory.CreateFactory().CreateNgaddataContext())
            {
                var spec = new CustomViewSpec
                {
                    ProviderId = providerId,
                    CustomViewType = customViewType
                };

                if (customViewColumnType == CustomViewColumnType.Device)
                {
                    var device = context.DeviceRepository.FindById(customViewId);
                    spec.EntityId = device.Id;
                }
                else if (customViewColumnType == CustomViewColumnType.CustomField)
                {
                    spec.CustomAttributeId = customViewId;
                }
                context.CustomViewDeleteRepository.DeleteBySpec(spec);
                context.SaveChanges();
            }
        }

        internal static int GetUserCustomViewsCountBySpec(CustomViewSpec spec)
        {
            if (!spec.OperatorId.HasValue)
                throw new ApplicationException("Operator id was not provided.");

            using (var context = AtHocDbContextFactory.CreateFactory().CreateNgaddataContext())
            {
                return context.CustomViewRepository.CountBySpec(spec);
            }
        }

       private static Tuple<IEnumerable<CustomView>, bool> RefreshUserCustomView(INgaddataContext context, SaveCustomViewSpec spec)
        {
            var userCustomViewSpec = new CustomViewSpec()
            {
                ProviderId = spec.ProviderId,
                CustomViewType = spec.ViewType,
                OperatorId = spec.OperatorId
            };
            var requireToCreateUserViews = GetUserCustomViewsCountBySpec(userCustomViewSpec) == 0;

            var defaultCustomViews = Enumerable.Empty<CustomView>();
            if (requireToCreateUserViews)
            {
                userCustomViewSpec.OperatorId = null;
                userCustomViewSpec.DefaultOnly = true;
                defaultCustomViews = context.CustomViewRepository.FindBySpec(userCustomViewSpec);
                foreach (var defaultCustomView in defaultCustomViews)
                {
                    defaultCustomView.OperatorId = spec.OperatorId;
                    defaultCustomView.RuntimeStatus = RuntimeStatus.New;

                    if (!(spec.Action == "remove" && defaultCustomView.ViewId == spec.ViewId))
                        context.CustomViewRepository.Save(defaultCustomView, true);
                }
            }
            return new Tuple<IEnumerable<CustomView>, bool>(defaultCustomViews, requireToCreateUserViews);
        }
    }
}
