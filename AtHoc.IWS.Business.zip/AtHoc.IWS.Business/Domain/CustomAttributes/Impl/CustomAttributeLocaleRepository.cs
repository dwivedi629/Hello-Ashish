﻿using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.Entities;
using System.Collections.Generic;
using System.Data;
using AtHoc.Data;
using System.Data.SqlClient;
using System;
using AtHoc.Infrastructure.Log;

namespace AtHoc.IWS.Business.Domain.CustomAttributes.Impl
{
    public class CustomAttributeLocaleRepository : ICustomAttributeLocaleRepository
    {

        public IEnumerable<CustomAttributeLocale> GetLocalizedCustomAttributes(string locale)
        {
            var customAttributeLocale = new List<CustomAttributeLocale>();
            try
            {
                using (var db = new AtHocDbContext())
                {
                    var cmd = db.Database.Connection.CreateCommand();
                    cmd.CommandText = "[dbo].[PRV_GET_ATTRIBUTE_LOCALE]";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@locale", locale));
                    db.Database.Connection.Open();

                    var reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        customAttributeLocale.Add(GetRawRecord(reader));
                    }

                    db.Database.Connection.Close();
                }
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => String.Format("Error occured in GetLocalizedCustomAttributes {0}. Error Message {1}", locale, ex.Message));
                return customAttributeLocale;
            }
            
            return customAttributeLocale;
        }

        private Entities.CustomAttributeLocale GetRawRecord(IDataRecord reader)
        {
            return new Entities.CustomAttributeLocale()
            {
                AttributeId = reader.GetValue("ATTRIBUTE_ID", 0),
                LocaleCode = reader.GetValue("LOCALE_CODE", string.Empty),
                AttributeName = reader.GetValue("ATTRIBUTE_NAME", string.Empty),
                Description = reader.GetValue("DESCRIPTION", string.Empty),
                HelpText = reader.GetValue("HELP_TEXT", string.Empty)
            };
        }
    }
}
