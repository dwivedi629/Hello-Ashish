﻿using System;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.Entities;
using System.Collections.Generic;
using System.Data;
using AtHoc.Data;
using System.Data.SqlClient;
using AtHoc.Infrastructure.Log;

namespace AtHoc.IWS.Business.Domain.CustomAttributes.Impl
{
    public class CustomAttributeValueLocalRepository : ICustomAttributeValueLocaleRepository
    {
        public IEnumerable<CustomAttributeValueLocale> GetLocalizedCustomAttributeValues(string locale)
        {
            var customAttributeValueLocale = new List<CustomAttributeValueLocale>();
            try
            {
                using (var db = new AtHocDbContext())
                {
                    var cmd = db.Database.Connection.CreateCommand();
                    cmd.CommandText = "[dbo].[PRV_GET_ATTRIBUTE_VALUE_LOCALE]";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@locale", locale));
                    db.Database.Connection.Open();

                    var reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        customAttributeValueLocale.Add(GetRawRecord(reader));
                    }

                    db.Database.Connection.Close();
                }
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => String.Format("Error occured in GetLocalizedCustomAttributeValues {0}. Error Message {1}", locale, ex.Message));
                return customAttributeValueLocale;
            }
            return customAttributeValueLocale;
        }

        private Entities.CustomAttributeValueLocale GetRawRecord(IDataRecord reader)
        {
            return new Entities.CustomAttributeValueLocale()
            {
                AttributeId = reader.GetValue("ATTRIBUTE_ID", 0),
                ValueId = reader.GetValue("VALUE_ID", 0),
                LocaleCode = reader.GetValue("LOCALE_CODE",string.Empty),
                ValueName = reader.GetValue("VALUE_NAME", string.Empty),
            };
        }
    }
}
