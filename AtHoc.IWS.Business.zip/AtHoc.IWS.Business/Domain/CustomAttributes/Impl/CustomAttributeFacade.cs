﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Configuration;
using AtHoc.Data.Specification;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Domain;
using AtHoc.Infrastructure.Meta;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Data;
using AtHoc.IWS.Business.Data.SearchSpec;
using AtHoc.IWS.Business.Domain.Audit;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.Infrastructure.Resources;
using AtHoc.IWS.Business.Resources;
using System.Xml.Linq;
using AtHoc.IWS.Business.Service;

namespace AtHoc.IWS.Business.Domain.CustomAttributes.Impl
{
    public class CustomAttributeFacade : FacadeBase<IAtHocContextFactory>, ICustomAttributeFacade
    {
        public CustomAttributeFacade(IAtHocContextFactory contextFactory) : base(contextFactory) { }

        public IEnumerable<CustomAttribute> GetCustomAttributesBySpec(CustomAttributeSpec spec)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.CustomAttributeRepository.FindBySpec(spec);
            }
        }

        public CustomAttribute GetOrgHierarchyAttributeBySpec(int providerId)
        {
            if (providerId > 0)
            {
                using (var context = ContextFactory.CreateNgaddataContext())
                {
                    return context.CustomAttributeRepository.GetOrgHierarchyAttribute(providerId);
                }
            }
            return null;
        }

        public int GetOrgHierarchyAttributeId(int providerId)
        {
            if (providerId > 0)
            {
                using (var context = ContextFactory.CreateNgaddataContext())
                {
                    return context.CustomAttributeRepository.GetOrgHierarchyAttributeId(providerId);
                }
            }
            return 0;
        }

        public IEnumerable<CustomView> GetCustomViewsBySpec(CustomViewSpec spec)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.CustomViewRepository.FindBySpec(spec);
            }
        }

        public IEnumerable<CustomView> GetUserCustomViewsBySpec(CustomViewSpec spec)
        {
            if (!spec.OperatorId.HasValue)
                throw new ApplicationException("Operator id was not provided.");

            using (var context = ContextFactory.CreateNgaddataContext())
            {
                var userCustomViews = context.CustomViewRepository.FindBySpec(spec);
                if (userCustomViews.HasValue())
                    return userCustomViews;

                spec.OperatorId = null;
                spec.DefaultOnly = true;
                return context.CustomViewRepository.FindBySpec(spec);
            }
        }

        public CustomView GetCustomViewBySpec(CustomViewSpec spec)
        {
            return GetCustomViewsBySpec(spec).FirstOrDefault();
        }

        public CustomView GetCustomViewById(int customViewId)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.CustomViewRepository.FindById(customViewId);
            }
        }

        public IEnumerable<CustomAttributeValue> GetCustomAttributeValuesBySpec(CustomAttributeValueSpec spec)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.CustomAttributeValueRepository.FindBySpec(spec);
            }
        }

        public Messages AddCustomView(AddCustomViewSpec addCustomViewSpec)
        {
            var messages = new Messages();

            if (addCustomViewSpec.OperatorId <= 0)
                throw new ArgumentException("providerId ({0})".FormatWith(addCustomViewSpec.OperatorId));

            if (addCustomViewSpec.CurrentUserId <= 0)
                throw new ArgumentException("currentUserId ({0})".FormatWith(addCustomViewSpec.CurrentUserId));

            if (addCustomViewSpec.CustomViewId <= 0)
                throw new ArgumentException("customAttributeId ({0})".FormatWith(addCustomViewSpec.CustomViewId));

            switch (addCustomViewSpec.ColumnId)
            {
                case CustomViewColumnType.CustomField:
                    //TODO: auth permission check??
                    AddCustomAttributeToCustomView(addCustomViewSpec, messages);
                    break;
                case CustomViewColumnType.Device:
                    AddDeviceToCustomView(addCustomViewSpec, messages);
                    break;
                case CustomViewColumnType.UserId:
                    break;
                default:
                    break;
            }

            return messages;
        }

        private void AddDeviceToCustomView(AddCustomViewSpec spec, Messages messages)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                //already exist?
                var device = context.DeviceRepository.FindById(spec.CustomViewId);
                var count = context.CustomViewRepository.CountBySpec(new CustomViewSpec
                {
                    ProviderId = spec.ProviderId,
                    CustomViewType = spec.CustomViewType,
                    EntityId = device.Id
                });

                if (count > 0)
                    messages.Add(AtHocResources.AddCustomView_CustomViewAlreadyExist, MessageType.Error);

                if (messages.NoErrors())
                {
                    //var device = context.DeviceRepository.FindById(customViewId);
                    var customView = new CustomView
                    {
                        ProviderId = spec.ProviderId,
                        ViewType = spec.CustomViewType,
                        Columnid = CustomViewColumnType.Device,
                        Seq = null,
                    };
                    context.CustomViewRepository.Save(customView);
                    context.SaveChanges();
                }
            }
        }

        private void AddCustomAttributeToCustomView(AddCustomViewSpec spec, Messages messages)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                //already exist?
                var count = context.CustomViewRepository.CountBySpec(new CustomViewSpec
                {
                    ProviderId = spec.ProviderId,
                    CustomViewType = spec.CustomViewType,
                    CustomAttributeId = spec.CustomViewId
                });

                if (count > 0)
                    messages.Add(AtHocResources.AddCustomView_CustomViewAlreadyExist, MessageType.Error);

                if (messages.NoErrors())
                {
                    var customAttribute = context.CustomAttributeRepository.FindBySpec(
                        new CustomAttributeSpec
                        {
                            Id = spec.CustomViewId,
                            ExcludeDeleted = true
                        }).SingleOrDefault();

                    var customView = new CustomView
                    {
                        ProviderId = spec.ProviderId,
                        ViewType = spec.CustomViewType,
                        Columnid = CustomViewColumnType.CustomField,
                        Seq = null,
                    };
                    context.CustomViewRepository.Save(customView);

                    context.SaveChanges();
                }
            }
        }

        public void SaveCustomView(CustomView customView)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                context.CustomViewRepository.Save(customView, true);
            }
        }

        public void RemoveCustomView(CustomViewSpec spec)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                context.CustomViewDeleteRepository.DeleteBySpec(spec);
            }
        }

        public IEnumerable<CustomAttributeQueryOperator> ReturnOperatorsForDataType(int dataTypeId)
        {
            var xmlOperators = XElement.Parse(Properties.Resources.QueryOperatorsByDataType);

            var dataType = from element in xmlOperators.Descendants("Datatype")
                           where element.Attribute("id").Value == dataTypeId.ToString()
                           select element;

            if (!dataType.Any()) //datatype not found!
                return Enumerable.Empty<CustomAttributeQueryOperator>();

            var operators = from operatorNode in dataType.First().Elements("Operator")
                            select new CustomAttributeQueryOperator
                            {
                                Id = Int32.Parse(operatorNode.Attribute("id").Value),
                                IsValueRequired = (from od in xmlOperators.Descendants("OperatorDetail")
                                                   where od.Attribute("id").Value == operatorNode.Attribute("id").Value
                                                   select od.Attribute("requireValue").Value).First().ToString().Equals("Y"),
                                CommonName = (from od in xmlOperators.Descendants("OperatorDetail")
                                              where od.Attribute("id").Value == operatorNode.Attribute("id").Value
                                              select od.Attribute("commonName").Value).First().ToString(),
                                ShowAdvancedValueSelector = (operatorNode.Attribute("showAdvancedValueSelector") != null && operatorNode.Attribute("showAdvancedValueSelector").Value == "true")

                            };

            return operators;


        }

        public IEnumerable<CustomAttributeQueryOperator> GetOperands()
        {
            var xmlOperators = XElement.Parse(Properties.Resources.QueryOperatorsByDataType);

            var operands = from element in xmlOperators.Descendants("OperatorDetail")
                           select new CustomAttributeQueryOperator
                           {
                               Id = element.Attribute("id").Value.ConvertTo<int>(),
                               CommonName = element.Attribute("commonName").Value,
                               IsValueRequired = element.Attribute("requireValue").Value.ConvertTo<bool>()
                           };

            return operands;
        }

        public IEnumerable<AtHoc.IWS.Business.Domain.Entities.Targeting> GetCustomAttributeTargetingBySpec(CustomAttributeTargetingSpec spec)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.CustomAttributeTargetingRepository.FindBySpec(spec);
            }
        }

        public Messages SaveCustomView(SaveCustomViewSpec spec)
        {
            return CustomViewManager.SaveCustomView(spec);
        }


        public PagingInfo<CustomAttribute> GetAttributesForList(UserAttributeSearchSpec searchSpec)
        {
            var sortField = CustomAttribute.Meta.AttributeName;
            var orderAsc = true;
            var count = 0;
            var pagedData = new PagingInfo<CustomAttribute>();

            if (searchSpec.ProviderId < 0) throw new ArgumentException("UserAttributeSearchSpec requires ProviderId");

            var sortFieldSpec = searchSpec.Sort.FirstOrDefault();
            if (sortFieldSpec != null)
            {
                var fieldName = sortFieldSpec.Field;
                var sortOrder = sortFieldSpec.Dir;
                if (sortOrder.ToUpper() == "DESC") orderAsc = false;

                switch (fieldName)
                {
                    case "Name":
                        sortField = CustomAttribute.Meta.AttributeName;
                        break;
                    case "AttributeType":
                        sortField = CustomAttribute.Meta.AttributeType;
                        break;
                    case "AttributeOrigin":
                        sortField = CustomAttribute.Meta.AttributeOrigin;
                        break;
                    case "UpdatedOn":
                        sortField = CustomAttribute.Meta.UpdatedOn;
                        break;

                }
            }

            var commonSpec = new CustomAttributeSpec()
            {
                ApplyFeatureMatrix = searchSpec._entityId != CustomAttributeType.Placeholder,
                IncludeValues = searchSpec._entityId == CustomAttributeType.Placeholder,
                ProviderId = searchSpec.ProviderId,
                ExcludeDeleted = true,
                ExcludeLists = true,
                EntityType = new List<CustomAttributeType>() { searchSpec._entityId },
                SearchString = searchSpec.SearchText,
                ExcludeSystem = true,
                CustomAttributeDataTypes = searchSpec.SelectedAttributeTypes,
                CurrentOrganizationAttributesOnly = searchSpec.CurrentOrganizationAttributesOnly,
                OtherOrganizationAttributesOnly = searchSpec.OtherOrganizationAttributesOnly,
                BaseLocale = searchSpec.Locale,
                ExcludeCommonNames=searchSpec.ExcludeCommonNames
            };
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                count = context.CustomAttributeRepository.CountBySpec(commonSpec);
            }
            commonSpec.OrderBy = sortField;
            commonSpec.Page = searchSpec.Page;
            commonSpec.PageSize = searchSpec.PageSize;
            commonSpec.OrderAsc = orderAsc;

            var customAttributes = GetCustomAttributesBySpec(commonSpec);

            pagedData.Data = customAttributes;
            pagedData.Count = count;
            return pagedData;
        }

        public ServiceResult<IEnumerable<CustomAttributeDeleteDependency>> DeleteCustomAttribute(int operatorId, int providerId, int attributeId, string commonName, string userSectionName = null, string selfServiceSectionName = null, string entityId = null, string operatorName = null)
        {
            //TODO: Send Separate Enum for different status,so UI can replace it with localized messages.
            var spec = new CustomAttributeDeleteDependencySpec();
            spec.UserAttributeId = attributeId;
            spec.ProviderId = providerId;

            using (var context = ContextFactory.CreateNgaddataContext())
            {
                var result = new ServiceResult<IEnumerable<CustomAttributeDeleteDependency>>
                {
                    ActionType = ServiceAction.CustomAttributeDeleted,
                    EntityType = entityId.ToUpper() == CustomAttributeType.Placeholder.ToString().ToUpper() ? EntityType.PlaceHoder : EntityType.CustomFieldManager
                };

                var attribute = context.CustomAttributeRepository.FindById(attributeId);
                if (attribute == null)
                {
                    result.CreateErrorMessage("Attribute Not Found To Delete");
                    return result;
                }

                //Ignore placeholder dependency check in below condition
                IEnumerable<CustomAttributeDeleteDependency> dependencies;
                if (entityId.ToUpper() != CustomAttributeType.Placeholder.ToString().ToUpper())
                    dependencies = context.CustomAttributeRepository.CheckDeleteDependency(spec);
                else
                    dependencies = context.CustomAttributeRepository.CheckPlaceholderDeleteDependency(spec);

                if (dependencies.Any())
                {
                    result.CreateErrorMessage("Attribute has dependencies. You can not delete it");
                    return result;
                }


                result.Messages.Add(context.CustomAttributeRepository.DeleteAttribute(providerId, attributeId, commonName, userSectionName, selfServiceSectionName, operatorId));
                OperationAuditor.LogAction(new AuditSpec
                {
                    Action = result.ActionType,
                    Username = operatorName,
                    ObjectType = result.EntityType,
                    ObjectName = attribute.AttributeName,
                    OperatorId = operatorId
                });
                return result;
            }
        }

        public IEnumerable<CustomAttributeDeleteDependency> CheckDeleteDependencies(CustomAttributeDeleteDependencySpec spec)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.CustomAttributeRepository.CheckDeleteDependency(spec);
            }
        }
        public IEnumerable<CustomAttributeDeleteDependency> CheckPlaceholderDeleteDependencies(CustomAttributeDeleteDependencySpec spec)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.CustomAttributeRepository.CheckPlaceholderDeleteDependency(spec);
            }
        }
        public IEnumerable<UserAttributeDataType> GetUserAttributeTypes()
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.CustomAttributeRepository.GetUserAttributeTypes();
            }
        }
        public int ValidateAttributeName(int providerId, string attributeName)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.CustomAttributeRepository.ValidateAttributeName(providerId, attributeName);
            }
        }

        public bool ValidateProviderAttributeId(int providerId, int attributeId, int attributeTypeId)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.CustomAttributeRepository.ValidateProviderAttributeId(providerId, attributeId, attributeTypeId);
            }
        }

        public int ValidateCommonName(int providerId, string commonName)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.CustomAttributeRepository.ValidateCommonName(providerId, commonName);
            }
        }

        public Messages SaveCustomAttribute(CustomAttributeModel model,int providerId)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                var message = context.CustomAttributeRepository.SaveCustomAttribute(model, providerId);
                if (message.FirstOrDefault().Type == MessageType.Success)
                {
                    var auditSpec = new AuditSpec(model.OperatorId, providerId)
                    {
                        Action = model.Id > 0 ? ServiceAction.CustomAttributeUpdated : ServiceAction.CustomAttributeCreated,
                        ObjectType = model.EntityId.ToUpper() == CustomAttributeType.Placeholder.ToString().ToUpper() ? EntityType.PlaceHoder : EntityType.CustomFieldManager,
                        ObjectName = model.CommonName
                    };
                    OperationAuditor.LogAction(auditSpec);
                }
                return message;
            }
        }

        public Messages DeleteAttributeValues(int operatorId, int providerId, int attributeId, string attributeName = null, string entityId = null)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                var message = context.CustomAttributeRepository.DeleteAttributeValues(providerId, attributeId);
                if (message.FirstOrDefault().Type == MessageType.Success)
                {
                    var auditSpec = new AuditSpec(operatorId, providerId)
                    {
                        Action = ServiceAction.CustomAttributeValueDeleted,
                        ObjectType = entityId.ToUpper() == CustomAttributeType.Placeholder.ToString().ToUpper() ? EntityType.PlaceHoder : EntityType.CustomFieldManager,
                        ObjectName = attributeName
                    };
                    OperationAuditor.LogAction(auditSpec);
                }
                return message;
            }
        }

        public Messages SetCustomAttributeDefaultValues(int operatorId, int providerId, int attributeId, string attributeName = null)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                var message = context.CustomAttributeRepository.SetCustomAttributeDefaultValues(providerId, attributeId);
                if (message.FirstOrDefault().Type == MessageType.Success)
                {
                    var auditSpec = new AuditSpec(operatorId, providerId)
                    {
                        Action = ServiceAction.CustomAttributeCleared,
                        ObjectType = EntityType.CustomFieldManager,
                        ObjectName = attributeName
                    };
                    OperationAuditor.LogAction(auditSpec);
                }
                return message;
            }
        }

        public Messages DeletePickListValues(int attributeId, int operatorId)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.CustomAttributeRepository.DeletePickListValues(attributeId, operatorId);
            }
        }
        public ServiceResult<IEnumerable<CustomAttributeDeleteDependency>> DeletePickListValue(string operatorName, int providerId, int attributeId, int valueId, int operatorId)
        {
            //TODO: Send Separate Enum for different status,so UI can replace it with localized messages.
            CustomAttributeDeleteDependencySpec spec = new CustomAttributeDeleteDependencySpec();
            spec.UserAttributeId = attributeId;
            spec.ProviderId = providerId;
            using (var context = ContextFactory.CreateNgaddataContext())
            {

                var result = new ServiceResult<IEnumerable<CustomAttributeDeleteDependency>>
                {
                    ActionType = ServiceAction.CustomAttributeUpdated,
                };

                var attribute = context.CustomAttributeRepository.FindById(attributeId);
                result.EntityType = attribute.EntityId.ToUpper() == CustomAttributeType.Placeholder.ToString().ToUpper() ? EntityType.PlaceHoder : EntityType.CustomFieldManager;
                if (attribute == null)
                {
                    result.CreateErrorMessage("Attribute Not Found To Delete");
                    return result;
                }

                //if (attribute.ProviderId != providerId)
                //{
                //    result.CreateErrorMessage("You cannot delete attribute created in some other VPS from this VPS");
                //    return result;
                //}

                var dependencies = context.CustomAttributeRepository.CheckDeleteDependency(spec);

                if (dependencies.Any())
                {
                    result.CreateErrorMessage("Attribute has dependencies. You can not delete it");
                    return result;
                }

                //TODO: Call Delete Repository Method.
                //TODO: Remove Attributes from all layout
                //TODO: Remove Attributes from Custom View for all operators
                //TODO: Uncomment below line after everything to audit

                result.Messages.Add(context.CustomAttributeRepository.DeletePickListValue(attributeId, valueId, operatorId));
                OperationAuditor.LogAction(new AuditSpec
                {
                    Action = result.ActionType,
                    Username = operatorName,
                    ObjectType = result.EntityType,
                    ObjectName = attribute.AttributeName,
                    OperatorId = operatorId
                });
                return result;
            }
        }
        public Dictionary<string, string> GetReportDetails(int attributeId)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.CustomAttributeRepository.GetReportDetails(attributeId);
            }

        }

       /// <summary>
       /// This function checks if the given attribute is a Status type attribute
       /// </summary>
       /// <param name="attribute"></param>
       /// <returns>Boolean value indicating if the given attribute is status attribute</returns>
        public bool IsStatusAttribute(CustomAttribute attribute)
        {
            if (attribute.AttributeTypeId == CustomAttributeDataType.Picklist && 
                ((attribute.SupportsHistoricalValues!=null) &&
               (attribute.SupportsHistoricalValues.ToLower() == "true" || attribute.SupportsHistoricalValues.ToLower() == "y")))
               return true;
            return false;
        }

        public Dictionary<string, object> CheckHierarchyDependencyList(CustomAttributeHierarchyDependencySpec spec)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.CustomAttributeRepository.CheckHierarchyDependencyList(spec);
            }
        }
    }
}


