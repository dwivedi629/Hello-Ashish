﻿using System;
using System.Collections.Generic;
using System.Linq;

using AtHoc.Infrastructure.Entity;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Data;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Users.Spec;

namespace AtHoc.IWS.Business.Domain.Users.Search
{
	internal class CustomAttributeManager
	{
		public static IEnumerable<DistributionList> GetStaticDistributionLists(DistributionListSpec spec)
		{
			using (var context = AtHocDbContextFactory.CreateFactory().CreateNgaddataContext())
			{
				spec.DistributionListTypes = new[] { ListItemType.Static };
				var providerStaticLists = context.DistributionListRepository.FindBySpec(spec);
			    var providerStaticDistListsIds =
			        providerStaticLists.Where(l => !string.IsNullOrWhiteSpace(l.Definition))
			            .Select(l => Convert.ToInt32(l.Definition));

				if (!spec.UserId.HasValue) return providerStaticLists;

				var operatorStaticDistListsIds = context.AttributeValueRepository.FindBySpec(
					new AttributeValueSpec(spec.UserId.Value)
					{
						AttributeIds = providerStaticDistListsIds
					}
					).Select(l => l.AttributeId);

			    return
			        providerStaticLists.Where(l => !string.IsNullOrWhiteSpace(l.Definition))
			            .Where(l => operatorStaticDistListsIds.Contains(Convert.ToInt32(l.Definition)));
			}
		}

		private static void DeleteUserStaticDistributionLists(INgaddataContext context, AttributeValueSpec spec, bool deleteAll = true)
		{
			var operatorStaticDistListsIds = GetStaticDistListsIds(spec, context).ToArray();
			var idsToDelete = deleteAll ? operatorStaticDistListsIds : operatorStaticDistListsIds.Except(spec.AttributeIds).ToArray();
			if (idsToDelete.Any())
			{
				context.AttributeValueRepository.DeleteBySpec(
					new AttributeValueSpec(spec.UserId)
					{
						AttributeIds = idsToDelete
					}
				);
			}
		}

		public static void SaveUserStaticDistributionLists(AttributeValueSpec spec)
		{
			using (var context = AtHocDbContextFactory.CreateFactory().CreateNgaddataContext())
			{
				context.UseTransaction = true;
				var operatorStaticDistListsIds = GetStaticDistListsIds(spec, context);
				DeleteUserStaticDistributionLists(context, spec, false);
				var attributeIdsToInsert = spec.AttributeIds.Except(operatorStaticDistListsIds);
				foreach (var attributeId in attributeIdsToInsert)
				{
					var value = context.CustomAttributeValueRepository.FindBySpec(
						new CustomAttributeValueSpec
						{
							AttributeId = attributeId,
							CommonName = "YES",
                            BaseLocale = spec.BaseLocale
						}
						).Single();
					var attributeValue = new AttributeValue()
					{
						UserId = spec.UserId.Value,
						AttributeId = attributeId,
						RuntimeStatus = RuntimeStatus.New,
						ValueId = value.ValueId
					};
					context.AttributeValueRepository.Save(attributeValue);
				}
				context.Commit();
			}
		}

		private static IEnumerable<int> GetStaticDistListsIds(AttributeValueSpec spec, INgaddataContext context)
		{
		    var providerStaticDistListsIds = context.DistributionListRepository.FindBySpec(
		        new DistributionListSpec
		        {
		            ProviderId = spec.ProviderId,
		            DistributionListTypes = new[] {ListItemType.Static}
		        }).Where(l => !string.IsNullOrWhiteSpace(l.Definition))
		        .Select(l => Convert.ToInt32(l.Definition)
		        );

			return context.AttributeValueRepository.FindBySpec(
				new AttributeValueSpec(spec.UserId)
				{
					AttributeIds = providerStaticDistListsIds
				})
				.Select(l => l.AttributeId)
				.ToArray();
		}
	}
}


