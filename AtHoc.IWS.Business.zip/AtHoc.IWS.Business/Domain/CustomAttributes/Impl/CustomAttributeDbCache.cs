﻿using System;
using System.Globalization;
using System.Linq;
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.Runtime;
using System.Runtime.Remoting.Messaging;

namespace AtHoc.IWS.Business.Domain.CustomAttributes.Impl
{
    public abstract class CallContextCache<T> : ICustomCache<T>
    {
        private readonly string _cacheKey;
        private readonly ProcessCache _customAttributesProcessCache;

        protected CallContextCache(string cacheKey)
        {
            _cacheKey = cacheKey;
            // Default caching for CustomAttributesProcessCache is 5 mins.
            var cacheDuration = System.Configuration.ConfigurationManager.AppSettings["CustomAttributesProcessCacheInMinutes"] ?? "5";
            var configuration = new ProcessCacheConfiguration
            {
                IsEnabled = true,
                DefaultExpiration = TimeSpan.FromHours(Int32.Parse(cacheDuration)),
                DefaultExpirationType = ExpirationType.Absolute,
                Name = cacheKey,
                PollingInterval = TimeSpan.FromMinutes(Int32.Parse(cacheDuration))
            };
            _customAttributesProcessCache = CustomAttributesProcessCache.GetInstanceProcessCache(configuration);
        }

        public T Get(string key, string baseLocale, bool readFromCache = false)
        {
            var itemCacheKey = String.Concat(key + "~" + baseLocale, _cacheKey);
            dynamic data = null;

            if (readFromCache)
                _customAttributesProcessCache.TryGet(itemCacheKey, out data);
            else
                data = CallContext.GetData(itemCacheKey);                

            if (data == null)
            {
                data = LoadCacheItem(key, baseLocale);
                _customAttributesProcessCache.Set(itemCacheKey, data);
                CallContext.SetData(itemCacheKey, data);
            }
            return (T)data;
        }

        public abstract T LoadCacheItem(string key, string baseLocale);
    }

    internal static class CacheUtils
    {
        internal static void ValidateCacheItem(string key, string baseLocale)
        {
            if (key.IsNullOrEmpty()) throw new ArgumentException("key cannot be null or empty");

            if (baseLocale.IsNullOrEmpty()) throw new ArgumentException("locale cannot be null or empty");

            var providerId = key.ConvertTo<int>();
            if (providerId <= 0) throw new ArgumentException("providerId cannot be less than or equals to 0");
        }
    }

    public class CustomAttributeCache : CallContextCache<CustomAttributeLookup>, ICustomAttributeCache
    {
        public CustomAttributeCache() : base("CustomAttributes") { }

        public override CustomAttributeLookup LoadCacheItem(string key, string baseLocale)
        {
            CacheUtils.ValidateCacheItem(key, baseLocale);

            using (var context = AtHocDbContextFactory.CreateFactory().CreateNgaddataContext())
            {
                return new CustomAttributeLookup(
                        context.CustomAttributeRepository.FindBySpec(new CustomAttributeSpec
                        {
                            IncludeValues = true,
                            IncludeTargeting = true,
                            ProviderId = key.ConvertTo<int>(),
                            BaseLocale = baseLocale,
                            EntityType = new[] { CustomAttributeType.User, CustomAttributeType.Alert, CustomAttributeType.WAM }
                        }));
            }
        }

        public CustomAttributeLookup Get(int providerId, string baseLocale, bool hideMassDevices, bool readFromCache = false)
        {
            if (providerId <= 0) throw new ArgumentException("ProviderId must be greater than 0");

            var providerAttributes = Get(providerId.ToString(CultureInfo.InvariantCulture), baseLocale, readFromCache);

            if (!hideMassDevices)
                return providerAttributes;

            return new CustomAttributeLookup(
                    providerAttributes.Where(a => !CustomAttributeSpec.RestrictedCommonNames.Contains(a.CommonName)));
        }
    }

    public class CustomAttributeValueCache : CallContextCache<CustomAttributeValueLookup>, ICustomAttributeValueCache
    {
        public CustomAttributeValueCache() : base("CustomAttributeValues") { }

        public override CustomAttributeValueLookup LoadCacheItem(string key, string baseLocale)
        {
            CacheUtils.ValidateCacheItem(key, baseLocale);

            using (var context = AtHocDbContextFactory.CreateFactory().CreateNgaddataContext())
            {
                return new CustomAttributeValueLookup(
                        context.CustomAttributeValueRepository.FindBySpec(new CustomAttributeValueSpec
                        {
                            ProviderId = key.ConvertTo<int>(),
                            BaseLocale = baseLocale
                        }));
            }
        }


        public CustomAttributeValueLookup Get(int providerId, string baseLocale, bool readFromCache = false)
        {
            return Get(providerId.ToString(CultureInfo.InvariantCulture), baseLocale, readFromCache);
        }

    }
}