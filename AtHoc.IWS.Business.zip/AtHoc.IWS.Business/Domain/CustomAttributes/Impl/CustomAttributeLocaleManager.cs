﻿using System;
using System.Collections.Generic;
using System.Linq;

using AtHoc.Infrastructure.Entity;

using AtHoc.IWS.Business.Data;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Users.Spec;

namespace AtHoc.IWS.Business.Domain.CustomAttributes.Impl
{
    internal class CustomAttributeLocaleManager
    {
        
    }
}
