﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Cache;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;
using AtHoc.IWS.Business.Domain.Entities;
using System.Runtime.Caching;

namespace AtHoc.IWS.Business.Domain.CustomAttributes.Impl
{
    /// <summary>
    /// Interface to implement cache based on key value.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface IValueCache<T>
    {
        /// <summary>
        // A method to get the data and set the data to cache.
        /// </summary>
        /// <param name="key">Key value.</param>
        /// <returns>List of objects</returns>
        IEnumerable<T> Get(string key);

        /// <summary>
        /// A method to get the items from cache.
        /// </summary>
        /// <param name="key">Key value.</param>
        /// <returns>List of objects.</returns>
        IEnumerable<T> LoadCacheItem(string key);
    }

    /// <summary>
    /// Implementation of Context class based on key value.
    /// </summary>
    /// <typeparam name="T">Expects Class name</typeparam>
    public abstract class CallContextLocaleCache<T> : IValueCache<T>
    {
        private readonly string _cacheKey;

        /// <summary>
        /// Context of loacle cache implemented based on key.
        /// </summary>
        /// <param name="cacheKey">Cache key value</param>
        protected CallContextLocaleCache(string cacheKey)
        {
            _cacheKey = cacheKey;
        }

        /// <summary>
        // A method to get the data and set the data to cache.
        /// </summary>
        /// <param name="key">Key value.</param>
        /// <returns>List of objects</returns>
        public IEnumerable<T> Get(string key)
        {
            var itemCacheKey = String.Concat(_cacheKey, "-", key);
            var cache = MemoryCache.Default;
            var data = cache.Get(itemCacheKey);
            if (data == null)
            {
                data = LoadCacheItem(key);
                cache.Set(itemCacheKey, data, DateTimeOffset.Now.AddMinutes(5));
            }
            return (IEnumerable<T>)data;
        }

        /// <summary>
        /// A method to get the items from cache.
        /// </summary>
        /// <param name="key">Key value.</param>
        /// <returns>List of objects.</returns>
        public abstract IEnumerable<T> LoadCacheItem(string key);

    }

    /// <summary>
    /// A utility class to validate the cache data.
    /// </summary>
    internal static class ValueCacheUtils
    {
        /// <summary>
        /// A method to validate the cache item based on a key.
        /// </summary>
        /// <param name="key">Key value.</param>
        internal static void ValidateCacheItem(string key)
        {
            if (key.IsNullOrEmpty()) throw new ArgumentException("key cannot be null or empty");
        }
    }

    /// <summary>
    /// A class to implement the cache functionality for custom attribute locale values.
    /// </summary>
    public class AttributeLocaleCache : CallContextLocaleCache<Entities.CustomAttributeLocale>, IAttributeLocaleCache
    {
        private readonly ICustomAttributeLocaleRepository _customAttributeLocaleRepository;

        /// <summary>
        /// Constructor of a AttributeLocaleCache class.
        /// </summary>
        /// <param name="customAttributeLocaleRepository">Expects ICustomAttributeLocaleRepository interface for dependecy injection.</param>
        public AttributeLocaleCache(ICustomAttributeLocaleRepository customAttributeLocaleRepository)
            : base("CustomAttributes")
        {
            _customAttributeLocaleRepository = customAttributeLocaleRepository;
        }

        /// <summary>
        /// Load CacheItem based on key passed.
        /// </summary>
        /// <param name="key">Uniquie key value.</param>
        /// <returns>List of CustomAttributeLocale</returns>
        public override IEnumerable<Entities.CustomAttributeLocale> LoadCacheItem(string key)
        {
            ValueCacheUtils.ValidateCacheItem(key);

            return _customAttributeLocaleRepository.GetLocalizedCustomAttributes(key); ;
        }

        /// <summary>
        /// Get the Custom Attributes locale from the cache.
        /// </summary>
        /// <param name="locale">Locale Name</param>
        /// <returns>List of CustomAttributeLocale</returns>
        public IEnumerable<Entities.CustomAttributeLocale> GetAttributesForLocale(string locale)
        {
            ValueCacheUtils.ValidateCacheItem(locale);
            return Get(locale);
        }
    }

    /// <summary>
    /// A class to implement the cache functionality for custom attribute locale values.
    /// </summary>
    public class AttributeLocaleValueCache : CallContextLocaleCache<Entities.CustomAttributeValueLocale>, IAttributeLocaleValueCache
    {
        private readonly ICustomAttributeValueLocaleRepository _customAttributeValueLocaleRepository;

        /// <summary>
        /// Constructor of a AttributeLocaleValueCache class.
        /// </summary>
        /// <param name="customAttributeValueLocaleRepository">Expects ICustomAttributeValueLocaleRepository interface for dependecy injection.</param>
        public AttributeLocaleValueCache(ICustomAttributeValueLocaleRepository customAttributeValueLocaleRepository)
            : base("CustomAttributesValue")
        {
            _customAttributeValueLocaleRepository = customAttributeValueLocaleRepository;
        }

        /// <summary>
        /// Load CacheItem based on key passed.
        /// </summary>
        /// <param name="key">Uniquie key value.</param>
        /// <returns>List of CustomAttributeValueLocale</returns>
        public override IEnumerable<Entities.CustomAttributeValueLocale> LoadCacheItem(string key)
        {
            ValueCacheUtils.ValidateCacheItem(key);
            return _customAttributeValueLocaleRepository.GetLocalizedCustomAttributeValues(key);
        }

        /// <summary>
        /// Get the Custom Attributes locale value from the cache.
        /// </summary>
        /// <param name="locale">Locale Name</param>
        /// <returns>List of CustomAttributeValueLocale</returns>
        public IEnumerable<Entities.CustomAttributeValueLocale> GetAttributeValuesForLocale(string locale)
        {
            ValueCacheUtils.ValidateCacheItem(locale);
            return Get(locale);
        }
    }
}
