﻿using System.Collections.Generic;

using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.CustomAttributes.Impl
{
	public class CommonNameComparer : IEqualityComparer<CustomAttribute>
	{
		public bool Equals(CustomAttribute x, CustomAttribute y)
		{
			return x.CommonName == y.CommonName;
		}

		public int GetHashCode(CustomAttribute obj)
		{
			return obj.GetHashCode();
		}
	}
}
