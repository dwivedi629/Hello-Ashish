﻿using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.CustomAttributes.Impl
{
    public class CustomAttributeLocaleFacade : ICustomAttributeLocaleFacade
    {
        private readonly IAttributeLocaleCache _attributeLocaleCache;
        private readonly IAttributeLocaleValueCache _attributeLocaleValueCache;

        public CustomAttributeLocaleFacade(IAttributeLocaleCache attributeLocaleCache, IAttributeLocaleValueCache attributeLocaleValueCache)
        {
            _attributeLocaleCache = attributeLocaleCache;
            _attributeLocaleValueCache = attributeLocaleValueCache;
        }

        public IEnumerable<Entities.CustomAttributeLocale> GetLocalizedCustomAttributes(string locale)
        {
            return _attributeLocaleCache.GetAttributesForLocale(locale);
        }

        public IEnumerable<Entities.CustomAttributeValueLocale> GetLocalizedCustomAttributeValues(string locale)
        {
            return _attributeLocaleValueCache.GetAttributeValuesForLocale(locale);
        }

        public Entities.CustomAttributeLocale GetLocalizedCustomAttribute(int attributeId, string locale)
        {
            return _attributeLocaleCache.GetAttributesForLocale(locale).Where(x => x.AttributeId == attributeId).FirstOrDefault();
        }

        public Entities.CustomAttributeValueLocale GetLocalizedCustomAttributeWithValue(int attributeId, int valueId, string locale)
        {
            return _attributeLocaleValueCache.GetAttributeValuesForLocale(locale).Where(x => x.AttributeId == attributeId && x.ValueId == valueId).FirstOrDefault();
        }

        public void TransalateCustomAttributes(IEnumerable<CustomAttribute> customAttributes, string locale)
        {
            foreach (var customAttribute in customAttributes)
            {
                // Get the localized attributes
                var localeCustomAttributes = GetLocalizedCustomAttribute(customAttribute.Id, locale);
                if (localeCustomAttributes != null)
                {
                    customAttribute.HelpText = (!String.IsNullOrEmpty(localeCustomAttributes.HelpText) ? localeCustomAttributes.HelpText : customAttribute.HelpText);
                    customAttribute.AttributeName = (!String.IsNullOrEmpty(localeCustomAttributes.AttributeName) ? localeCustomAttributes.AttributeName : customAttribute.AttributeName);
                    customAttribute.Description = (!String.IsNullOrEmpty(localeCustomAttributes.Description) ? localeCustomAttributes.Description : customAttribute.Description);
                }

                // Check if custom attribute has the values
                if (customAttribute.AttributeTypeId.HasValue)
                {
                    if (customAttribute.AttributeTypeId.Value == CustomAttributeDataType.Checkbox
                        || customAttribute.AttributeTypeId.Value == CustomAttributeDataType.Picklist
                        || customAttribute.AttributeTypeId.Value == CustomAttributeDataType.MultiPicklist)
                    {
                        foreach (var customValueName in customAttribute.Values)
                        {
                            // Get the localized attributes value
                            var localizedCustomAttributeWithValue = GetLocalizedCustomAttributeWithValue(customValueName.AttributeId, customValueName.ValueId, locale);
                            if (localizedCustomAttributeWithValue != null)
                                customValueName.ValueName = (!String.IsNullOrEmpty(localizedCustomAttributeWithValue.ValueName) ? localizedCustomAttributeWithValue.ValueName : customValueName.ValueName);
                        }
                    }
                }
            }
        }
    }
}
