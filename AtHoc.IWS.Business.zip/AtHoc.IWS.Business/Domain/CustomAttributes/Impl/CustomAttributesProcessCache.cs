﻿using AtHoc.Runtime;

namespace AtHoc.IWS.Business.Domain.CustomAttributes.Impl
{
    /// <summary>
    /// CustomAttributesProcessCache singleton class.
    /// </summary>
    public class CustomAttributesProcessCache
    {
        private static ProcessCache _processCache = null;

        public CustomAttributesProcessCache()
        {
        }

        /// <summary>
        /// Returns the current Instance for process cache.
        /// </summary>
        /// <param name="configuration"></param>
        /// <returns></returns>
        public static ProcessCache GetInstanceProcessCache(ProcessCacheConfiguration configuration)
        {
            return _processCache ?? (_processCache = new ProcessCache(configuration));
        }
    }
}