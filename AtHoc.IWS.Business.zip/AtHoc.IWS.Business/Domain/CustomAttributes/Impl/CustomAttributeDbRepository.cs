﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Database;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Sql;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using System.Transactions;
using System.Data;
using AtHoc.IWS.Business.Domain.PageLayout;
using AtHoc.IWS.Business.Domain.PageLayout.Spec;
using Microsoft.Practices.ObjectBuilder2;

namespace AtHoc.IWS.Business.Domain.CustomAttributes.Impl
{
    public class CustomAttributeDbRepository : DbRepository<CustomAttribute, CustomAttributeSpec>, ICustomAttributeRepository
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        public CustomAttributeDbRepository(IUnitOfWork context)
            : base(context)
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="spec"></param>
        /// <returns></returns>
        public override Messages DeleteBySpec(CustomAttributeSpec spec)
        {
            throw new NotImplementedException("DeleteBySpec is Not Implemented. Call Some Other method instead");
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public override CustomAttribute FindById(int id)
        {
            var spec = new CustomAttributeSpec() { Id = id, ApplyFeatureMatrix = false, IncludeValues = false };
            var attribute = base.SingleOrDefaultBySpec(spec);
            return attribute;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="spec"></param>
        /// <returns></returns>
        public override IEnumerable<CustomAttribute> FindBySpec(CustomAttributeSpec spec)
        {
            var customAttributes = base.FindBySpec(spec);
            if (spec.IncludeValues)
            {
                customAttributes = customAttributes.ToArray();
                var customAttributeLookup = customAttributes.ToLookup(x => x.Id);

                var customAttributeWithValues = customAttributes
                    .Where(x => x.AttributeTypeId.HasValue &&
                                (x.AttributeTypeId.Value == CustomAttributeDataType.Checkbox ||
                                 x.AttributeTypeId.Value == CustomAttributeDataType.Picklist ||
                                 x.AttributeTypeId.Value == CustomAttributeDataType.MultiPicklist));

                if (customAttributeWithValues.Any())
                {
                    // This query is return to get the localized custom attribute values
                    var sqlQuery = " SELECT PRV_ATTRIBUTE_VALUE_TAB.ATTRIBUTE_ID, PRV_ATTRIBUTE_VALUE_TAB.VALUE_ID, PRV_ATTRIBUTE_VALUE_LOCALE_TAB.VALUE_NAME,";
                    sqlQuery += " PRV_ATTRIBUTE_VALUE_TAB.PRIORITY, PRV_ATTRIBUTE_VALUE_TAB.COMMON_NAME, PRV_ATTRIBUTE_VALUE_TAB.STATUS,";
                    sqlQuery += " PRV_ATTRIBUTE_VALUE_TAB.CHECK_UPDATE_INTERVAL, PRV_ATTRIBUTE_VALUE_TAB.UPDATED_ON, PRV_ATTRIBUTE_VALUE_TAB.UPDATED_BY, ";
                    sqlQuery += " PRV_ATTRIBUTE_VALUE_TAB.SORT_ORDER ";
                    sqlQuery += " FROM PRV_ATTRIBUTE_VALUE_TAB(NOLOCK) LEFT JOIN  PRV_ATTRIBUTE_VALUE_LOCALE_TAB (NOLOCK) ON PRV_ATTRIBUTE_VALUE_TAB.ATTRIBUTE_ID = PRV_ATTRIBUTE_VALUE_LOCALE_TAB.ATTRIBUTE_ID ";
                    sqlQuery += " AND PRV_ATTRIBUTE_VALUE_TAB.VALUE_ID = PRV_ATTRIBUTE_VALUE_LOCALE_TAB.VALUE_ID ";
                    sqlQuery += " AND PRV_ATTRIBUTE_VALUE_LOCALE_TAB.LOCALE_CODE =  @LocaleCode ";
                    sqlQuery += " WHERE PRV_ATTRIBUTE_VALUE_TAB.ATTRIBUTE_ID IN @AttributeIds AND ISNULL(STATUS, '') <> 'DEL' ORDER BY SORT_ORDER";

                    var customAttributeValueLookup = Context.Query<CustomAttributeValue>(sqlQuery,
                        (customAttributeValue, resultItem, mapContext) =>
                        {
                            customAttributeValue.CustomAttribute = customAttributeLookup[customAttributeValue.AttributeId].FirstOrDefault();
                            return true;
                        },
                        new SqlParameter("AttributeIds", customAttributeWithValues.Select(x => x.Id)),
                        new SqlParameter("LocaleCode", spec.BaseLocale)
                        ).ToLookup(x => x.AttributeId);


                    foreach (var item in customAttributeWithValues)
                        item.Values = customAttributeValueLookup[item.Id];
                }
            }

            return customAttributes;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="customAttributes"></param>
        /// <param name="providerId"></param>
        /// <returns></returns>
        private IEnumerable<CustomAttribute> ApplyFeatureMatrix(IEnumerable<CustomAttribute> customAttributes, int? providerId)
        {
            if (providerId != null)
            {
                var orgHierarchyAttributeId = GetOrgHierarchyAttributeId(providerId.Value);

                using (var context = AtHocDbContextFactory.CreateFactory().CreateNgaddataContext())
                {
                    var featureMatrix = context.ProviderRepository.GetFeatureMatrix(providerId.Value);
                    if (featureMatrix != null)
                    {
                        var customAttributesTobeRemoved =
                            customAttributes.Where(
                                x =>
                                    (x.CommonName == AttributeCommonNames.SsaTeam &&
                                     !featureMatrix.IsEmergencyCommunitySupported)
                                    ||
                                    (x.Id == orgHierarchyAttributeId &&
                                     !featureMatrix.IsOrgHierarchySupported)
                                );

                        return customAttributes.Except(customAttributesTobeRemoved);
                    }
                }
            }
            return customAttributes;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="providerId"></param>
        /// <returns></returns>
        public int GetOrgHierarchyAttributeId(int providerId)
        {

            var orgHierarchyAttributeId = Context.ExecuteScalar<int>("select dbo.GET_HRCHY_ATTRIBUTE_ID(@providerId, @isListHrchy)",
                   new SqlParameter[]
                    {
                        new SqlParameter("providerId", providerId), 
                        new SqlParameter("isListHrchy", 0)
                    });

            return orgHierarchyAttributeId;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="providerId"></param>
        /// <returns></returns>
        public CustomAttribute GetOrgHierarchyAttribute(int providerId)
        {

            var orgHierarchyAttributeId = GetOrgHierarchyAttributeId(providerId);
            var orgHierarchyCustomAttribute = FindBySpec(new CustomAttributeSpec
            {
                ProviderId = providerId,
                ApplyFeatureMatrix = false,
                Id = orgHierarchyAttributeId
            }).FirstOrDefault();

            return orgHierarchyCustomAttribute;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="spec"></param>
        /// <returns></returns>
        public IEnumerable<CustomAttributeDeleteDependency> CheckDeleteDependency(CustomAttributeDeleteDependencySpec spec)
        {
            var dependencies = new List<CustomAttributeDeleteDependency>();
            var providerParameter = new SqlParameter("providerId", spec.ProviderId);
            var attributeParameter = new SqlParameter("attributeId", spec.UserAttributeId);
            var valueParameter = new SqlParameter("valueId", spec.ValueId);
            var pageParameter = new SqlParameter("page", spec.Page);
            var pageSizeParameter = new SqlParameter("recordsPerPage", spec.PageSize);

            using (var reader = Context.ExecuteDataReader("exec dbo.DPN_DELETE_ATTRIBUTE_CHECK_BY_PAGE", providerParameter, attributeParameter, valueParameter, pageParameter, pageSizeParameter))
            {
                while (reader.Read())
                {
                    var dependency = new CustomAttributeDeleteDependency
                    {
                        UsedIn = reader["USED_IN"].ToString(),
                        UsedFor = reader["USED_FOR"].ToString(),
                        EntityId = reader["OBJECT_ID"].ConvertTo<Int32>(),
                        EntityName = reader["OBJECT_NAME"].ToString(),
                        ProviderId = reader["PROVIDER_ID"].ConvertTo<Int32>(),
                        SourceProvider = reader["PROVIDER_DISPLAYNAME"].ToString()
                    };
                    dependencies.Add(dependency);
                }
            }
            return dependencies;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="spec"></param>
        /// <returns></returns>
        public IEnumerable<CustomAttributeDeleteDependency> CheckPlaceholderDeleteDependency(CustomAttributeDeleteDependencySpec spec)
        {
            var dependencies = new List<CustomAttributeDeleteDependency>();
            var providerParameter = new SqlParameter("providerId", spec.ProviderId);
            var attributeParameter = new SqlParameter("attributeId", spec.UserAttributeId);
            var valueParameter = new SqlParameter("valueId", spec.ValueId);
            var pageParameter = new SqlParameter("page", spec.Page);
            var pageSizeParameter = new SqlParameter("recordsPerPage", spec.PageSize);

            using (var reader = Context.ExecuteDataReader("exec dbo.DPN_DELETE_PLACEHOLDER_CHECK_BY_PAGE", providerParameter, attributeParameter, valueParameter, pageParameter, pageSizeParameter))
            {
                while (reader.Read())
                {
                    var dependency = new CustomAttributeDeleteDependency
                    {
                        UsedIn = reader["USED_IN"].ToString(),
                        UsedFor = reader["USED_FOR"].ToString(),
                        EntityId = reader["OBJECT_ID"].ConvertTo<Int32>(),
                        EntityName = reader["OBJECT_NAME"].ToString(),
                        ProviderId = reader["PROVIDER_ID"].ConvertTo<Int32>(),
                        SourceProvider = reader["PROVIDER_DISPLAYNAME"].ToString()
                    };
                    dependencies.Add(dependency);
                }
            }
            return dependencies;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="attributeId"></param>
        /// <returns></returns>
        public Messages DeleteAttribute(int providerId, int attributeId, string commonName, string userSectionName = null, string selfServiceSectionName = null, int operatorId = 1)
        {
            var messages = new Messages();
            try
            {
                using (var context = AtHocDbContextFactory.CreateFactory().CreateNgaddataContext())
                {

                    // Update Attribute Status
                    context.ExecuteNonQuery("Update dbo.PRV_ATTRIBUTE_TAB Set Status='DEL',Updated_on=dbo.GET_DATE_AS_SECONDS(getdate()),Updated_by=@operator_id where provider_id=@provider_id and attribute_id=@attribute_id",
                    new SqlParameter("@provider_id", providerId),
                    new SqlParameter("@attribute_id", attributeId),
                    new SqlParameter("@operator_id", operatorId));

                    // Update Attribute Value Status
                    context.ExecuteNonQuery("Update dbo.PRV_ATTRIBUTE_Value_TAB Set Status='DEL',Updated_on=dbo.GET_DATE_AS_SECONDS(getdate()),Updated_by=@operator_id  where attribute_id=@attribute_id",
                    new SqlParameter("@attribute_id", attributeId),
                    new SqlParameter("@operator_id", operatorId));

                    // Update User Section
                    if (!string.IsNullOrEmpty(userSectionName))
                    {
                        var layout = context.PageLayoutRepository.FindBySpec(new PageLayoutSpec { ProviderId = providerId, PageId = PageLayoutenum.NEWEUM.ToString() }).FirstOrDefault();
                        var updatedXml = layout.LayoutXml;
                        updatedXml = DeleteAttributeInXml(commonName, userSectionName, updatedXml);
                        layout.LayoutXml = updatedXml;
                        context.PageLayoutRepository.Save(layout, false, Entities.PageLayout.Meta.PageId, Entities.PageLayout.Meta.ProviderId);
                    }

                    // Update User Section
                    if (!string.IsNullOrEmpty(selfServiceSectionName))
                    {
                        var layout = context.PageLayoutRepository.FindBySpec(new PageLayoutSpec { ProviderId = providerId, PageId = PageLayoutenum.OPERATORDETAILS.ToString() }).FirstOrDefault();
                        var updatedXml = layout.LayoutXml;
                        updatedXml = DeleteAttributeInXml(commonName, selfServiceSectionName, updatedXml);
                        layout.LayoutXml = updatedXml;
                        context.PageLayoutRepository.Save(layout, false, Entities.PageLayout.Meta.PageId, Entities.PageLayout.Meta.ProviderId);
                    }
                    context.SaveChanges();

                    messages.Add(new Message
                    {
                        Type = MessageType.Success,
                        Value = "UserAttributeManager_Attribute_Delete_Success_Message"
                    });

                    return messages;
                }

            }
            catch (Exception exception)
            {
                messages.Add(new Message
                {
                    Type = MessageType.Error,
                    Sender = typeof(CustomAttributeDbRepository),
                    Value = exception.Message
                });
            }
            return messages;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="attributeId"></param>
        /// <param name="operatorId"></param>
        /// <returns></returns>
        public Messages DeletePickListValues(int attributeId, int operatorId)
        {
            var messages = new Messages();
            try
            {
                using (Context)
                {
                    // Update Attribute Value Status
                    Context.ExecuteNonQuery("Update dbo.PRV_ATTRIBUTE_Value_TAB Set Status='DEL',Updated_on=dbo.GET_DATE_AS_SECONDS(getdate()),Updated_by=@operator_id  where attribute_id=@attribute_id",
                    new SqlParameter("@attribute_id", attributeId),
                    new SqlParameter("@operator_id", operatorId));

                    messages.Add(new Message
                    {
                        Type = MessageType.Success,
                    });

                    return messages;
                }
            }
            catch (Exception exception)
            {
                messages.Add(new Message
                {
                    Type = MessageType.Error,
                    Value = exception.Message
                });
            }
            return messages;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<UserAttributeDataType> GetUserAttributeTypes()
        {
            var listOfAttribute = new List<UserAttributeDataType>();
            using (var reader = Context.ExecuteDataReader("SELECT * FROM GLB_ATTRIBUTE_TYPE_TAB WITH (NOLOCK) ORDER BY ATTRIBUTE_TYPE ASC"))
            {
                while (reader.Read())
                {
                    var attributeType = new UserAttributeDataType
                    {
                        AttributeTypeId = (Int32)reader["ATTRIBUTE_TYPE_ID"],
                        AttributeType = reader["ATTRIBUTE_TYPE"].ToString(),
                        ClassType = reader["CLASS_TYPE"].ToString(),
                        Description = reader["Description"].ToString(),
                        UserInterfaceDataType = reader["UI_DATA_TYPE"].ToString()
                    };
                    listOfAttribute.Add(attributeType);

                }


            }
            return listOfAttribute;
        }
        //
        protected override void SetSorting(CustomAttributeSpec spec, SqlBuilder builder) { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="spec"></param>
        /// <param name="builder"></param>
        /// <param name="query"></param>
        protected override void TranslateSpec(CustomAttributeSpec spec, SqlBuilder builder, bool query)
        {

            //Prepare Select Statement List. PRV_GET_ATTRIBUTES returns all inherited attributes all the way from System Set up 3. 
            //Fully configurable should be Yes if the attribute is local to VPS, therefore case statement there.
            // Join with PRV_PRovider_Tab to get the origin of Attribute and GLB_ATTRIBUTE_TYPE_TAB To get the Attribute Type
            builder.Select("a.*, p.PROVIDER_NAME as ATTRIBUTE_ORIGIN, G.ATTRIBUTE_TYPE");
            builder.From("PRV_GET_ATTRIBUTES(@providerId) a", new SqlParameter("providerId", spec.ProviderId == null ? 0 : spec.ProviderId.Value));
            builder.InnerJoin("PRV_PROVIDER_TAB P with (nolock) on a.provider_ID = p.PROVIDER_Id");
            builder.InnerJoin("GLB_ATTRIBUTE_TYPE_TAB G with (nolock) on A.ATTRIBUTE_TYPE_ID = G.ATTRIBUTE_TYPE_ID");

            //Check to see if Emergency Community and Organization Hierarchy Attribute should be returned. If ApplyFeature Matrix is on then we should honor
            //the feature matrix implementation.
            if (spec.ApplyFeatureMatrix)
            {
                using (var context = AtHocDbContextFactory.CreateFactory().CreateNgaddataContext())
                {
                    var featureMatrix = context.ProviderRepository.GetFeatureMatrix(spec.ProviderId == null ? 0 : spec.ProviderId.Value);
                    if (featureMatrix != null)
                    {
                        if (!featureMatrix.IsEmergencyCommunitySupported)
                            builder.Where("A.COMMON_NAME NOT IN ('SSA-TEAM')");
                        if (!featureMatrix.IsOrgHierarchySupported)
                            builder.Where("A.ATTRIBUTE_ID NOT IN (Select dbo.GET_HRCHY_ATTRIBUTE_ID(@providerId, 0))");
                    }
                }
            }


            if (spec.ExcludeCommonNames!=null && spec.ExcludeCommonNames.Any())
            {
              builder.Where("A.COMMON_NAME NOT IN ('" + spec.ExcludeCommonNames.Join("','") + "')");
            }

            //Filter Certain Common Names for Import Flow. Is Mass Device, ATHOC GV KEYS AND ATHOC GV TYPE Should not be Importable. 
            if (spec.UseCommonNamesRestriction.HasValue && spec.UseCommonNamesRestriction.Value)
                builder.Where(builder.Condition(CustomAttribute.Meta.CommonName, ConditionOperator.NotIn, CustomAttributeSpec.RestrictedCommonNames, "a"));

            //All other filters below
            if (spec.CommonNames.HasValue())
                builder.Where(builder.Condition(CustomAttribute.Meta.CommonName, ConditionOperator.In, spec.CommonNames, "a"));

            if (spec.CommonName.HasValue())
                builder.Where(builder.Condition(CustomAttribute.Meta.CommonName, ConditionOperator.Equals, spec.CommonName, "a"));

            if (spec.Name.HasValue())
                builder.Where(builder.Condition(CustomAttribute.Meta.AttributeName, ConditionOperator.Equals, spec.Name, "a"));

            if (spec.AttributeNames.HasValue())
                builder.Where(builder.Condition(CustomAttribute.Meta.AttributeName, ConditionOperator.In, spec.AttributeNames, "a"));

            if (spec.CustomAttributeDataType.HasValue)
                builder.Where(builder.Condition(CustomAttribute.Meta.AttributeTypeId, ConditionOperator.Equals, spec.CustomAttributeDataType.Value, "a"));

            if (spec.CustomAttributeDataTypes.HasValue())
                builder.Where(builder.Condition(CustomAttribute.Meta.AttributeTypeId, ConditionOperator.In, spec.CustomAttributeDataTypes, "a"));

            if (spec.Id.HasValue)
                builder.Where(builder.Condition(CustomAttribute.Meta.Id, ConditionOperator.Equals, spec.Id.Value, "a"));

            if (spec.Ids.HasValue())
                builder.Where(builder.Condition(CustomAttribute.Meta.Id, ConditionOperator.In, spec.Ids, "a"));

            if (spec.ExcludeIds.HasValue())
                builder.Where(builder.Condition(CustomAttribute.Meta.Id, ConditionOperator.NotIn, spec.ExcludeIds, "a"));

            if (spec.ExcludeDeleted.HasValue && spec.ExcludeDeleted.Value)
                builder.Where(builder.Condition(CustomAttribute.Meta.Status, ConditionOperator.NotEqualsWithIsNull, "DEL", "a"));

            if (spec.Status.HasValue)
                builder.Where(builder.Condition(CustomAttribute.Meta.Status, ConditionOperator.EqualsWithIsNull, spec.Status.Value, "a"));

            if (spec.SearchString != null)
            {
                //builder.Where(builder.Condition(CustomAttribute.Meta.AttributeName, ConditionOperator.Contains, spec.SearchString, "a"));
                string strQuery = string.Empty;
                for (int i = 0; i < spec.SearchString.Length; i++)
                {
                    if (spec.SearchString[i].Contains(","))
                    {
                        string[] orString = spec.SearchString[i].Split(',');
                        string oStr = " AND (";
                        foreach (var str in orString)
                        {
                            if (str.Contains("_"))
                                oStr = oStr + CustomAttribute.Meta.AttributeName.ColumnName + " like '%" + str.Trim().Replace("'", "''").Replace("_", "\\_") + "%' escape '\\' OR ";
                            else
                                oStr = oStr + CustomAttribute.Meta.AttributeName.ColumnName + " like '%" + str.Trim().Replace("'", "''") + "%' OR ";

                        }
                        oStr = oStr.TrimEnd().TrimEnd("OR".ToCharArray());
                        strQuery = strQuery + oStr + " )";
                    }
                    else
                    {
                        if (spec.SearchString[i].Contains("_"))
                            strQuery = strQuery + " AND (" + CustomAttribute.Meta.AttributeName.ColumnName + " like  '%" + spec.SearchString[i].Trim().Replace("'", "''").Replace("_", "\\_") + "%' escape '\\') ";
                        else
                            strQuery = strQuery + " AND (" + CustomAttribute.Meta.AttributeName.ColumnName + " like  '%" + spec.SearchString[i].Trim().Replace("'", "''") + "%') ";

                    }
                }
                if (strQuery != string.Empty)
                {
                    strQuery = strQuery.TrimStart().TrimStart("AND".ToCharArray());
                    builder.Where(strQuery);
                }
            }

            //PRV_GET_ATTRIBUTES returns Distribution List as Well. We want to exclude lists from User Attribute Manager 
            if (spec.ExcludeLists.HasValue && spec.ExcludeLists.Value)
            {
                builder.Where("(" +
                              "A.ATTRIBUTE_ID NOT IN (SELECT ISNULL(DEFINITION,0) FROM PDL_LIST_TAB WITH (NOLOCK) WHERE PROVIDER_ID = @providerId AND LIST_TYPE='STATIC') AND " +
                              "( " +
                              " ISNULL(A.HIERARCHY_ID,0) NOT IN ( " +
                              " SELECT HIERARCHY_ID from PDL_HIERARCHY_TAB WITH (NOLOCK) where PROVIDER_ID IN (@providerId) AND ( HIERARCHY_TYPE = 'LOC' OR (HIERARCHY_TYPE= 'ORG' and AVAILABLE_FOR_USERS= 'N'))" +
                              ")))");
            }

            //To exclude system attributes. Except for Organization Hierarchy which is also a system attribute.
            if ((spec.EntityType != null && !spec.EntityType.Where(a => a.Equals(CustomAttributeType.Placeholder)).Any()) && spec.ExcludeSystem.HasValue && spec.ExcludeSystem.Value)
            {
                builder.Where("((IS_SYSTEM_ATTRIBUTE = 'N') OR (ISNULL(A.HIERARCHY_ID,0)<>0 AND A.IS_SYSTEM_ATTRIBUTE='Y'))");
            }

            // Get current organization attributes only
            if (spec.CurrentOrganizationAttributesOnly)
            {
                builder.Where(builder.Condition(CustomAttribute.Meta.ProviderId, ConditionOperator.Equals, spec.ProviderId, "a"));
            }

            if (spec.EntityType != null && spec.EntityType.Where(a => a.Equals(CustomAttributeType.Placeholder)).Any())
            {
                //List<int> providers = new List<int>();
                //providers.Add(spec.ProviderId.GetValueOrDefault());
                //providers.Add(3);
                //builder.Where(builder.Condition(CustomAttribute.Meta.ProviderId, ConditionOperator.In, providers, "a"));
                builder.Where("((A.PROVIDER_ID = 3 AND A.IS_STANDARD='Y') OR A.PROVIDER_ID= @providerId )");
            }

            // Get other organization attributes
            if (spec.OtherOrganizationAttributesOnly)
            {
                builder.Where(builder.Condition(CustomAttribute.Meta.ProviderId, ConditionOperator.NotEquals, spec.ProviderId, "a"));
            }

            if (spec.EntityType != null && spec.EntityType.Any())
            {
                builder.Where(builder.Condition(CustomAttribute.Meta.EntityId, ConditionOperator.In, spec.EntityType, "a"));
            }

            //Take Care of Sorting
            if (spec.OrderBy != null && spec.OrderBy.ColumnName.IsNotNullOrEmpty())
            {

                var orderColumn = builder.Column(spec.OrderBy) + " {0}";
                var orderDirection = (spec.OrderAsc.HasValue && spec.OrderAsc.Value == false) ? "DESC" : "ASC";

                if (spec.OrderBy.Equals(CustomAttribute.Meta.AttributeOrigin))
                {
                    orderColumn = "p.DISPLAY_NAME {0}";
                }

                if (spec.OrderBy.Equals(CustomAttribute.Meta.AttributeType))
                {
                    orderColumn = "G.ATTRIBUTE_TYPE {0},a.Supports_Historical_Values {0}";
                }

                var orderSql = string.Format(orderColumn, orderDirection);

                builder.OrderBy(orderSql);

            }


            if (spec.IncludeTargeting || spec.IsTargetableGroup.HasValue)
            {
                if (spec.IncludeTargeting)
                    builder.SelectAll<AtHoc.IWS.Business.Domain.Entities.Targeting>("b", "2");
                builder.LeftJoin("PRV_TARGETING_TAB b with (nolock) on (b.PROVIDER_ID = @providerId AND (b.ENTITY_ID = a.ATTRIBUTE_ID OR (a.ATTRIBUTE_TYPE_ID = {0} AND b.ENTITY_ID = a.HIERARCHY_ID)))".FormatWith((int)CustomAttributeDataType.Path));
                if (spec.IsTargetableGroup.HasValue)
                {
                    if (spec.IsTargetableGroup == true)
                    {
                        builder.Where("b.ENTITY_ID is not null");
                        builder.OrderBy("b.DISPLAY_ORDER");

                    }
                    else
                    {
                        builder.Where("b.ENTITY_ID is null");

                    }
                }
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="spec"></param>
        /// <param name="obj"></param>
        /// <param name="resultItem"></param>
        /// <param name="mapContext"></param>
        /// <returns></returns>
        protected override bool OnItemDataBound(CustomAttributeSpec spec, CustomAttribute obj, DbResultItem resultItem, SqlMapperContext mapContext)
        {
            if (spec.IncludeTargeting)
                obj.Targeting = this.Context.Map.Translate<AtHoc.IWS.Business.Domain.Entities.Targeting>(resultItem, mapContext);

            return base.OnItemDataBound(spec, obj, resultItem, mapContext);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="attributeName"></param>
        /// <returns></returns>
        public int ValidateAttributeName(int providerId, string attributeName)
        {
            using (var db = new AtHocDbContext())
            {
                object[] parameters = { providerId, attributeName };
                var id = db.Database
                    .SqlQuery<int>("SELECT ATTRIBUTE_ID FROM PRV_GET_ATTRIBUTES({0}) where Attribute_Name ={1}", providerId, attributeName).AsQueryable().FirstOrDefault();

                if (id == 0)
                    return -1;
                else
                    return id;

            }
        }

        /// <summary>
        /// Check AttributeId is in  Provider contex.
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="attributeId"></param>
        /// <returns></returns>
        public bool ValidateProviderAttributeId(int providerId, int attributeId, int attributeTypeId)
        {
            using (var db = new AtHocDbContext())
            {                
                object[] parameters = { providerId, attributeId };
                var typeId = db.Database
                    .SqlQuery<int>("SELECT ATTRIBUTE_TYPE_ID FROM PRV_GET_ATTRIBUTES({0}) where Provider_id={0} and Attribute_id={1} ", providerId, attributeId).AsQueryable().FirstOrDefault();

                if (typeId > 0 && typeId == attributeTypeId)              
                    return true;
            }
            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="commonName"></param>
        /// <returns></returns>
        public int ValidateCommonName(int providerId, string commonName)
        {
            using (var db = new AtHocDbContext())
            {
                object[] parameters = { providerId, commonName };
                var id = db.Database
                    .SqlQuery<int>("SELECT ATTRIBUTE_ID FROM PRV_GET_ATTRIBUTES({0}) where Common_Name ={1}", providerId, commonName).AsQueryable().FirstOrDefault();

                if (id == 0)
                    return -1;
                else
                    return id;

            }
        }
        /// <summary>
        /// Save attribute and values  in attribute  tables and in corresponding local tables
        /// </summary>
        /// <param name="spec"></param>
        /// <returns></returns>
        public Messages SaveCustomAttribute(CustomAttributeModel model, int providerId)
        {
            Messages messages;
            // insert/update attribute in mian and locale attribute tables
            try
            {
                if (ValidateAttribute(model, out messages))
                {
                    string value = "UserAttributeManager_PlaceHolder_Save_Success_Message";
                    using (var context = AtHocDbContextFactory.CreateFactory().CreateNgaddataContext())
                    {
                        // If the attribute/placeholder is in same provider context then save the details otherwise not required to save.
                        if (providerId == model.ProviderId)
                        {
                            var parameters = new List<SqlParameter>
                                    {
                                        new SqlParameter("@prvId", model.ProviderId),
                                        new SqlParameter("@attributeId", model.Id,null,ParameterDirection.InputOutput),
                                        new SqlParameter("@fieldName", model.Name),
                                        new SqlParameter("@fieldCommonName", model.CommonName),
                                        new SqlParameter("@dataType", model.AttributeTypeId),
                                        new SqlParameter("@minValue", model.MinValue),
                                        new SqlParameter("@maxValue", model.MaxValue),
                                        new SqlParameter("@editLevel", model.EditLevel),
                                        new SqlParameter("@pickListValuesCSV", model.PickListValuesCSV),
                                        new SqlParameter("@toolTip", model.ToolTip),
                                        new SqlParameter("@helpText", model.HelpText),
                                        new SqlParameter("@mandatory", model.IsMandatory),
                                        new SqlParameter("@isEncrypted", model.IsEncrypted),
                                        new SqlParameter("@searchAllowed", model.SearchAllowed),
                                        new SqlParameter("@displayDropdown", model.DisplayDropdown),
                                        new SqlParameter("@defaultValue", model.DefaultValue),
                                        new SqlParameter("@picklistDelimiter", model.PicklistDelimiter),
                                        new SqlParameter("@isStandard",model.IsStandard),
                                        new SqlParameter("@reportName", model.ReportName),
                                        new SqlParameter("@reportDescription", model.Description),
                                        new SqlParameter("@isSystem", model.IsSystem),
                                        new SqlParameter("@supportsHistory", model.SupportsHistory),
                                        new SqlParameter("@iconId", model.IconId),
                                        new SqlParameter("@updatedBy", model.UpdatedBy),
                                        new SqlParameter("@createdBy", model.CreatedBy),
                                        new SqlParameter("@entityId",model.EntityId),
                                        new SqlParameter("@debugFlag", 0),
                                        new SqlParameter("@lineNumbers", model.LinesToShow)
                                    };
                            context.ExecuteNonQuery(@"EXEC ngaddata.dbo.PRV_SET_ATTRIBUTE", parameters);
                            var attributeId = (int)parameters[1].OutputValue;
                        }
                        if (model.EntityId.ToUpper() != CustomAttributeType.Placeholder.ToString().ToUpper())
                        {
                            // if the attribute is flowdown attribute then assign current providerId to attribute providerId
                            // to save the layout details.
                            // insert attribute name in User details
                            var userLayout = context.PageLayoutRepository.FindBySpec(new PageLayoutSpec { ProviderId = providerId, PageId = PageLayoutenum.NEWEUM.ToString() }).FirstOrDefault();
                            if (userLayout != null)
                            {
                                var updatedXml = userLayout.LayoutXml;
                                updatedXml = GetUpdatedPageLayoutXML(model.OldCommonName, model.CommonName,
                                    model.UserDetailsSectionName, updatedXml);
                                userLayout.LayoutXml = updatedXml;
                                context.PageLayoutRepository.Save(userLayout, false, Entities.PageLayout.Meta.PageId,
                                    Entities.PageLayout.Meta.ProviderId);
                            }

                            // insert attribute name in Self Service page layout xml
                            var selfServiceLayout = context.PageLayoutRepository.FindBySpec(new PageLayoutSpec { ProviderId = providerId, PageId = PageLayoutenum.OPERATORDETAILS.ToString() }).FirstOrDefault();
                            if (selfServiceLayout != null)
                            {
                                var updatedXml = selfServiceLayout.LayoutXml;
                                updatedXml = GetUpdatedPageLayoutXML(model.OldCommonName, model.CommonName,
                                    model.SelfServiceSectionName, updatedXml);
                                selfServiceLayout.LayoutXml = updatedXml;
                                context.PageLayoutRepository.Save(selfServiceLayout, false, Entities.PageLayout.Meta.PageId,
                                    Entities.PageLayout.Meta.ProviderId);
                            }

                            value = "UserAttributeManager_Save_Success_Message";
                        }
                        context.SaveChanges();

                    }
                    messages.Add(new Message
                    {
                        Type = MessageType.Success,
                        Value = value
                    });
                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
            return messages;
        }

        /// <summary>
        /// To save or update attribute name in attribute tables
        /// </summary>
        /// <param name="spec"></param>
        public int SaveAttribute(CustomAttributeModel model)
        {

            var parameters = new List<SqlParameter>
            {
                new SqlParameter("prvId", model.ProviderId),
               new SqlParameter("attributeId", model.Id,null,ParameterDirection.InputOutput),
                new SqlParameter("fieldName", model.Name),
                new SqlParameter("fieldCommonName", model.CommonName),
                new SqlParameter("dataType", model.AttributeTypeId),
                new SqlParameter("minValue", model.MinValue),
                new SqlParameter("maxValue", model.MaxValue),
                new SqlParameter("editLevel", model.EditLevel),
                new SqlParameter("pickListValuesCSV", model.PickListValuesCSV),
                new SqlParameter("toolTip", model.ToolTip),
                new SqlParameter("helpText", model.HelpText),
                new SqlParameter("mandatory", model.IsMandatory),
                new SqlParameter("isEncrypted", model.IsEncrypted),
                new SqlParameter("searchAllowed", model.SearchAllowed),
                new SqlParameter("displayDropdown", model.DisplayDropdown),
                new SqlParameter("defaultValue", model.DefaultValue),
                new SqlParameter("picklistDelimiter", model.PicklistDelimiter),
                new SqlParameter("isStandard",model.IsStandard),
                new SqlParameter("reportName", model.ReportName),
                new SqlParameter("reportDescription", model.Description),
                new SqlParameter("isSystem", model.IsSystem),
                new SqlParameter("supportsHistory", model.SupportsHistory),
                new SqlParameter("iconId", model.IconId),
                new SqlParameter("updatedBy", model.UpdatedBy),
                new SqlParameter("createdBy", model.CreatedBy),
                new SqlParameter("entityId",model.EntityId),
                new SqlParameter("debugFlag", 0),
                new SqlParameter("lineNumbers", model.LinesToShow)
            };
            Context.ExecuteStoredProcedure(@"dbo.PRV_SET_ATTRIBUTE", parameters.ToArray());
            return (int)parameters[1].OutputValue;
        }

        /// <summary>
        /// to save or update the pagelayout xml w.r.t page id
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="attributeName"></param>
        /// <param name="sectionName"></param>
        /// <param name="pageId"></param>
        public void SaveAttributeNameInPageLayout(int? providerId, string oldCommonName, string commonName, string sectionName, string pageId)
        {
            Entities.PageLayout layout;
            using (var context = AtHocDbContextFactory.CreateFactory().CreateNgaddataContext())
            {
                layout = context.PageLayoutRepository.FindBySpec(new PageLayoutSpec { ProviderId = providerId, PageId = pageId }).FirstOrDefault();
                string updatedXml = layout.LayoutXml;
                updatedXml = GetUpdatedPageLayoutXML(oldCommonName, commonName, sectionName, updatedXml);
                layout.LayoutXml = updatedXml;
                context.PageLayoutRepository.Save(layout, false, Entities.PageLayout.Meta.PageId, Entities.PageLayout.Meta.ProviderId);
                context.SaveChanges();

            }
        }

        /// <summary>
        /// to save or update the pagelayout xml w.r.t page id
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="attributeName"></param>
        /// <param name="sectionName"></param>
        /// <param name="pageId"></param>
        public void DeleteAttributeNameInPageLayout(int? providerId, string commonName, string sectionName, string pageId)
        {
            Entities.PageLayout layout;
            using (var context = AtHocDbContextFactory.CreateFactory().CreateNgaddataContext())
            {
                layout = context.PageLayoutRepository.FindBySpec(new PageLayoutSpec { ProviderId = providerId, PageId = pageId }).FirstOrDefault();
                string updatedXml = layout.LayoutXml;
                updatedXml = DeleteAttributeInXml(commonName, sectionName, updatedXml);
                layout.LayoutXml = updatedXml;
                context.PageLayoutRepository.Save(layout, false, Entities.PageLayout.Meta.PageId, Entities.PageLayout.Meta.ProviderId);
                context.SaveChanges();
            }
        }

        public string DeleteAttributeInXml(string commonName, string sectionName, string pageLayout)
        {
            var xml = new XmlDocument();
            xml.LoadXml(pageLayout);
            XmlNode nextNode = null;
            var xnList = xml.SelectSingleNode("/page/row/column/bucket/section/fields[field/text() =\"" + commonName + "\"]");
            if (xnList == null)
            {
                xnList = xml.SelectSingleNode("/page/row/column/bucket/section/section/fields[field/text() =\"" + commonName + "\"]");
            }
            if (xnList != null)
            {
                if (xnList.ParentNode != null && xnList.ParentNode["title"] != null)
                {
                    var existingNode = xnList.SelectSingleNode("field[text() =\"" + commonName + "\"]");
                    var xmlElement = xnList.ParentNode["title"];
                    if (xmlElement != null && (xnList.ParentNode != null && String.Compare(xmlElement.InnerText, sectionName,
                            StringComparison.OrdinalIgnoreCase) == 0))
                    {
                        nextNode = existingNode.NextSibling;
                    }
                    xnList.RemoveChild(existingNode);
                }
            }
            return xml.InnerXml;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="attributeName"></param>
        /// <param name="sectionName"></param>
        /// <param name="pageLayout"></param>
        /// <returns></returns>
        public string GetUpdatedPageLayoutXML(string oldCommonName, string commonName, string sectionName, string pageLayout)
        {
            var xml = new XmlDocument();
            xml.LoadXml(pageLayout);
            var updateRequired = true;
            XmlNode nextNode = null;

            string name = commonName.Equals(oldCommonName) ? commonName : oldCommonName != null ? oldCommonName : commonName;

            var xnList = xml.SelectSingleNode("/page/row/column/bucket/section/fields[field/text() =\"" + name + "\"]");
            if (xnList == null)
            {
                xnList = xml.SelectSingleNode("/page/row/column/bucket/section/section/fields[field/text() =\"" + name + "\"]");
            }
            if (xnList != null)
            {
                if (xnList.ParentNode != null && xnList.ParentNode["title"] != null)
                {
                    var existingNode = xnList.SelectSingleNode("field[text() =\"" + name + "\"]");
                    var xmlElement = xnList.ParentNode["title"];
                    if (xmlElement != null && (xnList.ParentNode != null && String.Compare(xmlElement.InnerText, sectionName,
                            StringComparison.OrdinalIgnoreCase) == 0))
                    {
                        nextNode = existingNode.NextSibling;
                    }
                    xnList.RemoveChild(existingNode);
                }
                else
                {
                    updateRequired = false;
                }
            }
            if (updateRequired)
            {
                var sectionNode = xml.SelectSingleNode("/page/row/column/bucket/section[title/text() ='" + sectionName + "']");
                //if it is null check child sections
                if (sectionNode == null)
                {
                    sectionNode = xml.SelectSingleNode("/page/row/column/bucket/section/section[title/text() ='" + sectionName + "']");
                }
                if (sectionNode != null)
                {
                    XmlElement createdElement = xml.CreateElement("field");
                    createdElement.InnerText = commonName;
                    if (nextNode == null)
                    {
                        var xmlElement = sectionNode["fields"];
                        if (xmlElement != null) xmlElement.AppendChild(createdElement);
                    }
                    else
                    {
                        var xmlElement = sectionNode["fields"];
                        if (xmlElement != null) xmlElement.InsertBefore(createdElement, nextNode);
                    }
                }
            }
            return xml.InnerXml;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="attributeId"></param>
        /// <returns></returns>
        public Dictionary<string, string> GetReportDetails(int attributeId)
        {
            Dictionary<string, string> rpt = new Dictionary<string, string>();

            using (var reader = Context.ExecuteDataReader("SELECT Top 1 REPORT_NAME,REPORT_DESCRIPTION FROM RPT_REPORT_TAB WITH (NOLOCK) WHERE ENTITY_ID =@EntityId AND STATUS='ACT' AND ISNULL(REPORT_NAME, '') <> '' ", new SqlParameter("EntityId", attributeId)))
            {
                while (reader.Read())
                {
                   rpt.Add("REPORT_NAME", reader["REPORT_NAME"].ToString());
                   rpt.Add("REPORT_DESCRIPTION", reader["REPORT_DESCRIPTION"].ToString());
                }
                return rpt;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="attributeModel"></param>
        /// <param name="validateMessages"></param>
        /// <returns></returns>
        public bool ValidateAttribute(CustomAttributeModel attributeModel, out Messages validateMessages)
        {
            validateMessages = new Messages();
            bool result = true;
            try
            {
                if ((attributeModel.Name.ToUpper() == "ROLE" || attributeModel.Name.ToUpper() == "ROLES") && attributeModel.EntityId == "USER")
                {
                    validateMessages.Add(new Message
                    {
                        Type = MessageType.Error,
                        Value = "UserAttributeManager_Roles_Unique_Message"
                    });
                    result = false;
                }
                else if ((attributeModel.Name.ToUpper() == "ORGANIZATION" ||
                          attributeModel.Name.ToUpper() == "ORGANIZATIONS") && attributeModel.EntityId == "USER" &&
                         attributeModel.CommonName.ToUpper() != "ORGANIZATIONS")
                {
                    validateMessages.Add(new Message
                    {
                        Type = MessageType.Error,
                        Value = "UserAttributeManager_Organization_Unique_Message"
                    });
                    result = false;
                }
                else if (!string.IsNullOrWhiteSpace(attributeModel.Name))
                {
                    if (attributeModel.AttributeTypeId != 9)
                    {
                        if (attributeModel.EntityId != "PLACEHOLDER")
                        {
                            if (attributeModel.Name.Trim().Length > 128)
                            {
                                var value = "UserAttributeManager_AttributeName_MaxLength_Message";
                                validateMessages.Add(new Message
                                {
                                    Type = MessageType.Error,
                                    Value = value
                                });
                                result = false;
                            }
                            else if (attributeModel.CommonName.Trim().Length > 128)
                            {
                                var value = "UserAttributeManager_CommonName_MaxLength_Message";
                                validateMessages.Add(new Message
                                {
                                    Type = MessageType.Error,
                                    Value = value
                                });
                                result = false;
                            }
                        }
                        int attrValidation = Context.ExecuteScalar<int>("select dbo.PRV_VALIDATE_ATTRIBUTE(@providerId, @Name,@CommonName,@attrId,@entityId)",
                       
                                new SqlParameter[]
                                {
                                    new SqlParameter("providerId", attributeModel.ProviderId),
                                    new SqlParameter("Name", attributeModel.Name),
                                    new SqlParameter("CommonName", attributeModel.CommonName),
                                    new SqlParameter("attrId", attributeModel.Id),
                                    new SqlParameter("entityId", attributeModel.EntityId),

                                });

                        if (attrValidation == 0)
                        {
                            var value = "Placeholder_Placeholder_Duplicate";
                            if (attributeModel.EntityId != CustomAttributeType.Placeholder.ToString().ToUpper())
                            {
                                value = "UserAttributeManager_AttributeName_Unique_Message";
                            }

                            validateMessages.Add(new Message
                            {
                                Type = MessageType.Error,
                                Value = value
                            });
                            result = false;
                        }
                        else if (attrValidation == 1)
                        {
                            validateMessages.Add(new Message
                            {
                                Type = MessageType.Error,
                                Value = "UserAttributeManager_CommonName_Unique_Message"
                            });
                            result = false;
                        }

                    }
                }
                else
                {
                    validateMessages.Add(new Message
                    {
                        Type = MessageType.Error,
                        Value = "UserAttributeManager_AttributeName_Required_Message"
                    });
                }
            }
            catch (Exception e)
            {
                validateMessages.Add(new Message
                {
                    Type = MessageType.Error,
                    Value = e.Message
                });
            }
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="attributeId"></param>
        /// <returns></returns>
        public Messages DeleteAttributeValues(int providerId, int attributeId)
        {
            var messages = new Messages();
            try
            {
                var providerParameter = new SqlParameter("providerId", providerId);
                var attributeParameter = new SqlParameter("attributeId", attributeId);

                using (Context)
                {
                    Context.ExecuteStoredProcedure("dbo.DPN_ATTRIBUTE_CLEAR_VALUE",
                        new SqlParameter[] { providerParameter, attributeParameter });
                    messages.Add(new Message
                    {
                        Type = MessageType.Success,
                    });

                    return messages;
                }
            }
            catch (Exception exception)
            {
                messages.Add(new Message
                {
                    Type = MessageType.Error,
                    Value = exception.Message
                });
            }
            return messages;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="attributeId"></param>
        /// <returns></returns>
        public Messages SetCustomAttributeDefaultValues(int providerId, int attributeId)
        {
            var messages = new Messages();
            try
            {
                var providerParameter = new SqlParameter("providerId", providerId);
                var attributeParameter = new SqlParameter("attributeId", attributeId);

                using (Context)
                {
                    Context.ExecuteStoredProcedure("dbo.DPN_ATTRIBUTE_DEFAULT_VALUE",
                        new SqlParameter[] { providerParameter, attributeParameter });

                    messages.Add(new Message
                    {
                        Type = MessageType.Success,
                    });

                    return messages;
                }
            }
            catch (Exception exception)
            {
                messages.Add(new Message
                {
                    Type = MessageType.Error,
                    Value = exception.Message
                });
            }
            return messages;
        }

        public Messages DeletePickListValue(int attributeId, int valueId, int operatorId)
        {
            var messages = new Messages();
            try
            {
                using (Context)
                {
                    // Update Attribute Value Status
                    Context.ExecuteNonQuery("Update dbo.PRV_ATTRIBUTE_Value_TAB Set Status='DEL',Updated_on=dbo.GET_DATE_AS_SECONDS(getdate()),Updated_by=@operator_id where attribute_id=@attribute_id and value_id=@value_id",
                    new SqlParameter("@attribute_id", attributeId),
                    new SqlParameter("@value_id", valueId),
                    new SqlParameter("@operator_id", operatorId));
                    messages.Add(new Message
                    {
                        Type = MessageType.Success,
                        Value = "User Attribute Value has been deleted successfully"
                    });
                    return messages;
                }
            }
            catch (Exception exception)
            {
                messages.Add(new Message
                {
                    Type = MessageType.Error,
                    Value = exception.Message
                });
            }
            return messages;
        }

        /// <summary>
        /// /
        /// </summary>
        /// <param name="spec"></param>
        /// <returns></returns>        
        public Dictionary<string, object> CheckHierarchyDependencyList(CustomAttributeHierarchyDependencySpec spec)
        {


            const string dependencySp = "exec dbo.DPN_DELETE_HIERARCHY_CHECK_BY_PAGE";
            var listdependencies = new List<CustomAttributeDeleteDependency>();
            var list = new List<CustomAttributeHierarchyDeleteList>();
            var totalRecordsCount = 0;
            var sqlParameters = new List<SqlParameter>
            {
                new SqlParameter("@count",0,null,ParameterDirection.Output) ,
                new SqlParameter("@hierarchyIds", spec.ListIds.Join(",")),
                new SqlParameter("@page", spec.Page),
                new SqlParameter("@recordsPerPage", spec.PageSize),
                new SqlParameter("@sortBy", spec.Sort[0].Field),
                new SqlParameter("@sortOrder", spec.Sort[0].Dir)
                             
            };


            using (Context)
            {
                using (var dataSet = Context.ExecuteDataSet(dependencySp, sqlParameters))
                {
                    totalRecordsCount = sqlParameters[0].OutputValue.ConvertTo<Int32>();

                    var hierarchiesDependencyTable = dataSet.Tables[0];
                    var userDependencyTable = dataSet.Tables[1];
                    listdependencies.AddRange(from DataRow row in hierarchiesDependencyTable.Rows
                                              select new CustomAttributeDeleteDependency
                                              {
                                                  UsedIn = row["USED_IN"].ToString(),
                                                  UsedFor = row["USED_FOR"].ToString(),
                                                  EntityId = row["OBJECT_ID"].ConvertTo<Int32>(),
                                                  EntityName = row["OBJECT_NAME"].ToString(),
                                                  ProviderId = row["PROVIDER_ID"].ConvertTo<Int32>(),
                                                  SourceProvider = row["PROVIDER_DISPLAYNAME"].ToString()
                                              });

                    list.AddRange(from DataRow row in userDependencyTable.Rows
                                  select new CustomAttributeHierarchyDeleteList
                                  {
                                      ListId = row["LIST_ID"].ConvertTo<Int32>(),
                                      Count = row["COUNT"].ConvertTo<Int32>(),
                                  });
                }

            }
            var details = new Dictionary<string, object>
            {
                {"DependencyList", listdependencies},
                {"listUserDependency", list},
                {"totalRecordsCount",totalRecordsCount}
            };
            return details;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    public enum AttributeType
    {
        Number = 1,
        String = 2,
        Memo = 3,
        Date = 4,
        DateTime = 5,
        Picklist = 6,
        MultiPicklist = 7,
        Checkbox = 8,
        Path = 9,
        Geography = 10,
        Time = 11,
    }

}
