﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Data;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.Infrastructure.Resources;

namespace AtHoc.IWS.Business.Domain.CustomAttributes
{
    public interface ICustomViewRepository : IRepository<CustomView, CustomViewSpec>
    {
        Messages DeleteByEntityIds(CustomViewSpec spec);
    }
	public interface ICustomViewDeleteRepository : IRepository<CustomView, CustomViewSpec>
    {
    }

	
}
