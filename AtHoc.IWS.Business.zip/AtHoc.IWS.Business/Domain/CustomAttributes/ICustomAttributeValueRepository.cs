﻿using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Resources;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.CustomAttributes
{
	public interface ICustomAttributeValueRepository : IRepository<CustomAttributeValue, CustomAttributeValueSpec> {
        void SaveCustomAttributeValue(CustomAttributeValueModel model);

    }
}
