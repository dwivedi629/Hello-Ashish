﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Resources;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.Publishing.Data;

namespace AtHoc.IWS.Business.Domain.CustomAttributes
{
    public interface ICustomAttributeRepository : IRepository<CustomAttribute, CustomAttributeSpec>
    {
        CustomAttribute GetOrgHierarchyAttribute(int providerId);
        int GetOrgHierarchyAttributeId(int providerId);
        IEnumerable<CustomAttributeDeleteDependency> CheckDeleteDependency(CustomAttributeDeleteDependencySpec spec);
        Messages DeleteAttribute(int providerId, int attributeId, string commonName, string userSectionName=null, string selfServiceSectionName=null, int operatorId=1);

        IEnumerable<UserAttributeDataType> GetUserAttributeTypes();
        int ValidateAttributeName(int providerId, string attributeName);
        bool ValidateProviderAttributeId(int providerId, int attributeId, int attributeTypeId);
        int ValidateCommonName(int providerId, string commonName);
        Messages SaveCustomAttribute(CustomAttributeModel model, int providerId);
        int SaveAttribute(CustomAttributeModel model);
        bool ValidateAttribute(CustomAttributeModel attributeName, out Messages validateMessages);

        Messages DeleteAttributeValues(int providerId, int attributeId);

        Messages SetCustomAttributeDefaultValues(int providerId, int attributeId);

        Messages DeletePickListValues(int attributeId, int operatorId);
        Dictionary<string, string> GetReportDetails(int attributeId);
        Messages DeletePickListValue(int attributeId, int valueId, int operatorId);
        IEnumerable<CustomAttributeDeleteDependency> CheckPlaceholderDeleteDependency(CustomAttributeDeleteDependencySpec spec);
        Dictionary<string, object> CheckHierarchyDependencyList(CustomAttributeHierarchyDependencySpec spec);
    }
}
