﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Data;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.Infrastructure.Resources;

namespace AtHoc.IWS.Business.Domain.CustomAttributes
{
    /// <summary>
    /// Interface to implement cache based on key value.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface ICustomCache<T>
    {
        T Get(string key, string baseLocale, bool readFromCache = false);

        T LoadCacheItem(string key, string baseLocale);
    }

}
