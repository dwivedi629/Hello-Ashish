﻿using System.ComponentModel.DataAnnotations;

using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;

namespace AtHoc.IWS.Business.Domain.Entities
{
	[MetadataType(typeof(OperatorEntityAccessMeta))]
	[MetaObject(TableName = "UPS_ENTITY_ACCESS_TAB")]
	public class OperatorEntityAccess : EntityBase
	{
		[MetaProperty(ColumnName = "USER_ID", DbTypeName = "int", IsKey = true)]
		[Required]
		public virtual int UserId
		{
			get { return this.Get<int>("UserId"); }
			set { this.Set<int>("UserId", value); }
		}

		[MetaProperty(ColumnName = "PROVIDER_ID", DbTypeName = "int", IsKey = true)]
		[Required]
		public virtual int ProviderId
		{
			get { return this.Get<int>("ProviderId"); }
			set { this.Set<int>("ProviderId", value); }
		}

		[MetaProperty(ColumnName = "ACCESS_TYPE", DbTypeName = "nvarchar", MaxLength = 3, AutoTrim = true)]
		[MaxLength(3)]
		public virtual string AccessType
		{
			get { return this.Get<string>("AccessType"); }
			set { this.Set<string>("AccessType", value); }
		}

		[MetaProperty(ColumnName = "ENTITY_TYPE", DbTypeName = "nvarchar", MaxLength = 3, AutoTrim = true)]
		[MaxLength(3)]
		public virtual string EntityType
		{
			get { return this.Get<string>("EntityType"); }
			set { this.Set<string>("EntityType", value); }
		}

		[MetaProperty(ColumnName = "ENTITY_ID", DbTypeName = "int")]
		[Required]
		public virtual int EntityId
		{
			get { return this.Get<int>("EntityId"); }
			set { this.Set<int>("EntityId", value); }
		}

		#region Properties
		public class Meta
		{
			public static readonly MetaProperty UserId = MetaObject.Get(typeof(OperatorEntityAccess))["UserId"];
			public static readonly MetaProperty ProviderId = MetaObject.Get(typeof(OperatorEntityAccess))["ProviderId"];
			public static readonly MetaProperty AccessType = MetaObject.Get(typeof(OperatorEntityAccess))["AccessType"];
			public static readonly MetaProperty EntityType = MetaObject.Get(typeof(OperatorEntityAccess))["EntityType"];
			public static readonly MetaProperty EntityId = MetaObject.Get(typeof(OperatorEntityAccess))["EntityId"];
		}
		#endregion Properties
	}

	#region OperatorEntityAccessMeta
	public partial class OperatorEntityAccessMeta
	{
	}
	#endregion OperatorEntityAccessMeta
}
