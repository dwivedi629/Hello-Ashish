﻿using System;

namespace AtHoc.IWS.Business.Domain.Entities
{
    /// <summary>
    /// Alert Log Entity for Who/When Alert get publish.
    /// </summary>
    public class AlertSourceLog
    {
        /// <summary>
        /// Alert Id 
        /// </summary>
        public int AlertId { get; set; }

        /// <summary>
        /// Entity Id could be EventId if source is Event
        /// </summary>
        public string EntityId { get; set; }

        /// <summary>
        /// Entity from where Alert get publish e.g. Event Manager, SSA Map, Alert Manager
        /// </summary>
        public string Entity { get; set; }

        /// <summary>
        /// Date and Time when Alert is published.
        /// </summary>
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Operator Id who published the Alert.
        /// </summary>
        public int CreatedBy { get; set; }
        
    }
}
