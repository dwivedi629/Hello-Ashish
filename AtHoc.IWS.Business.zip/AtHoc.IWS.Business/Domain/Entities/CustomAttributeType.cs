﻿using System.ComponentModel;
namespace AtHoc.IWS.Business.Domain.Entities
{
    public enum CustomAttributeType
    {
        User,
        Placeholder,
        Alert,
        WAM
    }

    public enum CustomAttributeDataType
    {
        /// <summary>
        /// Unknown is optionally used as Attribute Data Type for cases
        /// code is using AtHoc.Entity and its dynamic Attributes as intermediate 
        /// data container, e.g. - for passing result of a Query call from Service
        /// down to the client code.
        /// 
        /// Value in this case will contain application expected data type.
        /// </summary>
        Unknown,
        /// <summary>
        /// AtHoc Number, Value is string containing numeric value
        /// </summary>
        [Description("UserAttributeManager_Number")]
        Number,
        /// <summary>
        /// Value is string
        /// </summary>
        [Description("UserAttributeManager_Text")]
        String,
        /// <summary>
        /// AtHoc Memo, Value is string
        /// </summary>
        [Description("UserAttributeManager_Memo")]
        Memo,
        /// <summary>
        /// AtHoc Date, Value is string containing Date value
        /// </summary>
        [Description("UserAttributeManager_Date")]
        Date,
        /// <summary>
        /// AtHoc DateTime, Value is string containing DateTime value
        /// </summary>
        [Description("UserAttributeManager_DateTime")]
        DateTime,
        /// <summary>
        /// AtHoc Picklist, Value is string containing representation of Picklist object value(s)
        /// </summary>
        [Description("UserAttributeManager_Single_select_Picklist")]
        Picklist,
        /// <summary>
        /// AtHoc MultiPicklist, Value is string containing MultiPicklist object value(s)
        /// </summary>
        [Description("UserAttributeManager_Multi_select_Picklist")]
        MultiPicklist,
        /// <summary>
        /// AtHoc Checkbox, Value is string containing Checkbox value
        /// </summary>
        [Description("UserAttributeManager_Checkbox")]
        Checkbox,
        /// <summary>
        /// AtHoc Path, Value is string containing Path value
        /// </summary>
         [Description("UserAttributeManager_Path")]
        Path,
        /// <summary>
        /// AtHoc GeoLocation, Value is GeoLocationAttribute instance
        /// </summary>
        [Description("UserAttributeManager_Geolocation")]
        GeoLocation,
        //** below are general purpose items and are not persistable (yet) in ngaddata DB.
        /// <summary>
        /// Value contains another AttributeValue
        /// </summary>
        /// 

        [Description("UserAttributeManager_Time")]
        Time,
        /// <summary>
        /// Value contains another Entity
        /// </summary>
        Entity,
        /// <summary>
        /// Value contains an object other than any of the specialized types as listed by AttributeDataType.
        /// AttributeInfo.UserDefinedType is expected to be set with an integer value representing the said UDT.
        /// NOTE: can be c# basic types such as int, byte, float, double, etc..., user defined structure or object!
        /// </summary>
        Object,
        Device,
        AttributeValue,
        //** end of general purpose items
    }

    

    public enum UsedInPages
    {
        [Description("UserAttributeManager_Dependency_Page_OperatorPermissions")]
        Operator_Permissions,
        [Description("UserAttributeManager_Dependency_Page_Alert")]
        Alert,
        [Description("UserAttributeManager_Dependency_Page_AlertTemplate")]
        Alert_Template,
        [Description("UserAttributeManager_Dependency_Page_DisableEndUsers")]
        Disable_End_Users,
        [Description("UserAttributeManager_Dependency_Page_DeleteEndUsers")]
        Delete_End_Users,
        [Description("UserAttributeManager_Dependency_Page_SystemDynamicDistList")]
        System_Dynamic_Dist_List,
        [Description("UserAttributeManager_Dependency_Page_DynamicDistributionList")]
        Dynamic_Distribution_List,
        [Description("UserAttributeManager_Dependency_Page_PeopleLayer")]
        People_Layer,
        [Description("UserAttributeManager_Dependency_Page_PAEventTemplate")]
        PA_Event_Template,
        [Description("PA_Event_Manager_EntityNameSingle")]
        PA_Event,
    }

    public enum UsedForSection
    {
        [Description("UserAttributeManager_Dependency_Section_UserBaseRestriction")]
        User_Base_Restriction,
        [Description("UserAttributeManager_Dependency_Section_Targeting")]
        Targeting,
        [Description("UserAttributeManager_Dependency_Section_ResponseOptions")]
        Response_Options,
        [Description("UserAttributeManager_Dependency_Section_DisableEndUserCriteria")]
        Disable_End_User_Criteria,
        [Description("UserAttributeManager_Dependency_Section_DeleteEndUserCriteria")]
        Delete_End_User_Criteria,
        [Description("UserAttributeManager_Dependency_Section_SystemDynamicDistListCriteria")]
        System_Dynamic_Dist_List_Criteria,
        [Description("UserAttributeManager_Dependency_Section_MembershipCriteria")]
        Membership_Criteria,
        [Description("UserAttributeManager_Dependency_Section_EndUserCriteria")]
        End_User_Criteria,
        [Description("UserAttributeManager_Dependency_Section_FillCountandControlledDelivery")]
        Fill_Count_and_Controlled_Delivery,
        [Description("UserAttributeManager_Dependency_Section_AccountabilityTemplate")]
        Accountability_Template
    }
}
