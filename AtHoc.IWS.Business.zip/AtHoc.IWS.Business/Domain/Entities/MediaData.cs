﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Entities
{
    public partial class MediaData
    {
        public int MediaId { get; set; }
        public byte[] Data { get; set; }
        public string HashCode { get; set; }

        //public virtual Media Media { get; set; }
    }
}
