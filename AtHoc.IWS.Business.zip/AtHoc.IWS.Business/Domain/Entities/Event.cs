using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web.Script.Serialization;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;
using AtHoc.d911;
using AtHoc.d911.Model.Organization;
using AtHoc.Diagnostics;
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Domain.Entities.IncomingAlert.CustomData;
using AtHoc.IWS.Business.Domain.Event.Impl;
using Newtonsoft.Json;

namespace AtHoc.IWS.Business.Domain.Entities
{
    /// <summary>
    /// VW_EVT_EVENT view entity
    /// </summary>
    public partial class Event
    {
        public Event()
        {
            this.EventDescriptions = new List<EventDescription>();
            this.EventMedia = new List<EventMedia>();
        }

        public int EventId { get; set; }
        public int? EventCategoryId { get; set; }
        public string LogicalId { get; set; }
        public double? Latitude { get; set; }
        public double? Longitude { get; set; }
        public DateTime? EventTime { get; set; }
        public string MsgTitle { get; set; }
        public string MsgBody { get; set; }
        public int? UserId { get; set; }
        public string EventData { get; set; }
        public string EventType { get; set; }
        public string EventCategoryName { get; set; }
        public int? Priority { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime UpdatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public string Status { get; set; }
        public string IsMobileAccessible { get; set; }
        public int VisibilityLevel { get; set; }
        public int? IncidentId { get; set; }
        public ICollection<EventDescription> EventDescriptions { get; set; }
        public ICollection<EventMedia> EventMedia { get; set; }
        public EventCategory EventCategory { get; set; }

        public int ProviderId { get; set; }

        public string IsEditable { get; set; }
        public int? ReviewedBy { get; set; }
        public DateTime? ReviewedOn { get; set; }
        public DateTime? EventStart { get; set; }

        public DateTime? EventEnd { get; set; }

        public string IsResponded { get; set; }

        public string SourceType { get; set; }
        public string SourceName { get; set; }

        public string SourceId { get; set; }
        public string GeoJson { get; set; }
        
        public ActionPerformed ? ActionPerformed { get; set; }
        public string EventCategoryType { get; set; }

        public long ConnectInvitationId
        {
            get { return GetConnectInvitationId(); }
        }
        private long GetConnectInvitationId()
        {
            var customDataDictionary = GetCustomData();
            if (customDataDictionary == null) return 0;
            string val;
            if (!customDataDictionary.TryGetValue(OrganizationEventCustomAttrIds.ConnectInvitationId, out val)) return 0;
            long result;
            return long.TryParse(val, out result) ? result : 0;
        }

        public String GetCustomDataValue(OrganizationEventCustomAttrIds key)
        {
            string value;
            if (GetCustomData().TryGetValue(key, out value))
            {
                return value;
            }
            return null;
        }

        public void SetCustomDataValue(OrganizationEventCustomAttrIds key, string newValue)
        {
            string value;
            var customData = GetCustomData();
            if (customData.TryGetValue(key, out value))
            {
                customData.Set(key, newValue);
            }
            else
            {
                customData.Add(key, newValue);   
            }
            SetCustomData(customData);
        }

        public Dictionary<OrganizationEventCustomAttrIds, string> GetCustomData()
        {
            if (string.IsNullOrEmpty(EventData)) return null;
            var serializer = new XmlSerializer(typeof(Entity));
            var customData = (Entity)serializer.Deserialize(new StringReader(EventData));
            var values = new Dictionary<OrganizationEventCustomAttrIds, string>();
                        
            customData.Attributes.AttributeValue.ForEach(a=>
            {
                try
                {
                    OrganizationEventCustomAttrIds id =
                        EnumUtils<OrganizationEventCustomAttrIds>.GetValueByDescription(a.CommonName);
                    values.Add(id, a.Value);    
                }
                catch
                {
                    
                }                
            });
            return values;                  
        }
        /*Example of additional data xml
         * <Entity xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
          <Attributes>
            <AttributeValue>
              <CommonName>sender</CommonName>
              <Id>1002</Id>
              <Type>2</Type>
              <UpdatedOn>0001-01-01T00:00:00-08:00</UpdatedOn>
              <Value xsi:type="xsd:string">BasicDEVORG</Value>
            </AttributeValue>
            <AttributeValue>
              <CommonName>sourceOrganizationName</CommonName>
              <Id>1003</Id>
              <Type>2</Type>
              <UpdatedOn>0001-01-01T00:00:00-08:00</UpdatedOn>
              <Value xsi:type="xsd:string">BasicDEVORG</Value>
            </AttributeValue>
            <AttributeValue>
              <CommonName>connectInvitationId</CommonName>
              <Id>1010</Id>
              <Type>2</Type>
              <UpdatedOn>0001-01-01T00:00:00-08:00</UpdatedOn>
              <Value xsi:type="xsd:int">0</Value>
            </AttributeValue>
            <AttributeValue>
              <CommonName>isSend</CommonName>
              <Id>1011</Id>
              <Type>2</Type>
              <UpdatedOn>0001-01-01T00:00:00-08:00</UpdatedOn>
              <Value xsi:type="xsd:boolean">true</Value>
            </AttributeValue>
            <AttributeValue>
              <CommonName>isReceive</CommonName>
              <Id>1012</Id>
              <Type>2</Type>
              <UpdatedOn>0001-01-01T00:00:00-08:00</UpdatedOn>
              <Value xsi:type="xsd:boolean">true</Value>
            </AttributeValue>
            <AttributeValue>
              <CommonName>targetOrganizationName</CommonName>
              <Id>1014</Id>
              <Type>2</Type>
              <UpdatedOn>0001-01-01T00:00:00-08:00</UpdatedOn>
              <Value xsi:type="xsd:string">sandy1</Value>
            </AttributeValue>
            <AttributeValue>
              <CommonName>targetOrganizationGuid</CommonName>
              <Id>1013</Id>
              <Type>2</Type>
              <UpdatedOn>0001-01-01T00:00:00-08:00</UpdatedOn>
              <Value xsi:type="xsd:string">17c771c2-dad0-464f-9333-aed698f9a8b0</Value>
            </AttributeValue>
          </Attributes>
          <Name>Entity</Name>
          <EntityType>0</EntityType>
          <EntityDefinitionId>0</EntityDefinitionId>
          <Id>0</Id>
          <ContextId>0</ContextId>
        </Entity>*/
        public void SetCustomData(Dictionary<OrganizationEventCustomAttrIds, string> attributes)
        {
            if (attributes == null)
            {
                attributes = new Dictionary<OrganizationEventCustomAttrIds, string>();
            }                

            IncomingAlert.CustomData.Entity entity = new IncomingAlert.CustomData.Entity()
            {

            };
            entity.Attributes = new Attributes();
            entity.Attributes.AttributeValue = new List<IncomingAlert.CustomData.AttributeValue>();

            int i = 1000;
            foreach (var attribute in attributes)
            {
                var attr = new IncomingAlert.CustomData.AttributeValue()
                {
                    CommonName = attribute.Key.Description(),
                    Id = ((int)attribute.Key).ToString(),
                    Value = attribute.Value,
                    Type = "2" // for some reason all existing XMLs has type 2... 
                };
                entity.Attributes.AttributeValue.Add(attr);
            }

            string eventDataStr = null;
            using (StringWriter textWriter = new StringWriter())
            {
                XmlSerializer serializer = new XmlSerializer(typeof(Entity));
                serializer.Serialize(textWriter, entity);
                eventDataStr = textWriter.ToString();
            }
            if (string.IsNullOrEmpty(eventDataStr))
            {
                EventLogger.WriteError("failed to serialze event data");
                return;
            }
            EventData = eventDataStr;
        }
    }

    public enum ActionPerformed
    {
        ActionNotRequired = 1,
        ConnectRequestActionRequired = 2,
        Accepted = 3,
        Declined = 4,
        Cancelled = 5,
        Disconnected = 6,
        Unknown = 7
    }
    /// <summary>
    /// Event table Entity in Database
    /// </summary>
    public partial class EventEntity
    {
        public EventEntity()
        {
            this.EventDescriptions = new List<EventDescription>();
            this.EventMedia = new List<EventMedia>();
        }

        public int EventId { get; set; }
        public int? EventCategoryId { get; set; }
        public string LogicalId { get; set; }
        public double? Latitude { get; set; }
        public double? Longitude { get; set; }
        public DateTime? EventTime { get; set; }
        public string MsgTitle { get; set; }
        public string MsgBody { get; set; }
        public int? UserId { get; set; }
        public string EventData { get; set; }
        public string EventType { get; set; }
        public int? Priority { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime UpdatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public string Status { get; set; }
        public string IsMobileAccessible { get; set; }
        public int VisibilityLevel { get; set; }
        public int? IncidentId { get; set; }
        public string GeoJson { get; set; }
        public ICollection<EventDescription> EventDescriptions { get; set; }
        public ICollection<EventMedia> EventMedia { get; set; }
        public EventCategory EventCategory { get; set; }

        public bool? IsEditable { get; set; }
        public int? ReviewedBy { get; set; }
        public DateTime? ReviewedOn { get; set; }
        public DateTime? EventStart { get; set; }

        public DateTime? EventEnd { get; set; }

        public string IsResponded { get; set; }

        public string SourceType { get; set; }
        public string SourceName { get; set; }

        public string SourceId { get; set; }
        public int? AutoTriggeredAlertId { get; set; }
        public string IsSystem { get; set; }
        public string SupportsResponseToSender { get; set; }

        
        public ActionPerformed? ActionPerformed { get; set; }
        public List<EventResponseOption> ResponseOptions
        {
            get { return GetResponseOption(); }

        }

        public dynamic DeliveryContextInfo
        {
            get { return GetDeliveryContext(); }
        }

        private List<EventResponseOption> GetResponseOption()
        {
            var resOptions = GetEventDataValue(OrganizationEventCustomAttrIds.ResponseOptions.Description());

            if (!string.IsNullOrEmpty(resOptions))
            {
                return GetEventResponseOptions(resOptions);
            }

            return new List<EventResponseOption>();

        }

        /// <summary>
        /// Get JSON of response option values
        /// </summary>
        /// <param name="jsonString"></param>
        /// <returns></returns>
        private static List<EventResponseOption> GetEventResponseOptions(string jsonString)
        {
            var jsonSerializer = new JavaScriptSerializer();
            var evtResponseOptions = jsonSerializer.Deserialize<IEnumerable<EventResponseOption>>(jsonString).ToList();
            return evtResponseOptions;
        }

        private dynamic GetDeliveryContext()
        {

            var deliveryContextInfoAttr =
                GetEventDataValue(OrganizationEventCustomAttrIds.DeliveryContextInfo.Description());
            return JsonConvert.DeserializeObject<dynamic>((deliveryContextInfoAttr));
        }

        private string GetEventDataValue(string key)
        {
            var xmlDoc1 = new XmlDocument();
            xmlDoc1.LoadXml(EventData);
            var root = XElement.Parse(EventData);
            var matchingNode =
                root.Descendants()
                    .Where(
                        i =>
                            i.Name == "CommonName" &&
                            String.Equals(i.Value, key, StringComparison.InvariantCultureIgnoreCase))
                    .Select(i => i.Parent);
            var responseValue = matchingNode.Descendants().Where(i => i.Name == "Value").FirstOrDefault();
            if (responseValue != null && !string.IsNullOrEmpty(responseValue.Value))
            {
                return responseValue.Value;
            }
            else
            {
                return string.Empty;
            }
        }
    }

    public class AlertResponseEntity
    {
        public int AlertId { get; set; }
        public int ProviderId { get; set; }
        public int EventId { get; set; }
        public int RespondedBy { get; set; }
        public string RespondedByDisplayName { get; set; }
        public string ResponseText { get; set; }
        public DateTime RespondedOn { get; set; }
    }

}

namespace AtHoc.IWS.Business.Domain.Entities.IncomingAlert.CustomData
{

[XmlRoot(ElementName = "Value")]
    public class Value
    {
     [XmlIgnore()]
    [XmlAttribute(AttributeName = "type", Namespace = "http://www.w3.org/2001/XMLSchema-instance")]
    public string Type { get; set; }
     [XmlIgnore()]   
    [XmlText]
        public string Text { get; set; }
    }

    [XmlRoot(ElementName = "AttributeValue")]
    public class AttributeValue
    {
        [XmlElement(ElementName = "CommonName")]
        public string CommonName { get; set; }
        [XmlElement(ElementName = "Id")]
        public string Id { get; set; }
        [XmlElement(ElementName = "Type")]
        public string Type { get; set; }
        [XmlElement(ElementName = "UpdatedOn")]
        public string UpdatedOn { get; set; }
        [XmlElement(ElementName = "Value")]
        public string Value { get; set; }
    }

    [XmlRoot(ElementName = "Attributes")]
    public class Attributes
    {
        [XmlElement(ElementName = "AttributeValue")]
        public List<AttributeValue> AttributeValue { get; set; }
    }

    [XmlRoot(ElementName = "Entity")]
    public class Entity
    {
        public Entity()
        {
            // match default values as the one from D911 entity:
            ContextId = "0";
            EntityDefinitionId = "0";
            Id = "0";
            EntityType = "0";
            Name = "Entity";
        }
        [XmlElement(ElementName = "Attributes")]
        public Attributes Attributes { get; set; }
        [XmlElement(ElementName = "Name")]
        public string Name { get; set; }
        [XmlElement(ElementName = "EntityType")]
        public string EntityType { get; set; }
        [XmlElement(ElementName = "EntityDefinitionId")]
        public string EntityDefinitionId { get; set; }
        [XmlElement(ElementName = "Id")]
        public string Id { get; set; }
        [XmlElement(ElementName = "ContextId")]
        public string ContextId { get; set; }
        [XmlIgnore()]
        [XmlAttribute(AttributeName = "xsi", Namespace = "http://www.w3.org/2000/xmlns/")]
        public string Xsi { get; set; }

         [XmlIgnore()]
        [XmlAttribute(AttributeName = "xsd", Namespace = "http://www.w3.org/2000/xmlns/")]
        public string Xsd { get; set; }
    }

}
