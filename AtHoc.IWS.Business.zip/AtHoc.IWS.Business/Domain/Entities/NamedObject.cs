﻿namespace AtHoc.IWS.Business.Domain
{
	public interface INamedObject
	{
		string Name { get; set; }
	}

	public interface ICommonName
	{
		string CommonName { get; set; }
	}

	public class NamedObject : INamedObject
	{
		public string Name { get; set; }
	}
}
