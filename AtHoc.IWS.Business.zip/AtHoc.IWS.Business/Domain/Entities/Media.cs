﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.d911.Common.Model;
using System.ComponentModel.DataAnnotations.Schema;
using AtHoc.IWS.Business.Domain.Event;

namespace AtHoc.IWS.Business.Domain.Entities
{
    public partial class Media
    {
        public int MediaId { get; set; }
        public Guid MediaGuid { get; set; }
        public string Status { get; set; }
        public string MediaGroup { get; set; }
        public string ContentType { get; set; }
        public string ContentEncoding { get; set; }
        public string FileName { get; set; }
        public string Extension { get; set; }
        public string Description { get; set; }
        public int Height { get; set; }
        public int Width { get; set; }
        public bool AllowWebAccess { get; set; }
        public string Source { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime UpdatedOn { get; set; }
        public int CreatedBy { get; set; }
        public int UpdatedBy { get; set; }
        public int ConvertTo { get; set; }
        public int Rotation { get; set; }

        [NotMapped]
        public int TargetId { get; set; } //Media can be targeted by Event/Shape/Incident
        [NotMapped]
        public Guid ParentMediaGuid { get; set; }

        [NotMapped]
        public MediaContentType AdditionalContentType { get; set; }

        /// <summary>
        /// Media content's checksum.
        /// </summary>
        [NotMapped]
        public string Checksum { get; set; }

        //public ICollection<MediaData> MediaDatas { get; set; }
       //public ICollection<MediaThumbnail> MediaThumbnails { get; set; }
    }
}
