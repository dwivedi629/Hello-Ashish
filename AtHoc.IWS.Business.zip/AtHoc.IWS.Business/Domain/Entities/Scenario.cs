﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Entities
{
    public class Scenario
    {
        private DateTime? publishedDate;
        private DateTime? nextReccurence;
        public int ScenarioId { get; set; }
        public string CommonName { get; set; }
        public string ChannelName {get;set;}
        public string Name { get; set; }
        public string DateTimeFormat {get;set;}
        public string UpdatedBy { get; set; }
        public string Description { get; set; }
        public string AlertTitle { get; set; }
        public string AlertBody { get; set; }
        public bool IsChecked { get; set; }
        public bool Enabled { get; set; }
        public bool IsDefaultforNewAlert { get; set; }
        public bool IsDefaultforNewScenario { get; set; }
        public bool IsRecurringScenario { get; set; }        
        public bool IsQuickPublish { get; set; }
        public bool IsReadyForPublish { get; set; }
        public bool IsSystem { get; set; }


        public DateTime? NextRecurrence
        {
            get
            {
                return nextReccurence == DateTime.MinValue ? null : nextReccurence;
            }
            set
            {
                nextReccurence = value;
            }
        }
        public DateTime? PublishedOn
        {
            get
            {
                return publishedDate == DateTime.MinValue ? null : publishedDate;
            }
            set
            {
                publishedDate = value;
            }
        }

        public string NextRecurrenceString { get; set; }
        public string PublishedOnString { get; set; }
    }
}
