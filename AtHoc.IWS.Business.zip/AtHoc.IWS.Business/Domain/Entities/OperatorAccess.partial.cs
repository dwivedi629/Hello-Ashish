﻿using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using System.ComponentModel.DataAnnotations;

namespace AtHoc.IWS.Business.Domain.Entities
{
    public partial class OperatorAccess
    {
        [MetaProperty(IsPersistable = false)]
        public OperatorAccessExtendedParams ExtendedParams
        {
            get { return this.Get<OperatorAccessExtendedParams>("ExtendedParams"); }
            set { this.Set<OperatorAccessExtendedParams>("ExtendedParams", value); }
        }

        public string ObjectCommonName { get; set; }
        public string RoleCommonName { get; set; }
    }

    public class OperatorAccessExtendedParams : EntityBase
    {
        [MetaProperty(ColumnName = "PROVIDER_FILTER", DbTypeName = "int", IsPersistable = false)]
        [Required]
        public virtual int ProviderId
        {
            get { return this.Get<int>("ProviderId"); }
            set { this.Set<int>("ProviderId", value); }
        }

        [MetaProperty(ColumnName = "USER_ID", DbTypeName = "int", IsPersistable = false)]
        [Required]
        public virtual int UserId
        {
            get { return this.Get<int>("UserId"); }
            set { this.Set<int>("UserId", value); }
        }
    }
}
