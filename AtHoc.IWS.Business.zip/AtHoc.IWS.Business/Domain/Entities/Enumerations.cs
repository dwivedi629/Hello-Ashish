﻿using System.ComponentModel;

namespace AtHoc.IWS.Business.Domain.Entities
{
    public enum ActionType
    {
        View = 1,

        Modify = 2,

        Publish = 3
    }

    public enum UserStatusType
    {
        [Description("ACT")]
        Active,

        [Description("VLD")]
        Enabled,

        [Description("DSB")]
        Disabled,

        [Description("DEL")]
        Deleted,

        [Description("LCK")]
        Locked
    }

    public enum CustomViewType
    {
        [Description("USER MANAGER")]
        UserManager,

        [Description("USER REPORT")]
        UserReport,

        [Description("USER MANAGER V2")]
        UserManagerV2
    }

    public enum CustomViewColumnType
    {
        [Description("CUSTOMFIELD")]
        CustomField,

        [Description("DEVICE")]
        Device,

        [Description("USER_ID")]
        UserId,

        [Description("ORG_NAME")]
        OrgName,

        [Description("ROLE")]
        Role
    }

    public enum ListItemType
    {
        [Description("DYNAMIC")]
        Dynamic,

        [Description("STATIC")]
        Static,

        [Description("IP")]
        Ip,

        [Description("TREE")]
        Tree
    }

    public enum ListStatus
    {
        [Description("ACT")]
        Enabled,

        [Description("DSB")]
        Disabled
    }

    public enum SystemObject
    {
        Services = 1,
        VirtualSystemAdministrator = 3,
        CatalogBuilder = 4,
        ToolbarBuilder = 5,
        DynamicFeed = 6,
        Alert = 7,
        LiveUpdate = 8,
        Report = 9,
        //VirtualSystem = 10,
        //SystemSetup = 11,
        Operators = 12,
        AlertPublisher = 13,
        //VirtualSystemsManager = 14,
        //AdministrationSetup = 16,
        SDK = 20,
        EnterpriseAdmin = 21,
        //Agents = 22,
        //Devices = 24,
        DeliveryTemplates = 25,
        Digest = 27,
        ScenarioManager = 28,
        ScenarioPublisher = 29,
        AdvancedAlertManager = 30,
        ReferenceManuals = 31,
        AudioFiles = 32,
        EndUsers = 33,
        AlertChannelManager = 34,
        ImportExportUsers = 37,
        SecurityPolicy = 38,
        CustomAttributes = 39,
        ReportsSystemLog = 40,
        ReportsUsageSummary = 66,
        ReportsEndUserSummary = 67,
        DistributionLists = 41,
        DataIntegration = 45,
        ReportsPersonnel = 46,
        ReportsDeviceCoverage = 47,
        SystemTasks = 48,
        DeleteEndUser = 49,
        DataArchiving = 50,
        EmailPublish = 51,
        ExportData = 52,

        SystemSetup = 53,
        SystemServerSettings = 54,
        SystemVirtualSystems = 55,
        SystemDesktopClientFailover = 56,
        VirtualSystemSetup = 57,
        VirtualSystemConfiguration = 58,
        VirtualSystemDeliveryProtocols = 60,
        VirtualSystemDevices = 59,
        VirtualSystemAgents = 61,
        VirtualSystemAdvancedSettings = 62,

        GlobalSystemHealth = 68,
        VirtualSystemHealth = 69,
        CustomDictionary = 70,
        EventsConfiguration = 72,
        AutoDeleteUsers = 73,

        EventLog = 75,
        TestAlert = 76,
        DeviceAdministration = 77,
        SSAMap = 78,
        SSATeam = 79,
        SSAAllTeams = 80,
        SSASEtup = 81,

        IntegrationModule = 82,

        Incident = 83,
        //EventManager = 84,
        Organization = 85,
        EventManager = 86,
        EventPublisher = 87,
        OrganizationSettings = 88,
        GeneralSettings = 89,
        // EventReplier = 90,
        EventReviewer = 91,
       GrantOperators = 92,
        InboundAlertRules = 93,
        ActivityLog = 94,
        AccountabilityEvent = 95,
        AccountabilityTemplate = 96,
        HierarchyDefination=97
    }

    public enum TargetingType
    {
        ORG
    }

    public enum HierarchyType
    {
        ORG,
        LOC
    }

    public enum HierarchySearchType
    {
         [Description("GRP")]
        TargetingGroupList = -1,

        [Description("ORG")]
        Organization = 0,

        [Description("LIST")]
        DistributionList = 1,

        [Description("LOC")]
        IpList = 2
    }

    public enum Roles
    {
        Administrator = 3,
        SDKUser = 11,
        AdvancedAlertPublisher = 13,
        DraftAlertCreator = 15,
        DistributionListsManager = 18,
        EndUsersManager = 19,
        EnterpriseAdmin = 21,
        ReportViewer = 23,
        DownloadExportFile = 25,
        SSAViewer = 28,
        SSAOperator = 29,
        AdvancedAlertManager = 30,
        SystemAdmin = 31,
        ConnectAgreementManager = 32,
        ConnectPublisher = 33,
        Operator = 34,
        Admin = 35,
        ActivityLogManager = 36,
        ActivityLogViewer = 37,
        AccountabilityManager = 38,
        AccountabilityOfficer=39
       
    }

    public enum UserDeleteStatus
    {
        DeleteUserWithPii = 0,
        DeleteUserWithoutPii = 1,
        DeleteUserFull = 2
    }

    [DefaultValue(NotSent)]
    public enum AlertDeliveryStatus
    {
        [Description("Error")]
        Error = -1,

        [Description("Not Sent")]
        NotSent = 0,

        [Description("Sent")]
        Sent = 1,

        [Description("Received")]
        Received = 2,

        [Description("Responded")]
        Acknowledged = 3
    }

    public enum ActivityFeedType
    {
        [Description("Alert")]
        Alert,

        [Description("Alert response")]
        AlertResponse
    }

    public enum DistributionListDependencyType
    {
        [Description("Alert Template")]
        AlertTemplate = 1,

        [Description("Alert")]
        Alert = 2,

        [Description("Distribution List")]
        DistributionList = 3,

        [Description("AtHoc Mobile Notifier")]
        Gateway = 4
    }

    public enum DistributionListNameVerificationMessage
    {
        NewDLNameMatchesExistingDLName,

        NewDLNameMatchesExistingDLCommonName,

        NewDLCommonNameMatchesExistingDLName,

        NewDLCommonNameMatchesExistingDLCommonName,

        NewDLNameMatchesExistingAttributeName,

        NewDLNameMatchesExistingAttributeCommonName,

        NewDLCommonNameMatchesExistingAttributeName,

        NewDLCommonNameMatchesExistingAttributeCommonName,

        DLNameAndDLCommonNameAreValid
    }

    public enum UserImportStatusType
    {
        [Description("INP")]
        InProgress = 1,

        [Description("NEW")]
        New = 2,

        [Description("ABT")]
        Aborted = 3,

        [Description("DON")]
        Done = 4,

        [Description("ERR")]
        Error = 5
    }

    public enum SheduledEventStatusType
    {
        [Description("IPC")]
        Inprogress,

        [Description("DON")]
        Done,

        [Description("ERR")]
        Error
    }

    public enum DistributionListStatusType
    {
        [Description("ACT")]
        Active,

        [Description("DSB")]
        Disabled,

        [Description("DEL")]
        Deleted
    }

    public enum ExportFormat
    {
        [Description("PDF")]
        Pdf,

        [Description("CSV")]
        Csv
    }

    public enum ServiceAction
    {
        #region Alert
        [Description("AMC00")]
        CreatedPublished,

        [Description("AMC02")]
        AlertActivated,

        [Description("AMC10")]
        CreatedStandby,

        [Description("AMC11")]
        CreatedScheduled,

        [Description("AMC12")]
        AlertPublished,

        [Description("AMC01")]
        PublishedFromQap,

        [Description("AMC21")]
        MovedtoUserArchive,

        [Description("AMC22")]
        MovedtoSystemArchive,

        //[Description("AMC21")]
        //AlertEnded,

        [Description("AMC90")]
        AlertDeleted,

        [Description("AMC20")]
        AlertUpdated,

        #endregion Alert

        #region Scenario
        [Description("SCN00")]
        ScenarioCreated,

        [Description("SCN90")]
        ScenarioDeleted,

        [Description("SCN20")]
        ScenarioUpdated,
        #endregion Scenario

        #region Audio
        [Description("AUD00")]
        AudioCreated,

        [Description("AUD90")]
        AudioDeleted,

        [Description("AUD20")]
        AudioUpdated,
        #endregion Audio

        #region Button
        [Description("BTN00")]
        ButtonCreated,

        [Description("BTN01")]
        ButtonDuplicated,

        [Description("BTN90")]
        ButtonDeleted,

        [Description("BTN20")]
        ButtonUpdated,
        #endregion Button

        #region DeliveryTemplate
        [Description("TPL00")]
        DeliveryTemplateCreated,

        [Description("TPL01")]
        DeliveryTemplateDuplicated,

        [Description("TPL20")]
        DeliveryTemplateUpdated,

        [Description("TPL90")]
        DeliveryTemplateDeleted,
        #endregion DeliveryTemplate

        #region Feed
        [Description("DUP00")]
        FeedPublished,
        #endregion Feed

        #region Gateway
        [Description("DGS20")]
        GatewayUpdated,
        #endregion Gateway

        #region User

        [Description("USR00")]
        UserCreated,

        [Description("USR10")]
        UserEnablingFailed,

        [Description("USR11")]
        UserDisablingFailed,

        [Description("USR24")]
        UserDeletionFailed,

        [Description("USR21")]
        UserDisabled,

        [Description("USR22")]
        UserEnabled,

        [Description("USR20")]
        UserUpdated,

        [Description("USR30")]
        UserExport,

        [Description("USR40")]
        UserImport,

        [Description("USR41")]
        UserCancelImport,

        [Description("USR42")]
        UserImportTimeout,

        [Description("USR50")]
        UserBatchDeleted,

        [Description("USR51")]
        UserBatchDisabled,

        [Description("USR52")]
        UserBatchEnabled,

        [Description("USR23")]
        EndUserDeleted,

        [Description("USR55")]
        UserStatusUpdated,
   
        [Description("USR42")]
        EndUsersMoved,

        [Description("USR12")]
        UserMovingFailed,


        #endregion User

        #region System
        [Description("CAT20")]
        SystemCatalogUpdated,

        [Description("PRV20")]
        SystemProviderUpdated,
        #endregion System

        #region Group
        [Description("GRS00")]
        GroupSetCreated,

        [Description("GRS20")]
        GroupSetUpdated,

        [Description("GRS90")]
        GroupSetDeleted,
        #endregion Group

        #region LiveUpdate
        [Description("LUA00")]
        LiveUpdateActivate,

        [Description("LUA22")]
        LiveUpdateAbort,

        [Description("LUA01")]
        LiveUpdateDuplicate,

        [Description("LUA20")]
        LiveUpdate,
        #endregion LiveUpdate

        #region Svc
        [Description("SRV10")]
        SvcDisabled,

        [Description("SRV00")]
        SvcCreated,

        [Description("SRV02")]
        SvcEnabled,

        [Description("SRV20")]
        SvcUpdated,

        [Description("SRV90")]
        SvcDeleted,
        #endregion Svc

        #region ToolBar
        [Description("TLB02")]
        ToolBarSaveAsDraft,

        [Description("TLB01")]
        ToolBarSaveAndUpdate,

        [Description("TLB00")]
        ToolBarPublish,
        #endregion ToolBar

        #region Operator
        [Description("OPR00")]
        OperatorCreated,

        [Description("OPR01")]
        OperatorEnabled,

        [Description("OPR02")]
        OperatorDisabled,

        [Description("OPR03")]
        OperatorLocked,

        [Description("OPR10")]
        OperatorCreationFailed,

        [Description("OPR20")]
        OperatorUpdated,

        [Description("OPR90")]
        OperatorDeleted,

        [Description("OPR22")]
        OperatorPermissionGranted,

        [Description("OPR23")]
        OperatorPermissionRevoked,

        [Description("OPR24")]
        OperatorPermissionUpdated,

        [Description("OPR25")]
        OperatorPermissionGrantingFailed,

        [Description("OPR26")]
        OperatorPermissionRevokeFailed,
        #endregion Operator

        #region AffiliateTerms
        [Description("OPR48")]
        AffTermsAccepted,

        [Description("OPR49")]
        AffTermsDeclined,

        #endregion AffiliateTerms

        #region Password
        [Description("OPR21")]
        PasswordChanged,

        [Description("OPR11")]
        PasswordChangeErrorPasswordIncorrect,

        [Description("OPR12")]
        PasswordChangeErrorPasswordInvalid,

        [Description("OPR13")]
        PasswordChangeErrorPasswordSimilarToUserName,

        [Description("OPR14")]
        PasswordChangeErrorPasswordUsedInThePast,

        [Description("OPR15")]
        PasswordChangeErrorNoMinimumTime,

        [Description("OPR16")]
        PasswordChangeErrorMinCharChange,

        [Description("OPR19")]
        PasswordChangeUnknownError,

        [Description("OPR31")]
        PasswordChangeAccountLocked,

        [Description("OPR32")]
        PasswordChangeAccountExpiredOrSuspended,

        [Description("OPR41")]
        ForgotUsernameEmailSent,

        [Description("OPR42")]
        ForgotPasswordEmailSent,

        [Description("OPR43")]
        PasswordRecoveryKeyValidated,

        [Description("OPR44")]
        PasswordRecoveryKeyExpired,

        [Description("OPR45")]
        PasswordRecoveryKeyNotFound,

        [Description("OPR46")]
        NoActiveUsersFoundForPasswordChange,

        [Description("OPR47")]
        ActiveUsersPageAccessedForPasswordChange,

        #endregion Password

        #region CustomAttribute
        [Description("CFM00")]
        CustomAttributeCreated,

        [Description("CFM20")]
        CustomAttributeUpdated,

        [Description("CFM90")]
        CustomAttributeDeleted,

        [Description("CFM25")]
        CustomAttributeCleared,

        [Description("CFM26")]
        CustomAttributeStringValueTruncated,

        [Description("CFM91")]
        CustomAttributeValueDeleted,
        #endregion CustomAttribute

        #region DistributionList
        [Description("DLM00")]
        DistributionListCreated,

        [Description("DLM01")]
        DistributionListDuplicated,

        [Description("DLM20")]
        DistributionListUpdated,

        [Description("DLM90")]
        DistributionListDeleted,

        [Description("DLM40")]
        DistributionListImported,

        #endregion DistributionList

        #region Login
        [Description("LOG00")]
        LoginSuccess,

        [Description("LOG01")]
        LoginSuccessPasswordExpired,

        [Description("LOG11")]
        LoginFailedWrongUsername,

        [Description("LOG12")]
        LoginFailedWrongPassword,

        [Description("LOG13")]
        LoginFailedSessionExpired,

        [Description("LOG14")]
        LoginFailedAccountLocked,

        [Description("LOG15")]
        LoginFailedAccountSuspended,

        [Description("LOG16")]
        LoginFailedAccountExpired,

        [Description("LOG17")]
        LoginFailedPasswordReset,

        [Description("LOG18")]
        LoginFailedPasswordExpired,

        [Description("LOG30")]
        LoginFailedNoSdkAccess,

        [Description("LOG19")]
        LoginFailedOtherReason,
        #endregion Login

        #region Logout
        [Description("LOG02")]
        LogoutSuccessful,

        [Description("LOG03")]
        LogoutTimedOut,

        [Description("LOG04")]
        LogoutMaxSessionLimit,
        #endregion Logout

        #region Agent
        [Description("AGT00")]
        AgentCreated,

        [Description("AGT01")]
        AgentDuplicated,

        [Description("AGT20")]
        AgentUpdated,

        [Description("AGT90")]
        AgentDeleted,
        #endregion Agent

        #region Device
        [Description("DVC02")]
        DeviceEnabled,

        [Description("DVC10")]
        DeviceDisabled,

        [Description("DVC20")]
        DeviceUpdated,
        #endregion Device

        #region Vps
        [Description("PRV00")]
        VpsEnter,

        [Description("PRV01")]
        VpsExit,
        #endregion Vps

        #region CascadingVps
        [Description("SVP00")]
        CascadingVpsCreated,

        [Description("SVP20")]
        CascadingVpsUpdated,

        [Description("SVP90")]
        CascadingVpsRemoved,
        #endregion

        #region DbArchival
        [Description("ARV00")]
        DbArchivalStarted,

        [Description("ARV01")]
        DbArchivalArchived,
        #endregion

        #region Monitor
        [Description("MTR00")]
        MonitorCreated,

        [Description("MTR20")]
        MonitorUpdated,

        [Description("MTR90")]
        MonitorDeleted,
        #endregion

        #region PlaceHolder
        [Description("PLH01")]
        PlaceHolderCreated,

        [Description("PLH02")]
        PlaceHolderUpdated,

        [Description("PLH03")]
        PlaceHolderDeleted,
        #endregion

        #region Map
        [Description("MAP01")]
        MapSetupUpdated,

        [Description("MAP11")]
        MapShapeCreated,

        [Description("MAP12")]
        MapShapeUpdated,

        [Description("MAP13")]
        MapShapeDeleted,
        #endregion

        #region System
        [Description("SYS01")]
        SystemSetupUpdated,

        #endregion System

        #region SecurityPolicy

        [Description("SPL01")]
        SecurityPolicyUpdated,
        [Description("SPL02")]
        SecurityPolicyInserted,
        [Description("SPL03")]
        SecurityPolicyDeleted,
        [Description("SPL04")]
        SecurityPolicyEnforcePasswordUpdated,
        #endregion SecurityPolicy

        #region Ssa
        [Description("SSA00")]
        SsaSsaSetupUpdated,

        [Description("SSA01")]
        SsaActivityLogCreated,

        [Description("SSA02")]
        SsaActivityLogClosed,
        #endregion

        #region Event
        [Description("EVT01")]
        EventMarkAsReviewed,

        [Description("EVT02")]
        EventMarkAsUnReviewed,

        [Description("EVT03")]
        EventReply,

        [Description("EVT04")]
        EventSendAlert,

        [Description("EVT05")]
        EventDesciptionCreate,
        #endregion

        #region Organization
        [Description("ORG00")]
        OrgInvite,
        [Description("ORG01")]
        OrgInviteFail,

        [Description("ORG10")]
        OrgInviteAccept,
        [Description("ORG11")]
        OrgInviteAcceptFail,

        [Description("ORG12")]
        OrgInviteCancel,
        [Description("ORG13")]
        OrgInviteCancelFail,

        [Description("ORG14")]
        OrgInviteDecline,
        [Description("ORG15")]
        OrgInviteDeclineFail,

        [Description("ORG20")]
        OrgVisibilityChange,
        [Description("ORG21")]
        OrgVisibilityChangeFail,
        [Description("ORG22")]
        OrgInviteNewOrg,
        [Description("ORG23")]
        OrgInviteNewOrgFail,
        #endregion

        #region UserTargetingSettings

        [Description("UTS00")]
        UpdatedTargetingSettings,

        #endregion

        #region GeneralSettings

        [Description("GLS00")]
        UpdatedGeneralSettings,

        #endregion

        #region Self Service

        [Description("SLF10")]
        SelfServiceRegistrationSuccessful,

        [Description("SLF20")]
        SelfServiceUsernameRequested,

        [Description("SLF21")]
        SelfServiceForgotUsernameEmailSent,

        [Description("SLF30")]
        SelfServicePasswordChangeRequested,

        [Description("SLF31")]
        SelfServiceForgotPasswordEmailSent,

        [Description("SLF32")]
        SelfServicePasswordChangeSuccessful,

        [Description("SLF33")]
        SelfServicePasswordChangeFailed,

        #endregion

        #region Organizational Hierarchy


        [Description("HOH01")]
        OrganizationalHierarchyCreated,

        [Description("HOH02")]
        OrganizationalHierarchyUpdated,

        [Description("HOH03")]
        OrganizationalHierarchyDeleted,

        #endregion Organizational Hierarchy

        #region DistributionList Hierarchy

        [Description("HDL01")]
        DistributionListHierarchyCreated,

        [Description("HDL02")]
        DistributionListHierarchyUpdated,

        [Description("HDL03")]
        DistributionListHierarchyDeleted,
        #endregion DistributionList Hierarchy

        #region Location Hierarchy

        [Description("HLO01")]
        LocationHierarchyCreated,

        [Description("HLO02")]
        LocationHierarchyUpdated,

        [Description("HLO03")]
        LocationHierarchyDeleted,
        #endregion Location Hierarchy

        #region Incoming Alert Rule

        [Description("RUL01")]
        AlertRuleCreated,

        [Description("RUL02")]
        AlertRuleUpdated,

        [Description("RUL03")]
        AlertRuleDeleted,

        [Description("RUL04")]
        AlertRuleReOrdered,

        #endregion

        #region Organization Manager

        [Description("PRV10")]
        OrganizationCreated,

        [Description("PRV15")]
        OrganizationDuplicated,

        [Description("PRV20")]
        OrganizationDetailsUpdated,

        [Description("PRV90")]
        OrganizationDeleted,

        #endregion


        #region Auto Disable Delete
        [Description("ADD01")]
        AutoDisableDeleteUpdated,

        [Description("ADD02")]
        AutoDisableJobAction,

        [Description("ADD03")]
        AutoDeleteJobAction,
        #endregion

        #region AccountabilityTemplate Rule

        [Description("ACT01")]
        AccountabilityTemplateCreated,

        [Description("ACT02")]
        AccountabilityTemplateUpdated,

        [Description("ACT03")]
        AccountabilityTemplateDeleted,

        #endregion


        #region AccountabilityEvent Rule

        [Description("ACE01")]
        AccountabilityEventCreated,

        [Description("ACE02")]
        AccountabilityEventUpdated,

        [Description("ACE03")]
        AccountabilityEventDeleted,

        [Description("ACE04")]
        AccountabilityEventEnded,

        [Description("ACE05")]
        AccountabilityEventPublished,

        [Description("ACE06")]
        AccountabilityEventExported,

        #endregion
        #region Weather Alert Rule (WAM)

        [Description("WAM01")]
        WeatherRuleCreated,

        [Description("WAM02")]
        WeatherRuleDisabled,

        [Description("WAM03")]
        WeatherRuleEnabled,

        [Description("WAM04")]
        WeatherRuleDeleted,

        [Description("WAM05")]
        WeatherRuleUpdated,

        #endregion


    }

    public enum EntityType
    {
        [Description("AMC")]
        Alert,

        [Description("SCN")]
        Scenario,

        [Description("ARV")]
        DbArchive,

        [Description("PRV")]
        VirtualSystem,

        [Description("LOG")]
        LoginAttempt,

        [Description("MTR")]
        Monitor,

        [Description("DGS")]
        DeliveryGateway,

        [Description("USR")]
        EndUsers,

        [Description("SSA")]
        Ssa,

        [Description("MAP")]
        Map,

        [Description("PLH")]
        PlaceHoder,

        [Description("SYS")]
        System,

        [Description("OPR")]
        Operator,

        [Description("CFM")]
        CustomFieldManager,

        [Description("DLM")]
        DistributionListManager,

        [Description("SRV")]
        ServiceChannel,

        [Description("TPL")]
        DeliveryTemplate,

        [Description("AGT")]
        AgentEntity,

        [Description("AUD")]
        Audio,

        [Description("SVP")]
        SubProvider,

        [Description("EVT")]
        Event,

        [Description("SPL")]
        SecurityPolicy,

        [Description("ORG")]
        Organization,

        [Description("UTS")]
        UserTargetingSettings,

        [Description("GLS")]
        GeneralSettings,

        [Description("SLF")]
        SelfService,

        [Description("HOH")]
        OrganizationalHierarchy,

        [Description("HDL")]
        DistributionListHierarchy,

        [Description("HLO")]
        LocationHierarchy,
        [Description("RUL")]
        AlertRule,
        [Description("ADD")]
        AutoDisableDelete,

        [Description("ACT")]
        AccountabilityTemplate,

        [Description("ACE")]
        AccountabilityEvent,

        [Description("WAM")]
        WeatherAlertRule,
    }

    public enum AccessType
    {
        [Description("MGT")]
        Manage = 1,

        [Description("TRG")]
        Target = 2
    }

    /// <summary>
    /// To represent the template status .
    /// </summary>
    public enum AccountabilityTemplateStatus
    {
        [Description("ACT")]
        Active,

        [Description("DEL")]
        Deleted
    }

    public enum TargetingEntityType
    {
        [Description("HRCHY")]
        Hierarchy,

        [Description("LIST")]
        DistributionList,

        [Description("ATTRIBUTE")]
        Attribute
    }

    public enum PasswordState
    {
        ChangeRequired = 1,
        HasExpired = 2
    }

    public enum LoginIdUniquenessStatus
    {
        UserUsernameIsDuplicate = 1,
        OperatorUsernameIsDuplicate = 2,
        UserMappingIdIsDuplicate = 3,
        OperatorMappingIdIsDuplicate = 4
    }

    public enum OrgTypes
    {

        [Description("OrgType_Enterprise")]
        TPL_ENT,
        [Description("OrgType_SubOrganization")]
        TPL_SUB,
        [Description("OrgType_Basic")]
        TPL_BAS,
        [Description("OrgType_Unknown")]
        TPL_UNK
    }

    public enum AccountabilityEventAlertType
    {
        [Description("Start")]
        Start = 1,

        [Description("Reminder")]
        Reminder =2,

        [Description("Close")]
        Close = 3
    }
    public enum AccountabilityEventUserType
    {
        [Description("USR")]
        User = 1,

        [Description("OPR")]
        Operator = 2

        
    }
    public enum AccountabilityEventStatus
    {
        [Description("AccountabilityEventStatus_Publishing")]
        Publishing = 1,
        [Description("AccountabilityEventStatus_Live")]
        Live = 2,
        [Description("AccountabilityEventStatus_Ended")]
        Ended = 3,
        [Description("AccountabilityEventStatus_Deleted")]
        Deleted = 4
    }
    


    public enum AccountabilityEventPlaceHolders
    {
        [Description("AccountabilityName")]
        AccountabilityName = 1,
        [Description("AccountabilityDescription")]
        AccountabilityDescription = 2,
        [Description("AccountabilityStartTime")]
        AccountabilityStartTime = 3
    }

    public enum AccountabilityEventJobPickupType
    {
        [Description("RECOMPUTE")]
        Recompute =1,
        [Description("REMINDER")]
        Reminder =2,
        [Description("END")]
        End = 3,
        [Description("START")]
        Start = 4,
        [Description("STATUSATTRIBUTE")]
        StatusAttribute = 5,
        [Description("TRACKINGSUMMARY")]
        TrackingSummary = 6

    }
    public enum UserListType
    {
        [Description("AccountabilityList")]
        AccountabilityList = 1,
        [Description("EndUserManagerList")]
        EndUserManagerList = 2,
        [Description("IUTList")]
        IUTList = 3
    }

    public enum ScheduleType
    {
        [Description("Single")]
        Single = 1,
        [Description("Periodic")]
        Periodic = 2,
        [Description("Recurring")]
        Recurring = 3
    }

    public enum ScheduleEventStatus
    {
        [Description("NotStarted")]
        NotStarted = 1,
        [Description("InProgress")]
        InProgress = 2,
        [Description("Done")]
        Done = 3,
        [Description("Error")]
        Error = 4,
        [Description("Deleted")]
        Deleted = 5
    }

}
