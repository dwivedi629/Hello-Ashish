﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Entities
{
    /// <summary>
    /// Data schema returned from sproc 'GET_SNAPSHOT_TRACKING'
    /// </summary>
    public class SnapShotReportItemRaw
    {
        public int snapshot_count { get; set; }
        public DateTime last_update_datetime { get; set; }
    }

    public class SnapShotReportItem
    {
        public int Value { get; set; }
        public DateTime TimeStamp { get; set; }
        public string TimeStampFormatted { get; set; }
    }
}
