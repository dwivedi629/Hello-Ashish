﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Entities
{
    public class CustomAttributeLocale
    {

        public int AttributeId{ get; set; }
        
        public string LocaleCode {get;set;}

        public string AttributeName { get; set; }

        public string Description { get; set; }
 
		public  string HelpText{get;set;}
        		  
		public  int? UpdatedOn{get;set;}
        		
		public  int? UpdatedBy{get;set;}

    }
}
