﻿namespace AtHoc.IWS.Business.Domain
{

    public class DeviceGatewayEntity
    {
        public int ProviderId { get; set; }
        public int DeviceId { get; set; }
        public string GatewayId { get; set; }
        public int? DeliveryOrder { get; set; }
        public string GatewayConfig { get; set; }
    }

}
