﻿using System;
using System.ComponentModel.DataAnnotations;

using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;

namespace AtHoc.IWS.Business.Domain.Entities
{
	[MetadataType(typeof(LocalSystemMeta))]
	[MetaObject(TableName = "ATH_SYSINFO_VUE")]
	public class LocalSystem : EntityBase
	{
		[MetaProperty(ColumnName = "SYSTEM_TIME", DbTypeName = "datetime")]
		public virtual DateTime? SystemTime
		{
			get { return Get<DateTime?>("SystemTime"); }
			set { Set("SystemTime", value); }
		}

		[MetaProperty(ColumnName = "TIME_ZONE_REGION_ID", DbTypeName = "nvarchar", MaxLength = 50, AutoTrim = true)]
		[MaxLength(50)]
		public virtual string TimeZoneId
		{
			get { return Get<string>("TimeZoneId"); }
			set { Set("TimeZoneId", value); }
		}

		[MetaProperty(ColumnName = "URL", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
		public virtual string Url
		{
			get { return Get<string>("Url"); }
			set { Set("Url", value); }
		}

		#region Properties
		public class Meta
		{
			public static readonly MetaProperty SystemTime = MetaObject.Get(typeof(LocalSystem))["SystemTime"];
			public static readonly MetaProperty TimeZoneId = MetaObject.Get(typeof(LocalSystem))["TimeZoneId"];
			public static readonly MetaProperty Url = MetaObject.Get(typeof(LocalSystem))["Url"];
		}
		#endregion Properties
	}

	#region LocalSystemMeta
	public partial class LocalSystemMeta
	{
	}
	#endregion LocalSystemMeta
}
