﻿namespace AtHoc.IWS.Business.Domain.Entities
{
    public class CustomAttributeQueryOperator
    {
        public int Id { get; set; }
        public bool IsValueRequired { get; set; }
        public string CommonName { get; set; }
        public bool ShowAdvancedValueSelector { get; set; }
    }
}
