﻿using System.ComponentModel.DataAnnotations;

using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;

namespace AtHoc.IWS.Business.Domain.Entities
{
	[MetadataType(typeof (DistributionListItemMeta))]
	public class DistributionListDependency : EntityBase
	{
		[MetaProperty(ColumnName = "OBJECT_TYPE", DbTypeName = "int")]
		[Required]
		public virtual DistributionListDependencyType DependencyType
		{
			get { return Get<DistributionListDependencyType>("DependencyType"); }
			set { Set("DependencyType", value); }
		}

		[MetaProperty(ColumnName = "LIST_ID", DbTypeName = "int")]
		[Required]
		public virtual int ListId
		{
			get { return Get<int>("ListId"); }
			set { Set("ListId", value); }
		}

		[MetaProperty(ColumnName = "LIST_NAME", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
		public virtual string ListName
		{
			get { return Get<string>("ListName"); }
			set { Set("ListName", value); }
		}

		[MetaProperty(ColumnName = "DEPENDENT_ID", DbTypeName = "int")]
		[Required]
		public virtual int DependentId
		{
			get { return Get<int>("DependentId"); }
			set { Set("DependentId", value); }
		}

		[MetaProperty(ColumnName = "DEPENDENT_NAME", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string DependentName
		{
			get { return Get<string>("DependentName"); }
			set { Set("DependentName", value); }
		}

		#region Properties

		public class Meta
		{
			public static readonly MetaProperty DependencyType = MetaObject.Get(typeof(DistributionListDependency))["DependencyType"];
			public static readonly MetaProperty ListId = MetaObject.Get(typeof(DistributionListDependency))["ListId"];
			public static readonly MetaProperty ListName = MetaObject.Get(typeof(DistributionListDependency))["ListName"];
			public static readonly MetaProperty DependentId = MetaObject.Get(typeof(DistributionListDependency))["DependentId"];
			public static readonly MetaProperty DependentName = MetaObject.Get(typeof(DistributionListDependency))["DependentName"];
		}

		#endregion Properties
	}

	#region DistributionListDependencyMeta

	public class DistributionListDependencyMeta
	{
	}

	#endregion DistributionListDependencyMeta
}