﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Entities
{
    public class ScheduleJobDetail
    {
        public int Id { get; set; }
        public ScheduleType ScheduleType { get; set;  }
    }

    public class ScheduleJobStatus
    {
        public int Id { get; set; }
        public ScheduleType ScheduleType { get; set; }
        public SheduledEventStatusType? Status { get; set; }
    }
}
