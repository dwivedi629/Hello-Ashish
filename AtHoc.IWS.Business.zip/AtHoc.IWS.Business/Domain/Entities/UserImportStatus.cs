﻿using System;
using System.ComponentModel.DataAnnotations;

using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;

namespace AtHoc.IWS.Business.Domain.Entities
{
	[MetadataType(typeof(UserImportStatusMeta))]
	[MetaObject(TableName = "USR_IMPORT_STATUS_VUE")]
	public class UserImportStatus : EntityBase
	{
		[MetaProperty(ColumnName = "PROVIDER_ID", DbTypeName = "int")]
		public virtual int? ProviderId
		{
			get { return Get<int?>("ProviderId"); }
			set { Set("ProviderId", value); }
		}

		[MetaProperty(ColumnName = "JOB_ID", DbTypeName = "int")]
		public virtual int? JobId
		{
			get { return Get<int?>("JobId"); }
			set { Set("JobId", value); }
		}

		[MetaProperty(ColumnName = "STATUS", DbTypeName = "varchar", MaxLength = 3, AutoTrim = true)]
		[MaxLength(3)]
		public virtual UserImportStatusType? Status
		{
			get { return Get<UserImportStatusType>("Status"); }
			set { Set("Status", value); }
		}

		[MetaProperty(ColumnName = "UPLOAD_TIME", DbTypeName = "datetime")]
		public virtual DateTime UploadTime
		{
			get { return Get<DateTime>("UploadTime"); }
			set { Set("UploadTime", value); }
		}

		[MetaProperty(ColumnName = "START_TIME", DbTypeName = "datetime")]
		public virtual DateTime StartTime
		{
			get { return Get<DateTime>("StartTime"); }
			set { Set("StartTime", value); }
		}

		[MetaProperty(ColumnName = "END_TIME", DbTypeName = "datetime")]
		public virtual DateTime EndTime
		{
			get { return Get<DateTime>("EndTime"); }
			set { Set("EndTime", value); }
		}

		[MetaProperty(ColumnName = "UPLOAD_FILE_NAME", DbTypeName = "varchar")]
		public virtual string UploadFileName
		{
			get { return Get<string>("UploadFileName"); }
			set { Set("UploadFileName", value); }
		}

		[MetaProperty(ColumnName = "TOTAL_RECORDS", DbTypeName = "int")]
		public virtual int? TotalRecords
		{
			get { return Get<int?>("TotalRecords"); }
			set { Set("TotalRecords", value); }
		}

		[MetaProperty(ColumnName = "PROCESSED_RECORDS", DbTypeName = "int")]
		public virtual int? ProcessedRecords
		{
			get { return Get<int?>("ProcessedRecords"); }
			set { Set("ProcessedRecords", value); }
		}

		[MetaProperty(ColumnName = "SUCCESS_RECORDS", DbTypeName = "int")]
		public virtual int? SuccessRecords
		{
			get { return Get<int?>("SuccessRecords"); }
			set { Set("SuccessRecords", value); }
		}

		[MetaProperty(ColumnName = "FAILED_RECORDS", DbTypeName = "int")]
		public virtual int? FailedRecords
		{
			get { return Get<int?>("FailedRecords"); }
			set { Set("FailedRecords", value); }
		}

		[MetaProperty(ColumnName = "PARTIAL_RECORDS", DbTypeName = "int")]
		public virtual int? PartialRecords
		{
			get { return Get<int?>("PartialRecords"); }
			set { Set("PartialRecords", value); }
		}

		[MetaProperty(ColumnName = "TOTAl_REC_NUM", DbTypeName = "int")]
		public virtual int? TotalRecordsNumber
		{
			get { return Get<int?>("TotalRecordsNumber"); }
			set { Set("TotalRecordsNumber", value); }
		}

		[MetaProperty(ColumnName = "COMMENTS", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string Comments
		{
			get { return Get<string>("Comments"); }
			set { Set("Comments", value); }
		}

        [MetaProperty(ColumnName = "LAST_UPDATE_TIME", DbTypeName = "datetime")]
        public virtual DateTime? LastUpdateTime
        {
            get { return Get<DateTime?>("LastUpdateTime"); }
            set { Set("LastUpdateTime", value); }
        }

		#region Properties
		public class Meta
		{
			public static readonly MetaProperty ProviderId = MetaObject.Get(typeof(UserImportStatus))["ProviderId"];
			public static readonly MetaProperty JobId = MetaObject.Get(typeof(UserImportStatus))["JobId"];
			public static readonly MetaProperty Status = MetaObject.Get(typeof(UserImportStatus))["Status"];
			public static readonly MetaProperty UploadTime = MetaObject.Get(typeof(UserImportStatus))["UploadTime"];
			public static readonly MetaProperty StartTime = MetaObject.Get(typeof(UserImportStatus))["StartTime"];
			public static readonly MetaProperty EndTime = MetaObject.Get(typeof(UserImportStatus))["EndTime"];
			public static readonly MetaProperty UploadFileName = MetaObject.Get(typeof(UserImportStatus))["UploadFileName"];
			public static readonly MetaProperty TotalRecords = MetaObject.Get(typeof(UserImportStatus))["TotalRecords"];
			public static readonly MetaProperty ProcessedRecords = MetaObject.Get(typeof(UserImportStatus))["ProcessedRecords"];
			public static readonly MetaProperty SuccessRecords = MetaObject.Get(typeof(UserImportStatus))["SuccessRecords"];
			public static readonly MetaProperty FailedRecords = MetaObject.Get(typeof(UserImportStatus))["FailedRecords"];
			public static readonly MetaProperty PartialRecords = MetaObject.Get(typeof(UserImportStatus))["PartialRecords"];
			public static readonly MetaProperty TotalRecordsNumber = MetaObject.Get(typeof(UserImportStatus))["TotalRecordsNumber"];
			public static readonly MetaProperty Comments = MetaObject.Get(typeof(UserImportStatus))["Comments"];
            public static readonly MetaProperty LastUpdateTime = MetaObject.Get(typeof(UserImportStatus))["LastUpdateTime"];
		}
		#endregion Properties
	}

	#region ActivityFeedMeta
	public partial class UserImportStatusMeta
	{
	}
	#endregion ActivityFeedMeta
}
