﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Spatial;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Entities
{
    public interface IPoliticalArea
    {
        string Name { get; set; }
        string GeoId { get; set; }
        DbGeography Geography { get; set; }
   } 

    public class County : IPoliticalArea
    {
        public int Id { get; set; }
        public string StateFp { get; set; }
        public string CountyFp { get; set; }
        public string GeoId { get; set; }
        public string Name { get; set; }
        public DbGeography Geography { get; set; }
    }
}
