using AtHoc.Global.Resources.Entities;
using System;
using System.Collections.Generic;

namespace AtHoc.IWS.Business.Domain.Entities
{
    public partial class EventCategory
    {
        public EventCategory()
        {
            this.Events = new List<Event>();
        }

        public int EventCategoryId { get; set; }

        [LocalizationEntityProperty(BusinessEntity.EventCategory, "Name")]
        public string Name { get; set; }
        public string Description { get; set; }
        public string CategoryMessage { get; set; }        
        public string CommonName { get; set; }

        [LocalizationEntityIdAttribute(BusinessEntity.EventCategory)]
        public string LogicalId { get; set; }
        public int? Severity { get; set; }
        public string EventCategoryType { get; set; }
        public string IconName { get; set; }
        public string EventCategoryData { get; set; }
        public int? EditLevel { get; set; }

        public int? ProviderId { get; set; }
        public string ScenarioCommonName { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public string Status { get; set; }
        public int ScenarioId { get; set; }
        public string IsDefault { get; set; }
        public int? ImageId { get; set; }
        public ICollection<Event> Events { get; set; }

        public int? DefaultVisibility { get; set; }
        public int? DefaultPriority { get; set; }
        public int?  Availabillity { get; set; }
    }
}
