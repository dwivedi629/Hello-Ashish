﻿namespace AtHoc.IWS.Business.Domain.Entities
{
    public enum EntityType
    {
        /// <summary>
        /// Hierarchy
        /// </summary>
        HRCHY,
        /// <summary>
        /// DL
        /// </summary>
        LIST,
        /// <summary>
        /// custom attribute
        /// </summary>
        ATTRIBUTE,
    }
}
