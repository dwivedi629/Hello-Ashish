﻿using System.ComponentModel.DataAnnotations;

using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;

namespace AtHoc.IWS.Business.Domain.Entities
{
	[MetadataType(typeof(DistributionListFolderMeta))]
	[MetaObject(TableName = "PDL_LIST_FOLDER_TAB")]
	public class DistributionListFolder : EntityBase
	{
		[Required]
		[MetaProperty(ColumnName = "PARENT_LIST_ID", DbTypeName = "int")]
		public virtual int? ParentListId
		{
			get { return Get<int>("ParentListId"); }
			set { Set("ParentListId", value); }
		}

		[Required]
		[MetaProperty(ColumnName = "CHILD_LIST_ID", DbTypeName = "int")]
		public virtual int? ChildListId
		{
			get { return Get<int>("ChildListId"); }
			set { Set("ChildListId", value); }
		}

		[Required]
		[MetaProperty(ColumnName = "SORT_ORDER", DbTypeName = "int")]
		public virtual int? SortOrder
		{
			get { return Get<int>("SortOrder"); }
			set { Set("SortOrder", value); }
		}

		#region Properties
		public class Meta
		{
			public static readonly MetaProperty ParentListId = MetaObject.Get(typeof(DistributionListFolder))["ParentListId"];
			public static readonly MetaProperty ChildListId = MetaObject.Get(typeof(DistributionListFolder))["ChildListId"];
			public static readonly MetaProperty SortOrder = MetaObject.Get(typeof(DistributionListFolder))["SortOrder"];
		}
		#endregion Properties
	}

	#region DistributionListFolderMeta
	public partial class DistributionListFolderMeta
	{
	}
	#endregion DistributionListFolderMeta
}
