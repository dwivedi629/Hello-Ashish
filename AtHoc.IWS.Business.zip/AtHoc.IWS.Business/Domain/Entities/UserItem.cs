﻿using System.ComponentModel.DataAnnotations;

using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;

namespace AtHoc.IWS.Business.Domain.Entities
{
	public class UserItem : EntityBase
	{
		public UserItem()
		{
			this.UserDevice = new UserDevice();
			this.UserAttributes = new UserAttributes();
		}

		[MetaProperty(ColumnName = "USER_ID", DbTypeName = "int", IsKey = true)]
		[Required]
		public virtual int Id
		{
			get { return this.Get<int>("Id"); }
			set { this.Set<int>("Id", value); }
		}

		[MetaProperty(IsPersistable = true, ColumnName = "FIRST_NAME", DbTypeName = "nvarchar", AutoTrim = true)]
		public virtual string FirstName
		{
			get { return this.Get<string>("FirstName"); }
			set { this.Set<string>("FirstName", value); }
		}

		[MetaProperty(IsPersistable = true, ColumnName = "LAST_NAME", DbTypeName = "nvarchar", AutoTrim = true)]
		public virtual string LastName
		{
			get { return this.Get<string>("LastName"); }
			set { this.Set<string>("LastName", value); }
		}

		[MetaProperty(IsPersistable = true, ColumnName = "USERNAME", DbTypeName = "nvarchar", AutoTrim = true)]
		public virtual string UserName
		{
			get { return this.Get<string>("UserName"); }
			set { this.Set<string>("UserName", value); }
		}

		[MetaProperty(ColumnName = "DISPLAY_NAME", DbTypeName = "nvarchar", MaxLength = 150, AutoTrim = true)]
		[MaxLength(150)]
		public virtual string DisplayName
		{
			get { return this.Get<string>("DisplayName"); }
			set { this.Set<string>("DisplayName", value); }
		}

		[MetaProperty(IsPersistable = false)]
		public UserDevice UserDevice
		{
			get { return this.Get<UserDevice>("UserDevice"); }
			set { this.Set<UserDevice>("UserDevice", value); }
		}

		[MetaProperty(IsPersistable = false)]
		public UserAttributes UserAttributes
		{
			get { return this.Get<UserAttributes>("UserAttributes"); }
			set { this.Set("UserAttributes", value); }
		}

		#region Properties

		public class Meta
		{
			public static readonly MetaProperty Id = MetaObject.Get(typeof(UserItem))["Id"];
			public static readonly MetaProperty LastName = MetaObject.Get(typeof(UserItem))["LastName"];
			public static readonly MetaProperty FirstName = MetaObject.Get(typeof(UserItem))["FirstName"];
			public static readonly MetaProperty DisplayName = MetaObject.Get(typeof(UserItem))["DisplayName"];
			public static readonly MetaProperty UserName = MetaObject.Get(typeof(UserItem))["UserName"];
		}

		#endregion Properties
	}
}
