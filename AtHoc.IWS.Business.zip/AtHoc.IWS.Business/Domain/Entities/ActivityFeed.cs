﻿using System;
using System.ComponentModel.DataAnnotations;

using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain
{
	[MetadataType(typeof(ActivityFeedMeta))]
	[MetaObject(TableName = "USR_ACTIVITY_FEED_VUE")]
	public class ActivityFeed : EntityBase
	{
		[MetaProperty(ColumnName = "USER_ID", DbTypeName = "int")]
		public virtual int? UserId
		{
			get { return Get<int>("UserId"); }
			set { Set("UserId", value); }
		}

		[MetaProperty(ColumnName = "PROVIDER_ID", DbTypeName = "int")]
		public virtual int? ProviderId
		{
			get { return Get<int>("ProviderId"); }
			set { Set("ProviderId", value); }
		}

		[MetaProperty(ColumnName = "EVENT_ID", DbTypeName = "int")]
		public virtual int? EventId
		{
			get { return Get<int>("EventId"); }
			set { Set("EventId", value); }
		}

		[MetaProperty(ColumnName = "EVENT_TYPE", DbTypeName = "nvarchar", MaxLength = 14, AutoTrim = true)]
		public virtual string EventType
		{
			get { return Get<string>("EventType"); }
			set { Set("EventType", value); }
		}

		[MetaProperty(ColumnName = "BODY", DbTypeName = "nvarchar", MaxLength = 4000, AutoTrim = true)]
		[MaxLength(4000)]
		public virtual string Body
		{
			get { return Get<string>("Body"); }
			set { Set("Body", value); }
		}

		[MetaProperty(ColumnName = "TITLE", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string Title
		{
			get { return Get<string>("Title"); }
			set { Set("Title", value); }
		}

		[MetaProperty(ColumnName = "EVENT_TIME", DbTypeName = "datetime")]
		public virtual DateTime? EventTime
		{
			get { return Get<DateTime?>("EventTime"); }
			set { Set("EventTime", value); }
		}

		[MetaProperty(ColumnName = "RESPONSE_DATE", DbTypeName = "datetime")]
		public virtual DateTime? ResponseDate
		{
			get { return Get<DateTime?>("ResponseDate"); }
			set { Set("ResponseDate", value); }
		}

		[MetaProperty(ColumnName = "STATUS", DbTypeName = "nvarchar", MaxLength = 30, AutoTrim = true)]
		[MaxLength(30)]
		public virtual string Status
		{
			get { return Get<string>("Status"); }
			set { Set("Status", value); }
		}

		[MetaProperty(ColumnName = "PUBLISHER", DbTypeName = "nvarchar", MaxLength = 30, AutoTrim = true)]
		[MaxLength(30)]
		public virtual string Publisher
		{
			get { return Get<string>("Publisher"); } 
			set { Set("Publisher", value); }
		}

		[MetaProperty(ColumnName = "DELIVERY_STATUS", DbTypeName = "int")]
		public virtual AlertDeliveryStatus? DeliveryStatus
		{
			get { return Get<AlertDeliveryStatus?>("DeliveryStatus"); }
			set { Set("DeliveryStatus", value); }
		}

		[MetaProperty(ColumnName = "DEVICE_NAME", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
		public virtual string DeviceName
		{
			get { return Get<string>("DeviceName"); }
			set { Set("DeviceName", value); }
		}

		[MetaProperty(ColumnName = "DEVICE_ADDRESS", DbTypeName = "nvarchar", MaxLength = 2000, AutoTrim = true)]
		[MaxLength(2000)]
		public virtual string DeviceAddress
		{
			get { return Get<string>("DeviceAddress"); }
			set { Set("DeviceAddress", value); }
		}

		[MetaProperty(ColumnName = "DEVICE_COMMON_NAME", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
		public virtual string DeviceCommonName
		{
			get { return Get<string>("DeviceCommonName"); }
			set { Set("DeviceCommonName", value); }
		}

		[MetaProperty(ColumnName = "RESPONDED_TEXT", DbTypeName = "nvarchar", MaxLength = 400, AutoTrim = true)]
		[MaxLength(400)]
		public virtual string RespondedText
		{
			get { return Get<string>("RespondedText"); }
			set { Set("RespondedText", value); }
		}

		[MetaProperty(ColumnName = "NO_RESPONSE", DbTypeName = "int")]
		public virtual int? NoResponse
		{
			get { return Get<int>("NoResponse"); }
			set { Set("NoResponse", value); }
		}

		[MetaProperty(ColumnName = "SENT", DbTypeName = "int")]
		public virtual int? Sent
		{
			get { return Get<int>("Sent"); }
			set { Set("Sent", value); }
		}

		[MetaProperty(ColumnName = "IS_FIRST_RESPONDED", DbTypeName = "int")]
		public virtual int IsFirstResponded
		{
			get { return Get<int>("IsFirstResponded"); }
			set { Set("IsFirstResponded", value); }
		}

		[MetaProperty(ColumnName = "DELIVERY_STATE_CODE", DbTypeName = "nvarchar", MaxLength = 50, AutoTrim = true)]
		[MaxLength(50)]
		public virtual string DeliveryStateCode
		{
			get { return Get<string>("DeliveryStateCode"); }
			set { Set("DeliveryStateCode", value); }
		}

		[MetaProperty(ColumnName = "DELIVERY_STATE", DbTypeName = "nvarchar", MaxLength = 400, AutoTrim = true)]
		[MaxLength(400)]
		public virtual string DeliveryState
		{
			get { return Get<string>("DeliveryState"); }
			set { Set("DeliveryState", value); }
		}

        [MetaProperty(ColumnName="CONTENT_URL", DbTypeName="nvarchar")]
	    public virtual string MoreInfoUrl 
        { 
            get { return Get<string>("MoreInfoUrl"); }
            set { Set("MoreInfoUrl",value);}
        }
        [MetaProperty(ColumnName="Event_Category_Id")]
	    public virtual int? EventCategoryId {
            get { return Get<int>("EventCategoryId"); }
            set { Set("EventCategoryId",value);}
	    }

        [MetaProperty(ColumnName="Event_Category_Name")]
	    public virtual string EventCategoryName
	    {
	        get { return Get<string>("EventCategoryName"); }
	        set { Set("EventCategoryName",value);}
	    }

	    [MetaProperty(ColumnName = "Priority", DbTypeName = "int")]
	    public virtual int? Priority { 
            get { return Get<int>("Priority"); }
	        set { Set("Priority",value);}
	    }

	    [MetaProperty(ColumnName = "ENDED_ON", DbTypeName = "DateTime")]
	    public virtual DateTime? EndedOn
	    {
	        get { return Get<DateTime?>("EndedOn"); }
	        set { Set("EndedOn", value); }
	    }

        [MetaProperty(ColumnName="IMAGE_ID", DbTypeName="int")]
	    public virtual int? EventCategoryImageId
	    {
            get { return Get<int?>("EventCategoryImageId"); }
	        set { Set("EventCategoryImageId",value);}
	    }

        [MetaProperty(ColumnName="RESPONSE_OPTIONS",DbTypeName="xml")]
	    public virtual string ResponseOptionsXml
	    {
	        get { return Get<string>("ResponseOptionsXml"); }
            set { Set("ResponseOptionsXml",value);}
	    }

        [MetaProperty(ColumnName="GEO_JSON", DbTypeName="nvarchar")]
	    public virtual string GeoJson
	    {
	        get { return Get<string>("GeoJson"); }
	        set { Set("GeoJson",value);}
	    }

	    #region Properties
		public class Meta
		{
			public static readonly MetaProperty UserId = MetaObject.Get(typeof(ActivityFeed))["UserId"];
			public static readonly MetaProperty EventId = MetaObject.Get(typeof(ActivityFeed))["EventId"];
			public static readonly MetaProperty ProviderId = MetaObject.Get(typeof(ActivityFeed))["ProviderId"];
			public static readonly MetaProperty EventType = MetaObject.Get(typeof(ActivityFeed))["EventType"];
			public static readonly MetaProperty Title = MetaObject.Get(typeof(ActivityFeed))["Title"];
			public static readonly MetaProperty Body = MetaObject.Get(typeof(ActivityFeed))["Body"];
			public static readonly MetaProperty EventTime = MetaObject.Get(typeof(ActivityFeed))["EventTime"];
			public static readonly MetaProperty ResponseDate = MetaObject.Get(typeof(ActivityFeed))["ResponseDate"];
			public static readonly MetaProperty Status = MetaObject.Get(typeof(ActivityFeed))["Status"];
			public static readonly MetaProperty Publisher = MetaObject.Get(typeof(ActivityFeed))["Publisher"];
			public static readonly MetaProperty DeliveryStatus = MetaObject.Get(typeof(ActivityFeed))["DeliveryStatus"];
			public static readonly MetaProperty DeviceAddress = MetaObject.Get(typeof(ActivityFeed))["DeviceAddress"];
			public static readonly MetaProperty DeviceName = MetaObject.Get(typeof(ActivityFeed))["DeviceName"];
			public static readonly MetaProperty DeviceCommonName = MetaObject.Get(typeof(ActivityFeed))["DeviceCommonName"];
			public static readonly MetaProperty RespondedText = MetaObject.Get(typeof(ActivityFeed))["RespondedText"];
			public static readonly MetaProperty NoResponse = MetaObject.Get(typeof(ActivityFeed))["NoResponse"];
			public static readonly MetaProperty Sent = MetaObject.Get(typeof(ActivityFeed))["Sent"];
			public static readonly MetaProperty IsFirstResponded = MetaObject.Get(typeof(ActivityFeed))["IsFirstResponded"];
			public static readonly MetaProperty DeliveryStateCode = MetaObject.Get(typeof(ActivityFeed))["DeliveryStateCode"];
			public static readonly MetaProperty DeliveryState = MetaObject.Get(typeof(ActivityFeed))["DeliveryState"];
		    public static readonly MetaProperty EventCategoryId = MetaObject.Get(typeof (ActivityFeed))["EventCategoryId"];
		    public static readonly MetaProperty EndedOn = MetaObject.Get(typeof (ActivityFeed))["EndedOn"];
		    public static readonly MetaProperty MoreInfoUrl = MetaObject.Get(typeof (ActivityFeed))["MoreInfoUrl"];
		    public static readonly MetaProperty Priority = MetaObject.Get(typeof (ActivityFeed))["Priority"];
		    public static readonly MetaProperty EventCategoryName = MetaObject.Get(typeof (ActivityFeed))["EventCategoryName"];
		    public static readonly MetaProperty EventCategoryImageId = MetaObject.Get(typeof (ActivityFeed))["EventCategoryImageId"];
		    public static readonly MetaProperty ResponseOptionsXml = MetaObject.Get(typeof (ActivityFeed))["ResponseOptionsXml"];
		    public static readonly MetaProperty GeoJson = MetaObject.Get(typeof (ActivityFeed))["GeoJson"];            
		}
		#endregion Properties
	}

	#region ActivityFeedMeta
	public partial class ActivityFeedMeta
	{
	}
	#endregion ActivityFeedMeta
}
