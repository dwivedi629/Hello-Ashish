﻿namespace AtHoc.IWS.Business.Domain.Entities
{
    public class TargetableOrganization
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public int UserId { get; set; }
        public bool Selected { get; set; }
        /// <summary>
        /// Indicating whether the org is selected on the map
        /// </summary>
        public bool GeoSelected { get; set; }
    }
}