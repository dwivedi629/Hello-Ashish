﻿using System.ComponentModel.DataAnnotations;

using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;

namespace AtHoc.IWS.Business.Domain.Entities
{
    public class OperatorChannel : EntityBase
	{
        public int UserId
		{
			get { return this.Get<int>("UserId"); }
			set { this.Set<int>("UserId", value); }
		}
		public int ChannelId
		{
			get { return this.Get<int>("ChannelId"); }
			set { this.Set<int>("ChannelId", value); }
		}
	}
}
