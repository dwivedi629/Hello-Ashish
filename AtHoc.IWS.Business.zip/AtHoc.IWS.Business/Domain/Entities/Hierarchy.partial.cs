﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Meta;

namespace AtHoc.IWS.Business.Domain.Entities
{
    public partial class Hierarchy
    {
        [MetaProperty(IsPersistable = false)]
        public CustomAttribute CustomAttribute
        {
            get { return this.Get<CustomAttribute>("CustomAttribute"); }
            set { this.Set<CustomAttribute>("CustomAttribute", value); }
        }
    }
}
