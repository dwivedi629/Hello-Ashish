﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Entities
{
    public class UserAttributeDataType
    {
        public int AttributeTypeId { get; set; }
        public string AttributeType { get; set; }

        public string ClassType { get; set; }

        public string Description { get; set; }

        public string UserInterfaceDataType { get; set; }

    }
}
