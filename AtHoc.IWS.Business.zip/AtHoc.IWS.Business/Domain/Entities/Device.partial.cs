﻿using System;

using AtHoc.Infrastructure.Meta;

namespace AtHoc.IWS.Business.Domain.Entities
{
	public partial class Device : ICommonName
	{
		[MetaProperty(IsPersistable = false)]
		public DeviceProvider DeviceProvider
		{
			get { return Get<DeviceProvider>("DeviceProvider"); }
			set { Set("DeviceProvider", value); }
		}

		[MetaProperty(IsPersistable = false)]
		public DeviceGroup DeviceGroup
		{
			get { return Get<DeviceGroup>("DeviceGroup"); }
			set { Set("DeviceGroup", value); }
		}

		[MetaProperty(IsPersistable = false)]
		public object UserAddressValue { get; set; }

		[MetaProperty(IsPersistable = false)]
		public bool IsMassDevice
		{
			get { return DeviceGroup.RecipientType.Equals("Mass", StringComparison.CurrentCultureIgnoreCase); }
		}
	}
}