﻿namespace AtHoc.IWS.Business.Domain.Entities
{
    public class AlertReportColumn
    {
        public string ColumnId { get; set; }
        public string ColumnName { get; set; }
        public string IsStatic { get; set; }

    }
}