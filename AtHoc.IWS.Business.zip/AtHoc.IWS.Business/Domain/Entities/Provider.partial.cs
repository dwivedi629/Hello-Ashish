﻿using System;
using System.Globalization;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Meta;
using AtHoc.IWS.Business.Domain.Settings.Model;

namespace AtHoc.IWS.Business.Domain.Entities
{
    public enum VPSType
    {
        Parking,
        ShadowTemplate,
        Shadow,
        System,
        EnterpriseTemplate,
        Enterprise,
        Sub,
        Affiliate25Template,
        Affiliate25
    }

	public partial class Provider
	{
		[MetaProperty(IsPersistable = false)]
		public ExtendedParams ExtendedParams { get; set; }

		private static DateTime StartDateTime = new DateTime(2000, 1, 1);

	    private string GetFormatedVpsDateTime(DateTime? systemDateTime, string format)
	    {
            if (systemDateTime == null)
            {
                return "";
            }
            var vpsTime = this.SystemToVpsTime(new DateTime(systemDateTime.Value.Ticks, DateTimeKind.Unspecified));
            return String.Format(new CultureInfo("en-US"), "{0:" + format + "}", vpsTime);
	    }

		public DateTime GetVpsDateTimeFromSeconds(int seconds)
		{
			return TimeZoneInfo.ConvertTime(StartDateTime.AddSeconds(seconds), DateTimeConverter.GetSystemTimeZoneInfo(), GetVpsTimeZoneFromId());
		}

        public DateTime GetSystemDateTimeFromSeconds(int seconds)
        {
            return StartDateTime.AddSeconds(seconds);
        }

        public string GetVpsDateTimeFromSecondsFormated(int seconds)
        {
            var dateTime = TimeZoneInfo.ConvertTime(StartDateTime.AddSeconds(seconds), DateTimeConverter.GetSystemTimeZoneInfo(), GetVpsTimeZoneFromId());
            return dateTime.ToString(this.GetDateTimeFormat());
        }

        public string GetVpsDateFromSeconds(int seconds)
        {
            var dateTime = TimeZoneInfo.ConvertTime(StartDateTime.AddSeconds(seconds), DateTimeConverter.GetSystemTimeZoneInfo(), GetVpsTimeZoneFromId());
            return dateTime.ToString(this.GetDateFormat());
        }

		public DateTime SystemToVpsTime(DateTime systemDateTime)
		{
		    TimeZoneInfo systemTimeZoneInfo = DateTimeConverter.GetSystemTimeZoneInfo();
            
            if (systemTimeZoneInfo.IsInvalidTime(systemDateTime))
            {
                DaylightTime dayLightTime = TimeZone.CurrentTimeZone.GetDaylightChanges(systemDateTime.Year);
                systemDateTime = systemDateTime.AddHours(dayLightTime.Delta.Hours);
            }

			return TimeZoneInfo.ConvertTime(systemDateTime, DateTimeConverter.GetSystemTimeZoneInfo(), GetVpsTimeZoneFromId());
		}

        public string SystemToVpsDateTimeFormated(DateTime? systemDateTime)
        {
            return GetFormatedVpsDateTime(systemDateTime, this.GetDateTimeFormat());
        }

        public string SystemToVpsDateFormated(DateTime? systemDateTime)
        {
            return GetFormatedVpsDateTime(systemDateTime, this.GetDateFormat());
        }

        public string SystemToVpsTimeFormated(DateTime? systemDateTime)
        {
            return GetFormatedVpsDateTime(systemDateTime, this.GetTimeFormat());
        }

		public DateTime VpsToSystemTime(DateTime vpsDateTime)
		{
			return TimeZoneInfo.ConvertTime(vpsDateTime, GetVpsTimeZoneFromId(), DateTimeConverter.GetSystemTimeZoneInfo());
		}

		public string CurrentSystemTimeToVpsTimeString(string formatString = null)
		{
			return CurrentSystemTimeToVps().ToString(formatString ?? GetDateTimeFormat().Replace("TT","tt"));
		}

		public DateTime CurrentSystemTimeToVps()
		{
			return SystemToVpsTime(DateTimeConverter.GetSystemTime());
		}

        public DateTime CurrentSystemTime()
        {
            return DateTimeConverter.GetSystemTime();
        }

        public string GetTimeInVPSFormatWithoutTimeZoneAdjust(DateTime datetimetoConvert)
        {
            return datetimetoConvert.ToString(this.GetDateTimeFormat());
        }

		public DateTime ConvertUserInputDateTimeToSystemDateTime(string userInputDateTime)
		{
			var inputDate = DateTime.Parse(userInputDateTime,null,DateTimeStyles.RoundtripKind);
			inputDate = new DateTime(inputDate.Ticks, DateTimeKind.Unspecified);
		    return TimeZoneInfo.ConvertTime(inputDate, GetVpsTimeZoneFromId(), DateTimeConverter.GetSystemTimeZoneInfo());
		}

		public DateTime UtcToVpsTime(DateTime utcDateTime)
		{
			return TimeZoneInfo.ConvertTime(utcDateTime, TimeZoneInfo.Utc, GetVpsTimeZoneFromId());
		}

		public double VPSOffsetFromSystemInMinutes()
		{
			return DateTimeConverter.GetSystemTimeZoneInfo().BaseUtcOffset.TotalMinutes - GetVpsTimeZoneFromId().BaseUtcOffset.TotalMinutes;
		}

		public DateTime VpsToUtcTime(DateTime vpsDateTime)
		{
			return TimeZoneInfo.ConvertTime(vpsDateTime, GetVpsTimeZoneFromId(), TimeZoneInfo.Utc);
		}

		public TimeZoneInfo GetVpsTimeZoneFromId()
		{
			CheckExtendedParams();
			return TimeZoneInfo.FindSystemTimeZoneById(ExtendedParams.TimeZoneRegionId);
		}

		private void CheckExtendedParams()
		{
			if (ExtendedParams == null)
			{
				throw new ArgumentNullException("ExtendedParams");
			}
		}

		public string GetDateTimeFormat()
		{
			var providerDateTimeFormat = "MM/dd/yyyy hh:mm:ss tt";
			if (DateFormat.IsNotNullOrEmpty())
			{
				providerDateTimeFormat = DateFormat.Replace("DD", "dd").Replace("YYYY", "yyyy").Replace("YY", "yy");
			}
			if (TimeFormat.IsNotNullOrEmpty())
			{
				var hh = TimeFormat.ToLowerInvariant().EndsWith("tt") ? "hh" : "HH";
                providerDateTimeFormat += " " + TimeFormat.Replace("HH", hh).Replace("MM", "mm").Replace("SS", "ss").Replace("TT", "tt");
                
			}
			return providerDateTimeFormat;
		}

		public string GetDateFormat()
		{
			var providerDateTimeFormat = "MM/dd/yyyy";
			if (DateFormat.IsNotNullOrEmpty())
			{
				providerDateTimeFormat = DateFormat.Replace("DD", "dd").Replace("YYYY", "yyyy").Replace("YY", "yy");
			}
			return providerDateTimeFormat;
		}

        public string GetTimeFormat()
        {
            var providerTimeFormat = "mm/hh/ss";
            if (TimeFormat.IsNotNullOrEmpty())
            {
                var hh = TimeFormat.ToLowerInvariant().EndsWith("tt") ? "hh" : "HH";
                providerTimeFormat = TimeFormat.Replace("HH", hh).Replace("MM", "mm").Replace("SS", "ss").Replace("TT", "tt");
            }
            return providerTimeFormat;
        }


		public string GetDeviceFormat()
		{
			return "($1) $2-$3";
		}

        /// <summary>
        /// Current VPS ProviderType
        /// </summary>
        /// <returns></returns>
        public VPSType ProviderType()
        {
            CheckExtendedParams();
            switch (ExtendedParams.ProviderType)
            {
                case "PARKING":
                    return VPSType.Parking;
                case "SHADOWTEMPLATE":
                    return VPSType.ShadowTemplate;
                case "SHADOW":
                    return VPSType.Shadow;
                case "SYSTEM":
                    return VPSType.System;
                case "ENTTEMPLATE":
                    return VPSType.EnterpriseTemplate;
                case "ENTERPRISE":
                    return VPSType.Enterprise;
                case "SUB":
                    return VPSType.Sub;
                case "AFF25TEMPLATE":
                    return VPSType.Affiliate25Template;
                case "AFF25":
                    return VPSType.Affiliate25;
                default :
                    throw new Exception("Unknown ProviderType encountered in PRV_EXTENDED_PARAMS_TAB for ProviderId " + ExtendedParams.Id);
            }
        }

	    public FeatureMatrix FeatureMatrix;


	    public string BaseLocale;
	}
}