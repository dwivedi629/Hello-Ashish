﻿using System;
using System.Collections.Generic;

using AtHoc.Infrastructure.Meta;
using AtHoc.IWS.Business.Data;

namespace AtHoc.IWS.Business.Domain.Entities
{
	public partial class DistributionList
	{
		[MetaProperty(IsPersistable = false)]
		public Hierarchy Hierarchy
		{
			get { return this.Get<Hierarchy>("Hierarchy"); }
			set { this.Set("Hierarchy", value); }
		}

		[MetaProperty(IsPersistable = false)]
		public DistributionList ParentList { get; set; }

        [Obsolete("Use Facade API to get DL children")]
		[MetaProperty(IsPersistable = false)]
		public IList<DistributionList> Children
		{
			get { return this.Get<IList<DistributionList>>("Children"); }
			set { this.Set("Children", value); }
		}

        [MetaProperty(IsPersistable = false)]
        public string FullLineage
        {
            get { return string.Concat(this.Get<string>("Lineage"), this.Get<string>("Name")); }
        }

		[MetaProperty(IsPersistable = false)]
		public string TranslatedDefinition { get; set; }

		[MetaProperty(IsPersistable = false)]
		public ICriteria UserBase
		{
			get { return this.Get<ICriteria>("UserBase"); }
			set { this.Set<ICriteria>("UserBase", value); }
		}

        [MetaProperty(IsPersistable = false)]
        public int ChildrenCount
        {
            get { return this.Get<int>("ChildrenCount"); }
        }

        [MetaProperty(IsPersistable = false)]
        public string DescendantLists
        {
            get { return this.Get<string>("DescendantLists"); }
        }

	}
}
