﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Data;
using models = AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Models;

namespace AtHoc.IWS.Business.Domain
{
    public enum MediaContentType { Unknown, Photo, Video, Thumbnail }
    public class EventWrapper
    {
        public PagingInfo<models.Event> Events { get; set; }
        public List<models.EventDescription> EventDescriptions { get; set; }
        public List<models.EventMedia> EventMedias { get; set; }
        public List<models.Media > MediaAttachments { get; set; }
        public IDictionary<int, models.EventCategory> EventCategories { get; set; }
        public models.Event Event { get; set; }

    }
}
