﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Encryption;

namespace AtHoc.IWS.Business.Domain.Entities
{
    [MetadataType(typeof(ProviderMeta))]
	[MetaObject(TableName = "PRV_PROVIDER_TAB")]
	public partial class Provider : EntityBase
    {

		[MetaProperty(ColumnName = "PROVIDER_ID", DbTypeName = "int", IsKey = true)]
		[Required]
		public virtual int Id
		{
			get { return this.Get<int>("Id"); }
			set { this.Set<int>("Id", value); }
		}

		[MetaProperty(ColumnName = "PROVIDER_NAME", DbTypeName = "nvarchar", MaxLength = 64, AutoTrim = true)]
		[MaxLength(64)]
		[Required]
		public virtual string ProviderName
		{
			get { return this.Get<string>("ProviderName"); }
			set { this.Set<string>("ProviderName", value); }
		}

		[MetaProperty(ColumnName = "PROVIDER_GUID", DbTypeName = "nvarchar", MaxLength = 50, AutoTrim = true)]
		[MaxLength(50)]
		public virtual string ProviderGuid
		{
			get { return this.Get<string>("ProviderGuid"); }
			set { this.Set<string>("ProviderGuid", value); }
		}

		[MetaProperty(ColumnName = "PROVIDER_TYPE_ID", DbTypeName = "nvarchar", MaxLength = 3, AutoTrim = true)]
		[MaxLength(3)]
		public virtual string ProviderTypeId
		{
			get { return this.Get<string>("ProviderTypeId"); }
			set { this.Set<string>("ProviderTypeId", value); }
		}

		[MetaProperty(ColumnName = "PROVIDER_URL", DbTypeName = "nvarchar", MaxLength = 300, AutoTrim = true)]
		[MaxLength(300)]
		public virtual string ProviderUrl
		{
			get { return this.Get<string>("ProviderUrl"); }
			set { this.Set<string>("ProviderUrl", value); }
		}

		[MetaProperty(ColumnName = "PROVIDER_STATUS_ID", DbTypeName = "nvarchar", MaxLength = 3, AutoTrim = true)]
		[MaxLength(3)]
		public virtual string ProviderStatusId
		{
			get { return this.Get<string>("ProviderStatusId"); }
			set { this.Set<string>("ProviderStatusId", value); }
		}

		[MetaProperty(ColumnName = "DISPLAY_NAME", DbTypeName = "nvarchar", MaxLength = 62, AutoTrim = true)]
		[MaxLength(62)]
		public virtual string DisplayName
		{
			get { return this.Get<string>("DisplayName"); }
			set { this.Set<string>("DisplayName", value); }
		}

		[MetaProperty(ColumnName = "PACKAGE_STATUS", DbTypeName = "nvarchar", MaxLength = 3, AutoTrim = true)]
		[MaxLength(3)]
		public virtual string PackageStatus
		{
			get { return this.Get<string>("PackageStatus"); }
			set { this.Set<string>("PackageStatus", value); }
		}

		[MetaProperty(ColumnName = "DESCRIPTION", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string Description
		{
			get { return this.Get<string>("Description"); }
			set { this.Set<string>("Description", value); }
		}

		[MetaProperty(ColumnName = "TAG_LINE", DbTypeName = "nvarchar", MaxLength = 256, AutoTrim = true)]
		[MaxLength(256)]
		public virtual string TagLine
		{
			get { return this.Get<string>("TagLine"); }
			set { this.Set<string>("TagLine", value); }
		}

		[MetaProperty(ColumnName = "VERSION", DbTypeName = "int")]
		public virtual int? Version
		{
			get { return this.Get<int?>("Version"); }
			set { this.Set<int?>("Version", value); }
		}

		[MetaProperty(ColumnName = "ALERT_ALLOWED", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string AlertAllowed
		{
			get { return this.Get<string>("AlertAllowed"); }
			set { this.Set<string>("AlertAllowed", value); }
		}

		[MetaProperty(ColumnName = "LAUNCH_DATE", DbTypeName = "int")]
		public virtual int? LaunchDate
		{
			get { return this.Get<int?>("LaunchDate"); }
			set { this.Set<int?>("LaunchDate", value); }
		}

		[MetaProperty(ColumnName = "IS_CUSTOMIZE", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsCustomize
		{
			get { return this.Get<string>("IsCustomize"); }
			set { this.Set<string>("IsCustomize", value); }
		}

		[MetaProperty(ColumnName = "IS_PERSONAL_LINKS", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsPersonalLinks
		{
			get { return this.Get<string>("IsPersonalLinks"); }
			set { this.Set<string>("IsPersonalLinks", value); }
		}

		[MetaProperty(ColumnName = "IS_NETSCAPE", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsNetscape
		{
			get { return this.Get<string>("IsNetscape"); }
			set { this.Set<string>("IsNetscape", value); }
		}

		[MetaProperty(ColumnName = "CLIENT_VERSION", DbTypeName = "nvarchar", MaxLength = 64, AutoTrim = true)]
		[MaxLength(64)]
		public virtual string ClientVersion
		{
			get { return this.Get<string>("ClientVersion"); }
			set { this.Set<string>("ClientVersion", value); }
		}

		[MetaProperty(ColumnName = "SERVICE_IMAGE_ID", DbTypeName = "nvarchar", MaxLength = 30, AutoTrim = true)]
		[MaxLength(30)]
		public virtual string ServiceImageId
		{
			get { return this.Get<string>("ServiceImageId"); }
			set { this.Set<string>("ServiceImageId", value); }
		}

		[MetaProperty(ColumnName = "ALERT_IMAGE_ID", DbTypeName = "nvarchar", MaxLength = 50, AutoTrim = true)]
		[MaxLength(50)]
		public virtual string AlertImageId
		{
			get { return this.Get<string>("AlertImageId"); }
			set { this.Set<string>("AlertImageId", value); }
		}

		[MetaProperty(ColumnName = "WEB_IMAGE_ID", DbTypeName = "nvarchar", MaxLength = 50, AutoTrim = true)]
		[MaxLength(50)]
		public virtual string WebImageId
		{
			get { return this.Get<string>("WebImageId"); }
			set { this.Set<string>("WebImageId", value); }
		}

		[MetaProperty(ColumnName = "INF_EMAIL_FROM", DbTypeName = "nvarchar", MaxLength = 150, AutoTrim = true)]
		[MaxLength(150)]
		public virtual string InfEmailFrom
		{
			get { return this.Get<string>("InfEmailFrom"); }
			set { this.Set<string>("InfEmailFrom", value); }
		}

		[MetaProperty(ColumnName = "STYLE_VERSION", DbTypeName = "int")]
		[Required]
		public virtual int StyleVersion
		{
			get { return this.Get<int>("StyleVersion"); }
			set { this.Set<int>("StyleVersion", value); }
		}

		[MetaProperty(ColumnName = "IS_RMP", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsRmp
		{
			get { return this.Get<string>("IsRmp"); }
			set { this.Set<string>("IsRmp", value); }
		}

		[MetaProperty(ColumnName = "IS_SPS_DIRECT", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		[Required]
		public virtual string IsSpsDirect
		{
			get { return this.Get<string>("IsSpsDirect"); }
			set { this.Set<string>("IsSpsDirect", value); }
		}

		[MetaProperty(ColumnName = "IS_OFFLINE_INSTALL", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsOfflineInstall
		{
			get { return this.Get<string>("IsOfflineInstall"); }
			set { this.Set<string>("IsOfflineInstall", value); }
		}

		[MetaProperty(ColumnName = "IS_QUE_SIGN_ON", DbTypeName = "nchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		[Required]
		public virtual string IsQueSignOn
		{
			get { return this.Get<string>("IsQueSignOn"); }
			set { this.Set<string>("IsQueSignOn", value); }
		}

		[MetaProperty(ColumnName = "CONTACT_NAME", DbTypeName = "nvarchar", MaxLength = 64, AutoTrim = true)]
		[MaxLength(64)]
		public virtual string ContactName
		{
			get { return this.Get<string>("ContactName"); }
			set { this.Set<string>("ContactName", value); }
		}

		[MetaProperty(ColumnName = "CONTACT_TITLE", DbTypeName = "nvarchar", MaxLength = 40, AutoTrim = true)]
		[MaxLength(40)]
		public virtual string ContactTitle
		{
			get { return this.Get<string>("ContactTitle"); }
			set { this.Set<string>("ContactTitle", value); }
		}

		[MetaProperty(ColumnName = "CONTACT_EMAIL", DbTypeName = "nvarchar", MaxLength = 150, AutoTrim = true)]
		[MaxLength(150)]
		public virtual string ContactEmail
		{
			get { return this.Get<string>("ContactEmail"); }
			set { this.Set<string>("ContactEmail", value); }
		}

		[MetaProperty(ColumnName = "CONTACT_PHONE", DbTypeName = "nvarchar", MaxLength = 15, AutoTrim = true)]
		[MaxLength(15)]
		public virtual string ContactPhone
		{
			get { return this.Get<string>("ContactPhone"); }
			set { this.Set<string>("ContactPhone", value); }
		}

		[MetaProperty(ColumnName = "DIRECT_TRACKING", DbTypeName = "nvarchar", MaxLength = 20, AutoTrim = true)]
		[MaxLength(20)]
		public virtual string DirectTracking
		{
			get { return this.Get<string>("DirectTracking"); }
			set { this.Set<string>("DirectTracking", value); }
		}

		[MetaProperty(ColumnName = "CHECK_UPDATE_INTERVAL", DbTypeName = "int")]
		public virtual int? CheckUpdateInterval
		{
			get { return this.Get<int?>("CheckUpdateInterval"); }
			set { this.Set<int?>("CheckUpdateInterval", value); }
		}

		[MetaProperty(ColumnName = "IS_FORCE_CLIENT_UPDATE", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		[Required]
		public virtual string IsForceClientUpdate
		{
			get { return this.Get<string>("IsForceClientUpdate"); }
			set { this.Set<string>("IsForceClientUpdate", value); }
		}

		[MetaProperty(ColumnName = "WEBINTER_IMAGE_ID", DbTypeName = "nvarchar", MaxLength = 30, AutoTrim = true)]
		[MaxLength(30)]
		public virtual string WebinterImageId
		{
			get { return this.Get<string>("WebinterImageId"); }
			set { this.Set<string>("WebinterImageId", value); }
		}

		[MetaProperty(ColumnName = "IS_SYSTRAY_VISIBLE", DbTypeName = "nchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		[Required]
		public virtual string IsSystrayVisible
		{
			get { return this.Get<string>("IsSystrayVisible"); }
			set { this.Set<string>("IsSystrayVisible", value); }
		}

		[MetaProperty(ColumnName = "IS_BUTTONS", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsButtons
		{
			get { return this.Get<string>("IsButtons"); }
			set { this.Set<string>("IsButtons", value); }
		}

		[MetaProperty(ColumnName = "IS_ARRANGE", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsArrange
		{
			get { return this.Get<string>("IsArrange"); }
			set { this.Set<string>("IsArrange", value); }
		}

		[MetaProperty(ColumnName = "IS_MENUS", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsMenus
		{
			get { return this.Get<string>("IsMenus"); }
			set { this.Set<string>("IsMenus", value); }
		}

		[MetaProperty(ColumnName = "IS_SETTINGS", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsSettings
		{
			get { return this.Get<string>("IsSettings"); }
			set { this.Set<string>("IsSettings", value); }
		}

		[MetaProperty(ColumnName = "IS_SKINS", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsSkins
		{
			get { return this.Get<string>("IsSkins"); }
			set { this.Set<string>("IsSkins", value); }
		}

		[MetaProperty(ColumnName = "IS_NOTIFICATIONS", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsNotifications
		{
			get { return this.Get<string>("IsNotifications"); }
			set { this.Set<string>("IsNotifications", value); }
		}

		[MetaProperty(ColumnName = "IS_CORPORATE", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		[Required]
		public virtual string IsCorporate
		{
			get { return this.Get<string>("IsCorporate"); }
			set { this.Set<string>("IsCorporate", value); }
		}

		[MetaProperty(ColumnName = "IS_DEMO", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		[Required]
		public virtual string IsDemo
		{
			get { return this.Get<string>("IsDemo"); }
			set { this.Set<string>("IsDemo", value); }
		}

		[MetaProperty(ColumnName = "ALT_HOMEPAGE", DbTypeName = "nvarchar", MaxLength = 255, AutoTrim = true)]
		[MaxLength(255)]
		public virtual string AltHomepage
		{
			get { return this.Get<string>("AltHomepage"); }
			set { this.Set<string>("AltHomepage", value); }
		}

		[MetaProperty(ColumnName = "IS_REPORT_ENABLED", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsReportEnabled
		{
			get { return this.Get<string>("IsReportEnabled"); }
			set { this.Set<string>("IsReportEnabled", value); }
		}

		[MetaProperty(ColumnName = "CREATED_AT", DbTypeName = "nvarchar", MaxLength = 3, AutoTrim = true)]
		[MaxLength(3)]
		public virtual string CreatedAt
		{
			get { return this.Get<string>("CreatedAt"); }
			set { this.Set<string>("CreatedAt", value); }
		}

		[MetaProperty(ColumnName = "PRODUCT_STATUS", DbTypeName = "nvarchar", MaxLength = 3, AutoTrim = true)]
		[MaxLength(3)]
		public virtual string ProductStatus
		{
			get { return this.Get<string>("ProductStatus"); }
			set { this.Set<string>("ProductStatus", value); }
		}

		[MetaProperty(ColumnName = "CONTACT_ADDRESS", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string ContactAddress
		{
			get { return this.Get<string>("ContactAddress"); }
			set { this.Set<string>("ContactAddress", value); }
		}

		[MetaProperty(ColumnName = "CONTACT_PHONE2", DbTypeName = "nvarchar", MaxLength = 15, AutoTrim = true)]
		[MaxLength(15)]
		public virtual string ContactPhone2
		{
			get { return this.Get<string>("ContactPhone2"); }
			set { this.Set<string>("ContactPhone2", value); }
		}

		[MetaProperty(ColumnName = "SYSTRAY_IMAGE_ID", DbTypeName = "nvarchar", MaxLength = 30, AutoTrim = true)]
		[MaxLength(30)]
		public virtual string SystrayImageId
		{
			get { return this.Get<string>("SystrayImageId"); }
			set { this.Set<string>("SystrayImageId", value); }
		}

		[MetaProperty(ColumnName = "BROWSER_IMAGE_ID", DbTypeName = "nvarchar", MaxLength = 30, AutoTrim = true)]
		[MaxLength(30)]
		public virtual string BrowserImageId
		{
			get { return this.Get<string>("BrowserImageId"); }
			set { this.Set<string>("BrowserImageId", value); }
		}

		[MetaProperty(ColumnName = "IS_BROWSER_VISIBLE", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsBrowserVisible
		{
			get { return this.Get<string>("IsBrowserVisible"); }
			set { this.Set<string>("IsBrowserVisible", value); }
		}

		[MetaProperty(ColumnName = "PROVIDER_VERSION", DbTypeName = "int")]
		public virtual int? ProviderVersion
		{
			get { return this.Get<int?>("ProviderVersion"); }
			set { this.Set<int?>("ProviderVersion", value); }
		}

		[MetaProperty(ColumnName = "IS_MYDETAILS", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsMydetails
		{
			get { return this.Get<string>("IsMydetails"); }
			set { this.Set<string>("IsMydetails", value); }
		}

		[MetaProperty(ColumnName = "SUPPORTS_OFFLINE_ACTIVATIONS", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string SupportsOfflineActivations
		{
			get { return this.Get<string>("SupportsOfflineActivations"); }
			set { this.Set<string>("SupportsOfflineActivations", value); }
		}

		[MetaProperty(ColumnName = "SIGN_ON_TEMP_CU_INTERVAL", DbTypeName = "int")]
		public virtual int? SignOnTempCuInterval
		{
			get { return this.Get<int?>("SignOnTempCuInterval"); }
			set { this.Set<int?>("SignOnTempCuInterval", value); }
		}

		[MetaProperty(ColumnName = "IS_DESKBAR", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsDeskbar
		{
			get { return this.Get<string>("IsDeskbar"); }
			set { this.Set<string>("IsDeskbar", value); }
		}

		[MetaProperty(ColumnName = "IS_RIGHT_CLICK_MENU", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsRightClickMenu
		{
			get { return this.Get<string>("IsRightClickMenu"); }
			set { this.Set<string>("IsRightClickMenu", value); }
		}

		[MetaProperty(ColumnName = "IS_IE", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsIe
		{
			get { return this.Get<string>("IsIe"); }
			set { this.Set<string>("IsIe", value); }
		}

		[MetaProperty(ColumnName = "CLEAR_DF_HL_FOR_NEW_USER", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string ClearDfHlForNewUser
		{
			get { return this.Get<string>("ClearDfHlForNewUser"); }
			set { this.Set<string>("ClearDfHlForNewUser", value); }
		}

		[MetaProperty(ColumnName = "CLEAR_ALERT_HL_FOR_NEW_USER", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string ClearAlertHlForNewUser
		{
			get { return this.Get<string>("ClearAlertHlForNewUser"); }
			set { this.Set<string>("ClearAlertHlForNewUser", value); }
		}

		[MetaProperty(ColumnName = "TOOLBAR_NAME", DbTypeName = "nvarchar", MaxLength = 30, AutoTrim = true)]
		[MaxLength(30)]
		public virtual string ToolbarName
		{
			get { return this.Get<string>("ToolbarName"); }
			set { this.Set<string>("ToolbarName", value); }
		}

		[MetaProperty(ColumnName = "WTB_TOOLBAR_BEHAVIOR", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string WtbToolbarBehavior
		{
			get { return this.Get<string>("WtbToolbarBehavior"); }
			set { this.Set<string>("WtbToolbarBehavior", value); }
		}

		[MetaProperty(ColumnName = "WTB_TOOLBAR_ICON_TEXT_BEHAVIOR", DbTypeName = "nvarchar", MaxLength = 2, AutoTrim = true)]
		[MaxLength(2)]
		public virtual string WtbToolbarIconTextBehavior
		{
			get { return this.Get<string>("WtbToolbarIconTextBehavior"); }
			set { this.Set<string>("WtbToolbarIconTextBehavior", value); }
		}

		[MetaProperty(ColumnName = "WTB_SEARCH_BOX_SIZE", DbTypeName = "nvarchar", MaxLength = 10, AutoTrim = true)]
		[MaxLength(10)]
		public virtual string WtbSearchBoxSize
		{
			get { return this.Get<string>("WtbSearchBoxSize"); }
			set { this.Set<string>("WtbSearchBoxSize", value); }
		}

		[MetaProperty(ColumnName = "SSN_FORCE_CLEANUP_INTERVAL", DbTypeName = "int")]
		public virtual int? SsnForceCleanupInterval
		{
			get { return this.Get<int?>("SsnForceCleanupInterval"); }
			set { this.Set<int?>("SsnForceCleanupInterval", value); }
		}

		[MetaProperty(ColumnName = "SSN_INACTIVE_CLEANUP_INTERVAL", DbTypeName = "int")]
		public virtual int? SsnInactiveCleanupInterval
		{
			get { return this.Get<int?>("SsnInactiveCleanupInterval"); }
			set { this.Set<int?>("SsnInactiveCleanupInterval", value); }
		}

		[MetaProperty(ColumnName = "SSN_WEB_TIMEOUT_INTERVAL", DbTypeName = "int")]
		public virtual int? SsnWebTimeoutInterval
		{
			get { return this.Get<int?>("SsnWebTimeoutInterval"); }
			set { this.Set<int?>("SsnWebTimeoutInterval", value); }
		}

		[MetaProperty(ColumnName = "IS_SELF_REGISTRATION", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsSelfRegistration
		{
			get { return this.Get<string>("IsSelfRegistration"); }
			set { this.Set<string>("IsSelfRegistration", value); }
		}

		[MetaProperty(ColumnName = "SSN_PERSISTENCE_OPTION", DbTypeName = "nvarchar", MaxLength = 3, AutoTrim = true)]
		[MaxLength(3)]
		public virtual string SsnPersistenceOption
		{
			get { return this.Get<string>("SsnPersistenceOption"); }
			set { this.Set<string>("SsnPersistenceOption", value); }
		}

		[MetaProperty(ColumnName = "SHOW_UNINSTALL_YN", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string ShowUninstallYn
		{
			get { return this.Get<string>("ShowUninstallYn"); }
			set { this.Set<string>("ShowUninstallYn", value); }
		}

		[MetaProperty(ColumnName = "AUTOHIDE_FORCEEXPOSE_TYPE", DbTypeName = "int")]
		public virtual int? AutohideForceexposeType
		{
			get { return this.Get<int?>("AutohideForceexposeType"); }
			set { this.Set<int?>("AutohideForceexposeType", value); }
		}

		[MetaProperty(ColumnName = "AUTOHIDE_FORCEEXPOSE_TIME", DbTypeName = "int")]
		public virtual int? AutohideForceexposeTime
		{
			get { return this.Get<int?>("AutohideForceexposeTime"); }
			set { this.Set<int?>("AutohideForceexposeTime", value); }
		}

		[MetaProperty(ColumnName = "SSL_CSI_YN", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string SslCsiYn
		{
			get { return this.Get<string>("SslCsiYn"); }
			set { this.Set<string>("SslCsiYn", value); }
		}

		[MetaProperty(ColumnName = "SSL_WEB_YN", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string SslWebYn
		{
			get { return this.Get<string>("SslWebYn"); }
			set { this.Set<string>("SslWebYn", value); }
		}

		[MetaProperty(ColumnName = "CLIENT_OBJECT_NAME", DbTypeName = "nvarchar", MaxLength = 50, AutoTrim = true)]
		[MaxLength(50)]
		public virtual string ClientObjectName
		{
			get { return this.Get<string>("ClientObjectName"); }
			set { this.Set<string>("ClientObjectName", value); }
		}

		[MetaProperty(ColumnName = "CLIENT_CLASS_ID", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
		public virtual string ClientClassId
		{
			get { return this.Get<string>("ClientClassId"); }
			set { this.Set<string>("ClientClassId", value); }
		}

		[MetaProperty(ColumnName = "RUN_SERVICE_SYNC_YN", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string RunServiceSyncYn
		{
			get { return this.Get<string>("RunServiceSyncYn"); }
			set { this.Set<string>("RunServiceSyncYn", value); }
		}

		[MetaProperty(ColumnName = "RUN_GROUP_SYNC_YN", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string RunGroupSyncYn
		{
			get { return this.Get<string>("RunGroupSyncYn"); }
			set { this.Set<string>("RunGroupSyncYn", value); }
		}

		[MetaProperty(ColumnName = "RUN_LUA_SYNC_YN", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string RunLuaSyncYn
		{
			get { return this.Get<string>("RunLuaSyncYn"); }
			set { this.Set<string>("RunLuaSyncYn", value); }
		}

		[MetaProperty(ColumnName = "RUN_LAYOUT_SYNC_YN", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string RunLayoutSyncYn
		{
			get { return this.Get<string>("RunLayoutSyncYn"); }
			set { this.Set<string>("RunLayoutSyncYn", value); }
		}

		[MetaProperty(ColumnName = "RUN_BTN_LAYOUT_SYNC_ALWAYS_YN", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string RunBtnLayoutSyncAlwaysYn
		{
			get { return this.Get<string>("RunBtnLayoutSyncAlwaysYn"); }
			set { this.Set<string>("RunBtnLayoutSyncAlwaysYn", value); }
		}

		[MetaProperty(ColumnName = "PLS_MAX_COUNT", DbTypeName = "int")]
		public virtual int? PlsMaxCount
		{
			get { return this.Get<int?>("PlsMaxCount"); }
			set { this.Set<int?>("PlsMaxCount", value); }
		}

		[MetaProperty(ColumnName = "PLS_MIN_POLL_INTERVAL", DbTypeName = "int")]
		public virtual int? PlsMinPollInterval
		{
			get { return this.Get<int?>("PlsMinPollInterval"); }
			set { this.Set<int?>("PlsMinPollInterval", value); }
		}

		[MetaProperty(ColumnName = "UNINSTALL_MESSAGE_OPTION", DbTypeName = "nvarchar", MaxLength = 5, AutoTrim = true)]
		[MaxLength(5)]
		public virtual string UninstallMessageOption
		{
			get { return this.Get<string>("UninstallMessageOption"); }
			set { this.Set<string>("UninstallMessageOption", value); }
		}

		[MetaProperty(ColumnName = "DISMISS_RIGHT_CLICK_NOTIFIER_YN", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string DismissRightClickNotifierYn
		{
			get { return this.Get<string>("DismissRightClickNotifierYn"); }
			set { this.Set<string>("DismissRightClickNotifierYn", value); }
		}

		[MetaProperty(ColumnName = "REP_USER_ID", DbTypeName = "int")]
		public virtual int? RepUserId
		{
			get { return this.Get<int?>("RepUserId"); }
			set { this.Set<int?>("RepUserId", value); }
		}

		[MetaProperty(ColumnName = "REP_USER_LOCKED", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string RepUserLocked
		{
			get { return this.Get<string>("RepUserLocked"); }
			set { this.Set<string>("RepUserLocked", value); }
		}

		[MetaProperty(ColumnName = "SYSTRAY_BUTTON_ID", DbTypeName = "int")]
		public virtual int? SystrayButtonId
		{
			get { return this.Get<int?>("SystrayButtonId"); }
			set { this.Set<int?>("SystrayButtonId", value); }
		}

		[MetaProperty(ColumnName = "RCLICK_BUTTON_ID", DbTypeName = "int")]
		public virtual int? RclickButtonId
		{
			get { return this.Get<int?>("RclickButtonId"); }
			set { this.Set<int?>("RclickButtonId", value); }
		}

		[MetaProperty(ColumnName = "QU_USER_TYPE", DbTypeName = "nvarchar", MaxLength = 5, AutoTrim = true)]
		[MaxLength(5)]
		public virtual string QuUserType
		{
			get { return this.Get<string>("QuUserType"); }
			set { this.Set<string>("QuUserType", value); }
		}

		[MetaProperty(ColumnName = "QU_ACTIVE_USERS_ONLY", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string QuActiveUsersOnly
		{
			get { return this.Get<string>("QuActiveUsersOnly"); }
			set { this.Set<string>("QuActiveUsersOnly", value); }
		}

		[MetaProperty(ColumnName = "SYSTRAY_MENU_VERSION", DbTypeName = "int")]
		public virtual int? SystrayMenuVersion
		{
			get { return this.Get<int?>("SystrayMenuVersion"); }
			set { this.Set<int?>("SystrayMenuVersion", value); }
		}

		[MetaProperty(ColumnName = "RCLICK_MENU_VERSION", DbTypeName = "int")]
		public virtual int? RclickMenuVersion
		{
			get { return this.Get<int?>("RclickMenuVersion"); }
			set { this.Set<int?>("RclickMenuVersion", value); }
		}

		[MetaProperty(ColumnName = "PROFILE_VERSION", DbTypeName = "int")]
		public virtual int? ProfileVersion
		{
			get { return this.Get<int?>("ProfileVersion"); }
			set { this.Set<int?>("ProfileVersion", value); }
		}

		[MetaProperty(ColumnName = "DATE_FORMAT", DbTypeName = "nvarchar", MaxLength = 15, AutoTrim = true)]
		[MaxLength(15)]
		public virtual string DateFormat
		{
			get { return this.Get<string>("DateFormat"); }
			set { this.Set<string>("DateFormat", value); }
		}

		[MetaProperty(ColumnName = "TIME_FORMAT", DbTypeName = "nvarchar", MaxLength = 15, AutoTrim = true)]
		[MaxLength(15)]
		public virtual string TimeFormat
		{
			get { return this.Get<string>("TimeFormat"); }
			set { this.Set<string>("TimeFormat", value); }
		}

		[MetaProperty(ColumnName = "USER_AUTH_OPTION", DbTypeName = "nvarchar", MaxLength = 10, AutoTrim = true)]
		[MaxLength(10)]
		public virtual string UserAuthOption
		{
			get { return this.Get<string>("UserAuthOption"); }
			set { this.Set<string>("UserAuthOption", value); }
		}

		[MetaProperty(ColumnName = "DELETED_USER_PRVID", DbTypeName = "int")]
		public virtual int? DeletedUserPrvid
		{
			get { return this.Get<int?>("DeletedUserPrvid"); }
			set { this.Set<int?>("DeletedUserPrvid", value); }
		}

		[MetaProperty(ColumnName = "DISABLED_USER_PRVID", DbTypeName = "int")]
		public virtual int? DisabledUserPrvid
		{
			get { return this.Get<int?>("DisabledUserPrvid"); }
			set { this.Set<int?>("DisabledUserPrvid", value); }
		}

		[MetaProperty(ColumnName = "SCUR_MAX_PCT", DbTypeName = "int")]
		public virtual int? ScurMaxPct
		{
			get { return this.Get<int?>("ScurMaxPct"); }
			set { this.Set<int?>("ScurMaxPct", value); }
		}

		[MetaProperty(ColumnName = "EMAIL_ACK_TYPE", DbTypeName = "int")]
		public virtual int? EmailAckType
		{
			get { return this.Get<int?>("EmailAckType"); }
			set { this.Set<int?>("EmailAckType", value); }
		}

		[MetaProperty(ColumnName = "EMAIL_ACK_SERVER", DbTypeName = "nvarchar", MaxLength = 500, AutoTrim = true)]
		[MaxLength(500)]
		public virtual string EmailAckServer
		{
			get { return this.Get<string>("EmailAckServer"); }
			set { this.Set<string>("EmailAckServer", value); }
		}

		[MetaProperty(ColumnName = "EMAIL_ACK_USERNAME", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string EmailAckUsername
		{
			get { return this.Get<string>("EmailAckUsername"); }
			set { this.Set<string>("EmailAckUsername", value); }
		}

		[MetaProperty(ColumnName = "EMAIL_ACK_PASSWORD", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string EmailAckPassword
		{
			get { return this.Get<string>("EmailAckPassword"); }
			set { this.Set<string>("EmailAckPassword", value); }
		}

		[MetaProperty(ColumnName = "EMAIL_PUB_TYPE", DbTypeName = "int")]
		public virtual int? EmailPubType
		{
			get { return this.Get<int?>("EmailPubType"); }
			set { this.Set<int?>("EmailPubType", value); }
		}

		[MetaProperty(ColumnName = "EMAIL_PUB_SERVER", DbTypeName = "nvarchar", MaxLength = 500, AutoTrim = true)]
		[MaxLength(500)]
		public virtual string EmailPubServer
		{
			get { return this.Get<string>("EmailPubServer"); }
			set { this.Set<string>("EmailPubServer", value); }
		}

		[MetaProperty(ColumnName = "EMAIL_PUB_USERNAME", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string EmailPubUsername
		{
			get { return this.Get<string>("EmailPubUsername"); }
			set { this.Set<string>("EmailPubUsername", value); }
		}

		[MetaProperty(ColumnName = "EMAIL_PUB_PASSWORD", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string EmailPubPassword
		{
			get { return this.Get<string>("EmailPubPassword"); }
			set { this.Set<string>("EmailPubPassword", value); }
		}

		[MetaProperty(ColumnName = "AUDIO_SPEAKER_VOLUME", DbTypeName = "int")]
		public virtual int? AudioSpeakerVolume
		{
			get { return this.Get<int?>("AudioSpeakerVolume"); }
			set { this.Set<int?>("AudioSpeakerVolume", value); }
		}

		[MetaProperty(ColumnName = "AUDIO_FORCE_SPEAKER", DbTypeName = "int")]
		public virtual int? AudioForceSpeaker
		{
			get { return this.Get<int?>("AudioForceSpeaker"); }
			set { this.Set<int?>("AudioForceSpeaker", value); }
		}

		[MetaProperty(ColumnName = "USE_CUSTOM_NEW_END_USER_PAGE", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
        [System.ComponentModel.DataAnnotations.MaxLength(1)]
		public virtual string UseCustomNewEndUserPage
		{
			get { return this.Get<string>("UseCustomNewEndUserPage"); }
			set { this.Set<string>("UseCustomNewEndUserPage", value); }
		}

		[MetaProperty(ColumnName = "SYSTRAY_LAYOUT", DbTypeName = "", AutoTrim = true)]
		public virtual string SystrayLayout
		{
			get { return this.Get<string>("SystrayLayout"); }
			set { this.Set<string>("SystrayLayout", value); }
		}


		#region Properties
		public class Meta
		{
			public static readonly MetaProperty Id = MetaObject.Get(typeof(Provider))["Id"];
			public static readonly MetaProperty ProviderName = MetaObject.Get(typeof(Provider))["ProviderName"];
			public static readonly MetaProperty ProviderGuid = MetaObject.Get(typeof(Provider))["ProviderGuid"];
			public static readonly MetaProperty ProviderTypeId = MetaObject.Get(typeof(Provider))["ProviderTypeId"];
			public static readonly MetaProperty ProviderUrl = MetaObject.Get(typeof(Provider))["ProviderUrl"];
			public static readonly MetaProperty ProviderStatusId = MetaObject.Get(typeof(Provider))["ProviderStatusId"];
			public static readonly MetaProperty DisplayName = MetaObject.Get(typeof(Provider))["DisplayName"];
			public static readonly MetaProperty PackageStatus = MetaObject.Get(typeof(Provider))["PackageStatus"];
			public static readonly MetaProperty Description = MetaObject.Get(typeof(Provider))["Description"];
			public static readonly MetaProperty TagLine = MetaObject.Get(typeof(Provider))["TagLine"];
			public static readonly MetaProperty Version = MetaObject.Get(typeof(Provider))["Version"];
			public static readonly MetaProperty AlertAllowed = MetaObject.Get(typeof(Provider))["AlertAllowed"];
			public static readonly MetaProperty LaunchDate = MetaObject.Get(typeof(Provider))["LaunchDate"];
			public static readonly MetaProperty IsCustomize = MetaObject.Get(typeof(Provider))["IsCustomize"];
			public static readonly MetaProperty IsPersonalLinks = MetaObject.Get(typeof(Provider))["IsPersonalLinks"];
			public static readonly MetaProperty IsNetscape = MetaObject.Get(typeof(Provider))["IsNetscape"];
			public static readonly MetaProperty ClientVersion = MetaObject.Get(typeof(Provider))["ClientVersion"];
			public static readonly MetaProperty ServiceImageId = MetaObject.Get(typeof(Provider))["ServiceImageId"];
			public static readonly MetaProperty AlertImageId = MetaObject.Get(typeof(Provider))["AlertImageId"];
			public static readonly MetaProperty WebImageId = MetaObject.Get(typeof(Provider))["WebImageId"];
			public static readonly MetaProperty InfEmailFrom = MetaObject.Get(typeof(Provider))["InfEmailFrom"];
			public static readonly MetaProperty StyleVersion = MetaObject.Get(typeof(Provider))["StyleVersion"];
			public static readonly MetaProperty IsRmp = MetaObject.Get(typeof(Provider))["IsRmp"];
			public static readonly MetaProperty IsSpsDirect = MetaObject.Get(typeof(Provider))["IsSpsDirect"];
			public static readonly MetaProperty IsOfflineInstall = MetaObject.Get(typeof(Provider))["IsOfflineInstall"];
			public static readonly MetaProperty IsQueSignOn = MetaObject.Get(typeof(Provider))["IsQueSignOn"];
			public static readonly MetaProperty ContactName = MetaObject.Get(typeof(Provider))["ContactName"];
			public static readonly MetaProperty ContactTitle = MetaObject.Get(typeof(Provider))["ContactTitle"];
			public static readonly MetaProperty ContactEmail = MetaObject.Get(typeof(Provider))["ContactEmail"];
			public static readonly MetaProperty ContactPhone = MetaObject.Get(typeof(Provider))["ContactPhone"];
			public static readonly MetaProperty DirectTracking = MetaObject.Get(typeof(Provider))["DirectTracking"];
			public static readonly MetaProperty CheckUpdateInterval = MetaObject.Get(typeof(Provider))["CheckUpdateInterval"];
			public static readonly MetaProperty IsForceClientUpdate = MetaObject.Get(typeof(Provider))["IsForceClientUpdate"];
			public static readonly MetaProperty WebinterImageId = MetaObject.Get(typeof(Provider))["WebinterImageId"];
			public static readonly MetaProperty IsSystrayVisible = MetaObject.Get(typeof(Provider))["IsSystrayVisible"];
			public static readonly MetaProperty IsButtons = MetaObject.Get(typeof(Provider))["IsButtons"];
			public static readonly MetaProperty IsArrange = MetaObject.Get(typeof(Provider))["IsArrange"];
			public static readonly MetaProperty IsMenus = MetaObject.Get(typeof(Provider))["IsMenus"];
			public static readonly MetaProperty IsSettings = MetaObject.Get(typeof(Provider))["IsSettings"];
			public static readonly MetaProperty IsSkins = MetaObject.Get(typeof(Provider))["IsSkins"];
			public static readonly MetaProperty IsNotifications = MetaObject.Get(typeof(Provider))["IsNotifications"];
			public static readonly MetaProperty IsCorporate = MetaObject.Get(typeof(Provider))["IsCorporate"];
			public static readonly MetaProperty IsDemo = MetaObject.Get(typeof(Provider))["IsDemo"];
			public static readonly MetaProperty AltHomepage = MetaObject.Get(typeof(Provider))["AltHomepage"];
			public static readonly MetaProperty IsReportEnabled = MetaObject.Get(typeof(Provider))["IsReportEnabled"];
			public static readonly MetaProperty CreatedAt = MetaObject.Get(typeof(Provider))["CreatedAt"];
			public static readonly MetaProperty ProductStatus = MetaObject.Get(typeof(Provider))["ProductStatus"];
			public static readonly MetaProperty ContactAddress = MetaObject.Get(typeof(Provider))["ContactAddress"];
			public static readonly MetaProperty ContactPhone2 = MetaObject.Get(typeof(Provider))["ContactPhone2"];
			public static readonly MetaProperty SystrayImageId = MetaObject.Get(typeof(Provider))["SystrayImageId"];
			public static readonly MetaProperty BrowserImageId = MetaObject.Get(typeof(Provider))["BrowserImageId"];
			public static readonly MetaProperty IsBrowserVisible = MetaObject.Get(typeof(Provider))["IsBrowserVisible"];
			public static readonly MetaProperty ProviderVersion = MetaObject.Get(typeof(Provider))["ProviderVersion"];
			public static readonly MetaProperty IsMydetails = MetaObject.Get(typeof(Provider))["IsMydetails"];
			public static readonly MetaProperty SupportsOfflineActivations = MetaObject.Get(typeof(Provider))["SupportsOfflineActivations"];
			public static readonly MetaProperty SignOnTempCuInterval = MetaObject.Get(typeof(Provider))["SignOnTempCuInterval"];
			public static readonly MetaProperty IsDeskbar = MetaObject.Get(typeof(Provider))["IsDeskbar"];
			public static readonly MetaProperty IsRightClickMenu = MetaObject.Get(typeof(Provider))["IsRightClickMenu"];
			public static readonly MetaProperty IsIe = MetaObject.Get(typeof(Provider))["IsIe"];
			public static readonly MetaProperty ClearDfHlForNewUser = MetaObject.Get(typeof(Provider))["ClearDfHlForNewUser"];
			public static readonly MetaProperty ClearAlertHlForNewUser = MetaObject.Get(typeof(Provider))["ClearAlertHlForNewUser"];
			public static readonly MetaProperty ToolbarName = MetaObject.Get(typeof(Provider))["ToolbarName"];
			public static readonly MetaProperty WtbToolbarBehavior = MetaObject.Get(typeof(Provider))["WtbToolbarBehavior"];
			public static readonly MetaProperty WtbToolbarIconTextBehavior = MetaObject.Get(typeof(Provider))["WtbToolbarIconTextBehavior"];
			public static readonly MetaProperty WtbSearchBoxSize = MetaObject.Get(typeof(Provider))["WtbSearchBoxSize"];
			public static readonly MetaProperty SsnForceCleanupInterval = MetaObject.Get(typeof(Provider))["SsnForceCleanupInterval"];
			public static readonly MetaProperty SsnInactiveCleanupInterval = MetaObject.Get(typeof(Provider))["SsnInactiveCleanupInterval"];
			public static readonly MetaProperty SsnWebTimeoutInterval = MetaObject.Get(typeof(Provider))["SsnWebTimeoutInterval"];
			public static readonly MetaProperty IsSelfRegistration = MetaObject.Get(typeof(Provider))["IsSelfRegistration"];
			public static readonly MetaProperty SsnPersistenceOption = MetaObject.Get(typeof(Provider))["SsnPersistenceOption"];
			public static readonly MetaProperty ShowUninstallYn = MetaObject.Get(typeof(Provider))["ShowUninstallYn"];
			public static readonly MetaProperty AutohideForceexposeType = MetaObject.Get(typeof(Provider))["AutohideForceexposeType"];
			public static readonly MetaProperty AutohideForceexposeTime = MetaObject.Get(typeof(Provider))["AutohideForceexposeTime"];
			public static readonly MetaProperty SslCsiYn = MetaObject.Get(typeof(Provider))["SslCsiYn"];
			public static readonly MetaProperty SslWebYn = MetaObject.Get(typeof(Provider))["SslWebYn"];
			public static readonly MetaProperty ClientObjectName = MetaObject.Get(typeof(Provider))["ClientObjectName"];
			public static readonly MetaProperty ClientClassId = MetaObject.Get(typeof(Provider))["ClientClassId"];
			public static readonly MetaProperty RunServiceSyncYn = MetaObject.Get(typeof(Provider))["RunServiceSyncYn"];
			public static readonly MetaProperty RunGroupSyncYn = MetaObject.Get(typeof(Provider))["RunGroupSyncYn"];
			public static readonly MetaProperty RunLuaSyncYn = MetaObject.Get(typeof(Provider))["RunLuaSyncYn"];
			public static readonly MetaProperty RunLayoutSyncYn = MetaObject.Get(typeof(Provider))["RunLayoutSyncYn"];
			public static readonly MetaProperty RunBtnLayoutSyncAlwaysYn = MetaObject.Get(typeof(Provider))["RunBtnLayoutSyncAlwaysYn"];
			public static readonly MetaProperty PlsMaxCount = MetaObject.Get(typeof(Provider))["PlsMaxCount"];
			public static readonly MetaProperty PlsMinPollInterval = MetaObject.Get(typeof(Provider))["PlsMinPollInterval"];
			public static readonly MetaProperty UninstallMessageOption = MetaObject.Get(typeof(Provider))["UninstallMessageOption"];
			public static readonly MetaProperty DismissRightClickNotifierYn = MetaObject.Get(typeof(Provider))["DismissRightClickNotifierYn"];
			public static readonly MetaProperty RepUserId = MetaObject.Get(typeof(Provider))["RepUserId"];
			public static readonly MetaProperty RepUserLocked = MetaObject.Get(typeof(Provider))["RepUserLocked"];
			public static readonly MetaProperty SystrayButtonId = MetaObject.Get(typeof(Provider))["SystrayButtonId"];
			public static readonly MetaProperty RclickButtonId = MetaObject.Get(typeof(Provider))["RclickButtonId"];
			public static readonly MetaProperty QuUserType = MetaObject.Get(typeof(Provider))["QuUserType"];
			public static readonly MetaProperty QuActiveUsersOnly = MetaObject.Get(typeof(Provider))["QuActiveUsersOnly"];
			public static readonly MetaProperty SystrayMenuVersion = MetaObject.Get(typeof(Provider))["SystrayMenuVersion"];
			public static readonly MetaProperty RclickMenuVersion = MetaObject.Get(typeof(Provider))["RclickMenuVersion"];
			public static readonly MetaProperty ProfileVersion = MetaObject.Get(typeof(Provider))["ProfileVersion"];
			public static readonly MetaProperty DateFormat = MetaObject.Get(typeof(Provider))["DateFormat"];
			public static readonly MetaProperty TimeFormat = MetaObject.Get(typeof(Provider))["TimeFormat"];
			public static readonly MetaProperty UserAuthOption = MetaObject.Get(typeof(Provider))["UserAuthOption"];
			public static readonly MetaProperty DeletedUserPrvid = MetaObject.Get(typeof(Provider))["DeletedUserPrvid"];
			public static readonly MetaProperty DisabledUserPrvid = MetaObject.Get(typeof(Provider))["DisabledUserPrvid"];
			public static readonly MetaProperty ScurMaxPct = MetaObject.Get(typeof(Provider))["ScurMaxPct"];
			public static readonly MetaProperty EmailAckType = MetaObject.Get(typeof(Provider))["EmailAckType"];
			public static readonly MetaProperty EmailAckServer = MetaObject.Get(typeof(Provider))["EmailAckServer"];
			public static readonly MetaProperty EmailAckUsername = MetaObject.Get(typeof(Provider))["EmailAckUsername"];
			public static readonly MetaProperty EmailAckPassword = MetaObject.Get(typeof(Provider))["EmailAckPassword"];
			public static readonly MetaProperty EmailPubType = MetaObject.Get(typeof(Provider))["EmailPubType"];
			public static readonly MetaProperty EmailPubServer = MetaObject.Get(typeof(Provider))["EmailPubServer"];
			public static readonly MetaProperty EmailPubUsername = MetaObject.Get(typeof(Provider))["EmailPubUsername"];
			public static readonly MetaProperty EmailPubPassword = MetaObject.Get(typeof(Provider))["EmailPubPassword"];
			public static readonly MetaProperty AudioSpeakerVolume = MetaObject.Get(typeof(Provider))["AudioSpeakerVolume"];
			public static readonly MetaProperty AudioForceSpeaker = MetaObject.Get(typeof(Provider))["AudioForceSpeaker"];
			public static readonly MetaProperty UseCustomNewEndUserPage = MetaObject.Get(typeof(Provider))["UseCustomNewEndUserPage"];
			public static readonly MetaProperty SystrayLayout = MetaObject.Get(typeof(Provider))["SystrayLayout"];
		}
		#endregion Properties

    }

	#region ProviderMeta
	public partial class ProviderMeta
	{
	}
	#endregion ProviderMeta
}
