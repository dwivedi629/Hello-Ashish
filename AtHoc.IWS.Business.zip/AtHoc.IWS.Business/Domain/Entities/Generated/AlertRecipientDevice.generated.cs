﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Encryption;

namespace AtHoc.IWS.Business.Domain.Entities
{
	[MetadataType(typeof(AlertRecipientDeviceMeta))]
	[MetaObject(TableName = "OLP_ALERT_RECIPIENT_DEVICE_TAB")]
	public partial class AlertRecipientDevice : EntityBase
	{

		[MetaProperty(ColumnName = "ALERT_ID", DbTypeName = "int")]
		[Required]
		public virtual int AlertId
		{
			get { return this.Get<int>("AlertId"); }
			set { this.Set<int>("AlertId", value); }
		}

		[MetaProperty(ColumnName = "USER_ID", DbTypeName = "int")]
		[Required]
		public virtual int UserId
		{
			get { return this.Get<int>("UserId"); }
			set { this.Set<int>("UserId", value); }
		}

		[MetaProperty(ColumnName = "DEVICE_ID", DbTypeName = "int")]
		[Required]
		public virtual int DeviceId
		{
			get { return this.Get<int>("DeviceId"); }
			set { this.Set<int>("DeviceId", value); }
		}

		[MetaProperty(ColumnName = "SESSION_ID", DbTypeName = "int")]
		public virtual int? SessionId
		{
			get { return this.Get<int?>("SessionId"); }
			set { this.Set<int?>("SessionId", value); }
		}

		[MetaProperty(ColumnName = "EXTERNAL_ALERT_ID", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string ExternalAlertId
		{
			get { return this.Get<string>("ExternalAlertId"); }
			set { this.Set<string>("ExternalAlertId", value); }
		}

		[MetaProperty(ColumnName = "DELIVERY_STATUS", DbTypeName = "int")]
		public virtual int? DeliveryStatus
		{
			get { return this.Get<int?>("DeliveryStatus"); }
			set { this.Set<int?>("DeliveryStatus", value); }
		}

		[MetaProperty(ColumnName = "STATUS_UPDATED_ON", DbTypeName = "int")]
		public virtual int? StatusUpdatedOn
		{
			get { return this.Get<int?>("StatusUpdatedOn"); }
			set { this.Set<int?>("StatusUpdatedOn", value); }
		}

		[MetaProperty(ColumnName = "HIGHLIGHT_STATE", DbTypeName = "int")]
		public virtual int? HighlightState
		{
			get { return this.Get<int?>("HighlightState"); }
			set { this.Set<int?>("HighlightState", value); }
		}

		[MetaProperty(ColumnName = "RESPONSE_TEXT", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string ResponseText
		{
			get { return this.Get<string>("ResponseText"); }
			set { this.Set<string>("ResponseText", value); }
		}

		[MetaProperty(ColumnName = "DELIVERY_ORDER", DbTypeName = "int")]
		public virtual int? DeliveryOrder
		{
			get { return this.Get<int?>("DeliveryOrder"); }
			set { this.Set<int?>("DeliveryOrder", value); }
		}

		[MetaProperty(ColumnName = "ADDRESS_ID", DbTypeName = "int")]
		public virtual int? AddressId
		{
			get { return this.Get<int?>("AddressId"); }
			set { this.Set<int?>("AddressId", value); }
		}

		[MetaProperty(ColumnName = "ADDRESS", DbTypeName = "nvarchar", MaxLength = 2000, AutoTrim = true)]
		[MaxLength(2000)]
		public virtual string Address
		{
			get { return this.Get<string>("Address"); }
			set { this.Set<string>("Address", value); }
		}

		[MetaProperty(ColumnName = "ADDRESS_LABEL", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string AddressLabel
		{
			get { return this.Get<string>("AddressLabel"); }
			set { this.Set<string>("AddressLabel", value); }
		}

		[MetaProperty(ColumnName = "RAW_ADDRESS", DbTypeName = "nvarchar", MaxLength = 2000, AutoTrim = true)]
		[MaxLength(2000)]
		public virtual string RawAddress
		{
			get { return this.Get<string>("RawAddress"); }
			set { this.Set<string>("RawAddress", value); }
		}

		[MetaProperty(ColumnName = "PROXY_ID", DbTypeName = "nvarchar", MaxLength = 20, AutoTrim = true)]
		[MaxLength(20)]
		public virtual string ProxyId
		{
			get { return this.Get<string>("ProxyId"); }
			set { this.Set<string>("ProxyId", value); }
		}

		[MetaProperty(ColumnName = "BATCH_ID", DbTypeName = "int")]
		public virtual int? BatchId
		{
			get { return this.Get<int?>("BatchId"); }
			set { this.Set<int?>("BatchId", value); }
		}

		[MetaProperty(ColumnName = "HASH_RAW_ADDRESS", DbTypeName = "binary")]
		public virtual byte[] HashRawAddress
		{
			get { return this.Get<byte[]>("HashRawAddress"); }
			set { this.Set<byte[]>("HashRawAddress", value); }
		}


		#region Properties
		public class Meta
		{
			public static readonly MetaProperty AlertId = MetaObject.Get(typeof(AlertRecipientDevice))["AlertId"];
			public static readonly MetaProperty UserId = MetaObject.Get(typeof(AlertRecipientDevice))["UserId"];
			public static readonly MetaProperty DeviceId = MetaObject.Get(typeof(AlertRecipientDevice))["DeviceId"];
			public static readonly MetaProperty SessionId = MetaObject.Get(typeof(AlertRecipientDevice))["SessionId"];
			public static readonly MetaProperty ExternalAlertId = MetaObject.Get(typeof(AlertRecipientDevice))["ExternalAlertId"];
			public static readonly MetaProperty DeliveryStatus = MetaObject.Get(typeof(AlertRecipientDevice))["DeliveryStatus"];
			public static readonly MetaProperty StatusUpdatedOn = MetaObject.Get(typeof(AlertRecipientDevice))["StatusUpdatedOn"];
			public static readonly MetaProperty HighlightState = MetaObject.Get(typeof(AlertRecipientDevice))["HighlightState"];
			public static readonly MetaProperty ResponseText = MetaObject.Get(typeof(AlertRecipientDevice))["ResponseText"];
			public static readonly MetaProperty DeliveryOrder = MetaObject.Get(typeof(AlertRecipientDevice))["DeliveryOrder"];
			public static readonly MetaProperty AddressId = MetaObject.Get(typeof(AlertRecipientDevice))["AddressId"];
			public static readonly MetaProperty Address = MetaObject.Get(typeof(AlertRecipientDevice))["Address"];
			public static readonly MetaProperty AddressLabel = MetaObject.Get(typeof(AlertRecipientDevice))["AddressLabel"];
			public static readonly MetaProperty RawAddress = MetaObject.Get(typeof(AlertRecipientDevice))["RawAddress"];
			public static readonly MetaProperty ProxyId = MetaObject.Get(typeof(AlertRecipientDevice))["ProxyId"];
			public static readonly MetaProperty BatchId = MetaObject.Get(typeof(AlertRecipientDevice))["BatchId"];
			public static readonly MetaProperty HashRawAddress = MetaObject.Get(typeof(AlertRecipientDevice))["HashRawAddress"];
		}
		#endregion Properties

	}

	#region AlertRecipientDeviceMeta
	public partial class AlertRecipientDeviceMeta
	{
	}
	#endregion AlertRecipientDeviceMeta
}
