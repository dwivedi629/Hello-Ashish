﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Encryption;

namespace AtHoc.IWS.Business.Domain.Entities
{
	[MetadataType(typeof(CustomAttributeMeta))]
	[MetaObject(TableName = "PRV_ATTRIBUTE_TAB")]
	public partial class CustomAttribute : EntityBase
	{
		[MetaProperty(ColumnName = "ATTRIBUTE_ID", DbTypeName = "int", IsKey = true, SequenceType = "ATTRIBUTEID")]
		[Required]
		public virtual int Id
		{
			get { return this.Get<int>("Id"); }
			set { this.Set<int>("Id", value); }
		}

		[MetaProperty(ColumnName = "PROVIDER_ID", DbTypeName = "int")]
		[Required]
		public virtual int ProviderId
		{
			get { return this.Get<int>("ProviderId"); }
			set { this.Set<int>("ProviderId", value); }
		}

		[MetaProperty(ColumnName = "ENTITY_ID", DbTypeName = "nvarchar", MaxLength = 50, AutoTrim = true)]
		[MaxLength(50)]
		public virtual string EntityId
		{
			get { return this.Get<string>("EntityId"); }
			set { this.Set<string>("EntityId", value); }
		}

		[MetaProperty(ColumnName = "ATTRIBUTE_NAME", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string AttributeName
		{
			get { return this.Get<string>("AttributeName"); }
			set { this.Set<string>("AttributeName", value); }
		}

		[MetaProperty(ColumnName = "ATTRIBUTE_TYPE_ID", DbTypeName = "int")]
		public virtual CustomAttributeDataType? AttributeTypeId
		{
			get { return this.Get<CustomAttributeDataType?>("AttributeTypeId"); }
			set { this.Set<CustomAttributeDataType?>("AttributeTypeId", value); }
		}

		[MetaProperty(ColumnName = "COMMON_NAME", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string CommonName
		{
			get
			{
				var value = this.Get<string>("CommonName");
				return value.HasValue() ? value : AttributeName;
			}
			set { this.Set<string>("CommonName", value); }
		}

		[MetaProperty(ColumnName = "DEFAULT_VALUE", DbTypeName = "nvarchar", MaxLength = 4000, AutoTrim = true)]
		[MaxLength(4000)]
		public virtual string DefaultValue
		{
			get { return this.Get<string>("DefaultValue"); }
			set { this.Set<string>("DefaultValue", value); }
		}

		[MetaProperty(ColumnName = "MIN_VALUE", DbTypeName = "nvarchar", MaxLength = 30, AutoTrim = true)]
		[MaxLength(30)]
		public virtual string MinValue
		{
			get { return this.Get<string>("MinValue"); }
			set { this.Set<string>("MinValue", value); }
		}

		[MetaProperty(ColumnName = "MAX_VALUE", DbTypeName = "nvarchar", MaxLength = 30, AutoTrim = true)]
		[MaxLength(30)]
		public virtual string MaxValue
		{
			get { return this.Get<string>("MaxValue"); }
			set { this.Set<string>("MaxValue", value); }
		}

		[MetaProperty(ColumnName = "IS_MANDATORY", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsMandatory
		{
			get { return this.Get<string>("IsMandatory"); }
			set { this.Set<string>("IsMandatory", value); }
		}

		[MetaProperty(ColumnName = "IS_MAPPED", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsMapped
		{
			get { return this.Get<string>("IsMapped"); }
			set { this.Set<string>("IsMapped", value); }
		}

		[MetaProperty(ColumnName = "REQUIRES_CONFIRMATION", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string RequiresConfirmation
		{
			get { return this.Get<string>("RequiresConfirmation"); }
			set { this.Set<string>("RequiresConfirmation", value); }
		}

		[MetaProperty(ColumnName = "IS_AUTO_POSTBACK", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsAutoPostback
		{
			get { return this.Get<string>("IsAutoPostback"); }
			set { this.Set<string>("IsAutoPostback", value); }
		}

		[MetaProperty(ColumnName = "IS_SYNCHRONIZED", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsSynchronized
		{
			get { return this.Get<string>("IsSynchronized"); }
			set { this.Set<string>("IsSynchronized", value); }
		}

		[MetaProperty(ColumnName = "SYNC_SOURCE", DbTypeName = "nvarchar", MaxLength = 20, AutoTrim = true)]
		[MaxLength(20)]
		public virtual string SyncSource
		{
			get { return this.Get<string>("SyncSource"); }
			set { this.Set<string>("SyncSource", value); }
		}

		[MetaProperty(ColumnName = "DESCRIPTION", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string Description
		{
			get { return this.Get<string>("Description"); }
			set { this.Set<string>("Description", value); }
		}

		[MetaProperty(ColumnName = "VALIDATION_TYPE", DbTypeName = "int")]
		public virtual int? ValidationType
		{
			get { return this.Get<int?>("ValidationType"); }
			set { this.Set<int?>("ValidationType", value); }
		}

		[MetaProperty(ColumnName = "VALIDATION_PAYLOAD", DbTypeName = "nvarchar", MaxLength = 500, AutoTrim = true)]
		[MaxLength(500)]
		public virtual string ValidationPayload
		{
			get { return this.Get<string>("ValidationPayload"); }
			set { this.Set<string>("ValidationPayload", value); }
		}

		[MetaProperty(ColumnName = "MAPPED_ATTRIBUTE_PAYLOAD", DbTypeName = "nvarchar", MaxLength = 500, AutoTrim = true)]
		[MaxLength(500)]
		public virtual string MappedAttributePayload
		{
			get { return this.Get<string>("MappedAttributePayload"); }
			set { this.Set<string>("MappedAttributePayload", value); }
		}

		[MetaProperty(ColumnName = "IS_ENCRYPTED", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsEncrypted
		{
			get { return this.Get<string>("IsEncrypted"); }
			set { this.Set<string>("IsEncrypted", value); }
		}

		[MetaProperty(ColumnName = "EDIT_LEVEL", DbTypeName = "int")]
		public virtual int? EditLevel
		{
			get { return this.Get<int?>("EditLevel"); }
			set { this.Set<int?>("EditLevel", value); }
		}

		[MetaProperty(ColumnName = "CREATED_ON", DbTypeName = "int")]
		public virtual int? CreatedOn
		{
			get { return this.Get<int?>("CreatedOn"); }
			set { this.Set<int?>("CreatedOn", value); }
		}

		[MetaProperty(ColumnName = "CREATED_BY", DbTypeName = "int")]
		public virtual int? CreatedBy
		{
			get { return this.Get<int?>("CreatedBy"); }
			set { this.Set<int?>("CreatedBy", value); }
		}

		[MetaProperty(ColumnName = "UPDATED_ON", DbTypeName = "int")]
		public virtual int? UpdatedOn
		{
			get { return this.Get<int?>("UpdatedOn"); }
			set { this.Set<int?>("UpdatedOn", value); }
		}

		[MetaProperty(ColumnName = "UPDATED_BY", DbTypeName = "int")]
		public virtual int? UpdatedBy
		{
			get { return this.Get<int?>("UpdatedBy"); }
			set { this.Set<int?>("UpdatedBy", value); }
		}

		[MetaProperty(ColumnName = "STATUS", DbTypeName = "nvarchar", MaxLength = 3, AutoTrim = true)]
		[MaxLength(3)]
		public virtual string Status
		{
			get { return this.Get<string>("Status"); }
			set { this.Set<string>("Status", value); }
		}

		[MetaProperty(ColumnName = "IS_SYSTEM_ATTRIBUTE", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsSystemAttribute
		{
			get { return this.Get<string>("IsSystemAttribute"); }
			set { this.Set<string>("IsSystemAttribute", value); }
		}

		[MetaProperty(ColumnName = "HIERARCHY_ID", DbTypeName = "int")]
		public virtual int? HierarchyId
		{
			get { return this.Get<int?>("HierarchyId"); }
			set { this.Set<int?>("HierarchyId", value); }
		}

		[MetaProperty(ColumnName = "FIELD_DELIMITER", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string FieldDelimiter
		{
			get { return this.Get<string>("FieldDelimiter"); }
			set { this.Set<string>("FieldDelimiter", value); }
		}

		[MetaProperty(ColumnName = "HELP_TEXT", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string HelpText
		{
			get { return this.Get<string>("HelpText"); }
			set { this.Set<string>("HelpText", value); }
		}

		[MetaProperty(ColumnName = "DISPLAY_DROP_DOWN", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string DisplayDropDown
		{
			get { return this.Get<string>("DisplayDropDown"); }
			set { this.Set<string>("DisplayDropDown", value); }
		}

		[MetaProperty(ColumnName = "IS_SEARCHABLE", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsSearchable
		{
			get { return this.Get<string>("IsSearchable"); }
			set { this.Set<string>("IsSearchable", value); }
		}

		[MetaProperty(ColumnName = "UPDATE_ONLY_ONCE", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string UpdateOnlyOnce
		{
			get { return this.Get<string>("UpdateOnlyOnce"); }
			set { this.Set<string>("UpdateOnlyOnce", value); }
		}

		[MetaProperty(ColumnName = "IS_STANDARD", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsStandard
		{
			get { return this.Get<string>("IsStandard"); }
			set { this.Set<string>("IsStandard", value); }
		}

		[MetaProperty(ColumnName = "SUPPORTS_HISTORICAL_VALUES", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string SupportsHistoricalValues
		{
			get { return this.Get<string>("SupportsHistoricalValues"); }
			set { this.Set<string>("SupportsHistoricalValues", value); }
		}

		[MetaProperty(ColumnName = "ICON_ID", DbTypeName = "int")]
		public virtual int? IconId
		{
			get { return this.Get<int?>("IconId"); }
			set { this.Set<int?>("IconId", value); }
		}

		[MetaProperty(ColumnName = "TEXT_LINE_NUMBERS", DbTypeName = "int")]
		public virtual int? TextLineNumbers
		{
			get { return this.Get<int?>("TextLineNumbers"); }
			set { this.Set<int?>("TextLineNumbers", value); }
		}


		#region Properties
		public class Meta
		{
			public static readonly MetaProperty Id = MetaObject.Get(typeof(CustomAttribute))["Id"];
			public static readonly MetaProperty ProviderId = MetaObject.Get(typeof(CustomAttribute))["ProviderId"];
			public static readonly MetaProperty EntityId = MetaObject.Get(typeof(CustomAttribute))["EntityId"];
			public static readonly MetaProperty AttributeName = MetaObject.Get(typeof(CustomAttribute))["AttributeName"];
			public static readonly MetaProperty AttributeTypeId = MetaObject.Get(typeof(CustomAttribute))["AttributeTypeId"];
			public static readonly MetaProperty CommonName = MetaObject.Get(typeof(CustomAttribute))["CommonName"];
			public static readonly MetaProperty DefaultValue = MetaObject.Get(typeof(CustomAttribute))["DefaultValue"];
			public static readonly MetaProperty MinValue = MetaObject.Get(typeof(CustomAttribute))["MinValue"];
			public static readonly MetaProperty MaxValue = MetaObject.Get(typeof(CustomAttribute))["MaxValue"];
			public static readonly MetaProperty IsMandatory = MetaObject.Get(typeof(CustomAttribute))["IsMandatory"];
			public static readonly MetaProperty IsMapped = MetaObject.Get(typeof(CustomAttribute))["IsMapped"];
			public static readonly MetaProperty RequiresConfirmation = MetaObject.Get(typeof(CustomAttribute))["RequiresConfirmation"];
			public static readonly MetaProperty IsAutoPostback = MetaObject.Get(typeof(CustomAttribute))["IsAutoPostback"];
			public static readonly MetaProperty IsSynchronized = MetaObject.Get(typeof(CustomAttribute))["IsSynchronized"];
			public static readonly MetaProperty SyncSource = MetaObject.Get(typeof(CustomAttribute))["SyncSource"];
			public static readonly MetaProperty Description = MetaObject.Get(typeof(CustomAttribute))["Description"];
			public static readonly MetaProperty ValidationType = MetaObject.Get(typeof(CustomAttribute))["ValidationType"];
			public static readonly MetaProperty ValidationPayload = MetaObject.Get(typeof(CustomAttribute))["ValidationPayload"];
			public static readonly MetaProperty MappedAttributePayload = MetaObject.Get(typeof(CustomAttribute))["MappedAttributePayload"];
			public static readonly MetaProperty IsEncrypted = MetaObject.Get(typeof(CustomAttribute))["IsEncrypted"];
			public static readonly MetaProperty EditLevel = MetaObject.Get(typeof(CustomAttribute))["EditLevel"];
			public static readonly MetaProperty CreatedOn = MetaObject.Get(typeof(CustomAttribute))["CreatedOn"];
			public static readonly MetaProperty CreatedBy = MetaObject.Get(typeof(CustomAttribute))["CreatedBy"];
			public static readonly MetaProperty UpdatedOn = MetaObject.Get(typeof(CustomAttribute))["UpdatedOn"];
			public static readonly MetaProperty UpdatedBy = MetaObject.Get(typeof(CustomAttribute))["UpdatedBy"];
			public static readonly MetaProperty Status = MetaObject.Get(typeof(CustomAttribute))["Status"];
			public static readonly MetaProperty IsSystemAttribute = MetaObject.Get(typeof(CustomAttribute))["IsSystemAttribute"];
			public static readonly MetaProperty HierarchyId = MetaObject.Get(typeof(CustomAttribute))["HierarchyId"];
			public static readonly MetaProperty FieldDelimiter = MetaObject.Get(typeof(CustomAttribute))["FieldDelimiter"];
			public static readonly MetaProperty HelpText = MetaObject.Get(typeof(CustomAttribute))["HelpText"];
			public static readonly MetaProperty DisplayDropDown = MetaObject.Get(typeof(CustomAttribute))["DisplayDropDown"];
			public static readonly MetaProperty IsSearchable = MetaObject.Get(typeof(CustomAttribute))["IsSearchable"];
			public static readonly MetaProperty UpdateOnlyOnce = MetaObject.Get(typeof(CustomAttribute))["UpdateOnlyOnce"];
			public static readonly MetaProperty IsStandard = MetaObject.Get(typeof(CustomAttribute))["IsStandard"];
			public static readonly MetaProperty SupportsHistoricalValues = MetaObject.Get(typeof(CustomAttribute))["SupportsHistoricalValues"];
			public static readonly MetaProperty IconId = MetaObject.Get(typeof(CustomAttribute))["IconId"];
			public static readonly MetaProperty TextLineNumbers = MetaObject.Get(typeof(CustomAttribute))["TextLineNumbers"];
		    public static readonly MetaProperty AttributeOrigin = MetaObject.Get(typeof (CustomAttribute))["AttributeOrigin"];
            public static readonly MetaProperty AttributeType = MetaObject.Get(typeof (CustomAttribute))["AttributeType"];
		}
		#endregion Properties

    }

	#region CustomAttributeMeta
	public partial class CustomAttributeMeta
	{
	}
	#endregion CustomAttributeMeta
}
