﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using AtHoc.Business.Domain;
using AtHoc.Infrastructure.Domain;
using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Encryption;
using AtHoc.IWS.Business.Domain.Audit;

namespace AtHoc.IWS.Business.Domain.Entities
{
    [MetadataType(typeof(OperatorAuditMeta))]
	[MetaObject(TableName = "UPS_AUDIT_TAB")]
	public partial class OperatorAudit : EntityBase
    {

		[MetaProperty(ColumnName = "AUDIT_ID", DbTypeName = "int")]
		[Required]
		public virtual int AuditId
		{
			get { return this.Get<int>("AuditId"); }
			set { this.Set<int>("AuditId", value); }
		}

		[MetaProperty(ColumnName = "USER_ID", DbTypeName = "int")]
		public virtual int? UserId
		{
			get { return this.Get<int?>("UserId"); }
			set { this.Set<int?>("UserId", value); }
		}

		[MetaProperty(ColumnName = "USERNAME", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
		public virtual string Username
		{
			get { return this.Get<string>("Username"); }
			set { this.Set<string>("Username", value); }
		}

		[MetaProperty(ColumnName = "PROVIDER_ID", DbTypeName = "int")]
		public virtual int? ProviderId
		{
			get { return this.Get<int?>("ProviderId"); }
			set { this.Set<int?>("ProviderId", value); }
		}

		[MetaProperty(ColumnName = "ACTION_ID", DbTypeName = "nvarchar", MaxLength = 10, AutoTrim = true)]
		[MaxLength(10)]
		public virtual ServiceAction ActionId
		{
			get { return this.Get<ServiceAction>("ActionId"); }
			set { this.Set<ServiceAction>("ActionId", value); }
		}

		[MetaProperty(ColumnName = "ACTION_TIMESTAMP", DbTypeName = "int")]
		[Required]
		public virtual IntDateTime ActionDateTime
		{
			get { return this.Get<IntDateTime>("ActionDateTime"); }
			set { this.Set<IntDateTime>("ActionDateTime", value); }
		}

		[MetaProperty(ColumnName = "ACTION_DATE", DbTypeName = "int")]
		public virtual IntDateTime ActionDate
		{
			get { return this.Get<IntDateTime>("ActionDate"); }
			set { this.Set<IntDateTime>("ActionDate", value); }
		}

		[MetaProperty(ColumnName = "OBJECT_TYPE", DbTypeName = "nvarchar", MaxLength = 10, AutoTrim = true)]
		[MaxLength(10)]
		public virtual EntityType ObjectType
		{
			get { return this.Get<EntityType>("ObjectType"); }
			set { this.Set<EntityType>("ObjectType", value); }
		}

		[MetaProperty(ColumnName = "OBJECT_ID", DbTypeName = "int")]
		public virtual int? ObjectId
		{
			get { return this.Get<int?>("ObjectId"); }
			set { this.Set<int?>("ObjectId", value); }
		}

		[MetaProperty(ColumnName = "OBJECT_NAME", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string ObjectName
		{
			get { return this.Get<string>("ObjectName"); }
			set { this.Set<string>("ObjectName", value); }
		}

		[MetaProperty(ColumnName = "CLIENT_IP", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string ClientIp
		{
			get { return this.Get<string>("ClientIp"); }
			set { this.Set<string>("ClientIp", value); }
		}

		[MetaProperty(ColumnName = "SOURCE", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
		public virtual string Source
		{
			get { return this.Get<string>("Source"); }
			set { this.Set<string>("Source", value); }
		}

		[MetaProperty(ColumnName = "SERVER_NAME", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
		public virtual string ServerName
		{
			get { return this.Get<string>("ServerName"); }
			set { this.Set<string>("ServerName", value); }
		}

		[MetaProperty(ColumnName = "ADDITIONAL_INFO", DbTypeName = "nvarchar", AutoTrim = true)]
		public virtual string AdditionalInfo
		{
			get { return this.Get<string>("AdditionalInfo"); }
			set { this.Set<string>("AdditionalInfo", value); }
		}

		[MetaProperty(ColumnName = "STATUS", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string Status
		{
			get { return this.Get<string>("Status"); }
			set { this.Set<string>("Status", value); }
		}


		#region Properties
		public class Meta
		{
			public static readonly MetaProperty AuditId = MetaObject.Get(typeof(OperatorAudit))["AuditId"];
			public static readonly MetaProperty UserId = MetaObject.Get(typeof(OperatorAudit))["UserId"];
			public static readonly MetaProperty Username = MetaObject.Get(typeof(OperatorAudit))["Username"];
			public static readonly MetaProperty ProviderId = MetaObject.Get(typeof(OperatorAudit))["ProviderId"];
			public static readonly MetaProperty ActionId = MetaObject.Get(typeof(OperatorAudit))["ActionId"];
			public static readonly MetaProperty ActionTimestamp = MetaObject.Get(typeof(OperatorAudit))["ActionDateTime"];
			public static readonly MetaProperty ActionDate = MetaObject.Get(typeof(OperatorAudit))["ActionDate"];
			public static readonly MetaProperty ObjectType = MetaObject.Get(typeof(OperatorAudit))["ObjectType"];
			public static readonly MetaProperty ObjectId = MetaObject.Get(typeof(OperatorAudit))["ObjectId"];
			public static readonly MetaProperty ObjectName = MetaObject.Get(typeof(OperatorAudit))["ObjectName"];
			public static readonly MetaProperty ClientIp = MetaObject.Get(typeof(OperatorAudit))["ClientIp"];
			public static readonly MetaProperty Source = MetaObject.Get(typeof(OperatorAudit))["Source"];
			public static readonly MetaProperty ServerName = MetaObject.Get(typeof(OperatorAudit))["ServerName"];
			public static readonly MetaProperty AdditionalInfo = MetaObject.Get(typeof(OperatorAudit))["AdditionalInfo"];
			public static readonly MetaProperty Status = MetaObject.Get(typeof(OperatorAudit))["Status"];
		}
		#endregion Properties

    }

	#region OperatorAuditMeta
	public partial class OperatorAuditMeta
	{
	}
	#endregion OperatorAuditMeta
}
