﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Encryption;

namespace AtHoc.IWS.Business.Domain.Entities
{
    [MetadataType(typeof(ExtendedParamsMeta))]
	[MetaObject(TableName = "PRV_EXTENDED_PARAMS_TAB")]
	public partial class ExtendedParams : EntityBase
    {

		[MetaProperty(ColumnName = "PROVIDER_ID", DbTypeName = "int", IsKey = true)]
		[Required]
		public virtual int Id
		{
			get { return this.Get<int>("Id"); }
			set { this.Set<int>("Id", value); }
		}

		[MetaProperty(ColumnName = "SUPPORT_EMAIL", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string SupportEmail
		{
			get { return this.Get<string>("SupportEmail"); }
			set { this.Set<string>("SupportEmail", value); }
		}

		[MetaProperty(ColumnName = "CLIENT_SENDLOG_EMAIL", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string ClientSendlogEmail
		{
			get { return this.Get<string>("ClientSendlogEmail"); }
			set { this.Set<string>("ClientSendlogEmail", value); }
		}

		[MetaProperty(ColumnName = "INFORMATION_BANNER", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string InformationBanner
		{
			get { return this.Get<string>("InformationBanner"); }
			set { this.Set<string>("InformationBanner", value); }
		}

		[MetaProperty(ColumnName = "RUN_DSW_AFTER_INSTALL", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string RunDswAfterInstall
		{
			get { return this.Get<string>("RunDswAfterInstall"); }
			set { this.Set<string>("RunDswAfterInstall", value); }
		}

		[MetaProperty(ColumnName = "PACKAGE_AUDIO_FOR_DSW", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string PackageAudioForDsw
		{
			get { return this.Get<string>("PackageAudioForDsw"); }
			set { this.Set<string>("PackageAudioForDsw", value); }
		}

		[MetaProperty(ColumnName = "DSW_VERSION", DbTypeName = "nvarchar", MaxLength = 20, AutoTrim = true)]
		[MaxLength(20)]
		public virtual string DswVersion
		{
			get { return this.Get<string>("DswVersion"); }
			set { this.Set<string>("DswVersion", value); }
		}

		[MetaProperty(ColumnName = "DSW_FILE_CONTENT", DbTypeName = "image", MaxLength = 16, AutoTrim = true)]
		[MaxLength(16)]
		public virtual string DswFileContent
		{
			get { return this.Get<string>("DswFileContent"); }
			set { this.Set<string>("DswFileContent", value); }
		}

		[MetaProperty(ColumnName = "DSW_STATUS", DbTypeName = "nvarchar", MaxLength = 3, AutoTrim = true)]
		[MaxLength(3)]
		public virtual string DswStatus
		{
			get { return this.Get<string>("DswStatus"); }
			set { this.Set<string>("DswStatus", value); }
		}

		[MetaProperty(ColumnName = "DSW_UPDATED_ON", DbTypeName = "int")]
		public virtual int? DswUpdatedOn
		{
			get { return this.Get<int?>("DswUpdatedOn"); }
			set { this.Set<int?>("DswUpdatedOn", value); }
		}

		[MetaProperty(ColumnName = "DSW_STATUS_UPDATED_ON", DbTypeName = "int")]
		public virtual int? DswStatusUpdatedOn
		{
			get { return this.Get<int?>("DswStatusUpdatedOn"); }
			set { this.Set<int?>("DswStatusUpdatedOn", value); }
		}

		[MetaProperty(ColumnName = "WELCOME_MESSAGE", DbTypeName = "nvarchar", MaxLength = 1000, AutoTrim = true)]
		[MaxLength(1000)]
		public virtual string WelcomeMessage
		{
			get { return this.Get<string>("WelcomeMessage"); }
			set { this.Set<string>("WelcomeMessage", value); }
		}

		[MetaProperty(ColumnName = "DSW_ENABLE_STATUS_POPUP", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string DswEnableStatusPopup
		{
			get { return this.Get<string>("DswEnableStatusPopup"); }
			set { this.Set<string>("DswEnableStatusPopup", value); }
		}

		[MetaProperty(ColumnName = "DISPLAY_LOGO_ON_WEB_APP", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string DisplayLogoOnWebApp
		{
			get { return this.Get<string>("DisplayLogoOnWebApp"); }
			set { this.Set<string>("DisplayLogoOnWebApp", value); }
		}

		[MetaProperty(ColumnName = "EUM_SHOW_SUBSCRIPTION", DbTypeName = "nchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string EumShowSubscription
		{
			get { return this.Get<string>("EumShowSubscription"); }
			set { this.Set<string>("EumShowSubscription", value); }
		}

		[MetaProperty(ColumnName = "EUM_SHOW_SESSION", DbTypeName = "nchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string EumShowSession
		{
			get { return this.Get<string>("EumShowSession"); }
			set { this.Set<string>("EumShowSession", value); }
		}

		[MetaProperty(ColumnName = "WEB_IMAGE_TOOL_TIP", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
		public virtual string WebImageToolTip
		{
			get { return this.Get<string>("WebImageToolTip"); }
			set { this.Set<string>("WebImageToolTip", value); }
		}

		[MetaProperty(ColumnName = "WEB_IMAGE_ALTERNATE_TEXT", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
		public virtual string WebImageAlternateText
		{
			get { return this.Get<string>("WebImageAlternateText"); }
			set { this.Set<string>("WebImageAlternateText", value); }
		}

		[MetaProperty(ColumnName = "SS_HEADER_TEXT", DbTypeName = "nvarchar", MaxLength = 500, AutoTrim = true)]
		[MaxLength(500)]
		public virtual string SsHeaderText
		{
			get { return this.Get<string>("SsHeaderText"); }
			set { this.Set<string>("SsHeaderText", value); }
		}

		[MetaProperty(ColumnName = "SS_TAB_LAYOUT", DbTypeName = "text", MaxLength = 16, AutoTrim = true)]
		[MaxLength(16)]
		public virtual string SsTabLayout
		{
			get { return this.Get<string>("SsTabLayout"); }
			set { this.Set<string>("SsTabLayout", value); }
		}

		[MetaProperty(ColumnName = "DSW_STOP_CU_ON_SCREENSAVER", DbTypeName = "nchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string DswStopCuOnScreensaver
		{
			get { return this.Get<string>("DswStopCuOnScreensaver"); }
			set { this.Set<string>("DswStopCuOnScreensaver", value); }
		}

		[MetaProperty(ColumnName = "TERMS_AND_CONDITIONS_LINK", DbTypeName = "nvarchar", MaxLength = 300, AutoTrim = true)]
		[MaxLength(300)]
		public virtual string TermsAndConditionsLink
		{
			get { return this.Get<string>("TermsAndConditionsLink"); }
			set { this.Set<string>("TermsAndConditionsLink", value); }
		}

		[MetaProperty(ColumnName = "SS_AUTH_OPTION", DbTypeName = "nvarchar", MaxLength = 10, AutoTrim = true)]
		[MaxLength(10)]
		public virtual string SsAuthOption
		{
			get { return this.Get<string>("SsAuthOption"); }
			set { this.Set<string>("SsAuthOption", value); }
		}

		[MetaProperty(ColumnName = "DSW_SIGNON_MAPPING_API", DbTypeName = "nvarchar", MaxLength = 300, AutoTrim = true)]
		[MaxLength(300)]
		public virtual string DswSignonMappingApi
		{
			get { return this.Get<string>("DswSignonMappingApi"); }
			set { this.Set<string>("DswSignonMappingApi", value); }
		}

		[MetaProperty(ColumnName = "DSW_START_WARMUP_TIME", DbTypeName = "int")]
		public virtual int? DswStartWarmupTime
		{
			get { return this.Get<int?>("DswStartWarmupTime"); }
			set { this.Set<int?>("DswStartWarmupTime", value); }
		}

		[MetaProperty(ColumnName = "DEFAULT_SCENARIO_FOR_NEW_ALERT", DbTypeName = "int")]
		public virtual int? DefaultScenarioForNewAlert
		{
			get { return this.Get<int?>("DefaultScenarioForNewAlert"); }
			set { this.Set<int?>("DefaultScenarioForNewAlert", value); }
		}

		[MetaProperty(ColumnName = "DEFAULT_SCENARIO_FOR_NEW_SCENARIO", DbTypeName = "int")]
		public virtual int? DefaultScenarioForNewScenario
		{
			get { return this.Get<int?>("DefaultScenarioForNewScenario"); }
			set { this.Set<int?>("DefaultScenarioForNewScenario", value); }
		}

		[MetaProperty(ColumnName = "SS_TERMS_CONDITIONS_LABEL", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
		public virtual string SsTermsConditionsLabel
		{
			get { return this.Get<string>("SsTermsConditionsLabel"); }
			set { this.Set<string>("SsTermsConditionsLabel", value); }
		}

		[MetaProperty(ColumnName = "GEO_TARGETING_ACTIVATED", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string GeoTargetingActivated
		{
			get { return this.Get<string>("GeoTargetingActivated"); }
			set { this.Set<string>("GeoTargetingActivated", value); }
		}

		[MetaProperty(ColumnName = "ANONYMIZE_USER_INFO_ON_DELETE", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string AnonymizeUserInfoOnDelete
		{
			get { return this.Get<string>("AnonymizeUserInfoOnDelete"); }
			set { this.Set<string>("AnonymizeUserInfoOnDelete", value); }
		}

		[MetaProperty(ColumnName = "DSW_CERTIFICATE_COLLECT_MODE", DbTypeName = "int")]
		public virtual int? DswCertificateCollectMode
		{
			get { return this.Get<int?>("DswCertificateCollectMode"); }
			set { this.Set<int?>("DswCertificateCollectMode", value); }
		}

		[MetaProperty(ColumnName = "EXPORT_DATA_YN", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string ExportDataYn
		{
			get { return this.Get<string>("ExportDataYn"); }
			set { this.Set<string>("ExportDataYn", value); }
		}

		[MetaProperty(ColumnName = "DSW_RECONNECT_INTERVAL", DbTypeName = "int")]
		public virtual int? DswReconnectInterval
		{
			get { return this.Get<int?>("DswReconnectInterval"); }
			set { this.Set<int?>("DswReconnectInterval", value); }
		}

		[MetaProperty(ColumnName = "DSW_RECOVERY_INTERVAL", DbTypeName = "int")]
		public virtual int? DswRecoveryInterval
		{
			get { return this.Get<int?>("DswRecoveryInterval"); }
			set { this.Set<int?>("DswRecoveryInterval", value); }
		}

		[MetaProperty(ColumnName = "DSW_RECONNECT_WINDOW", DbTypeName = "int")]
		public virtual int? DswReconnectWindow
		{
			get { return this.Get<int?>("DswReconnectWindow"); }
			set { this.Set<int?>("DswReconnectWindow", value); }
		}

		[MetaProperty(ColumnName = "DSW_LISTENER_ACTIVE_YN", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string DswListenerActiveYn
		{
			get { return this.Get<string>("DswListenerActiveYn"); }
			set { this.Set<string>("DswListenerActiveYn", value); }
		}

		[MetaProperty(ColumnName = "DSW_RETRIES", DbTypeName = "int")]
		public virtual int? DswRetries
		{
			get { return this.Get<int?>("DswRetries"); }
			set { this.Set<int?>("DswRetries", value); }
		}

		[MetaProperty(ColumnName = "GEO_LONGITUDE", DbTypeName = "nvarchar", MaxLength = 50, AutoTrim = true)]
		[MaxLength(50)]
		public virtual string GeoLongitude
		{
			get { return this.Get<string>("GeoLongitude"); }
			set { this.Set<string>("GeoLongitude", value); }
		}

		[MetaProperty(ColumnName = "GEO_LATITUDE", DbTypeName = "nvarchar", MaxLength = 50, AutoTrim = true)]
		[MaxLength(50)]
		public virtual string GeoLatitude
		{
			get { return this.Get<string>("GeoLatitude"); }
			set { this.Set<string>("GeoLatitude", value); }
		}

		[MetaProperty(ColumnName = "TGT_CTRL_DEFAULT_TAB", DbTypeName = "nvarchar", MaxLength = 5, AutoTrim = true)]
		[MaxLength(5)]
		public virtual string TgtCtrlDefaultTab
		{
			get { return this.Get<string>("TgtCtrlDefaultTab"); }
			set { this.Set<string>("TgtCtrlDefaultTab", value); }
		}

		[MetaProperty(ColumnName = "TIME_ZONE_REGION_ID", DbTypeName = "nvarchar", MaxLength = 50, AutoTrim = true)]
		[MaxLength(50)]
		public virtual string TimeZoneRegionId
		{
			get { return this.Get<string>("TimeZoneRegionId"); }
			set { this.Set<string>("TimeZoneRegionId", value); }
		}

        [MetaProperty(ColumnName = "ORG_CODE", DbTypeName = "nvarchar", MaxLength = 300, AutoTrim = true)]
        [MaxLength(300)]
        public virtual string OrgCode
        {
            get { return this.Get<string>("OrgCode"); }
            set { this.Set<string>("OrgCode", value); }
        }

        [MetaProperty(ColumnName = "PROVIDER_TYPE", DbTypeName = "nvarchar", MaxLength = 20, AutoTrim = true)]
        [MaxLength(20)]
        public virtual string ProviderType
        {
            get { return this.Get<string>("ProviderType"); }
            set { this.Set<string>("ProviderType", value); }
        }

        [MetaProperty(ColumnName = "COUNTRY_CODE", DbTypeName = "nvarchar", MaxLength = 20, AutoTrim = true)]
        [MaxLength(20)]
        public virtual string CountryCode
        {
            get { return this.Get<string>("CountryCode"); }
            set { this.Set<string>("CountryCode", value); }
        }

        [MetaProperty(ColumnName = "ISO_COUNTRY_CODE", DbTypeName = "nvarchar", MaxLength = 20, AutoTrim = true)]
        public virtual string IsoCountryCode
        {

            get { return this.Get<string>("IsoCountryCode"); }
            set { this.Set<string>("IsoCountryCode", value); }
        }


        [MetaProperty(ColumnName = "SS_SECURITY_DISCLAIMER_TEXT", DbTypeName = "nvarchar", MaxLength = 1024, AutoTrim = true)]
        public virtual string SSSecurityDisclaimerText
        {

            get { return this.Get<string>("SSSecurityDisclaimerText"); }
            set { this.Set<string>("SSSecurityDisclaimerText", value); }
        }
      
       #region Properties
		public class Meta
		{
			public static readonly MetaProperty Id = MetaObject.Get(typeof(ExtendedParams))["Id"];
			public static readonly MetaProperty SupportEmail = MetaObject.Get(typeof(ExtendedParams))["SupportEmail"];
			public static readonly MetaProperty ClientSendlogEmail = MetaObject.Get(typeof(ExtendedParams))["ClientSendlogEmail"];
			public static readonly MetaProperty InformationBanner = MetaObject.Get(typeof(ExtendedParams))["InformationBanner"];
			public static readonly MetaProperty RunDswAfterInstall = MetaObject.Get(typeof(ExtendedParams))["RunDswAfterInstall"];
			public static readonly MetaProperty PackageAudioForDsw = MetaObject.Get(typeof(ExtendedParams))["PackageAudioForDsw"];
			public static readonly MetaProperty DswVersion = MetaObject.Get(typeof(ExtendedParams))["DswVersion"];
			public static readonly MetaProperty DswFileContent = MetaObject.Get(typeof(ExtendedParams))["DswFileContent"];
			public static readonly MetaProperty DswStatus = MetaObject.Get(typeof(ExtendedParams))["DswStatus"];
			public static readonly MetaProperty DswUpdatedOn = MetaObject.Get(typeof(ExtendedParams))["DswUpdatedOn"];
			public static readonly MetaProperty DswStatusUpdatedOn = MetaObject.Get(typeof(ExtendedParams))["DswStatusUpdatedOn"];
			public static readonly MetaProperty WelcomeMessage = MetaObject.Get(typeof(ExtendedParams))["WelcomeMessage"];
			public static readonly MetaProperty DswEnableStatusPopup = MetaObject.Get(typeof(ExtendedParams))["DswEnableStatusPopup"];
			public static readonly MetaProperty DisplayLogoOnWebApp = MetaObject.Get(typeof(ExtendedParams))["DisplayLogoOnWebApp"];
			public static readonly MetaProperty EumShowSubscription = MetaObject.Get(typeof(ExtendedParams))["EumShowSubscription"];
			public static readonly MetaProperty EumShowSession = MetaObject.Get(typeof(ExtendedParams))["EumShowSession"];
			public static readonly MetaProperty WebImageToolTip = MetaObject.Get(typeof(ExtendedParams))["WebImageToolTip"];
			public static readonly MetaProperty WebImageAlternateText = MetaObject.Get(typeof(ExtendedParams))["WebImageAlternateText"];
			public static readonly MetaProperty SsHeaderText = MetaObject.Get(typeof(ExtendedParams))["SsHeaderText"];
			public static readonly MetaProperty SsTabLayout = MetaObject.Get(typeof(ExtendedParams))["SsTabLayout"];
			public static readonly MetaProperty DswStopCuOnScreensaver = MetaObject.Get(typeof(ExtendedParams))["DswStopCuOnScreensaver"];
			public static readonly MetaProperty TermsAndConditionsLink = MetaObject.Get(typeof(ExtendedParams))["TermsAndConditionsLink"];
			public static readonly MetaProperty SsAuthOption = MetaObject.Get(typeof(ExtendedParams))["SsAuthOption"];
			public static readonly MetaProperty DswSignonMappingApi = MetaObject.Get(typeof(ExtendedParams))["DswSignonMappingApi"];
			public static readonly MetaProperty DswStartWarmupTime = MetaObject.Get(typeof(ExtendedParams))["DswStartWarmupTime"];
			public static readonly MetaProperty DefaultScenarioForNewAlert = MetaObject.Get(typeof(ExtendedParams))["DefaultScenarioForNewAlert"];
			public static readonly MetaProperty DefaultScenarioForNewScenario = MetaObject.Get(typeof(ExtendedParams))["DefaultScenarioForNewScenario"];
			public static readonly MetaProperty SsTermsConditionsLabel = MetaObject.Get(typeof(ExtendedParams))["SsTermsConditionsLabel"];
			public static readonly MetaProperty GeoTargetingActivated = MetaObject.Get(typeof(ExtendedParams))["GeoTargetingActivated"];
			public static readonly MetaProperty AnonymizeUserInfoOnDelete = MetaObject.Get(typeof(ExtendedParams))["AnonymizeUserInfoOnDelete"];
			public static readonly MetaProperty DswCertificateCollectMode = MetaObject.Get(typeof(ExtendedParams))["DswCertificateCollectMode"];
			public static readonly MetaProperty ExportDataYn = MetaObject.Get(typeof(ExtendedParams))["ExportDataYn"];
			public static readonly MetaProperty DswReconnectInterval = MetaObject.Get(typeof(ExtendedParams))["DswReconnectInterval"];
			public static readonly MetaProperty DswRecoveryInterval = MetaObject.Get(typeof(ExtendedParams))["DswRecoveryInterval"];
			public static readonly MetaProperty DswReconnectWindow = MetaObject.Get(typeof(ExtendedParams))["DswReconnectWindow"];
			public static readonly MetaProperty DswListenerActiveYn = MetaObject.Get(typeof(ExtendedParams))["DswListenerActiveYn"];
			public static readonly MetaProperty DswRetries = MetaObject.Get(typeof(ExtendedParams))["DswRetries"];
			public static readonly MetaProperty GeoLongitude = MetaObject.Get(typeof(ExtendedParams))["GeoLongitude"];
			public static readonly MetaProperty GeoLatitude = MetaObject.Get(typeof(ExtendedParams))["GeoLatitude"];
			public static readonly MetaProperty TgtCtrlDefaultTab = MetaObject.Get(typeof(ExtendedParams))["TgtCtrlDefaultTab"];
			public static readonly MetaProperty TimeZoneRegionId = MetaObject.Get(typeof(ExtendedParams))["TimeZoneRegionId"];
            public static readonly MetaProperty OrgCode = MetaObject.Get(typeof(ExtendedParams))["OrgCode"];
            public static readonly MetaProperty ProviderType = MetaObject.Get(typeof(ExtendedParams))["ProviderType"];
            public static readonly MetaProperty CountryCode = MetaObject.Get(typeof(ExtendedParams))["CountryCode"];
            public static readonly MetaProperty IsoCountryCode = MetaObject.Get(typeof(ExtendedParams))["IsoCountryCode"];
            public static readonly MetaProperty SSSecurityDisclaimerText = MetaObject.Get(typeof(ExtendedParams))["SSSecurityDisclaimerText"];
          //  public static readonly MetaProperty SSSecurityDisclaimerEnabled = MetaObject.Get(typeof(ExtendedParams))["SSSecurityDisclaimerEnabled"];
		}
		#endregion Properties

    }

	#region ExtendedParamsMeta
	public partial class ExtendedParamsMeta
	{
	}
	#endregion ExtendedParamsMeta
}
