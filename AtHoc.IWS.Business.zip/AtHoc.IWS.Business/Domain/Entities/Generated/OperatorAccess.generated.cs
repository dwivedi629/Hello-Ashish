﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Encryption;

namespace AtHoc.IWS.Business.Domain.Entities
{
    [MetadataType(typeof(OperatorAccessMeta))]
	[MetaObject(TableName = "UPS_ACCESS_TAB")]
	public partial class OperatorAccess : EntityBase
    {
		[MetaProperty(ColumnName = "ROLE_ID", DbTypeName = "int")]
		[Required]
		public virtual int RoleId
		{
			get { return this.Get<int>("RoleId"); }
			set { this.Set<int>("RoleId", value); }
		}

		[MetaProperty(ColumnName = "ACTION_ID", DbTypeName = "int")]
		[Required]
		public virtual ActionType ActionType
		{
			get { return this.Get<ActionType>("ActionType"); }
			set { this.Set<ActionType>("ActionType", value); }
		}

		[MetaProperty(ColumnName = "OBJECT_ID", DbTypeName = "int")]
		[Required]
		public virtual int ObjectId
		{
			get { return this.Get<int>("ObjectId"); }
			set { this.Set<int>("ObjectId", value); }
		}


		#region Properties
		public class Meta
		{
			public static readonly MetaProperty RoleId = MetaObject.Get(typeof(OperatorAccess))["RoleId"];
			public static readonly MetaProperty ActionType = MetaObject.Get(typeof(OperatorAccess))["ActionType"];
			public static readonly MetaProperty ObjectId = MetaObject.Get(typeof(OperatorAccess))["ObjectId"];
		}
		#endregion Properties

    }

	#region OperatorAccessMeta
	public partial class OperatorAccessMeta
	{
	}
	#endregion OperatorAccessMeta
}
