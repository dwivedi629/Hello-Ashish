﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Encryption;

namespace AtHoc.IWS.Business.Domain.Entities
{
    [MetadataType(typeof(PagerCarrierMeta))]
	[MetaObject(TableName = "DLV_PAGER_CARRIER_TAB")]
	public partial class PagerCarrier : EntityBase
    {

		[MetaProperty(ColumnName = "Id", DbTypeName = "int", IsKey = true, IsIdentity = true)]
		[Required]
		public virtual int Id
		{
			get { return this.Get<int>("Id"); }
			set { this.Set<int>("Id", value); }
		}

		[MetaProperty(ColumnName = "CarrierId", DbTypeName = "int")]
		[Required]
		public virtual int Carrierid
		{
			get { return this.Get<int>("Carrierid"); }
			set { this.Set<int>("Carrierid", value); }
		}

		[MetaProperty(ColumnName = "CarrierName", DbTypeName = "nvarchar", MaxLength = 255, AutoTrim = true)]
		[MaxLength(255)]
		[Required]
		public virtual string Carriername
		{
			get { return this.Get<string>("Carriername"); }
			set { this.Set<string>("Carriername", value); }
		}


		#region Properties
		public class Meta
		{
			public static readonly MetaProperty Id = MetaObject.Get(typeof(PagerCarrier))["Id"];
			public static readonly MetaProperty Carrierid = MetaObject.Get(typeof(PagerCarrier))["Carrierid"];
			public static readonly MetaProperty Carriername = MetaObject.Get(typeof(PagerCarrier))["Carriername"];
		}
		#endregion Properties

    }

	#region PagerCarrierMeta
	public partial class PagerCarrierMeta
	{
	}
	#endregion PagerCarrierMeta
}

#warning Temporary solution due to lack of time on release (repository and specs as well). Proper fix - 2 tables: dictionary and map table.

namespace AtHoc.IWS.Business.Domain.Entities
{
	[MetadataType(typeof(PagerCarrierEntityMeta))]
	[MetaObject(TableName = "USR_PAGER_CARRIER_VUE")]
	public partial class PagerCarrierEntity : EntityBase
	{
		[MetaProperty(ColumnName = "CarrierId", DbTypeName = "int")]
		[Required]
		public virtual int Carrierid
		{
			get { return this.Get<int>("Carrierid"); }
			set { this.Set<int>("Carrierid", value); }
		}

		[MetaProperty(ColumnName = "CarrierName", DbTypeName = "nvarchar", MaxLength = 255, AutoTrim = true)]
		[MaxLength(255)]
		[Required]
		public virtual string Carriername
		{
			get { return this.Get<string>("Carriername"); }
			set { this.Set<string>("Carriername", value); }
		}

		#region Properties
		public class Meta
		{
			public static readonly MetaProperty Carrierid = MetaObject.Get(typeof(PagerCarrierEntity))["Carrierid"];
			public static readonly MetaProperty Carriername = MetaObject.Get(typeof(PagerCarrierEntity))["Carriername"];
		}
		#endregion Properties

	}

	#region PagerCarrierEntityMeta
	public partial class PagerCarrierEntityMeta
	{
	}
	#endregion PagerCarrierEntityMeta
}