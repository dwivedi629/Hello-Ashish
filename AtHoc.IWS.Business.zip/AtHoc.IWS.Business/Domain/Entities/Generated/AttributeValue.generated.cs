﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Encryption;

namespace AtHoc.IWS.Business.Domain.Entities
{
    [MetadataType(typeof(AttributeValueMeta))]
	[MetaObject(TableName = "USR_ATTRIBUTE_VALUE_TAB")]
	public partial class AttributeValue : EntityBase
    {

		[MetaProperty(ColumnName = "USER_ID", DbTypeName = "int")]
		[Required]
		public virtual int UserId
		{
			get { return this.Get<int>("UserId"); }
			set { this.Set<int>("UserId", value); }
		}

		[MetaProperty(ColumnName = "ATTRIBUTE_ID", DbTypeName = "int")]
		[Required]
		public virtual int AttributeId
		{
			get { return this.Get<int>("AttributeId"); }
			set { this.Set<int>("AttributeId", value); }
		}

		[MetaProperty(ColumnName = "VALUE_ID", DbTypeName = "int")]
		public virtual int? ValueId
		{
			get { return this.Get<int?>("ValueId"); }
			set { this.Set<int?>("ValueId", value); }
		}

		[MetaProperty(ColumnName = "PRIORITY", DbTypeName = "int")]
		public virtual int? Priority
		{
			get { return this.Get<int?>("Priority"); }
			set { this.Set<int?>("Priority", value); }
		}

		[MetaProperty(ColumnName = "INTEGER_VALUE", DbTypeName = "int")]
		public virtual int? IntegerValue
		{
			get { return this.Get<int?>("IntegerValue"); }
			set { this.Set<int?>("IntegerValue", value); }
		}

		[MetaProperty(ColumnName = "STRING_VALUE", DbTypeName = "nvarchar", MaxLength = 440, AutoTrim = true)]
		[MaxLength(440)]
		public virtual string StringValue
		{
			get { return this.Get<string>("StringValue"); }
			set { this.Set<string>("StringValue", value); }
		}

		[MetaProperty(ColumnName = "MEMO_VALUE", DbTypeName = "nvarchar", AutoTrim = true)]
		public virtual string MemoValue
		{
			get { return this.Get<string>("MemoValue"); }
			set { this.Set<string>("MemoValue", value); }
		}

		[MetaProperty(ColumnName = "IS_NEW", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		[Obsolete]
		public virtual string IsNew_
		{
			get { return this.Get<string>("IsNew_"); }
			set { this.Set<string>("IsNew_", value); }
		}

		[MetaProperty(ColumnName = "UPDATED_ON", DbTypeName = "int")]
		public virtual int? UpdatedOn
		{
			get { return this.Get<int?>("UpdatedOn"); }
			set { this.Set<int?>("UpdatedOn", value); }
		}

		[MetaProperty(ColumnName = "UPDATED_BY", DbTypeName = "int")]
		public virtual int? UpdatedBy
		{
			get { return this.Get<int?>("UpdatedBy"); }
			set { this.Set<int?>("UpdatedBy", value); }
		}

		[MetaProperty(ColumnName = "DATE_VALUE", DbTypeName = "datetime")]
		public virtual DateTime? DateValue
		{
			get { return this.Get<DateTime?>("DateValue"); }
			set { this.Set<DateTime?>("DateValue", value); }
		}
        
		[MetaProperty(ColumnName = "UPDATED_FROM", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string UpdatedFrom
		{
			get { return this.Get<string>("UpdatedFrom"); }
			set { this.Set<string>("UpdatedFrom", value); }
		}

		[MetaProperty(ColumnName = "ROW_INDEX", DbTypeName = "int", IsKey = true, IsIdentity = true)]
		[Required]
		public virtual int Id
		{
			get { return this.Get<int>("Id"); }
			set { this.Set<int>("Id", value); }
		}


		#region Properties
		public class Meta
		{
			public static readonly MetaProperty UserId = MetaObject.Get(typeof(AttributeValue))["UserId"];
			public static readonly MetaProperty AttributeId = MetaObject.Get(typeof(AttributeValue))["AttributeId"];
			public static readonly MetaProperty ValueId = MetaObject.Get(typeof(AttributeValue))["ValueId"];
			public static readonly MetaProperty Priority = MetaObject.Get(typeof(AttributeValue))["Priority"];
			public static readonly MetaProperty IntegerValue = MetaObject.Get(typeof(AttributeValue))["IntegerValue"];
			public static readonly MetaProperty StringValue = MetaObject.Get(typeof(AttributeValue))["StringValue"];
			public static readonly MetaProperty MemoValue = MetaObject.Get(typeof(AttributeValue))["MemoValue"];
			public static readonly MetaProperty IsNew_ = MetaObject.Get(typeof(AttributeValue))["IsNew_"];
			public static readonly MetaProperty UpdatedOn = MetaObject.Get(typeof(AttributeValue))["UpdatedOn"];
			public static readonly MetaProperty UpdatedBy = MetaObject.Get(typeof(AttributeValue))["UpdatedBy"];
			public static readonly MetaProperty DateValue = MetaObject.Get(typeof(AttributeValue))["DateValue"];
			public static readonly MetaProperty GeoValue = MetaObject.Get(typeof(AttributeValue))["GeoValue"];
			public static readonly MetaProperty UpdatedFrom = MetaObject.Get(typeof(AttributeValue))["UpdatedFrom"];
			public static readonly MetaProperty Id = MetaObject.Get(typeof(AttributeValue))["Id"];
		}
		#endregion Properties

    }

	#region AttributeValueMeta
	public partial class AttributeValueMeta
	{
	}
	#endregion AttributeValueMeta
}
