﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Encryption;

namespace AtHoc.IWS.Business.Domain.Entities
{
	[MetadataType(typeof(UserMeta))]
	[MetaObject(TableName = "USR_USER_TAB")]
	public partial class User : EntityBase
	{
		[MetaProperty(ColumnName = "USER_ID", DbTypeName = "int", IsKey = true, SequenceType = "USER")]
		[Required]
		public virtual int Id
		{
			get { return this.Get<int>("Id"); }
			set { this.Set<int>("Id", value); }
		}

		[MetaProperty(ColumnName = "TOKEN", DbTypeName = "nvarchar", MaxLength = 10, AutoTrim = true)]
		[MaxLength(10)]
		[Required]
		public virtual string Token
		{
			get { return this.Get<string>("Token"); }
			set { this.Set<string>("Token", value); }
		}

		[MetaProperty(ColumnName = "USER_TYPE_ID", DbTypeName = "nvarchar", MaxLength = 3, AutoTrim = true)]
		[MaxLength(3)]
		[Required]
		public virtual string UserTypeId
		{
			get { return this.Get<string>("UserTypeId"); }
			set { this.Set<string>("UserTypeId", value); }
		}

		[MetaProperty(ColumnName = "PROVIDER_ID", DbTypeName = "int")]
		public virtual int? ProviderId
		{
			get { return this.Get<int?>("ProviderId"); }
			set { this.Set<int?>("ProviderId", value); }
		}

		[MetaProperty(ColumnName = "LAST_CHANGE", DbTypeName = "int")]
		public virtual int? LastChange
		{
			get { return this.Get<int?>("LastChange"); }
			set { this.Set<int?>("LastChange", value); }
		}

		[MetaProperty(ColumnName = "DISPLAY_NAME", DbTypeName = "nvarchar", MaxLength = 150, AutoTrim = true)]
		[MaxLength(150)]
		public virtual string DisplayName
		{
			get { return this.Get<string>("DisplayName"); }
			set { this.Set<string>("DisplayName", value); }
		}

		[MetaProperty(ColumnName = "CREATE_TYPE", DbTypeName = "nvarchar", MaxLength = 3, AutoTrim = true)]
		[MaxLength(3)]
		public virtual string CreateType
		{
			get { return this.Get<string>("CreateType"); }
			set { this.Set<string>("CreateType", value); }
		}

		[MetaProperty(ColumnName = "REGISTERED_ON", DbTypeName = "int")]
		public virtual int? RegisteredOn
		{
			get { return this.Get<int?>("RegisteredOn"); }
			set { this.Set<int?>("RegisteredOn", value); }
		}

		[MetaProperty(ColumnName = "SINGLE_NEXT_CHECK_UPDATE", DbTypeName = "int")]
		public virtual int? SingleNextCheckUpdate
		{
			get { return this.Get<int?>("SingleNextCheckUpdate"); }
			set { this.Set<int?>("SingleNextCheckUpdate", value); }
		}

		[MetaProperty(ColumnName = "TIME_ZONE", DbTypeName = "int")]
		public virtual int? TimeZone
		{
			get { return this.Get<int?>("TimeZone"); }
			set { this.Set<int?>("TimeZone", value); }
		}

		[MetaProperty(ColumnName = "TEMP_CU_INTERVAL", DbTypeName = "int")]
		public virtual int? TempCuInterval
		{
			get { return this.Get<int?>("TempCuInterval"); }
			set { this.Set<int?>("TempCuInterval", value); }
		}

		[MetaProperty(ColumnName = "LAST_CHECK_UPDATE", DbTypeName = "int")]
		public virtual int? LastCheckUpdate
		{
			get { return this.Get<int?>("LastCheckUpdate"); }
			set { this.Set<int?>("LastCheckUpdate", value); }
		}

		[MetaProperty(ColumnName = "LAST_TEMP_CU_UPDATE", DbTypeName = "int")]
		public virtual int? LastTempCuUpdate
		{
			get { return this.Get<int?>("LastTempCuUpdate"); }
			set { this.Set<int?>("LastTempCuUpdate", value); }
		}

		[MetaProperty(ColumnName = "NAV_POPUP_INDIRECT_YN", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string NavPopupIndirectYn
		{
			get { return this.Get<string>("NavPopupIndirectYn"); }
			set { this.Set<string>("NavPopupIndirectYn", value); }
		}

		[MetaProperty(ColumnName = "CHECK_UPDATE_VERSION", DbTypeName = "int")]
		public virtual int? CheckUpdateVersion
		{
			get { return this.Get<int?>("CheckUpdateVersion"); }
			set { this.Set<int?>("CheckUpdateVersion", value); }
		}

		[MetaProperty(ColumnName = "TRACKING_ANONYMIZATION_REQUIRED", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string TrackingAnonymizationRequired
		{
			get { return this.Get<string>("TrackingAnonymizationRequired"); }
			set { this.Set<string>("TrackingAnonymizationRequired", value); }
		}

		[MetaProperty(ColumnName = "DELETE_FULL_REQUIRED", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string DeleteFullRequired
		{
			get { return this.Get<string>("DeleteFullRequired"); }
			set { this.Set<string>("DeleteFullRequired", value); }
		}


		#region Properties
		public class Meta
		{
			public static readonly MetaProperty Id = MetaObject.Get(typeof(User))["Id"];
			public static readonly MetaProperty Token = MetaObject.Get(typeof(User))["Token"];
			public static readonly MetaProperty UserTypeId = MetaObject.Get(typeof(User))["UserTypeId"];
			public static readonly MetaProperty ProviderId = MetaObject.Get(typeof(User))["ProviderId"];
			public static readonly MetaProperty LastChange = MetaObject.Get(typeof(User))["LastChange"];
			public static readonly MetaProperty DisplayName = MetaObject.Get(typeof(User))["DisplayName"];
			public static readonly MetaProperty CreateType = MetaObject.Get(typeof(User))["CreateType"];
			public static readonly MetaProperty RegisteredOn = MetaObject.Get(typeof(User))["RegisteredOn"];
			public static readonly MetaProperty SingleNextCheckUpdate = MetaObject.Get(typeof(User))["SingleNextCheckUpdate"];
			public static readonly MetaProperty TimeZone = MetaObject.Get(typeof(User))["TimeZone"];
			public static readonly MetaProperty TempCuInterval = MetaObject.Get(typeof(User))["TempCuInterval"];
			public static readonly MetaProperty LastCheckUpdate = MetaObject.Get(typeof(User))["LastCheckUpdate"];
			public static readonly MetaProperty LastTempCuUpdate = MetaObject.Get(typeof(User))["LastTempCuUpdate"];
			public static readonly MetaProperty NavPopupIndirectYn = MetaObject.Get(typeof(User))["NavPopupIndirectYn"];
			public static readonly MetaProperty CheckUpdateVersion = MetaObject.Get(typeof(User))["CheckUpdateVersion"];
			public static readonly MetaProperty TrackingAnonymizationRequired = MetaObject.Get(typeof(User))["TrackingAnonymizationRequired"];
			public static readonly MetaProperty DeleteFullRequired = MetaObject.Get(typeof(User))["DeleteFullRequired"];
		}
		#endregion Properties

    }

	#region UserMeta
	public partial class UserMeta
	{
	}
	#endregion UserMeta
}
