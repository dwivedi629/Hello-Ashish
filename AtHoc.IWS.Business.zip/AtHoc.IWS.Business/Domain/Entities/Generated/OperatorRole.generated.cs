﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Encryption;
using AtHoc.Global.Resources.Entities;

namespace AtHoc.IWS.Business.Domain.Entities
{
	[MetadataType(typeof(OperatorRoleMeta))]
	[MetaObject(TableName = "UPS_ROLE_TAB")]
	public partial class OperatorRole : EntityBase
	{
		[MetaProperty(ColumnName = "ROLE_ID", DbTypeName = "int", IsKey = true)]
        [LocalizationEntityIdAttribute(BusinessEntity.OperatorRole)]
		[Required]
		public virtual int Id
		{
			get { return this.Get<int>("Id"); }
			set { this.Set<int>("Id", value); }
		}

		[MetaProperty(ColumnName = "ROLE_NAME", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
        [LocalizationEntityProperty(BusinessEntity.OperatorRole, "RoleName")]
		public virtual string RoleName
		{
			get { return this.Get<string>("RoleName"); }
			set { this.Set<string>("RoleName", value); }
		}

		[MetaProperty(ColumnName = "ROLE_TYPE", DbTypeName = "nvarchar", MaxLength = 3, AutoTrim = true)]
		[MaxLength(3)]
		public virtual string RoleType
		{
			get { return this.Get<string>("RoleType"); }
			set { this.Set<string>("RoleType", value); }
		}

		[MetaProperty(ColumnName = "STATUS", DbTypeName = "nvarchar", MaxLength = 3, AutoTrim = true)]
		[MaxLength(3)]
		public virtual string Status
		{
			get { return this.Get<string>("Status"); }
			set { this.Set<string>("Status", value); }
		}

		[MetaProperty(ColumnName = "DESCRIPTION", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
        [LocalizationEntityProperty(BusinessEntity.OperatorRole, "Description")]
		public virtual string Description
		{
			get { return this.Get<string>("Description"); }
			set { this.Set<string>("Description", value); }
		}

        [MetaProperty(ColumnName = "COMMON_NAME", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
        [MaxLength(200)]
        public virtual string CommonName
        {
            get { return this.Get<string>("CommonName"); }
            set { this.Set<string>("CommonName", value); }
        }

        [MetaProperty(ColumnName = "UNRESTRICTED_ALERTFOLDERS", DbTypeName = "varchar", MaxLength = 1, AutoTrim = true)]
        public virtual string UnrestrictedAlertFolders
        {
            get { return this.Get<string>("UnrestrictedAlertFolders"); }
            set { this.Set<string>("UnrestrictedAlertFolders", value); }
        }

        [MetaProperty(ColumnName = "UNRESTRICTED_USERBASE", DbTypeName = "varchar", MaxLength = 1, AutoTrim = true)]
        public virtual string UnrestrictedUserBase
        {
            get { return this.Get<string>("UnrestrictedUserBase"); }
            set { this.Set<string>("UnrestrictedUserBase", value); }
        }

        [MetaProperty(ColumnName = "UNRESTRICTED_ENTITYACCESS", DbTypeName = "varchar", MaxLength = 1, AutoTrim = true)]
        public virtual string UnrestrictedEntityAccess
        {
            get { return this.Get<string>("UnrestrictedEntityAccess"); }
            set { this.Set<string>("UnrestrictedEntityAccess", value); }
        }


		#region Properties
		public class Meta
		{
			public static readonly MetaProperty Id = MetaObject.Get(typeof(OperatorRole))["Id"];
			public static readonly MetaProperty RoleName = MetaObject.Get(typeof(OperatorRole))["RoleName"];
			public static readonly MetaProperty RoleType = MetaObject.Get(typeof(OperatorRole))["RoleType"];
			public static readonly MetaProperty Status = MetaObject.Get(typeof(OperatorRole))["Status"];
			public static readonly MetaProperty Description = MetaObject.Get(typeof(OperatorRole))["Description"];
            public static readonly MetaProperty CommonName = MetaObject.Get(typeof(OperatorObject))["CommonName"];
            public static readonly MetaProperty UnrestrictedAlertFolders = MetaObject.Get(typeof(OperatorRole))["UnrestrictedAlertFolders"];
            public static readonly MetaProperty UnrestrictedUserBase = MetaObject.Get(typeof(OperatorRole))["UnrestrictedUserBase"];
            public static readonly MetaProperty UnrestrictedEntityAccess = MetaObject.Get(typeof(OperatorObject))["UnrestrictedEntityAccess"];
		}
		#endregion Properties

    }

	#region OperatorRoleMeta
	public partial class OperatorRoleMeta
	{
	}
	#endregion OperatorRoleMeta
}
