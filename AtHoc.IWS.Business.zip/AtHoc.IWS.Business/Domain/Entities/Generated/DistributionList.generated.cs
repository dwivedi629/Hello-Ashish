﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Encryption;

namespace AtHoc.IWS.Business.Domain.Entities
{
    [MetadataType(typeof (DistributionListMeta))]
    [MetaObject(TableName = "PDL_LIST_TAB")]
    public partial class DistributionList : EntityBase
    {
        [MetaProperty(ColumnName = "LIST_ID", DbTypeName = "int", IsKey = true, SequenceType = "LISTID")]
        [Required]
        public virtual int Id
        {
            get { return this.Get<int>("Id"); }
            set { this.Set<int>("Id", value); }
        }

        [MetaProperty(ColumnName = "PROVIDER_ID", DbTypeName = "int")]
        [Required]
        public virtual int ProviderId
        {
            get { return this.Get<int>("ProviderId"); }
            set { this.Set<int>("ProviderId", value); }
        }

        [MetaProperty(ColumnName = "NAME", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
        [MaxLength(100)]
        public virtual string Name
        {
            get { return this.Get<string>("Name"); }
            set { this.Set<string>("Name", value); }
        }

        [MetaProperty(ColumnName = "LIST_TYPE", DbTypeName = "nvarchar")]
        [Required]
        public virtual ListItemType ListType
        {
            get { return this.Get<ListItemType>("ListType"); }
            set { this.Set<ListItemType>("ListType", value); }
        }

        [MetaProperty(ColumnName = "COMMON_NAME", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
        [MaxLength(100)]
        public virtual string CommonName
        {
            get { return this.Get<string>("CommonName"); }
            set { this.Set<string>("CommonName", value); }
        }

        [MetaProperty(ColumnName = "DESCRIPTION", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
        [MaxLength(200)]
        public virtual string Description
        {
            get { return this.Get<string>("Description"); }
            set { this.Set<string>("Description", value); }
        }

        [MetaProperty(ColumnName = "DEFINITION", DbTypeName = "nvarchar", AutoTrim = true)]
        public virtual string Definition
        {
            get { return this.Get<string>("Definition"); }
            set { this.Set<string>("Definition", value); }
        }

        [MetaProperty(ColumnName = "ATTRIBUTE_ID", DbTypeName = "int")]
        public virtual int? AttributeId
        {
            get { return this.Get<int?>("AttributeId"); }
            set { this.Set<int?>("AttributeId", value); }
        }

        [MetaProperty(ColumnName = "IS_SYNCHRONIZED", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
        [MaxLength(1)]
        public virtual string IsSynchronized
        {
            get { return this.Get<string>("IsSynchronized"); }
            set { this.Set<string>("IsSynchronized", value); }
        }

        [MetaProperty(ColumnName = "SYNC_SOURCE", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
        [MaxLength(100)]
        public virtual string SyncSource
        {
            get { return this.Get<string>("SyncSource"); }
            set { this.Set<string>("SyncSource", value); }
        }

        [MetaProperty(ColumnName = "EDIT_LEVEL", DbTypeName = "int")]
        public virtual int? EditLevel
        {
            get { return this.Get<int?>("EditLevel"); }
            set { this.Set<int?>("EditLevel", value); }
        }

        [MetaProperty(ColumnName = "HIERARCHY_ID", DbTypeName = "int")]
        public virtual int? HierarchyId
        {
            get { return this.Get<int?>("HierarchyId"); }
            set { this.Set<int?>("HierarchyId", value); }
        }

        [MetaProperty(ColumnName = "LINEAGE", DbTypeName = "nvarchar", MaxLength = 500, AutoTrim = true)]
        [MaxLength(500)]
        public virtual string Lineage
        {
            get { return this.Get<string>("Lineage"); }
            set { this.Set<string>("Lineage", value); }
        }

        [MetaProperty(ColumnName = "PARENT_LIST_ID", DbTypeName = "int")]
        public virtual int? ParentListId
        {
            get { return this.Get<int?>("ParentListId"); }
            set { this.Set<int?>("ParentListId", value); }
        }

        [MetaProperty(ColumnName = "STATUS", DbTypeName = "nvarchar", MaxLength = 3, AutoTrim = true)]
        [MaxLength(3)]
        public virtual DistributionListStatusType? Status
        {
            get { return this.Get<DistributionListStatusType?>("Status"); }
            set { this.Set<DistributionListStatusType?>("Status", value); }
        }

        [MetaProperty(ColumnName = "META_STORE", DbTypeName = "text", MaxLength = 16, AutoTrim = true)]
        [MaxLength(16)]
        public virtual string MetaStore
        {
            get { return this.Get<string>("MetaStore"); }
            set { this.Set<string>("MetaStore", value); }
        }

        [MetaProperty(ColumnName = "CREATED_BY", DbTypeName = "int")]
        public virtual int? CreatedBy
        {
            get { return this.Get<int?>("CreatedBy"); }
            set { this.Set<int?>("CreatedBy", value); }
        }

        [MetaProperty(ColumnName = "CREATED_ON", DbTypeName = "int")]
        public virtual int? CreatedOn
        {
            get { return this.Get<int?>("CreatedOn"); }
            set { this.Set<int?>("CreatedOn", value); }
        }

        [MetaProperty(ColumnName = "UPDATED_BY", DbTypeName = "int")]
        public virtual int? UpdatedBy
        {
            get { return this.Get<int?>("UpdatedBy"); }
            set { this.Set<int?>("UpdatedBy", value); }
        }

        [MetaProperty(ColumnName = "UPDATED_ON", DbTypeName = "int")]
        public virtual int? UpdatedOn
        {
            get { return this.Get<int?>("UpdatedOn"); }
            set { this.Set<int?>("UpdatedOn", value); }
        }

        [MetaProperty(ColumnName = "FROM_SUB_PROVIDER", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
        [MaxLength(1)]
        public virtual string FromSubProvider
        {
            get { return this.Get<string>("FromSubProvider"); }
            set { this.Set<string>("FromSubProvider", value); }
        }

        [MetaProperty(ColumnName = "IS_SYSTEM", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
        [MaxLength(1)]
        public virtual string IsSystem
        {
            get { return this.Get<string>("IsSystem"); }
            set { this.Set<string>("IsSystem", value); }
        }

        [MetaProperty(ColumnName = "IS_EXTENDED", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
        [MaxLength(1)]
        public virtual string IsExtended
        {
            get { return this.Get<string>("IsExtended"); }
            set { this.Set<string>("IsExtended", value); }
        }

        [MetaProperty(ColumnName = "IS_AVAILABLE_FOR_MAP", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
        [MaxLength(1)]
        public virtual string IsAvailableForMap
        {
            get { return this.Get<string>("IsAvailableForMap"); }
            set { this.Set<string>("IsAvailableForMap", value); }
        }
    

    #region Properties

    public class Meta
    {
        public static readonly MetaProperty Id = MetaObject.Get(typeof (DistributionList))["Id"];
        public static readonly MetaProperty ProviderId = MetaObject.Get(typeof (DistributionList))["ProviderId"];
        public static readonly MetaProperty Name = MetaObject.Get(typeof (DistributionList))["Name"];
        public static readonly MetaProperty ListType = MetaObject.Get(typeof (DistributionList))["ListType"];
        public static readonly MetaProperty CommonName = MetaObject.Get(typeof (DistributionList))["CommonName"];
        public static readonly MetaProperty Description = MetaObject.Get(typeof (DistributionList))["Description"];
        public static readonly MetaProperty Definition = MetaObject.Get(typeof (DistributionList))["Definition"];
        public static readonly MetaProperty AttributeId = MetaObject.Get(typeof (DistributionList))["AttributeId"];
        public static readonly MetaProperty IsSynchronized = MetaObject.Get(typeof (DistributionList))["IsSynchronized"];
        public static readonly MetaProperty SyncSource = MetaObject.Get(typeof (DistributionList))["SyncSource"];
        public static readonly MetaProperty EditLevel = MetaObject.Get(typeof (DistributionList))["EditLevel"];
        public static readonly MetaProperty HierarchyId = MetaObject.Get(typeof (DistributionList))["HierarchyId"];
        public static readonly MetaProperty Lineage = MetaObject.Get(typeof (DistributionList))["Lineage"];
        public static readonly MetaProperty ParentListId = MetaObject.Get(typeof (DistributionList))["ParentListId"];
        public static readonly MetaProperty Status = MetaObject.Get(typeof (DistributionList))["Status"];
        public static readonly MetaProperty MetaStore = MetaObject.Get(typeof (DistributionList))["MetaStore"];
        public static readonly MetaProperty CreatedBy = MetaObject.Get(typeof (DistributionList))["CreatedBy"];
        public static readonly MetaProperty CreatedOn = MetaObject.Get(typeof (DistributionList))["CreatedOn"];
        public static readonly MetaProperty UpdatedBy = MetaObject.Get(typeof (DistributionList))["UpdatedBy"];
        public static readonly MetaProperty UpdatedOn = MetaObject.Get(typeof (DistributionList))["UpdatedOn"];

        public static readonly MetaProperty FromSubProvider =
            MetaObject.Get(typeof (DistributionList))["FromSubProvider"];

        public static readonly MetaProperty IsSystem = MetaObject.Get(typeof (DistributionList))["IsSystem"];
        public static readonly MetaProperty IsExtended = MetaObject.Get(typeof (DistributionList))["IsExtended"];

        public static readonly MetaProperty IsAvailableForMap =
            MetaObject.Get(typeof (DistributionList))["IsAvailableForMap"];
    }

    #endregion Properties

}

#region DistributionListMeta
	public partial class DistributionListMeta
	{
	}
	#endregion DistributionListMeta
}