﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Encryption;

namespace AtHoc.IWS.Business.Domain.Entities
{
    [MetadataType(typeof(DeviceProviderMeta))]
	[MetaObject(TableName = "DLV_PRV_DEVICE_TAB")]
	public partial class DeviceProvider : EntityBase
    {

		[MetaProperty(ColumnName = "PROVIDER_ID", DbTypeName = "int", IsKey = true)]
		[Required]
		public virtual int ProviderId
		{
			get { return this.Get<int>("ProviderId"); }
			set { this.Set<int>("ProviderId", value); }
		}

		[MetaProperty(ColumnName = "DEVICE_ID", DbTypeName = "int", IsKey = true)]
		[Required]
		public virtual int Id
		{
			get { return this.Get<int>("Id"); }
			set { this.Set<int>("Id", value); }
		}

		[MetaProperty(ColumnName = "IS_ENABLED", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsEnabled
		{
			get { return this.Get<string>("IsEnabled"); }
			set { this.Set<string>("IsEnabled", value); }
		}

		[MetaProperty(ColumnName = "EDIT_LEVEL", DbTypeName = "int")]
		public virtual int? EditLevel
		{
			get { return this.Get<int?>("EditLevel"); }
			set { this.Set<int?>("EditLevel", value); }
		}

		[MetaProperty(ColumnName = "ADDRESS_REQUIRED", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string AddressRequired
		{
			get { return this.Get<string>("AddressRequired"); }
			set { this.Set<string>("AddressRequired", value); }
		}


		#region Properties
		public class Meta
		{
			public static readonly MetaProperty ProviderId = MetaObject.Get(typeof(DeviceProvider))["ProviderId"];
			public static readonly MetaProperty Id = MetaObject.Get(typeof(DeviceProvider))["Id"];
			public static readonly MetaProperty IsEnabled = MetaObject.Get(typeof(DeviceProvider))["IsEnabled"];
			public static readonly MetaProperty EditLevel = MetaObject.Get(typeof(DeviceProvider))["EditLevel"];
			public static readonly MetaProperty AddressRequired = MetaObject.Get(typeof(DeviceProvider))["AddressRequired"];
		}
		#endregion Properties

    }

	#region DeviceProviderMeta
	public partial class DeviceProviderMeta
	{
	}
	#endregion DeviceProviderMeta
}
