﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Encryption;

namespace AtHoc.IWS.Business.Domain.Entities
{
    [MetadataType(typeof(CacheinfoMeta))]
	[MetaObject(TableName = "SYS_CACHEINFO")]
	public partial class Cacheinfo : EntityBase
    {

		[MetaProperty(ColumnName = "Id", DbTypeName = "int", IsKey = true, IsIdentity = true)]
		[Required]
		public virtual int Id
		{
			get { return this.Get<int>("Id"); }
			set { this.Set<int>("Id", value); }
		}

		[MetaProperty(ColumnName = "CacheName", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
		[Required]
		public virtual string Cachename
		{
			get { return this.Get<string>("Cachename"); }
			set { this.Set<string>("Cachename", value); }
		}

		[MetaProperty(ColumnName = "LastUpdated", DbTypeName = "datetime")]
		[Required]
		public virtual DateTime Lastupdated
		{
			get { return this.Get<DateTime>("Lastupdated"); }
			set { this.Set<DateTime>("Lastupdated", value); }
		}


		#region Properties
		public class Meta
		{
			public static readonly MetaProperty Id = MetaObject.Get(typeof(Cacheinfo))["Id"];
			public static readonly MetaProperty Cachename = MetaObject.Get(typeof(Cacheinfo))["Cachename"];
			public static readonly MetaProperty Lastupdated = MetaObject.Get(typeof(Cacheinfo))["Lastupdated"];
		}
		#endregion Properties

    }

	#region CacheinfoMeta
	public partial class CacheinfoMeta
	{
	}
	#endregion CacheinfoMeta
}
