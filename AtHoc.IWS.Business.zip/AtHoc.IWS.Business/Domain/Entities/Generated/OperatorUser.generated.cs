﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Encryption;

namespace AtHoc.IWS.Business.Domain.Entities
{
    [MetadataType(typeof(OperatorUserMeta))]
	[MetaObject(TableName = "UPS_USER_TAB")]
	public partial class OperatorUser : EntityBase
    {

		[MetaProperty(ColumnName = "USER_ID", DbTypeName = "int", IsKey = true, SequenceType = "MSUSER")]
		[Required]
		public virtual int Id
		{
			get { return this.Get<int>("Id"); }
			set { this.Set<int>("Id", value); }
		}

		[MetaProperty(ColumnName = "USERNAME", DbTypeName = "nvarchar", MaxLength = 120, AutoTrim = true)]
		[MaxLength(40)]
		[Required]
		public virtual string Username
		{
			get { return this.Get<string>("Username"); }
			set { this.Set<string>("Username", value); }
		}

        [MetaProperty(ColumnName = "MAPPING_ID", DbTypeName = "nvarchar", MaxLength = 40, AutoTrim = true)]
        [MaxLength(120)]
        public virtual string MappingId
        {
            get { return this.Get<string>("MappingId"); }
            set { this.Set<string>("MappingId", value); }
        }

		[MetaProperty(ColumnName = "PASSWORD", DbTypeName = "nvarchar", MaxLength = 128, AutoTrim = true)]
		[MaxLength(128)]
		public virtual string Password
		{
			get { return this.Get<string>("Password"); }
			set { this.Set<string>("Password", value); }
		}

		[MetaProperty(ColumnName = "FULL_NAME", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
		public virtual string FullName
		{
			get { return this.Get<string>("FullName"); }
			set { this.Set<string>("FullName", value); }
		}

        [MetaProperty(ColumnName = "ACCESS_LOCKED", DbTypeName = "nvarchar", MaxLength = 128, AutoTrim = true)]
        [MaxLength(128)]
        public virtual string AccessLocked
        {
            get { return this.Get<string>("AccessLocked"); }
            set { this.Set<string>("AccessLocked", value); }
        }

        /*
		[MetaProperty(ColumnName = "STATUS", DbTypeName = "nvarchar")]
		public virtual UserStatusType? Status
		{
			get { return this.Get<UserStatusType?>("Status"); }
			set { this.Set<UserStatusType?>("Status", value); }
		}
        */

		[MetaProperty(ColumnName = "CREATED_ON", DbTypeName = "int")]
		public virtual int? CreatedOn
		{
			get { return this.Get<int?>("CreatedOn"); }
			set { this.Set<int?>("CreatedOn", value); }
		}

		[MetaProperty(ColumnName = "EXPIRATION_DATE", DbTypeName = "int")]
		public virtual int? ExpirationDate
		{
			get { return this.Get<int?>("ExpirationDate"); }
			set { this.Set<int?>("ExpirationDate", value); }
		}

		[MetaProperty(ColumnName = "FIRST_NAME", DbTypeName = "nvarchar", MaxLength = 30, AutoTrim = true)]
		[MaxLength(30)]
		public virtual string FirstName
		{
			get { return this.Get<string>("FirstName"); }
			set { this.Set<string>("FirstName", value); }
		}

		[MetaProperty(ColumnName = "LAST_NAME", DbTypeName = "nvarchar", MaxLength = 30, AutoTrim = true)]
		[MaxLength(30)]
		public virtual string LastName
		{
			get { return this.Get<string>("LastName"); }
			set { this.Set<string>("LastName", value); }
		}

		[MetaProperty(ColumnName = "PASSWORD_UPDATED_ON", DbTypeName = "int")]
		public virtual int? PasswordUpdatedOn
		{
			get { return this.Get<int?>("PasswordUpdatedOn"); }
			set { this.Set<int?>("PasswordUpdatedOn", value); }
		}

		[MetaProperty(ColumnName = "NEXT_LOGIN_CHANGE_PW", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string NextLoginChangePw
		{
			get { return this.Get<string>("NextLoginChangePw"); }
			set { this.Set<string>("NextLoginChangePw", value); }
		}

		[MetaProperty(ColumnName = "PASSWORD_NEVER_EXPIRES", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string PasswordNeverExpires
		{
			get { return this.Get<string>("PasswordNeverExpires"); }
			set { this.Set<string>("PasswordNeverExpires", value); }
		}

		[MetaProperty(ColumnName = "CURRENT_FAILED_ATTEMPTS", DbTypeName = "int")]
		public virtual int? CurrentFailedAttempts
		{
			get { return this.Get<int?>("CurrentFailedAttempts"); }
			set { this.Set<int?>("CurrentFailedAttempts", value); }
		}

		[MetaProperty(ColumnName = "LAST_FAILED_ATTEMPTS", DbTypeName = "int")]
		public virtual int? LastFailedAttempts
		{
			get { return this.Get<int?>("LastFailedAttempts"); }
			set { this.Set<int?>("LastFailedAttempts", value); }
		}

		[MetaProperty(ColumnName = "CURRENT_LOGIN_MACHINE_NAME", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string CurrentLoginMachineName
		{
			get { return this.Get<string>("CurrentLoginMachineName"); }
			set { this.Set<string>("CurrentLoginMachineName", value); }
		}

		[MetaProperty(ColumnName = "LAST_LOGIN_MACHINE_NAME", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string LastLoginMachineName
		{
			get { return this.Get<string>("LastLoginMachineName"); }
			set { this.Set<string>("LastLoginMachineName", value); }
		}

		[MetaProperty(ColumnName = "CURRENT_LOGIN_TIME", DbTypeName = "int")]
		public virtual int? CurrentLoginTime
		{
			get { return this.Get<int?>("CurrentLoginTime"); }
			set { this.Set<int?>("CurrentLoginTime", value); }
		}

		[MetaProperty(ColumnName = "LAST_LOGIN_TIME", DbTypeName = "int")]
		public virtual int? LastLoginTime
		{
			get { return this.Get<int?>("LastLoginTime"); }
			set { this.Set<int?>("LastLoginTime", value); }
		}

		[MetaProperty(ColumnName = "FAILED_ATTEMPTS_BEFORE_RESET", DbTypeName = "int")]
		public virtual int? FailedAttemptsBeforeReset
		{
			get { return this.Get<int?>("FailedAttemptsBeforeReset"); }
			set { this.Set<int?>("FailedAttemptsBeforeReset", value); }
		}

		[MetaProperty(ColumnName = "LAST_FAILED_ATTEMPT_TIME", DbTypeName = "int")]
		public virtual int? LastFailedAttemptTime
		{
			get { return this.Get<int?>("LastFailedAttemptTime"); }
			set { this.Set<int?>("LastFailedAttemptTime", value); }
		}


		[MetaProperty(ColumnName = "DEFAULT_LOGIN_PROVIDER", DbTypeName = "int")]
		public virtual int? DefaultLoginProvider
		{
			get { return this.Get<int?>("DefaultLoginProvider"); }
			set { this.Set<int?>("DefaultLoginProvider", value); }
		}

		[MetaProperty(ColumnName = "USER_RANDOM_ID", DbTypeName = "nvarchar", MaxLength = 50, AutoTrim = true)]
		[MaxLength(50)]
		public virtual string UserRandomId
		{
			get { return this.Get<string>("UserRandomId"); }
			set { this.Set<string>("UserRandomId", value); }
		}

        //This field is populated only for OperatorUsers and is in USR_USER_TAB. 
        // To remember the operators last logged on provider from 87CP1 onwards.
        // Value of -1 means you must force the operator to change provider.
        [MetaProperty(ColumnName = "LAST_ACCESSED_PROVIDER", DbTypeName = "int")]
        public virtual int? LastAccessedProvider
        {
            get { return this.Get<int?>("LastAccessedProvider"); }
            set { this.Set<int?>("LastAccessedProvider", value); }
        }

		#region Properties
		public class Meta
		{
			public static readonly MetaProperty Id = MetaObject.Get(typeof(OperatorUser))["Id"];
			public static readonly MetaProperty MappingId = MetaObject.Get(typeof(OperatorUser))["MappingId"];
            public static readonly MetaProperty Username = MetaObject.Get(typeof(OperatorUser))["Username"];
			public static readonly MetaProperty Password = MetaObject.Get(typeof(OperatorUser))["Password"];
			public static readonly MetaProperty FullName = MetaObject.Get(typeof(OperatorUser))["FullName"];
            public static readonly MetaProperty AccessLocked = MetaObject.Get(typeof(OperatorUser))["AccessLocked"];
			//public static readonly MetaProperty Status = MetaObject.Get(typeof(OperatorUser))["Status"];
			public static readonly MetaProperty CreatedOn = MetaObject.Get(typeof(OperatorUser))["CreatedOn"];
			public static readonly MetaProperty ExpirationDate = MetaObject.Get(typeof(OperatorUser))["ExpirationDate"];
			public static readonly MetaProperty FirstName = MetaObject.Get(typeof(OperatorUser))["FirstName"];
			public static readonly MetaProperty LastName = MetaObject.Get(typeof(OperatorUser))["LastName"];
			public static readonly MetaProperty PasswordUpdatedOn = MetaObject.Get(typeof(OperatorUser))["PasswordUpdatedOn"];
			public static readonly MetaProperty NextLoginChangePw = MetaObject.Get(typeof(OperatorUser))["NextLoginChangePw"];
			public static readonly MetaProperty PasswordNeverExpires = MetaObject.Get(typeof(OperatorUser))["PasswordNeverExpires"];
			public static readonly MetaProperty CurrentFailedAttempts = MetaObject.Get(typeof(OperatorUser))["CurrentFailedAttempts"];
			public static readonly MetaProperty LastFailedAttempts = MetaObject.Get(typeof(OperatorUser))["LastFailedAttempts"];
			public static readonly MetaProperty CurrentLoginMachineName = MetaObject.Get(typeof(OperatorUser))["CurrentLoginMachineName"];
			public static readonly MetaProperty LastLoginMachineName = MetaObject.Get(typeof(OperatorUser))["LastLoginMachineName"];
			public static readonly MetaProperty CurrentLoginTime = MetaObject.Get(typeof(OperatorUser))["CurrentLoginTime"];
			public static readonly MetaProperty LastLoginTime = MetaObject.Get(typeof(OperatorUser))["LastLoginTime"];
			public static readonly MetaProperty FailedAttemptsBeforeReset = MetaObject.Get(typeof(OperatorUser))["FailedAttemptsBeforeReset"];
			public static readonly MetaProperty LastFailedAttemptTime = MetaObject.Get(typeof(OperatorUser))["LastFailedAttemptTime"];
			public static readonly MetaProperty DefaultLoginProvider = MetaObject.Get(typeof(OperatorUser))["DefaultLoginProvider"];
			public static readonly MetaProperty UserRandomId = MetaObject.Get(typeof(OperatorUser))["UserRandomId"];
		    public static readonly MetaProperty LastAccessedProvider = MetaObject.Get(typeof (OperatorUser))["LastAccessedProvider"];
		}
		#endregion Properties

    }

	#region OperatorUserMeta
	public partial class OperatorUserMeta
	{
	}
	#endregion OperatorUserMeta
}
