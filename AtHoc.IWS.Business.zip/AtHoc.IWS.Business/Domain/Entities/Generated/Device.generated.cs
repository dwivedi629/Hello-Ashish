﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Global.Resources.Entities;
using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Encryption;

namespace AtHoc.IWS.Business.Domain.Entities
{
    [MetadataType(typeof(DeviceMeta))]
	[MetaObject(TableName = "DLV_DEVICE_TAB")]
	public partial class Device : EntityBase
    {

		[MetaProperty(ColumnName = "DEVICE_ID", DbTypeName = "int", IsKey = true)]
        [LocalizationEntityIdAttribute(BusinessEntity.Device)]
		[Required]
		public virtual int Id
		{
			get { return this.Get<int>("Id"); }
			set { this.Set<int>("Id", value); }
		}

		[MetaProperty(ColumnName = "NAME", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
		[Required]
        [LocalizationEntityProperty(BusinessEntity.Device,"Name")]
		public virtual string Name
		{
			get { return this.Get<string>("Name"); }
			set { this.Set<string>("Name", value); }
		}

		[MetaProperty(ColumnName = "COMMON_NAME", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
		public virtual string CommonName
		{
			get { return this.Get<string>("CommonName"); }
			set { this.Set<string>("CommonName", value); }
		}

		[MetaProperty(ColumnName = "DESCRIPTION", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
        [LocalizationEntityProperty(BusinessEntity.Device, "Description")]
		public virtual string Description
		{
			get { return this.Get<string>("Description"); }
			set { this.Set<string>("Description", value); }
		}

		[MetaProperty(ColumnName = "GROUP_ID", DbTypeName = "int")]
		public virtual int? GroupId
		{
			get { return this.Get<int?>("GroupId"); }
			set { this.Set<int?>("GroupId", value); }
		}

		[MetaProperty(ColumnName = "GROUP_SORT_ORDER", DbTypeName = "int")]
		public virtual int? GroupSortOrder
		{
			get { return this.Get<int?>("GroupSortOrder"); }
			set { this.Set<int?>("GroupSortOrder", value); }
		}

		[MetaProperty(ColumnName = "IMAGE_ID", DbTypeName = "int")]
		public virtual int? ImageId
		{
			get { return this.Get<int?>("ImageId"); }
			set { this.Set<int?>("ImageId", value); }
		}

		[MetaProperty(ColumnName = "TARGETING_CONFIRMATION_TEXT", DbTypeName = "nvarchar", MaxLength = 500, AutoTrim = true)]
		[MaxLength(500)]
		public virtual string TargetingConfirmationText
		{
			get { return this.Get<string>("TargetingConfirmationText"); }
			set { this.Set<string>("TargetingConfirmationText", value); }
		}

		[MetaProperty(ColumnName = "ADDRESS_ENTRY_HELP_TEXT", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string AddressEntryHelpText
		{
			get { return this.Get<string>("AddressEntryHelpText"); }
			set { this.Set<string>("AddressEntryHelpText", value); }
		}

		[MetaProperty(ColumnName = "ADDRESS_ENTRY_TOOL_TIP", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string AddressEntryToolTip
		{
			get { return this.Get<string>("AddressEntryToolTip"); }
			set { this.Set<string>("AddressEntryToolTip", value); }
		}

		[MetaProperty(ColumnName = "ADDRESS_MGMT_URL", DbTypeName = "nvarchar", MaxLength = 1000, AutoTrim = true)]
		[MaxLength(1000)]
		public virtual string AddressMgmtUrl
		{
			get { return this.Get<string>("AddressMgmtUrl"); }
			set { this.Set<string>("AddressMgmtUrl", value); }
		}

		[MetaProperty(ColumnName = "STATUS", DbTypeName = "nvarchar", MaxLength = 3, AutoTrim = true)]
		[MaxLength(3)]
		public virtual string Status
		{
			get { return this.Get<string>("Status"); }
			set { this.Set<string>("Status", value); }
		}

		[MetaProperty(ColumnName = "CREATED_ON", DbTypeName = "datetime")]
		public virtual DateTime? CreatedOn
		{
			get { return this.Get<DateTime?>("CreatedOn"); }
			set { this.Set<DateTime?>("CreatedOn", value); }
		}

		[MetaProperty(ColumnName = "CREATED_BY", DbTypeName = "int")]
		public virtual int? CreatedBy
		{
			get { return this.Get<int?>("CreatedBy"); }
			set { this.Set<int?>("CreatedBy", value); }
		}

		[MetaProperty(ColumnName = "UPDATED_ON", DbTypeName = "datetime")]
		public virtual DateTime? UpdatedOn
		{
			get { return this.Get<DateTime?>("UpdatedOn"); }
			set { this.Set<DateTime?>("UpdatedOn", value); }
		}

		[MetaProperty(ColumnName = "UPDATED_BY", DbTypeName = "int")]
		public virtual int? UpdatedBy
		{
			get { return this.Get<int?>("UpdatedBy"); }
			set { this.Set<int?>("UpdatedBy", value); }
		}

		#region Properties
		public class Meta
		{
			public static readonly MetaProperty Id = MetaObject.Get(typeof(Device))["Id"];
			public static readonly MetaProperty Name = MetaObject.Get(typeof(Device))["Name"];
			public static readonly MetaProperty CommonName = MetaObject.Get(typeof(Device))["CommonName"];
			public static readonly MetaProperty Description = MetaObject.Get(typeof(Device))["Description"];
			public static readonly MetaProperty GroupId = MetaObject.Get(typeof(Device))["GroupId"];
			public static readonly MetaProperty GroupSortOrder = MetaObject.Get(typeof(Device))["GroupSortOrder"];
			public static readonly MetaProperty ImageId = MetaObject.Get(typeof(Device))["ImageId"];
			public static readonly MetaProperty TargetingConfirmationText = MetaObject.Get(typeof(Device))["TargetingConfirmationText"];
			public static readonly MetaProperty AddressEntryHelpText = MetaObject.Get(typeof(Device))["AddressEntryHelpText"];
			public static readonly MetaProperty AddressEntryToolTip = MetaObject.Get(typeof(Device))["AddressEntryToolTip"];
			public static readonly MetaProperty AddressMgmtUrl = MetaObject.Get(typeof(Device))["AddressMgmtUrl"];
			public static readonly MetaProperty Status = MetaObject.Get(typeof(Device))["Status"];
			public static readonly MetaProperty CreatedOn = MetaObject.Get(typeof(Device))["CreatedOn"];
			public static readonly MetaProperty CreatedBy = MetaObject.Get(typeof(Device))["CreatedBy"];
			public static readonly MetaProperty UpdatedOn = MetaObject.Get(typeof(Device))["UpdatedOn"];
			public static readonly MetaProperty UpdatedBy = MetaObject.Get(typeof(Device))["UpdatedBy"];
		}
		#endregion Properties

	}

	#region DeviceMeta
	public partial class DeviceMeta
	{
	}
	#endregion DeviceMeta
}
