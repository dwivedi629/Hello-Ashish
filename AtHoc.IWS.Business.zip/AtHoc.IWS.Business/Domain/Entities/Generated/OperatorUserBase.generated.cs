﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Encryption;

namespace AtHoc.IWS.Business.Domain.Entities
{
    [MetadataType(typeof(OperatorUserBaseMeta))]
	[MetaObject(TableName = "UPS_USER_BASE_TAB")]
	public partial class OperatorUserBase : EntityBase
    {
		[MetaProperty(ColumnName = "USER_ID", DbTypeName = "int", IsKey = true, SequenceType = "OPERATOR_USER_BASE")]
		[Required]
		public virtual int UserId
		{
			get { return this.Get<int>("UserId"); }
			set { this.Set<int>("UserId", value); }
		}

		[MetaProperty(ColumnName = "PROVIDER_ID", DbTypeName = "int")]
		[Required]
		public virtual int ProviderId
		{
			get { return this.Get<int>("ProviderId"); }
			set { this.Set<int>("ProviderId", value); }
		}

		[MetaProperty(ColumnName = "ATTRIBUTE_ID", DbTypeName = "int")]
		[Required]
		public virtual int AttributeId
		{
			get { return this.Get<int>("AttributeId"); }
			set { this.Set<int>("AttributeId", value); }
		}

		[MetaProperty(ColumnName = "SEARCH_CONDITION", DbTypeName = "int")]
		public virtual int? SearchCondition
		{
			get { return this.Get<int?>("SearchCondition"); }
			set { this.Set<int?>("SearchCondition", value); }
		}

		[MetaProperty(ColumnName = "SEARCH_VALUES", DbTypeName = "nvarchar", MaxLength = 2000, AutoTrim = true)]
		[MaxLength(2000)]
		public virtual string SearchValues
		{
			get { return this.Get<string>("SearchValues"); }
			set { this.Set<string>("SearchValues", value); }
		}

		[MetaProperty(ColumnName = "ATTRIBUTE_TYPE", DbTypeName = "nvarchar", MaxLength = 20, AutoTrim = true)]
		[MaxLength(20)]
		public virtual string AttributeType
		{
			get { return this.Get<string>("AttributeType"); }
			set { this.Set<string>("AttributeType", value); }
		}


		#region Properties
		public class Meta
		{
			public static readonly MetaProperty UserId = MetaObject.Get(typeof(OperatorUserBase))["UserId"];
			public static readonly MetaProperty ProviderId = MetaObject.Get(typeof(OperatorUserBase))["ProviderId"];
			public static readonly MetaProperty AttributeId = MetaObject.Get(typeof(OperatorUserBase))["AttributeId"];
			public static readonly MetaProperty SearchCondition = MetaObject.Get(typeof(OperatorUserBase))["SearchCondition"];
			public static readonly MetaProperty SearchValues = MetaObject.Get(typeof(OperatorUserBase))["SearchValues"];
			public static readonly MetaProperty AttributeType = MetaObject.Get(typeof(OperatorUserBase))["AttributeType"];
		}
		#endregion Properties

    }

	#region OperatorUserBaseMeta
	public partial class OperatorUserBaseMeta
	{
	}
	#endregion OperatorUserBaseMeta
}
