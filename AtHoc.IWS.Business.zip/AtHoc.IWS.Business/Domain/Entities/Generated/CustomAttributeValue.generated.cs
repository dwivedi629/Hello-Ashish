﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Encryption;

namespace AtHoc.IWS.Business.Domain.Entities
{
    [MetadataType(typeof(CustomAttributeValueMeta))]
	[MetaObject(TableName = "PRV_ATTRIBUTE_VALUE_TAB")]
	public partial class CustomAttributeValue : EntityBase
    {

		[MetaProperty(ColumnName = "ATTRIBUTE_ID", DbTypeName = "int", IsKey = true)]
		[Required]
		public virtual int AttributeId
		{
			get { return this.Get<int>("AttributeId"); }
			set { this.Set<int>("AttributeId", value); }
		}

		[MetaProperty(ColumnName = "VALUE_ID", DbTypeName = "int", IsKey = true)]
		[Required]
		public virtual int ValueId
		{
			get { return this.Get<int>("ValueId"); }
			set { this.Set<int>("ValueId", value); }
		}

		[MetaProperty(ColumnName = "VALUE_NAME", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true, IsPersistable = false)]
		[MaxLength(200)]
		public virtual string ValueName
		{
			get { return this.Get<string>("ValueName"); }
			set { this.Set<string>("ValueName", value); }
		}

        /*[MetaProperty(IsPersistable = false)]
        [MaxLength(200)]
        public virtual string ValueName
        {
            get { return this.Get<string>("ValueName"); }
            set { this.Set<string>("ValueName", value); }
        }*/

		[MetaProperty(ColumnName = "PRIORITY", DbTypeName = "int")]
		public virtual int? Priority
		{
			get { return this.Get<int?>("Priority"); }
			set { this.Set<int?>("Priority", value); }
		}

        [MetaProperty(ColumnName = "SORT_ORDER", DbTypeName = "int")]
        public virtual int? SortOrder
        {
            get { return this.Get<int?>("SortOrder"); }
            set { this.Set<int?>("SortOrder",value);}
        }

		[MetaProperty(ColumnName = "COMMON_NAME", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string CommonName
		{
			get { return this.Get<string>("CommonName"); }
			set { this.Set<string>("CommonName", value); }
		}

		[MetaProperty(ColumnName = "STATUS", DbTypeName = "nvarchar", MaxLength = 3, AutoTrim = true)]
		[MaxLength(3)]
		public virtual string Status
		{
			get { return this.Get<string>("Status"); }
			set { this.Set<string>("Status", value); }
		}

		[MetaProperty(ColumnName = "CHECK_UPDATE_INTERVAL", DbTypeName = "int")]
		public virtual int? CheckUpdateInterval
		{
			get { return this.Get<int?>("CheckUpdateInterval"); }
			set { this.Set<int?>("CheckUpdateInterval", value); }
		}

		[MetaProperty(ColumnName = "UPDATED_ON", DbTypeName = "int")]
		public virtual int? UpdatedOn
		{
			get { return this.Get<int?>("UpdatedOn"); }
			set { this.Set<int?>("UpdatedOn", value); }
		}

		[MetaProperty(ColumnName = "UPDATED_BY", DbTypeName = "int")]
		public virtual int? UpdatedBy
		{
			get { return this.Get<int?>("UpdatedBy"); }
			set { this.Set<int?>("UpdatedBy", value); }
		}


		#region Properties
		public class Meta
		{
			public static readonly MetaProperty AttributeId = MetaObject.Get(typeof(CustomAttributeValue))["AttributeId"];
			public static readonly MetaProperty ValueId = MetaObject.Get(typeof(CustomAttributeValue))["ValueId"];
			public static readonly MetaProperty ValueName = MetaObject.Get(typeof(CustomAttributeValue))["ValueName"];
			public static readonly MetaProperty Priority = MetaObject.Get(typeof(CustomAttributeValue))["Priority"];
		    public static readonly MetaProperty SortOrder = MetaObject.Get(typeof (CustomAttributeValue))["SortOrder"];
			public static readonly MetaProperty CommonName = MetaObject.Get(typeof(CustomAttributeValue))["CommonName"];
			public static readonly MetaProperty Status = MetaObject.Get(typeof(CustomAttributeValue))["Status"];
			public static readonly MetaProperty CheckUpdateInterval = MetaObject.Get(typeof(CustomAttributeValue))["CheckUpdateInterval"];
			public static readonly MetaProperty UpdatedOn = MetaObject.Get(typeof(CustomAttributeValue))["UpdatedOn"];
			public static readonly MetaProperty UpdatedBy = MetaObject.Get(typeof(CustomAttributeValue))["UpdatedBy"];
		}
		#endregion Properties

    }

	#region CustomAttributeValueMeta
	public partial class CustomAttributeValueMeta
	{
	}
	#endregion CustomAttributeValueMeta
}
