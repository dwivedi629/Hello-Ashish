﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Global.Resources.Entities;
using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Encryption;

namespace AtHoc.IWS.Business.Domain.Entities
{
    [MetadataType(typeof(DeviceGroupMeta))]
	[MetaObject(TableName = "DLV_DEVICE_GROUP_TAB")]
	public partial class DeviceGroup : EntityBase
    {

		[MetaProperty(ColumnName = "GROUP_ID", DbTypeName = "int", IsKey = true)]
        [LocalizationEntityIdAttribute(BusinessEntity.DeviceGroup)]
		[Required]
		public virtual int Id
		{
			get { return this.Get<int>("Id"); }
			set { this.Set<int>("Id", value); }
		}

		[MetaProperty(ColumnName = "COMMON_NAME", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
		public virtual string CommonName
		{
			get { return this.Get<string>("CommonName"); }
			set { this.Set<string>("CommonName", value); }
		}

        [LocalizationEntityProperty(BusinessEntity.DeviceGroup, "Name")]
		[MetaProperty(ColumnName = "NAME", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
		public virtual string Name
		{
			get { return this.Get<string>("Name"); }
			set { this.Set<string>("Name", value); }
		}

		[MetaProperty(ColumnName = "SORT_ORDER", DbTypeName = "int")]
		public virtual int? SortOrder
		{
			get { return this.Get<int?>("SortOrder"); }
			set { this.Set<int?>("SortOrder", value); }
		}

		[MetaProperty(ColumnName = "IMAGE_ID", DbTypeName = "int")]
		public virtual int? ImageId
		{
			get { return this.Get<int?>("ImageId"); }
			set { this.Set<int?>("ImageId", value); }
		}

		[MetaProperty(ColumnName = "EXTENSION_ID", DbTypeName = "int")]
		public virtual int? ExtensionId
		{
			get { return this.Get<int?>("ExtensionId"); }
			set { this.Set<int?>("ExtensionId", value); }
		}

		[MetaProperty(ColumnName = "IS_TARGETABLE", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsTargetable
		{
			get { return this.Get<string>("IsTargetable"); }
			set { this.Set<string>("IsTargetable", value); }
		}

		[MetaProperty(ColumnName = "COMBINE_MSG_ON_SHARED_ADDRESSES", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string CombineMsgOnSharedAddresses
		{
			get { return this.Get<string>("CombineMsgOnSharedAddresses"); }
			set { this.Set<string>("CombineMsgOnSharedAddresses", value); }
		}

		[MetaProperty(ColumnName = "RECIPIENT_TYPE", DbTypeName = "nvarchar", MaxLength = 20, AutoTrim = true)]
		[MaxLength(20)]
		public virtual string RecipientType
		{
			get { return this.Get<string>("RecipientType"); }
			set { this.Set<string>("RecipientType", value); }
		}

		[MetaProperty(ColumnName = "RECIPIENT_TARGETING_IMPLICIT", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string RecipientTargetingImplicit
		{
			get { return this.Get<string>("RecipientTargetingImplicit"); }
			set { this.Set<string>("RecipientTargetingImplicit", value); }
		}

		[MetaProperty(ColumnName = "ADDRESS_VALIDATION_PAYLOAD", DbTypeName = "", AutoTrim = true)]
		public virtual string AddressValidationPayload
		{
			get { return this.Get<string>("AddressValidationPayload"); }
			set { this.Set<string>("AddressValidationPayload", value); }
		}

		[MetaProperty(ColumnName = "ADDRESS_STRIP_REGEX", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
		public virtual string AddressStripRegex
		{
			get { return this.Get<string>("AddressStripRegex"); }
			set { this.Set<string>("AddressStripRegex", value); }
		}

		[MetaProperty(ColumnName = "IS_DELIVERY_ORDER_SUPPORTED", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsDeliveryOrderSupported
		{
			get { return this.Get<string>("IsDeliveryOrderSupported"); }
			set { this.Set<string>("IsDeliveryOrderSupported", value); }
		}


		#region Properties
		public class Meta
		{
			public static readonly MetaProperty Id = MetaObject.Get(typeof(DeviceGroup))["Id"];
			public static readonly MetaProperty CommonName = MetaObject.Get(typeof(DeviceGroup))["CommonName"];
			public static readonly MetaProperty Name = MetaObject.Get(typeof(DeviceGroup))["Name"];
			public static readonly MetaProperty SortOrder = MetaObject.Get(typeof(DeviceGroup))["SortOrder"];
			public static readonly MetaProperty ImageId = MetaObject.Get(typeof(DeviceGroup))["ImageId"];
			public static readonly MetaProperty ExtensionId = MetaObject.Get(typeof(DeviceGroup))["ExtensionId"];
			public static readonly MetaProperty IsTargetable = MetaObject.Get(typeof(DeviceGroup))["IsTargetable"];
			public static readonly MetaProperty CombineMsgOnSharedAddresses = MetaObject.Get(typeof(DeviceGroup))["CombineMsgOnSharedAddresses"];
			public static readonly MetaProperty RecipientType = MetaObject.Get(typeof(DeviceGroup))["RecipientType"];
			public static readonly MetaProperty RecipientTargetingImplicit = MetaObject.Get(typeof(DeviceGroup))["RecipientTargetingImplicit"];
			public static readonly MetaProperty AddressValidationPayload = MetaObject.Get(typeof(DeviceGroup))["AddressValidationPayload"];
			public static readonly MetaProperty AddressStripRegex = MetaObject.Get(typeof(DeviceGroup))["AddressStripRegex"];
			public static readonly MetaProperty IsDeliveryOrderSupported = MetaObject.Get(typeof(DeviceGroup))["IsDeliveryOrderSupported"];
		}
		#endregion Properties

    }

	#region DeviceGroupMeta
	public partial class DeviceGroupMeta
	{
	}
	#endregion DeviceGroupMeta
}
