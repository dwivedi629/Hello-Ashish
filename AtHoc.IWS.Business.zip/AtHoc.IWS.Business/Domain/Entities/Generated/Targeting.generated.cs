﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Encryption;

namespace AtHoc.IWS.Business.Domain.Entities
{
    [MetadataType(typeof(TargetingMeta))]
	[MetaObject(TableName = "PRV_TARGETING_TAB")]
	public partial class Targeting : EntityBase
    {

		[MetaProperty(ColumnName = "PROVIDER_ID", DbTypeName = "int")]
		[Required]
		public virtual int ProviderId
		{
			get { return this.Get<int>("ProviderId"); }
			set { this.Set<int>("ProviderId", value); }
		}

		[MetaProperty(ColumnName = "TARGETING_TYPE", DbTypeName = "nvarchar")]
		[Required]
		public virtual TargetingType TargetingType
		{
			get { return this.Get<TargetingType>("TargetingType"); }
			set { this.Set<TargetingType>("TargetingType", value); }
		}

		[MetaProperty(ColumnName = "ENTITY_TYPE", DbTypeName = "nvarchar", MaxLength = 10, AutoTrim = true)]
		[MaxLength(10)]
		[Required]
		public virtual string EntityType
		{
			get { return this.Get<string>("EntityType"); }
			set { this.Set<string>("EntityType", value); }
		}

		[MetaProperty(ColumnName = "ENTITY_ID", DbTypeName = "int")]
		public virtual int? EntityId
		{
			get { return this.Get<int?>("EntityId"); }
			set { this.Set<int?>("EntityId", value); }
		}

		[MetaProperty(ColumnName = "DISPLAY_ORDER", DbTypeName = "int")]
		public virtual int? DisplayOrder
		{
			get { return this.Get<int?>("DisplayOrder"); }
			set { this.Set<int?>("DisplayOrder", value); }
		}


		#region Properties
		public class Meta
		{
			public static readonly MetaProperty ProviderId = MetaObject.Get(typeof(Targeting))["ProviderId"];
			public static readonly MetaProperty TargetingType = MetaObject.Get(typeof(Targeting))["TargetingType"];
			public static readonly MetaProperty EntityType = MetaObject.Get(typeof(Targeting))["EntityType"];
			public static readonly MetaProperty EntityId = MetaObject.Get(typeof(Targeting))["EntityId"];
			public static readonly MetaProperty DisplayOrder = MetaObject.Get(typeof(Targeting))["DisplayOrder"];
		}
		#endregion Properties

    }

	#region TargetingMeta
	public partial class TargetingMeta
	{
	}
	#endregion TargetingMeta
}
