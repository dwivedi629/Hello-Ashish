﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Encryption;
using AtHoc.Global.Resources.Entities;

namespace AtHoc.IWS.Business.Domain.Entities
{
    [MetadataType(typeof(AlertChannelMeta))]
	[MetaObject(TableName = "ALT_CHANNEL_TAB")]
	public partial class AlertChannel : EntityBase
    {
         [LocalizationEntityIdAttribute(BusinessEntity.AlertFolder)]
		[MetaProperty(ColumnName = "CHANNEL_ID", DbTypeName = "int", IsKey = true)]
		[Required]
		public virtual int Id
		{
			get { return this.Get<int>("Id"); }
			set { this.Set<int>("Id", value); }
		}

		[MetaProperty(ColumnName = "PROVIDER_ID", DbTypeName = "int")]
		[Required]
		public virtual int ProviderId
		{
			get { return this.Get<int>("ProviderId"); }
			set { this.Set<int>("ProviderId", value); }
		}

        [LocalizationEntityProperty(BusinessEntity.AlertFolder, "Name")]
		[MetaProperty(ColumnName = "NAME", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
		[Required]
		public virtual string Name
		{
			get { return this.Get<string>("Name"); }
			set { this.Set<string>("Name", value); }
		}

        [LocalizationEntityProperty(BusinessEntity.AlertFolder, "Description")]
		[MetaProperty(ColumnName = "DESCRIPTION", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string Description
		{
			get { return this.Get<string>("Description"); }
			set { this.Set<string>("Description", value); }
		}

		[MetaProperty(ColumnName = "STATUS", DbTypeName = "nvarchar", MaxLength = 10, AutoTrim = true)]
		[MaxLength(10)]
		[Required]
		public virtual string Status
		{
			get { return this.Get<string>("Status"); }
			set { this.Set<string>("Status", value); }
		}

		[MetaProperty(ColumnName = "COMMON_NAME", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
		public virtual string CommonName
		{
			get { return this.Get<string>("CommonName"); }
			set { this.Set<string>("CommonName", value); }
		}

		[MetaProperty(ColumnName = "META_STORE", DbTypeName = "", AutoTrim = true)]
		public virtual string MetaStore
		{
			get { return this.Get<string>("MetaStore"); }
			set { this.Set<string>("MetaStore", value); }
		}
		

		[MetaProperty(ColumnName = "UPDATED_ON", DbTypeName = "datetime")]
		public virtual DateTime? UpdatedOn
		{
			get { return this.Get<DateTime?>("UpdatedOn"); }
			set { this.Set<DateTime?>("UpdatedOn", value); }
		}

		[MetaProperty(ColumnName = "UPDATED_BY", DbTypeName = "int")]
		public virtual int? UpdatedBy
		{
			get { return this.Get<int?>("UpdatedBy"); }
			set { this.Set<int?>("UpdatedBy", value); }
		}

		[MetaProperty(ColumnName = "CREATED_ON", DbTypeName = "datetime")]
		public virtual DateTime? CreatedOn
		{
			get { return this.Get<DateTime?>("CreatedOn"); }
			set { this.Set<DateTime?>("CreatedOn", value); }
		}

		[MetaProperty(ColumnName = "CREATED_BY", DbTypeName = "int")]
		public virtual int? CreatedBy
		{
			get { return this.Get<int?>("CreatedBy"); }
			set { this.Set<int?>("CreatedBy", value); }
		}


		#region Properties
		public class Meta
		{
			public static readonly MetaProperty Id = MetaObject.Get(typeof(AlertChannel))["Id"];
			public static readonly MetaProperty ProviderId = MetaObject.Get(typeof(AlertChannel))["ProviderId"];
			public static readonly MetaProperty Name = MetaObject.Get(typeof(AlertChannel))["Name"];
			public static readonly MetaProperty Description = MetaObject.Get(typeof(AlertChannel))["Description"];
			public static readonly MetaProperty Status = MetaObject.Get(typeof(AlertChannel))["Status"];
			public static readonly MetaProperty CommonName = MetaObject.Get(typeof(AlertChannel))["CommonName"];
			public static readonly MetaProperty MetaStore = MetaObject.Get(typeof(AlertChannel))["MetaStore"];
			public static readonly MetaProperty AgentId = MetaObject.Get(typeof(AlertChannel))["AgentId"];
			public static readonly MetaProperty UpdatedOn = MetaObject.Get(typeof(AlertChannel))["UpdatedOn"];
			public static readonly MetaProperty UpdatedBy = MetaObject.Get(typeof(AlertChannel))["UpdatedBy"];
			public static readonly MetaProperty CreatedOn = MetaObject.Get(typeof(AlertChannel))["CreatedOn"];
			public static readonly MetaProperty CreatedBy = MetaObject.Get(typeof(AlertChannel))["CreatedBy"];
		}
		#endregion Properties

    }

	#region AlertChannelMeta
	public partial class AlertChannelMeta
	{
	}
	#endregion AlertChannelMeta
}
