﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Encryption;

namespace AtHoc.IWS.Business.Domain.Entities
{
    [MetadataType(typeof(CustomViewMeta))]
	[MetaObject(TableName = "PRV_CUSTOM_VIEW_TAB")]
	public partial class CustomView : EntityBase
    {
		[MetaProperty(ColumnName = "VIEW_ID", DbTypeName = "int", IsKey = true, IsIdentity = true)]
		[Required]
        public virtual int ViewId
		{
            get { return this.Get<int>("ViewId"); }
            set { this.Set<int>("ViewId", value); }
		}

		[MetaProperty(ColumnName = "PROVIDER_ID", DbTypeName = "int")]
		[Required]
		public virtual int ProviderId
		{
			get { return this.Get<int>("ProviderId"); }
			set { this.Set<int>("ProviderId", value); }
		}

        [MetaProperty(ColumnName = "OPERATOR_ID", DbTypeName = "int")]
        [Required]
        public virtual int? OperatorId
        {
            get { return this.Get<int>("OperatorId"); }
            set { this.Set<int?>("OperatorId", value); }
        }

        [MetaProperty(ColumnName = "ENTITY_ID", DbTypeName = "int")]
        [Required]
        public virtual int? EntityId
        {
            get { return this.Get<int?>("EntityId"); }
            set { this.Set<int?>("EntityId", value); }
        }

		[MetaProperty(ColumnName = "VIEW_TYPE", DbTypeName = "nvarchar")]
		[Required]
		public virtual CustomViewType ViewType
		{
			get { return this.Get<CustomViewType>("ViewType"); }
			set { this.Set<CustomViewType>("ViewType", value); }
		}

		[MetaProperty(ColumnName = "COLUMNID", DbTypeName = "nvarchar")]
		public virtual CustomViewColumnType? Columnid
		{
			get { return this.Get<CustomViewColumnType?>("Columnid"); }
			set { this.Set<CustomViewColumnType?>("Columnid", value); }
		}

		[MetaProperty(ColumnName = "SEQ", DbTypeName = "int")]
		public virtual int? Seq
		{
			get { return this.Get<int?>("Seq"); }
			set { this.Set<int?>("Seq", value); }
		}


		#region Properties
		public class Meta
		{
			public static readonly MetaProperty ViewId = MetaObject.Get(typeof(CustomView))["ViewId"];
			public static readonly MetaProperty ProviderId = MetaObject.Get(typeof(CustomView))["ProviderId"];
            public static readonly MetaProperty OperatorId = MetaObject.Get(typeof(CustomView))["OperatorId"];
            public static readonly MetaProperty EntityId = MetaObject.Get(typeof(CustomView))["EntityId"];
			public static readonly MetaProperty ViewType = MetaObject.Get(typeof(CustomView))["ViewType"];
            public static readonly MetaProperty Columnid = MetaObject.Get(typeof(CustomView))["Columnid"];
			public static readonly MetaProperty Seq = MetaObject.Get(typeof(CustomView))["Seq"];
        }
		#endregion Properties

    }

	#region CustomViewMeta
	public partial class CustomViewMeta
	{
	}
	#endregion CustomViewMeta
}
