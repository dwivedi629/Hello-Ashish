﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Encryption;

namespace AtHoc.IWS.Business.Domain.Entities
{
    [MetadataType(typeof(PageLayoutMeta))]
	[MetaObject(TableName = "PRV_PAGE_LAYOUT_TAB")]
	public partial class PageLayout : EntityBase
    {

		[MetaProperty(ColumnName = "PROVIDER_ID", DbTypeName = "int")]
		[Required]
		public virtual int ProviderId
		{
			get { return this.Get<int>("ProviderId"); }
			set { this.Set<int>("ProviderId", value); }
		}

		[MetaProperty(ColumnName = "ENTITY_ID", DbTypeName = "nvarchar", MaxLength = 20, AutoTrim = true)]
		[MaxLength(20)]
		[Required]
		public virtual string EntityId
		{
			get { return this.Get<string>("EntityId"); }
			set { this.Set<string>("EntityId", value); }
		}

		[MetaProperty(ColumnName = "PAGE_ID", DbTypeName = "nvarchar", MaxLength = 20, AutoTrim = true)]
		[MaxLength(20)]
		[Required]
		public virtual string PageId
		{
			get { return this.Get<string>("PageId"); }
			set { this.Set<string>("PageId", value); }
		}

		[MetaProperty(ColumnName = "IS_DEFAULT", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsDefault
		{
			get { return this.Get<string>("IsDefault"); }
			set { this.Set<string>("IsDefault", value); }
		}

		[MetaProperty(ColumnName = "NAME", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
		public virtual string Name
		{
			get { return this.Get<string>("Name"); }
			set { this.Set<string>("Name", value); }
		}

		[MetaProperty(ColumnName = "LAYOUT_XML", DbTypeName = "text", MaxLength = 16, AutoTrim = true)]
		[MaxLength(16)]
		public virtual string LayoutXml
		{
			get { return this.Get<string>("LayoutXml"); }
			set { this.Set<string>("LayoutXml", value); }
		}

		[MetaProperty(ColumnName = "PAGE_TYPE", DbTypeName = "nvarchar", MaxLength = 10, AutoTrim = true)]
		[MaxLength(10)]
		public virtual string PageType
		{
			get { return this.Get<string>("PageType"); }
			set { this.Set<string>("PageType", value); }
		}


		#region Properties
		public class Meta
		{
			public static readonly MetaProperty ProviderId = MetaObject.Get(typeof(PageLayout))["ProviderId"];
			public static readonly MetaProperty EntityId = MetaObject.Get(typeof(PageLayout))["EntityId"];
			public static readonly MetaProperty PageId = MetaObject.Get(typeof(PageLayout))["PageId"];
			public static readonly MetaProperty IsDefault = MetaObject.Get(typeof(PageLayout))["IsDefault"];
			public static readonly MetaProperty Name = MetaObject.Get(typeof(PageLayout))["Name"];
			public static readonly MetaProperty LayoutXml = MetaObject.Get(typeof(PageLayout))["LayoutXml"];
			public static readonly MetaProperty PageType = MetaObject.Get(typeof(PageLayout))["PageType"];
		}
		#endregion Properties

    }

	#region PageLayoutMeta
	public partial class PageLayoutMeta
	{
	}
	#endregion PageLayoutMeta
}
