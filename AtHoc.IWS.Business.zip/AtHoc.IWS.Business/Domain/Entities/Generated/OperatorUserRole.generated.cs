﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Encryption;

namespace AtHoc.IWS.Business.Domain.Entities
{
    [MetadataType(typeof(OperatorUserRoleMeta))]
	[MetaObject(TableName = "UPS_USER_ROLE_TAB")]
	public partial class OperatorUserRole : EntityBase
    {

		[MetaProperty(ColumnName = "ROLE_ID", DbTypeName = "int", IsKey = true)]
		[Required]
		public virtual int RoleId
		{
			get { return this.Get<int>("RoleId"); }
			set { this.Set<int>("RoleId", value); }
		}

		[MetaProperty(ColumnName = "USER_ID", DbTypeName = "int", IsKey = true)]
		[Required]
		public virtual int UserId
		{
			get { return this.Get<int>("UserId"); }
			set { this.Set<int>("UserId", value); }
		}

		[MetaProperty(ColumnName = "CONTENT_FILTER_ID", DbTypeName = "int")]
		public virtual int? ContentFilterId
		{
			get { return this.Get<int?>("ContentFilterId"); }
			set { this.Set<int?>("ContentFilterId", value); }
		}

		[MetaProperty(ColumnName = "PROVIDER_FILTER", DbTypeName = "nvarchar", MaxLength = 10, AutoTrim = true)]
		[MaxLength(10)]
		public virtual string ProviderFilter
		{
			get { return this.Get<string>("ProviderFilter"); }
			set { this.Set<string>("ProviderFilter", value); }
		}

        [MetaProperty(IsPersistable = false)]
        public string RoleName { get; set; }


		#region Properties
		public class Meta
		{
			public static readonly MetaProperty RoleId = MetaObject.Get(typeof(OperatorUserRole))["RoleId"];
			public static readonly MetaProperty UserId = MetaObject.Get(typeof(OperatorUserRole))["UserId"];
			public static readonly MetaProperty ContentFilterId = MetaObject.Get(typeof(OperatorUserRole))["ContentFilterId"];
			public static readonly MetaProperty ProviderFilter = MetaObject.Get(typeof(OperatorUserRole))["ProviderFilter"];
		}
		#endregion Properties

    }

	#region OperatorUserRoleMeta
	public partial class OperatorUserRoleMeta
	{
	}
	#endregion OperatorUserRoleMeta
}
