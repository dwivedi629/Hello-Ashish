﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Encryption;

namespace AtHoc.IWS.Business.Domain.Entities
{
    [MetadataType(typeof(HierarchyMeta))]
	[MetaObject(TableName = "PDL_HIERARCHY_TAB")]
	public partial class Hierarchy : EntityBase
    {

		[MetaProperty(ColumnName = "HIERARCHY_ID", DbTypeName = "int", IsKey = true)]
		[Required]
		public virtual int Id
		{
			get { return this.Get<int>("Id"); }
			set { this.Set<int>("Id", value); }
		}

		[MetaProperty(ColumnName = "PROVIDER_ID", DbTypeName = "int")]
		[Required]
		public virtual int ProviderId
		{
			get { return this.Get<int>("ProviderId"); }
			set { this.Set<int>("ProviderId", value); }
		}

		[MetaProperty(ColumnName = "NAME", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
		public virtual string Name
		{
			get { return this.Get<string>("Name"); }
			set { this.Set<string>("Name", value); }
		}

		[MetaProperty(ColumnName = "COMMON_NAME", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
		public virtual string CommonName
		{
			get { return this.Get<string>("CommonName"); }
			set { this.Set<string>("CommonName", value); }
		}

		[MetaProperty(ColumnName = "HIERARCHY_TYPE", DbTypeName = "nvarchar", MaxLength = 3, AutoTrim = true)]
		[MaxLength(3)]
		public virtual string HierarchyType
		{
			get { return this.Get<string>("HierarchyType"); }
			set { this.Set<string>("HierarchyType", value); }
		}

		[MetaProperty(ColumnName = "IS_SYNCHRONIZED", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsSynchronized
		{
			get { return this.Get<string>("IsSynchronized"); }
			set { this.Set<string>("IsSynchronized", value); }
		}

		[MetaProperty(ColumnName = "SYNC_SOURCE", DbTypeName = "nvarchar", MaxLength = 50, AutoTrim = true)]
		[MaxLength(50)]
		public virtual string SyncSource
		{
			get { return this.Get<string>("SyncSource"); }
			set { this.Set<string>("SyncSource", value); }
		}

		[MetaProperty(ColumnName = "DESCRIPTION", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string Description
		{
			get { return this.Get<string>("Description"); }
			set { this.Set<string>("Description", value); }
		}

		[MetaProperty(ColumnName = "STATUS", DbTypeName = "nvarchar", MaxLength = 3, AutoTrim = true)]
		[MaxLength(3)]
		public virtual string Status
		{
			get { return this.Get<string>("Status"); }
			set { this.Set<string>("Status", value); }
		}

		[MetaProperty(ColumnName = "META_STORE", DbTypeName = "text", MaxLength = 16, AutoTrim = true)]
		[MaxLength(16)]
		public virtual string MetaStore
		{
			get { return this.Get<string>("MetaStore"); }
			set { this.Set<string>("MetaStore", value); }
		}

		[MetaProperty(ColumnName = "CREATED_BY", DbTypeName = "int")]
		public virtual int? CreatedBy
		{
			get { return this.Get<int?>("CreatedBy"); }
			set { this.Set<int?>("CreatedBy", value); }
		}

		[MetaProperty(ColumnName = "CREATED_ON", DbTypeName = "int")]
		public virtual int? CreatedOn
		{
			get { return this.Get<int?>("CreatedOn"); }
			set { this.Set<int?>("CreatedOn", value); }
		}

		[MetaProperty(ColumnName = "UPDATED_BY", DbTypeName = "int")]
		public virtual int? UpdatedBy
		{
			get { return this.Get<int?>("UpdatedBy"); }
			set { this.Set<int?>("UpdatedBy", value); }
		}

		[MetaProperty(ColumnName = "UPDATED_ON", DbTypeName = "int")]
		public virtual int? UpdatedOn
		{
			get { return this.Get<int?>("UpdatedOn"); }
			set { this.Set<int?>("UpdatedOn", value); }
		}

		[MetaProperty(ColumnName = "PATH_DELIMITER", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string PathDelimiter
		{
			get { return this.Get<string>("PathDelimiter"); }
			set { this.Set<string>("PathDelimiter", value); }
		}

		[MetaProperty(ColumnName = "AVAILABLE_FOR_USERS", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string AvailableForUsers
		{
			get { return this.Get<string>("AvailableForUsers"); }
			set { this.Set<string>("AvailableForUsers", value); }
		}

		[MetaProperty(ColumnName = "AVAILABLE_FOR_LISTS", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string AvailableForLists
		{
			get { return this.Get<string>("AvailableForLists"); }
			set { this.Set<string>("AvailableForLists", value); }
		}


		#region Properties
		public class Meta
		{
			public static readonly MetaProperty Id = MetaObject.Get(typeof(Hierarchy))["Id"];
			public static readonly MetaProperty ProviderId = MetaObject.Get(typeof(Hierarchy))["ProviderId"];
			public static readonly MetaProperty Name = MetaObject.Get(typeof(Hierarchy))["Name"];
			public static readonly MetaProperty CommonName = MetaObject.Get(typeof(Hierarchy))["CommonName"];
			public static readonly MetaProperty HierarchyType = MetaObject.Get(typeof(Hierarchy))["HierarchyType"];
			public static readonly MetaProperty IsSynchronized = MetaObject.Get(typeof(Hierarchy))["IsSynchronized"];
			public static readonly MetaProperty SyncSource = MetaObject.Get(typeof(Hierarchy))["SyncSource"];
			public static readonly MetaProperty Description = MetaObject.Get(typeof(Hierarchy))["Description"];
			public static readonly MetaProperty Status = MetaObject.Get(typeof(Hierarchy))["Status"];
			public static readonly MetaProperty MetaStore = MetaObject.Get(typeof(Hierarchy))["MetaStore"];
			public static readonly MetaProperty CreatedBy = MetaObject.Get(typeof(Hierarchy))["CreatedBy"];
			public static readonly MetaProperty CreatedOn = MetaObject.Get(typeof(Hierarchy))["CreatedOn"];
			public static readonly MetaProperty UpdatedBy = MetaObject.Get(typeof(Hierarchy))["UpdatedBy"];
			public static readonly MetaProperty UpdatedOn = MetaObject.Get(typeof(Hierarchy))["UpdatedOn"];
			public static readonly MetaProperty PathDelimiter = MetaObject.Get(typeof(Hierarchy))["PathDelimiter"];
			public static readonly MetaProperty AvailableForUsers = MetaObject.Get(typeof(Hierarchy))["AvailableForUsers"];
			public static readonly MetaProperty AvailableForLists = MetaObject.Get(typeof(Hierarchy))["AvailableForLists"];
		}
		#endregion Properties

    }

	#region HierarchyMeta
	public partial class HierarchyMeta
	{
	}
	#endregion HierarchyMeta
}
