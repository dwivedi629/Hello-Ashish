﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Encryption;

namespace AtHoc.IWS.Business.Domain.Entities
{
	[MetadataType(typeof(DeviceAddressBaseMeta))]
	[MetaObject(TableName = "USR_DEVICE_ADDRESS_TAB")]
	public abstract partial class DeviceAddressBase : EntityBase
	{
		[MetaProperty(ColumnName = "ADDRESS_ID", DbTypeName = "int", IsKey = true, SequenceType = "ADDRESSID")]
		[Required]
		public virtual int Id
		{
			get { return this.Get<int>("Id"); }
			set { this.Set<int>("Id", value); }
		}

		[MetaProperty(ColumnName = "USER_ID", DbTypeName = "int")]
		[Required]
		public virtual int UserId
		{
			get { return this.Get<int>("UserId"); }
			set { this.Set<int>("UserId", value); }
		}

		[MetaProperty(ColumnName = "ADDRESS", DbTypeName = "nvarchar", MaxLength = 2000, AutoTrim = true)]
		[MaxLength(2000)]
		public virtual string Address
		{
			get { return this.Get<string>("Address"); }
			set { this.Set<string>("Address", value); }
		}

		[MetaProperty(ColumnName = "DEVICE_ID", DbTypeName = "int")]
		[Required]
		public virtual int DeviceId
		{
			get { return this.Get<int>("DeviceId"); }
			set { this.Set<int>("DeviceId", value); }
		}

		[MetaProperty(ColumnName = "IS_PRIMARY", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public virtual string IsPrimary
		{
			get { return this.Get<string>("IsPrimary"); }
			set { this.Set<string>("IsPrimary", value); }
		}

		[MetaProperty(ColumnName = "VALIDATION_CODE", DbTypeName = "nvarchar", MaxLength = 20, AutoTrim = true)]
		[MaxLength(20)]
		public virtual string ValidationCode
		{
			get { return this.Get<string>("ValidationCode"); }
			set { this.Set<string>("ValidationCode", value); }
		}

		[MetaProperty(ColumnName = "UPDATED_ON", DbTypeName = "datetime")]
		public virtual DateTime? UpdatedOn
		{
			get { return this.Get<DateTime?>("UpdatedOn"); }
			set { this.Set<DateTime?>("UpdatedOn", value); }
		}

		[MetaProperty(ColumnName = "UPDATED_BY_USERNAME", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string UpdatedByUsername
		{
			get { return this.Get<string>("UpdatedByUsername"); }
			set { this.Set<string>("UpdatedByUsername", value); }
		}

		[MetaProperty(ColumnName = "HASHED_CLEAN_ADDRESS", DbTypeName = "binary")]
		public virtual byte[] HashedCleanAddress
		{
			get { return this.Get<byte[]>("HashedCleanAddress"); }
			set { this.Set<byte[]>("HashedCleanAddress", value); }
		}


		#region Properties
		public class Meta
		{
			public static readonly MetaProperty Id = MetaObject.Get(typeof(DeviceAddressBase))["Id"];
			public static readonly MetaProperty UserId = MetaObject.Get(typeof(DeviceAddressBase))["UserId"];
			public static readonly MetaProperty Address = MetaObject.Get(typeof(DeviceAddressBase))["Address"];
			public static readonly MetaProperty DeviceId = MetaObject.Get(typeof(DeviceAddressBase))["DeviceId"];
			public static readonly MetaProperty IsPrimary = MetaObject.Get(typeof(DeviceAddressBase))["IsPrimary"];
			public static readonly MetaProperty ValidationCode = MetaObject.Get(typeof(DeviceAddressBase))["ValidationCode"];
			public static readonly MetaProperty UpdatedOn = MetaObject.Get(typeof(DeviceAddressBase))["UpdatedOn"];
			public static readonly MetaProperty UpdatedByUsername = MetaObject.Get(typeof(DeviceAddressBase))["UpdatedByUsername"];
			public static readonly MetaProperty HashedCleanAddress = MetaObject.Get(typeof(DeviceAddressBase))["HashedCleanAddress"];
		}
		#endregion Properties

    }

	#region DeviceAddressBaseMeta
	public partial class DeviceAddressBaseMeta
	{
	}
	#endregion DeviceAddressBaseMeta
}
