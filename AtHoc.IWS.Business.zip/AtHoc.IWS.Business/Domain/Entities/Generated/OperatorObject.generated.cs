﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Encryption;

namespace AtHoc.IWS.Business.Domain.Entities
{
    [MetadataType(typeof(OperatorObjectMeta))]
	[MetaObject(TableName = "UPS_OBJECT_TAB")]
	public partial class OperatorObject : EntityBase
    {

		[MetaProperty(ColumnName = "OBJECT_ID", DbTypeName = "int", IsKey = true)]
		[Required]
		public virtual int Id
		{
			get { return this.Get<int>("Id"); }
			set { this.Set<int>("Id", value); }
		}

		[MetaProperty(ColumnName = "OBJECT_NAME", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
		public virtual string ObjectName
		{
			get { return this.Get<string>("ObjectName"); }
			set { this.Set<string>("ObjectName", value); }
		}

		[MetaProperty(ColumnName = "DESCRIPTION", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string Description
		{
			get { return this.Get<string>("Description"); }
			set { this.Set<string>("Description", value); }
		}

        [MetaProperty(ColumnName = "COMMON_NAME", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
        [MaxLength(200)]
        public virtual string CommonName
        {
            get { return this.Get<string>("CommonName"); }
            set { this.Set<string>("CommonName", value); }
        }


		#region Properties
		public class Meta
		{
			public static readonly MetaProperty Id = MetaObject.Get(typeof(OperatorObject))["Id"];
			public static readonly MetaProperty ObjectName = MetaObject.Get(typeof(OperatorObject))["ObjectName"];
			public static readonly MetaProperty Description = MetaObject.Get(typeof(OperatorObject))["Description"];
            public static readonly MetaProperty CommonName = MetaObject.Get(typeof(OperatorObject))["CommonName"];
		}
		#endregion Properties

    }

	#region OperatorObjectMeta
	public partial class OperatorObjectMeta
	{
	}
	#endregion OperatorObjectMeta
}
