﻿using System;
using System.Collections.Generic;

using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Entity;

namespace AtHoc.IWS.Business.Domain.Entities
{
	public partial class CustomAttribute : ICommonName, IEntity
    {
        [MetaProperty(IsPersistable = false)]
        public new IEnumerable<CustomAttributeValue> Values
        {
            get { return this.Get<IEnumerable<CustomAttributeValue>>("Values"); }
            set { this.Set<IEnumerable<CustomAttributeValue>>("Values", value); }
        }

        [MetaProperty(IsPersistable = false)]
        public Targeting Targeting
        {
            get { return this.Get<Targeting>("Targeting"); }
            set { this.Set<Targeting>("Targeting", value); }
        }

	    [MetaProperty(IsPersistable = false,ColumnName = "ATTRIBUTE_ORIGIN", DbTypeName = "nvarchar", AutoTrim = true)]
	    public string AttributeOrigin
	    {
	        get { return this.Get<string>("AttributeOrigin"); }
	        set {this.Set<string>("AttributeOrigin",value); }
	    }

	    [MetaProperty(IsPersistable = false, ColumnName = "FULLY_CONFIGURABLE", DbTypeName = "nvarchar", AutoTrim = true)]
	    public string FullyConfigurable
	    {
            get { return this.Get<string>("FullyConfigurable"); }
	        set { this.Set<string>("FullyConfigurable",value);}
	    }

	    [MetaProperty(IsPersistable = false, ColumnName = "ATTRIBUTE_TYPE", DbTypeName = "nvarchar", AutoTrim = true)]
	    public string AttributeType
	    {
	        get { return this.Get<string>("AttributeType"); }
	        set { this.Set<string>("AttributeType", value); }
	    }

        [MetaProperty(IsPersistable = false)]
        public object UserAttributeValue { get; set; }

        [MetaProperty(IsPersistable = false)]
        public bool IsNewUser { get; set; }

        [MetaProperty(IsPersistable = false)]
        public DateTime UpdatedDateStamp { get; set; }

        [MetaProperty(IsPersistable = false, ColumnName = "LOCALE_CODE", DbTypeName = "nvarchar", AutoTrim = true)]
        public string LocaleCode
        {
            get { return this.Get<string>("LocaleCode"); }
            set { this.Set<string>("LocaleCode", value); }
        }
        public Type GetPropertyType()
        {
            switch (this.AttributeTypeId.Value)
            {
                case CustomAttributeDataType.Number:
                    return typeof(int);

                case CustomAttributeDataType.Date:
                case CustomAttributeDataType.DateTime:
                    return typeof(DateTime);

                case CustomAttributeDataType.GeoLocation:
                    return typeof(string);
                    //this works but for now just return as string
                    //return typeof(SqlGeography);

                case CustomAttributeDataType.MultiPicklist:
                    return typeof(List<string>);

                case CustomAttributeDataType.Checkbox:                
                case CustomAttributeDataType.Memo:
                case CustomAttributeDataType.Path:
                case CustomAttributeDataType.Picklist:
                case CustomAttributeDataType.String:
                    return typeof(string);

                case CustomAttributeDataType.Unknown:
                case CustomAttributeDataType.AttributeValue:
                case CustomAttributeDataType.Entity:
                case CustomAttributeDataType.Object:
                default:
                    return typeof(object);
            }
        }


        public string GetDataFormat(Provider provider)
        {
            string dataFormat = string.Empty;
            switch (this.AttributeTypeId)
            {
                case CustomAttributeDataType.Device:
                    dataFormat = provider.GetDeviceFormat(); 
                    break;
                case CustomAttributeDataType.Date:
                    dataFormat = provider.GetDateFormat();
                    break;
                case CustomAttributeDataType.DateTime:
                    dataFormat = provider.GetDateTimeFormat();
                    break;
                default:
                    break;
            }
            return dataFormat;
        }
    }

    public class UserAttribute : EntityBase
    {
        
        [MetaProperty(ColumnName = "ATTRIBUTE_ID", IsPersistable = false, DbTypeName = "int")]
        public virtual int Id
        {
            get { return this.Get<int>("Id"); }
            set { this.Set<int>("Id", value); }
        }

        [MetaProperty(ColumnName = "COMMON_NAME", IsPersistable = false, DbTypeName = "nvarchar", AutoTrim = true)]
        public virtual string CommonName
        {
            get { return this.Get<string>("CommonName"); }
            set { this.Set<string>("CommonName", value); }
        }

        [MetaProperty(ColumnName = "ATTRIBUTE_NAME", IsPersistable = false, DbTypeName = "nvarchar", AutoTrim = true)]
        public virtual string AttributeName
        {
            get { return this.Get<string>("AttributeName"); }
            set { this.Set<string>("AttributeName", value); }
        }

        [MetaProperty(ColumnName = "VALUE", IsPersistable = false, DbTypeName = "nvarchar", AutoTrim = true)]
        public virtual string Value
        {
            get { return this.Get<string>("Value"); }
            set { this.Set<string>("Value", value); }
        }

        [MetaProperty(ColumnName = "DISPLAY_VALUE", IsPersistable = false, DbTypeName = "nvarchar", AutoTrim = true)]
        public virtual string DisplayValue
        {
            get { return this.Get<string>("DisplayValue"); }
            set { this.Set<string>("DisplayValue", value); }
        }

        [MetaProperty(ColumnName = "META_DATA", IsPersistable = false, DbTypeName = "nvarchar", AutoTrim = true)]
        public virtual string MetaData
        {
            get { return this.Get<string>("MetaData"); }
            set { this.Set<string>("MetaData", value); }
        }

        [MetaProperty(ColumnName = "attribute_type_id", IsPersistable = false, DbTypeName = "int")]
        public virtual int AttributeTypeId
        {
            get { return this.Get<int>("AttributeTypeId"); }
            set { this.Set<int>("AttributeTypeId", value); }
        }


        [MetaProperty(ColumnName = "UPDATED_ON", IsPersistable = false, DbTypeName = "datetime")]
        public virtual DateTime UpdatedOn
        {
            get { return this.Get<DateTime>("UpdatedOn"); }
            set { this.Set<DateTime>("UpdatedOn", value); }
        }

        [MetaProperty(ColumnName = "UPDATED_BY", IsPersistable = false, DbTypeName = "nvarchar", AutoTrim = true)]
        public virtual string UpdatedBy
        {
            get { return this.Get<string>("UpdatedBy"); }
            set { this.Set<string>("UpdatedBy", value); }
        }

        [MetaProperty(ColumnName = "UPDATED_FROM", IsPersistable = false, DbTypeName = "nvarchar", AutoTrim = true)]
        public virtual string UpdatedFrom
        {
            get { return this.Get<string>("UpdatedFrom"); }
            set { this.Set<string>("UpdatedFrom", value); }
        }

        [MetaProperty(ColumnName = "ATTRIBUTE_TYPE", IsPersistable = false, DbTypeName = "nvarchar", AutoTrim = true)]
        public virtual string AttributeType
        {
            get { return this.Get<string>("AttributeType"); }
            set { this.Set<string>("AttributeType", value); }
        }

    }
}
