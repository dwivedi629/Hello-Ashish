﻿using AtHoc.Infrastructure.Entity;

namespace AtHoc.IWS.Business.Domain.Entities
{
	public class UserDevice : EntityBase {}

	public class UserAttributes : EntityBase {}
}
