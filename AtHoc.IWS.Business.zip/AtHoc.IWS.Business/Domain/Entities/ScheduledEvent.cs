﻿using System.ComponentModel.DataAnnotations;

using AtHoc.Business.Domain;
using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;

namespace AtHoc.IWS.Business.Domain.Entities
{
	[MetadataType(typeof(ScheduledEventMeta))]
	[MetaObject(TableName = "SCD_EVENT_TAB")]
	public class ScheduledEvent : EntityBase
	{
#warning Use sequnce type here...
		[MetaProperty(ColumnName = "JOB_ID", DbTypeName = "int", IsKey = true, SequenceType = "SCD_JOB")]
		public virtual int? JobId
		{
			get { return Get<int>("JobId"); }
			set { Set("JobId", value); }
		}

		[MetaProperty(ColumnName = "RUN_ON", DbTypeName = "int")]
		public virtual int? RunOn
		{
			get { return Get<int>("RunOn"); }
			set { Set("RunOn", value); }
		}

		[MetaProperty(ColumnName = "PRIORITY", DbTypeName = "smallint")]
		public virtual short? Priority
		{
			get { return Get<short>("Priority"); }
			set { Set("Priority", value); }
		}

		[MetaProperty(ColumnName = "PAYLOAD", DbTypeName = "nvarchar")]
		public virtual string Payload
		{
			get { return Get<string>("Payload"); }
			set { Set("Payload", value); }
		}

		[MetaProperty(ColumnName = "TIMEOUT_INTERVAL", DbTypeName = "int")]
		public virtual int? TimeoutInterval
		{
			get { return Get<int?>("TimeoutInterval"); }
			set { Set("TimeoutInterval", value); }
		}

		[MetaProperty(ColumnName = "STATUS", DbTypeName = "nvarchar", MaxLength = 3, AutoTrim = true)]
		[MaxLength(3)]
		public virtual SheduledEventStatusType? Status
		{
			get { return Get<SheduledEventStatusType>("Status"); }
			set { Set("Status", value); }
		}

		[MetaProperty(ColumnName = "PICKUP_TIME", DbTypeName = "int")]
		public IntDateTime PickupTime
		{
			get { return Get<IntDateTime>("PickupTime"); }
			set { Set("PickupTime", value); }
		}

		[MetaProperty(ColumnName = "SCD_TYPE", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public string ScdType
		{
			get { return Get<string>("ScdType"); }
			set { Set("ScdType", value); }
		}

		[MetaProperty(ColumnName = "SCHEDULE_ID", DbTypeName = "int")]
		public int? ScheduleId
		{
			get { return Get<int?>("ScheduleId"); }
			set { Set("ScheduleId", value); }
		}

		[MetaProperty(ColumnName = "DB_ADMIN_LOGIN_REQUIRED_YN", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
		[MaxLength(1)]
		public string DbAdminLoginRequired
		{
			get { return Get<string>("DbAdminLoginRequired"); }
			set { Set("DbAdminLoginRequired", value); }
		}

        [MetaProperty(ColumnName = "RETRY_YN", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
        [MaxLength(1)]
        public string RetryRequired
        {
            get { return Get<string>("RetryRequired"); }
            set { Set("RetryRequired", value); }
        }


        [MetaProperty(ColumnName = "PICKUP_COUNT", DbTypeName = "int")]
        public virtual int? PickupCount
        {
            get { return Get<int?>("PickupCount"); }
            set { Set("PickupCount", value); }
        }
		#region Properties
		public class Meta
		{
			public static readonly MetaProperty JobId = MetaObject.Get(typeof(ScheduledEvent))["JobId"];
			public static readonly MetaProperty RunOn = MetaObject.Get(typeof(ScheduledEvent))["RunOn"];
			public static readonly MetaProperty Priority = MetaObject.Get(typeof(ScheduledEvent))["Priority"];
			public static readonly MetaProperty Payload = MetaObject.Get(typeof(ScheduledEvent))["Payload"];
			public static readonly MetaProperty TimeoutInterval = MetaObject.Get(typeof(ScheduledEvent))["TimeoutInterval"];
			public static readonly MetaProperty Status = MetaObject.Get(typeof(ScheduledEvent))["Status"];
			public static readonly MetaProperty PickupTime = MetaObject.Get(typeof(ScheduledEvent))["PickupTime"];
			public static readonly MetaProperty ScdType = MetaObject.Get(typeof(ScheduledEvent))["ScdType"];
			public static readonly MetaProperty ScheduleId = MetaObject.Get(typeof(ScheduledEvent))["ScheduleId"];
			public static readonly MetaProperty DbAdminLoginRequired = MetaObject.Get(typeof(ScheduledEvent))["DbAdminLoginRequired"];
            public static readonly MetaProperty RetryRequired = MetaObject.Get(typeof(ScheduledEvent))["RetryRequired"];
            public static readonly MetaProperty PickupCount = MetaObject.Get(typeof(ScheduledEvent))["PickupCount"];
		}
		#endregion Properties
	}

	#region ActivityFeedMeta
	public partial class ScheduledEventMeta
	{
	}
	#endregion ActivityFeedMeta
}
