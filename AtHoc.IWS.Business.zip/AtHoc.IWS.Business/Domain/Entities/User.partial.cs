﻿using System;
using System.Collections.Generic;

using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Meta;

namespace AtHoc.IWS.Business.Domain.Entities
{
	public partial class User
	{
		public User()
		{
			UserDevice = new UserDevice();
			Password = String.Empty;
			UserTypeId = "RG";
			CreateType = "NA";
		}

		[MetaProperty(IsPersistable = false)]
		public UserDevice UserDevice
		{
			get { return Get<UserDevice>("UserDevice"); }
			set { Set("UserDevice", value); }
		}

		[MetaProperty(IsPersistable = false)]
		public IEnumerable<UserAttribute> UserAttributes
		{
			get { return Get<IEnumerable<UserAttribute>>("UserAttributes"); }
			set { Set("UserAttributes", value); }
		}

		[MetaProperty(IsPersistable = false, ColumnName = "FIRST_NAME", DbTypeName = "nvarchar", AutoTrim = true)]
		public virtual string FirstName
		{
			get { return Get<string>("FirstName"); }
			set { Set("FirstName", value); }
		}

		[MetaProperty(IsPersistable = false, ColumnName = "LAST_NAME", DbTypeName = "nvarchar", AutoTrim = true)]
		public virtual string LastName
		{
			get { return Get<string>("LastName"); }
			set { Set("LastName", value); }
		}

		[MetaProperty(IsPersistable = false, ColumnName = "USERNAME", DbTypeName = "nvarchar", AutoTrim = true)]
		public virtual string UserName
		{
			get { return Get<string>("UserName"); }
            set { Set("UserName", value); }
		}

        [MetaProperty(IsPersistable = false, ColumnName = "MAPPING_ID", DbTypeName = "nvarchar", AutoTrim = true)]
        public virtual string MappingId
        {
            get { return Get<string>("MappingId"); }
            set { Set("MappingId", value); }
        }

		[MetaProperty(IsPersistable = false)]
		public string Password
		{
			get { return Get<string>("Password"); }
			set { Set("Password", value); }
		}

		[MetaProperty(IsPersistable = false, ColumnName = "USER_STATUS_ID", DbTypeName = "nvarchar", AutoTrim = true)]
		public UserStatusType Status
		{
			get { return Get<UserStatusType>("Status"); }
		}

		public string GetDisplayName()
		{
			return DisplayName.IsNotNullOrEmpty()
				? DisplayName
				: ("{0} {1}".FormatWith(FirstName, LastName)).IsNotNullOrEmpty()
					? "{0} {1}".FormatWith(FirstName, LastName)
					: UserName;
		}

        public string GetShortDisplayName()
        {
            return DisplayName.IsNotNullOrEmpty()
                ? DisplayName
                : FirstName.IsNotNullOrEmpty()
                ? FirstName : LastName.IsNotNullOrEmpty() 
                ? LastName : UserName;
        }
	}
}