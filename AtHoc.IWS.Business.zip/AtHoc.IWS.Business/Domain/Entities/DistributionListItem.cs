﻿using System.ComponentModel.DataAnnotations;

using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;

namespace AtHoc.IWS.Business.Domain.Entities
{
	[MetadataType(typeof (DistributionListItemMeta))]
	[MetaObject(TableName = "PDL_LISTITEM_VUE")]
	public class DistributionListItem : EntityBase
	{
		[MetaProperty(ColumnName = "LIST_ID", DbTypeName = "int", IsKey = true)]
		[Required]
		public virtual int Id
		{
			get { return Get<int>("Id"); }
			set { Set("Id", value); }
		}

		[MetaProperty(ColumnName = "NAME", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
		public virtual string Name
		{
			get { return Get<string>("Name"); }
			set { Set("Name", value); }
		}

		[MetaProperty(ColumnName = "COMMON_NAME", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
		public virtual string CommonName
		{
			get { return Get<string>("CommonName"); }
			set { Set("CommonName", value); }
		}

		[MetaProperty(ColumnName = "DESCRIPTION", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string Description
		{
			get { return Get<string>("Description"); }
			set { Set("Description", value); }
		}

		[MetaProperty(ColumnName = "USER_COUNT", DbTypeName = "int", IsKey = true)]
		[Required]
		public virtual int UserCount
		{
			get { return Get<int>("UserCount"); }
			set { Set("UserCount", value); }
		}

		[MetaProperty(ColumnName = "LIST_TYPE", DbTypeName = "nvarchar")]
		[Required]
		public virtual ListItemType? ListType
		{
			get { return Get<ListItemType?>("ListType"); }
			set { Set("ListType", value); }
		}

		[MetaProperty(ColumnName = "LINEAGE", DbTypeName = "nvarchar", MaxLength = 500, AutoTrim = true)]
		[MaxLength(500)]
		public virtual string Lineage
		{
			get { return Get<string>("Lineage"); }
			set { Set("Lineage", value); }
		}

		[MetaProperty(ColumnName = "PROVIDER_ID", DbTypeName = "int")]
		[Required]
		public virtual int ProviderId
		{
			get { return Get<int>("ProviderId"); }
			set { Set("ProviderId", value); }
		}

		[MetaProperty(ColumnName = "PROVIDER_NAME", DbTypeName = "nvarchar", MaxLength = 64, AutoTrim = true)]
		[MaxLength(64)]
		public virtual string ProviderName
		{
			get { return Get<string>("ProviderName"); }
			set { Set("ProviderName", value); }
		}

		[MetaProperty(ColumnName = "IS_SYSTEM", DbTypeName = "nvarchar")]
		[Required]
		public virtual string IsSystem
		{
			get { return Get<string>("IsSystem"); }
			set { Set("IsSystem", value); }
		}

		#region Properties

		public class Meta
		{
			public static readonly MetaProperty Id = MetaObject.Get(typeof (DistributionListItem))["Id"];
			public static readonly MetaProperty Name = MetaObject.Get(typeof (DistributionListItem))["Name"];
			public static readonly MetaProperty CommonName = MetaObject.Get(typeof(DistributionListItem))["CommonName"];
			public static readonly MetaProperty UserCount = MetaObject.Get(typeof (DistributionListItem))["UserCount"];
			public static readonly MetaProperty ListType = MetaObject.Get(typeof (DistributionListItem))["ListType"];
			public static readonly MetaProperty Lineage = MetaObject.Get(typeof (DistributionListItem))["Lineage"];
			public static readonly MetaProperty ProviderId = MetaObject.Get(typeof (DistributionListItem))["ProviderId"];
			public static readonly MetaProperty ProviderName = MetaObject.Get(typeof (DistributionListItem))["ProviderName"];
			public static readonly MetaProperty IsSynchronized = MetaObject.Get(typeof (DistributionListItem))["IsSynchronized"];
			public static readonly MetaProperty IsSystem = MetaObject.Get(typeof(DistributionListItem))["IsSystem"];
		}

		#endregion Properties
	}

	#region DistributionListItemMeta

	public class DistributionListItemMeta
	{
	}

	#endregion DistributionListItemMeta
}