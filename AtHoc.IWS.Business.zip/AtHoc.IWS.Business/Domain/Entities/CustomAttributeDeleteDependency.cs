﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Entities
{
    public class CustomAttributeDeleteDependency
    {
        public int? ProviderId { get; set; }
        public int? EntityId { get; set; }
        public string EntityName { get; set; }
        public string UsedFor { get; set; }
        public string UsedIn { get; set; }
        public string SourceProvider { get; set; }
    }

    public class PlaceholderDeleteDependency
    {
        public int? ProviderId { get; set; }
        public int? AlertId { get; set; }
        public string EntityName { get; set; }
    }
}
