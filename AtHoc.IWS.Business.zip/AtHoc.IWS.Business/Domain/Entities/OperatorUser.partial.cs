﻿using System;
using System.Collections.Generic;

using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Meta;
using AtHoc.IWS.Business.Data;

namespace AtHoc.IWS.Business.Domain.Entities
{
	public interface IAccessProvider
	{
		IEnumerable<OperatorAccess> OperatorAccess { get; }
	}

	public partial class OperatorUser : IAccessProvider
	{

		public OperatorUser()
		{
			CurrentFailedAttempts = 0;
			LastFailedAttempts = 0;
			CurrentLoginMachineName = String.Empty;
			LastLoginMachineName = String.Empty;
			CurrentLoginTime = 0;
			LastLoginTime = 0;
			LastFailedAttemptTime = 0;
			FullName = String.Empty;
			LastName = String.Empty;
		}

		[MetaProperty(IsPersistable = false)]
		public string DisplayName
		{
            get
            {
                var displayName = FullName.IsNotNullOrEmpty()? FullName: "{0} {1}".FormatWith(FirstName, LastName);
                if (displayName.IsNullOrEmpty())
                    displayName = Username;

                return displayName;
            }
		}

	    [MetaProperty(IsPersistable = false)]
		public bool IsExpired
		{
			get { return false; }
		}

		[MetaProperty(IsPersistable = false)]
		public IEnumerable<OperatorAccess> OperatorAccess { get; set; }

        [MetaProperty(IsPersistable = false)]
        public bool HasMultipleVpsAccess { get; set; }


        [MetaProperty(IsPersistable = false)]
        public bool IsTeamMember { get; set; }

        [MetaProperty(IsPersistable = false)]
        public string ShortDisplayName { get; set; }


		[MetaProperty(IsPersistable = false)]
		public ICriteria UserBase
		{
			get { return this.Get<ICriteria>("UserBase"); }
			set { this.Set<ICriteria>("UserBase", value); }
		}

        [MetaProperty(IsPersistable = false)]
	    public int? TeamId { get; set; }

        [MetaProperty(IsPersistable = false)]
        public bool IsRestricted { get; set; }
	}
}