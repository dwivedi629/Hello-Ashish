﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using System.ComponentModel;
using AtHoc.Global.Resources.Entities;
using AtHoc.Infrastructure;

namespace AtHoc.IWS.Business.Domain.Entities
{
    public class PlaceHolder
    {
        public PlaceHolder()
        {
            ProviderId = 0;
            ScenarioId = 0;
            CommonName = String.Empty;
            Name = String.Empty;
            ControlType = PlaceHolderControlType.Text;
            DisplayType = PlaceHolderType.Custom;
            MinimumLength = 0;
            MaximumLength = 0;
            DisplayLines = 0;
            AttributeTypeId = 0;
            DefaultText = String.Empty;
            IsStandard = String.Empty;
        }

        internal const int SYSTEM_PLACEHOLDERS_VPS_ID = 3;

        public int ProviderId;

        public int ScenarioId;

        public int Id;

        public String CommonName;

        public String Name;

        public PlaceHolderControlType ControlType;

        public PlaceHolderType DisplayType;

        public int MinimumLength;

        public int MaximumLength;

        public int DisplayLines;

        public IEnumerable<PlaceHolderValue> Values;

        public int AttributeTypeId;
        public string DefaultText;
        public string DefaultValue { get; set; }
        public bool IsSystem
        {
            get { return ProviderId == SYSTEM_PLACEHOLDERS_VPS_ID; }
        }
        public string IsStandard { get; set; }
    }

    public enum PlaceHolderType
    {
        System,
        Custom
    }

    public enum PlaceHolderControlType
    {
        SingleSelection,
        MultiSelection,
        Memo,
        Text,
        Date,
        DateTime,
        Time
    }

    public static class EnumMap
    {
        public static AttributeTypes ToAttributeType(this PlaceHolderControlType value)
        {
            switch (value)
            {
                case PlaceHolderControlType.SingleSelection:
                    return AttributeTypes.Picklist;
                case PlaceHolderControlType.MultiSelection:
                    return AttributeTypes.MultiPicklist;
                case PlaceHolderControlType.Memo:
                    return AttributeTypes.String;
                case PlaceHolderControlType.Text:
                    return AttributeTypes.String;
                case PlaceHolderControlType.Date:
                    return AttributeTypes.Date;
                case PlaceHolderControlType.DateTime:
                    return AttributeTypes.DateTime;
                case PlaceHolderControlType.Time:
                    return AttributeTypes.Time;
                default:
                    return AttributeTypes.String;
            }
        }

        public static PlaceHolderControlType ToPlaceHolderType(this AttributeTypes value)
        {
            switch (value)
            {
                case AttributeTypes.Picklist:
                    return PlaceHolderControlType.SingleSelection;
                case AttributeTypes.MultiPicklist:
                    return PlaceHolderControlType.MultiSelection;
                case AttributeTypes.Memo:
                    return PlaceHolderControlType.Text;
                case AttributeTypes.String:
                    return PlaceHolderControlType.Text;
                case AttributeTypes.Date:
                    return PlaceHolderControlType.Date;
                case AttributeTypes.DateTime:
                    return PlaceHolderControlType.DateTime;
                case AttributeTypes.Time:
                    return PlaceHolderControlType.Time;
                default:
                    return PlaceHolderControlType.Text;
            }
        }
    }

    public enum AttributeTypes
    {
        Number = 1,
        String = 2,
        Memo = 3,
        Date = 4,
        DateTime = 5,
        Picklist = 6,
        MultiPicklist = 7,
        Checkbox = 8,
        Path = 9,
        Geography = 10,
        Time = 11,
    }
    public class PlaceHolderValue
    {
        public int Id;

        public String Name;

        public String Value;

        public bool IsDefault;
    }

    public class PlaceHolderValueComparer : IEqualityComparer<PlaceHolderValue>
    {
        public bool Equals(PlaceHolderValue x, PlaceHolderValue y)
        {
            return (x.Id == y.Id) && x.Name == y.Name && x.Value == y.Value;
        }

        public int GetHashCode(PlaceHolderValue obj)
        {
            return obj.Id.ToString().GetHashCode();
        }
    }

    public class PlaceHolderSimpleItem
    {
        public int Id { get; set; }

        public bool IsSystem { get; set; }

        public string Name { get; set; }

        public string DisplayName { get { return string.Format("[[{0}]]", Name); } }
    }

    public class SystemPlaceholders
    {
        public string OperatorFullName { get; set; }
        public string SystemName { get; set; }
        public string OrganizationId { get; set; }
        public string OrganizationName { get; set; }
        public string PublishDate { get; set; }
        public string PublishTime { get; set; }
        public string TimeZone { get; set; }
        public Dictionary<string, string> GetSystemStaticPlaceholders()
        {
            return new Dictionary<string, string>
            {
                {SystemPlaceHolderTypes.OperatorFullName.GetDescription(), OperatorFullName},
                {SystemPlaceHolderTypes.SystemName.GetDescription(), AtHoc.Systems.AtHocSystem.Local.Name},
                {SystemPlaceHolderTypes.OrganizationID.GetDescription(), OrganizationId},
                {SystemPlaceHolderTypes.OrganizationName.GetDescription(), OrganizationName},
                {SystemPlaceHolderTypes.PublishDate.GetDescription(), PublishDate},
                {SystemPlaceHolderTypes.PublishTime.GetDescription(), PublishTime},
                {SystemPlaceHolderTypes.TimeZone.GetDescription(), TimeZone}
            };
        }
    }

    public enum SystemPlaceHolderTypes
    {
        /// <summary>
        /// Publish Date
        /// </summary>
        [Description("PUBLISH-DATE")]
        PublishDate,            // using VPS TZ

        /// <summary>
        /// Publish Time
        /// </summary>
        [Description("PUBLISH-TIME")]
        PublishTime,            // using VPS TZ

        /// <summary>
        /// Virtual System Time Zone
        /// </summary>
        [Description("TIME-ZONE")]
        TimeZone,               // which TX was used to show date time

        /// <summary>
        /// Virtual System Id
        /// </summary>
        [Description("VIRTUAL-SYSTEM-ID")]
        OrganizationID,

        /// <summary>
        /// Virtual System Name
        /// </summary>
        [Description("VIRTUAL-SYSTEM-NAME")]
        OrganizationName,      // VPS Name

        /// <summary>
        /// FirstName LastName
        /// </summary>
        [Description("OPERATOR-FULL-NAME")]
        OperatorFullName,       // FirstName LastName

        /// <summary>
        /// Operator Email
        /// </summary>
        [Description("OPERATOR-EMAIL")]
        OperatorEmail,          // 

        /// <summary>
        /// Local System Name 
        /// </summary>
        [Description("SYSTEM-NAME")]
        SystemName              // Local System Name
    }

    public class EventPlaceholders
    {
        [LocalizationEntityId(BusinessEntity.EventPlaceholder)]
        public string EventPlaceholderId { get; set; }
        [LocalizationEntityProperty(BusinessEntity.EventPlaceholder, "Name")]
        public string EventPlaceholderName { get; set; }
        public string EventPlaceholderDisplayName { get; set; }

    }
}
