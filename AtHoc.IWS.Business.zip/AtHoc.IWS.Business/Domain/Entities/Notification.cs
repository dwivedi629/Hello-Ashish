﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Spatial;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Notification
{
    public class Notification
    {
        public int ProviderId { get; set; }
        public string ContentId { get; set; }
        public DateTime LastUpdatedOn { get; set; }
    }

    public class ShapeNotification
    {
        public int Id { get; set; }
        public DateTime UpdatedOn { get; set; }
        public int LayerId { get; set; }
        public string Name { get; set; }
        public DbGeometry Geometry { get; set; }
        public virtual MapLayer MapLayer { get; set; }
    }

    public class MapLayer
    {
        public MapLayer()
        {
            ShapeNotifications = new List<ShapeNotification>();
        }

        public int Id { get; set; }
        public int ProviderId { get; set; }
        public string IsPredefinedZone { get; set; }
        public string Name { get; set; }
        public DateTime? UpdatedOn { get; set; }
        // sourceType 0 means shape layer, 2 means people layer
        public int SourceType { get; set; }
        public string Status { get; set; }
        public virtual ICollection<ShapeNotification> ShapeNotifications { get; set; }

        public string FillColor { get; set; }

        public string IsDisplayOnly { get; set; }

        public int? SortOrder { get; set; }
    }

    public class AlertNotification
    {
        public int Id { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public int ProviderId { get; set; }
    }

    public class ResponseNotification
    {
        public int Id { get; set; }
        //why updated_on in this table is int instead of datetime?
        public int? UpdatedOn { get; set; }
        public int UserId { get; set; }
        public int? Status { get; set; }
        public virtual User User { get; set; }

    }

    public class User
    {
        public User()
        {
            responseNotification = new List<ResponseNotification>();
            peopleNotification = new List<PeopleNotification>();
        }

        public int Id { get; set; }
        public int ProviderId { get; set; }

        public virtual ICollection<ResponseNotification> responseNotification { get; set; }
        public virtual ICollection<PeopleNotification> peopleNotification { get; set; }
    }

    public class PeopleNotification
    {
        public int Id { get; set; }
        public int UpdatedOn { get; set; }
        public int UserId { get; set; }
        public int AttributeId { get; set; }
        public virtual User User { get; set; }
    }

    public class LastLocation
    {
        public int Id { get; set; }
        public string AttributeName { get; set; }
    }

}
