﻿using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using System.ComponentModel.DataAnnotations;

namespace AtHoc.IWS.Business.Domain.Entities
{
    [MetadataType(typeof(ScheduledEntityMeta))]
    [MetaObject(TableName = "SCD_SCHEDULE_TAB")]
    public class ScheduledEntity : EntityBase
    {
        [MetaProperty(ColumnName = "SCHEDULE_ID", DbTypeName = "int")]
        public int ScheduleId
        {
            get { return Get<int>("ScheduleId"); }
            set { Set("ScheduleId", value); }
        }

        [MetaProperty(ColumnName = "NAME", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
        [MaxLength(100)]
        public virtual string Name
        {
            get { return Get<string>("Name"); }
            set { Set("Name", value); }
        }

        [MetaProperty(ColumnName = "RUN_ON", DbTypeName = "int")]
        public int RunOn
        {
            get { return Get<int>("RunOn"); }
            set { Set("RunOn", value); }
        }

        [MetaProperty(ColumnName = "EXPIRE_ON", DbTypeName = "int")]
        public int ExpireOn
        {
            get { return Get<int>("ExpireOn"); }
            set { Set("ExpireOn", value); }
        }

        [MetaProperty(ColumnName = "INTERVAL", DbTypeName = "int")]
        public int Interval
        {
            get { return Get<int>("Interval"); }
            set { Set("Interval", value); }
        }

        [MetaProperty(ColumnName = "PRIORITY", DbTypeName = "smallint")]
        public virtual short? Priority
        {
            get { return Get<short>("Priority"); }
            set { Set("Priority", value); }
        }

        [MetaProperty(ColumnName = "IS_DISABLED", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
        [MaxLength(1)]
        public virtual string IsDisabled
        {
            get { return Get<string>("IsDisabled"); }
            set { Set("IsDisabled", value); }
        }

        [MetaProperty(ColumnName = "PAYLOAD", DbTypeName = "nvarchar")]
        public virtual string Payload
        {
            get { return Get<string>("Payload"); }
            set { Set("Payload", value); }
        }

        [MetaProperty(ColumnName = "DESCRIPTION", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
        [MaxLength(200)]
        public virtual string Description
        {
            get { return Get<string>("Description"); }
            set { Set("Description", value); }
        }

        [MetaProperty(ColumnName = "TIMEOUT_INTERVAL", DbTypeName = "int")]
        public int TimeoutInterval
        {
            get { return Get<int>("TimeoutInterval"); }
            set { Set("TimeoutInterval", value); }
        }

        [MetaProperty(ColumnName = "MAX_INSTANCE_COUNT", DbTypeName = "smallint")]
        public virtual short? MaxInstanceCount
        {
            get { return Get<short>("MaxInstanceCount"); }
            set { Set("MaxInstanceCount", value); }
        }
        
        [MetaProperty(ColumnName = "HISTORY_RECORDS", DbTypeName = "int")]
        public int HistoryRecords
        {
            get { return Get<int>("HistoryRecords"); }
            set { Set("HistoryRecords", value); }
        }

        [MetaProperty(ColumnName = "SHOW_IN_JOB_MANAGER", DbTypeName = "nchar", MaxLength = 1, AutoTrim = true)]
        [MaxLength(1)]
        public virtual string ShowInJobManager
        {
            get { return Get<string>("ShowInJobManager"); }
            set { Set("ShowInJobManager", value); }
        }

        [MetaProperty(ColumnName = "UI_USER_CONTROL", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
        [MaxLength(100)]
        public virtual string UiUserControl
        {
            get { return Get<string>("UiUserControl"); }
            set { Set("UiUserControl", value); }
        }

        [MetaProperty(ColumnName = "ADDITIONAL_INFO", DbTypeName = "nvarchar")]
        public virtual string AdditionalInfo
        {
            get { return Get<string>("AdditionalInfo"); }
            set { Set("AdditionalInfo", value); }
        }

        [MetaProperty(ColumnName = "DB_ADMIN_LOGIN_REQUIRED_YN", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
        [MaxLength(1)]
        public string DbAdminLoginRequired
        {
            get { return Get<string>("DbAdminLoginRequired"); }
            set { Set("DbAdminLoginRequired", value); }
        }

        [MetaProperty(ColumnName = "INTERVAL_UNIT", DbTypeName = "nvarchar", MaxLength = 10, AutoTrim = true)]
        [MaxLength(10)]
        public virtual string IntervalUnit
        {
            get { return Get<string>("IntervalUnit"); }
            set { Set("IntervalUnit", value); }
        }

        [MetaProperty(ColumnName = "RETRY_YN", DbTypeName = "nvarchar", MaxLength = 1, AutoTrim = true)]
        [MaxLength(1)]
        public string RetryRequired
        {
            get { return Get<string>("RetryRequired"); }
            set { Set("RetryRequired", value); }
        }

        #region Properties
        public class Meta
        {
            public static readonly MetaProperty ScheduleId = MetaObject.Get(typeof(ScheduledEvent))["ScheduleId"];
            public static readonly MetaProperty Name = MetaObject.Get(typeof(ScheduledEvent))["Name"];
            public static readonly MetaProperty RunOn = MetaObject.Get(typeof(ScheduledEvent))["RunOn"];
            public static readonly MetaProperty ExpireOn = MetaObject.Get(typeof(ScheduledEvent))["ExpireOn"];
            public static readonly MetaProperty Interval = MetaObject.Get(typeof(ScheduledEvent))["Interval"];
            public static readonly MetaProperty Priority = MetaObject.Get(typeof(ScheduledEvent))["Priority"];
            public static readonly MetaProperty IsDisabled = MetaObject.Get(typeof(ScheduledEvent))["IsDisabled"];
            public static readonly MetaProperty Payload = MetaObject.Get(typeof(ScheduledEvent))["Payload"];
            public static readonly MetaProperty Description = MetaObject.Get(typeof(ScheduledEvent))["Description"];
            public static readonly MetaProperty TimeoutInterval = MetaObject.Get(typeof(ScheduledEvent))["TimeoutInterval"];
            public static readonly MetaProperty MaxInstanceCount = MetaObject.Get(typeof(ScheduledEvent))["MaxInstanceCount"];
            public static readonly MetaProperty HistoryRecords = MetaObject.Get(typeof(ScheduledEvent))["HistoryRecords"];
            public static readonly MetaProperty ShowInJobManager = MetaObject.Get(typeof(ScheduledEvent))["ShowInJobManager"];
            public static readonly MetaProperty UiUserControl = MetaObject.Get(typeof(ScheduledEvent))["UiUserControl"];
            public static readonly MetaProperty AdditionalInfo = MetaObject.Get(typeof(ScheduledEvent))["AdditionalInfo"];
            public static readonly MetaProperty DbAdminLoginRequired = MetaObject.Get(typeof(ScheduledEvent))["DbAdminLoginRequired"];
            public static readonly MetaProperty IntervalUnit = MetaObject.Get(typeof(ScheduledEvent))["IntervalUnit"];
            public static readonly MetaProperty RetryRequired = MetaObject.Get(typeof(ScheduledEvent))["RetryRequired"];
        }
        #endregion Properties

    }


    #region ScheduledEntityMeta
    public partial class ScheduledEntityMeta
    {
    }
    #endregion ScheduledEntityMeta
}
