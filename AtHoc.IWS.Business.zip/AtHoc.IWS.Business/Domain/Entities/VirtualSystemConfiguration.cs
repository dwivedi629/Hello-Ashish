﻿using System.ComponentModel.DataAnnotations;

using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;

namespace AtHoc.IWS.Business.Domain.Entities
{
	[MetadataType(typeof (ProviderConfigurationMeta))]
	[MetaObject(TableName = "PRV_CONFIG_TAB")]
	public class VirtualSystemConfiguration : EntityBase
	{
		[MetaProperty(ColumnName = "PROVIDER_ID", DbTypeName = "int", IsKey = true)]
		[Required]
		public virtual int Id
		{
			get { return Get<int>("Id"); }
			set { Set("Id", value); }
		}

		[MetaProperty(ColumnName = "GROUP_ID", DbTypeName = "nvarchar", MaxLength = 30, AutoTrim = true)]
		[MaxLength(30)]
		public virtual string GroupId
		{
			get { return Get<string>("GroupId"); }
			set { Set("GroupId", value); }
		}

		[MetaProperty(ColumnName = "KEY_NAME", DbTypeName = "nvarchar", MaxLength = 100, AutoTrim = true)]
		[MaxLength(100)]
		public virtual string KeyName
		{
			get { return Get<string>("KeyName"); }
			set { Set("KeyName", value); }
		}

		[MetaProperty(ColumnName = "VALUE", DbTypeName = "nvarchar", AutoTrim = true)]
		public virtual string Value
		{
			get { return Get<string>("Value"); }
			set { Set("Value", value); }
		}

		[MetaProperty(ColumnName = "DESCRIPTION", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
		[MaxLength(200)]
		public virtual string Description
		{
			get { return Get<string>("Description"); }
			set { Set("Description", value); }
		}

		#region Properties

		public class Meta
		{
			public static readonly MetaProperty Id = MetaObject.Get(typeof (VirtualSystemConfiguration))["Id"];

			public static readonly MetaProperty GroupId = MetaObject.Get(typeof (VirtualSystemConfiguration))["GroupId"];

			public static readonly MetaProperty KeyName = MetaObject.Get(typeof (VirtualSystemConfiguration))["KeyName"];

			public static readonly MetaProperty Value = MetaObject.Get(typeof (VirtualSystemConfiguration))["Value"];

			public static readonly MetaProperty Description = MetaObject.Get(typeof (VirtualSystemConfiguration))["Description"];
		}

		#endregion Properties
	}

	#region ProviderConfigurationMeta

	public class ProviderConfigurationMeta
	{
	}

	#endregion ProviderConfigurationMeta
}