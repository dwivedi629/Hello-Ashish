﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Entities.Search
{
    public class SearchEntity
    {
        /// <summary>
        /// Identity 
        /// </summary>
        public int  Id { get; set; }

        /// <summary>
        /// This could be RuleId, AlertId, ScenarioId
        /// </summary>
        public int EntityId { get; set; }

        public int ProviderId { get; set; }

        public int ? UserId { get; set; }

        public string EntityType { get; set; }

    }

    
}
