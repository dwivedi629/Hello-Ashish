﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Entities.Search
{
    public class SearchQueryValueEntity
    {
        public int  Id { get; set; }
        public int SearchQueryId { get; set; }
        public string SearchValue { get; set; }
    }
}
