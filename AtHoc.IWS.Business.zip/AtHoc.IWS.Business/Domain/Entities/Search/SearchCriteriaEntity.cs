﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Entities.Search
{
    public class SearchCriteriaEntity
    {
        public int Id { get; set; }
        public int SearchEntityId  { get; set; }
        public int NodeId { get; set; }

        public string SearchValue { get; set; }
        public string NodeType { get; set; }  
    }
}
