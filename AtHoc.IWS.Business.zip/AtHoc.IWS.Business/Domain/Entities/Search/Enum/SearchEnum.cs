﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Entities.Search
{
    public enum SearchOperators
    {
        Equals = 1,         //=
        NotEquals,          //!=
        Contains,
        NotContains,
        StartsWith,
        EndsWith,
        LessThan,           //<
        GreaterThan,        //>
        LessThanEqual,      //<=
        GreaterThanEqual,   //>=
        IsEmpty,
        IsNotEmpty,
        IsInside,           //For geo attribute
        IsOutside,          //For geo attribute
    }
    public enum SearchQueryType
    {
        Attribute = 1,  //query by custom attribute
        Device,         //query by device
        Tracking,       //query by tracking
        OperatorRole,   //query by operator role
        VirtualSystem,  //query by VPS
        Alert           //query by Alert (RBT)        
    }

    public enum SearchEntityType
    {
        Scenario = 1,
        Alert = 2,
        OperatorBaseRestriction = 3,
        List = 4,
        Rule = 5
        //Other search types    
    }
    public enum SearchNodeType
    {
        AllUserBase = 1,    //All user base
        Attribute,          //Custom attribute
        AttributeValue,     //Custom attribute value
        StaticList,         //static dl list
        DynamicList,        //dynamic dl list
        ListHrchy,          //dl list hierarchy
        OrgHrchy,           //org hierarchy
        IpHrchy,            //IP hierarchy
        User,               //an user
        MassUser,           //mass device endpoint
        OrgUser,            //org endpoint (i.e. Connect)
        Query,              //query targeting
        Geo,                //geo targeting
        OrgGeo              //organization geo targeting
    }
}
