﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Entities.Search
{
    public class SearchQueryEntity
    {
        public int Id { get; set; }
        public int SearchCriteriaId { get; set; }

        public int SearchQueryEntityId { get; set; }

        public AtHoc.IWS.Business.Domain.Entities.Search.SearchOperators Operator { get; set; }

        public string QueryType { get; set; }

    }
}
