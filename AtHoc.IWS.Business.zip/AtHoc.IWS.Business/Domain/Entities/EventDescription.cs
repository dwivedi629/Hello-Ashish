using System;
using System.Collections.Generic;
using System.Data.Entity.Spatial;

namespace AtHoc.IWS.Business.Domain.Entities
{
    public partial class EventDescription
    {
        public int Id { get; set; }
        public byte[] RowId { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public System.DateTime UpdatedOn { get; set; }
        public int EventId { get; set; }
        public string Description { get; set; }
        public virtual Event Event { get; set; }
        public DbGeometry GeoInfo { get; set; }
        public string GeoSymbol { get; set; }
        public string Type { get; set; }

        public string SourceType { get; set; }

        public int? SourceId { get; set; }
    }

    
}
