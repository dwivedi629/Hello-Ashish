﻿using AtHoc.Infrastructure.Meta;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Entities
{
    public class AccountabilityActivityFeed : ActivityFeed
    {
        [MetaProperty(ColumnName = "EVENT_ALERTS_COUNT", DbTypeName = "int")]
        public virtual int EventAlertsCount
        {
            get { return Get<int>("EventAlertsCount"); }
            set { Set("EventAlertsCount", value); }
        }

        [MetaProperty(ColumnName = "RESPONSE_UPDATED_FROM", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
        public virtual string StatusUpdatedBy
        {
            get { return Get<string>("StatusUpdatedBy"); }
            set { Set("StatusUpdatedBy", value); }
        }

        #region Properties
        public class Meta
        {
            public static readonly MetaProperty EventAlertsCount = MetaObject.Get(typeof(AccountabilityActivityFeed))["EventAlertsCount"];
            public static readonly MetaProperty StatusUpdatedBy = MetaObject.Get(typeof(AccountabilityActivityFeed))["StatusUpdatedBy"];
        }
        #endregion Properties
    }
}
