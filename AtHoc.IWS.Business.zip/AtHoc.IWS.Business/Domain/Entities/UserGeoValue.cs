﻿using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using Microsoft.SqlServer.Types;
using System.ComponentModel.DataAnnotations;

namespace AtHoc.IWS.Business.Domain.Entities
{
    /// <summary>
    /// Used to hold user geo attribute value for USR_GEO_TAB
    /// </summary>
    [MetadataType(typeof(UserGeoValueMeta))]
    [MetaObject(TableName = "USR_GEO_TAB")]
    public class UserGeoValue : EntityBase
    {
        [MetaProperty(IsPersistable = true, ColumnName = "USER_ID", DbTypeName = "int", IsKey = true)]
        public int UserId
        {
            get { return Get<int>("UserId"); }
            set { Set("UserId", value); }
        }
        [MetaProperty(IsPersistable = true, ColumnName = "ATTRIBUTE_ID", DbTypeName = "int", IsKey = true)]
        public int AttributeId
        {
            get { return Get<int>("AttributeId"); }
            set { Set("AttributeId", value); }
        }

        [MetaProperty(IsPersistable = true, ColumnName = "ADDRESS", DbTypeName = "nvarchar")]
        public string Address
        {
            get { return Get<string>("Address"); }
            set { Set("Address", value); }
        }

        [MetaProperty(IsPersistable = true, ColumnName = "GEO_VALUE", DbTypeName = "Geography")]
        public SqlGeography GeoValue
        {

            get { return Get<SqlGeography>("GeoValue"); }
            set { Set("GeoValue", value); }
        }

        [MetaProperty(IsPersistable = true, ColumnName = "UPDATED_ON", DbTypeName = "int")]
        public int UpdatedOn
        {
            get { return Get<int>("UpdatedOn"); }
            set { Set("UpdatedOn", value); }
        }

        [MetaProperty(IsPersistable = true, ColumnName = "UPDATED_BY", DbTypeName = "int")]
        public int UpdatedBy
        {
            get { return Get<int>("UpdatedBy"); }
            set { Set("UpdatedBy", value); }
        }

        [MetaProperty(IsPersistable = true, ColumnName = "UPDATED_FROM", DbTypeName = "nvarchar", MaxLength = 200, AutoTrim = true)]
        [MaxLength(200)]
        public string UpdatedFrom
        {
            get { return Get<string>("UpdatedFrom"); }
            set { Set("UpdatedFrom", value); }
        }

        [MetaProperty(IsPersistable = false, ColumnName = "ROW_INDEX", DbTypeName = "int")]
        [Required]
        public int RowIndex
        {
            get { return Get<int>("RowIndex"); }
            set { Set("RowIndex", value); }
        }

        #region Properties
        public class Meta
        {
            public static readonly MetaProperty UserId = MetaObject.Get(typeof(UserGeoValue))["UserId"];
            public static readonly MetaProperty AttributeId = MetaObject.Get(typeof(UserGeoValue))["AttributeId"];
            public static readonly MetaProperty Address = MetaObject.Get(typeof(UserGeoValue))["Address"];
            public static readonly MetaProperty GeoValue = MetaObject.Get(typeof(UserGeoValue))["GeoValue"];
            public static readonly MetaProperty UpdatedFrom = MetaObject.Get(typeof(UserGeoValue))["UpdatedFrom"];
            public static readonly MetaProperty RowIndex = MetaObject.Get(typeof(UserGeoValue))["RowIndex"];
            public static readonly MetaProperty UpdatedOn = MetaObject.Get(typeof(UserGeoValue))["UpdatedOn"];
            public static readonly MetaProperty UpdatedBy = MetaObject.Get(typeof(UserGeoValue))["UpdatedBy"];
        }
        #endregion Properties

        #region UserGeoValueMeta
        public partial class UserGeoValueMeta
        {
        }
        #endregion UserGeoValueMeta

    }
}
