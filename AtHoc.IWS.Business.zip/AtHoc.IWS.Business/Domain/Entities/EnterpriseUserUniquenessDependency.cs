﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Entities
{
    public class EnterpriseUserUniquenessDependency
    {
        public int? ProviderId { get; set; }
        public int UserId { get; set; }
        public string MAPPING_ID { get; set; }
        public string UserName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string DisplayName { get; set; }
        public string PROVIDER_DISPLAYNAME { get; set; }      
    }
}
