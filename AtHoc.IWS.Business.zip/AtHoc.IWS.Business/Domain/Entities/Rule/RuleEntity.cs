﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Entities
{
    public class RuleEntity : CommonAttributeEntity
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int ProviderId { get; set; }
        
        /// <summary>
        /// Rule Display/Execution Order
        /// </summary>
        public int Order { get; set; }

        /// <summary>
        /// Active/Not Active
        /// </summary>
        public string IsActive { get; set; }
        public bool StopProcessing { get; set; }

        public string IsStandard { get; set; }

        public virtual ICollection<RuleActionEntity> RuleActionEntities { get; set; }

        public string RuleType { get; set; }
        public int? GroupId { get; set; }

    }
}
