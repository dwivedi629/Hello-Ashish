﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Entities.Rule.Enum
{
    
    public enum ActionType
    {
        [Description("Execute Scenario")]
        ExecuteScenario = 1,

        [Description("Delegate to Response")]
        DelegateResponses = 2
    }
    public enum RuleTypes
    {        
        INCOMING_ALERT_RULE,       
        INCOMING_FEED_RULE,
        INCOMING_FEED_RULE_PROCESSING
    }

    public enum FeedTypes
    {
        WAM
    }
}
