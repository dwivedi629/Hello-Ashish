﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Entities
{
    public class RuleActionEntity : CommonAttributeEntity
    {
        public int Id { get; set; }
        public int ? RuleId { get; set; }
        public AtHoc.IWS.Business.Domain.Entities.Rule.Enum.ActionType ActionType { get; set; }
        
        [Obsolete("Use RuleActionValuesEntities")]
        public string ActionTypeContext { get; set; }
        public virtual RuleEntity RuleEntity { get; set; }
        public virtual ICollection<RuleActionValueEntity> RuleActionValueEntities { get; set; }
    }
     public class RuleActionValueEntity 
    {
        public int Id { get; set; }
        public int ? RuleActionId { get; set; }
        public string ParameterKey { get; set; }
        public string ParameterValue { get; set; }
        public virtual RuleActionEntity RuleActionEntity { get; set; }
    }
}
