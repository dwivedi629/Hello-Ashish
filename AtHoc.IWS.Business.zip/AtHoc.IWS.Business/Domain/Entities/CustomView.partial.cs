﻿using AtHoc.Infrastructure.Meta;

namespace AtHoc.IWS.Business.Domain.Entities
{
    public partial class CustomView
    {
        public CustomView() {
            //this.IsPlaceholder = "N";
        }
        [MetaProperty(IsPersistable = false)]
        public CustomAttribute CustomAttribute { get; set; }
    }
}
