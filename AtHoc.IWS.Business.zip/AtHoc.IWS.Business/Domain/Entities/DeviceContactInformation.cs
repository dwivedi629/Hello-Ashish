﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Entities
{
    public class DeviceContactInformation
    {
        public List<ContactInfoPerDevice> ContactInfo {get; set;}
        public int TotalCount { get; set; }
        public int TotalCovered { get; set; }
        public int TotalCoveredPercentage
        {
            get
            {
                return (int)((Double)TotalCovered / TotalCount * 100);//since it's an INT, the percentage will be rounded.
            }
        }
        public int TotalNotCovered { get; set; }
        public int TotalNotCoveredPercentage
        {
            get
            {
                return 100 - TotalCoveredPercentage; ;
            }
        }
    }

    public class ContactInfoPerDevice
    {
        public ContactInfoPerDevice(int deviceId, int count, int allUsersCount)
        {
            DeviceId = deviceId;
            Count = count;
            Percentage = (int)((Double)Count / allUsersCount * 100);
        }
        public int DeviceId { get; set; }
        public int Count { get; set; }

        public int Percentage
        {
            get;
            set;
        }
    
    }
}
