﻿using System.Text;
using System.Security.Cryptography;
using System.ComponentModel.DataAnnotations;

using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Meta;
using System.Text.RegularExpressions;

namespace AtHoc.IWS.Business.Domain.Entities
{
	[MetadataType(typeof(DeviceAddressBaseMeta))]
	[MetaObject(TableName = "USR_DEVICE_ADDRESS_TAB")]
	public partial class DeviceAddress : DeviceAddressBase
	{
		private readonly SHA1 _sha = new SHA1CryptoServiceProvider();

		[MetaProperty(ColumnName = "ADDRESS", DbTypeName = "nvarchar", MaxLength = 2000, AutoTrim = true)]
		[MaxLength(2000)]
		public override string Address
		{
			get
			{
				return base.Address;
			}
			set
			{
				base.Address = value;
                if (value.IsNotNullOrEmpty())
                {
                    if (this.Device != null && this.Device.DeviceGroup != null)
                    {
                        if (this.Device.DeviceGroup.CommonName == "PHONE")
                        {
                            var digitsOnly = new Regex(@"[^\d]");
                            var phone = digitsOnly.Replace(value, "");
                            this.HashedCleanAddress = _sha.ComputeHash(Encoding.Unicode.GetBytes(phone.ToLower()));
                        }
                        else {
                            this.HashedCleanAddress = _sha.ComputeHash(Encoding.Unicode.GetBytes(value.ToLower()));
                        }
                    }
                    else
                    {
                        this.HashedCleanAddress = _sha.ComputeHash(Encoding.Unicode.GetBytes(value.ToLower()));
                    }
                }
                
			}
		}

        [MetaProperty(IsPersistable=false)]
        public Device Device { get; set; }
	}
}