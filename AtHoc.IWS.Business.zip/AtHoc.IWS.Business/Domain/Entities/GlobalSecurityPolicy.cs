﻿using System.ComponentModel.DataAnnotations;

using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;

namespace AtHoc.IWS.Business.Domain.Entities
{
	[MetadataType(typeof(SecurityConfigurationMeta))]
	[MetaObject(TableName = "GLB_SECURITY_POLICY_TAB")]
	public class GlobalSecurityPolicy : EntityBase
	{
		[MetaProperty(ColumnName = "PASSWORD_CHANGE_DAYS", DbTypeName = "int")]
		public virtual int? PasswordChangeDays
		{
			get { return Get<int>("PasswordChangeDays"); }
			set { Set("PasswordChangeDays", value); }
		}

		[MetaProperty(ColumnName = "REMEMBER_PREVIOUS_PASSWORDS", DbTypeName = "int")]
		public virtual int? RememberPreviousPassword
		{
			get { return Get<int>("RememberPreviousPassword"); }
			set { Set("RememberPreviousPassword", value); }
		}

		[MetaProperty(ColumnName = "LOGIN_LOCKOUT_ATTEMPTS", DbTypeName = "int")]
		public virtual int? LoginLockoutAttempts
		{
			get { return Get<int>("LoginLockoutAttempts"); }
			set { Set("LoginLockoutAttempts", value); }
		}

		[MetaProperty(ColumnName = "SESSION_TIMEOUT_INTERVAL", DbTypeName = "int")]
		public virtual int? SessionTimeoutInterval
		{
			get { return Get<int>("SessionTimeoutInterval"); }
			set { Set("SessionTimeoutInterval", value); }
		}

		[MetaProperty(ColumnName = "PASSWORD_MIN_LENGTH", DbTypeName = "int")]
		public virtual int? PasswordMinLength
		{
			get { return Get<int>("PasswordMinLength"); }
			set { Set("PasswordMinLength", value); }
		}

		[MetaProperty(ColumnName = "PASSWORD_MIN_LCASE_CHARS", DbTypeName = "int")]
		public virtual int? PasswordMinLCaseChars
		{
			get { return Get<int>("PasswordMinLCaseChars"); }
			set { Set("PasswordMinLCaseChars", value); }
		}

		[MetaProperty(ColumnName = "PASSWORD_MIN_UCASE_CHARS", DbTypeName = "int")]
		public virtual int? PasswordMinUCaseChars
		{
			get { return Get<int>("PasswordMinUCaseChars"); }
			set { Set("PasswordMinUCaseChars", value); }
		}

		[MetaProperty(ColumnName = "PASSWORD_MIN_NUMERIC_CHARS", DbTypeName = "int")]
		public virtual int? PasswordMinNumericChars
		{
			get { return Get<int>("PasswordMinNumericChars"); }
			set { Set("PasswordMinNumericChars", value); }
		}

		[MetaProperty(ColumnName = "PASSWORD_MIN_SPECIAL_CHARS", DbTypeName = "int")]
		public virtual int? PasswordMinSpecialChars
		{
			get { return Get<int>("PasswordMinSpecialChars"); }
			set { Set("PasswordMinSpecialChars", value); }
		}

		[MetaProperty(ColumnName = "PASSWORD_CHANGE_MIN_DAYS", DbTypeName = "int")]
		public virtual int? PasswordChangeMinDays
		{
			get { return Get<int>("PasswordChangeMinDays"); }
			set { Set("PasswordChangeMinDays", value); }
		}

		[MetaProperty(ColumnName = "PASSWORD_CHANGE_MIN_CHARS", DbTypeName = "int")]
		public virtual int? PasswordChangeMinChars
		{
			get { return Get<int>("PasswordChangeMinChars"); }
			set { Set("PasswordChangeMinChars", value); }
		}

		[MetaProperty(ColumnName = "SECURITY_DISCLAIMER", DbTypeName = "nvarchar", MaxLength = 4000)]
		public virtual string SecurityDisclaimer
		{
			get { return Get<string>("SecurityDisclaimer"); }
			set { Set("SecurityDisclaimer", value); }
		}

		[MetaProperty(ColumnName = "DSW_CERTIFICATE_COLLECT_MODE", DbTypeName = "int")]
		public virtual int? DswCertificateCollectMode
		{
			get { return Get<int>("DswCertificateCollectMode"); }
			set { Set("DswCertificateCollectMode", value); }
		}

		[MetaProperty(ColumnName = "LOGIN_LOCKOUT_TIMEOUT", DbTypeName = "int")]
		public virtual int? LoginLockoutTimeout
		{
			get { return Get<int>("LoginLockoutTimeout"); }
			set { Set("LoginLockoutTimeout", value); }
		}

		[MetaProperty(ColumnName = "MAX_SESSIONS_PER_OPERATOR", DbTypeName = "int")]
		public virtual int? MaxSessionPerOperator
		{
			get { return Get<int>("MaxSessionPerOperator"); }
			set { Set("MaxSessionPerOperator", value); }
		}

		#region Properties
		public class Meta
		{
			public static readonly MetaProperty PasswordChangeDays = MetaObject.Get(typeof(GlobalSecurityPolicy))["PasswordChangeDays"];
			public static readonly MetaProperty RememberPreviousPassword = MetaObject.Get(typeof(GlobalSecurityPolicy))["RememberPreviousPassword"];
			public static readonly MetaProperty LoginLockoutAttempts = MetaObject.Get(typeof(GlobalSecurityPolicy))["LoginLockoutAttempts"];
			public static readonly MetaProperty SessionTimeoutInterval = MetaObject.Get(typeof(GlobalSecurityPolicy))["SessionTimeoutInterval"];
			public static readonly MetaProperty PasswordMinLength = MetaObject.Get(typeof(GlobalSecurityPolicy))["PasswordMinLength"];
			public static readonly MetaProperty PasswordMinLCaseChars = MetaObject.Get(typeof(GlobalSecurityPolicy))["PasswordMinLCaseChars"];
			public static readonly MetaProperty PasswordMinUCaseChars = MetaObject.Get(typeof(GlobalSecurityPolicy))["PasswordMinUCaseChars"];
			public static readonly MetaProperty PasswordMinNumericChars = MetaObject.Get(typeof(GlobalSecurityPolicy))["PasswordMinNumericChars"];
			public static readonly MetaProperty PasswordMinSpecialChars = MetaObject.Get(typeof(GlobalSecurityPolicy))["PasswordMinSpecialChars"];
			public static readonly MetaProperty PasswordChangeMinDays = MetaObject.Get(typeof(GlobalSecurityPolicy))["PasswordChangeMinDays"];
			public static readonly MetaProperty PasswordChangeMinChars = MetaObject.Get(typeof(GlobalSecurityPolicy))["PasswordChangeMinChars"];
			public static readonly MetaProperty SecurityDisclaimer = MetaObject.Get(typeof(GlobalSecurityPolicy))["SecurityDisclaimer"];
			public static readonly MetaProperty DswCertificateCollectMode = MetaObject.Get(typeof(GlobalSecurityPolicy))["DswCertificateCollectMode"];
			public static readonly MetaProperty LoginLockoutTimeout = MetaObject.Get(typeof(GlobalSecurityPolicy))["LoginLockoutTimeout"];
			public static readonly MetaProperty MaxSessionPerOperator = MetaObject.Get(typeof(GlobalSecurityPolicy))["MaxSessionPerOperator"];
		}
		#endregion Properties
	}

	#region SecurityConfigurationMeta
	public partial class SecurityConfigurationMeta
	{
	}
	#endregion SecurityConfigurationMeta
}
