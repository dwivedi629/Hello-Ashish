﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
namespace AtHoc.IWS.Business.Domain.Entities
{
    /// <summary>
    /// This is class is specifically for consuming RPT_ALERT_TRACKING_SUMMARY
    /// where the NodeId returned is of type nvarchar instead of int
    /// </summary>
    public class AlertReportRawDataEx
    {
        public string NodeId { get; set; }
        public string ColumnId { get; set; }
        public int TotalCount { get; set; }
        public int NodeCount { get; set; }
        public string NodeName { get; set; }
    }

    public class AlertReportRawData
    {
        public int NodeId { get; set; }
        public string ColumnId { get; set; }
        public int TotalCount { get; set; }
        public int NodeCount { get; set; }
        public string NodeName { get; set; }
    }

    public class AlertUserListColumn
    {
    public string  ColumnType	{ get; set; }
    public int ColumnId{ get; set; }
    public string ColumnName	{ get; set; }
    public string ColumnExportName{ get; set; }
    public string ColumnDataType { get; set; }	
    public int ColumnOrder { get; set; }
    public string ColumnCommonName { get; set; }

    public int ColumnViewId { get; set; }

    }

    public class AlertUserListRawData
    {
        public int RecordNum { get; set; }
        public int UserId  { get; set; }
        public string ColumnType { get; set; }
        public int ColumnId { get; set; }
        public string ColumnValue { get; set; }
        public int ColumnOrder { get; set; }
        public string ColumnDataType { get; set; }
    }

    public class AlertReportCriteria
    {
        public string AttributeType { get; set; }
        public string AttributeIdCSV { get; set; }
        public int CachedUsersSessionId { get; set; }
        public int ProviderId { get; set; }
        public int EntityIdFilter { get; set; }
        public string HrchyType { get; set; }
        public int HrchyNodeId { get; set; }

        public int IncludeChildren { get; set; }

        public int GetCoveredByAttributeUsers { get; set; }

        public int GetNOTCoveredByAttributeUsers { get; set; }

        public int GetTotalUsers { get; set; }

        public int GetTotalCoveredUsers { get; set; }

        public int GetTotalNOTCoveredUsers { get; set; }

        public int GetDevices { get; set; }

        public int SortBy { get; set; }

        public string IsSortAsc { get; set; }

        public int PageNumber { get; set; }

        public int RowsPerPage { get; set; }

        public int AdjustTimeZone { get; set; }

        public int Debugflag { get; set; }

        public string GetAttributes { get; set; }
        public string AttributeSearchValue { get; set; }
        public int TotalUsers { get; set; }
    }

    public class AlertUserListData
    {
        public string ColumnId { get; set; }
        public string ColumnName { get; set; }
        public int ColumnViewId { get; set; }
       
        public string ColumnValue { get; set; }
        public int ColumnOrder { get; set; }
        public int ColumnRecord { get; set; }
    }

}
