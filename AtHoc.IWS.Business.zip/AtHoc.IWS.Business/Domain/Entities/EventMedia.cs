using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using AtHoc.IWS.Business.Domain.Event;

namespace AtHoc.IWS.Business.Domain.Entities
{
    public partial class EventMedia : ITargetAttachment

    {
        public int Id { get; set; }
        public byte[] RowId { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public System.DateTime UpdatedOn { get; set; }
        public int EventId { get; set; }
        public System.Guid MediaId { get; set; }
        public virtual Event Event { get; set; }

        [NotMapped]
        public ICollection<Media> Medias { get; set; }

        [NotMapped]
        public int TargetId
        {
            get { return EventId; }
            set { EventId = value; }
        }

        [NotMapped]
        public Guid MediaGuid
        {
            get { return MediaId; }
            set { MediaId = value; }
        }
    }
}
