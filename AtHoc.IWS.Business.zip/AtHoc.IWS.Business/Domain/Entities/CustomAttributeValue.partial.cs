﻿using AtHoc.Infrastructure.Meta;

namespace AtHoc.IWS.Business.Domain.Entities
{
	public partial class CustomAttributeValue
	{
		[MetaProperty(IsPersistable = false)]
		public CustomAttribute CustomAttribute { get; set; }

        [MetaProperty(IsPersistable = false)]
        public bool IsReadOnly
        {
            get { return this.Get<bool>("IsReadOnly"); }
            set { this.Set<bool>("IsReadOnly", value); }
        }
	}
}
