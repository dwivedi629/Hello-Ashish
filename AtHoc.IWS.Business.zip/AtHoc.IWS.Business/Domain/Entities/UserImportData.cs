﻿using System;
using System.ComponentModel.DataAnnotations;

using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;

namespace AtHoc.IWS.Business.Domain.Entities
{
	[MetadataType(typeof(UserImportDataMeta))]
	[MetaObject(TableName = "UPL_DATA_TAB")]
	public class UserImportData : EntityBase
	{
		[MetaProperty(ColumnName = "UPLOAD_ID", DbTypeName = "int", IsKey = true, IsIdentity = true)]
		public virtual int? Id
		{
			get { return Get<int>("Id"); }
			set { Set("Id", value); }
		}

		[MetaProperty(ColumnName = "PROVIDER_ID", DbTypeName = "int")]
		public virtual int? ProviderId
		{
			get { return Get<int>("ProviderId"); }
			set { Set("ProviderId", value); }
		}

		[MetaProperty(ColumnName = "CREATED_BY", DbTypeName = "int")]
		public virtual int? CreatedBy
		{
			get { return Get<int?>("CreatedBy"); }
			set { Set("CreatedBy", value); }
		}

		[MetaProperty(ColumnName = "UPLOAD_TYPE", DbTypeName = "nvarchar", MaxLength = 10, AutoTrim = true)]
		public virtual string UploadType
		{
			get { return Get<string>("UploadType"); }
			set { Set("UploadType", value); }
		}

		[MetaProperty(ColumnName = "STATUS", DbTypeName = "nvarchar", MaxLength = 10, AutoTrim = true)]
		public virtual UserImportStatusType? Status
		{
			get { return Get<UserImportStatusType?>("Status"); }
			set { Set<UserImportStatusType?>("Status", value); }
		}

		[MetaProperty(ColumnName = "START_TIME", DbTypeName = "int")]
		public virtual int? StartTime
		{
			get { return Get<int>("StartTime"); }
			set { Set("StartTime", value); }
		}

		[MetaProperty(ColumnName = "END_TIME", DbTypeName = "int")]
		public virtual int? EndTime
		{
			get { return Get<int>("EndTime"); }
			set { Set("EndTime", value); }
		}

		[MetaProperty(ColumnName = "JOB_ID", DbTypeName = "int")]
		public virtual int? JobId
		{
			get { return Get<int>("JobId"); }
			set { Set("JobId", value); }
		}

		[MetaProperty(ColumnName = "UPLOAD_FILE_NAME", DbTypeName = "nvarchar")]
		public virtual string UploadFilename
		{
			get { return Get<string>("UploadFilename"); }
			set { Set("UploadFileName", value); }
		}

		[MetaProperty(ColumnName = "UPLOAD_FILE_DATA", DbTypeName = "nvarchar")]
		public virtual string UploadFileData
		{
			get { return Get<string>("UploadFileData"); }
			set { Set("UploadFileData", value); }
		}

		[MetaProperty(ColumnName = "COMMENTS", DbTypeName = "nvarchar", MaxLength = 200)]
		public virtual string Comments
		{
			get { return Get<string>("Comments"); }
			set { Set("Comments", value); }
		}

		[MetaProperty(ColumnName = "UPLOAD_TIME", DbTypeName = "int")]
		public virtual int? UploadTime
		{
			get { return Get<int>("UploadTime"); }
			set { Set("UploadTime", value); }
		}

		[MetaProperty(ColumnName = "TOTAL_RECORDS", DbTypeName = "int")]
		public virtual int? TotalRecords
		{
			get { return Get<int>("TotalRecords"); }
			set { Set("TotalRecords", value); }
		}

		[MetaProperty(ColumnName = "PROCESSED_RECORDS", DbTypeName = "int")]
		public virtual int? ProcessedRecords
		{
			get { return Get<int>("ProcessedRecords"); }
			set { Set("ProcessedRecords", value); }
		}

		[MetaProperty(ColumnName = "SUCCESS_RECORDS", DbTypeName = "int")]
		public virtual int? SuccessRecords
		{
			get { return Get<int>("SuccessRecords"); }
			set { Set("SuccessRecords", value); }
		}

		[MetaProperty(ColumnName = "FAILED_RECORDS", DbTypeName = "int")]
		public virtual int? FailedRecords
		{
			get { return Get<int>("FailedRecords"); }
			set { Set("FailedRecords", value); }
		}

		[MetaProperty(ColumnName = "PARTIAL_RECORDS", DbTypeName = "int")]
		public virtual int? PartialRecords
		{
			get { return Get<int>("PartialRecords"); }
			set { Set("PartialRecords", value); }
		}

		[MetaProperty(ColumnName = "REC_NUM", DbTypeName = "int")]
		public virtual int? RecordNumber
		{
			get { return Get<int>("RecordNumber"); }
			set { Set("RecordNumber", value); }
		}

		[MetaProperty(ColumnName = "LAST_UPDATE_TIME", DbTypeName = "datetime")]
		public virtual DateTime? LastUpdateTime
		{
			get { return Get<DateTime?>("LastUpdateTime"); }
			set { Set("LastUpdateTime", value); }
		}

		#region Properties

		public class Meta
		{
			public static readonly MetaProperty Id = MetaObject.Get(typeof(UserImportData))["Id"];
			public static readonly MetaProperty ProviderId = MetaObject.Get(typeof (UserImportData))["ProviderId"];
			public static readonly MetaProperty CreatedBy = MetaObject.Get(typeof(UserImportData))["CreatedBy"];
			public static readonly MetaProperty UploadType = MetaObject.Get(typeof (UserImportData))["UploadType"];
			public static readonly MetaProperty Status = MetaObject.Get(typeof (UserImportData))["Status"];
			public static readonly MetaProperty StartTime = MetaObject.Get(typeof (UserImportData))["ProviderId"];
			public static readonly MetaProperty EndTime = MetaObject.Get(typeof (UserImportData))["UploadType"];
			public static readonly MetaProperty JobId = MetaObject.Get(typeof (UserImportData))["Status"];
			public static readonly MetaProperty UploadFilename = MetaObject.Get(typeof (UserImportData))["UploadFilename"];
			public static readonly MetaProperty UploadFileData = MetaObject.Get(typeof (UserImportData))["UploadFileData"];
			public static readonly MetaProperty Comments = MetaObject.Get(typeof (UserImportData))["Comments"];
			public static readonly MetaProperty UploadTime = MetaObject.Get(typeof (UserImportData))["UploadTime"];
			public static readonly MetaProperty TotalRecords = MetaObject.Get(typeof (UserImportData))["TotalRecords"];
			public static readonly MetaProperty ProcessedRecords = MetaObject.Get(typeof (UserImportData))["ProcessedRecords"];
			public static readonly MetaProperty SuccessRecords = MetaObject.Get(typeof (UserImportData))["SuccessRecords"];
			public static readonly MetaProperty FailedRecords = MetaObject.Get(typeof (UserImportData))["FailedRecords"];
			public static readonly MetaProperty PartialRecords = MetaObject.Get(typeof (UserImportData))["PartialRecords"];
			public static readonly MetaProperty RecordNumber = MetaObject.Get(typeof (UserImportData))["RecordNumber"];
			public static readonly MetaProperty LastUpdateTime = MetaObject.Get(typeof(UserImportData))["LastUpdateTime"];
		}

		#endregion Properties
	}

	#region ImportDataMeta

	public class UserImportDataMeta
	{
	}

	#endregion ImportDataMeta
}