﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Entities
{
    public partial class MediaThumbnail
    {
        public int MediaId { get; set; }
        public int ThumbnailMediaId { get; set; }

        //public virtual Media Media { get; set; }
        //public virtual Media ThumbnailMedia { get; set; }
    }
}
