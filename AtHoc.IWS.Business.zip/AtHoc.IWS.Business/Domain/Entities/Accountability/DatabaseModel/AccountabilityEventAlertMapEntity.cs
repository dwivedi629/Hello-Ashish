﻿
using AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel;

namespace AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel
{
    /// <summary>
    /// Entity to map with 'ACCT_EVENT_ALERT_MAP_TAB' table.
    /// This will store the basic information for all Start, Reminder, Close event. (Since ALT_BASE_TAB has many attributes, which may not be used for events, thus creating separate entity is recommended.
    /// </summary>
    public class AccountabilityEventAlertMapEntity : AccountabilityAlertMapEntity
    {
        /// <summary>
        /// Accountability Event Id
        /// </summary>
        public int EventId { get; set; }

        /// <summary>
        /// Object to access the AccountabilityEvent entity which is associated to this transition entity (between AccountabilityEvent and AlertBase)
        /// </summary>
        public virtual AccountabilityEventEntity AccountabilityEvent { get; set; }

        //internal  AccountabilityEventAlertMapEntity CopyTo(AccountabilityMessage acctMessage,
        //    AccountabilityEventAlertType eventType, AccountabilityEventUserType eventUserType)
        //{
        //    var  alertMapEntity = new AccountabilityEventAlertMapEntity();
        //    base.CopyTo(alertMapEntity, acctMessage,
        //     eventType,  eventUserType);
        //    return alertMapEntity;
            
        //}
    }
}
