﻿using System;

namespace AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel
{
    /// <summary>
    /// Entity to hold the recipient list of Event
    /// </summary>
    public class AccountabilityEventRecipientEntity : AccountabilityEventRecipientBase
    {
        

        /// <summary>
        /// Object to access the AccountabilityEvent entity which is associated to this transition entity (between AccountabilityEvent and AlertBase)
        /// </summary>
        public virtual AccountabilityEventEntity AccountabilityEvent { get; set; }

    }

    public class AccountabilityEventRecipientBase
    {
        /// <summary>
        /// Identity key
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Accountability Event Id for which the recipient will be inserted
        /// </summary>
        public int EventId { get; set; }

        /// <summary>
        /// Recipient Id
        /// 
        /// </summary>
        public int UserId { get; set; }

        /// <summary>
        /// User Attribute Id 
        /// refers to ACCT_EVENT_ACCOUNTING_ATTRIBUTE_TAB.USER_ACCT_STATUS_ID, during event publishing all recpts get populated 
        /// and user's status from time >= PAST_STATUS_VALIDITY_FROM will be copied here.
        /// </summary>
        public int UserStatusAttributeId { get; set; }

        /// <summary>
        /// Status Updated on.
        /// This is value of status.updatedOn from usr_attr_value_tab and not the time of update (for older status values)
        /// </summary>
        public DateTime? StatusUpdatedOn { get; set; }

        /// <summary>
        /// Created On
        /// </summary>
        public DateTime? CreatedOn { get; set; }

        /// <summary>
        /// Updated By user Id
        /// </summary>
        public int? UpdatedBy { get; set; }

        /// <summary>
        /// Updated from 
        /// </summary>
        public string UpdateFrom { get; set; }

        /// <summary>
        /// Comments
        /// </summary>
        public string Comments { get; set; }

        /// <summary>
        /// Mark users excluded only if there is no status available for them.
        /// </summary>
        public string IsExcluded { get; set; }
    }

}
