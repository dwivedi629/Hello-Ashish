﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.d911.Model.Poll;

namespace AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel
{
    /// <summary>
    /// Background job will use this table to identify the event execution time.
    /// </summary>
    public class AccountabilityEventPickupScheduleEntity
    {
        /// <summary>
        /// Accountability Event Id, also a primary key for AccountabilityEventPickupScheduleEntity i.e ACCT_EVENT_PICKUP_SCHEDULE_TAB
        /// </summary>
        public int EventId { get; set; }

       /// <summary>
        /// Possible Value: Recompute, Reminder
        /// Set PickupActionType = Recompute - for event receipient recomputing 
        /// Set PickupActionType = Reminder - for next reminder alert.
        /// </summary>
        public string PickupActionType { get; set; }

        /// <summary>
        /// Time to execute next action
        /// </summary>
        public DateTime NextRunTime { get; set; }
        /// <summary>
        /// Object to access the AccountabilityEvent entity which is associated to this transition entity (between AccountabilityEvent and AlertBase)
        /// </summary>
        public virtual AccountabilityEventEntity AccountabilityEvent { get; set; }
    }
}
