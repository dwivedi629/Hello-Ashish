﻿using System;
using System.Collections.Generic;
using AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel;
using AtHoc.IWS.Business.Mappings;

namespace AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel
{
    /// <summary>
    /// Entity model for AccountabilityTemplate. Mapped to ACCT_TEMPLATE_TAB table
    /// </summary>
    public class AccountabilityTemplateEntity
    {
         
        public AccountabilityTemplateEntity()
        {
            Events = new HashSet<AccountabilityEventEntity>();
        }

        public AccountabilityTemplateEntity(AccountabilityTemplate template)
        {
            Events = new HashSet<AccountabilityEventEntity>();

        }

        /// <summary>
        /// Accountability Template Id
        /// </summary>
        public int TemplateId { get; set; }

        /// <summary>
        /// Provider Id
        /// </summary>
        public int ProviderId { get; set; }

        /// <summary>
        /// Name of Accountability Event template
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// UNIQUE Common name for Accountability Event template
        /// </summary>
        public string CommonName { get; set; }
     
        /// <summary>
        /// Description for Accountability Event template
        /// </summary>
        public string Description { get; set; }
        
        /// <summary>
        /// AlertBaseID (mapped to ALT_BASE_TAB -> Alert Id)
        /// </summary>
        public int UserAlertBaseId { get; set; }

        /// <summary>
        /// Operator Alert base Id - Mapped to ALT_BASE_TAB ID column
        /// </summary>
        public int? OperatorAlertBaseId { get; set; }
       
        /// <summary>
        /// Event: Scheduled, Live, Ended
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// Represents the value of PassStatusValidityDurationUnit 
        /// </summary>
        public int ? PastStatusValidityDurationValue { get; set; }

        /// <summary>
        /// Represents the unit of PastStatusValidityDurationValue attribute e.g. HR/MIN/SEC
        /// </summary>
        public string PastStatusValidityDurationUnit { get; set; }

        /// <summary>
        /// This property will hold the event recipeint refresh duration. (Mainly used in background job)
        /// </summary>
        public int ? EventRecipientRefreshIntervalValue { get; set; }

        /// <summary>
        /// This will hold the unit value for EventRecipientRefreshIntervalValue property.
        /// </summary>
        public string EventRecipientRefreshIntervalUnit { get; set; }

        /// <summary>
        /// Accountability Event template created on date.
        /// </summary>
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Accountability Event template created by user id
        /// </summary>
        public int CreatedBy { get; set; }

        /// <summary>
        /// Accountability Event template updated on date
        /// </summary>
        public DateTime UpdatedOn { get; set; }

        /// <summary>
        /// Accountability Event updated by user id
        /// </summary>
        public int UpdatedBy { get; set; }

        /// <summary>
        /// Flag to Identify if template is visible to UI or not
        /// </summary>
        public string ShowInUi { get; set; }

        /// <summary>
        /// Collection of Events which are derived from this template
        /// </summary>
        public virtual ICollection<AccountabilityEventEntity> Events { get; set; }
        public virtual ICollection<AccountabilityTemplateAlertMapEntity> TemplateAlertMapEntities { get; set; }
        
        
    }
}
