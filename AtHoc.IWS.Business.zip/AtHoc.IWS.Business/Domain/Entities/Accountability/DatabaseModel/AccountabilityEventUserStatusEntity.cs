﻿using System;
using System.Collections.Generic;

namespace AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel
{
   /// <summary>
   /// This entity will get populate at Event Publish Time, a copy of all attribute values is made here (attribute is taken from RESPONSE_BASED_ATTRIBUTE_ID of Acct_base child tables)
   /// </summary>
    public class AccountabilityEventUserStatusEntity
    {
        /// <summary>
        /// This is primary key for AccountabilityEventUserStatusEntity
        /// </summary>
        public Int64 Id { get; set; }
        /// <summary>
        /// Accountability Event Id
        /// Also, it is foreign key
        /// </summary>
        public int EventId { get; set; }

        /// <summary>
        /// User Status Attribute Id 
        /// attribute is taken from RESPONSE_BASED_ATTRIBUTE_ID of Acct_base child tables
        /// This will map to SortOrder in PRV_ATTRIBUTE_VALUE_TAB (starts with 1)
        /// </summary>
        public int UserStatusOrderId { get; set; }

        /// <summary>
        /// User Status Attribute value Id
        /// Maps to PRV_ATTRIBUTE_VALUE_TAB -> VALUEID
        /// </summary>
        public int UserStatusAttributeValueId { get; set; }

        public int? UserStatusAttributeId { get; set; }
     

        /// <summary>
        /// Object to hold Accountability Event object (mapped by EventId)
        /// </summary>
        public virtual AccountabilityEventEntity AccountabilityEvent { get; set; }
    }
    public class AccountabilityEventStatusAttribute
    {

        public int AttributeId { get; set; }
        public int ValueId { get; set; }
        public string CommonName { get; set; }
        public string ValueName { get; set; }
        public int SortOrder { get; set; }

    }

    public class AccountabilityEventStatusAttributePerEvent : AccountabilityEventStatusAttribute
    {
        public int EventId { get; set; }
    }

    public class AccountabilityEventEndDate
    {
        public int EventId { get; set; }
        /// <summary>
        /// The new event end time will be in VPS time format and therefore string type
        /// </summary>
        public string NewDate { get; set; }
    }
    public class UserStatusUpdateSpec
    {
        public int OperatorId { get; set; }
        public List<int> UserIds { get; set; }
        public int AttributeId { get; set; }
        public int ValueId { get; set; }
        public int UpdatedBy { get; set; }
        public string Comments { get; set; }
        public string UpdatedFrom { get; set; }
        public int EventId { get; set; }
    }
}
