﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel;
using AtHoc.Utilities;

namespace AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel
{
    public class AccountabilityAlertMapEntity
    {
        /// <summary>
        /// Primary Key - Identity (1,1)
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Alert Type - Possible value USR-> USER, OPR->Operator
        /// </summary>
        public string AlertType { get; set; }

        /// <summary>
        /// Alert Initial type (e.g. Start, Reminder, Close)
        /// </summary>
        public string AlertInitType { get; set; }

        /// <summary>
        /// Is this Event enabled? (e.g. Y or N)
        /// </summary>
        public string IsEnabled { get; set; }

        /// <summary>
        /// Event template content title
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        ///Event template content Body
        /// </summary>
        public string Body { get; set; }

        /// <summary>
        /// Repeat duration for alert. (e.g. Reminder Alert may repeast after 30 min)
        /// This property holds the integer value for AlertRepeatDurationUnit property.
        /// </summary>
        public int AlertRepeatDurationValue { get; set; }

        /// <summary>
        /// This property holds the unit value for AlertRepeatDurationValue property. (e.g. Say duration is 30 MIN, then this property will store MIN as value.)
        /// </summary>
        public string AlertRepeatDurationUnit { get; set; }

        internal void CopyTo(AccountabilityAlertMapEntity alertMapEntity, AccountabilityMessage acctMessage, AccountabilityEventAlertType eventType, AccountabilityEventUserType eventUserType)
        {
            alertMapEntity.Id = acctMessage.MessageId;
            alertMapEntity.AlertInitType = eventType.ToString();
            alertMapEntity.IsEnabled = acctMessage.IsEnabled ? "Y" : "N";
            alertMapEntity.Body = acctMessage.Body;
            alertMapEntity.Title = acctMessage.Title;
            alertMapEntity.AlertType = eventUserType.GetDescription();
            
            if (acctMessage.AlertRepeatDuration != null)
            {
                alertMapEntity.AlertRepeatDurationUnit = acctMessage.AlertRepeatDuration.Unit.GetString();
                alertMapEntity.AlertRepeatDurationValue = acctMessage.AlertRepeatDuration.Value;
            }
        }

    }
}
