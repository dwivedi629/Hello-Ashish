﻿using System;

namespace AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel
{
   public class AccountabilityEventSummary
    {
       public int EventId { get; set; }
       public int ProviderId { get; set; }
       public int PublishedYear { get; set; }
       public int PublishedMonth { get; set; }
       public DateTime  PublishedTime { get; set; }
       public DateTime  EndedTime { get; set; }
       public DateTime UpdatedOn { get; set; }
       public string Title { get; set; }
       public int ? OriginType { get; set; }
       public int ? TestLevel { get; set; }
    }
   public class AccountabilityEventSummaryByMessageSent
   {
       public int AlertId { get; set; }
       public string AlertInitType { get; set; }
       public DateTime PublishedTime { get; set; }
   }
}
