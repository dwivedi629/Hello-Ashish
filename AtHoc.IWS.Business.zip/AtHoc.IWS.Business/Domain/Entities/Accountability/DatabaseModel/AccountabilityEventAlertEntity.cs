﻿
namespace AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel
{
    /// <summary>
    /// Entity to map ACCT_EVENT_ALERT_TAB table
    /// </summary>
    public class AccountabilityEventAlertEntity
    {
        /// <summary>
        /// Primary key for ACCT_EVENT_ALERT_TAB table
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Accountability Event Id
        /// </summary>
        public int EventId { get; set; }

        /// <summary>
        /// This is foreign key to AccountabilityEventAlertMapEntity  Id(i.e. ACCT_EVENT_ALERT_MAP_TAB table)
        /// </summary>
        public int AccountabilityEventAlertMapId { get; set; }
        
        /// <summary>
        /// Master Alert base ide for event (Mapped to Alt_Base_Tab AlertId)
        /// </summary>
        public int AlertId { get; set; }


        /// <summary>
        /// Object to access the AccountabilityEvent entity which is associated to this transition entity (between AccountabilityEvent and AlertBase)
        /// </summary>
        public virtual AccountabilityEventEntity AccountabilityEvent { get; set; }
        public virtual AccountabilityEventAlertMapEntity AccountabilityEventAlertMap { get; set; }
    }
}
