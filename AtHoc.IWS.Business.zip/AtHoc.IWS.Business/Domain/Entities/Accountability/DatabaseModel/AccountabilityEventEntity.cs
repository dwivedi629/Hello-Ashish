﻿using System;
using System.Collections.Generic;

namespace AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel
{
    public class AccountabilityEventEntity
    {

        /// <summary>
        /// Primary (master) key
        /// </summary>
        public int EventId { get; set; }

        /// <summary>
        /// Parent Accountability Template Id
        /// </summary>
        public int TemplateId { get; set; }

        /// <summary>
        /// ProviderId for Accountability Event
        /// </summary>
        public int ProviderId { get; set; }


        /// <summary>
        /// Accoutability Event Name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        ///Unique Id for Event.
        /// This will help to handle circular event issue. It is similar to AUID in ALT_BASE_TAB
        /// </summary>
        public string EventUniqueId { get; set; }

        /// <summary>
        /// Description for Event
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Alert base Id - Mapped to ALT_BASE_TAB ID column
        /// </summary>
        public int UserAlertBaseId { get; set; }

        /// <summary>
        /// Operator Alert base Id - Mapped to ALT_BASE_TAB ID column
        /// </summary>
        public int? OperatorAlertBaseId { get; set; }

        /// <summary>
        /// Status of event (Scheduled, Live, Ended)
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// This property will use to evaluate reciepients from past duration time. e.g. Before 3 HOUR of Event 
        /// This property holds the integer value for PastStatusValidityDurationUnit property.
        /// </summary>
        public int? PastStatusValidityDurationValue { get; set; }

        /// <summary>
        /// This property holds the unit value for PastStatusValidityDurationValue property. (e.g. Say duration is 30 MIN, then this property will store MIN as value.)
        /// </summary>
        public string PastStatusValidityDurationUnit { get; set; }

        /// <summary>
        /// This property will hold the event recipeint refresh duration. (Mainly used in background job)
        /// </summary>
        public int? EventRecipientRefreshIntervalValue { get; set; }

        /// <summary>
        /// This will hold the unit value for EventRecipientRefreshIntervalValue property.
        /// </summary>
        public string EventRecipientRefreshIntervalUnit { get; set; }

        /// <summary>
        /// Set Start Date for Event
        /// </summary>
        public DateTime StartDate { get; set; }

        /// <summary>
        /// Set End Date for Event
        /// </summary>
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// Set Publish time for event. There could be possible delta between start date and Publish Date
        /// Actual Event Publish time
        /// </summary>
        public DateTime? PublishedOn { get; set; }

        /// <summary>
        /// Set publisher name of event. e.g. SYSTEM, USERNAME 
        /// </summary>
        public string PublishedByUserName { get; set; }

        /// <summary>
        /// Set UserId who invoke this event publishing
        /// </summary>
        public int? PublishedByUserId { get; set; }

        /// <summary>
        /// Actual alert end time
        /// </summary>
        public DateTime? EndedOn { get; set; }

        /// <summary>
        /// Event ended by User e.g. SYSTEM, USER
        /// </summary>
        public string EndedByUserName { get; set; }

        /// <summary>
        /// Event ended by user id.
        /// </summary>
        public int? EndedByUserId { get; set; }

        /// <summary>
        /// Set 'Y', if event has to archieve periodically (By backgroud job)
        /// </summary>

        public string IsTrackingArchieved { get; set; }

        /// <summary>
        /// Event Created On
        /// </summary>
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Event Created By
        /// </summary>
        public int CreatedBy { get; set; }
        /// <summary>
        /// Event Updated On
        /// </summary>
        public DateTime UpdatedOn { get; set; }

        /// <summary>
        /// Event updated by
        /// </summary>
        public int UpdatedBy { get; set; }

        /// <summary>
        /// Object to access the AccountabilityTemplate which is associated to Event.
        /// </summary>
        public virtual AccountabilityTemplateEntity EventTemplate { get; set; }

        public virtual ICollection<AccountabilityEventAlertMapEntity> AccountabilityEventAlertMapEntities { get; set; }
        public virtual ICollection<AccountabilityEventAlertEntity> AccountabilityEventAlertEntities { get; set; }
        public virtual AccountabilityEventSummaryTrackingEntity AccountabilityEventSummaryTrackingEntity { get; set; }

        public virtual ICollection<AccountabilityEventPickupScheduleEntity> AccountabilityEventPickupScheduleEntities { get; set; }

    }
}
