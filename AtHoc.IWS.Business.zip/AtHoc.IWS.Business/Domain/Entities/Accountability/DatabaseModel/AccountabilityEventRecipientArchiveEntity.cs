﻿using System;
namespace AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel
{
    /// <summary>
    /// Entity to hold the archived list of event recipient
    /// </summary>
    public class AccountabilityEventRecipientArchiveEntity : AccountabilityEventRecipientBase
    {
        /// <summary>
        /// Object to access the AccountabilityEvent entity which is associated to this transition entity (between AccountabilityEvent and AlertBase)
        /// </summary>
        public virtual AccountabilityEventEntity AccountabilityEvent { get; set; }


    }
}