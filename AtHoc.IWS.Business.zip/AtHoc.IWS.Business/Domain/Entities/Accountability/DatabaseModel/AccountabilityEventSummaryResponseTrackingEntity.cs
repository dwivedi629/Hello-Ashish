﻿using System;

namespace AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel
{
    public class AccountabilityEventSummaryResponseTracking
    {
        public int EventId { get; set; }
        public int  StatusId { get; set; } //Sort order id of corresponded Attribute Value id

        public string ResponseText { get; set; }

        public int ? ResponseCount { get; set; }

        public DateTime UpdatedOn { get; set; }
    }
}
