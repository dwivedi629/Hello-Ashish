﻿
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel;
using AtHoc.Utilities;

namespace AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel
{
    public class AccountabilityTemplateAlertMapEntity : AccountabilityAlertMapEntity
    {
        /// <summary>
        /// Accountability Template Id
        /// </summary>
        public int TemplateId { get; set; }

        /// <summary>
        /// Object to access AccountablityTemplateEntity object from this entitu. This will be lazy loading.
        /// </summary>
        public virtual AccountabilityTemplateEntity AccountabilityTemplate { get; set; }

        internal AccountabilityTemplateAlertMapEntity CopyTo(AccountabilityMessage acctMessage,
          AccountabilityEventAlertType eventType, AccountabilityEventUserType eventUserType)
        {
            var alertMapEntity= new AccountabilityTemplateAlertMapEntity();
            base.CopyTo(alertMapEntity, acctMessage,
             eventType, eventUserType);
            return alertMapEntity;
        }

    }
}
