﻿using System;

namespace AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel
{
    public class AccountabilityEventSummaryTrackingEntity
    {
        public int EventId { get; set; }
        public int? Targeted { get; set; }
        public int? Responded { get; set; }
        public int? NoResponse { get; set; }
        public DateTime UpdatedOn { get; set; }

        public virtual AccountabilityEventEntity AccountabilityEvent { get; set; }
    }
}
