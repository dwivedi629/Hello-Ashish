﻿using System;
using System.Collections.Generic;

namespace AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel
{
    public class AccountabilityEventSummaryModel
    {
        /// <summary>
        /// List of user count sliced by duration (slice by Min/Hour/Day)
        /// </summary>
        public List<AccountabilityEventSummaryUserWithResponseCountModel> EventSummaryUserWithResponseCountModel { get; set; }


        /// <summary>
        /// List of sent message count sliced by duration (slice by Min/Hour/Day)
        /// </summary>
        public List<AccountabilityEventSummaryMessageSentCountModel> EventSummaryMessageSentCountModel { get; set; }
       

        /// <summary>
        /// List of user count by status Id.
        /// </summary>
        public List<AccountabilityEventStatusStatisticModel> EventStatusStatisticModel { get; set; }
    }

   
    public class AccountabilityEventStatusStatisticModel
    {
        public DateTime? StatusUpdatedOn { get; set; }
        public int UserCount { get; set; }
        public int StatusId { get; set; }
        public string ResponseText { get; set; }

    }
    public class AccountabilityEventSummaryUserWithResponseCountModel
    {
        public int UserCount { get; set; }
        public string GroupName { get; set; }
        public DateTime GroupStartTime { get; set; }
        public DateTime GroupEndTime { get; set; }
    }

    public class AccountabilityEventSummaryMessageSentCountModel
    {
        public int SentMessageCount { get; set; }
        public string GroupName { get; set; }
        public DateTime GroupStartTime { get; set; }
        public DateTime GroupEndTime { get; set; }
    }
   
}
