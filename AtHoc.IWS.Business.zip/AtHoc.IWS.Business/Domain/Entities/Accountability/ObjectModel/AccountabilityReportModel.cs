﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.SessionState;
using AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel;

namespace AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel
{
    public class AccountabilityReportModel
    {
        public int SessionId { get; set; }

        public int StatusTrackingModelsTotalUsers { get; set; }
        public IEnumerable<AccountabilityEventStatusTrackingReportModel> StatusTrackingModels { get; set; }
        public IEnumerable<AccountabilityEventStatusTrackingByOrgReportModel> StatusTrackingByOrgModels { get; set; }
    }



    public class EventStatusModel
    {
        public EventStatusModel()
        {
            StatusByResponse = new List<EventStatusEntryModel>();            
        }
        public List<int> EventIds { get; set; }

        public int TotalUsers { get; set; }
        public EventStatusEntryModel TotalResponses { get; set; }

        public List<EventStatusEntryModel> StatusByResponse { get; set; }               

        public int SessionId { get; set; }

        public int TotalAffectedUsers { get; set; }

        public bool IsRestricted { get; set; }
    }

    public class EventStatusEntryModel
    {
        public int ResponseId { get; set; }
        public AccountabilityEventStatusAttribute StatusAttribute { get; set; }        
        public int Responses { get; set; }
        public int ResponsesByUser { get; set; }
        public int ResponsesByOperator { get; set; }        
    }

    public class AccountabilityEventStatusTrackingReportModel
    {
        public int EventId { get; set; }
        public object GroupBy { get; set; }
        public object SubGroupBy { get; set; }
        public int UsersCount { get; set; }
    }

    public class AccountabilityEventStatusTrackingByOrgReportModel
    {
        public int SeqId { get; set; }
        public int OrgId { get; set; }
        public string Org { get; set; }
        public string OrgPath { get; set; }

        public int? ParentNodeId { get; set; }
        public string ParentNode { get; set; }
        public int TreeDepth { get; set; }
        public int TreeDepthFromLeaf { get; set; }
        public int Status { get; set; }
        public int UsersCount { get; set; }
    }

    public class AcctEventReport
    {
        public string Node { get; set; }
        public int NodeId { get; set; }
        public int ParentNodeId { get; set; }
        public int StatusId { get; set; }
        public int StatusCount { get; set; }

    }
}
