﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Security.AccessControl;
using AtHoc.Data.Specification;
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel;
using AtHoc.Publishing;
using AtHoc.Utilities;

namespace AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel
{
    public class AccountabilityEvent : AccountabilityEventBase
    {
        public AccountabilityEvent()
        {
            AssociatedAlerts = new List<AccountabilityEventAlert>();
        }
        public string Name { get; set; }
        public string Description { get; set; }
        public int EventId { get; set; }
        public int TemplateId { get; set; }
        public AccountabilityEventStatus Status { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public DateTime? StartedOn { get; set; }
        public int? StartedBy { get; set; }
        public DateTime? EndedOn { get; set; }
        public int? EndedBy { get; set; }

        public string StartedByName { get; set; }

        public string EndedByName { get; set; }
        public int CountOfUserAffected { get; set; }
        public int CountOfUserWithResponse { get; set; }
        public int CountOfUserWithNoResponse { get; set; }
        protected override void LoadDetail()
        {
            // DO NOTHING
        }

        public List<AccountabilityEventAlert> AssociatedAlerts { get; set; }
        /// <summary>
        /// To set the accountabilityEventEntity from AccountabilityEvent.
        /// </summary>
        /// <returns>Event Entity.</returns>
        public AccountabilityEventEntity ToEntity()
        {
            var eventEntity = new AccountabilityEventEntity
            {
                EventId = EventId,
                Name = AlertSpec.Content.Header,
                Description = AlertSpec.Content.Body,
                UserAlertBaseId = AlertId,
                ProviderId = ProviderId,
                TemplateId = TemplateId,
                Status = Status.ToString(),
                StartDate = StartDate,
                EndDate = EndDate,
                PublishedOn = StartedOn,
                PublishedByUserId = StartedBy,
                PublishedByUserName = StartedByName,
                EndedOn = EndedOn,
                EndedByUserId = EndedBy,
                CreatedOn = CreatedOn,
                CreatedBy = CreatedBy,
                UpdatedOn = UpdatedOn,
                UpdatedBy = UpdatedBy,
                PastStatusValidityDurationUnit = (PastStatusValidityDuration != null ?PastStatusValidityDuration.Unit.GetString():null),
                PastStatusValidityDurationValue = (PastStatusValidityDuration != null ? PastStatusValidityDuration.Value : (int?)null),
                EventRecipientRefreshIntervalUnit = (RecipientRefreshIntervalDuration != null ? RecipientRefreshIntervalDuration.Unit.GetString() : null),
                EventRecipientRefreshIntervalValue = (RecipientRefreshIntervalDuration != null ? RecipientRefreshIntervalDuration.Value : (int?)null)
            };
            if (OperatorAlertBase != null)
            {
                eventEntity.OperatorAlertBaseId = OperatorAlertBase.AlertId;
            }
            eventEntity.AccountabilityEventAlertMapEntities = ToAlertMapEntities();

            if (PastStatusValidityDuration != null)
            {
                eventEntity.PastStatusValidityDurationUnit = PastStatusValidityDuration.Unit.GetString();
                eventEntity.PastStatusValidityDurationValue = PastStatusValidityDuration.Value;
            }

            if (RecipientRefreshIntervalDuration != null)
            {
                eventEntity.EventRecipientRefreshIntervalUnit = RecipientRefreshIntervalDuration.Unit.GetString();
                eventEntity.EventRecipientRefreshIntervalValue = RecipientRefreshIntervalDuration.Value;
            }
            return eventEntity;
        }

        /// <summary>
        /// To set the AccountabilityEvent from  accountabilityEventEntity.
        /// </summary>
        public void FromEntity(AccountabilityEventEntity eventEntity, bool includeReminders, bool includeEventStatistics = false)
        {
            EventId = eventEntity.EventId;
            AlertId = eventEntity.UserAlertBaseId;
            UserAlertBaseId = eventEntity.UserAlertBaseId;
            OperatorAlertBaseId = eventEntity.OperatorAlertBaseId;
            Name = eventEntity.Name;
            Description = eventEntity.Description;
            ProviderId = eventEntity.ProviderId;
            TemplateId = eventEntity.TemplateId;
            Status = eventEntity.Status.ToEnum<AccountabilityEventStatus>();
            StartDate = eventEntity.StartDate;
            EndDate = eventEntity.EndDate;
            StartedOn = eventEntity.PublishedOn;
            StartedBy = eventEntity.PublishedByUserId;
            EndedOn = eventEntity.EndedOn;
            EndedBy = eventEntity.EndedByUserId;
            CreatedOn = eventEntity.CreatedOn;
            CreatedBy = eventEntity.CreatedBy;
            UpdatedOn = eventEntity.UpdatedOn;
            UpdatedBy = eventEntity.UpdatedBy;

            if (includeEventStatistics)
            {
                if (eventEntity.AccountabilityEventSummaryTrackingEntity != null)
                {
                    CountOfUserAffected =
                        eventEntity.AccountabilityEventSummaryTrackingEntity.Targeted.GetValueOrDefault();
                    CountOfUserWithResponse =
                        eventEntity.AccountabilityEventSummaryTrackingEntity.Responded.GetValueOrDefault();
                    CountOfUserWithNoResponse =
                        eventEntity.AccountabilityEventSummaryTrackingEntity.NoResponse.GetValueOrDefault();
                }
            }

            AssociatedAlerts = new List<AccountabilityEventAlert>();

            var associatedAlerts = from a in eventEntity.AccountabilityEventAlertEntities
                join alert in eventEntity.AccountabilityEventAlertMapEntities on a.AccountabilityEventAlertMapId equals
                    alert.Id
                select new AccountabilityEventAlert {AlertId = a.AlertId, AlertInitType = alert.AlertInitType};
            AssociatedAlerts = associatedAlerts.ToList();
            FromAletMapEntities(eventEntity.AccountabilityEventAlertMapEntities);
            if (eventEntity.PastStatusValidityDurationValue.HasValue && !string.IsNullOrEmpty(eventEntity.PastStatusValidityDurationUnit))
            {
                PastStatusValidityDuration = new Duration(eventEntity.PastStatusValidityDurationUnit, eventEntity.PastStatusValidityDurationValue.Value);
            }

            if (eventEntity.EventRecipientRefreshIntervalValue.HasValue && !string.IsNullOrEmpty(eventEntity.EventRecipientRefreshIntervalUnit))
            {
                RecipientRefreshIntervalDuration = new Duration(eventEntity.EventRecipientRefreshIntervalUnit, eventEntity.EventRecipientRefreshIntervalValue.Value);
            }
           
        }

        /// <summary>
        /// To set the AccountabilityEvent form AccountabilityTemplate.
        /// </summary>
        /// <param name="accTemplate">Accountability Template.</param>
        public void FromTemplate(AccountabilityTemplate accTemplate)
        {
            
            var createdTime = DateTimeConverter.GetSystemTime();
            TemplateId = accTemplate.TemplateId;
            FirstAlertUserMessage = accTemplate.FirstAlertUserMessage;
            ReminderAlertUserMessage = accTemplate.ReminderAlertUserMessage;
            CloseAlertUserMessage = accTemplate.CloseAlertUserMessage;
            FirstAlertOperatorMessage = accTemplate.FirstAlertOperatorMessage;
            CloseAlertOperatorMessage = accTemplate.CloseAlertOperatorMessage;
            PastStatusValidityDuration = accTemplate.PastStatusValidityDuration;
            RecipientRefreshIntervalDuration = accTemplate.RecipientRefreshIntervalDuration;
            StartDate = createdTime;
            EndDate = accTemplate.AlertSpec.LiveDuration.GetEndTime(createdTime);
        }

        private  ICollection<AccountabilityEventAlertMapEntity>ToAlertMapEntities()
        {

            ICollection<AccountabilityEventAlertMapEntity> alertMapCollection = new Collection<AccountabilityEventAlertMapEntity>();

            if (FirstAlertUserMessage != null)
            {
                var firstEventAlertEntity = new AccountabilityEventAlertMapEntity();
                firstEventAlertEntity.CopyTo(firstEventAlertEntity, FirstAlertUserMessage, AccountabilityEventAlertType.Start, AccountabilityEventUserType.User);
                alertMapCollection.Add(firstEventAlertEntity);
            }
            if (ReminderAlertUserMessage != null)
            {
                var reminderEventAlertEntity = new AccountabilityEventAlertMapEntity();
                reminderEventAlertEntity.CopyTo(reminderEventAlertEntity,ReminderAlertUserMessage, AccountabilityEventAlertType.Reminder, AccountabilityEventUserType.User);
                alertMapCollection.Add(reminderEventAlertEntity);
            }
            if (CloseAlertUserMessage != null)
            {
                var closeEventAlertEntity = new AccountabilityEventAlertMapEntity();
                closeEventAlertEntity.CopyTo(closeEventAlertEntity,CloseAlertUserMessage, AccountabilityEventAlertType.Close, AccountabilityEventUserType.User);
                alertMapCollection.Add(closeEventAlertEntity);
            }

            //Operator Message
            if (FirstAlertOperatorMessage != null )
            {
                var firstOprEventAlertEntity = new AccountabilityEventAlertMapEntity();
                firstOprEventAlertEntity.CopyTo(firstOprEventAlertEntity,FirstAlertOperatorMessage, AccountabilityEventAlertType.Start, AccountabilityEventUserType.Operator);
                if (OperatorAlertBase == null)
                {
                    firstOprEventAlertEntity.IsEnabled = "N";
                }
                alertMapCollection.Add(firstOprEventAlertEntity);
            }

            if (CloseAlertOperatorMessage != null )
            {
                var closingOprEventAlertEntity = new AccountabilityEventAlertMapEntity();
                closingOprEventAlertEntity.CopyTo(closingOprEventAlertEntity,CloseAlertOperatorMessage, AccountabilityEventAlertType.Close, AccountabilityEventUserType.Operator);
                if (OperatorAlertBase == null)
                {
                    closingOprEventAlertEntity.IsEnabled = "N";
                }
                alertMapCollection.Add(closingOprEventAlertEntity);
            }

            return alertMapCollection;
        }

        private void FromAletMapEntities(IEnumerable<AccountabilityEventAlertMapEntity> accountabilityEventAlertMapEntities)
        {
            var eventAlertMapEntities = accountabilityEventAlertMapEntities as IList<AccountabilityEventAlertMapEntity> ?? accountabilityEventAlertMapEntities.ToList();
            if (eventAlertMapEntities.Any())
            {
                var userType = AccountabilityEventUserType.User.GetDescription();
                var operatorType = AccountabilityEventUserType.Operator.GetDescription();

                //Get Start Event - Messages from base template
                var startAlertMessageEntity = eventAlertMapEntities
                    .FirstOrDefault(
                        s =>
                            (String.Equals(s.AlertInitType, AccountabilityEventAlertType.Start.ToString(),
                                StringComparison.InvariantCultureIgnoreCase))
                            && (String.Equals(s.AlertType, userType, StringComparison.InvariantCultureIgnoreCase))
                    );
                if (startAlertMessageEntity != null)
                {
                    var startAlertMessage = AccountabilityMessage.GetAlertMessageFromBaseEntity(startAlertMessageEntity);
                    FirstAlertUserMessage = startAlertMessage;
                }

                //Get Reminder Event - Messages from base template
                var reminderAlertMessageEntity =
                    eventAlertMapEntities.FirstOrDefault(
                        s =>
                            String.Equals(s.AlertInitType, AccountabilityEventAlertType.Reminder.ToString(),
                                StringComparison.InvariantCultureIgnoreCase)
                            && String.Equals(s.AlertType, userType, StringComparison.InvariantCultureIgnoreCase)
                        );
                if (reminderAlertMessageEntity != null)
                {
                    var startAlertMessage =
                        AccountabilityMessage.GetAlertMessageFromBaseEntity(reminderAlertMessageEntity);
                    ReminderAlertUserMessage = startAlertMessage;
                }

                //Get Close Event - Messages from base template
                var closeAlertMessageEntity =
                    eventAlertMapEntities.FirstOrDefault(
                        s =>
                            String.Equals(s.AlertInitType, AccountabilityEventAlertType.Close.ToString(),
                                StringComparison.InvariantCultureIgnoreCase)
                            && String.Equals(s.AlertType, userType, StringComparison.InvariantCultureIgnoreCase)
                        );
                if (closeAlertMessageEntity != null)
                {
                    var closeAlertMessage = AccountabilityMessage.GetAlertMessageFromBaseEntity(closeAlertMessageEntity);
                    CloseAlertUserMessage = closeAlertMessage;
                }

                //Get Start Event -Operator Messages from base template
                var startOprAlertMessageEntity =
                    eventAlertMapEntities.FirstOrDefault(
                        s =>
                            String.Equals(s.AlertInitType, AccountabilityEventAlertType.Start.ToString(),
                                StringComparison.InvariantCultureIgnoreCase)
                            && String.Equals(s.AlertType, operatorType, StringComparison.InvariantCultureIgnoreCase)
                        );
                if (startOprAlertMessageEntity != null)
                {
                    var startOprAlertMessage =
                        AccountabilityMessage.GetAlertMessageFromBaseEntity(startOprAlertMessageEntity);
                    FirstAlertOperatorMessage = startOprAlertMessage;
                }

                //Get Close Event - Messages from base template
                var closeOprAlertMessageEntity =
                    eventAlertMapEntities.FirstOrDefault(
                        s =>
                            String.Equals(s.AlertInitType, AccountabilityEventAlertType.Close.ToString(),
                                StringComparison.InvariantCultureIgnoreCase)
                            && String.Equals(s.AlertType, operatorType, StringComparison.InvariantCultureIgnoreCase)
                        );
                if (closeOprAlertMessageEntity != null)
                {
                    var closeOprAlertMessage =
                        AccountabilityMessage.GetAlertMessageFromBaseEntity(closeOprAlertMessageEntity);
                    CloseAlertOperatorMessage = closeOprAlertMessage;
                }
            }
        }
    }
}
