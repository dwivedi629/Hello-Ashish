﻿
namespace AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel
{
    public class AccountabilityUserPerProvider
    {
        public int ProviderId { get; set; }

        public int ResponseAttributeId { get; set; } 
    }
}
