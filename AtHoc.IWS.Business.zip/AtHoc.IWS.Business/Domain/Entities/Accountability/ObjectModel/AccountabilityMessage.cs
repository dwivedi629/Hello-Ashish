﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel;
using AtHoc.Utilities;

namespace AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel
{
    public class AccountabilityMessage
    {
        #region properties
        public int MessageId { get; set; }
        public string Title { get; set; }
        public string Body { get; set; }
        public bool IsEnabled { get; set; }
        public Duration AlertRepeatDuration { get; set; }
        #endregion
        #region methods
        /// <summary>
        /// 
        /// </summary>
        /// <param name="alertMessageEntity"></param>
        /// <returns></returns>
        public static AccountabilityMessage GetAlertMessageFromBaseEntity(AccountabilityAlertMapEntity alertMessageEntity)
        {
            var duration = new Duration(alertMessageEntity.AlertRepeatDurationUnit, alertMessageEntity.AlertRepeatDurationValue);
            var body = alertMessageEntity.Body;
            var title = alertMessageEntity.Title;
            var isEnabled = alertMessageEntity.IsEnabled == "Y";
            var accountabilityMessage = new AccountabilityMessage
            {
                MessageId = alertMessageEntity.Id,
                AlertRepeatDuration = duration,
                Body = body,
                IsEnabled = isEnabled,
                Title = title
            };
            return accountabilityMessage;
        }
        
        #endregion

    }
}
