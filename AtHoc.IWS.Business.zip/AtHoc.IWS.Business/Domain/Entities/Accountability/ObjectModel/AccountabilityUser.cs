﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel
{
    public class AccountabilityUser
    {
        public int UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Comments { get; set; }
        public string Organization { get; set; }
        public string Status { get; set; }
        public string Source { get; set; }
        public DateTime? RespondedOn { get; set; }
    }
}
