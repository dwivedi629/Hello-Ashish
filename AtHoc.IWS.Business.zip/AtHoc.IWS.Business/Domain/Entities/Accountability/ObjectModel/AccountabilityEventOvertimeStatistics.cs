﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel
{
    public class AccountabilityEventOvertimeStatistics
    {
        public List<AccountabilityEventSummaryUserWithResponseCountModel> EventOvertimeStatusesWithGroups { get; set; }
        public List<AccountabilityEventSummaryMessageSentCountModel> EventOvertimeMessageSents { get; set; }
    }

    
}
