﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel;
using AtHoc.Publishing;
using AtHoc.Utilities;

namespace AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel
{
    /// <summary>
    /// 
    /// </summary>
    public class AccountabilityEventSearchResult
    {
        public int EventId { get; set; }
        public string EventName { get; set; }
        public string EventDescription { get; set; }
        public int AlertBaseId { get; set; }
        public int StatusAttributeId { get; set; }
        public string StatusAttributeName { get; set; }
        public int CreatedBy { get; set; }
        public string CreatedByName { get; set; }
        public string Status { get; set; }
        public int UpdatedBy { get; set; }
        public string UpdatedByName { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime UpdatedOn { get; set; }
        public int Priority { get; set; }
        public int ProviderId { get; set; }
        public string ProviderName { get; set; }
        public int StartedBy { get; set; }
        public string StartedByName { get; set; }
        public DateTime StartedOn { get; set; }
        public DateTime EndDate { get; set; }
        public decimal Affected { get; set; }
        public decimal UsersResponded { get; set; }
        public decimal UsersNotResponded { get; set; }
        public string GeoJson { get; set; }
        public IEnumerable<AccountabilityEventSummaryResponseTracking> Responses { get; set; }
    }
}
