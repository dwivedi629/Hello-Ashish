﻿using System;
using AtHoc.Publishing;

namespace AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel
{
    public class AccountabilityEventAlert
    {
        public int EventId { get; set; }
        public int AlertId { get; set; }

        //public AlertStatus Status { get; set; }
        public string  AlertStatus { get; set; }
      
        public string AlertTitle { get; set; }
        public string AlertBody { get; set; }

        /// <summary>
        /// Start,Reminder,Close
        /// </summary>
        public string AlertInitType { get; set; }
        //AlertType = USR/OPR
        public string AlertType { get; set; }

        public int ? TotalUser { get; set; }

        public DateTime? PublishedOn { get; set; }
        
        public DateTime StartDate { get; set; }

        public int ErrorCount { get; set; }

    }
}
