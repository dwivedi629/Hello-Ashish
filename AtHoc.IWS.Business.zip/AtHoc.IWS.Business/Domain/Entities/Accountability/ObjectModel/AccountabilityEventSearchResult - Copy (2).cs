﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel;
using AtHoc.Publishing;
using AtHoc.Utilities;

namespace AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel
{
    /// <summary>
    /// 
    /// </summary>
    public class AccountabilityEventSearchResult
    {
        public int EventId { get; set; }
        public string EventName { get; set; }
        public int StatusAttributeId { get; set; }
        public string StatusAttributeName { get; set; }
        public int CreatedById { get; set; }
        public string CreatedBy { get; set; }
        public string Status { get; set; }
        public int UpdatedById { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime UpdatedOn { get; set; }
        public int Priority { get; set; }
        public int ProviderId { get; set; }
        public string ProviderName { get; set; }
        public int StartedBy { get; set; }
        public string PublishedBy { get; set; }
        public DateTime StartedOn { get; set; }
        public int? Affected { get; set; }
        public int? UsersResponded { get; set; }
        public int? UsersNotResponded { get; set; }
    }
}
