﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel
{
    public class UserAccountabilityEventAlert
    {
        public int AlertId { get; set; }
        public int EventId { get; set; }

        public int UserId { get; set; }

        public string Title { get; set; }

        public string Body { get; set; }

        public DateTime PublishedOn { get; set; }
    }

    public class AccountabilityEventDetail
    {
        public  AccountabilityEventDetail()
        {
            UserAccountabilityEventAlerts =new List<UserAccountabilityEventAlert>();
        }
        public AccountabilityActivityFeed AccountabilityActivityFeed { get; set; }
        public List<UserAccountabilityEventAlert> UserAccountabilityEventAlerts { get; set; }
    }
}
