﻿using System.Collections.Generic;

namespace AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel
{
    public class EventOrganizationHierarchy
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }

    public class EventOrganizationReport
    {
        public int Id { get; set; }
        public int ParentId { get; set; }
        public bool HasChildren { get; set; }
        public string Name { get; set; }
        public Dictionary<string, int> ResponseValues { get; set; }
        public int Depth { get; set; }
        public int TotalCount { get; set; }
        public int SortOrder { get; set; }
    }
}
