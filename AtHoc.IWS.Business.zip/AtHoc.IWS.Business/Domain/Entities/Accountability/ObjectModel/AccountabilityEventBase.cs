﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Publishing;
using AtHoc.Utilities;

namespace AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel
{
   public class AccountabilityEventBase :AlertBase
    {
        public int UserAlertBaseId { get; set; }
        public int? OperatorAlertBaseId { get; set; }
        public Duration PastStatusValidityDuration { get; set; }
        public Duration RecipientRefreshIntervalDuration { get; set; }
        public AccountabilityMessage FirstAlertUserMessage { get; set; }
        public AccountabilityMessage ReminderAlertUserMessage { get; set; }
        public AccountabilityMessage CloseAlertUserMessage { get; set; }

        //Operator Message
        public AccountabilityMessage FirstAlertOperatorMessage { get; set; }
        public AccountabilityMessage CloseAlertOperatorMessage { get; set; }
      
       //
        public AccountabilityAlertBase OperatorAlertBase { get; set; }
        #region methods
        protected override void LoadDetail()
        {
            //DO NOTHING.
        }

        internal void CopyTo(AccountabilityEventBase acctEventBase, int operatorId)
        {
            base.CopyTo(acctEventBase, operatorId);

            acctEventBase.FirstAlertUserMessage = FirstAlertUserMessage;
            acctEventBase.ReminderAlertUserMessage = ReminderAlertUserMessage;
            acctEventBase.CloseAlertUserMessage = CloseAlertUserMessage;
            acctEventBase.PastStatusValidityDuration = PastStatusValidityDuration;
            acctEventBase.RecipientRefreshIntervalDuration = RecipientRefreshIntervalDuration;
            //Operator Message
            acctEventBase.FirstAlertOperatorMessage = FirstAlertOperatorMessage;
            acctEventBase.CloseAlertOperatorMessage = CloseAlertOperatorMessage;
        }
        #endregion
    }

    public class AccountabilityAlertBase : AlertBase
    {
        protected override void LoadDetail()
        {
           //DO NOTHING
        }
    }
}
