﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel;
using AtHoc.Publishing;
using AtHoc.Utilities;

namespace AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel
{
    /// <summary>
    /// 
    /// </summary>
    public class AccountabilityTemplate : AccountabilityEventBase
    {
        public AccountabilityTemplate()
        {
            //UserReminderDuration = new Duration(DurationUnit.Hour, 4);
        }

        #region Properties

      
        /// <summary>
        /// 
        /// </summary>
        public int TemplateId { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// /
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string CommonName { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Status { get; set; }
        public DateTime LastEventPublishedOnDateTime { get; set; }

        #endregion

        #region Methods

        /// <summary>
        /// 
        /// </summary>
        protected override void LoadDetail()
        {
            // DO NOTHING
        }
        internal void CopyTo(AccountabilityTemplate template)
        {
            base.CopyTo(template);
            template.Name = Name;
            template.Description = Description;
            template.CommonName = CommonName;
            template.Status = Status;
        }
        #endregion

        /// <summary>
        /// To set the AccountabilityTemplateEntity from AccountabilityTemplate.
        /// </summary>        
        /// <returns>accountability tempalte entity.</returns>
        public AccountabilityTemplateEntity ToEntity()
        {
            var templateEntity = new AccountabilityTemplateEntity
            {
                TemplateId = TemplateId,
                Name = Name,
                Description = Description,
                CommonName = CommonName,
                Status = Status,
                UserAlertBaseId = AlertId,
                ShowInUi = "Y",
                ProviderId = ProviderId,
                CreatedBy = CreatedBy,
                CreatedOn = CreatedOn,
                UpdatedBy = UpdatedBy,
                UpdatedOn = UpdatedOn
            };
            if (OperatorAlertBase!=null)
                templateEntity.OperatorAlertBaseId = OperatorAlertBase.AlertId;

            templateEntity.TemplateAlertMapEntities = ToAlertMapEntities();

            if (PastStatusValidityDuration != null)
            {
                templateEntity.PastStatusValidityDurationUnit = PastStatusValidityDuration.Unit.GetString();
                templateEntity.PastStatusValidityDurationValue = PastStatusValidityDuration.Value;
            }

            if (RecipientRefreshIntervalDuration != null)
            {
                templateEntity.EventRecipientRefreshIntervalUnit = RecipientRefreshIntervalDuration.Unit.GetString();
                templateEntity.EventRecipientRefreshIntervalValue = RecipientRefreshIntervalDuration.Value;
            }
            return templateEntity;
        }

        

        /// <summary>
        /// To set AccountabilityTemplate from AccountabilityTemplateEntity.
        /// </summary>
        /// <param name="templateEntity">accountability template entity.</param>        
        public void FromEntity(AccountabilityTemplateEntity templateEntity)
        {
            UserAlertBaseId = templateEntity.UserAlertBaseId;
            OperatorAlertBaseId = templateEntity.OperatorAlertBaseId;
            TemplateId = templateEntity.TemplateId;
            Name = templateEntity.Name;
            Description = templateEntity.Description;
            CommonName = templateEntity.CommonName;
            Status = templateEntity.Status;

            if ((!string.IsNullOrEmpty( templateEntity.EventRecipientRefreshIntervalUnit) )&&
                templateEntity.PastStatusValidityDurationValue.HasValue &&
                templateEntity.PastStatusValidityDurationValue.Value > 0)
            {
               
                    RecipientRefreshIntervalDuration = new Duration(templateEntity.EventRecipientRefreshIntervalUnit, templateEntity.EventRecipientRefreshIntervalValue.Value);
            }
            

            if (templateEntity.Events != null)
            {
                var recentEventWithPublishedTime = templateEntity.Events
                    .OrderByDescending(e => e.PublishedOn)
                    .FirstOrDefault(e => e.PublishedOn.HasValue);
                if (recentEventWithPublishedTime != null && recentEventWithPublishedTime.PublishedOn.HasValue)
                {
                    LastEventPublishedOnDateTime = recentEventWithPublishedTime.PublishedOn.Value;
                }
            }
          

            if (templateEntity.PastStatusValidityDurationValue.HasValue && !string.IsNullOrEmpty(templateEntity.PastStatusValidityDurationUnit))
            {
                PastStatusValidityDuration = new Duration(templateEntity.PastStatusValidityDurationUnit, templateEntity.PastStatusValidityDurationValue.Value);
            }

            if (templateEntity.EventRecipientRefreshIntervalValue.HasValue && !string.IsNullOrEmpty(templateEntity.EventRecipientRefreshIntervalUnit))
            {
                RecipientRefreshIntervalDuration = new Duration(templateEntity.EventRecipientRefreshIntervalUnit, templateEntity.EventRecipientRefreshIntervalValue.Value);
            }
            FromAletMapEntities(templateEntity.TemplateAlertMapEntities);
            AlertId = templateEntity.UserAlertBaseId;
            CreatedOn = templateEntity.CreatedOn;
            CreatedBy = templateEntity.CreatedBy;
            UpdatedOn = templateEntity.UpdatedOn;
            UpdatedBy = templateEntity.UpdatedBy;
        }

        private ICollection<AccountabilityTemplateAlertMapEntity> ToAlertMapEntities()
        {

            ICollection<AccountabilityTemplateAlertMapEntity> alertMapCollection = new Collection<AccountabilityTemplateAlertMapEntity>();

            if (FirstAlertUserMessage != null)
            {
                var firstEventAlertEntity = new AccountabilityTemplateAlertMapEntity();
                firstEventAlertEntity.CopyTo(firstEventAlertEntity, FirstAlertUserMessage, AccountabilityEventAlertType.Start, AccountabilityEventUserType.User);
                alertMapCollection.Add(firstEventAlertEntity);
            }
            if (ReminderAlertUserMessage != null)
            {
                var reminderEventAlertEntity = new AccountabilityTemplateAlertMapEntity();
                reminderEventAlertEntity.CopyTo(reminderEventAlertEntity, ReminderAlertUserMessage, AccountabilityEventAlertType.Reminder, AccountabilityEventUserType.User);
                alertMapCollection.Add(reminderEventAlertEntity);
            }
            if (CloseAlertUserMessage != null)
            {
                var closeEventAlertEntity = new AccountabilityTemplateAlertMapEntity();
                closeEventAlertEntity.CopyTo(closeEventAlertEntity, CloseAlertUserMessage, AccountabilityEventAlertType.Close, AccountabilityEventUserType.User);
                alertMapCollection.Add(closeEventAlertEntity);
            }

            //Operator Message
            if (FirstAlertOperatorMessage != null)
            {
                var firstOprEventAlertEntity = new AccountabilityTemplateAlertMapEntity();
                firstOprEventAlertEntity.CopyTo(firstOprEventAlertEntity, FirstAlertOperatorMessage, AccountabilityEventAlertType.Start, AccountabilityEventUserType.Operator);
                alertMapCollection.Add(firstOprEventAlertEntity);
            }

            if (CloseAlertOperatorMessage != null)
            {
                var closingOprEventAlertEntity = new AccountabilityTemplateAlertMapEntity();
                closingOprEventAlertEntity.CopyTo(closingOprEventAlertEntity, CloseAlertOperatorMessage, AccountabilityEventAlertType.Close, AccountabilityEventUserType.Operator);
                alertMapCollection.Add(closingOprEventAlertEntity);
            }

            return alertMapCollection;
        }

        private void FromAletMapEntities(
            IEnumerable<AccountabilityTemplateAlertMapEntity> accountabilityTemplateAlertMapEntities)
        {
            var templateAlertMapEntities = accountabilityTemplateAlertMapEntities as IList<AccountabilityTemplateAlertMapEntity> ?? accountabilityTemplateAlertMapEntities.ToList();
            if (templateAlertMapEntities.Any())
            {

                var userType = AccountabilityEventUserType.User.GetDescription();
                var operatorType = AccountabilityEventUserType.Operator.GetDescription();

                //Get Start Event - Messages from base template
                var startAlertMessageEntity = templateAlertMapEntities
                        .FirstOrDefault(
                        s => (String.Equals(s.AlertInitType, AccountabilityEventAlertType.Start.ToString(), StringComparison.InvariantCultureIgnoreCase))
                            && (String.Equals(s.AlertType, userType, StringComparison.InvariantCultureIgnoreCase))
                            );
                if (startAlertMessageEntity != null)
                {
                    var startAlertMessage = AccountabilityMessage.GetAlertMessageFromBaseEntity(startAlertMessageEntity);
                    FirstAlertUserMessage = startAlertMessage;
                }

                //Get Reminder Event - Messages from base template
                var reminderAlertMessageEntity = templateAlertMapEntities.FirstOrDefault(s => String.Equals(s.AlertInitType, AccountabilityEventAlertType.Reminder.ToString(), StringComparison.InvariantCultureIgnoreCase)
                    && String.Equals(s.AlertType, userType, StringComparison.InvariantCultureIgnoreCase)
                    );
                if (reminderAlertMessageEntity != null)
                {
                    var startAlertMessage = AccountabilityMessage.GetAlertMessageFromBaseEntity(reminderAlertMessageEntity);
                    ReminderAlertUserMessage = startAlertMessage;
                }

                //Get Close Event - Messages from base template
                var closeAlertMessageEntity = templateAlertMapEntities.FirstOrDefault(s => String.Equals(s.AlertInitType, AccountabilityEventAlertType.Close.ToString(), StringComparison.InvariantCultureIgnoreCase)
                    && String.Equals(s.AlertType, userType, StringComparison.InvariantCultureIgnoreCase)
                    );
                if (closeAlertMessageEntity != null)
                {
                    var closeAlertMessage = AccountabilityMessage.GetAlertMessageFromBaseEntity(closeAlertMessageEntity);
                    CloseAlertUserMessage = closeAlertMessage;
                }

                //Get Start Event - Message for Operator from base template
                var startOperatorAlertMessageEntity = templateAlertMapEntities.FirstOrDefault(s => String.Equals(s.AlertInitType, AccountabilityEventAlertType.Start.ToString(), StringComparison.InvariantCultureIgnoreCase)
                    && String.Equals(s.AlertType, operatorType, StringComparison.InvariantCultureIgnoreCase)
                    );
                if (startOperatorAlertMessageEntity != null)
                {
                    var startOprAlertMessage = AccountabilityMessage.GetAlertMessageFromBaseEntity(startOperatorAlertMessageEntity);
                    FirstAlertOperatorMessage = startOprAlertMessage;
                }
                //Get Close Event - Message for Operator from base template
                var closeOperatorAlertMessageEntity = templateAlertMapEntities.FirstOrDefault(s => String.Equals(s.AlertInitType, AccountabilityEventAlertType.Close.ToString(), StringComparison.InvariantCultureIgnoreCase)
                   && String.Equals(s.AlertType, operatorType, StringComparison.InvariantCultureIgnoreCase)
                   );
                if (closeOperatorAlertMessageEntity != null)
                {
                    var closeOprAlertMessage = AccountabilityMessage.GetAlertMessageFromBaseEntity(closeOperatorAlertMessageEntity);
                    CloseAlertOperatorMessage = closeOprAlertMessage;
                }
            }
        }
        
    }
}
