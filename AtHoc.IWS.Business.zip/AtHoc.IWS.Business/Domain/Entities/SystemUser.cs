﻿using System;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Collections.Generic;

using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.Users.Impl;

namespace AtHoc.IWS.Business.Domain.Entities
{
	public class SystemUser
	{
		public SystemUser()
		{
			UserBase = Enumerable.Empty<OperatorUserBase>();
			Channels = Enumerable.Empty<OperatorChannel>();
			EntityAccessList = new List<OperatorEntityAccess>();
			Roles = Enumerable.Empty<OperatorUserRole>();
			DistributionLists = Enumerable.Empty<DistributionList>();
		}

		public int ProviderId
		{
		    get
		    {
		        return User.ProviderId != null ? User.ProviderId.Value : 0;
		    }
		    set { User.ProviderId = value; }
		}

		public int OperatorId
		{
			get { return OperatorUser.Id; }
			set { OperatorUser.Id = value; }
		}

		public int UserId
		{
			get { return User.Id; }
			set { User.Id = value; }
		}

		public IEnumerable<OperatorAccess> OperatorAccess
		{
			get { return OperatorUser.OperatorAccess; }
			set { OperatorUser.OperatorAccess = value; }
		}

		public User User { get; set; }

		public OperatorUser OperatorUser { get; set; }

		public IEnumerable<OperatorUserRole> Roles { get; set; }

		public IEnumerable<DistributionList> DistributionLists { get; internal set; }

		public IEnumerable<OperatorChannel> Channels { get; set; }

		public IEnumerable<OperatorEntityAccess> EntityAccessList { get; set; }

		public IEnumerable<OperatorUserBase> UserBase { get; set; }

        public bool HasUnrestrictedAlertFolders { get; set; }
        public bool HasUnrestrictedEntityAccess { get; set; }
        public bool HasUnrestrictedUserBaseAccess { get; set; }

		public bool IsOperator
		{
			get { return Roles.HasValue() || EntityAccessList.HasValue() || UserBase.HasValue(); }
		}

		public bool IsLocked
		{
			get
			{
			    return !string.IsNullOrEmpty(this.OperatorUser.AccessLocked) && this.OperatorUser.AccessLocked.ToUpper() == "YES";
			}
		}

		public bool IsChannelListUnrestricted()
		{
		    if (HasUnrestrictedAlertFolders) return true;
			return !Channels.Any();
		}

		public bool IsUserBaseUnrestricted()
		{
            if (HasUnrestrictedUserBaseAccess) return true;
			return !UserBase.Any();
		}

		public bool IsTargetableAccessListUnrestricted()
		{
            if (HasUnrestrictedEntityAccess) return true;
			var list = GetTargetableAccessList();
            return IsAccessListUnrestricted(list);
		}

		public bool IsManagableAccessListUnrestricted()
		{
            if (HasUnrestrictedEntityAccess) return true;
			var list = GetManagableAccessList();
			return IsAccessListUnrestricted(list);
		}

		public void UnrestrictUserBase()
		{
			UserBase = Enumerable.Empty<OperatorUserBase>();
		}

		public void UnrestrictChannels()
		{
			Channels = Enumerable.Empty<OperatorChannel>();
		}

		public void UnrestrictEntityAccess()
		{
			EntityAccessList = new []
			{
				CreateEntityAccessObj(TargetableListAccessType),
				CreateEntityAccessObj(ManagableListAccessType)
			};
		}

		public IEnumerable<OperatorEntityAccess> GetManagableAccessList()
		{
			return GetAccessList(ManagableListAccessType);
		}

		public IEnumerable<OperatorEntityAccess> GetTargetableAccessList()
		{
			return GetAccessList(TargetableListAccessType);
		}

		#region Private

		private static bool IsAccessListUnrestricted(IEnumerable<OperatorEntityAccess> list)
		{
            
			return list.Count() == 1 && list.First().EntityId == UnrestrictedCode;
		}

		private IEnumerable<OperatorEntityAccess> GetAccessList(string accessType)
		{
			return EntityAccessList.Where(e => e.AccessType == accessType).ToArray();
		}

		private OperatorEntityAccess CreateEntityAccessObj(string accessType, int entityId = UnrestrictedCode)
		{
			if (this.OperatorUser == null)
			{
				throw new ApplicationException("The OperatorUser property is not set.");
			}

			if (this.User == null)
			{
				throw new ApplicationException("The User property property is not set.");
			}

			if (!this.User.ProviderId.HasValue)
			{
				throw new ApplicationException("The User provider property is not set.");
			}

			return new OperatorEntityAccess
			{
				UserId = this.OperatorUser.Id,
				ProviderId = this.User.ProviderId.Value,
				AccessType = accessType,
				EntityType = "LST",
				EntityId = entityId
			};
		}

		private const string TargetableListAccessType = "TRG";
		private const string ManagableListAccessType = "MGT";
		private const int UnrestrictedCode = -1;

		#endregion Private
	}
}
