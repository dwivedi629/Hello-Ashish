﻿using AtHoc.Infrastructure.Meta;

namespace AtHoc.IWS.Business.Domain.Entities
{
	public partial class PageLayout
	{
		[MetaProperty(IsPersistable = false)]
		public int Id { get; set; }
	}

    public class Disclaimer
    {
        public string Title { get; set; }
        public string Description { get; set; }
    }
}