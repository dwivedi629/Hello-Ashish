﻿using System;

using AtHoc.IWS.Business;

namespace AtHoc.Business.Domain
{
	public class IntDateTime : IConvertible
	{
		protected bool Equals(IntDateTime other)
		{
			return Value.Equals(other.Value);
		}

		public IntDateTime(DateTime value)
		{
			Value = value;
		}

		public IntDateTime(int value)
		{
			Value = DateTimeConverter.GetDateTimeFromSeconds(value);
		}

		public DateTime Value { get; private set; }

		public static implicit operator IntDateTime(DateTime value)
		{
			return new IntDateTime(value);
		}

		public static implicit operator IntDateTime(int value)
		{
			return new IntDateTime(value);
		}

		public static implicit operator int(IntDateTime value)
		{
			return DateTimeConverter.GetSecondsFromDateTime(value.Value);
		}

		public override bool Equals(object obj)
		{
			if (obj == null)
			{
				return false;
			}

			if (obj is DateTime)
			{
				return ((DateTime) obj) == Value;
			}

			if (obj is int)
			{
				return this == (int) obj;
			}

			return Value == ((IntDateTime) obj).Value;
		}

		public override int GetHashCode()
		{
			return Value.GetHashCode();
		}

		#region IConvertible
		public TypeCode GetTypeCode()
		{
			throw new NotImplementedException();
		}

		public bool ToBoolean(IFormatProvider provider)
		{
			throw new NotImplementedException();
		}

		public char ToChar(IFormatProvider provider)
		{
			throw new NotImplementedException();
		}

		public sbyte ToSByte(IFormatProvider provider)
		{
			throw new NotImplementedException();
		}

		public byte ToByte(IFormatProvider provider)
		{
			throw new NotImplementedException();
		}

		public short ToInt16(IFormatProvider provider)
		{
			throw new NotImplementedException();
		}

		public ushort ToUInt16(IFormatProvider provider)
		{
			throw new NotImplementedException();
		}

		public int ToInt32(IFormatProvider provider)
		{
			return this;
		}

		public uint ToUInt32(IFormatProvider provider)
		{
			throw new NotImplementedException();
		}

		public long ToInt64(IFormatProvider provider)
		{
			throw new NotImplementedException();
		}

		public ulong ToUInt64(IFormatProvider provider)
		{
			throw new NotImplementedException();
		}

		public float ToSingle(IFormatProvider provider)
		{
			throw new NotImplementedException();
		}

		public double ToDouble(IFormatProvider provider)
		{
			throw new NotImplementedException();
		}

		public decimal ToDecimal(IFormatProvider provider)
		{
			throw new NotImplementedException();
		}

		public DateTime ToDateTime(IFormatProvider provider)
		{
			throw new NotImplementedException();
		}

		public string ToString(IFormatProvider provider)
		{
			throw new NotImplementedException();
		}

		public object ToType(Type conversionType, IFormatProvider provider)
		{
			throw new NotImplementedException();
		}
		#endregion IConvertible
	}
}