﻿using AtHoc.Infrastructure.Data;

using AtHoc.IWS.Business.Domain.Devices.Spec;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.Devices
{
	public interface IPagerCarrierRepository : IRepository<PagerCarrier, PagerCarrierSpec> {}

	public interface IPagerCarrierEntityRepository : IRepository<PagerCarrierEntity, PagerCarrierEntitySpec> {}
}