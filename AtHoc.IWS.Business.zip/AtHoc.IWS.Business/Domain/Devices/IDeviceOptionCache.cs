﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Devices
{
    public interface IDeviceOptionCache
    {
        string Get(int vpsId, int deviceGroupId, string locale);

        void Set(int vpsId, int deviceGroupId, string locale, string deviceGroupHtml);

        void Clear(int vpsId);
    }
}
