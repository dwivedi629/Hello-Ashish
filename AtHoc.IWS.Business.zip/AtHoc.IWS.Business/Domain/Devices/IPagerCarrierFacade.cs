﻿using System.Collections.Generic;

using AtHoc.IWS.Business.Domain.Devices.Spec;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.Devices
{
	public interface IPagerCarrierFacade
	{
		IEnumerable<PagerCarrier> GetPagerCarrierBySpec(PagerCarrierSpec spec);

		IEnumerable<PagerCarrierEntity> GetPagerCarrierEntityBySpec(PagerCarrierEntitySpec spec);

		IEnumerable<PagerCarrierEntity> GetAllPagerCarrierEntities();
	}
}