﻿using System.Linq;

using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Database;
using AtHoc.Infrastructure.Sql;
using AtHoc.IWS.Business.Domain.Devices.Spec;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.Devices.Impl
{
    public class DeviceAddressRepository : DbRepository<DeviceAddress, DeviceValueSpec>, IDeviceAddressRepository
    {
        public DeviceAddressRepository(IUnitOfWork context) : base(context) { }

        protected override void TranslateSpec(DeviceValueSpec spec, SqlBuilder builder, bool query)
        {
            builder.SelectAll<DeviceAddress>("a");
            builder.From(builder.Table<DeviceAddress>("a"));

            if (spec.IncludeDevice.HasValue && spec.IncludeDevice.Value)
            {
                builder.SelectAll<Device>("b", "1");
                builder.InnerJoin("DLV_DEVICE_TAB b WITH (NOLOCK) on b.DEVICE_ID = a.DEVICE_ID");
                if (spec.IncludeDeviceGroup.HasValue && spec.IncludeDeviceGroup.Value)
                {
                    builder.SelectAll<DeviceGroup>("c", "2");
                    builder.InnerJoin("DLV_DEVICE_GROUP_TAB c WITH (NOLOCK) on c.GROUP_ID = b.GROUP_ID");
                }
            }
          
            builder.Where(builder.Condition(DeviceAddress.Meta.UserId, ConditionOperator.Equals, spec.UserId));

            if (spec.DeviceIds != null && spec.DeviceIds.Any(a => a > 0))
            {
                builder.Where(builder.Condition(DeviceAddress.Meta.DeviceId, ConditionOperator.In, spec.DeviceIds, "a"));
            }

        }

        protected override bool OnItemDataBound(DeviceValueSpec spec, DeviceAddress obj, DbResultItem resultItem, SqlMapperContext mapContext)
        {
            if (spec.IncludeDevice.HasValue && spec.IncludeDevice.Value)
            {
                obj.Device = this.Context.Map.Translate<Device>(resultItem, mapContext);
                if (spec.IncludeDeviceGroup.HasValue && spec.IncludeDeviceGroup.Value)
                {
                    obj.Device.DeviceGroup = this.Context.Map.Translate<DeviceGroup>(resultItem, mapContext);
                }
            }
           
            
            return base.OnItemDataBound(spec, obj, resultItem, mapContext);
        }
    }
}
