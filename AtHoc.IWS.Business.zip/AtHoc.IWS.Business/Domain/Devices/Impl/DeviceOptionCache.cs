﻿using AtHoc.Runtime;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Devices.Impl
{
    public class DeviceOptionCache : IDeviceOptionCache
    {
        private readonly string _cacheKey = "DeviceOptionHtml";
        private static ProcessCache _deviceOptionProcessCache;
        private IDeviceOptionDbCache _deviceOptionDbCache;

        public DeviceOptionCache(IDeviceOptionDbCache deviceOptionDbCache)
        {
            _deviceOptionDbCache = deviceOptionDbCache;

            CreateNewDeviceCache();
        }

        public string Get(int vpsId, int deviceGroupId, string locale)
        {
            var deviceHtml = string.Empty;
            _deviceOptionProcessCache.TryGet(GetKey(vpsId, deviceGroupId, locale), out deviceHtml);

            //if empty get from db
            if (string.IsNullOrWhiteSpace(deviceHtml))
                deviceHtml = _deviceOptionDbCache.Get(vpsId, deviceGroupId, locale);

            return deviceHtml;
        }

        public void Set(int vpsId, int deviceGroupId, string locale, string DeviceOptionHtml)
        {
            _deviceOptionProcessCache.Set(GetKey(vpsId, deviceGroupId, locale), DeviceOptionHtml);

            //set value in db
            _deviceOptionDbCache.Set(vpsId, deviceGroupId, locale, DeviceOptionHtml);
        }

        public void Clear(int vpsId)
        {
            //remove from cache
            _deviceOptionProcessCache = null;

            //recreate cache
            CreateNewDeviceCache();

            //remove from db
            _deviceOptionDbCache.Clear(vpsId);
        }

        private string GetKey(int vpsId, int deviceGroupId, string locale)
        {
            return string.Format("{0}_{1}_{2}_{3}", _cacheKey, vpsId, deviceGroupId, locale);
        }

        private void CreateNewDeviceCache()
        {
            if (_deviceOptionProcessCache == null)
            {
                // Default caching for is 60 mins.
                var cacheDuration = System.Configuration.ConfigurationManager.AppSettings["DeviceOptionProcessCacheInMinutes"] ?? "60";
                var configuration = new ProcessCacheConfiguration
                {
                    IsEnabled = true,
                    DefaultExpiration = TimeSpan.FromMinutes(Int32.Parse(cacheDuration)),
                    DefaultExpirationType = ExpirationType.Absolute,
                    Name = _cacheKey,
                    PollingInterval = TimeSpan.FromMinutes(Int32.Parse(cacheDuration))
                };
                _deviceOptionProcessCache = new ProcessCache(configuration);
            }
        }
    }
}
