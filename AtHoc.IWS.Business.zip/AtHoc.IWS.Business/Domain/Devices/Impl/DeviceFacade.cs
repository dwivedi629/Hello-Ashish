﻿using System.Linq;
using System.Collections.Generic;
using AtHoc.Global.Resources.Entities;
using AtHoc.IWS.Business.Data;
using AtHoc.Infrastructure.Domain;
using AtHoc.IWS.Business.Domain.Devices.Spec;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.Global.Resources.Implementations;
using AtHoc.Global.Resources.Interfaces;
using AtHoc.IWS.Business.Context;
using AtHoc.Infrastructure.Ioc;

namespace AtHoc.IWS.Business.Domain.Devices.Impl
{
    public class DeviceFacade : FacadeBase<IAtHocContextFactory>, IDeviceFacade
    {
        private IGlobalEntityLocaleFacade _globalEntityLocaleFacade;
        public DeviceFacade(IAtHocContextFactory contextFactory)
            : base(contextFactory)
        {
            _globalEntityLocaleFacade = ServiceLocator.Resolve<IGlobalEntityLocaleFacade>();
        }

        public IEnumerable<Device> GetDevicesBySpec(DeviceSpec spec, string locale)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                var devices = context.DeviceRepository.FindBySpec(spec).ToList();
                if (_globalEntityLocaleFacade != null)
                {
                    return _globalEntityLocaleFacade.GetLocalizedEntity(devices, locale);
                }
                else
                {
                    return devices;
                }
            }
        }

        public Device GetDeviceBySpec(DeviceSpec spec, string locale)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                var device = context.DeviceRepository.FindBySpec(spec).SingleOrDefault();
                if (_globalEntityLocaleFacade != null)
                {
                    return _globalEntityLocaleFacade.GetLocalizedEntity(device, locale);
                }
                else
                {
                    return device;
                }

            }
        }
        public NotificationInfo GetNotificationInfo(int endUserId, string locale)
        {
            var notificationInfo = NotificationInfo.FindByUserId(endUserId);

            // Localize Desktop Popup Notification Name
            var desktopPopup = _globalEntityLocaleFacade.GetLocalizedValue(notificationInfo.DesktopDeviceId.ToString(),
                BusinessEntity.Device, "Name", locale);
            if (!string.IsNullOrWhiteSpace(desktopPopup))
                notificationInfo.DesktopName = desktopPopup;

            // Localize Mobile Notification Name
            var mobileNotification = _globalEntityLocaleFacade.GetLocalizedValue(notificationInfo.MobileNotificationId.ToString(), BusinessEntity.Device, "Name", locale);
            if (!string.IsNullOrWhiteSpace(mobileNotification))
                notificationInfo.MobileNotificationName = mobileNotification;

            return notificationInfo;
        }
    }
}
