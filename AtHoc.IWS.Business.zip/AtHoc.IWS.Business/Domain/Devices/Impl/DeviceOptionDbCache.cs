﻿using AtHoc.Data;
using AtHoc.Diagnostics;
using AtHoc.Infrastructure.Database;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Devices.Impl
{
    public class DeviceOptionDbCache : IDeviceOptionDbCache
    {
        public string Get(int vpsId, int deviceGroupId, string locale)
        {
            var result = string.Empty;
            try
            {
                using (var ngadDB = new NgadDatabase())
                {
                    var storedProcedure = "GLB_GET_DEVICE_HTML";
                    ngadDB.AddParameter("@VpsId", SqlDbType.Int, vpsId);
                    ngadDB.AddParameter("@GroupId", SqlDbType.Int, deviceGroupId);
                    ngadDB.AddParameter("@LocaleCode", SqlDbType.Text, locale);
                    ngadDB.CommandType = CommandType.StoredProcedure;
                    result = (string)ngadDB.ExecuteScalar(storedProcedure);
                    return result;
                }
            }
            catch(Exception ex)
            {
                EventLogger.WriteError(ex);
                return result;
            }
        }

        public void Set(int vpsId, int deviceGroupId, string locale, string deviceOptionHtml)
        {
            try
            {
                using (var ngadDB = new NgadDatabase())
                {
                    var storedProcedure = "GLB_SET_DEVICE_HTML";
                    ngadDB.AddParameter("@VpsId", SqlDbType.Int, vpsId);
                    ngadDB.AddParameter("@GroupId", SqlDbType.Int, deviceGroupId);
                    ngadDB.AddParameter("@LocaleCode", SqlDbType.Text, locale);
                    ngadDB.AddParameter("@Html", SqlDbType.Text, deviceOptionHtml);
                    ngadDB.CommandType = CommandType.StoredProcedure;
                    ngadDB.ExecuteNonQuery(storedProcedure);
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(ex);
            }
        }

        public void Clear(int vpsId)
        {
            try
            {
                using (var ngadDB = new NgadDatabase())
                {
                    var storedProcedure = "GLB_CLEAR_DEVICE_HTML";
                    ngadDB.AddParameter("@VpsId", SqlDbType.Int, vpsId);
                    ngadDB.CommandType = CommandType.StoredProcedure;
                    ngadDB.ExecuteNonQuery(storedProcedure);
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(ex);
            }
        }
    }
}
