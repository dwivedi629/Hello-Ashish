﻿using System.Linq;

using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Database;
using AtHoc.Infrastructure.Sql;
using AtHoc.IWS.Business.Domain.Devices.Spec;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.Devices.Impl
{
    public class DeviceGroupRepository : DbRepository<DeviceGroup, DeviceGroupSpec>, IDeviceGroupRepository
    {
        public DeviceGroupRepository(IUnitOfWork context) : base(context) {}

        protected override void TranslateSpec(DeviceGroupSpec spec, SqlBuilder builder, bool query)
        {
            builder.SelectAll("g.*");
            builder.From("dbo.dlv_device_group_tab g with (nolock)");

            if (spec.IsTargetable)
            {
                builder.Where("g.is_targetable = 'Y'");
            }

            if (spec.GroupIds.Any())
            {
                //BAD
				//var groupIdsSql = String.Format(("g.group_id in ({0})"), spec.GroupIds.Join());
                //builder.Where(groupIdsSql);

                //GOOD
                builder.Where("g.group_id in @GroupIds", new SqlParameter("GroupIds",  spec.GroupIds));
            }
        }
    }
}
