﻿using System.Collections.Generic;

using AtHoc.Infrastructure.Domain;
using AtHoc.IWS.Business.Data;
using AtHoc.IWS.Business.Domain.Devices.Spec;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.Devices.Impl
{
	public class PagerCarrierFacade : FacadeBase<IAtHocContextFactory>, IPagerCarrierFacade
	{
		public PagerCarrierFacade(IAtHocContextFactory contextFactory) : base(contextFactory) {}

		public IEnumerable<PagerCarrier> GetPagerCarrierBySpec(PagerCarrierSpec spec)
		{
			using (var context = ContextFactory.CreateNgaddataContext())
			{
				return context.PagerCarrierRepository.FindBySpec(spec);
			}
		}

		public IEnumerable<PagerCarrierEntity> GetPagerCarrierEntityBySpec(PagerCarrierEntitySpec spec)
		{
			using (var context = ContextFactory.CreateNgaddataContext())
			{
				return context.PagerCarrierEntityRepository.FindBySpec(spec);
			}
		}

		public IEnumerable<PagerCarrierEntity> GetAllPagerCarrierEntities()
		{
			return GetPagerCarrierEntityBySpec(new PagerCarrierEntitySpec());
		}
	}
}