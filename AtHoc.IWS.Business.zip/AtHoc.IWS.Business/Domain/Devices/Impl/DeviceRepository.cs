﻿using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Database;
using AtHoc.Infrastructure.Sql;
using AtHoc.IWS.Business.Domain.Devices.Spec;
using AtHoc.IWS.Business.Domain.Entities;
using System;

namespace AtHoc.IWS.Business.Domain.Devices.Impl
{
    public class DeviceDbRepository : DbRepository<Device, DeviceSpec>, IDeviceRepository
    {
        public DeviceDbRepository(IUnitOfWork context) : base(context) { }

        protected override void TranslateSpec(DeviceSpec spec, SqlBuilder builder, bool query)
        {
            builder.SelectAll<Device>("a");
            builder.From(builder.Table<Device>("a"));

            if (spec.ProviderId.HasValue)
            {
                if (spec.IncludeDeviceProvider)
                {
                    builder.SelectAll<DeviceProvider>("b", "1");
                }

                builder.InnerJoin("DLV_PRV_DEVICE_TAB b WITH (NOLOCK) on b.DEVICE_ID = a.DEVICE_ID");
                builder.Where("b.PROVIDER_ID = @ProviderId", new SqlParameter("ProviderId", spec.ProviderId.Value));
                if (spec.EnabledOnly)
                {
                    builder.Where("b.IS_ENABLED = @Enabled", new SqlParameter("Enabled", "Y"));
                }
            }
            else if (spec.IncludeDeviceProvider)
            {
                throw new InvalidOperationException("Cannot get device provider without provider id.");
            }


			if (spec.IncludeDeviceGroup || spec.IsMassDevice.HasValue)
            {
                builder.SelectAll<DeviceGroup>("c", "2");
                builder.InnerJoin("DLV_DEVICE_GROUP_TAB c WITH (NOLOCK) on a.GROUP_ID = c.GROUP_ID");

				if (spec.IsMassDevice.HasValue)
				{
					var operation = spec.IsMassDevice.Value ? "=" : "!=";
					builder.Where("c.RECIPIENT_TYPE {0} 'Mass'".FormatWith(operation));
				}
			}

            if (spec.DeviceId.HasValue)
            {
                builder.Where(builder.Condition(Device.Meta.Id, ConditionOperator.Equals, spec.DeviceId.Value, "a"));
            }

	        if (spec.CommonName.HasValue())
	        {
				builder.Where(builder.Condition(Device.Meta.CommonName, ConditionOperator.Equals, spec.CommonName, "a"));
	        }

			if (spec.Name.HasValue())
			{
				builder.Where(builder.Condition(Device.Meta.Name, ConditionOperator.Equals, spec.Name, "a"));
			}

			if (spec.CommonNames.HasValue())
				builder.Where(builder.Condition(Device.Meta.CommonName, ConditionOperator.In, spec.CommonNames, "a"));

	        if (spec.DeviceIds.HasValue())
	        {
				builder.Where(builder.Condition(Device.Meta.Id, ConditionOperator.In, spec.DeviceIds, "a"));
	        }
        }

        protected override bool OnItemDataBound(DeviceSpec spec, Device obj, DbResultItem resultItem, SqlMapperContext mapContext)
        {
            if (spec.IncludeDeviceProvider)
            {
                obj.DeviceProvider = this.Context.Map.Translate<DeviceProvider>(resultItem, mapContext);
            }
            if (spec.IncludeDeviceGroup)
            {
                obj.DeviceGroup = this.Context.Map.Translate<DeviceGroup>(resultItem, mapContext);
            }
            return base.OnItemDataBound(spec, obj, resultItem, mapContext);
        }
    }
}
