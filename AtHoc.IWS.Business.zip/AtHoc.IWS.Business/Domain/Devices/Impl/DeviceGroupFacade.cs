﻿using System.Linq;
using System.Collections.Generic;

using AtHoc.Infrastructure.Domain;
using AtHoc.IWS.Business.Data;
using AtHoc.IWS.Business.Domain.Devices.Spec;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.Devices.Impl
{
    public class DeviceGroupFacade : FacadeBase<IAtHocContextFactory>, IDeviceGroupFacade
    {
        public DeviceGroupFacade(IAtHocContextFactory contextFactory) : base(contextFactory) { }

        public IEnumerable<DeviceGroup> GetDeviceGroupsBySpec(DeviceGroupSpec spec)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.DeviceGroupRepository.FindBySpec(spec).ToArray();
            }
        }
    }
}
