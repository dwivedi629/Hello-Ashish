﻿using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Database;
using AtHoc.Infrastructure.Sql;

using AtHoc.IWS.Business.Domain.Devices.Spec;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.Devices.Impl
{
	public class PagerCarrierRepository : DbRepository<PagerCarrier, PagerCarrierSpec>, IPagerCarrierRepository
	{
		public PagerCarrierRepository(IUnitOfWork context) : base(context) {}

		protected override void TranslateSpec(PagerCarrierSpec spec, SqlBuilder builder, bool query)
		{
			builder.SelectAll<PagerCarrier>("a");
			builder.From(builder.Table<PagerCarrier>("a"));

			if (spec.CarrierId.HasValue)
				builder.Where("a.CarrierId = @CarrierId", new SqlParameter("CarrierId", spec.CarrierId.Value));

			if (spec.CarrierName.IsNotNullOrEmpty())
				builder.Where("a.CarrierName = @CarrierName", new SqlParameter("CarrierName", spec.CarrierName));
		}
	}

	public class PagerCarrierEntityDbRepository : DbRepository<PagerCarrierEntity, PagerCarrierEntitySpec>, IPagerCarrierEntityRepository
	{
		public PagerCarrierEntityDbRepository(IUnitOfWork context) : base(context) { }

		protected override void TranslateSpec(PagerCarrierEntitySpec spec, SqlBuilder builder, bool query)
		{
			builder.SelectAll<PagerCarrierEntity>("a");
			builder.From(builder.Table<PagerCarrierEntity>("a"));

			if (spec.CarrierId.HasValue)
				builder.Where("a.CarrierId = @CarrierId", new SqlParameter("CarrierId", spec.CarrierId.Value));

			if (spec.CarrierName.IsNotNullOrEmpty())
				builder.Where("a.CarrierName = @CarrierName", new SqlParameter("CarrierName", spec.CarrierName));
		}
	}
}