﻿using System.Collections.Generic;
using System.Linq;

using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Data;

using AtHoc.IWS.Business.Data;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.Devices.Spec;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.Global.Resources.Interfaces;
using AtHoc.Global.Resources;
using System;

namespace AtHoc.IWS.Business.Domain.Users.Search
{
#warning Refactor....
    public class NotificationInfo
    {

        const string ACTIVE_LABEL = "Active";
        const string IN_ACTIVE_LABEL = "Inactive";
        const string NOT_AVAILABLE_LABEL = "Not Available";

        public DeviceAddress Desktop { get; set; }

        public string DesktopName { get; set; }

        public int DesktopDeviceId { get; set; }

        public IEnumerable<DeviceAddress> Mobile { get; set; }

        public string MobileNotificationName { get; set; }

        public int MobileNotificationId { get; set; }

        public string MobileNotificationAddress { get; set; }

        public string DesktopAddress { get; set; }

        public static NotificationInfo FindByUserId(int userId)
        {
            using (var context = AtHocDbContextFactory.CreateFactory().CreateNgaddataContext())
            {
                var mobileNotificationDevice =
                    context.DeviceRepository.FindBySpec(new DeviceSpec { CommonName = "mobileNotification" }).SingleOrDefault();

                var popupDevice =
                    context.DeviceRepository.FindBySpec(new DeviceSpec { CommonName = "DesktopPopup" }).SingleOrDefault();

                var deviceAddresses = context.DeviceAddressRepository.FindBySpec(new DeviceValueSpec(userId));
                var result = new NotificationInfo();
                if (popupDevice != null)
                {
                    //Localizied Desktop based on locale
                    result.DesktopDeviceId = popupDevice.Id;
                    result.Desktop = deviceAddresses.SingleOrDefault(d => d.DeviceId == popupDevice.Id);
                    result.DesktopName = popupDevice.Name;
                    result.DesktopAddress = GetDeviceAddress(context, userId, popupDevice.Id);
                }
                if (mobileNotificationDevice != null)
                {
                    result.MobileNotificationId = mobileNotificationDevice.Id;
                    result.Mobile = deviceAddresses.Where(a => a.DeviceId == mobileNotificationDevice.Id);
                    result.MobileNotificationName = mobileNotificationDevice.Name;
                    result.MobileNotificationAddress = GetDeviceAddress(context, userId, mobileNotificationDevice.Id);
                }
                return result;
            }
        }

        private static string GetDeviceAddress(INgaddataContext context, int userId, int deviceId)
        {
            const string sql = @"select address from USR_DEVICES_VUE where user_id = @userId and device_id = @deviceId";
            var query = new DbQuery(context, sql);
            query.AddParameter("userId", userId);
            query.AddParameter("deviceId", deviceId);
            return ResolveValue(query.ExecuteScalar<string>());
        }
        
        /// <summary>
        /// Resolving values based on localized resource file.
        /// </summary>
        /// <param name="value">Value</param>
        /// <returns>Returns localized value.</returns>
        public static string ResolveValue(string value)
        {
            var resolvedValue = value.HasValue() ? value : IWSResources.Device_Not_Available;
            switch (resolvedValue)
            {
                case ACTIVE_LABEL:
                    resolvedValue = IWSResources.Device_Active;
                    break;
                case IN_ACTIVE_LABEL:
                    resolvedValue = IWSResources.Device_Inactive;
                    break;
                case NOT_AVAILABLE_LABEL:
                    resolvedValue = IWSResources.Device_Not_Available;
                    break;
            }
            return resolvedValue;
        }
    }
}