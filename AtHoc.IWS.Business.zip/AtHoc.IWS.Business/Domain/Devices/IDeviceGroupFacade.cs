﻿using System.Collections.Generic;

using AtHoc.IWS.Business.Domain.Devices.Spec;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.Devices
{
    public interface IDeviceGroupFacade
    {
        IEnumerable<DeviceGroup> GetDeviceGroupsBySpec(DeviceGroupSpec spec);
    }
}
