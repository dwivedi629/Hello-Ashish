﻿using AtHoc.Infrastructure.Entity;

namespace AtHoc.IWS.Business.Domain.Devices.Spec
{
	public class PagerCarrierSpec : EntitySpec
	{
		public int? CarrierId { get; set; }

		public string CarrierName { get; set; }
	}

	public class PagerCarrierEntitySpec : EntitySpec
	{
		public int? CarrierId { get; set; }

		public string CarrierName { get; set; }
	}
}