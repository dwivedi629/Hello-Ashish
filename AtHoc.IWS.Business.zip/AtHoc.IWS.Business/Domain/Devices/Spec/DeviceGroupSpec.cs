﻿using System.Collections.Generic;

using AtHoc.Infrastructure.Entity;

namespace AtHoc.IWS.Business.Domain.Devices.Spec
{
    public class DeviceGroupSpec : EntitySpec
    {
        public DeviceGroupSpec()
        {
            GroupIds = new int[] {};
        }

        public IEnumerable<int> GroupIds { get; set; }

        public bool IsTargetable { get; set; }

        public bool SupportsImplicitTargeting { get; set; }
    }
}
