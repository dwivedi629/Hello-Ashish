﻿using System.Collections.Generic;

using AtHoc.Infrastructure.Entity;

namespace AtHoc.IWS.Business.Domain.Devices.Spec
{
	public class DeviceSpec : EntitySpec
	{
		public DeviceSpec()
		{
			GetDeletedDevices = false;
		}

		public int? ProviderId { get; set; }

		public bool IncludeDeviceProvider { get; set; }

		public bool IncludeDeviceGroup { get; set; }

		public int? DeviceId { get; set; }

		public IEnumerable<int> DeviceIds { get; set; }

		public bool EnabledOnly { get; set; }

		public bool? IsMassDevice { get; set; }

		public bool TargetableDeviceOnly { get; set; }

		public bool GetDeletedDevices { get; set; }

		public string CommonName { get; set; }

		public string Name { get; set; }

		public IEnumerable<string> CommonNames { get; set; } 
	}
}
