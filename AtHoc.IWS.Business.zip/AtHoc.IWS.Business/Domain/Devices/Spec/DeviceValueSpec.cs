﻿using AtHoc.Infrastructure.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.Devices.Spec
{
    public class DeviceValueSpec : EntitySpec
    {
        public DeviceValueSpec(int userId) 
        {
            if (userId == 0) {
                throw new ArgumentNullException("User Id cannot be null");
            }
            this.UserId = userId;
        }
        public int UserId { get; set; }
        public IEnumerable<int> DeviceIds { get; set; }

        public bool? IncludeDevice { get; set; }

        public bool? IncludeDeviceGroup { get; set; }
    }
}
