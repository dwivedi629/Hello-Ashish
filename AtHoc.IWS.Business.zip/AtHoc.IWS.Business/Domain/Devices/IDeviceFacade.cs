﻿using System.Collections.Generic;

using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Devices.Spec;
using AtHoc.IWS.Business.Domain.Users.Search;

namespace AtHoc.IWS.Business.Domain.Devices
{
	public interface IDeviceFacade
	{			
        Device GetDeviceBySpec(DeviceSpec spec, string locale);
        IEnumerable<Device> GetDevicesBySpec(DeviceSpec spec, string locale);
        NotificationInfo GetNotificationInfo(int endUserId, string locale);
	}
}
