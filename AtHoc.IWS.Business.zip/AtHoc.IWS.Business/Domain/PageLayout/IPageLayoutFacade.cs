﻿using System.Collections.Generic;
using System.Linq;
using System.Xml;

using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.PageLayout.Spec;
using AtHoc.Infrastructure.Resources;

namespace AtHoc.IWS.Business.Domain.PageLayout
{
    public interface IPageLayoutFacade
    {
        IEnumerable<Entities.PageLayout> GetPageLayoutBySpec(PageLayoutSpec spec);

        IEnumerable<T> GetAttributeIds<T>(string pageLayout);

        IEnumerable<string> GetAttributeCommonNames(XmlDocument pageLayout, bool ignoreBlank = false);
        
        IEnumerable<string> GetDeviceCommonNames(XmlDocument pageLayout);
        
        XmlDocument PageLayoutXml { get; }

        Messages SavePageLayout(int providerId, string entityId, string pageId, string name, string xml, string pageType);

        IEnumerable<string> GetSectionNames(string pageLayout, string attributeName = "");

        string UpdatePageLayoutByAttributeName(string attributeName, string sectionName, string pageLayout);

        string DeleteAttributeFromLayout(string attributeName, string sectionName, string pageLayout);
        //IEnumerable<PageLayoutRow> LoadPageLayoutRows(User endUser, ILookup<string, CustomAttribute> customAttributeByAttributeCommonName, ILookup<string, Device> devicesByCommonName, Provider provider, bool loadEmptyAttribute);


        Disclaimer GetDisclaimerValues(string pageLayout); 

    }
}
