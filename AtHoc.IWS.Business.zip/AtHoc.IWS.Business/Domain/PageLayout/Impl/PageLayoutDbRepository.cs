﻿using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Database;

using AtHoc.IWS.Business.Domain.PageLayout.Spec;

namespace AtHoc.IWS.Business.Domain.PageLayout.Impl
{
    public class PageLayoutDbRepository : DbRepository<Entities.PageLayout, PageLayoutSpec>, IPageLayoutRepository
    {
        public PageLayoutDbRepository(IUnitOfWork context): base(context) {}

        protected override void TranslateSpec(PageLayoutSpec spec, Infrastructure.Sql.SqlBuilder builder, bool query)
        {
            builder.SelectAll<Entities.PageLayout>("a");
            builder.From(builder.Table<Entities.PageLayout>("a"));

            if (spec.ProviderId.HasValue)
                builder.Where(builder.Condition(Entities.PageLayout.Meta.ProviderId, ConditionOperator.Equals, spec.ProviderId.Value, "a"));

            if (spec.PageId.IsNotNullOrEmpty())
                builder.Where(builder.Condition(Entities.PageLayout.Meta.PageId, ConditionOperator.Equals, spec.PageId, "a"));

        }
    }
}
