﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using AtHoc.Infrastructure.Domain;
using AtHoc.Infrastructure.Extensions;
using AtHoc.IWS.Business.Data;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Resources;
using System.Diagnostics;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.PageLayout.Impl
{
    public class PageLayoutFacade : FacadeBase<IAtHocContextFactory>, IPageLayoutFacade
    {
        public PageLayoutFacade(IAtHocContextFactory contextFactory) : base(contextFactory) { }

        public IEnumerable<Entities.PageLayout> GetPageLayoutBySpec(Spec.PageLayoutSpec spec)
        {
            using (var context = ContextFactory.CreateNgaddataContext())
            {
                return context.PageLayoutRepository.FindBySpec(spec);
            }
        }





        public XmlDocument PageLayoutXml { get; private set; }


        public Disclaimer GetDisclaimerValues(string pageLayout)
        {
            var disclaimerValues = new Disclaimer();
            var xml = new XmlDocument();
            xml.LoadXml(pageLayout);
            var xNode = xml.SelectSingleNode("/page/title");
            disclaimerValues.Title = (xNode.HasValue() && xNode != null) ? xNode.InnerXml.Trim() : string.Empty;
            xNode = xml.SelectSingleNode("/page/description");
            disclaimerValues.Description = (xNode.HasValue() && xNode != null) ? xNode.InnerXml.Trim() : string.Empty;
            return disclaimerValues;
        }


        public IEnumerable<string> GetSectionNames(string pageLayout, string attributeName = "")
        {
            //if (PageLayoutXml == null)
            //{
            var xml = new XmlDocument();
            xml.LoadXml(pageLayout);
            PageLayoutXml = xml;
            //}

            var allSecionNames = new List<string>();
            //var xnList = PageLayoutXml.SelectNodes("/page/row/column/bucket/");

            var xnList1 = PageLayoutXml.SelectNodes("/page/row");
            foreach (XmlNode xn in xnList1)
            {
                //Columns Tag
                foreach (XmlNode columnNode in xn.ChildNodes)
                {
                    //Buckets
                    foreach (XmlNode bucket in columnNode.ChildNodes)
                    {
                        //Sections
                        var allEnabledSections = bucket.SelectNodes("section[@enabled='true']");
                        foreach (XmlNode section in allEnabledSections)
                        {
                            var childSections = section.SelectNodes("section");
                            if (childSections.Count == 0 && section["title"] != null && section["title"].InnerText.IsNotNullOrEmpty())
                            {
                                allSecionNames.Add(section["title"].InnerText.Trim());
                            }

                            if (childSections.Count > 0)
                            {
                                foreach (XmlNode childSection in childSections)
                                {
                                    if (childSection["title"] != null && childSection.InnerText.IsNotNullOrEmpty())
                                    {
                                        allSecionNames.Add(childSection["title"].InnerText.Trim());
                                    }
                                }
                            }

                        }
                    }
                }
            }
            return allSecionNames;
        }

        public IEnumerable<string> GetAttributeCommonNames(XmlDocument xml, bool ignoreBlank = false)
        {
            PageLayoutXml = xml;
            var allAttributeCommonNames = new List<string>();
            var allSections = PageLayoutXml.SelectNodes("/page/row/column/bucket/section[@type='Attributes']");
            foreach (XmlNode section in allSections)
            {
                var xmlNodeList = section.SelectSingleNode("fields");
                if (xmlNodeList != null)
                {
                    allAttributeCommonNames.AddRange(getAttributeFromSection(section, ignoreBlank));
                }
                else
                {
                    allAttributeCommonNames.Add(string.Format("Error: {0}", section.ChildNodes[0].InnerText));
                }
               
                var childSections = section.SelectNodes("section");

                if (childSections != null && childSections.Count > 0)
                {
                    foreach (XmlNode childSection in childSections)
                    {
                        var xnList = childSection.SelectSingleNode("fields");
                        if (xnList != null)
                        {
                            allAttributeCommonNames.AddRange(getAttributeFromSection(childSection, ignoreBlank));
                        }
                        else
                        {
                            allAttributeCommonNames.Add(string.Format("Error: {0}", childSection.ChildNodes[0].InnerText));
                        }
                       
                    }
                }
            }
            return allAttributeCommonNames;
        }

        private List<string> getAttributeFromSection(XmlNode section, bool ignoreBlank)
        {
            var allAttributeCommonNames = new List<string>();
            var xnList = section.SelectSingleNode("fields");
                foreach (XmlNode xn in xnList)
                {
                    if (xn.InnerText.IsNotNullOrEmpty() || ignoreBlank)
                    {
                        allAttributeCommonNames.Add(xn.InnerText.Trim());
                    }
                }           
            return allAttributeCommonNames;
        }

        public string UpdatePageLayoutByAttributeName(string attributeName, string sectionName, string pageLayout)
        {
            if (attributeName.IsNullOrEmpty() || sectionName.IsNullOrEmpty())
            {
                throw new ArgumentNullException("attributeName", "Attribute CommonName can not be null");
            }
            // if (PageLayoutXml == null)
            //{
            var xml = new XmlDocument();
            xml.LoadXml(pageLayout);
            PageLayoutXml = xml;
            //}
            var updateRequired = true;
            var allAttributeCommonNames = new List<string>();
            XmlNode nextNode = null;

            //remove renamed attributes


            var xnList =
                PageLayoutXml.SelectSingleNode("/page/row/column/bucket/section[@type='Attributes']/fields[field/text() =\"" + attributeName + "\"]");
            if (xnList == null)
            {
                xnList =
                    PageLayoutXml.SelectSingleNode("/page/row/column/bucket/section[@type='Attributes']/section/fields[field/text() =\"" + attributeName + "\"]");
            }
            if (xnList != null)
            {
                Trace.WriteLine(xnList.ParentNode.Name);
                if (xnList.ParentNode["title"] != null)
                {
                    var existingNode = xnList.SelectSingleNode("field[text() =\"" + attributeName + "\"]");
                    if (
                        String.Compare(xnList.ParentNode["title"].InnerText, sectionName,
                            StringComparison.OrdinalIgnoreCase) == 0)
                    {
                        nextNode = existingNode.NextSibling;
                    }
                    Trace.WriteLine(existingNode.InnerText);
                    xnList.RemoveChild(existingNode);
                }
                else
                {
                    updateRequired = false;
                }
            }
            if (updateRequired)
            {
                var sectionNode = PageLayoutXml.SelectSingleNode("/page/row/column/bucket/section[@type='Attributes' and title/text() ='" + sectionName + "']");
                //if it is null check child sections
                if (sectionNode == null)
                {
                    sectionNode = PageLayoutXml.SelectSingleNode("/page/row/column/bucket/section[@type='Attributes']/section[title/text() ='" + sectionName + "']");
                }
                if (sectionNode != null)
                {
                    XmlElement createdElement = PageLayoutXml.CreateElement("field");
                    createdElement.InnerText = attributeName;
                    if (nextNode == null)
                        sectionNode["fields"].AppendChild(createdElement);
                    else
                    {

                        sectionNode["fields"].InsertBefore(createdElement, nextNode);
                    }
                }
            }
            return PageLayoutXml.InnerXml;
        }

        public string DeleteAttributeFromLayout(string attributeName, string sectionName, string pageLayout)
        {
            //if (PageLayoutXml == null)
            //{
            var xml = new XmlDocument();
            xml.LoadXml(pageLayout);
            PageLayoutXml = xml;
            //}
            var allAttributeCommonNames = new List<string>();
            var xnList = PageLayoutXml.SelectSingleNode("/page/row/column/bucket/section[@type='Attributes']/fields[field/text() =\"" + attributeName + "\"]");
            if (xnList == null)
            {
                xnList = PageLayoutXml.SelectSingleNode("/page/row/column/bucket/section[@type='Attributes']/section/fields[field/text() =\"" + attributeName + "\"]");
            }
            if (xnList != null)
            {
                Trace.WriteLine(xnList.ParentNode.Name);
                if (xnList.ParentNode["title"] != null)
                {
                    var existingNode = xnList.SelectSingleNode("field[text() =\"" + attributeName + "\"]");
                    Trace.WriteLine(existingNode.InnerText);
                    xnList.RemoveChild(existingNode);
                }
            }
            return PageLayoutXml.InnerXml;
        }


        public IEnumerable<string> GetDeviceCommonNames(XmlDocument xml)
        {
            
            PageLayoutXml = xml;
            var allDeviceCommonNames = new List<string>();
            var xnList = PageLayoutXml.SelectNodes("/page/row/column/bucket/section[@type='Devices']/fields/field");
            foreach (XmlNode xn in xnList)
            {
                if (xn.InnerText.IsNotNullOrEmpty())
                {
                    allDeviceCommonNames.Add(xn.InnerText.Trim());
                }
            }
            return allDeviceCommonNames;
        }

        public IEnumerable<T> GetAttributeIds<T>(string pageLayout)
        {
            var allAttributeIds = new List<T>();
            // if (PageLayoutXml == null)
            // {
            var xml = new XmlDocument();
            xml.LoadXml(pageLayout);
            PageLayoutXml = xml;
            //}

            var xnList = PageLayoutXml.SelectNodes("/page/row/column/bucket/section/fields/field");
            foreach (XmlNode xn in xnList)
            {
                if (xn.Attributes["id"].Value.IsNumeric())
                {
                    allAttributeIds.Add(xn.Attributes["id"].Value.ConvertTo<T>());
                }
            }
            return allAttributeIds;
        }


        public Messages SavePageLayout(int providerId, string entityId, string pageId, string name, string xml, string pageType)
        {
            var messages = new Messages();

            try
            {
                using (var context = ContextFactory.CreateNgaddataContext())
                {
                    var existingLayout = context.PageLayoutRepository.FindBySpec(new Spec.PageLayoutSpec { ProviderId = providerId, PageId = pageId }).First();
                    if (existingLayout == null)
                    {
                        existingLayout = new Entities.PageLayout { ProviderId = providerId, Name = name, PageId = pageId, EntityId = entityId, PageType = pageType };
                    }
                    existingLayout.LayoutXml = xml;
                    context.PageLayoutRepository.Save(existingLayout, false, Entities.PageLayout.Meta.PageId, Entities.PageLayout.Meta.ProviderId);
                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                messages.Add(ex.Message, MessageType.Error, "EndUserAttributeSave");
            }
            return messages;
        }


    }
}
