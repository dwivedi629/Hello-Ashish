﻿using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Domain.PageLayout.Spec
{
    public class PageLayoutSpec : EntitySpec
    {
        public IEnumerable<MetaProperty> SelectedProperties { get; set; }
        public int? ProviderId { get; set; }
        public string PageId { get; set; }
        public string EntityId { get; set; }
    }

    enum PageLayoutenum
    {
        NEWEUM,
        OPERATORDETAILS,
        SIGNUP,
        DEVICES,
        MYINFO
    }
}
