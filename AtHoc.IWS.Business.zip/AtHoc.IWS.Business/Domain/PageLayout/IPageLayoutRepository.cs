﻿using AtHoc.Infrastructure.Data;
using AtHoc.IWS.Business.Domain.PageLayout.Spec;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.PageLayout
{
    public interface IPageLayoutRepository : IRepository<Entities.PageLayout, PageLayoutSpec>
    {
    }
}
