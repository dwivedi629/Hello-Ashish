﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.d911.Model.Event;
using AtHoc.d911.Model.Organization;
using AtHoc.IWS.Business.Data.SearchSpec;

namespace AtHoc.IWS.Business.Domain.Organization
{
    public class OrganizationSpec:BaseSearchSpec
    {
        public OrganizationSpec()
        {
            
        }

        public string SearchText { get; set; }
       // public OrganizationType? TypeId { get; set; }
        public int? TypeId { get; set; }

        public FilterType? Filter { get; set; }

        public IList<string> OrganizationGuidList { get; set; }
    
    }

    public enum FilterType
    {
        All,
        RequestPending,
        Connected
    }
}
