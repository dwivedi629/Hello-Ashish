﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.d911.Common.Model;
using AtHoc.d911.Model;
using AtHoc.d911.Model.Organization;
using AtHoc.IWS.Business.Domain.Devices;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Targeting;
using AtHoc.IWS.Business.Domain.Targeting.Impl;

namespace AtHoc.IWS.Business.Domain.Organization
{
    public interface IOrganizationFacade
    {
        ConnectivityStatus GetConnectivityStatus(int providerId);
        OrganizationInfo GetSelfOrganization(int providerId);
        string GetSelfOrganizationGuid(int providerId);
        IDictionary<string, OrganizationInfo> GetOrganizations(int providerId, OrganizationSpec spec);
        OrganizationInfo GetOrganizationById(int providerId, string guid);
        OrganizationLogo GetOrganizationLogo(int providerId, string orgId);
        OrganizationConnection GetConnections(int providerId, bool includeAgreement = true, bool includeInvitation = true, bool includeExternalInvitation = false);
        
        [Obsolete("to be remove")]
        IEnumerable<OrganizationAgreementInfo> GetOrganizationAgreements(int providerId);

        IEnumerable<OrganizationSectorInfo> GetOrganizationSectors(int providerId);

        /// <summary>
        /// Set Organization Visibility
        /// </summary>
        /// <param name="providerId">Provider ID</param>
        /// <param name="isVisibleToAll">Is Organization is visible to all?</param>
        /// <param name="organizationTypeIds">List of OrganizationTypeId.</param>
        /// <returns>Boolean success</returns>
        bool SetOrganizationVisibility(int providerId, bool isVisibleToAll, List<int> organizationTypeIds);
        OrganizationVisibility GetOrganizationVisibility(int providerId);        
        int Invite(int providerId, string otherOrganizationGuid, AgreementDirection direction, string message);
        bool CancelAgreement(int providerId, int id);
        Response<bool> UpdateInvitation(int providerId, int id, InvitationAction status);
        bool MarkMessageAsRead(int providerId, List<int> ids);
        bool SetMessageStatus(int providerId, String messageContext, MessageDeliveryStatus status, string responseOptionId = null, String description = null, GeoLocation location = null);        
        Response<bool> InviteNewOrganization(int providerId, InviteNewOrganizationParams inviteNewOrganizationParams);        
        IEnumerable<TargetableOrganization> GetActiveOrganization(int providerId, int operatorId, IUserFacade userFacade, IDeviceFacade deviceFacade);
        /// <summary>
        /// Gets the list of active orgs for the specified VPS
        /// 0 gets all the orgs in the system
        /// </summary>
        /// <param name="providerId"></param>
        /// <returns></returns>
        IEnumerable<TargetableOrganization> GetActiveOrganization(int providerId = 0);

        IEnumerable<MassDeviceTargetingResult> GetActiveOrganizationInformation(int providerId = 0);

        void ExecuteJob();

    }

    public enum ConnectivityStatus
    {
        Connected,
        DeviceNotConfigured, //IAC device is not enabled for this vps.
        NotConfigured, //not connected to PSS
        NotListed, // Connected to PSS but not listed on the Hub
    }
}
