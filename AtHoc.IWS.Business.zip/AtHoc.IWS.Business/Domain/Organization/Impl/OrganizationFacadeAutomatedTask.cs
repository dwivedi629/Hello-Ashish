﻿using System.Web.UI;
using AtHoc.d911.Model.Organization;
using AtHoc.Diagnostics;
using AtHoc.Infrastructure.Ioc;
using AtHoc.Infrastructure.Log.EventLog;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.IWS.Business.Domain.Devices;
using AtHoc.IWS.Business.Domain.Devices.Impl;
using AtHoc.IWS.Business.Domain.Devices.Spec;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Settings.Impl;
using AtHoc.IWS.Business.Domain.Targeting;
using AtHoc.IWS.Business.Domain.Targeting.Impl;
using AtHoc.IWS.Business.Domain.Targeting.Spec;
using AtHoc.IWS.Business.Domain.Users;
using AtHoc.IWS.Business.Domain.Users.Impl;
using AtHoc.IWS.Business.Domain.Users.Spec;
using Microsoft.SqlServer.Types;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;

namespace AtHoc.IWS.Business.Domain.Organization.Impl
{
    public partial class OrganizationFacade
    {
        /// <summary>
        /// This method is getting call from  polling agent.
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="selfOrgId"></param>
        /// <param name="agreementInfos"></param>
        /// <returns></returns>
        public bool OnOrganizationAgreementChange(int providerId, string selfOrgId, IEnumerable<OrganizationAgreementInfoModel> agreementInfos)
        {
            EventLogger.WriteInformation("OnOrganizationAgreementChange starts now...");
            try
            {
                var organizationsById = GetOrganizations(providerId, new OrganizationSpec());
                var systemOrganizationAgreements = new List<SystemOrganizationAgreement>();
                systemOrganizationAgreements.Add(new SystemOrganizationAgreement { OrganizationAgreements = agreementInfos.ToList(), OrganizationGuid = selfOrgId, VpsId = providerId });
                UpdateUsersWithAgreements(systemOrganizationAgreements, organizationsById);
            }
            catch (Exception e)
            {
                EventLogger.WriteError(string.Format("Failed tp run OnOrganizationAgreementChange"), e);

            }
            EventLogger.WriteVerbose(string.Format("OnOrganizationAgreementChange end"));
            return true;
        }
        
        /// <summary>
        /// This method is getting call from Regular Scheduler job.
        /// </summary>
        public void OnSyncSystemUserBase()
        {
            EventLogger.WriteVerbose("OnSyncSystemUserBase starts now...");
            try
            {
                if (!GetCachedPssParams().IsPollServiceEnabled)
                {
                    // if polling agent is not enabled, no need to synch.
                    return;
                }
                SystemOrganizationConnection ret = GetSystemConnectionAgreements();
                if (ret == null)
                {
                    EventLogger.WriteError("failed to run OnSyncSystemUserBase: failed to get agreements from PSS");
                    return;
                }
                Dictionary<string, OrganizationInfo> organizationsById = ret.Organizations.ToDictionary(organizationInfo => organizationInfo.Guid);
                UpdateUsersWithAgreements(ret.SystemOrganizationAgreements, organizationsById);
            }
            catch (Exception e)
            {
                EventLogger.WriteError(string.Format("Failed tp run OnSyncSystemUserBase"),e);
                
            }
            EventLogger.WriteVerbose(string.Format("OnSyncSystemUserBase end"));
        }
        private bool UpdateUsersWithAgreements(List<SystemOrganizationAgreement> organizationAgreements, IDictionary<string, OrganizationInfo> organizationById)
        {
            try
            {
                var logString = new StringBuilder();
                logString.Append("User Sync Job: \n ");
                IUserFacade userFacade = new UserFacade();
                var context = AtHocDbContextFactory.CreateFactory();
                var customAttributeFacade = new CustomAttributeFacade(context);
                IOperatorFacade operatorFacade = new UserFacade();

                var massDeviceTargetingRepository = ServiceLocator.Resolve<IMassDeviceTargetingFacade>();
                var iacUsersAcrossSystem = massDeviceTargetingRepository.GetMassDeviceEndpoints(new MassDeviceTargetingSpec
                {
                    // Pass provider id = 0 to get users across the system
                    ProviderId = organizationAgreements.Count == 1?organizationAgreements[0].VpsId:0,
                    DeviceCommonName = IacCommonName
                });

                var logIacUserCount = iacUsersAcrossSystem.Count;
                logString.Append(string.Format("Total # of Iac User : {0} \n ", logIacUserCount));
                //Build the dictionary by ProviderId as key
                Dictionary<int, List<MassDeviceTargetingResult>> iacUsersByProviderId =
                    iacUsersAcrossSystem.GroupBy(p => p.ProviderId).ToDictionary(k => k.Key, grp => grp.ToList());

                foreach (var providerOrganizationAgreement in organizationAgreements)
                {
                    UpdateProviderUsersWithAgreements(organizationById, logString, userFacade, context, customAttributeFacade, operatorFacade, iacUsersByProviderId, providerOrganizationAgreement);
                }
                EventLogger.WriteVerbose(logString.ToString());
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(ex);
            }
            return false;
        }

        private void UpdateProviderUsersWithAgreements(IDictionary<string, OrganizationInfo> organizationById, StringBuilder logString, IUserFacade userFacade, Data.IAtHocContextFactory context, CustomAttributeFacade customAttributeFacade, IOperatorFacade operatorFacade, Dictionary<int, List<MassDeviceTargetingResult>> iacUsersByProviderId, SystemOrganizationAgreement providerOrganizationAgreement)
        {
            
            var operatorId = 1;
            var tempProviderId = providerOrganizationAgreement.VpsId;
            var agreements = providerOrganizationAgreement.OrganizationAgreements;
            var existingUsers = GetIacUsersByProviderId(tempProviderId, iacUsersByProviderId);

            IEnumerable<string> targetedOrgIds = from o in agreements
                                                 where o.IsSend
                                                 select o.OtherOrganizationGuid;

            var existingUsersByOrgId = new Dictionary<string, MassDeviceTargetingResult>();
            var obsoleteUserIds = new List<int>();
            var addedUsers = new List<OrganizationInfo>();
            var updatedUsers = new Dictionary<int, string>();
            var updatedUsersLocation = new Dictionary<int, string>();

            if (existingUsers != null)
            {
                foreach (var iacUser in existingUsers)
                {
                    string userOrgId = GetOrganizationGuidFromIacUser(iacUser);
                    if (userOrgId == null)
                    {
                        obsoleteUserIds.Add(iacUser.UserId);
                        continue;
                    }
                    MassDeviceTargetingResult u;
                    if (existingUsersByOrgId.TryGetValue(userOrgId, out u))
                    {
                        //this organization is already represented by other user. remove this user.
                        obsoleteUserIds.Add(iacUser.UserId);
                        EventLogger.WriteError( string.Format("more than one user is associated with orgid: {0}", userOrgId));
                    }
                    else
                    {
                        existingUsersByOrgId.Add(userOrgId, iacUser);
                    }
                }
            }

            foreach (var targetedOrgId in targetedOrgIds)
            {
                OrganizationInfo org;
                organizationById.TryGetValue(targetedOrgId, out org);
                if (org == null)
                {
                    //Organization could be inactive
                    EventLogger.WriteWarning(string.Format("Could not find organizationInfo for id: {0}, skip this user. Organization could be disabled", targetedOrgId));
                    continue;
                }

                // check if already exist
                MassDeviceTargetingResult endUser;
                existingUsersByOrgId.TryGetValue(targetedOrgId, out endUser);
                if (endUser != null)
                {
                    // exist, update this user name if name changed
                    if (!org.Name.Equals(endUser.DisplayName, StringComparison.InvariantCultureIgnoreCase))
                    {
                        try
                        {
                            string tempOrgName;
                            if (!updatedUsers.TryGetValue(endUser.UserId, out tempOrgName))
                            {
                                updatedUsers.Add(endUser.UserId, org.Name);
                                EventLogger.WriteVerbose(string.Format("Updating IAC user details {0} with name: {1} ",
                                    endUser.UserName, org.Name));
                            }
                        }
                        catch (Exception ex)
                        {
                            EventLogger.WriteError(ex);
                        }
                    }
                    // Make sure Location is not updated on connect side. If it is not same as IWS side, then add to the list for update.
                    if (!org.Location.Equals(endUser.LastKnownLocation, StringComparison.InvariantCultureIgnoreCase))
                    {
                        string tempLocation;
                        if (!updatedUsersLocation.TryGetValue(endUser.UserId, out tempLocation))
                        {
                            updatedUsersLocation.Add(endUser.UserId, org.Location);
                        }
                    }
                    // remove it from the list of existing users. users left in this list wil be removed later, as they deleted the agreement.
                    existingUsersByOrgId.Remove(targetedOrgId);
                }
                else
                {
                    // Build the list to create new user.
                    addedUsers.Add(org);
                }
            }

            // added users
            logString.Append(string.Format("# of Added users: {0} \n", addedUsers.Count));
            if (addedUsers.Count > 0)
            {
                try
                {
                    var displayNameAttribute = GetDisplayNameAttribute(tempProviderId, customAttributeFacade);
                    var device = GetCrossAgencyDevice(tempProviderId, context);
                    if (device == null)
                    {
                        EventLogger.WriteWarning(string.Format(
                                    "Failed to get existing IAC Users for provider {0}. Is IAC device enabled?",
                                    tempProviderId));
                    }
                    else
                    {
                        //Get Mass Device Attribute
                        var massDeviceAttribute = GetMassDeviceAttribute(tempProviderId, customAttributeFacade);
                        if (massDeviceAttribute == null)
                        {
                            EventLogger.WriteError(
                                string.Format(
                                    "Method:UpdateProviderWithAgreements -> Unable to locate Mass Device attribute for provider Id = {0}",tempProviderId));

                        }
                        //Get Org Hierarchy Attribute
                        var orgHierarchyAttribute = GetOrgHierarchyAttribute(tempProviderId, customAttributeFacade);

                        //Get Geo Attribute
                        var geoAttribute = GetGeoAttribute(tempProviderId, customAttributeFacade);

                        foreach (var organizationInfo in addedUsers)
                        {
                            var devices = new List<Device>();
                            var userAttributes = new List<CustomAttribute>();
                            device.UserAddressValue = organizationInfo.Guid;
                            displayNameAttribute.UserAttributeValue = organizationInfo.Name;
                            
                            if (!string.IsNullOrEmpty(organizationInfo.Location) && geoAttribute != null)
                            {
                                //EventLogger.WriteInformation(string.Format("Org Location : - {0}", organizationInfo.Location));
                                var geometryString = new SqlChars(new SqlString(organizationInfo.Location));
                                //var geoSqlObject = organizationInfo.Location.ConvertTo<SqlGeography>();
                                var orgLocation = SqlGeography.STGeomFromText(geometryString, 4326);
                                EventLogger.WriteInformation(string.Format("Org Location : - {0}", orgLocation.ToString()));
                                geoAttribute.UserAttributeValue = orgLocation;
                                userAttributes.Add(geoAttribute);
                            }

                            devices.Add(device);
                            userAttributes.Add(displayNameAttribute);
                            userAttributes.Add(massDeviceAttribute);
                            if (orgHierarchyAttribute != null)
                            {
                                orgHierarchyAttribute.UserAttributeValue = orgHierarchyAttribute.DefaultValue;
                                userAttributes.Add(orgHierarchyAttribute);
                            }
                            CreateIacUser(tempProviderId,operatorId, operatorFacade, userFacade, organizationInfo, devices, userAttributes);
                        }
                    }
                }
                catch (Exception ex)
                {
                    EventLogger.WriteError("User Sync Job - Error while CreateIacUser: ", ex);
                }
            }
            // updated users
            logString.Append(string.Format("# of Updated users: {0} \n", updatedUsers.Count));
            if (updatedUsers.Count > 0)
            {
                try
                {
                    var displayNameAttribute = GetDisplayNameAttribute(tempProviderId, customAttributeFacade);
                    foreach (var user in updatedUsers)
                    {
                        var userAttributes = new List<CustomAttribute>();
                        displayNameAttribute.UserAttributeValue = user.Value;
                        userAttributes.Add(displayNameAttribute);

                        UpdateIacUser(tempProviderId,operatorId, userFacade, userAttributes, user.Key);
                    }
                }
                catch (Exception ex)
                {
                    EventLogger.WriteError("User Sync Job - Error While Updating IACUSer ", ex);
                }
            }

            if (updatedUsersLocation.Count > 0)
            {
                try
                {
                    var getAttribute = GetGeoAttribute(tempProviderId, customAttributeFacade);
                    foreach (var location in updatedUsersLocation)
                    {
                        var getAttributes = new List<CustomAttribute>();
                        getAttribute.UserAttributeValue = location.Value;
                        getAttributes.Add(getAttribute);

                        UpdateIacUser(tempProviderId,operatorId, userFacade, getAttributes, location.Key);
                    }
                }
                catch (Exception ex)
                {
                    EventLogger.WriteError(string.Format("User Sync Job - Error While Updating User Location. Provider Id - {0}",tempProviderId), ex);
                }
            }

            // whatever left inexistingUsersByOrgId should be deleted.
            // now delete users           
            obsoleteUserIds.AddRange(existingUsersByOrgId.Values.Select(u => u.UserId));
            logString.Append(string.Format("# of Deleted users: {0} \n", obsoleteUserIds.Count));
            if (obsoleteUserIds.Count > 0)
            {
                try
                {
                    
                    RemoveIacUsers(tempProviderId,operatorId, obsoleteUserIds, userFacade);

                    EventLogger.WriteVerbose(string.Format("OnOrganizationAgreementChange, deleting: {0} users: {1}", obsoleteUserIds.Count, String.Join(String.Empty, obsoleteUserIds.ToArray())));
                }
                catch (Exception ex)
                {
                    EventLogger.WriteError(ex);
                }
            }
        }

        private static string GetOrganizationGuidFromIacUser(MassDeviceTargetingResult user)
        {
            try
            {
                if (user == null)
                {
                   EventLogger.WriteError( string.Format("failed to GetOrganizationGuidForUser. user is null "));
                    return null;
                }

                if (string.IsNullOrEmpty(user.UserName))
                {
                    EventLogger.WriteError(string.Format("failed to GetOrganizationGuidForUser. username is empty or null, id: {0} ", user.UserId));
                    return null;
                }
                //u.De.Select(x=>x.)
                return user.UserName.Split('_')[1];
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("failed to GetOrganizationGuidForUser for username: {0} ", user.UserId), ex);

            }
            return null;
        }
        private static string GetOrganizationLocationFromIacUser(MassDeviceTargetingResult user)
        {
            try
            {
                if (user == null)
                {
                    EventLogger.WriteError(string.Format("failed to GetOrganizationGuidForUser. user is null "));
                    return null;
                }

                if (string.IsNullOrEmpty(user.UserName))
                {
                    EventLogger.WriteError(string.Format("failed to GetOrganizationGuidForUser. username is empty or null, id: {0} ", user.UserId));
                    return null;
                }
                //u.De.Select(x=>x.)
                return user.LastKnownLocation;
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("failed to GetOrganizationGuidForUser for username: {0} ", user.UserId), ex);

            }
            return null;
        }
        private List<MassDeviceTargetingResult> GetIacUsersByProviderId(int providerId, Dictionary<int, List<MassDeviceTargetingResult>> iacUsers)
        {
            List<MassDeviceTargetingResult> lstOfUsers = new List<MassDeviceTargetingResult>();
            iacUsers.TryGetValue(providerId, out lstOfUsers);
            return lstOfUsers;
        }


        private static void UpdateIacUser(int providerId, int operatorId,IUserFacade userFacade, IEnumerable<CustomAttribute> attributes, int userId)
        {
            userFacade.UpdateCustomAttributesForEndUser(new UserAttributesUpdateSpec
            {
                ProviderId = providerId,
                UserId = userId,
                UpdatedBy = operatorId,
                Attributes = attributes,
                LogAudit = false,
                Devices = new List<Device>(),
            });
        }
        private void CreateIacUser(int providerId, int operatorId, IOperatorFacade operatorFacade, IUserFacade userFacade, OrganizationInfo org, IEnumerable<Device> devices, IEnumerable<CustomAttribute> userAttributes)
        {
            
            var newUser = new User { UserName = GetUserName(org.Guid), Token = "athoc", DisplayName = org.Name, ProviderId = providerId };
            // add the device                        
            var systemUser = new SystemUser
            {
                User = newUser,
                OperatorUser = new OperatorUser {/*Id = newUser.Id,*/ Username = newUser.UserName, /*Status = UserStatusType.Active,*/}
            };

            operatorFacade.SaveUser(new UserSaveSpec
            {
                OperatorId = operatorId,
                SystemUser = systemUser,
                UserName = newUser.UserName
            });
            
            userFacade.UpdateCustomAttributesForEndUser(new UserAttributesUpdateSpec
            {
                ProviderId = providerId,
                UserId = newUser.Id,
                UpdatedBy = 1, //1 - operator
                Attributes = userAttributes,
                Devices = devices,
                LogAudit = false
            });
        }
        private static void RemoveIacUsers(int providerId,int operatorId, List<int> obsoleteUserIds, IUserFacade userFacade)
        {
            if (obsoleteUserIds.Count > 0)
            {
                userFacade.DeleteUser(new UserSpec
                {
                    ProviderId = providerId,
                    UserIds = obsoleteUserIds,
                    OperatorId = operatorId
                });
            }
        }

        private Device GetCrossAgencyDevice(int providerId, Data.IAtHocContextFactory context)
        {
            IDeviceFacade deviceFacade = new DeviceFacade(context);

            var deviceSpec = new DeviceSpec
            {
                ProviderId = providerId,
                CommonName = IacCommonName,
                IncludeDeviceProvider = true,
                GetDeletedDevices = false,
                EnabledOnly = true
                
            };
            var providerContext = new ProviderRepository(new AtHocEventLogger());
            IProviderFacade providerFacade = new ProviderFacade(providerContext);
            var providerBaseLocale = providerFacade.GetProviderLocale(providerId);
            if (string.IsNullOrEmpty(providerBaseLocale))
            {
                EventLogger.WriteError(string.Format("Method: GetCrossAgencyDevice - Unable to find base locale for provider = {0}", providerId));
                providerBaseLocale = "en-US";
            }
            
            var crossagencyDevice = deviceFacade.GetDeviceBySpec(deviceSpec, providerBaseLocale);

            return crossagencyDevice;
        }

        private CustomAttribute GetDisplayNameAttribute(int providerId, CustomAttributeFacade customAttributeFacade)
        {
            var displayNameAttr = customAttributeFacade.GetCustomAttributesBySpec(new CustomAttributeSpec()
            {
                CommonName = "DISPLAYNAME",
                ProviderId = providerId,
                ApplyFeatureMatrix = false,
            }).FirstOrDefault();
            return displayNameAttr;
        }

        private CustomAttribute GetMassDeviceAttribute(int providerId, CustomAttributeFacade customAttributeFacade)
        {
            //GetCustomAttributeValues requires the locale to be passed.
            var providerContext = new ProviderRepository(new AtHocEventLogger());
            IProviderFacade providerFacade = new ProviderFacade(providerContext);
            var providerBaseLocale = providerFacade.GetProviderLocale(providerId);
            if (string.IsNullOrEmpty(providerBaseLocale))
            {
                EventLogger.WriteError(string.Format("Method: GetCrossAgencyDevice - Unable to find base locale for provider = {0}", providerId));
                providerBaseLocale = "en-US";
            }

            var massDeviceAttr = customAttributeFacade.GetCustomAttributesBySpec(new CustomAttributeSpec()
            {
                CommonName = "NPD",//Non Personal Device
                ProviderId = providerId
                
            }).FirstOrDefault();

            if (massDeviceAttr == null)
            {
                EventLogger.WriteError(string.Format("Method -> GetMassDeviceAttribute : Unable to find Mass Divice Attribute for CommonName=NPD and provider Id = {0}", providerId));
                return null;
            }
            var massDeviceAttrValues = customAttributeFacade.GetCustomAttributeValuesBySpec(new CustomAttributeValueSpec()
            {
                AttributeId = massDeviceAttr.Id,
                BaseLocale = providerBaseLocale
            });

            //add massDeviceAttr.
            var massDeviceAttrValue = massDeviceAttrValues.FirstOrDefault(cav => cav.CommonName.Equals("YES", StringComparison.CurrentCultureIgnoreCase));
            if (massDeviceAttrValue == null)
            {
                EventLogger.WriteError(string.Format("Method -> GetMassDeviceAttribute : Unable to find Mass Divice Attribute value for CommonName=YES, Attribute Id = {0} and provider Id = {1}", massDeviceAttr.Id, providerId));
                return null;
            }
            massDeviceAttr.UserAttributeValue = massDeviceAttrValue.ValueId; //4428; //todo lookup here!
            return massDeviceAttr;
        }

        /// <summary>
        /// Get Org Hierarchy Custom Attribute
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="customAttributeFacade"></param>
        /// <returns>CustomAttribute</returns>
        private CustomAttribute GetOrgHierarchyAttribute(int providerId, CustomAttributeFacade customAttributeFacade)
        {
            var orgHierarchyAttribute = customAttributeFacade.GetOrgHierarchyAttributeBySpec(providerId);
            return orgHierarchyAttribute;
        }

        /// <summary>
        /// Get Geo Attribute for Provider 
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="customAttributeFacade"></param>
        /// <returns></returns>
        private CustomAttribute GetGeoAttribute(int providerId, CustomAttributeFacade customAttributeFacade)
        {
            var spec = new CustomAttributeSpec { ProviderId = providerId, CommonName = "LAST-KNOWN-LOCATION" };
            var geoAttribute = customAttributeFacade.GetCustomAttributesBySpec(spec).First();
            return geoAttribute;
        }

    }
}
