﻿using System;
using System.Collections.Generic;
using AtHoc.d911.Model.Organization;
using AtHoc.Runtime;
using AtHoc.Systems;

namespace AtHoc.IWS.Business.Domain.Organization.Impl
{
    public class OrganizationFacadeCache
    {       

        public const string SelfOrganizationCacheName = "organization.selfOrganization";
        public const string SelfOrganizationCachePolicyName = "CACHE_POLICY_SELF_ORGANIZATION";
        public const int SelfOrganizationCacheDefaultPolicy = 2 * 60;   // 2 min            

        public const string OrganizationListCacheName = "organization.organizationList";
        public const string OrganizationListCachePolicyName = "CACHE_POLICY_ORGANIZATION_LIST";
        public const int OrganizationListCacheDefaultPolicy = 2 * 60;     // 2 min          

        public const string OrganizationLogoCacheName = "organization.organization.logo";
        public const string OrganizationLogoCachePolicyName = "CACHE_POLICY_ORGANIZATION_LOGO";
        public const int OrganizationLogoCacheDefaultPolicy = 15 * 60 ;     // 15 min      

        public const string PssParamCacheName = "organization.pss.params";
        public const string PssParamCachePolicyName = "CACHE_POLICY_ORGANIZATION_PSS_PARAM";
        public const int PssParamCacheDefaultPolicy = 2*60;     // 2 min             

        public const string OrganizationTypeListCacheName = "organization.organizationTypeList";
        public const string OrganizationTypeListCachePolicyName = "CACHE_POLICY_ORGANIZATION_TYPE_LIST";
        public const int OrganizationTypeListCacheDefaultPolicy = 2 * 60;     // 2 min   

        private const string OrganizationDetailCacheName = "organization.organizationDetail";
        private const string OrganizationDetailCachePolicyName = "CACHE_POLICY_ORGANIZATION_DETAIL";
        private const int OrganizationDetailCacheDefaultPolicy = 2 * 60; //2 min


        private static readonly object CacheLock = new object();

        private OrganizationFacadeCache() { }

        private static readonly OrganizationFacadeCache Instance = new OrganizationFacadeCache();
        public static OrganizationFacadeCache GetInstance()
        {
            return Instance;
        }

        public IDictionary<string, OrganizationInfo> GetOrganizationListCache(int providerId,Func<IDictionary<string, OrganizationInfo>> getValueCallbackFunc)
        {
            string cacheKey = string.Format("orgs-{0}", providerId);
            return GetSetObjectCache(OrganizationListCacheName, cacheKey, OrganizationListCachePolicyName, OrganizationListCacheDefaultPolicy, getValueCallbackFunc);
        }

        public OrganizationInfo GetOrganizationDetailCache(
            string guid)
        {
            string cacheKey = string.Format("org-{0}", guid);
            return GetObjectFromCache<OrganizationInfo>(OrganizationDetailCacheName, cacheKey, OrganizationDetailCachePolicyName,
                OrganizationDetailCacheDefaultPolicy);
        }

        public void SetOrganizationDetailCache(string guid,OrganizationInfo orgInfo)
        {
            string cacheKey = string.Format("org-{0}", guid);
            SetObjectFromCache(OrganizationDetailCacheName,cacheKey,OrganizationDetailCachePolicyName,OrganizationDetailCacheDefaultPolicy,orgInfo);            
        }

        public OrganizationInfo GetSelfOrganizationCache(int providerId, Func<OrganizationInfo> getValueCallbackFunc)
        {
            string cacheKey = string.Format("selfOrg-{0}", providerId);
            return GetSetObjectCache(SelfOrganizationCacheName, cacheKey, SelfOrganizationCachePolicyName, SelfOrganizationCacheDefaultPolicy, getValueCallbackFunc);
        }

        public IDictionary<string, OrganizationSectorInfo> GetOrganizationTypeCache(int providerId, Func<IDictionary<string, OrganizationSectorInfo>> getValueCallbackFunc)
        {
            string cacheKey = string.Format("OrgTypes");
            return GetSetObjectCache(OrganizationTypeListCacheName, cacheKey, OrganizationTypeListCacheName, OrganizationTypeListCacheDefaultPolicy, getValueCallbackFunc);
        }        

        public OrganizationLogo GetOrganizationLogoCache(string guid, Func<OrganizationLogo> getValueCallbackFunc)
        {
            return GetSetObjectCache(OrganizationLogoCacheName, guid, OrganizationLogoCachePolicyName, OrganizationLogoCacheDefaultPolicy, getValueCallbackFunc);
        }

        public PssConnectionParams GetPssConnectionParamCache(Func<PssConnectionParams> getValueCallbackFunc)
        {
            // entire system
            string key = "1";
            return GetSetObjectCache(PssParamCacheName, key, PssParamCachePolicyName, PssParamCacheDefaultPolicy, getValueCallbackFunc);
        } 
       

        private T GetSetObjectCache<T>(string cacheName, string cacheKey, string cachePolicyName, int defaultExpirationPolicy, Func<T> getValueCallbackFunc)
        {
            IProcessCache cache = GetOrCreateCache(cacheName, cachePolicyName, defaultExpirationPolicy);

            T container;
            if (!cache.TryGet(cacheKey, out container))
            {
                lock (CacheLock)
                {
                    if (!cache.TryGet(cacheKey, out container))
                    {
                        container = getValueCallbackFunc();
                        if (container != null)
                        {
                            // put configuration in cache
                            cache.Set(cacheKey, container);
                        }
                    }
                }
            }

            return container;
        }

        private T GetObjectFromCache<T>(string cacheName, string cacheKey, string cachePolicyName, int defaultExpirationPolicy)
        {
            IProcessCache cache = GetOrCreateCache(cacheName, cachePolicyName, defaultExpirationPolicy);

            T container;
            cache.TryGet(cacheKey, out container);
            return container;
        }

        private void SetObjectFromCache<T>(string cacheName, string cacheKey, string cachePolicyName, int defaultExpirationPolicy, T value)
        {
            IProcessCache cache = GetOrCreateCache(cacheName, cachePolicyName, defaultExpirationPolicy);
            lock (CacheLock)
            {
                T container;
                if (!cache.TryGet(cacheKey, out container))
                {
                    // put configuration in cache
                    cache.Set(cacheKey, value);
                }
            }
        }

        private static IProcessCache GetOrCreateCache(string cacheName, string cachePolicyName, int defaultPolicy = 0)
        {
            // TODO: this should be re-factored to use file pased cache definitions
            var cache = AtHocRuntime.ProcessCacheManager.GetCache(cacheName);
            if (cache == null)
            {
                lock (CacheLock)
                {
                    cache = AtHocRuntime.ProcessCacheManager.GetCache(cacheName);
                    if (cache == null)
                    {
                        // TODO: need to convert this to come from cache.confg file

                        // TODO: get values from database configuration table use these as defaults
                        var cachePolicyString = AtHocSystem.Local.Configuration.GetValue(cachePolicyName);
                        var cachePolicy = !string.IsNullOrEmpty(cachePolicyString)
                            ? Int32.Parse(cachePolicyString)
                            : defaultPolicy;
                        if (cachePolicy < 0) cachePolicy = 0;

                        var isEnabled = cachePolicy > 0;
                        var defaultExpiration = TimeSpan.FromSeconds(cachePolicy);
                        var pollingInterval = TimeSpan.FromSeconds(5);
                        const ExpirationType defaultExpirationType = ExpirationType.Absolute;
                        const int cacheMemoryLimitMegabytes = 20;
                        const int physicalMemoryLimitPercentage = 0;

                        var configuration = new ProcessCacheConfiguration
                        {
                            IsEnabled = isEnabled,
                            DefaultExpirationType = defaultExpirationType,
                            DefaultExpiration = defaultExpiration,
                            PollingInterval = pollingInterval,
                            PhysicalMemoryLimitPercentage = physicalMemoryLimitPercentage,
                            CacheMemoryLimitMegabytes = cacheMemoryLimitMegabytes,
                            Name = cacheName
                        };
                        cache = AtHocRuntime.ProcessCacheManager.CreateCache(configuration);
                        // TODO: in the future when this is automatuically read from the config file
                        //      we should log an error if the cache is not found.
                        //      hard error fail.
                        //EventLogger.WriteWarning("Missing Cache Configuration: " + cacheName);
                    }
                }
            }

            return cache;
        }
    }
}
