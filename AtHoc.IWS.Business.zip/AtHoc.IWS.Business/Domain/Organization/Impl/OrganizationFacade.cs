﻿using AtHoc.d911.Common.Model;
using AtHoc.d911.Model.Organization;
using AtHoc.d911.Net;
using AtHoc.Devices;
using AtHoc.Diagnostics;
using AtHoc.Infrastructure.Ioc;
using AtHoc.Infrastructure.Ioc.SimpleInjector;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Log.EventLog;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Audit;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;
using AtHoc.IWS.Business.Domain.Devices;
using AtHoc.IWS.Business.Domain.Devices.Spec;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Event.Impl;
using AtHoc.IWS.Business.Domain.Events;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Settings.Impl;
using AtHoc.IWS.Business.Domain.Spec;
using AtHoc.IWS.Business.Domain.Targeting;
using AtHoc.IWS.Business.Domain.Targeting.Impl;
using AtHoc.IWS.Business.Domain.Targeting.Spec;
using AtHoc.IWS.Business.Domain.Users.Impl.Search;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Business.Encryption;
using AtHoc.IWS.Business.Helper;
using AtHoc.IWS.Business.Ioc;
using AtHoc.Systems;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Text;
using AtHoc.IWS.Business.Shedule;
using AtHoc.IWS.Business.Shedule.Spec;
using EnumerableExtensions = Microsoft.Practices.ObjectBuilder2.EnumerableExtensions;
using User = AtHoc.IWS.Business.Domain.Entities.User;

namespace AtHoc.IWS.Business.Domain.Organization.Impl
{
    public partial class OrganizationFacade : IOrganizationFacade
    {
        public readonly string IacCommonName = "UAP-IAC";
        public const string UserAuthHttpHeader = @"UserAuthKey";
        private const string SourceType = "USER";
        private const string ResponseType = "response";

        static OrganizationFacade()
        {
            // We need to create this context since this facade is not always being called from the UI context.
            // for example form the polling agent or Event Server
            //All regular schedular job must initialize the service locator like below.
            //OrganizationFacade, AccountabilityEventProcessor, AutoDisableDeleteProcess
            //if (ServiceLocator.Current == null)
            //{
            //    string message = "Init servicelocator from Organization Facade";
            //    EventLogger.WriteInformation(new Exception(message));
            //    var serviceLoader = new AtHocServiceLoader();
            //    serviceLoader.LoadAll();

            //    if (ServiceLocator.Current != null)
            //    {
            //        ServiceLocator.Current.Register<IRuntimeContext, StandAloneRuntimeContext>(ServiceLifecycle.Singleton);
            //    }
            //}
            //RegularSchedularServiceInitializer.Init();
            
        }

        public ConnectivityStatus GetConnectivityStatus(int providerId)
        {
            var pssParams = GetCachedPssParams();
            if (!pssParams.IsPollServiceEnabled)
            {
                return ConnectivityStatus.NotConfigured;
            }
            if (!IsIacEnabled(providerId))
            {
                return ConnectivityStatus.DeviceNotConfigured;
            }
            if (GetSelfOrganizationGuid(providerId) == null)
            {
                return ConnectivityStatus.NotListed;
            }
            return ConnectivityStatus.Connected;
        }

        /// <summary>
        /// retrieve organizations from the hub
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="spec"></param>
        /// <returns></returns>
        public IDictionary<string, OrganizationInfo> GetOrganizations(int providerId, OrganizationSpec spec)
        {
            // at this point all we are doing is calling PSS for it.     

            var cachedList = spec.OrganizationGuidList == null || spec.OrganizationGuidList.Count == 0
                            ? GetCachedOrganizatios(providerId)
                            : GetCachedDetailOrganization(providerId, spec.OrganizationGuidList);

            IDictionary<string, OrganizationInfo> ret = new Dictionary<string, OrganizationInfo>();
            EnumerableExtensions.ForEach(cachedList, item =>
            {
                if (spec.SearchText != null)
                {
                    spec.SearchText = spec.SearchText.Trim();
                }
                var isFiltered = false;
                if (!string.IsNullOrEmpty(spec.SearchText))
                {
                    var name = item.Value.Name ?? "";
                    var desc = item.Value.Description ?? "";
                    if (string.IsNullOrEmpty(item.Value.Name))
                    {
                        isFiltered = true;
                    }
                    else if (!(name.IndexOf(spec.SearchText, StringComparison.OrdinalIgnoreCase) >= 0 || desc.IndexOf(spec.SearchText, StringComparison.OrdinalIgnoreCase) >= 0))
                    {
                        isFiltered = true;
                    }
                }

                if (spec.TypeId != null && spec.TypeId >= 0)
                {
                    if (spec.TypeId != item.Value.Sector.Id)
                    {
                        isFiltered = true;
                    }
                }
                if (!isFiltered)
                {
                    ret.Add(item);
                }
            });

            return ret;
        }

        public OrganizationInfo GetOrganizationById(int providerId, string guid)
        {
            IDictionary<string, OrganizationInfo> org = GetCachedDetailOrganization(providerId, new List<string>() { guid });
            OrganizationInfo orgInfo;
            if (org != null && org.Count > 0)
            {
                if (org.TryGetValue(guid, out orgInfo))
                    return orgInfo;
            }
            return null;
        }

        public string GetSelfOrganizationGuid(int providerId)
        {
            var self = GetSelfOrganization(providerId);
            if (self == null)
            {
                return null;
            }
            return self.Guid;
        }

        public OrganizationInfo GetSelfOrganization(int providerId)
        {
            var self = OrganizationFacadeCache.GetInstance().GetSelfOrganizationCache(providerId, () =>
            {
                string token = GetOrganizationToken(providerId);
                Response<OrganizationInfo> res = MakeApiCall<OrganizationInfo>(string.Format("{0}", "organizations/self"), token);
                if (res.IsSuccess)
                {
                    return res.Value;
                }

                if (!res.IsSuccess &&
                    !string.IsNullOrEmpty(res.Error) &&
                    res.ErrorId.Equals(ErrorCodes.OrganizationNotListed.ToString()))
                {
                    return new OrganizationInfo();
                }
                return null;
            });

            return self;
        }

        public OrganizationLogo GetOrganizationLogo(int providerId, string orgId)
        {
            var logo = OrganizationFacadeCache.GetInstance().GetOrganizationLogoCache(orgId, () =>
            {
                var selfOrganizationToken = GetSelfOrganizationGuid(providerId);
                Response<OrganizationLogo> res = MakeApiCall<OrganizationLogo>(string.Format("{0}/{1}/logo", "organizations", orgId), selfOrganizationToken);
                if (res.IsSuccess)
                {
                    return res.Value;
                }
                return null;
            });

            return logo;
        }

        public OrganizationConnection GetConnections(int providerId, bool includeAgreement = true, bool includeInvitation = true, bool includeExternalInvitation = false)
        {
            var myParameters = new OrganizationConnectionGetParams()
            {
                IncludeAgreement = includeAgreement,
                IncludeInvitation = includeInvitation,
                IncludeExternalInvitation = includeExternalInvitation
            };

            Response<OrganizationConnection> res = MakeApiCall<OrganizationConnection>(string.Format("{0}", "connections/self"), GetSelfOrganizationGuid(providerId), true, myParameters);
            if (res.IsSuccess)
            {
                return res.Value;
            }

            return null;
        }

        [Obsolete("to be remove")]
        public IEnumerable<OrganizationAgreementInfo> GetOrganizationAgreements(int providerId)
        {
            Response<List<OrganizationAgreementInfo>> res = MakeApiCall<List<OrganizationAgreementInfo>>(string.Format("{0}", "organizations/self/agreements"), GetSelfOrganizationGuid(providerId));
            if (res.IsSuccess)
            {
                return res.Value;
            }

            return null;
        }

        public IEnumerable<OrganizationAgreementInfoModel> GetOrganizationConnectionAgreements(int providerId)
        {
            var myParameters = new OrganizationConnectionGetParams() { IncludeAgreement = true, IncludeInvitation = false };
            Response<OrganizationConnection> res = MakeApiCall<OrganizationConnection>(string.Format("{0}", "connections/self"), GetSelfOrganizationGuid(providerId), true, myParameters);
            if (res.IsSuccess)
            {
                return res.Value.Agreements;
            }

            return null;
        }

        [Obsolete("to be remove")]
        public SystemOrganizationAgreementsResponse GetSystemAgreements()
        {
            Response<SystemOrganizationAgreementsResponse> res = MakeApiCall<SystemOrganizationAgreementsResponse>(string.Format("{0}{1}", "organizations/system/agreements?systemId=", GetCachedPssParams().Domain), null);
            if (res.IsSuccess)
            {
                return res.Value;
            }
            return null;
        }
        public SystemOrganizationConnection GetSystemConnectionAgreements()
        {

            Response<SystemOrganizationConnection> res = MakeApiCall<SystemOrganizationConnection>(string.Format("{0}{1}", "connections/system?systemId=", GetCachedPssParams().Domain), null);
            if (res.IsSuccess)
            {
                return res.Value;
            }
            return null;
        }
        public int Invite(int providerId, string otherOrganizationGuid, AgreementDirection direction, string message)
        {
            var selfOrganizationToken = GetSelfOrganizationGuid(providerId);
            var isSend = (direction == AgreementDirection.Both || direction == AgreementDirection.Send);
            var isRecv = (direction == AgreementDirection.Both || direction == AgreementDirection.Receive);
            var myParameters = new OrganizationAgreementInviteParams() { InviteeOrganizationGuid = otherOrganizationGuid, IsSend = isSend, IsReceive = isRecv, Message = message };
            Response<int> res = MakeApiCall<int>("connections/self/invitation/create", selfOrganizationToken, true, myParameters);
            var auditSpec = new AuditSpec(RuntimeContext.OperatorId, providerId)
            {
                Action = res.IsSuccess ? ServiceAction.OrgInvite : ServiceAction.OrgInviteFail,
                ObjectType = EntityType.Organization,
                ObjectName = RuntimeContext.Operator.DisplayName
            };
            OperationAuditor.LogAction(auditSpec);

            if (!res.IsSuccess)
            {
                return -1;
            }

            return res.Value;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="providerId">ProviderId</param>
        /// <param name="id">Invitation/AgreementId</param>
        /// <param name="status">InvitationAction</param>
        /// <returns>Boolean True/False</returns>
        public Response<bool> UpdateInvitation(int providerId, int id, InvitationAction status)
        {
            var selfOrganizationToken = GetSelfOrganizationGuid(providerId);
            var myParameters = new OrganizationInvitationUpdateParams() { InvitationIds = new List<int> { id }, Action = status };
            Response<bool> res = MakeApiCall<bool>("connections/self/invitation/update", selfOrganizationToken, true, myParameters);

            var auditSpec = new AuditSpec(RuntimeContext.OperatorId, RuntimeContext.ProviderId)
            {
                ObjectType = EntityType.Organization,
                ObjectName = RuntimeContext.Operator.DisplayName
            };
            switch (status)
            {
                case InvitationAction.Accept:
                    auditSpec.Action = res.IsSuccess ? ServiceAction.OrgInviteAccept : ServiceAction.OrgInviteAcceptFail;
                    break;
                case InvitationAction.Cancel:
                    auditSpec.Action = res.IsSuccess ? ServiceAction.OrgInviteCancel : ServiceAction.OrgInviteCancelFail;
                    break;
                case InvitationAction.Decline:
                    auditSpec.Action = res.IsSuccess ? ServiceAction.OrgInviteDecline : ServiceAction.OrgInviteDeclineFail;
                    break;
            }
            OperationAuditor.LogAction(auditSpec);
            return res;

        }

        public bool CancelAgreement(int providerId, int id)
        {
            var selfOrganizationToken = GetSelfOrganizationGuid(providerId);
            var myParameters = new List<OrganizationAgreementCancelParams> { new OrganizationAgreementCancelParams() { AgreementId = id } };
            Response<bool> res = MakeApiCall<bool>("connections/self/agreement/cancel", selfOrganizationToken, true, myParameters);

            var auditSpec = new AuditSpec(RuntimeContext.OperatorId, RuntimeContext.ProviderId)
            {
                ObjectType = EntityType.Organization,
                ObjectName = RuntimeContext.Operator.DisplayName,
                Action = res.IsSuccess ? ServiceAction.OrgInviteCancel : ServiceAction.OrgInviteCancelFail
            };
            OperationAuditor.LogAction(auditSpec);

            if (!res.IsSuccess)
            {
                return false;
            }

            return true;
        }

        public bool MarkMessageAsRead(int providerId, List<int> ids)
        {
            var selfOrganizationToken = GetSelfOrganizationGuid(providerId);
            var myParameters = new List<OrganizationMessageMarkAsReadPostParams>();
            foreach (var id in ids)
            {
                myParameters.Add(new OrganizationMessageMarkAsReadPostParams() { MessageId = id });
            }
            Response<bool> res = MakeApiCall<bool>("connections/self/message/markasread", selfOrganizationToken, true, myParameters);
            return res.IsSuccess;
        }

        public bool SetMessageStatus(int providerId, String messageContext, MessageDeliveryStatus status, string responseOptionId = null,
            String description = null, GeoLocation location = null)
        {
            var selfOrganizationToken = GetSelfOrganizationGuid(providerId);
            var myParameters = new SetMessageStatusPostParams() { ContextId = messageContext, MessageDeliveryStatus = status, ResponseId = responseOptionId, Location = location, Description = description };
            Response<bool> res = MakeApiCall<bool>("messages/respond", selfOrganizationToken, true, myParameters);
            return res.IsSuccess;
        }

        public IEnumerable<OrganizationSectorInfo> GetOrganizationSectors(int providerId)
        {

            var cachedOrgTypes = GetCachedOrganizationTypes(providerId);
            var lstOfOrgTypes = new List<OrganizationSectorInfo>();
            //there may a chance,when self Organization is disabled, then OrganizationTypes cannot be retrieve from PSS, thus it will return null.
            if (cachedOrgTypes != null)
            {
                lstOfOrgTypes = cachedOrgTypes.Select(orgType => orgType.Value).ToList();
            }
            return lstOfOrgTypes;

        }

        /// <summary>
        /// Set Organization Visibility
        /// </summary>
        /// <param name="providerId">Provider ID</param>
        /// <param name="isVisibleToAll">Is Organization is visible to all?</param>
        /// <param name="organizationTypeIds">List of OrganizationTypeId.</param>
        /// <returns>Boolean success</returns>
        public bool SetOrganizationVisibility(int providerId, bool isVisibleToAll, List<int> organizationTypeIds)
        {
            try
            {
                var postParams = new SetOrganizationVisibilityPostParams();

                //if Organization is not visible to ALL
                if (!isVisibleToAll)
                {
                    if (organizationTypeIds == null || !organizationTypeIds.Any()) //Validate input parameters. Atleast one Organization should be selected.
                    {
                        LogService.Current.Error(() =>
                            string.Format(
                                "Method SetOgranizationVisibility({0},{1},null) has invalid parameter value. If param 'isVisibleToAll'= false, then int[] organizationTypeIds param cannot be null. " +
                                "Atleast 1 OrganizationType should be selected.", providerId, "false"));
                        return false;
                    }
                }
                postParams.OrganizationTypeIds = organizationTypeIds;
                postParams.IsVisibleToAll = isVisibleToAll;
                string token = GetSelfOrganizationGuid(providerId);
                Response<bool> res = MakeApiCall<bool>("organizations/self/visibility/update", token, true, postParams);
                var auditSpec = new AuditSpec(RuntimeContext.OperatorId, RuntimeContext.ProviderId)
                {
                    Action = res.IsSuccess ? ServiceAction.OrgVisibilityChange : ServiceAction.OrgVisibilityChangeFail,
                    ObjectType = EntityType.Organization,
                    ObjectName = RuntimeContext.Operator.DisplayName,
                    AdditionalInfo = isVisibleToAll ? "Visible to all" : string.Join(",", organizationTypeIds.ToArray())
                };
                OperationAuditor.LogAction(auditSpec);

                return res.Value;
            }
            catch (Exception ex)
            {

                LogService.Current.Error(() => ex);
            }
            return false;
        }

        public OrganizationVisibility GetOrganizationVisibility(int providerId)
        {
            string token = GetSelfOrganizationGuid(providerId);
            Response<OrganizationVisibility> orgVisTypes = MakeApiCall<OrganizationVisibility>(string.Format("{0}", "organizations/self/visibility"), token);
            if (orgVisTypes.Value.IsVisibleToAll)
            {
                Response<List<OrganizationSectorInfo>> orgTypes =
                    MakeApiCall<List<OrganizationSectorInfo>>(string.Format("{0}", "systeminfo/organizationtypes"), token);
                orgVisTypes.Value.OrganizationTypes = orgTypes.Value;

            }
            return orgVisTypes.Value;

        }

        public Response<bool> InviteNewOrganization(int providerId, InviteNewOrganizationParams inviteNewOrganizationParams)
        {
            inviteNewOrganizationParams.InviterName = inviteNewOrganizationParams.InviterName ?? string.Empty;
            inviteNewOrganizationParams.InviterRole = inviteNewOrganizationParams.InviterRole ?? string.Empty;
            string token = GetSelfOrganizationGuid(providerId);
            Response<bool> ret = MakeApiCall<bool>(string.Format("{0}", "organizations/invite"), token, true, inviteNewOrganizationParams);
            var auditSpec = new AuditSpec(RuntimeContext.OperatorId, providerId)
            {
                Action = ret.IsSuccess ? ServiceAction.OrgInviteNewOrg : ServiceAction.OrgInviteNewOrgFail,
                ObjectType = EntityType.Organization,
                ObjectName = RuntimeContext.Operator.DisplayName,
                AdditionalInfo = inviteNewOrganizationParams.InviteeContactEmail
            };
            OperationAuditor.LogAction(auditSpec);
            return ret;
        }


        public bool IsIacEnabled(int providerId)
        {
            var deviceManager = new DeviceManager(providerId);
            var iacDevice = deviceManager.GetDevice(IacCommonName);
            var isIacEnabled = iacDevice != null && iacDevice.Enabled;
            return isIacEnabled;
        }



        public IEnumerable<TargetableOrganization> GetActiveOrganization(int providerId, int operatorId, IUserFacade userFacade, IDeviceFacade deviceFacade)
        {
            var orgDeviceCommonName = IacCommonName;

            List<UserSearchResultItem> users = SearchIacUsers(providerId, operatorId, userFacade, deviceFacade);

            List<TargetableOrganization> list = new List<TargetableOrganization>();
            foreach (var user in users)
            {
                string oid = "";
                foreach (KeyValuePair<string, string> device in user.UserDevice)
                {
                    if (device.Key.Equals(orgDeviceCommonName))
                    {
                        oid = device.Value;
                    }
                }
                list.Add(new TargetableOrganization()
                {
                    Name = user.DisplayName,
                    Id = oid,
                    UserId = user.Id,
                    Selected = false
                });

            }

            return list;
        }

        private List<UserSearchResultItem> SearchIacUsers(int providerId, int operatorId, IUserFacade userFacade, IDeviceFacade deviceFacade)
        {
            var srchArgsV2 = new UserSearchArgs(false, true, true)
            {
                ProviderId = RuntimeContext.ProviderId,
                ProviderCriteria = UserSearchHelper.GetProviderCriteria(RuntimeContext.ProviderId),
                AttributeNames = new List<string>() { AttributeCommonNames.UserName, 
                                                    AttributeCommonNames.DisplayName,
                                                    AttributeCommonNames.FirstName,
                                                    AttributeCommonNames.LastName},
                DeviceNames = new List<string>() { IacCommonName }
            };

            var orgDevice = deviceFacade.GetDeviceBySpec(new DeviceSpec()
            {
                ProviderId = providerId,
                CommonName = IacCommonName,
                IncludeDeviceProvider = true,
                GetDeletedDevices = false,
                EnabledOnly = true,
            }, ProviderHelper.GetProviderLocale(providerId));

            var ret = new List<UserSearchResultItem>();

            if (orgDevice == null)
            {
                return ret;
            }

            var deviceId = orgDevice.Id;
            var advancedCriterion = new List<GenericCriteria> { new DeviceCriteria(deviceId, 12, "") };

            srchArgsV2.TargetCriteria = UserSearchHelper.GetCustomCriteria(new[] { advancedCriterion });

            var users = userFacade.SearchUsersByContext(srchArgsV2);

            foreach (var user in users.Users)
            {
                // return only users with IAC device address
                foreach (var device in user.UserDevice)
                {
                    if (device.Key.Equals(IacCommonName))
                    {
                        ret.Add(user);
                        break;
                    }
                }
            }
            return ret;
        }

        public void OnDelegateEventResponsesToConnect()
        {
            EventLogger.WriteVerbose("OnDelegateEventResponsesToConnect is execution started...");
            try
            {

                int noOfRecordsToBeProcessed = GetCachedPssParams().EventResponseBatchCount;
                EventLogger.WriteVerbose(string.Format("EventResponseBatchCount : {0} ", noOfRecordsToBeProcessed));
                var eventRepository = ServiceLocator.Resolve<IEventRepository>();

                //Get Alert Responses for Event. (Using SP NGEVENT=> PROCESS_ALERT_RESPONSE_DELEGATION)

                var alertResponsesForEvent = eventRepository.GetAlertResponsesForEvents(noOfRecordsToBeProcessed);
                if (EventLogger.IsVerboseEnabled)
                {
                    EventLogger.WriteVerbose(string.Format("GetAlertResponsesForEvents count: {0} ", alertResponsesForEvent.Count()));
                }
                if (alertResponsesForEvent == null || alertResponsesForEvent.Count == 0)
                {
                    EventLogger.WriteVerbose("OnDelegateEventResponsesToConnect is execution Done... No Responses available to process.");
                    return;
                }

                var eventIds = alertResponsesForEvent.Select(e => e.EventId).ToList();
                var eventSpec = new EventSpec { EventId = eventIds };

                //Get the list of Events for which Response has been sent.
                var events = eventRepository.GetEventEntities(eventSpec);

                //Put all events into the dictionary
                Dictionary<int, EventEntity> eventsDictionary = events.ToDictionary(eventEntity => eventEntity.EventId);

                //Build parameters
                var postParameters = new List<SetMessageStatusPostParams>();
                var eventDescriptions = new List<EventDescription>();

                foreach (var alertResponse in alertResponsesForEvent)
                {
                    var setMessageStatusPostParam = new SetMessageStatusPostParams();
                    var eventDescription = new EventDescription();
                    var evnt = new EventEntity();
                    if (!eventsDictionary.TryGetValue(alertResponse.EventId, out evnt))
                    {
                        EventLogger.WriteError(string.Format("Custom Error - Method : OnDelegateEventResponsesToConnect - Unable to find Event; Id = {0}", alertResponse.EventId));
                        //Make sure to process next event.
                        continue;
                    }


                    //Case 1: What if duplicate response text? Pick first responseId from List
                    EventResponseOption eventResponseOption = evnt.ResponseOptions.FirstOrDefault(a => a.ResponseText.Equals(alertResponse.ResponseText, StringComparison.InvariantCultureIgnoreCase));
                    if (eventResponseOption == null)
                    {
                        EventLogger.WriteError(string.Format("Custom Error - Mehod - OnDelegateEventResponsesToConnect - No Response Option available for eventId:{0}", alertResponse.EventId));
                        continue;
                    }

                    if (evnt.DeliveryContextInfo == null || string.IsNullOrEmpty(evnt.DeliveryContextInfo.DeliveryTaskId.ToString()))
                    {
                        EventLogger.WriteError(string.Format("Custom Error - Method - OnDelegateEventResponsesToConnect - No Delivery Context Id found in Event XML Data:{0}", alertResponse.EventId));
                        continue;
                    }
                    setMessageStatusPostParam.ResponseId = eventResponseOption.OptionId.ToString(CultureInfo.InvariantCulture);
                    setMessageStatusPostParam.MessageDeliveryStatus = MessageDeliveryStatus.Response;
                    setMessageStatusPostParam.Description = string.Empty;
                    setMessageStatusPostParam.SelfOrganizationToken = GetOrganizationToken(alertResponse.ProviderId);
                    setMessageStatusPostParam.ContextId = evnt.DeliveryContextInfo.DeliveryTaskId.ToString();

                    postParameters.Add(setMessageStatusPostParam);

                    eventDescription.EventId = alertResponse.EventId;
                    eventDescription.Description = alertResponse.ResponseText;
                    eventDescription.CreatedOn = DateTime.UtcNow;
                    eventDescription.UpdatedOn = DateTime.UtcNow;
                    eventDescription.SourceId = alertResponse.RespondedBy;
                    eventDescription.SourceType = SourceType;
                    eventDescription.Type = ResponseType;

                    eventDescriptions.Add(eventDescription);
                }

                Response<bool> res = MakeApiCall<bool>("messages/system/respond", null, true, postParameters);
                if (!res.IsSuccess)
                {
                    EventLogger.WriteError("'messages/system/respond' API  call Failed to send response option. - Method  OnDelegateEventResponsesToConnect");
                    return;
                }

                //Mark Event as Responded
                //Update Event Description table with Response Text and Responded by
                eventRepository.AddEventResponseOption(eventDescriptions);


            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Failed to run OnDelegateEventResponsesToConnect", ex);
            }


        }

        /// <summary>
        /// This method is called from ScheduledJob. Meant to migrate HubComm -> Invite type event data.
        /// This should execute only once. Later, the job itself should be disabled.
        /// </summary>
        public void MigrateHubCommEvents()
        {
            var organizationConnectionsByVpsId = new Dictionary<int, OrganizationConnection>();
            try
            {
                string actionNotRequiredEventIds = string.Empty;
                string actionRequiredEventIds = string.Empty;
                if (!GetCachedPssParams().IsPollServiceEnabled)
                {
                    // if polling agent is not enabled, no need to sync.
                    return;
                }

                var actionableEvents = new Dictionary<int, int>(); //Where EventId is Key, Provider id is value.
                var nonactionableEvents = new Dictionary<int, int>(); //Where EventId is Key, Provider id is value.

                var eventRepository = ServiceLocator.Resolve<IEventRepository>();
                var events = eventRepository.GetEventsFromDbView(true);

                var inviteEvents = events.Where(e => e.EventCategory.CommonName == "INVITE"
                    && (!e.ActionPerformed.HasValue || e.ActionPerformed.Value == ActionPerformed.ActionNotRequired)
                    && (!e.ReviewedBy.HasValue && !e.ReviewedOn.HasValue))
                    .Select(x => new { x.EventId, x.SourceId, x.EventCategory.ProviderId });

                foreach (var inviteEvent in inviteEvents)
                {
                    if (!organizationConnectionsByVpsId.ContainsKey(inviteEvent.ProviderId.Value))
                    {
                        //Get only Invitations and Agreement for current row ProviderId.
                        OrganizationConnection currentVpsOrgInvitation = GetConnections(inviteEvent.ProviderId.Value, includeAgreement: true, includeInvitation: true, includeExternalInvitation: false);
                        if (currentVpsOrgInvitation != null)
                        {
                            organizationConnectionsByVpsId.Add(inviteEvent.ProviderId.Value, currentVpsOrgInvitation);
                        }
                        else
                        {
                            //if no agreement or invitation found. that means events in no more valid.
                            nonactionableEvents.Add(inviteEvent.EventId, inviteEvent.ProviderId.Value);
                            continue;

                        }
                    }

                    OrganizationConnection vpsAgreementAndInvitations = null;

                    //Check if provider has any agreement/invitation. if not  then - make this event as actionable.
                    if (organizationConnectionsByVpsId.TryGetValue(inviteEvent.ProviderId.Value, out vpsAgreementAndInvitations))
                    {
                        //build currentVPS agreement list, keep OtherOrganizationGuid is key
                        var agreementDictBySourceGuid = vpsAgreementAndInvitations.Agreements.ToDictionary(o => o.OtherOrganizationGuid);


                        //check if current event - SourceOrganizationGUID is exists in current VPS agreement list.
                        if (agreementDictBySourceGuid.ContainsKey(inviteEvent.SourceId))
                        {
                            //if agreement exists between current event - SourceGuid and current Provider Id..Then no action required.
                            nonactionableEvents.Add(inviteEvent.EventId, inviteEvent.ProviderId.Value);
                        }
                        else
                        {
                            //Get Only Pending Invitation.
                            var invitationDictBySourceGuid = vpsAgreementAndInvitations.Invitations.Where(i => i.Status == OrganizationInvitationStatus.Pending).ToDictionary(o => o.InviterOrganizationGuid);
                            if (invitationDictBySourceGuid.ContainsKey(inviteEvent.SourceId))
                            {
                                //if agreement does not exists, but invitation exists then make current event as actionalbe.
                                actionableEvents.Add(inviteEvent.EventId, inviteEvent.ProviderId.Value);
                            }
                            else
                            {
                                nonactionableEvents.Add(inviteEvent.EventId, inviteEvent.ProviderId.Value);
                            }

                        }
                    }
                    else
                    {
                        nonactionableEvents.Add(inviteEvent.EventId, inviteEvent.ProviderId.Value);
                    }


                }

                foreach (var actionableEvent in actionableEvents)
                {
                    actionRequiredEventIds += actionableEvent.Key.ToString() + ",";
                    //Update Event Table
                    eventRepository.SetConnectActionFlag(actionableEvent.Key, ActionPerformed.ConnectRequestActionRequired, 1); //Where key is eventId, 1 is SystemAdmin operator Id
                }
                foreach (var nonactionableEvent in nonactionableEvents)
                {
                    actionNotRequiredEventIds += nonactionableEvent.Key.ToString() + ",";
                    //Update Event Table
                    eventRepository.SetConnectActionFlag(nonactionableEvent.Key, ActionPerformed.ActionNotRequired, 1); //Where key is eventId, 1 is SystemAdmin operator Id
                }

                EventLogger.WriteInformation(string.Format("Action required on EventId - {0}", actionRequiredEventIds));
                EventLogger.WriteInformation(string.Format("Action not required on EventId - {0}", actionNotRequiredEventIds));


                var scheduleJobFacade = ServiceLocator.Resolve<IScheduledEventFacade>();
                int jobid = 1010151;
                var isJobDisabled= scheduleJobFacade.DisableScheduleJob(jobid);
                if (isJobDisabled)
                {
                    EventLogger.WriteInformation(string.Format("Scheduled job disabled. Job Id - {0}", jobid));
                }
                else
                {
                    EventLogger.WriteWarning(string.Format("Make sure Job Id - {0} should be disabled after migration.", jobid));
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Error while Event Data Migration for Hubcomm events - ", ex);
            }
        }

        public void ExecuteJob()
        {
            OnSyncSystemUserBase();
        }


        private static Dictionary<int, object> _updateUserBaseLockByProvider = new Dictionary<int, object>();


        /// <summary>
        /// Make D911 Api call
        /// </summary>
        /// <typeparam name="T">Reponse Type</typeparam>
        /// <param name="methodName">Method Name</param>
        /// <param name="post">is HTTP POST?</param>
        /// <param name="parameters">Object parameter(s)</param>
        /// <returns>Response of Type T</returns>
        private Response<T> MakeApiCall<T>(String methodName, string selfToken, bool post = false, object parameters = null)
        {
            var pssParams = GetCachedPssParams();
            string apiUrl = string.Format(@"{0}/AtHoc.D911.OrganizationApi/v1/{1}", pssParams.PollingServiceUrl, methodName);
            if (EventLogger.IsVerboseEnabled)
            {
                EventLogger.WriteVerbose(string.Format("Making API call to: {0}", apiUrl));
            }
            try
            {
                using (var wc = pssParams.ConnectHttpCompressionEnabled ? new GzipWebClient() : new WebClient())
                {
                    SetCredentials(wc);
                    wc.Headers[HttpRequestHeader.ContentType] = "application/json";
                    wc.Headers["SelfToken"] = selfToken;
                    string HtmlResult = null;
                    if (post)
                    {
                        string parametersString = String.Empty;
                        using (MemoryStream ms = new MemoryStream())
                        {
                            DataContractJsonSerializer dcjs = new DataContractJsonSerializer(parameters.GetType());
                            dcjs.WriteObject(ms, parameters);
                            byte[] json = ms.ToArray();
                            parametersString = Encoding.UTF8.GetString(json, 0, json.Length);
                        }
                        wc.Encoding = Encoding.UTF8;
                        HtmlResult = wc.UploadString(apiUrl, parametersString);
                    }
                    else
                    {
                        HtmlResult = wc.DownloadString(apiUrl);
                    }

                    if (EventLogger.IsVerboseEnabled)
                    {
                        EventLogger.WriteVerbose(string.Format("API {0} ; Results: {1}", apiUrl, HtmlResult ?? ""));
                    }

                    Response<T> res = JsonConvert.DeserializeObject<Response<T>>(HtmlResult);
                    return res;
                }
            }
            catch (WebException wex)
            {
                // do somthing here                
                if (wex.Status == WebExceptionStatus.ProtocolError)
                {
                    HttpWebResponse response = (HttpWebResponse)wex.Response;
                    EventLogger.WriteError(string.Format("Failed to call api : {0}, Status Code : {1}, Description : {2}", apiUrl, response.StatusCode, response.StatusDescription), wex);
                }
                else
                {
                    EventLogger.WriteError(string.Format("Failed to call api : {0}", apiUrl), wex);
                }
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(string.Format("Failed to call api : {0}", apiUrl), ex);
            }

            return Response<T>.FailResponse("");
        }

        private PssConnectionParams GetCachedPssParams()
        {
            PssConnectionParams pssParams = OrganizationFacadeCache.GetInstance().GetPssConnectionParamCache(PssConnectionParams.ReadServerPollAgentSettingsFromTable);
            return pssParams;
        }

        private IDictionary<string, OrganizationInfo> GetCachedOrganizatios(int providerId)
        {
            // check cache first
            var cachedList = OrganizationFacadeCache.GetInstance().GetOrganizationListCache(providerId, () =>
            {
                var selfOrganizationToken = GetSelfOrganizationGuid(providerId);
                var myParameters = new GetOrganizationsPostParams()
                {
                    SearchCriteria = new OrganizationSearchCriteria() { SinceCheckpoint = "0" }
                };

                Response<GetOrganizationsResponse> res = MakeApiCall<GetOrganizationsResponse>("organizations/query", selfOrganizationToken, true, myParameters);
                if (!res.IsSuccess || res.Value == null)
                {
                    LogService.Current.Error(() => string.Format("failed to retrieve organization list. {0}", res.Error));
                    return null;
                }

                var orgById = new Dictionary<string, OrganizationInfo>();
                foreach (var organizationInfo in res.Value.Organizations)
                {
                    orgById.Add(organizationInfo.Guid, organizationInfo);
                }

                return orgById;
            }
            );

            return cachedList;
        }

        /// <summary>
        /// Returns organization Detail for the given guid(s)
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="guidList"></param>
        /// <returns></returns>
        private IDictionary<string, OrganizationInfo> GetCachedDetailOrganization(int providerId, IList<string> guidList)
        {

            if (guidList == null || guidList.Count == 0)
            {
                return null;
            }
            var retorgById = new Dictionary<string, OrganizationInfo>();
            var notReturnedFromCacheOrg = new List<string>();
            foreach (var orgGuid in guidList)
            {
                var orgInfo = OrganizationFacadeCache.GetInstance().GetOrganizationDetailCache(orgGuid);
                if (orgInfo != null)
                {
                    retorgById.Add(orgInfo.Guid, orgInfo);
                }
                else
                {
                    notReturnedFromCacheOrg.Add(orgGuid);
                }
            }
            if (notReturnedFromCacheOrg.Count > 0)
            {
                var selfOrganizationToken = GetSelfOrganizationGuid(providerId);
                var myParameters = new GetOrganizationsPostParams()
                {
                    SearchCriteria = new OrganizationSearchCriteria()
                    {
                        SinceCheckpoint = "0",
                        OrganizationGuidList = notReturnedFromCacheOrg
                    }
                };
                Response<GetOrganizationsResponse> res = MakeApiCall<GetOrganizationsResponse>("organizations/query", selfOrganizationToken, true, myParameters);
                if (!res.IsSuccess || res.Value == null)
                {
                    LogService.Current.Error(() => string.Format("failed to retrieve organization list. {0}", res.Error));
                    return null;
                }
                foreach (var organizationInfo in res.Value.Organizations)
                {
                    OrganizationFacadeCache.GetInstance().SetOrganizationDetailCache(organizationInfo.Guid, organizationInfo);
                    retorgById.Add(organizationInfo.Guid, organizationInfo);
                }
            }
            return retorgById;
        }

        private IDictionary<string, OrganizationSectorInfo> GetCachedOrganizationTypes(int providerId)
        {
            // check cache first
            var cachedList = OrganizationFacadeCache.GetInstance().GetOrganizationTypeCache(providerId, () =>
            {
                string token = GetSelfOrganizationGuid(providerId);
                Response<List<OrganizationSectorInfo>> res = MakeApiCall<List<OrganizationSectorInfo>>(string.Format("{0}", "systeminfo/organizationtypes"), token);
                if (!res.IsSuccess || res.Value == null)
                {
                    LogService.Current.Error(() => string.Format("failed to retrieve organization type list. {0}", res.Error));
                    return null;
                }

                var orgTypeById = new Dictionary<string, OrganizationSectorInfo>();
                foreach (var organizationSectorInfo in res.Value)
                {
                    orgTypeById.Add(organizationSectorInfo.Id.ToString(), organizationSectorInfo);
                }

                return orgTypeById;
            }
            );

            return cachedList;
        }
        private string GetUserName(string orgId)
        {
            return string.Format("{0}_{1}", "organization", orgId);
        }

        private string GetOrganizationGuidForUser(UserSearchResultItem u)
        {
            try
            {
                if (u == null)
                {
                    LogService.Current.Error(() => string.Format("failed to GetOrganizationGuidForUser. user is null "));
                    return null;
                }

                if (string.IsNullOrEmpty(u.UserName))
                {
                    LogService.Current.Error(() => string.Format("failed to GetOrganizationGuidForUser. username is empty or null, id: {0} ", u.Id));
                    return null;
                }
                //u.De.Select(x=>x.)
                return u.UserName.Split('_')[1];
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => string.Format("failed to GetOrganizationGuidForUser for username: {0} ", u.Id));
                LogService.Current.Error(() => ex);
            }
            return null;
        }

        private string GetOrganizationToken(int providerId)
        {
            var pssParams = GetCachedPssParams();
            return string.Format("{0};{1}", pssParams.Domain, providerId);
        }

        private void SetCredentials(WebClient wc)
        {
            var pssParams = GetCachedPssParams();
            var credentialString = string.Format("{0}:{1}:{2}", pssParams.Domain, pssParams.UserName, Encryptor.Decrypt(pssParams.DoubleEncrptedPassword)); // this is bad - dobule encript password ?!
            wc.Headers[UserAuthHttpHeader] = credentialString;
        }

        public IEnumerable<TargetableOrganization> GetActiveOrganization(int providerId = 0)
        {
            var deviceEndpoints = GetActiveOrganizationInformation(providerId);

            var ret = (from d in deviceEndpoints
                       select new TargetableOrganization
                       {
                           Name = d.DisplayName,
                           UserId = d.UserId,
                           Id = d.DeviceAddress
                       }).ToList();

            return ret;

        }

        public IEnumerable<MassDeviceTargetingResult> GetActiveOrganizationInformation(int providerId = 0)
        {
            var facade = new MassDeviceTargetingFacade();
            var orgDeviceCommonName = IacCommonName;

            var deviceEndpoints = facade.GetMassDeviceEndpoints(new MassDeviceTargetingSpec
            {
                ProviderId = providerId,
                DeviceCommonName = orgDeviceCommonName
            });

            return deviceEndpoints;
        }
    }

    public class PssConnectionParams
    {
        private const string PollingServiceUserNameKey = @"POLLING-SERVICE-USERNAME";
        private const string PollingServiceUserPasswordKey = @"POLLING-SERVICE-PASSWORD";
        private const string PollingServerUrlKey = @"POLLING-SERVICE-URL";
        private const string PollingServerRequiredKey = @"POLLING-SERVICE-REQUIRED";
        private const string ConnectHttpCompression = "CONNECT-HTTP-COMPRESSION-ENABLED";
        private const string EventResponseBatchCountKey = "EVENT-RESPONSE-BATCH-COUNT";

        public string UserName { get; set; }
        public string Domain { get; set; }
        public string PollingServiceUrl { get; set; }
        public string DoubleEncrptedPassword { get; set; }
        public bool IsPollServiceEnabled { get; set; }

        /// <summary>
        /// This flag will be set "yes" by default but "no" for 
        /// cloud-hosted iws deployment
        /// </summary>
        public bool ConnectHttpCompressionEnabled { get; private set; }

        /// <summary>
        /// Used for throttling alert's event responses
        /// by default set to 100
        /// </summary>
        public int EventResponseBatchCount { get; private set; }

        /// <summary>
        /// fetch/set the basic communication parameters from the database in order to call Hub API
        /// </summary>

        public static PssConnectionParams ReadServerPollAgentSettingsFromTable()
        {
            PssConnectionParams pssParams = new PssConnectionParams();
            try
            {
                pssParams.UserName = AtHocSystem.Local.Configuration.GetValue(PollingServiceUserNameKey);
            }
            catch (ApplicationException ex)
            {
                LogService.Current.Error(() => ex);

            }

            try
            {
                pssParams.Domain = AtHocSystem.Local.Configuration.GetValue("SYSTEM_ID");
            }
            catch (ApplicationException ex)
            {
                LogService.Current.Error(() => ex);
            }

            try
            {
                pssParams.DoubleEncrptedPassword = AtHocSystem.Local.Configuration.GetValue(PollingServiceUserPasswordKey);
            }
            catch (Exception ex)
            {

                LogService.Current.Error(() => ex);
            }
            try
            {
                pssParams.PollingServiceUrl = AtHocSystem.Local.Configuration.GetValue(PollingServerUrlKey);
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
            }

            try
            {
                pssParams.IsPollServiceEnabled = "yes".Equals(AtHocSystem.Local.Configuration.GetValue(PollingServerRequiredKey), StringComparison.InvariantCultureIgnoreCase);
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(ex);
                pssParams.IsPollServiceEnabled = false;
            }

            try
            {
                pssParams.ConnectHttpCompressionEnabled = !("no".Equals(AtHocSystem.Local.Configuration.GetValue(ConnectHttpCompression),
                        StringComparison.InvariantCultureIgnoreCase));
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(ex);
                pssParams.ConnectHttpCompressionEnabled = true;
            }

            try
            {
                pssParams.EventResponseBatchCount = int.Parse(AtHocSystem.Local.Configuration.GetValue(EventResponseBatchCountKey));
            }
            catch (Exception ex)
            {
                EventLogger.WriteError(ex);
                pssParams.EventResponseBatchCount = 100;
            }
            return pssParams;
        }
    }



    /// <summary>
    /// Standalone Implementation of IRuntimeContext.
    /// This is required for background job, which does not have HTTPContext, thus explictly Implement IRuntimecontext with only required property.
    /// DI won't work, in case of background job.
    /// </summary>
    public class StandAloneRuntimeContext : IRuntimeContext
    {
        public StandAloneRuntimeContext()
        {
            
            Provider = new Provider { Id = 1,BaseLocale = "en-US"};
            Operator = new OperatorUser
            {
                Id = 1,
                Username = "athocadmin",
                OperatorAccess = new List<OperatorAccess>
				{
					new OperatorAccess { ActionType = ActionType.Modify, ObjectId = (int) SystemObject.Organization },
					new OperatorAccess { ActionType = ActionType.View, ObjectId = (int) SystemObject.Organization}
				}
            };
        }

        public Provider Provider { get; private set; }

        public OperatorUser Operator { get; private set; }
        public User LoggedOnUser { get; private set; }

        public OperatorUser RefreshedOperatorContext() { return null; }

        public Provider RefreshedProviderContext() { return null; }

    }
}
