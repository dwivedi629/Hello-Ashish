﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Domain.Entities.Search;


namespace AtHoc.IWS.Business.Domain.RuleProcessor
{
    public static class StringEvaluator
    {
        public static bool Evaluate(string lhs, SearchOperators searchOperator, string rhs = null)
        {
            // split
            // value might be comma seperated, and null
            return EvaluateImpl(lhs, searchOperator, rhs);

        }
        private static bool EvaluateImpl(string lhs, SearchOperators searchOperator, string rhs = null)
        {
            if (!string.IsNullOrEmpty(lhs))
            {
                lhs = lhs.Trim();
            }
            IEnumerable<string> rhsArray = null;
            if (rhs != null)
            {
                //Condition value can have (COMMA) which considered as OR operator.
                rhsArray = rhs.Split(',').Select(a => a.Trim());
            }

            // value is single value or null l
            switch (searchOperator)
            {
                case SearchOperators.Equals:
                    {
                        if (string.IsNullOrEmpty(lhs) && string.IsNullOrEmpty(rhs))
                        {
                            return true;
                        }
                        if (rhsArray != null)
                        {
                            foreach (var s in rhsArray)
                            {
                                if (s.Trim().Equals(lhs, StringComparison.CurrentCultureIgnoreCase))
                                {
                                    return true;
                                }
                            }
                        }
                        return false;
                    }

                case SearchOperators.NotEquals:
                    {
                        if (string.IsNullOrEmpty(lhs) || string.IsNullOrEmpty(rhs))
                        {
                            return true;
                        }
                        foreach (var s in rhsArray)
                        {
                            if (s.Equals(lhs, StringComparison.CurrentCultureIgnoreCase))
                            {
                                return false;
                            }
                        }
                        return true;

                    }
                    break;
                case SearchOperators.StartsWith:
                    {
                        if (string.IsNullOrEmpty(lhs) && string.IsNullOrEmpty(rhs))
                        { return false; }
                        if (rhsArray == null) return false;
                        foreach (var s in rhsArray)
                        {
                            if (lhs != null && lhs.Trim().StartsWith(s, StringComparison.CurrentCultureIgnoreCase))
                            {
                                return true;
                            }
                        }
                        return false;

                    }
                case SearchOperators.EndsWith:
                    {
                        if (string.IsNullOrEmpty(lhs) && string.IsNullOrEmpty(rhs))
                        {
                            return false;
                        }
                        if (rhsArray == null) return false;
                        foreach (var s in rhsArray)
                        {
                            if (lhs != null && lhs.Trim().EndsWith(s, StringComparison.CurrentCultureIgnoreCase))
                            {
                                return true;
                            }
                        }
                        return false;
                    }
                case SearchOperators.Contains:
                    {
                        if (string.IsNullOrEmpty(lhs) && string.IsNullOrEmpty(rhs))
                        {
                            return false;
                        }
                        if (rhsArray == null) return false;
                        foreach (var s in rhsArray)
                        {
                            if (lhs != null && lhs.ToLower().Contains(s.ToLower()))
                            {
                                return true;
                            }
                        }
                        return false;
                    }
                case SearchOperators.NotContains:
                    {
                        if (string.IsNullOrEmpty(lhs) || string.IsNullOrEmpty(rhs))
                        {
                            return true;
                        }

                        foreach (var s in rhsArray)
                        {
                            if (lhs.ToLower().Contains(s.ToLower()))
                            {
                                return false;
                            }
                        }
                        return true;
                    }
                case SearchOperators.IsEmpty:
                    return lhs.IsNullOrEmpty(true);
                case SearchOperators.IsNotEmpty:
                    return lhs.IsNotNullOrEmpty(true);
                default:
                    return false;
            }
        }

        
    }
}
