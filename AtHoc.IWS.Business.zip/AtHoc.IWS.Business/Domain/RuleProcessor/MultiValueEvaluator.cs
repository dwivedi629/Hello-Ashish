﻿using System.Collections.Generic;
using System.Linq;
using AtHoc.IWS.Business.Domain.Entities.Search;
using AtHoc.Utilities;

namespace AtHoc.IWS.Business.Domain.RuleProcessor
{
    public static class MultiValueEvaluator
    {
        public static bool Evaluate(string lhs, SearchOperators searchOperator, IList<string> rhs = null)
        {
            return EvaluateImpl(lhs, searchOperator, rhs);

        }

        private static bool EvaluateImpl(string lhs, SearchOperators searchOperator, IList<string> rhs = null)
        {
            bool result = false;
            // value is single value or null l
            switch (searchOperator)
            {
                case SearchOperators.Equals:
                    result = rhs != null && rhs.Contains(lhs);
                    break;
                case SearchOperators.NotEquals:
                {
                    result = !rhs.Contains(lhs);
                    break;
                }
                case SearchOperators.IsEmpty:
                    result = string.IsNullOrEmpty(lhs);
                    break;
                case SearchOperators.IsNotEmpty:
                    result = !string.IsNullOrEmpty(lhs);
                    break;
                case SearchOperators.Contains:
                {
                    if (rhs != null)
                    {
                        foreach (var s in rhs)
                        {
                            if (lhs != null && lhs.ToLower().Contains(s.ToLower()))
                            {
                                return true;
                            }
                        }
                    }
                    return false;
                }
            }
            return result;
        }
    }
}
