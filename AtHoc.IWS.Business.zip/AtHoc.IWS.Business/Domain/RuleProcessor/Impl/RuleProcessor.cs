﻿using System;
using System.Collections.Generic;
using System.Linq;
using AtHoc.Diagnostics;
using AtHoc.IWS.Business.Domain.Entities;
using ActionType = AtHoc.IWS.Business.Domain.Entities.Rule.Enum.ActionType;
using Rule = AtHoc.IWS.Business.Domain.RuleModel;

namespace AtHoc.IWS.Business.Domain.RuleProcessor
{
     /// <summary>
     /// Implementation of IRuleProcessor
     /// </summary>
    public class RuleProcessor : IRuleProcessor
    {
        #region VARIABLES
        private IEnumerable<Rule.Rule> _ruleSet;
        private Rule.IRuleOperandProvider _ruleOperandProvider;
        private Rule.IRuleExecutionProvider _ruleExecutionProvider;
        private IDictionary<ActionType, Rule.IRuleActionExecutor> _actionExecutors;
        
        
        #endregion

         /// <summary>
         /// Setup the Fact for rules. 
         /// </summary>
         /// <param name="ruleSet">Set of Rules</param>
         /// <param name="ruleOperandProvider">OperandValue Provider. </param>
         /// <param name="ruleExecutionProvider">Rule Action Provider.</param>
         public void Init(IEnumerable<Rule.Rule> ruleSet,  Rule.IRuleOperandProvider ruleOperandProvider, Rule.IRuleExecutionProvider ruleExecutionProvider)
        {
            _ruleSet = ruleSet;
            _ruleOperandProvider = ruleOperandProvider;
            _ruleExecutionProvider = ruleExecutionProvider;
            _actionExecutors = _ruleExecutionProvider.GetRuleActionExecutionSet();
            
        }
        


        /// <summary>
        /// Execute the Rule
        /// </summary>
        /// <param name="executionContext">Execution context can contain providerid, event and other required context information to execute the action.</param>
        /// <param name="matchingRules">List of Matching Rules.</param>
        /// <returns></returns>
        public bool Execute(object executionContext, out List<Rule.Rule> matchingRules)
        {
            //Temp collection to store the rules which matches the condition.
            matchingRules = new List<Rule.Rule>();

            //Iterate the rule(s) and make sure the rule processing is done as per the sort-order set.
            foreach (var rule in _ruleSet.OrderBy(a => a.Order))
            {
                if (rule.Criterias == null)
                {
                    EventLogger.WriteInformation(string.Format("No Criteria defined for Rule - {0}",rule.Name));
                    continue;
                }
                //Evaluate each rule - Pass the list of Criterias (Condition), operand provider, execution Context.
                var isMatch = Evaluate(rule.Criterias, _ruleOperandProvider, executionContext);
                
                //If rule satisfied the condition, then add the rule to temparory list
                if (isMatch)
                {
                    matchingRules.Add(rule);
                    
                    //Execute the each action associated to matched rule.
                    foreach (var ruleAction in rule.Actions)
                    {
                        //Action has been implemented as client (i.e. IncomingAlertPlugin - at polling agent)
                        Rule.IRuleActionExecutor actionExecutor;

                        if (_actionExecutors == null)
                        {
                            EventLogger.WriteError(string.Format("No Action Executor Implemented for Action {0}.",ruleAction.ActionName));
                            continue;
                        }

                        if (!_actionExecutors.TryGetValue(ruleAction.ActionName, out actionExecutor))
                        {
                            EventLogger.WriteError("Action Executor is not defined. Make sure to add ActionTYpe and associated executor while initialize the rule processor. Make IncomingALertRulePlugin.cs and INIT method.");
                            continue;
                        }

                        try
                        {
                            //Execute the action associated to matched Rule.
                            bool isSuccess = actionExecutor.ExecuteAction(rule, ruleAction, executionContext);
                            if (isSuccess)
                            {
                                if (EventLogger.IsVerboseEnabled)
                                {
                                    string actionKeyValues = string.Empty;
                                    foreach (var a in ruleAction.ActionValues)
                                    {
                                        actionKeyValues += string.Format("Key ->{0} & Value -> {1} | ", a.Key, a.Value);
                                    }
                                   
                                    EventLogger.WriteVerbose(
                                        string.Format("Action executed successfully for RULE - {0},  Action - {1}, ActionKeyValues - {2} ",
                                            rule.Name, ruleAction.ActionName,actionKeyValues));
                                }
                            }
                            else
                            {
                                
                                string actionKeyValues = string.Empty;
                                foreach (var a in ruleAction.ActionValues)
                                {
                                    actionKeyValues += string.Format("Key ->{0} & Value -> {1} | ", a.Key, a.Value);
                                }
                                   
                                EventLogger.WriteWarning(string.Format("Action execution failed for RULE - '{0}', and Action - '{1}', ActionKeyvalues are {2}. ", rule.Name, ruleAction.ActionName, actionKeyValues));
                            }
                            
                        }
                        catch (Exception ex)
                        {
                            EventLogger.WriteError(string.Format("Error while execution rule action. - {0}, and Action - {1} ", rule.Name, ruleAction.ActionName),ex);
                        }

                    }

                    //Make sure rule should stop when Stop Processing Flag is true 
                    if (rule.StopProcessing)
                    {
                        break;
                    }
                }
                //else //Rule condition fails - check if Stop Processing flag is true. If True then no more rule should execute.
                //{
                //    if (rule.StopProcessing)
                //    {
                //        break;
                //    }
                //}
            }
            return true;
        }


        /// <summary>
        /// Evaluate the rule Condition.
        /// </summary>
        /// <param name="ruleCriterias">List of Conditions</param>
        /// <param name="ruleOperandProvider">Operand Provider</param>
        /// <param name="executionContext">Execution context (it contain info like event, providerId etc.)</param>
        /// <returns></returns>
        private bool Evaluate(IEnumerable<Rule.RuleCriteria> ruleCriterias, Rule.IRuleOperandProvider ruleOperandProvider, object executionContext)
        {
            if (ruleCriterias == null)
            {
                EventLogger.WriteError(string.Format("Argument '{0}' Cannot be null", "ruleCriterias"));
                return false;
            }
            if (ruleOperandProvider == null)
            {
                EventLogger.WriteError(string.Format("Argument '{0}' Cannot be null", "ruleOperandProvider"));
                return false;
            }
            if (executionContext == null)
            {
                EventLogger.WriteError(string.Format("Argument '{0}' Cannot be null", "executionContext"));
                return false;
            }
            //Iterate each condition.
            foreach (var ruleCriteria in ruleCriterias)
            {
                //Get the operand type for Execution Context. e.g. String, MultipickLIst,Numeric. (referenced to GLB_ATTRIBUTE_TYPE_TAB in DB)
                var operantType = ruleOperandProvider.GetOperandType(ruleCriteria.AttributeName, executionContext);
                if (operantType == null)
                {
                    EventLogger.WriteError(string.Format("Operand type cannot be null for attribute {0}",ruleCriteria.AttributeName));
                    return false;
                }
                bool isConditionMatch;
                
                if (operantType.Value == CustomAttributeDataType.String)
                {
                    //get operand value i.e. EventTitle, EventBody, Severity,Type etc for execution context and assign to LHV (Left hand Value)
                    var lhv = ruleOperandProvider.GetOperandValue<string>(ruleCriteria.AttributeName, executionContext);
                    
                    //Get the Rule Criteria RHS Value ie. Title ="Some Title" which is stored while creating rules.
                    var rhv = ruleCriteria.AttributeValue;
                    string ruleCondition = string.Empty;
                    if (rhv != null && rhv.Count > 0)
                    {
                        ruleCondition = string.Join(",", rhv);
                    }

                    //Make sure Compare the LHS and RHS. For STRING type is will always contain only one value thus rhv[0] is used.
                    isConditionMatch = StringEvaluator.Evaluate(lhv, ruleCriteria.Operator, ruleCondition);
                    if (!isConditionMatch)
                    {
                        return false;
                    }

                }
                else if (operantType.Value == CustomAttributeDataType.MultiPicklist) // multiple selection
                {
                    var lhv = ruleOperandProvider.GetOperandValue<string>(ruleCriteria.AttributeName, executionContext);
                    var rhv = ruleCriteria.AttributeValue;

                    //Make sure Compare the LHS and RHS. For MultiPickLIst type is will be one or many value thus rhv collection is used.
                    isConditionMatch = MultiValueEvaluator.Evaluate(lhv, ruleCriteria.Operator, (rhv == null || rhv.Count == 0 ? null : rhv));
                    
                    
                    if (!isConditionMatch)
                    {
                        return false;
                    }
                }
                else 
                {
                    EventLogger.WriteError(string.Format("Evualuator not implement for CustomAttributeDataType EQUALS {0}",operantType.Value));
                    return false;
                }

            }
            return true;
        }

    }

}