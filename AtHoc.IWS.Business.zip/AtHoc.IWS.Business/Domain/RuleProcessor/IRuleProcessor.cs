﻿using System;
using System.Collections.Generic;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.RuleProcessor
{
    public interface IRuleProcessor
    {
        /// <summary>
        /// Setup the Fact for rules. 
        /// </summary>
        /// <param name="ruleSet">Set of Rules</param>
        /// <param name="ruleOperandProvider">OperandValue Provider. </param>
        /// <param name="ruleExecutionProvider">Rule Action Provider.</param>
        void Init(IEnumerable<RuleModel.Rule> ruleSet, RuleModel.IRuleOperandProvider ruleOperandProvider, RuleModel.IRuleExecutionProvider ruleExecutionProvider);


        /// <summary>
        /// Execute the Rule
        /// </summary>
        /// <param name="executionContext">Execution context can contain providerid, event and other required context information to execute the action.</param>
        /// <param name="matchingRules">List of Matching Rules.</param>
        /// <returns>Boolean Success/Fail</returns>
        bool Execute(object executionContext, out List<RuleModel.Rule> matchingRules);
    }
}
