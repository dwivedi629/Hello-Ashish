﻿using System;
using System.Data;

using AtHoc.Business.Domain;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Sql;
using AtHoc.IWS.Business.Domain.Audit;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Database
{
	public partial class NgaddataDbContext
	{
		public override object ObjectToDbValue(SqlParameter parameter, SqlDbType sqlDbType, string udtTypeName)
		{
			var dbValue = (object) null;
			if (sqlDbType == SqlDbType.NVarChar || sqlDbType == SqlDbType.VarChar)
			{
				if (parameter.Value is UserStatusType)
				{
					dbValue = GetEnumToDbValue<UserStatusType>(parameter);
				}
				else if (parameter.Value is CustomViewType)
				{
					dbValue = GetEnumToDbValue<CustomViewType>(parameter);
				}
				else if (parameter.Value is CustomViewColumnType)
				{
					dbValue = GetEnumToDbValue<CustomViewColumnType>(parameter);
				}
				else if (parameter.Value is ListItemType)
				{
					dbValue = GetEnumToDbValue<ListItemType>(parameter);
				}
				else if (parameter.Value is ActionType)
				{
					dbValue = (int) ((ActionType) parameter.Value);
				}
				else if (parameter.Value is ListStatus)
				{
					dbValue = GetEnumToDbValue<ListStatus>(parameter);
				}
				else if (parameter.Value is EntityType)
				{
					dbValue = GetEnumToDbValue<EntityType>(parameter);
				}
				else if (parameter.Value is ServiceAction)
				{
					dbValue = GetEnumToDbValue<ServiceAction>(parameter);
				}
				else if (parameter.Value is AlertDeliveryStatus)
				{
					dbValue = GetEnumToDbValue<AlertDeliveryStatus>(parameter);
				}
				else if (parameter.Value is SheduledEventStatusType)
				{
					dbValue = GetEnumToDbValue<SheduledEventStatusType>(parameter);
				}
				else if (parameter.Value is DistributionListStatusType)
				{
					dbValue = GetEnumToDbValue<DistributionListStatusType>(parameter);
				}
				else if (parameter.Value is UserImportStatusType)
				{
					dbValue = GetEnumToDbValue<UserImportStatusType>(parameter);
				}
				else if (parameter.Value is bool)
				{
					dbValue = (bool) parameter.Value ? 'Y' : 'N';
				}
			}
			else if (parameter.Value is IntDateTime)
			{
				dbValue = (int)((IntDateTime)parameter.Value);
			}
			return dbValue ?? base.ObjectToDbValue(parameter, sqlDbType, udtTypeName);
		}

		public override object DbValueToObject(object dbValue, MetaProperty metaProperty)
		{
			object value = null;

			if (dbValue != null && dbValue != DBNull.Value && metaProperty != null)
			{
				var propertyType = metaProperty.PropertyType.IsNullable()
					? Nullable.GetUnderlyingType(metaProperty.PropertyType)
					: metaProperty.PropertyType;

				if (propertyType == typeof (UserStatusType))
				{
					value = GetDbToEnumValue<UserStatusType>(dbValue);
				}
				else if (propertyType == typeof (CustomViewType))
				{
					value = GetDbToEnumValue<CustomViewType>(dbValue);
				}
				else if (propertyType == typeof (CustomViewColumnType))
				{
					value = GetDbToEnumValue<CustomViewColumnType>(dbValue);
				}
				else if (propertyType == typeof (ListItemType))
				{
					value = GetDbToEnumValue<ListItemType>(dbValue);
				}
				else if (propertyType == typeof (ActionType))
				{
					value = (ActionType) (dbValue);
				}
				else if (propertyType == typeof (ListStatus))
				{
					value = GetDbToEnumValue<ListStatus>(dbValue);
				}
				else if (propertyType == typeof(EntityType))
				{
					value = GetDbToEnumValue<EntityType>(dbValue);
				}
				else if (propertyType == typeof (ServiceAction))
				{
					value = GetDbToEnumValue<ServiceAction>(dbValue);
				}
				else if (propertyType == typeof(AlertDeliveryStatus))
				{
					value = GetDbToEnumValue<AlertDeliveryStatus>(dbValue);
				}
				else if (propertyType == typeof(DistributionListDependencyType))
				{
					value = GetDbToEnumValue<DistributionListDependencyType>(dbValue);
				}
				else if (propertyType == typeof(UserImportStatusType))
				{
					value = GetDbToEnumValue<UserImportStatusType>(dbValue);
				}
				else if (propertyType == typeof(SheduledEventStatusType))
				{
					value = GetDbToEnumValue<SheduledEventStatusType>(dbValue);
				}
				else if (propertyType == typeof(DistributionListStatusType))
				{
					value = GetDbToEnumValue<DistributionListStatusType>(dbValue);
				}
				else if (propertyType == typeof (IntDateTime))
				{
					value = (IntDateTime)((int)dbValue);
				}
			}

			return value ?? base.DbValueToObject(dbValue, metaProperty);
		}

		private static string GetEnumToDbValue<T>(SqlParameter parameter)
		{
			return EnumUtils<T>.GetDescriptionByValue((T) parameter.Value);
		}

		private static T GetDbToEnumValue<T>(object dbValue)
		{
			if (dbValue is int)
			{
				return (T) dbValue;
			}
			return EnumUtils<T>.GetValueByDescription(dbValue.ConvertTo<string>());
		}
	}
}