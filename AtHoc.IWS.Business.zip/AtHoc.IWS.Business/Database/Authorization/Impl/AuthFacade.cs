﻿using AtHoc.Infrastructure.Domain;

using AtHoc.IWS.Business.Data;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Users.Spec;

namespace AtHoc.IWS.Business.Domain.Authorization.Impl
{
	public class AuthFacade : FacadeBase<IAtHocContextFactory>, IAuthFacade
	{
		private readonly IOperatorDetailsFacade _operatorFacade;

		public AuthFacade(IAtHocContextFactory contextFactory, IOperatorDetailsFacade operatorFacade) : base(contextFactory)
		{
			_operatorFacade = operatorFacade;
		}

	    public bool HasAccess(OperatorUser operatorUser, int providerId, SystemObject systemObject, ActionType actionType)
	    {
            if (operatorUser == null)
                return false;

            operatorUser.OperatorAccess = _operatorFacade.GetOperatorAccess(new OperatorAccessSpec { OperatorId = operatorUser.Id, ProviderId = providerId });
            return operatorUser.OperatorAccess != null && operatorUser.HasPermission(systemObject, actionType);
	    }

	    public bool HasAccess(int operatorId, int providerId, SystemObject systemObject, ActionType actionType)
		{
			var operatorUser = _operatorFacade.GetOperatorUserBySpec(new OperatorUserSpec { OperatorId = operatorId , ExcludeDeleted = true});
	        return HasAccess(operatorUser, providerId, systemObject, actionType);
		}

		public bool HasAccess(int userId, int roleId)
		{
			return true;
		}
	}
}