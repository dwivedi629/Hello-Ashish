﻿using System.Collections.Generic;
using System.Linq;

using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain.Authorization
{
	public static class OperatorAccessExtenstion
	{
		public static bool HasPermission(this IEnumerable<OperatorAccess> operatorAccess, SystemObject systemObject, ActionType actionType)
		{
			return operatorAccess.Any(a => EnumUtils<SystemObject>.Equals(a.ObjectId, systemObject) && a.ActionType.Equals(actionType));
		}

		public static bool HasPermission(this IAccessProvider accessProvider, SystemObject systemObject, ActionType actionType)
		{
			return accessProvider.OperatorAccess.HasPermission(systemObject, actionType);
		}
	}
}
