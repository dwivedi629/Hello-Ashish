﻿using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Database;
using AtHoc.Infrastructure.Sql;

using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Domain
{
	public interface IGlobalSecurityPolicyRepository : IRepository<GlobalSecurityPolicy, GlobalSecurityPolicySpec> { }

	public class GlobalSecurityPolicyDbRepository : DbRepository<GlobalSecurityPolicy, GlobalSecurityPolicySpec>, IGlobalSecurityPolicyRepository
	{
		public GlobalSecurityPolicyDbRepository(IUnitOfWork context) : base(context) {}

		protected override void TranslateSpec(GlobalSecurityPolicySpec spec, SqlBuilder builder, bool query)
		{
			builder.SelectAll<GlobalSecurityPolicy>();
			builder.From(builder.Table<GlobalSecurityPolicy>());
		}
	}
}
