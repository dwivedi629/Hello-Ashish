﻿using AtHoc.Infrastructure.Entity;

namespace AtHoc.IWS.Business.Domain
{
	public class GlobalSecurityPolicySpec : EntitySpec {}
}
