﻿using AtHoc.IWS.Business.Configurations;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel;
using AtHoc.IWS.Business.Domain.Entities.Rule;
using AtHoc.IWS.Business.Domain.Entities.Search;
using AtHoc.IWS.Business.Domain.Notification;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Mappings;
using AtHoc.Publishing;
using SearchEntity = AtHoc.IWS.Business.Domain.Entities.Search.SearchEntity;
using AtHoc.IWS.Business.Domain.Audit;
using AtHoc.IWS.Business.Domain.Entities.Accountability;
using AtHoc.IWS.Business.Domain;

namespace AtHoc.IWS.Business.Database
{
    public class AtHocDbContext : DbContext
    {
        public AtHocDbContext() : base(AtHocConfigService.Current.NgaddataConnStr) { }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {

            //Define mapping 
            modelBuilder.Configurations.Add(new SystemSettingMapping());
            modelBuilder.Configurations.Add(new GlobalConfigurationMapping());
            modelBuilder.Configurations.Add(new GlobalSecurityMapping());
            modelBuilder.Configurations.Add(new ProviderSettingsMapping());
            modelBuilder.Configurations.Add(new AudioFilesMapping());
            modelBuilder.Configurations.Add(new DeliveryTemplateMapping());
            modelBuilder.Configurations.Add(new DeviceMapping());
            modelBuilder.Configurations.Add(new DevicGroupMapping());
            modelBuilder.Configurations.Add(new ShapeNotificationMapping());
            modelBuilder.Configurations.Add(new MapLayerMapping());
            modelBuilder.Configurations.Add(new AlertMapping());
            modelBuilder.Configurations.Add(new ResponseNotificationMapping());
            modelBuilder.Configurations.Add(new UserMapping());
            modelBuilder.Configurations.Add(new PeopleNotificationMapping());
            modelBuilder.Configurations.Add(new LastLocationMapping());
            modelBuilder.Configurations.Add(new ProviderExtendedMapping());
            modelBuilder.Configurations.Add(new TargetingSettingsMapping());
            modelBuilder.Configurations.Add(new ProviderConfigurationMapping());            
            modelBuilder.Configurations.Add(new UserBaseMapping());
            modelBuilder.Configurations.Add(new PdlHierarchyMapping());
            modelBuilder.Configurations.Add(new PdlListMapping());
            modelBuilder.Configurations.Add(new SecurityPolicyMapping());
            modelBuilder.Configurations.Add(new SystemParametersMapping());
            modelBuilder.Configurations.Add(new ChannelMapping());
            modelBuilder.Configurations.Add(new AgentSettingsMapping());
            modelBuilder.Configurations.Add(new RuleEntityMapping());
            modelBuilder.Configurations.Add(new RuleActionEntityMapping());
            modelBuilder.Configurations.Add(new RuleActionValueEntityMapping());
            modelBuilder.Configurations.Add(new LanguageMap());
            modelBuilder.Configurations.Add(new SearchEntityMapping());
            modelBuilder.Configurations.Add(new SearchCriteriaEntityMapping());
            modelBuilder.Configurations.Add(new SearchQueryEntityMapping());
            modelBuilder.Configurations.Add(new SearchQueryValueEntityMapping());
            modelBuilder.Configurations.Add(new AuditEntityMapping());
            modelBuilder.Configurations.Add(new AuditActionMapping());
            modelBuilder.Configurations.Add(new ProviderLocaleMapping());

            modelBuilder.Configurations.Add(new AccountabilityEventMapping());
            modelBuilder.Configurations.Add(new AccountabilityEventSummaryTrackingMapping());
            modelBuilder.Configurations.Add(new AccountabilityTemplateMapping());
            modelBuilder.Configurations.Add(new AccountabilityEventAlertsMapping());
            modelBuilder.Configurations.Add(new AccountabilityEventUserStatusMapping());
            modelBuilder.Configurations.Add(new AccountabilityEventRecipientMapping());
            modelBuilder.Configurations.Add(new AccountabilityTemplateAlertMapEntityMapping());
            modelBuilder.Configurations.Add(new AccountabilityEventPickupScheduleEntityMapping());
            modelBuilder.Configurations.Add(new AccountabilityEventRecipientArchiveMapping());
            modelBuilder.Configurations.Add(new AccountabilityEventAlertMapEntityMapping());
            modelBuilder.Configurations.Add(new DeviceGatewayMapping());
            base.OnModelCreating(modelBuilder);
        }
        public DbSet<ProviderLocaleSettings> ProviderLocaleSettings { get; set; }
        public DbSet<ChannelSettings> ChannelSettings { get; set; }
        public DbSet<SecurityPolicySettings> SecurityPolicySettings { get; set; }
        public DbSet<PldHierarchySettings> PldHierarchySettings { get; set; }
        public DbSet<PdlListSettings> PldListSettings { get; set; }
        public DbSet<UserBaseSettings> UserBaseSettings { get; set; }
        public DbSet<ProviderExtendedSettings> ProviderExtendedSettings { get; set; }
        public DbSet<ProviderSettings> ProviderSettings { get; set; }
        public DbSet<SystemSetting> SystemSettings { get; set; }
        public DbSet<GlobalConfigurationSettings> GlobalConfigurationSettings { get; set; }
        public DbSet<GlobalSecuritySettings> GlobalSecuritySettings { get; set; }
        public DbSet<AudioFileSettings> AudioFileSettings { get; set; }
        public DbSet<DeliveryTemplateSettings> DeliveryTemplateSettings { get; set; }

        public DbSet<Language> Language { get; set; }
        public DbSet<DeviceSettings> DeviceSettings { get; set; }
        public DbSet<DeviceGroupSettings> DeviceGroupSettings { get; set; }
        public DbSet<ShapeNotification> ShapeNoticaNotifications { get; set; }
        public DbSet<AlertNotification> AlertNoticaNotifications { get; set; }
        public DbSet<ResponseNotification> ResponseNoticaNotifications { get; set; }
        public DbSet<PeopleNotification> PeopleNotifications { get; set; }
        public DbSet<LastLocation> LastLocation { get; set; }
        public DbSet<MapLayer> MapLayers { get; set; }
        public DbSet<TargetingSettings> TargetingSetting { get; set; }
        public DbSet<ProviderConfigurationSettings> ProviderConfigurationSetting { get; set; }
        public DbSet<SystemParameters> SystemParameters { get; set; }
        public DbSet<AgentSettings> AgentSettings { get; set; }

        public DbSet<RuleEntity> Rules { get; set; }
        public DbSet<RuleActionEntity> RuleActions { get; set; }
        public DbSet<RuleActionValueEntity> RuleActionValues { get; set; }
        public DbSet<SearchCriteriaEntity> SearchCriterias { get; set; }
        public DbSet<SearchEntity> SearchEntities { get; set; }
        public DbSet<SearchQueryEntity> SearchQueryEntities  { get; set; }
        public DbSet<SearchQueryValueEntity> SearchQueryValueEntities { get; set; }
        public DbSet<AuditEntity> AuditEntity{ get; set; }
        public DbSet<AuditAction> AuditAction { get; set; }

        public virtual DbSet<AccountabilityTemplateEntity> AccountabilityTemplateEntities { get; set; }
        public virtual DbSet<AccountabilityEventEntity> AccountabilityEventEntities { get; set; }

        public virtual DbSet<AccountabilityEventSummaryTrackingEntity> AccountabilityEventSummaryTrackingEntities { get; set; }
        public virtual DbSet<AccountabilityEventAlertEntity> AccountabilityEventAlertEntities { get; set; }
        public virtual DbSet<AccountabilityEventUserStatusEntity> AccountabilityEventUserStatusEntities { get; set; }
        public virtual DbSet<AccountabilityEventRecipientEntity> AccountabilityEventRecipientEntities { get; set; }

        public virtual DbSet<AccountabilityEventAlertMapEntity> AccountabilityEventAlertMapEntities { get; set; }
        public virtual DbSet<AccountabilityEventPickupScheduleEntity> AccountabilityEventPickupScheduleEntities { get; set; }
        public virtual DbSet<AccountabilityEventRecipientArchiveEntity> AccountabilityEventRecipientArchiveEntities { get; set; }
        public virtual DbSet<AccountabilityTemplateAlertMapEntity> AccountabilityTemplateAlertMapEntities { get; set; }

        public DbSet<DeviceGatewayEntity> DeliveryGatewayEntities { get; set; }


    }
}
