﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Mappings;
using AtHoc.IWS.Business.Models.Mapping;

namespace AtHoc.IWS.Business.Database
{
    public class AtHocGeoDbContext : DbContext
    {
        public AtHocGeoDbContext() : base(AtHocConfigService.Current.NgGeoConnStr)
        {

        }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            //Define mapping 
            modelBuilder.Configurations.Add(new MapMapping());
            base.OnModelCreating(modelBuilder);
        }
        public DbSet<County> Counties { get; set; }
    }
}
