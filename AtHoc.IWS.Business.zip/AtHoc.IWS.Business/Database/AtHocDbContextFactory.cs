﻿using System;
using System.ComponentModel;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Factory;
using AtHoc.Infrastructure.Ioc;
using AtHoc.IWS.Business.Data;

namespace AtHoc.IWS.Business.Database
{
    public class AtHocDbContextFactory : FactoryBase<IUnitOfWork, Type>, IAtHocContextFactory
    {
        public static IAtHocContextFactory CreateFactory()
        {
            return ServiceLocator.Current.Resolve<IAtHocContextFactory>();
        }

        public INgaddataContext CreateNgaddataContext()
        {
            return ServiceLocator.Current.Resolve<INgaddataContext>();
        }

        #region Protected methods
        protected override IUnitOfWork CreateImpl(Type key)
        {
            if (key == typeof(INgaddataContext)) return ServiceLocator.Resolve<INgaddataContext>();

            throw new NotSupportedException("Key ({0}) not is not supported".FormatWith(key.FullName));
        }

        protected override Type ConvertToKey(object key)
        {
            return key as Type;
        }
        #endregion Protected methods
    }
}
