﻿using AtHoc.Infrastructure.Database.MsSql;
using AtHoc.Infrastructure.Ioc;
using AtHoc.Infrastructure.Log;
using AtHoc.IWS.Business.Cache;
using AtHoc.IWS.Business.Cache.Impl;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Business.Data;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.Audit;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;
using AtHoc.IWS.Business.Domain.Devices;
using AtHoc.IWS.Business.Domain.Devices.Impl;
using AtHoc.IWS.Business.Domain.PageLayout;
using AtHoc.IWS.Business.Domain.PageLayout.Impl;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Business.Domain.Publishing.Impl;
using AtHoc.IWS.Business.Domain.RuleModel;
using AtHoc.IWS.Business.Domain.SelfService;
using AtHoc.IWS.Business.Domain.SelfService.Impl;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Targeting;
using AtHoc.IWS.Business.Domain.Targeting.Impl;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Business.Domain.Impl;
using AtHoc.IWS.Business.Domain.Settings.Impl;
using AtHoc.IWS.Business.Domain.Users;
using AtHoc.IWS.Business.Domain.Users.Impl;
using AtHoc.IWS.Business.Domain.VirtualSystem;
using AtHoc.IWS.Business.Domain.VirtualSystem.Impl;
using AtHoc.IWS.Business.Shedule;
using AtHoc.IWS.Business.Shedule.Impl;
using AtHoc.IWS.Business.Domain.RuleModel.Impl;

namespace AtHoc.IWS.Business.Database
{
    public partial class NgaddataDbContext : MsSql2008DbContext, INgaddataContext
    {
        public NgaddataDbContext()
            : base("NgaddataContext", AtHocConfigService.Current.NgaddataConnStr)
        {
            VirtualSystemRepository = new VirtualSystemDbRepository(this);
            OperatorUserRepository = new OperatorUserDbRepository(this);
            EndUserRepository = new EndUserDbRepository(this);
            CustomAttributeRepository = new CustomAttributeDbRepository(this);
            CustomAttributeValueRepository = new CustomAttributeValueDbRepository(this);
            CustomViewRepository = new CustomViewDbRepository(this);
            HierarchyRepository = new HierarchyDbRepository(this);
            PageLayoutRepository = new PageLayoutDbRepository(this);
            DeviceRepository = new DeviceDbRepository(this);
            AlertChannelRepository = new AlertChannelDbRepository(this);
            OperatorAccessRepository = new OperatorAccessDbRepository(this);
            OperatorVPSAccessRepository = new OperatorVPSAccessDbRepository(this);
            DistributionListRepository = new DistributionListDbRepository(this);
            DeviceGroupRepository = new DeviceGroupRepository(this);
            EndUserSearchRepository = new EndUserSearchDbRepository(this);
            EndUserSearchCountRepository = new EndUserSearchCountRepository(this);
            PagerCarrierRepository = new PagerCarrierRepository(this);
            AttributeValueRepository = new AttributeValueDbRepository(this);
            CacheinfoRepository = new CacheinfoDbRepository(this);
            DeviceAddressRepository = new DeviceAddressRepository(this);
            OperatorChannelRepository = new OperatorChannelDbRepository(this);
            OperatorUserRoleRepository = new OperatorUserRoleDbRepository(this);
            OperatorUserBaseRepository = new OperatorUserBaseDbRepository(this);
            OperatorRoleRepository = new OperatorRoleDbRepository(this);
            EndUserEntityRepository = new EndUserEntityDbRepository(this);
            OperatorEntityAccessRepository = new OperatorEntityAccessDbRepository(this);
            CustomViewDeleteRepository = new CustomViewDbDeleteRepository(this);
            OperatorAuditRepository = new OperatorAuditDbRepository(this);
            ActivityFeedRepository = new ActivityFeedDbRepository(this);
            AccountabilityActivityFeedRepository = new AccountabilityActivityFeedDbRepository(this);
            AlertRecipientDeviceRepository = new AlertRecipientDeviceDbRepository(this);
            DistributionListItemRepository = new DistributionListItemDbRepositiory(this);
            ProviderConfigurationRepository = new VirtualSystemConfigurationRepository(this);
            CustomAttributeTargetingRepository = new CustomAttributeTargetingDbRepository(this);
            DistributionListDependencyRepositiory = new DistributionListDependencyDbRepositiory(this);
            UserImportDataRepository = new UserUserImportDataDbRepository(this);
            UserImportStatusRepository = new UserImportStatusDbRepository(this);
            ScheduledEventRepository = new ScheduledEventDbRepository(this);
            ScheduleRepository = new ScheduleDbRepository(this);
            GlobalSecurityPolicyRepository = new GlobalSecurityPolicyDbRepository(this);
            DistributionListFolderDbRepository = new DistributionListFolderDbRepository(this);
            LocalSystemRepository = new LocalSystemDbRepository(this);
            PagerCarrierEntityRepository = new PagerCarrierEntityDbRepository(this);
            UserSearchRepository = new UserSearchDbRepository(this);
            SelfServiceAccountRepository = new SelfServiceAccountDbRepository(this);
            ScenarioRepository = new ScenarioDbRepository(this);
            SelfServiceRepository = new SelfServiceDbRepository(this);
            SecurityPolicyRepository = new SecurityPolicyRepository(this);
            DeliveryTemplateRepository = new DeliveryTemplateRepository(this);
            MassDeviceTargetingRepository = new MassDeviceTargetingDbRepository(this);
            ProviderRepository = new ProviderRepository(ServiceLocator.Current.Resolve<ILogService>());
            RuleRepository = new RuleRepository();
            DisableDeleteEndUsersRepository = new DisableDeleteEndUsersRepository();
            UserGeoValueDBRepository = new UserGeoValueDBRepository(this);
        }

        public IVirtualSystemRepository VirtualSystemRepository { get; set; }

        public IOperatorUserRepository OperatorUserRepository { get; set; }

        public IEndUserRepository EndUserRepository { get; set; }

        public ICustomAttributeRepository CustomAttributeRepository { get; set; }

        public ICustomAttributeValueRepository CustomAttributeValueRepository { get; set; }

        public ICustomViewRepository CustomViewRepository { get; set; }

        public ICustomViewDeleteRepository CustomViewDeleteRepository { get; set; }

        public IHierarchyRepository HierarchyRepository { get; set; }

        public ILanguageRepository LanguageRepository { get; set; }

        public IPageLayoutRepository PageLayoutRepository { get; set; }

        public IDeviceRepository DeviceRepository { get; set; }

        public IDeviceGroupRepository DeviceGroupRepository { get; set; }

        public IAlertChannelRepository AlertChannelRepository { get; set; }

        public IOperatorAccessRepository OperatorAccessRepository { get; set; }

        public IOperatorVPSAccessRepository OperatorVPSAccessRepository { get; set; }

        public IGlobalSecurityPolicyRepository GlobalSecurityPolicyRepository { get; set; }

        public ISecurityPolicyRepository SecurityPolicyRepository { get; set; }

        public IDistributionListFolderRepository DistributionListFolderDbRepository { get; set; }

        public ILocalSystemRepository LocalSystemRepository { get; set; }

        public IPagerCarrierEntityRepository PagerCarrierEntityRepository { get; set; }

        public IDistributionListRepository DistributionListRepository { get; set; }

        public IDistributionListItemRepositiory DistributionListItemRepository { get; set; }

        public IDistributionListDependencyRepositiory DistributionListDependencyRepositiory { get; set; }

        public IEndUserSearchRepository EndUserSearchRepository { get; set; }

        public IEndUserSearchCountRepository EndUserSearchCountRepository { get; set; }

        public IPagerCarrierRepository PagerCarrierRepository { get; set; }

        public IAttributeValueRepository AttributeValueRepository { get; set; }

        public ICacheinfoRepository CacheinfoRepository { get; set; }

        public IDeviceAddressRepository DeviceAddressRepository { get; set; }

        public IOperatorChannelRepository OperatorChannelRepository { get; set; }

        public IOperatorUserRoleRepository OperatorUserRoleRepository { get; set; }

        public IOperatorUserBaseRepository OperatorUserBaseRepository { get; set; }

        public IOperatorRoleRepository OperatorRoleRepository { get; set; }

        public IEndUserEntityRepository EndUserEntityRepository { get; set; }

        public IOperatorEntityAccessRepository OperatorEntityAccessRepository { get; set; }

        public IOperatorAuditRepository OperatorAuditRepository { get; set; }

        public IActivityFeedRepository ActivityFeedRepository { get; set; }

        public IAccountabilityActivityFeedRepository AccountabilityActivityFeedRepository { get; set; }

        public IAlertRecipientDeviceRepository AlertRecipientDeviceRepository { get; set; }

        public IProviderConfigurationRepository ProviderConfigurationRepository { get; set; }

        public ICustomAttributeTargetingRepository CustomAttributeTargetingRepository { get; set; }

        public IUserImportStatusRepository UserImportStatusRepository { get; set; }

        public IUserImportDataRepository UserImportDataRepository { get; set; }

        public IScheduledEventRepository ScheduledEventRepository { get; set; }

        public IScheduleRepository ScheduleRepository { get; set; }

        public IUserSearchRepository UserSearchRepository { get; set; }

        public ISelfServiceAccountRepository SelfServiceAccountRepository { get; set; }

        public IScenarioRepository ScenarioRepository { get; set; }

        public ISelfServiceRepository SelfServiceRepository { get; set; }

        public IDeliveryTemplateRepository DeliveryTemplateRepository { get; set; }

        public IMassDeviceTargetingRepository MassDeviceTargetingRepository { get; set; }

        public IProviderRepository ProviderRepository { get; set; }
        public IAudioFileRepository AudioFileRepository { get; set; }

        public IRuleRepository RuleRepository { get; set; }

        public IDisableDeleteEndUsersRepository DisableDeleteEndUsersRepository { get; set; }

        public IUserGeoValueDBRepository UserGeoValueDBRepository { get; set; }

    }
}