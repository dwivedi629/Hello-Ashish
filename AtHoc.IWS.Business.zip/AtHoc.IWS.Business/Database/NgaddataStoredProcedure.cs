﻿using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Database;

namespace AtHoc.IWS.Business.Database
{
	public class NgaddataStoredProcedure : StoredProcedure
	{
		public NgaddataStoredProcedure(IDbContext dbContext, string name) : base(dbContext, name) { }

		public NgaddataStoredProcedure(string name) : base(AtHocDbContextFactory.CreateFactory().CreateNgaddataContext(), name) { }
	}
}
