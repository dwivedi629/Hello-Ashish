﻿using AtHoc.IWS.Business.Configurations;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Mappings;
using AtHoc.IWS.Business.Models;
using AtHoc.IWS.Business.Models.Mapping;
using models= AtHoc.IWS.Business.Domain.Entities;
namespace AtHoc.IWS.Business.Database
{
    public class AtHocEventDbContext : DbContext
    {
        //public AtHocEventDbContext() : base("Server=situationdev.athocdevo.com;Initial Catalog=ngaddata;User Id=sa;Password=RedWhiteBlue@2013!;") { }
        public AtHocEventDbContext() : base(AtHocConfigService.Current.NgadEventConnStr) { }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            //Define mapping 
            modelBuilder.Configurations.Add(new EventMapping());
            modelBuilder.Configurations.Add(new EventEntityMapping());
            modelBuilder.Configurations.Add(new EventMediaMap());
            modelBuilder.Configurations.Add(new EventCategoryMap());
            modelBuilder.Configurations.Add(new EventDescriptionMap());
          
        }

        /// <summary>
        /// DBset for VW_EVT_EVENT view from ngEvent database. In order to avoid multiple roundtrip to db server, view has been mapped to Event Object Model.
        /// </summary>
        public DbSet<models.Event> Events { get; set; }

        /// <summary>
        /// DBset for Event table in ngEvent Datbase. This object will be used to Add/Update Event Functionality.
        /// </summary>
        public DbSet<models.EventEntity> EventEntities { get; set; }
        public DbSet<models.EventCategory> EventCategories { get; set; }

        public DbSet<models.EventDescription> EventDescriptions { get; set; }
        public DbSet<models.EventMedia> EventMedias { get; set; }
        
    }
}
