﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Data;
using AtHoc.Infrastructure.Database;
using AtHoc.IWS.Business.Configurations;

namespace AtHoc.IWS.Business.Database
{
    public class NgoladataDbContext: System.Data.Entity.DbContext
    {
         public NgoladataDbContext() : base(AtHocConfigService.Current.NgoladataConnStr) { }
    }
}
