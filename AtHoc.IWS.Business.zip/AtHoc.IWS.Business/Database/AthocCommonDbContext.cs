﻿using AtHoc.IWS.Business.Configurations;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Mappings;
using AtHoc.IWS.Business.Models;
using AtHoc.IWS.Business.Models.Mapping;

namespace AtHoc.IWS.Business.Database
{
    public class AthocCommonDbContext : DbContext
    {
        //public AtHocEventDbContext() : base("Server=situationdev.athocdevo.com;Initial Catalog=ngaddata;User Id=sa;Password=RedWhiteBlue@2013!;") { }
        public AthocCommonDbContext() : base(AtHocConfigService.Current.NgCommonConnStr) { }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            //Define mapping 
            modelBuilder.Configurations.Add(new MediaMapping());
            modelBuilder.Configurations.Add(new MediaDataMapping());
            modelBuilder.Configurations.Add(new MediaThumbnailMapping());
            base.OnModelCreating(modelBuilder);
        }

        public DbSet<Media> Medias { get; set; }
        public DbSet<MediaData> MediaDatas { get; set; }
        public DbSet<MediaThumbnail> MediaThumbnails { get; set; }

      
    }
}
