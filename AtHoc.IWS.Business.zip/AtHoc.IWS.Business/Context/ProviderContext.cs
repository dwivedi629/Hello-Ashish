﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Context
{
    public class ProviderContext : IProviderContext
    {
        public int ProviderId { get; set; }
        public string BaseLocale { get; set; }
    }

   
}
