﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Context
{
    public interface IProviderContext
    {
        int ProviderId { get; set; }
        string BaseLocale { get; set; }
    }
}
