﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Context
{
    public interface IOperatorContext
    {
        int OperatorId { get; set; }
        int ProviderId { get; set; }
    }
}
