﻿using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Context
{
	public interface IRuntimeContext
	{
		Provider Provider { get; }
		OperatorUser Operator { get; }
        User LoggedOnUser { get; }
        Provider RefreshedProviderContext();
        OperatorUser RefreshedOperatorContext();
        
    }
}
