﻿using System.Security.Cryptography.X509Certificates;
using AtHoc.Infrastructure.Ioc;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.Entities;
using System.Collections.Generic;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;
using AtHoc.Global.Resources.Implementations;
using AtHoc.Global.Resources.Interfaces;
using System.Web;

namespace AtHoc.IWS.Business.Context
{
	public static class RuntimeContext
	{
        public const string ContextKey = "AtHoc.Context.HttpRuntimeContext";
       

#warning DO NOT MAKE THAT METHOD PUBLIC !!! IMPLEMENT APPROPRIATE STATIC PROPERTIES ONLY !!!
		internal static IRuntimeContext GetRuntimeContext()
		{
			return ServiceLocator.Resolve<IRuntimeContext>();
		}

		public static int ProviderId
		{
			get { return Provider.Id; }
		}

		public static int OperatorId
		{
			get { return Operator.Id; }
		}

		public static Provider Provider
		{
			get { return GetRuntimeContext().Provider; }
		}

		public static OperatorUser Operator
		{
			get { return GetRuntimeContext().Operator; }
		}

        public static User LoggedOnUser
        {
            get { return GetRuntimeContext().LoggedOnUser; }
        }

		public static OperatorUser RefreshedOperatorContext
		{
			get { return GetRuntimeContext().RefreshedOperatorContext(); }
		}

		public static CustomAttributeLookup CustomAttributes
		{
			get { return CustomAttributeCache.Get(ProviderId, Provider.BaseLocale, false); }
		}

		public static CustomAttributeLookup CustomAttributesWithouMassDevices
		{
			get { return CustomAttributeCache.Get(ProviderId, Provider.BaseLocale); }
		}

		public static CustomAttributeValueLookup CustomAttributeValues
		{
            get { return ServiceLocator.Resolve<ICustomAttributeValueCache>().Get(ProviderId, Provider.BaseLocale); }
		}

		private static ICustomAttributeCache CustomAttributeCache
		{
			get { return ServiceLocator.Resolve<ICustomAttributeCache>(); }
		}
       
	    public static Provider RefreshedProviderContext
        {
            get { return GetRuntimeContext().RefreshedProviderContext(); }
        }

	    public static void RefreshOperatorContext()
	    {
            GetRuntimeContext().RefreshedOperatorContext(); 
	    }
        public static void SetDisclaimerAsAccepted()
        {
            var context = GetRuntimeContext();
            HttpContext.Current.Session[ContextKey] = context;

        }
         public static void SetDisclaimerAsDeclined(string ssEnabled)
        {
            var context = GetRuntimeContext();
            HttpContext.Current.Session[ContextKey] = context;
        }

         public static CustomAttributeLookup CustomAttributesWithouMassDevices_UserLocale(string userLocale)
         {
              return CustomAttributeCache.Get(ProviderId, Provider.BaseLocale, false,false); 
         }
    }
}