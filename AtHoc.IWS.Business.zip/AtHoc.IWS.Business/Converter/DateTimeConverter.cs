﻿using System;

using AtHoc.IWS.Business.Domain.Systems.Impl;

namespace AtHoc.IWS.Business
{
	public class DateTimeConverter
	{
		private readonly double _sysTimeZoneOffset;
		private readonly double _vpsTimeZoneOffset;

		#region Instance Members

		public DateTimeConverter(double sysTimeZoneOffset, double vpsTimeZoneOffset)
		{
			_sysTimeZoneOffset = sysTimeZoneOffset;
			_vpsTimeZoneOffset = vpsTimeZoneOffset;
		}

		public DateTime GetSysTimeFromVpsTime(DateTime vpsDateTime)
		{
			return vpsDateTime.AddHours(_sysTimeZoneOffset - _vpsTimeZoneOffset);
		}

		public DateTime GetVpsTimeFromSysTime(DateTime sysDateTime)
		{
			return sysDateTime.AddHours(_vpsTimeZoneOffset - _sysTimeZoneOffset);
		}

		#endregion Instance Members

		private static DateTime _defaultDateTime = new DateTime(2000, 1, 1);

		public static DateTime GetDateTimeFromSeconds(int seconds)
		{
			return _defaultDateTime.AddSeconds(seconds);
		}

		public static int GetSecondsFromDateTime(DateTime date)
		{
			return (int)date.Subtract(_defaultDateTime).TotalSeconds;
		}

		public static DateTime GetSystemTime()
		{
			return LocalSystemManager.GetSystem().SystemTime.GetValueOrDefault();;
		}

		public static int GetSystemTimeAsSeconds()
		{
			return GetSecondsFromDateTime(GetSystemTime());
		}

		internal static TimeZoneInfo GetSystemTimeZoneInfo()
		{
		    return TimeZoneInfo.FindSystemTimeZoneById(TimeZone.CurrentTimeZone.StandardName);
		}

        public static DateTime? GetDateTimeFromSeconds(int? createdOn)
        {
            if (createdOn != null)
            {
                var seconds = (double) createdOn;
                return _defaultDateTime.AddSeconds(seconds);
            }
            else
            {
                return null;
            }
        }
	}
}
