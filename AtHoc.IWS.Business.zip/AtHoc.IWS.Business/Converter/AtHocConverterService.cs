﻿using AtHoc.Infrastructure.Converter.Default;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure;

namespace AtHoc.IWS.Business.Converter
{
    public class AtHocConverterService : DefaultConverterService
    {
        public override object ConvertTo(Type type, object value, object defaultValue = null, bool throwException = false, IFormatProvider provider = null, System.Globalization.CultureInfo cultureInfo = null)
        {
            if (type == typeof(DateTime) && value is int)
            {
                return new DateTime(2000, 1, 1).AddSeconds(value.ConvertTo<int>());
            }
            return base.ConvertTo(type, value, defaultValue, throwException, provider, cultureInfo);
        }
    }
}
