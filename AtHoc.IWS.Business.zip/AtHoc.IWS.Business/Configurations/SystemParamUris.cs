﻿namespace AtHoc.Runtime
{
	/// <summary>
	/// Define string URI consts to some of system parameters
	/// </summary>
	public static class SystemParamUris
	{
		public const string OleDbConnectionString = "OleDbConnectionString";
		public const string ReadonlyAdoDbConnectionString = "ReadonlyAdoDbConnectionString";
		public const string SystemInstallFolder = "Install/AppLoc";

		private const string SystemFramework = "SystemFramework";

		public const string LoggingFramework = SystemFramework + "/Logging";
		//public const string LoggingConfigFileFolder = LoggingFramework + "/ConfigFileFolder";
		public const string LoggingConfigFilePath = LoggingFramework + "/ConfigFilePath";

		public const string SecurityFramework = SystemFramework + "/Security";
		public const string BootstrapFileFolder = SecurityFramework + "/BootstrapFileFolder";

		public const string DependencyInjectionFramework = SystemFramework + "/DependencyInjection";
		public const string ContainerExtensions = DependencyInjectionFramework + "/ContainerExtensions";
	}
}
