﻿using System.Text;

using AtHoc.Infrastructure.Configurations;

namespace AtHoc.IWS.Business.Configurations
{
	public interface IAtHocConfigurations : IConfigurations
	{
		string NgaddataConnStr { get; set; }

        string NgadEventConnStr { get; }
        string NgGeoConnStr { get; }

        string NgCommonConnStr { get;  }

        string NgoladataConnStr { get; }

		string CryptoDllFolder { get; set; }

		Encoding DefaultEncoding { get; }

        Encoding Windows1252Encoding { get; }

		bool IsIpAlertingAllowed { get; set; }

		int UserBulkUpdatePageSize { get; }
	}
}