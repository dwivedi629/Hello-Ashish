﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
namespace AtHoc.IWS.Business.Configurations
{
    public static class Constants
    {
        public const string ImportFileUploadPath = "\\CommonSiteData\\Graphics\\images\\adminTemp\\";
        public const string DefaultBlankImage = "\\CommonSiteData\\Graphics\\images\\misc\\blank.gif";
        public const string DefaultImagePath = "\\CommonSiteData\\Graphics\\images\\misc\\9999.gif";
        public const int SystemVps = 3;
        public const int DeviceId = 15;
        public const string xlsname = "http://www.athoc.com/accessibility";
        public const int AudioObjectId = 32;
        public const int AudioModifyId = 2;
        public const string AudioEntityType = "PUB";
        public const string AudioStatus = "PUB";
        public const string AudioFormat = "WAV";
        public const string DesktopPopupXml = "/client/users/client/tools/common/desktopPopupSampleData.xml";
        public const string TemplateNodeXml = "/client/users/client/tools/common/templateNodes.xml";
        public const string PreviewXslt = "/client/users/client/tools/common/preview.xsl";
        public const string linebreak = "\r\n";
        public const string tab = "\t";
        public const string InitialDate = "1/1/2000";
        public const string SelfServiceUrl = "/SelfService";
        public const string DefaultGuiId = "00000000-0000-0000-0000-000000000000";



        public const string DesktopPath = "/iws/template/desktop";
        public const string LogoPath = "/iws/provider/logo";
        public const string IconPath = "/ssa/map/icon";
        public const string AtHocUser = "ATUSR";
        public const string Registration = "Register";
        public static string[] imageClass = { "atImageTopLeft", "atImageTopRight", "atImageBottomLeft", "atImageBottomRight" };
        public static string[] SecurityParameters = { "SESSION-TIMEOUT-INTERVAL", "ALLOW-MULTIPLE-SESSIONS", "LOGIN-SCREEN-SECURITY-DISCLAIMER", "REQUIRE_CAPTCHA" };
        public static string[] SystemParameters = { "DB_ARCHIVE_LOCATION", "SELF-SERVICE-DISPLAY-ALERTS-CUTOFF-DAYS","SYSTEM_ID",

                                                        "SELF-SERVICE-DISPLAY-ALERTS-CUTOFF-DAYS","CLIENT_CERT_REQUIRED","CLIENT_CERT_STORELOCATION",

                                                        "CLIENT_CERT_STORENAME","CLIENT_CERT_SUBJECT","SUPPORT_PAGE_CUSTOM_CONTENT",

                                                        "POLLING-INTERVAL","POLLING-SERVICE-PASSWORD","POLLING-SERVICE-REQUIRED","POLLING-SERVICE-URL",

                                                        "POLLING-SERVICE-USERNAME","GEO_HISTORY_PURGE_DAYS","PURGE_BEYOND_DAYS_AEV","PURGE_BEYOND_DAYS_SESSIONS" 

                                                    };
        public static string[] Hierarchy = { "Organizational Hierarchy", "Distribution Lists", "IP Lists" };
    }
}