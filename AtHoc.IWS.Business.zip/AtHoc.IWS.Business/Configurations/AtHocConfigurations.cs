﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

using AtHoc.Data;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Configurations.Registry;

namespace AtHoc.IWS.Business.Configurations
{
	public class AtHocConfigurations : IAtHocConfigurations
	{
		private readonly RegistryConfigurations registryConf =
			new RegistryConfigurations(@"HKEY_LOCAL_MACHINE\SOFTWARE\Wow6432Node\AtHocServer");

		#region IConfigurations

		public string CdnBaseUrl
		{
            get {
                var url = (ConfigurationManager.GetURL() + "/athoc-cdn");

                // THIS IS FOR DEVELOPERS MACHINE
                #if DEBUG
                    url = "localhost/athoc-cdn";
                #endif

                url = url.Replace("http://", "");
                url = url.Replace("https://", "");
                return url;
            }
            set
            { }
		}

        public string IwsBaseUrl
        {
            get
            {
                var url = (ConfigurationManager.GetURL() + "/athoc-iws");

                // THIS IS FOR DEVELOPERS MACHINE
                #if DEBUG
                url = "localhost/athoc-iws";
                #endif

                url = url.Replace("http://", "");
                url = url.Replace("https://", "");
                return url;
            }
            set
            { }
        }

        public string FilesBasePath
        {
            get { return registryConf.Get(@"\Install", "AppLoc") as string; }
        }

		public string Version
		{
			get { return registryConf.Get(@"\Install", "Version") as string; }
			set { registryConf.Set(@"\Install", "Version", value); }
		}

		public bool IsIpAlertingAllowed
		{
			get
			{
				var value = registryConf.Get(@"\ProductConfig\ALERTING\IP", "Enabled") as string;
				return value != null && value == "Y";
			}
			set { registryConf.Set(@"\ProductConfig\ALERTING\IP", "CryptoDllFolder", value ? "Y" : "N"); }
		}

		public int UserBulkUpdatePageSize
		{
			get { return 5000;  }
		}

        public byte[] CryptoSalt
        {
            get
            { return null; }
            set { }
        }

        public string CryptoPassword
        {
            get { return null; }
            set { }
        }

        public string CryptoDllFolder
        {
	        get
	        {
				return Path.Combine(FilesBasePath, @"ServerObjects\DOTNET");
	        }
            set { }
        }

		#endregion IConfigurations

		#region IAtHocConfigurations

		public Encoding DefaultEncoding
		{
			get { return Encoding.UTF8; }
		}

	    public Encoding Windows1252Encoding
	    {
	        get { return Encoding.GetEncoding(1252); }
	    }

		public string NgaddataConnStr
		{
			get { return registryConf.Get(@"", "OleDbConnectionString", null, x => Regex.Replace((string) x, "Provider=.*?;", "")) as string; }
			set { registryConf.Set(@"", "OleDbConnectionString", value); }
		}

        public string NgadEventConnStr
        {
            get
            {
                return AtHocDatabase.Ngevent.AdoConnString();
            }
        }

        public string NgGeoConnStr
        {
            get
            {
                return AtHocDatabase.Nggeo.AdoConnString();
            }
        }

	    public string NgoladataConnStr
	    {
	        get { return AtHocDatabase.Ngola.AdoConnString(); }
	    }

        public string NgCommonConnStr
        {
            get
            {
                return AtHocDatabase.Ngcommon.AdoConnString();
            }
        }

		#endregion IAtHocConfigurations


       
    }
}