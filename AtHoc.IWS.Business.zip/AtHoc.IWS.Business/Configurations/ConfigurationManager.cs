﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Caching;

using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Entity;
using AtHoc.Systems;

using AtHoc.IWS.Business.Data;
using AtHoc.IWS.Business.Database;

using AtHoc.IWS.Business.Domain.Systems.Impl;

namespace AtHoc.IWS.Business.Configurations
{
    public static class ConfigurationManager
    {
        public static string GetURL()
        {
            return LocalSystemManager.GetSystem().Url;
        }
    }
}
