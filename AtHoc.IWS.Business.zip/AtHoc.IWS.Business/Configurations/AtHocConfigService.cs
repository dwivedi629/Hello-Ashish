﻿using AtHoc.Infrastructure.Ioc;

namespace AtHoc.IWS.Business.Configurations
{
	public static class AtHocConfigService
	{
		public static IAtHocConfigurations Current { get; private set; }

		static AtHocConfigService()
		{
			Current = new AtHocConfigurations();
		}
	}
}