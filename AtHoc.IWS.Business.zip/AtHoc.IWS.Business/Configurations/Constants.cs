﻿
namespace AtHoc.IWS.Business.Configurations
{
    public static class Constants
    {
        public const string ImportFileUploadPath = "\\CommonSiteData\\Graphics\\images\\adminTemp\\";
        public const string DefaultBlankImage = "\\client\\images\\blank.gif";
        public const string DefaultImagePath = "\\CommonSiteData\\Graphics\\images\\misc\\9999.gif";
        public const int SystemVps = 3;
        public const string XlsName = "http://www.athoc.com/accessibility";
        public const int AudioObjectId = 32;
        public const int AudioModifyId = 2;
        public const string DefaultLocale = "en-US";
        public const string SelfServiceLanguageCookie = "SelfService_CurrentLanguage";
        public const string IwsLanguageCookie = "AtHoc_CurrentLanguage";
		public const string DisclaimerCookie = "AtHoc_ShowDisclaimer";
		public const string AudioEntityType = "PUB";
        public const string AudioStatus = "PUB";
        public const string HierarchyTreeType = "TREE";
        public const string DefaultColor = "#000000";
        public const string DefaultBackGroundColor = "#ffffff";
        public const string DefaultFontSize= "12";
        public const string DefaultTitleFontSize = "18";
        public const string CustomImageOption = "CUSTOM";
        public static string[] ImageOption = { "SYSTEM", "CUSTOM" };
        public const string Organizationalimg = "/athoc-cdn/images/icon3-groups-purple.png";
        public const string Groupimg = "/athoc-cdn/images/icon3-groups-purple.png";
        public const string Individualimg = "/athoc-cdn/images/icon3-users-purple.png";
        public const string AudioFormat = "WAV";
        public const string DesktopPopupXml = "/client/users/client/tools/common/desktopPopupSampleData.xml";
        public const string EmailTemplateXml = "/client/users/client/tools/common/emailTemplateSampleData.xml";
        public const string TemplateNodeXml = "/client/users/client/tools/common/templateNodes.xml";
        public const string PreviewXslt = "/client/users/client/tools/common/preview.xsl";
        public const string DesktopPreviewXslt = "/client/users/client/tools/common/desktopPreview.xsl";
        public const string LineBreak = "\r\n";
        public const string Tab = "\t";
        public const string InitialDate = "1/1/2000";
        public const string SelfServiceUrl = "/SelfService";
        public const string DefaultGuiId = "00000000-0000-0000-0000-000000000000";
        public const string DesktopPath = "/iws/template/desktop";
        public const string LogoPath = "/iws/provider/logo";
        public const string IconPath = "/ssa/map/icon";
        public static string DesktopGroupCommonName = "DESKTOP-POPUP";
        public static string EmailGroupCommonName = "EMAIL";
        public const string AtHocUser = "ATUSR";
        public const string Registration = "Register";
        public const string WalkMeLanguageCookie = "AtHoc_IWSWalkMeSetLanguage";
        public const string PA_Status = "Status";
        public static string[] ImageClass =
        {
            "atImageTopLeft", "atImageTopRight", "atImageBottomLeft",
            "atImageBottomRight"
        };

        public static string[] SecurityParameters =
        {
             "ALLOW-MULTIPLE-SESSIONS",
            "LOGIN-SCREEN-SECURITY-DISCLAIMER", "REQUIRE_CAPTCHA",
           
        };

        public static string[] DeviceGroupNames = { "EMAIL", "DESKTOP-POPUP", "SN-FEED" };
        public static string[] SystemParameters = { 
            "DB_ARCHIVE_LOCATION", "SELF-SERVICE-DISPLAY-ALERTS-CUTOFF-DAYS", "SYSTEM_ID",

                                                        "SELF-SERVICE-DISPLAY-ALERTS-CUTOFF-DAYS","CLIENT_CERT_REQUIRED","CLIENT_CERT_STORELOCATION",

                                                        "CLIENT_CERT_STORENAME","CLIENT_CERT_SUBJECT","SUPPORT_PAGE_CUSTOM_CONTENT",

                                                        "POLLING-INTERVAL","POLLING-SERVICE-PASSWORD","POLLING-SERVICE-REQUIRED","POLLING-SERVICE-URL",

            "POLLING-SERVICE-USERNAME", "GEO_HISTORY_PURGE_DAYS", "PURGE_BEYOND_DAYS_AEV", "PURGE_BEYOND_DAYS_SESSIONS",
            "MGMT_LOGIN_SUPPORT_TEXT", "SS_TOUR_ENABLED", "MGMT_TOUR_ENABLED", "TOUR_ANALYTICS_ENABLED",
            "DESKTOP_TRAFFIC_URL"
                                                    };

        public static string[] Hierarchy = { "Organizational Hierarchy", "Distribution Lists", "IP Lists" };
        public const string CallBridgeKey = "CALL_BRIDGE";
        public const string IsUserUniqueAcrossEnterprise = "IsUserUniqueAcrossEnterprise";
        public const string TargetingType = "ORG";
        public const string WebSource = "Web Logo";
        public const int DefaultHeight = 450;
        public const int DefaultWidth = 450;
        public const int DefaultLeftOffset = 0;
        public const int DefaultTopOffset = 0;
        public const int DefaultTimeOutValue = 9999;
        public const string TreeType = "TREE";
        public const bool True = true;
        public static string[] RestrictedCommonNames = { "STATUS", "SYSTEM-GROUPS" };
        public const string TargetedUserXMLTagName = "user";
        public const string DefaultTemplateCommonName = "AtHoc-Default-Template";
        public const string resourceAssembly = "AtHoc.Global.Resources.IWSResources";
        public const int AutoDisableJobId = 1010140;
        public const int AutoDeleteJobId = 1010139;

        public const string InvalidCharacterSet =  @"/*?,><:;\[]+=|""";
        public const string InvalidOrgCharacterSet = @"`!$%^()={},;:?""<>|";

        public const string InvalidDLCharacterSet = @"\`~!^()={};:?""<>|/,[]";

        public const string UserId = "USER_ID";
        public const string UserNameColumnCommonName = "LOGIN_ID";
        public const string HrchyPrefix = "HRCHY";
        public const string DevicePrefix = "DEVICE";

        public const string XPropGeoStringValue = "GEOSTRINGVALUE";
        public const string XPropEnterpriseProviderId = "ENTPROVIDERID";
        public const string CVS_COLUMN_SEPARATOR = ":";
    }
}