﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using AtHoc.Data;
using AtHoc.Diagnostics;
using AtHoc.Infrastructure.Ioc;
using AtHoc.Infrastructure.Ioc.SimpleInjector;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Organization.Impl;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Business.Domain.Users.Impl.Search;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.IWS.Business.Ioc;
using AtHoc.Runtime;
using AtHoc.SystemJobs;
using AtHoc.Systems;
using AtHoc.Targeting;
using AtHoc.Utilities;
using AtHoc.VirtualSystems;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Business.Domain.Users.Impl;
using AtHoc.Global.Resources;
using System.Threading;
using System.Globalization;

namespace AtHoc.IWS.Business.AutoCleanupUsers
{
    public class AutoDisableDeleteService
    {
        /// <summary>
        /// Called by processor
        /// </summary>
        /// <param name="type"></param>
        public static void RunAll(string type)
        {
            //1. get list of providers
            //2. loop through list and execute one AutoDisable or one AutoDelete operation
            //   for each provider
            IEnumerable<VirtualSystem> vpsList = VirtualSystem.GetAll();
            foreach (VirtualSystem vs in vpsList)
            {
                if (vs.Id > 1000)
                {
                    RunSingle(vs.Id, type, 1, false, "", 0);
                }
            }
        }
        public static void RunSingle(int providerId, string type, int operatorId, bool ignoreListStatus, string criteria, int auditId)
        {
            var autoDisableDeleteProcess = new AutoDisabDeleteProcess();
            autoDisableDeleteProcess.Run(providerId, type, operatorId, criteria, auditId);
        }
    }
    public class AutoDisabDeleteProcess
    {
        static AutoDisabDeleteProcess()
        {
			//All regular schedular job must initialize the service locator like below.
			//OrganizationFacade, AccountabilityEventProcessor, AutoDisableDeleteProcess
            //if (ServiceLocator.Current == null)
            //{
            //    string message = "Init servicelocator from AutoDisabDeleteProcess";
            //    EventLogger.WriteInformation(new Exception(message));
            //    var serviceLoader = new AtHocServiceLoader();
            //    serviceLoader.LoadAll();

            //    if (ServiceLocator.Current != null)
            //    {
            //        ServiceLocator.Current.Register<IRuntimeContext, StandAloneRuntimeContext>(ServiceLifecycle.Singleton);
            //    }
            //}
            //RegularSchedularServiceInitializer.Init();

        }
        public ModifyUserStatus _lastExecutionStatus = ModifyUserStatus.NA;
        public AutoCleanupType ActionType { get; set; }
        public ModifyUserStatus LastExecutionStatus(int providerId)
        {

            if (_lastExecutionStatus == ModifyUserStatus.NA)
            {
                GetJobExecutionInfo(providerId);
            }
            return _lastExecutionStatus;

        }
        public void GetJobExecutionInfo(int providerId)
        {
            using (var ngad = new NgadDatabase())
            {
                ngad.AddParameter("commonName", SqlDbType.VarChar, DistListCommonName);
                ngad.AddParameter("providerId", SqlDbType.Int, providerId);

                using (SqlDataReader reader = ngad.ExecuteReader(LastExecutionSelectSql))
                {
                    if (reader.Read())
                    {
                        _lastExecutionTime = AtHocContext.Current.DateTimeConverter().SystemToVps(reader.GetValue<DateTime>("ACTION_TIMESTAMP"));
                        AuditId = reader.GetValue("AUDIT_ID", 0);
                        var lastExecStatus = reader.GetValue("STATUS", "");
                        if (lastExecStatus.Length != 0)
                        {
                            try // if values is "NULL", just ignore, status will remain as NA
                            {
                                _lastExecutionStatus = (ModifyUserStatus)Enum.Parse(typeof(ModifyUserStatus), lastExecStatus);
                            }
                            catch (Exception ex)
                            {

                            }
                        }
                    }
                    if (_lastExecutionStatus == ModifyUserStatus.NA)
                    {
                        _lastExecutionTime = AtHocSystem.DefaultDateTime;
                    }
                }
                ngad.AddParameter("jobId", SqlDbType.Int, JobId);
                using (SqlDataReader reader = ngad.ExecuteReader(ScheduledJobSelectSql))
                {
                    if (reader.Read())
                    {
                        _nextExecutionTime = AtHocContext.Current.DateTimeConverter().SystemToVps(reader.GetValue<DateTime>("RUN_ON"));
                        Interval = new Duration(reader.GetValue("INTERVAL_UNIT", "SEC"), reader.GetValue<int>("INTERVAL"));
                       
                    }
                }
            }
        }
        public Duration Interval { get; set; }
        public DateTime _nextExecutionTime;
        /// <summary>
        /// Date and time of the next execution run of the job
        /// </summary>
        public DateTime NextExecutionTime
        {
            get { return _nextExecutionTime; }
        }
        public DateTime _lastExecutionTime;
        /// <summary>
        /// Date and time of the last execution run of the job
        /// </summary>
        public int AuditId;
        public DistributionListStatusType Status;
        public string DistListCommonName
        {
            get { return ActionType == AutoCleanupType.DeleteUsers ? AttributeCommonNames.DeleteDistListCommonName : AttributeCommonNames.DisableDistListCommonName; }
        }
        public string AuditActionType
        {
            get { return ActionType == AutoCleanupType.DeleteUsers ? Operators.AuditedAction.BatchUsersDeleted : Operators.AuditedAction.BatchUsersDisabled; }
        }
        public string NewUserStatus
        {
            get { return ActionType == AutoCleanupType.DeleteUsers ? AttributeCommonNames.StatusAttributeValue : AttributeCommonNames.UserDisableStatus; }
        }
        public int JobId
        {
            get { return ActionType == AutoCleanupType.DisableUsers ? AttributeCommonNames.AutoDisableJobId : AttributeCommonNames.AutoDeleteJobId; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string LastExecutionSelectSql
        {
            get
            {
                return @"
                        SELECT TOP(1) dbo.GET_DATE_AS_DATETIME([ACTION_TIMESTAMP]) as ACTION_TIMESTAMP
                              ,dbo.GET_DATE_AS_DATETIME([ACTION_DATE]) as ACTION_DATE
                              ,AUDIT_ID,
                              STATUS
                        FROM [ngaddata].[dbo].[UPS_AUDIT_TAB] with (nolock)
                        WHERE SOURCE = @commonName
                        AND provider_id = @providerId 
                        ORDER BY AUDIT_ID DESC";
            }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ScheduledJobSelectSql
        {
            get
            {
                return @"
                        SELECT [NAME]
                              ,dbo.GET_DATE_AS_DATETIME([RUN_ON]) as RUN_ON
                              ,[INTERVAL]
                              ,[INTERVAL_UNIT]
                        FROM [ngaddata].[dbo].[SCD_SCHEDULE_TAB] with (nolock)
                        WHERE SCHEDULE_ID = @jobId";
            }
        }
        //  2. Loop the list and update the user status.
        //  3. Add info of each user to a csv string
        //  4. Update audit log, put csv string in new column
        /// <summary>
        /// 1. Get the list of users from distribution list.
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="type"></param>
        /// <param name="operatorId"></param>
        /// <param name="auditId"></param>
        /// <param name="criteria"></param>
        internal void Run(int providerId, string type, int operatorId, string criteria, int auditId)
        {
            ActionType = (AutoCleanupType)Enum.Parse(typeof(AutoCleanupType), type);
            ModifyUserStatus status;
            var csvAudit = new StringBuilder();
            bool isRunSingle = false;
            var pageNo = 1;
            const int pageSize = 10000;
            List<UserSearchResultItem> userList = null;
            string userStatusToSet = string.Empty;
            try
            {
                if (string.IsNullOrEmpty(criteria))
                {
                    var distriButionlist = GetDistributionListToRunAutoCleanup(providerId, operatorId);
                    if ((distriButionlist == null) || (distriButionlist != null && distriButionlist.Status != DistributionListStatusType.Active))
                        return;
                    criteria = distriButionlist.Definition;
                }
                var searchUserResult = FindUserToAutoDisableDelete(criteria, providerId, operatorId);
                if (searchUserResult != null && searchUserResult.SearchResultCount == 0)
                    return;

                if (auditId == 0)
                    auditId = LogAction(providerId, operatorId, "", ModifyUserStatus.IPC.ToString());
                else
                {
                    //Handle Job Timeout
                    isRunSingle = true;
                }

                var searchResultCount = searchUserResult.SearchResultCount;
                var sessionId = searchUserResult.SessionId;

                //Getting the locale 
                var providerLocal = this.GetProviderLocale(providerId);

                //Getting New Status Value based on the Locale
                var customAttributeValueCache = new CustomAttributeValueCache();
                var customAttributeValueDictionary = customAttributeValueCache.Get(providerId, providerLocal);
                var customAttributeValue = customAttributeValueDictionary.GetByCommonNames(NewUserStatus).FirstOrDefault();
                if (customAttributeValue != null)
                    userStatusToSet = customAttributeValue.ValueName;

                //CSV column headers
                csvAudit.AppendLine(string.Join(",", AttributeCommonNames.ColumnHeaders));
                while (searchResultCount > 0)
                {
                     userList = FindUsersBySessionToAutoDisableDelete(sessionId, pageNo, pageSize).Users;
                    searchResultCount = userList.Count;
                    if (isRunSingle)
                    {
                        if (LastExecutionStatus(providerId) == ModifyUserStatus.IPC)
                        {
                            var currDateTime = AtHocSystem.Local.CurrentDateTime;
                            var interval = currDateTime - _lastExecutionTime;
                            if (interval.TotalSeconds > JobInfo.GetJobInfo(JobId).Timeout)
                            {
                                UpdateAuditLog(auditId, csvAudit, ModifyUserStatus.Failure.ToString());
                                return;
                            }
                        }
                    }
                    var userSpec = new UserSpec { ProviderId = providerId, UserIds = userList.Select(a => a.Id), UpdatedByOperatorId = operatorId };
                    DisableDeleteUsers(userSpec, NewUserStatus);
                    AddToStatusChangeLogforUser(ref csvAudit, userList, "", userStatusToSet);
                    pageNo++;
                }
                status = ModifyUserStatus.Success;
                
            }
            catch (Exception ex)
            {
                status = ModifyUserStatus.Failure;
                AddToStatusChangeLogforUser(ref csvAudit, userList, ex.Message, userStatusToSet);
            }
            //Sucess Update
            UpdateAuditLog(auditId, csvAudit, status.ToString());
        }

        /// <summary>
        /// Getting Locale Code
        /// </summary>
        /// <param name="providerId"></param>
        /// <returns></returns>
        public string GetProviderLocale(int providerId)
        {
            var localeCode = "en-US";
            using (var ngadDb = new NgadDatabase())
            {
                string sql = @"select isnull((SELECT LOCALE_CODE from PRV_LOCALE_TAB WITH (NOLOCK)  WHERE isnull(IS_DEFAULT,'N')='Y' AND PROVIDER_ID=@providerid),'en-US') as LocaleCode";
                ngadDb.AddParameter("@providerid", SqlDbType.Int, providerId);
                ngadDb.CommandType = CommandType.Text;
                using (var reader = ngadDb.ExecuteDbReader(sql, CommandBehavior.CloseConnection))
                {
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            localeCode = (reader.GetValue<string>("LocaleCode"));
                        }
                    }

                }
            }
            return localeCode;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userSpec"></param>
        /// <param name="userStatus"></param>
        public void DisableDeleteUsers(UserSpec userSpec, string userStatus)
        {
            var userIds = String.Join(",", userSpec.UserIds.ToArray());
            using (var ngadDb = new NgadDatabase())
            {
                string sql = @"dbo.USR_STATUS_UPDATE";
                ngadDb.AddParameter("@tgtUsersList", SqlDbType.VarChar, userIds);
                ngadDb.AddParameter("@valueCommonName", SqlDbType.VarChar, userStatus);
                ngadDb.AddParameter("@updatedBy", SqlDbType.Int, 1);
                ngadDb.CommandType = CommandType.StoredProcedure;
                ngadDb.ExecuteNonQuery(sql);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="commonName"></param>
        /// <returns></returns>
        public AttributeCriteria GetAutoDisableDeleteCriteria(int providerId, string commonName)
        {
            string sql = @"select a.attribute_id, b.value_id from dbo.prv_attribute_tab a (nolock) 
                           inner join dbo.prv_attribute_value_locale_tab b (nolock)       
                           on a.attribute_id = b.attribute_id where a.provider_id = 3  and a.ENTITY_ID = 'USER'  
                           and isnull(a.status, 'ACT') = 'ACT' and a.common_name = @commonName  and b.value_name = 'NO' 
                           and b.locale_code='en-US'";
            var attributeId = 0;
            var valueId = 0;
            using (var ngadDb = new NgadDatabase())
            {
                ngadDb.AddParameter("@commonName", SqlDbType.VarChar, commonName);
                ngadDb.CommandType = CommandType.Text;
                using (var reader = ngadDb.ExecuteDbReader(sql, CommandBehavior.CloseConnection))
                {
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            attributeId = (reader.GetValue<int>("attribute_id"));
                            valueId = (reader.GetValue<int>("value_id"));
                        }
                    }
                }
            }
            return new AttributeCriteria(attributeId, CriteriaOperator.Equals, valueId);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="userId"></param>
        /// <param name="csvAudit"></param>
        /// <param name="status"></param>
        /// <returns></returns>
        public int LogAction(int providerId, int userId, string csvAudit, string status)
        {
            var vps = VirtualSystem.GetById(providerId);
            if (vps != null)
            {
                string vpsName = vps.DisplayName;

                return Operators.OperationAuditor.LogAction(
                    userId,
                    providerId,
                    AuditActionType,
                    Operators.AuditedEntity.EndUsers,
                    vpsName,
                    userId,
                    DistListCommonName,
                    csvAudit,
                    status
                    );
            }
            return 0;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="auditRecordId"></param>
        /// <param name="csvAudit"></param>
        /// <param name="status"></param>
        public void UpdateAuditLog(int auditRecordId, StringBuilder csvAudit, string status)
        {
            using (var ngadDb = new NgadDatabase())
            {
                string sql = @" update UPS_AUDIT_TAB set  ADDITIONAL_INFO = @csvAudit, STATUS = @status where AUDIT_ID = @auditRecordId";

                ngadDb.AddParameter("csvAudit", SqlDbType.VarChar, csvAudit.ToString());
                ngadDb.AddParameter("status", SqlDbType.VarChar, status);
                ngadDb.AddParameter("auditRecordId", SqlDbType.Int, auditRecordId);
                ngadDb.ExecuteNonQuery(sql);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="operatorId"></param>
        /// <returns></returns>
        private Domain.Entities.DistributionList GetDistributionListToRunAutoCleanup(int providerId, int operatorId)
        {
            var publishingFacade = new PublishingFacade(new AtHocDbContextFactory());
            var spec = new DistributionListSpec { CommonName = DistListCommonName, ProviderId = providerId, IncludeParentChildren = true, OperatorId = operatorId };
            return publishingFacade.GetDistributionLists(spec).FirstOrDefault();
        }

        /// <summary>
        /// getting the search expression element for the user search
        /// </summary>
        /// <param name="definition"></param>
        /// <returns></returns>
        public IEnumerable<List<GenericCriteria>> GetCustomCriteriaFromDefinition(string definition)
        {
            var customCriterias = new List<List<GenericCriteria>>();

            var orLines = definition.Split(new[] { Environment.NewLine }, StringSplitOptions.None);

            foreach (var orLine in orLines)
            {
                var andLines = orLine.Split('^');

                var customCriteria = new List<GenericCriteria>();

                foreach (var andLine in andLines)
                {
                    var data = andLine.Split('!');

                    var type = data[0].Split('-')[0];
                    var id = Int32.Parse(data[0].Split('-')[1]);
                    var opr = Int32.Parse(data[1]);
                    var value = data[2];

                    customCriteria.Add(new GenericCriteria(type, id, opr, value));
                }

                customCriterias.Add(customCriteria);
            }

            return customCriterias;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sessionId"></param>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public SessionSearchResult FindUsersBySessionToAutoDisableDelete(int sessionId, int pageNo, int pageSize)
        {
            var srchArgsV2 = new UserSearchSession(false, true, true, pageNo, pageSize, "User_Id", "ASC")
            {
                SessionId = sessionId,
                Options = new QueryOptions
                {
                    EnableSession = true,
                    ProcessNestedList = true,
                    GetUsers = false
                },
                AttributeNames = new List<string> {
                    AttributeCommonNames.UserName, 
                    AttributeCommonNames.DisplayName,
                    AttributeCommonNames.FirstName,
                    AttributeCommonNames.LastName,
                    AttributeCommonNames.Status
                }
            };

            var userFacade = new UserFacade();
            var result = userFacade.SearchUsersBySession(srchArgsV2);
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="definition"></param>
        /// <param name="providerId"></param>
        /// <param name="operatorId"></param>
        /// <returns></returns>
        public ContextSearchResult FindUserToAutoDisableDelete(string definition, int providerId, int operatorId)
        {
            var result = new ContextSearchResult();

            if (!string.IsNullOrWhiteSpace(definition))
            {

                var customCriteria = UserSearchHelper.GetCustomCriteria(GetCustomCriteriaFromDefinition(definition));
                var srchArgsV2 = new UserSearchSession(true, false, false)
                {
                    ProviderId = providerId,
                    Options = new QueryOptions
                    {
                        EnableSession = true,
                        ProcessNestedList = true,
                        GetUsers = false,
                        GetCountsOnly = true
                    },
                    ProviderCriteria = UserSearchHelper.GetProviderCriteria(providerId),
                    OperatorCriteria = UserSearchHelper.GetOperatorUserBaseCriteria(operatorId, providerId),
                };

                var userFacade = new UserFacade();
                var statusAttributeId = userFacade.GetStatusAttributeId();
                var statusValueIds = NewUserStatus == AttributeCommonNames.UserDisableStatus ? userFacade.GetStatusValueIds(new[] { AttributeCommonNames.ValidEnabledUsers }) :
                    userFacade.GetStatusValueIds(new[] { AttributeCommonNames.ValidEnabledUsers, AttributeCommonNames.UserDisableStatus });
                var statusCriteria = UserSearchHelper.GetUserStatusCriteria(statusAttributeId, statusValueIds);
                //Auto Disable Delete Criteria
                var autoDisableDeleteCommonName = (ActionType == AutoCleanupType.DisableUsers) ? AttributeCommonNames.Do_not_Auto_Disable_User : AttributeCommonNames.Do_not_Auto_Delete_User;
                var autoDisableDeleteCriteria = GetAutoDisableDeleteCriteria(providerId, autoDisableDeleteCommonName);
                srchArgsV2.TargetCriteria = customCriteria & statusCriteria & autoDisableDeleteCriteria;

                result = userFacade.SearchUsersByContext(srchArgsV2);
            }

            return result;
        }
        /// <summary>
        /// New Pegasus Implementation
        /// </summary>
        /// <param name="csvAudit"></param>
        /// <param name="users"></param>
        /// <param name="comments"></param>
        /// <param name="newUserStatus"></param>
        public void AddToStatusChangeLogforUser(ref StringBuilder csvAudit, List<UserSearchResultItem> users, string comments, string newUserStatus)
        {

            foreach (UserSearchResultItem item in users)
            {
                //No error, so add this record to csv string for audit
                csvAudit.Append(item.Id + "");
                csvAudit.Append(",");
                csvAudit.Append(item.UserName + "");
                csvAudit.Append(",");
                csvAudit.Append(item.FirstName + "");
                csvAudit.Append(",");
                csvAudit.Append(item.LastName + "");
                csvAudit.Append(",");
                csvAudit.Append(item.DisplayName + "");
                csvAudit.Append(",");
                csvAudit.Append(item.UserAttributes.FirstOrDefault(a => a.Key == "STATUS").Value + "");
                csvAudit.Append(",");
                csvAudit.Append(newUserStatus);
                csvAudit.Append(",");
                csvAudit.AppendLine(comments);
            }
        }
        public void RunNow(int providerId, string type, int operatorId, string criteria)
        {
            ActionType = (AutoCleanupType)Enum.Parse(typeof(AutoCleanupType), type);
            var auditId = LogAction(providerId, operatorId, "", "IPC");
            var timeOut = JobInfo.GetJobInfo(JobId).Timeout;
            XElement payloadXml = new XElement("PAYLOAD",
                   new XAttribute("PLATFORM", "DOTNET"),
                   new XElement("PACKAGE", "AtHoc.IWS.Business",
                       new XAttribute("SOURCE", "AtHoc.IWS.Business,Version=1.0.0.0,PublicKeyToken=148270b0172fe65b,Culture=Neutral"),
                       new XAttribute("LOCATION", "GAC")
                   ),
                   new XElement("CLASS", "AutoCleanupUsers.AutoDisableDeleteService"),
                   new XElement("METHOD", "RunSingle"),
                   new XElement("PARAMETERS",
                       new XElement("PARAM",
                           new XAttribute("TYPE", "Integer"),
                           new XAttribute("VALUE", providerId)),
                       new XElement("PARAM",
                           new XAttribute("TYPE", "String"),
                           new XAttribute("VALUE", type)),
                       new XElement("PARAM",
                           new XAttribute("TYPE", "Integer"),
                           new XAttribute("VALUE", operatorId)),
                       new XElement("PARAM",
                           new XAttribute("TYPE", "Boolean"),
                           new XAttribute("VALUE", true)),
                       new XElement("PARAM",
                           new XAttribute("TYPE", "String"),
                           new XAttribute("VALUE", criteria)),
                       new XElement("PARAM",
                           new XAttribute("TYPE", "Integer"),
                           new XAttribute("VALUE", auditId))
                   ));
            //priority: 2; timeout: 10800 seconds

            Job.SubmitJobToExecute(2, timeOut, payloadXml.ToString());
        }
    }

}
