﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Database;
using AtHoc.Infrastructure.Sql;
using AtHoc.IWS.Business.Cache.Spec;
using AtHoc.IWS.Business.Data;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Cache.Impl
{
    public class CacheinfoDbRepository : DbRepository<Cacheinfo, CacheinfoSpec>, ICacheinfoRepository
    {
        public CacheinfoDbRepository(IUnitOfWork context)
            : base(context)
        {
        }

        protected override void TranslateSpec(CacheinfoSpec spec, SqlBuilder builder, bool query)
        {
            builder.SelectAll<Cacheinfo>("a");
            builder.From(builder.Table<Cacheinfo>("a"));

            if (spec.CacheName.IsNotNullOrEmpty())
                builder.Where(builder.Condition(Cacheinfo.Meta.Cachename, ConditionOperator.Equals, spec.CacheName, "a"));
        }
    }
}
