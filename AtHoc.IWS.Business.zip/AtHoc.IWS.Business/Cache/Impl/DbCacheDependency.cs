﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Cache;
using AtHoc.IWS.Business.Cache.Spec;
using AtHoc.IWS.Business.Data;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Cache.Impl
{
    public class DbCacheDependency : ICacheDependency
    {
        private IDictionary<string, Item> cacheTimes = new Dictionary<string, Item>();
        private double bufferOffset = 5000;
        private IAtHocContextFactory contextFactory = null;
        private object objLock = new object();

        public DbCacheDependency(IAtHocContextFactory contextFactory)
        {
            this.contextFactory = contextFactory;
        }

        public bool IsExpired(string cacheName, string key)
        {
            var isExpired = true;
            var generatedKey = this.GenerateKey(cacheName, key);

            lock (this.objLock)
            {
                if (this.cacheTimes.ContainsKey(generatedKey))
                {
                    //check last updated from server?
                    var item = this.cacheTimes[generatedKey];
                    if (item.LastChecked.AddMilliseconds(bufferOffset) < DateTime.Now)
                    {
                        using (var context = this.contextFactory.CreateNgaddataContext())
                        {
                            var cacheinfo = context.CacheinfoRepository.FindBySpec(new CacheinfoSpec { CacheName = generatedKey }).FirstOrDefault();
                            if (cacheinfo != null)
                            {
                                if (cacheinfo.Lastupdated == item.LastUpdated)
                                    isExpired = false;

                                item.LastChecked = DateTime.Now;
                                item.LastUpdated = cacheinfo.Lastupdated;
                                this.cacheTimes[generatedKey] = item;
                            }
                        }
                    }
                    else
                    {
                        //already checked "bufferOffset" ago
                        isExpired = false;
                    }
                }
            }
            return isExpired;
        }

        public DateTime Expired(string cacheName, string key)
        {
            var expiredOn = DateTime.Now;
            var generatedKey = this.GenerateKey(cacheName, key);
            lock (this.objLock)
            {
                using (var context = this.contextFactory.CreateNgaddataContext())
                {
                    var cacheinfo = context.CacheinfoRepository.FindBySpec(new CacheinfoSpec { CacheName = generatedKey }).FirstOrDefault();
                    if (cacheinfo == null)
                        cacheinfo = new Cacheinfo { Cachename = generatedKey };

                    cacheinfo.Lastupdated = expiredOn;
                    context.CacheinfoRepository.Save(cacheinfo);
                    context.SaveChanges();
                }

                //expired
                this.cacheTimes.Remove(generatedKey);
            }
            return expiredOn;
        }

        public void Refreshed(string cacheName, string key)
        {
            var generatedKey = this.GenerateKey(cacheName, key);
            lock (this.objLock)
            {
                using (var context = this.contextFactory.CreateNgaddataContext())
                {
                    var cacheinfo = context.CacheinfoRepository.FindBySpec(new CacheinfoSpec { CacheName = generatedKey }).FirstOrDefault();
                    if (cacheinfo == null)
                    {
                        cacheinfo = new Cacheinfo 
                        { 
                            Cachename = generatedKey,
                            Lastupdated = DateTime.Now
                        };
                        context.CacheinfoRepository.Save(cacheinfo);
                        context.SaveChanges();
                    }

                    var item = new Item
                    {
                        LastChecked = DateTime.Now,
                        LastUpdated = cacheinfo.Lastupdated
                    };
                    this.cacheTimes[generatedKey] = item;
                }
            }
        }

        private struct Item
        {
            public DateTime LastUpdated { get; set; }
            public DateTime LastChecked { get; set; }
        }

        private string GenerateKey(string cacheName, string key)
        {
            return "{0}-{1}".FormatWith(cacheName, key);
        }
    }
}
