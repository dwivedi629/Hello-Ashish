﻿using AtHoc.Infrastructure.Data;

using AtHoc.IWS.Business.Cache.Spec;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Business.Cache
{
	public interface ICacheinfoRepository : IRepository<Cacheinfo, CacheinfoSpec> {}
}