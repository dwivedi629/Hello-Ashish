﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Entity;

namespace AtHoc.IWS.Business.Cache.Spec
{
    public class CacheinfoSpec : EntitySpec
    {
        public string CacheName { get; set; }
    }
}
