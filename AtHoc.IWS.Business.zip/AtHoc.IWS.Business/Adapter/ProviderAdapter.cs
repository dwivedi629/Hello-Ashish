﻿using System.Data;
using AtHoc.Data;
using AtHoc.IWS.Business.Database;


namespace AtHoc.IWS.Business.Adapter
{
    public class ProviderAdapter
    {
        public static string GetProviderCallerId(int providerId)
        {
            using (var db = new NgadDatabase())
            {
                string commandText = string.Format("select ISNULL(Caller_Id,'') from dbo.PRV_EXTENDED_PARAMS_TAB with (nolock) where provider_id ={0}", providerId);
                //check for uniqueness for all Alerts but current one
                db.CommandType = CommandType.Text;
                var callerId = db.ExecuteScalar<string>(commandText, "");
                return callerId ?? string.Empty;
            }
        }

    }
}