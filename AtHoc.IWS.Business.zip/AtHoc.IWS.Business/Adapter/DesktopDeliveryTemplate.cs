﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Business.Adapter
{
    public class DesktopDeliveryTemplate
    {
        public int TemplateId { get; set; }
        public string Name { get; set; }
        public string CommonName { get; set; }
        public string ImageGuid { get; set; }
        public string ImageAsBase64 { get; set; }
        public int PopupWidth { get; set; }
        public int PopupHeight { get; set; }
        public string PopupLocation { get; set; }  
        public bool IsFullScreen { get; set; }
        public string Xslt { get; set; }
        public int Timeout { get; set; }
        public string Origin { get; set; }
        public int LeftOffset { get; set; }
        public int TopOffset { get; set; }
        public string MotionOn { get; set; }
        public string MotionOff { get; set; }
        public bool HasCustomImage { get; set; }
    }
}
