﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Data;

namespace AtHoc.IWS.Business.Adapter
{
    public class ConfigurationSettingsAdapter
    {

        public static int GetSessionTimeOutInterval()
        {
            using (var db = new NgadDatabase())
            {
                string commandText =
                    string.Format("select isnull(SESSION_TIMEOUT_INTERVAL,30) from GLB_SECURITY_POLICY_TAB with (nolock)");
                //check for uniqueness for all Alerts but current one
                db.CommandType = CommandType.Text;
                var interval = db.ExecuteScalar<int>(commandText, 0);
                return interval;
            }

        }

        public static int GetPopupTimeoutInterval()
        {
            using (var db = new NgadDatabase())
            {
                string commandText =
                    string.Format("select isnull(POPUP_TIMEOUT_INTERVAL,0) from GLB_SECURITY_POLICY_TAB with (nolock)");
                //check for uniqueness for all Alerts but current one
                db.CommandType = CommandType.Text;
                var timeoutInterval = db.ExecuteScalar<int>(commandText, 0);
                return timeoutInterval;
            }
        }
    }
}

