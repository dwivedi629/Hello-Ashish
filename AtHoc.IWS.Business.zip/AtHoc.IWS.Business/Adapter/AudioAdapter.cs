﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Xml.XPath;
using AtHoc.Devices;
using AtHoc.Diagnostics;
using AtHoc.Infrastructure.Ioc;
using AtHoc.Infrastructure.Ioc.SimpleInjector;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Settings.Impl;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Helper;
using AtHoc.Systems;
using AtHoc.IWS.Business.Domain.Events;
using AtHoc.Publishing;
using AtHoc.IWS.Business.Context;
using AtHoc.Global.Resources.Interfaces;

namespace AtHoc.IWS.Business.Adapter
{
    public class AudioAdapter
    {
        private static IGlobalEntityLocaleFacade _globalEntityLocaleFacade;
        private static IAudioFileRepository _audioFileRepository;

        static AudioAdapter()
        {
            if (ServiceLocator.Current == null)
            {
                ServiceLocator.Current = new SimpleInjectorServiceLocator();
                ServiceLocator.Current.LoadAll();
            }
            _globalEntityLocaleFacade = ServiceLocator.Resolve<IGlobalEntityLocaleFacade>();
            _audioFileRepository = ServiceLocator.Resolve<IAudioFileRepository>();
        }

        public static XPathNodeIterator GetAudiosAsIterator(int providerId, string baseUrl, string queryString, bool filterByLocale)
        {
            var criteria = new AudioSearchCriteria
            {
                IsAudioPublic = true,
                ProviderId = providerId,
                FilterByLocale = filterByLocale,
                SearchString = new string[] { },
                Locale = RuntimeContext.Provider.BaseLocale
            };

            var _audioFileFacade = new AudioFileFacade(_audioFileRepository, _globalEntityLocaleFacade);
            var audios = _audioFileFacade.GetAudioList(criteria).ToList().Select(p => new
            {
                AudioId = p.Audio_Id,
                AudioName = p.Audio_Name,
                Description = p.Description,
                AudioCommonName = p.Audio_Common_Name,
                AudioSize = ((byte[])p.Audio_Blob).Length,
                Locale = p.Locale_Code
            });

            string url = baseUrl + queryString;
            XElement root = new XElement("audios");
            XElement child = null;

            foreach (var audio in audios)
            {
                int kb = audio.AudioSize / 1024;
                child = new XElement("audio",
                    new XElement("name", audio.AudioName),
                    new XElement("commonName", audio.AudioCommonName),
                    new XElement("description", audio.Description + ", " + kb.ToString() + "kb"),
                    new XElement("url", url.Replace("[AUDIO_ID]", audio.AudioId.ToString()))
                    );
                child.SetAttributeValue("id", audio.AudioId);
                child.SetAttributeValue("locale", audio.Locale);

                root.Add(child);
            }
            return root.CreateNavigator().Select("audio");
        }
    }
}
