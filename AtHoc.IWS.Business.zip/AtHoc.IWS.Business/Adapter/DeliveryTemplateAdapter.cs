﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Xml.XPath;
using AtHoc.Devices;
using AtHoc.Diagnostics;
using AtHoc.Infrastructure.Ioc;
using AtHoc.Infrastructure.Ioc.SimpleInjector;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Settings.Impl;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Helper;
using AtHoc.Systems;
using AtHoc.IWS.Business.Domain.Events;
using AtHoc.Publishing;
using AtHoc.IWS.Business.Context;
using AtHoc.Global.Resources.Interfaces;

namespace AtHoc.IWS.Business.Adapter
{
    public class DeliveryTemplateAdapter
    {
        private static IGlobalEntityLocaleFacade _globalEntityLocaleFacade;
        static DeliveryTemplateAdapter()
        {
            if (ServiceLocator.Current == null)
            {
                ServiceLocator.Current = new SimpleInjectorServiceLocator();
                ServiceLocator.Current.LoadAll();
            }
            _globalEntityLocaleFacade = ServiceLocator.Resolve<IGlobalEntityLocaleFacade>();
        }


        public static XPathNodeIterator GetDeliveryTemplatesAsIterator(int providerId, string deviceGroupCommonName)
        {
            var criteriaSpec = new DeliveryTemplateCriteria
                               {
                                   ProviderId = providerId,
                                   DeviceGroupCommonName = deviceGroupCommonName
                               };

            var deliveryFacade = new DeliveryTemplateFacade(_globalEntityLocaleFacade);             
            var templateList = deliveryFacade.GetDeliveryTemplates(criteriaSpec, ProviderHelper.GetProviderLocale(providerId));
            if (templateList == null)            
                return new XElement("NotifierTemplates").CreateNavigator().Select("NotifierTemplate");
            
            // sort delivery template by name
            templateList = templateList.ToList().OrderBy(t => t.Name).ToList();

            var root = new XElement("NotifierTemplates");
            foreach (var template in templateList)
            {
                var child = new XElement("NotifierTemplate", new XElement("Name", template.Name), new XElement("CommonName", template.Common_Name));
                child.SetAttributeValue("Id", template.Template_Id);
                child.SetAttributeValue("Locale", template.Locale_Code);
                root.Add(child);
            }
            return root.CreateNavigator().Select("NotifierTemplate");
        }

        public static DesktopDeliveryTemplate GetTemplateDetails(int templateId, int providerId, bool renderForPublishing = true)
        {
            var deliveryFacade = new DeliveryTemplateFacade(_globalEntityLocaleFacade);            
            var templateData = deliveryFacade.GetTemplateDetails(templateId, providerId, ProviderHelper.GetProviderLocale(providerId), renderForPublishing);
            return ExtractDetails(templateData); 
        }

        public static String GetDefautTemplateDefinitionBySeverity(int providerId, Priority severity,int deviceId)
        {
            var deliveryFacade = new DeliveryTemplateFacade(_globalEntityLocaleFacade);            
            var templateData = deliveryFacade.GetDefautTemplateDefinitionBySeverity(providerId, severity,deviceId);
            return templateData;   
        }

        public static TemplateDetailsModel GetTemplateByCommonNane(string commonName, int providerId)
        {
            var deliveryFacade = new DeliveryTemplateFacade(_globalEntityLocaleFacade);            
            var templateData = deliveryFacade.GetTemplateDetails(0, 0, ProviderHelper.GetProviderLocale(providerId),true, commonName);
            return templateData;
        }


        private static DesktopDeliveryTemplate ExtractDetails(TemplateDetailsModel templateData)
        {

            if (templateData == null)
                return null;

            var desktopTemplate = new DesktopDeliveryTemplate
            {
                TemplateId = templateData.templateId,
                Name = templateData.name,
                CommonName = templateData.templateCommonName,
                ImageGuid = !string.IsNullOrEmpty(templateData.templateImageGuid) ? templateData.templateImageGuid : templateData.vpsImageId,
                ImageAsBase64 = templateData.imageDisplayValue,
                HasCustomImage = templateData.imgOption != "SYSTEM",
                Xslt = !string.IsNullOrEmpty(templateData.templateDefinition) ? templateData.templateDefinition : templateData.standardXslt,
                PopupHeight = templateData.height.HasValue ? templateData.height.Value : Constants.DefaultHeight,
                PopupWidth = templateData.width.HasValue ? templateData.width.Value : Constants.DefaultWidth,
                Timeout = templateData.timeOutValue.HasValue ? GetTimeoutInSeconds(templateData.timeOutValue.Value, templateData.timeOutUnit) : 0,
                LeftOffset = templateData.leftOffset.HasValue ? templateData.leftOffset.Value : 0,
                TopOffset = templateData.topOffset.HasValue ? templateData.topOffset.Value : 0,
                MotionOn = templateData.motionOn,
                MotionOff = templateData.motionOff,
                IsFullScreen = templateData.fullScreenYN == "Y",
                PopupLocation = !string.IsNullOrEmpty(templateData.popupLocation) ? templateData.popupLocation : "SYSTRAY",
            };

            return desktopTemplate;
        }

        private static int GetTimeoutInSeconds(int timeoutValue, string timeoutUnit)
        {
            switch (timeoutUnit)
            {
                case "SEC":
                    return timeoutValue;
                case "MIN":
                    return timeoutValue*60;
                case "HRS":
                    return timeoutValue*60*60;
                case "DAY":
                    return timeoutValue*24*60*60;
            }
            return 0;
        }
    }
}
