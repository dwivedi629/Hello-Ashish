﻿namespace Agility.MicroClearNext.Web.Controllers
{
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;

    public class HomeController : Controller
    {
        [AllowAnonymous]
        public IActionResult Index()
        {
            // ICargoInfo info = new CargoInfo();
            // var a =  info.GetListJourneyManifest();
             return this.Redirect(@"../app/account/index.html");
           // return this.Redirect("/index.html");
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";
            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Error()
        {
            return View();
        }
    }
}
