﻿namespace Agility.MicroClearNext.Web
{
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Configuration;

    public class Startup
    {
        public Startup(IHostingEnvironment env)
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true)
                .AddEnvironmentVariables();  
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }
             
            app.UseSession(new SessionOptions() { CookieHttpOnly = false, CookieName = ".Fx.Session", IdleTimeout = TimeSpan.FromMinutes(Convert.ToDouble(FxSettings.SessionTimeOut)) });
            
            app.UseDefaultFiles();
            app.UseStaticFiles();
          
            app.UseMvc(routes =>
            {
                routes.MapRoute(
                   name: "webapi",
                   template: "api/{controller}/{action}/{id?}",
                   defaults: new { controller = "App", action = "Index" });

                routes.MapRoute(
                    name: "catchall",
                    template: "{*url}",
                    defaults: new { controller = "Home", action = "Index" },
                    constraints: new { url = @"^$|^([^\.])*$" });
            }); 
        }

    }
}
