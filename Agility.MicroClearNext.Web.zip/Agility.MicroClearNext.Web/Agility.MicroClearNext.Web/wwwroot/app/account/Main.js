"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var platform_browser_dynamic_1 = require("@angular/platform-browser-dynamic");
var AppModule_1 = require("./AppModule");
platform_browser_dynamic_1.platformBrowserDynamic().bootstrapModule(AppModule_1.AppModule);
//# sourceMappingURL=Main.js.map