"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var FrameworkModule_1 = require("framework/FrameworkModule");
var AccountRoutingModule_1 = require("./AccountRoutingModule");
var LoginComponent_1 = require("./LoginComponent");
var RegisterComponent_1 = require("./RegisterComponent");
var RegisterResolver_1 = require("./RegisterResolver");
var AccountService_1 = require("./AccountService");
var HomeComponent_1 = require("./HomeComponent");
var logoComponent_1 = require("./logo/logoComponent");
var imagesCarouselComponent_1 = require("./imagesCarousel/imagesCarouselComponent");
var forgotPwdComponent_1 = require("./forgotPwd/forgotPwdComponent");
var registrationModule_1 = require("./registration/registrationModule");
//import { SharedModule } from './Common/shared.module'
var DashboardModule_1 = require("../dashboard/DashboardModule");
//import { JourneyModule } from "../cargo/JourneyModule";
//import { JourneyRoutingModule } from "../cargo/JourneyRoutingModule";
var AccountModule = (function () {
    function AccountModule() {
    }
    return AccountModule;
}());
AccountModule = __decorate([
    core_1.NgModule({
        imports: [
            FrameworkModule_1.FrameworkModule,
            AccountRoutingModule_1.AccountRoutingModule,
            registrationModule_1.RegistrationModule,
            DashboardModule_1.DashboardModule,
        ],
        declarations: [
            LoginComponent_1.LoginComponent,
            RegisterComponent_1.RegisterComponent,
            HomeComponent_1.HomeComponent,
            imagesCarouselComponent_1.ImagesCarouselComponent,
            logoComponent_1.LogoComponent,
            forgotPwdComponent_1.ForgotPWDComponent
        ],
        providers: [
            AccountService_1.AccountService,
            RegisterResolver_1.RegisterNewResolver
        ]
    })
], AccountModule);
exports.AccountModule = AccountModule;
//# sourceMappingURL=AccountModule.js.map