﻿import { Injectable } from "@angular/core";
import { Http, Response, RequestOptions, URLSearchParams } from "@angular/http";
import { Observable } from "rxjs/Observable";
import { LoginViewModel } from "./viewmodels/LoginViewModel";
import { RegisterViewModel } from "./viewmodels/RegisterViewModel";
import { UserProfile } from "account/UserProfile";
import { OrganizationViewModel } from "./viewmodels/OrganizationViewModel";
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";

@Injectable()
export class AccountService {
    serviceDocument: ServiceDocument<UserProfile> = new ServiceDocument<UserProfile>();
    organizationModel: OrganizationViewModel[];
    constructor(private http: Http) {
    }

    login(loginModel: LoginViewModel): Observable<ServiceDocument<UserProfile>> {        
        return this.serviceDocument.login("/api/account/login", loginModel);
    }
    register(registerModel: RegisterViewModel): Observable<ServiceDocument<UserProfile>> {
        return this.http.post("/api/account/register", registerModel)
            .map((response: Response) => response.json());
    }
    getOrganizations(): Observable<OrganizationViewModel[]> {
        return this.http.get("/api/account/getOrganizations")
            .map((response: Response) => response.json());
    }
}