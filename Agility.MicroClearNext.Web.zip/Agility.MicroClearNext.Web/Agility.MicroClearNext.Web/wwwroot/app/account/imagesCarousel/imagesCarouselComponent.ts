import { Component, OnInit } from '@angular/core';
@Component({
    moduleId: module.id,
    selector: 'app-images-carousel',
    templateUrl: './imagesCarouselComponent.html',
    //styleUrls: ['./imagesCarouselComponent.css']
})
export class ImagesCarouselComponent implements OnInit {

    constructor() {
    }

    ngOnInit() {
    }
}
