import { Component, OnInit } from '@angular/core';
@Component({
    moduleId: module.id,
    selector: 'app-logo',
    //templateUrl:".app/"
    templateUrl: './logoComponent.html',
    //styleUrls: ['./logoComponent.css']
})
export class LogoComponent implements OnInit {

    constructor() {
    }

    ngOnInit() {
    }
}
