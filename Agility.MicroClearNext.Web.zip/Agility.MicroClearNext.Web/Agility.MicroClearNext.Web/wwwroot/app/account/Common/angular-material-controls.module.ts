import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { ExpansionPanelsModule } from 'ng2-expansion-panels';
//import { CdkTableModule } from '@angular/cdk';
import 'hammerjs';
import {
    MdButtonModule,
    MdCheckboxModule,
    MdRadioModule,
    MdCardModule,
    //MdTableModule,
    MdTabsModule,
    MdListModule,
    MdMenuModule,
    MdDialogModule,
    MdTooltipModule,
    MdInputModule,
    MdSelectModule,
    MdDatepickerModule,
    MdNativeDateModule,
    MdAutocompleteModule,
    MdSlideToggleModule,
    MD_PLACEHOLDER_GLOBAL_OPTIONS,
    MD_ERROR_GLOBAL_OPTIONS,
    showOnDirtyErrorStateMatcher
} from '@angular/material';

@NgModule({
    imports: [
        FlexLayoutModule,
        ExpansionPanelsModule,
        MdButtonModule,
        MdCheckboxModule,
        MdRadioModule,
        MdCardModule,
        //MdTableModule,
        //CdkTableModule,
        MdTabsModule,
        MdListModule,
        MdMenuModule,
        MdTooltipModule,
        MdInputModule,
        MdSelectModule,
        MdDatepickerModule,
        MdDialogModule,
        MdNativeDateModule,
        MdAutocompleteModule,
        MdSlideToggleModule
    ],
    exports: [
        FlexLayoutModule,
        ExpansionPanelsModule,
        MdButtonModule,
        MdCheckboxModule,
        MdRadioModule,
        MdCardModule,
        //MdTableModule,
        //CdkTableModule,
        MdTabsModule,
        MdListModule,
        MdMenuModule,
        MdTooltipModule,
        MdDialogModule,
        MdInputModule,
        MdSelectModule,
        MdDatepickerModule,
        MdNativeDateModule,
        MdSlideToggleModule,
        MdAutocompleteModule
    ],
    providers: [
        { provide: MD_ERROR_GLOBAL_OPTIONS, useValue: { errorStateMatcher: showOnDirtyErrorStateMatcher } }
    ]
})
export class AngularMaterialControlsModule {

}
