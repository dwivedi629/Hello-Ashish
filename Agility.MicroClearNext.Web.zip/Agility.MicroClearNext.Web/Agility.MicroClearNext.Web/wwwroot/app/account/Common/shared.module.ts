import {NgModule} from '@angular/core';

import { CustomTooltipDirective } from './custom-tooltip.directive';
import { CustomDatepickerDirective } from './custom-datepicker.directive';
import { CustomSelect2Directive } from './custom-select2.directive';
import { CustomTimepickerDirective } from './custom-timepicker.directive';
//import {ConsigneeDetailsModalComponent} from './inspection/inspection-request/inspection-request-details/consignee-details-modal/consignee-details-modal.component';
//import { EditItemInfoModalComponent } from './inspection/inspection-request/inspection-request-details/inspection-request-report/edit-item-info-modal/edit-item-info-modal.component';

@NgModule({
  declarations: [
    CustomTooltipDirective,
    CustomDatepickerDirective,
    CustomSelect2Directive,
    CustomTimepickerDirective,
    //ConsigneeDetailsModalComponent,
    //EditItemInfoModalComponent
  ],
  exports: [
    CustomTooltipDirective,
    CustomDatepickerDirective,
    CustomSelect2Directive,
    CustomTimepickerDirective,
    //ConsigneeDetailsModalComponent,
    //EditItemInfoModalComponent
  ]
})

export class SharedModule {
}

// Import this module at child level every time
