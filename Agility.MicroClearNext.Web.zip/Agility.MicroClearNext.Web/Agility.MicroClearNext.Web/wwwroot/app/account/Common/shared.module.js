"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var custom_tooltip_directive_1 = require("./custom-tooltip.directive");
var custom_datepicker_directive_1 = require("./custom-datepicker.directive");
var custom_select2_directive_1 = require("./custom-select2.directive");
var custom_timepicker_directive_1 = require("./custom-timepicker.directive");
//import {ConsigneeDetailsModalComponent} from './inspection/inspection-request/inspection-request-details/consignee-details-modal/consignee-details-modal.component';
//import { EditItemInfoModalComponent } from './inspection/inspection-request/inspection-request-details/inspection-request-report/edit-item-info-modal/edit-item-info-modal.component';
var SharedModule = (function () {
    function SharedModule() {
    }
    return SharedModule;
}());
SharedModule = __decorate([
    core_1.NgModule({
        declarations: [
            custom_tooltip_directive_1.CustomTooltipDirective,
            custom_datepicker_directive_1.CustomDatepickerDirective,
            custom_select2_directive_1.CustomSelect2Directive,
            custom_timepicker_directive_1.CustomTimepickerDirective,
        ],
        exports: [
            custom_tooltip_directive_1.CustomTooltipDirective,
            custom_datepicker_directive_1.CustomDatepickerDirective,
            custom_select2_directive_1.CustomSelect2Directive,
            custom_timepicker_directive_1.CustomTimepickerDirective,
        ]
    })
], SharedModule);
exports.SharedModule = SharedModule;
// Import this module at child level every time
//# sourceMappingURL=shared.module.js.map