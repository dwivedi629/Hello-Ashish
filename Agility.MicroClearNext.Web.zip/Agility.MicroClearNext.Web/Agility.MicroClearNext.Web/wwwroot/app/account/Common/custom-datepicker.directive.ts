import {Directive, ElementRef, Output, OnInit, EventEmitter } from '@angular/core';

declare var $: any;
@Directive({
  selector: '[appCustomDatepicker]'
})
export class CustomDatepickerDirective implements OnInit {
  public monthsArray = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  public selectedDate = '';
  @Output() onDateChange: EventEmitter<any> = new EventEmitter();
  el: ElementRef;
  constructor(el: ElementRef) {
    this.el = el;
  }
  ngOnInit() {
    $(this.el.nativeElement).datepicker({
      format: 'dd-mm-yyyy',
      // format: 'dd MM, YYYY',
      // setDate: new Date(),
      // setDate: (new Date().getDate() < 10 ? '0' + new Date().getDate() : new Date().getDate()) +
      //   '-' + this.monthsArray[new Date().getMonth()] + '-' + new Date().getFullYear(),
      autoHide: true,
      autoPick: true
    });
    $(this.el.nativeElement).on('change', (event, args) => {
      console.log(typeof event.target.value, event.target.value, (new Date(event.target.value).getDate() < 10 ? '0' + new Date(event.target.value).getDate() :
          new Date(event.target.value).getDate()) +
        ' ' + this.monthsArray[new Date(event.target.value).getMonth()] + ',' + new Date(event.target.value).getFullYear());

      this.selectedDate = (new Date(event.target.value).getDate() < 10 ? '0' + new Date(event.target.value).getDate() :
          new Date(event.target.value).getDate()) +
        '-' + this.monthsArray[new Date(event.target.value).getMonth()] + '-' + new Date(event.target.value).getFullYear();

      this.onDateChange.emit(this.selectedDate);
      // this.onDateChange.emit(event.target.value);
    });
    $(this.el.nativeElement).on('pick.datepicker', function (event) {
      // console.log(typeof event.target.value, event.target.value, event.date, '****', event.view);
      // this.onDateChange.emit(event.target.value);
    });
  }
}
