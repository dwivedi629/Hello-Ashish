import {Directive, ElementRef, Input, Output, EventEmitter, OnInit} from '@angular/core';

declare var jQuery: any;
@Directive({
  selector: '[appCustomSelect]'
})
export class CustomSelect2Directive implements OnInit {
  @Input() selectOptions: any;
  el: ElementRef;
  @Output() onSelectChangeEvent: EventEmitter<any> = new EventEmitter();

  constructor(el: ElementRef) {
    this.el = el;
  }
  ngOnInit() {
    jQuery(this.el.nativeElement).select2(this.selectOptions);
    jQuery(this.el.nativeElement).on('change', (e, args) => {
      this.onSelectChangeEvent.emit(e.target.value);
    });
  }
}
