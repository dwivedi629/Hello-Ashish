"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var CustomSelect2Directive = (function () {
    function CustomSelect2Directive(el) {
        this.onSelectChangeEvent = new core_1.EventEmitter();
        this.el = el;
    }
    CustomSelect2Directive.prototype.ngOnInit = function () {
        var _this = this;
        jQuery(this.el.nativeElement).select2(this.selectOptions);
        jQuery(this.el.nativeElement).on('change', function (e, args) {
            _this.onSelectChangeEvent.emit(e.target.value);
        });
    };
    return CustomSelect2Directive;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], CustomSelect2Directive.prototype, "selectOptions", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", core_1.EventEmitter)
], CustomSelect2Directive.prototype, "onSelectChangeEvent", void 0);
CustomSelect2Directive = __decorate([
    core_1.Directive({
        selector: '[appCustomSelect]'
    }),
    __metadata("design:paramtypes", [core_1.ElementRef])
], CustomSelect2Directive);
exports.CustomSelect2Directive = CustomSelect2Directive;
//# sourceMappingURL=custom-select2.directive.js.map