import {Directive, ElementRef, Input, OnInit} from '@angular/core';

declare var $: any;
@Directive({
  selector: '[appCustomTooltip]'
})
export class CustomTooltipDirective implements OnInit {
  @Input() tooltipTitle: any;

  el: ElementRef;

  constructor(el: ElementRef) {
    this.el = el;
  }

  ngOnInit() {
    $(this.el.nativeElement).tooltip({
      placement: 'bottom',
      title: this.tooltipTitle
    });
  }
}
