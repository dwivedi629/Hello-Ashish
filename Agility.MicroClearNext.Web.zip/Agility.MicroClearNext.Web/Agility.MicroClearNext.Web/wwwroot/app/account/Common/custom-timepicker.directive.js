"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var CustomTimepickerDirective = (function () {
    function CustomTimepickerDirective(el) {
        this.onTimeChange = new core_1.EventEmitter();
        this.el = el;
    }
    CustomTimepickerDirective.prototype.ngOnInit = function () {
        var _this = this;
        $(this.el.nativeElement).timepicker({
            showSeconds: true,
            showMeridian: false,
            icons: { up: 'icon-up-caret',
                down: 'icon-down-caret' }
        });
        /* $(this.el.nativeElement).timepicker().on('changeTime.timepicker', function(e) {
         console.log('The time is ' + e.time.value, e.time.hours, e.time.minutes, e.time.meridian);
         });*/
        // $(this.el.nativeElement).on('onTimeChange', (event, args) => {
        //   console.log(typeof event.target.value, event.target.value, '**changeA**');
        //   this.onTimeChange.emit(event.target.value);
        // });
        $(this.el.nativeElement).on('blur', function (event, args) {
            console.log(typeof event.target.value, event.target.value, '**changeB**');
            _this.onTimeChange.emit(event.target.value);
        });
        $(this.el.nativeElement).on('change', function (event, args) {
            console.log(typeof event.target.value, event.target.value, '**changeC**');
            _this.onTimeChange.emit(event.target.value);
            console.log('**AfterchangeC**');
        });
    };
    return CustomTimepickerDirective;
}());
__decorate([
    core_1.Output(),
    __metadata("design:type", core_1.EventEmitter)
], CustomTimepickerDirective.prototype, "onTimeChange", void 0);
CustomTimepickerDirective = __decorate([
    core_1.Directive({
        selector: '[appCustomTimepicker]'
    }),
    __metadata("design:paramtypes", [core_1.ElementRef])
], CustomTimepickerDirective);
exports.CustomTimepickerDirective = CustomTimepickerDirective;
//# sourceMappingURL=custom-timepicker.directive.js.map