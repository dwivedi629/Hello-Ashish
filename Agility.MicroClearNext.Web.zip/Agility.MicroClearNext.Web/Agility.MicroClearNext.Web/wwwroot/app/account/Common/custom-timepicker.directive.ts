import {Directive, ElementRef, Output, OnInit, EventEmitter } from '@angular/core';

declare var $: any;
@Directive({
  selector: '[appCustomTimepicker]'
})
export class CustomTimepickerDirective implements OnInit  {
  @Output() onTimeChange: EventEmitter<any> = new EventEmitter();
  el: ElementRef;
  constructor(el: ElementRef) {
    this.el = el;
  }
  ngOnInit() {
    $(this.el.nativeElement).timepicker({
      showSeconds: true,
      showMeridian: false,
      icons: { up: 'icon-up-caret',
        down: 'icon-down-caret'}
    });
    /* $(this.el.nativeElement).timepicker().on('changeTime.timepicker', function(e) {
     console.log('The time is ' + e.time.value, e.time.hours, e.time.minutes, e.time.meridian);
     });*/
    // $(this.el.nativeElement).on('onTimeChange', (event, args) => {
    //   console.log(typeof event.target.value, event.target.value, '**changeA**');
    //   this.onTimeChange.emit(event.target.value);
    // });
    $(this.el.nativeElement).on('blur', (event, args) => {
      console.log(typeof event.target.value, event.target.value, '**changeB**');
      this.onTimeChange.emit(event.target.value);
    });
    $(this.el.nativeElement).on('change', (event, args) => {
      console.log(typeof event.target.value, event.target.value, '**changeC**');
      this.onTimeChange.emit(event.target.value);
      console.log('**AfterchangeC**');
    });
  }
}
