"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var CustomDatepickerDirective = (function () {
    function CustomDatepickerDirective(el) {
        this.monthsArray = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        this.selectedDate = '';
        this.onDateChange = new core_1.EventEmitter();
        this.el = el;
    }
    CustomDatepickerDirective.prototype.ngOnInit = function () {
        var _this = this;
        $(this.el.nativeElement).datepicker({
            format: 'dd-mm-yyyy',
            // format: 'dd MM, YYYY',
            // setDate: new Date(),
            // setDate: (new Date().getDate() < 10 ? '0' + new Date().getDate() : new Date().getDate()) +
            //   '-' + this.monthsArray[new Date().getMonth()] + '-' + new Date().getFullYear(),
            autoHide: true,
            autoPick: true
        });
        $(this.el.nativeElement).on('change', function (event, args) {
            console.log(typeof event.target.value, event.target.value, (new Date(event.target.value).getDate() < 10 ? '0' + new Date(event.target.value).getDate() :
                new Date(event.target.value).getDate()) +
                ' ' + _this.monthsArray[new Date(event.target.value).getMonth()] + ',' + new Date(event.target.value).getFullYear());
            _this.selectedDate = (new Date(event.target.value).getDate() < 10 ? '0' + new Date(event.target.value).getDate() :
                new Date(event.target.value).getDate()) +
                '-' + _this.monthsArray[new Date(event.target.value).getMonth()] + '-' + new Date(event.target.value).getFullYear();
            _this.onDateChange.emit(_this.selectedDate);
            // this.onDateChange.emit(event.target.value);
        });
        $(this.el.nativeElement).on('pick.datepicker', function (event) {
            // console.log(typeof event.target.value, event.target.value, event.date, '****', event.view);
            // this.onDateChange.emit(event.target.value);
        });
    };
    return CustomDatepickerDirective;
}());
__decorate([
    core_1.Output(),
    __metadata("design:type", core_1.EventEmitter)
], CustomDatepickerDirective.prototype, "onDateChange", void 0);
CustomDatepickerDirective = __decorate([
    core_1.Directive({
        selector: '[appCustomDatepicker]'
    }),
    __metadata("design:paramtypes", [core_1.ElementRef])
], CustomDatepickerDirective);
exports.CustomDatepickerDirective = CustomDatepickerDirective;
//# sourceMappingURL=custom-datepicker.directive.js.map