export interface IForgotPWD {
  emailId: string;
}
