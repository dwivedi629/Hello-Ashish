import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { IForgotPWD } from './forgotpwd';

@Component({
    moduleId: module.id,
    selector: 'app-forgot-pwd',
    templateUrl: './forgotPwdComponent.html',
    //styleUrls: ['./forgotPwdComponent.css']
})

export class ForgotPWDComponent implements OnInit {
    public forgotPWDForm: FormGroup;
    public forgotPWDFormSubmitted: boolean;

    constructor(private _fb: FormBuilder) {
    }

    ngOnInit() {
        this.forgotPWDForm = this._fb.group({
            emailId: ['', [<any>Validators.required, <any>Validators.pattern('^[_a-z0-9]+(\.[_a-z0-9]+)*@[a-z0-9-]+(\.[a-z0-9' +
                '-]+)*(\.[a-z]{2,4})$')]]
        });
    }

    validateForgotPWD(model: IForgotPWD, isValid: boolean) {
    }
}
