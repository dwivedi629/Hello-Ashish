import { Component } from '@angular/core';

@Component({
    moduleId: module.id,
  selector: 'app-registration',
  templateUrl: './registrationComponent.html',
  styleUrls: ['./registrationComponent.css']
})

export class RegistrationComponent {}
