"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
/// <reference path="registrationwizard/successdialog/successdialogcomponent.ts" />
var core_1 = require("@angular/core");
var common_1 = require("@angular/common");
var router_1 = require("@angular/router");
var forms_1 = require("@angular/forms");
//import { SharedModule } from '../Common/shared.module';
var passwordStrengthBarComponent_1 = require("./registrationWizard/accountInfo/passwordStrengthBarComponent");
var registrationComponent_1 = require("./registrationComponent");
var registrationHeaderComponent_1 = require("./registrationHeader/registrationHeaderComponent");
var registrationSelectionComponent_1 = require("./registrationSelection/registrationSelectionComponent");
var registrationWizardComponent_1 = require("./registrationWizard/registrationWizardComponent");
var organizationInfoComponent_1 = require("./registrationWizard/organizationInfo/organizationInfoComponent");
var accountInfoComponent_1 = require("./registrationWizard/accountInfo/accountInfoComponent");
var personalInfoComponent_1 = require("./registrationWizard/personalInfo/personalInfoComponent");
var addressInfoComponent_1 = require("./registrationWizard/addressInfo/addressInfoComponent");
var otherInfoComponent_1 = require("./registrationWizard/otherInfo/otherInfoComponent");
var previewComponent_1 = require("./registrationWizard/preview/previewComponent");
var angular_material_controls_module_1 = require("../Common/angular-material-controls.module");
var index_1 = require("ngx-accordion/index");
var ng2_expansion_panels_1 = require("ng2-expansion-panels");
var SuccessDialogComponent_1 = require("./registrationWizard/successDialog/SuccessDialogComponent");
var registrationRoutes = [
    {
        path: 'registration',
        component: registrationComponent_1.RegistrationComponent,
        children: [
            {
                path: 'selection',
                component: registrationSelectionComponent_1.RegistrationSelectionComponent,
                data: {
                    title: 'Registration Selection'
                }
            },
            {
                path: 'wizard',
                component: registrationWizardComponent_1.RegistrationWizardComponent,
                children: [
                    {
                        path: 'organization-info',
                        component: organizationInfoComponent_1.OrganizationInfoComponent,
                        data: {
                            title: 'Organization Info',
                            stepCount: 1
                        }
                    },
                    {
                        path: 'account-info',
                        component: accountInfoComponent_1.AccountInfoComponent,
                        data: {
                            title: 'Account Info',
                            stepCount: 2
                        }
                    },
                    {
                        path: 'personal-info',
                        component: personalInfoComponent_1.PersonalInfoComponent,
                        data: {
                            title: 'Personal Info',
                            stepCount: 3
                        }
                    },
                    {
                        path: 'address-info',
                        component: addressInfoComponent_1.AddressInfoComponent,
                        data: {
                            title: 'Address Info',
                            stepCount: 4
                        }
                    },
                    {
                        path: 'other-info',
                        component: otherInfoComponent_1.OtherInfoComponent,
                        data: {
                            title: 'Other Info',
                            stepCount: 5
                        }
                    },
                    {
                        path: 'preview',
                        component: previewComponent_1.PreviewComponent,
                        data: {
                            title: 'Preview',
                            stepCount: 6
                        }
                    },
                    {
                        path: '',
                        redirectTo: 'account-info',
                        pathMatch: 'full'
                    },
                    {
                        path: '**',
                        redirectTo: 'account-info',
                        pathMatch: 'full'
                    }
                ]
            },
            {
                path: '',
                redirectTo: 'selection',
                pathMatch: 'full'
            },
            {
                path: '**',
                redirectTo: 'selection',
                pathMatch: 'full'
            }
        ]
    }
];
var RegistrationRoutingModule = (function () {
    function RegistrationRoutingModule() {
    }
    return RegistrationRoutingModule;
}());
RegistrationRoutingModule = __decorate([
    core_1.NgModule({
        declarations: [
            passwordStrengthBarComponent_1.PasswordStrengthBarComponent,
            registrationComponent_1.RegistrationComponent,
            registrationSelectionComponent_1.RegistrationSelectionComponent,
            registrationHeaderComponent_1.RegistrationHeaderComponent,
            registrationWizardComponent_1.RegistrationWizardComponent,
            personalInfoComponent_1.PersonalInfoComponent,
            organizationInfoComponent_1.OrganizationInfoComponent,
            accountInfoComponent_1.AccountInfoComponent,
            addressInfoComponent_1.AddressInfoComponent,
            otherInfoComponent_1.OtherInfoComponent,
            previewComponent_1.PreviewComponent,
            SuccessDialogComponent_1.SuccessDialogComponent
        ],
        imports: [
            common_1.CommonModule,
            forms_1.FormsModule,
            forms_1.ReactiveFormsModule,
            // SharedModule,
            angular_material_controls_module_1.AngularMaterialControlsModule,
            router_1.RouterModule.forChild(registrationRoutes),
            index_1.AccordionModule,
            ng2_expansion_panels_1.ExpansionPanelsModule
        ],
        exports: [
            router_1.RouterModule,
            //SharedModule,
            registrationComponent_1.RegistrationComponent
        ],
        entryComponents: [
            SuccessDialogComponent_1.SuccessDialogComponent
        ]
    })
], RegistrationRoutingModule);
exports.RegistrationRoutingModule = RegistrationRoutingModule;
//# sourceMappingURL=registrationRoutingModule.js.map