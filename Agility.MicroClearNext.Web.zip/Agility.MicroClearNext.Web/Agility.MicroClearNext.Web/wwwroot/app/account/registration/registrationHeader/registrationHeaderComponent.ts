import { Component, OnInit } from '@angular/core';

@Component({
    moduleId: module.id,
  selector: 'app-registration-header',
  templateUrl: './registrationHeaderComponent.html'
})
export class RegistrationHeaderComponent implements OnInit {
  menuFilter: any = {name: ''};

  constructor() { }

  ngOnInit() {
  }

}
