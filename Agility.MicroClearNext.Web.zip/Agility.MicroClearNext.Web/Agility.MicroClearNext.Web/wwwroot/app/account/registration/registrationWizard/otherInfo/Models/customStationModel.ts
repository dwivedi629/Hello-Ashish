import { ProfileModel } from "framework/profile/ProfileModel";

export class CustomStationModel extends ProfileModel {
    customStationId: string;
    stationCode: string;
    stationName: string;
}
