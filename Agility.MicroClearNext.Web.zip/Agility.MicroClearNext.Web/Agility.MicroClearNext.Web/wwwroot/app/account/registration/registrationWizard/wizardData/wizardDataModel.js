"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var FormData = (function () {
    function FormData() {
        this.IndividualFile = [];
    }
    return FormData;
}());
exports.FormData = FormData;
var accountInfo = (function () {
    function accountInfo() {
    }
    return accountInfo;
}());
exports.accountInfo = accountInfo;
var personalInfo = (function () {
    function personalInfo() {
    }
    return personalInfo;
}());
exports.personalInfo = personalInfo;
//# sourceMappingURL=wizardDataModel.js.map