export interface IAccount {
  emailId: string;
  password: string;
  confirmPassword: string;
  /*pwdChallengeQuestion: string;
  challengeResponse: string;*/
}
