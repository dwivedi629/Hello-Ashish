import { ProfileModel } from "framework/profile/ProfileModel";

export class AddressModel extends ProfileModel {
    addressId: number;
    parentId: number;
    parentType: string;
    isPrimary: string;
    addressLine1: string;
    addressLine2: string;
    addressLine3: string;
    cityId: number;
    stateId: number;
    countryId: number;
    postalCodeId: number;
    nmCity: string;
    nmState: string;
    nmCountry: string;
    nmPostalcode: string;
    ownerCSId: number;
    ownerLocId: number;
    createdDate: Date;
}
