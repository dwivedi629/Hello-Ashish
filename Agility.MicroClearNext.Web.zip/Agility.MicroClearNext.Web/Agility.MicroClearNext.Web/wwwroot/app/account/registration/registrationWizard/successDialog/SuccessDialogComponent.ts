import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
//import { MdDialog,MdDialogRef } from '@angular/material';
import { MdDialog, MdDialogRef } from '@angular/material';
@Component({
    moduleId: module.id,
    selector: 'app-SuccessDialogue',
    templateUrl: './SuccessDialogComponent.html',
    //providers: [MdDialogRef],
    styleUrls: ['./SuccessDialogComponent.css']
})

export class SuccessDialogComponent implements OnInit {    
    public : boolean;
  
    constructor(private router: Router) {   
    }

    ngOnInit() {        
    // public dialogRef: MdDialogRef<SuccessDialogComponent>;
    }

    goToLogin()
    {
        //this.dialogRef.close();
    this.router.navigate(['/Account/Login']);
    }
}