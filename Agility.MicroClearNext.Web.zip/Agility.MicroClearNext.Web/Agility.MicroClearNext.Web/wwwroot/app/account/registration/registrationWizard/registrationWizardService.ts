import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class RegistrationWizardService {
  // Observable string sources
  private stepCompletionStatusSource = new Subject<number>();

  // Observable string streams
  stepCompletionStatusEmitted$ = this.stepCompletionStatusSource.asObservable();

  // Service message commands
  emitStepCompletionStatus(stepCompletionStatus: number) {
    this.stepCompletionStatusSource.next(stepCompletionStatus);
  }
}
