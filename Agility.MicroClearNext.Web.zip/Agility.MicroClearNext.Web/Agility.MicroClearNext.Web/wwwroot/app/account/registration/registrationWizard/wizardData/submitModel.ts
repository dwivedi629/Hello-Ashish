﻿import { bankDetails, docData } from "./wizardDataModel";

export class SubmitModel {
    public stakeHoldertype: string
    public emailID: string;
    public password: string;
    public confirmPassword: string;
    public firstName: string;
    public lastName: string;
    public gender: string;
    public nationality: string;
    public IdNumber: string;
    public IdType: string;
    public country: string;
    public state: string;
    public city: string;
    public pin: string;
    public addressLine1: string;
    public addressLine2: string;
    public mobCode: string;
    public mobNumber: string;
    public primaryTelCode: string;
    public primaryTelNumber: string;
    public altCode: string;
    public altNumber: string;
    public idocTypeVal: string;
    public faxCode: string;
    public faxNumber: string;
    public customStationId: string;
    public registeredCSId: string;
    public odocTypeVal: string;
    public businessEntityId: string;
    public regAuthority: string;
    public businessEntity: string;
    public organizationName: string;
    public brn: string;
    public gstNumber: string;    
    public banks: bankDetails[]=[];
    public indvidualDoc: docData[] = [];
    public orgDoc: docData[] = [];


    public assocustomStation: string;
    public registeredCSName: string;
    public countryname: string;
    public statename: string;
    public cityname: string;
    public pincode: string;
    public regAuthorityName: string;

}
