﻿
import { ProfileModel } from "framework/profile/ProfileModel";

export class CountryModel extends ProfileModel {
    countryId: string;

    countryName?: string;
}