﻿import { Injectable } from "@angular/core";
import { Http, Headers, Response, RequestOptions, URLSearchParams } from "@angular/http";
import { Observable } from "rxjs/Observable";

import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { AddressModel } from "./addressinfo/models/addressmodel";
import { CityModel } from "./addressinfo/models/citymodel";
import { StateModel } from "./addressinfo/models/statemodel";
import { CountryModel } from "./addressinfo/models/countrymodel";
import { BankModel } from '../registrationwizard/otherinfo/models/bankModel';
import { CustomStationModel } from '../registrationwizard/otherinfo/models/customstationmodel';
import { RegistrationTypeModel, GenderModel } from './personalinfo/model/registrationtypemodel'
import { DocumentTypeModel } from './personalinfo/model/documenttypemodel';
import { SubmitModel } from './wizardData/submitModel';
import { TeleCodeModel } from "./addressinfo/models/telecodemodel";
import { PostalCodeModel } from "./addressinfo/models/postalcodemodel";

@Injectable()
export class RegistrationService {

    constructor(private _http: Http) { }
    headers = new Headers({ 'Content-Type': 'application/json' });
    options = new RequestOptions({ headers: this.headers });
    country: CountryModel[];
    bank: BankModel[];
    customStation: CustomStationModel[];

    registrationType: RegistrationTypeModel[];
    document: DocumentTypeModel[];
    documentType: RegistrationTypeModel[];

    SubmitRegData(formModel: SubmitModel): Observable<any[]> {
        let input = new FormData();
        //input.append("formModel", formModel);
        return this._http.post("/api/Manager/RegisterUser", formModel, this.options)
            .map(this.extractSubmitData).catch(this.handleError);
    }


    upload(fileToUpload: any) {
        console.log(fileToUpload);
        let input = new FormData();
        input.append("file", fileToUpload);
        console.log(input);
        return this._http.post("/api/Manager/uploadFile", input);
    }


    getCountry(): Observable<any[]>
    {
        return this._http.get("/api/Master/GetCountry", this.options).
            map(this.extractData).catch(this.handleError);
    }
    getState(id:number): Observable<any[]> {
        return this._http.get("/api/Master/GetState/" + id, this.options).
            map(this.extractDataState).catch(this.handleError);
    }
    getCity(id:number): Observable<any[]> {
        return this._http.get("/api/Master/GetCity/" + id, this.options).
            map(this.extractDataCity).catch(this.handleError);
    }
    getBanks(): Observable<any[]> {
        return this._http.get("/api/Master/GetBank", this.options).
            map(this.extractDataBank).catch(this.handleError);
    }

    getCustomStation(): Observable<any[]> {
        return this._http.get("/api/Master/GetCustomStation", this.options).
            map(this.extractDataCS).catch(this.handleError);
    }
    getTeleCode(id: number): Observable<any[]> {
        return this._http.get("/api/Master/GetTeleCode/" + id, this.options).
            map(this.extractDataTeleCode).catch(this.handleError);
    }
    getPostalCode(id: number): Observable<any[]> {
        return this._http.get("/api/Master/GetPostalCode/" + id, this.options).
            map(this.extractDataPostalCode).catch(this.handleError);
    }
    getIdType(): Observable<any[]> {
        return this._http.get("/api/Master/GetIdType", this.options).
            map(this.extractDataRegistartionType).catch(this.handleError);

    }
    getDocumentType(): Observable<any[]> {
        return this._http.get("/api/Master/GetDocumentType", this.options).
            map(this.extractDataDocumentType).catch(this.handleError);
    }

    getRegistrationTypeById(id: number): Observable<any[]> {
        return this._http.get("/api/Master/GetRegistrationTypeById/" + id, this.options).
            map(this.extractDataRegistartion).catch(this.handleError);
    }

    getGender(): Observable<any[]> {
        return this._http.get("/api/Master/GetGender", this.options).
            map(this.extractDataGender).catch(this.handleError);
    }

    getRegistrationAuthority(): Observable<any[]> {
        return this._http.get("/api/Master/GetRegistrationAuthority", this.options).
            map(this.extractDomainData).catch(this.handleError);
    }

    getBussinessEntity(): Observable<any[]> {
        return this._http.get("/api/Master/GetBussinessEntity", this.options).
            map(this.extractDomainData).catch(this.handleError);
    }




    extractDomainData(res: Response) {
        let response = <any[]>res.json().domainData;
        let body = response;
        return body || [];
    }

    extractDataTeleCode(res: Response) {
        let response = <TeleCodeModel[]>res.json().telePhoneCountryCode;
        let body = response;
        return body || [];
    }
    extractDataPostalCode(res: Response) {
        let response = <PostalCodeModel[]>res.json().postalCode;
        let body = response;
        return body || [];
    }
    extractDataGender(res: Response) {
        let response = <any[]>res.json().gender;
        let body = response;
        return body || [];
    }

    extractDataRegistartionType(res: Response) {
        let response = <RegistrationTypeModel[]>res.json().registrationType;
        let body = response;
        return body || [];
    }
    extractDataRegistartion(res: Response) {
        let response = <RegistrationTypeModel[]>res.json().documentType;
        let body = response;
        return body || [];
    }
    extractDataDocumentType(res: Response) {
        let response = <DocumentTypeModel[]>res.json().document;
        let body = response;
        return body || [];
    }

    extractDataBank(res: Response) {
        let response = <BankModel[]>res.json().bank;
        let body = response;
        return body || [];
    }
    extractDataCS(res: Response) {
        let response = <CustomStationModel[]>res.json().customStation;
        let body = response;
        return body || [];
    }
    extractData(res: Response) {
        let response = <CountryModel[]>res.json().country;
        let body = response;
        return body || [];
    }
    extractDataState(res: Response) {
        let response = <StateModel[]>res.json().state;
        let body = response;
        return body || [];
    }
    extractDataCity(res: Response) {
        let response = <CityModel[]>res.json().city;
        let body = response;
        return body || [];
    }

    extractSubmitData(res: Response) {
        let response = res.json();
        let body = response;
        return body || [];
    }


    handleError(error: Response | any) {
        let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        console.log(errMsg);
        let errorResponse = error.json();
        if (errorResponse.StatusCode == 401) {
            location.reload();
        }
        return Observable.throw(errMsg);
    }
}