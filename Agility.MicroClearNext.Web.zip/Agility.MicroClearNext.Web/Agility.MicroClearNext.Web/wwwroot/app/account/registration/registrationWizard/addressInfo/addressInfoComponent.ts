import {Component, OnInit} from '@angular/core';
import {RegistrationWizardService} from '../registrationWizardService';
import {FormGroup, FormControl, FormBuilder, Validators} from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from "rxjs/Observable";
import { FormDataService } from "../wizardData/wizardDataService";
import { addressInfo } from "../wizardData/wizardDataModel";
import { RegistrationService } from '../registrationservice';
import { IAddress } from './addressInfo';
import { CountryModel } from "./models/CountryModel";
import { StateModel } from './models/statemodel';
import { CityModel } from './models/cityModel';
import { PostalCodeModel } from './models/postalcodemodel';
import { TeleCodeModel } from './models/telecodemodel'; 
 
@Component({
    moduleId: module.id,
  selector: 'app-address-info',
  templateUrl: './addressInfoComponent.html',
  providers: [RegistrationWizardService, RegistrationService],
  styleUrls: ['./addressInfoComponent.css']
})
export class AddressInfoComponent implements OnInit {
  public addressInfoForm: FormGroup;
  public addressInfoFormSubmitted: boolean;
  public selectOptions = {
    'minimumResultsForSearch': '-1'
  };


  public countries: CountryModel[];
  public state: StateModel[];
  public city: CityModel[];
  public postalCodes: PostalCodeModel[];
  public telePhoneCountryCode: TeleCodeModel[];
  public teleCode1: TeleCodeModel[];
  public teleCode2: TeleCodeModel[];
  public selectedValue: number;
  errorMessage: string;
  public postalCode: PostalCodeModel[];
  public countryname: string;
  public statename: string;
  public cityname: string;
  public pincode: string;

  myControl: FormControl = new FormControl();
  filteredOptions: Observable<any[]>;

  constructor(private _fb: FormBuilder,
              private router: Router,
              private activatedRoute: ActivatedRoute,
              private registrationWizardService: RegistrationWizardService,
              private FormDataService: FormDataService,
              private registrationService: RegistrationService) {
  }

  public addressInfo: addressInfo;
  public addressInfomodel: IAddress;

  ngOnInit() {

      this.filteredOptions = this.myControl.valueChanges
          .startWith(null)
          .map(val => val ? this.filter(val) : this.postalCode.slice());
      this.addressInfoForm = this._fb.group({
          country: [''],    //[<any>Validators.required]], 
      state: [''],       //[<any>Validators.required, <any>Validators.minLength(8)]],
      city: [''],          //[<any>Validators.required, <any>Validators.minLength(8)]],
      countryname: [''],
      statename: [''],
      cityname: [''],
      pin: [''],  // [<any>Validators.required]],
      pincode: [''],
      addressLine1: ['',[<any>Validators.required]],
      addressLine2: [''],
      mobCode: [''],     //[<any>Validators.required]],
      mobNumber: [''],
      primaryTelCode: [''],
      primaryTelNumber: [''],
      altCode:[''],
      altNumber: [''],
      faxCode: [''],
      faxNumber: [''],
      });

      this.addressInfo = this.FormDataService.getaddressInfo();
      this.getCountries();
      if (this.addressInfo.state != undefined) {
          this.GetStatesByCountry(this.addressInfo.country);
          this.getTeleCode(this.addressInfo.country);
      }
      if (this.addressInfo.state) {
          this.GetCitiesByState(this.addressInfo.state);
          this.getPostalCode(this.addressInfo.state);
      }
  }

  validateAddressInfo(model: IAddress, isValid: boolean) {
      if (isValid) {
          if (model.country != undefined)
              model.countryname = this.countries.find(x => x.countryId == model.country).countryName;
          if (model.state != undefined)
              model.statename = this.state.find(x => x.stateId == model.state).stateName;
          if (model.city != undefined)
              model.cityname = this.city.find(x => x.cityId == model.city).cityName;
          if (model.pincode != undefined)
              model.pin = this.postalCode.find(x => x.postalCode == model.pincode).postalCodeId;
          this.FormDataService.setaddressInfo(model);
          this.router.navigate(['/registration/wizard/other-info']);
      }
  }

  goToPreviousStep() {
      this.router.navigate(['/Account/Login']);
  }



  getCountries() {
      this.registrationService.getCountry().subscribe
          (response => { this.countries = response;});
  }


  GetStatesByCountry(id: any) {
     this.registrationService.getState(id)
          .subscribe(Response => { this.state = Response },
          error => this.errorMessage = <any>error
          );
  }
  GetCitiesByState(id: any) {
      this.registrationService.getCity(id)
          .subscribe(Response => {this.city = Response},
          error => this.errorMessage = <any>error
          );
  }
 getTeleCode(id:any) {
        this.registrationService.getTeleCode(id)
            .subscribe(Response => {this.telePhoneCountryCode = Response },
             error => this.errorMessage = <any>error
            );
    }
  getPostalCode(id: any) {
      this.registrationService.getPostalCode(id).subscribe
          (response => {
              this.postalCodes = response;
              this.postalCode = this.postalCodes;
          },
          error => this.errorMessage = <any>error
          );
 }
  getNAuto(prefix: string) {
      this.postalCode = null;
      this.postalCode = this.postalCodes.filter((item) => item.postalCode.toLowerCase().startsWith(prefix.toLowerCase()));
  }
  filter(val: string): any[] {
      return this.postalCode.filter(option => option.postalCode.indexOf(val.toLowerCase()) === 0);
  }


}
