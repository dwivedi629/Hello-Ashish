﻿export class RegistrationTypeModel
{
    public typeId: number;

    public typeTypeId: number;

    public name:string;

    public description:string;
}

export class GenderModel {
    public genderId: number;

    public gendername: string;
}