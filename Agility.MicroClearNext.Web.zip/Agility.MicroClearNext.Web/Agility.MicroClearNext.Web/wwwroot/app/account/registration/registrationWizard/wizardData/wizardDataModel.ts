export class FormData {
    stakeHoldertype:string;
    emailId: string;
    password : string;
    confirmPassword: string;
    pwdChallengeQuestion: string;
    challengeResponse: string;
firstName: string;
  lastName: string;
  gender: string;
  nationality: string;
  IdType: string;
  IdNumber: string;
  DocTypeVal: string;
  idDetails: {
    idType: string;
    gst: string;
  };
  uploadedDocs: {
      docType: string;
      docname: string;
    category: string;
    file: any;
  };
IndividualFile : File[]=[];
country: string;
  state: string;
  city: string;
  pin: string;
  addressLine1: string;
  addressLine2: string;
  mobCode: string;
  mobNumber: string;
  primaryTelCode: string;
  primaryTelNumber: string;
  altCode: string;
  altNumber: string;
  faxCode: string; 
  faxNumber: string;
  mobileNor: {
    code: string;
    number: string;
  };
  primaryTelephoneNor: {
    code: string;
    number: string;
  };
  alternateTelephoneNor: {
    code: string;
    number: string;
  };
  faxNor: {
    code: string;
    number: string;
  };

  bankDetails: {
      bankId: string;
      bankName: string;
      branch: string;
      accountNo: string;
      ibANCode: string;
  };
  customStationId: string;
  registeredCSId: string;

   regAuthority: string;
  businessEntity: string;
  organizationName: string;
  brn: string;
  gstNumber: string;
  OrguploadedDocs: {
    docType: string;
    category: string;
    file: string;
  };
}

export class accountInfo {
   emailId: string ;
    password : string;
    confirmPassword: string;
   // pwdChallengeQuestion: string;
    //challengeResponse: string;
}
export class personalInfo {
  firstName: string
  lastName: string
  gender: string
  IdType: string;
  IdNumber: string;
  DocTypeVal: string;
  idDetails: {
    idType: string;
    gst: string;
  };
  uploadedDocs: {
      docType: string;
      docname: string;
    category: string;
    file: any;
  };
}

export interface addressInfo {
  country: string;
  state: string;
  city: string;
  countryname: string;
  statename: string;
  cityname: string;
  pin: string;
  pincode: string;
  addressLine1: string;
  addressLine2: string;
  mobCode: string;
  mobNumber: string;
  primaryTelCode: string;
  primaryTelNumber: string;
  altCode: string;
  altNumber: string;
  faxCode: string;
  faxNumber: string;
}


export interface otherInfo {
    bankDetails: {
        bankId: string;
        bankName: string;
        branch: string;
        accountNo: string;
        ibANCode: string;
    };
    customStationId: string;
    assocustomStation: string;
    registeredCSId: string;
    registeredCSName: string;

}

export interface organizationInfo {
  regAuthority: string;
  businessEntity: string;
  organizationName: string;
     businessEntityId: string;
  regAuthorityName: string;
  brn: string;
  gstNumber: string;
  doctypval: string;
  OrguploadedDocs: {
      docType: string;
      category: string;
      file: string;
  };
  }

export interface bankDetails {
    bankId: string;
    bankName: string;
    branch: string;
    accountNo: string;
    ibANCode: string;
    bankLogo: string;
}


export interface docData {
    docType: string;
    docId: string;
    file: File;
    //fileName: string;
}
