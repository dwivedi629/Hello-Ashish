"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var registrationWizardService_1 = require("./registrationWizardService");
var wizardDataService_1 = require("./wizardData/wizardDataService");
var RegistrationWizardComponent = (function () {
    function RegistrationWizardComponent(router, FormDataService, activatedRoute, registrationWizardService) {
        var _this = this;
        this.router = router;
        this.FormDataService = FormDataService;
        this.activatedRoute = activatedRoute;
        this.registrationWizardService = registrationWizardService;
        this.data = {};
        this.isCompleted = false;
        this.completedStep = 0;
        this.registrationWizardService.stepCompletionStatusEmitted$.subscribe(function (status) {
            _this.completedStep = status;
        });
    }
    RegistrationWizardComponent.prototype.ngOnInit = function () {
        this.registrationType = this.activatedRoute.snapshot.params['registrationType'];
        this.FormDataService.setStakeHolderType(this.registrationType);
        if (this.registrationType === 'organization') {
            this.dispLable = 'Organization';
            this.router.navigate(['organization-info'], { relativeTo: this.activatedRoute });
        }
        else {
            this.dispLable = 'Individual';
        }
    };
    RegistrationWizardComponent.prototype.checkWizardStatus = function (currentStep) {
        console.log(this.completedStep);
        console.log(currentStep);
        if (this.completedStep >= currentStep) {
            this.completedStep = currentStep - 1;
            console.log(this.completedStep);
        }
    };
    return RegistrationWizardComponent;
}());
RegistrationWizardComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'app-registration-wizard',
        templateUrl: './registrationWizardComponent.html',
        styleUrls: ['./registrationWizardComponent.css'],
        providers: [registrationWizardService_1.RegistrationWizardService, wizardDataService_1.FormDataService]
    }),
    __metadata("design:paramtypes", [router_1.Router,
        wizardDataService_1.FormDataService,
        router_1.ActivatedRoute,
        registrationWizardService_1.RegistrationWizardService])
], RegistrationWizardComponent);
exports.RegistrationWizardComponent = RegistrationWizardComponent;
//# sourceMappingURL=registrationWizardComponent.js.map