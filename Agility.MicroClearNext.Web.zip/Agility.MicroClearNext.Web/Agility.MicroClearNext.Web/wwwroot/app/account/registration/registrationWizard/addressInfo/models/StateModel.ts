﻿
import { ProfileModel } from "framework/profile/ProfileModel";

export class StateModel extends ProfileModel {
    stateId: string;

    stateName?: string;
}