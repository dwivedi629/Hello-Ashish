"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var submitModel_1 = require("./submitModel");
var wizardDataModel_1 = require("./wizardDataModel");
var FormDataService = (function () {
    function FormDataService() {
        this.formData = new wizardDataModel_1.FormData();
        this.submitModel = new submitModel_1.SubmitModel();
        this.isaccountInfoValid = false;
        this.isaddressInfoValid = false;
        this.isorganizationInfoValid = false;
        this.isotherInfoValid = false;
        this.ispersonalInfoValid = false;
    }
    FormDataService.prototype.getaccountInfo = function () {
        var accountInfo = {
            emailId: this.submitModel.emailID,
            password: this.submitModel.password,
            confirmPassword: this.submitModel.confirmPassword,
        };
        return accountInfo;
    };
    FormDataService.prototype.setaccountInfo = function (data) {
        this.isaccountInfoValid = true;
        this.submitModel.emailID = data.emailId;
        this.submitModel.confirmPassword = data.confirmPassword;
        this.submitModel.password = data.password;
    };
    FormDataService.prototype.getpersonalInfo = function () {
        var personalInfo = {
            firstName: this.submitModel.firstName,
            lastName: this.submitModel.lastName,
            DocTypeVal: this.formData.DocTypeVal,
            gender: this.submitModel.gender,
            IdType: this.submitModel.IdType,
            IdNumber: this.submitModel.IdNumber,
            idDetails: this.formData.idDetails,
            uploadedDocs: this.formData.uploadedDocs,
        };
        return personalInfo;
    };
    FormDataService.prototype.setpersonalInfo = function (data) {
        this.submitModel.firstName = data.firstName;
        this.submitModel.lastName = data.lastName;
        this.submitModel.gender = data.gender;
        this.submitModel.IdNumber = data.idDetails.gst;
        this.submitModel.IdType = data.idDetails.idType;
        this.submitModel.gender = data.gender;
    };
    FormDataService.prototype.getaddressInfo = function () {
        var addressInfo = {
            country: this.submitModel.country,
            state: this.submitModel.state,
            city: this.submitModel.city,
            pin: this.submitModel.pin,
            countryname: this.submitModel.countryname,
            statename: this.submitModel.statename,
            pincode: this.submitModel.pincode,
            cityname: this.submitModel.cityname,
            addressLine1: this.submitModel.addressLine1,
            addressLine2: this.submitModel.addressLine2,
            mobCode: this.submitModel.mobCode,
            mobNumber: this.submitModel.mobNumber,
            primaryTelCode: this.submitModel.primaryTelCode,
            primaryTelNumber: this.submitModel.primaryTelNumber,
            altCode: this.submitModel.altCode,
            altNumber: this.submitModel.altNumber,
            faxCode: this.submitModel.faxCode,
            faxNumber: this.submitModel.faxNumber
        };
        return addressInfo;
    };
    FormDataService.prototype.setaddressInfo = function (data) {
        this.isaddressInfoValid = true;
        this.submitModel.country = data.country;
        this.submitModel.state = data.state;
        this.submitModel.city = data.city;
        this.submitModel.pin = data.pin;
        this.submitModel.addressLine1 = data.addressLine1;
        this.submitModel.addressLine2 = data.addressLine2;
        this.submitModel.mobCode = data.mobCode;
        this.submitModel.mobNumber = data.mobNumber;
        this.submitModel.primaryTelCode = data.primaryTelCode;
        this.submitModel.primaryTelNumber = data.primaryTelNumber;
        this.submitModel.countryname = data.countryname;
        this.submitModel.statename = data.statename;
        this.submitModel.pincode = data.pincode;
        this.submitModel.cityname = data.cityname;
        this.submitModel.altCode = data.altCode;
        this.submitModel.altNumber = data.altNumber;
        this.submitModel.faxCode = data.faxCode;
        this.submitModel.faxNumber = data.faxNumber;
    };
    FormDataService.prototype.getotherInfo = function () {
        var otherInfo = {
            bankDetails: this.formData.bankDetails,
            customStationId: this.submitModel.customStationId,
            registeredCSId: this.submitModel.registeredCSId,
            assocustomStation: "",
            registeredCSName: ""
        };
        return otherInfo;
    };
    FormDataService.prototype.setotherInfo = function (data) {
        this.isotherInfoValid = true;
        this.submitModel.customStationId = data.customStationId,
            this.submitModel.registeredCSId = data.registeredCSId;
        this.submitModel.assocustomStation = data.assocustomStation,
            this.submitModel.registeredCSName = data.registeredCSName;
    };
    FormDataService.prototype.getorganizationInfo = function () {
        var organizationInfo = {
            regAuthority: this.submitModel.regAuthority,
            businessEntity: this.submitModel.businessEntity,
            organizationName: this.submitModel.organizationName,
            regAuthorityName: this.submitModel.regAuthorityName,
            businessEntityId: this.submitModel.businessEntityId,
            brn: this.submitModel.brn,
            doctypval: "",
            gstNumber: this.submitModel.gstNumber,
            OrguploadedDocs: this.formData.OrguploadedDocs
        };
        return organizationInfo;
    };
    FormDataService.prototype.setorganizationInfo = function (data) {
        this.isorganizationInfoValid = true;
        this.submitModel.regAuthority = data.regAuthority;
        this.submitModel.businessEntity = data.businessEntity;
        this.submitModel.brn = data.brn;
        this.submitModel.gstNumber = data.gstNumber;
        this.submitModel.organizationName = data.organizationName;
        this.submitModel.regAuthorityName = data.regAuthorityName;
        this.submitModel.businessEntityId = data.businessEntityId;
    };
    FormDataService.prototype.getFormData = function () {
        return this.formData;
    };
    FormDataService.prototype.getSubmitModelData = function () {
        return this.submitModel;
    };
    FormDataService.prototype.setStakeHolderType = function (type) {
        this.submitModel.stakeHoldertype = type;
    };
    FormDataService.prototype.setBanks = function (bank) {
        this.submitModel.banks.push(bank);
        return this.submitModel.banks;
    };
    FormDataService.prototype.getBanks = function () {
        return this.submitModel.banks;
    };
    FormDataService.prototype.setIndividualDocs = function (docs) {
        this.submitModel.indvidualDoc.push(docs);
        return this.submitModel.indvidualDoc;
    };
    FormDataService.prototype.getIndividualDocs = function () {
        return this.submitModel.indvidualDoc;
    };
    FormDataService.prototype.setOrgDocs = function (docs) {
        this.submitModel.orgDoc.push(docs);
        return this.submitModel.orgDoc;
    };
    FormDataService.prototype.getOrgDocs = function () {
        return this.submitModel.orgDoc;
    };
    FormDataService.prototype.resetSubmitData = function () {
        this.submitModel = new submitModel_1.SubmitModel();
    };
    FormDataService.prototype.setIndividualUpldDoc = function (file) {
        this.formData.IndividualFile.push(file);
    };
    return FormDataService;
}());
FormDataService = __decorate([
    core_1.Injectable()
], FormDataService);
exports.FormDataService = FormDataService;
//# sourceMappingURL=wizardDataService.js.map