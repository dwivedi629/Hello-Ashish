export interface IOther {
  registeredCustomStation: string;
  associateCustomStation: string;
  bankName: string;
  accountNo: string;
  ibanCode: string;
  bankLogo: string;
}
