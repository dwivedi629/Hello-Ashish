"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var RegistrationTypeModel = (function () {
    function RegistrationTypeModel() {
    }
    return RegistrationTypeModel;
}());
exports.RegistrationTypeModel = RegistrationTypeModel;
var GenderModel = (function () {
    function GenderModel() {
    }
    return GenderModel;
}());
exports.GenderModel = GenderModel;
//# sourceMappingURL=registrationtypemodel.js.map