"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var forms_1 = require("@angular/forms");
var router_1 = require("@angular/router");
var registrationWizardService_1 = require("../registrationWizardService");
var wizardDataService_1 = require("../wizardData/wizardDataService");
var AccountInfoComponent = (function () {
    function AccountInfoComponent(_fb, router, activatedRoute, registrationWizardService, FormDataService) {
        this._fb = _fb;
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.registrationWizardService = registrationWizardService;
        this.FormDataService = FormDataService;
        this.accountInfoFormSubmitted = false;
        this._force = 0;
        this._regex = /[$-/:-?{-~!"^_`\[\]]/g;
        this._lowerLetters = false;
        this._upperLetters = false;
        this._numbers = false;
        this._symbols = false;
        this._flags = [];
        this._passedMatches = 0;
        this.colors = ['#F00', '#F90', '#FF0', '#9F0', '#0F0'];
        this.EMAIL_REGEX = /^[a-zA-Z0-9.!#$%&�*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
        this.Password_Regex = /^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])([a-zA-Z0-9]{8,15})$/;
    }
    AccountInfoComponent.prototype.ngOnChanges = function () {
    };
    AccountInfoComponent.prototype.measureStrength = function (p) {
        this._force = 0;
        this._lowerLetters = /[a-z]+/.test(p);
        this._upperLetters = /[A-Z]+/.test(p);
        this._numbers = /[0-9]+/.test(p);
        this._symbols = this._regex.test(p);
        this._flags = [this._lowerLetters, this._upperLetters, this._numbers, this._symbols];
        this._passedMatches = 0;
        for (var i = 0; i < this._flags.length; i++) {
            //console.log(this._flags[i]);
            this._passedMatches += this._flags[i] === true ? 1 : 0;
        }
        this._force += 2 * p.length + ((p.length >= 10) ? 1 : 0);
        this._force += this._passedMatches * 10;
        // penality (short password)
        this._force = (p.length <= 6) ? Math.min(this._force, 10) : this._force;
        // penality (poor variety of characters)
        this._force = (this._passedMatches === 1) ? Math.min(this._force, 10) : this._force;
        this._force = (this._passedMatches === 2) ? Math.min(this._force, 20) : this._force;
        this._force = (this._passedMatches === 3) ? Math.min(this._force, 40) : this._force;
        return this._force;
    };
    AccountInfoComponent.prototype.getColor = function (s) {
        var idx = 0;
        if (s <= 10) {
            idx = 0;
        }
        else if (s <= 20) {
            idx = 1;
        }
        else if (s <= 30) {
            idx = 2;
        }
        else if (s <= 40) {
            idx = 3;
        }
        else {
            idx = 4;
        }
        return {
            idx: idx + 1,
            col: this.colors[idx]
        };
    };
    AccountInfoComponent.prototype.setBarColors = function (count, col) {
        for (var _n = 0; _n < count; _n++) {
            //console.log('bar' + _n);
            this['bar' + _n] = col;
        }
    };
    AccountInfoComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.accountInfoForm = this._fb.group({
            emailId: ['', [forms_1.Validators.required, forms_1.Validators.pattern(this.EMAIL_REGEX)]],
            password: ['', [forms_1.Validators.required, forms_1.Validators.minLength(8)]],
            confirmPassword: ['', [forms_1.Validators.required, forms_1.Validators.minLength(8)]]
        });
        this.accountInfoForm.valueChanges.subscribe(function (data) {
            _this.setBarColors(5, '#DDD');
            if (data.password) {
                var c = _this.getColor(_this.measureStrength(data.password));
                _this.setBarColors(c.idx, c.col);
            }
        });
        this.accountInfo = this.FormDataService.getaccountInfo();
    };
    AccountInfoComponent.prototype.validateAccountInfo = function (model, isValid) {
        if (isValid) {
            this.FormDataService.setaccountInfo(model);
            this.registrationWizardService.emitStepCompletionStatus(this.activatedRoute.snapshot.data['stepCount']);
            this.router.navigate(['/registration/wizard/personal-info']); //personal-info
        }
    };
    AccountInfoComponent.prototype.goToPreviousStep = function () {
        this.router.navigate(['/Account/Login']);
    };
    return AccountInfoComponent;
}());
AccountInfoComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'app-registration-accountinfo',
        templateUrl: './accountInfoComponent.html',
        providers: [registrationWizardService_1.RegistrationWizardService],
        styleUrls: ['./accountInfoComponent.css']
    }),
    __metadata("design:paramtypes", [forms_1.FormBuilder,
        router_1.Router,
        router_1.ActivatedRoute,
        registrationWizardService_1.RegistrationWizardService,
        wizardDataService_1.FormDataService])
], AccountInfoComponent);
exports.AccountInfoComponent = AccountInfoComponent;
//# sourceMappingURL=accountInfoComponent.js.map