﻿
import { ProfileModel } from "framework/profile/ProfileModel";

export class PostalCodeModel extends ProfileModel {
    postalCodeId: string;
    postalCode: string;
    stateId: number;
}