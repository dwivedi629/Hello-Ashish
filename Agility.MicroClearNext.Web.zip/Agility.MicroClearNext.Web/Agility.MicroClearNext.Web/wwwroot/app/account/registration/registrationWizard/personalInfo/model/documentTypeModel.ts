﻿export class DocumentTypeModel {

    public documentId: number;

    public documentTypeId: number;

    public name: string;

    public description: string;
}