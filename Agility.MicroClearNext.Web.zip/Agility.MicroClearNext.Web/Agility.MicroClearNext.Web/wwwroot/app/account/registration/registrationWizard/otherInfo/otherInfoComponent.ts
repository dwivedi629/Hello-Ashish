import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { RegistrationWizardService } from '../registrationWizardService';
//import { FormDataService } from "../wizardData/wizardDataService";
import { IOther } from './otherInfo';
import { otherInfoModel } from './Models/otherInfoModel';
//import { FormDataService } from "../wizardData/wizardDataservice";
import { FormDataService } from "../wizardData/wizardDataService";
import { BankModel } from './models/bankModel';
import { CustomStationModel } from './models/customStationModel';
import { RegistrationService } from '../registrationservice';
import { bankDetails } from "../wizarddata/wizarddatamodel";
import { CommonService } from "framework/CommonService";


@Component({
    moduleId: module.id,
  selector: 'app-other-info',
  templateUrl: './otherInfoComponent.html',
  providers: [RegistrationWizardService, RegistrationService, BankModel, CustomStationModel],
  styleUrls: ['./otherInfoComponent.css']
})
export class OtherInfoComponent implements OnInit {
  public otherInfoForm: FormGroup;
  public otherInfoFormSubmitted: boolean;
  public newBnkdetails: bankDetails;
  public otherInfo: otherInfoModel;
  public OtherInfoModel: otherInfoModel;
  public banks: BankModel[];
  public addedBanks: bankDetails[];
  public prefix: any;
  public Selectedbank: any;
  public filtercustomStation: CustomStationModel[];
  public customStation: CustomStationModel[];

  bank: any;
  bankCtrl: FormControl;
  filteredbank: any;
  public errorMessage: string;
  myControl: FormControl = new FormControl();
  filteredOptionsB: Observable<string[]>;
  filteredOptionsCS: Observable<string[]>;
  constructor( 
      private _fb: FormBuilder,
      private router: Router,
      private activatedRoute: ActivatedRoute,
      private registrationWizardService: RegistrationWizardService,
      private route: ActivatedRoute,
      private commonService: CommonService,
      private registrationService: RegistrationService,
      private FormDataService: FormDataService ) {
  }


  ngOnInit() {
      this.getBanks();
      this.getCustomStation();
      this.otherInfoForm = this._fb.group({
          bankDetails: this._fb.group({
              bankId: [''],
              bankName: [''],
              branch: [''],
              accountNo: [''],
              ibANCode: ['']
          }),

          customStationId: ['', <any>Validators.required],
          registeredCSId: ['']
      });
      this.otherInfo = this.FormDataService.getotherInfo();
      this.addedBanks = this.FormDataService.getBanks();
  }


  validateOtherInfoForm(model: otherInfoModel, isValid: boolean) {
      if (isValid) {
          if (model.customStationId != undefined)
              model.assocustomStation = this.customStation.find(x => x.customStationId == model.customStationId).stationName;
          if (model.registeredCSId != undefined)
              model.registeredCSName = this.customStation.find(x => x.customStationId == model.registeredCSId).stationName;
          this.FormDataService.setotherInfo(model);
          this.router.navigate(['/registration/wizard/preview']);
      }
  }

  goToPreviousStep() {
      this.router.navigate(['/Account/Login']);
  }

  getBanks() {
      this.registrationService.getBanks().subscribe
          (response => {
              this.banks = response;
              this.bank = this.banks;
          },
          error => this.errorMessage = <any>error
          );
  }


  getCustomStation() {
      this.customStation = null;
      this.registrationService.getCustomStation().subscribe
          (response => {
              this.customStation = response;
              this.filtercustomStation = this.customStation;
          },
          error => this.errorMessage = <any>error
          );
  }



  displayFn(bankId): string {
      //this.Selectedbank = this.bank.find(x => x.bankId == bankId);
      this.Selectedbank = this.bank.find(x => x.bankId == bankId);
       let bankName = this.Selectedbank.bankName;
       return bankId ? bankName : bankId;
  }



  getNAuto(prefix: string) {
      this.bank = null;
      this.bank = this.banks.filter((item) => item.bankName.toLowerCase().startsWith(prefix.toLowerCase()));
  }
  //getfiltercs(prefix: string) {
  //    this.filtercustomStation = null;
  //    this.filtercustomStation = this.customStation.filter((item) => item.stationName.toLowerCase().startsWith(prefix.toLowerCase()));
  //    console.log(this.filtercustomStation);
  //}



  addBank(model: otherInfoModel, isValid: boolean) {

      if (model.bankDetails.bankName != undefined)
          model.bankDetails.bankId = this.bank.find(x => x.bankName == model.bankDetails.bankName).bankId;
      else {
          this.commonService.showAlert("Please Select Bank Name");
          return false;
      }
        
      if (model.bankDetails.accountNo != undefined)
          model.bankDetails.bankId = this.bank.find(x => x.bankName == model.bankDetails.bankName).bankId;
      else {
          this.commonService.showAlert("Please Add Account Number");
          return false;
      }
          var bankdetails = {
              'bankId': model.bankDetails.bankId,
              'bankName': model.bankDetails.bankName,
              'branch': model.bankDetails.branch,
              'accountNo': model.bankDetails.accountNo,
              'ibANCode': model.bankDetails.ibANCode,
              'bankLogo': './assets/images/bank-images/bank-3.png'
          };
          this.addedBanks = this.FormDataService.setBanks(bankdetails);
  }

}
