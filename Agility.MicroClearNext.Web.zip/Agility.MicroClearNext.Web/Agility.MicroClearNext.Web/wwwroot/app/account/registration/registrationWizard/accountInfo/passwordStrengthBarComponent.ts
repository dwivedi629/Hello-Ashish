import {Component, OnChanges, Input, SimpleChange} from '@angular/core';

@Component({
    moduleId: module.id,
  selector: 'password-strength-bar',
  templateUrl: './passwordStrengthBarComponent.html',
  styleUrls: ['./passwordStrengthBarComponent.css']
})
export class PasswordStrengthBarComponent implements OnChanges {
  @Input() passwordToCheck: string;
  bar0: string;
  bar1: string;
  bar2: string;
  bar3: string;
  bar4: string;

  public _force = 0;
  public _regex = /[$-/:-?{-~!"^_`\[\]]/g;

  public _lowerLetters = false;
  public _upperLetters = false;
  public _numbers = false;
  public _symbols = false;

  public _flags = [];

  public _passedMatches = 0;
  public colors = ['#F00', '#F90', '#FF0', '#9F0', '#44a846'];

  measureStrength(p) {
    this._force = 0;
    this._lowerLetters = /[a-z]+/.test(p);
    this._upperLetters = /[A-Z]+/.test(p);
    this._numbers = /[0-9]+/.test(p);
    this._symbols = this._regex.test(p);

    this._flags = [this._lowerLetters, this._upperLetters, this._numbers, this._symbols];

    this._passedMatches = 0;

    for (let i = 0; i < this._flags.length; i++) {
      console.log(this._flags[i]);
      this._passedMatches += this._flags[i] === true ? 1 : 0;
    }
    this._force += 2 * p.length + ((p.length >= 10) ? 1 : 0);
    this._force += this._passedMatches * 10;

    // penality (short password)
    this._force = (p.length <= 6) ? Math.min(this._force, 10) : this._force;

    // penality (poor variety of characters)
    this._force = (this._passedMatches === 1) ? Math.min(this._force, 10) : this._force;
    this._force = (this._passedMatches === 2) ? Math.min(this._force, 20) : this._force;
    this._force = (this._passedMatches === 3) ? Math.min(this._force, 40) : this._force;

    return this._force;

  }

  getColor(s) {
    let idx = 0;
    if (s <= 10) {
      idx = 0;
    } else if (s <= 20) {
      idx = 1;
    } else if (s <= 30) {
      idx = 2;
    } else if (s <= 40) {
      idx = 3;
    } else {
      idx = 4;
    }
    return {
      idx: idx + 1,
      col: this.colors[idx]
    };
  }
  setBarColors(count, col) {
    for (let _n = 0; _n < count; _n++) {
      this['bar' + _n] = col;
    }
  }
  ngOnChanges(changes: {[propName: string]: SimpleChange}): void {
    console.log('testting');
    let password = changes['passwordToCheck'].currentValue;
    this.setBarColors(5, '#DDD');
    if (password) {
      let c = this.getColor(this.measureStrength(password));
      this.setBarColors(c.idx, c.col);
    }
  }


}
