"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var registrationWizardService_1 = require("../registrationWizardService");
var material_1 = require("@angular/material");
var FxContext_1 = require("framework/context/FxContext");
var SuccessDialogComponent_1 = require("../successDialog/SuccessDialogComponent");
var registrationservice_1 = require("../registrationservice");
var submitModel_1 = require("../wizardData/submitModel");
var wizardDataService_1 = require("../wizardData/wizardDataService");
var CommonService_1 = require("framework/CommonService");
//declare var $: any;
var PreviewComponent = (function () {
    function PreviewComponent(router, fxContext, registrationWizardService, dialog, FormDataService, SubmitModelData, commonService, registrationService, successDialogueComponent) {
        this.router = router;
        this.registrationWizardService = registrationWizardService;
        this.dialog = dialog;
        this.FormDataService = FormDataService;
        this.SubmitModelData = SubmitModelData;
        this.commonService = commonService;
        this.registrationService = registrationService;
        this.successDialogueComponent = successDialogueComponent;
        this.hidePassword = true;
        this.docdetails = [];
        this.showOrganization = false;
        this.dispalyGender = "";
        this.Idtype = "";
        this.toggleButton = true;
        fxContext.IsAuthenticated = false;
    }
    PreviewComponent.prototype.ngOnInit = function () {
        this.SubmitModelData = this.FormDataService.getSubmitModelData();
        if (this.SubmitModelData.stakeHoldertype == "organization")
            this.showOrganization = true;
        if (this.SubmitModelData.gender == "1")
            this.dispalyGender = "Male";
        else if (this.SubmitModelData.gender == "2")
            this.dispalyGender = "Female";
        else if (this.SubmitModelData.gender == "3")
            this.dispalyGender = "Neutral Gender";
        if (this.SubmitModelData.IdType == "343")
            this.Idtype = "NRIC No";
        else if (this.SubmitModelData.IdType == "344")
            this.Idtype = "Passport No";
        this.getDocsData();
        this.filecount();
    };
    PreviewComponent.prototype.validate = function () {
        this.registrationSuccessModal.modal('show');
    };
    PreviewComponent.prototype.goToLogin = function () {
        this.registrationSuccessModal.modal('hide');
        this.router.navigate(['/login']);
    };
    PreviewComponent.prototype.goToPreviousStep = function () {
        this.router.navigate(['/Account/Login']);
    };
    PreviewComponent.prototype.openSuccessDialog = function (event) {
        var _this = this;
        console.log(this.FormDataService.getSubmitModelData());
        this.registrationService.SubmitRegData(this.FormDataService.getSubmitModelData()).subscribe(function (response) {
            _this.result = response;
            console.log(_this.result);
            if (_this.result.model == 0 /* success */) {
                _this.dialog.open(SuccessDialogComponent_1.SuccessDialogComponent, {
                    panelClass: 'registration-success-modal',
                    disableClose: true
                });
                _this.FormDataService.resetSubmitData();
            }
            else {
                _this.commonService.showAlert(_this.result.message);
            }
        }, function (error) { return console.error(error); });
    };
    PreviewComponent.prototype.getDocsData = function () {
        this.docdetails = this.FormDataService.getIndividualDocs();
    };
    PreviewComponent.prototype.filecount = function () {
        if (this.docdetails.length > 0)
            this.fileheader = true;
        else
            this.fileheader = false;
    };
    return PreviewComponent;
}());
PreviewComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'app-preview',
        templateUrl: './previewComponent.html',
        providers: [registrationWizardService_1.RegistrationWizardService, submitModel_1.SubmitModel, registrationservice_1.RegistrationService, SuccessDialogComponent_1.SuccessDialogComponent],
        styleUrls: ['./previewComponent.css']
    }),
    __metadata("design:paramtypes", [router_1.Router, FxContext_1.FxContext,
        registrationWizardService_1.RegistrationWizardService,
        material_1.MdDialog,
        wizardDataService_1.FormDataService,
        submitModel_1.SubmitModel,
        CommonService_1.CommonService,
        registrationservice_1.RegistrationService,
        SuccessDialogComponent_1.SuccessDialogComponent])
], PreviewComponent);
exports.PreviewComponent = PreviewComponent;
//# sourceMappingURL=previewComponent.js.map