import { Component, OnChanges, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { IAccount } from './accountInfo';
import { RegistrationWizardService } from '../registrationWizardService';
import { FormDataService } from '../wizardData/wizardDataService';
import { accountInfo } from '../wizardData/wizardDataModel';
import { EqualValidator } from './equal-validator.directive';

@Component({
    moduleId: module.id,
  selector: 'app-registration-accountinfo',
  templateUrl: './accountInfoComponent.html',
  providers: [RegistrationWizardService],
  styleUrls: ['./accountInfoComponent.css']
})
export class AccountInfoComponent implements OnInit, OnChanges {
  public accountInfoForm: FormGroup;
  public accountInfoFormSubmitted: boolean =false;

  bar0: string;
  bar1: string;
  bar2: string;
  bar3: string;
  bar4: string;

  public _force = 0;
  public _regex = /[$-/:-?{-~!"^_`\[\]]/g;

  public _lowerLetters = false;
  public _upperLetters = false;
  public _numbers = false;
  public _symbols = false;

  public _flags = [];

  public _passedMatches = 0;
  public colors = ['#F00', '#F90', '#FF0', '#9F0', '#0F0'];
  selectedValue: string;


  constructor(private _fb: FormBuilder,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private registrationWizardService: RegistrationWizardService,
    private FormDataService: FormDataService) {
  }
  EMAIL_REGEX = /^[a-zA-Z0-9.!#$%&�*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
  Password_Regex = /^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])([a-zA-Z0-9]{8,15})$/;

  ///^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])([a-zA-Z0-9]{8,})$/;/^([a-zA-Z0-9@*#]{8,15})$/

    //(?=.*\d)(?=.*[a - z])(?=.*[A - Z])(?=.*[@#$ %]).{ 6, 20 }
  public accountInfo: accountInfo;
  ngOnChanges() {
  }

 

  measureStrength(p) {
    this._force = 0;
    this._lowerLetters = /[a-z]+/.test(p);
    this._upperLetters = /[A-Z]+/.test(p);
    this._numbers = /[0-9]+/.test(p);
    this._symbols = this._regex.test(p);

    this._flags = [this._lowerLetters, this._upperLetters, this._numbers, this._symbols];

    this._passedMatches = 0;

    for (let i = 0; i < this._flags.length; i++) {
      //console.log(this._flags[i]);
      this._passedMatches += this._flags[i] === true ? 1 : 0;
    }
    this._force += 2 * p.length + ((p.length >= 10) ? 1 : 0);
    this._force += this._passedMatches * 10;

    // penality (short password)
    this._force = (p.length <= 6) ? Math.min(this._force, 10) : this._force;

    // penality (poor variety of characters)
    this._force = (this._passedMatches === 1) ? Math.min(this._force, 10) : this._force;
    this._force = (this._passedMatches === 2) ? Math.min(this._force, 20) : this._force;
    this._force = (this._passedMatches === 3) ? Math.min(this._force, 40) : this._force;

    return this._force;

  }

  getColor(s) {
    let idx = 0;
    if (s <= 10) {
      idx = 0;
    } else if (s <= 20) {
      idx = 1;
    } else if (s <= 30) {
      idx = 2;
    } else if (s <= 40) {
      idx = 3;
    } else {
      idx = 4;
    }
    return {
      idx: idx + 1,
      col: this.colors[idx]
    };
  }

  setBarColors(count, col) {
    for (let _n = 0; _n < count; _n++) {
      //console.log('bar' + _n);
      this['bar' + _n] = col;
    }
  }
  

  ngOnInit() {
      this.accountInfoForm = this._fb.group({
          emailId: ['', [<any>Validators.required, Validators.pattern(this.EMAIL_REGEX)]],
          password: ['', [<any>Validators.required, <any>Validators.minLength(8)]], //Validators.pattern(this.Password_Regex),<any>Validators.maxLength(15)
      confirmPassword: ['', [<any>Validators.required, <any>Validators.minLength(8)]]
      });

    this.accountInfoForm.valueChanges.subscribe(data => {
      this.setBarColors(5, '#DDD');
      if (data.password) {
        let c = this.getColor(this.measureStrength(data.password));
        this.setBarColors(c.idx, c.col);
      }
    });
    this.accountInfo = this.FormDataService.getaccountInfo();
  }

  validateAccountInfo(model: IAccount, isValid: boolean) {
      if (isValid) {
        this.FormDataService.setaccountInfo(model);
        this.registrationWizardService.emitStepCompletionStatus(this.activatedRoute.snapshot.data['stepCount']);
        this.router.navigate(['/registration/wizard/personal-info']);  //personal-info
    }

  }

  goToPreviousStep() {
      this.router.navigate(['/Account/Login']);
  }
}
