import { Injectable }   from '@angular/core';

import { SubmitModel } from './submitModel';
import { FormData, accountInfo, addressInfo, organizationInfo, otherInfo, personalInfo, bankDetails, docData }   from './wizardDataModel';

@Injectable()

export class FormDataService{
    public formData: FormData = new FormData();
    public submitModel: SubmitModel = new SubmitModel();
    private isaccountInfoValid: boolean = false;
    private isaddressInfoValid: boolean = false;
    private isorganizationInfoValid: boolean = false;
    private isotherInfoValid: boolean = false;
    private ispersonalInfoValid: boolean = false;

    getaccountInfo(): accountInfo {
        var accountInfo: accountInfo = {
            emailId: this.submitModel.emailID,
            password: this.submitModel.password,
            confirmPassword: this.submitModel.confirmPassword,
        };
        return accountInfo;
    }

    setaccountInfo(data: accountInfo) {
        this.isaccountInfoValid = true;
        this.submitModel.emailID = data.emailId;
        this.submitModel.confirmPassword = data.confirmPassword;
        this.submitModel.password = data.password;
        }


getpersonalInfo(): personalInfo {
    var personalInfo: personalInfo = {
        firstName: this.submitModel.firstName,
        lastName: this.submitModel.lastName,
        DocTypeVal: this.formData.DocTypeVal,
        gender: this.submitModel.gender,
        IdType: this.submitModel.IdType,
        IdNumber: this.submitModel.IdNumber,
        idDetails: this.formData.idDetails,
        uploadedDocs: this.formData.uploadedDocs,
            };
        return personalInfo;
       
    }

setpersonalInfo(data: personalInfo) {

    this.submitModel.firstName = data.firstName;
    this.submitModel.lastName = data.lastName;
    this.submitModel.gender = data.gender;
    this.submitModel.IdNumber = data.idDetails.gst;
    this.submitModel.IdType = data.idDetails.idType;
    this.submitModel.gender = data.gender;
    }


getaddressInfo(): addressInfo {
    var addressInfo: addressInfo = {
        country: this.submitModel.country,
        state: this.submitModel.state,
        city: this.submitModel.city,
        pin: this.submitModel.pin,
        countryname: this.submitModel.countryname,
        statename: this.submitModel.statename,
        pincode: this.submitModel.pincode,
        cityname: this.submitModel.cityname,
        addressLine1: this.submitModel.addressLine1,
        addressLine2: this.submitModel.addressLine2,
        mobCode: this.submitModel.mobCode,
        mobNumber: this.submitModel.mobNumber,
        primaryTelCode: this.submitModel.primaryTelCode,
        primaryTelNumber: this.submitModel.primaryTelNumber,
        altCode: this.submitModel.altCode,
        altNumber: this.submitModel.altNumber,
        faxCode: this.submitModel.faxCode,
        faxNumber: this.submitModel.faxNumber
            };
        return addressInfo;
    }


setaddressInfo(data: addressInfo) {
    this.isaddressInfoValid = true;
    this.submitModel.country = data.country;
    this.submitModel.state = data.state;
    this.submitModel.city = data.city;
    this.submitModel.pin = data.pin;
    this.submitModel.addressLine1 = data.addressLine1;
    this.submitModel.addressLine2 = data.addressLine2;
    this.submitModel.mobCode = data.mobCode;
    this.submitModel.mobNumber = data.mobNumber;
    this.submitModel.primaryTelCode = data.primaryTelCode;
    this.submitModel.primaryTelNumber = data.primaryTelNumber;
    this.submitModel.countryname = data.countryname;
    this.submitModel.statename = data.statename;
    this.submitModel.pincode = data.pincode;
    this.submitModel.cityname = data.cityname;
    this.submitModel.altCode = data.altCode;
    this.submitModel.altNumber = data.altNumber;
    this.submitModel.faxCode = data.faxCode;
    this.submitModel.faxNumber = data.faxNumber;
    }



getotherInfo(): otherInfo {
        var otherInfo: otherInfo = {
            bankDetails: this.formData.bankDetails,
            customStationId: this.submitModel.customStationId,
            registeredCSId: this.submitModel.registeredCSId,
            assocustomStation: "",
            registeredCSName: ""
    };
        return otherInfo;
    }

setotherInfo(data: otherInfo) {
        this.isotherInfoValid = true;
        this.submitModel.customStationId = data.customStationId,
        this.submitModel.registeredCSId = data.registeredCSId
        this.submitModel.assocustomStation = data.assocustomStation,
        this.submitModel.registeredCSName = data.registeredCSName
    }


getorganizationInfo(): organizationInfo {
    var organizationInfo: organizationInfo = {
        regAuthority: this.submitModel.regAuthority,
        businessEntity: this.submitModel.businessEntity,
        organizationName: this.submitModel.organizationName,
        regAuthorityName: this.submitModel.regAuthorityName,
        businessEntityId: this.submitModel.businessEntityId,
        brn: this.submitModel.brn,
        doctypval: "",
        gstNumber: this.submitModel.gstNumber,
        OrguploadedDocs:this.formData.OrguploadedDocs
    };
    return organizationInfo;
    }


setorganizationInfo(data: organizationInfo) {
        this.isorganizationInfoValid = true;

        this.submitModel.regAuthority = data.regAuthority;
        this.submitModel.businessEntity = data.businessEntity;
        this.submitModel.brn = data.brn;
        this.submitModel.gstNumber = data.gstNumber;
        this.submitModel.organizationName = data.organizationName;
        this.submitModel.regAuthorityName = data.regAuthorityName;
        this.submitModel.businessEntityId = data.businessEntityId;
    }


    getFormData(): FormData {
        return this.formData;
    }


    getSubmitModelData(): SubmitModel {
        return this.submitModel;
    }


    setStakeHolderType(type:string)
    {
        this.submitModel.stakeHoldertype = type;
    }



     setBanks(bank:bankDetails): bankDetails[]
     {
         this.submitModel.banks.push(bank);
         return this.submitModel.banks;
     }

     getBanks(): bankDetails[]
     {
         return this.submitModel.banks;

     }

     setIndividualDocs(docs: docData): docData[]
     {
         this.submitModel.indvidualDoc.push(docs);
         return this.submitModel.indvidualDoc;
     }

     getIndividualDocs(): docData[] {
         return this.submitModel.indvidualDoc;
     }

     setOrgDocs(docs: docData): docData[] {
         this.submitModel.orgDoc.push(docs);
         return this.submitModel.orgDoc;
     }

     getOrgDocs(): docData[] {
         return this.submitModel.orgDoc;
     }

     resetSubmitData()
     {
         this.submitModel = new SubmitModel();
     }

     setIndividualUpldDoc(file: File) {
         this.formData.IndividualFile.push(file);
     }
}