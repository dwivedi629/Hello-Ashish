export interface IOrganization {
  regAuthority: string;
  businessEntity: string;
  businessEntityId: string;
  regAuthorityName: string;
  organizationName: string;
  brn: string;
  gstNumber: string;
  doctypval: string;
  OrguploadedDocs: {
    docType: string;
    category: string;
    file: string;
  };
}



