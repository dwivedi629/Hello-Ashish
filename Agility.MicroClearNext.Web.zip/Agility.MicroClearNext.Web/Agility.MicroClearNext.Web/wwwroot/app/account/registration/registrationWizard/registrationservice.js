"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
var Observable_1 = require("rxjs/Observable");
var RegistrationService = (function () {
    function RegistrationService(_http) {
        this._http = _http;
        this.headers = new http_1.Headers({ 'Content-Type': 'application/json' });
        this.options = new http_1.RequestOptions({ headers: this.headers });
    }
    RegistrationService.prototype.SubmitRegData = function (formModel) {
        var input = new FormData();
        //input.append("formModel", formModel);
        return this._http.post("/api/Manager/RegisterUser", formModel, this.options)
            .map(this.extractSubmitData).catch(this.handleError);
    };
    RegistrationService.prototype.upload = function (fileToUpload) {
        console.log(fileToUpload);
        var input = new FormData();
        input.append("file", fileToUpload);
        console.log(input);
        return this._http.post("/api/Manager/uploadFile", input);
    };
    RegistrationService.prototype.getCountry = function () {
        return this._http.get("/api/Master/GetCountry", this.options).
            map(this.extractData).catch(this.handleError);
    };
    RegistrationService.prototype.getState = function (id) {
        return this._http.get("/api/Master/GetState/" + id, this.options).
            map(this.extractDataState).catch(this.handleError);
    };
    RegistrationService.prototype.getCity = function (id) {
        return this._http.get("/api/Master/GetCity/" + id, this.options).
            map(this.extractDataCity).catch(this.handleError);
    };
    RegistrationService.prototype.getBanks = function () {
        return this._http.get("/api/Master/GetBank", this.options).
            map(this.extractDataBank).catch(this.handleError);
    };
    RegistrationService.prototype.getCustomStation = function () {
        return this._http.get("/api/Master/GetCustomStation", this.options).
            map(this.extractDataCS).catch(this.handleError);
    };
    RegistrationService.prototype.getTeleCode = function (id) {
        return this._http.get("/api/Master/GetTeleCode/" + id, this.options).
            map(this.extractDataTeleCode).catch(this.handleError);
    };
    RegistrationService.prototype.getPostalCode = function (id) {
        return this._http.get("/api/Master/GetPostalCode/" + id, this.options).
            map(this.extractDataPostalCode).catch(this.handleError);
    };
    RegistrationService.prototype.getIdType = function () {
        return this._http.get("/api/Master/GetIdType", this.options).
            map(this.extractDataRegistartionType).catch(this.handleError);
    };
    RegistrationService.prototype.getDocumentType = function () {
        return this._http.get("/api/Master/GetDocumentType", this.options).
            map(this.extractDataDocumentType).catch(this.handleError);
    };
    RegistrationService.prototype.getRegistrationTypeById = function (id) {
        return this._http.get("/api/Master/GetRegistrationTypeById/" + id, this.options).
            map(this.extractDataRegistartion).catch(this.handleError);
    };
    RegistrationService.prototype.getGender = function () {
        return this._http.get("/api/Master/GetGender", this.options).
            map(this.extractDataGender).catch(this.handleError);
    };
    RegistrationService.prototype.getRegistrationAuthority = function () {
        return this._http.get("/api/Master/GetRegistrationAuthority", this.options).
            map(this.extractDomainData).catch(this.handleError);
    };
    RegistrationService.prototype.getBussinessEntity = function () {
        return this._http.get("/api/Master/GetBussinessEntity", this.options).
            map(this.extractDomainData).catch(this.handleError);
    };
    RegistrationService.prototype.extractDomainData = function (res) {
        var response = res.json().domainData;
        var body = response;
        return body || [];
    };
    RegistrationService.prototype.extractDataTeleCode = function (res) {
        var response = res.json().telePhoneCountryCode;
        var body = response;
        return body || [];
    };
    RegistrationService.prototype.extractDataPostalCode = function (res) {
        var response = res.json().postalCode;
        var body = response;
        return body || [];
    };
    RegistrationService.prototype.extractDataGender = function (res) {
        var response = res.json().gender;
        var body = response;
        return body || [];
    };
    RegistrationService.prototype.extractDataRegistartionType = function (res) {
        var response = res.json().registrationType;
        var body = response;
        return body || [];
    };
    RegistrationService.prototype.extractDataRegistartion = function (res) {
        var response = res.json().documentType;
        var body = response;
        return body || [];
    };
    RegistrationService.prototype.extractDataDocumentType = function (res) {
        var response = res.json().document;
        var body = response;
        return body || [];
    };
    RegistrationService.prototype.extractDataBank = function (res) {
        var response = res.json().bank;
        var body = response;
        return body || [];
    };
    RegistrationService.prototype.extractDataCS = function (res) {
        var response = res.json().customStation;
        var body = response;
        return body || [];
    };
    RegistrationService.prototype.extractData = function (res) {
        var response = res.json().country;
        var body = response;
        return body || [];
    };
    RegistrationService.prototype.extractDataState = function (res) {
        var response = res.json().state;
        var body = response;
        return body || [];
    };
    RegistrationService.prototype.extractDataCity = function (res) {
        var response = res.json().city;
        var body = response;
        return body || [];
    };
    RegistrationService.prototype.extractSubmitData = function (res) {
        var response = res.json();
        var body = response;
        return body || [];
    };
    RegistrationService.prototype.handleError = function (error) {
        var errMsg;
        if (error instanceof http_1.Response) {
            var body = error.json() || '';
            var err = body.error || JSON.stringify(body);
            errMsg = error.status + " - " + (error.statusText || '') + " " + err;
        }
        else {
            errMsg = error.message ? error.message : error.toString();
        }
        console.log(errMsg);
        var errorResponse = error.json();
        if (errorResponse.StatusCode == 401) {
            location.reload();
        }
        return Observable_1.Observable.throw(errMsg);
    };
    return RegistrationService;
}());
RegistrationService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [http_1.Http])
], RegistrationService);
exports.RegistrationService = RegistrationService;
//# sourceMappingURL=registrationservice.js.map