import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { RegistrationWizardService } from '../registrationWizardService';
import { IOther } from '../otherInfo/otherInfo';
import { MdDialog, MdDialogRef } from '@angular/material';
import { FxContext } from "framework/context/FxContext";
import { SuccessDialogComponent } from '../successDialog/SuccessDialogComponent';
import { RegistrationService } from '../registrationservice';
import { SubmitModel } from '../wizardData/submitModel';
import { FormDataService } from "../wizardData/wizardDataService";
import { CommonService } from "framework/CommonService";
//declare var $: any;

@Component({
    moduleId: module.id,
  selector: 'app-preview',
  templateUrl: './previewComponent.html',
  providers: [RegistrationWizardService, SubmitModel, RegistrationService, SuccessDialogComponent],
  styleUrls: ['./previewComponent.css']
})
export class PreviewComponent implements OnInit {
  public hidePassword: boolean = true;
  private registrationSuccessModal: any;
  protected docdetails = [];
  public fileheader: any;
  private showOrganization: boolean = false;
  private dispalyGender: string = "";
  private Idtype: string =""
  toggleButton: boolean = true;
  private result: any;

  constructor(
      private router: Router, fxContext: FxContext,      
      private registrationWizardService: RegistrationWizardService,
      public dialog: MdDialog,
      private FormDataService: FormDataService,
      private SubmitModelData: SubmitModel,
      private commonService: CommonService,
      private registrationService: RegistrationService,
      private successDialogueComponent: SuccessDialogComponent)
  {
      fxContext.IsAuthenticated = false;
  } 



  ngOnInit() {

      this.SubmitModelData = this.FormDataService.getSubmitModelData();
      if (this.SubmitModelData.stakeHoldertype == "organization")
          this.showOrganization = true;

      if (this.SubmitModelData.gender == "1")
          this.dispalyGender = "Male";
      else if (this.SubmitModelData.gender == "2")
          this.dispalyGender = "Female";
      else if (this.SubmitModelData.gender == "3")
          this.dispalyGender = "Neutral Gender";


      if (this.SubmitModelData.IdType == "343")
          this.Idtype = "NRIC No";
      else if (this.SubmitModelData.IdType == "344")
          this.Idtype = "Passport No";
      this.getDocsData();
      this.filecount();
  }

  validate() {
    this.registrationSuccessModal.modal('show');
  }

  goToLogin(): void {
    this.registrationSuccessModal.modal('hide');
    this.router.navigate(['/login']);
  }

  goToPreviousStep() {
      this.router.navigate(['/Account/Login']);
  }
  openSuccessDialog(event) {
      console.log(this.FormDataService.getSubmitModelData());
      this.registrationService.SubmitRegData(this.FormDataService.getSubmitModelData()).subscribe
          (response => {
              this.result = response;
              console.log(this.result);
              if (this.result.model == MessageType.success)
              {
                  this.dialog.open(SuccessDialogComponent, {
                      panelClass: 'registration-success-modal',
                      disableClose: true
                  });
                  this.FormDataService.resetSubmitData();
              }
              else {
                  this.commonService.showAlert(this.result.message);
              }
          },
          error => console.error(error)
      );
        
  }

  getDocsData() {
      this.docdetails = this.FormDataService.getIndividualDocs();
  }
  filecount() {
      if (this.docdetails.length > 0)
          this.fileheader = true;
      else
          this.fileheader = false;
  }
}
