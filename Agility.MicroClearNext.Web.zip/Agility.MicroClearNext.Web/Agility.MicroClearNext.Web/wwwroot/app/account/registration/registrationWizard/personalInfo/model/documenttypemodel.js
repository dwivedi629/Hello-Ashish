"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var DocumentTypeModel = (function () {
    function DocumentTypeModel() {
    }
    return DocumentTypeModel;
}());
exports.DocumentTypeModel = DocumentTypeModel;
//# sourceMappingURL=documenttypemodel.js.map