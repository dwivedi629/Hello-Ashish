"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var forms_1 = require("@angular/forms");
var router_1 = require("@angular/router");
var registrationWizardService_1 = require("../registrationWizardService");
//import { FormDataService } from "../wizardData/wizardDataservice";
var wizardDataService_1 = require("../wizardData/wizardDataService");
var bankModel_1 = require("./models/bankModel");
var customStationModel_1 = require("./models/customStationModel");
var registrationservice_1 = require("../registrationservice");
var CommonService_1 = require("framework/CommonService");
var OtherInfoComponent = (function () {
    function OtherInfoComponent(_fb, router, activatedRoute, registrationWizardService, route, commonService, registrationService, FormDataService) {
        this._fb = _fb;
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.registrationWizardService = registrationWizardService;
        this.route = route;
        this.commonService = commonService;
        this.registrationService = registrationService;
        this.FormDataService = FormDataService;
        this.myControl = new forms_1.FormControl();
    }
    OtherInfoComponent.prototype.ngOnInit = function () {
        this.getBanks();
        this.getCustomStation();
        this.otherInfoForm = this._fb.group({
            bankDetails: this._fb.group({
                bankId: [''],
                bankName: [''],
                branch: [''],
                accountNo: [''],
                ibANCode: ['']
            }),
            customStationId: ['', forms_1.Validators.required],
            registeredCSId: ['']
        });
        this.otherInfo = this.FormDataService.getotherInfo();
        this.addedBanks = this.FormDataService.getBanks();
    };
    OtherInfoComponent.prototype.validateOtherInfoForm = function (model, isValid) {
        if (isValid) {
            if (model.customStationId != undefined)
                model.assocustomStation = this.customStation.find(function (x) { return x.customStationId == model.customStationId; }).stationName;
            if (model.registeredCSId != undefined)
                model.registeredCSName = this.customStation.find(function (x) { return x.customStationId == model.registeredCSId; }).stationName;
            this.FormDataService.setotherInfo(model);
            this.router.navigate(['/registration/wizard/preview']);
        }
    };
    OtherInfoComponent.prototype.goToPreviousStep = function () {
        this.router.navigate(['/Account/Login']);
    };
    OtherInfoComponent.prototype.getBanks = function () {
        var _this = this;
        this.registrationService.getBanks().subscribe(function (response) {
            _this.banks = response;
            _this.bank = _this.banks;
        }, function (error) { return _this.errorMessage = error; });
    };
    OtherInfoComponent.prototype.getCustomStation = function () {
        var _this = this;
        this.customStation = null;
        this.registrationService.getCustomStation().subscribe(function (response) {
            _this.customStation = response;
            _this.filtercustomStation = _this.customStation;
        }, function (error) { return _this.errorMessage = error; });
    };
    OtherInfoComponent.prototype.displayFn = function (bankId) {
        //this.Selectedbank = this.bank.find(x => x.bankId == bankId);
        this.Selectedbank = this.bank.find(function (x) { return x.bankId == bankId; });
        var bankName = this.Selectedbank.bankName;
        return bankId ? bankName : bankId;
    };
    OtherInfoComponent.prototype.getNAuto = function (prefix) {
        this.bank = null;
        this.bank = this.banks.filter(function (item) { return item.bankName.toLowerCase().startsWith(prefix.toLowerCase()); });
    };
    //getfiltercs(prefix: string) {
    //    this.filtercustomStation = null;
    //    this.filtercustomStation = this.customStation.filter((item) => item.stationName.toLowerCase().startsWith(prefix.toLowerCase()));
    //    console.log(this.filtercustomStation);
    //}
    OtherInfoComponent.prototype.addBank = function (model, isValid) {
        if (model.bankDetails.bankName != undefined)
            model.bankDetails.bankId = this.bank.find(function (x) { return x.bankName == model.bankDetails.bankName; }).bankId;
        else {
            this.commonService.showAlert("Please Select Bank Name");
            return false;
        }
        if (model.bankDetails.accountNo != undefined)
            model.bankDetails.bankId = this.bank.find(function (x) { return x.bankName == model.bankDetails.bankName; }).bankId;
        else {
            this.commonService.showAlert("Please Add Account Number");
            return false;
        }
        var bankdetails = {
            'bankId': model.bankDetails.bankId,
            'bankName': model.bankDetails.bankName,
            'branch': model.bankDetails.branch,
            'accountNo': model.bankDetails.accountNo,
            'ibANCode': model.bankDetails.ibANCode,
            'bankLogo': './assets/images/bank-images/bank-3.png'
        };
        this.addedBanks = this.FormDataService.setBanks(bankdetails);
    };
    return OtherInfoComponent;
}());
OtherInfoComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'app-other-info',
        templateUrl: './otherInfoComponent.html',
        providers: [registrationWizardService_1.RegistrationWizardService, registrationservice_1.RegistrationService, bankModel_1.BankModel, customStationModel_1.CustomStationModel],
        styleUrls: ['./otherInfoComponent.css']
    }),
    __metadata("design:paramtypes", [forms_1.FormBuilder,
        router_1.Router,
        router_1.ActivatedRoute,
        registrationWizardService_1.RegistrationWizardService,
        router_1.ActivatedRoute,
        CommonService_1.CommonService,
        registrationservice_1.RegistrationService,
        wizardDataService_1.FormDataService])
], OtherInfoComponent);
exports.OtherInfoComponent = OtherInfoComponent;
//# sourceMappingURL=otherInfoComponent.js.map