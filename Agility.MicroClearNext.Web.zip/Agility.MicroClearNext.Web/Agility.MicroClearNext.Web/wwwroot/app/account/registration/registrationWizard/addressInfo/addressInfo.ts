export interface IAddress {
  country: string;
  state: string;
  city: string;
  countryname: string;
  statename: string;
  cityname: string;
  pin: string;
  pincode: string;
  addressLine1: string;
  addressLine2: string;
  mobCode: string,
  mobNumber: string,
  primaryTelCode: string,
  primaryTelNumber: string,
  altCode: string,
  altNumber: string,
  faxCode: string,
  faxNumber: string,
  mobileNor: {
    code: string;
    number: string;
  };
  primaryTelephoneNor: {
    code: string;
    number: string;
  };
  alternateTelephoneNor: {
    code: string;
    number: string;
  };
  faxNor: {
    code: string;
    number: string;
  };
}
