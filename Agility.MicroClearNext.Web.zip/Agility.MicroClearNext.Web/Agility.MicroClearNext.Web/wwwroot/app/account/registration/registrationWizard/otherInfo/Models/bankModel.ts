//export interface BankModel {
//    bankId: number;
//    bankName: string;
//    bankCode: string;
    //isAutoDebitforExcise: string;
    //ownerCSId: number;
    //ownerLocId: number;
//}
import { ProfileModel } from "framework/profile/ProfileModel";

export class BankModel extends ProfileModel {
    bankId: number;
    bankName: string;
    bankCode: string;
}
