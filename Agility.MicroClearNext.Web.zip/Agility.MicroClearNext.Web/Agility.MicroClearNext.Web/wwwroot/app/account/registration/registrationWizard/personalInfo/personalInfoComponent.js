"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var forms_1 = require("@angular/forms");
var router_1 = require("@angular/router");
var registrationWizardService_1 = require("../registrationWizardService");
var wizardDataService_1 = require("../wizardData/wizardDataService");
var registrationservice_1 = require("../registrationservice");
//import { RegistrationTypeModel } from './model/registrationtypemodel';
//import { DocumentTypeModel } from './model/documenttypemodel';
var PersonalInfoComponent = (function () {
    function PersonalInfoComponent(_fb, router, activatedRoute, registrationWizardService, route, FormDataService, registrationService) {
        this._fb = _fb;
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.registrationWizardService = registrationWizardService;
        this.route = route;
        this.FormDataService = FormDataService;
        this.registrationService = registrationService;
        this.docdetails = [];
    }
    PersonalInfoComponent.prototype.ngOnInit = function () {
        this.getGenders();
        this.getIDTypes();
        this.personalInfoForm = this._fb.group({
            firstName: ['', [forms_1.Validators.required]],
            lastName: ['', [forms_1.Validators.required]],
            gender: [''],
            idDetails: this._fb.group({
                idType: [''],
                gst: [''],
            }),
            uploadedDocs: this._fb.group({
                docType: [''],
                category: [''],
                file: ['']
            })
        });
        this.personalInfo = this.FormDataService.getpersonalInfo();
        this.getDocsData();
        this.filecount();
        this.getGenders();
        this.getIDTypes();
        if (this.personalInfo.IdType != undefined)
            this.getRegistrationTypeById(this.personalInfo.IdType);
    };
    PersonalInfoComponent.prototype.validatePersonalInfo = function (model, isValid) {
        if (isValid) {
            this.FormDataService.setpersonalInfo(model);
            this.registrationWizardService.emitStepCompletionStatus(this.activatedRoute.snapshot.data['stepCount']);
            this.router.navigate(['/registration/wizard/address-info']);
        }
    };
    PersonalInfoComponent.prototype.goToPreviousStep = function () {
        this.router.navigate(['/Account/Login']);
    };
    PersonalInfoComponent.prototype.filecount = function () {
        if (this.docdetails.length > 0)
            this.fileheader = true;
        else
            this.fileheader = false;
    };
    PersonalInfoComponent.prototype.fileChange = function (event) {
        var fileList = event.target.files;
        if (fileList.length > 0) {
            this.file = fileList[0];
        }
        if (this.file != undefined) {
            this.FormDataService.setIndividualUpldDoc(this.file);
            var Idtype = this.personalInfo.DocTypeVal;
            if (Idtype != undefined)
                this.Selecteddoc = this.Doctypes.find(function (x) { return x.typeId == Idtype; }).name;
            else
                this.Selecteddoc = "Not Selected";
            var docdata = {
                'docType': this.Selecteddoc,
                'docId': Idtype,
                'file': this.file,
            };
            this.docdetails = this.FormDataService.setIndividualDocs(docdata);
            this.filecount();
        }
    };
    PersonalInfoComponent.prototype.getDocsData = function () {
        this.docdetails = this.FormDataService.getIndividualDocs();
    };
    PersonalInfoComponent.prototype.getGenders = function () {
        var _this = this;
        this.registrationService.getGender().subscribe(function (response) {
            _this.genders = response;
        }, function (error) { return console.error(error); });
    };
    PersonalInfoComponent.prototype.getIDTypes = function () {
        var _this = this;
        this.registrationService.getIdType().subscribe(function (response) { return _this.Idtypes = response; }, function (error) { return console.error(error); });
    };
    PersonalInfoComponent.prototype.getRegistrationTypeById = function (id) {
        var _this = this;
        this.registrationService.getRegistrationTypeById(id)
            .subscribe(function (Response) {
            _this.Doctypes = Response;
            _this.personalInfo.DocTypeVal = _this.Doctypes[0].typeId;
        }, function (error) { return console.error(error); });
    };
    return PersonalInfoComponent;
}());
PersonalInfoComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'app-registration-personalinfo',
        templateUrl: './personalInfoComponent.html',
        providers: [registrationWizardService_1.RegistrationWizardService, registrationservice_1.RegistrationService],
        styleUrls: ['./personalInfoComponent.css']
    }),
    __metadata("design:paramtypes", [forms_1.FormBuilder,
        router_1.Router,
        router_1.ActivatedRoute,
        registrationWizardService_1.RegistrationWizardService,
        router_1.ActivatedRoute,
        wizardDataService_1.FormDataService, registrationservice_1.RegistrationService])
], PersonalInfoComponent);
exports.PersonalInfoComponent = PersonalInfoComponent;
//# sourceMappingURL=personalInfoComponent.js.map