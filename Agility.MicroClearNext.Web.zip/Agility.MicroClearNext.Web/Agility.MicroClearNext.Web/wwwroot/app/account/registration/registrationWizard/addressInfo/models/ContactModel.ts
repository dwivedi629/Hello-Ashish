import { ProfileModel } from "framework/profile/ProfileModel";

export class ContactModel extends ProfileModel {
    //contactId: number;
    //parentId: number;
    //parentType: string;
    //isPrimary: string;
    //businessNumber: string;
    //residencyNumber: string;
    //faxNumber: string;
    //mobileNumber: string;
    //businessCountryCode: string;
    //residenceCountryCode: string;
    //mobileCountryCode: string;
    //faXCountryCode: string;
    //csBizCountryCode: string;
    //csResidenCountryCode: string;
    //csMobileCountryCode: string;
    //csFAXCountryCode: string;
    //ownerCSId: number;
    //ownerLocId: number;
    mobileNor: {
        code: string;
        number: string;
    };
    primaryTelephoneNor: {
        code: string;
        number: string;
    };
    alternateTelephoneNor: {
        code: string;
        number: string;
    };
    faxNor: {
        code: string;
        number: string;
    };
}
