import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { IOrganization } from './organizationInfo';
import { RegistrationWizardService } from '../registrationWizardService';
import { organizationInfo } from '../wizardData/wizardDataModel';
import { FormDataService } from '../wizardData/wizardDataService';
import { RegistrationService } from '../registrationservice';
import { DocumentTypeModel } from '../personalinfo/model/documenttypemodel';


@Component({
    moduleId: module.id,
    selector: 'app-registration-org-info',
    templateUrl: './organizationInfoComponent.html',
    providers: [RegistrationWizardService, RegistrationService],
    styleUrls: ['./organizationInfoComponent.css']
})
export class OrganizationInfoComponent implements OnInit {
    public organizationInfoForm: FormGroup;
    public organizationInfoFormSubmitted: boolean;
    public organizationInfo: organizationInfo;
    public file: any;
    public docTypes: any;
    Selecteddoc: any;
    protected docdetails = [];
    public fileheader: any;
    private regAuthorities: any;
    private businessEntities: any;
    private businessEntity: any;
    private prefix: any;
    private SelectedEntity: any;


    constructor(private _fb: FormBuilder, private router: Router, private activatedRoute: ActivatedRoute,
        private registrationWizardService: RegistrationWizardService,
        private FormDataService: FormDataService,
        private registrationService: RegistrationService) {
    }

    ngOnInit() {
        this.organizationInfoForm = this._fb.group({
            regAuthority: [''],
            businessEntity: ['', [<any>Validators.required]],
            organizationName: ['', [<any>Validators.required]],
            brn: ['', [<any>Validators.required]],
            gstNumber: [''], // [<any>Validators.required]],
            uploadedDocs: this._fb.group({
                docType: [''],
                category: [''],
                file: ['']
            })
        });
        this.organizationInfo = this.FormDataService.getorganizationInfo();
        this.getDocType();
        this.getDocsData();
        this.filecount();
        this.getBussinessEntity();
        this.getRegistrationAuthority();
    }
    getNAuto(prefix: string) {
        this.businessEntity = null;
        this.businessEntity = this.businessEntities.filter((item) => item.name.toLowerCase().startsWith(prefix.toLowerCase()));
    }


    validateOrganizationInfo(model: IOrganization, isValid: boolean) {
        if (isValid) {
            if (model.businessEntity != undefined)
                model.businessEntityId = this.businessEntity.find(x => x.name == model.businessEntity).typeId;
            if (model.regAuthority != undefined)
                model.regAuthorityName = this.regAuthorities.find(x => x.typeId == model.regAuthority).name;
            this.organizationInfoFormSubmitted = true;
            this.FormDataService.setorganizationInfo(model);
            this.router.navigate(['/registration/wizard/account-info']);
        }
    }

    goToPreviousStep() {
        this.router.navigate(['/Account/Login']);
    }

    fileChange(event) {
        let fileList: FileList = event.target.files;
        if (fileList.length > 0) {
            this.file = fileList[0];
        }
        if (this.file != undefined) {
            var Idtype = this.organizationInfo.doctypval;
            if (Idtype != undefined)
                this.Selecteddoc = this.docTypes.find(x => x.documentId == Idtype).name;
            else
                this.Selecteddoc = "Not Selected";
            var docdata = {
                'docType': this.Selecteddoc,
                'docId': Idtype,
                'file': this.file,
            };
            this.docdetails = this.FormDataService.setOrgDocs(docdata);
            this.filecount();
        }
    }

    filecount() {
        if (this.docdetails.length > 0)
            this.fileheader = true;
        else
            this.fileheader = false;
    }

    getDocType() {
        this.registrationService.getDocumentType().subscribe
            (response => {
                this.docTypes = response;
            },
            error => console.log(error));
    }

    getDocsData() {
        this.docdetails = this.FormDataService.getOrgDocs();
    }

    change(object: any): void {
        //event.preventDefault();
        var Idtype = this.organizationInfo.doctypval;
        this.Selecteddoc = this.docTypes.find(x => x.documentId == Idtype);
        var docdata = {
            'docType': this.Selecteddoc.name,
            'docId': Idtype,
            'file': object.formData,
            'fileName': object.name
        };
        this.docdetails = this.FormDataService.setOrgDocs(docdata);
        this.filecount();
    }

    getRegistrationAuthority() {

        this.registrationService.getRegistrationAuthority().subscribe
            (response => {
                this.regAuthorities = response;
            },
            error => console.log(error));
    }

    getBussinessEntity() {

        this.registrationService.getBussinessEntity().subscribe
            (response => {
                this.businessEntities = response;
                this.businessEntity = this.businessEntities;
            },
            error => console.log(error));
    }

}
