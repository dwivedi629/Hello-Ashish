  export interface otherInfoModel
  {
      bankDetails: {
          bankId: string;
          bankName: string;
          branch: string;
          accountNo: string;
          ibANCode: string;
      };
      customStationId: string;
      assocustomStation: string;
      registeredCSId: string;
      registeredCSName: string;
  }
