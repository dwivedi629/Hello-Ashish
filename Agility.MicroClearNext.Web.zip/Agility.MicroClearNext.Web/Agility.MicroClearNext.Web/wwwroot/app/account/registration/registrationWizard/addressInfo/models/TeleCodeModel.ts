﻿
import { ProfileModel } from "framework/profile/ProfileModel";

export class TeleCodeModel extends ProfileModel {
    telePhoneCountryCodeId: number;
    countryId: number;
    countryCode: string;
}