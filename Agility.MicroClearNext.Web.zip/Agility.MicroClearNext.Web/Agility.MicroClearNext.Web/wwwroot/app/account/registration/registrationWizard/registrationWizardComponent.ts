import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { RegistrationWizardService } from './registrationWizardService';
import { FormDataService } from './wizardData/wizardDataService';

@Component({
  moduleId: module.id,
  selector: 'app-registration-wizard',
  templateUrl: './registrationWizardComponent.html',
  styleUrls: ['./registrationWizardComponent.css'],
  providers: [RegistrationWizardService, FormDataService]
})
export class RegistrationWizardComponent implements OnInit {
  public data: any = {};
  public isCompleted: boolean = false;
  public completedStep: number = 0;
  public registrationType: string;
  private dispLable: string;

  constructor(
      private router: Router,
      private FormDataService: FormDataService,
    private activatedRoute: ActivatedRoute,
    private registrationWizardService: RegistrationWizardService
  ) {
    this.registrationWizardService.stepCompletionStatusEmitted$.subscribe(
      status => {
        this.completedStep = status;
      });
  }

  ngOnInit() {
      this.registrationType = this.activatedRoute.snapshot.params['registrationType'];
      this.FormDataService.setStakeHolderType(this.registrationType);
      if (this.registrationType === 'organization') {
          this.dispLable = 'Organization';
          this.router.navigate(['organization-info'], { relativeTo: this.activatedRoute });
      }
      else
      {
          this.dispLable = 'Individual';
      }

  }

  checkWizardStatus(currentStep: number) {
      console.log(this.completedStep);
      console.log(currentStep);
    if (this.completedStep >= currentStep) {
        this.completedStep = currentStep - 1;
        console.log(this.completedStep);
    }
  }
}
