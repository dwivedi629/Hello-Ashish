﻿
import { ProfileModel } from "framework/profile/ProfileModel";

export class CityModel extends ProfileModel {
    cityId: string;

    cityName?: string;
}