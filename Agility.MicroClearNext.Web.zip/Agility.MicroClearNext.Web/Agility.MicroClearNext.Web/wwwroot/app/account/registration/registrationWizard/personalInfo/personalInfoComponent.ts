import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { IPersonal } from './personalInfo';
import { Router, ActivatedRoute } from '@angular/router';
import { RegistrationWizardService } from '../registrationWizardService';
import { FormDataService } from "../wizardData/wizardDataService";
import { personalInfo } from "../wizardData/wizardDataModel";
import { RegistrationService } from '../registrationservice';
//import { RegistrationTypeModel } from './model/registrationtypemodel';
//import { DocumentTypeModel } from './model/documenttypemodel';

@Component({
    moduleId: module.id,
  selector: 'app-registration-personalinfo',
  templateUrl: './personalInfoComponent.html',
  providers: [RegistrationWizardService, RegistrationService], // RegistrationTypeModel, DocumentTypeModel],
  styleUrls: ['./personalInfoComponent.css']
})
export class PersonalInfoComponent implements OnInit {
    public personalInfoForm: FormGroup;
    public personalInfo: personalInfo;
  public personalInfoFormSubmitted: boolean;
  protected docdetails = [];
  public file: any;
  public fileheader: any;
  prefix: any;
  Selecteddoc: any;
  Idtypes: any[];
  Doctypes: any[];
  genders: any[];

  constructor(
    private _fb: FormBuilder,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private registrationWizardService: RegistrationWizardService,
    private route: ActivatedRoute,
    private FormDataService: FormDataService, private registrationService: RegistrationService
  ) { }

  ngOnInit() {
      this.getGenders();
      this.getIDTypes();
    this.personalInfoForm = this._fb.group({
      firstName: ['', [<any>Validators.required]],
      lastName: ['',[<any>Validators.required]],
      gender: [''],   //[<any>Validators.required]],
    
      idDetails: this._fb.group({
        idType: [''], //[<any>Validators.required]],
        gst: [''],  //[<any>Validators.required]]
      }),
      uploadedDocs: this._fb.group({
        docType: [''],
        category: [''], 
        file: ['']
      })
      });
    this.personalInfo = this.FormDataService.getpersonalInfo();
    this.getDocsData();
    this.filecount();
    this.getGenders();
    this.getIDTypes();
    if (this.personalInfo.IdType != undefined)
        this.getRegistrationTypeById(this.personalInfo.IdType);
  }

  validatePersonalInfo(model: personalInfo, isValid: boolean) {
      if (isValid) {
          this.FormDataService.setpersonalInfo(model);
          this.registrationWizardService.emitStepCompletionStatus(this.activatedRoute.snapshot.data['stepCount']);
          this.router.navigate(['/registration/wizard/address-info']);
      }
  }

  goToPreviousStep() {
      this.router.navigate(['/Account/Login']);
  }

  filecount() {
      if (this.docdetails.length > 0)
          this.fileheader = true;
      else
          this.fileheader = false;
  }



  fileChange(event) {
      let fileList: FileList = event.target.files;
      if (fileList.length > 0) {
          this.file = fileList[0];
      }
      if (this.file != undefined) {
          this.FormDataService.setIndividualUpldDoc(this.file);
          var Idtype = this.personalInfo.DocTypeVal;
          if (Idtype != undefined)
              this.Selecteddoc = this.Doctypes.find(x => x.typeId == Idtype).name;
          else
              this.Selecteddoc = "Not Selected";
          var docdata = {
              'docType': this.Selecteddoc,
              'docId': Idtype,
              'file': this.file,
          };
          this.docdetails=this.FormDataService.setIndividualDocs(docdata);
          this.filecount();
      }
  }

  getDocsData()
  {
      this.docdetails=this.FormDataService.getIndividualDocs();
  }

      getGenders()
      {
          this.registrationService.getGender().subscribe
              (response => {
                  this.genders = response;
              },
              error => console.error(error));

      }


      getIDTypes()
      {
          this.registrationService.getIdType().subscribe
              (response => this.Idtypes = response,
              error => console.error(error));
      }

      getRegistrationTypeById(id: any) {
          this.registrationService.getRegistrationTypeById(id)
              .subscribe(Response => {
                  this.Doctypes = Response;
                  this.personalInfo.DocTypeVal = this.Doctypes[0].typeId;
              },
              error => console.error(error));
      }
  }
