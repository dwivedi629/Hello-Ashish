export interface IPersonal {
    registeredCustomStation: string;
    associateCustomStation: string;
    bankName: string;
    accountNo: string;
    ibanCode: string;
    bankLogo: string;
}