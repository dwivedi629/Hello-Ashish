"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var registrationWizardService_1 = require("../registrationWizardService");
var forms_1 = require("@angular/forms");
var router_1 = require("@angular/router");
var wizardDataService_1 = require("../wizardData/wizardDataService");
var registrationservice_1 = require("../registrationservice");
var AddressInfoComponent = (function () {
    function AddressInfoComponent(_fb, router, activatedRoute, registrationWizardService, FormDataService, registrationService) {
        this._fb = _fb;
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.registrationWizardService = registrationWizardService;
        this.FormDataService = FormDataService;
        this.registrationService = registrationService;
        this.selectOptions = {
            'minimumResultsForSearch': '-1'
        };
        this.myControl = new forms_1.FormControl();
    }
    AddressInfoComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.filteredOptions = this.myControl.valueChanges
            .startWith(null)
            .map(function (val) { return val ? _this.filter(val) : _this.postalCode.slice(); });
        this.addressInfoForm = this._fb.group({
            country: [''],
            state: [''],
            city: [''],
            countryname: [''],
            statename: [''],
            cityname: [''],
            pin: [''],
            pincode: [''],
            addressLine1: ['', [forms_1.Validators.required]],
            addressLine2: [''],
            mobCode: [''],
            mobNumber: [''],
            primaryTelCode: [''],
            primaryTelNumber: [''],
            altCode: [''],
            altNumber: [''],
            faxCode: [''],
            faxNumber: [''],
        });
        this.addressInfo = this.FormDataService.getaddressInfo();
        this.getCountries();
        if (this.addressInfo.state != undefined) {
            this.GetStatesByCountry(this.addressInfo.country);
            this.getTeleCode(this.addressInfo.country);
        }
        if (this.addressInfo.state) {
            this.GetCitiesByState(this.addressInfo.state);
            this.getPostalCode(this.addressInfo.state);
        }
    };
    AddressInfoComponent.prototype.validateAddressInfo = function (model, isValid) {
        if (isValid) {
            if (model.country != undefined)
                model.countryname = this.countries.find(function (x) { return x.countryId == model.country; }).countryName;
            if (model.state != undefined)
                model.statename = this.state.find(function (x) { return x.stateId == model.state; }).stateName;
            if (model.city != undefined)
                model.cityname = this.city.find(function (x) { return x.cityId == model.city; }).cityName;
            if (model.pincode != undefined)
                model.pin = this.postalCode.find(function (x) { return x.postalCode == model.pincode; }).postalCodeId;
            this.FormDataService.setaddressInfo(model);
            this.router.navigate(['/registration/wizard/other-info']);
        }
    };
    AddressInfoComponent.prototype.goToPreviousStep = function () {
        this.router.navigate(['/Account/Login']);
    };
    AddressInfoComponent.prototype.getCountries = function () {
        var _this = this;
        this.registrationService.getCountry().subscribe(function (response) { _this.countries = response; });
    };
    AddressInfoComponent.prototype.GetStatesByCountry = function (id) {
        var _this = this;
        this.registrationService.getState(id)
            .subscribe(function (Response) { _this.state = Response; }, function (error) { return _this.errorMessage = error; });
    };
    AddressInfoComponent.prototype.GetCitiesByState = function (id) {
        var _this = this;
        this.registrationService.getCity(id)
            .subscribe(function (Response) { _this.city = Response; }, function (error) { return _this.errorMessage = error; });
    };
    AddressInfoComponent.prototype.getTeleCode = function (id) {
        var _this = this;
        this.registrationService.getTeleCode(id)
            .subscribe(function (Response) { _this.telePhoneCountryCode = Response; }, function (error) { return _this.errorMessage = error; });
    };
    AddressInfoComponent.prototype.getPostalCode = function (id) {
        var _this = this;
        this.registrationService.getPostalCode(id).subscribe(function (response) {
            _this.postalCodes = response;
            _this.postalCode = _this.postalCodes;
        }, function (error) { return _this.errorMessage = error; });
    };
    AddressInfoComponent.prototype.getNAuto = function (prefix) {
        this.postalCode = null;
        this.postalCode = this.postalCodes.filter(function (item) { return item.postalCode.toLowerCase().startsWith(prefix.toLowerCase()); });
    };
    AddressInfoComponent.prototype.filter = function (val) {
        return this.postalCode.filter(function (option) { return option.postalCode.indexOf(val.toLowerCase()) === 0; });
    };
    return AddressInfoComponent;
}());
AddressInfoComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'app-address-info',
        templateUrl: './addressInfoComponent.html',
        providers: [registrationWizardService_1.RegistrationWizardService, registrationservice_1.RegistrationService],
        styleUrls: ['./addressInfoComponent.css']
    }),
    __metadata("design:paramtypes", [forms_1.FormBuilder,
        router_1.Router,
        router_1.ActivatedRoute,
        registrationWizardService_1.RegistrationWizardService,
        wizardDataService_1.FormDataService,
        registrationservice_1.RegistrationService])
], AddressInfoComponent);
exports.AddressInfoComponent = AddressInfoComponent;
//# sourceMappingURL=addressInfoComponent.js.map