"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var SubmitModel = (function () {
    function SubmitModel() {
        this.banks = [];
        this.indvidualDoc = [];
        this.orgDoc = [];
    }
    return SubmitModel;
}());
exports.SubmitModel = SubmitModel;
//# sourceMappingURL=submitModel.js.map