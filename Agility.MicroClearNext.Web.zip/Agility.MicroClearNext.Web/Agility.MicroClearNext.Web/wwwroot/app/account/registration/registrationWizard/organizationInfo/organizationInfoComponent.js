"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var forms_1 = require("@angular/forms");
var router_1 = require("@angular/router");
var registrationWizardService_1 = require("../registrationWizardService");
var wizardDataService_1 = require("../wizardData/wizardDataService");
var registrationservice_1 = require("../registrationservice");
var OrganizationInfoComponent = (function () {
    function OrganizationInfoComponent(_fb, router, activatedRoute, registrationWizardService, FormDataService, registrationService) {
        this._fb = _fb;
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.registrationWizardService = registrationWizardService;
        this.FormDataService = FormDataService;
        this.registrationService = registrationService;
        this.docdetails = [];
    }
    OrganizationInfoComponent.prototype.ngOnInit = function () {
        this.organizationInfoForm = this._fb.group({
            regAuthority: [''],
            businessEntity: ['', [forms_1.Validators.required]],
            organizationName: ['', [forms_1.Validators.required]],
            brn: ['', [forms_1.Validators.required]],
            gstNumber: [''],
            uploadedDocs: this._fb.group({
                docType: [''],
                category: [''],
                file: ['']
            })
        });
        this.organizationInfo = this.FormDataService.getorganizationInfo();
        this.getDocType();
        this.getDocsData();
        this.filecount();
        this.getBussinessEntity();
        this.getRegistrationAuthority();
    };
    OrganizationInfoComponent.prototype.getNAuto = function (prefix) {
        this.businessEntity = null;
        this.businessEntity = this.businessEntities.filter(function (item) { return item.name.toLowerCase().startsWith(prefix.toLowerCase()); });
    };
    OrganizationInfoComponent.prototype.validateOrganizationInfo = function (model, isValid) {
        if (isValid) {
            if (model.businessEntity != undefined)
                model.businessEntityId = this.businessEntity.find(function (x) { return x.name == model.businessEntity; }).typeId;
            if (model.regAuthority != undefined)
                model.regAuthorityName = this.regAuthorities.find(function (x) { return x.typeId == model.regAuthority; }).name;
            this.organizationInfoFormSubmitted = true;
            this.FormDataService.setorganizationInfo(model);
            this.router.navigate(['/registration/wizard/account-info']);
        }
    };
    OrganizationInfoComponent.prototype.goToPreviousStep = function () {
        this.router.navigate(['/Account/Login']);
    };
    OrganizationInfoComponent.prototype.fileChange = function (event) {
        var fileList = event.target.files;
        if (fileList.length > 0) {
            this.file = fileList[0];
        }
        if (this.file != undefined) {
            var Idtype = this.organizationInfo.doctypval;
            if (Idtype != undefined)
                this.Selecteddoc = this.docTypes.find(function (x) { return x.documentId == Idtype; }).name;
            else
                this.Selecteddoc = "Not Selected";
            var docdata = {
                'docType': this.Selecteddoc,
                'docId': Idtype,
                'file': this.file,
            };
            this.docdetails = this.FormDataService.setOrgDocs(docdata);
            this.filecount();
        }
    };
    OrganizationInfoComponent.prototype.filecount = function () {
        if (this.docdetails.length > 0)
            this.fileheader = true;
        else
            this.fileheader = false;
    };
    OrganizationInfoComponent.prototype.getDocType = function () {
        var _this = this;
        this.registrationService.getDocumentType().subscribe(function (response) {
            _this.docTypes = response;
        }, function (error) { return console.log(error); });
    };
    OrganizationInfoComponent.prototype.getDocsData = function () {
        this.docdetails = this.FormDataService.getOrgDocs();
    };
    OrganizationInfoComponent.prototype.change = function (object) {
        //event.preventDefault();
        var Idtype = this.organizationInfo.doctypval;
        this.Selecteddoc = this.docTypes.find(function (x) { return x.documentId == Idtype; });
        var docdata = {
            'docType': this.Selecteddoc.name,
            'docId': Idtype,
            'file': object.formData,
            'fileName': object.name
        };
        this.docdetails = this.FormDataService.setOrgDocs(docdata);
        this.filecount();
    };
    OrganizationInfoComponent.prototype.getRegistrationAuthority = function () {
        var _this = this;
        this.registrationService.getRegistrationAuthority().subscribe(function (response) {
            _this.regAuthorities = response;
        }, function (error) { return console.log(error); });
    };
    OrganizationInfoComponent.prototype.getBussinessEntity = function () {
        var _this = this;
        this.registrationService.getBussinessEntity().subscribe(function (response) {
            _this.businessEntities = response;
            _this.businessEntity = _this.businessEntities;
        }, function (error) { return console.log(error); });
    };
    return OrganizationInfoComponent;
}());
OrganizationInfoComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'app-registration-org-info',
        templateUrl: './organizationInfoComponent.html',
        providers: [registrationWizardService_1.RegistrationWizardService, registrationservice_1.RegistrationService],
        styleUrls: ['./organizationInfoComponent.css']
    }),
    __metadata("design:paramtypes", [forms_1.FormBuilder, router_1.Router, router_1.ActivatedRoute,
        registrationWizardService_1.RegistrationWizardService,
        wizardDataService_1.FormDataService,
        registrationservice_1.RegistrationService])
], OrganizationInfoComponent);
exports.OrganizationInfoComponent = OrganizationInfoComponent;
//# sourceMappingURL=organizationInfoComponent.js.map