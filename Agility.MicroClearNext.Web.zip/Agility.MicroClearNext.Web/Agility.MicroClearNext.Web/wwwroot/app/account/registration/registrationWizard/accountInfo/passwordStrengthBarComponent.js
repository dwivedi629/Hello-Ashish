"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var PasswordStrengthBarComponent = (function () {
    function PasswordStrengthBarComponent() {
        this._force = 0;
        this._regex = /[$-/:-?{-~!"^_`\[\]]/g;
        this._lowerLetters = false;
        this._upperLetters = false;
        this._numbers = false;
        this._symbols = false;
        this._flags = [];
        this._passedMatches = 0;
        this.colors = ['#F00', '#F90', '#FF0', '#9F0', '#44a846'];
    }
    PasswordStrengthBarComponent.prototype.measureStrength = function (p) {
        this._force = 0;
        this._lowerLetters = /[a-z]+/.test(p);
        this._upperLetters = /[A-Z]+/.test(p);
        this._numbers = /[0-9]+/.test(p);
        this._symbols = this._regex.test(p);
        this._flags = [this._lowerLetters, this._upperLetters, this._numbers, this._symbols];
        this._passedMatches = 0;
        for (var i = 0; i < this._flags.length; i++) {
            console.log(this._flags[i]);
            this._passedMatches += this._flags[i] === true ? 1 : 0;
        }
        this._force += 2 * p.length + ((p.length >= 10) ? 1 : 0);
        this._force += this._passedMatches * 10;
        // penality (short password)
        this._force = (p.length <= 6) ? Math.min(this._force, 10) : this._force;
        // penality (poor variety of characters)
        this._force = (this._passedMatches === 1) ? Math.min(this._force, 10) : this._force;
        this._force = (this._passedMatches === 2) ? Math.min(this._force, 20) : this._force;
        this._force = (this._passedMatches === 3) ? Math.min(this._force, 40) : this._force;
        return this._force;
    };
    PasswordStrengthBarComponent.prototype.getColor = function (s) {
        var idx = 0;
        if (s <= 10) {
            idx = 0;
        }
        else if (s <= 20) {
            idx = 1;
        }
        else if (s <= 30) {
            idx = 2;
        }
        else if (s <= 40) {
            idx = 3;
        }
        else {
            idx = 4;
        }
        return {
            idx: idx + 1,
            col: this.colors[idx]
        };
    };
    PasswordStrengthBarComponent.prototype.setBarColors = function (count, col) {
        for (var _n = 0; _n < count; _n++) {
            this['bar' + _n] = col;
        }
    };
    PasswordStrengthBarComponent.prototype.ngOnChanges = function (changes) {
        console.log('testting');
        var password = changes['passwordToCheck'].currentValue;
        this.setBarColors(5, '#DDD');
        if (password) {
            var c = this.getColor(this.measureStrength(password));
            this.setBarColors(c.idx, c.col);
        }
    };
    return PasswordStrengthBarComponent;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], PasswordStrengthBarComponent.prototype, "passwordToCheck", void 0);
PasswordStrengthBarComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'password-strength-bar',
        templateUrl: './passwordStrengthBarComponent.html',
        styleUrls: ['./passwordStrengthBarComponent.css']
    })
], PasswordStrengthBarComponent);
exports.PasswordStrengthBarComponent = PasswordStrengthBarComponent;
//# sourceMappingURL=passwordStrengthBarComponent.js.map