import { Component, OnInit } from '@angular/core';

@Component({
    moduleId: module.id,
  selector: 'app-registration-selection',
  templateUrl: './registrationSelectionComponent.html',
  styleUrls: ['./registrationSelectionComponent.css']
})
export class RegistrationSelectionComponent implements OnInit {

  constructor() {}
  ngOnInit() {
  }

}
