/// <reference path="registrationwizard/successdialog/successdialogcomponent.ts" />
import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule, Routes} from '@angular/router';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

//import { SharedModule } from '../Common/shared.module';

import { PasswordStrengthBarComponent } from './registrationWizard/accountInfo/passwordStrengthBarComponent';

import { RegistrationComponent } from './registrationComponent';
import { RegistrationHeaderComponent } from './registrationHeader/registrationHeaderComponent';
import { RegistrationSelectionComponent } from './registrationSelection/registrationSelectionComponent';
import { RegistrationWizardComponent } from './registrationWizard/registrationWizardComponent';
import { OrganizationInfoComponent } from './registrationWizard/organizationInfo/organizationInfoComponent';
import { AccountInfoComponent } from './registrationWizard/accountInfo/accountInfoComponent';
import { PersonalInfoComponent } from './registrationWizard/personalInfo/personalInfoComponent';
import { AddressInfoComponent } from './registrationWizard/addressInfo/addressInfoComponent';
import { OtherInfoComponent } from './registrationWizard/otherInfo/otherInfoComponent';
import { PreviewComponent } from './registrationWizard/preview/previewComponent';
import { AngularMaterialControlsModule } from '../Common/angular-material-controls.module';

import { AccordionModule } from "ngx-accordion/index";
import { ExpansionPanelsModule } from "ng2-expansion-panels";

import { SuccessDialogComponent } from './registrationWizard/successDialog/SuccessDialogComponent';

const registrationRoutes: Routes = [
  {
    path: 'registration',
    component: RegistrationComponent,
    children: [
      {
        path: 'selection',
        component: RegistrationSelectionComponent,
        data: {
          title: 'Registration Selection'
        }
      },
      {
        path: 'wizard',
        component: RegistrationWizardComponent,
        children: [
          {
            path: 'organization-info',
            component: OrganizationInfoComponent,
            data: {
              title: 'Organization Info',
              stepCount: 1
            }
          },
          {
            path: 'account-info',
            component: AccountInfoComponent,
            data: {
              title: 'Account Info',
              stepCount: 2
            }
          },
          {
            path: 'personal-info',
            component: PersonalInfoComponent,
            data: {
              title: 'Personal Info',
              stepCount: 3
            }
          },
          {
            path: 'address-info',
            component: AddressInfoComponent,
            data: {
              title: 'Address Info',
              stepCount: 4
            }
          },
          {
            path: 'other-info',
            component: OtherInfoComponent,
            data: {
              title: 'Other Info',
              stepCount: 5
            }
          },
          {
            path: 'preview',
            component: PreviewComponent,
            data: {
              title: 'Preview',
              stepCount: 6
            }
          },
          {
            path: '',
            redirectTo: 'account-info',
            pathMatch: 'full'
          },
          {
            path: '**',
            redirectTo: 'account-info',
            pathMatch: 'full'
          }
        ]
      },
      {
        path: '',
        redirectTo: 'selection',
        pathMatch: 'full'
      },
      {
        path: '**',
        redirectTo: 'selection',
        pathMatch: 'full'
      }
    ]
  }
];

@NgModule({
  declarations: [
    PasswordStrengthBarComponent,
    RegistrationComponent,
    RegistrationSelectionComponent,
    RegistrationHeaderComponent,
    RegistrationWizardComponent,
    PersonalInfoComponent,
    OrganizationInfoComponent,
    AccountInfoComponent,
    AddressInfoComponent,
    OtherInfoComponent,
      PreviewComponent,
      SuccessDialogComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
   // SharedModule,
      AngularMaterialControlsModule,
    RouterModule.forChild(
      registrationRoutes
    ),
     AccordionModule,
      ExpansionPanelsModule
  ],
  exports: [
    RouterModule,
    //SharedModule,
    RegistrationComponent
  ],
  entryComponents: [
      SuccessDialogComponent
  ]
})
export class RegistrationRoutingModule {}
