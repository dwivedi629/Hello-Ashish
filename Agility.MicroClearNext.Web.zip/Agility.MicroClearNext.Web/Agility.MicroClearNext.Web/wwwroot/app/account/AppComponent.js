"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var platform_browser_1 = require("@angular/platform-browser");
var FxContext_1 = require("framework/context/FxContext");
var AppComponent = (function () {
    function AppComponent(router, activatedRoute, titleService, fxContext) {
        var _this = this;
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.titleService = titleService;
        this.fxContext = fxContext;
        // Dynamic Browser Tab Title
        this.router.events
            .filter(function (event) { return event instanceof router_1.NavigationEnd; })
            .map(function () { return _this.activatedRoute; })
            .map(function (route) {
            while (route.firstChild) {
                route = route.firstChild;
            }
            return route;
        })
            .filter(function (route) { return route.outlet === 'primary'; })
            .mergeMap(function (route) { return route.data; })
            .subscribe(function (event) {
            _this.titleService.setTitle(event['title']);
            _this.currentRouteUrl = _this.router.url;
            _this.registrationBg = _this.currentRouteUrl.startsWith('/registration');
            _this.hideHeaders = _this.currentRouteUrl !== '/Account/Login' && !_this.currentRouteUrl.startsWith('/registration');
            if (event instanceof router_1.NavigationEnd) {
                window.scrollTo(0, 0);
            }
        });
    }
    AppComponent.prototype.ngOnInit = function () {
        this.router.navigate(["/Account"]);
    };
    return AppComponent;
}());
__decorate([
    core_1.HostBinding('class.registration-bg'),
    __metadata("design:type", Boolean)
], AppComponent.prototype, "registrationBg", void 0);
__decorate([
    core_1.HostBinding('class.common-bg'),
    __metadata("design:type", Boolean)
], AppComponent.prototype, "hideHeaders", void 0);
AppComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: "body",
        templateUrl: "AppComponent.html",
        styles: ['.active {background-color:#dcdcdc}', '.fx-nav-container {height: 500px;}', '.fx-nav {width:70px}']
    }),
    __metadata("design:paramtypes", [router_1.Router,
        router_1.ActivatedRoute,
        platform_browser_1.Title,
        FxContext_1.FxContext])
], AppComponent);
exports.AppComponent = AppComponent;
//# sourceMappingURL=AppComponent.js.map