"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var forms_1 = require("@angular/forms");
var platform_browser_1 = require("@angular/platform-browser");
var animations_1 = require("@angular/platform-browser/animations");
var FrameworkModule_1 = require("framework/FrameworkModule");
var AppRoutingModule_1 = require("./AppRoutingModule");
var AppComponent_1 = require("./AppComponent");
var CommonService_1 = require("framework/CommonService");
var AccountModule_1 = require("./AccountModule");
var ngx_accordion_1 = require("ngx-accordion");
var JourneyModule_1 = require("../cargo/JourneyModule");
var JourneyRoutingModule_1 = require("../cargo/JourneyRoutingModule");
var MenuModalComponent_1 = require("../header/menuModal/MenuModalComponent");
var HeaderComponent_1 = require("../header/HeaderComponent");
var ProfileModalComponent_1 = require("../header/profileModal/ProfileModalComponent");
var SearchModalComponent_1 = require("../header/searchModal/SearchModalComponent");
var QuickLinksModalComponent_1 = require("../header/quickLinksModal/QuickLinksModalComponent");
var SubheaderComponent_1 = require("../subheader/SubheaderComponent");
var ng2_filter_pipe_1 = require("ng2-filter-pipe");
//import { HashLocationStrategy, LocationStrategy } from "@angular/common";
var angular2_masonry_1 = require("angular2-masonry");
var BillOfLadingLineService_1 = require("../cargo/journeyDetails/billOfLadingLine/BillOfLadingLineService");
//import { OverlayMenuService } from "../header/OverlaymenuService";
var OverlayMenuService_1 = require("../header/OverlayMenuService");
var filter_menu_service_1 = require("../account/Common/filter-menu.service");
//import { VesselModule } from "../vessel/vessel.module";
var DashboardModule_1 = require("../dashboard/DashboardModule");
var forgotPwdComponent_1 = require("./forgotPwd/forgotPwdComponent");
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        imports: [
            platform_browser_1.BrowserModule,
            animations_1.BrowserAnimationsModule,
            FrameworkModule_1.FrameworkModule,
            AppRoutingModule_1.AppRoutingModule,
            AccountModule_1.AccountModule,
            ngx_accordion_1.AccordionModule,
            JourneyModule_1.JourneyModule,
            JourneyRoutingModule_1.JourneyRoutingModule,
            ng2_filter_pipe_1.Ng2FilterPipeModule,
            angular2_masonry_1.MasonryModule,
            DashboardModule_1.DashboardModule,
            // DeclarationModule,
            //  MdDialogRef,
            forms_1.FormsModule
        ],
        declarations: [
            HeaderComponent_1.HeaderComponent,
            MenuModalComponent_1.MenuModalComponent,
            ProfileModalComponent_1.ProfileModalComponent,
            SearchModalComponent_1.SearchModalComponent,
            QuickLinksModalComponent_1.QuickLinksModalComponent,
            SubheaderComponent_1.SubheaderComponent,
            AppComponent_1.AppComponent
        ],
        entryComponents: [
            AppComponent_1.AppComponent,
            MenuModalComponent_1.MenuModalComponent,
            ProfileModalComponent_1.ProfileModalComponent,
            SearchModalComponent_1.SearchModalComponent,
            QuickLinksModalComponent_1.QuickLinksModalComponent,
            forgotPwdComponent_1.ForgotPWDComponent
            //MdDialogRef
        ],
        providers: [
            CommonService_1.CommonService,
            //  MdDialogRef,
            BillOfLadingLineService_1.BolLineService,
            OverlayMenuService_1.OverlayMenuService,
            //    JourneyService,
            // LoginService,
            //  ManifestService,    
            BillOfLadingLineService_1.BolLineService,
            filter_menu_service_1.FilterMenuService
        ],
        bootstrap: [
            AppComponent_1.AppComponent
        ]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=AppModule.js.map