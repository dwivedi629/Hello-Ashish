(function (global) {
    System.config({
        paths: {
            "npm:": "lib/js/"
        },
        map: {
            app: "app",
            // angular bundles
            "@angular/animations": "npm:@angular/animations.umd.js",
            "@angular/animations/browser": "npm:@angular/animations-browser.umd.js",
            "@angular/core": "npm:@angular/core.umd.js",
            "@angular/common": "npm:@angular/common.umd.js",
            "@angular/compiler": "npm:@angular/compiler.umd.js",
            "@angular/cdk": "npm:@angular/cdk.umd.js",
            "@angular/platform-browser/animations": "npm:@angular/platform-browser-animations.umd.js",
            "@angular/platform-browser-dynamic": "npm:@angular/platform-browser-dynamic.umd.js",
            "@angular/http": "npm:@angular/http.umd.js",
            "@angular/router": "npm:@angular/router.umd.js",
            "@angular/forms": "npm:@angular/forms.umd.js",
            "@angular/material": "npm:@angular/material.umd.js",
            "@angular/flex-layout": "npm:@angular/flex-layout.umd.js",
            "ngx-accordion": "npm:ngx-accordion",
            "ng2-expansion-panels": "npm:ng2-expansion-panels",
            "ng2-filter-pipe": "npm:ng2-filter-pipe",
            // other libraries
            "rxjs": "npm:rxjs",
            "hammerjs": "npm:hammerjs/hammer.js",
            //lodash
            "lodash": "npm:lodash/lodash.js",
            '@swimlane/ngx-datatable': 'npm:ngx-datatable/ngx-datatable/release/index.js',
            "@angular/platform-browser": "npm:@angular/platform-browser.umd.js",

            // "angular2-masonry": "node_modules/angular2-masonry",
            "masonry-layout": "npm:masonry-layout/dist/masonry.pkgd.js",
            "angular2-masonry": "npm:angular2-masonry",
            //"masonry-layout": "npm:masonry-layout"
        },
        meta: {
        },       
        packages: {
            'dashboard': {
                main: "/dashboard/*.js",
                defaultExtension: 'js'
            },
            'header': {
                main: "/header/*.js",
                defaultExtension: 'js'
            },
            'subheader': {
                main: "/subheader/*.js",
                defaultExtension: 'js'
            },
            'cargo': {
                main: "/cargo/*.js",
                defaultExtension: 'js'
            },
            'vessel': {
                main: "/vessel/*.js",
                defaultExtension: 'js'
            },
            'declaration': {
                main: "/declaration/*.js",
                defaultExtension: 'js'
            },
            app: {
                main: "/account/Main.js",
                defaultExtension: "js"
            },
            rxjs: {
                defaultExtension: "js"
            },
            'ngx-accordion': { "main": "index.js", "defaultExtension": "js" },
            'ng2-expansion-panels': { "main": "/dist/ng2-expansion-panels.bundle.js", "defaultExtension": "js" },
            'ng2-filter-pipe': { "main": "/dist/index.js", "defaultExtension": "js" },
            "angular2-masonry": { "main": "index.js", "defaultExtension": "js", }

        }

    });
})(this);
