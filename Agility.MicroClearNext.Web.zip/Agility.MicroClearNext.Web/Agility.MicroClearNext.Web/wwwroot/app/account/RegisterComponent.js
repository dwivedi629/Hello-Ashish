"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var forms_1 = require("@angular/forms");
var router_1 = require("@angular/router");
var RegisterViewModel_1 = require("./viewmodels/RegisterViewModel");
var AccountService_1 = require("./AccountService");
var CommonService_1 = require("framework/CommonService");
var OrganizationViewModel_1 = require("./viewmodels/OrganizationViewModel");
var RegisterComponent = (function () {
    function RegisterComponent(route, accountService, formBuilder, router, commonService) {
        var _this = this;
        this.route = route;
        this.accountService = accountService;
        this.formBuilder = formBuilder;
        this.router = router;
        this.commonService = commonService;
        this.idVal = "id";
        this.textVal = "name";
        this.organizations = [
            { organizationId: 1, name: "aes", organizationEmailAddress: "aes@agility.com", organizationPhoneNumber: "9780987098709709" },
            { organizationId: 2, name: "cus", organizationEmailAddress: "cus@agility.com", organizationPhoneNumber: "9780987098709709" }
        ];
        this.stateCtrl = new forms_1.FormControl();
        this.filteredStates = this.stateCtrl.valueChanges
            .startWith(null)
            .map(function (name) { return _this.filterOrganizations(name); });
    }
    RegisterComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.route.data
            .subscribe(function () { return _this.organizationModel = _this.accountService.organizationModel; });
        this.dataModel = new RegisterViewModel_1.RegisterViewModel();
        this.dataModel.name = "";
        this.dataModel.userName = "";
        this.dataModel.organization = new OrganizationViewModel_1.OrganizationViewModel();
        this.dataModel.email = "";
        this.dataModel.password = "";
        this.dataModel.confirmPassword = "";
        this.registerForm = this.commonService.getFormGroup(this.dataModel, 0);
    };
    RegisterComponent.prototype.filterOrganizations = function (val) {
        return val ? this.organizations.filter(function (s) { return new RegExp("^" + val, 'gi').test(s.name); })
            : this.organizations;
    };
    RegisterComponent.prototype.displayFn = function (val) {
        return val ? val[this.textVal] : val;
    };
    RegisterComponent.prototype.validate = function () {
        var _this = this;
        this.accountService.register(this.registerForm.value).subscribe(function () {
            if (+_this.accountService.serviceDocument.result.type !== 0 /* success */) {
                _this.commonService.showAlert(_this.accountService.serviceDocument.result.message, " 'Register Failed. Please try again.'", 5000);
            }
            else {
                _this.router.navigate(["/DashBoard"]);
            }
        }, function () {
            _this.commonService.showAlert(_this.accountService.serviceDocument.result.message, " 'Register Failed. Please try again.'", 5000);
        });
    };
    return RegisterComponent;
}());
RegisterComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: "register",
        templateUrl: "RegisterComponent.html"
    }),
    __metadata("design:paramtypes", [router_1.ActivatedRoute, AccountService_1.AccountService, forms_1.FormBuilder, router_1.Router,
        CommonService_1.CommonService])
], RegisterComponent);
exports.RegisterComponent = RegisterComponent;
//# sourceMappingURL=RegisterComponent.js.map