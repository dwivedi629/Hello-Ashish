import { NgModule } from "@angular/core";
import { FormsModule } from '@angular/forms';
import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { FrameworkModule } from "framework/FrameworkModule";
import { AppRoutingModule } from "./AppRoutingModule";
import { AppComponent } from "./AppComponent";
import { CommonService } from "framework/CommonService";
import { AccountModule } from "./AccountModule";
import { AccordionModule } from "ngx-accordion";
import { JourneyModule } from "../cargo/JourneyModule";
import { JourneyRoutingModule } from "../cargo/JourneyRoutingModule";
import { MenuModalComponent } from '../header/menuModal/MenuModalComponent';
import { HeaderComponent } from "../header/HeaderComponent";
import { ProfileModalComponent } from '../header/profileModal/ProfileModalComponent';
import { SearchModalComponent } from '../header/searchModal/SearchModalComponent';
import { QuickLinksModalComponent } from '../header/quickLinksModal/QuickLinksModalComponent';
import { SubheaderComponent } from '../subheader/SubheaderComponent';
import { Ng2FilterPipeModule } from 'ng2-filter-pipe';
//import { HashLocationStrategy, LocationStrategy } from "@angular/common";
import { MasonryModule } from 'angular2-masonry';
import { BolLineService } from '../cargo/journeyDetails/billOfLadingLine/BillOfLadingLineService';
//import { OverlayMenuService } from "../header/OverlaymenuService";
import { OverlayMenuService } from "../header/OverlayMenuService";
import { FilterMenuService } from "../account/Common/filter-menu.service";
//import { VesselModule } from "../vessel/vessel.module";
import { DashboardModule } from "../dashboard/DashboardModule";
//import { DeclarationModule } from "../declaration/declaration.module";
import { MdDialogRef } from "@angular/material/material";
import { ForgotPWDComponent } from './forgotPwd/forgotPwdComponent';
@NgModule({
    imports: [

        BrowserModule,
        BrowserAnimationsModule,
        FrameworkModule,
        AppRoutingModule,
        AccountModule,
        AccordionModule,
        JourneyModule,
        JourneyRoutingModule,
        Ng2FilterPipeModule,
        MasonryModule,// VesselModule,
        DashboardModule,
        // DeclarationModule,
        //  MdDialogRef,
        FormsModule

    ],
    declarations: [
        HeaderComponent,
        MenuModalComponent,
        ProfileModalComponent,
        SearchModalComponent,
        QuickLinksModalComponent,
        SubheaderComponent,
        AppComponent

    ],
    entryComponents: [
        AppComponent,
        MenuModalComponent,
        ProfileModalComponent,
        SearchModalComponent,
        QuickLinksModalComponent,
        ForgotPWDComponent
        //MdDialogRef
    ],
    providers: [
        CommonService,
        //  MdDialogRef,
        BolLineService,
        OverlayMenuService,
        //    JourneyService,
        // LoginService,
        //  ManifestService,    
        BolLineService,
        FilterMenuService
    ],
    bootstrap: [
        AppComponent
    ]
})
export class AppModule {

}
