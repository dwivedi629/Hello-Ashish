﻿import { NgModule } from "@angular/core";
import { FrameworkModule } from "framework/FrameworkModule";
import { AccountRoutingModule } from "./AccountRoutingModule";
import { LoginComponent } from "./LoginComponent";
import { RegisterComponent } from "./RegisterComponent";
import { RegisterNewResolver } from "./RegisterResolver"
import { AccountService } from "./AccountService";
import { HomeComponent } from "./HomeComponent";
import { LogoComponent } from './logo/logoComponent';
import { ImagesCarouselComponent } from './imagesCarousel/imagesCarouselComponent';
import { ForgotPWDComponent } from './forgotPwd/forgotPwdComponent';
import { RegistrationModule } from './registration/registrationModule';
//import { SharedModule } from './Common/shared.module'
import { DashboardModule } from "../dashboard/DashboardModule";
//import { JourneyModule } from "../cargo/JourneyModule";
//import { JourneyRoutingModule } from "../cargo/JourneyRoutingModule";
@NgModule({
    imports: [
        FrameworkModule,
        AccountRoutingModule,
        RegistrationModule,
        DashboardModule,
        //JourneyModule,
        //JourneyRoutingModule
    ],
    declarations: [
        LoginComponent,
        RegisterComponent,
        HomeComponent,
        ImagesCarouselComponent,
        LogoComponent,
        ForgotPWDComponent
    ],
    providers: [
        AccountService,
        RegisterNewResolver
    ]
})
export class AccountModule {
}
