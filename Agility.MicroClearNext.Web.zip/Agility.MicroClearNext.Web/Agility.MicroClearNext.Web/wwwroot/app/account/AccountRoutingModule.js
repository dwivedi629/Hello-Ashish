"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var RegisterResolver_1 = require("./RegisterResolver");
var LoginComponent_1 = require("./LoginComponent");
var RegisterComponent_1 = require("./RegisterComponent");
var DashboardComponent_1 = require("../dashboard/DashboardComponent");
var AccountRoutes = [
    {
        path: "Account",
        data: {
            title: 'Microclear'
        },
        children: [
            {
                path: "", redirectTo: "Login", pathMatch: "full"
            },
            {
                path: "Home",
                component: DashboardComponent_1.DashboardComponent,
                data: {
                    title: 'Microclear'
                }
            },
            {
                path: "Login",
                component: LoginComponent_1.LoginComponent,
                data: {
                    title: 'Login'
                }
            },
            {
                path: "Register",
                component: RegisterComponent_1.RegisterComponent,
                data: {
                    title: 'Registration'
                },
                resolve: {
                    OrganizationViewModel: RegisterResolver_1.RegisterNewResolver
                }
            },
        ]
    }
];
var AccountRoutingModule = (function () {
    function AccountRoutingModule() {
    }
    return AccountRoutingModule;
}());
AccountRoutingModule = __decorate([
    core_1.NgModule({
        imports: [
            router_1.RouterModule.forChild(AccountRoutes)
        ]
    })
], AccountRoutingModule);
exports.AccountRoutingModule = AccountRoutingModule;
//# sourceMappingURL=AccountRoutingModule.js.map