﻿import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { RegisterNewResolver } from "./RegisterResolver";
import { LoginComponent } from "./LoginComponent";
import { RegisterComponent } from "./RegisterComponent";
import { DashboardComponent } from "../dashboard/DashboardComponent";
import { HomeComponent } from "./HomeComponent";

const AccountRoutes: Routes = [
    {
        path: "Account",
        data: {
            title: 'Microclear'
        },
        children: [
            {
                path: "", redirectTo: "Login", pathMatch: "full"
            },
            {
                path: "Home",
                component: DashboardComponent,
                data: {
                    title: 'Microclear'
                }
            },
            {
                path: "Login",
                component: LoginComponent,
                data: {
                    title: 'Login'
                }
            },
            {
                path: "Register",
                component: RegisterComponent,
                data: {
                    title: 'Registration'
                },
                resolve: {
                    OrganizationViewModel: RegisterNewResolver
                }
            },
        ]
    }
];

@NgModule({
    imports: [
        RouterModule.forChild(AccountRoutes)
    ]
})
export class AccountRoutingModule { }
