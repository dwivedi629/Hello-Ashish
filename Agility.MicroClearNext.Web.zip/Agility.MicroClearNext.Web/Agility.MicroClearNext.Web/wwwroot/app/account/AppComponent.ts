import { Component, HostBinding, OnInit } from "@angular/core";
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { FxContext } from "framework/context/FxContext";

@Component({
    moduleId: module.id,
    selector: "body",
    templateUrl: "AppComponent.html",
    styles: ['.active {background-color:#dcdcdc}', '.fx-nav-container {height: 500px;}', '.fx-nav {width:70px}']
})
export class AppComponent implements OnInit {
    public currentRouteUrl: string;
    @HostBinding('class.registration-bg') registrationBg: boolean;
    @HostBinding('class.common-bg') hideHeaders: boolean;

    constructor(private router: Router,
        private activatedRoute: ActivatedRoute,
        private titleService: Title,
        private fxContext: FxContext) {
        // Dynamic Browser Tab Title
        this.router.events
            .filter(event => event instanceof NavigationEnd)
            .map(() => this.activatedRoute)
            .map(route => {
                while (route.firstChild) {
                    route = route.firstChild;
                }
                return route;
            })
            .filter(route => route.outlet === 'primary')
            .mergeMap(route => route.data)
            .subscribe((event) => {
                this.titleService.setTitle(event['title']);
                this.currentRouteUrl = this.router.url;
                this.registrationBg = this.currentRouteUrl.startsWith('/registration');
                this.hideHeaders = this.currentRouteUrl !== '/Account/Login' && !this.currentRouteUrl.startsWith('/registration');
                if (event instanceof NavigationEnd) {
                    window.scrollTo(0, 0);
                }
            });
    }

    ngOnInit(): void {
        this.router.navigate(["/Account"]);
    }
}

