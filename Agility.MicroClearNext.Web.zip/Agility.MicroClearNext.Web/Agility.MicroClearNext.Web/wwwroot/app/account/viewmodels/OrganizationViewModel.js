"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var OrganizationViewModel = (function () {
    function OrganizationViewModel() {
    }
    return OrganizationViewModel;
}());
exports.OrganizationViewModel = OrganizationViewModel;
//# sourceMappingURL=OrganizationViewModel.js.map