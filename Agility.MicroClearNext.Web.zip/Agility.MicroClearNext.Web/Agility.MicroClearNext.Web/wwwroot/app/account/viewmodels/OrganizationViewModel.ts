﻿export class OrganizationViewModel {
    organizationId: number;
    name: string;
}