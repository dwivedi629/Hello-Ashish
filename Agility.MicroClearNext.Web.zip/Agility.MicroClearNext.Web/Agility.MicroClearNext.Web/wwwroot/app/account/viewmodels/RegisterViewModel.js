"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var RegisterViewModel = (function () {
    function RegisterViewModel() {
    }
    return RegisterViewModel;
}());
exports.RegisterViewModel = RegisterViewModel;
//# sourceMappingURL=RegisterViewModel.js.map