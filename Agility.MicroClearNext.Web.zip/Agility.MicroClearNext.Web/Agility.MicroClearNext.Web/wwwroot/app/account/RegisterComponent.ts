﻿import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from "@angular/forms";
import { Router, ActivatedRoute } from "@angular/router";
import { RegisterViewModel } from "./viewmodels/RegisterViewModel";
import { FxContext } from "framework/context/FxContext";
import { AccountService } from "./AccountService";
import { CommonService } from "framework/CommonService";
import { UserProfile } from "account/UserProfile";
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { OrganizationViewModel } from "./viewmodels/OrganizationViewModel";
import { State } from "framework/controls/State";

@Component({
    moduleId: module.id,
    selector: "register",
    templateUrl: "RegisterComponent.html"
})
export class RegisterComponent implements OnInit {
    stateCtrl: FormControl;
    filteredStates: any;
    idVal: string = "id";
    textVal: string = "name";
    organizations = [
        { organizationId: 1, name: "aes", organizationEmailAddress: "aes@agility.com", organizationPhoneNumber:"9780987098709709" },
        { organizationId: 2, name: "cus", organizationEmailAddress: "cus@agility.com", organizationPhoneNumber: "9780987098709709" }
    ]

    registerForm: FormGroup;
    dataModel: RegisterViewModel;
    organizationModel: OrganizationViewModel[];
    constructor(private route: ActivatedRoute, private accountService: AccountService, private formBuilder: FormBuilder, private router: Router,
        private commonService: CommonService
    ) {
        this.stateCtrl = new FormControl();
        this.filteredStates = this.stateCtrl.valueChanges
            .startWith(null)
            .map(name => this.filterOrganizations(name));
    }
    ngOnInit(): void {
        
        this.route.data
            .subscribe(() => this.organizationModel = this.accountService.organizationModel);
        this.dataModel = new RegisterViewModel();
        this.dataModel.name = "";
        this.dataModel.userName = "";
        this.dataModel.organization = new OrganizationViewModel();
        this.dataModel.email = "";
        this.dataModel.password = "";
        this.dataModel.confirmPassword = "";
        this.registerForm = this.commonService.getFormGroup(this.dataModel, 0);
    }
    filterOrganizations(val: string) {
        return val ? this.organizations.filter(s => new RegExp(`^${val}`, 'gi').test(s.name))
            : this.organizations;
    }

    displayFn(val) {
        return val ? val[this.textVal] : val;
    }
    validate() {
        this.accountService.register(this.registerForm.value).subscribe((
        ) => {
            if (+this.accountService.serviceDocument.result.type !== MessageType.success) {
                this.commonService.showAlert(this.accountService.serviceDocument.result.message, " 'Register Failed. Please try again.'", 5000);
            } else {
                this.router.navigate(["/DashBoard"]);
            }
        }, () => {
            this.commonService.showAlert(this.accountService.serviceDocument.result.message, " 'Register Failed. Please try again.'", 5000);
        });
    }
}