import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { FxContext } from "framework/context/FxContext";

@Component({
    moduleId: module.id,
    selector: "home-app",
    templateUrl: "HomeComponent.html",
    styles: ['.active {background-color:#dcdcdc}', '.fx-nav-container {height: 500px;}','.fx-nav {width:70px}']
})
export class HomeComponent{
}

