﻿
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

const appRoutes: Routes = [


    {
        path: 'journey',
        data: {
            title: 'Journey'
        },
        loadChildren: 'app/cargo/JourneyModule#JourneyModule'
        //loadChildren: 'app/journey/journey.module#JourneyModule'
    },
    {
        path: 'vessel',
        data: {
            title: 'Vessel'
        },
        loadChildren: 'app/vessel/vessel.module#VesselModule'
    },
    {
        path: 'declaration',
        data: {
            title: 'Declaration'
        },
        loadChildren: 'app/declaration/declaration.module#DeclarationModule'
    },];

@NgModule({
    imports: [
        RouterModule.forRoot(appRoutes)
    ]
})
export class AppRoutingModule { }
