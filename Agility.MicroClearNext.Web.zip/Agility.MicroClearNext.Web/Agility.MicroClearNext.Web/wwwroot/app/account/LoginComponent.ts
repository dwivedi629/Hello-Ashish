﻿import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, FormControl, Validators, ValidatorFn, AbstractControl } from "@angular/forms";
import { Router } from "@angular/router";
import { LoginViewModel } from "./viewmodels/LoginViewModel";
import { FxContext } from "framework/context/FxContext";
import { AccountService } from "./AccountService";
import { CommonService } from "framework/CommonService";
import { UserProfile } from "account/UserProfile";
import { IdentityMenuModel } from "account/IdentityMenuModel";
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { ServiceDocumentResult } from "framework/servicedocument/ServiceDocumentResult";

@Component({
    moduleId: module.id,
    selector: "login",
    templateUrl: "LoginComponent.html"
})
export class LoginComponent implements OnInit {
    loginForm: FormGroup;
    dataModel: LoginViewModel;
    serviceDocument: ServiceDocument<UserProfile>;
    private logval: ServiceDocumentResult;
    constructor(private fxContext: FxContext, private formBuilder: FormBuilder, private router: Router,
        private accountService: AccountService,
        private commonService: CommonService,
        private service: AccountService) {
        fxContext.IsAuthenticated = false;
    }

    ngOnInit(): void {
        this.dataModel = new LoginViewModel();
        this.dataModel.email = "";
        this.dataModel.password = "";
        this.dataModel.rememberMe = false;
        this.loginForm = this.commonService.getFormGroup(this.dataModel, 0);
        // Adding multple validators including custom validators."
        this.loginForm.controls["email"].setValidators([Validators.required, emailValidator("Invalid Email Address")]);
    }

    // custom validator
    //emailValidator(control: FormControl): any {
    //    debugger;
    //    if (control.value.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
    //        return null;
    //    } else {
    //        return { 'InvalidEmailAddress1': true };
    //    }
    //}

    validate() {
        if (this.loginForm.valid) {
            this.accountService.login(this.loginForm.value).subscribe((
            ) => {
                if (this.service.serviceDocument.result.type == MessageType.success) {
                    //this.fxContext.IsAuthenticated = true;
                    //this.fxContext.menus = this.service.serviceDocument.userProfile.menus;

                    this.fxContext.userProfile = this.service.serviceDocument.userProfile;
                    this.router.navigate(["Account/Home"]);
                }
                else {
                    this.commonService.showAlert(this.service.serviceDocument.result.message, "Please try again", 5000);
                }
            }, () => {
                this.commonService.showAlert("Login Failed. Please try again.");
            });
        }
        else
        {
            this.commonService.showAlert("Please enter credientials");
        }
    }
}

export function emailValidator(errorMessage): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } => {
        if (control.value.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
            return null;
        } else {
            return { errorMessage };
        }
    };
}
