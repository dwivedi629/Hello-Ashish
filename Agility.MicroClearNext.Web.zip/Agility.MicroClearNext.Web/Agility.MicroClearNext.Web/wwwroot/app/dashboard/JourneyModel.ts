﻿import { ProfileModel } from "framework/profile/ProfileModel";
import { LocationModel } from "./LocationModel";

export class JourneyModel extends ProfileModel {
    journeyId: number;
    journeyType: string;
    journeyNumber: string;
    lastPortOfCallId: number;
    LocationLastPortOfCallId: LocationModel;
    nextPortOfCallId: number;
    locationNextPortOfCallId: LocationModel;
    originPortId: number;
    arrivalPortId: number;
    entryCustomsStationId: number;
    exitCustomsStationId: number;
    lastPortOfCallATA: Date;
    lastPortOfCallATD: Date;
    lastPortOfCallVoyageNo: string;
    lastPortOfCallPurposeOfCall: string;
    lastPortOfCallISPS: number;
    entryPonumber: string;
    dateOfShipment: Date;
    expectedArrivalDate: Date;
    expectedDepartureDate: Date;
    vesselId: number;
    captainName: string;
    vesselName: string;
    actualBerth: string;
    shipCallNo: string;
    shipClearanceRefNo: string;
    principalSAName: string;
    shippingAgentCode: string;
    countryId: number;
    manifestList: any[];
    deletedInd: boolean;
}