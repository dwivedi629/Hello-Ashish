﻿import { Injectable } from "@angular/core";
import { Resolve, ActivatedRouteSnapshot } from "@angular/router";

import { Observable } from "rxjs/Observable";

import { JourneyService } from "./JourneyService";
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { JourneyModel } from "./JourneyModel";

@Injectable()
export class JourneyResolver implements Resolve<ServiceDocument<JourneyModel>> {
    constructor(private service: JourneyService) { }

    resolve(route: ActivatedRouteSnapshot): Observable<ServiceDocument<JourneyModel>> {
        return this.service.GetJouneyInfo();
    }
}
