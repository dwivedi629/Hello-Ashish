"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
//@Component({
//  selector: 'app-toolbar',
//  templateUrl: 'toolbar.component.html',
//  styleUrls: ['toolbar.component.css']
//})
var ToolbarComponent = (function () {
    function ToolbarComponent() {
        this.sources = [
            { value: 'source-0', viewValue: 'source1' },
            { value: 'source-1', viewValue: 'source2' },
            { value: 'source-2', viewValue: 'source3' }
        ];
        this.modules = [
            { value: 'module-0', viewValue: 'module1' },
            { value: 'module-1', viewValue: 'module2' },
            { value: 'module-2', viewValue: 'module3' }
        ];
    }
    ToolbarComponent.prototype.ngOnInit = function () {
    };
    return ToolbarComponent;
}());
ToolbarComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: "toolbar",
        templateUrl: "toolbar.component.html",
        styleUrls: ['toolbar.component.css']
    }),
    __metadata("design:paramtypes", [])
], ToolbarComponent);
exports.ToolbarComponent = ToolbarComponent;
//# sourceMappingURL=toolbar.component.js.map