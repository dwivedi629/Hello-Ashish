﻿import { Component, OnInit } from '@angular/core';

//@Component({
//  selector: 'app-toolbar',
//  templateUrl: 'toolbar.component.html',
//  styleUrls: ['toolbar.component.css']
//})
@Component({
    moduleId: module.id,
    selector: "toolbar",
    templateUrl: "toolbar.component.html",
    styleUrls: ['toolbar.component.css']
})
export class ToolbarComponent implements OnInit {

    sources = [
        { value: 'source-0', viewValue: 'source1' },
        { value: 'source-1', viewValue: 'source2' },
        { value: 'source-2', viewValue: 'source3' }
    ];
    modules = [
        { value: 'module-0', viewValue: 'module1' },
        { value: 'module-1', viewValue: 'module2' },
        { value: 'module-2', viewValue: 'module3' }
    ];

  constructor() { }

  ngOnInit() {
  }

}
