﻿import { Component, OnInit } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";

//import { AddressModel } from "./models/AddressModel";
//import { AddressService } from "./AddressService";
//import { CountryModel } from "../housebill/models/CountryModel";
//import { CityModel } from "./models/CityModel";


@Component({
    moduleId: module.id,
    selector: "dashboard",
    templateUrl: "DashboardComponent.html"
})

export class DashboardComponent implements OnInit {
    constructor() { }

    ngOnInit() {       
    }
    //serviceDocument: ServiceDocument<AddressModel>;
    //optionsData: any[];
    //country: CountryModel[];
    //city: CityModel[];
    //constructor(private _route: ActivatedRoute, private _router: Router, public _service: AddressService) {
    //    this.optionsData = [{ key: 'M', value: 'Male' }, { key: 'F', value: 'Female' }]
    //}

    //ngOnInit(): void {
    //    this._route.data
    //        .subscribe(() => {
    //            this.serviceDocument = this._service.serviceDocument;
    //        });
    //}

    //cancel() {
    //    this._router.navigate(["/Address"]);
    //    return false;
    //}


    //submit(): void {
    //    this._service.submit()
    //        .subscribe(() => {
    //            alert("submitted");
    //            this._router.navigate(["/Address"]);
    //        });
    //}

    //save() {
    //    this._service.save().subscribe(() => {
    //        alert("saved");
    //    });
    //}

    //GetCountry(event: any): void {
    //    this.country = [];
    //    this._service.getCountry(event.value).subscribe((data:any) => {          
    //        this.country = data["country"];
    //    });
    //}

    //GetCity(event: any): void {
    //    this.city = [];
    //    this._service.getCity(event.value).subscribe((data: any) => {
    //        this.city = data["city"];
    //    });
    //}
}