import { Component, OnInit } from '@angular/core';

//@Component({
//  selector: 'app-inbox-tabs',
//  templateUrl: 'inbox-tabs.component.html',
//  styleUrls: ['inbox-tabs.component.css']
//})
@Component({
    moduleId: module.id,
    selector: "inbox",
    templateUrl: "inbox-tabs.component.html",
    styleUrls: ['inbox-tabs.component.css']
})
export class InboxTabsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

