﻿import { Injectable } from "@angular/core";
import { Http, Response, RequestOptions, URLSearchParams } from "@angular/http";
import { Observable } from "rxjs/Observable";

import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { JourneyModel } from "./JourneyModel";

@Injectable()
export class JourneyService {
    serviceDocument: ServiceDocument<JourneyModel> = new ServiceDocument<JourneyModel>();

    constructor(private http: Http) { }

    GetJouneyInfo(): Observable<ServiceDocument<JourneyModel>> {
        return this.serviceDocument.open("/api/Cargo/GetJouneyInfo");
    }
}