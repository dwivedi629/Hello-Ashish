﻿import { NgModule } from "@angular/core";
import { FrameworkModule } from "framework/FrameworkModule";
import { DashboardRoutingModule } from "./DashboardRoutingModule";
import { DashboardComponent } from "./DashboardComponent";
import { InboxTabsComponent } from "./inbox-tabs/inbox-tabs.component";


import { AccordionModule } from "ngx-accordion/index";

@NgModule({
    imports: [
        FrameworkModule,
        DashboardRoutingModule,
        AccordionModule
    ],
    declarations: [     
        InboxTabsComponent,
        DashboardComponent
    ],
    providers: [
           
    ]
})
export class DashboardModule {
}
