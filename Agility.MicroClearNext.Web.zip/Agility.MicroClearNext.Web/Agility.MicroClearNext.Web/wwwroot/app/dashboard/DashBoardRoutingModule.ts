﻿import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";

import { DashboardComponent } from "./DashboardComponent";

const AccountRoutes: Routes = [
    {
        path: "Dashboard",
        children: [
            {
                path: "", redirectTo: "Index", pathMatch: "full"
            },
            {
                path: "Index",
                component: DashboardComponent,
            },
        ]
    }
];

@NgModule({
    imports: [
        RouterModule.forChild(AccountRoutes)
    ]
})
export class DashboardRoutingModule { }
