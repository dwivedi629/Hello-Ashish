"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var JourneyService_1 = require("./JourneyService");
var JourneyComponent = (function () {
    function JourneyComponent(_journeyService) {
        this._journeyService = _journeyService;
        this.journeyList = [
            {
                'id': 1,
                'title': 'JRN-6-MYPKG-17',
                'startsFromShortName': 'SIN',
                'arrivalToShortName': 'MY',
                'startsFromFullName': 'Singapore',
                'arrivalToFullName': 'Malaysia',
                'startDate': '23 Mar, 2017',
                'arrivalDate': '23 Mar, 2017',
                'startTime': '06:00 PM',
                'arrivalTime': '02:00 PM',
                'berthNumr': '06',
                'status': 'Arrived',
                'viaImage': 'Ship',
                'modeOfTransportation': 'Sea (Mode of Transportation)',
                'statusClass': 'arrived'
            },
            {
                'id': 2,
                'title': 'JRN-7-MYUKG-16',
                'startsFromShortName': 'NYC',
                'arrivalToShortName': 'MYBAI',
                'startsFromFullName': 'Singapore',
                'arrivalToFullName': 'Malaysia',
                'startDate': '29 Mar, 2017',
                'arrivalDate': '31 Mar, 2017',
                'startTime': '04:00PM',
                'arrivalTime': '09:00PM',
                'berthNumr': '19',
                'status': 'Cancellation Requested',
                'viaImage': 'Plane',
                'modeOfTransportation': 'Air (Mode of Transportation)',
                'statusClass': 'cancellation-requested'
            },
            {
                'id': 3,
                'title': 'NYC-7-UYIKG-18',
                'startsFromShortName': 'AEULR',
                'arrivalToShortName': 'MYBGG',
                'startsFromFullName': 'Singapore',
                'arrivalToFullName': 'Malaysia',
                'startDate': '1 May, 2017',
                'arrivalDate': '5 May, 2017',
                'startTime': '08:00AM',
                'arrivalTime': '02:00PM',
                'berthNumr': '26',
                'status': 'Approved to Unload',
                'viaImage': 'Ship',
                'modeOfTransportation': 'Sea (Mode of Transportation)',
                'statusClass': 'approved-to-unload'
            },
            {
                'id': 4,
                'title': 'URN-9-IKGHIG-34',
                'startsFromShortName': 'ALTEN',
                'arrivalToShortName': 'MYKEL',
                'startsFromFullName': 'Singapore',
                'arrivalToFullName': 'Malaysia',
                'startDate': '09 Jun, 2017',
                'arrivalDate': '11 Jun, 2017',
                'startTime': '10:00PM',
                'arrivalTime': '09:00PM',
                'berthNumr': '39',
                'status': 'Submitted',
                'viaImage': 'Ship',
                'modeOfTransportation': 'Sea (Mode of Transportation)',
                'statusClass': 'submitted'
            },
            {
                'id': 5,
                'title': 'USN-9-URMIN-02',
                'startsFromShortName': 'BOM',
                'arrivalToShortName': 'MYCAP',
                'startsFromFullName': 'Singapore',
                'arrivalToFullName': 'Malaysia',
                'startDate': '01 Jul, 2017',
                'arrivalDate': '04 Jul, 2017',
                'startTime': '06:00PM',
                'arrivalTime': '02:00PM',
                'berthNumr': '21',
                'status': 'Arrived',
                'viaImage': 'Ship',
                'modeOfTransportation': 'Sea (Mode of Transportation)',
                'statusClass': 'arrived'
            },
            {
                'id': 6,
                'title': 'UIN-4-MINPEI-03',
                'startsFromShortName': 'ALTEN',
                'arrivalToShortName': 'MYKEL',
                'startsFromFullName': 'Singapore',
                'arrivalToFullName': 'Malaysia',
                'startDate': '23 Jul, 2017',
                'arrivalDate': '26 Jul, 2017',
                'startTime': '10:00PM',
                'arrivalTime': '12:00PM',
                'berthNumr': '17',
                'status': 'Drafts',
                'viaImage': 'Ship',
                'modeOfTransportation': 'Sea (Mode of Transportation)',
                'statusClass': 'drafts'
            }
        ];
    }
    JourneyComponent.prototype.ngOnInit = function () {
        // this.getJourneyList();
    };
    JourneyComponent.prototype.getJourneyList = function () {
        var _this = this;
        this._journeyService.getJourneyList()
            .subscribe(function (journeyList) { return _this.journeyList = journeyList; }, function (error) { return _this.errorMessage = error; });
    };
    return JourneyComponent;
}());
JourneyComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'app-journey',
        templateUrl: './JourneyComponent.html',
        styleUrls: ['./JourneyComponent.css'],
        providers: [JourneyService_1.JourneyService]
    }),
    __metadata("design:paramtypes", [JourneyService_1.JourneyService])
], JourneyComponent);
exports.JourneyComponent = JourneyComponent;
//# sourceMappingURL=JourneyComponent.js.map