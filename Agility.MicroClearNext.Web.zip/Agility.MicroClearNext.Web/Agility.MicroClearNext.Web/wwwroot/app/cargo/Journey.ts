export interface IJourney {
  id: number;
  title: string;
  startsFromShortName: string;
  arrivalToShortName: string;
  startsFromFullName: string;
  arrivalToFullName: string;
  startDate: string;
  arrivalDate: string;
  startTime: string;
  arrivalTime: string;
  berthNumr: string;
  status: string;
  viaImage: string;
  modeOfTransportation: string;
  statusClass: string;
}
