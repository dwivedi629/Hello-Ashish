(function (global) {
    System.config({
        paths: {
            "npm:": "lib/js/"
        },
        map: {
            app: "app/cargo",
            // angular bundles
            "@angular/animations": "npm:@angular/animations.umd.js",
            "@angular/animations/browser": "npm:@angular/animations-browser.umd.js",
            "@angular/core": "npm:@angular/core.umd.js",
            "@angular/common": "npm:@angular/common.umd.js",
            "@angular/compiler": "npm:@angular/compiler.umd.js",
            "@angular/cdk": "npm:@angular/cdk.umd.js",
            "@angular/platform-browser/animations": "npm:@angular/platform-browser-animations.umd.js",
            "@angular/platform-browser-dynamic": "npm:@angular/platform-browser-dynamic.umd.js",
            "@angular/http": "npm:@angular/http.umd.js",
            "@angular/router": "npm:@angular/router.umd.js",
            "@angular/forms": "npm:@angular/forms.umd.js",
            "@angular/material": "npm:@angular/material.umd.js",
            "@angular/flex-layout": "npm:@angular/flex-layout.umd.js",

            // other libraries
            "rxjs": "npm:rxjs",
            "hammerjs": "npm:hammerjs/hammer.js",

            //lodash
            "lodash": "npm:lodash/lodash.js",
            '@swimlane/ngx-datatable': 'npm:ngx-datatable/ngx-datatable/release/index.js',
            "@angular/platform-browser": "npm:@angular/platform-browser.umd.js",
            "ng2-expansion-panels": "npm:ng2-expansion-panels"
        },
        meta: {
        },
        packages: {
            'cargo': {
                main: "./cargo/*.js",
                defaultExtension: 'js'
            },
            app: {

                main: "./Main.js",
                defaultExtension: "js"
            },

            rxjs: {
                defaultExtension: "js"
            },

            'ng2-expansion-panels': { "main": "dist/ng2-expansion-panels.bundle.js", "defaultExtension": "js" },
            'ngx-accordion': { "main": "index.js", "defaultExtension": "js" }
        }
    });
})(this);

