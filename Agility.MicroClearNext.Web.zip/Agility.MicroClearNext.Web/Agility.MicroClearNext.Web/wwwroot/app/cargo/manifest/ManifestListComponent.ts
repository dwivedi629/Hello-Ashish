﻿import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";

import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { ManifestService } from "./ManifestService";
import { ManifestModel } from "./models/ManifestModel";

@Component({
    moduleId: module.id,
    selector: "manifest-list",
    templateUrl: "ManifestListComponent.html"
})
export class ManifestListComponent implements OnInit {
    serviceDocument: ServiceDocument<ManifestModel>;

    constructor(private service: ManifestService, private route: ActivatedRoute) {
    }

    ngOnInit(): void {
        this.route.data
            .subscribe(() => this.serviceDocument = this.service.serviceDocument);
    }

    open(manifest: ManifestModel): void {
        this.service.open(manifest.manifestId).subscribe();
    }

    new(): void {
        this.service.new().subscribe();
    }
}