﻿import { NgModule } from "@angular/core";

import { FrameworkModule } from "framework/FrameworkModule";
import { ManifestRoutingModule } from "./ManifestRoutingModule";
import { ManifestListComponent } from "./ManifestListComponent";
import { ManifestComponent } from "./ManifestComponent";
import { ManifestService } from "./ManifestService";
import { ManifestListResolver, ManifestNewResolver, ManifestViewResolver, ManifestOpenResolver } from "./ManifestResolver";

@NgModule({
    imports: [
        FrameworkModule,
        ManifestRoutingModule
    ],
    declarations: [
        ManifestListComponent,
        ManifestComponent
    ],
    providers: [
        ManifestService,
        ManifestListResolver,
        ManifestNewResolver,
        ManifestViewResolver,
        ManifestOpenResolver
    ]
})
export class ManifestModule {
}