﻿import { ProfileModel } from "framework/profile/ProfileModel";
import { VMWarehouseOrganizationsModel } from "./vmWarehouseOrganizationsModel";

export class ManifestModel extends ProfileModel {
    manifestId: number;

    journeyId: number;

    agentId: number;

    manifestNumber: string;

    manifestDate: Date;

    manifestfor: string;

    storageLocationId: number;

    //wareHouse: VMWarehouseOrganizationsModel;

    totalNoOfHBs: string;

    manifestSubmittedDate: Date;

    remarks: string;

    manifestType: string;

    storageType: string;

    actualHouseBills: number;

    isSlotAgentManifest: boolean;

    useInTranshipment: string;

    manifestStatus: string;

    assignedTo: number;

    assignedBy: number;

    assignedDate: Date;

    dateOfApproval: Date;
}