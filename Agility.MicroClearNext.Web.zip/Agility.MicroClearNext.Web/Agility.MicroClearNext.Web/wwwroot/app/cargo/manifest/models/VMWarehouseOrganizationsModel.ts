﻿import { ProfileModel } from "framework/profile/ProfileModel";

export class VMWarehouseOrganizationsModel extends ProfileModel {
    organizationName: string;
    registrationTypeId: number;
    description: string;
    name: string;
    typeCode: string;
}