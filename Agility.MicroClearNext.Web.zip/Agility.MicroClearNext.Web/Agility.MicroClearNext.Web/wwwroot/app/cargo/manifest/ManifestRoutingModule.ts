﻿import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";

import { ManifestListComponent } from "./ManifestListComponent";
import { ManifestComponent } from "./ManifestComponent";
import { ManifestListResolver, ManifestOpenResolver, ManifestNewResolver } from "./ManifestResolver";

const ManifestRoutes: Routes = [
    {
        path: "Manifest",
        children: [
            {
                path: "", redirectTo: "List", pathMatch: "full"
            },
            {
                path: "List",
                component: ManifestListComponent,
                resolve:
                {
                    serviceDocument: ManifestListResolver
                }
            },
            {
                path: "Open/:id",
                component: ManifestComponent,
                resolve:
                {
                    serviceDocument: ManifestOpenResolver
                }
            },
            {
                path: "New",
                component: ManifestComponent,
                resolve:
                {
                    serviceDocument: ManifestNewResolver
                }
            }

        ]
    }
];

@NgModule({
    imports: [
        RouterModule.forChild(ManifestRoutes)
    ]
})
export class ManifestRoutingModule { }