﻿import { Injectable } from "@angular/core";
import { Resolve, ActivatedRouteSnapshot } from "@angular/router";

import { Observable } from "rxjs/Observable";

import { ManifestService } from "./ManifestService";
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { ManifestModel } from "./models/ManifestModel";

@Injectable()
export class ManifestListResolver implements Resolve<ServiceDocument<ManifestModel>> {
    constructor(private service: ManifestService) { }

    resolve(route: ActivatedRouteSnapshot): Observable<ServiceDocument<ManifestModel>> {
        return this.service.list();
    }
}

@Injectable()
export class ManifestNewResolver implements Resolve<ServiceDocument<ManifestModel>> {
    constructor(private service: ManifestService) { }

    resolve(): Observable<ServiceDocument<ManifestModel>> {
        return this.service.new();
    }
}

@Injectable()
export class ManifestViewResolver implements Resolve<ServiceDocument<ManifestModel>> {
    constructor(private service: ManifestService) { }

    resolve(route: ActivatedRouteSnapshot): Observable<ServiceDocument<ManifestModel>> {
        return this.service.view(route.params["id"]);
    }
}

@Injectable()
export class ManifestOpenResolver implements Resolve<ServiceDocument<ManifestModel>> {
    constructor(private service: ManifestService) { }

    resolve(route: ActivatedRouteSnapshot): Observable<ServiceDocument<ManifestModel>> {
        return this.service.open(route.params["id"]);
    }
}