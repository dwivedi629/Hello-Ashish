﻿import { Component, OnInit } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";

import { ManifestModel } from "./models/ManifestModel";
import { ManifestService } from "./ManifestService";

@Component({
    moduleId: module.id,
    selector: "manifest",
    templateUrl: "ManifestComponent.html"
})
export class ManifestComponent implements OnInit {
    serviceDocument: ServiceDocument<ManifestModel>;

    constructor(private route: ActivatedRoute, private router: Router, public service: ManifestService) { }

    ngOnInit(): void {
        this.route.data
            .subscribe(() => {
                this.serviceDocument = this.service.serviceDocument;
            });
    }

    submit(): void {
        this.service.submit()
            .subscribe(() => {
                alert("submitted");
                this.router.navigate(["/Manifest"]);
            });
    }

    save() {
        this.service.save().subscribe(() => {
            alert("saved");
        });
    }

    cancel() {
        this.router.navigate(["/Manifest"]);
        return false;
    }
}