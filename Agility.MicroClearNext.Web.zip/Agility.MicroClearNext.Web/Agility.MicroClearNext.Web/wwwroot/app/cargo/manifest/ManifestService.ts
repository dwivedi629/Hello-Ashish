﻿import { Injectable } from "@angular/core";
import { Http, Response, RequestOptions, URLSearchParams } from "@angular/http";
import { Observable } from "rxjs/Observable";

import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { ManifestModel } from "./models/ManifestModel";

@Injectable()
export class ManifestService {
    serviceDocument: ServiceDocument<ManifestModel> = new ServiceDocument<ManifestModel>();

    constructor(private http: Http) { }

    list(): Observable<ServiceDocument<ManifestModel>> {
        return this.serviceDocument.list("/api/Manifest/List");
    }

    new(): Observable<ServiceDocument<ManifestModel>> {
        return this.serviceDocument.new("/api/Manifest/New");
    }

    view(id: number): Observable<ServiceDocument<ManifestModel>> {
        return this.serviceDocument.view("/api/Manifest/View", new URLSearchParams("id=" + id));
    }

    open(id: number): Observable<ServiceDocument<ManifestModel>> {
        return this.serviceDocument.open("/api/Manifest/Open", new URLSearchParams("id=" + id));
    }

    delete(): Observable<ServiceDocument<ManifestModel>> {
        return this.serviceDocument.delete("/api/Manifest/Delete");
    }

    save(): Observable<ServiceDocument<ManifestModel>> {
        return this.serviceDocument.save("/api/Manifest/Save");
    }

    submit(): Observable<ServiceDocument<ManifestModel>> {
        return this.serviceDocument.submit("/api/Manifest/Submit");
    }
}