"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var FrameworkModule_1 = require("framework/FrameworkModule");
var ManifestRoutingModule_1 = require("./ManifestRoutingModule");
var ManifestListComponent_1 = require("./ManifestListComponent");
var ManifestComponent_1 = require("./ManifestComponent");
var ManifestService_1 = require("./ManifestService");
var ManifestResolver_1 = require("./ManifestResolver");
var ManifestModule = (function () {
    function ManifestModule() {
    }
    return ManifestModule;
}());
ManifestModule = __decorate([
    core_1.NgModule({
        imports: [
            FrameworkModule_1.FrameworkModule,
            ManifestRoutingModule_1.ManifestRoutingModule
        ],
        declarations: [
            ManifestListComponent_1.ManifestListComponent,
            ManifestComponent_1.ManifestComponent
        ],
        providers: [
            ManifestService_1.ManifestService,
            ManifestResolver_1.ManifestListResolver,
            ManifestResolver_1.ManifestNewResolver,
            ManifestResolver_1.ManifestViewResolver,
            ManifestResolver_1.ManifestOpenResolver
        ]
    })
], ManifestModule);
exports.ManifestModule = ManifestModule;
//# sourceMappingURL=ManifestModule.js.map