import { Component, OnInit, ViewChild, TemplateRef  } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { JourneyInfo } from '../journeydetails/journeyinfo/journeyinfoaccordion/JourneyInfo';
//import { JourneyService } from '../journeyservice';
import { JourneyInfoService } from "../journeyDetails/journeyInfo/Journeyinfoservice";

@Component({
    moduleId: module.id,
    selector: 'app-journey-list-view',
    templateUrl: './JourneyListViewComponent.html',
    styleUrls: ['./JourneyListViewComponent.css']
})
export class JourneyListViewComponent implements OnInit {
    journeyList: JourneyInfo[];  
    errorMessage: string;
    public serviceDocument: ServiceDocument<JourneyInfo>;

    constructor(public service: JourneyInfoService, private route: ActivatedRoute) { }

    ngOnInit() {
        this.route.data
            .subscribe((res) => {
                this.serviceDocument = this.service.serviceDocument;
                console.log(this.serviceDocument);
            });
        this.journeyList = this.serviceDocument.dataProfile.dataList;
    }
}