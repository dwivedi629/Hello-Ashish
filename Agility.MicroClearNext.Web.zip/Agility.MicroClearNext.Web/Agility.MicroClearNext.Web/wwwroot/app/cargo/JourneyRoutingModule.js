"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var common_1 = require("@angular/common");
var router_1 = require("@angular/router");
var forms_1 = require("@angular/forms");
//import {SharedModule} from '../shared.module';
var JourneyComponent_1 = require("./JourneyComponent");
var CreateJourneyComponent_1 = require("./createJourney/CreateJourneyComponent");
var DashboardComponent_1 = require("./createJourney/dashboard/DashboardComponent");
var journeyListViewComponent_1 = require("./journeyListView/journeyListViewComponent");
var JourneyGridViewComponent_1 = require("./journeyGridView/JourneyGridViewComponent");
var JourneyDetailsComponent_1 = require("./journeyDetails/JourneyDetailsComponent");
var ExistingJourneyComponent_1 = require("./journeyDetails/existingJourney/ExistingJourneyComponent");
var JourneyInfoComponent_1 = require("./journeyDetails/journeyInfo/JourneyInfoComponent");
var JourneyInfoAccordionComponent_1 = require("./journeyDetails/journeyInfo/journeyInfoAccordion/JourneyInfoAccordionComponent");
var ManifestComponent_1 = require("./journeyDetails/manifest/ManifestComponent");
var editManifestDetailsComponent_1 = require("./journeyDetails/manifest/editManifestDetails/editManifestDetailsComponent");
var ManifestListViewComponent_1 = require("./journeyDetails/manifest/manifestListView/ManifestListViewComponent");
var manifestDetailsComponent_1 = require("./journeyDetails/manifest/manifestDetails/manifestDetailsComponent");
var BillOfLadingComponent_1 = require("./journeyDetails/billOfLading/BillOfLadingComponent");
var billOfLadingListViewComponent_1 = require("./journeyDetails/billOfLading/billOfLadingListView/billOfLadingListViewComponent");
var BillOfLadingDetailsComponent_1 = require("./journeyDetails/billOfLading/billOfLadingDetails/BillOfLadingDetailsComponent");
var HbPartyComponent_1 = require("./journeyDetails/billOfLading/hbParty/HbPartyComponent");
var EditBillOfLadingDetailsComponent_1 = require("./journeyDetails/billOfLading/editBillOfLadingDetails/EditBillOfLadingDetailsComponent");
var BillOfLadingLineComponent_1 = require("./journeyDetails/billOfLadingLine/BillOfLadingLineComponent");
var billOfLadingLineListViewComponent_1 = require("./journeyDetails/billOfLadingLine/billOfLadingLineListView/billOfLadingLineListViewComponent");
var BillOfLadingLineDetailsComponent_1 = require("./journeyDetails/billOfLadingLine/billOfLadingLineDetails/BillOfLadingLineDetailsComponent");
var editBillOfLadingLineDetailsComponent_1 = require("./journeyDetails/billOfLadingLine/editBillOfLadingLineDetails/editBillOfLadingLineDetailsComponent");
var BillOfLadingLineContainerInformationComponent_1 = require("./journeyDetails/billOfLadingLine/billOfLadingLineContainerInformation/BillOfLadingLineContainerInformationComponent");
var AddContainerComponent_1 = require("./journeyDetails/billOfLadingLine/billOfLadingLineContainerInformation/addContainer/AddContainerComponent");
var BillOfLadingLineVehicleInformationComponent_1 = require("./journeyDetails/billOfLadingLine/billOfLadingLineVehicleInformation/BillOfLadingLineVehicleInformationComponent");
var AddVehicleComponent_1 = require("./journeyDetails/billOfLadingLine/billOfLadingLineVehicleInformation/addVehicle/AddVehicleComponent");
var DeliveryOrderComponent_1 = require("./journeyDetails/deliveryOrder/DeliveryOrderComponent");
var FrameworkModule_1 = require("framework/FrameworkModule");
var ng2_expansion_panels_1 = require("ng2-expansion-panels");
var cdk_1 = require("@angular/cdk");
var ContainerResolver_1 = require("./journeyDetails/billOfLadingLine/billOfLadingLineContainerInformation/addContainer/ContainerResolver");
var ManifestResolver_1 = require("./journeyDetails/manifest/ManifestResolver");
var billofladingresolver_1 = require("./journeydetails/billoflading/billofladingresolver");
var DeliveryOrderResolver_1 = require("./journeyDetails/deliveryOrder/DeliveryOrderResolver");
var BillOfLadingLineResolver_1 = require("./journeyDetails/billOfLadingLine/BillOfLadingLineResolver");
var JourneyInfoResolver_1 = require("./journeyDetails/journeyInfo/JourneyInfoResolver");
var journeyRoutes = [
    {
        path: '',
        component: JourneyComponent_1.JourneyComponent,
        //data: {
        //  title: 'Journey'
        //},
        children: [
            {
                path: 'create',
                component: CreateJourneyComponent_1.CreateJourneyComponent,
                data: {
                    title: 'New Journey'
                },
                children: [
                    {
                        path: 'dashboard',
                        component: DashboardComponent_1.CreateDashboardComponent,
                        data: {
                            title: 'New Journey'
                        }
                    },
                    {
                        path: 'journey-info-form',
                        component: JourneyInfoAccordionComponent_1.JourneyInfoAccordionComponent,
                        data: {
                            title: 'New Journey',
                            stepCount: 1
                        },
                        resolve: {
                            serviceDocument: JourneyInfoResolver_1.JourneyInfoNewResolver
                        }
                    },
                    {
                        path: 'edit-manifest-details',
                        component: editManifestDetailsComponent_1.EditManifestDetailsComponent,
                        data: {
                            title: 'New Journey',
                            stepCount: 2
                        },
                        resolve: {
                            serviceDocument: ManifestResolver_1.ManifestNewResolver
                        }
                    },
                    {
                        path: 'edit-bill-of-lading-details',
                        component: EditBillOfLadingDetailsComponent_1.EditBillOfLadingDetailsComponent,
                        data: {
                            title: 'New Journey',
                            stepCount: 3
                        }
                    },
                    {
                        path: 'edit-bill-of-lading-details',
                        component: EditBillOfLadingDetailsComponent_1.EditBillOfLadingDetailsComponent,
                        resolve: {
                            serviceDocument: billofladingresolver_1.HouseBillNewResolver
                        },
                        data: {
                            title: 'New Journey',
                            stepCount: 3
                        }
                    },
                    {
                        path: 'hb-party',
                        component: HbPartyComponent_1.HBPartyComponent,
                        data: {
                            title: 'New Journey',
                            stepCount: 4
                        }
                    },
                    {
                        path: 'edit-bill-of-lading-line-details',
                        component: editBillOfLadingLineDetailsComponent_1.EditBillOfLadingLineDetailsComponent,
                        resolve: {
                            serviceDocument: BillOfLadingLineResolver_1.HBItemlNewResolver
                        },
                        data: {
                            title: 'New Journey',
                            stepCount: 5
                        }
                    },
                    {
                        path: 'add-container',
                        component: AddContainerComponent_1.AddContainerComponent,
                        data: {
                            title: 'New Journey',
                            stepCount: 6
                        }
                    },
                    {
                        path: 'add-vehicle',
                        component: AddVehicleComponent_1.AddVehicleComponent,
                        data: {
                            title: 'New Journey',
                            stepCount: 7
                        }
                    },
                    {
                        path: 'delivery-order',
                        component: DeliveryOrderComponent_1.DeliveryOrderComponent,
                        data: {
                            title: 'New Journey',
                            stepCount: 8
                        },
                        resolve: {
                            serviceDocument: DeliveryOrderResolver_1.DeliveryOrderNewResolver
                        }
                    },
                    {
                        path: '',
                        redirectTo: 'dashboard',
                        pathMatch: 'full'
                    },
                    {
                        path: '**',
                        redirectTo: 'dashboard',
                        pathMatch: 'full'
                    }
                ]
            },
            {
                path: 'journey-grid-view',
                component: JourneyGridViewComponent_1.JourneyGridViewComponent,
                data: {
                    title: 'Journey'
                },
                resolve: {
                    serviceDocument: JourneyInfoResolver_1.JourneyInfoListResolver
                }
            },
            {
                path: 'journey-list-view',
                component: journeyListViewComponent_1.JourneyListViewComponent,
                data: {
                    title: 'Journey'
                },
                resolve: {
                    serviceDocument: JourneyInfoResolver_1.JourneyInfoListResolver
                }
            },
            {
                path: 'journey-details/:id',
                component: JourneyDetailsComponent_1.JourneyDetailsComponent,
                data: {
                    title: 'Journey Details'
                },
                resolve: {
                    serviceDocument: JourneyInfoResolver_1.JourneyInfoOpenResolver
                },
                children: [
                    {
                        path: 'existing-journey',
                        component: ExistingJourneyComponent_1.ExistingJourneyComponent,
                        data: {
                            title: 'Journey Details'
                        }
                    },
                    {
                        path: 'journey-info',
                        component: JourneyInfoComponent_1.JourneyInfoComponent,
                        data: {
                            title: 'Journey Details',
                            stepCount: 1
                        }
                    },
                    {
                        path: 'journey-info-accordion',
                        component: JourneyInfoAccordionComponent_1.JourneyInfoAccordionComponent,
                        data: {
                            title: 'Journey Details',
                            stepCount: 1
                        },
                        resolve: {
                            serviceDocument: JourneyInfoResolver_1.JourneyInfoOpenResolver
                        },
                    },
                    {
                        path: 'manifest',
                        component: ManifestComponent_1.ManifestComponent,
                        data: {
                            title: 'Journey Details',
                            stepCount: 2
                        },
                        children: [
                            {
                                path: 'manifest-list-view',
                                component: ManifestListViewComponent_1.ManifestListViewComponent,
                                //data: {
                                //    title: 'Journey Details'
                                //},
                                resolve: {
                                    serviceDocument: ManifestResolver_1.ManifestListResolver
                                }
                            },
                            {
                                path: 'manifest-details/:id',
                                component: manifestDetailsComponent_1.ManifestDetailsComponent,
                                data: {
                                    title: 'Journey Details'
                                },
                                resolve: {
                                    serviceDocument: ManifestResolver_1.ManifestOpenResolver
                                }
                                //ManifestOpenResolver  ManifestViewResolver
                            },
                            {
                                path: 'edit-manifest-details',
                                component: editManifestDetailsComponent_1.EditManifestDetailsComponent,
                                data: {
                                    title: 'Journey Details',
                                    stepCount: 2
                                },
                            },
                            {
                                path: '',
                                redirectTo: 'manifest-list-view',
                                pathMatch: 'full',
                            },
                            {
                                path: '**',
                                redirectTo: 'manifest-list-view',
                                pathMatch: 'full',
                            }
                        ]
                    },
                    {
                        path: 'bill-of-lading',
                        component: BillOfLadingComponent_1.BillOfLadingComponent,
                        data: {
                            title: 'Journey Details',
                            stepCount: 3
                        },
                        children: [
                            {
                                path: 'bill-of-lading-list-view',
                                component: billOfLadingListViewComponent_1.BillOfLadingListViewComponent,
                                data: {
                                    title: 'Journey Details'
                                },
                                resolve: {
                                    serviceDocument: billofladingresolver_1.HouseBillListResolver
                                },
                            },
                            {
                                path: 'bill-of-lading-details/:id',
                                component: BillOfLadingDetailsComponent_1.BillOfLadingDetailsComponent,
                                data: {
                                    title: 'Journey Details'
                                },
                                resolve: {
                                    serviceDocument: billofladingresolver_1.HouseBilOpenResolver
                                },
                            },
                            {
                                path: 'edit-bill-of-lading-details',
                                component: EditBillOfLadingDetailsComponent_1.EditBillOfLadingDetailsComponent,
                                data: {
                                    title: 'Journey Details',
                                    stepCount: 3
                                }
                            },
                            {
                                path: 'hb-party',
                                component: HbPartyComponent_1.HBPartyComponent,
                                data: {
                                    title: 'Journey Details',
                                    stepCount: 4
                                }
                            },
                            {
                                path: '',
                                redirectTo: 'bill-of-lading-list-view',
                                pathMatch: 'full'
                            },
                            {
                                path: '**',
                                redirectTo: 'bill-of-lading-list-view',
                                pathMatch: 'full'
                            }
                        ]
                    },
                    {
                        path: 'bill-of-lading-line',
                        component: BillOfLadingLineComponent_1.BillOfLadingLineComponent,
                        data: {
                            title: 'Journey Details',
                            stepCount: 5
                        },
                        children: [
                            {
                                path: 'bill-of-lading-line-list-view',
                                component: billOfLadingLineListViewComponent_1.BillOfLadingLineListViewComponent,
                                resolve: {
                                    serviceDocument: BillOfLadingLineResolver_1.HBItemListResolver
                                },
                                data: {
                                    title: 'Journey Details'
                                }
                            },
                            {
                                path: 'bill-of-lading-line-details/:id',
                                component: BillOfLadingLineDetailsComponent_1.BillOfLadingLineDetailsComponent,
                                resolve: {
                                    serviceDocument: BillOfLadingLineResolver_1.HBItemOpenResolver
                                },
                                data: {
                                    title: 'Journey Details'
                                }
                            },
                            {
                                path: 'edit-bill-of-lading-line-details/:id',
                                component: editBillOfLadingLineDetailsComponent_1.EditBillOfLadingLineDetailsComponent,
                                resolve: {
                                    serviceDocument: BillOfLadingLineResolver_1.HBItemOpenResolver
                                },
                                data: {
                                    title: 'Journey Details',
                                    stepCount: 5
                                }
                            },
                            {
                                path: 'bill-of-lading-line-container-information',
                                component: BillOfLadingLineContainerInformationComponent_1.BillOfLadingLineContainerInformationComponent,
                                data: {
                                    title: 'Journey Details',
                                    stepCount: 6
                                },
                                resolve: {
                                    serviceDocument: ContainerResolver_1.IContainerListResolver
                                }
                            },
                            {
                                path: 'add-container',
                                component: AddContainerComponent_1.AddContainerComponent,
                                data: {
                                    title: 'Journey Details',
                                    stepCount: 6
                                },
                                resolve: {
                                    serviceDocument: ContainerResolver_1.IContainerNewResolver
                                }
                            },
                            {
                                path: 'add-container/:id',
                                component: AddContainerComponent_1.AddContainerComponent,
                                data: {
                                    title: 'Journey Details',
                                    stepCount: 6
                                },
                                resolve: {
                                    serviceDocument: ContainerResolver_1.IContainerOpenResolver
                                }
                            },
                            {
                                path: 'list-container',
                                component: BillOfLadingLineContainerInformationComponent_1.BillOfLadingLineContainerInformationComponent,
                                data: {
                                    title: 'Journey Details',
                                    stepCount: 7
                                },
                                resolve: {
                                    serviceDocument: ContainerResolver_1.IContainerListResolver
                                }
                            },
                            {
                                path: 'bill-of-lading-line-vehicle-information',
                                component: BillOfLadingLineVehicleInformationComponent_1.BillOfLadingLineVehicleInformationComponent,
                                data: {
                                    title: 'Journey Details',
                                    stepCount: 8
                                }
                            },
                            {
                                path: 'add-vehicle',
                                component: AddVehicleComponent_1.AddVehicleComponent,
                                data: {
                                    title: 'Journey Details',
                                    stepCount: 9
                                }
                            },
                            {
                                path: '',
                                redirectTo: 'bill-of-lading-line-list-view',
                                pathMatch: 'full'
                            },
                            {
                                path: '**',
                                redirectTo: 'bill-of-lading-line-list-view',
                                pathMatch: 'full'
                            }
                        ]
                    },
                    {
                        path: 'delivery-order',
                        component: DeliveryOrderComponent_1.DeliveryOrderComponent,
                        data: {
                            title: 'Journey Details',
                            stepCount: 8
                        },
                        resolve: {
                            serviceDocument: DeliveryOrderResolver_1.DeliveryOrderOpenResolver
                        },
                    },
                    {
                        path: '',
                        redirectTo: 'existing-journey',
                        pathMatch: 'full'
                    },
                    {
                        path: '**',
                        redirectTo: 'existing-journey',
                        pathMatch: 'full'
                    }
                ]
            },
            {
                path: '',
                redirectTo: 'journey-grid-view',
                pathMatch: 'full'
            },
            {
                path: '**',
                redirectTo: 'journey-grid-view',
                pathMatch: 'full'
            }
        ]
    }
];
var JourneyRoutingModule = (function () {
    function JourneyRoutingModule() {
    }
    return JourneyRoutingModule;
}());
JourneyRoutingModule = __decorate([
    core_1.NgModule({
        declarations: [
            JourneyComponent_1.JourneyComponent,
            CreateJourneyComponent_1.CreateJourneyComponent,
            DashboardComponent_1.CreateDashboardComponent,
            journeyListViewComponent_1.JourneyListViewComponent,
            JourneyGridViewComponent_1.JourneyGridViewComponent,
            JourneyDetailsComponent_1.JourneyDetailsComponent,
            ExistingJourneyComponent_1.ExistingJourneyComponent,
            JourneyInfoComponent_1.JourneyInfoComponent,
            JourneyInfoAccordionComponent_1.JourneyInfoAccordionComponent,
            ManifestComponent_1.ManifestComponent,
            ManifestListViewComponent_1.ManifestListViewComponent,
            manifestDetailsComponent_1.ManifestDetailsComponent,
            editManifestDetailsComponent_1.EditManifestDetailsComponent,
            BillOfLadingComponent_1.BillOfLadingComponent,
            billOfLadingListViewComponent_1.BillOfLadingListViewComponent,
            BillOfLadingDetailsComponent_1.BillOfLadingDetailsComponent,
            HbPartyComponent_1.HBPartyComponent,
            EditBillOfLadingDetailsComponent_1.EditBillOfLadingDetailsComponent,
            BillOfLadingLineComponent_1.BillOfLadingLineComponent,
            billOfLadingLineListViewComponent_1.BillOfLadingLineListViewComponent,
            BillOfLadingLineDetailsComponent_1.BillOfLadingLineDetailsComponent,
            editBillOfLadingLineDetailsComponent_1.EditBillOfLadingLineDetailsComponent,
            BillOfLadingLineContainerInformationComponent_1.BillOfLadingLineContainerInformationComponent,
            AddContainerComponent_1.AddContainerComponent,
            BillOfLadingLineVehicleInformationComponent_1.BillOfLadingLineVehicleInformationComponent,
            AddVehicleComponent_1.AddVehicleComponent,
            DeliveryOrderComponent_1.DeliveryOrderComponent
        ],
        imports: [
            common_1.CommonModule,
            forms_1.FormsModule,
            FrameworkModule_1.FrameworkModule,
            forms_1.ReactiveFormsModule,
            cdk_1.CdkTableModule,
            // SharedModule,
            ng2_expansion_panels_1.ExpansionPanelsModule,
            router_1.RouterModule.forChild(journeyRoutes)
        ],
        exports: [
            router_1.RouterModule,
            // SharedModule,
            JourneyComponent_1.JourneyComponent,
            FrameworkModule_1.FrameworkModule,
            ng2_expansion_panels_1.ExpansionPanelsModule,
            cdk_1.CdkTableModule
        ]
    })
], JourneyRoutingModule);
exports.JourneyRoutingModule = JourneyRoutingModule;
//# sourceMappingURL=JourneyRoutingModule.js.map