import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
//import {SharedModule} from '../shared.module';
import { JourneyComponent } from './JourneyComponent';
import { CreateJourneyComponent } from './createJourney/CreateJourneyComponent';
import { CreateDashboardComponent } from './createJourney/dashboard/DashboardComponent';
import { JourneyListViewComponent } from './journeyListView/journeyListViewComponent';
import { JourneyGridViewComponent } from './journeyGridView/JourneyGridViewComponent';
import { JourneyDetailsComponent } from './journeyDetails/JourneyDetailsComponent';
import { ExistingJourneyComponent } from './journeyDetails/existingJourney/ExistingJourneyComponent';
import { JourneyInfoComponent } from './journeyDetails/journeyInfo/JourneyInfoComponent';
import { JourneyInfoAccordionComponent } from './journeyDetails/journeyInfo/journeyInfoAccordion/JourneyInfoAccordionComponent';
import { ManifestComponent } from './journeyDetails/manifest/ManifestComponent';
import { EditManifestDetailsComponent } from './journeyDetails/manifest/editManifestDetails/editManifestDetailsComponent';
import { ManifestListViewComponent } from './journeyDetails/manifest/manifestListView/ManifestListViewComponent';
import { ManifestDetailsComponent } from './journeyDetails/manifest/manifestDetails/manifestDetailsComponent';
import { BillOfLadingComponent } from './journeyDetails/billOfLading/BillOfLadingComponent';
import { BillOfLadingListViewComponent } from './journeyDetails/billOfLading/billOfLadingListView/billOfLadingListViewComponent';
import { BillOfLadingDetailsComponent } from './journeyDetails/billOfLading/billOfLadingDetails/BillOfLadingDetailsComponent';
import { HBPartyComponent } from './journeyDetails/billOfLading/hbParty/HbPartyComponent';
import { EditBillOfLadingDetailsComponent } from './journeyDetails/billOfLading/editBillOfLadingDetails/EditBillOfLadingDetailsComponent';
import { BillOfLadingLineComponent } from './journeyDetails/billOfLadingLine/BillOfLadingLineComponent';
import { BillOfLadingLineListViewComponent } from './journeyDetails/billOfLadingLine/billOfLadingLineListView/billOfLadingLineListViewComponent';
import { BillOfLadingLineDetailsComponent } from './journeyDetails/billOfLadingLine/billOfLadingLineDetails/BillOfLadingLineDetailsComponent';
import { EditBillOfLadingLineDetailsComponent } from './journeyDetails/billOfLadingLine/editBillOfLadingLineDetails/editBillOfLadingLineDetailsComponent';
import { BillOfLadingLineContainerInformationComponent } from './journeyDetails/billOfLadingLine/billOfLadingLineContainerInformation/BillOfLadingLineContainerInformationComponent';
import { AddContainerComponent } from './journeyDetails/billOfLadingLine/billOfLadingLineContainerInformation/addContainer/AddContainerComponent';
import { BillOfLadingLineVehicleInformationComponent } from './journeyDetails/billOfLadingLine/billOfLadingLineVehicleInformation/BillOfLadingLineVehicleInformationComponent';
import { AddVehicleComponent } from './journeyDetails/billOfLadingLine/billOfLadingLineVehicleInformation/addVehicle/AddVehicleComponent';
import { DeliveryOrderComponent } from './journeyDetails/deliveryOrder/DeliveryOrderComponent';
import { FrameworkModule } from "framework/FrameworkModule";
import { ExpansionPanelsModule } from "ng2-expansion-panels";
import { CdkTableModule } from '@angular/cdk';
import { IContainerListResolver, IContainerNewResolver, IContainerOpenResolver } from './journeyDetails/billOfLadingLine/billOfLadingLineContainerInformation/addContainer/ContainerResolver';
import { ManifestListResolver, ManifestNewResolver, ManifestOpenResolver, ManifestViewResolver } from "./journeyDetails/manifest/ManifestResolver";
import { HouseBillListResolver, HouseBilOpenResolver, HouseBillNewResolver } from './journeydetails/billoflading/billofladingresolver';
import { DeliveryOrderListResolver, DeliveryOrderNewResolver, DeliveryOrderViewResolver, DeliveryOrderOpenResolver } from "./journeyDetails/deliveryOrder/DeliveryOrderResolver";
import { HBItemListResolver, HBItemlNewResolver, HBItemOpenResolver } from "./journeyDetails/billOfLadingLine/BillOfLadingLineResolver";
import { JourneyInfoListResolver, JourneyInfoNewResolver, JourneyInfoOpenResolver } from "./journeyDetails/journeyInfo/JourneyInfoResolver";
const journeyRoutes: Routes = [
    {
        path: '',
        component: JourneyComponent,
        //data: {
        //  title: 'Journey'
        //},
        children: [
            {
                path: 'create',
                component: CreateJourneyComponent,
                data: {
                    title: 'New Journey'
                },
                children: [
                    {
                        path: 'dashboard',
                        component: CreateDashboardComponent,
                        data: {
                            title: 'New Journey'
                        }
                    },
                    {
                        path: 'journey-info-form',
                        component: JourneyInfoAccordionComponent,
                        data: {
                            title: 'New Journey',
                            stepCount: 1
                        
                    },
                    resolve:
                    {
                        serviceDocument: JourneyInfoNewResolver
                    }
                    },
                    {
                        path: 'edit-manifest-details',
                        component: EditManifestDetailsComponent,
                        data: {
                            title: 'New Journey',
                            stepCount: 2
                        },
                        resolve: {
                            serviceDocument: ManifestNewResolver
                        }
                    },
                    {
                        path: 'edit-bill-of-lading-details',
                        component: EditBillOfLadingDetailsComponent,
                        data: {
                            title: 'New Journey',
                            stepCount: 3
                        }
                    },
                    {
                        path: 'edit-bill-of-lading-details',
                        component: EditBillOfLadingDetailsComponent,
                        resolve:
                        {
                            serviceDocument: HouseBillNewResolver
                        },
                        data: {
                            title: 'New Journey',
                            stepCount: 3
                        }
                    },
                    {
                        path: 'hb-party',
                        component: HBPartyComponent,
                        
                        data: {
                            title: 'New Journey',
                            stepCount: 4
                        }
                       
                    },
                    {
                        path: 'edit-bill-of-lading-line-details',
                        component: EditBillOfLadingLineDetailsComponent,
                        resolve:
                        {
                            serviceDocument: HBItemlNewResolver
                        },
                        data: {
                            title: 'New Journey',
                            stepCount: 5
                        }
                    },
                    {
                        path: 'add-container',
                        component: AddContainerComponent,
                        data: {
                            title: 'New Journey',
                            stepCount: 6
                        }

                    },
                    {
                        path: 'add-vehicle',
                        component: AddVehicleComponent,
                        data: {
                            title: 'New Journey',
                            stepCount: 7
                        }
                    },
                    {
                        path: 'delivery-order',
                        component: DeliveryOrderComponent,
                        data: {
                            title: 'New Journey',
                            stepCount: 8
                        },
                        resolve: {
                            serviceDocument: DeliveryOrderNewResolver
                        }
                    },
                    {
                        path: '',
                        redirectTo: 'dashboard',
                        pathMatch: 'full'
                    },
                    {
                        path: '**',
                        redirectTo: 'dashboard',
                        pathMatch: 'full'
                    }
                ]
            },
            {
                path: 'journey-grid-view',
                component: JourneyGridViewComponent,
                data: {
                    title: 'Journey'
                },
                resolve:
                {
                    serviceDocument: JourneyInfoListResolver
                }
            },
            {
                path: 'journey-list-view',
                component: JourneyListViewComponent,
                data: {
                    title: 'Journey'
                },
                resolve:
                {
                    serviceDocument: JourneyInfoListResolver
                }
            },
            {
                path: 'journey-details/:id',
                component: JourneyDetailsComponent,
                data: {
                    title: 'Journey Details'
                },
                resolve:
                {
                    serviceDocument: JourneyInfoOpenResolver
                },
                children: [
                    {
                        path: 'existing-journey',
                        component: ExistingJourneyComponent,
                        data: {
                            title: 'Journey Details'
                        }
                    },
                    {
                        path: 'journey-info',
                        component: JourneyInfoComponent,
                        data: {
                            title: 'Journey Details',
                            stepCount: 1
                        }
                    },
                    {
                        path: 'journey-info-accordion',
                        component: JourneyInfoAccordionComponent,
                        data: {
                            title: 'Journey Details',
                            stepCount: 1
                        },
                        resolve:
                        {
                            serviceDocument: JourneyInfoOpenResolver
                        },
                    },
                    {
                        path: 'manifest',
                        component: ManifestComponent,
                        data: {
                            title: 'Journey Details',
                            stepCount: 2
                        },
                        children: [
                            {
                                path: 'manifest-list-view',
                                component: ManifestListViewComponent,
                                //data: {
                                //    title: 'Journey Details'
                                //},
                                resolve: {
                                    serviceDocument: ManifestListResolver
                                }
                            },
                            {
                                path: 'manifest-details/:id',
                                component: ManifestDetailsComponent,
                                data: {
                                    title: 'Journey Details'
                                }, 
                                resolve: {
                                    serviceDocument: ManifestOpenResolver
                                }
                                //ManifestOpenResolver  ManifestViewResolver
                                
                            },
                            {
                                path: 'edit-manifest-details',
                                component: EditManifestDetailsComponent,
                                data: {
                                    title: 'Journey Details',
                                    stepCount: 2
                                },
                            },
                            {
                                path: '',
                                redirectTo: 'manifest-list-view',
                                pathMatch: 'full',
                                //resolve: {
                                //    serviceDocument: ManifestListResolver
                                //}
                                
                            },

                            {
                                path: '**',
                                redirectTo: 'manifest-list-view',
                                pathMatch: 'full',
                                //resolve: {
                                //    serviceDocument: ManifestListResolver
                                //}
                            }
                        ]
                    },
                    {
                        path: 'bill-of-lading',
                        component: BillOfLadingComponent,
                        data: {
                            title: 'Journey Details',
                            stepCount: 3
                        },
                        children: [
                            {
                                path: 'bill-of-lading-list-view',
                                component: BillOfLadingListViewComponent,
                                data: {
                                    title: 'Journey Details'
                                },
                                resolve:
                                {
                                    serviceDocument: HouseBillListResolver
                                },
                            },
                            {
                                path: 'bill-of-lading-details/:id',
                                component: BillOfLadingDetailsComponent,
                                data: {
                                    title: 'Journey Details'
                                },
                                 resolve:
                                {
                                    serviceDocument: HouseBilOpenResolver
                                },
                            },
                            {
                                path: 'edit-bill-of-lading-details',
                                component: EditBillOfLadingDetailsComponent,
                                data: {
                                    title: 'Journey Details',
                                    stepCount: 3
                                }
                            },
                            {
                                path: 'hb-party',
                                component: HBPartyComponent,
                                data: {
                                    title: 'Journey Details',
                                    stepCount: 4
                                }
                            },
                            {
                                path: '',
                                redirectTo: 'bill-of-lading-list-view',
                                pathMatch: 'full'
                            },
                            {
                                path: '**',
                                redirectTo: 'bill-of-lading-list-view',
                                pathMatch: 'full'
                            }
                        ]
                    },
                    {
                        path: 'bill-of-lading-line',
                        component: BillOfLadingLineComponent,
                        data: {
                            title: 'Journey Details',
                            stepCount: 5
                        },
                        children: [
                            {
                                path: 'bill-of-lading-line-list-view',
                                component: BillOfLadingLineListViewComponent,
                                resolve:
                                {
                                    serviceDocument: HBItemListResolver
                                },
                                data: {
                                    title: 'Journey Details'
                                }
                            },
                            {
                                path: 'bill-of-lading-line-details/:id',
                                component: BillOfLadingLineDetailsComponent,
                                resolve:
                                {
                                    serviceDocument: HBItemOpenResolver
                                },
                                data: {
                                    title: 'Journey Details'
                                }
                            },
                            {
                                path: 'edit-bill-of-lading-line-details/:id',
                                component: EditBillOfLadingLineDetailsComponent,
                                resolve:
                                {
                                    serviceDocument: HBItemOpenResolver
                                },
                                data: {
                                    title: 'Journey Details',
                                    stepCount: 5
                                }
                            },
                            {
                                path: 'bill-of-lading-line-container-information',
                                component: BillOfLadingLineContainerInformationComponent,
                                data: {
                                    title: 'Journey Details',
                                    stepCount: 6
                                },
                                resolve:
                                {
                                    serviceDocument: IContainerListResolver
                                }
                            },
                            {
                                path: 'add-container',
                                component: AddContainerComponent,
                                data: {
                                    title: 'Journey Details',
                                    stepCount: 6

                                },
                                resolve:
                                {
                                    serviceDocument: IContainerNewResolver
                                }


                            },
                            {
                                path: 'add-container/:id',
                                component: AddContainerComponent,
                                data: {
                                    title: 'Journey Details',
                                    stepCount: 6

                                },
                                resolve:
                                {
                                    serviceDocument: IContainerOpenResolver
                                }


                            },
                            {
                                path: 'list-container',
                                component: BillOfLadingLineContainerInformationComponent,
                                data: {
                                    title: 'Journey Details',
                                    stepCount: 7

                                },
                                resolve:
                                {
                                    serviceDocument: IContainerListResolver
                                }


                            },
                            {
                                path: 'bill-of-lading-line-vehicle-information',
                                component: BillOfLadingLineVehicleInformationComponent,
                                data: {
                                    title: 'Journey Details',
                                    stepCount: 8
                                }
                            },
                            {
                                path: 'add-vehicle',
                                component: AddVehicleComponent,
                                data: {
                                    title: 'Journey Details',
                                    stepCount: 9
                                }
                            },
                            {
                                path: '',
                                redirectTo: 'bill-of-lading-line-list-view',
                                pathMatch: 'full'
                            },
                            {
                                path: '**',
                                redirectTo: 'bill-of-lading-line-list-view',
                                pathMatch: 'full'
                            }
                        ]
                    },
                    {
                        path: 'delivery-order',
                        component: DeliveryOrderComponent,
                        data: {
                            title: 'Journey Details',
                            stepCount: 8
                        },
                        resolve:
                        {
                            serviceDocument: DeliveryOrderOpenResolver
                        },

                    },
                    {
                        path: '',
                        redirectTo: 'existing-journey',
                        pathMatch: 'full'
                    },
                    {
                        path: '**',
                        redirectTo: 'existing-journey',
                        pathMatch: 'full'
                    }]
            },
            {
                path: '',
                redirectTo: 'journey-grid-view',
                pathMatch: 'full'
            },
            {
                path: '**',
                redirectTo: 'journey-grid-view',
                pathMatch: 'full'
            }
        ]
    }
];

@NgModule({
    declarations: [
        JourneyComponent,
        CreateJourneyComponent,
        CreateDashboardComponent,
        JourneyListViewComponent,
        JourneyGridViewComponent,
        JourneyDetailsComponent,
        ExistingJourneyComponent,
        JourneyInfoComponent,
        JourneyInfoAccordionComponent,
        ManifestComponent,
        ManifestListViewComponent,
        ManifestDetailsComponent,
        EditManifestDetailsComponent,
        BillOfLadingComponent,
        BillOfLadingListViewComponent,
        BillOfLadingDetailsComponent,
        HBPartyComponent,
        EditBillOfLadingDetailsComponent,
        BillOfLadingLineComponent,
        BillOfLadingLineListViewComponent,
        BillOfLadingLineDetailsComponent,
        EditBillOfLadingLineDetailsComponent,
        BillOfLadingLineContainerInformationComponent,
        AddContainerComponent,
        BillOfLadingLineVehicleInformationComponent,
        AddVehicleComponent,
        DeliveryOrderComponent
    ],
    imports: [
        CommonModule,
        FormsModule,
        FrameworkModule,
        ReactiveFormsModule,
        CdkTableModule,
        // SharedModule,

        ExpansionPanelsModule,
        RouterModule.forChild(
            journeyRoutes
        )

    ],
    exports: [
        RouterModule,
        // SharedModule,
        JourneyComponent,
        FrameworkModule,
        ExpansionPanelsModule,
        CdkTableModule
    ]
})
export class JourneyRoutingModule {
}
