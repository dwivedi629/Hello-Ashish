﻿import { Component, OnInit } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";

import { JourneyModel } from "./models/JourneyModel";
import { JourneyService } from "./JourneyService";
import { ManifestModel } from "../manifest/models/ManifestModel";

@Component({
    moduleId: module.id,
    selector: "Journey",
    templateUrl: "JourneyComponent.html"
})
export class JourneyComponent implements OnInit {
    serviceDocument: ServiceDocument<JourneyModel>;
    manifestModel: ManifestModel = new ManifestModel();
    journeyModel: JourneyModel = new JourneyModel();
    optionsData = [
        { "key": "Male", "value": "Male" }, { "key": "Female", "value": "Female" }
    ]

    constructor(private route: ActivatedRoute, private router: Router, public service: JourneyService) { }

    ngOnInit(): void {
        this.route.data
            .subscribe(() => {
                //this.service.serviceDocument.dataProfile.dataModel.gender = this.optionsData;
                this.serviceDocument = this.service.serviceDocument;
            });
    }

    submit(): void {
        this.service.submit()
            .subscribe(() => {
                alert("submitted");
                this.router.navigate(["/Journey"]);
            });
    }

    save() {
        this.service.save().subscribe(() => {
            alert("saved");
        });
    }

    cancel() {
        this.router.navigate(["/Journey"]);
        return false;
    }

    addSubProfile()
    {
        this.manifestModel.journeyId = this.serviceDocument.dataProfile.dataModel.journeyId;
        this.manifestModel.manifestNumber = 'M1';
        if (this.serviceDocument.dataProfile.dataModel.manifestList == null) {
            this.serviceDocument.dataProfile.dataModel.manifestList = new Array<ManifestModel>();
        }
        this.serviceDocument.dataProfile.dataModel.manifestList.push(this.manifestModel);

        return false;
    }

    newModel()
    {
        this.journeyModel.journeyNumber = "";
        this.journeyModel.vesselName = "";
        this.journeyModel.lastPortOfCallId = null;
        this.journeyModel.countryId = null;
        this.serviceDocument = this.service.serviceDocument.newModel(this.journeyModel);
        return false;
    }

    changeCountry(event: any): void {
    }

    temp1(event: any): void {

    }
}