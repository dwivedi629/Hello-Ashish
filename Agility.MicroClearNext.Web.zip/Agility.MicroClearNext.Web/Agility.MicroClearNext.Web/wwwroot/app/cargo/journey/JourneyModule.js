"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var FrameworkModule_1 = require("framework/FrameworkModule");
var journeyroutingmodule_1 = require("./journeyroutingmodule");
var JourneyListComponent_1 = require("./JourneyListComponent");
var JourneyComponent_1 = require("./JourneyComponent");
var JourneyService_1 = require("./JourneyService");
var JourneyResolver_1 = require("./JourneyResolver");
var JourneyModule = (function () {
    function JourneyModule() {
    }
    return JourneyModule;
}());
JourneyModule = __decorate([
    core_1.NgModule({
        imports: [
            FrameworkModule_1.FrameworkModule,
            journeyroutingmodule_1.JourneyRoutingModule
        ],
        declarations: [
            JourneyListComponent_1.JourneyListComponent,
            JourneyComponent_1.JourneyComponent
        ],
        providers: [
            JourneyService_1.JourneyService,
            JourneyResolver_1.JourneyListResolver,
            JourneyResolver_1.JourneyNewResolver,
            JourneyResolver_1.JourneyViewResolver,
            JourneyResolver_1.JourneyOpenResolver
        ]
    })
], JourneyModule);
exports.JourneyModule = JourneyModule;
//# sourceMappingURL=JourneyModule.js.map