"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var JourneyService_1 = require("./JourneyService");
var JourneyListResolver = (function () {
    function JourneyListResolver(service) {
        this.service = service;
    }
    JourneyListResolver.prototype.resolve = function (route) {
        return this.service.list();
    };
    return JourneyListResolver;
}());
JourneyListResolver = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [JourneyService_1.JourneyService])
], JourneyListResolver);
exports.JourneyListResolver = JourneyListResolver;
var JourneyNewResolver = (function () {
    function JourneyNewResolver(service) {
        this.service = service;
    }
    JourneyNewResolver.prototype.resolve = function () {
        return this.service.new();
    };
    return JourneyNewResolver;
}());
JourneyNewResolver = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [JourneyService_1.JourneyService])
], JourneyNewResolver);
exports.JourneyNewResolver = JourneyNewResolver;
var JourneyViewResolver = (function () {
    function JourneyViewResolver(service) {
        this.service = service;
    }
    JourneyViewResolver.prototype.resolve = function (route) {
        return this.service.view(route.params["id"]);
    };
    return JourneyViewResolver;
}());
JourneyViewResolver = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [JourneyService_1.JourneyService])
], JourneyViewResolver);
exports.JourneyViewResolver = JourneyViewResolver;
var JourneyOpenResolver = (function () {
    function JourneyOpenResolver(service) {
        this.service = service;
    }
    JourneyOpenResolver.prototype.resolve = function (route) {
        return this.service.open(route.params["id"]);
    };
    return JourneyOpenResolver;
}());
JourneyOpenResolver = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [JourneyService_1.JourneyService])
], JourneyOpenResolver);
exports.JourneyOpenResolver = JourneyOpenResolver;
//# sourceMappingURL=JourneyResolver.js.map