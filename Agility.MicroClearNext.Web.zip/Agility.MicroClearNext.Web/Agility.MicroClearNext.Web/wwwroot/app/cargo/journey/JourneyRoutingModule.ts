﻿import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";

import { JourneyListComponent } from "./JourneyListComponent";
import { JourneyComponent } from "./JourneyComponent";
import { JourneyListResolver, JourneyOpenResolver, JourneyNewResolver } from "./JourneyResolver";

const JourneyRoutes: Routes = [
    {
        path: "Journey",
        children: [
            {
                path: "", redirectTo: "List", pathMatch: "full"
            },
            {
                path: "List",
                component: JourneyListComponent,
                resolve:
                {
                    serviceDocument: JourneyListResolver
                }
            },
            {
                path: "Open/:id",
                component: JourneyComponent,
                resolve:
                {
                    serviceDocument: JourneyOpenResolver
                }
            },
            {
                path: "New",
                component: JourneyComponent,
                resolve:
                {
                    serviceDocument: JourneyNewResolver
                }
            }

        ]
    }
];

@NgModule({
    imports: [
        RouterModule.forChild(JourneyRoutes)
    ]
})
export class JourneyRoutingModule { }
