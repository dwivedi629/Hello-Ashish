"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var JourneyService_1 = require("./JourneyService");
var FxControlModels_1 = require("framework/controls/FxControlModels");
var FxDialogService_1 = require("framework/controls/FxDialogService");
var FxButtonClickService_1 = require("framework/controls/FxButtonClickService");
var CommonService_1 = require("framework/CommonService");
var JourneyListComponent = (function () {
    function JourneyListComponent(service, route, dialogService, fxButtonClickService, commonService) {
        var _this = this;
        this.service = service;
        this.route = route;
        this.dialogService = dialogService;
        this.fxButtonClickService = fxButtonClickService;
        this.commonService = commonService;
        this.fxDialog = new FxControlModels_1.FxDialog();
        fxButtonClickService.clickAnnounced$.subscribe(function (btnName) {
            if (btnName == "Ok") {
                _this.serviceDocument.dataProfile.dataModel = _this.journeyModel;
                service.delete().subscribe(function (response) {
                    if (response.result) {
                        _this.serviceDocument.dataProfile.dataList.splice(_this.serviceDocument.dataProfile.dataList.indexOf(_this.journeyModel), 1);
                        _this.commonService.showAlert("Journey deleted successfully.");
                    }
                    else {
                        _this.commonService.showAlert("There is a problem in deleting the journey.");
                    }
                });
                _this.dialogRef.close();
            }
            else {
                _this.dialogRef.close();
            }
        });
    }
    JourneyListComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.route.data
            .subscribe(function () { return _this.serviceDocument = _this.service.serviceDocument; });
        this.columns = [
            { name: "Captain Name", prop: "captainName" },
            { name: "Journey Type", prop: "journeyType" },
            { name: "Journey Number", prop: "journeyNumber" },
            { name: "Origin PortId", prop: "originPortId" },
            { name: "Arrival PortId", prop: "arrivalPortId" },
            { name: "Date Of Shipment", prop: "dateOfShipment" },
            { name: "Expected Arrival Date", prop: "expectedArrivalDate" },
            { name: "Expected Departure Date", prop: "expectedDepartureDate" },
            {
                name: "Actions", prop: "Actions", cellTemplate: this.editTmpl
            }
        ];
    };
    JourneyListComponent.prototype.open = function (jrny) {
        this.service.open(jrny.journeyId).subscribe();
    };
    JourneyListComponent.prototype.new = function () {
        this.service.new().subscribe();
    };
    JourneyListComponent.prototype.save = function () {
        this.service.save().subscribe();
    };
    JourneyListComponent.prototype.delete = function ($event, model) {
        $event.preventDefault();
        this.journeyModel = model;
        this.fxDialog.title = "Confirmation";
        this.fxDialog.content = "Are you sure you want to delete this Journey?";
        this.fxDialog.buttonList = [new FxControlModels_1.FxButton("", "Ok", ""), new FxControlModels_1.FxButton("", "Cancel", "")];
        //this.dialogRef = this.dialogService.openMessageDialog(this.fxDialog);
        this.dialogRef = this.dialogService.openDialog(this.fxDialog);
    };
    return JourneyListComponent;
}());
__decorate([
    core_1.ViewChild('editButton'),
    __metadata("design:type", core_1.TemplateRef)
], JourneyListComponent.prototype, "editTmpl", void 0);
JourneyListComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: "journey-list",
        templateUrl: "JourneyListComponent.html"
    }),
    __metadata("design:paramtypes", [JourneyService_1.JourneyService, router_1.ActivatedRoute, FxDialogService_1.FxDialogService,
        FxButtonClickService_1.FxButtonClickService,
        CommonService_1.CommonService])
], JourneyListComponent);
exports.JourneyListComponent = JourneyListComponent;
//# sourceMappingURL=JourneyListComponent.js.map