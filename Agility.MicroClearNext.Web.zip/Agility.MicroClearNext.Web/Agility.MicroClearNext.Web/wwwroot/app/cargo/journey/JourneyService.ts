﻿import { Injectable } from "@angular/core";
import { Http, Response, RequestOptions, URLSearchParams } from "@angular/http";
import { Observable } from "rxjs/Observable";

import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { JourneyModel } from "./models/JourneyModel";

@Injectable()
export class JourneyService {
    serviceDocument: ServiceDocument<JourneyModel> = new ServiceDocument<JourneyModel>();

    constructor(private http: Http) { }

    list(): Observable<ServiceDocument<JourneyModel>> {
        //debugger;
        //  this.serviceDocument.http.fxContext.IsAuthenticated = true;
        return this.serviceDocument.list("/api/Cargo/ListOfJourney");
    }

    new(): Observable<ServiceDocument<JourneyModel>> {     
        return this.serviceDocument.new("/api/Journey/New");
    }

    view(id: number): Observable<ServiceDocument<JourneyModel>> {
        return this.serviceDocument.view("/api/Journey/View", new URLSearchParams("id=" + id));
    }

    open(id: number): Observable<ServiceDocument<JourneyModel>> {
        return this.serviceDocument.open("/api/Journey/Open", new URLSearchParams("id=" + id));
    }

    delete(): Observable<ServiceDocument<JourneyModel>> {
        return this.serviceDocument.delete("/api/Journey/Delete");
    }

    save(): Observable<ServiceDocument<JourneyModel>> {
        return this.serviceDocument.save("/api/Journey/Save");
    }

    submit(): Observable<ServiceDocument<JourneyModel>> {
        return this.serviceDocument.submit("/api/Journey/Submit");
    }

}