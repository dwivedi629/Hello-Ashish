﻿import { ProfileModel } from "framework/profile/ProfileModel";
export class LocationModel extends ProfileModel {
    locationId: number;
    locationCode: string;
}