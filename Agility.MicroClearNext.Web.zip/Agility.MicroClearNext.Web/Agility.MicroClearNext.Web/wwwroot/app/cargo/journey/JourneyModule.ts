﻿import { NgModule } from "@angular/core";
import { FrameworkModule } from "framework/FrameworkModule";
import { JourneyRoutingModule } from "./journeyroutingmodule";
import { JourneyListComponent } from "./JourneyListComponent";
import { JourneyComponent } from "./JourneyComponent";
import { JourneyService } from "./JourneyService";
import { JourneyListResolver, JourneyNewResolver, JourneyViewResolver, JourneyOpenResolver } from "./JourneyResolver";

@NgModule({
    imports: [
        FrameworkModule,
        JourneyRoutingModule
    ],
    declarations: [
        JourneyListComponent,
        JourneyComponent
    ],
    providers: [
        JourneyService,
        JourneyListResolver,
        JourneyNewResolver,
        JourneyViewResolver,
        JourneyOpenResolver
    ]
})
export class JourneyModule {
}
