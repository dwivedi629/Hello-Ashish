"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var JourneyModel_1 = require("./models/JourneyModel");
var JourneyService_1 = require("./JourneyService");
var ManifestModel_1 = require("../manifest/models/ManifestModel");
var JourneyComponent = (function () {
    function JourneyComponent(route, router, service) {
        this.route = route;
        this.router = router;
        this.service = service;
        this.manifestModel = new ManifestModel_1.ManifestModel();
        this.journeyModel = new JourneyModel_1.JourneyModel();
        this.optionsData = [
            { "key": "Male", "value": "Male" }, { "key": "Female", "value": "Female" }
        ];
    }
    JourneyComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.route.data
            .subscribe(function () {
            //this.service.serviceDocument.dataProfile.dataModel.gender = this.optionsData;
            _this.serviceDocument = _this.service.serviceDocument;
        });
    };
    JourneyComponent.prototype.submit = function () {
        var _this = this;
        this.service.submit()
            .subscribe(function () {
            alert("submitted");
            _this.router.navigate(["/Journey"]);
        });
    };
    JourneyComponent.prototype.save = function () {
        this.service.save().subscribe(function () {
            alert("saved");
        });
    };
    JourneyComponent.prototype.cancel = function () {
        this.router.navigate(["/Journey"]);
        return false;
    };
    JourneyComponent.prototype.addSubProfile = function () {
        this.manifestModel.journeyId = this.serviceDocument.dataProfile.dataModel.journeyId;
        this.manifestModel.manifestNumber = 'M1';
        if (this.serviceDocument.dataProfile.dataModel.manifestList == null) {
            this.serviceDocument.dataProfile.dataModel.manifestList = new Array();
        }
        this.serviceDocument.dataProfile.dataModel.manifestList.push(this.manifestModel);
        return false;
    };
    JourneyComponent.prototype.newModel = function () {
        this.journeyModel.journeyNumber = "";
        this.journeyModel.vesselName = "";
        this.journeyModel.lastPortOfCallId = null;
        this.journeyModel.countryId = null;
        this.serviceDocument = this.service.serviceDocument.newModel(this.journeyModel);
        return false;
    };
    JourneyComponent.prototype.changeCountry = function (event) {
    };
    JourneyComponent.prototype.temp1 = function (event) {
    };
    return JourneyComponent;
}());
JourneyComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: "Journey",
        templateUrl: "JourneyComponent.html"
    }),
    __metadata("design:paramtypes", [router_1.ActivatedRoute, router_1.Router, JourneyService_1.JourneyService])
], JourneyComponent);
exports.JourneyComponent = JourneyComponent;
//# sourceMappingURL=JourneyComponent.js.map