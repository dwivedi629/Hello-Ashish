﻿import { Injectable } from "@angular/core";
import { Resolve, ActivatedRouteSnapshot } from "@angular/router";

import { Observable } from "rxjs/Observable";

import { JourneyService } from "./JourneyService";
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { JourneyModel } from "./models/JourneyModel";

@Injectable()
export class JourneyListResolver implements Resolve<ServiceDocument<JourneyModel>> {
    constructor(private service: JourneyService) { }

    resolve(route: ActivatedRouteSnapshot): Observable<ServiceDocument<JourneyModel>> {
        return this.service.list();
    }
}

@Injectable()
export class JourneyNewResolver implements Resolve<ServiceDocument<JourneyModel>> {
    constructor(private service: JourneyService) { }

    resolve(): Observable<ServiceDocument<JourneyModel>> {
        return this.service.new();
    }
}

@Injectable()
export class JourneyViewResolver implements Resolve<ServiceDocument<JourneyModel>> {
    constructor(private service: JourneyService) { }

    resolve(route: ActivatedRouteSnapshot): Observable<ServiceDocument<JourneyModel>> {
        return this.service.view(route.params["id"]);
    }
}

@Injectable()
export class JourneyOpenResolver implements Resolve<ServiceDocument<JourneyModel>> {
    constructor(private service: JourneyService) { }

    resolve(route: ActivatedRouteSnapshot): Observable<ServiceDocument<JourneyModel>> {
        return this.service.open(route.params["id"]);
    }
}
