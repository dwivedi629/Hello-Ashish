﻿import { Component, OnInit, ViewChild, TemplateRef } from "@angular/core";
import { ActivatedRoute } from "@angular/router";

import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { JourneyService } from "./JourneyService";
import { JourneyModel } from "./models/JourneyModel";
import { FxButton, FxDialog } from "framework/controls/FxControlModels";
import { FxDialogService } from "framework/controls/FxDialogService";
import { FxButtonClickService } from "framework/controls/FxButtonClickService";
import { CommonService } from "framework/CommonService";

@Component({
    moduleId: module.id,
    selector: "journey-list",
    templateUrl: "JourneyListComponent.html"
})
export class JourneyListComponent implements OnInit {
    dialogRef: any;

    serviceDocument: ServiceDocument<JourneyModel>;
    columns: any[];
    @ViewChild('editButton') public editTmpl: TemplateRef<JourneyListComponent>;
    journeyModel: JourneyModel;
    fxDialog: FxDialog = new FxDialog();

    constructor(private service: JourneyService, private route: ActivatedRoute, private dialogService: FxDialogService,
        private fxButtonClickService: FxButtonClickService,
        private commonService: CommonService) {
        fxButtonClickService.clickAnnounced$.subscribe(
            btnName => {
                if (btnName == "Ok") {
                    this.serviceDocument.dataProfile.dataModel = this.journeyModel;
                    service.delete().subscribe((response: any) => {
                        if (response.result) {
                            this.serviceDocument.dataProfile.dataList.splice(this.serviceDocument.dataProfile.dataList.indexOf(this.journeyModel), 1);
                            this.commonService.showAlert("Journey deleted successfully.");
                        } else {
                            this.commonService.showAlert("There is a problem in deleting the journey.");
                        }
                    });

                    this.dialogRef.close();
                }
                else {
                    this.dialogRef.close();
                }
            })
    }

    ngOnInit(): void {
        this.route.data
            .subscribe(() => this.serviceDocument = this.service.serviceDocument);
        this.columns = [
            { name: "Captain Name", prop: "captainName" },
            { name: "Journey Type", prop: "journeyType" },
            { name: "Journey Number", prop: "journeyNumber" },
            { name: "Origin PortId", prop: "originPortId" },
            { name: "Arrival PortId", prop: "arrivalPortId" },
            { name: "Date Of Shipment", prop: "dateOfShipment" },
            { name: "Expected Arrival Date", prop: "expectedArrivalDate" },
            { name: "Expected Departure Date", prop: "expectedDepartureDate" },
            {
                name: "Actions", prop: "Actions", cellTemplate: this.editTmpl
            }
        ];
    }

    open(jrny: JourneyModel): void {
        this.service.open(jrny.journeyId).subscribe();
    }

    new(): void {
        this.service.new().subscribe();
    }

    save(): void {
        this.service.save().subscribe();
    }

    delete($event: MouseEvent, model: JourneyModel) {
        $event.preventDefault();
        this.journeyModel = model;
        this.fxDialog.title = "Confirmation";
        this.fxDialog.content = "Are you sure you want to delete this Journey?";
        this.fxDialog.buttonList = [new FxButton("", "Ok", ""), new FxButton("", "Cancel", "")];
        //this.dialogRef = this.dialogService.openMessageDialog(this.fxDialog);
        this.dialogRef = this.dialogService.openDialog(this.fxDialog)
    }
}
