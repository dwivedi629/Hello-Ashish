import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
//import { IJourney } from '../../journey';
//import { JourneyService } from '../../JourneyService';
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { JourneyInfo } from '../journeyInfo/journeyInfoAccordion/JourneyInfo';
import { JourneyInfoService } from "../journeyInfo/Journeyinfoservice";
//import { RegistrationWizardService } from '../../../account/registration/registrationWizard/registrationWizardService';

@Component({
    moduleId: module.id,
  selector: 'app-existing-journey',
  templateUrl: './ExistingJourneyComponent.html',
  styleUrls: ['./ExistingJourneyComponent.css']
})

export class ExistingJourneyComponent implements OnInit {

    journeydetail: JourneyInfo;
  //  [] = [
  //  {
  //    'id': 1,
  //    'title': 'JRN-6-MYPKG-17',
  //    'startsFromShortName': 'SIN',
  //    'arrivalToShortName': 'MY',
  //    'startsFromFullName': 'Singapore',
  //    'arrivalToFullName': 'Malaysia',
  //    'startDate': '23 Mar, 2017',
  //    'arrivalDate': '23 Mar, 2017',
  //    'startTime': '06:00 PM',
  //    'arrivalTime': '02:00 PM',
  //    'berthNumr': '06',
  //    'status': 'Arrived',
  //    'viaImage': 'Ship',
  //    'modeOfTransportation': 'Sea (Mode of Transportation)',
  //    'statusClass': 'arrived'
  //  },
  //  {
  //    'id': 2,
  //    'title': 'JRN-7-MYUKG-16',
  //    'startsFromShortName': 'NYC',
  //    'arrivalToShortName': 'MYBAI',
  //    'startsFromFullName': 'Singapore',
  //    'arrivalToFullName': 'Malaysia',
  //    'startDate': '29 Mar, 2017',
  //    'arrivalDate': '31 Mar, 2017',
  //    'startTime': '04:00PM',
  //    'arrivalTime': '09:00PM',
  //    'berthNumr': '19',
  //    'status': 'Cancellation Requested',
  //    'viaImage': 'Plane',
  //    'modeOfTransportation': 'Air (Mode of Transportation)',
  //    'statusClass': 'cancellation-requested'
  //  },
  //  {
  //    'id': 3,
  //    'title': 'NYC-7-UYIKG-18',
  //    'startsFromShortName': 'AEULR',
  //    'arrivalToShortName': 'MYBGG',
  //    'startsFromFullName': 'Singapore',
  //    'arrivalToFullName': 'Malaysia',
  //    'startDate': '1 May, 2017',
  //    'arrivalDate': '5 May, 2017',
  //    'startTime': '08:00AM',
  //    'arrivalTime': '02:00PM',
  //    'berthNumr': '26',
  //    'status': 'Approved to Unload',
  //    'viaImage': 'Ship',
  //    'modeOfTransportation': 'Sea (Mode of Transportation)',
  //    'statusClass': 'approved-to-unload'
  //  },
  //  {
  //    'id': 4,
  //    'title': 'URN-9-IKGHIG-34',
  //    'startsFromShortName': 'ALTEN',
  //    'arrivalToShortName': 'MYKEL',
  //    'startsFromFullName': 'Singapore',
  //    'arrivalToFullName': 'Malaysia',
  //    'startDate': '09 Jun, 2017',
  //    'arrivalDate': '11 Jun, 2017',
  //    'startTime': '10:00PM',
  //    'arrivalTime': '09:00PM',
  //    'berthNumr': '39',
  //    'status': 'Submitted',
  //    'viaImage': 'Ship',
  //    'modeOfTransportation': 'Sea (Mode of Transportation)',
  //    'statusClass': 'submitted'
  //  },
  //  {
  //    'id': 5,
  //    'title': 'USN-9-URMIN-02',
  //    'startsFromShortName': 'BOM',
  //    'arrivalToShortName': 'MYCAP',
  //    'startsFromFullName': 'Singapore',
  //    'arrivalToFullName': 'Malaysia',
  //    'startDate': '01 Jul, 2017',
  //    'arrivalDate': '04 Jul, 2017',
  //    'startTime': '06:00PM',
  //    'arrivalTime': '02:00PM',
  //    'berthNumr': '21',
  //    'status': 'Arrived',
  //    'viaImage': 'Ship',
  //    'modeOfTransportation': 'Sea (Mode of Transportation)',
  //    'statusClass': 'arrived'
  //  },
  //  {
  //    'id': 6,
  //    'title': 'UIN-4-MINPEI-03',
  //    'startsFromShortName': 'ALTEN',
  //    'arrivalToShortName': 'MYKEL',
  //    'startsFromFullName': 'Singapore',
  //    'arrivalToFullName': 'Malaysia',
  //    'startDate': '23 Jul, 2017',
  //    'arrivalDate': '26 Jul, 2017',
  //    'startTime': '10:00PM',
  //    'arrivalTime': '12:00PM',
  //    'berthNumr': '17',
  //    'status': 'Drafts',
  //    'viaImage': 'Ship',
  //    'modeOfTransportation': 'Sea (Mode of Transportation)',
  //    'statusClass': 'drafts'
  //  }
  //];
  errorMessage: string;
  id: number;
  private sub: any;
  public serviceDocument: ServiceDocument<JourneyInfo>;

  constructor(
      //private _journeyService: JourneyService,
      public service: JourneyInfoService,
      private route: ActivatedRoute) { }

  ngOnInit() {
      this.route.data
          .subscribe((res) => {
              this.serviceDocument = this.service.serviceDocument;
              console.log(this.serviceDocument);
          });
      this.journeydetail = this.serviceDocument.dataProfile.dataModel;
  }

  //ngOnInit() {
    // this.getJourneyList();
    //this.sub = this.route.params.subscribe(params => {
    //  this.id = +params['id']; // (+) converts string 'id' to associate-inspection-instructions number

      // In associate-inspection-instructions real app: dispatch action to load the details here.
  //  });
  //}

  //getJourneyList() {
  //  this._journeyService.getJourneyList()
  //    .subscribe(journeyList => this.journeyList = journeyList,
  //      error => this.errorMessage = <any>error
  //    );
  //}
}
