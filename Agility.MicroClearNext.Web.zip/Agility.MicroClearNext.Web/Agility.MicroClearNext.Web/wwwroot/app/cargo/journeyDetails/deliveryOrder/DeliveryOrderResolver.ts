import { Injectable } from "@angular/core";
import { Resolve, ActivatedRouteSnapshot } from "@angular/router";

import { Observable } from "rxjs/Observable";

import { DeliveryOrderService } from "./DeliveryOrderService";
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { DeliveryOrderModel } from "./DeliveryOrder";

@Injectable()

export class DeliveryOrderListResolver implements Resolve<ServiceDocument<DeliveryOrderModel>> {
    constructor(private service: DeliveryOrderService) { }

    resolve(route: ActivatedRouteSnapshot): Observable<ServiceDocument<DeliveryOrderModel>> {
        return this.service.list();
    }
}

@Injectable()
export class DeliveryOrderNewResolver implements Resolve<ServiceDocument<DeliveryOrderModel>> {
    constructor(private service: DeliveryOrderService) { }

    resolve(): Observable<ServiceDocument<DeliveryOrderModel>> {
        return this.service.new();
    }
}

@Injectable()
export class DeliveryOrderViewResolver implements Resolve<ServiceDocument<DeliveryOrderModel>> {
    constructor(private service: DeliveryOrderService) { }

    resolve(route: ActivatedRouteSnapshot): Observable<ServiceDocument<DeliveryOrderModel>> {
        return this.service.view(route.params["id"]);
    }
}

@Injectable()
export class DeliveryOrderOpenResolver implements Resolve<ServiceDocument<DeliveryOrderModel>> {
    constructor(private service: DeliveryOrderService) { }

    resolve(route: ActivatedRouteSnapshot): Observable<ServiceDocument<DeliveryOrderModel>> {
        return this.service.open(route.params["id"]);
    }
}
