"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var DeliveryOrderService_1 = require("./DeliveryOrderService");
var DeliveryOrderListResolver = (function () {
    function DeliveryOrderListResolver(service) {
        this.service = service;
    }
    DeliveryOrderListResolver.prototype.resolve = function (route) {
        return this.service.list();
    };
    return DeliveryOrderListResolver;
}());
DeliveryOrderListResolver = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [DeliveryOrderService_1.DeliveryOrderService])
], DeliveryOrderListResolver);
exports.DeliveryOrderListResolver = DeliveryOrderListResolver;
var DeliveryOrderNewResolver = (function () {
    function DeliveryOrderNewResolver(service) {
        this.service = service;
    }
    DeliveryOrderNewResolver.prototype.resolve = function () {
        return this.service.new();
    };
    return DeliveryOrderNewResolver;
}());
DeliveryOrderNewResolver = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [DeliveryOrderService_1.DeliveryOrderService])
], DeliveryOrderNewResolver);
exports.DeliveryOrderNewResolver = DeliveryOrderNewResolver;
var DeliveryOrderViewResolver = (function () {
    function DeliveryOrderViewResolver(service) {
        this.service = service;
    }
    DeliveryOrderViewResolver.prototype.resolve = function (route) {
        return this.service.view(route.params["id"]);
    };
    return DeliveryOrderViewResolver;
}());
DeliveryOrderViewResolver = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [DeliveryOrderService_1.DeliveryOrderService])
], DeliveryOrderViewResolver);
exports.DeliveryOrderViewResolver = DeliveryOrderViewResolver;
var DeliveryOrderOpenResolver = (function () {
    function DeliveryOrderOpenResolver(service) {
        this.service = service;
    }
    DeliveryOrderOpenResolver.prototype.resolve = function (route) {
        return this.service.open(route.params["id"]);
    };
    return DeliveryOrderOpenResolver;
}());
DeliveryOrderOpenResolver = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [DeliveryOrderService_1.DeliveryOrderService])
], DeliveryOrderOpenResolver);
exports.DeliveryOrderOpenResolver = DeliveryOrderOpenResolver;
//# sourceMappingURL=DeliveryOrderResolver.js.map