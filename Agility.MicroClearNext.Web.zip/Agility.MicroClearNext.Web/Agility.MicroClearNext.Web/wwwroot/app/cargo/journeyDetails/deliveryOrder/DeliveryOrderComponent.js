"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var cdk_1 = require("@angular/cdk");
var BehaviorSubject_1 = require("rxjs/BehaviorSubject");
require("rxjs/add/operator/startWith");
require("rxjs/add/observable/merge");
require("rxjs/add/operator/map");
var router_1 = require("@angular/router");
var DeliveryOrderService_1 = require("./DeliveryOrderService");
var DeliveryOrderComponent = (function () {
    function DeliveryOrderComponent(router, activatedRoute, deliveryOrderService) {
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.deliveryOrderService = deliveryOrderService;
        this.displayedColumns = ['checkbox', 'blNo', 'manifestNo', 'totalPackages', 'blDate', 'billSplit', 'journey'];
        this.exampleDatabase = new ExampleDatabase();
    }
    DeliveryOrderComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.activatedRoute.data
            .subscribe(function (result) {
            _this.serviceDocument = result.serviceDocument;
            console.log(_this.serviceDocument);
        });
    };
    DeliveryOrderComponent.prototype.validateDeliveryOrderForm = function (model, isValid) {
        this.deliveryOrderFormSubmitted = true; // set form submit to true
    };
    DeliveryOrderComponent.prototype.submitManifest = function () {
        this.deliveryOrderService.submit().subscribe(function (result) {
            alert("submitted");
        });
    };
    return DeliveryOrderComponent;
}());
DeliveryOrderComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'app-delivery-order',
        templateUrl: './DeliveryOrderComponent.html',
        styleUrls: ['./DeliveryOrderComponent.css'],
    }),
    __metadata("design:paramtypes", [router_1.Router,
        router_1.ActivatedRoute,
        DeliveryOrderService_1.DeliveryOrderService])
], DeliveryOrderComponent);
exports.DeliveryOrderComponent = DeliveryOrderComponent;
/** An example database that the data source uses to retrieve data for the table. */
var ExampleDatabase = (function () {
    function ExampleDatabase() {
        /** Stream that emits whenever the data has been modified. */
        this.billOfLadingList = [
            {
                'id': 1,
                'blNo': 'bill111',
                'manifestNo': 'I-MRN-25-90-17',
                'totalPackages': 1000.00,
                'blDate': '26 Feb, 2017',
                'billSplit': 'No',
                'journey': 'JRN-6'
            },
            {
                'id': 2,
                'blNo': 'bill111',
                'manifestNo': 'I-MRN-25-90-17',
                'totalPackages': 1000.00,
                'blDate': '26 Feb, 2017',
                'billSplit': 'No',
                'journey': 'JRN-6'
            },
            {
                'id': 3,
                'blNo': 'bill111',
                'manifestNo': 'I-MRN-25-90-17',
                'totalPackages': 1000.00,
                'blDate': '26 Feb, 2017',
                'billSplit': 'No',
                'journey': 'JRN-6'
            }
        ];
        this.dataChange = new BehaviorSubject_1.BehaviorSubject([]);
        this.dataChange.next(this.billOfLadingList);
    }
    Object.defineProperty(ExampleDatabase.prototype, "data", {
        get: function () { return this.dataChange.value; },
        enumerable: true,
        configurable: true
    });
    return ExampleDatabase;
}());
exports.ExampleDatabase = ExampleDatabase;
var ExampleDataSource = (function (_super) {
    __extends(ExampleDataSource, _super);
    function ExampleDataSource(_exampleDatabase) {
        var _this = _super.call(this) || this;
        _this._exampleDatabase = _exampleDatabase;
        return _this;
    }
    /** Connect function called by the table to retrieve one stream containing the data to render. */
    ExampleDataSource.prototype.connect = function () {
        return this._exampleDatabase.dataChange;
    };
    ExampleDataSource.prototype.disconnect = function () { };
    return ExampleDataSource;
}(cdk_1.DataSource));
exports.ExampleDataSource = ExampleDataSource;
//# sourceMappingURL=DeliveryOrderComponent.js.map