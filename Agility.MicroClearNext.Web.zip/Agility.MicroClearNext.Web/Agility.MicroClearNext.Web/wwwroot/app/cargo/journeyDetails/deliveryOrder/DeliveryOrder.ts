import { ProfileModel } from "framework/profile/ProfileModel";
import { OrganizationModel } from "../manifest/models/OrganizationModel";
export interface DeliveryOrderModel extends ProfileModel {
    //deliveryOrderNo: string;
    //deliveryOrderDate: string;
    //consignee: string;
    //deliveryOrderExpiryDate: string;
    //consigneeFreeText: string;

    deliveryOrderId: number;
    deliveryOrderNumber: string;
    deliveryOrderDate: Date;
    expiryDate: Date;
    consigneeId: number;
    //organizationDetails: OrganizationModel;
    personalId: number;
    securityCode: string;
    unregisteredConsignee: string;
    journeyId: number;
    ownerLocId: number;
    ownerCSId: number;
}
