import { Injectable } from "@angular/core";
import { Http, Response, RequestOptions, URLSearchParams } from "@angular/http";
import { Observable } from "rxjs/Observable";
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { DeliveryOrderModel } from "./DeliveryOrder";

@Injectable()
export class DeliveryOrderService {
    serviceDocument: ServiceDocument<DeliveryOrderModel> = new ServiceDocument<DeliveryOrderModel>();

    constructor(private http: Http) { }
    list(): Observable<ServiceDocument<DeliveryOrderModel>> {
        return this.serviceDocument.list("/api/Cargo/DeliveryOrderList");
    }

    new(): Observable<ServiceDocument<DeliveryOrderModel>> {
        var test = this.serviceDocument.new("/api/Cargo/DeliveryOrderNew");
        return test;
    }

    view(id: number): Observable<ServiceDocument<DeliveryOrderModel>> {
        return this.serviceDocument.view("/api/Cargo/DeliveryOrderOpen", new URLSearchParams("id=" + id));
    }

    open(id: number): Observable<ServiceDocument<DeliveryOrderModel>> {
        return this.serviceDocument.open("/api/Cargo/DeliveryOrderOpen", new URLSearchParams("id=" + id));
    }

    delete(): Observable<ServiceDocument<DeliveryOrderModel>> {
        return this.serviceDocument.delete("/api/Cargo/DeliveryOrderDelete");
    }

    save(): Observable<ServiceDocument<DeliveryOrderModel>> {
        return this.serviceDocument.save("/api/Cargo/DeliveryOrderSave");
    }

    submit(): Observable<ServiceDocument<DeliveryOrderModel>> {
        return this.serviceDocument.submit("/api/Cargo/DeliveryOrderSubmit");
    }

}