import { Component, ViewChild, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { DataSource } from '@angular/cdk';
import { MdSort } from '@angular/material';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/startWith';
import 'rxjs/add/observable/merge';
import 'rxjs/add/operator/map';
import { DeliveryOrderModel } from './DeliveryOrder';
import { BillOfLadingList } from './BillofLadingList';
import { Router, ActivatedRoute } from '@angular/router';
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { DeliveryOrderService } from "./DeliveryOrderService";

@Component({
    moduleId: module.id,
    selector: 'app-delivery-order',
    templateUrl: './DeliveryOrderComponent.html',
    styleUrls: ['./DeliveryOrderComponent.css'],
})
export class DeliveryOrderComponent implements OnInit {
    public serviceDocument: ServiceDocument<DeliveryOrderModel>;
    public deliveryOrderForm: FormGroup;
    public deliveryOrderFormSubmitted: boolean;
    displayedColumns = ['checkbox', 'blNo', 'manifestNo', 'totalPackages', 'blDate', 'billSplit', 'journey'];
    exampleDatabase = new ExampleDatabase();
    dataSource: ExampleDataSource | null;

    constructor(private router: Router,
        private activatedRoute: ActivatedRoute,
        public deliveryOrderService: DeliveryOrderService) {

    }

    ngOnInit() {
        this.activatedRoute.data
            .subscribe((result: any) => {
                this.serviceDocument = result.serviceDocument;
                console.log(this.serviceDocument);
            });
    }

    validateDeliveryOrderForm(model: DeliveryOrderModel, isValid: boolean) {
        this.deliveryOrderFormSubmitted = true; // set form submit to true
    }

    submitManifest(): void {        
        this.deliveryOrderService.submit().subscribe((result) => {
            alert("submitted");
        });
    }
   
}

/** An example database that the data source uses to retrieve data for the table. */
export class ExampleDatabase {
    /** Stream that emits whenever the data has been modified. */
    public billOfLadingList: BillOfLadingList[] = [
        {
            'id': 1,
            'blNo': 'bill111',
            'manifestNo': 'I-MRN-25-90-17',
            'totalPackages': 1000.00,
            'blDate': '26 Feb, 2017',
            'billSplit': 'No',
            'journey': 'JRN-6'
        },
        {
            'id': 2,
            'blNo': 'bill111',
            'manifestNo': 'I-MRN-25-90-17',
            'totalPackages': 1000.00,
            'blDate': '26 Feb, 2017',
            'billSplit': 'No',
            'journey': 'JRN-6'
        },
        {
            'id': 3,
            'blNo': 'bill111',
            'manifestNo': 'I-MRN-25-90-17',
            'totalPackages': 1000.00,
            'blDate': '26 Feb, 2017',
            'billSplit': 'No',
            'journey': 'JRN-6'
        }
    ];
    dataChange: BehaviorSubject<BillOfLadingList[]> = new BehaviorSubject<BillOfLadingList[]>([]);
    get data(): BillOfLadingList[] { return this.dataChange.value; }

    constructor() {
        this.dataChange.next(this.billOfLadingList);
    }
}

export class ExampleDataSource extends DataSource<any> {
    constructor(private _exampleDatabase: ExampleDatabase) {
        super();
    }

    /** Connect function called by the table to retrieve one stream containing the data to render. */
    connect(): Observable<BillOfLadingList[]> {
        return this._exampleDatabase.dataChange;
    }

    disconnect() { }
}
