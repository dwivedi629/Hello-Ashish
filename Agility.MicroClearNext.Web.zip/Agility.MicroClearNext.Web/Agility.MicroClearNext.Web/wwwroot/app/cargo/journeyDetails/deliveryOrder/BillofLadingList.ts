﻿export interface BillOfLadingList {
    id: number;
    blNo: string;
    manifestNo: string;
    totalPackages: number;
    blDate: string;
    billSplit: string;
    journey: string;
}
