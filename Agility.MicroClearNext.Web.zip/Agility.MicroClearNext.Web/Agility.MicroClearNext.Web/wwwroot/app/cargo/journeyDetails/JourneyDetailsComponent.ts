import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { JourneyInfo } from './journeyInfo/journeyInfoAccordion/JourneyInfo';
import { JourneyInfoService } from "./journeyInfo/Journeyinfoservice";


@Component({
    moduleId: module.id,
    selector: 'app-journey-details',
    templateUrl: './JourneyDetailsComponent.html',
    changeDetection: ChangeDetectionStrategy.OnPush, // for only ExpressionChangedAfterItHasBeenCheckedError
    styleUrls: ['./JourneyDetailsComponent.css']
})
export class JourneyDetailsComponent implements OnInit {
    private isCompleted: boolean = false;
    public completedStep: number = 0;

    journeyDetails: JourneyInfo;
    errorMessage: string;
    onActivate(e, outlet) {
        outlet.scrollTop = 0;
    }
    public serviceDocument: ServiceDocument<JourneyInfo>;

    constructor(
        public service: JourneyInfoService,
        private activatedRoute: ActivatedRoute) {
    }

    ngOnInit() {
        this.activatedRoute.data
            .subscribe((res) => {
                this.serviceDocument = this.service.serviceDocument;
                console.log(this.serviceDocument);
            });
        this.journeyDetails = this.serviceDocument.dataProfile.dataModel;
    }

    
    checkWizardStatus(event, currentStep: number) {
        event.preventDefault();
        event.stopPropagation();

        if (this.completedStep >= currentStep) {
            this.completedStep = currentStep - 1;
        }
    }
}
