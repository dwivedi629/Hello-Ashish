"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var Journeyinfoservice_1 = require("./journeyInfo/Journeyinfoservice");
var JourneyDetailsComponent = (function () {
    function JourneyDetailsComponent(service, activatedRoute) {
        this.service = service;
        this.activatedRoute = activatedRoute;
        this.isCompleted = false;
        this.completedStep = 0;
    }
    JourneyDetailsComponent.prototype.onActivate = function (e, outlet) {
        outlet.scrollTop = 0;
    };
    JourneyDetailsComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.activatedRoute.data
            .subscribe(function (res) {
            _this.serviceDocument = _this.service.serviceDocument;
            console.log(_this.serviceDocument);
        });
        this.journeyDetails = this.serviceDocument.dataProfile.dataModel;
    };
    JourneyDetailsComponent.prototype.checkWizardStatus = function (event, currentStep) {
        event.preventDefault();
        event.stopPropagation();
        if (this.completedStep >= currentStep) {
            this.completedStep = currentStep - 1;
        }
    };
    return JourneyDetailsComponent;
}());
JourneyDetailsComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'app-journey-details',
        templateUrl: './JourneyDetailsComponent.html',
        changeDetection: core_1.ChangeDetectionStrategy.OnPush,
        styleUrls: ['./JourneyDetailsComponent.css']
    }),
    __metadata("design:paramtypes", [Journeyinfoservice_1.JourneyInfoService,
        router_1.ActivatedRoute])
], JourneyDetailsComponent);
exports.JourneyDetailsComponent = JourneyDetailsComponent;
//# sourceMappingURL=JourneyDetailsComponent.js.map