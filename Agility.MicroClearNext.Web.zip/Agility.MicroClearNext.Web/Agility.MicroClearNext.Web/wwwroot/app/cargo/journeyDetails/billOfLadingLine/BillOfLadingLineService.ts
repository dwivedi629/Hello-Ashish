import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, URLSearchParams } from "@angular/http";
import { Observable } from 'rxjs/Rx';
import 'rxjs/Rx';
import { HBItemModel } from "./BillOfLadingLine";
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";

@Injectable()
export class BolLineService {
    public serviceDocument: ServiceDocument<HBItemModel> = new ServiceDocument<HBItemModel>();
    constructor() { };
    list(): Observable<ServiceDocument<HBItemModel>> {
        return this.serviceDocument.list("/api/Cargo/ListOfHbItem");
    }

    new(): Observable<ServiceDocument<HBItemModel>> {
        return this.serviceDocument.new("/api/Cargo/NewOfHbItem");
    }
    open(id: number): Observable<ServiceDocument<HBItemModel>> {
        return this.serviceDocument.open("/api/Cargo/OpenOfHbItem", new URLSearchParams("id=" + id));
    }

    delete(): Observable<ServiceDocument<HBItemModel>> {
        return this.serviceDocument.delete("/api/Cargo/DeleteHbItem");
    }

    save(): Observable<ServiceDocument<HBItemModel>> {
        return this.serviceDocument.save("/api/Cargo/SaveHbItem");
    }

    submit(): Observable<ServiceDocument<HBItemModel>> {
        return this.serviceDocument.submit("/api/Cargo/SubmitHbItem");
    }


}
