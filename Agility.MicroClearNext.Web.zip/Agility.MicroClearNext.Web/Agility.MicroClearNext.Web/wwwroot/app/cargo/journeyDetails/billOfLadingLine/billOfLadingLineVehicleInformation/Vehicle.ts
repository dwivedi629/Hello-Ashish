﻿import { ProfileModel } from "framework/profile/ProfileModel";


export class VehicleModel extends ProfileModel {

    public vehicleId: number;

    public houseBillItemId?: number;

    public journeyId?: number;

    public containerId?: number;

    public vehicleTypeId?: number;

    public chasisNumber: string;

    public vehicleCC: string;

    public engineNumber: string;

    public shape: string;

    public color: string;

    public brandModelId?: number; 

    public year?: number;

    public remarks: string;

    public apNumber: string;

    public yearOfFirstRegistration?: number;

    public vehicleConditionId?: number;

    public vehicleMake: string;

    public permitIssuingAutharityId?: number;

    public vehicleBrandId?: number;

    public permitApplicationId?: number;

    public submittedDate?: Date;

    public ownerCSId?: number;

    public ownerLocId?: number;

    public createdDate: Date;

    public vehicleStatusId?: number;

}
