export interface IContainer {
  kindOfContainer: string;
  containerNo: string;
  goodsType: string;
  containerLoadType: string;
  grossWeight: string;
  noOfPackages: string;
  description: string;
  isISOType: string;
  tareWeight: string;
  tareWeightUOM: string;
  grossWeightUOM: string;
  iSOCode: string;
  containerOwner: string;
  containerType: string;
  containerSize: string;
  temperatureDegreeC: string;
  sealNo: string;
  remarks: string;
  containerStatus: string;
}
