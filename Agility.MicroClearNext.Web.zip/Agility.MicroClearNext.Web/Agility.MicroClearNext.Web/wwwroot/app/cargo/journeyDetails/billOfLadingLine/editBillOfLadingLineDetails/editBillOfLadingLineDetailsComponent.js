"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var BillOfLadingLineService_1 = require("../BillOfLadingLineService");
var EditBillOfLadingLineDetailsComponent = (function () {
    function EditBillOfLadingLineDetailsComponent(router, activatedRoute, service) {
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.service = service;
        this.showId = false;
    }
    EditBillOfLadingLineDetailsComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.activatedRoute.params.subscribe(function (params) {
            return _this.EditId = params['id'];
        });
        if (!isNaN(this.EditId) && this.EditId != undefined && this.EditId != 0) {
            this.showId = true;
        }
        this.activatedRoute.data
            .subscribe(function (res) {
            _this.serviceDocument = res.serviceDocument;
            _this.service.serviceDocument = res.serviceDocument;
            console.log("serviceDocument");
            console.log(_this.serviceDocument);
            console.log(res);
            _this.hbItem = _this.serviceDocument.dataProfile.dataModel;
            console.log(_this.hbItem);
        });
    };
    EditBillOfLadingLineDetailsComponent.prototype.submit = function () {
        this.service.submit()
            .subscribe(function () {
            alert("submitted");
        });
        this.router.navigate(['../bill-of-lading-line-container-information'], { relativeTo: this.activatedRoute });
    };
    EditBillOfLadingLineDetailsComponent.prototype.save = function () {
        this.service.save().subscribe(function () {
            alert("saved");
        });
        this.router.navigate(['../bill-of-lading-line-container-information'], { relativeTo: this.activatedRoute });
    };
    EditBillOfLadingLineDetailsComponent.prototype.cancel = function () {
        this.router.navigate(["/Journey"]);
        return false;
    };
    EditBillOfLadingLineDetailsComponent.prototype.submitBillOfLadingLine = function () {
        this.router.navigate(['../bill-of-lading-line-container-information'], { relativeTo: this.activatedRoute });
    };
    return EditBillOfLadingLineDetailsComponent;
}());
EditBillOfLadingLineDetailsComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'app-edit-bill-of-lading-line-details',
        templateUrl: './EditBillOfLadingLineDetailsComponent.html',
        styleUrls: ['./EditBillOfLadingLineDetailsComponent.css']
    }),
    __metadata("design:paramtypes", [router_1.Router,
        router_1.ActivatedRoute,
        BillOfLadingLineService_1.BolLineService])
], EditBillOfLadingLineDetailsComponent);
exports.EditBillOfLadingLineDetailsComponent = EditBillOfLadingLineDetailsComponent;
//# sourceMappingURL=editBillOfLadingLineDetailsComponent.js.map