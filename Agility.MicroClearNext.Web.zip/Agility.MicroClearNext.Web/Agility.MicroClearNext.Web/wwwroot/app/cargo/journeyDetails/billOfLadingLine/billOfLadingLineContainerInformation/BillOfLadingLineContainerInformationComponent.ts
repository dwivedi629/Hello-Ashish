import { Component, OnInit } from '@angular/core';
import { DataSource } from '@angular/cdk';
import { MdSort } from '@angular/material';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/startWith';
import 'rxjs/add/observable/merge';
import 'rxjs/add/operator/map';
import { Container } from './Container';
import { IContainerService } from "./addContainer/ContainerService";
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";

import { Router, ActivatedRoute } from '@angular/router';

@Component({
    moduleId: module.id,
    selector: 'app-bill-of-lading-line-container-information',
    templateUrl: './BillOfLadingLineContainerInformationComponent.html',
    styleUrls: ['./BillOfLadingLineContainerInformationComponent.css']
})
export class BillOfLadingLineContainerInformationComponent implements OnInit {
    errorMessage: any;
    containerList: ServiceDocument<Container>;
    serviceDocument: ServiceDocument<Container>;
    displayedColumns = ['checkbox', 'containerNo', 'containerSize', 'containerType', 'status', 'actions'];
    exampleDatabase: any; // new ExampleDatabase();

    constructor(
        private router: Router,
        private activatedRoute: ActivatedRoute,
        private IContainerService: IContainerService) { }

    ngOnInit() {


        this.activatedRoute.data
            .subscribe(() => {
                this.serviceDocument = this.IContainerService.serviceDocument;
                this.exampleDatabase = this.serviceDocument.dataProfile.dataList;
            });
    }

    List() {
        this.IContainerService.list()
            .subscribe(Response => {
                this.containerList = Response;
                console.log("New");
                console.log(this.containerList);
                console.log("errorMessage");

            },
            error => this.errorMessage = <any>error,
        );

    }

    disconnect() { }
}

