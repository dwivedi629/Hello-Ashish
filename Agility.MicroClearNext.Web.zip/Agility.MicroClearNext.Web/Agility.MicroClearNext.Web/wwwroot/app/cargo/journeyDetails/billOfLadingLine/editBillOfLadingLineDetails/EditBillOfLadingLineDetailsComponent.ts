import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { IBillOfLadingLineDetails } from './EditBillOfLadingLineDetails';
import { Router, ActivatedRoute } from '@angular/router';
import { BolLineService } from "../BillOfLadingLineService";
import { HBItemModel } from "../BillOfLadingLine";
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";

@Component({
    moduleId: module.id,
    selector: 'app-edit-bill-of-lading-line-details',
    templateUrl: './EditBillOfLadingLineDetailsComponent.html',
    styleUrls: ['./EditBillOfLadingLineDetailsComponent.css']
})
export class EditBillOfLadingLineDetailsComponent implements OnInit {
    public billOfLadingLineDetailsFormSubmitted: boolean;
    public serviceDocument: ServiceDocument<HBItemModel>;
    public hbItem: any;
    errorMessage: string;
    showId = false;
    EditId: number;
    constructor(
        private router: Router,
        private activatedRoute: ActivatedRoute,
        private service: BolLineService) { }

    ngOnInit() {
        this.activatedRoute.params.subscribe(params =>
            this.EditId = params['id']);
        if (!isNaN(this.EditId) && this.EditId != undefined && this.EditId != 0)
        {
            this.showId = true;
        }
        
        this.activatedRoute.data
                .subscribe((res) => {
                    this.serviceDocument = res.serviceDocument;
                    this.service.serviceDocument = res.serviceDocument;
                    console.log("serviceDocument");
                    console.log(this.serviceDocument);
                    console.log(res);
                    this.hbItem = this.serviceDocument.dataProfile.dataModel;
                    console.log(this.hbItem);
                });
    }

    submit(): void {
        this.service.submit()
            .subscribe(() => {
                alert("submitted");
            });
        this.router.navigate(['../bill-of-lading-line-container-information'], { relativeTo: this.activatedRoute });
    }

    save() {
        this.service.save().subscribe(() => {
            alert("saved");
        });
        this.router.navigate(['../bill-of-lading-line-container-information'], { relativeTo: this.activatedRoute });
    }

    cancel() {
        this.router.navigate(["/Journey"]);
        return false;
    }
    submitBillOfLadingLine() {
        this.router.navigate(['../bill-of-lading-line-container-information'], { relativeTo: this.activatedRoute });
    }
}
