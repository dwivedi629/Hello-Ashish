import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { IContainer } from './Container';
import { Router, ActivatedRoute } from '@angular/router';

import { RegistrationWizardService } from '../../../../../account/registration/registrationWizard/registrationWizardService';

@Component({
    moduleId: module.id,
    selector: 'app-add-container',
    templateUrl: './AddContainerComponent.html',
    styleUrls: ['./AddContainerComponent.css']
})
export class AddContainerComponent implements OnInit {
    public addContainerForm: FormGroup;
    public addContainerFormSubmitted: boolean;

    public toggleName = 'Show More';
    public toggleValue = false;
    public toggleClass = 'icon-down-caret';

    constructor(private _fb: FormBuilder,
        private router: Router,
        private activatedRoute: ActivatedRoute,
        private registrationWizardService: RegistrationWizardService) { }

    handleToggle() {
        if (this.toggleName === 'Show More') {
            this.toggleName = 'Show Less';
            this.toggleValue = true;
            this.toggleClass = 'icon-up-caret';
        } else {
            this.toggleName = 'Show More';
            this.toggleValue = false;
            this.toggleClass = 'icon-down-caret';
        }
    }

    ngOnInit() {
        this.addContainerForm = this._fb.group({
            kindOfContainer: ['', [<any>Validators.required]],
            containerNo: ['', [<any>Validators.required]],
            goodsType: ['', [<any>Validators.required]],
            containerLoadType: ['', [<any>Validators.required]],
            grossWeight: ['', [<any>Validators.required]],
            noOfPackages: ['', [<any>Validators.required]],
            description: ['', [<any>Validators.required]],
            isISOType: [''],
            tareWeight: [''],
            tareWeightUOM: [''],
            grossWeightUOM: [''],
            iSOCode: [''],
            containerOwner: [''],
            containerType: [''],
            containerSize: [''],
            temperatureDegreeC: [''],
            sealNo: [''],
            remarks: [''],
            containerStatus: ['']
        });
    }

    validateAddContainerForm(model: IContainer, isValid: boolean) {
        this.addContainerFormSubmitted = true; // set form submit to true

        // check if model is valid
        console.log(model, isValid);
        // this.router.navigate(['/vessel/add-vessel/ship-owner']);
    }

    addContainer() {
        this.registrationWizardService.emitStepCompletionStatus(this.activatedRoute.snapshot.data['stepCount']);
        this.router.navigate(['../bill-of-lading-line-vehicle-information'], { relativeTo: this.activatedRoute });
    }
}
