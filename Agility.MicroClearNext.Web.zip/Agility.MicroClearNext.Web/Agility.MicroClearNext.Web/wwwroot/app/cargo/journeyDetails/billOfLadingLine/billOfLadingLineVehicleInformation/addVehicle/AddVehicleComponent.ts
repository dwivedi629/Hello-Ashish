import {Component, OnInit} from '@angular/core';
import {FormGroup, FormBuilder, Validators} from '@angular/forms';
import { VehicleModel } from '../Vehicle';
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { VehicleService } from "./VehicleService";
import {Router, ActivatedRoute} from '@angular/router';

@Component({
    moduleId: module.id,
  selector: 'app-add-vehicle',
  templateUrl: './AddVehicleComponent.html',
  styleUrls: ['./AddVehicleComponent.css']
})
export class AddVehicleComponent implements OnInit {
    serviceDocument: ServiceDocument<VehicleModel>;
  public addVehicleForm: FormGroup;
  public addVehicleFormSubmitted: boolean;
  vehicleList: any;
  public toggleName = 'Show More';
  public toggleValue = false;
  public toggleClass = 'icon-down-caret';
  public errorMessage: string;
  StatusId: any;

  constructor(private _fb: FormBuilder,
              private router: Router,
              private activatedRoute: ActivatedRoute,
              private VehicleService: VehicleService,  ) { }

  handleToggle() {
    if (this.toggleName === 'Show More') {
      this.toggleName = 'Show Less';
      this.toggleValue = true;
      this.toggleClass = 'icon-up-caret';
    } else {
      this.toggleName = 'Show More';
      this.toggleValue = false;
      this.toggleClass = 'icon-down-caret';
    }
  }

  ngOnInit() {
      
      this.activatedRoute.data
          .subscribe(() => {
              this.serviceDocument = this.VehicleService.serviceDocument;
          });
      this.serviceDocument.dataProfile.profileForm 
  }

  new() {
      this.VehicleService.new()
          .subscribe(Response => {
              this.vehicleList = Response;
          },
          error => this.errorMessage = <any>error,
      );

  }
  submit(): void {
      this.VehicleService.submit()
          .subscribe(() => {                    
              this.router.navigate(["/Journey"]);
          });
  }
  save(): void {

      this.VehicleService.save()
          .subscribe(() => {
              this.router.navigate(["/Journey"]); 
          });
  }




  validateAddVehicleForm(model: VehicleModel, isValid: boolean) {
    this.addVehicleFormSubmitted = true; // set form submit to true
  }

  addVehicle() {
    this.router.navigate(['../../delivery-order'], {relativeTo: this.activatedRoute});        
  }
}
