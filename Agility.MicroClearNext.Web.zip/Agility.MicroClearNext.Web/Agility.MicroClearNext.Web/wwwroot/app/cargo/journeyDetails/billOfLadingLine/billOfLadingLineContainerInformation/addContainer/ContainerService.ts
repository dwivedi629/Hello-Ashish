﻿import { Injectable } from "@angular/core";
import { Http, Response, RequestOptions, URLSearchParams } from "@angular/http";
import { Observable } from "rxjs/Observable";

import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
//import { JourneyModel } from "./models/JourneyModel";

import { Container } from "../container";

@Injectable()
export class IContainerService {
    serviceDocument: ServiceDocument<Container> = new ServiceDocument<Container>();

    constructor(private http: Http) { }

    list(): Observable<ServiceDocument<Container>> {
        return this.serviceDocument.list("/api/Container/List");
    }

    new(): Observable<ServiceDocument<Container>> {
       
        var test = this.serviceDocument.new("/api/Container/New");
        return test;
    }

    view(id: number): Observable<ServiceDocument<Container>> {
        return this.serviceDocument.view("/api/Container/Open", new URLSearchParams("id=" + id));
    }

    open(id: number): Observable<ServiceDocument<Container>> {
        return this.serviceDocument.open("/api/Container/Open", new URLSearchParams("id=" + id));
    }

    delete(): Observable<ServiceDocument<Container>> {
        return this.serviceDocument.delete("/api/Container/Delete");
    }

    save(): Observable<ServiceDocument<Container>> {
        return this.serviceDocument.save("/api/Container/Save");
    }

    submit(): Observable<ServiceDocument<Container>> {
        return this.serviceDocument.submit("/api/Container/Submit");
    }

}