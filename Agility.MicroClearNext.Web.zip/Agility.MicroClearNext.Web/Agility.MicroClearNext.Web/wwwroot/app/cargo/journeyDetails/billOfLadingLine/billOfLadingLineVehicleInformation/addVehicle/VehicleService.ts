﻿import { Injectable } from "@angular/core";
import { Http, Response, RequestOptions, URLSearchParams } from "@angular/http";
import { Observable } from "rxjs/Observable";

import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
//import { JourneyModel } from "./models/JourneyModel";

import { VehicleModel } from "../Vehicle";

@Injectable()
export class VehicleService {
    serviceDocument: ServiceDocument<VehicleModel> = new ServiceDocument<VehicleModel>();

    constructor(private http: Http) { }

    list(): Observable<ServiceDocument<VehicleModel>> {
        return this.serviceDocument.list("/api/Cargo/ListOfVehicle");
    }

    new(): Observable<ServiceDocument<VehicleModel>> {
        return this.serviceDocument.new("/api/Cargo/NewOfVehicle");
    }

    view(id: number): Observable<ServiceDocument<VehicleModel>> {
        return this.serviceDocument.view("/api/Vehicle/View", new URLSearchParams("id=" + id));
    }

    open(id: number): Observable<ServiceDocument<VehicleModel>> {
        return this.serviceDocument.open("/api/Vehicle/Open", new URLSearchParams("id=" + id));
    }

    delete(): Observable<ServiceDocument<VehicleModel>> {
        return this.serviceDocument.delete("/api/Vehicle/Delete");
    }

    save(): Observable<ServiceDocument<VehicleModel>> {
        return this.serviceDocument.save("/api/Cargo/SaveVehicle");
    }

    submit(): Observable<ServiceDocument<VehicleModel>> {
        return this.serviceDocument.submit("/api/Cargo/SubmitVehicle");
    }

}