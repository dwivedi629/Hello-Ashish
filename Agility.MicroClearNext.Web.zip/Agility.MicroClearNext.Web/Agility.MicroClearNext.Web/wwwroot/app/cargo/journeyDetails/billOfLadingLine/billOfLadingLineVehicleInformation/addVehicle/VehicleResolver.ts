﻿/// <reference path="../Vehicle.ts" />
import { Injectable } from "@angular/core";
import { Resolve, ActivatedRouteSnapshot } from "@angular/router";

import { Observable } from "rxjs/Observable";

import { VehicleService } from "./VehicleService"
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { VehicleModel } from "../Vehicle";

@Injectable()
export class VehicleListResolver implements Resolve<ServiceDocument<VehicleModel>> {
    constructor(private service: VehicleService) { }

    resolve(route: ActivatedRouteSnapshot): Observable<ServiceDocument<VehicleModel>> {
        return this.service.list();
    }
}

@Injectable()
export class VehicleNewResolver implements Resolve<ServiceDocument<VehicleModel>> {
    constructor(private service: VehicleService) { }

    resolve(): Observable<ServiceDocument<VehicleModel>> {
        return this.service.new();
    }
}

@Injectable()
export class VehicleViewResolver implements Resolve<ServiceDocument<VehicleModel>> {
    constructor(private service: VehicleService) { }

    resolve(route: ActivatedRouteSnapshot): Observable<ServiceDocument<VehicleModel>> {
        return this.service.view(route.params["id"]);
    }
}

@Injectable()
export class VehicleOpenResolver implements Resolve<ServiceDocument<VehicleModel>> {
    constructor(private service: VehicleService) { }

    resolve(route: ActivatedRouteSnapshot): Observable<ServiceDocument<VehicleModel>> {
        return this.service.open(route.params["id"]);
    }
}
