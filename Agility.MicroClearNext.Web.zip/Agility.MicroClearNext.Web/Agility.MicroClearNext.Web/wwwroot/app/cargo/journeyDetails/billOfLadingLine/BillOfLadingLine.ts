import { ProfileModel } from "framework/profile/ProfileModel";
import { HouseBillModel } from "../billofLading/BillOfLading";
import { CargoTypeModel } from "../../../mdm/models/CargoTypeModel";
import { QuentityUnitModel } from "../../../mdm/models/QuantityUnitModel";
import { WeightUnitModel } from "../../../mdm/models/WeightUnitModel";
import { VolumeUnitModel } from "../../../mdm/models/VolumeUnitModel";
import { CountryModel } from "../../../mdm/models/CountyModel";
export interface IBol {
  id: number;
  bolNumber: string;
  status: string;
  statusClass: string;
  bolDate: string;
  splitted: string;
  qty: string;
}

export class HBItemModel extends ProfileModel {
    public hbItemId: number;
    public houseBillId?: number;
    public houseBill: HouseBillModel;
    public description: string;
    public quantity?: number;
    public qantityUOM?: number;
    public quantityUnit: QuentityUnitModel;
    public grossWeight?: number;
    public grossWeightUOM?: number;
    //public grossWeightUnit: WeightUnitModel;
    public netWeight?: number;
    public netWeightUOM?: number;
    //public netWeightUnit: WeightUnitModel;
    public volume?: number;
    public volumeUOM?: number;
    //public volumeUnit: VolumeUnitModel;
    public hbItemNo?: number;
    public cargoTypeId?: number;
    //public cargoType: CargoTypeModel;
    public actualQuantity?: number;
    public actualVolume?: number;
    public reasonRemarks?: string;
    public cargoClassId?: number;
    //public cargoTypeClass: CargoTypeModel;
    public hsCodeId?: number;
    public countryOfOriginId?: number;
    public country: CountryModel;
    public transRefId: number;
    public undgNumber: string;
    public flashpoint: string;
    public noOfPackages?: number;
    public isSTAItem: string;
    public stACodeId?: number;
    public isNonConsole: string;
    public actualQty?: number;
    public assignedTo?: number;
    public assignedBy?: number;
    public assignedDate?: Date;
    public actualGWeight?: number;
    public subHeadingId?: number;
    public processedQty?: number;
    public availableQty?: number;
    public processedGrossWeight?: number;
    public availableGrossWeight?: number;
    public ownerCSId?: number;
    public ownerLocId?: number;

}
