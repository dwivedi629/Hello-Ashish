export interface IBLLData {
  hsCode: string;
  refNumber: string;
}
