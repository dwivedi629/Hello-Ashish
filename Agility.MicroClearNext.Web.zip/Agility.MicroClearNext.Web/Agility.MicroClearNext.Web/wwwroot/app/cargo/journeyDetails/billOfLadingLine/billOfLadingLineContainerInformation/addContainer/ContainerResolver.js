"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
/// <reference path="../container.ts" />
var core_1 = require("@angular/core");
var ContainerService_1 = require("./ContainerService");
var IContainerListResolver = (function () {
    function IContainerListResolver(service) {
        this.service = service;
    }
    IContainerListResolver.prototype.resolve = function (route) {
        return this.service.list();
    };
    return IContainerListResolver;
}());
IContainerListResolver = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [ContainerService_1.IContainerService])
], IContainerListResolver);
exports.IContainerListResolver = IContainerListResolver;
var IContainerNewResolver = (function () {
    function IContainerNewResolver(service) {
        this.service = service;
    }
    IContainerNewResolver.prototype.resolve = function () {
        return this.service.new();
    };
    return IContainerNewResolver;
}());
IContainerNewResolver = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [ContainerService_1.IContainerService])
], IContainerNewResolver);
exports.IContainerNewResolver = IContainerNewResolver;
var IContainerViewResolver = (function () {
    function IContainerViewResolver(service) {
        this.service = service;
    }
    IContainerViewResolver.prototype.resolve = function (route) {
        return this.service.view(route.params["id"]);
    };
    return IContainerViewResolver;
}());
IContainerViewResolver = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [ContainerService_1.IContainerService])
], IContainerViewResolver);
exports.IContainerViewResolver = IContainerViewResolver;
var IContainerOpenResolver = (function () {
    function IContainerOpenResolver(service) {
        this.service = service;
    }
    IContainerOpenResolver.prototype.resolve = function (route) {
        return this.service.open(route.params["id"]);
    };
    return IContainerOpenResolver;
}());
IContainerOpenResolver = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [ContainerService_1.IContainerService])
], IContainerOpenResolver);
exports.IContainerOpenResolver = IContainerOpenResolver;
//# sourceMappingURL=ContainerResolver.js.map