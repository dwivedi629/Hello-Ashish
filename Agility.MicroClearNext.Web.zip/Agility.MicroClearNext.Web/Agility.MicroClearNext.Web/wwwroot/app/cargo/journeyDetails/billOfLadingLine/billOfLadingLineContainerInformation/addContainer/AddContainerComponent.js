"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var forms_1 = require("@angular/forms");
var router_1 = require("@angular/router");
var registrationWizardService_1 = require("../../../../../account/registration/registrationWizard/registrationWizardService");
var AddContainerComponent = (function () {
    function AddContainerComponent(_fb, router, activatedRoute, registrationWizardService) {
        this._fb = _fb;
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.registrationWizardService = registrationWizardService;
        this.toggleName = 'Show More';
        this.toggleValue = false;
        this.toggleClass = 'icon-down-caret';
    }
    AddContainerComponent.prototype.handleToggle = function () {
        if (this.toggleName === 'Show More') {
            this.toggleName = 'Show Less';
            this.toggleValue = true;
            this.toggleClass = 'icon-up-caret';
        }
        else {
            this.toggleName = 'Show More';
            this.toggleValue = false;
            this.toggleClass = 'icon-down-caret';
        }
    };
    AddContainerComponent.prototype.ngOnInit = function () {
        this.addContainerForm = this._fb.group({
            kindOfContainer: ['', [forms_1.Validators.required]],
            containerNo: ['', [forms_1.Validators.required]],
            goodsType: ['', [forms_1.Validators.required]],
            containerLoadType: ['', [forms_1.Validators.required]],
            grossWeight: ['', [forms_1.Validators.required]],
            noOfPackages: ['', [forms_1.Validators.required]],
            description: ['', [forms_1.Validators.required]],
            isISOType: [''],
            tareWeight: [''],
            tareWeightUOM: [''],
            grossWeightUOM: [''],
            iSOCode: [''],
            containerOwner: [''],
            containerType: [''],
            containerSize: [''],
            temperatureDegreeC: [''],
            sealNo: [''],
            remarks: [''],
            containerStatus: ['']
        });
    };
    AddContainerComponent.prototype.validateAddContainerForm = function (model, isValid) {
        this.addContainerFormSubmitted = true; // set form submit to true
        // check if model is valid
        console.log(model, isValid);
        // this.router.navigate(['/vessel/add-vessel/ship-owner']);
    };
    AddContainerComponent.prototype.addContainer = function () {
        this.registrationWizardService.emitStepCompletionStatus(this.activatedRoute.snapshot.data['stepCount']);
        this.router.navigate(['../bill-of-lading-line-vehicle-information'], { relativeTo: this.activatedRoute });
    };
    return AddContainerComponent;
}());
AddContainerComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'app-add-container',
        templateUrl: './AddContainerComponent.html',
        styleUrls: ['./AddContainerComponent.css']
    }),
    __metadata("design:paramtypes", [forms_1.FormBuilder,
        router_1.Router,
        router_1.ActivatedRoute,
        registrationWizardService_1.RegistrationWizardService])
], AddContainerComponent);
exports.AddContainerComponent = AddContainerComponent;
//# sourceMappingURL=AddContainerComponent.js.map