﻿/// <reference path="../container.ts" />
import { Injectable } from "@angular/core";
import { Resolve, ActivatedRouteSnapshot } from "@angular/router";

import { Observable } from "rxjs/Observable";

import { IContainerService } from "./ContainerService"
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { Container } from "../container";

@Injectable()
export class IContainerListResolver implements Resolve<ServiceDocument<Container>> {
    constructor(private service: IContainerService) { }

    resolve(route: ActivatedRouteSnapshot): Observable<ServiceDocument<Container>> {
        return this.service.list();
    }
}

@Injectable()
export class IContainerNewResolver implements Resolve<ServiceDocument<Container>> {
    constructor(private service: IContainerService) { }

    resolve(): Observable<ServiceDocument<Container>> {
        return this.service.new();
    }
}

@Injectable()
export class IContainerViewResolver implements Resolve<ServiceDocument<Container>> {
    constructor(private service: IContainerService) { }

    resolve(route: ActivatedRouteSnapshot): Observable<ServiceDocument<Container>> {
        return this.service.view(route.params["id"]);
    }
}

@Injectable()
export class IContainerOpenResolver implements Resolve<ServiceDocument<Container>> {
    constructor(private service: IContainerService) { }

    resolve(route: ActivatedRouteSnapshot): Observable<ServiceDocument<Container>> {
        return this.service.open(route.params["id"]);
    }
}
