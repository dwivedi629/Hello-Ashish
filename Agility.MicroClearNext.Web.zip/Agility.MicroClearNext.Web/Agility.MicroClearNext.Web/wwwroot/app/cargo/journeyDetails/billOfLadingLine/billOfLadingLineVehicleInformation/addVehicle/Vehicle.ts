import { ProfileModel } from "framework/profile/ProfileModel";


export class VehicleModel extends ProfileModel {

    public VehicleId: number;

    public HouseBillItemId: number;

    public  JourneyId : number;

    public ContainerId: number;

    public  VehicleTypeId : number;

    public  ChasisNumber: string; 

    public  VehicleCC: string;

    public  EngineNumber: string;

    public  Shape: string;

    public  Color: string;

    public  BrandModelId: number;

    public  Year : number;

    public  Remarks: string;

    public  APNumber: string;

    public  YearOfFirstRegistration: number;

    public  VehicleConditionId: number;

    public  VehicleMake: string;

    public  PermitIssuingAutharityId: number;

    public  VehicleBrandId: number;

    public  PermitApplicationId: number;

    public  SubmittedDate: Date;

    public  OwnerCSId: number;

    public  OwnerLocId: number;

    public  CreatedDate: Date;

}
