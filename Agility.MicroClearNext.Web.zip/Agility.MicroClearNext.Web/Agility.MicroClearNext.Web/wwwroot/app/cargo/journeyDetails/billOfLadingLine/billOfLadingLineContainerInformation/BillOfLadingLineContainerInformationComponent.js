"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
require("rxjs/add/operator/startWith");
require("rxjs/add/observable/merge");
require("rxjs/add/operator/map");
var ContainerService_1 = require("./addContainer/ContainerService");
var router_1 = require("@angular/router");
var BillOfLadingLineContainerInformationComponent = (function () {
    function BillOfLadingLineContainerInformationComponent(router, activatedRoute, IContainerService) {
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.IContainerService = IContainerService;
        this.displayedColumns = ['checkbox', 'containerNo', 'containerSize', 'containerType', 'status', 'actions'];
    }
    BillOfLadingLineContainerInformationComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.activatedRoute.data
            .subscribe(function () {
            _this.serviceDocument = _this.IContainerService.serviceDocument;
            _this.exampleDatabase = _this.serviceDocument.dataProfile.dataList;
        });
    };
    BillOfLadingLineContainerInformationComponent.prototype.List = function () {
        var _this = this;
        this.IContainerService.list()
            .subscribe(function (Response) {
            _this.containerList = Response;
            console.log("New");
            console.log(_this.containerList);
            console.log("errorMessage");
        }, function (error) { return _this.errorMessage = error; });
    };
    BillOfLadingLineContainerInformationComponent.prototype.disconnect = function () { };
    return BillOfLadingLineContainerInformationComponent;
}());
BillOfLadingLineContainerInformationComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'app-bill-of-lading-line-container-information',
        templateUrl: './BillOfLadingLineContainerInformationComponent.html',
        styleUrls: ['./BillOfLadingLineContainerInformationComponent.css']
    }),
    __metadata("design:paramtypes", [router_1.Router,
        router_1.ActivatedRoute,
        ContainerService_1.IContainerService])
], BillOfLadingLineContainerInformationComponent);
exports.BillOfLadingLineContainerInformationComponent = BillOfLadingLineContainerInformationComponent;
//# sourceMappingURL=BillOfLadingLineContainerInformationComponent.js.map