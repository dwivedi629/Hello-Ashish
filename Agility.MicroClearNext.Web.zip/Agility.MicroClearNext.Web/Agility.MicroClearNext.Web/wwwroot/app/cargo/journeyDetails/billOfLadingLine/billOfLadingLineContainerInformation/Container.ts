﻿import { ProfileModel } from "framework/profile/ProfileModel";
import { CargoTypeModel } from "../../../../mdm/models/CargoTypeModel";
import { WeightUnitModel } from "../../../../mdm/models/WeightUnitModel";
//import { GoodsTypeModel } from "../../../../mdm/models/GoodsTypeModel";
//import { ContainerISOCodeModel } from "../../../../mdm/models/ContainerISOCodeModel";

export class Container extends ProfileModel {
    public containerId: number;
    public journeyId?: number;
    public containerNumber: string;
   public containerTypeId?: number;
    //public cargoType: CargoTypeModel;
   // public weigtUnit: WeightUnitModel;
   // public GoodsType: GoodsTypeModel;
  //  public ContainerISOCode: ContainerISOCodeModel;
    public containerLoadTypeId?: number;
    public containerSize?: number;
    public containerOwnerId?: number;
    public kindTypeId?: number;
    public goodsTypeId?: number;
    public isOCode?: number;
    public description?: string;
    public tareWeight?: number;
    public tareWeightUOM?: number;
    public grossWeight?: number;
    public grossWeightUOM?: number;
    public sealNumber: string;
    public noOfPacakage?: number;
    public temparature?: number;
    public remarks: string;
    public unloadEndDate: Date;
    public unloadStartDate: Date;
    public dischargeStartDate: Date;
    public dischargeEndDate: Date;
    public refId?: number;
    public refType: string;
    public storageLocationId?: number;
   // public isDefault: string;
    //public assignedTo?: number;
    //public assignedBy?: number;
    //public assignedDate: Date;
    //public isISOType: string;
    public containerStatusId?: number;
    //public ownerCSId?: number;
    //public ownerLocId?: number;
    public createdDate: Date;
    // domain data models
   
    
}
