"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var cdk_1 = require("@angular/cdk");
var BehaviorSubject_1 = require("rxjs/BehaviorSubject");
require("rxjs/add/operator/startWith");
require("rxjs/add/observable/merge");
require("rxjs/add/operator/map");
var VehicleService_1 = require("../billOfLadingLineVehicleInformation/addVehicle/VehicleService");
var router_1 = require("@angular/router");
var BillOfLadingLineVehicleInformationComponent = (function () {
    function BillOfLadingLineVehicleInformationComponent(VehicleService, activatedRoute) {
        this.VehicleService = VehicleService;
        this.activatedRoute = activatedRoute;
        this.displayedColumns = ['checkbox', 'engineNumber', 'chasisNumber', 'vehicleId', 'status', 'actions'];
    }
    BillOfLadingLineVehicleInformationComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.activatedRoute.data
            .subscribe(function () { _this.serviceDocument = _this.VehicleService.serviceDocument; });
        this.exampleDatabase = this.serviceDocument.dataProfile.dataList;
        this.dataSource = new ExampleDataSource(this.exampleDatabase);
    };
    return BillOfLadingLineVehicleInformationComponent;
}());
BillOfLadingLineVehicleInformationComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'app-bill-of-lading-line-vehicle-information',
        templateUrl: './BillOfLadingLineVehicleInformationComponent.html',
        styleUrls: ['./BillOfLadingLineVehicleInformationComponent.css']
    }),
    __metadata("design:paramtypes", [VehicleService_1.VehicleService,
        router_1.ActivatedRoute])
], BillOfLadingLineVehicleInformationComponent);
exports.BillOfLadingLineVehicleInformationComponent = BillOfLadingLineVehicleInformationComponent;
/** An example database that the data source uses to retrieve data for the table. */
var ExampleDatabase = (function () {
    function ExampleDatabase() {
        /** Stream that emits whenever the data has been modified. */
        this.dataChange = new BehaviorSubject_1.BehaviorSubject([]);
    }
    Object.defineProperty(ExampleDatabase.prototype, "data", {
        get: function () { return this.dataChange.value; },
        enumerable: true,
        configurable: true
    });
    return ExampleDatabase;
}());
exports.ExampleDatabase = ExampleDatabase;
var ExampleDataSource = (function (_super) {
    __extends(ExampleDataSource, _super);
    function ExampleDataSource(_exampleDatabase) {
        var _this = _super.call(this) || this;
        _this._exampleDatabase = _exampleDatabase;
        return _this;
    }
    /** Connect function called by the table to retrieve one stream containing the data to render. */
    ExampleDataSource.prototype.connect = function () {
        return this._exampleDatabase.dataChange;
    };
    ExampleDataSource.prototype.disconnect = function () { };
    return ExampleDataSource;
}(cdk_1.DataSource));
exports.ExampleDataSource = ExampleDataSource;
//# sourceMappingURL=BillOfLadingLineVehicleInformationComponent.js.map