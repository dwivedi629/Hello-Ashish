export interface IBillOfLadingLineDetails {
  hsCode: string;
  cargoClass: string;
  countryOfOrigin: string;
  refNo: string;
  billOfLadingDate: string;
  cargoType: string;
  quantity: string;
  unitOfQuantityMeasurement: string;
  volume: string;
  unitOfVolumeMeasurement: string;
  netWeight: string;
  unitOfNetWeightMeasurement: string;
  grossWeight: string;
  unitOfGrossWeightMeasurement: string;
  unDgNo: string;
  flashPoint: string;
  cargoDescription: string;
}
