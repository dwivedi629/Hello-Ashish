import { Component, OnInit } from '@angular/core';
import { DataSource } from '@angular/cdk';
import { MdSort } from '@angular/material';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/startWith';
import 'rxjs/add/observable/merge';
import 'rxjs/add/operator/map';
import { VehicleService } from "../billOfLadingLineVehicleInformation/addVehicle/VehicleService";
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { VehicleModel } from './Vehicle';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
    moduleId: module.id,
    selector: 'app-bill-of-lading-line-vehicle-information',
    templateUrl: './BillOfLadingLineVehicleInformationComponent.html',
    styleUrls: ['./BillOfLadingLineVehicleInformationComponent.css']
})
export class BillOfLadingLineVehicleInformationComponent implements OnInit {
    serviceDocument: ServiceDocument<VehicleModel>;
    displayedColumns = ['checkbox', 'engineNumber', 'chasisNumber', 'vehicleId', 'status', 'actions'];
    dataSource: any;
    exampleDatabase: any;
    columns: any[];
    constructor(private VehicleService: VehicleService,
        private activatedRoute: ActivatedRoute,) { }

    ngOnInit() {
        this.activatedRoute.data
            .subscribe(() => { this.serviceDocument = this.VehicleService.serviceDocument });
        this.exampleDatabase = this.serviceDocument.dataProfile.dataList;
        this.dataSource = new ExampleDataSource(this.exampleDatabase);
    }
}

/** An example database that the data source uses to retrieve data for the table. */
export class ExampleDatabase {
    /** Stream that emits whenever the data has been modified. */
   
    dataChange: BehaviorSubject<VehicleModel[]> = new BehaviorSubject<VehicleModel[]>([]);
    get data(): VehicleModel[] { return this.dataChange.value; }

    constructor() {         
    }
}

export class ExampleDataSource extends DataSource<any> {
    constructor(private _exampleDatabase: ExampleDatabase) {
        super();
    }

    /** Connect function called by the table to retrieve one stream containing the data to render. */
    connect(): Observable<VehicleModel[]> {
        return this._exampleDatabase.dataChange;
    }

    disconnect() { }
}


