import { Component, OnInit } from '@angular/core';
import { BolLineService } from '../BillOfLadingLineService';
import { HBItemModel } from "../BillOfLadingLine";
import { Router, ActivatedRoute } from "@angular/router";
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";

@Component({
    moduleId: module.id,
    selector: 'app-bill-of-lading-line-details',
    templateUrl: './BillOfLadingLineDetailsComponent.html',
    styleUrls: ['./BillOfLadingLineDetailsComponent.css'],
    providers: [HBItemModel]
})
export class BillOfLadingLineDetailsComponent implements OnInit {
    serviceDocument: ServiceDocument<HBItemModel>;
    constructor(private route: ActivatedRoute, private router: Router, public service: BolLineService, private hbItem: HBItemModel) { }

    ngOnInit() {
        this.route.data
            .subscribe((res) => {
                this.serviceDocument = res.serviceDocument;
                this.hbItem = this.serviceDocument.dataProfile.dataModel; 
            });
    }

}
