import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { IBLLData } from './BillLadingLineData';
import { IBol } from '../BillOfLadingLine';
import { BolLineService } from '../BillOfLadingLineService';
import { HBItemModel } from "../BillOfLadingLine";
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { Router, ActivatedRoute } from '@angular/router';

@Component({
    moduleId: module.id,
    selector: 'app-bill-of-lading-line-list-view',
    templateUrl: './BillOfLadingLineListViewComponent.html',
    styleUrls: ['./BillOfLadingLineListViewComponent.css']
})
export class BillOfLadingLineListViewComponent implements OnInit {
    public bllListForm: FormGroup;
    public bllListFormSubmitted: boolean;
    public hbItemList: HBItemModel[];
    public serviceDocument: ServiceDocument<HBItemModel>;
    errorMessage: string;

    constructor(private _fb: FormBuilder, private service: BolLineService, private router: Router,
        private activatedRoute: ActivatedRoute, ) {
    }

    ngOnInit() {
        this.activatedRoute.data
            .subscribe((res) => {
                this.serviceDocument = res.serviceDocument;                
                this.hbItemList = this.serviceDocument.dataProfile.dataList;
            });
    }

    displayHbItem() {
        this.service.list().subscribe(response => this.serviceDocument = response,
            error => console.error(error),
            () => {
                this.hbItemList = this.serviceDocument.dataProfile.dataList;
                this.resetJourney();
            });
    }
    resetJourney() {
    }
}
