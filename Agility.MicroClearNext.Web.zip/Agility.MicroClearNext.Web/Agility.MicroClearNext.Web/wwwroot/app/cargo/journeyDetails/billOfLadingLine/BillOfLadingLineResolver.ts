﻿import { Injectable } from "@angular/core";
import { Resolve, ActivatedRouteSnapshot } from "@angular/router";
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { Observable } from "rxjs/Observable";
import { HBItemModel } from "./BillOfLadingLine";
import { BolLineService } from "./BillOfLadingLineService";

@Injectable()
export class HBItemListResolver implements Resolve<ServiceDocument<HBItemModel>> {
    constructor(private service: BolLineService) { }

    resolve(route: ActivatedRouteSnapshot): Observable<ServiceDocument<HBItemModel>> {
        return this.service.list();
    }
}

@Injectable()
export class HBItemlNewResolver implements Resolve<ServiceDocument<HBItemModel>> {
    constructor(private service: BolLineService) { }

    resolve(): Observable<ServiceDocument<HBItemModel>> {
        return this.service.new();
    }
}

@Injectable()
export class HBItemOpenResolver implements Resolve<ServiceDocument<HBItemModel>> {
    constructor(private service: BolLineService) { }

    resolve(route: ActivatedRouteSnapshot): Observable<ServiceDocument<HBItemModel>> {
        return this.service.open(route.params["id"]);
    }
}
