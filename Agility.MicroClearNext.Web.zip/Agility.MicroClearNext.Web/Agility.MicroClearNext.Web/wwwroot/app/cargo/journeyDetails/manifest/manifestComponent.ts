import { Component, OnInit } from '@angular/core';
import { IManifest } from './Manifest';
import { ManifestService } from './ManifestService';
import { RegistrationWizardService } from '../../../account/registration/registrationWizard/registrationWizardService';

@Component({
    moduleId: module.id,
  selector: 'app-manifest',
  templateUrl: './ManifestComponent.html',
  styleUrls: ['./ManifestComponent.css'],
  
})
export class ManifestComponent implements OnInit {

 
  errorMessage: string;

  constructor() { }

  ngOnInit() {
   // this.getManifestList();
  }

  getManifestList() {
    
  }

}
