export interface IManifestInfoDetails {
  manifestInfo: string;
  storageType: string;
  manifestFor: string;
  manifestDate: string;
  storageLocation: string;
  numOfBills: string;
  type: string;
  submtd: {
    subDate: string;
    subTime: string;
  };
  actualArrival: {
    aaDate: string;
    aaTime: string;
  };
}
