﻿
import { ProfileModel } from "framework/profile/ProfileModel";

export class OrganizationModel extends ProfileModel {
    OrganizationId: number;
    organizationName: string;
}