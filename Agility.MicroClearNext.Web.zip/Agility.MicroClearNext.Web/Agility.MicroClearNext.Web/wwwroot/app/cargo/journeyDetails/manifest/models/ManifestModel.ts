﻿import { ProfileModel } from "framework/profile/ProfileModel";
import { CustomStationModel } from "./CustomStationModel";
import { StorageLocationModel } from "./StorageLocationModel";
import { OrganizationModel } from "./OrganizationModel";
import { CargoTypesModel } from "./cargotypemodel";
//import { HouseBillModel } from "../../housebill/models/HouseBill";
export class ManifestModel extends ProfileModel {
    manifestId: number;
    journeyId: number;
    //journey: JourneyModel;

    agentId: number;
    organizationDetails: OrganizationModel;
    manifestNumber: string;
    manifestDate: Date;
    manifestfor: string;
    //manifestF: CargoTypesModel;

    manifestType: string;
    //manifestT?: CargoTypesModel;

    storageType: string;
    //storageT?: CargoTypesModel;

    storageLocationId: number;
    customStation?: CustomStationModel;

    totalNoOfHBs: number;
    manifestSubmittedDate: Date;
    //isLateSubmitted: boolean;
    //isNilCargo: boolean;
    //remarks: string;
    //actualHouseBills: number;
    //isSlotAgentManifest: number;
    //transRefId: number;
    //useInTranshipment: boolean;
    //dataVersion: number;
    //isDisclaimerChecked: boolean;
    //manifestStatus: boolean;
    //assignedTo: number;
    //assignedBy: number;
    //assignedDate: Date;
    //dateOfApproval: Date;
    //ownerLocId: number;
    //ownerCSId: number;
    ////houseBillList: HouseBillModel[];

   //journeyNumber: string;
}