"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var ManifestService_1 = require("./ManifestService");
var ManifestListResolver = (function () {
    function ManifestListResolver(service) {
        this.service = service;
    }
    ManifestListResolver.prototype.resolve = function (route) {
        return this.service.list();
    };
    return ManifestListResolver;
}());
ManifestListResolver = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [ManifestService_1.ManifestService])
], ManifestListResolver);
exports.ManifestListResolver = ManifestListResolver;
var ManifestNewResolver = (function () {
    function ManifestNewResolver(service) {
        this.service = service;
    }
    ManifestNewResolver.prototype.resolve = function () {
        return this.service.new();
    };
    return ManifestNewResolver;
}());
ManifestNewResolver = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [ManifestService_1.ManifestService])
], ManifestNewResolver);
exports.ManifestNewResolver = ManifestNewResolver;
var ManifestViewResolver = (function () {
    function ManifestViewResolver(service) {
        this.service = service;
    }
    ManifestViewResolver.prototype.resolve = function (route) {
        return this.service.view(route.params["id"]);
    };
    return ManifestViewResolver;
}());
ManifestViewResolver = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [ManifestService_1.ManifestService])
], ManifestViewResolver);
exports.ManifestViewResolver = ManifestViewResolver;
var ManifestOpenResolver = (function () {
    function ManifestOpenResolver(service) {
        this.service = service;
    }
    ManifestOpenResolver.prototype.resolve = function (route) {
        return this.service.open(route.params["id"]);
    };
    return ManifestOpenResolver;
}());
ManifestOpenResolver = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [ManifestService_1.ManifestService])
], ManifestOpenResolver);
exports.ManifestOpenResolver = ManifestOpenResolver;
//# sourceMappingURL=ManifestResolver.js.map