"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var ManifestService_1 = require("../ManifestService");
var Journeyinfoservice_1 = require("../../journeyInfo/Journeyinfoservice");
var EditManifestDetailsComponent = (function () {
    function EditManifestDetailsComponent(manifestService, journeyInfoService, router, activatedRoute) {
        this.manifestService = manifestService;
        this.journeyInfoService = journeyInfoService;
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.showbuttons = true;
        this.manifestF = [
            { typeId: 'I', name: 'Inward' }, { typeId: 'T', name: 'Transshipment' }
        ];
        this.manifestT = [
            { typeId: '1', name: 'Cargo' }, { typeId: '2', name: 'Courier' }
        ];
        this.storageT = [
            { typeId: 'P', name: 'Port' }, { typeId: 'W', name: 'Warehouse' }
        ];
    }
    EditManifestDetailsComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.activatedRoute.data
            .subscribe(function () {
            _this.serviceDocument = _this.manifestService.serviceDocument;
            //this.serviceDocument.dataProfile.profileForm.patchValue({ 'journeyNumber': this.journeyInfoService.journeyModel.journeyNumber });
            //console.log(this.serviceDocument);
        });
        //this.getCustomStation();
        //this.getStorageLocation();
        //this.getManifestFor();
        //this.getManifestType();
        //this.getStorageType();
    };
    EditManifestDetailsComponent.prototype.validateIManifestInfoDetailsForm = function (model, isValid) {
        this.manifestInfoDetailsFormSubmitted = true;
        // check if model is valid
        console.log(model, isValid);
        // this.router.navigate(['/vessel/add-vessel/ship-owner']);
    };
    EditManifestDetailsComponent.prototype.validateManifestCarrierDetailsForm = function (model, isValid) {
        this.manifestCarrierDetailsFormSubmitted = true;
        // check if model is valid
        console.log(model, isValid);
        // this.router.navigate(['/vessel/add-vessel/ship-owner']);
    };
    EditManifestDetailsComponent.prototype.submitManifest = function () {
        var _this = this;
        this.serviceDocument.dataProfile.profileForm.patchValue({ 'journeyId': this.journeyInfoService.journeyModel.journeyId });
        this.manifestService.submit().subscribe(function (result) {
            // alert("submitted");
            _this.serviceDocument.dataProfile.dataModel.manifestNumber = result.dataProfile.dataModel.manifestNumber;
            //this.serviceDocument.dataProfile.dataModel.journey = result.dataProfile.dataModel.journey;
        });
        //this.registrationWizardService.emitStepCompletionStatus(this.route.snapshot.data['stepCount']);
        // this.router.navigate(['../../sbill-of-lading'], { relativeTo: this.activatedRoute });
    };
    EditManifestDetailsComponent.prototype.save = function () {
        this.manifestService.save().subscribe(function () {
            alert("saved");
        });
    };
    return EditManifestDetailsComponent;
}());
EditManifestDetailsComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'app-edit-manifest-details',
        templateUrl: './EditManifestDetailsComponent.html',
        styleUrls: ['./EditManifestDetailsComponent.css'],
    }),
    __metadata("design:paramtypes", [ManifestService_1.ManifestService,
        Journeyinfoservice_1.JourneyInfoService,
        router_1.Router,
        router_1.ActivatedRoute])
], EditManifestDetailsComponent);
exports.EditManifestDetailsComponent = EditManifestDetailsComponent;
//# sourceMappingURL=editManifestDetailsComponent.js.map