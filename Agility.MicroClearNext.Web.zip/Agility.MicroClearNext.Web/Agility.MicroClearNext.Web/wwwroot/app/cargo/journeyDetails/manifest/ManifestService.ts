import { Injectable } from "@angular/core";
import { Http, Response, RequestOptions, URLSearchParams } from "@angular/http";
import { Observable } from "rxjs/Observable";
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { ManifestModel } from "./models/ManifestModel";

@Injectable()
export class ManifestService {
    serviceDocument: ServiceDocument<ManifestModel> = new ServiceDocument<ManifestModel>();

    constructor(private http: Http) { }
    list(): Observable<ServiceDocument<ManifestModel>> {
        return this.serviceDocument.list("/api/Manifest/List");
    }

    new(): Observable<ServiceDocument<ManifestModel>> {

        var test = this.serviceDocument.new("/api/Cargo/ManifestNew");
        return test;
    }

    view(id: number): Observable<ServiceDocument<ManifestModel>> {
        return this.serviceDocument.view("/api/Cargo/ManifestOpen", new URLSearchParams("id=" + id));
    }

    open(id: number): Observable<ServiceDocument<ManifestModel>> {
        return this.serviceDocument.open("/api/Cargo/ManifestOpen", new URLSearchParams("id=" + id));
    }

    delete(): Observable<ServiceDocument<ManifestModel>> {
        return this.serviceDocument.delete("/api/Cargo/ManifestDelete");
    }

    save(): Observable<ServiceDocument<ManifestModel>> {
        return this.serviceDocument.save("/api/Cargo/ManifestSave");
    }

    submit(): Observable<ServiceDocument<ManifestModel>> {
        return this.serviceDocument.submit("/api/Cargo/ManifestSubmit");
    }


      //Manifest master data

    //getCustomStation(): Observable<any> {
    //    return this.serviceDocument.get("/api/CustomStation/GetCustomStation");
    //}

    //getStorageLocation(): Observable<any> {
    //    return this.serviceDocument.get("/api/Master/GetStorageLocation");
    //}
    //getManifestFor(): Observable<any> {
    //    return this.serviceDocument.get("/api/Master/GetManifestFor");
    //}
    //getManifestType(): Observable<any> {
    //    return this.serviceDocument.get("/api/Master/GetManifestType");
    //}
    //getStorageType(): Observable<any> {
    //    return this.serviceDocument.get("/api/Master/GetStorageType");
    //} 

}