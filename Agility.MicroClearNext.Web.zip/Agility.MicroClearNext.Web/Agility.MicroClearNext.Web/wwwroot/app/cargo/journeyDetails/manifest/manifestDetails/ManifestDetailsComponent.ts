import { Component, OnInit, ViewChild, TemplateRef } from "@angular/core";
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { ManifestModel } from "../models/ManifestModel";
import { ManifestService } from '../ManifestService';

@Component({
    moduleId: module.id,
  selector: 'app-manifest-details',
  templateUrl: './ManifestDetailsComponent.html',
  styleUrls: ['./ManifestDetailsComponent.css']
})
export class ManifestDetailsComponent implements OnInit {
    public serviceDocument: ServiceDocument<ManifestModel>;
    manifestItem: ManifestModel;
    constructor(private router: Router, private manifestService: ManifestService,
              private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
      this.activatedRoute.data
          .subscribe(() => {
              this.serviceDocument = this.manifestService.serviceDocument;

              this.serviceDocument.dataProfile.dataList.forEach(
                  item => {
                      if (item.manifestfor == 'I') {
                          item.manifestfor = 'Inward';
                      }
                      else {
                          item.manifestfor = 'Transshipment';
                      }
                      if (item.manifestType == 'C') {
                          item.manifestType = 'Cargo';
                      }
                      else {
                          item.manifestType = 'Courier';
                      }
                      if (item.storageType == 'P') {
                          item.storageType = 'Port';
                      }
                      else {
                          item.storageType = 'Warehouse';
                      }
                  });
              console.log(this.serviceDocument);
          });
      this.manifestItem = this.serviceDocument.dataProfile.dataModel;
    //this.router.events.subscribe((evt) => {
    //  if (!(evt instanceof NavigationEnd)) {
    //    return;
    //  }
    //window.scrollTo(0, 0);
    //});
  }

}
