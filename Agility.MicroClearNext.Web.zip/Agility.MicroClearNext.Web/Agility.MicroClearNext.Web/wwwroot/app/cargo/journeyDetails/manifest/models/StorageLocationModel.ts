﻿
import { ProfileModel } from "framework/profile/ProfileModel";

export class StorageLocationModel extends ProfileModel {
    storageLocationId: number;
    code: string;
    name: string;

}