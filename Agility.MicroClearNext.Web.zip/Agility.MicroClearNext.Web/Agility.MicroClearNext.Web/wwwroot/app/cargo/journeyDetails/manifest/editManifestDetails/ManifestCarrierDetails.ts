export interface IManifestCarrierDetails {
  agentName: string;
}
