import { ProfileModel } from "framework/profile/ProfileModel";

export interface CargoTypesModel {
     typeId: number;

     typeTypeId: number;

     name: string;

     description: string;
}
