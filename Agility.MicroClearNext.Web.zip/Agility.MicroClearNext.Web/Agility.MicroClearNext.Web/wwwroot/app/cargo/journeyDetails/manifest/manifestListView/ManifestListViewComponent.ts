import { Component, OnInit, ViewChild, TemplateRef } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { ManifestModel } from "../models/ManifestModel";
import { ManifestService } from '../ManifestService';

@Component({
    moduleId: module.id,
    selector: 'app-manifest-list-view',
    templateUrl: './ManifestListViewComponent.html',
    styleUrls: ['./ManifestListViewComponent.css'],

})
export class ManifestListViewComponent implements OnInit {
    manifestF: any[];
    manifestT: any[];
    storageT: any[];

    columns: any[];
    manifestModel: ManifestModel;
    @ViewChild('editButton') public editTmpl: TemplateRef<ManifestListViewComponent>;
    @ViewChild('editButton1') public editTmpl1: TemplateRef<ManifestListViewComponent>;
    public serviceDocument: ServiceDocument<ManifestModel>;

    manifestList: ManifestModel[];
    errorMessage: string;

    constructor(private manifestService: ManifestService, private _route: ActivatedRoute) {
        this.manifestF = [
            { typeId: 'I', name: 'Inward' }, { typeId: 'T', name: 'Transshipment' }
        ];
        this.manifestT = [
            { typeId: 'C', name: 'Cargo' }, { typeId: 'R', name: 'Courier' }
        ];
        this.storageT = [
            { typeId: 'P', name: 'Port' }, { typeId: 'W', name: 'Warehouse' }
        ];
    }

    ngOnInit() {
        this._route.data
            .subscribe((res) => {
                this.serviceDocument = this.manifestService.serviceDocument;
                this.serviceDocument.dataProfile.dataList.forEach(
                    item => {
                        if (item.manifestfor == 'I') {
                            item.manifestfor = 'Inward';
                        }
                        else {
                            item.manifestfor = 'Transshipment';
                        }
                        if (item.manifestType == 'C') {
                            item.manifestType = 'Cargo';
                        }
                        else {
                            item.manifestType = 'Courier';
                        }
                        if (item.storageType == 'P') {
                            item.storageType = 'Port';
                        }
                        else {
                            item.storageType = 'Warehouse';
                        }

                    });

            });


        //this.autocompleteService.getCurrentResults().subscribe(
        //    value => console.log(value)
        //);
        //this.columns = [
        //    { name: "Manifest No.", prop: "manifestNumber" },
        //    { name: "Manifest For", prop: "journeyId" },
        //    { name: "Shipping Type", prop: "storageType" },
        //   //{ name: "Agent Name", prop: "organizationDetails.organizationName" },
        //    // { name: "Manifest Date", prop: "manifestDate", cellTemplate: this.editTmpl1 },
        //    //{ name: "Status", prop: "workFlowInstance.workflowState.stateName" },
        //    { name: "Actions", prop: "Actions", cellTemplate: this.editTmpl }
        //];
        // this.getManifestList();
        this.manifestList = this.serviceDocument.dataProfile.dataList;
        console.log(this.manifestList);
    }
    open(manifest: ManifestModel): void {
        this.manifestService.open(manifest.manifestId).subscribe();
    }

    //getManifestList() {
    //  this._manifestService.getManifestList()
    //    .subscribe(manifestList => this.manifestList = manifestList,
    //      error => this.errorMessage = <any>error
    //    );
    //}
}
