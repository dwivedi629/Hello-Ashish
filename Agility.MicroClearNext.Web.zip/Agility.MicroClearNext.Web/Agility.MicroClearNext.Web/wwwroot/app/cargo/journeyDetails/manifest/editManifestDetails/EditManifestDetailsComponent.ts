import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { IManifestInfoDetails } from './ManifestInfoDetails';
import { IManifestCarrierDetails } from './ManifestCarrierDetails';
import { Router, ActivatedRoute } from '@angular/router';
import { ManifestModel } from "../models/ManifestModel";
import { CargoTypesModel } from "../models/cargotypemodel";
import { CustomStationModel } from "../models/customstationmodel";
import { OrganizationModel } from "../models/organizationmodel";
import { StorageLocationModel } from "../models/storagelocationmodel";
import { ManifestService } from "../ManifestService";
import { JourneyInfoService } from "../../journeyInfo/Journeyinfoservice";

import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
@Component({
    moduleId: module.id,
    selector: 'app-edit-manifest-details',
    templateUrl: './EditManifestDetailsComponent.html',
    styleUrls: ['./EditManifestDetailsComponent.css'],

})
export class EditManifestDetailsComponent implements OnInit {
    public serviceDocument: ServiceDocument<ManifestModel>;
    public manifestInfoDetailsFormSubmitted: boolean;
    public manifestCarrierDetailsFormSubmitted: boolean;

    //storageLocation: StorageLocationModel[]
    //customStation: CustomStationModel[];
    manifestF: any[];
    manifestT: any[];
    storageT: any[];
    organization: OrganizationModel[];
    showbuttons: boolean=true;

    constructor(private manifestService: ManifestService,
        private journeyInfoService: JourneyInfoService,
        private router: Router,
        private activatedRoute: ActivatedRoute) {
        this.manifestF = [
            { typeId: 'I', name: 'Inward' }, { typeId: 'T', name: 'Transshipment' }
        ];
        this.manifestT = [
            { typeId: '1', name: 'Cargo' }, { typeId: '2', name: 'Courier' }
        ];
        this.storageT = [
            { typeId: 'P', name: 'Port' }, { typeId: 'W', name: 'Warehouse' }
        ];
    }

    ngOnInit() {
        this.activatedRoute.data
            .subscribe(() => {
                this.serviceDocument = this.manifestService.serviceDocument;
                //this.serviceDocument.dataProfile.profileForm.patchValue({ 'journeyNumber': this.journeyInfoService.journeyModel.journeyNumber });
                //console.log(this.serviceDocument);
            });
   
        //this.getCustomStation();
        //this.getStorageLocation();
        //this.getManifestFor();
        //this.getManifestType();
        //this.getStorageType();
    }

    validateIManifestInfoDetailsForm(model: IManifestInfoDetails, isValid: boolean) {
        this.manifestInfoDetailsFormSubmitted = true;
        // check if model is valid
        console.log(model, isValid);
        // this.router.navigate(['/vessel/add-vessel/ship-owner']);
    }

    validateManifestCarrierDetailsForm(model: IManifestCarrierDetails, isValid: boolean) {
        this.manifestCarrierDetailsFormSubmitted = true;

        // check if model is valid
        console.log(model, isValid);
        // this.router.navigate(['/vessel/add-vessel/ship-owner']);
    }
    submitManifest(): void {
        this.serviceDocument.dataProfile.profileForm.patchValue({ 'journeyId': this.journeyInfoService.journeyModel.journeyId });
        this.manifestService.submit().subscribe((result) => {
           // alert("submitted");
            this.serviceDocument.dataProfile.dataModel.manifestNumber = result.dataProfile.dataModel.manifestNumber;
            //this.serviceDocument.dataProfile.dataModel.journey = result.dataProfile.dataModel.journey;
        });
        //this.registrationWizardService.emitStepCompletionStatus(this.route.snapshot.data['stepCount']);
       // this.router.navigate(['../../sbill-of-lading'], { relativeTo: this.activatedRoute });
    }
    save() {
        this.manifestService.save().subscribe(() => {
          alert("saved");
        });
    }  
}
