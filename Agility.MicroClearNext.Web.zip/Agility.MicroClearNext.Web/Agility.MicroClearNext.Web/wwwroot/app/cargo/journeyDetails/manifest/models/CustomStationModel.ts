﻿
import { ProfileModel } from "framework/profile/ProfileModel";

export class CustomStationModel extends ProfileModel {
    customStationId: number;
    stationCode: string;
    stationName: string;
}