export interface IManifest {
  id: number;
  manifestNumber: string;
  status: string;
  statusClass: string;
  manifestDate: string;
  shippingType: string;
  manifestFor: string;
}
