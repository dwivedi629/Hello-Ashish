"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var ManifestService_1 = require("../ManifestService");
var ManifestListViewComponent = (function () {
    function ManifestListViewComponent(manifestService, _route) {
        this.manifestService = manifestService;
        this._route = _route;
        this.manifestF = [
            { typeId: 'I', name: 'Inward' }, { typeId: 'T', name: 'Transshipment' }
        ];
        this.manifestT = [
            { typeId: 'C', name: 'Cargo' }, { typeId: 'R', name: 'Courier' }
        ];
        this.storageT = [
            { typeId: 'P', name: 'Port' }, { typeId: 'W', name: 'Warehouse' }
        ];
    }
    ManifestListViewComponent.prototype.ngOnInit = function () {
        var _this = this;
        this._route.data
            .subscribe(function (res) {
            _this.serviceDocument = _this.manifestService.serviceDocument;
            _this.serviceDocument.dataProfile.dataList.forEach(function (item) {
                if (item.manifestfor == 'I') {
                    item.manifestfor = 'Inward';
                }
                else {
                    item.manifestfor = 'Transshipment';
                }
                if (item.manifestType == 'C') {
                    item.manifestType = 'Cargo';
                }
                else {
                    item.manifestType = 'Courier';
                }
                if (item.storageType == 'P') {
                    item.storageType = 'Port';
                }
                else {
                    item.storageType = 'Warehouse';
                }
            });
        });
        //this.autocompleteService.getCurrentResults().subscribe(
        //    value => console.log(value)
        //);
        //this.columns = [
        //    { name: "Manifest No.", prop: "manifestNumber" },
        //    { name: "Manifest For", prop: "journeyId" },
        //    { name: "Shipping Type", prop: "storageType" },
        //   //{ name: "Agent Name", prop: "organizationDetails.organizationName" },
        //    // { name: "Manifest Date", prop: "manifestDate", cellTemplate: this.editTmpl1 },
        //    //{ name: "Status", prop: "workFlowInstance.workflowState.stateName" },
        //    { name: "Actions", prop: "Actions", cellTemplate: this.editTmpl }
        //];
        // this.getManifestList();
        this.manifestList = this.serviceDocument.dataProfile.dataList;
        console.log(this.manifestList);
    };
    ManifestListViewComponent.prototype.open = function (manifest) {
        this.manifestService.open(manifest.manifestId).subscribe();
    };
    return ManifestListViewComponent;
}());
__decorate([
    core_1.ViewChild('editButton'),
    __metadata("design:type", core_1.TemplateRef)
], ManifestListViewComponent.prototype, "editTmpl", void 0);
__decorate([
    core_1.ViewChild('editButton1'),
    __metadata("design:type", core_1.TemplateRef)
], ManifestListViewComponent.prototype, "editTmpl1", void 0);
ManifestListViewComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'app-manifest-list-view',
        templateUrl: './ManifestListViewComponent.html',
        styleUrls: ['./ManifestListViewComponent.css'],
    }),
    __metadata("design:paramtypes", [ManifestService_1.ManifestService, router_1.ActivatedRoute])
], ManifestListViewComponent);
exports.ManifestListViewComponent = ManifestListViewComponent;
//# sourceMappingURL=ManifestListViewComponent.js.map