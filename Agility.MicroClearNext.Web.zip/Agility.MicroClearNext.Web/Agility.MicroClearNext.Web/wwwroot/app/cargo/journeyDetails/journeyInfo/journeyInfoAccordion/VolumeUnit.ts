import { ProfileModel } from "framework/profile/ProfileModel";

export class VolumeUnitModel extends ProfileModel {

    volumeUnitId: number;
    unitName: string;
}