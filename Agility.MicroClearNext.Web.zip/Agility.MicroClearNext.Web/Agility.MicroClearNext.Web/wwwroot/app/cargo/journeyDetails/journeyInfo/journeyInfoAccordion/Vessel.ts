import { ProfileModel } from "framework/profile/ProfileModel";

export class VesselModel extends ProfileModel {

    vesselId: number;
    vesselName: string;
    vesselNumber: string;
}