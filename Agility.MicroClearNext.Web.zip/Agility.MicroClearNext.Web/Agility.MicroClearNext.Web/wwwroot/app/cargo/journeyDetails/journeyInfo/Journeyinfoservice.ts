﻿/// <reference path="journeyinfoaccordion/journeyinfo.ts" />
import { Injectable } from "@angular/core";
import { Http, Response, RequestOptions, URLSearchParams } from "@angular/http";
import { Observable } from "rxjs/Observable";
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { JourneyInfo } from "./journeyInfoAccordion/JourneyInfo";

@Injectable()
export class JourneyInfoService
{
    serviceDocument: ServiceDocument<JourneyInfo> = new ServiceDocument<JourneyInfo>();
    journeyModel: JourneyInfo;
    constructor(private http: Http) { }

    list(): Observable<ServiceDocument<JourneyInfo>> {
        //debugger;
        //  this.serviceDocument.http.fxContext.IsAuthenticated = true;
        return this.serviceDocument.list("/api/Cargo/ListOfJourney");
    }

    new(): Observable<ServiceDocument<JourneyInfo>> {     
        return this.serviceDocument.new("/api/Cargo/NewJourney");
    }

    view(id: number): Observable<ServiceDocument<JourneyInfo>> {
        return this.serviceDocument.view("/api/Cargo/OpenJourney", new URLSearchParams("id=" + id));
    }

    open(id: number): Observable<ServiceDocument<JourneyInfo>> {
        return this.serviceDocument.open("/api/Cargo/OpenJourney", new URLSearchParams("id=" + id));
    }

    delete(): Observable<ServiceDocument<JourneyInfo>> {
        return this.serviceDocument.delete("/api/Cargo/Delete");
    }

    save(): Observable<ServiceDocument<JourneyInfo>> {
        return this.serviceDocument.save("/api/Cargo/SaveJourney");
    }

    submit(): Observable<ServiceDocument<JourneyInfo>> {
        return this.serviceDocument.submit("/api/Cargo/SubmitJourney");
    }

    getLocations(): Observable<any> {
        return this.serviceDocument.get("/api/Master/GetLocation");
    }

    getCustomstation(): Observable<any> {
        return this.serviceDocument.get("/api/Master/GetCustomStation");
    }


}