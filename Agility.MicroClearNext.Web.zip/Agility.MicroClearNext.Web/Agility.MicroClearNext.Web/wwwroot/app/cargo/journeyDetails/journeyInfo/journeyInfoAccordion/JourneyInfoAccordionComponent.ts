import {Component, OnInit} from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { JourneyInfo } from './JourneyInfo';
import {Router, ActivatedRoute, NavigationEnd} from '@angular/router';
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { JourneyInfoService } from "../Journeyinfoservice";

@Component({
    moduleId: module.id,
  selector: 'app-journey-info-accordion',
  templateUrl: './JourneyInfoAccordionComponent.html',
  styleUrls: ['./JourneyInfoAccordionComponent.css']
})
export class JourneyInfoAccordionComponent implements OnInit {
    public monthsArray = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    public journeyInfoFormSubmitted: boolean;
    public toggleName = 'Show More';
    public showMoreCarrierDetails: boolean = false;
    public toggleClass = 'icon-down-caret';

    public serviceDocument: ServiceDocument<JourneyInfo>;
    public carriers: any = [
        {
            value: 'carrier-1',
            viewValue: 'Carrier 1'
        },
        {
            value: 'carrier-2',
            viewValue: 'Carrier 2'
        }
    ];

    constructor(
        private router: Router,
        private activatedRoute: ActivatedRoute,
        public service: JourneyInfoService) { }

    onTimeChange(event, input) {
        console.log(input, 'Time value:::', event);
    } 

    handleToggle() {
        if (this.toggleName === 'Show More') {
            this.toggleName = 'Show Less';
            this.showMoreCarrierDetails = true;
            this.toggleClass = 'icon-up-caret';
        } else {
            this.toggleName = 'Show More';
            this.showMoreCarrierDetails = false;
            this.toggleClass = 'icon-down-caret';
        }
    }

    ngOnInit() {
        this.activatedRoute.data.subscribe(() => {
            this.serviceDocument = this.service.serviceDocument,
                console.log(this.serviceDocument);
        });

    }

    validateJourneyInfoForm(model: JourneyInfo, isValid: boolean) {
        this.journeyInfoFormSubmitted = true; // set form submit to true
    }

    submitJourneyInfo() {
        this.service.submit()
            .subscribe(() => {
                alert("submitted");
                this.router.navigate(['../manifest/manifest-list-view'], { relativeTo: this.activatedRoute });
            });
    }

    cancel() {
        this.router.navigate(["/Journey"]);
        return false;
    }
}
