import { ProfileModel } from "framework/profile/ProfileModel";

export class CustomStationModel extends ProfileModel {

    customStationId: number;
    stationName: string;
}