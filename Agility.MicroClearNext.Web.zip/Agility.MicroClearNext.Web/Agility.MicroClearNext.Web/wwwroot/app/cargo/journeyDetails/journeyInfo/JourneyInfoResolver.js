"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var Journeyinfoservice_1 = require("./Journeyinfoservice");
var JourneyInfoListResolver = (function () {
    function JourneyInfoListResolver(service) {
        this.service = service;
    }
    JourneyInfoListResolver.prototype.resolve = function (route) {
        return this.service.list();
    };
    return JourneyInfoListResolver;
}());
JourneyInfoListResolver = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [Journeyinfoservice_1.JourneyInfoService])
], JourneyInfoListResolver);
exports.JourneyInfoListResolver = JourneyInfoListResolver;
var JourneyInfoNewResolver = (function () {
    function JourneyInfoNewResolver(service) {
        this.service = service;
    }
    JourneyInfoNewResolver.prototype.resolve = function () {
        return this.service.new();
    };
    return JourneyInfoNewResolver;
}());
JourneyInfoNewResolver = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [Journeyinfoservice_1.JourneyInfoService])
], JourneyInfoNewResolver);
exports.JourneyInfoNewResolver = JourneyInfoNewResolver;
var JourneyInfoOpenResolver = (function () {
    function JourneyInfoOpenResolver(service) {
        this.service = service;
    }
    JourneyInfoOpenResolver.prototype.resolve = function (route) {
        return this.service.open(route.params["id"]);
    };
    return JourneyInfoOpenResolver;
}());
JourneyInfoOpenResolver = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [Journeyinfoservice_1.JourneyInfoService])
], JourneyInfoOpenResolver);
exports.JourneyInfoOpenResolver = JourneyInfoOpenResolver;
//# sourceMappingURL=JourneyInfoResolver.js.map