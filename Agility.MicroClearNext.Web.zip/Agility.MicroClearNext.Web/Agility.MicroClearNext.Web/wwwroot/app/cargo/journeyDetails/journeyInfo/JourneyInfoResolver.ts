﻿import { Injectable } from "@angular/core";
import { Resolve, ActivatedRouteSnapshot } from "@angular/router";
import { Observable } from "rxjs/Observable";
import { JourneyInfoService } from "./Journeyinfoservice";
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { JourneyInfo } from "./journeyInfoAccordion/JourneyInfo";

@Injectable()
export class JourneyInfoListResolver implements Resolve<ServiceDocument<JourneyInfo>> {
    constructor(private service: JourneyInfoService) { }

    resolve(route: ActivatedRouteSnapshot): Observable<ServiceDocument<JourneyInfo>> {
        return this.service.list();
    }
}

@Injectable()
export class JourneyInfoNewResolver implements Resolve<ServiceDocument<JourneyInfo>> {
    constructor(private service: JourneyInfoService) { }

    resolve(): Observable<ServiceDocument<JourneyInfo>> {
        return this.service.new();
    }
}

@Injectable()
export class JourneyInfoOpenResolver implements Resolve<ServiceDocument<JourneyInfo>> {
    constructor(private service: JourneyInfoService) { }

    resolve(route: ActivatedRouteSnapshot): Observable<ServiceDocument<JourneyInfo>> {
        return this.service.open(route.params["id"]);
    }
}
