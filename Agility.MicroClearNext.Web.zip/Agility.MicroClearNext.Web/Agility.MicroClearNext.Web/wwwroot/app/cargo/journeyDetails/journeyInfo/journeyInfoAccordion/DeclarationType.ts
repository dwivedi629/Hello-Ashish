import { ProfileModel } from "framework/profile/ProfileModel";

export class DeclarationTypeModel extends ProfileModel {

    typeId: number;
    typeTypeId: number;
    name: string;
}