﻿import { ProfileModel } from "framework/profile/ProfileModel";

export class LocationModel extends ProfileModel {
    locationId: number;
    locationTypeId: number;
    name: string;
    locationCode: string;
   }
   

      
       
  