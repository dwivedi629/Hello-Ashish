/// <reference path="journeyinfoaccordion/journeyinfo.ts" />
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { JourneyInfo } from './journeyInfoAccordion/JourneyInfo';
import { JourneyInfoService } from "./Journeyinfoservice";

@Component({
    moduleId: module.id,
  selector: 'app-journey-info',
  templateUrl: './JourneyInfoComponent.html',
  styleUrls: ['./JourneyInfoComponent.css']
})
export class JourneyInfoComponent implements OnInit {
    journeydetail: JourneyInfo;
    public serviceDocument: ServiceDocument<JourneyInfo>;

    constructor(public service: JourneyInfoService, private route: ActivatedRoute) { }

    ngOnInit() {
        this.route.data
            .subscribe((res) => {
                this.serviceDocument = this.service.serviceDocument;
                console.log(this.serviceDocument);
            });
        this.journeydetail = this.serviceDocument.dataProfile.dataModel;
    }

}
