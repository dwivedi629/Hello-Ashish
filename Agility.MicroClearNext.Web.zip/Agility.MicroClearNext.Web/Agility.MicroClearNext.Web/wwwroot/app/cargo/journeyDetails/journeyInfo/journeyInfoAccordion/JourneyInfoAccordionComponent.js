"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var Journeyinfoservice_1 = require("../Journeyinfoservice");
var JourneyInfoAccordionComponent = (function () {
    function JourneyInfoAccordionComponent(router, activatedRoute, service) {
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.service = service;
        this.monthsArray = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        this.toggleName = 'Show More';
        this.showMoreCarrierDetails = false;
        this.toggleClass = 'icon-down-caret';
        this.carriers = [
            {
                value: 'carrier-1',
                viewValue: 'Carrier 1'
            },
            {
                value: 'carrier-2',
                viewValue: 'Carrier 2'
            }
        ];
    }
    JourneyInfoAccordionComponent.prototype.onTimeChange = function (event, input) {
        console.log(input, 'Time value:::', event);
    };
    JourneyInfoAccordionComponent.prototype.handleToggle = function () {
        if (this.toggleName === 'Show More') {
            this.toggleName = 'Show Less';
            this.showMoreCarrierDetails = true;
            this.toggleClass = 'icon-up-caret';
        }
        else {
            this.toggleName = 'Show More';
            this.showMoreCarrierDetails = false;
            this.toggleClass = 'icon-down-caret';
        }
    };
    JourneyInfoAccordionComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.activatedRoute.data.subscribe(function () {
            _this.serviceDocument = _this.service.serviceDocument,
                console.log(_this.serviceDocument);
        });
    };
    JourneyInfoAccordionComponent.prototype.validateJourneyInfoForm = function (model, isValid) {
        this.journeyInfoFormSubmitted = true; // set form submit to true
    };
    JourneyInfoAccordionComponent.prototype.submitJourneyInfo = function () {
        var _this = this;
        this.service.submit()
            .subscribe(function () {
            alert("submitted");
            _this.router.navigate(['../manifest/manifest-list-view'], { relativeTo: _this.activatedRoute });
        });
    };
    JourneyInfoAccordionComponent.prototype.cancel = function () {
        this.router.navigate(["/Journey"]);
        return false;
    };
    return JourneyInfoAccordionComponent;
}());
JourneyInfoAccordionComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'app-journey-info-accordion',
        templateUrl: './JourneyInfoAccordionComponent.html',
        styleUrls: ['./JourneyInfoAccordionComponent.css']
    }),
    __metadata("design:paramtypes", [router_1.Router,
        router_1.ActivatedRoute,
        Journeyinfoservice_1.JourneyInfoService])
], JourneyInfoAccordionComponent);
exports.JourneyInfoAccordionComponent = JourneyInfoAccordionComponent;
//# sourceMappingURL=JourneyInfoAccordionComponent.js.map