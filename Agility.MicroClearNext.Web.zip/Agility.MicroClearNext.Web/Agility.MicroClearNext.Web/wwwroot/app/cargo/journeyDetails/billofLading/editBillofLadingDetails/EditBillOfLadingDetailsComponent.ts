import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { BillOfLadingInfo } from './BillOfLadingInfo';
import { Router, ActivatedRoute } from '@angular/router';

import { RegistrationWizardService } from '../../../../account/registration/registrationWizard/registrationWizardService';

@Component({
    moduleId: module.id,
    selector: 'app-edit-bill-of-lading-details',
    templateUrl: './EditBillOfLadingDetailsComponent.html',
    styleUrls: ['./EditBillOfLadingDetailsComponent.css']
})
export class EditBillOfLadingDetailsComponent implements OnInit {
    public billOfLadingForm: FormGroup;
    public billOfLadingFormSubmitted: boolean;

    constructor(private _fb: FormBuilder,
        private router: Router,
        private activatedRoute: ActivatedRoute,
        private registrationWizardService: RegistrationWizardService) { }

    ngOnInit() {
        this.billOfLadingForm = this._fb.group({
            gManifestInfo: ['', [<any>Validators.required]],
            gUniqueBLNo: ['', [<any>Validators.required]],
            gblDate: ['', [<any>Validators.required]],
            blCreationDate: ['', [<any>Validators.required]],
            carrierDate: ['', [<any>Validators.required]],
            refBLNo: ['', [<any>Validators.required]],
            blFor: ['', [<any>Validators.required]],
            billFor: ['', [<any>Validators.required]],
            nocNo: ['', [<any>Validators.required]],
            agentName: ['', [<any>Validators.required]],
            manifestYear: ['', [<any>Validators.required]],
            manifestStatus: ['', [<any>Validators.required]],
            vesselIdentificationNo: ['', [<any>Validators.required]],
            blStatus: ['', [<any>Validators.required]],
            shipCallNum: ['', [<any>Validators.required]],
            shipAgentCode: ['', [<any>Validators.required]],
            blDTDateAndTime: this._fb.group({
                blDTDate: ['', [<any>Validators.required]],
                blDTTime: ['', [<any>Validators.required]]
            }),
            customsStationCode: ['', [<any>Validators.required]],
            processingIndicator: ['', [<any>Validators.required]],
            languageIndicator: ['', [<any>Validators.required]],
            manifestInfo: ['', [<any>Validators.required]],
            uniqueBLNo: ['', [<any>Validators.required]],
            bblDate: ['', [<any>Validators.required]]
        });
    }

    onDateChange(event, input) {
        if (input === 'gblDate') {
            this.billOfLadingForm.controls['gblDate'].patchValue(event);
        } if (input === 'blDate') {
            this.billOfLadingForm.controls['blDate'].patchValue(event);
        } if (input === 'dDate') {
            this.billOfLadingForm.controls['dDate'].patchValue(event);
        } if (input === 'carrierDate') {
            this.billOfLadingForm.controls['carrierDate'].patchValue(event);
        } if (input === 'blDTDate') {
            (<FormGroup>this.billOfLadingForm.controls['blDTDateAndTime']).controls['blDTDate'].patchValue(event);
        } if (input === 'bblDate') {
            this.billOfLadingForm.controls['bblDate'].patchValue(event);
        }
    }

    validateBillOfLadingForm(model: BillOfLadingInfo, isValid: boolean) {
        this.billOfLadingFormSubmitted = true; // set form submit to true

        // check if model is valid
        console.log(model, isValid);
        // this.router.navigate(['/vessel/add-vessel/ship-owner']);
    }

    submitBillOfLading() {
        this.registrationWizardService.emitStepCompletionStatus(this.activatedRoute.snapshot.data['stepCount']);
        this.router.navigate(['../bill-of-lading/bill-of-lading-list-view'], { relativeTo: this.activatedRoute });
    }
}
