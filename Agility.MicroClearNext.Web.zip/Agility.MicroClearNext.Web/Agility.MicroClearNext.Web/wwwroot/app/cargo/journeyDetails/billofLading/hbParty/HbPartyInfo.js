"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var HbPartyInfo = (function () {
    function HbPartyInfo() {
    }
    return HbPartyInfo;
}());
exports.HbPartyInfo = HbPartyInfo;
//# sourceMappingURL=HbPartyInfo.js.map