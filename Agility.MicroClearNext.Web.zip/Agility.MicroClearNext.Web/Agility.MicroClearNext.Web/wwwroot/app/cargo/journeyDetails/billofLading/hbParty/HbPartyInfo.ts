﻿export class HbPartyInfo {
    consigneeRegistered: string;
    consigneeFreeText: string;
    consigneeCode: string;
    consigneeName: string;
    consigneeEmailId: string;
    consigneeMobileNum: {
        code: string;
        number: string;
    };
    consigneeAddressCountry: string;
    consigneeAddress: string;
    consigneeCountry: string;
    consigneePostalCode: string;
    consigneeState: string;
    consigneeCityTownAreaLand: string;
    notifyPartySameAsConsignee: string;
    notifyParty: string;
    notifyPartyCode: string;
    notifyPartyEmailId: string;
    notifyPartyMobileNum: {
        code: string;
        number: string;
    };
    notifyPartyCountrySubEntityName: string;
    notifyPartyAddress: string;
    notifyPartyCountry: string;
    notifyPartyPostalCode: string;
    notifyPartyState: string;
    notifyPartyCityTownAreaLand: string;
    shipper: string;
    shipperMarks: string;
    shipperEmailId: string;
    shipperMobileNum: {
        code: string;
        number: string;
    };
    shipperAddress: string;
    shipperCountry: string;
    shipperPostalCode: string;
    shipperState: string;
    shipperCityTownAreaLand: string;
}
