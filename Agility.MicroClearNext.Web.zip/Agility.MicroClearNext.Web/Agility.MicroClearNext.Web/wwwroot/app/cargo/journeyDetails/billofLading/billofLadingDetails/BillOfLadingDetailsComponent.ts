import { Component, OnInit } from '@angular/core';
import { RegistrationWizardService } from '../../../../account/registration/registrationWizard/registrationWizardService';

@Component({
    moduleId: module.id,
  selector: 'app-bill-of-lading-details',
  templateUrl: './BillOfLadingDetailsComponent.html',
  styleUrls: ['./BillOfLadingDetailsComponent.css']
})
export class BillOfLadingDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
