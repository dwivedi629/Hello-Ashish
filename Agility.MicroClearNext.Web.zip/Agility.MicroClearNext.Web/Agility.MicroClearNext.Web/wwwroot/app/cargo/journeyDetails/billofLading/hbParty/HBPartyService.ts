﻿import { Injectable } from "@angular/core";
import { Http, Response, RequestOptions, URLSearchParams } from "@angular/http";
import { Observable } from "rxjs/Observable";
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { HBPartyModel} from "./HBParty"

@Injectable()
export class HBPartyService {
    serviceDocument: ServiceDocument<HBPartyModel> = new ServiceDocument<HBPartyModel>();

    constructor() { }

    list(): Observable<ServiceDocument<HBPartyModel>> {
        return this.serviceDocument.list("/api/Manifest/List");
    }

    new(): Observable<ServiceDocument<HBPartyModel>> {

        var test = this.serviceDocument.new("/api/Cargo/ManifestNew");
        return test;
    }

    view(id: number): Observable<ServiceDocument<HBPartyModel>> {
        return this.serviceDocument.view("/api/Cargo/ManifestOpen", new URLSearchParams("id=" + id));
    }

    open(id: number): Observable<ServiceDocument<HBPartyModel>> {
        return this.serviceDocument.open("/api/Cargo/ManifestOpen", new URLSearchParams("id=" + id));
    }

    delete(): Observable<ServiceDocument<HBPartyModel>> {
        return this.serviceDocument.delete("/api/Cargo/ManifestDelete");
    }

    save(): Observable<ServiceDocument<HBPartyModel>> {
        return this.serviceDocument.save("/api/Manifest/Save");
    }

    submit(): Observable<ServiceDocument<HBPartyModel>> {
        return this.serviceDocument.submit("/api/Cargo/ManifestSubmit");
    }


    
}