import { Component, OnInit } from '@angular/core';
import { IBol } from './BillOfLading';
import { BolService } from './BillOfLadingService';
import { RegistrationWizardService } from '../../../account/registration/registrationWizard/registrationWizardService';


@Component({
    moduleId: module.id,
    selector: 'app-bill-of-lading',
    templateUrl: './BillOfLadingComponent.html',
    styleUrls: ['./BillOfLadingComponent.css'],
    providers: [BolService]
})
export class BillOfLadingComponent implements OnInit {

    bolList: IBol[] = [
        {
            'id': 1,
            'bolNumber': 'Bill001',
            'status': 'submitted',
            'statusClass': 'submitted',
            'bolDate': '26 Mar,2017',
            'splitted': 'No',
            'qty': '200'
        },
        {
            'id': 2,
            'bolNumber': 'Bill002',
            'status': 'approved',
            'statusClass': 'approved',
            'bolDate': '26 Mar,2017',
            'splitted': 'No',
            'qty': '200'
        },
        {
            'id': 3,
            'bolNumber': 'Bill003',
            'status': 'submitted',
            'statusClass': 'submitted',
            'bolDate': '26 Mar,2017',
            'splitted': 'No',
            'qty': '200'
        },
        {
            'id': 4,
            'bolNumber': 'Bill004',
            'status': 'submitted',
            'statusClass': 'submitted',
            'bolDate': '26 Mar,2017',
            'splitted': 'Yes',
            'qty': '200'
        },
        {
            'id': 5,
            'bolNumber': 'Bill005',
            'status': 'approved',
            'statusClass': 'approved',
            'bolDate': '26 Mar,2017',
            'splitted': 'No',
            'qty': '200'
        },
        {
            'id': 6,
            'bolNumber': 'Bill006',
            'status': 'submitted',
            'statusClass': 'submitted',
            'bolDate': '26 Mar,2017',
            'splitted': 'No',
            'qty': '200'
        },
        {
            'id': 7,
            'bolNumber': 'Bill007',
            'status': 'submitted',
            'statusClass': 'submitted',
            'bolDate': '26 Mar,2017',
            'splitted': 'No',
            'qty': '200'
        },
        {
            'id': 8,
            'bolNumber': 'Bill008',
            'status': 'approved',
            'statusClass': 'approved',
            'bolDate': '26 Mar,2017',
            'splitted': 'No',
            'qty': '200'
        },
        {
            'id': 9,
            'bolNumber': 'Bill009',
            'status': 'submitted',
            'statusClass': 'submitted',
            'bolDate': '26 Mar,2017',
            'splitted': 'No',
            'qty': '200'
        },
        {
            'id': 10,
            'bolNumber': 'Bill010',
            'status': 'submitted',
            'statusClass': 'submitted',
            'bolDate': '26 Mar,2017',
            'splitted': 'No',
            'qty': '200'
        }
    ];
    errorMessage: string;

    constructor(private _bolService: BolService) { }

    ngOnInit() {
        // this.getManifestList();
    }
}
