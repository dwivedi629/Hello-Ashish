export interface IShipperDetails {
  shipper: string;
  shipperMarks: string;
  emailId: string;
  mobileNum: {
    code: string;
    number: string;
  };
  address: string;
  country: string;
  postalCode: string;
  state: string;
  cityTownAreaLand: string;
}
