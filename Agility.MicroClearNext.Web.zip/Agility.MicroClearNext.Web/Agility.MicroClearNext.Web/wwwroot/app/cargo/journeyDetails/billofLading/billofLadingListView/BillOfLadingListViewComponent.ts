import { Component, OnInit } from '@angular/core';
import {FormGroup, FormBuilder, Validators} from '@angular/forms';
import { IBol } from '../BillOfLading';
import { IBLData } from './BillLadingData';
import { BolService } from '../BillOfLadingService';
import { RegistrationWizardService } from '../../../../account/registration/registrationWizard/registrationWizardService';

@Component({
    moduleId: module.id,
  selector: 'app-bill-of-lading-list-view',
  templateUrl: './BillOfLadingListViewComponent.html',
  styleUrls: ['./BillOfLadingListViewComponent.css']
})
export class BillOfLadingListViewComponent implements OnInit {
  public blListForm: FormGroup;
  public blListFormSubmitted: boolean;

  bolList: IBol[] = [
    {
      'id':  1,
      'bolNumber': 'Bill001',
      'status': 'Submitted',
      'statusClass': 'submitted',
      'bolDate': '26 Mar,2017',
      'splitted': 'No',
      'qty': '200'
    },
    {
      'id':  2,
      'bolNumber': 'Bill002',
      'status': 'Approved',
      'statusClass': 'approved',
      'bolDate': '26 Mar,2017',
      'splitted': 'No',
      'qty': '200'
    },
    {
      'id':  3,
      'bolNumber': 'Bill003',
      'status': 'Submitted',
      'statusClass': 'submitted',
      'bolDate': '26 Mar,2017',
      'splitted': 'No',
      'qty': '200'
    },
    {
      'id':  4,
      'bolNumber': 'Bill004',
      'status': 'Submitted',
      'statusClass': 'submitted',
      'bolDate': '26 Mar,2017',
      'splitted': 'Yes',
      'qty': '200'
    },
    {
      'id':  5,
      'bolNumber': 'Bill005',
      'status': 'Approved',
      'statusClass': 'approved',
      'bolDate': '26 Mar,2017',
      'splitted': 'No',
      'qty': '200'
    },
    {
      'id':  6,
      'bolNumber': 'Bill006',
      'status': 'Submitted',
      'statusClass': 'submitted',
      'bolDate': '26 Mar,2017',
      'splitted': 'No',
      'qty': '200'
    },
    {
      'id':  7,
      'bolNumber': 'Bill007',
      'status': 'Submitted',
      'statusClass': 'submitted',
      'bolDate': '26 Mar,2017',
      'splitted': 'No',
      'qty': '200'
    },
    {
      'id':  8,
      'bolNumber': 'Bill008',
      'status': 'Approved',
      'statusClass': 'approved',
      'bolDate': '26 Mar,2017',
      'splitted': 'No',
      'qty': '200'
    },
    {
      'id':  9,
      'bolNumber': 'Bill009',
      'status': 'Submitted',
      'statusClass': 'submitted',
      'bolDate': '26 Mar,2017',
      'splitted': 'No',
      'qty': '200'
    },
    {
      'id':  10,
      'bolNumber': 'Bill010',
      'status': 'Submitted',
      'statusClass': 'submitted',
      'bolDate': '26 Mar,2017',
      'splitted': 'No',
      'qty': '200'
    }
  ];
  errorMessage: string;

  constructor(private _fb: FormBuilder, private _bolService: BolService) { }

  ngOnInit() {
    // this.getBolList();
    this.blListForm = this._fb.group({
      blNo: ['', [<any>Validators.required]],
      status: ['', [<any>Validators.required]]
    });
  }

  validateBLListForm(model: IBLData, isValid: boolean) {
    this.blListFormSubmitted = true; // set form submit to true

    // check if model is valid
    console.log(model, isValid);
    // this.router.navigate(['/vessel/add-vessel/ship-owner']);
  }

  specificBLOptionPropagation(event) {
    event.stopPropagation();
  }

}
