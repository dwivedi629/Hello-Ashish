export interface IGeneralInfo {
  manifestInfo: string;
  uniqueBLNo: string;
  blDate: string;
  blCreationDate: string;
  carrierDate: string;
  refBLNo: string;
  blFor: string;
  billFor: string;
  nocNo: string;
  agentName: string;
  manifestYear: string;
  manifestStatus: string;
  vesselIdentificationNo: string;
  blStatus: string;
  shipCallNum: string;
  shipAgentCode: string;
  blDTDateAndTime: {
    blDTDate: string;
    blDTTime: string;
  };
  customsStationCode: string;
  processingIndicator: string;
  languageIndicator: string;
}
