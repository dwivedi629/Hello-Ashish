"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
var ServiceDocument_1 = require("framework/servicedocument/ServiceDocument");
var HBPartyService = (function () {
    function HBPartyService() {
        this.serviceDocument = new ServiceDocument_1.ServiceDocument();
    }
    HBPartyService.prototype.list = function () {
        return this.serviceDocument.list("/api/Manifest/List");
    };
    HBPartyService.prototype.new = function () {
        var test = this.serviceDocument.new("/api/Cargo/ManifestNew");
        return test;
    };
    HBPartyService.prototype.view = function (id) {
        return this.serviceDocument.view("/api/Cargo/ManifestOpen", new http_1.URLSearchParams("id=" + id));
    };
    HBPartyService.prototype.open = function (id) {
        return this.serviceDocument.open("/api/Cargo/ManifestOpen", new http_1.URLSearchParams("id=" + id));
    };
    HBPartyService.prototype.delete = function () {
        return this.serviceDocument.delete("/api/Cargo/ManifestDelete");
    };
    HBPartyService.prototype.save = function () {
        return this.serviceDocument.save("/api/Manifest/Save");
    };
    HBPartyService.prototype.submit = function () {
        return this.serviceDocument.submit("/api/Cargo/ManifestSubmit");
    };
    return HBPartyService;
}());
HBPartyService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [])
], HBPartyService);
exports.HBPartyService = HBPartyService;
//# sourceMappingURL=HBPartyService.js.map