export interface INotifyPartyDetails {
  notifyPartySameAsConsignee: string;
  notifyParty: string;
  notifyPartyCode: string;
  emailId: string;
  mobileNum: {
    code: string;
    number: string;
  };
  notifyPartyCountrySubEntityName: string;
  address: string;
  country: string;
  postalCode: string;
  state: string;
  cityTownAreaLand: string;
}
