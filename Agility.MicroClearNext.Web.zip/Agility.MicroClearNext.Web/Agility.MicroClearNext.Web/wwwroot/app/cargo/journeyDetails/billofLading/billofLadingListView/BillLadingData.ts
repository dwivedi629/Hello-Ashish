export interface IBLData {
  blNo: string;
  status: string;
}
