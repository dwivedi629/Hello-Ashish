"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var BillOfLadingService_1 = require("./BillOfLadingService");
var BillOfLadingComponent = (function () {
    function BillOfLadingComponent(_bolService) {
        this._bolService = _bolService;
        this.bolList = [
            {
                'id': 1,
                'bolNumber': 'Bill001',
                'status': 'submitted',
                'statusClass': 'submitted',
                'bolDate': '26 Mar,2017',
                'splitted': 'No',
                'qty': '200'
            },
            {
                'id': 2,
                'bolNumber': 'Bill002',
                'status': 'approved',
                'statusClass': 'approved',
                'bolDate': '26 Mar,2017',
                'splitted': 'No',
                'qty': '200'
            },
            {
                'id': 3,
                'bolNumber': 'Bill003',
                'status': 'submitted',
                'statusClass': 'submitted',
                'bolDate': '26 Mar,2017',
                'splitted': 'No',
                'qty': '200'
            },
            {
                'id': 4,
                'bolNumber': 'Bill004',
                'status': 'submitted',
                'statusClass': 'submitted',
                'bolDate': '26 Mar,2017',
                'splitted': 'Yes',
                'qty': '200'
            },
            {
                'id': 5,
                'bolNumber': 'Bill005',
                'status': 'approved',
                'statusClass': 'approved',
                'bolDate': '26 Mar,2017',
                'splitted': 'No',
                'qty': '200'
            },
            {
                'id': 6,
                'bolNumber': 'Bill006',
                'status': 'submitted',
                'statusClass': 'submitted',
                'bolDate': '26 Mar,2017',
                'splitted': 'No',
                'qty': '200'
            },
            {
                'id': 7,
                'bolNumber': 'Bill007',
                'status': 'submitted',
                'statusClass': 'submitted',
                'bolDate': '26 Mar,2017',
                'splitted': 'No',
                'qty': '200'
            },
            {
                'id': 8,
                'bolNumber': 'Bill008',
                'status': 'approved',
                'statusClass': 'approved',
                'bolDate': '26 Mar,2017',
                'splitted': 'No',
                'qty': '200'
            },
            {
                'id': 9,
                'bolNumber': 'Bill009',
                'status': 'submitted',
                'statusClass': 'submitted',
                'bolDate': '26 Mar,2017',
                'splitted': 'No',
                'qty': '200'
            },
            {
                'id': 10,
                'bolNumber': 'Bill010',
                'status': 'submitted',
                'statusClass': 'submitted',
                'bolDate': '26 Mar,2017',
                'splitted': 'No',
                'qty': '200'
            }
        ];
    }
    BillOfLadingComponent.prototype.ngOnInit = function () {
        // this.getManifestList();
    };
    return BillOfLadingComponent;
}());
BillOfLadingComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'app-bill-of-lading',
        templateUrl: './BillOfLadingComponent.html',
        styleUrls: ['./BillOfLadingComponent.css'],
        providers: [BillOfLadingService_1.BolService]
    }),
    __metadata("design:paramtypes", [BillOfLadingService_1.BolService])
], BillOfLadingComponent);
exports.BillOfLadingComponent = BillOfLadingComponent;
//# sourceMappingURL=BillOfLadingComponent.js.map