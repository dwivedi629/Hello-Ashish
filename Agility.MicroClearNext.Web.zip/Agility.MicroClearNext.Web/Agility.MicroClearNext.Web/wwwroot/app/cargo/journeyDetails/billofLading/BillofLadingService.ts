import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, URLSearchParams } from "@angular/http";

import { Observable } from 'rxjs/Rx';
//import 'rxjs/Rx';
import { HouseBillModel } from './BillOfLading';
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";

@Injectable ()
export class BolService {
    public serviceDocument: ServiceDocument<HouseBillModel> = new ServiceDocument<HouseBillModel>();
  constructor() {};
  list(): Observable<ServiceDocument<HouseBillModel>> {
      return this.serviceDocument.list("/api/Cargo/ListOfHouseBill");
  }

  new(): Observable<ServiceDocument<HouseBillModel>> {
      return this.serviceDocument.new("/api/Cargo/NewOfHouseBill");
  }
  open(id: number): Observable<ServiceDocument<HouseBillModel>> {
      return this.serviceDocument.open("/api/Cargo/OpenOfHouseBil", new URLSearchParams("id=" + id));
  }

  delete(): Observable<ServiceDocument<HouseBillModel>> {
      return this.serviceDocument.delete("/api/Cargo/DeleteHouseBill");
  }

  save(): Observable<ServiceDocument<HouseBillModel>> {
      return this.serviceDocument.save("/api/Cargo/SaveHouseBill");
  }

  submit(): Observable<ServiceDocument<HouseBillModel>> {
      return this.serviceDocument.submit("/api/Cargo/SubmitHouseBill");
  }
}
