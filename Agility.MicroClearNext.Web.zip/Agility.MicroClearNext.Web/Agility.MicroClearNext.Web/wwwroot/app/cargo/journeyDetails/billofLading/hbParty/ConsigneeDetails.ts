export interface IConsigneeDetails {
  consigneeRegistered: string;
  consigneeFreeText: string;
  consigneeCode: string;
  consigneeName: string;
  emailId: string;
  mobileNum: {
    code: string;
    number: string;
  };
  consigneeAddressCountry: string;
  address: string;
  country: string;
  postalCode: string;
  state: string;
  cityTownAreaLand: string;
}
