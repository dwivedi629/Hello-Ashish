﻿import { Injectable } from "@angular/core";
import { Resolve, ActivatedRouteSnapshot } from "@angular/router";

import { Observable } from "rxjs/Observable";

import { BolService } from "./BillofLadingService";
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { HouseBillModel } from './BillOfLading';

@Injectable()
export class HouseBillListResolver implements Resolve<ServiceDocument<HouseBillModel>> {
    constructor(private service: BolService) { }

    resolve(route: ActivatedRouteSnapshot): Observable<ServiceDocument<HouseBillModel>> {
        return this.service.list();
    }
}

@Injectable()
export class HouseBillNewResolver implements Resolve<ServiceDocument<HouseBillModel>> {
    constructor(private service: BolService) { }

    resolve(): Observable<ServiceDocument<HouseBillModel>> {
        return this.service.new();
    }
}


@Injectable()
export class HouseBilOpenResolver implements Resolve<ServiceDocument<HouseBillModel>> {
    constructor(private service: BolService) { }

    resolve(route: ActivatedRouteSnapshot): Observable<ServiceDocument<HouseBillModel>> {
        return this.service.open(route.params["id"]);
    }
}
