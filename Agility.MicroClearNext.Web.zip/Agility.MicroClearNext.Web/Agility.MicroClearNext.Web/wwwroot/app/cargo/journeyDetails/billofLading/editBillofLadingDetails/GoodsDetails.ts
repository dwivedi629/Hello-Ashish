export interface IGoodsDetails {
  manifestInfo: string;
  uniqueBLNo: string;
  bblDate: string;
}
