"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var forms_1 = require("@angular/forms");
var router_1 = require("@angular/router");
var registrationWizardService_1 = require("../../../../account/registration/registrationWizard/registrationWizardService");
var EditBillOfLadingDetailsComponent = (function () {
    function EditBillOfLadingDetailsComponent(_fb, router, activatedRoute, registrationWizardService) {
        this._fb = _fb;
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.registrationWizardService = registrationWizardService;
    }
    EditBillOfLadingDetailsComponent.prototype.ngOnInit = function () {
        this.billOfLadingForm = this._fb.group({
            gManifestInfo: ['', [forms_1.Validators.required]],
            gUniqueBLNo: ['', [forms_1.Validators.required]],
            gblDate: ['', [forms_1.Validators.required]],
            blCreationDate: ['', [forms_1.Validators.required]],
            carrierDate: ['', [forms_1.Validators.required]],
            refBLNo: ['', [forms_1.Validators.required]],
            blFor: ['', [forms_1.Validators.required]],
            billFor: ['', [forms_1.Validators.required]],
            nocNo: ['', [forms_1.Validators.required]],
            agentName: ['', [forms_1.Validators.required]],
            manifestYear: ['', [forms_1.Validators.required]],
            manifestStatus: ['', [forms_1.Validators.required]],
            vesselIdentificationNo: ['', [forms_1.Validators.required]],
            blStatus: ['', [forms_1.Validators.required]],
            shipCallNum: ['', [forms_1.Validators.required]],
            shipAgentCode: ['', [forms_1.Validators.required]],
            blDTDateAndTime: this._fb.group({
                blDTDate: ['', [forms_1.Validators.required]],
                blDTTime: ['', [forms_1.Validators.required]]
            }),
            customsStationCode: ['', [forms_1.Validators.required]],
            processingIndicator: ['', [forms_1.Validators.required]],
            languageIndicator: ['', [forms_1.Validators.required]],
            manifestInfo: ['', [forms_1.Validators.required]],
            uniqueBLNo: ['', [forms_1.Validators.required]],
            bblDate: ['', [forms_1.Validators.required]]
        });
    };
    EditBillOfLadingDetailsComponent.prototype.onDateChange = function (event, input) {
        if (input === 'gblDate') {
            this.billOfLadingForm.controls['gblDate'].patchValue(event);
        }
        if (input === 'blDate') {
            this.billOfLadingForm.controls['blDate'].patchValue(event);
        }
        if (input === 'dDate') {
            this.billOfLadingForm.controls['dDate'].patchValue(event);
        }
        if (input === 'carrierDate') {
            this.billOfLadingForm.controls['carrierDate'].patchValue(event);
        }
        if (input === 'blDTDate') {
            this.billOfLadingForm.controls['blDTDateAndTime'].controls['blDTDate'].patchValue(event);
        }
        if (input === 'bblDate') {
            this.billOfLadingForm.controls['bblDate'].patchValue(event);
        }
    };
    EditBillOfLadingDetailsComponent.prototype.validateBillOfLadingForm = function (model, isValid) {
        this.billOfLadingFormSubmitted = true; // set form submit to true
        // check if model is valid
        console.log(model, isValid);
        // this.router.navigate(['/vessel/add-vessel/ship-owner']);
    };
    EditBillOfLadingDetailsComponent.prototype.submitBillOfLading = function () {
        this.registrationWizardService.emitStepCompletionStatus(this.activatedRoute.snapshot.data['stepCount']);
        this.router.navigate(['../bill-of-lading/bill-of-lading-list-view'], { relativeTo: this.activatedRoute });
    };
    return EditBillOfLadingDetailsComponent;
}());
EditBillOfLadingDetailsComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'app-edit-bill-of-lading-details',
        templateUrl: './EditBillOfLadingDetailsComponent.html',
        styleUrls: ['./EditBillOfLadingDetailsComponent.css']
    }),
    __metadata("design:paramtypes", [forms_1.FormBuilder,
        router_1.Router,
        router_1.ActivatedRoute,
        registrationWizardService_1.RegistrationWizardService])
], EditBillOfLadingDetailsComponent);
exports.EditBillOfLadingDetailsComponent = EditBillOfLadingDetailsComponent;
//# sourceMappingURL=EditBillOfLadingDetailsComponent.js.map