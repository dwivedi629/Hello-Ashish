"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var registrationWizardService_1 = require("../../../../account/registration/registrationWizard/registrationWizardService");
var HBPartyComponent = (function () {
    function HBPartyComponent(router, activatedRoute, registrationWizardService) {
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.registrationWizardService = registrationWizardService;
    }
    HBPartyComponent.prototype.ngOnInit = function () {
        //this.activatedRoute.data
        //    .subscribe(() => {
        //        this.serviceDocument = this.manifestService.serviceDocument;
        //        console.log(this.serviceDocument);
        //    });
    };
    //this.hbPartyForm = this._fb.group({
    //    consigneeRegistered: [''],
    //    consigneeFreeText: [''],
    //    consigneeCode: [''],
    //    consigneeName: [''],
    //    consigneeEmailId: [''],
    //    consigneeMobileNor: this._fb.group({
    //        consigneeCode: [''],
    //        number: ['']
    //    }),
    //    consigneeAddressCountry: [''],
    //    consigneeAddress: [''],
    //    consigneeCountry: [''],
    //    consigneePostalCode: [''],
    //    consigneeState: [''],
    //    consigneeCityTownAreaLand: [''],
    //    notifyPartySameAsConsignee: [''],
    //    notifyParty: [''],
    //    notifyPartyCode: [''],
    //    notifyPartyEmailId: [''],
    //    notifyPartyMobileNor: this._fb.group({
    //        notifyCode: [''],
    //        number: [''],
    //    }),
    //    notifyPartyCountrySubEntityName: [''],
    //    notifyPartyAddress: ['', [<any>Validators.required]],
    //    notifyPartyCountry: ['', [<any>Validators.required]],
    //    notifyPartyPostalCode: [''],
    //    notifyPartyState: [''],
    //    notifyPartyCityTownAreaLand: [''],
    //    shipper: ['', [<any>Validators.required]],
    //    shipperMarks: [''],
    //    shipperEmailId: [''],
    //    shipperMobileNor: this._fb.group({
    //        shipMobileCode: [''],
    //        number: ['']
    //    }),
    //    shipperAddress: ['', [<any>Validators.required]],
    //    shipperCountry: ['', [<any>Validators.required]],
    //    shipperPostalCode: [''],
    //    shipperState: [''],
    //    shipperCityTownAreaLand: ['']
    //});
    // }
    //validateHbPartyForm(model: HbPartyInfo, isValid: boolean) {
    //    this.hbPartyFormSubmitted = true; // set form submit to true
    //    // check if model is valid
    //    console.log(model, isValid);
    //    // this.router.navigate(['/vessel/add-vessel/ship-owner']);
    //}
    HBPartyComponent.prototype.valueChangeEvent = function (event, inputType) {
        //console.log(inputType, 'drop down value:::', event);
        //if (inputType === 'consigeCode') {
        //    (<FormGroup>this.hbPartyForm.controls['consigneeMobileNor']).controls['countryCode'].patchValue(event);
        //}
        //if (inputType === 'carrierType') {
        //    this.hbPartyForm.controls['carrierType'].patchValue(event);
        //}
        //if (inputType === 'shipMobileCode') {
        //    (<FormGroup>this.hbPartyForm.controls['shipperMobileNor']).controls['shipMobileCode'].patchValue(event);
        //}
        //if (inputType === 'notifyCode') {
        //    (<FormGroup>this.hbPartyForm.controls['mobileNor']).controls['notifyCode'].patchValue(event);
        //}
    };
    HBPartyComponent.prototype.submitHbParty = function () {
        this.registrationWizardService.emitStepCompletionStatus(this.activatedRoute.snapshot.data['stepCount']);
        this.router.navigate(['../../bill-of-lading-line'], { relativeTo: this.activatedRoute });
    };
    return HBPartyComponent;
}());
HBPartyComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'app-hbparty',
        templateUrl: './HbpartyComponent.html',
        styleUrls: ['./HbpartyComponent.css']
    }),
    __metadata("design:paramtypes", [router_1.Router,
        router_1.ActivatedRoute,
        registrationWizardService_1.RegistrationWizardService])
], HBPartyComponent);
exports.HBPartyComponent = HBPartyComponent;
//# sourceMappingURL=HbPartyComponent.js.map