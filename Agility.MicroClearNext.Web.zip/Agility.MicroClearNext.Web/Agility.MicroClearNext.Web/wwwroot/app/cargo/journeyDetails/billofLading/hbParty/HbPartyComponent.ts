import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
//import { HbPartyInfo } from './HbPartyInfo';
import {HBPartyModel } from "./HBParty";
import { Router, ActivatedRoute } from '@angular/router';
import { RegistrationWizardService } from '../../../../account/registration/registrationWizard/registrationWizardService';
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
@Component({
    moduleId: module.id,
    selector: 'app-hbparty',
    templateUrl: './HbpartyComponent.html',
    styleUrls: ['./HbpartyComponent.css']
})
export class HBPartyComponent implements OnInit {
    //public hbPartyForm: FormGroup;
    public serviceDocument: ServiceDocument<HBPartyModel>;
    public hbPartyFormSubmitted: boolean;

    constructor(
        private router: Router,
        private activatedRoute: ActivatedRoute,
        private registrationWizardService: RegistrationWizardService) { }

    ngOnInit() {
        //this.activatedRoute.data
        //    .subscribe(() => {
        //        this.serviceDocument = this.manifestService.serviceDocument;
        //        console.log(this.serviceDocument);
        //    });

    }
        //this.hbPartyForm = this._fb.group({
        //    consigneeRegistered: [''],
        //    consigneeFreeText: [''],
        //    consigneeCode: [''],
        //    consigneeName: [''],
        //    consigneeEmailId: [''],
        //    consigneeMobileNor: this._fb.group({
        //        consigneeCode: [''],
        //        number: ['']
        //    }),
        //    consigneeAddressCountry: [''],
        //    consigneeAddress: [''],
        //    consigneeCountry: [''],
        //    consigneePostalCode: [''],
        //    consigneeState: [''],
        //    consigneeCityTownAreaLand: [''],
        //    notifyPartySameAsConsignee: [''],
        //    notifyParty: [''],
        //    notifyPartyCode: [''],
        //    notifyPartyEmailId: [''],
        //    notifyPartyMobileNor: this._fb.group({
        //        notifyCode: [''],
        //        number: [''],
        //    }),
        //    notifyPartyCountrySubEntityName: [''],
        //    notifyPartyAddress: ['', [<any>Validators.required]],
        //    notifyPartyCountry: ['', [<any>Validators.required]],
        //    notifyPartyPostalCode: [''],
        //    notifyPartyState: [''],
        //    notifyPartyCityTownAreaLand: [''],
        //    shipper: ['', [<any>Validators.required]],
        //    shipperMarks: [''],
        //    shipperEmailId: [''],
        //    shipperMobileNor: this._fb.group({
        //        shipMobileCode: [''],
        //        number: ['']
        //    }),
        //    shipperAddress: ['', [<any>Validators.required]],
        //    shipperCountry: ['', [<any>Validators.required]],
        //    shipperPostalCode: [''],
        //    shipperState: [''],
        //    shipperCityTownAreaLand: ['']
        //});
   // }

    //validateHbPartyForm(model: HbPartyInfo, isValid: boolean) {
    //    this.hbPartyFormSubmitted = true; // set form submit to true

    //    // check if model is valid
    //    console.log(model, isValid);
    //    // this.router.navigate(['/vessel/add-vessel/ship-owner']);
    //}

    valueChangeEvent(event, inputType) {
        //console.log(inputType, 'drop down value:::', event);
        //if (inputType === 'consigeCode') {
        //    (<FormGroup>this.hbPartyForm.controls['consigneeMobileNor']).controls['countryCode'].patchValue(event);
        //}
        //if (inputType === 'carrierType') {
        //    this.hbPartyForm.controls['carrierType'].patchValue(event);
        //}
        //if (inputType === 'shipMobileCode') {
        //    (<FormGroup>this.hbPartyForm.controls['shipperMobileNor']).controls['shipMobileCode'].patchValue(event);
        //}
        //if (inputType === 'notifyCode') {
        //    (<FormGroup>this.hbPartyForm.controls['mobileNor']).controls['notifyCode'].patchValue(event);
        //}
    }

    submitHbParty() {
        this.registrationWizardService.emitStepCompletionStatus(this.activatedRoute.snapshot.data['stepCount']);
        this.router.navigate(['../../bill-of-lading-line'], { relativeTo: this.activatedRoute });
    }
}
