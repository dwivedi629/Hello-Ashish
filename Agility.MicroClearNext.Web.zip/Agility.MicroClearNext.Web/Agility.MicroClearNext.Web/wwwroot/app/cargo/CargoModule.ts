import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";

import { FrameworkModule } from "framework/FrameworkModule";
import { CargoRoutingModule } from "./CargoRoutingModule";
import { CargoComponent } from "./CargoComponent";
import { CommonService } from "framework/CommonService";
import { JourneyModule } from "./JourneyModule";

@NgModule({
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        FrameworkModule,
        CargoRoutingModule,
        JourneyModule
    ],
    declarations: [
        CargoComponent
    ],
    entryComponents: [
        CargoComponent
    ],
    providers: [
        CommonService
    ],
    bootstrap: [
        CargoComponent
    ]
})
export class CargoModule {

}
