"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var platform_browser_dynamic_1 = require("@angular/platform-browser-dynamic");
var CargoModule_1 = require("./CargoModule");
platform_browser_dynamic_1.platformBrowserDynamic().bootstrapModule(CargoModule_1.CargoModule);
//# sourceMappingURL=Main.js.map