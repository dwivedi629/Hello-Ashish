import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { IJourney } from './journey';
import 'rxjs/Rx';


@Injectable ()
export class JourneyService {
  constructor(private _http: Http) {};

  handleError(error: Response) {
    console.log(error);
    const message = `Error status code ${error.status} at ${error.url}`;
    return Observable.throw(message);
  }
  getJourneyList(): Observable<IJourney[]> {
    
      return this._http.get('../../assets/api/json/journey.json')
      .map((response: Response) => <IJourney[]> response.json())
      .do(data => console.log());
    // .catch(this.handleError());
  }
}
