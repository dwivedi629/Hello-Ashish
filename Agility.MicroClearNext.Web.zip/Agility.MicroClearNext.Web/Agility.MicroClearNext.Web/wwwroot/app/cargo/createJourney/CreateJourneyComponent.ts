import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
//import { RegistrationWizardService } from '../../../registration/registration-wizard/registration-wizard.service';
import { RegistrationWizardService } from '../../account/registration/registrationWizard/registrationWizardService';

@Component({
    moduleId: module.id,
    selector: 'app-create-journey',
    templateUrl: './CreateJourneyComponent.html',
    //styleUrls: ['./CreateJourneyComponent.css'],
    providers: [RegistrationWizardService]
})
export class CreateJourneyComponent implements OnInit {
    private isCompleted: boolean = false;
    public completedStep: number = 0;

    errorMessage: string;

    onActivate(e, outlet) {
        outlet.scrollTop = 0;
    }

    constructor(
        private registrationWizardService: RegistrationWizardService,
        private activatedRoute: ActivatedRoute
    ) {
        this.registrationWizardService.stepCompletionStatusEmitted$.subscribe(
            status => {
                this.completedStep = status;
            });
    }

    ngOnInit() { }

    checkWizardStatus(event, currentStep: number) {
        event.preventDefault();
        event.stopPropagation();

        if (this.completedStep >= currentStep) {
            this.completedStep = currentStep - 1;
        }
    }
}
