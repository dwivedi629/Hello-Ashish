import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { RegistrationWizardService } from '../../../account/registration/registrationWizard/registrationWizardService';

@Component({
    moduleId: module.id,
  selector: 'app-create-dashboard',
  templateUrl: './DashboardComponent.html',
  //styleUrls: ['./DashboardComponent.css']
})
export class CreateDashboardComponent implements OnInit {
  public isNewManifest: boolean = true;

  constructor(private activatedRoute: ActivatedRoute) { }

  ngOnInit() { }
}
