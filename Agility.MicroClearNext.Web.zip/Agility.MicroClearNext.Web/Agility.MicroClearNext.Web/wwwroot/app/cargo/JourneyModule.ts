import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { JourneyRoutingModule } from './JourneyRoutingModule';
import { FrameworkModule } from "framework/FrameworkModule";
import { IContainerService } from "./journeyDetails/billOfLadingLine/billOfLadingLineContainerInformation/addContainer/ContainerService";
import { IContainerListResolver, IContainerNewResolver, IContainerViewResolver, IContainerOpenResolver } from "./journeyDetails/billOfLadingLine/billOfLadingLineContainerInformation/addContainer/ContainerResolver";
//import { IContainerNewResolver } from "./journeyDetails/billOfLadingLine/billOfLadingLineContainerInformation/addContainer/ContainerResolver/"; "
import { ManifestService } from "./journeyDetails/manifest/ManifestService";
import { ManifestListResolver, ManifestNewResolver, ManifestOpenResolver, ManifestViewResolver } from "./journeyDetails/manifest/ManifestResolver";
import { HouseBillListResolver, HouseBilOpenResolver, HouseBillNewResolver } from './journeyDetails/billofLading/BillOfLadingResolver';
import { BolService } from "./journeyDetails/billofLading/BillofLadingService";
import { DeliveryOrderService } from "./journeyDetails/deliveryOrder/DeliveryOrderService";

import { DeliveryOrderListResolver, DeliveryOrderNewResolver, DeliveryOrderViewResolver, DeliveryOrderOpenResolver } from "./journeyDetails/deliveryOrder/DeliveryOrderResolver";
import { JourneyInfoService } from "./journeyDetails/journeyInfo/Journeyinfoservice";
import { JourneyInfoListResolver, JourneyInfoNewResolver, JourneyInfoOpenResolver } from "./journeyDetails/journeyInfo/JourneyInfoResolver";
import { HBItemListResolver, HBItemlNewResolver, HBItemOpenResolver } from "./journeyDetails/billOfLadingLine/BillOfLadingLineResolver";
import { BolLineService } from "./journeyDetails/billOfLadingLine/BillOfLadingLineService";
//import { JourneyService } from "./JourneyService";
@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        JourneyRoutingModule,
        FrameworkModule,
        // IContainerService,
        //IContainerListResolver
        // NguiDatetimePickerModule
    ],
    providers: [
        //JourneyService,
        IContainerService,
        ManifestService,
        BolService,
        BolLineService,
        JourneyInfoService,
        JourneyInfoListResolver, JourneyInfoNewResolver, JourneyInfoOpenResolver,
        DeliveryOrderService,
        IContainerNewResolver, IContainerListResolver, , IContainerViewResolver, IContainerOpenResolver,
        ManifestListResolver, ManifestNewResolver, ManifestOpenResolver, ManifestViewResolver,
        HouseBillListResolver, HouseBilOpenResolver, HouseBillNewResolver,
        DeliveryOrderListResolver, DeliveryOrderNewResolver, DeliveryOrderViewResolver, DeliveryOrderOpenResolver,
        HBItemListResolver, HBItemlNewResolver, HBItemOpenResolver
    ],
    declarations: []
})
export class JourneyModule { }
