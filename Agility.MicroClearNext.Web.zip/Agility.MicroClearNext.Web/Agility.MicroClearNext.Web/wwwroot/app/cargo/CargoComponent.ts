import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { FxContext } from "framework/context/FxContext";

@Component({
    moduleId: module.id,
    selector: "root-app",
    templateUrl: "CargoComponent.html",
    styles: ['.active {background-color:#dcdcdc}', '.fx-nav-container {height: 500px;}','.fx-nav {width:70px}']
})
export class CargoComponent implements OnInit {

    constructor(public fxContext: FxContext, private router: Router) {
    }

    ngOnInit(): void {
        debugger;
        this.router.navigate(["./Journey"]);
    }
}

