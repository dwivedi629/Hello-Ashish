"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var common_1 = require("@angular/common");
var forms_1 = require("@angular/forms");
var JourneyRoutingModule_1 = require("./JourneyRoutingModule");
var FrameworkModule_1 = require("framework/FrameworkModule");
var ContainerService_1 = require("./journeyDetails/billOfLadingLine/billOfLadingLineContainerInformation/addContainer/ContainerService");
var ContainerResolver_1 = require("./journeyDetails/billOfLadingLine/billOfLadingLineContainerInformation/addContainer/ContainerResolver");
//import { IContainerNewResolver } from "./journeyDetails/billOfLadingLine/billOfLadingLineContainerInformation/addContainer/ContainerResolver/"; "
var ManifestService_1 = require("./journeyDetails/manifest/ManifestService");
var ManifestResolver_1 = require("./journeyDetails/manifest/ManifestResolver");
var BillOfLadingResolver_1 = require("./journeyDetails/billofLading/BillOfLadingResolver");
var BillofLadingService_1 = require("./journeyDetails/billofLading/BillofLadingService");
var DeliveryOrderService_1 = require("./journeyDetails/deliveryOrder/DeliveryOrderService");
var DeliveryOrderResolver_1 = require("./journeyDetails/deliveryOrder/DeliveryOrderResolver");
var Journeyinfoservice_1 = require("./journeyDetails/journeyInfo/Journeyinfoservice");
var JourneyInfoResolver_1 = require("./journeyDetails/journeyInfo/JourneyInfoResolver");
var BillOfLadingLineResolver_1 = require("./journeyDetails/billOfLadingLine/BillOfLadingLineResolver");
var BillOfLadingLineService_1 = require("./journeyDetails/billOfLadingLine/BillOfLadingLineService");
//import { JourneyService } from "./JourneyService";
var JourneyModule = (function () {
    function JourneyModule() {
    }
    return JourneyModule;
}());
JourneyModule = __decorate([
    core_1.NgModule({
        imports: [
            common_1.CommonModule,
            forms_1.FormsModule,
            forms_1.ReactiveFormsModule,
            JourneyRoutingModule_1.JourneyRoutingModule,
            FrameworkModule_1.FrameworkModule,
        ],
        providers: [
            //JourneyService,
            ContainerService_1.IContainerService,
            ManifestService_1.ManifestService,
            BillofLadingService_1.BolService,
            BillOfLadingLineService_1.BolLineService,
            Journeyinfoservice_1.JourneyInfoService,
            JourneyInfoResolver_1.JourneyInfoListResolver, JourneyInfoResolver_1.JourneyInfoNewResolver, JourneyInfoResolver_1.JourneyInfoOpenResolver,
            DeliveryOrderService_1.DeliveryOrderService,
            ContainerResolver_1.IContainerNewResolver, ContainerResolver_1.IContainerListResolver, , ContainerResolver_1.IContainerViewResolver, ContainerResolver_1.IContainerOpenResolver,
            ManifestResolver_1.ManifestListResolver, ManifestResolver_1.ManifestNewResolver, ManifestResolver_1.ManifestOpenResolver, ManifestResolver_1.ManifestViewResolver,
            BillOfLadingResolver_1.HouseBillListResolver, BillOfLadingResolver_1.HouseBilOpenResolver, BillOfLadingResolver_1.HouseBillNewResolver,
            DeliveryOrderResolver_1.DeliveryOrderListResolver, DeliveryOrderResolver_1.DeliveryOrderNewResolver, DeliveryOrderResolver_1.DeliveryOrderViewResolver, DeliveryOrderResolver_1.DeliveryOrderOpenResolver,
            BillOfLadingLineResolver_1.HBItemListResolver, BillOfLadingLineResolver_1.HBItemlNewResolver, BillOfLadingLineResolver_1.HBItemOpenResolver
        ],
        declarations: []
    })
], JourneyModule);
exports.JourneyModule = JourneyModule;
//# sourceMappingURL=JourneyModule.js.map