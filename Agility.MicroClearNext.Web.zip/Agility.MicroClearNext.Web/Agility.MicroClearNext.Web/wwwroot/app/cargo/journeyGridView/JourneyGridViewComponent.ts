import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
//import { IJourney } from '../Journey';
//import { JourneyService } from '../JourneyService';
import { ServiceDocument } from "framework/servicedocument/ServiceDocument";
import { JourneyInfo } from '../journeyDetails/journeyInfo/journeyInfoAccordion/JourneyInfo';
import { JourneyInfoService } from "../journeyDetails/journeyInfo/Journeyinfoservice";
import { RegistrationWizardService } from '../../account/registration/registrationWizard/registrationWizardService';


@Component({
    moduleId: module.id,
    selector: 'app-journey-grid-view',
    templateUrl: './JourneyGridViewComponent.html',
    styleUrls: ['./JourneyGridViewComponent.css']
})
export class JourneyGridViewComponent implements OnInit, OnDestroy {
    journeyList: JourneyInfo[];
    errorMessage: string;
    id: number;
    private sub: any;
    public serviceDocument: ServiceDocument<JourneyInfo>;


    constructor(
        //private _journeyService: JourneyService,
        private service: JourneyInfoService,
        private route: ActivatedRoute) {
    }

    ngOnInit() {
        this.sub =this.route.data
            .subscribe((res) => {
                this.serviceDocument = this.service.serviceDocument;
                console.log(this.serviceDocument);
            });
        this.journeyList = this.serviceDocument.dataProfile.dataList;
    }

    //ngOnInit() {
    //    // this.getJourneyList();
    //    this.sub = this.route.params.subscribe(params => {
    //        this.id = +params['id']; // (+) converts string 'id' to associate-inspection-instructions number

    //        // In associate-inspection-instructions real app: dispatch action to load the details here.
    //    });
    //}

    //getJourneyList() {
    //    this._journeyService.getJourneyList()
    //        .subscribe(journeyList => this.journeyList = journeyList,
    //        error => this.errorMessage = <any>error
    //        );
    //}

    ngOnDestroy() {
        this.sub.unsubscribe();
    }

    mapPropagation(event) {
        event.stopPropagation();
    }

    optionPropagation(event) {
        event.stopPropagation();
    }

}
