import { Component, OnInit } from '@angular/core';
import { MdDialog } from '@angular/material';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { SearchModalComponent } from './searchModal/SearchModalComponent';
import { QuickLinksModalComponent } from './quickLinksModal/QuickLinksModalComponent';
import { ProfileModalComponent } from './profileModal/ProfileModalComponent';
import { MenuModalComponent } from './menuModal/MenuModalComponent';

//declare var $: any;
@Component({
    moduleId: module.id,
    selector: 'app-header',
    templateUrl: './HeaderComponent.html',
    styleUrls: ['./HeaderComponent.css']
})
export class HeaderComponent implements OnInit {
    public modalStyles: any = {
        height: '100%',
        width: '100%',
        panelClass: 'fullscreen-modal'
    };
    public activeClass: boolean;
    public searchForm: FormGroup;
    public searchFormSubmitted: boolean;
    private isMenuModalVissible: boolean;
    private test = true;

    constructor(private _fb: FormBuilder,
        private router: Router, public dialog: MdDialog) {
    }

    ngOnInit() {
      //  $('[rel="tooltip"]').tooltip('show');
        // this.getOverlayMenusList();
    }

    //Toggle Class
    onToggleClass() { 
        this.activeClass = !this.activeClass;
    }


    //Search Dialog Open
    openSearchDialog() {        
        this.dialog.open(SearchModalComponent, this.modalStyles);
    }

    //Quick links Dailog open
    openQuickLinksDialog() {
        this.dialog.open(QuickLinksModalComponent, this.modalStyles);
    }

    //Profile Dialog Open
    openProfileDialog() {
        this.onToggleClass();
        this.dialog.open(ProfileModalComponent, this.modalStyles);
    }

    //Menu Dialog Open
    openMenuDialog() {
        this.dialog.open(MenuModalComponent, this.modalStyles);
    }
}
