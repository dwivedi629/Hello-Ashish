﻿using AtHoc.Global.Resources.Entities;
using AtHoc.Global.Resources.Interfaces;
using AtHoc.Runtime;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.Global.Resources.Implementations
{
    public class GlobalEntityCacheManager
    {
        private ProcessCache _entityCache;
        private IGlobalEntityLocaleRepository _globalEntityLocaleRepository;

        /// <summary>
        /// Default constructor for the class
        /// </summary>
        /// <param name="globalEntityLocaleRepository"></param>
        public GlobalEntityCacheManager(IGlobalEntityLocaleRepository globalEntityLocaleRepository)
        {
            _globalEntityLocaleRepository = globalEntityLocaleRepository;

            var cacheDuration = System.Configuration.ConfigurationManager.AppSettings["DeliveryCacheDurationInMinutes"] ?? "5";
            var configuration = new ProcessCacheConfiguration
            {
                IsEnabled = true,
                DefaultExpiration = TimeSpan.FromMinutes(Int32.Parse(cacheDuration)),
                DefaultExpirationType = ExpirationType.Absolute,
                Name = "EntityCache"
            };

            _entityCache = GlobalCacheConfiguration.GetProcessCacheConfiguration(configuration);
        }

        /// <summary>
        /// Returns the localised value of the given entity from cache
        /// First it looks for the cache for the particular locale
        /// If it is present, then searches within it, returns value from that
        /// If not present, then build the cache(from DB) and then searches within it, returns value from that
        /// </summary>
        /// <param name="entityId"></param>
        /// <param name="entityType"></param>
        /// <param name="entityKey"></param>
        /// <param name="locale"></param>
        /// <returns></returns>
        public string GetEntityValue(string entityId, string entityType, string entityKey, string locale)
        {
            if (!IsCacheAvailable(locale))
            {
                if (!SetEntitiesCache(locale)) return string.Empty;
            }
            
            string localisedValue = string.Empty;
            Dictionary<string, string> entityDictionary = null; 

            if (_entityCache.TryGet(BuildCacheName(locale), out entityDictionary))
            {
                if (entityDictionary != null)
                {
                    IEnumerable<KeyValuePair<string, string>> searchResults = entityDictionary.Where(x => x.Key.Equals(BuildEntityKeyName(entityId, entityType, entityKey), StringComparison.OrdinalIgnoreCase));
                    if (searchResults.Any())
                        localisedValue = searchResults.First().Value;
                }
            }
            return localisedValue;
        }

        /// <summary>
        /// Holds logic to create Cache name depending on locale name
        /// It returns the Cache name for the given locale
        /// </summary>
        /// <param name="locale"></param>
        /// <returns></returns>
        private string BuildCacheName(string locale)
        {
            return string.Format("GlobalCache_{0}", locale);
        }

        /// <summary>
        /// Holds logic to create Cache Item name depending on locale name and given entity details
        /// It returns the Cache name for the given locale and entity
        /// </summary>
        /// <param name="entityId"></param>
        /// <param name="entityType"></param>
        /// <param name="entityKey"></param>
        /// <param name="locale"></param>
        /// <returns></returns>
        private string BuildEntityKeyName(string entityId, string entityType, string entityKey)
        {
            return string.Format("{0}_{1}_{2}", entityType, entityId, entityKey.Replace(' ', '_'));
        }

        /// <summary>
        /// Reads data from the DB for given locale and stores it in Cache in Dcitionary format
        /// </summary>
        /// <param name="locale"></param>
        private bool SetEntitiesCache(string locale)
        {
            IEnumerable<EntityLocale> entityLocaleList = _globalEntityLocaleRepository.GetAll(locale);
            if (!entityLocaleList.Any()) return false;
            Dictionary<string, string> entityDictionary = new Dictionary<string, string>();

            foreach(EntityLocale attributeRow in entityLocaleList)
                entityDictionary.Add(BuildEntityKeyName(attributeRow.EntityId, attributeRow.EntityType, attributeRow.EntityKey), attributeRow.EntityValue);
         
            _entityCache.Set(BuildCacheName(locale), entityDictionary);
            return true;
        }

        /// <summary>
        /// Checks if locale specific cache available
        /// </summary>
        /// <param name="locale"></param>
        /// <returns></returns>
        private bool IsCacheAvailable(string locale)
        {
            return _entityCache.Contains(BuildCacheName(locale));
        }

       
    }
}
