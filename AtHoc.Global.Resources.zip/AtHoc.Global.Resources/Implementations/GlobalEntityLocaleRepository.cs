﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using AtHoc.Data;
using System.Data.SqlClient;
using AtHoc.Global.Resources;
using AtHoc.Global.Resources.Entities;
using AtHoc.Global.Resources.Interfaces;

namespace AtHoc.Global.Resources.Implementations
{
    public class GlobalEntityLocaleRepository : IGlobalEntityLocaleRepository
    {
        /// <summary>
        /// Method to fetch all the records from ENTITY_LOCALE_TAB for input locale
        /// </summary>
        /// <param name="locale">locale code</param>
        /// <returns>collection of EntityLocale</returns>
        public IEnumerable<EntityLocale> GetAll(string locale)
        {
            var entityLocaleList = new List<EntityLocale>();

            try
            {
                using (var db = new LocaleDbContext())
                {
                    var command = db.Database.Connection.CreateCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = Procedures.GetEntityLocale;
                    command.Parameters.Add(new SqlParameter("@LocaleCode", locale));
                    db.Database.Connection.Open();

                    var reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        entityLocaleList.Add(GetRawRecord(reader));
                    }

                    db.Database.Connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return entityLocaleList;
        }             

        /// <summary>
        /// Method to fetch localized value from ENTITY_LOCALE_TAB based on input parameters
        /// </summary>
        /// <param name="entityType">entity type</param>
        /// <param name="entityId">entity Id</param>
        /// <param name="entityKey">entity key (field of which localized value need to be fetched)</param>
        /// <param name="locale">locale code</param>
        /// <returns></returns>
        public string GetLocaleValue(string entityType, string entityId, string entityKey, string locale)
        {
            var entityLocaleList = new List<EntityLocale>();

            try
            {
                using (var db = new LocaleDbContext())
                {
                    var command = db.Database.Connection.CreateCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = Procedures.GetEntityLocale;
                    command.Parameters.Add(new SqlParameter("@EntityType", entityType));
                    command.Parameters.Add(new SqlParameter("@EntityID", entityId));
                    command.Parameters.Add(new SqlParameter("@EntityKey", entityKey));
                    command.Parameters.Add(new SqlParameter("@LocaleCode", locale));

                    db.Database.Connection.Open();

                    var reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        entityLocaleList.Add(GetRawRecord(reader));
                        reader.NextResult();
                    }

                    db.Database.Connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return entityLocaleList.Count > 0 ? entityLocaleList.First().EntityValue : null;
        }

        private EntityLocale GetRawRecord(IDataRecord reader)
        {
            return new EntityLocale()
            {
                Id = reader.GetValue(EntityLocaleColumns.Id, 0),
                EntityId = reader.GetValue(EntityLocaleColumns.EntityId, string.Empty),
                EntityType = reader.GetValue(EntityLocaleColumns.EntityType, string.Empty),
                LocaleCode = reader.GetValue(EntityLocaleColumns.LocaleCode, string.Empty),
                EntityKey = reader.GetValue(EntityLocaleColumns.EntityKey, string.Empty),
                EntityValue = reader.GetValue(EntityLocaleColumns.EntityValue, string.Empty),
            };
        }

    }
}
