﻿using System;
using AtHoc.Runtime;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.Global.Resources.Implementations
{
    public class GlobalCacheConfiguration
    {
        private static ProcessCache _entityCache;

        private GlobalCacheConfiguration()
        {

        }

        public static ProcessCache GetProcessCacheConfiguration(ProcessCacheConfiguration configuration)
        {
            if (_entityCache == null)
            {
                _entityCache = new ProcessCache(configuration);
            }

            return _entityCache;
        }
    }
}

