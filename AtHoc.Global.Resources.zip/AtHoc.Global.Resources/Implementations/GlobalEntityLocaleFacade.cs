﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using AtHoc.Global.Resources.Entities;
using AtHoc.Global.Resources.Interfaces;

namespace AtHoc.Global.Resources.Implementations
{
    public class GlobalEntityLocaleFacade : IGlobalEntityLocaleFacade
    {
        GlobalEntityCacheManager _globalEntityCacheManager = null;

        public GlobalEntityLocaleFacade(IGlobalEntityLocaleRepository globalEntityLocaleRepository)
        {
            _globalEntityCacheManager = new GlobalEntityCacheManager(globalEntityLocaleRepository);
        }

        /// <summary>
        /// Method to get localized value for a single property within an entity
        /// </summary>
        /// <param name="entityId">entity id</param>
        /// <param name="entityType">entity type</param>
        /// <param name="entityKey">entity key (field need to be localized for ex. Name or Description)</param>
        /// <param name="localeCode">locale code</param>
        /// <returns>localized value</returns>
        public string GetLocalizedValue(string entityId, BusinessEntity entityType, string entityKey, string localeCode)
        {
            try
            {
                if (string.IsNullOrEmpty(entityId)  || string.IsNullOrEmpty(entityKey) || string.IsNullOrEmpty(localeCode))
                    throw new Exception("EntityId, EntityType, EntityKey and LocaleCode are required to translate");

                var localizedValue = _globalEntityCacheManager.GetEntityValue(entityId, entityType.ToString(), entityKey, localeCode);

                if (!string.IsNullOrEmpty(localizedValue))
                    return localizedValue;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return null;
        }

        /// <summary>
        /// Method used to localize an entity based on input locale code
        /// </summary>
        /// <param name="entity">entity to localize</param>
        /// <param name="localeCode">locale code</param>
        /// <returns>localized entity</returns>
        public T GetLocalizedEntity<T>(T entity, string localeCode)
        {
            if (entity == null) return entity;

            if (string.IsNullOrEmpty(localeCode)) throw new Exception("Locale is required to translate");

            var entityType = entity.GetType();

            if ((entityType.IsValueType)) return entity;

            if (entityType == typeof(string)) return entity;

            try
            {
                if (IsTypeACollection(entityType))
                {
                    T localizeClassType;
                    if (LocalizedIEnumerableEntities(entity, localeCode, entityType, out localizeClassType))
                        return localizeClassType;
                }

                var id = entityType.GetProperties().Where(p => Attribute.IsDefined(p, typeof(LocalizationEntityIdAttribute)));

                if (id.Any())
                {
                    foreach (var property in entity.GetType().GetProperties())
                    {
                        if (!property.CanWrite || property.GetValue(entity) == null) continue;

                        var propertyValue = property.GetValue(entity);
                        var propertyType = property.PropertyType;

                        if (IsTypeACollection(propertyType))
                        {
                            Type type = this.GetType();
                            MethodInfo method = type.GetMethod("LocalizedIEnumerableEntities", BindingFlags.Instance | BindingFlags.NonPublic);
                            var parameters = new object[] { propertyValue, localeCode, propertyType, null };
                            var methodInvoke = method.MakeGenericMethod(new Type[] { propertyType });
                            methodInvoke.Invoke(this, parameters);
                        }
                        else if ((propertyType.IsClass && !propertyType.FullName.StartsWith("System.")))
                        {
                            MethodInvoker<T>(localeCode, propertyType, propertyValue);
                        }
                        else if(Attribute.IsDefined(property, typeof(LocalizationEntityPropertyAttribute)))
                        {
                            var localizationEntityPropertyAttribute = (LocalizationEntityPropertyAttribute) Attribute.GetCustomAttribute(property, typeof(LocalizationEntityPropertyAttribute));
                            var businessEntity = localizationEntityPropertyAttribute.BusinessEtity;
                            var entityProperty = localizationEntityPropertyAttribute.PropertyName;
                            var entityId = id.Where(x=> ((LocalizationEntityIdAttribute) x.GetCustomAttribute(typeof(LocalizationEntityIdAttribute)))
                                             .BusinessEtity.Equals(businessEntity)).FirstOrDefault();
                            if (entityId.GetValue(entity) != null)
                            {
                                var propertyVal = _globalEntityCacheManager.GetEntityValue(entityId.GetValue(entity).ToString(), businessEntity, entityProperty, localeCode);

                                if (!string.IsNullOrEmpty(propertyVal))
                                    property.SetValue(entity, propertyVal);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return entity;
        }

        /// <summary>
        /// Method is used to localize collection types. Iterates over the collection and for each item invokes GetLocalizedEntity method
        /// </summary>
        /// <param name="entity">collection entity</param>
        /// <param name="localeCode">locale code</param>
        /// <param name="entityType">type of the collection entity</param>
        /// <param name="localizeClassType">Out localized collection entity</param>
        /// <returns>true on successfull localization of entity</returns>
        private bool LocalizedIEnumerableEntities<T>(T entity, string localeCode, Type entityType, out T localizeClassType)
        {
            if ((entityType.GetInterface(Constants.IDictionary) != null))
            {
                var args = entityType.GetGenericArguments();
                var keyType = args[0];
                var valueType = args[1];
                var dictionaryType = typeof(Dictionary<,>).MakeGenericType(keyType, valueType);
                var updatedDictionary = (IDictionary)Activator.CreateInstance(dictionaryType);

                var dictionary = entity as IDictionary;
                if (dictionary != null)
                    foreach (var item in dictionary)
                    {
                        var value = GetLocalizedEntity(item.GetType().GetProperty(Constants.Value).GetValue(item), localeCode);
                        updatedDictionary.Add(item.GetType().GetProperty(Constants.Key).GetValue(item), value);
                    }

                {
                    localizeClassType = (T)updatedDictionary;
                    return true;
                }
            }
            if (entityType.GetGenericArguments()[0] != typeof(string) && !entityType.GetGenericArguments()[0].IsValueType)
            {
                var listType = typeof(List<>).MakeGenericType(entityType.GetGenericArguments()[0]);
                var updatedList = (IList)Activator.CreateInstance(listType);

                var items = entity as IList;
                if (items != null)
                    foreach (var item in items)
                        updatedList.Add(GetLocalizedEntity(item, localeCode));

                {
                    localizeClassType = (T)updatedList;
                    return true;
                }
            }

            localizeClassType = default(T);

            return false;
        }

        /// <summary>
        /// Method to check whether a given type is a collection type
        /// </summary>
        /// <param name="type">input type</param>
        /// <returns>true if type is a collection else false</returns>
        private bool IsTypeACollection(Type type)
        {
            return ((type.GetInterface(Constants.ICollection) != null && !(type.BaseType != null && type.BaseType.Name.Equals(Constants.EntityBase)) && type.GetGenericArguments().Any()) ||
                    (type.GetInterface(Constants.IEnumerable) != null && !(type.BaseType != null && type.BaseType.Name.Equals(Constants.EntityBase)) && type.GetGenericArguments().Any() && !(type == typeof(string))));
        }

        /// <summary>
        /// Invokes method GetLocalizedEntity with type T as propertyType and parameters as propertyValue and localeCode
        /// </summary>
        /// <param name="localeCode">locale code</param>
        /// <param name="propertyType">property type</param>
        /// <param name="propertyValue">property value</param>
        private void MethodInvoker<T>(string localeCode, Type propertyType, object propertyValue)
        {
            var method = this.GetType().GetMethod("GetLocalizedEntity", BindingFlags.Instance | BindingFlags.Public);
            var methodInvoke = method.MakeGenericMethod(new Type[] { propertyType });
            methodInvoke.Invoke(this, new object[] { propertyValue, localeCode });
        }
    }
}
