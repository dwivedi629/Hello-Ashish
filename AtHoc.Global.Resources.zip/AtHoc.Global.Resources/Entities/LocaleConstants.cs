﻿namespace AtHoc.Global.Resources.Entities
{
    public static class EntityLocaleColumns
    {
        public static readonly string Id = "ID";
        public static readonly string EntityType = "ENTITY_TYPE";
        public static readonly string EntityId = "ENTITY_ID";
        public static readonly string LocaleCode = "LOCALE_CODE";
        public static readonly string EntityKey = "ENTITY_KEY";
        public static readonly string EntityValue = "ENTITY_VALUE";
        public static readonly string CreatedOn = "CREATED_ON";
        public static readonly string UpdatedOn = "UPDATED_ON";
        public static readonly string CreatedBy = "CREATED_BY";
        public static readonly string UpdatedBy = "UPDATED_BY";
    }

    public static class Procedures
    {
        public static readonly string GetEntityLocale = "LOCALE_GET_ENTITY";

    }
    public static class Constants
    {
        public static readonly string ICollection = "ICollection";
        public static readonly string IEnumerable = "IEnumerable";
        public static readonly string IDictionary = "IDictionary";
        public static readonly string Key = "Key";
        public static readonly string Value = "Value";
        public static readonly string EntityBase = "EntityBase";
    }
}
