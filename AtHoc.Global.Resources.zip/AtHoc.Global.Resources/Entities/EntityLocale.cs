﻿using System;

namespace AtHoc.Global.Resources.Entities
{
    public class EntityLocale
    {
        public int Id { get; set; }
        public string EntityId { get; set; }
        public string EntityType { get; set; }
        public string LocaleCode { get; set; }
        public string EntityKey { get; set; }
        public string EntityValue { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime UpdatedOn { get; set; }
        public int CreatedBy { get; set; }
        public int UpdatedBy { get; set; }
    }
}
