﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.Global.Resources.Entities
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
    public class LocalizationEntityIdAttribute : Attribute
    {
        private readonly string _businessEntity;
        public LocalizationEntityIdAttribute(BusinessEntity businessEntity)
        {
            _businessEntity = Convert.ToString(businessEntity);
        }

        public string BusinessEtity
        {
            get { return _businessEntity; }
        }
    }
}
