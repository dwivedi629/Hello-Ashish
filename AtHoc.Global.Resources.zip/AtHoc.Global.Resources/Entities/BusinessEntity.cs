﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.Global.Resources.Entities
{
    public enum  BusinessEntity
    {
        Device,
        DeviceGroup,
        AlertFolder,
        DeliveryTemplate,
        AgentSettings,
        AudioFile,        
        OperatorRole,
        EventCategory,
        CheckBox,
        DesktopPopup,
        Severity,
        EventPlaceholder
    }
}
