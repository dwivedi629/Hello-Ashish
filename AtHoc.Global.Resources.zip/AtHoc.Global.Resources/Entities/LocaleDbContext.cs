﻿using System;
using System.Collections.Generic;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.Global.Resources.Entities
{
    class LocaleDbContext : DbContext
    {
        public LocaleDbContext() : base(GetConnectionString()) { }

        private static string GetConnectionString()
        {
            var registry = @"HKEY_LOCAL_MACHINE\SOFTWARE\Wow6432Node\AtHocServer";
            var value = (string)Microsoft.Win32.Registry.GetValue(registry, "OleDbConnectionString", string.Empty);
            return value.Replace("Provider=SQLOLEDB.1;", "");
        }
    }
}
