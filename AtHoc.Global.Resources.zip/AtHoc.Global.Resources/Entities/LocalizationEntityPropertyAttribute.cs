﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.Global.Resources.Entities
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
    public class LocalizationEntityPropertyAttribute : Attribute
    {
        private readonly string _businessEntity;
        private readonly string _propertyName;

        public LocalizationEntityPropertyAttribute(BusinessEntity businessEntity, string propertyName)
        {
            _businessEntity = Convert.ToString(businessEntity);
            _propertyName = propertyName;
        }

        public string BusinessEtity
        {
            get { return _businessEntity; }
        }

        public string PropertyName
        {
            get { return _propertyName; }
        }
    }
}
