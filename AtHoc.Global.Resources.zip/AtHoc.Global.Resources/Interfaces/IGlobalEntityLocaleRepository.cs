﻿using System;
using System.Collections.Generic;
using AtHoc.Global.Resources.Entities;


namespace AtHoc.Global.Resources.Interfaces
{
    public interface IGlobalEntityLocaleRepository
    {
         IEnumerable<EntityLocale> GetAll(string locale);                        
         string GetLocaleValue(string entityType, string entityId, string entityKey, string locale);
    }
}
