﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Global.Resources.Entities;

namespace AtHoc.Global.Resources.Interfaces
{
    public interface IGlobalEntityLocaleFacade
    {
        T GetLocalizedEntity<T>(T entity, string localeCode);
        string GetLocalizedValue(string entityId, BusinessEntity entityType, string entityKey, string localeCode);

    }
}
