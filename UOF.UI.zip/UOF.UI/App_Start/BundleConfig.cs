﻿using System.Web;
using System.Web.Optimization;

namespace UOF
{
    public class BundleConfig
    {
        // For more information on Bundling, visit http://go.microsoft.com/fwlink/?LinkId=254725
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/Scripts/jquery-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryui").Include(
                        "~/Scripts/jquery-ui-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                        "~/Scripts/jquery.unobtrusive*",
                        "~/Scripts/jquery.validate*"));

            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at http://modernizr.com to pick only the tests you need.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                        "~/Scripts/modernizr-*"));

            bundles.Add(new StyleBundle("~/Content/css").Include("~/Content/site.css"));

            bundles.Add(new StyleBundle("~/Content/themes/base/css").Include(
                        "~/Content/themes/base/jquery.ui.core.css",
                        "~/Content/themes/base/jquery.ui.resizable.css",
                        "~/Content/themes/base/jquery.ui.selectable.css",
                        "~/Content/themes/base/jquery.ui.accordion.css",
                        "~/Content/themes/base/jquery.ui.autocomplete.css",
                        "~/Content/themes/base/jquery.ui.button.css",
                        "~/Content/themes/base/jquery.ui.dialog.css",
                        "~/Content/themes/base/jquery.ui.slider.css",
                        "~/Content/themes/base/jquery.ui.tabs.css",
                        "~/Content/themes/base/jquery.ui.datepicker.css",
                        "~/Content/themes/base/jquery.ui.progressbar.css",
                        "~/Content/themes/base/jquery.ui.theme.css"));

            #region "Script Bundle Files Declaration"
            var layoutScripts = new[]
            {
               
               "~/Scripts/Kendo/UOF.kendoGrid.utils.js",
               "~/Scripts/Knockout/knockout-3.2.0.js",
               "~/Scripts/Knockout/knockout.validation.js",
               "~/Scripts/Knockout/knockout.mapping.js",
               "~/Content/plugins/multipleselect-dropdown/bootstrap-select.js",
               "~/Scripts/CommonUILogic/readOnlyPageOnPermission.js",
               "~/Scripts/Login/UoF.Login.js",
               "~/Scripts/CommonUILogic/UoF.CommonUILogic.details.js",
               "~/Scripts/CommonUILogic/confirmationMessage.js",
               "~/Scripts/CommonUILogic/alertMessageTemplate.js",
               "~/Scripts/jquery.sticky.js",
               "~/Content/plugins/input-mask/jquery.inputmask.js",
               "~/Content/plugins/moment/moment-with-locales.js",
               "~/Content/plugins/datetimepicker/bootstrap-datetimepicker.js",
               "~/Content/plugins/timepicker/bootstrap-timepicker.js",
               "~/Content/plugins/multipleselect-dropdown/bootstrap-select.js",
               "~/Scripts/inputmask.js",
               "~/Scripts/inputmask.extensions.js",
               "~/Scripts/inputmask.phone.extensions.js",
            };

            var layoutMinScripts = new[]
            {
                "~/Content/plugins/jQuery/jQuery-2.1.4.min.js",
               "~/Content/bootstrap/js/bootstrap.min.js",
                "~/Content/plugins/datatables/jquery.dataTables.min.js",
               "~/Content/plugins/slimScroll/jquery.slimscroll.min.js",
               "~/Content/plugins/iCheck/icheck.min.js",
               "~/Scripts/underscore.min.js",
               "~/Content/admincss/js/app.min.js",
               "~/Scripts/Kendo/kendo.all.min.js",
            };
            var incidentScripts = new[]
            {
                "~/Scripts/Incident/UoF.Incident.details.js",
                "~/Scripts/Incident/UoF.Constants.js",
                "~/Scripts/Incident/UoF.Incident.details.js",
                "~/Scripts/Incident/UoF.InvolvedEmployee.js",
                "~/Scripts/Incident/UoF.Suspects.js",
                "~/Scripts/Incident/UoF.EmpWitness.js",
                "~/Scripts/Incident/UoF.NonEmpWitness.js",
                "~/Scripts/Incident/UoF.Canine.js",
                "~/Scripts/Incident/UoF.Incident.Deputy.js",
                "~/Scripts/Incident/UoF.Incident.StatisticalData.js",
                "~/Scripts/Incident/UoF.Artifacts.js",
                "~/Scripts/Upload/jquery.ui.widget.js",
                "~/Scripts/Upload/jquery.iframe-transport.js",
                "~/Scripts/Upload/jquery.fileupload.js",
                "~/Scripts/Upload/jquery.fileupload-process.js",
                "~/Scripts/Upload/jquery.fileupload-audio.js",
                "~/Scripts/Upload/jquery.fileupload-video.js",
                "~/Scripts/Upload/jquery.fileupload-validate.js",
                "~/Scripts/Upload/jquery.fileupload-ui.js",
                "~/Scripts/Upload/jquery.fileupload.js",
              };



            #endregion "Script Bundle Files Declaration"

            #region "Style Bundle File Declaration"


            var layoutStyles = new[]
        {
            // Bootstrap 3.3.5 --,
            "~/Content/plugins/datatables/dataTables.bootstrap.css",
            // datepicker --,
            "~/Content/bootstrap-datetimepicker.css",
            // iCheck for checkboxes and radio inputs --,
            "~/Content/plugins/iCheck/all.css",
            // Select2 --,
            "~/Content/plugins/multipleselect-dropdown/bootstrap-select.css",
            // Theme style --,
            "~/Content/admincss/css/AdminLTE.css",
            // Global css --,
            "~/Content/global.css",
        };
            var layoutMinStyles = new[]
        {
            // Bootstrap 3.3.5 --,
            "~/Content/bootstrap/css/bootstrap.min.css",
            // Font Awesome --,
            "~/Content/font-awesome.min.css",
            // Ionicons --,
            "~/Content/ionicons.min.css",
            // Bootstrap Color Picker --,
            "~/Content/plugins/colorpicker/bootstrap-colorpicker.min.css",
            // Bootstrap time Picker --,
            "~/Content/plugins/timepicker/bootstrap-timepicker.min.css",
            "~/Content/plugins/select2/select2.min.css",
            // Theme style --,
            "~/Content/Kendo/kendo.default.min.css" ,
            "~/Content/admincss/css/skins/skin-blue.min.css",
            "~/Content/Kendo/kendo.common.min.css",
            "~/Content/Kendo/kendo.uniform.min.css",
        };




            #endregion "Style Bundle File Declaration"

            #region "Script Bundle "

            /* ==========================================================================================================================
                  1) LayoutScripts it contains all common scripts including athoc customized scripts  [Bundle name : layout-scripts-bundle]
               =========================================================================================================================== */

            bundles.Add(new StyleBundle("~/bundles/layout-scripts-bundle")
              .Include(layoutScripts)
              );

            bundles.Add(new StyleBundle("~/bundles/layout-min-scripts-bundle")
              .Include(layoutMinScripts)
              );

            /*===================================================================================
              2)Incident list bundle scripts  [Bundle name : incident-script-bundle]
          =================================================================================== */
            var incidnetScriptBundle = new ScriptBundle("~/bundles/incident-script-bundle")

                .Include(incidentScripts);

            bundles.Add(incidnetScriptBundle);
            /*===================================================================================
              3)Inmate list bundle scripts  [Bundle name : Inmate-script-bundle]
          =================================================================================== */
            var inmateScriptBundle = new ScriptBundle("~/bundles/inmate-script-bundle")
                .Include("~/Scripts/Inmate/UoF.Inmate.Constants.js")
               .Include("~/Scripts/Inmate/UoF.Inmate.Injury.js");

            bundles.Add(inmateScriptBundle);

            /*===================================================================================
             4)Medical list bundle scripts  [Bundle name : Inmate-script-bundle]
         =================================================================================== */
            var medicalScriptBundle = new ScriptBundle("~/bundles/medical-script-bundle")
                 .Include("~/Scripts/MedicalReport/UoF.MedicalReport.Constants.js")
                .Include("~/Scripts/MedicalReport/UoF.MedicalReport.js");

            bundles.Add(medicalScriptBundle);

            /*===================================================================================
            5)CustodyService list bundle scripts  [Bundle name : Inmate-script-bundle]
        =================================================================================== */
            var CustodyServiceScriptBundle = new ScriptBundle("~/bundles/CustodyService-script-bundle")
                 .Include("~/Scripts/UoFNarrative/UoF.CustodyService.js");

            bundles.Add(CustodyServiceScriptBundle);

               /*===================================================================================
            6)CriminalAnalysis list bundle scripts  [Bundle name : Inmate-script-bundle]
        =================================================================================== */
            var CriminalAnalysisScriptBundle = new ScriptBundle("~/bundles/CriminalAnalysis-script-bundle")
                 .Include("~/Scripts/UoFNarrative/UoF.CriminalAnalysis.js");

            bundles.Add(CriminalAnalysisScriptBundle);

            /*===================================================================================
          6)CriminalAnalysis list bundle scripts  [Bundle name : Inmate-script-bundle]
      =================================================================================== */
            var IRScriptBundle = new ScriptBundle("~/bundles/IR-script-bundle")
                 .Include("~/Scripts/UoFNarrative/UoF.Narrative.Constants.js")
                   .Include("~/Scripts/UoFNarrative/UoF.Narrative.IncidentReport.js");

            bundles.Add(IRScriptBundle);

            #endregion "Script Bundles"
            #region"Style Bundles"

            bundles.Add(new StyleBundle("~/bundles/layout-style-bundle")
               .Include(layoutMinStyles)
               .Include(layoutStyles)
               );

            #endregion "Style Bundles"
            BundleTable.EnableOptimizations = false;
        }

    }
}