﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Xml;
using UOF.UI.Models;
using System.Xml.XPath;

namespace UOF.UI.Controllers
{
    public class FileUploadController : BaseController
    {
        private object _lock = new object();

        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult DownloadFile(string fileName, string type, int bookingId)
        {
            string fullName = GetFilePath(bookingId, fileName, false, type);

            if (!System.IO.File.Exists(fullName))
            {
                return HttpNotFound();
            }

            var fileBytes = System.IO.File.ReadAllBytes(fullName);
            var response = new FileContentResult(fileBytes, "application/octet-stream")
            {
                FileDownloadName = fileName
            };
            return response;
        }

        private string GetFilePath(int bookingId, string fileName = null, bool isForUpload = true, string selectedType = "")
        {
            string path = string.Empty;
            string incidentId = (string)UofSessionValue.Get("SelectedIncidentId");
            var UploadPath = Server.MapPath(ConfigurationManager.AppSettings["FolderPath"]);
            UploadPath = UploadPath + "\\" + incidentId;
            if (!string.IsNullOrWhiteSpace(selectedType) && bookingId > 0)
            {
                UploadPath = UploadPath + "\\" + bookingId + "\\" + selectedType;
            }
            else if (!string.IsNullOrWhiteSpace(selectedType) && bookingId == 0)
            {
                UploadPath = UploadPath + "\\" + selectedType;
            }
            else if (bookingId > 0)
            {
                UploadPath = UploadPath + "\\" + bookingId;
            }

            if (isForUpload && !Directory.Exists(UploadPath))
            {
                Directory.CreateDirectory(UploadPath);
            }
            if (!string.IsNullOrWhiteSpace(fileName))
            {
                path = Path.Combine(UploadPath, fileName);
            }
            else
                path = UploadPath;
            return path;
        }
        private string GetFilePathforMedical(string fileName = null,  string selectedType = "")
        {
            string path = string.Empty;
            string incidentId = (string)UofSessionValue.Get("SelectedIncidentId");
            string roleCode = (string)UofSessionValue.Get("UserCode");
            var UploadPath = Server.MapPath(ConfigurationManager.AppSettings["MedicalImageFolderPath"]);
            UploadPath = UploadPath + "\\" + incidentId + "\\" + roleCode+"\\"+selectedType;
            if (!Directory.Exists(UploadPath))
            {
                Directory.CreateDirectory(UploadPath);
            }
            if (!string.IsNullOrWhiteSpace(fileName))
            {
                path = Path.Combine(UploadPath, fileName);
            }
            else
                path = UploadPath;
            return path;
        }



        [HttpPost]
        public ContentResult UploadAudioVideoFile(int bookingId, string selectedType)
        {
            var listOfFiles = new List<UploadFilesResult>();
            foreach (string file in Request.Files)
            {
                var fileDataContent = Request.Files[file];
                var fileName = Convert.ToString(Request.Headers["X-Chunk-fname"] ?? "");
                if (fileDataContent != null && fileDataContent.ContentLength > 0)
                {
                    // take the input stream, and save it to a temp folder using
                    // the original file.part name posted
                    var stream = fileDataContent.InputStream;
                    string path = this.GetFilePath(bookingId, fileName, true, selectedType);
                    try
                    {
                        if (System.IO.File.Exists(path))
                            System.IO.File.Delete(path);
                        using (var fileStream = System.IO.File.Create(path))
                        {
                            stream.CopyTo(fileStream);
                        }

                        listOfFiles.Add(new UploadFilesResult()
                        {
                            Name = fileDataContent.FileName,
                            Length = fileDataContent.ContentLength,
                            Type = fileDataContent.ContentType
                        });
                        // Once the file part is saved, see if we have enough to merge it
                        MergeFile(path, fileDataContent.ContentLength);
                    }
                    catch (IOException ex)
                    {
                        // handle
                    }
                }
            }
            if (Request.Files.Count > 0)
                return Content("{\"name\":\"" + listOfFiles[0].Name + "\",\"type\":\"" + listOfFiles[0].Type + "\",\"size\":\"" + string.Format("{0} bytes", listOfFiles[0].Length) + "\"}", "application/json");
            else
                return Content("{\"name\":\"" + "Nothing" + "\"");
        }

        private bool MergeFile(string FileName, int length)
        {
            bool rslt = false;
            // parse out the different tokens from the filename according to the convention
            string partToken = ".part_";
            if (FileName.IndexOf(partToken) > 0)
            {
                string baseFileName = FileName.Substring(0, FileName.IndexOf(partToken));
                string trailingTokens = FileName.Substring(FileName.IndexOf(partToken) + partToken.Length);
                int FileIndex = 0;
                int FileCount = 0;
                int.TryParse(trailingTokens.Substring(0, trailingTokens.IndexOf(".")), out FileIndex);
                int.TryParse(trailingTokens.Substring(trailingTokens.IndexOf(".") + 1), out FileCount);
                // get a list of all file parts in the temp folder
                string Searchpattern = Path.GetFileName(baseFileName) + partToken + "*";

                string[] FilesList = Directory.GetFiles(Path.GetDirectoryName(FileName), Searchpattern);

                if (FilesList.Count() == FileCount)
                {
                    //  merge .. improvement would be to confirm individual parts are there / correctly in
                    // sequence, a security check would also be important
                    // only proceed if we have received all the file chunks
                    List<SortedFile> MergeList = new List<SortedFile>();
                    foreach (string File in FilesList)
                    {
                        SortedFile sFile = new SortedFile();
                        sFile.FileName = File;
                        trailingTokens = File.Substring(File.IndexOf(partToken) + partToken.Length);
                        int.TryParse(trailingTokens.
                           Substring(0, trailingTokens.IndexOf(".")), out FileIndex);
                        sFile.FileOrder = FileIndex;
                        MergeList.Add(sFile);
                    }
                    var MergeOrder = MergeList.OrderBy(s => s.FileOrder).ToList();
                    using (FileStream FS = new FileStream(baseFileName, FileMode.Create))
                    {
                        // merge each file chunk back into one contiguous file stream
                        foreach (var chunk in MergeOrder)
                        {
                            try
                            {
                                using (FileStream fileChunk =
                                   new FileStream(chunk.FileName, FileMode.Open))
                                {
                                    fileChunk.CopyTo(FS);
                                }
                            }
                            catch (IOException ex)
                            {
                                // handle
                            }
                        }
                        rslt = true;

                    }

                    foreach (string f in FilesList)
                    {
                        System.IO.File.Delete(f);
                    }
                }
            }
            return true;
        }

        [HttpPost]
        public ContentResult DeleteFile(string fname, string type, int bookingId)
        {
            try
            {
                fname = this.GetFilePath(bookingId, fname, false, type);
                FileInfo filePath = new FileInfo(fname);
                if (filePath.Exists)
                    filePath.Delete();
            }
            catch (Exception)
            {
                return Content("false");
            }

            return Content("true");
        }

        [HttpGet]
        public ContentResult GetAllFiles(int bookingId)
        {
            List<FileUploadGridContent> arrFileName = new List<FileUploadGridContent>();
            try
            {
                var fPath = this.GetFilePath(bookingId);
                DirectoryInfo info = new DirectoryInfo(fPath);

                foreach (var item in info.GetDirectories())
                {
                    foreach (var fName in item.GetFiles())
                    {
                        FileUploadGridContent uploadFName = new FileUploadGridContent();
                        uploadFName.FileName = fName.Name;
                        uploadFName.SelectedFileType = item.Name;
                        arrFileName.Add(uploadFName);
                    }
                }
                return Content(JsonConvert.SerializeObject(arrFileName));
            }
            catch (Exception)
            {
                return Content("NoData");
            }
        }

        [HttpGet]
        public ContentResult isFilesExist(int bookingId)
        {
            bool fileExist = false;
            try
            {
                var fPath = this.GetFilePath(bookingId);
                DirectoryInfo info = new DirectoryInfo(fPath);
                foreach (var item in info.GetDirectories())
                {
                    if (item.GetFiles().Length > 0)
                    {
                        fileExist = true;
                        break;
                    }
                }

                return Content(JsonConvert.SerializeObject(fileExist));
            }
            catch (Exception)
            {
                return Content(fileExist.ToString());
            }
        }

        [HttpPost]
        public ContentResult SaveInterviewType(FileUploadGridContent content, int bookingId)
        {
            bool fileExist = false;
            string fileName = "interviewData.xml";
            try
            {
                lock (_lock)
                {
                    var fPath = this.GetFilePath(bookingId);
                    fPath = fPath + "\\" + fileName;
                    if (System.IO.File.Exists(fPath))
                    {
                        System.IO.File.Delete(fPath);
                    }

                    if (content != null && content.InterviewType != null && content.InterviewType.Count > 0)
                    {
                        XmlDocument doc = new XmlDocument();
                        string strInterviewType = "<InterviewTypes>";
                        foreach (var item in content.InterviewType)
                        {
                            strInterviewType += "<" + item.Key + ">" + item.Value + "</" + item.Key + ">";
                        }
                        strInterviewType += "</InterviewTypes>";
                        doc.LoadXml(strInterviewType);
                        doc.Save(fPath);
                    }
                }

                return Content(JsonConvert.SerializeObject(fileExist));
            }
            catch (Exception)
            {
                return Content(fileExist.ToString());
            }
        }

        [HttpGet]
        public ContentResult GetInterviewType(int bookingId)
        {
            string fileName = "interviewData.xml";
            Dictionary<string, string> interviewType = null;
            try
            {
                lock (_lock)
                {
                    var fPath = this.GetFilePath(bookingId);
                    fPath = fPath + "\\" + fileName;
                    if (System.IO.File.Exists(fPath))
                    {
                        interviewType = new Dictionary<string, string>();
                        XmlDocument doc = new XmlDocument();
                        doc.Load(fPath);
                        XmlNode node = doc.SelectSingleNode("InterviewTypes");
                        XmlNodeList nodes = node.ChildNodes;
                        foreach (XmlNode child in nodes)
                        {
                            interviewType.Add(child.Name, child.InnerText);
                        }
                    }
                }
                return Content(JsonConvert.SerializeObject(interviewType));
            }
            catch (Exception)
            {
                return Content("");
            }

        }


        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult FileUpload()
        {
            if (Request.Files.Count > 0)
            {
                try
                {
                    var uploadFile = System.Web.HttpContext.Current.Request.Files["MyImages"];
                    string relativePath = "";
                    string physicalPath = "";
                    if (uploadFile != null && uploadFile.ContentLength > 0)
                    {
                        physicalPath = this.GetFilePathforMedical(uploadFile.FileName, "MR");
                        FileInfo filePath = new FileInfo(physicalPath);
                        if (filePath.Exists)
                            filePath.Delete();

                       
                        //string physicalPath = Server.MapPath(relativePath);
                         uploadFile.SaveAs(physicalPath);

                         var test = Path.GetDirectoryName(physicalPath);
                         relativePath = GetFileURL(uploadFile.FileName);
                         return Json(new { Success = true, relativePath });
                    }
                    return Json(new { Success = false});
                }
                catch (Exception ex)
                {
                    return Json(new { Success = false, Messages = ex.Message });
                }
            }
            else
            {
                return Json("No files selected.");
            }
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult GetMedicalUploadedFile()
        {
            try
            {
               
                var filters = new String[] { "jpg", "jpeg", "png", "gif", "tiff", "bmp" };
                var files = GetFilesFrom(this.GetFilePathforMedical("", "MR"), filters, false);
                if (files != null && files.Length > 0)
                {
                    var relativePath = GetFileURL(Path.GetFileName(files[0]));
                    return Json(new { Success = true, relativePath });
                }
                else
                    return Json(new{ Success = false,});
                
            }
            catch (Exception ex)
            {

                return Json(new { Success = false, Messages = ex.Message });
            }
        }

        private string GetFileURL(string fileName)
        {
                return Url.Content(ConfigurationManager.AppSettings["MedicalImageFolderPath"] +
                       "//" + (string)UofSessionValue.Get("SelectedIncidentId") +
                       "//" + (string)UofSessionValue.Get("UserCode") + "//" + "MR" + "//" + Path.GetFileName(fileName)); 
            
            
        }
        public static String[] GetFilesFrom(String searchFolder, String[] filters, bool isRecursive)
        {
            List<String> filesFound = new List<String>();
            var searchOption = isRecursive ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly;
            foreach (var filter in filters)
            {
                filesFound.AddRange(Directory.GetFiles(searchFolder, String.Format("*.{0}", filter), searchOption));
            }
            return filesFound.ToArray();
        }

    }

    public class FileUploadGridContent
    {
        public string FileName { get; set; }

        public string SelectedFileType { get; set; }

        public Dictionary<string, string> InterviewType { get; set; }
    }


}
