﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using System.Web.Mvc;
using UOF.Common.EntityModel;
using UOF.Logging;
using UOF.UI.Filters;
using UOF.UI.Helper;
using UOF.UI.Models;


namespace UOF.UI.Controllers
{

    public class IncidentController : BaseController
    {
        static readonly ILogService LogService = new LogService(typeof(IncidentController));
        //
        // GET: /Incident/
        public ActionResult Incident()
        {
            UoFHelper helper = new UoFHelper();
            ViewBag.IncidentId = (string)UofSessionValue.Get("ApprovedIncidentId");
            ViewBag.SelectedPageNumber = (string)UofSessionValue.Get("SelectedPageNumber");
            UofSessionValue.Set("ApprovedIncidentId", null);
            UofSessionValue.Set("SelectedPageNumber", null);
            return View("Index");
        }

        [FormBasedAuth(IncidentPermission.IncidentDetails)]
        public ActionResult IncidentDetail(string incidentId, string mode)
        {
            ViewBag.CurrentMode = mode;
            ViewBag.IncidentId = incidentId;
            return View("IncidentDetails");
        }

        [HttpPost]
        //To assign the Incident Id in the Sesssion
        public ActionResult GetIncidentId(string id, string PageNumber)
        {
            HttpClient httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Accept.Clear();
            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            UoFModel result = null;
            if (!string.IsNullOrWhiteSpace(id) && id != "0")
            {
                UofSessionValue.Set("SelectedIncidentId", id);

                if (!string.IsNullOrWhiteSpace(PageNumber))
                    UofSessionValue.Set("SelectedPageNumber", PageNumber);

                string query = string.Format(ConfigurationManager.AppSettings["UOF.API"] + "/api/Incident/GetIncidentData?incidentId={0}&userId={1}", id, (string)UofSessionValue.Get("UserCode"));
                try
                {
                    var resp = httpClient.GetAsync(query).Result;
                    resp.EnsureSuccessStatusCode();
                    result = resp.Content.ReadAsAsync<UoFModel>().Result;
                    if (result != null && result.IncidentDetails != null)
                    {
                        UofSessionValue.Set("SelectedIncidentURN", result.IncidentDetails.URN);
                        UofSessionValue.Set("SelectedIncidentDate", result.IncidentDetails.IncidentDate.ToString());
                        UofSessionValue.Set("ReferenceNo", result.IncidentDetails.ReferenceNo);
                        UofSessionValue.Set("SelectedIncidentCategory", result.IncidentDetails.IncidentCategoryId.ToString());
                        UofSessionValue.Set("IncidentLocation", result.IncidentDetails.IncidentName);
                        UofSessionValue.Set("ForceLocation", result.IncidentDetails.ForceLocation);
                        UofSessionValue.Set("Station", result.IncidentDetails.Station);
                        UofSessionValue.Set("OnDutySupervisor", result.OnDutySupervisor);
                        UofSessionValue.Set("InvestSupervisor", result.InvestSupervisor);
                        UofSessionValue.Set("WC", result.WC);
                        UofSessionValue.Set("eLot", result.IncidentDetails.eLOTS);

                        if (result.IncidentDetails.ForceTypeId != null)
                        {
                            if (result.IncidentDetails.ForceTypeId.Contains("TP") || result.IncidentDetails.ForceTypeId.Contains("TR") || result.IncidentDetails.ForceTypeId.Contains("CR") || result.IncidentDetails.ForceTypeId.Contains("HR"))
                                UofSessionValue.Set("IsCFRTNotified", "true");
                        }
                        else
                            UofSessionValue.Set("IsCFRTNotified", "false");
                        if (result.IncidentDetails.IsIABNotified == "Y")
                            UofSessionValue.Set("IsIABNotified", "true");
                        else
                            UofSessionValue.Set("IsIABNotified", "false");

                        var model = new
                        {
                            success = "true",
                            Data = result,
                            IsCFRTNotified = (string)UofSessionValue.Get("IsCFRTNotified"),
                            IsIABNotified = result.IncidentDetails.IsIABNotified,
                            InvestSupervisor = result.IncidentDetails.InvestOfficerId
                        };
                        return Json(model);
                    }
                }
                catch (Exception ex)
                {
                    LogService.CustomError(ex, "GetIncidentId", ex.Source.ToString(), ex.StackTrace.ToString());
                }
            }
            return Content("");
        }
        [HttpGet]
        //To assign the Incident Id in the Sesssion
        public ActionResult verifyIncidentCategory(string id, int formID)
        {
            UofSessionValue.Set("SelectedIncidentId", id);
            HttpClient httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Accept.Clear();
            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            string query = string.Format(ConfigurationManager.AppSettings["UOF.API"] + "/api/Incident/VerifyCatFormsStatus?incidentId={0}&formID={1}", Convert.ToInt32(id), formID);
            try
            {
                var resp = httpClient.GetAsync(query).Result;
                resp.EnsureSuccessStatusCode();
                bool result = resp.Content.ReadAsAsync<bool>().Result;
                return Content(result ? "true" : "false");
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "VerifyCatFormsStatus", ex.Source.ToString(), ex.StackTrace.ToString());
            }
            return Content("");
        }

        [HttpPost]
        //To assign the Incident Id in the Sesssion
        public ActionResult setApprovedIncident(string incidentID)
        {
            UofSessionValue.Set("ApprovedIncidentId", incidentID);
            return Content("true");
        }
    }
}
