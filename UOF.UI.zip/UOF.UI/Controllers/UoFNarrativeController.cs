﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UOF.UI.Filters;
using UOF.UI.Helper;

namespace UOF.UI.Controllers
{
    public class UoFNarrativeController : BaseController
    {
        //
        // GET: /UoFNarrative/
        [FormBasedAuth(SergeantPermission.Ser_ForceNarrativeReport)]
        public ActionResult Index(string formName)
        {
            return View(formName);
        }


    }
}
