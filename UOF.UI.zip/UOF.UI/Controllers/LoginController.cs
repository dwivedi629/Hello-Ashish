﻿
using System.Web.Mvc;
using UOF.Business;
using UOF.UI.Helper;
using UOF.UI.Models;
using System.Configuration;
using System;
using UOF.Logging;
using System.Web;

namespace UOF.UI.Controllers
{
    public class LoginController : Controller
    {
        readonly ILogService LogService = new LogService(typeof(LoginController));

        public ActionResult Index(string returnUrl)
        {
            UoFHelper helper = new UoFHelper();
            try
            {
                if (ConfigurationManager.AppSettings["allowWithLogin"] == "true")
                {
                    return View("Login");
                }
                if (helper.validateUser())
                {

                    if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                        return Redirect(returnUrl);
                    else
                        return RedirectToAction("LoggedInInfo", new { roleCode = (string)UofSessionValue.Get("RoleCode") });
                }
                //else
                //    return RedirectToAction("Index", "Unauthorized");
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "Logged - Index", ex.Source, ex.StackTrace);
            }
            return null;
        }


        public ActionResult LoggedInInfo(string roleCode)
        {
            try
            {
                var LoggedInData = new
                {
                    success = "success",
                    UserId = 1,
                    LoggedInRole = roleCode,
                    data = Url.Action("Incident", "Incident"),
                };
                var userCode = string.Empty;
                UofAuthorizedUserPermission.GetAllRequiredEntities();
                if (ConfigurationManager.AppSettings["allowWithLogin"] == "true")
                {
                    //TODO: Refactor
                    switch (roleCode)
                    {
                        case "SGT":
                            userCode = "517771";//234272"; //TODO: refactor
                            UofSessionValue.Set("UserName", "Sergeant");
                            UofSessionValue.Set("Rank", "2"); //Rank 
                            break;
                        case "DSG":
                            userCode = "234271"; //TODO: refactor
                            UofSessionValue.Set("UserName", "Deputy Shreiff");
                            UofSessionValue.Set("Rank", "1"); //Rank 
                            break;
                        case "WC":
                            userCode = "408494"; //TODO: refactor
                            UofSessionValue.Set("UserName", "Watch Commander");
                            UofSessionValue.Set("Rank", "3"); //Rank 
                            break;
                        case "CAPT":
                            userCode = "216980"; //TODO: refactor
                            UofSessionValue.Set("UserName", "Unit Commander");
                            UofSessionValue.Set("Rank", "4"); //Rank 
                            break;
                        case "CMDR":
                            userCode = "413798"; //TODO: refactor
                            UofSessionValue.Set("UserName", "Commander");
                            UofSessionValue.Set("Rank", "5"); //Rank 
                            break;
                        case "DC":
                            userCode = "786001"; //TODO: refactor
                            UofSessionValue.Set("UserName", "CHIEF");
                            UofSessionValue.Set("Rank", "6"); //Rank 
                            break;
                        case "CFRT":
                            userCode = "CFRT"; //TODO: refactor
                            UofSessionValue.Set("UserName", "CFRT");
                            UofSessionValue.Set("Rank", "8"); //Rank 
                            break;
                        default:
                            break;
                    }
                    UofSessionValue.Set("RoleCode", roleCode);
                    UofSessionValue.Set("UserCode", userCode);
                }

                //End
                if (UofAuthorizedUserPermission.IsAuthorized(IncidentPermission.IncidentList))
                {

                    if (ConfigurationManager.AppSettings["allowWithLogin"] == "true")
                    {
                        return Json(LoggedInData, "application/json;charset=utf-8", JsonRequestBehavior.AllowGet);

                    }
                    return RedirectToAction("Incident", "Incident");

                }
                else
                {

                    if (ConfigurationManager.AppSettings["allowWithLogin"] == "true")
                    {
                        LoggedInData = new
                        {
                            success = "unauthorized",
                            UserId = 1,
                            LoggedInRole = roleCode,
                            data = Url.Action("Index", "Unauthorized"),
                        };
                        return Json(LoggedInData, "application/json;charset=utf-8", JsonRequestBehavior.AllowGet);
                    }
                    //return RedirectToAction("Index", "Unauthorized");

                }
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "LoggedInfo", ex.Source, ex.StackTrace);
            }
            return null;
        }

        public ActionResult Logout()
        {
            Uri lastUrl = System.Web.HttpContext.Current.Request.UrlReferrer;

            UofSessionValue.ExpireSession();

            //if (ConfigurationManager.AppSettings["allowWithLogin"] == "true")
            //{
            //    return RedirectToAction("Index", "Login");
            //}
            if (lastUrl != null)
                return View("logout", new { returnUrl = lastUrl.PathAndQuery });
            else
                return View("logout");


        }
    }
}
