﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UOF.UI.Filters;
using UOF.UI.Helper;

namespace UOF.UI.Controllers
{
    [FormBasedAuth(SettingPermission.Settings)]
    public class SettingsController : BaseController
    {
        //
        // GET: /Setting/
        public ActionResult Index()
        {
            return View("_FormPermission");
        }

        public ActionResult ChangeRole()
        {
            return View("ChangeRole");
        }
        public ActionResult ChangeOwner()
        {
            return View("ChangeOwner");
        }
        public ActionResult ChangePackageOwner()
        {
            return View("ChangePackageOwner");
        }
    }
}
