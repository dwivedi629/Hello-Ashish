﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using System.Web.Mvc;
using UOF.Common.EntityModel;
using UOF.Logging;
using UOF.UI.Filters;
using UOF.UI.Helper;
using UOF.UI.Models;

namespace UOF.UI.Controllers
{
    public class SupervisorsReportforceController : BaseController
    {
        //
        // GET: /SupervisorsReportforce/
        [FormBasedAuth(SergeantPermission.Ser_UofC1Incidents)]
        public ActionResult SupervisorsReportforce(string FormId, string IncidentId, string SubmittedId)
        {
            ViewBag.FormId = FormId;
            ViewBag.IncidentId = IncidentId;
            ViewBag.DeputyId = SubmittedId;
            return View();
        }
        //[FormBasedAuth(SergeantPermission.Ser_UofC1Incidents)]
        public ActionResult UoFTracking(int FormId)
        {
            ViewBag.FormId = FormId;
            ViewBag.IncidentId = Convert.ToInt32((string)UofSessionValue.Get("SelectedIncidentId")); 
            //int incidentId = Convert.ToInt32((string)UofSessionValue.Get("SelectedIncidentId"));
            //HttpClient httpClient = new HttpClient();
            //httpClient.DefaultRequestHeaders.Accept.Clear();
            //httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            //TrackingModel result = null;
            //string query = string.Format(ConfigurationManager.AppSettings["UOF.API"] + "/api/UOFForm/GetTrackingDetails?FormId={0}&IncidentId={1}", FormId, incidentId);
            //try
            //{
            //    var resp = httpClient.GetAsync(query).Result;
            //    resp.EnsureSuccessStatusCode();
            //    result = resp.Content.ReadAsAsync<TrackingModel>().Result;
            //    if (result != null)
            //    {
            //        return View("UoFTracking", result);
            //    }
            //}
            //catch (Exception ex)
            //{
            //    //LogService.CustomError(ex, "GetIncidentId", ex.Source.ToString(), ex.StackTrace.ToString());
            //}
            return View();
        }

    }
}
