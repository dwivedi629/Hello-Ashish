﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UOF.UI.Filters;
using UOF.UI.Helper;

namespace UOF.UI.Controllers
{
    public class CustodyServicesController : BaseController
    {
        //
        // GET: /CustodyServices/
        [FormBasedAuth(DuptyPermission.D_CSDCAS)]
        public ActionResult CustodyServices(string FormId, string IncidentId, string SubmittedId)
        {
            ViewBag.FormId = FormId;
            ViewBag.IncidentId = IncidentId;
            ViewBag.DeputyId = SubmittedId;
            return View("CustodyServices");
        }

    }
}
