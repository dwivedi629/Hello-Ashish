﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UOF.UI.Filters;
using UOF.UI.Helper;

namespace UOF.UI.Controllers
{
    public class CommanderReviewController : BaseController
    {
        //
        // GET: /CommanderReview/
         [FormBasedAuth(CommanderPermission.C_UofReview)]
        public ActionResult CommanderUoFReview(string FormId, string IncidentId, string SubmittedId)
        {
            ViewBag.FormId = FormId;
            ViewBag.IncidentId = IncidentId;
            ViewBag.SubmittedId = SubmittedId;
            return View();
        }

    }
}
