﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UOF.UI.Filters;

namespace UOF.UI.Controllers
{
    [SessionExpireAttribute]
    public class BaseController : Controller
    {

    }
}
