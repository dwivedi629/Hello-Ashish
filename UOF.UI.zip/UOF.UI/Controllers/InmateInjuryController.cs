﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UOF.UI.Filters;
using UOF.UI.Helper;

namespace UOF.UI.Controllers
{
    public class InmateInjuryController : BaseController
    {
        //
        // GET: /InmateInjury/
        [FormBasedAuth(DuptyPermission.D_InmateInjurtIllness)]
        public ActionResult InmateInjury(string FormId, string IncidentId, string SubmittedId)
        {
            ViewBag.FormId = FormId;
            ViewBag.IncidentId = IncidentId;
            ViewBag.DeputyId = SubmittedId;
            return View("InmateInjury");
        }

    }
}
