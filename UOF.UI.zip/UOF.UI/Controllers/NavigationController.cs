﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using Kendo.Mvc.UI;
using Kendo.Mvc.UI.Fluent;
using UOF.UI.Helper;
using System.Threading.Tasks;
using UOF.Common.EntityModel;
using UOF.UI.Models;
using UOF.Common.Utilities;
using UOF.Logging;

namespace UOF.UI.Controllers
{
    public class NavigationController : BaseController
    {
        //
        // GET: /Navigation/
        readonly ILogService LogService = new LogService(typeof(UoFHelper));
        [ChildActionOnly]
        public ActionResult MainMenu()
        {
            MenuItem rootMenuItem = new MenuItem() { Text = "Root" };
            try
            {
                string rank = (string)UofSessionValue.Get("Rank");
                bool isSettings = false;
                if (rank == "2" || rank == "3" || rank == "4" || rank == "5" || rank == "6")
                    isSettings = true;

                string username = this.HttpContext.User.Identity.Name;
                LogService.CustomInfo("MainMenu", "username : ", username);
                MenuItem homeMenuItem = new MenuItem() { ImageUrl = "~/Images/home-icon.png", ActionName = "Incident", ControllerName = "Incident" };
                MenuItem reportMenuItem = new MenuItem() { Text = "Report" };
                MenuItem settingMenuItem = null;
                if (isSettings)
                    settingMenuItem = new MenuItem() { Text = "Settings" };

                homeMenuItem.ImageHtmlAttributes.Add("class", "home-icon");
                RouteValueDictionary routeValues = new RouteValueDictionary();
                rootMenuItem.Items.Add(homeMenuItem);
                List<FormsNameSettings> frmsName = UofAuthorizedUserPermission.GetFormsName();
                if (frmsName != null && frmsName.Any())
                {
                    MenuItem mainMenu = null;
                    frmsName = frmsName.FindAll(a => Convert.ToBoolean(a.IsMenuItem));
                    var parentFormsName = frmsName.FindAll(a => a.ParentId == 0);
                    routeValues = new RouteValueDictionary();
                    routeValues["FormId"] = 0;
                    routeValues["reportName"] = "UoF_SupervisorsReport";
                    reportMenuItem.Items.Add(new MenuItem() { Text = "Supervisory", ActionName = "Index", ControllerName = "Report", RouteValues = routeValues });
                    reportMenuItem.HtmlAttributes.Add("Id", "topWidgetRptItem");
                    if (isSettings)
                        settingMenuItem.HtmlAttributes.Add("Id", "topWidgetSetItem");
                    foreach (var parentItem in parentFormsName)
                    {
                        LogService.CustomInfo("MainMenu", "MainMenu", parentItem.FormName);
                        if (!string.IsNullOrWhiteSpace(parentItem.FormCode) && parentItem.FormCode == LogoutPermission.LogoutMenu)
                        {
                            mainMenu = new MenuItem() { Text = parentItem.FormName, ActionName = parentItem.ActionName, ControllerName = parentItem.ControllerName };
                        }
                        if (UofAuthorizedUserPermission.IsAuthorized(parentItem.FormCode))
                        {
                            if (parentItem.FormCode != LogoutPermission.LogoutMenu)
                            {
                                if (parentItem.FormCode == SettingPermission.Settings)
                                {

                                    foreach (var childItem in frmsName)
                                    {
                                        if ((parentItem.FormId == childItem.ParentId) && (childItem.ParentId != 0))
                                        {
                                            //MenuItem setMenu = mainMenu = new MenuItem() { Text = parentItem.FormName, ActionName = parentItem.ActionName, ControllerName = parentItem.ControllerName };
                                            MenuItem childMenu = new MenuItem() { Text = childItem.FormName, ActionName = childItem.ActionName, ControllerName = childItem.ControllerName };
                                            if (isSettings)
                                                settingMenuItem.Items.Add(childMenu);
                                        }
                                    }
                                }
                                else
                                {
                                    mainMenu = new MenuItem() { Text = parentItem.FormName, ActionName = parentItem.ActionName, ControllerName = parentItem.ControllerName };
                                    //if (this.isMenuRequired(parentItem.FormName))
                                    //{
                                    mainMenu.HtmlAttributes.Add("Id", "topWidgetMenuItem");
                                    foreach (var childItem in frmsName)
                                    {
                                        if ((parentItem.FormId == childItem.ParentId) && (childItem.ParentId != 0))
                                        {
                                            routeValues = new RouteValueDictionary();
                                            routeValues["FormId"] = childItem.FormId;
                                            MenuItem childMenu = new MenuItem() { Text = childItem.FormName, ActionName = childItem.ActionName, ControllerName = childItem.ControllerName, RouteValues = routeValues };
                                            childMenu.HtmlAttributes.Add("Id", "frm" + childItem.FormId);
                                            mainMenu.Items.Add(childMenu);

                                            RouteValueDictionary RptValues = new RouteValueDictionary();
                                            RptValues["FormId"] = childItem.FormId;
                                            RptValues["reportName"] = childItem.Text;
                                            MenuItem rptMenu = new MenuItem() { Text = childItem.FormName, ActionName = "Index", ControllerName = "Report", RouteValues = RptValues };
                                            rptMenu.HtmlAttributes.Add("Id", "rpt" + childItem.FormId);
                                            reportMenuItem.Items.Add(rptMenu);
                                        }
                                    }
                                    rootMenuItem.Items.Add(mainMenu);
                                }
                                //}
                            }
                        }
                    }
                    rootMenuItem.Items.Add(reportMenuItem); // Report Menu - Commented for TIme being
                    if (isSettings)
                        rootMenuItem.Items.Add(settingMenuItem);  // Settings Menu
                    rootMenuItem.Items.Add(mainMenu);  // Logout Menu
                }

            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "MainMenu", ex.Source, ex.StackTrace);
            }
            return PartialView(rootMenuItem);
        }

        private bool isMenuRequired(string frmName)
        {
            string roleCode = (string)UofSessionValue.Get("RoleCode");
            if (!string.IsNullOrWhiteSpace(roleCode))
            {

                frmName = frmName.Replace(" ", "").ToLower();

                if (roleCode == Constants.UserRoles.SGT.ToString() && frmName != "sergeant")
                    return false;
                else if (roleCode == Constants.UserRoles.WC.ToString() && frmName != "watchcommander")
                    return false;
                else if (roleCode == Constants.UserRoles.CAPT.ToString() && frmName != "unitcommander")
                    return false;
                else if (roleCode == Constants.UserRoles.CMDR.ToString() && frmName != "commander")
                    return false;
                else if (roleCode == Constants.UserRoles.MS.ToString() && frmName != "medicalstaff")
                    return false;
                else if (roleCode == Constants.UserRoles.CA.ToString() && frmName != "custodyassistant")
                    return false;
                else if (roleCode == Constants.UserRoles.DC.ToString() && frmName != "divisionchief")
                    return false;
                else if (roleCode == Constants.UserRoles.DI.ToString() && frmName != "discovery")
                    return false;
                else
                    return true;
            }
            return true;
        }
    }
}
