﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Xml;
using UOF.UI.Models;
using System.Xml.XPath;
using UOF.Business;
using UOF.Common.EntityModel;
using UOF.Logging;
using System.Net.Http;
using System.Net.Http.Headers;

namespace UOF.UI.Controllers
{
    public class ArtifactsUploadController : Controller
    {
        static readonly ILogService LogService = new LogService(typeof(ArtifactsUploadController));
        private object _lock = new object();

        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult DownloadFile(string fileName,int incidentId)
        {
            string fullName = GetFilePath(incidentId, fileName, false);

            if (!System.IO.File.Exists(fullName))
            {
                return HttpNotFound();
            }

            var fileBytes = System.IO.File.ReadAllBytes(fullName);
            var response = new FileContentResult(fileBytes, "application/octet-stream")
            {
                FileDownloadName = fileName
            };
            return response;
        }

        private string GetFilePath(int incidentId, string fileName = null, bool isForUpload = true)
        {
            string path = string.Empty;
            var UploadPath = Server.MapPath(ConfigurationManager.AppSettings["ArtifactFolder"]);
            UploadPath = UploadPath + "\\" + incidentId;
           
            if (isForUpload && !Directory.Exists(UploadPath))
            {
                Directory.CreateDirectory(UploadPath);
            }
            if (!string.IsNullOrWhiteSpace(fileName))
            {
                path = Path.Combine(UploadPath, fileName);
            }
            else
                path = UploadPath;
            return path;
        }

        [HttpPost]
        public ContentResult UploadArtifactFiles(int incidentId)
        {
            var listOfFiles = new List<UploadFilesResult>();
            foreach (string file in Request.Files)
            {
                var fileDataContent = Request.Files[file];
                var fileName = Convert.ToString(Request.Headers["X-Chunk-fname"] ?? "");
                if (fileDataContent != null && fileDataContent.ContentLength > 0)
                {
                    // take the input stream, and save it to a temp folder using
                    // the original file.part name posted
                    var stream = fileDataContent.InputStream;
                    string path = this.GetFilePath(incidentId, fileName, true);
                    try
                    {
                        if (System.IO.File.Exists(path))
                            System.IO.File.Delete(path);
                        using (var fileStream = System.IO.File.Create(path))
                        {
                            stream.CopyTo(fileStream);
                        }

                        listOfFiles.Add(new UploadFilesResult()
                        {
                            Name = fileDataContent.FileName,
                            Length = fileDataContent.ContentLength,
                            Type = fileDataContent.ContentType
                        });
                        // Once the file part is saved, see if we have enough to merge it
                        MergeFile(path, fileDataContent.ContentLength, incidentId);
                    }
                    catch (IOException ex)
                    {
                        // handle
                    }
                }
            }
            if (Request.Files.Count > 0)
                return Content("{\"name\":\"" + listOfFiles[0].Name + "\",\"type\":\"" + listOfFiles[0].Type + "\",\"size\":\"" + string.Format("{0} bytes", listOfFiles[0].Length) + "\"}", "application/json");
            else
                return Content("{\"name\":\"" + "Nothing" + "\"");
        }

        private bool MergeFile(string fileName, int length, int incidentId)
        {
            bool rslt = false;
            // parse out the different tokens from the filename according to the convention
            string partToken = ".part_";
            if (fileName.IndexOf(partToken) > 0)
            {
                string baseFileName = fileName.Substring(0, fileName.IndexOf(partToken));
                string trailingTokens = fileName.Substring(fileName.IndexOf(partToken) + partToken.Length);
                int FileIndex = 0;
                int FileCount = 0;
                int.TryParse(trailingTokens.Substring(0, trailingTokens.IndexOf(".")), out FileIndex);
                int.TryParse(trailingTokens.Substring(trailingTokens.IndexOf(".") + 1), out FileCount);
                // get a list of all file parts in the temp folder
                string Searchpattern = Path.GetFileName(baseFileName) + partToken + "*";

                string[] FilesList = Directory.GetFiles(Path.GetDirectoryName(fileName), Searchpattern);

                if (FilesList.Count() == FileCount)
                {
                    //  merge .. improvement would be to confirm individual parts are there / correctly in
                    // sequence, a security check would also be important
                    // only proceed if we have received all the file chunks
                    List<SortedFile> MergeList = new List<SortedFile>();
                    foreach (string File in FilesList)
                    {
                        SortedFile sFile = new SortedFile();
                        sFile.FileName = File;
                        trailingTokens = File.Substring(File.IndexOf(partToken) + partToken.Length);
                        int.TryParse(trailingTokens.
                           Substring(0, trailingTokens.IndexOf(".")), out FileIndex);
                        sFile.FileOrder = FileIndex;
                        MergeList.Add(sFile);
                    }
                    var MergeOrder = MergeList.OrderBy(s => s.FileOrder).ToList();
                    using (FileStream FS = new FileStream(baseFileName, FileMode.Create))
                    {
                        // merge each file chunk back into one contiguous file stream
                        foreach (var chunk in MergeOrder)
                        {
                            try
                            {
                                using (FileStream fileChunk =
                                   new FileStream(chunk.FileName, FileMode.Open))
                                {
                                    fileChunk.CopyTo(FS);
                                }
                            }
                            catch (IOException ex)
                            {
                                // handle
                            }
                        }
                        rslt = true;

                    }

                    foreach (string f in FilesList)
                    {
                        System.IO.File.Delete(f);
                    }

                    var fName = Path.GetFileName(baseFileName);
                    this.SaveArtifacts(fName, baseFileName, incidentId);
                }
            }
            else
            {
                var fName = Path.GetFileName(fileName);
                this.SaveArtifacts(fName, fileName, incidentId);
            }
            return true;
        }

        [HttpPost]
        public ContentResult DeleteFile(int artifactId, int incidentId, string fileName)
        {
            try
            {
                fileName = this.GetFilePath(incidentId, fileName, false);
                FileInfo filePath = new FileInfo(fileName);
                if (filePath.Exists)
                {
                    filePath.Delete();
                    BLArtifacts artifacts = new BLArtifacts();
                    artifacts.DeleteIncidentArtifacts(artifactId, incidentId);
                }
            }
            catch (Exception)
            {
                return Content("false");
            }

            return Content("true");
        }

        private void SaveArtifacts(string filename, string filepath, int incidentId)
        {
            try
            {
                BLArtifacts artifacts = new BLArtifacts();
                ArtifactEntity artEntity = new ArtifactEntity
                {
                    FileName = filename,
                    IncidentId = incidentId,
                    UploadedDate = DateTime.Now,
                };

                //artifacts.SaveIncidentArtifacts(artEntity);
                HttpClient httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Accept.Clear();
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                StringContent content = new StringContent(JsonConvert.SerializeObject(artEntity), System.Text.Encoding.UTF8, "application/json");
                var resp = httpClient.PostAsync(ConfigurationManager.AppSettings["UOF.API"] + "/api/Artifacts/SaveIncidentArtifacts", content).Result;
                resp.EnsureSuccessStatusCode();
               bool data = resp.Content.ReadAsAsync<bool>().Result;
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "SaveArtifacts", ex.Source.ToString(), ex.StackTrace.ToString());
            }
        }
    }
}