﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UOF.UI.Filters;
using UOF.UI.Helper;

namespace UOF.UI.Controllers
{
    public class UnitCommanderReviewController : BaseController
    {
        //
        // GET: /UnitCommanderReview/
        [FormBasedAuth(UnitCommanderPermission.UC_UofReview)]
        public ActionResult UWUoFReview(string FormId, string IncidentId, string SubmittedId)
        {
            ViewBag.FormId = FormId;
            ViewBag.IncidentId = IncidentId;
            ViewBag.SubmittedId = SubmittedId;
            return View();
        }

    }
}
