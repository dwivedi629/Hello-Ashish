﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace UOF.UI.Controllers
{
    public class CrimeAnalysisController : BaseController
    {
        //
        // GET: /CrimeAnalysis/

        public ActionResult CrimeAnalysis(string FormId, string IncidentId, string SubmittedId)
        {
            ViewBag.FormId = FormId;
            ViewBag.IncidentId = IncidentId;
            ViewBag.DeputyId = SubmittedId;
            return View("CrimeAnalysis");
        }

    }
}
