﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UOF.UI.Filters;
using UOF.UI.Helper;

namespace UOF.UI.Controllers
{
    public class UseofForceNarrativeController : BaseController
    {
        //
        // GET: /Narrative/
        [FormBasedAuth(SergeantPermission.Ser_ForceNarrativeReport)]
        public ActionResult Narrative(string FormId, string IncidentId, string SubmittedId)
        {
            ViewBag.FormId = FormId;
            ViewBag.IncidentId = IncidentId;
            ViewBag.DeputyId = SubmittedId;
            return View("Narrative");
        }

        [FormBasedAuth(SergeantPermission.Ser_CDFRchecklist)]
        public ActionResult COForceReviewCheckList(string FormId, string IncidentId, string SubmittedId)
        {
            ViewBag.FormId = FormId;
            ViewBag.IncidentId = IncidentId;
            ViewBag.DeputyId = SubmittedId;
            return View("_COForceReviewCheckList");
        }

        public ActionResult UoFMemo(string FormId, string IncidentId, string SubmittedId)
        {
            ViewBag.FormId = FormId;
            ViewBag.IncidentId = IncidentId;
            ViewBag.DeputyId = SubmittedId;
            return View("_UoFMemo");
        }
        public ActionResult SupplementalReport(string FormId, string IncidentId, string SubmittedId)
        {
            ViewBag.FormId = FormId;
            ViewBag.IncidentId = IncidentId;
            ViewBag.DeputyId = SubmittedId;
            return View("_SupplementalReport");
        }
        public ActionResult IAB(string FormId, string IncidentId, string SubmittedId)
        {
            ViewBag.FormId = FormId;
            ViewBag.IncidentId = IncidentId;
            ViewBag.DeputyId = SubmittedId;
            return View("_IAB");
        }
        
        public ActionResult UoFReviewNotice(string FormId, string IncidentId, string SubmittedId)
        {
            ViewBag.FormId = FormId;
            ViewBag.IncidentId = IncidentId;
            ViewBag.DeputyId = SubmittedId;
            return View("UoFReviewNotice");
        }
       
        
        

    }
}
