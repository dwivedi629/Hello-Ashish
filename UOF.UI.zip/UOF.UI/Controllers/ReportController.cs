﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Web;
using System.Web.Mvc;
using UOF.Business;
using UOF.Business.Factory;
using UOF.Common.EntityModel;
using UOF.UI.Models;

namespace UOF.UI.Controllers
{
    public class ReportController : BaseController
    {
        //
        // GET: /Report/
        //[FormBasedAuth(ReportPermission.Reports)]

        private IEntityBusinessModel _objModel = null;
        private string _repName = null;
        private List<string> _lstRepName = null;
        private bool isSupervisoryRpt = false;

        public ActionResult Index(string FormId, string reportName = "Default", string userID = "")
        {
            HttpClient httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Accept.Clear();
            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var data = (dynamic)null;
            int formId = Convert.ToInt32(FormId);
            int incidentId = Convert.ToInt32((string)UofSessionValue.Get("SelectedIncidentId"));
            ParameterCriteria cirteria = new ParameterCriteria { employeeId = userID, incidentId = incidentId, formId = formId, report = true };
            StringContent content = new StringContent(JsonConvert.SerializeObject(cirteria), Encoding.UTF8, "application/json");

            string viewName = getViewName(reportName);

            if (!string.IsNullOrEmpty(viewName))
            {
                BLSupervisorsReportforce blCatOne = new BLSupervisorsReportforce();
                BLUoFForm blforms = new BLUoFForm();
                BLReview blCmdrs = new BLReview();
                BLNarrative blNarr = new BLNarrative();
                string query = string.Empty;
                
                string customswitch = "--footer-center \"Name: " + reportName + "  DOS: " +
                                      DateTime.Now.Date.ToString("MM/dd/yyyy") + "  Page: [page]/[toPage]\"" +
                                      " --footer-line --footer-font-size \"10\" --footer-spacing 6 --footer-font-name \"MS Gothic\"";

                switch (reportName)
                {
                    case "UoF_CatOne":
                        // data = blCatOne.GetSupervisorsReportforceInfo(formId, incidentId, userID);
                        try
                        {
                            var resp = httpClient.PostAsync(ConfigurationManager.AppSettings["UOF.API"] + "/api/SupervisorsReportforce/GetSupervisorsReportforceInfo", content).Result;
                            resp.EnsureSuccessStatusCode();
                            data = resp.Content.ReadAsAsync<SupervisorsReportBusinessModel>().Result;
                        }
                        catch (Exception ex)
                        {
                            //LogService.CustomError(ex, "GetIncidentId", ex.Source.ToString(), ex.StackTrace.ToString());
                        }
                        break;

                    case "UoF_ReviewNotice":
                        data = blforms.GetReviewNotice(formId, incidentId, userID);
                        break;

                    case "UoF_Memo":
                        try
                        {
                            var resp = httpClient.PostAsync(ConfigurationManager.AppSettings["UOF.API"] + "/api/UOFForm/GetMemoDetails", content).Result;
                            resp.EnsureSuccessStatusCode();
                            data = resp.Content.ReadAsAsync<UOFMemo>().Result;
                        }
                        catch (Exception ex)
                        {
                            //LogService.CustomError(ex, "GetIncidentId", ex.Source.ToString(), ex.StackTrace.ToString());
                        }
                        //data = blforms.GetMemoDetails(formId, incidentId, userID);
                        break;

                    case "UoF_Custody_Division":
                        try
                        {
                            var resp = httpClient.PostAsync(ConfigurationManager.AppSettings["UOF.API"] + "/api/UOFForm/GetForceReview", content).Result;
                            resp.EnsureSuccessStatusCode();
                            data = resp.Content.ReadAsAsync<OperationsForceReview>().Result;
                        }
                        catch (Exception ex)
                        {
                            //LogService.CustomError(ex, "GetIncidentId", ex.Source.ToString(), ex.StackTrace.ToString());
                        }
                        //data = blforms.GetForceReview(formId, incidentId, userID);
                        break;

                    case "UoF_SuppReport":
                        try
                        {
                            var resp = httpClient.PostAsync(ConfigurationManager.AppSettings["UOF.API"] + "/api/UOFForm/GetSupplementalDetails", content).Result;
                            resp.EnsureSuccessStatusCode();
                            data = resp.Content.ReadAsAsync<SupplementalModel>().Result;
                        }
                        catch (Exception ex)
                        {
                            //LogService.CustomError(ex, "GetIncidentId", ex.Source.ToString(), ex.StackTrace.ToString());
                        }
                        //data = blforms.GetSupplementalDetails(formId, incidentId, userID);
                        break;

                    case "UoF_WCReview":
                        try
                        {
                            var resp = httpClient.PostAsync(ConfigurationManager.AppSettings["UOF.API"] + "/api/Review/GetWCReviewData", content).Result;
                            resp.EnsureSuccessStatusCode();
                            data = resp.Content.ReadAsAsync<ReviewsResponse>().Result;
                        }
                        catch (Exception ex)
                        {
                            //LogService.CustomError(ex, "GetIncidentId", ex.Source.ToString(), ex.StackTrace.ToString());
                        }
                        //data = blCmdrs.GetWCReviewData(formId, incidentId, userID);
                        break;

                    case "UoF_UCReview":
                        try
                        {
                            var resp = httpClient.PostAsync(ConfigurationManager.AppSettings["UOF.API"] + "/api/Review/GetUCReviewData", content).Result;
                            resp.EnsureSuccessStatusCode();
                            data = resp.Content.ReadAsAsync<ReviewsResponse>().Result;
                        }
                        catch (Exception ex)
                        {
                            //LogService.CustomError(ex, "GetIncidentId", ex.Source.ToString(), ex.StackTrace.ToString());
                        }
                        //data = blCmdrs.GetUCReviewData(formId, incidentId, userID);
                        break;

                    case "UoF_CMReview":
                        try
                        {
                            var resp = httpClient.PostAsync(ConfigurationManager.AppSettings["UOF.API"] + "/api/Review/GetCommanderReviewData", content).Result;
                            resp.EnsureSuccessStatusCode();
                            data = resp.Content.ReadAsAsync<ReviewsResponse>().Result;
                        }
                        catch (Exception ex)
                        {
                            //LogService.CustomError(ex, "GetIncidentId", ex.Source.ToString(), ex.StackTrace.ToString());
                        }
                        // data = blCmdrs.GetCommanderReviewData(formId, incidentId, userID);
                        break;

                    case "UoF_Tracking":
                        string query1 = string.Format(ConfigurationManager.AppSettings["UOF.API"] + "/api/UOFForm/GetTrackingDetails?incidentId={0}&formId={1}", incidentId, formId);
                        try
                        {
                            var resp = httpClient.GetAsync(query1).Result;
                            resp.EnsureSuccessStatusCode();
                            data = resp.Content.ReadAsAsync<TrackingModel>().Result;
                        }
                        catch (Exception ex)
                        {
                            //LogService.CustomError(ex, "GetIncidentId", ex.Source.ToString(), ex.StackTrace.ToString());
                        }
                        //data = blforms.GetTrackingDetails(formId, incidentId);
                        break;

                    case "UoF_Narrative":
                        try
                        {
                            var resp = httpClient.PostAsync(ConfigurationManager.AppSettings["UOF.API"] + "/api/UOFForm/GetUoFNarrativeInfo", content).Result;
                            resp.EnsureSuccessStatusCode();
                            data = resp.Content.ReadAsAsync<UoFNarrativeEntityModel>().Result;
                        }
                        catch (Exception ex)
                        {
                            //LogService.CustomError(ex, "GetIncidentId", ex.Source.ToString(), ex.StackTrace.ToString());
                        }
                        //data = blNarr.GetNarrative(formId, incidentId, userID);
                        break;

                    case "UoF_MedicalReport":
                        try
                        {
                            var resp = httpClient.PostAsync(ConfigurationManager.AppSettings["UOF.API"] + "/api/UOFForm/GetMedicalReport", content).Result;
                            resp.EnsureSuccessStatusCode();
                            data = resp.Content.ReadAsAsync<MedicalEntity>().Result;
                        }
                        catch (Exception ex)
                        {
                            //LogService.CustomError(ex, "GetIncidentId", ex.Source.ToString(), ex.StackTrace.ToString());
                        }
                        break;

                    case "UoF_InmateInjury":
                        try
                        {
                            var resp = httpClient.PostAsync(ConfigurationManager.AppSettings["UOF.API"] + "/api/InmateInjury/GetInmateInjuryInfo", content).Result;
                            resp.EnsureSuccessStatusCode();
                            data = resp.Content.ReadAsAsync<InmateInjuryBusinessModel>().Result;
                        }
                        catch (Exception ex)
                        {
                            //LogService.CustomError(ex, "GetIncidentId", ex.Source.ToString(), ex.StackTrace.ToString());
                        }
                        break;

                    case "UoF_IAB":
                        string IABquery = string.Format(ConfigurationManager.AppSettings["UOF.API"] + "/api/UOFForm/GetIABDetails?FormId={0}&IncidentId={1}&DeputyId={2}", formId, incidentId, userID);
                        try
                        {
                            var resp = httpClient.GetAsync(IABquery).Result;
                            resp.EnsureSuccessStatusCode();
                            data = resp.Content.ReadAsAsync<IABModel>().Result;
                        }
                        catch (Exception ex)
                        {
                            //LogService.CustomError(ex, "GetIncidentId", ex.Source.ToString(), ex.StackTrace.ToString());
                        }
                        break;

                    default:
                        break;
                }
                if (data != null)
                {
                    GeneratePDF(viewName, customswitch, reportName, data);
                    return View(viewName, data);
                }
                return View(viewName, data);
            }
            else
            {
                if (reportName == "UoF_SupervisorsReport")
                {
                    Generate438(reportName, Convert.ToInt32(FormId), userID);
                }
                else if (reportName == "UoF_SuppReport")
                {
                    GenerateUOFSuppReport(reportName, Convert.ToInt32(FormId), userID);
                }
                else if (reportName == "UoF_Memo")
                {
                    GenerateUOFMemoReport(reportName, Convert.ToInt32(FormId), userID);
                }
                else
                {
                    _repName = reportName;
                    string TempFile = _repName + ".pdf";

                    string tempFolderName = Server.MapPath(ConfigurationManager.AppSettings["ReportTempPath"]);
                    if (!Directory.Exists(tempFolderName))
                        Directory.CreateDirectory(tempFolderName);

                    string path = System.IO.Path.Combine(tempFolderName, TempFile);
                    if (System.IO.File.Exists(path))
                        System.IO.File.Delete(path);
                    string templateFolderName = Server.MapPath(ConfigurationManager.AppSettings["ReportTemplatesPath"]);
                    string TemplateFile = System.IO.Path.Combine(templateFolderName, _repName + ".pdf");
                    if (System.IO.File.Exists(TemplateFile))
                    {
                        PdfReader pdfReader = new PdfReader(TemplateFile);
                        using (FileStream objStream = new FileStream(path, FileMode.Create))
                        {
                            PdfStamper pdfStamper = new PdfStamper(pdfReader, objStream);

                            AcroFields pdfFormFields = pdfStamper.AcroFields;
                            string SelectedIncidentId = (string)UofSessionValue.Get("SelectedIncidentId");
                            int formid = Convert.ToInt32(FormId);
                            this.GetReport(formid, Convert.ToInt32(SelectedIncidentId), userID);
                            SetReportDataItems(pdfFormFields);

                            pdfStamper.FormFlattening = true;
                            // close the pdf
                            pdfStamper.Close();
                            //Response.Redirect("temp/" + TempFile, false);
                        }

                        Response.ContentType = "Application/pdf";
                        Response.AppendHeader("Content-Disposition", "attachment; filename=" + _repName + ".pdf");
                        Response.TransmitFile(path);
                        Response.End();
                    }
                }
            }

            return Content("");
        }

        private int CalculatePages(SupervisoryModel objForce)
        {
            // Page 1 contains basic information plus up to 3 involved staff
            int pageCount = 1;
            int tPage = 0;

            int involvedStaff = 0;
            int suspects = 0;
            int empWitnesses = 0;
            int witnesses = 0;
            int steps = 0;

            if (objForce.Involved != null)
            {
                involvedStaff = objForce.Involved.Count;
            }
            // add Involved Staff pages,
            int tCount = 0;
            tCount = involvedStaff - 3; // first page holds up to 3 staff
            if (tCount > 0)
            {
                tPage = tCount / 5; // additional Involved Staff pages hold 5 staff
                tPage += (tCount - (tCount / 5)) > 0 ? 1 : 0; // Add a page if there is a remainder
            }
            pageCount += tPage;
            if (objForce.Suspects != null)
            {
                suspects = objForce.Suspects.Count;
            }
            // Add Suspect pages
            tPage = 0;
            tCount = suspects;
            if (tCount > 0)
            {
                tPage = tCount / 3; // additional Suspect pages hold 3 suspects
                tPage += (tCount - (tCount / 3)) > 0 ? 1 : 0; // Add a page if there is a remainder
            }
            pageCount += tPage;
            if (objForce.EmpWitness != null)
            {
                empWitnesses = objForce.EmpWitness.Count;
            }
            if (objForce.NonEmpWitness != null)
            {
                witnesses = objForce.NonEmpWitness.Count;
            }
            // Add Witness Pages (much more complicated 3 Emp Witnesses and 9 other witnesses per page)
            tPage = 0;
            tCount = 0;
            if (empWitnesses > 0 || witnesses > 0)
            {
                int witnessPages = 0;
                witnessPages = empWitnesses / 3; // additional Witness pages hold 3 Employee Witnesses
                witnessPages += (empWitnesses - (empWitnesses / 3)) > 0 ? 1 : 0; // Add a page if there is a remainder
                int otherWitnesses = 0;
                otherWitnesses = witnesses / 9; // additional witness pages hold 9 other witnesses
                otherWitnesses += (witnesses - (witnesses / 9)) > 0 ? 1 : 0; // add a page if there is a remainder
                tPage = (witnessPages > otherWitnesses) ? witnessPages : otherWitnesses;  // Determine the max pages needed for witnesses
            }
            pageCount += tPage;
            if (objForce.Statisticals != null)
            {
                steps = objForce.Statisticals.Count;
            }
            tCount = steps;
            tPage = 1;
            if (tCount > 0)
            {
                tPage = tCount / 25; // additional Step By Step pages hold 25 Steps
                tPage += (tCount - (tCount / 25)) > 0 ? 1 : 0; // Add a page if there is a remainder
            }
            pageCount += tPage;
            return pageCount;
        }

        private void GenerateIAB(string _repName, int _formId)
        {
        }

        private void GenerateUOFMemoReport(string _repName, int _formId, string _empId)
        {
            String urn1 = (string)UofSessionValue.Get("SelectedIncidentURN");
            string templatFName = "UoF_Memo";
            string TempFile = templatFName + ".pdf";
            string tempFolderName = Server.MapPath(ConfigurationManager.AppSettings["ReportTempPath"]);
            if (!Directory.Exists(tempFolderName))
                Directory.CreateDirectory(tempFolderName);

            string path = System.IO.Path.Combine(tempFolderName, TempFile);
            if (System.IO.File.Exists(path))
                System.IO.File.Delete(path);
            string templateFolderName = Server.MapPath(ConfigurationManager.AppSettings["ReportTemplatesPath"]);
            string TemplateFile = System.IO.Path.Combine(templateFolderName, templatFName + ".pdf");

            if (System.IO.File.Exists(TemplateFile))
            {
                string SelectedIncidentId = (string)UofSessionValue.Get("SelectedIncidentId");
                this.GetReport(_formId, Convert.ToInt32(SelectedIncidentId), _empId);
                UOFMemo model = (UOFMemo)_objModel;

                int pageCount = 1;

                PdfReader tempRpt = new PdfReader(TemplateFile);
                path = tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + ".pdf";
                PdfStamper stamper = new PdfStamper(tempRpt, new FileStream(path, FileMode.Create));
                stamper.AcroFields.GenerateAppearances = true;
                stamper.AnnotationFlattening = true;
                stamper.FormFlattening = true;
                AcroFields form = stamper.AcroFields;

                //First Page

                form.SetField("File", model.File);
                form.SetField("ReferenceFile", model.ReferenceFile);
                if (model.DeputyPW == "PD")
                {
                    form.SetField("PrimaryDeputy", "Yes");
                }

                if (model.DeputyPW == "WD")
                {
                    form.SetField("WitnessDeputy", "Yes");
                }
                
                form.SetField("DeputyLastName", model.DeputyLastName);
                form.SetField("EmployeeID", model.EmployeeID);

                if (model.MemoItems.Count > 0)
                {
                    for (int i = 0; i < model.MemoItems.Count; i++)
                    {
                        form.SetField("InvolvedInmates_" + Convert.ToString(i + 1), model.MemoItems[i].InvolvedInmates);
                        form.SetField("BookingNumber_" + Convert.ToString(i + 1), model.MemoItems[i].BookingNumber);
                    }
                }

                form.SetField("Narrative", model.Narrative);
                form.SetField("Date", model.Date);
                form.SetField("Time", model.Time);
                form.SetField("LocationOfOccurrence", model.LocationOfOccurrence);

                stamper.FormFlattening = true;
                stamper.Close();
                // Clean up memory
                tempRpt.Close();
                tempRpt.Dispose();
                tempRpt = null;
                stamper.Dispose();
                stamper = null;
                form = null;

                if (model.Narrative.Length <= 3232)
                {
                    //Write the file
                    string outputfile = tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + ".pdf";
                    Response.ContentType = "Application/pdf";
                    Response.AppendHeader("Content-Disposition", "attachment; filename=" + outputfile);
                    Response.TransmitFile(outputfile);
                    Response.End();
                    //Delete the file from temp directory
                    System.IO.File.Delete(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + ".pdf");
                }
                else
                {
                    int additionalPages = (model.Narrative.Length / 3232) - 1;
                    int reminder = model.Narrative.Length % 3232;
                    if (reminder > 0)
                    {
                        additionalPages = additionalPages + 1;
                    }

                    pageCount = 1;

                    for (int i = 0; i < additionalPages; i++)
                    {
                        TemplateFile = System.IO.Path.Combine(templateFolderName, "UoF_MemoCont.pdf");
                        PdfReader temoRptCont = new PdfReader(TemplateFile);
                        path = tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + pageCount.ToString() + ".pdf";
                        PdfStamper stamperCont = new PdfStamper(temoRptCont, new FileStream(path, FileMode.Create));
                        stamperCont.AcroFields.GenerateAppearances = true;
                        stamperCont.AnnotationFlattening = true;
                        stamperCont.FormFlattening = true;
                        AcroFields formCont = stamperCont.AcroFields;



                        formCont.SetField("DeputyLastName_Cont", model.DeputyLastName);
                        formCont.SetField("File_Cont", model.File);
                        formCont.SetField("ReferenceFile_Cont", model.ReferenceFile);

                        if (i != additionalPages - 1)
                        {
                            formCont.SetField("NarrativeCont", model.Narrative.Substring((3232) * pageCount, 3232));
                        }
                        else
                        {
                            formCont.SetField("NarrativeCont", model.Narrative.Substring((3232) * pageCount, (model.Narrative.Length - (3232) * pageCount)));
                        }

                        //formCont.SetField("PageNumber", (pageCount + 1).ToString());

                        stamperCont.FormFlattening = true;
                        stamperCont.Close();

                        // Clean up memory

                        temoRptCont.Close();
                        temoRptCont.Dispose();
                        temoRptCont = null;
                        stamperCont.Dispose();
                        stamperCont = null;
                        formCont = null;
                        pageCount++;
                    }

                    int counter = 0;

                    Document document = new Document();
                    string cpath = tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + "Final.pdf";
                    PdfSmartCopy copy = new PdfSmartCopy(document, new FileStream(cpath, FileMode.Create));
                    document.Open();

                    PdfReader tempReport = new PdfReader(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + ".pdf");
                    copy.AddDocument(tempReport);
                    tempReport.Close();
                    tempReport.Dispose();
                    tempReport = null;

                    System.IO.File.Delete(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + ".pdf");

                    document.AddTitle("Deputy Memorandam report");
                    document.AddSubject("Deputy Memorandam report");
                    document.AddCreator("Custody Force");
                    document.AddAuthor("Uday"); //TODO
                    pageCount--;

                    //flatten files
                    while (counter < pageCount)
                    {
                        counter++;
                        PdfReader tRpt = new PdfReader(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + counter.ToString() + ".pdf");
                        stamper = new PdfStamper(tRpt, new FileStream(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + counter.ToString() + "f.pdf", FileMode.Create), PdfWriter.VERSION_1_7);
                        tRpt.SetPageContent(1, tRpt.GetPageContent(1), PdfStream.BEST_COMPRESSION, true);
                        stamper.Writer.CompressionLevel = 9;
                        stamper.SetFullCompression();
                        stamper.FormFlattening = true;
                        stamper.Reader.RemoveUnusedObjects();
                        stamper.SetFullCompression();
                        stamper.Close();
                        tRpt.Close();
                        tRpt.Dispose();
                        tRpt = null;
                        System.IO.File.Delete(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + counter.ToString() + ".pdf");
                    }

                    counter = 0;

                    while (counter < pageCount)
                    {
                        counter++;
                        PdfReader tRpt = new PdfReader(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + counter.ToString() + "f.pdf");
                        copy.AddDocument(tRpt);
                        tRpt.Close();
                        tRpt.Dispose();
                        tRpt = null;
                        System.IO.File.Delete(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + counter.ToString() + "f.pdf");
                    }
                    document.Close();

                    // Compress document
                    PdfReader tRptc = new PdfReader(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + "Final.pdf");

                    stamper = new PdfStamper(tRptc, new FileStream(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + "-C.pdf", FileMode.Create), PdfWriter.VERSION_1_7);
                    stamper.SetFullCompression();
                    stamper.Reader.RemoveUnusedObjects();
                    PdfWriter writer = stamper.Writer;
                    writer.CompressionLevel = PdfStream.BEST_COMPRESSION;
                    tRptc.RemoveFields();
                    tRptc.RemoveUnusedObjects();
                    stamper.Close();
                    tRptc.Close();
                    tRptc.Dispose();
                    tRptc = null;

                    System.IO.File.Delete(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + "Final.pdf");

                    string outputfile = tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + "-C.pdf";
                    Response.ContentType = "Application/pdf";
                    Response.AppendHeader("Content-Disposition", "attachment; filename=" + outputfile);
                    Response.TransmitFile(outputfile);
                    Response.End();

                    System.IO.File.Delete(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + "-C.pdf");
                }
            }
        }

        private void GenerateUOFSuppReport(string _repName, int _formId, string _empId)
        {
            String urn1 = (string)UofSessionValue.Get("SelectedIncidentURN");
            string templatFName = "UoF_SuppReport";
            string TempFile = templatFName + ".pdf";
            string tempFolderName = Server.MapPath(ConfigurationManager.AppSettings["ReportTempPath"]);
            if (!Directory.Exists(tempFolderName))
                Directory.CreateDirectory(tempFolderName);

            string path = System.IO.Path.Combine(tempFolderName, TempFile);
            if (System.IO.File.Exists(path))
                System.IO.File.Delete(path);
            string templateFolderName = Server.MapPath(ConfigurationManager.AppSettings["ReportTemplatesPath"]);
            string TemplateFile = System.IO.Path.Combine(templateFolderName, templatFName + ".pdf");

            if (System.IO.File.Exists(TemplateFile))
            {
                string SelectedIncidentId = (string)UofSessionValue.Get("SelectedIncidentId");
                this.GetReport(_formId, Convert.ToInt32(SelectedIncidentId), _empId);
                SupplementalModel model = (SupplementalModel)_objModel;

                int pageCount = 1;

                PdfReader tempRpt = new PdfReader(TemplateFile);
                path = tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + ".pdf";
                PdfStamper stamper = new PdfStamper(tempRpt, new FileStream(path, FileMode.Create));
                stamper.AcroFields.GenerateAppearances = true;
                stamper.AnnotationFlattening = true;
                stamper.FormFlattening = true;
                AcroFields form = stamper.AcroFields;

                //First Page

                form.SetField("Date", model.Date);
                form.SetField("File", model.File);
                form.SetField("Action", model.Action);
                form.SetField("Code", model.Code);

                if (model.SupNarratives.Count > 0)
                {
                    for (int i = 0; i < model.SupNarratives.Count; i++)
                    {
                        form.SetField("CodeId_" + Convert.ToString(i + 1), model.SupNarratives[i].CodeId);
                        form.SetField("CodeNarrative_" + Convert.ToString(i + 1), model.SupNarratives[i].CodeNarrative);
                    }
                }

                form.SetField("Narrative", model.Narrative);
                form.SetField("By", model.By);
                form.SetField("Approved", model.Approved);
                form.SetField("Assigned", model.Assigned);
                form.SetField("Secretary", model.Secretary);

                stamper.FormFlattening = true;
                stamper.Close();
                // Clean up memory
                tempRpt.Close();
                tempRpt.Dispose();
                tempRpt = null;
                stamper.Dispose();
                stamper = null;
                form = null;

                //Only one page

                if (model.Narrative.Length <= 2970)
                {
                    //Write the file
                    string outputfile = tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + ".pdf";
                    Response.ContentType = "Application/pdf";
                    Response.AppendHeader("Content-Disposition", "attachment; filename=" + outputfile);
                    Response.TransmitFile(outputfile);
                    Response.End();
                    //Delete the file from temp directory
                    System.IO.File.Delete(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + ".pdf");
                }
                else
                {
                    int additionalPages = (model.Narrative.Length / 2970) - 1;
                    int reminder = model.Narrative.Length % 2970;
                    if (reminder > 0)
                    {
                        additionalPages = additionalPages + 1;
                    }

                    pageCount = 1;

                    for (int i = 0; i < additionalPages; i++)
                    {
                        TemplateFile = System.IO.Path.Combine(templateFolderName, "UoF_SuppReportCont.pdf");
                        PdfReader tempRptCont = new PdfReader(TemplateFile);
                        path = tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + pageCount.ToString() + ".pdf";
                        PdfStamper stamperCont = new PdfStamper(tempRptCont, new FileStream(path, FileMode.Create));
                        stamperCont.AcroFields.GenerateAppearances = true;
                        stamperCont.AnnotationFlattening = true;
                        stamperCont.FormFlattening = true;
                        AcroFields formCont = stamperCont.AcroFields;

                        formCont.SetField("NarrativeDate", model.Date);
                        formCont.SetField("NarrativeFile", model.File);
                        formCont.SetField("NarrativeAction", model.Action);
                        if (i != additionalPages - 1)
                        {
                            formCont.SetField("Reason", model.Narrative.Substring((2970) * pageCount, 2970));
                        }
                        else
                        {
                            formCont.SetField("Reason", model.Narrative.Substring((2970) * pageCount, (model.Narrative.Length - (2970) * pageCount)));
                        }
                        formCont.SetField("PageNumber", (pageCount + 1).ToString());

                        stamperCont.FormFlattening = true;
                        stamperCont.Close();

                        // Clean up memory

                        tempRptCont.Close();
                        tempRptCont.Dispose();
                        tempRptCont = null;
                        stamperCont.Dispose();
                        stamperCont = null;
                        formCont = null;
                        pageCount++;
                    }

                    int counter = 0;
                    Document document = new Document();
                    string cpath = tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + "Final.pdf";
                    PdfSmartCopy copy = new PdfSmartCopy(document, new FileStream(cpath, FileMode.Create));
                    document.Open();

                    PdfReader tempReport = new PdfReader(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + ".pdf");
                    copy.AddDocument(tempReport);
                    tempReport.Close();
                    tempReport.Dispose();
                    tempReport = null;

                    System.IO.File.Delete(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + ".pdf");

                    document.AddTitle("Deputy Supplemental report");
                    document.AddSubject("Deputy Supplemental report");
                    document.AddCreator("Custody Force");
                    document.AddAuthor("Uday"); //TODO
                    pageCount--;

                    //flatten files
                    while (counter < pageCount)
                    {
                        counter++;
                        PdfReader tRpt = new PdfReader(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + counter.ToString() + ".pdf");
                        stamper = new PdfStamper(tRpt, new FileStream(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + counter.ToString() + "f.pdf", FileMode.Create), PdfWriter.VERSION_1_7);
                        tRpt.SetPageContent(1, tRpt.GetPageContent(1), PdfStream.BEST_COMPRESSION, true);
                        stamper.Writer.CompressionLevel = 9;
                        stamper.SetFullCompression();
                        stamper.FormFlattening = true;
                        stamper.Reader.RemoveUnusedObjects();
                        stamper.SetFullCompression();
                        stamper.Close();
                        tRpt.Close();
                        tRpt.Dispose();
                        tRpt = null;
                        System.IO.File.Delete(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + counter.ToString() + ".pdf");
                    }

                    counter = 0;
                    while (counter < pageCount)
                    {
                        counter++;
                        PdfReader tRpt = new PdfReader(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + counter.ToString() + "f.pdf");
                        copy.AddDocument(tRpt);
                        tRpt.Close();
                        tRpt.Dispose();
                        tRpt = null;
                        System.IO.File.Delete(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + counter.ToString() + "f.pdf");
                    }
                    document.Close();

                    // Compress document
                    PdfReader tempRptC = new PdfReader(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + "Final.pdf");

                    stamper = new PdfStamper(tempRptC, new FileStream(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + "-C.pdf", FileMode.Create), PdfWriter.VERSION_1_7);
                    stamper.SetFullCompression();
                    stamper.Reader.RemoveUnusedObjects();
                    PdfWriter writer = stamper.Writer;
                    writer.CompressionLevel = PdfStream.BEST_COMPRESSION;
                    tempRptC.RemoveFields();
                    tempRptC.RemoveUnusedObjects();
                    stamper.Close();
                    tempRptC.Close();
                    tempRptC.Dispose();
                    tempRptC = null;

                    System.IO.File.Delete(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + "Final.pdf");

                    string outputfile = tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + "-C.pdf";
                    Response.ContentType = "Application/pdf";
                    Response.AppendHeader("Content-Disposition", "attachment; filename=" + outputfile);
                    Response.TransmitFile(outputfile);
                    Response.End();

                    System.IO.File.Delete(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + "-C.pdf");
                }
            }
        }

        private void Generate438(string _repName, int _formId, string _empId)
        {
            String urn1 = (string)UofSessionValue.Get("SelectedIncidentURN");
            string templatFName = "F438P1-Patrol";
            string TempFile = templatFName + ".pdf";
            string tempFolderName = Server.MapPath(ConfigurationManager.AppSettings["ReportTempPath"]);
            if (!Directory.Exists(tempFolderName))
                Directory.CreateDirectory(tempFolderName);

            string path = System.IO.Path.Combine(tempFolderName, TempFile);
            if (System.IO.File.Exists(path))
                System.IO.File.Delete(path);
            string templateFolderName = Server.MapPath(ConfigurationManager.AppSettings["ReportTemplatesPath"]);
            string TemplateFile = System.IO.Path.Combine(templateFolderName, templatFName + ".pdf");
            if (System.IO.File.Exists(TemplateFile))
            {
                string SelectedIncidentId = (string)UofSessionValue.Get("SelectedIncidentId");
                this.GetReport(_formId, Convert.ToInt32(SelectedIncidentId), _empId);
                SupervisoryModel model = (SupervisoryModel)_objModel;
                int tbTotalPages = CalculatePages(model);
                int pageCount = 1;
                IncidentEntity IncidentModel = model.Incident;
                String[] urn = IncidentModel.URN.Trim().Split('-');

                #region Page1 of 438

                PdfReader t438P1 = new PdfReader(TemplateFile);
                //HttpContext.Current.Server.MapPath("~/Temp/" + sysUser.sAMAccountName.Trim() + urn1.Trim() + "P" + PageCount.ToString() + ".pdf")
                path = tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + "P" + pageCount.ToString() + ".pdf";
                PdfStamper stamper = new PdfStamper(t438P1, new FileStream(path, FileMode.Create));
                stamper.AcroFields.GenerateAppearances = true;
                stamper.AnnotationFlattening = true;
                stamper.FormFlattening = true;
                AcroFields form = stamper.AcroFields;
                form.SetField("URN1", urn[0]);
                form.SetField("URN2", urn[1]);
                form.SetField("URN3", urn[2]);
                form.SetField("URN4", urn[3]);
                form.SetField("TotalPages", tbTotalPages.ToString());
                if (IncidentModel.IncidentDate != null)
                {
                    form.SetField("IncidentDate", ((DateTimeOffset)IncidentModel.IncidentDate).Date.ToString("MM/dd/yyyy"));
                    form.SetField("IncidentTime", ((DateTimeOffset)IncidentModel.IncidentDate).ToLocalTime().ToString("HH:MM"));
                }
                if (IncidentModel.Location != null)
                {
                    form.SetField("IncidentLocation", NameCase(IncidentModel.Location.Trim()));
                }
                if (IncidentModel.City != null)
                {
                    form.SetField("IncidentCity", NameCase(IncidentModel.City.Trim()));
                }
                if (IncidentModel.StationFacility != null)
                {
                    form.SetField("IncidentBureau", NameCase(IncidentModel.StationFacility.Trim()));
                }
                String fieldName = String.Empty;
                if (IncidentModel.IsAdminInvestigation != null)
                {
                    if (IncidentModel.IsAdminInvestigation == "Y")
                    {
                        fieldName = "AdminInvestYes";
                        form.SetField(fieldName, form.GetFieldItem(fieldName).GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                    }
                    else
                    {
                        fieldName = "AdminInvestNo";
                        form.SetField(fieldName, form.GetFieldItem(fieldName).GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                    }
                }
                String forceList = String.Empty;
                int counter = 0;
                if (IncidentModel.ForceTypeId != null)
                {
                    string[] fId = IncidentModel.ForceTypeId.Split(',');
                    if (fId.Length > 0)
                    {
                        foreach (string ft in fId)
                        {
                            counter++;
                            if (counter != fId.Length)
                            {
                                forceList += ft.Trim() + " / ";
                            }
                            else
                            {
                                forceList += ft.Trim();
                            }
                        }
                    }
                }
                form.SetField("IncidentTypeOfForce", forceList.Trim());
                if (IncidentModel.IncidentCategoryId != null)
                {
                    switch (IncidentModel.IncidentCategoryId)
                    {
                        case 1:
                            fieldName = "IncidentForceCategory1";
                            form.SetField(fieldName, form.GetFieldItem(fieldName).GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                            break;

                        case 2:
                            fieldName = "IncidentForceCategory2";
                            form.SetField(fieldName, form.GetFieldItem(fieldName).GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                            break;

                        case 3:
                            fieldName = "IncidentForceCategory3";
                            form.SetField(fieldName, form.GetFieldItem(fieldName).GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                            break;
                    }
                }
                if (IncidentModel.IsDeptyInjury != null)
                {
                    if (IncidentModel.IsDeptyInjury == "Y")
                    {
                        fieldName = "StaffInjuredYes";
                        form.SetField(fieldName, form.GetFieldItem(fieldName).GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                    }
                    else
                    {
                        fieldName = "StaffInjuredNo";
                        form.SetField(fieldName, form.GetFieldItem(fieldName).GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                    }
                }
                if (IncidentModel.IsSuspectInjury != null)
                {
                    if (IncidentModel.IsSuspectInjury == "Y")
                    {
                        fieldName = "SuspectInjuredYes";
                        form.SetField(fieldName, form.GetFieldItem(fieldName).GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                    }
                    else
                    {
                        fieldName = "SuspectInjuredNo";
                        form.SetField(fieldName, form.GetFieldItem(fieldName).GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                    }
                }
                if (IncidentModel.ContactTypeId != null)
                {
                    String contact = IncidentModel.ContactTypeId.Trim();
                    if (IncidentModel.ContactTypeId != null && contact.Contains("Custody"))
                    {
                        contact += " - " + IncidentModel.CustodyEventId.Trim();
                    }
                    form.SetField("ContactType", NameCase(contact.Trim()));
                }
                if (IncidentModel.IsByFootPursuit != null)
                {
                    if (IncidentModel.IsByFootPursuit == "Y")
                    {
                        fieldName = "FootPursuit";
                        form.SetField(fieldName, form.GetFieldItem(fieldName).GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                    }
                }
                if (IncidentModel.IsByVehiclePursuit != null)
                {
                    if (IncidentModel.IsByVehiclePursuit == "Y")
                    {
                        fieldName = "VehiclePursuit";
                        form.SetField(fieldName, form.GetFieldItem(fieldName).GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                    }
                }
                if (IncidentModel.IsIABNotified != null)
                {
                    if (IncidentModel.IsIABNotified == "Y")
                    {
                        fieldName = "IabNotifiedYes";
                        form.SetField(fieldName, form.GetFieldItem(fieldName).GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                        if (IncidentModel.PersonNotified != null)
                        {
                            form.SetField("IabPersonNotified", NameCase(IncidentModel.PersonNotified.Trim()));
                        }
                        if (IncidentModel.IABNotifiedUserId != null)
                        {
                            form.SetField("IabPersonNotifiedEmp", IncidentModel.IABNotifiedUserId.Trim());
                        }
                        if (IncidentModel.IsIABRollOut != null)
                        {
                            if (IncidentModel.IsIABRollOut == "Y")
                            {
                                fieldName = "IabRolloutYes";
                                form.SetField(fieldName, form.GetFieldItem(fieldName).GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                            }
                            else
                            {
                                fieldName = "IabRolloutNo";
                                form.SetField(fieldName, form.GetFieldItem(fieldName).GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                            }
                        }
                    }
                    else
                    {
                        fieldName = "IabNotifiedNo";
                        form.SetField(fieldName, form.GetFieldItem(fieldName).GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                        fieldName = "IabRolloutNo";
                        form.SetField(fieldName, form.GetFieldItem(fieldName).GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                    }
                }

                #region involvedEmployeesMainPage

                List<InvolvedUserEntity> involvedEmployees = model.Involved;
                List<InvolvedUserEntity> involvedEmployees1 = (from f in model.Involved select f).ToList();
                //List<InvolvedUserEntity> involvedEmployees1 = model.Involved;
                InvolvedEmployee objEmp = null;
                counter = 0;
                if (involvedEmployees.Count > 0)
                {
                    fieldName = "InvolvedEmployee";
                    foreach (InvolvedUserEntity ie in involvedEmployees)
                    {
                        counter++;
                        if (counter <= 3)
                        {
                            if (ie.IncidentUserInvolvedId != null)
                            {
                                form.SetField(fieldName + counter.ToString() + "Index", ie.IncidentUserInvolvedId.ToString());
                            }
                            if (ie.EmployeeId != null)
                            {
                                form.SetField(fieldName + counter.ToString() + "Emp", ie.EmployeeId.Trim());
                            }
                            if (ie.LastName != null)
                            {
                                form.SetField(fieldName + counter.ToString() + "LastName", NameCase(ie.LastName.Trim()));
                            }
                            if (ie.FirstName != null)
                            {
                                form.SetField(fieldName + counter.ToString() + "FirstName", NameCase(ie.FirstName.Trim()));
                            }
                            if (ie.MiddleName != null)
                            {
                                form.SetField(fieldName + counter.ToString() + "MiddleName", NameCase(ie.MiddleName.Trim()));
                            }
                            if (ie.Rank != null)
                            {
                                form.SetField(fieldName + counter.ToString() + "Rank", ie.Rank.Trim());
                            }
                            if (ie.Sex != null)
                            {
                                switch (ie.Sex)
                                {
                                    case "M":
                                        form.SetField(fieldName + counter.ToString() + "Gender", "Male");
                                        break;

                                    case "F":
                                        form.SetField(fieldName + counter.ToString() + "Gender", "Female");
                                        break;

                                    case "T":
                                        form.SetField(fieldName + counter.ToString() + "Gender", "Transgender");
                                        break;

                                    case "U":
                                        form.SetField(fieldName + counter.ToString() + "Gender", "Unknown");
                                        break;

                                    default:
                                        form.SetField(fieldName + counter.ToString() + "Gender", "Unknown");
                                        break;
                                }
                            }
                            if (ie.Race != null)
                            {
                                form.SetField(fieldName + counter.ToString() + "Race", ie.Race.Trim());
                            }
                            if (ie.Height != null)
                            {
                                form.SetField(fieldName + counter.ToString() + "Height", ie.Height.ToString());
                            }
                            if (ie.Weight != null)
                            {
                                form.SetField(fieldName + counter.ToString() + "Weight", ie.Weight.ToString());
                            }
                            if (ie.Age != null)
                            {
                                form.SetField(fieldName + counter.ToString() + "Age", ie.Age.ToString());
                            }
                            if (ie.Shift != null)
                            {
                                switch (ie.Shift.Trim().ToLower())
                                {
                                    case "em":
                                        form.SetField(fieldName + counter.ToString() + "ShiftEM", form.GetFieldItem(fieldName + counter.ToString() + "ShiftEM").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                        break;

                                    case "day":
                                        form.SetField(fieldName + counter.ToString() + "ShiftDay", form.GetFieldItem(fieldName + counter.ToString() + "ShiftDay").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                        break;

                                    case "pm":
                                        form.SetField(fieldName + counter.ToString() + "ShiftPM", form.GetFieldItem(fieldName + counter.ToString() + "ShiftPM").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                        break;
                                }
                            }
                            if (ie.ShiftType != null)
                            {
                                switch (ie.ShiftType.Trim().ToLower())
                                {
                                    case "regular":
                                        form.SetField(fieldName + counter.ToString() + "ShiftTypeRegularShift", form.GetFieldItem(fieldName + counter.ToString() + "ShiftTypeRegularShift").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                        break;

                                    case "overtime":
                                        form.SetField(fieldName + counter.ToString() + "ShiftTypeOTShift", form.GetFieldItem(fieldName + counter.ToString() + "ShiftTypeOTShift").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                        break;

                                    case "offduty":
                                        form.SetField(fieldName + counter.ToString() + "ShiftTypeOffDuty", form.GetFieldItem(fieldName + counter.ToString() + "ShiftTypeOffDuty").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                        break;
                                }
                            }
                            if (ie.UnitOfAssignment != null)
                            {
                                form.SetField(fieldName + counter.ToString() + "Uoa", ie.UnitOfAssignment.Trim());
                            }
                            if (ie.WorkAssignment != null)
                            {
                                form.SetField(fieldName + counter.ToString() + "WorkAssignment", ie.WorkAssignment.Trim());
                            }

                            int forceTypeCounter = 0;
                            forceList = String.Empty;
                            if (ie.TypeOfForce != null)
                            {
                                string[] fid = ie.TypeOfForce.Split(',');

                                if (fid.Length > 0)
                                {
                                    foreach (string ft in fid)
                                    {
                                        forceTypeCounter++;
                                        if (forceTypeCounter != fid.Length)
                                        {
                                            forceList += ft.Trim() + " / ";
                                        }
                                        else
                                        {
                                            forceList += ft.Trim();
                                        }
                                    }
                                }
                            }
                            form.SetField(fieldName + counter.ToString() + "ForceUsed", forceList.Trim());
                            if (ie.IsDirected)
                            {
                                if (ie.IsDirected)
                                {
                                    form.SetField(fieldName + counter.ToString() + "Directed", form.GetFieldItem(fieldName + counter.ToString() + "Directed").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                }
                            }
                            if (ie.IsRescue)
                            {
                                if (ie.IsRescue)
                                {
                                    form.SetField(fieldName + counter.ToString() + "Rescue", form.GetFieldItem(fieldName + counter.ToString() + "Rescue").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                }
                            }
                            if (ie.IsMedicalAssist)
                            {
                                if (ie.IsMedicalAssist)
                                {
                                    form.SetField(fieldName + counter.ToString() + "Medical", form.GetFieldItem(fieldName + counter.ToString() + "Medical").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                }
                            }
                            if (ie.IndividualCatId != null)
                            {
                                switch (ie.IndividualCatId)
                                {
                                    case 1:
                                        form.SetField(fieldName + counter.ToString() + "Cat1", form.GetFieldItem(fieldName + counter.ToString() + "Cat1").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                        break;

                                    case 2:
                                        form.SetField(fieldName + counter.ToString() + "Cat2", form.GetFieldItem(fieldName + counter.ToString() + "Cat2").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                        break;

                                    case 3:
                                        form.SetField(fieldName + counter.ToString() + "Cat3", form.GetFieldItem(fieldName + counter.ToString() + "Cat3").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                        break;
                                }
                            }
                            if (ie.IsInjured)
                            {
                                if (ie.IsInjured)
                                {
                                    form.SetField(fieldName + counter.ToString() + "Injured", form.GetFieldItem(fieldName + counter.ToString() + "Injured").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                }
                            }
                            if (ie.IsTreated)
                            {
                                if (ie.IsTreated)
                                {
                                    form.SetField(fieldName + counter.ToString() + "Treated", form.GetFieldItem(fieldName + counter.ToString() + "Treated").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                }
                            }
                            if (ie.IsAdmitted)
                            {
                                if (ie.IsAdmitted)
                                {
                                    form.SetField(fieldName + counter.ToString() + "Admitted", form.GetFieldItem(fieldName + counter.ToString() + "Admitted").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                }
                            }
                            if (ie.Facility != null)
                            {
                                form.SetField("AdmittedFacility", NameCase(ie.Facility.Trim()));
                            }
                            if (ie.CoronerCaseId != null)
                            {
                                form.SetField("Coroner", ie.CoronerCaseId.Trim());
                            }
                            involvedEmployees1.Remove(ie);
                        }
                    }
                }

                #endregion involvedEmployeesMainPage

                if (involvedEmployees1.Count > 0)
                {
                    form.SetField("AdditionalInvolvedEmployees", form.GetFieldItem("AdditionalInvolvedEmployees").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                }
                List<WitnessUserEntity> SupervisorData = model.Dupties;
                WitnessUserEntity supervisor = SupervisorData.Where(x => x.UserTypeId == 8).FirstOrDefault();
                if (supervisor.EmployeeId != null)
                {
                    form.SetField("OnDutySupervisorEmp", supervisor.EmployeeId.Trim());
                }
                if (supervisor.LastName != null)
                {
                    form.SetField("OnDutySupervisorLastName", NameCase(supervisor.LastName.Trim()));
                }
                if (supervisor.FirstName != null)
                {
                    form.SetField("OnDutySupervisorFirstName", NameCase(supervisor.FirstName.Trim()));
                }
                if (supervisor.MiddleName != null)
                {
                    form.SetField("OnDutySupervisorMiddleName", NameCase(supervisor.MiddleName.Trim()));
                }
                if (supervisor.Rank != null)
                {
                    form.SetField("OnDutySupervisorRank", NameCase(supervisor.Rank.Trim()));
                }
                if (supervisor.IsPresent != null)
                {
                    if (supervisor.IsPresent == "Y")
                    {
                        fieldName = "OnDutySupervisorPresentYes";
                        form.SetField(fieldName, form.GetFieldItem(fieldName).GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                    }
                    else
                    {
                        fieldName = "OnDutySupervisorPresentNo";
                        form.SetField(fieldName, form.GetFieldItem(fieldName).GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                    }
                }
                if (supervisor.IsWitness != null)
                {
                    if (supervisor.IsWitness == "Y")
                    {
                        fieldName = "OnDutySupervisorWitnessYes";
                        form.SetField(fieldName, form.GetFieldItem(fieldName).GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                    }
                    else
                    {
                        fieldName = "OnDutySupervisorWitnessNo";
                        form.SetField(fieldName, form.GetFieldItem(fieldName).GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                    }
                }
                supervisor = SupervisorData.Where(x => x.UserTypeId == 9).FirstOrDefault();
                if (supervisor.EmployeeId != null)
                {
                    form.SetField("SupervisorCompletingEmp", supervisor.EmployeeId.Trim());
                }
                if (supervisor.LastName != null)
                {
                    form.SetField("SupervisorCompletingLastName", NameCase(supervisor.LastName.Trim()));
                }
                if (supervisor.FirstName != null)
                {
                    form.SetField("SupervisorCompletingFirstName", NameCase(supervisor.FirstName.Trim()));
                }
                if (supervisor.MiddleName != null)
                {
                    form.SetField("SupervisorCompletingMiddleName", NameCase(supervisor.MiddleName.Trim()));
                }
                if (supervisor.Rank != null)
                {
                    form.SetField("SupervisorCompletingRank", NameCase(supervisor.Rank.Trim()));
                }
                if (supervisor.IsPresent != null)
                {
                    if (supervisor.IsPresent == "Y")
                    {
                        fieldName = "SupervisorCompletingPresentYes";
                        form.SetField(fieldName, form.GetFieldItem(fieldName).GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                    }
                    else
                    {
                        fieldName = "SupervisorCompletingPresentNo";
                        form.SetField(fieldName, form.GetFieldItem(fieldName).GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                    }
                }
                if (supervisor.IsWitness != null)
                {
                    if (supervisor.IsWitness == "Y")
                    {
                        fieldName = "SupervisorCompletingWitnessYes";
                        form.SetField(fieldName, form.GetFieldItem(fieldName).GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                    }
                    else
                    {
                        fieldName = "SupervisorCompletingWitnessNo";
                        form.SetField(fieldName, form.GetFieldItem(fieldName).GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                    }
                }
                supervisor = SupervisorData.Where(x => x.UserTypeId == 5).FirstOrDefault();
                if (supervisor.EmployeeId != null)
                {
                    form.SetField("WatchCommanderEmp", supervisor.EmployeeId.Trim());
                }
                if (supervisor.LastName != null)
                {
                    form.SetField("WatchCommanderLastName", NameCase(supervisor.LastName.Trim()));
                }
                if (supervisor.FirstName != null)
                {
                    form.SetField("WatchCommanderFirstName", NameCase(supervisor.FirstName.Trim()));
                }
                if (supervisor.MiddleName != null)
                {
                    form.SetField("WatchCommanderMiddleName", NameCase(supervisor.MiddleName.Trim()));
                }
                if (supervisor.Rank != null)
                {
                    form.SetField("WatchCommanderRank", NameCase(supervisor.Rank.Trim()));
                }
                String name = String.Empty;

                #region Madhu Commented

                //TODO - Madhu
                //if (supervisor.UCFirstName != null)
                //{
                //    name = supervisor.UCFirstName.Trim() + " ";
                //}
                //if (supervisor.UCMiddleInitial != null)
                //{
                //    name += supervisor.UCMiddleInitial.Trim() + " ";
                //}
                //if (supervisor.UCLastName != null)
                //{
                //    name += supervisor.UCLastName.Trim();
                //}
                //if (supervisor.UCRank != null)
                //{
                //    name += ", " + supervisor.UCRank.Trim();
                //}
                //form.SetField("UnitCommanderName", NameCase(name.Trim()));
                //if (objForce.UnitCommanderEmp != null)
                //{
                //    form.SetField("UnitCommanderEmp", objForce.UnitCommanderEmp.Trim());
                //}
                //if (objForce.Division != "P")
                //{
                //    String reference = String.Format("{0}-{1}-{2}-{3}", objForce.CustodyReferenceNumber.Substring(0, 4),
                //                                                    objForce.CustodyReferenceNumber.Substring(4, 4),
                //                                                    objForce.CustodyReferenceNumber.Substring(8, 4),
                //                                                    objForce.CustodyReferenceNumber.Substring(12, 3));
                //    form.SetField("ReferenceNumber", reference.Trim());
                //    form.RegenerateField("ReferenceNumber");
                //    int elots1 = 0;
                //    int elots2 = 0;
                //    int elots3 = 0;
                //    Boolean facilityFound = false;
                //    Boolean yearFound = false;
                //    Boolean indexFound = false;
                //    int idx = 0;
                //    foreach (char c in objForce.eLotsNumber)
                //    {
                //        idx++;
                //        if (Char.IsDigit(c))
                //        {
                //            if (!yearFound)
                //            {
                //                elots1++;
                //            }
                //            else
                //            {
                //                facilityFound = true;
                //                elots3++;
                //            }
                //        }
                //        if (Char.IsLetter(c))
                //        {
                //            yearFound = true;
                //            elots2++;
                //        }
                //    }
                //    String elots = String.Format("{0}-{1}-{2}", objForce.eLotsNumber.Substring(0, 4),
                //                                             objForce.eLotsNumber.Substring(4, elots2),
                //                                             objForce.eLotsNumber.Substring(4 + elots2, elots3));

                //    form.SetField("eLotsNumber", elots.Trim());
                //    form.RegenerateField("eLotsNumber");
                //}

                #endregion Madhu Commented

                form.SetField("ReferenceNumber", IncidentModel.ReferenceNo.Trim());
                form.RegenerateField("ReferenceNumber");
                form.SetField("eLotsNumber", IncidentModel.eLOTS.Trim());
                form.RegenerateField("eLotsNumber");
                stamper.FormFlattening = true;
                stamper.Close();
                // Clean up memory
                t438P1.Close();
                t438P1.Dispose();
                t438P1 = null;
                stamper.Dispose();
                stamper = null;
                //XfaForm xfa = form.Xfa;
                form = null;

                #endregion Page1 of 438

                pageCount++;
                // Next area is involved Staff

                #region Page2-? Involved Staff

                involvedEmployees.Clear();
                involvedEmployees = null;
                int tPage = 0;
                if (involvedEmployees1.Count > 0)   // Still have employees to add
                {
                    tPage = involvedEmployees1.Count / 5; // additional Involved Staff pages hold 5 staff
                    tPage += (involvedEmployees1.Count - (involvedEmployees1.Count / 5)) > 0 ? 1 : 0; // Add a page if there is a remainder

                    involvedEmployees = involvedEmployees1.ToList();
                    while (tPage > 0)
                    {
                        tPage--;
                        TemplateFile = System.IO.Path.Combine(templateFolderName, "F438InvolvedEmployees.pdf");
                        //path = System.IO.Path.Combine(tempFolderName, "Page2.pdf");
                        path = tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + "P" + pageCount.ToString() + ".pdf";
                        PdfReader t438IE = new PdfReader(TemplateFile);
                        stamper = new PdfStamper(t438IE, new FileStream(path, FileMode.Create));
                        //stamper.AcroFields.GenerateAppearances = true;
                        form = stamper.AcroFields;
                        form.SetField("URN1", urn[0]);
                        form.SetField("URN2", urn[1]);
                        form.SetField("URN3", urn[2]);
                        form.SetField("URN4", urn[3]);
                        form.SetField("PageNumber", pageCount.ToString().Trim());
                        form.SetField("TotalPages", tbTotalPages.ToString());
                        counter = 0;
                        fieldName = "InvolvedEmployee";
                        foreach (InvolvedUserEntity ie in involvedEmployees)
                        {
                            counter++;
                            if (counter <= 5)
                            {
                                if (ie.IncidentUserInvolvedId != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "Index", ie.IncidentUserInvolvedId.ToString());
                                }
                                if (ie.EmployeeId != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "Emp", ie.EmployeeId.Trim());
                                }
                                if (ie.LastName != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "LastName", NameCase(ie.LastName.Trim()));
                                }
                                if (ie.FirstName != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "FirstName", NameCase(ie.FirstName.Trim()));
                                }
                                if (ie.MiddleName != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "MiddleName", NameCase(ie.MiddleName.Trim()));
                                }
                                if (ie.Rank != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "Rank", ie.Rank.Trim());
                                }
                                if (ie.Sex != null)
                                {
                                    switch (ie.Sex)
                                    {
                                        case "M":
                                            form.SetField(fieldName + counter.ToString() + "Gender", "Male");
                                            break;

                                        case "F":
                                            form.SetField(fieldName + counter.ToString() + "Gender", "Female");
                                            break;

                                        case "T":
                                            form.SetField(fieldName + counter.ToString() + "Gender", "Transgender");
                                            break;

                                        case "U":
                                            form.SetField(fieldName + counter.ToString() + "Gender", "Unknown");
                                            break;

                                        default:
                                            form.SetField(fieldName + counter.ToString() + "Gender", "Unknown");
                                            break;
                                    }
                                    //if (ie.Sex.Trim() == "M")
                                    //{
                                    //    form.SetField(fieldName + counter.ToString() + "Male", form.GetFieldItem(fieldName + counter.ToString() + "Male").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                    //}
                                    //else if (ie.Sex.Trim() == "F")
                                    //{
                                    //    form.SetField(fieldName + counter.ToString() + "Female", form.GetFieldItem(fieldName + counter.ToString() + "Female").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                    //}
                                }
                                if (ie.Race != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "Race", ie.Race.Trim());
                                }
                                if (ie.Height != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "Height", ie.Height.ToString());
                                }
                                if (ie.Weight != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "Weight", ie.Weight.ToString());
                                }
                                if (ie.Age != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "Age", ie.Age.ToString());
                                }
                                if (ie.Shift != null)
                                {
                                    switch (ie.Shift.Trim().ToLower())
                                    {
                                        case "em":
                                            form.SetField(fieldName + counter.ToString() + "ShiftEM", form.GetFieldItem(fieldName + counter.ToString() + "ShiftEM").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                            break;

                                        case "day":
                                            form.SetField(fieldName + counter.ToString() + "ShiftDay", form.GetFieldItem(fieldName + counter.ToString() + "ShiftDay").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                            break;

                                        case "pm":
                                            form.SetField(fieldName + counter.ToString() + "ShiftPM", form.GetFieldItem(fieldName + counter.ToString() + "ShiftPM").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                            break;
                                    }
                                }
                                if (ie.ShiftType != null)
                                {
                                    switch (ie.ShiftType.Trim().ToLower())
                                    {
                                        case "regular":
                                            form.SetField(fieldName + counter.ToString() + "ShiftTypeRegularShift", form.GetFieldItem(fieldName + counter.ToString() + "ShiftTypeRegularShift").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                            break;

                                        case "overtime":
                                            form.SetField(fieldName + counter.ToString() + "ShiftTypeOTShift", form.GetFieldItem(fieldName + counter.ToString() + "ShiftTypeOTShift").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                            break;

                                        case "offduty":
                                            form.SetField(fieldName + counter.ToString() + "ShiftTypeOffDuty", form.GetFieldItem(fieldName + counter.ToString() + "ShiftTypeOffDuty").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                            break;
                                    }
                                }
                                if (ie.UnitOfAssignment != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "Uoa", NameCase(ie.UnitOfAssignment.Trim()));
                                }
                                if (ie.WorkAssignment != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "WorkAssignment", ie.WorkAssignment.Trim());
                                }

                                int forceTypeCounter = 0;
                                forceList = String.Empty;
                                if (ie.TypeOfForce != null)
                                {
                                    string[] fid = ie.TypeOfForce.Split(',');

                                    if (fid.Length > 0)
                                    {
                                        foreach (string ft in fid)
                                        {
                                            forceTypeCounter++;
                                            if (forceTypeCounter != fid.Length)
                                            {
                                                forceList += ft.Trim() + " / ";
                                            }
                                            else
                                            {
                                                forceList += ft.Trim();
                                            }
                                        }
                                    }
                                }
                                form.SetField(fieldName + counter.ToString() + "ForceUsed", forceList.Trim());
                                if (ie.IsDirected)
                                {
                                    if (ie.IsDirected)
                                    {
                                        form.SetField(fieldName + counter.ToString() + "Directed", form.GetFieldItem(fieldName + counter.ToString() + "Directed").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                    }
                                }
                                if (ie.IsRescue)
                                {
                                    if (ie.IsRescue)
                                    {
                                        form.SetField(fieldName + counter.ToString() + "Rescue", form.GetFieldItem(fieldName + counter.ToString() + "Rescue").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                    }
                                }
                                if (ie.IsMedicalAssist)
                                {
                                    if (ie.IsMedicalAssist)
                                    {
                                        form.SetField(fieldName + counter.ToString() + "Medical", form.GetFieldItem(fieldName + counter.ToString() + "Medical").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                    }
                                }
                                if (ie.IndividualCatId != null)
                                {
                                    switch (ie.IndividualCatId)
                                    {
                                        case 1:
                                            form.SetField(fieldName + counter.ToString() + "Cat1", form.GetFieldItem(fieldName + counter.ToString() + "Cat1").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                            break;

                                        case 2:
                                            form.SetField(fieldName + counter.ToString() + "Cat2", form.GetFieldItem(fieldName + counter.ToString() + "Cat2").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                            break;

                                        case 3:
                                            form.SetField(fieldName + counter.ToString() + "Cat3", form.GetFieldItem(fieldName + counter.ToString() + "Cat3").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                            break;
                                    }
                                }
                                if (ie.IsInjured)
                                {
                                    if (ie.IsInjured)
                                    {
                                        form.SetField(fieldName + counter.ToString() + "Injured", form.GetFieldItem(fieldName + counter.ToString() + "Injured").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                    }
                                }
                                if (ie.IsTreated)
                                {
                                    if (ie.IsTreated)
                                    {
                                        form.SetField(fieldName + counter.ToString() + "Treated", form.GetFieldItem(fieldName + counter.ToString() + "Treated").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                    }
                                }
                                if (ie.IsAdmitted)
                                {
                                    if (ie.IsAdmitted)
                                    {
                                        form.SetField(fieldName + counter.ToString() + "Admitted", form.GetFieldItem(fieldName + counter.ToString() + "Admitted").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                    }
                                }
                                if (ie.Facility != null)
                                {
                                    form.SetField("AdmittedFacility", NameCase(ie.Facility.Trim()));
                                }
                                if (ie.CoronerCaseId != null)
                                {
                                    form.SetField("Coroner", ie.CoronerCaseId.Trim());
                                }
                                involvedEmployees1.Remove(ie);
                            }
                        }
                        involvedEmployees.Clear();
                        involvedEmployees = null;
                        if (involvedEmployees1.Count > 0)
                        {
                            involvedEmployees = involvedEmployees1.ToList();
                        }
                        //                    stamper.FormFlattening = true;
                        stamper.Close();
                        // Clean up memory
                        t438IE.Close();
                        t438IE.Dispose();
                        t438IE = null;
                        stamper.Dispose();
                        stamper = null;
                        form = null;
                        pageCount++;
                    }
                }

                #endregion Page2-? Involved Staff

                #region Suspects

                List<SuspectUserEntity> suspects = model.Suspects.ToList();
                List<SuspectUserEntity> suspects1 = model.Suspects.ToList();
                tPage = 0;
                if (suspects.Count > 0)
                {
                    tPage = suspects.Count / 3; // additional Suspect pages hold 3 suspects
                    tPage += (suspects.Count - (suspects.Count / 3)) > 0 ? 1 : 0; // Add a page if there is a remainder
                    int suspectPage = 0;
                    while (tPage > 0)
                    {
                        tPage--;
                        PdfReader t438S = null;
                        //path = System.IO.Path.Combine(tempFolderName, "Page3.pdf");
                        path = tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + "P" + pageCount.ToString() + ".pdf";
                        if (suspectPage == 0)
                        {
                            t438S = new PdfReader(System.IO.Path.Combine(templateFolderName, "F438SuspectInfo.pdf"));
                        }
                        else
                        {
                            t438S = new PdfReader(System.IO.Path.Combine(templateFolderName, "F438SuspectInfoC.pdf"));
                        }
                        stamper = new PdfStamper(t438S, new FileStream(path, FileMode.Create));
                        //var outstream = new MemoryStream();
                        //stamper = new PdfStamper(t438S, outstream);
                        //stamper.AcroFields.GenerateAppearances = true;
                        form = stamper.AcroFields;
                        //XfaForm xfa = form.Xfa;
                        //if (xfa.XfaPresent)
                        //{
                        //    form.RemoveXfa();
                        //}
                        //form
                        form.SetField("URN1", urn[0]);
                        form.SetField("URN2", urn[1]);
                        form.SetField("URN3", urn[2]);
                        form.SetField("URN4", urn[3]);
                        form.SetField("PageNumber", pageCount.ToString().Trim());
                        form.SetField("TotalPages", tbTotalPages.ToString().Trim());

                        counter = 0;
                        fieldName = "Suspect";
                        foreach (SuspectUserEntity s in suspects)
                        {
                            counter++;
                            if (counter < 4)
                            {
                                if (Convert.ToString(s.IncidentUserSuspectId) != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "Index", s.IncidentUserSuspectId.ToString());
                                }
                                if (s.LastName != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "LastName", NameCase(s.LastName.Trim()));
                                }
                                if (s.FirstName != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "FirstName", NameCase(s.FirstName.Trim()));
                                }
                                if (s.MiddleName != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "MiddleName", NameCase(s.MiddleName.Trim()));
                                }
                                if (s.Armed != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "ArmedDDL", s.Armed.Trim());
                                }
                                if (s.AkaLastname != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "AkaLastName", NameCase(s.AkaLastname.Trim()));
                                }
                                if (s.AkaFirstname != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "AkaFirstName", NameCase(s.AkaFirstname.Trim()));
                                }
                                if (s.AkaMiddleName != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "AkaMiddleName", NameCase(s.AkaMiddleName.Trim()));
                                }
                                if (s.Sex != null)
                                {
                                    switch (s.Sex)
                                    {
                                        case "M":
                                            form.SetField(fieldName + counter.ToString() + "Gender", "Male");
                                            break;

                                        case "F":
                                            form.SetField(fieldName + counter.ToString() + "Gender", "Female");
                                            break;

                                        case "T":
                                            form.SetField(fieldName + counter.ToString() + "Gender", "Transgender");
                                            break;

                                        case "U":
                                            form.SetField(fieldName + counter.ToString() + "Gender", "Unknown");
                                            break;

                                        default:
                                            form.SetField(fieldName + counter.ToString() + "Gender", "Unknown");
                                            break;
                                    }
                                }
                                if (s.Race != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "Race", s.Race.Trim());
                                }
                                if (s.Age != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "Age", s.Age.ToString());
                                }
                                if (s.Height != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "Height", s.Height.ToString());
                                }
                                if (s.Weight != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "Weight", s.Weight.ToString());
                                }
                                if (s.DateOfBirth != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "Dob", ((DateTimeOffset)s.DateOfBirth).Date.ToString("MM/dd/yy"));
                                }
                                if (s.PPhMode != null)
                                {
                                    switch (s.PPhMode)
                                    {
                                        case "Cell":
                                            form.SetField(fieldName + counter.ToString() + "Phone1C", form.GetFieldItem(fieldName + counter.ToString() + "Phone1C").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                            break;

                                        case "Home":
                                            form.SetField(fieldName + counter.ToString() + "Phone1H", form.GetFieldItem(fieldName + counter.ToString() + "Phone1H").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                            break;

                                        case "Work":
                                            form.SetField(fieldName + counter.ToString() + "Phone1W", form.GetFieldItem(fieldName + counter.ToString() + "Phone1W").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                            break;
                                    }
                                }
                                if (s.PrimaryPhno != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "Phone1", s.PrimaryPhno.Trim());
                                }
                                if (s.SPhMode != null)
                                {
                                    switch (s.SPhMode)
                                    {
                                        case "Cell":
                                            form.SetField(fieldName + counter.ToString() + "Phone2C", form.GetFieldItem(fieldName + counter.ToString() + "Phone2C").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                            break;

                                        case "Home":
                                            form.SetField(fieldName + counter.ToString() + "Phone2H", form.GetFieldItem(fieldName + counter.ToString() + "Phone2H").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                            break;

                                        case "Work":
                                            form.SetField(fieldName + counter.ToString() + "Phone2W", form.GetFieldItem(fieldName + counter.ToString() + "Phone2W").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                            break;
                                    }
                                }
                                if (s.SecondaryPhno != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "Phone2", s.SecondaryPhno.Trim());
                                }
                                if (s.Street != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "Address", NameCase(s.Street.Trim()));
                                }
                                if (s.City != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "City", NameCase(s.City.Trim()));
                                }
                                String address = String.Empty;
                                if (s.State != null)
                                {
                                    address = s.State.Trim().ToUpper();
                                    if (s.ZipCode != null)
                                    {
                                        address += " " + s.ZipCode.Trim();
                                    }
                                }
                                else
                                {
                                    if (s.ZipCode != null)
                                    {
                                        address = s.ZipCode.Trim();
                                    }
                                }
                                form.SetField(fieldName + counter.ToString() + "StateZip", address.Trim());
                                if (s.BookingNumber != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "Booking", s.BookingNumber.Trim());
                                }
                                if (s.PrimaryChargCode != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "PrimaryCharge", s.PrimaryChargCode.Trim());
                                }
                                if (s.SecondaryChargCode != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "SecondaryCharge", s.SecondaryChargCode.Trim());
                                }
                                if (s.CriminalHistory != null)
                                {
                                    if (s.CriminalHistory == "Y")
                                    {
                                        form.SetField(fieldName + counter.ToString() + "CriminalHistory", form.GetFieldItem(fieldName + counter.ToString() + "CriminalHistory").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                    }
                                }
                                if (s.TreatedOnScene != null)
                                {
                                    if (s.TreatedOnScene == "Y")
                                    {
                                        form.SetField(fieldName + counter.ToString() + "TreatedOnSceneYes", "1");
                                    }
                                    else
                                    {
                                        form.SetField(fieldName + counter.ToString() + "TreatedOnSceneNo", "1");
                                    }
                                }
                                if (s.TreatedName != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "TreatedBy", NameCase(s.TreatedName.Trim()));
                                }
                                if (s.TreatedUnit != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "TreatedByUnit", s.TreatedUnit.Trim());
                                }
                                if (s.TreatedPhone != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "TreatedByPhone", s.TreatedPhone.Trim());
                                }
                                if (s.HospitalAdmission != null)
                                {
                                    if (s.HospitalAdmission == "Y")
                                    {
                                        form.SetField(fieldName + counter.ToString() + "HospitalAdmission", form.GetFieldItem(fieldName + counter.ToString() + "HospitalAdmission").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                    }
                                }
                                if (s.BY != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "Hospital", NameCase(s.BY.Trim()));
                                }
                                if (s.CornerCase != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "CoronerCase", s.CornerCase.Trim());
                                }
                                if (s.MentalHistory != null)
                                {
                                    if (s.MentalHistory == "Y")
                                    {
                                        form.SetField(fieldName + counter.ToString() + "MentalHistory", form.GetFieldItem(fieldName + counter.ToString() + "MentalHistory").GetValue(0).GetAsDict(PdfName.AP).GetAsDict(PdfName.N).Keys.Single().ToString().TrimStart('/'));
                                    }
                                }
                                if (s.RecdTreatmentAt != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "HospitalTreatedBy", s.RecdTreatmentAt.Trim());
                                }
                                if (s.HospitalAddress != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "HospitalAddress", NameCase(s.HospitalAddress.Trim()));
                                }
                                if (s.HospitalPhone != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "HospitalPhone", s.HospitalPhone.Trim());
                                }
                                if (s.UnderInfluence != null)
                                {
                                    if (s.UnderInfluence == "Y")
                                    {
                                        form.SetField(fieldName + counter.ToString() + "UnderInfluenceYes", "1");
                                    }
                                    else
                                    {
                                        form.SetField(fieldName + counter.ToString() + "UnderInfluenceNo", "1");
                                    }
                                }
                                if (s.Substance != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "SubstanceDDL", s.Substance.Trim());
                                }
                                if (s.factorinForce != null)
                                {
                                    if (s.factorinForce == "Y")
                                    {
                                        form.SetField(fieldName + counter.ToString() + "Factor5150Yes", "1");
                                    }
                                    else
                                    {
                                        form.SetField(fieldName + counter.ToString() + "Factor5150No", "1");
                                    }
                                }
                                if (s.InterviewDate != null)
                                {
                                    form.SetField(fieldName + counter.ToString() + "InterviewDate", ((DateTimeOffset)s.InterviewDate).Date.ToString("MM/dd/yy"));
                                    form.SetField(fieldName + counter.ToString() + "InterviewTime", (s.InterviewTime));
                                }
                                if (s.Audiotape != null)
                                {
                                    if (s.Audiotape == "Y")
                                    {
                                        form.SetField(fieldName + counter.ToString() + "AudioTape", "1");
                                    }
                                }
                                if (s.Videotape != null)
                                {
                                    if (s.Videotape == "Y")
                                    {
                                        form.SetField(fieldName + counter.ToString() + "VideoTape", "1");
                                    }
                                }
                                if (s.PhotosofInjuries != null)
                                {
                                    if (s.PhotosofInjuries == "Y")
                                    {
                                        form.SetField(fieldName + counter.ToString() + "PhotosOfInjuries", "1");
                                    }
                                }
                                if (s.Announcements != null)
                                {
                                    if (s.Announcements == "Y")
                                    {
                                        form.SetField(fieldName + counter.ToString() + "AdmitsHearing", "1");
                                    }
                                }
                                suspects1.Remove(s);
                            }
                        }
                        if (suspects1.Count > 0)
                        {
                            form.SetField("AdditionalSuspects", "1");
                        }
                        suspects.Clear();
                        suspects = null;
                        suspects = suspects1.ToList();
                        suspectPage++;
                        //stamper.FormFlattening = true;
                        stamper.Close();
                        // Clean up memory
                        t438S.Close();
                        t438S.Dispose();
                        t438S = null;
                        stamper.Dispose();
                        stamper = null;
                        form = null;
                        pageCount++;
                    }
                }

                #endregion Suspects

                #region Witnesses

                List<WitnessUserEntity> wits = model.NonEmpWitness;
                List<WitnessUserEntity> wits1 = (from f in model.NonEmpWitness select f).ToList();
                List<WitnessUserEntity> eWits = model.EmpWitness;
                List<WitnessUserEntity> eWits1 = (from f in model.EmpWitness select f).ToList();
                tPage = 0;
                if (wits.Count > 0 || eWits.Count > 0)
                {
                    int witPages = 0;
                    int eWitPages = 0;
                    witPages = wits.Count / 9;
                    witPages += (wits.Count - (wits.Count / 9)) > 0 ? 1 : 0; // Add a page if there is a remainder
                    eWitPages = eWits.Count / 3;
                    eWitPages += (eWits.Count - (eWits.Count / 3)) > 0 ? 1 : 0; // Add a page if there is a remainder
                    tPage = (witPages > eWitPages) ? witPages : eWitPages;
                    int witnessPage = 0;
                    while (tPage > 0)
                    {
                        tPage--;
                        PdfReader t438w = null;
                        //path = System.IO.Path.Combine(tempFolderName, "Page4.pdf");
                        path = tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + "P" + pageCount.ToString() + ".pdf";
                        if (witnessPage == 0)
                        {
                            t438w = new PdfReader(System.IO.Path.Combine(templateFolderName, "F438Witnesses.pdf"));
                        }
                        else
                        {
                            t438w = new PdfReader(System.IO.Path.Combine(templateFolderName, "F438WitnessesC.pdf"));
                        }
                        PdfStamper stamperW = new PdfStamper(t438w, new FileStream(path, FileMode.Create));
                        //stamperW.AcroFields.GenerateAppearances = true;
                        form = stamperW.AcroFields;
                        form.SetField("URN1", urn[0]);
                        form.SetField("URN2", urn[1]);
                        form.SetField("URN3", urn[2]);
                        form.SetField("URN4", urn[3]);
                        form.SetField("PageNumber", pageCount.ToString().Trim());
                        form.SetField("TotalPages", tbTotalPages.ToString().Trim());
                        counter = 0;
                        if (eWits.Count > 0)
                        {
                            fieldName = "eWitness";
                            foreach (WitnessUserEntity ew in eWits)
                            {
                                counter++;
                                if (counter <= 4)
                                {
                                    if (ew.IncidentUserWitnessId != null)
                                    {
                                        form.SetField(fieldName + counter.ToString() + "Emp", ew.IncidentUserWitnessId.ToString());
                                    }
                                    if (ew.LastName != null)
                                    {
                                        form.SetField(fieldName + counter.ToString() + "LastName", NameCase(ew.LastName.Trim()));
                                    }
                                    if (ew.FirstName != null)
                                    {
                                        form.SetField(fieldName + counter.ToString() + "FirstName", NameCase(ew.FirstName.Trim()));
                                    }
                                    if (ew.MiddleName != null)
                                    {
                                        form.SetField(fieldName + counter.ToString() + "MiddleName", NameCase(ew.MiddleName.Trim()));
                                    }
                                    if (ew.UnitOfAssignment != null)
                                    {
                                        form.SetField(fieldName + counter.ToString() + "Uoa", ew.UnitOfAssignment.Trim());
                                    }
                                    if (ew.WorkAssignment != null)
                                    {
                                        form.SetField(fieldName + counter.ToString() + "WorkAssignment", ew.WorkAssignment.Trim());
                                    }
                                    if (ew.Shift != null)
                                    {
                                        switch (ew.Shift.Trim().ToLower())
                                        {
                                            case "em":
                                                form.SetField(fieldName + counter.ToString() + "ShiftEM", "1");
                                                break;

                                            case "day":
                                                form.SetField(fieldName + counter.ToString() + "ShiftDay", "1");
                                                break;

                                            case "pm":
                                                form.SetField(fieldName + counter.ToString() + "ShiftPM", "1");
                                                break;
                                        }
                                    }
                                    if (ew.ShiftType != null)
                                    {
                                        switch (ew.ShiftType.Trim().ToLower())
                                        {
                                            case "regular":
                                                form.SetField(fieldName + counter.ToString() + "ShiftTypeRegularShift", "1");
                                                break;

                                            case "overtime":
                                                form.SetField(fieldName + counter.ToString() + "ShiftTypeOTShift", "1");
                                                break;

                                            case "offduty":
                                                form.SetField(fieldName + counter.ToString() + "ShiftTypeOffDuty", "1");
                                                break;
                                        }
                                    }
                                    eWits1.Remove(ew);
                                }
                            }
                        }
                        counter = 0;
                        if (wits.Count > 0)
                        {
                            fieldName = "Witness";
                            foreach (WitnessUserEntity w in wits)
                            {
                                counter++;
                                if (counter < 10)
                                {
                                    if (w.LastName != null)
                                    {
                                        String witName = NameCase(w.LastName.Trim());
                                        if (w.InmateType != null)
                                        {
                                            if (w.InmateType == "IN")
                                            {
                                                witName += " (Bkg #: " + w.EmployeeId.Trim() + ")";
                                            }
                                        }
                                        form.SetField(fieldName + counter.ToString() + "LastName", witName);
                                    }
                                    if (w.FirstName != null)
                                    {
                                        form.SetField(fieldName + counter.ToString() + "FirstName", NameCase(w.FirstName.Trim()));
                                    }
                                    if (w.MiddleName != null)
                                    {
                                        form.SetField(fieldName + counter.ToString() + "MiddleName", NameCase(w.MiddleName.Trim()));
                                    }
                                    if (w.Age != null)
                                    {
                                        form.SetField(fieldName + counter.ToString() + "Age", w.Age.ToString());
                                    }
                                    if (w.DateOfBirth != null)
                                    {
                                        form.SetField(fieldName + counter.ToString() + "Dob", ((DateTimeOffset)w.DateOfBirth).Date.ToString("MM/dd/yy"));
                                    }
                                    if (w.Street != null)
                                    {
                                        form.SetField(fieldName + counter.ToString() + "Address", NameCase(w.Street.Trim()));
                                    }
                                    if (w.City != null)
                                    {
                                        form.SetField(fieldName + counter.ToString() + "City", NameCase(w.City.Trim()));
                                    }
                                    if (w.ZipCode != null)
                                    {
                                        form.SetField(fieldName + counter.ToString() + "Zip", w.ZipCode.Trim());
                                    }
                                    if (w.PrimaryPhone != null)
                                    {
                                        form.SetField(fieldName + counter.ToString() + "Phone1", w.PrimaryPhone.Trim());
                                    }
                                    if (w.SecondaryPhone != null)
                                    {
                                        form.SetField(fieldName + counter.ToString() + "Phone2", w.SecondaryPhone.Trim());
                                    }
                                    wits1.Remove(w);
                                }
                            }
                        }
                        eWits.Clear();
                        eWits = null;
                        eWits = eWits1.ToList();
                        wits.Clear();
                        wits = null;
                        wits = wits1.ToList();
                        if (wits.Count > 0 || eWits.Count > 0)
                        {
                            if (witnessPage == 0)
                            {
                                form.SetField("AdditionalWitnesses", "1");
                            }
                        }
                        //stamperW.FormFlattening = true;
                        stamperW.Close();
                        // Clean up memory
                        t438w.Close();
                        t438w.Dispose();
                        t438w = null;
                        stamperW.Dispose();
                        stamperW = null;
                        form = null;
                        pageCount++;
                        witnessPage++;
                    }
                }

                #endregion Witnesses

                #region Steps

                List<StatisticalEntity> steps = model.Statisticals;
                List<StatisticalEntity> steps1 = (from f in model.Statisticals select f).ToList();
                tPage = 0;
                if (steps.Count > 0)
                {
                    tPage = steps.Count / 25; // additional Suspect pages hold 3 suspects
                    tPage += (steps.Count - (steps.Count / 25)) > 0 ? 1 : 0; // Add a page if there is a remainder
                    while (tPage > 0)
                    {
                        tPage--;
                        //path = System.IO.Path.Combine(tempFolderName, "Page4.pdf");
                        path = tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + "P" + pageCount.ToString() + ".pdf";
                        PdfReader t438st = new PdfReader(System.IO.Path.Combine(templateFolderName, "F438StepbyStep.pdf"));
                        stamper = new PdfStamper(t438st, new FileStream(path, FileMode.Create));
                        //                    stamper.AcroFields.GenerateAppearances = true;
                        form = stamper.AcroFields;
                        form.SetField("URN1", urn[0]);
                        form.SetField("URN2", urn[1]);
                        form.SetField("URN3", urn[2]);
                        form.SetField("URN4", urn[3]);
                        form.SetField("PageNumber", pageCount.ToString().Trim());
                        form.SetField("TotalPages", tbTotalPages.ToString().Trim());
                        counter = 0;
                        fieldName = "Suspect";
                        foreach (StatisticalEntity s in steps)
                        {
                            counter++;
                            if (counter < 26)
                            {
                                if (s.ForcedUsedByName != null)
                                {
                                    form.SetField("UsedBy" + counter.ToString() + "Name", NameCase(s.ForcedUsedByName.Trim()));
                                }
                                if (s.ForcedUsedById != null)
                                {
                                    String usedBy = s.ForcedUsedById.Trim();
                                    if (s.ForcedUsedById != null)
                                    {
                                        usedBy += s.ForcedUsedById.ToString().Trim();
                                    }
                                    form.SetField("UsedBy" + counter.ToString(), usedBy.Trim());
                                }
                                if (s.ForcedUsedAgainstName != null)
                                {
                                    form.SetField("UsedAgainst" + counter.ToString() + "Name", NameCase(s.ForcedUsedAgainstName.Trim()));
                                }
                                if (s.ForcedUsedAgainstId != null)
                                {
                                    String against = s.ForcedUsedAgainstId.Trim();
                                    if (s.ForcedUsedAgainstId != null)
                                    {
                                        against += s.ForcedUsedAgainstId.ToString().Trim();
                                    }
                                    form.SetField("UsedAgainst" + counter.ToString(), against.Trim());
                                }
                                if (s.MethodCode != null)
                                {
                                    form.SetField("Method" + counter.ToString(), s.MethodCode.Trim());
                                }
                                if (s.InjuryTypeCode != null)
                                {
                                    form.SetField("Injury" + counter.ToString(), s.InjuryTypeCode.Trim());
                                }
                                if (s.BodyPartInvolvedCode != null)
                                {
                                    form.SetField("BodyPart" + counter.ToString(), s.BodyPartInvolvedCode.Trim());
                                }
                            }
                            steps1.Remove(s);
                        }
                        steps.Clear();
                        steps = null;
                        steps = steps1.ToList();
                        //stamperW.FormFlattening = true;
                        stamper.Close();
                        // Clean up memory
                        t438st.Close();
                        t438st.Dispose();
                        t438st = null;
                        stamper.Dispose();
                        stamper = null;
                        form = null;
                        pageCount++;
                    }
                }

                #endregion Steps

                #region Canine

                CanineEntity cd = model.Canine;
                if (cd != null)
                {
                    //path = System.IO.Path.Combine(tempFolderName, "Page5.pdf");
                    path = tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + "P" + pageCount.ToString() + ".pdf";
                    PdfReader t438C = new PdfReader(System.IO.Path.Combine(templateFolderName, "F438Canine.pdf"));
                    stamper = new PdfStamper(t438C, new FileStream(path, FileMode.Create));
                    //stamper.AcroFields.GenerateAppearances = true;
                    form = stamper.AcroFields;
                    form.SetField("URN1", urn[0]);
                    form.SetField("URN2", urn[1]);
                    form.SetField("URN3", urn[2]);
                    form.SetField("URN4", urn[3]);
                    form.SetField("TotalPages", tbTotalPages.ToString().Trim());
                    form.SetField("PageNumber", pageCount.ToString().Trim());
                    List<HandlerEntity> Handlers = cd.Handlers;
                    foreach (HandlerEntity item in Handlers)
                    {
                        if (item.HandlerType == "P")
                        {
                            if (item.HandlerName != null)
                            {
                                form.SetField("PrimaryHandlerName", NameCase(item.HandlerName));
                            }
                            if (item.HandlerNumber != null)
                            {
                                form.SetField("PrimaryHandlerEmp", item.HandlerNumber);
                            }
                            if (item.CanineNumber != null)
                            {
                                form.SetField("PrimaryHandlerCanine", NameCase(item.CanineNumber));
                            }
                            if (item.UnitNumber != null)
                            {
                                form.SetField("PrimaryHandlerUnit", item.UnitNumber);
                            }
                        }
                        else
                        {
                            counter++;
                            if (item.HandlerName != null)
                            {
                                form.SetField("AssistHandler" + counter.ToString() + "Name", NameCase(item.HandlerName.Trim()));
                            }
                            if (item.HandlerNumber != null)
                            {
                                form.SetField("AssistHandler" + counter.ToString() + "Emp", item.HandlerNumber);
                            }
                            if (item.CanineNumber != null)
                            {
                                form.SetField("AssistHandler" + counter.ToString() + "Canine", NameCase(item.CanineNumber.Trim()));
                            }
                            if (item.UnitNumber != null)
                            {
                                form.SetField("AssistHandler" + counter.ToString() + "Name", item.UnitNumber.Trim());
                            }
                        }
                    }

                    if (cd.Area != null)
                    {
                        if (cd.Area)
                        {
                            form.SetField("SearchTypeArea", "1");
                        }
                    }
                    if (cd.Building != null)
                    {
                        if (cd.Building)
                        {
                            form.SetField("SearchTypeBuilding", "1");
                        }
                    }
                    if (cd.TOSOther != null)
                    {
                        if (cd.TOSOther)
                        {
                            form.SetField("SearchTypeOther", "1");
                            if (cd.TOIOther != null)
                            {
                                form.SetField("SearchTypeOtherText", cd.BOWOtherReason.ToString());
                            }
                        }
                    }
                    if (cd.Bite != null)
                    {
                        if (cd.Bite)
                        {
                            form.SetField("IncidentTypeBite", "1");
                        }
                    }
                    if (cd.TOIOther != null)
                    {
                        if (cd.TOIOther)
                        {
                            form.SetField("IncidentTypeOther", "1");
                            if (cd.BOWOtherReason != null)
                            {
                                form.SetField("IncidentTypeOtherText", cd.BOWOtherReason.Trim());
                            }
                        }
                    }
                    if (cd.ApprehendingSuspect != null)
                    {
                        if (cd.ApprehendingSuspect)
                        {
                            form.SetField("BiteApprehending", "1");
                        }
                    }
                    if (cd.ConductingSearch != null)
                    {
                        if (cd.ConductingSearch)
                        {
                            form.SetField("BiteConducting", "1");
                        }
                    }
                    if (cd.ProtectingHandler != null)
                    {
                        if (cd.ProtectingHandler)
                        {
                            form.SetField("BiteProtecting", "1");
                        }
                    }
                    if (cd.BOWOtherReason != null)
                    {
                        if (cd.BOWOtherReason != null)
                        {
                            form.SetField("BiteOther", "1");
                            if (cd.BOWOtherReason != null)
                            {
                                form.SetField("BiteOtherText", cd.BOWOtherReason.Trim());
                            }
                        }
                    }
                    if (cd.AnnouncementsBy != null)
                    {
                        if (cd.AnnouncementsBy)
                        {
                            form.SetField("AnnouncementsMade", "1");
                        }
                    }
                    if (cd.AnnouncementsIn)
                    {
                        if (cd.AnnouncementsIn)
                        {
                            form.SetField("AnnouncementsNone", "1");
                            if (cd.AnnouncementsNoneReason != null)
                            {
                                form.SetField("AnnouncementsNoneReason", cd.AnnouncementsNoneReason.Trim());
                            }
                        }
                    }
                    if (cd.AnnouncementMadebyReason != null)
                    {
                        form.SetField("AnnouncementsMadeBy", NameCase(cd.AnnouncementMadebyReason));
                    }
                    if (cd.BYAeroUnit)
                    {
                        if (cd.BYAeroUnit)
                        {
                            form.SetField("AnnouncementsAero", "1");
                        }
                    }
                    if (cd.ByRadioCar)
                    {
                        if (cd.ByRadioCar)
                        {
                            form.SetField("AnnouncementsRadioCar", "1");
                        }
                    }
                    if (cd.English)
                    {
                        if (cd.English)
                        {
                            form.SetField("AnnouncementsEnglish", "1");
                        }
                    }
                    if (cd.Spanish)
                    {
                        if (cd.Spanish)
                        {
                            form.SetField("AnnouncementsSpanish", "1");
                        }
                    }
                    if (cd.Recorded)
                    {
                        if (cd.Recorded)
                        {
                            form.SetField("AnnoouncementsRecorded", "1");
                        }
                    }
                    if (cd.CriminalHistory != null)
                    {
                        form.SetField("CriminalHistory", cd.CriminalHistory.Trim());
                    }
                    if (cd.Notifications != null)
                    {
                        form.SetField("Notifications", cd.Notifications.Trim());
                    }
                    //ac.Clear();
                    //ac = null;
                    stamper.FormFlattening = true;
                    stamper.Close();
                    // Clean up memory
                    t438C.Close();
                    t438C.Dispose();
                    t438C = null;
                    stamper.Dispose();
                    stamper = null;
                    form = null;
                    pageCount++;
                }

                #endregion Canine

                #region buildform

                counter = 0;
                Document document = new Document();
                //Server.MapPath(ConfigurationManager.AppSettings["ReportTemplatesPath"])
                string cpath = tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + ".pdf";
                PdfSmartCopy copy = new PdfSmartCopy(document, new FileStream(cpath, FileMode.Create));
                document.Open();
                document.AddTitle("Custody Force");
                document.AddSubject("Supervisors Report on Use of Force");
                document.AddCreator("Custody Force");
                document.AddAuthor("Madhu"); //TODO
                pageCount--;
                //flatten files
                while (counter < pageCount)
                {
                    counter++;
                    PdfReader t438 = new PdfReader(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + "P" + counter.ToString() + ".pdf");
                    stamper = new PdfStamper(t438, new FileStream(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + "P" + counter.ToString() + "f.pdf", FileMode.Create), PdfWriter.VERSION_1_7);
                    t438.SetPageContent(1, t438.GetPageContent(1), PdfStream.BEST_COMPRESSION, true);
                    //t438.AcroFields.GenerateAppearances = true;
                    stamper.Writer.CompressionLevel = 9;
                    stamper.SetFullCompression();
                    stamper.FormFlattening = true;
                    stamper.Reader.RemoveUnusedObjects();
                    stamper.SetFullCompression();
                    stamper.Close();
                    t438.Close();
                    t438.Dispose();
                    t438 = null;
                    System.IO.File.Delete(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + "P" + counter.ToString() + ".pdf");
                }
                counter = 0;
                while (counter < pageCount)
                {
                    counter++;
                    PdfReader t438 = new PdfReader(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + "P" + counter.ToString() + "f.pdf");
                    copy.AddDocument(t438);
                    t438.Close();
                    t438.Dispose();
                    t438 = null;
                    System.IO.File.Delete(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + "P" + counter.ToString() + "f.pdf");
                }
                document.Close();
                // Compress document
                PdfReader t438c = new PdfReader(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + ".pdf");

                stamper = new PdfStamper(t438c, new FileStream(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + "-C.pdf", FileMode.Create), PdfWriter.VERSION_1_7);
                stamper.SetFullCompression();
                //            stamper.Writer.SetFullCompression();
                stamper.Reader.RemoveUnusedObjects();
                PdfWriter writer = stamper.Writer;
                writer.CompressionLevel = PdfStream.BEST_COMPRESSION;
                t438c.RemoveFields();
                t438c.RemoveUnusedObjects();
                stamper.Close();
                t438c.Close();
                t438c.Dispose();
                t438c = null;

                System.IO.File.Delete(tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + ".pdf");

                #endregion buildform

                string outputfile = tempFolderName + "\\" + (string)UofSessionValue.Get("UserName") + urn1.Trim() + "-C.pdf";
                Response.ContentType = "Application/pdf";
                Response.AppendHeader("Content-Disposition", "attachment; filename=" + outputfile);
                Response.TransmitFile(outputfile);
                Response.End();
            }

            //PdfWindow.NavigateUrl = "~/Temp/" + sysUser.sAMAccountName.Trim() + urn1.Trim() + "-C.pdf";
        }

        private String NameCase(String myText)
        {
            CultureInfo cultureInfo = Thread.CurrentThread.CurrentCulture;
            TextInfo ti = cultureInfo.TextInfo;
            myText = myText.ToLower();
            myText = ti.ToTitleCase(myText);
            return myText.Trim();
        }

        private string getViewName(string reportName)
        {
            string retValue = string.Empty;

            switch (reportName)
            {
                case "UoF_CatOne":
                    retValue = "_CatOnePDF";
                    break;

                case "UoF_ReviewNotice":
                    retValue = "_ReviewNoticePDF";
                    break;

                case "UoF_Custody_Division":
                    retValue = "_CustodyDivisionPDF";
                    break;

                //case "UoF_Memo":
                //    retValue = "_MemoPDF";
                //    break;
                
                //case "UoF_SuppReport":
                //    retValue = "_SuppReportPDF";
                //    break;

                case "UoF_WCReview":
                    retValue = "_WCPDF";
                    break;

                case "UoF_UCReview":
                    retValue = "_UCPDF";
                    break;

                case "UoF_CMReview":
                    retValue = "_CMPDF";
                    break;

                case "UoF_Tracking":
                    retValue = "_FTRPDF";
                    break;

                case "UoF_Narrative":
                    retValue = "_NarrativePDF";
                    break;

                case "UoF_MedicalReport":
                    retValue = "_MedicalPDF";
                    break;

                case "UoF_InmateInjury":
                    retValue = "_InmatePDF";
                    break;

                case "UoF_IAB":
                    retValue = "_IABPDF";
                    break;

                default:
                    break;
            }

            return retValue;
        }

        public ActionResult Index_old(string FormId, string reportName = "Default", string userID = "")
        {
            //BLUoFForm bl = new BLUoFForm();
            //var data = bl.GetMedicalReport(17, 1, "786001");
            //string customswitch = string.Format("--print-media-type --zoom 0.7 --header-spacing 2 --header-line --allow {0} --footer-html {0} --allow {1} --header-html {1}",
            //Url.Action("Footer", "Report", new { area = "" }, "http"), Url.Action("Header", "Report", new { area = "" }, "http"));

            string customswitch =
               "--footer-center \"Name: " + "Medical" + "  DOS: " +
               DateTime.Now.Date.ToString("MM/dd/yyyy") + "  Page: [page]/[toPage]\"" +
               " --footer-line --footer-font-size \"9\" --footer-spacing 6 --footer-font-name \"calibri light\"";
            //BLUoFForm bl = new BLUoFForm();
            //BLInmateInjury bl = new BLInmateInjury();//new BLUoFForm();
            //BLUoFForm bl = new BLUoFForm();//new BLUoFForm();
            BLReview bl = new BLReview();

            //var data = bl.GetMedicalReport(17, 9, "504160");
            //var data = bl.GetInmateInjury(19, 9, "504160");
            // var data = bl.GetMemoDetails(20, 9, "504160");
            //var data = bl.GetSup(21, 9, "504160");

            ViewBag.FormId = "17";
            ViewBag.IncidentId = (string)UofSessionValue.Get("SelectedIncidentId");
            ViewBag.SubmitedId = userID;

            //GeneratePDF("_MedicalPDF", customswitch, "Test", data);

            // GeneratePDF("_UCPDF", customswitch, "Test", data);

            return View("_MemoPDF");
            //return View("_MedicalPDF", data);
            //return View("_InmatePDF", data);
            //return View("_MemoPDF", data);
            //return View("_SuppReportPDF", data);
            //return View("_MedicalPDF", data);

            //if (reportName == "UoF_SupervisorsReport")
            //    isSupervisoryRpt = true;

            //_repName = reportName;
            //string TempFile = _repName + ".pdf";

            //string tempFolderName = Server.MapPath(ConfigurationManager.AppSettings["ReportTempPath"]);
            //if (!Directory.Exists(tempFolderName))
            //    Directory.CreateDirectory(tempFolderName);

            //string path = Path.Combine(tempFolderName, TempFile);
            //if (System.IO.File.Exists(path))
            //    System.IO.File.Delete(path);
            //string templateFolderName = Server.MapPath(ConfigurationManager.AppSettings["ReportTemplatesPath"]);
            //string TemplateFile = Path.Combine(templateFolderName, _repName + ".pdf");
            //if (System.IO.File.Exists(TemplateFile))
            //{
            //    PdfReader pdfReader = new PdfReader(TemplateFile);
            //    using (FileStream objStream = new FileStream(path, FileMode.Create))
            //    {
            //        PdfStamper pdfStamper = new PdfStamper(pdfReader, objStream);

            //        AcroFields pdfFormFields = pdfStamper.AcroFields;
            //        string SelectedIncidentId = (string)UofSessionValue.Get("SelectedIncidentId");
            //        int formid = Convert.ToInt32(FormId);
            //        this.GetReport(formid, Convert.ToInt32(SelectedIncidentId));
            //        SetReportDataItems(pdfFormFields);

            //        pdfStamper.FormFlattening = true;
            //        // close the pdf
            //        pdfStamper.Close();
            //        //Response.Redirect("temp/" + TempFile, false);
            //    }

            //    Response.ContentType = "Application/pdf";
            //    Response.AppendHeader("Content-Disposition", "attachment; filename=" + _repName + ".pdf");
            //    Response.TransmitFile(path);
            //    Response.End();
            //}
        }

        private void GeneratePDF(string viewName, string customswitch, string token, object model)
        {
            MemoryStream stream = null;
            try
            {
                string fileName = viewName.Replace("PDF", string.Empty);
                var pdf = new CshtmlViewAsPDF(viewName, model) { CustomSwitches = customswitch };
                var pdfBytes = pdf.BuildPdf(ControllerContext);
                stream = new MemoryStream(pdfBytes);
                stream.WriteTo(Response.OutputStream);
                Response.AppendCookie(new HttpCookie("fileDownloadToken", token));
                System.Web.HttpContext.Current.Response.AddHeader("content-disposition", "attachment; filename=UOF" + fileName + DateTime.Now.ToString("yyyyMMddHHmmss") + ".pdf");
            }
            catch (Exception exception)
            {
            }
        }

        private void GetReport(int formId, int incidentId, string empId)
        {
            var fctry = new DefaultFactory();
            _objModel = fctry.GetModelObject(formId, incidentId, empId);
        }

        private void SetReportDataItems(AcroFields pdfFormFields)
        {
            if (_objModel != null)
            {
                this.GetReportNameString();
                var properties = _objModel.GetType().GetProperties();
                foreach (var item in properties)
                {
                    if (item.PropertyType.IsGenericType && item.PropertyType.GetGenericTypeDefinition() == typeof(List<>))//item.PropertyType.GetInterfaces().Any(x => x == typeof(IEnumerable))  Note:dont remove may be it cab be use laster to test if property is ofcollectio type
                    {
                        Type clsValue = item.PropertyType.GetGenericArguments()[0];
                        string PropName = clsValue.Name;
                        if (isSupervisoryRpt)
                            PropName = item.Name;
                        var model = (IEnumerable)GetListPropertyValue(_objModel, PropName);
                        var counter = 0;
                        if (model != null)
                        {
                            foreach (var clsItem in model)
                            {
                                counter++;

                                if (_lstRepName.Contains(_repName))
                                {
                                    string ID = string.Empty;
                                    string Observer = string.Empty;
                                    string Answer = string.Empty;
                                    string Cntrltype = string.Empty;
                                    string name = string.Empty;
                                    if (clsItem.GetType().GetProperties().Length == 4)
                                    {
                                        ID = clsItem.GetType().GetProperties()[0].GetValue(clsItem).ToString();
                                        Cntrltype = clsItem.GetType().GetProperties()[1].GetValue(clsItem).ToString();
                                        Answer = clsItem.GetType().GetProperties()[2].GetValue(clsItem).ToString();
                                        Observer = clsItem.GetType().GetProperties()[3].GetValue(clsItem).ToString();
                                        name = Observer + ID;
                                        if (Cntrltype == "radio")
                                            name = Observer + ID + Answer;
                                        if (_repName == "UoF_CrimeAnalysis" || _repName == "UoF_CustodyServices")
                                            name = ID;
                                        pdfFormFields.SetField(name, Answer);
                                    }
                                    else if (_repName == "UoF_CustodyServices" && clsItem.GetType().GetProperties().Length == 5)
                                    {
                                        foreach (var listItem in clsItem.GetType().GetProperties())
                                        {
                                            pdfFormFields.SetField(listItem.Name + "_" + counter, listItem.GetValue(clsItem, null) == null ? "" : listItem.GetValue(clsItem, null).ToString());
                                        }
                                    }
                                }
                                else
                                {
                                    string prefixString = string.Empty;
                                    if (isSupervisoryRpt)
                                    {
                                        if (item.Name == "Suspects")
                                            prefixString = "SS_";
                                        else if (item.Name == "EmpWitness")
                                            prefixString = "EW_";
                                        else if (item.Name == "NonEmpWitness")
                                            prefixString = "NEW_";
                                        else if (item.Name == "Dupties")
                                        {
                                            if (clsItem != null)
                                            {
                                                string userTypeId = clsItem.GetType().GetProperty("UserTypeId").GetValue(clsItem, null).ToString();
                                                switch (userTypeId)
                                                {
                                                    case "8":
                                                        prefixString = "D_";
                                                        break;

                                                    case "9":
                                                        prefixString = "S_";
                                                        break;

                                                    case "5":
                                                        prefixString = "WC_";
                                                        break;
                                                }
                                            }
                                        }
                                    }
                                    if (clsItem != null)
                                    {
                                        foreach (var listItem in clsItem.GetType().GetProperties())
                                        {
                                            pdfFormFields.SetField(prefixString + listItem.Name + "_" + counter, listItem.GetValue(clsItem, null) == null ? "" : listItem.GetValue(clsItem, null).ToString());
                                        }
                                    }
                                }
                            }
                        }
                    }
                    // Checking the Class type of properties and their values
                    else if (item.PropertyType.FullName != "System.String" && !item.PropertyType.IsPrimitive)
                    {
                        //Type argType = item.PropertyType.GetGenericArguments()[0]; /Note this code will give the type of the property like class name

                        #region if Below code not works to get the class type propeties infor use this

                        var model = GetPropertyValue(_objModel, item.Name);
                        if (model != null)
                        {
                            foreach (var clsItem in model.GetType().GetProperties())
                            {
                                if (clsItem.PropertyType.IsGenericType && clsItem.PropertyType.GetGenericTypeDefinition() == typeof(List<>))
                                {
                                    Type aclsValue = clsItem.PropertyType.GetGenericArguments()[0];
                                    string PropName = aclsValue.Name;
                                    if (isSupervisoryRpt)
                                        PropName = clsItem.Name;
                                    var amodel = (IEnumerable)GetListPropertyValue(model, PropName);
                                    if (amodel != null)
                                    {
                                        var counter = 0;
                                        foreach (var aclsItem in amodel)
                                        {
                                            if (_repName == "UoF_CrimeAnalysis" || _repName == "UoF_CustodyServices")
                                            {
                                                if (aclsItem.GetType().GetProperties().Length == 4)
                                                {
                                                    counter++;
                                                    pdfFormFields.SetField(aclsItem.GetType().GetProperties()[0].Name + "_" + counter, aclsItem.GetType().GetProperties()[0].GetValue(aclsItem).ToString());
                                                    pdfFormFields.SetField(aclsItem.GetType().GetProperties()[1].Name + "_" + counter, aclsItem.GetType().GetProperties()[1].GetValue(aclsItem).ToString());
                                                    pdfFormFields.SetField(aclsItem.GetType().GetProperties()[2].Name + "_" + counter, aclsItem.GetType().GetProperties()[2].GetValue(aclsItem).ToString());
                                                    pdfFormFields.SetField(aclsItem.GetType().GetProperties()[3].Name + "_" + counter, aclsItem.GetType().GetProperties()[3].GetValue(aclsItem).ToString());
                                                }
                                            }
                                            else
                                            {
                                                if (aclsItem.GetType().GetProperties().Length == 6)
                                                {
                                                    counter++;
                                                    pdfFormFields.SetField(aclsItem.GetType().GetProperties()[0].Name + "_" + counter, aclsItem.GetType().GetProperties()[0].GetValue(aclsItem).ToString());
                                                    pdfFormFields.SetField(aclsItem.GetType().GetProperties()[1].Name + "_" + counter, aclsItem.GetType().GetProperties()[1].GetValue(aclsItem).ToString());
                                                    pdfFormFields.SetField(aclsItem.GetType().GetProperties()[2].Name + "_" + counter, aclsItem.GetType().GetProperties()[2].GetValue(aclsItem).ToString());
                                                    pdfFormFields.SetField(aclsItem.GetType().GetProperties()[3].Name + "_" + counter, aclsItem.GetType().GetProperties()[3].GetValue(aclsItem).ToString());
                                                    pdfFormFields.SetField(aclsItem.GetType().GetProperties()[4].Name + "_" + counter, aclsItem.GetType().GetProperties()[4].GetValue(aclsItem).ToString());
                                                    pdfFormFields.SetField(aclsItem.GetType().GetProperties()[5].Name + "_" + counter, aclsItem.GetType().GetProperties()[5].GetValue(aclsItem).ToString());
                                                }
                                                else if (aclsItem.GetType().GetProperties().Length == 3)
                                                {
                                                    if (_repName == "UoF_IncidentReport")
                                                    {
                                                        counter++;
                                                        pdfFormFields.SetField(aclsItem.GetType().GetProperties()[0].Name, aclsItem.GetType().GetProperties()[0].GetValue(aclsItem).ToString());
                                                        counter++;
                                                        pdfFormFields.SetField(aclsItem.GetType().GetProperties()[1].Name, aclsItem.GetType().GetProperties()[1].GetValue(aclsItem).ToString());
                                                        counter++;
                                                        pdfFormFields.SetField(aclsItem.GetType().GetProperties()[2].Name, aclsItem.GetType().GetProperties()[2].GetValue(aclsItem).ToString());
                                                    }
                                                    else
                                                    {
                                                        counter++;
                                                        pdfFormFields.SetField(aclsItem.GetType().GetProperties()[0].Name + "_" + counter, aclsItem.GetType().GetProperties()[0].GetValue(aclsItem).ToString());
                                                        counter++;
                                                        pdfFormFields.SetField(aclsItem.GetType().GetProperties()[1].Name + "_" + counter, aclsItem.GetType().GetProperties()[1].GetValue(aclsItem).ToString());
                                                        counter++;
                                                        pdfFormFields.SetField(aclsItem.GetType().GetProperties()[2].Name + "_" + counter, aclsItem.GetType().GetProperties()[2].GetValue(aclsItem).ToString());
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                else
                                    if (isSupervisoryRpt && clsItem.Name == "URN")
                                {
                                    string value = clsItem.GetValue(model, null).ToString();
                                    value = (value.Length < 15) ? value.PadRight(15, '0') : value;
                                    pdfFormFields.SetField(clsItem.Name + "1", clsItem.GetValue(model, null) == null ? "" : value.Substring(0, 3));
                                    pdfFormFields.SetField(clsItem.Name + "2", clsItem.GetValue(model, null) == null ? "" : value.Substring(4, 5));
                                    pdfFormFields.SetField(clsItem.Name + "3", clsItem.GetValue(model, null) == null ? "" : value.Substring(10, 4));
                                    pdfFormFields.SetField(clsItem.Name + "4", clsItem.GetValue(model, null) == null ? "" : value.Substring(11, 3));

                                    pdfFormFields.SetField("S_" + clsItem.Name + "1", clsItem.GetValue(model, null) == null ? "" : value.Substring(0, 3));
                                    pdfFormFields.SetField("S_" + clsItem.Name + "2", clsItem.GetValue(model, null) == null ? "" : value.Substring(4, 5));
                                    pdfFormFields.SetField("S_" + clsItem.Name + "3", clsItem.GetValue(model, null) == null ? "" : value.Substring(10, 4));
                                    pdfFormFields.SetField("S_" + clsItem.Name + "4", clsItem.GetValue(model, null) == null ? "" : value.Substring(11, 3));

                                    pdfFormFields.SetField("EN_" + clsItem.Name + "1", clsItem.GetValue(model, null) == null ? "" : value.Substring(0, 3));
                                    pdfFormFields.SetField("EN_" + clsItem.Name + "2", clsItem.GetValue(model, null) == null ? "" : value.Substring(4, 5));
                                    pdfFormFields.SetField("EN_" + clsItem.Name + "3", clsItem.GetValue(model, null) == null ? "" : value.Substring(10, 4));
                                    pdfFormFields.SetField("EN_" + clsItem.Name + "4", clsItem.GetValue(model, null) == null ? "" : value.Substring(11, 3));

                                    pdfFormFields.SetField("SD_" + clsItem.Name + "1", clsItem.GetValue(model, null) == null ? "" : value.Substring(0, 3));
                                    pdfFormFields.SetField("SD_" + clsItem.Name + "2", clsItem.GetValue(model, null) == null ? "" : value.Substring(4, 5));
                                    pdfFormFields.SetField("SD_" + clsItem.Name + "3", clsItem.GetValue(model, null) == null ? "" : value.Substring(10, 4));
                                    pdfFormFields.SetField("SD_" + clsItem.Name + "4", clsItem.GetValue(model, null) == null ? "" : value.Substring(11, 3));

                                    pdfFormFields.SetField("IE_" + clsItem.Name + "1", clsItem.GetValue(model, null) == null ? "" : value.Substring(0, 3));
                                    pdfFormFields.SetField("IE_" + clsItem.Name + "2", clsItem.GetValue(model, null) == null ? "" : value.Substring(4, 5));
                                    pdfFormFields.SetField("IE_" + clsItem.Name + "3", clsItem.GetValue(model, null) == null ? "" : value.Substring(10, 4));
                                    pdfFormFields.SetField("IE_" + clsItem.Name + "4", clsItem.GetValue(model, null) == null ? "" : value.Substring(11, 3));

                                    pdfFormFields.SetField("SI_" + clsItem.Name + "1", clsItem.GetValue(model, null) == null ? "" : value.Substring(0, 3));
                                    pdfFormFields.SetField("SI_" + clsItem.Name + "2", clsItem.GetValue(model, null) == null ? "" : value.Substring(4, 5));
                                    pdfFormFields.SetField("SI_" + clsItem.Name + "3", clsItem.GetValue(model, null) == null ? "" : value.Substring(10, 4));
                                    pdfFormFields.SetField("SI_" + clsItem.Name + "4", clsItem.GetValue(model, null) == null ? "" : value.Substring(11, 3));

                                    pdfFormFields.SetField("EW_" + clsItem.Name + "1", clsItem.GetValue(model, null) == null ? "" : value.Substring(0, 3));
                                    pdfFormFields.SetField("EW_" + clsItem.Name + "2", clsItem.GetValue(model, null) == null ? "" : value.Substring(4, 5));
                                    pdfFormFields.SetField("EW_" + clsItem.Name + "3", clsItem.GetValue(model, null) == null ? "" : value.Substring(10, 4));
                                    pdfFormFields.SetField("EW_" + clsItem.Name + "4", clsItem.GetValue(model, null) == null ? "" : value.Substring(11, 3));

                                    pdfFormFields.SetField("CN_" + clsItem.Name + "1", clsItem.GetValue(model, null) == null ? "" : value.Substring(0, 3));
                                    pdfFormFields.SetField("CN_" + clsItem.Name + "2", clsItem.GetValue(model, null) == null ? "" : value.Substring(4, 5));
                                    pdfFormFields.SetField("CN_" + clsItem.Name + "3", clsItem.GetValue(model, null) == null ? "" : value.Substring(10, 4));
                                    pdfFormFields.SetField("CN_" + clsItem.Name + "4", clsItem.GetValue(model, null) == null ? "" : value.Substring(11, 3));
                                }
                                else
                                    pdfFormFields.SetField(clsItem.Name, clsItem.GetValue(model, null) == null ? "" : clsItem.GetValue(model, null).ToString());
                            }
                        }

                        #endregion if Below code not works to get the class type propeties infor use this
                    }
                    else
                    {
                        pdfFormFields.SetField("URN", (string)UofSessionValue.Get("SelectedIncidentURN"));
                        pdfFormFields.SetField(item.Name, item.GetValue(_objModel, null) == null ? "" : item.GetValue(_objModel, null).ToString());
                    }
                }
            }
        }

        public object GetPropertyValue(object obj, string propertyName)
        {
            foreach (var prop in propertyName.Split('.').Select(s => obj.GetType().GetProperty(s)))
                obj = prop.GetValue(obj, null);

            return obj;
        }

        public object GetListPropertyValue(object obj, string propertyName)
        {
            Type t = obj.GetType();
            PropertyInfo prop = t.GetProperty(propertyName);
            object list = prop.GetValue(obj);

            return list;
        }

        /// <summary>
        /// Method to check whether a given type is a collection type
        /// </summary>
        /// <param name="type">input type</param>
        /// <returns>true if type is a collection else false</returns>
        private void GetReportNameString()
        {
            _lstRepName = new List<string>();
            _lstRepName.Add("UoF_WCReview");
            _lstRepName.Add("UoF_UCReview");
            _lstRepName.Add("UoF_CMReview");
            _lstRepName.Add("UoF_CrimeAnalysis");
            _lstRepName.Add("UoF_CustodyServices");
        }

        [AllowAnonymous]
        public ActionResult Footer()
        {
            return View();
        }

        /// <summary>
        /// Footer for the pdf
        /// </summary>
        /// <returns>Partial View for footer</returns>
        [AllowAnonymous]
        public ActionResult Header()
        {
            return View();
        }
    }
}


//BLUoFForm bl = new BLUoFForm();
//var data = bl.GetMedicalReport(17, 1, "786001");
//string customswitch = string.Format("--print-media-type --zoom 0.7 --header-spacing 2 --header-line --allow {0} --footer-html {0} --allow {1} --header-html {1}",
//Url.Action("Footer", "Report", new { area = "" }, "http"), Url.Action("Header", "Report", new { area = "" }, "http"));

//BLUoFForm bl = new BLUoFForm();
//var data = bl.GetMedicalReport(17, 1, "504160");
//string customswitch =
//       "--footer-center \"Name: " + reportName + "  DOS: " +
//       DateTime.Now.Date.ToString("MM/dd/yyyy") + "  Page: [page]/[toPage]\"" +
//       " --footer-line --footer-font-size \"10\" --footer-spacing 6 --footer-font-name \"MS Gothic\"";

//BLInmateInjury bl = new BLInmateInjury();
//BLUoFForm bl = new BLUoFForm();//new BLUoFForm();
//BLReview bl = new BLReview();
//BLSupervisorsReportforce bl = new BLSupervisorsReportforce();
//var data = bl.GetMemoDetails(20, 9, "504160");
//var data = bl.GetSupplementalDetails(22, 9, "504160");
//var data = bl.GetWCReviewData(23, 8, "408494");
//var data = bl.GetUCReviewData(26, 8, "216980");
//var data = bl.GetReviewNotice(15, 9, "234272");
//var data = bl.GetForceReview(12, 9, "234272");
//var data = bl.GetCommanderReviewData(30, 8, "413798");

//var data = bl.GetSupervisorsReportforceInfo(14, 8, "234272");
//var data = bl.GetTrackingDetails(12, 8);
//GeneratePDF("_MedicalPDF", customswitch, "UoF_Tracking", data);
// return View("_MedicalPDF", data);

//        string customswitch = string.Format("--print-media-type --zoom 0.7 --header-spacing 2 --header-line --allow {0} --footer-html {0} --allow {1} --header-html {1}",
//Url.Action("Footer", "Home", new { area = "" }, "http"), Url.Action("Header", "Home", new { area = "" }, "http"));