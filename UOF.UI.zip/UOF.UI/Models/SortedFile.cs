﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UOF.UI.Models
{
   internal class SortedFile
    {
        internal string FileName { get; set; }
        internal int FileOrder { get; set; }
    }
}
