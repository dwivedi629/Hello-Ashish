﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UOF.UI.Models
{
    public class GlobalObject
    {
        public string RoleCode { get; set; }
        public string FormId { get; set; }
        public string SelectedIncidentId { get; set; }
        public string UserCode { get; set; }
        public int NoOfNotifications { get; set; }
        public string SelectedIncidentURN { get; set; }
        public string SelectedIncidentDate { get; set; }
        public string SelectedIncidentCategory { get; set; }
        public string UserName { get; set; }
        public string IsCFRTNotified { get; set; }
        public string IsIABNotified { get; set; }
        public bool RoleReadOnly { get; set; }
        public string ApprovedIncidentId { get; set; }
        public string SelectedPageNumber { get; set; }
        public string ReferenceNo { get; set; }
        public string IncidentLocation { get; set; }
        public string ForceLocation { get; set; }
        public string Station { get; set; }
        public string OnDutySupervisor { get; set; }
        public string InvestSupervisor { get; set; }
        public string WC { get; set; }
        public string eLot { get; set; }
        public string Rank { get; set; }
    }
}