﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UOF.UI.Models
{
   internal class UploadFilesResult
    {
       internal string Name { get; set; }
       internal int Length { get; set; }
       internal string Type { get; set; }
    }
}
