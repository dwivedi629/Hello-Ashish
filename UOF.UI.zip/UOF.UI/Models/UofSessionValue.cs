﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Reflection;

namespace UOF.UI.Models
{
    public sealed class UofSessionValue
    {
        /// <summary>
        /// Get the session value based on key
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public static object Get(String key)
        {
            if (string.IsNullOrWhiteSpace(key)) return new NotImplementedException("Must pass key");
            if (HttpContext.Current.Session["GlobalObject"] != null)
            {
                GlobalObject globalObject = (GlobalObject)HttpContext.Current.Session["GlobalObject"];
                if (globalObject != null)
                {
                    PropertyInfo propInfos = typeof(GlobalObject).GetProperty(key);
                    if (propInfos != null)
                    {
                      return  propInfos.GetValue(globalObject);
                    }

                }
            }

            return null;
        }

        /// <summary>
        /// Set the value based on key
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        public static void Set(string key, object value)
        {

            GlobalObject globalObject = null;
            if (HttpContext.Current.Session["GlobalObject"] != null)
            {
                globalObject = (GlobalObject)HttpContext.Current.Session["GlobalObject"];
            }
            else
            {
                globalObject = new GlobalObject();
            }

            PropertyInfo[] propInfo = typeof(GlobalObject).GetProperties();
            foreach (var item in propInfo)
            {
                if (item.Name == key)
                {
                   item.SetValue(globalObject, value);
                   break;
                }
            }

            HttpContext.Current.Session["GlobalObject"] = globalObject;
        }

        /// <summary>
        /// Expire the session
        /// </summary>
        public static void ExpireSession()
        {
            HttpContext.Current.Session.Clear();
            HttpContext.Current.Session.Abandon();
        }
    }
}