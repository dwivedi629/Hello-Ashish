﻿using Rotativa;
using System.Web.Mvc;


namespace UOF.UI.Models
{
    public class CshtmlViewAsPDF : PartialViewAsPdf
    {
        public CshtmlViewAsPDF(string viewName, object model)
            : base(viewName, model)
        {

        }


        public byte[] GetByte(ControllerContext context)
        {
            base.PrepareResponse(context.HttpContext.Response);
            base.ExecuteResult(context);
            return base.CallTheDriver(context);
        }
    }
}