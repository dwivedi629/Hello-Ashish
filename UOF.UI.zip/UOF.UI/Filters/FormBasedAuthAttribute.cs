﻿using System;
using System.Configuration;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using UOF.UI.Helper;
using UOF.UI.Models;

namespace UOF.UI.Filters
{
    public class FormBasedAuthAttribute :AuthorizeAttribute
    {
        public string FormCode
        {
            get;
            set;
        }
        public FormBasedAuthAttribute(string frmCode)
        {
            FormCode = frmCode;
        }

       private bool IsAuthorized { get; set; }

       public override void OnAuthorization(AuthorizationContext httpContext)
        {
            IsAuthorized = UofAuthorizedUserPermission.IsAuthorized(FormCode);
            HandleUnauthorizedRequest(httpContext);
        }
        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {

            if (!IsAuthorized)
            {
                if (string.IsNullOrWhiteSpace((string)UofSessionValue.Get("RoleCode")))
                {
                    filterContext.Result = new RedirectResult("~/Login/Index");
                }
                else
                {
                    filterContext.Result = new RedirectResult("~/Unauthorized/Index");
                }
            }
        }
    }
}