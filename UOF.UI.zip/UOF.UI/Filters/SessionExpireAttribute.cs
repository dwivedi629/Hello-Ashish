﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace UOF.UI.Filters
{
    public class SessionExpireAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            // check  sessions here
            if (HttpContext.Current.Session["GlobalObject"] == null)
            {
                Uri lastUrl = System.Web.HttpContext.Current.Request.UrlReferrer;
                if (lastUrl != null)
                    filterContext.Result = new RedirectResult("~/Login/Index?returnUrl=" + lastUrl.PathAndQuery);
                else if(System.Web.HttpContext.Current.Request.Url!=null)
                {
                    lastUrl = System.Web.HttpContext.Current.Request.Url;
                    filterContext.Result = new RedirectResult("~/Login/Index?returnUrl=" +lastUrl.PathAndQuery);
                }
                else
                    filterContext.Result = new RedirectResult("~/Login/Index"); 
            }
            base.OnActionExecuting(filterContext);
        }
    }
}