﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Net.Http;
using System.Net.Http.Headers;
using UOF.Common.EntityModel;
using UOF.Logging;
using UOF.UI.Models;

namespace UOF.UI.Helper
{
    public static class UofAuthorizedUserPermission
    {
       static UofAuthorizedUserPermission()
        {
            httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Accept.Clear();
            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

       private static HttpClient httpClient = null;
        static readonly ILogService LogService = new LogService(typeof(UofAuthorizedUserPermission));
        private static string LoggedInRoleCode { get; set; }
        //public static string LoggedInUserId { get; set; }
        public static string SuperAdmin = "SuperAdmin";

        /// <summary>
        /// This method is used for authorization check for form based
        /// </summary>
        /// <param name="frmCode">form code</param>
        /// <returns>true or false</returns>
        public static bool IsAuthorized(string frmCode)
        {
            LoggedInRoleCode = (string)UofSessionValue.Get("RoleCode");
            if (string.IsNullOrWhiteSpace(LoggedInRoleCode)) return false;
            if (LoggedInRoleCode == SuperAdmin) return true;

            string query = string.Format(ConfigurationManager.AppSettings["UOF.API"] + "/api/Settings/GetFormPermission?formCode={0}&roleCode={1}", frmCode, LoggedInRoleCode);
            try
            {
                var resp = httpClient.GetAsync(query).Result;
                resp.EnsureSuccessStatusCode();
                return resp.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "IsAuthorized", ex.Source.ToString(), ex.StackTrace.ToString());
            }

            return false;
        }

        /// <summary>
        /// This method is used for authorization check for form based
        /// </summary>
        /// <param name="frmCode">form code</param>
        public static void GetAllRequiredEntities()
        {
            string query = ConfigurationManager.AppSettings["UOF.API"] + "/api/Settings/GetAllRequiredEntities";
            try
            {
                var resp = httpClient.GetAsync(query).Result;
                resp.EnsureSuccessStatusCode();
            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "IsAuthorizedMenu", ex.Source.ToString(), ex.StackTrace.ToString());
            }
        }

        public static List<FormsNameSettings> GetFormsName()
        {
            string query = string.Format(ConfigurationManager.AppSettings["UOF.API"] + "/api/Settings/GetFormsName");
            try
            {
                var resp = httpClient.GetAsync(query).Result;
                resp.EnsureSuccessStatusCode();
                return resp.Content.ReadAsAsync<List<FormsNameSettings>>().Result;

            }
            catch (Exception ex)
            {
                LogService.CustomError(ex, "GetFormsName", ex.Source.ToString(), ex.StackTrace.ToString());
            }

            return null;
        }
    }

}