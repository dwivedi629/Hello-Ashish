﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Mail;
using System.Web;
using UOF.Business;
using UOF.Common.EntityModel;
using UOF.Common.Utilities;
using UOF.Logging;
using UOF.UI.Models;

namespace UOF.UI.Helper
{
    public class UoFHelper
    {
        readonly ILogService LogService = new LogService(typeof(UoFHelper));
        public void getNotifications(string roleCode, string userCode)
        {
            var BLIncident = new BLIncident();
            int result = 0;
            try
            {
                result = BLIncident.GetNotifications(roleCode, userCode);

            }
            catch (Exception)
            {
            }

            UofSessionValue.Set("NoOfNotifications", result);
        }
        public bool validateUser()
        {
            var uofRoles = GetRoles();
            string strUserName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
            string displayName = strUserName;
            bool isAuth = System.Security.Principal.WindowsIdentity.GetCurrent().IsAuthenticated;
            if (strUserName.Contains("\\"))
                displayName = strUserName.Split('\\')[1];
            if (!string.IsNullOrWhiteSpace(displayName) && isAuth)
            {

                string query = string.Format(ConfigurationManager.AppSettings["EmployeeService"] + "{0}", displayName);
                using (var client = CreateProxy(query))
                {
                    try
                    {
                        var resp = client.GetAsync(query).Result;
                        resp.EnsureSuccessStatusCode();
                        UserModel model = resp.Content.ReadAsAsync<UserModel>().Result;
                        string forceRole = string.Empty;
                        //if (model.Success)
                        //{
                        UofAuthorizedUserPermission.GetAllRequiredEntities();
                        bool isCFRT = getUserGroups(model.EmployeeNumber, false);
                        bool isMED = getUserGroups(model.EmployeeNumber, true);
                        if (isCFRT)
                            UofSessionValue.Set("RoleCode", Constants.UserRoles.CFRT.ToString());
                        else if (isMED)
                            UofSessionValue.Set("RoleCode", Constants.UserRoles.MED.ToString());
                        else
                        {
                            switch (model.RankAbrev.ToUpper())
                            {
                                case "W/C":
                                case "LT":
                                    forceRole = Constants.UserRoles.WC.ToString();
                                    break;
                                case "CAPT":
                                case "A/CAPT":
                                    forceRole = Constants.UserRoles.CAPT.ToString();
                                    break;
                                case "C/A":
                                case "CA":
                                    forceRole = Constants.UserRoles.CA.ToString();
                                    break;
                                case "CHIEF":
                                    forceRole = Constants.UserRoles.DC.ToString();
                                    break;
                                default:
                                    forceRole = model.RankAbrev.ToUpper();
                                    break;
                            }
                        }
                        var uRole = uofRoles.Find(x => x.RoleCode == forceRole);
                        UofSessionValue.Set("Rank", Convert.ToString(uRole.Rank)); //Rank 
                        UofSessionValue.Set("RoleReadOnly", uRole.ReadOnly);
                        UofSessionValue.Set("RoleCode", forceRole);
                        UofSessionValue.Set("UserCode", model.EmployeeNumber);
                        UofSessionValue.Set("UserName", model.DisplayName);
                        //}
                        // return model.Success;
                        return true;
                    }
                    catch (Exception ex)
                    {
                        LogService.CustomError(ex, "validateUser", ex.Source, ex.StackTrace);
                    }


                }
            }
            return false; ;
        }

        private List<UserRoleSettingsEntity> GetRoles()
        {
            BLFormPermissionSettings obj = new BLFormPermissionSettings();
            string query = ConfigurationManager.AppSettings["UOF.API"] + "/api/Settings/GetRoles";
            List<UserRoleSettingsEntity> model = new List<UserRoleSettingsEntity>();
            using (var client = CreateProxy(query))
            {
                try
                {
                    var resp = client.GetAsync(query).Result;
                    resp.EnsureSuccessStatusCode();
                    model = resp.Content.ReadAsAsync<List<UserRoleSettingsEntity>>().Result;

                }
                catch (Exception ex)
                {
                    LogService.CustomError(ex, "getUserGroups", ex.Source, ex.StackTrace);
                }
                return model;
            }
        }

        public bool getUserGroups(string employeeNumber, bool isMedicalUser)
        {
            string query = string.Format(ConfigurationManager.AppSettings["CFRTService"] + "{0}", employeeNumber);
            using (var client = CreateProxy(query))
            {
                try
                {
                    var resp = client.GetAsync(query).Result;
                    resp.EnsureSuccessStatusCode();
                    UserModel model = resp.Content.ReadAsAsync<UserModel>().Result;

                    foreach (var item in model.groups)
                    {

                        if (isMedicalUser)
                        {
                            if (item == "Med Srvs Bureau, All Personnel") return true;
                        }
                        else
                        {
                            if (item == "CTSB-CFRT") return true;
                        }
                    }

                    //CTSB-CFRT

                }
                catch (Exception ex)
                {
                    LogService.CustomError(ex, "getUserGroups", ex.Source, ex.StackTrace);
                }
                return false;
            }
        }

        public bool SendMail(string emailId, int IncidentId)
        {
            bool retValue;
            //try
            //{
            //    BLUoFForm UoF = new BLUoFForm();
            //    var BLIncident = new BLIncident();
            //    var result = BLIncident.GetIncidentData(Convert.ToInt32(IncidentId));
            //    var body = "<p>Email From: {0} ({1})</p><p>Message:</p><p>{2}</p>";
            //    var message = new System.Net.Mail.MailMessage();
            //    message.To.Add(new MailAddress(emailId));
            //    message.Subject = "Incident URN: " + result.URN;
            //    message.Body = string.Format(body, "UoF Project", "The URN is for your review", "Test Mail from the UoF Application");
            //    message.IsBodyHtml = true;
            //    SmtpClient smtp = new SmtpClient();
            //    smtp.Send(message);


            //        EmailNotificationModel entity = new EmailNotificationModel();
            //        entity.IncidentId = Convert.ToInt32(IncidentId);
            //        entity.EmailId = emailId;
            //        entity.Sent = true;
            //        entity.Department = "CFRT";
            //        entity.EmployeeNumber = (string)UofSessionValue.Get("UserCode");
            //        retValue = UoF.EmailNotification(entity);

            //    return retValue;
            //}
            //catch (Exception ex)
            //{
            //    LogService.CustomError(ex, "SendMail", ex.InnerException != null ? ex.InnerException.Message : ex.Message, ex.StackTrace);
            //}
            return false;
        }
        private static HttpClient CreateProxy(string query)
        {
            var client = new HttpClient();
            client.BaseAddress = new Uri(ConfigurationManager.AppSettings["EmployeeService"]);//
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            return client;
        }
    }
}