﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace UOF.UI.Helper
{
    public static class GlobalUofConfiguration
    {
        public static string GetApiURL
        {
            get
            {
                return ConfigurationManager.AppSettings["UOF.API"].ToString();
            }
        }
        public static string GetUIURL
        {
            get
            {
                return ConfigurationManager.AppSettings["UOF.UI"].ToString();
            }
        }
        public static string GetInvolvedEmployeeServiceURL
        {
            get
            {
                if (ConfigurationManager.AppSettings["allowWithLogin"] == "true")
                    return ConfigurationManager.AppSettings["UOF.API"].ToString() + "/api/Incident/GetEmployeeDetails?empId=";

                else
                    return ConfigurationManager.AppSettings["InvolvedEmployeeService"].ToString();
            }
        }
        public static string GetInmateServiceURL
        {
            get
            {
                if (ConfigurationManager.AppSettings["allowWithLogin"] == "true")
                    return ConfigurationManager.AppSettings["UOF.API"].ToString() + "/api/User/GetSuspectDetails?bookingNumber=";
                else
                    return ConfigurationManager.AppSettings["InmateService"].ToString();
            }
        }
        public static string GetCFRTServiceURL
        {
            get
            {
                return ConfigurationManager.AppSettings["CFRTService"].ToString();
            }
        }
        public static string GetForceServiceURL
        {
            get
            {
                return ConfigurationManager.AppSettings["ForceService"].ToString();
            }
        }
        public static string GetEmployeeURL
        {
            get
            {
                if (ConfigurationManager.AppSettings["allowWithLogin"] == "true")
                    return ConfigurationManager.AppSettings["UOF.API"].ToString() + "/api/Incident/GetEmployeeDetails?empId=";

                else
                    return ConfigurationManager.AppSettings["EmployeeService"].ToString();
            }
        }
    }

    public class SettingPermission
    {
        public const string SettingMainMenu = "Settings";
        public const string Settings = "Settings";
    }

    public class CommanderPermission
    {
        public const string CommanderMainMenu = "Commander";
        public const string C_UofReview = "C_UofReview";
    }

    public class UnitCommanderPermission
    {
        public const string UnitCommanderMainMenu = "UnitCommander";
        public const string UC_UofReview = "UC_UofReview";
    }

    public class WatchCommanderPermission
    {
        public const string WatchCommanderMainMenu = "WatchCommander";
        public const string WC_UofReview = "WC_UofReview";
        public const string WC_IMF = "WC_IMF";
    }

    public class DuptyPermission
    {
        public const string DeputyMainMenu = "Deputy";
        public const string D_CSDCAS = "D_CSDCAS";
        public const string D_IncidentReport = "D_IncidentReport";
        public const string D_InmateInjurtIllness = "D_InmateInjurtIllness";
        public const string D_MedicalReport = "D_MedicalReport";
        public const string D_CASS = "D_CASS";
        public const string D_DUofM = "D_DUofM";
        public const string D_DSR = "D_DSR";
    }

    public class SergeantPermission
    {
        public const string SergeantMainMenu = "Sergeant";
        public const string Ser_ForceNarrativeReport = "Ser_ForceNarrativeReport";
        public const string IncidenSer_ChemicalAgenttReport = "Ser_ChemicalAgent";
        public const string Ser_CDFRchecklist = "Ser_CDFRchecklist";
        public const string Ser_UofPTS = "Ser_UofPTS";

        public const string Ser_UofC1Incidents = "Ser_UofC1Incidents";
        public const string Ser_UofRNotice = "Ser_UofRNotice";
    }

    public class IncidentPermission
    {
        public const string InvolvedEmp = "InvolvedEmp";
        public const string SuspectInfo = "SuspectInfo";
        public const string EmpWitness = "EmpWitness";
        public const string NonEmpWitness = "NonEmpWitness";
        public const string StaticalData = "StaticalData";
        public const string OnDuty = "OnDuty";
        public const string CanineDeployment = "CanineDeployment";
        public const string IncidentList = "IncidentList";
        public const string IncidentDetails = "IncidentDetails";
        public const string ArtifactPermission = "ArtifactPermission";
    }

    public class ReportPermission
    {
        public const string ReportMainMenu = "Reports";
        public const string Reports = "Reports";
    }

    public class LogoutPermission
    {
        public const string LogoutMenu = "Logout";
    }
}