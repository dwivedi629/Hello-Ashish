﻿var uof = uof || {};
uof.ui = uof.ui || {};
uof.ui.incident = uof.ui.incident || {};

if (uof.ui.incident) {
    uof.ui.incident.deputy = function () {
        return {
            parameters: null,
            isChanged: false,
            init: function (args) {
                this.parameters = args;
            },
            viewModel: {
                OnDupty: {
                    Mode: ko.observable("Add"),
                    IncidentId: ko.observable(),
                    EmployeeId: ko.observable(""),
                    LastName: ko.observable(""),
                    FirstName: ko.observable(""),
                    MiddleName: ko.observable(""),
                    Rank: ko.observable(),
                    IsPresent: ko.observable(),
                    IsWitness: ko.observable(),
                    UserTypeId: ko.observable(8),
                    LoggedId: ko.observable(UoFParams.userId),
                    EmailId: ko.observable(),
                },
                SupervisorComplInvest: {
                    Mode: ko.observable("Add"),
                    IncidentId: ko.observable(),
                    EmployeeId: ko.observable(""),
                    LastName: ko.observable(""),
                    FirstName: ko.observable(""),
                    MiddleName: ko.observable(""),
                    Rank: ko.observable(),
                    IsPresent: ko.observable(),
                    IsWitness: ko.observable(),
                    UserTypeId: ko.observable(9),
                    LoggedId: ko.observable(UoFParams.userId),
                    EmailId: ko.observable(),
                },
                WatchCommander: {
                    Mode: ko.observable("Add"),
                    IncidentId: ko.observable(),
                    EmployeeId: ko.observable(""),
                    LastName: ko.observable(""),
                    FirstName: ko.observable(""),
                    MiddleName: ko.observable(""),
                    Rank: ko.observable(),
                    UserTypeId: ko.observable(5),
                    LoggedId: ko.observable(UoFParams.userId),
                    EmailId: ko.observable(),
                },

                getEmployeeDetails: function (value, mode) {
                    uof.ui.incident.deputy.getEmployeeDetails(value, mode);
                },
            },
            load: function () {

                if (uof.ui.incident.detail.selectedContext.selectedIncident() > 0) {
                    uof.ui.incident.deputy.validateControls();
                    uof.ui.incident.deputy.subscribeMethod();
                    uof.ui.incident.deputy.viewModel.OnDupty.IncidentId = uof.ui.incident.detail.selectedContext.selectedIncident();
                    uof.ui.incident.deputy.viewModel.SupervisorComplInvest.IncidentId = uof.ui.incident.detail.selectedContext.selectedIncident();
                    uof.ui.incident.deputy.viewModel.WatchCommander.IncidentId = uof.ui.incident.detail.selectedContext.selectedIncident();
                    uof.ui.incident.deputy.incidentDuptiesInfo();
                    ko.cleanNode($("#On_Duty").get(0));
                    ko.applyBindings(uof.ui.incident.deputy.viewModel, $("#On_Duty").get(0));
                    uof.ui.incident.detail.viewModel.incident.currentMode(localStorage.getItem('mode'));
                }
                if ((uof.ui.incident.detail.viewModel.incident.currentMode() == 'Edit')) {
                    uof.ui.incident.deputy.SetFormControls(false);
                }
                else if ((uof.ui.incident.detail.viewModel.incident.currentMode() == 'view')) {
                    uof.ui.incident.deputy.SetFormControls(true);
                }
            },
            SetFormControls: function (isDisable) {
                $("#On_Duty").find('input, select, textarea, button').each(function () {
                    $(this).attr('disabled', isDisable);
                });
            },

            //Cancel Data,on cancel button click
            cancelData: function () {
                //uof.ui.incident.deputy.viewModel.OnDupty.Mode= ko.observable("Add");
                //uof.ui.incident.deputy.viewModel.OnDupty.IncidentId = ko.observable(undefined);
                //uof.ui.incident.deputy.viewModel.OnDupty.EmployeeId = ko.observable(undefined);
                //uof.ui.incident.deputy.viewModel.OnDupty.LastName = ko.observable(undefined);
                //uof.ui.incident.deputy.viewModel.OnDupty.FirstName = ko.observable(undefined);
                //uof.ui.incident.deputy.viewModel.OnDupty.MiddleName = ko.observable(undefined);
                //uof.ui.incident.deputy.viewModel.OnDupty.Rank = ko.observable(undefined);
                //uof.ui.incident.deputy.viewModel.OnDupty.IsPresent = ko.observable(undefined);
                //uof.ui.incident.deputy.viewModel.OnDupty.IsWitness = ko.observable(undefined);
                //uof.ui.incident.deputy.viewModel.OnDupty.UserTypeId= ko.observable(8);
                //uof.ui.incident.deputy.viewModel.OnDupty.LoggedId= ko.observable(UoFParams.userId);
                //uof.ui.incident.deputy.viewModel.OnDupty.EmailId = ko.observable(undefined);

                //uof.ui.incident.deputy.viewModel.SupervisorComplInvest.Mode= ko.observable("Add");
                //uof.ui.incident.deputy.viewModel.SupervisorComplInvest.IncidentId= ko.observable(undefined);
                //uof.ui.incident.deputy.viewModel.SupervisorComplInvest.EmployeeId = ko.observable(undefined);
                //uof.ui.incident.deputy.viewModel.SupervisorComplInvest.LastName = ko.observable(undefined);
                //uof.ui.incident.deputy.viewModel.SupervisorComplInvest.FirstName = ko.observable(undefined);
                //uof.ui.incident.deputy.viewModel.SupervisorComplInvest.MiddleName = ko.observable(undefined);
                //uof.ui.incident.deputy.viewModel.SupervisorComplInvest.Rank = ko.observable(undefined);
                //uof.ui.incident.deputy.viewModel.SupervisorComplInvest.IsPresent = ko.observable(undefined);
                //uof.ui.incident.deputy.viewModel.SupervisorComplInvest.IsWitness = ko.observable(undefined);
                //uof.ui.incident.deputy.viewModel.SupervisorComplInvest.UserTypeId= ko.observable(9);
                //uof.ui.incident.deputy.viewModel.SupervisorComplInvest.LoggedId= ko.observable(UoFParams.userId);
                //uof.ui.incident.deputy.viewModel.SupervisorComplInvest.EmailId = ko.observable(undefined);

                //uof.ui.incident.deputy.viewModel.WatchCommander.Mode= ko.observable("Add");
                //uof.ui.incident.deputy.viewModel.WatchCommander.IncidentId = ko.observable(undefined);
                //uof.ui.incident.deputy.viewModel.WatchCommander.EmployeeId = ko.observable(undefined);
                //uof.ui.incident.deputy.viewModel.WatchCommander.LastName = ko.observable(undefined);
                //uof.ui.incident.deputy.viewModel.WatchCommander.FirstName = ko.observable(undefined);
                //uof.ui.incident.deputy.viewModel.WatchCommander.MiddleName = ko.observable(undefined);
                //uof.ui.incident.deputy.viewModel.WatchCommander.Rank = ko.observable(undefined);
                //uof.ui.incident.deputy.viewModel.WatchCommander.UserTypeId= ko.observable(5);
                //uof.ui.incident.deputy.viewModel.WatchCommander.LoggedId= ko.observable(UoFParams.userId);
                //uof.ui.incident.deputy.viewModel.WatchCommander.EmailId = ko.observable(undefined);

                //var objDeputy = uof.ui.incident.deputy.viewModel.OnDupty;
                //var objSC = uof.ui.incident.deputy.viewModel.SupervisorComplInvest;
                //var objWC = uof.ui.incident.deputy.viewModel.WatchCommander;

                for (var objDeputy in uof.ui.incident.deputy.viewModel) {
                    for (var prop in uof.ui.incident.deputy.viewModel[objDeputy]) {
                        if (uof.ui.incident.deputy.viewModel[objDeputy].hasOwnProperty(prop) && ko.isObservable(uof.ui.incident.deputy.viewModel[objDeputy][prop])) {
                            if (prop == "Mode")
                                uof.ui.incident.deputy.viewModel[objDeputy][prop]("Add");
                            else
                                uof.ui.incident.deputy.viewModel[objDeputy][prop](undefined);
                        }
                    }
                }
                result = ko.validation.group(uof.ui.incident.deputy.viewModel, { deep: true });
                result.showAllMessages(false);
                uof.ui.incident.deputy.load();
                //for (var prop in objSC) {
                //    if (objSC.hasOwnProperty(prop) && ko.isObservable(objSC[prop])) {
                //        objSC[prop](undefined);
                //    }
                //}
                //for (var prop in objWC) {
                //    if (objWC.hasOwnProperty(prop) && ko.isObservable(objWC[prop])) {
                //        objWC[prop](undefined);
                //    }
                //}
            },
            //Validate the controls on Add
            validateControls: function () {
                uof.ui.incident.deputy.viewModel.OnDupty.EmployeeId.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });

                //uof.ui.incident.deputy.viewModel.OnDupty.Rank.extend({
                //    required: {
                //        params: true,
                //    },
                //});
                uof.ui.incident.deputy.viewModel.OnDupty.IsPresent.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });

                uof.ui.incident.deputy.viewModel.OnDupty.IsWitness.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });
                //*********************************************
                uof.ui.incident.deputy.viewModel.SupervisorComplInvest.EmployeeId.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });

                //uof.ui.incident.deputy.viewModel.SupervisorComplInvest.Rank.extend({
                //    required: {
                //        params: true,
                //        message: IncidentConstants.Required
                //    },
                //});
                uof.ui.incident.deputy.viewModel.SupervisorComplInvest.IsPresent.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });

                uof.ui.incident.deputy.viewModel.SupervisorComplInvest.IsWitness.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });
                uof.ui.incident.deputy.viewModel.WatchCommander.EmployeeId.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });

                //uof.ui.incident.deputy.viewModel.WatchCommander.Rank.extend({
                //    required: {
                //        params: true,
                //        message: IncidentConstants.Required
                //    },
                //});
            },
            // subscribe method
            subscribeMethod: function () {
                // Subscribing the name and code to get changes
                uof.ui.incident.deputy.viewModel.OnDupty.Rank.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        uof.ui.incident.deputy.isChanged = true;
                    }

                });
                uof.ui.incident.deputy.viewModel.OnDupty.IsPresent.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        uof.ui.incident.deputy.isChanged = true;
                    }

                });
                uof.ui.incident.deputy.viewModel.OnDupty.IsWitness.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        uof.ui.incident.deputy.isChanged = true;
                    }

                });

                uof.ui.incident.deputy.viewModel.SupervisorComplInvest.Rank.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        uof.ui.incident.deputy.isChanged = true;
                    }

                });
                uof.ui.incident.deputy.viewModel.SupervisorComplInvest.IsPresent.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        uof.ui.incident.deputy.isChanged = true;
                    }

                });
                uof.ui.incident.deputy.viewModel.SupervisorComplInvest.IsWitness.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        uof.ui.incident.deputy.isChanged = true;
                    }

                });


                uof.ui.incident.deputy.viewModel.WatchCommander.EmployeeId.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        uof.ui.incident.deputy.isChanged = true;
                    }

                });
                uof.ui.incident.deputy.viewModel.WatchCommander.Rank.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        uof.ui.incident.deputy.isChanged = true;
                    }

                });

            },
            validateDeputiesInfo: function () {
                result = ko.validation.group([uof.ui.incident.deputy.viewModel.OnDupty.EmployeeId, uof.ui.incident.deputy.viewModel.SupervisorComplInvest.EmployeeId, uof.ui.incident.deputy.viewModel.WatchCommander.EmployeeId]);
                if (result().length > 0) {
                    uof.ui.incident.deputy.viewModel.OnDupty.EmployeeId.valueHasMutated();
                    uof.ui.incident.deputy.viewModel.SupervisorComplInvest.EmployeeId.valueHasMutated();
                    uof.ui.incident.deputy.viewModel.WatchCommander.EmployeeId.valueHasMutated();
                    return false;
                }
                return true;
            },
            validateDeputiesInfoFields: function () {
                result = ko.validation.group(uof.ui.incident.deputy.viewModel, { deep: true });
                if (result().length > 0) {
                    uof.ui.incident.deputy.viewModel.OnDupty.EmployeeId.valueHasMutated();
                    uof.ui.incident.deputy.viewModel.OnDupty.Rank.valueHasMutated();
                    uof.ui.incident.deputy.viewModel.OnDupty.IsPresent.valueHasMutated();
                    uof.ui.incident.deputy.viewModel.OnDupty.IsWitness.valueHasMutated();

                    uof.ui.incident.deputy.viewModel.SupervisorComplInvest.EmployeeId.valueHasMutated();
                    uof.ui.incident.deputy.viewModel.SupervisorComplInvest.Rank.valueHasMutated();
                    uof.ui.incident.deputy.viewModel.SupervisorComplInvest.IsPresent.valueHasMutated();
                    uof.ui.incident.deputy.viewModel.SupervisorComplInvest.IsWitness.valueHasMutated();

                    uof.ui.incident.deputy.viewModel.WatchCommander.EmployeeId.valueHasMutated();
                    uof.ui.incident.deputy.viewModel.WatchCommander.Rank.valueHasMutated();
                    return false;
                }
                return true;
            },

            getEmployeeDetails: function (empId, mode) {

                if ((empId == undefined) || ((empId != undefined) && (empId.length <= 0))) {
                    if (empId == "") {
                        switch (mode) {
                            case "OD":
                                uof.ui.incident.deputy.viewModel.OnDupty.FirstName("");
                                uof.ui.incident.deputy.viewModel.OnDupty.LastName("");
                                uof.ui.incident.deputy.viewModel.OnDupty.MiddleName("");
                                uof.ui.incident.deputy.viewModel.OnDupty.Rank("");
                                break;
                            case "WC":
                                uof.ui.incident.deputy.viewModel.WatchCommander.FirstName("");
                                uof.ui.incident.deputy.viewModel.WatchCommander.LastName("");
                                uof.ui.incident.deputy.viewModel.WatchCommander.MiddleName("");
                                uof.ui.incident.deputy.viewModel.WatchCommander.Rank("");
                                break;
                            default:
                                uof.ui.incident.deputy.viewModel.SupervisorComplInvest.FirstName("");
                                uof.ui.incident.deputy.viewModel.SupervisorComplInvest.LastName("");
                                uof.ui.incident.deputy.viewModel.SupervisorComplInvest.MiddleName("");
                                uof.ui.incident.deputy.viewModel.SupervisorComplInvest.Rank("");

                                break;
                        }
                    }
                    return false
                };


                var IdOfControls = (mode == 'OD' ? '#OD_Employee' : mode == 'WC' ? '#WC_Employee' : '#SCI_Employee');
                // Search based on emp id
                $.prototype.showProgressBar("On_Duty " + IdOfControls);
                jQuery.ajax({
                    type: "GET",
                    url: EmployeeAPIUrl() + empId,
                    dataType: "json",
                    cache: false,
                    crossDomain: true,
                    processData: true,
                    success: function (empData) {
                        if (mode == 'OD') {
                            uof.ui.incident.deputy.viewModel.OnDupty.FirstName(empData.FirstName);
                            uof.ui.incident.deputy.viewModel.OnDupty.LastName(empData.LastName);
                            uof.ui.incident.deputy.viewModel.OnDupty.MiddleName(empData.MiddleName);
                            uof.ui.incident.deputy.viewModel.OnDupty.Rank(empData.Rank);
                            uof.ui.incident.deputy.viewModel.OnDupty.EmailId(empData.EmailAddress);
                        }
                        else if (mode == 'WC') {
                            uof.ui.incident.deputy.viewModel.WatchCommander.FirstName(empData.FirstName);
                            uof.ui.incident.deputy.viewModel.WatchCommander.LastName(empData.LastName);
                            uof.ui.incident.deputy.viewModel.WatchCommander.MiddleName(empData.MiddleName);
                            uof.ui.incident.deputy.viewModel.WatchCommander.Rank(empData.Rank);
                            uof.ui.incident.deputy.viewModel.WatchCommander.EmailId(empData.EmailAddress);
                            $("#btnDepSave").focus();
                        }
                        else {
                            uof.ui.incident.deputy.viewModel.SupervisorComplInvest.FirstName(empData.FirstName);
                            uof.ui.incident.deputy.viewModel.SupervisorComplInvest.LastName(empData.LastName);
                            uof.ui.incident.deputy.viewModel.SupervisorComplInvest.MiddleName(empData.MiddleName);
                            uof.ui.incident.deputy.viewModel.SupervisorComplInvest.Rank(empData.Rank);
                            uof.ui.incident.deputy.viewModel.SupervisorComplInvest.EmailId(empData.EmailAddress);

                        }

                        $.prototype.hideProgressBar("On_Duty " + IdOfControls);
                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                        $.prototype.hideProgressBar("On_Duty " + IdOfControls);
                        showAlert(errorThrown);
                    },
                });

            },
            saveDuputiesInfo: function () {
                if (uof.ui.incident.deputy.validateDeputiesInfo()) {
                    $.prototype.showUofOverlay();
                    var duptiesdata = ko.observableArray();
                    duptiesdata.push(ko.mapping.toJS(uof.ui.incident.deputy.viewModel.OnDupty));
                    duptiesdata.push(ko.mapping.toJS(uof.ui.incident.deputy.viewModel.SupervisorComplInvest));
                    duptiesdata.push(ko.mapping.toJS(uof.ui.incident.deputy.viewModel.WatchCommander));
                    var mappedData = ko.mapping.toJS(duptiesdata);
                    $.ajax(
                           {
                               url: window.location.uofAPIOrigin() + '/api/User/SaveDuputiesInfo',
                               cache: false,
                               type: "POST",
                               dataType: 'json',
                               data: JSON.stringify(mappedData),
                               contentType: "application/json;charset=utf-8",
                               beforeSend: function myfunction() {

                               },
                               success: function (empData) {
                                   $.prototype.hideUofOverlay();
                                   uof.ui.incident.deputy.viewModel.OnDupty.Mode = ko.observable("Edit");
                                   uof.ui.incident.deputy.viewModel.SupervisorComplInvest.Mode = ko.observable("Edit");
                                   uof.ui.incident.deputy.viewModel.WatchCommander.Mode = ko.observable("Edit");
                                   showAlert(empData);
                               },
                               error: function (e) {
                                   $.prototype.hideUofOverlay();
                                   showAlert(e.responseText);
                               },
                           });
                }
            },
            saveDuputiesInformation: function () {
                if (uof.ui.incident.deputy.validateDeputiesInfoFields()) {
                    uof.ui.incident.deputy.saveDuputiesInfo();
                }
            },

            incidentDuptiesInfo: function () {
                $.prototype.showUofOverlay();
                $.ajax(
                {
                    url: window.location.uofAPIOrigin() + '/api/User/GetincidentDupties',
                    cache: false,
                    data: 'incidentId=' + String(uof.ui.incident.detail.selectedContext.selectedIncident()),
                    type: "GET",
                    dataType: 'json',
                    contentType: "application/json;charset=utf-8",
                    success: function (DuptiesData) {
                        $.prototype.hideUofOverlay();
                        if (DuptiesData.length > 0) {

                            for (var i = 0; i < DuptiesData.length; i++) {
                                if (DuptiesData[i] == null) break;
                                uof.ui.incident.deputy.viewModel.OnDupty.Mode = 'Edit';
                                uof.ui.incident.deputy.viewModel.SupervisorComplInvest.Mode = 'Edit';
                                uof.ui.incident.deputy.viewModel.WatchCommander.Mode = 'Edit';
                                if (DuptiesData[i].UserTypeId == 8)
                                    uof.ui.incident.deputy.viewModel.OnDupty = ko.mapping.fromJS(DuptiesData[i], ko.mapping.toJS(uof.ui.incident.deputy.viewModel.OnDupty));
                                else if (DuptiesData[i].UserTypeId == 9)
                                    uof.ui.incident.deputy.viewModel.SupervisorComplInvest = ko.mapping.fromJS(DuptiesData[i], ko.mapping.toJS(uof.ui.incident.deputy.viewModel.SupervisorComplInvest));
                                else if (DuptiesData[i].UserTypeId == 5)
                                    uof.ui.incident.deputy.viewModel.WatchCommander = ko.mapping.fromJS(DuptiesData[i], ko.mapping.toJS(uof.ui.incident.deputy.viewModel.WatchCommander));
                            }
                        }

                        uof.ui.incident.detail.viewModel.hasError = ko.observable(false);
                        //uof.ui.incident.deputy.validateControls();
                        // uof.ui.incident.deputy.subscribeMethod();
                        $.prototype.hideUofOverlay();
                        ko.cleanNode($("#On_Duty").get(0));
                        ko.applyBindings(uof.ui.incident.deputy.viewModel, $("#On_Duty").get(0));
                    },
                    error: function (e) {
                        $.prototype.hideUofOverlay();
                        showAlert("Error");
                    },
                });
            },
        }
    }();
}