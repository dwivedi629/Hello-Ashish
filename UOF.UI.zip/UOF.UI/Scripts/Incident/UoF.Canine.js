﻿var uof = uof || {};
uof.ui = uof.ui || {};
uof.ui.incident = uof.ui.incident || {};
if (uof.ui.incident) {
    uof.ui.Canine = function () {
        return {
            parameters: null,
            isChanged: false,
            init: function (args) {
                this.parameters = args;
            },


            viewModel: {
                // To add different location, just add the one more item in this list

                canine: {
                    IncidentCanineDeploymentId: ko.observable(),
                    Mode: ko.observable("Add"),
                    IncidentId: ko.observable(),
                    LoggedId: ko.observable(UoFParams.userId),
                    //PrimaryHandlerType: ko.observable(),
                    //PrimaryHandlerId: ko.observable(),
                    //PrimaryHandlerNumber: ko.observable(),
                    //PrimaryHandlerName: ko.observable(),
                    //PrimaryHandlerCanine: ko.observable(),
                    //PrimaryHandlerUnit: ko.observable(),
                    //AssistHandlerId: ko.observable(),
                    //AssistHandlerType: ko.observable(),
                    //AssistHandlerNumber: ko.observable(),
                    //AssistHandlerName: ko.observable(),
                    //AssistHandlerCanine: ko.observable(),
                    //AssistHandlerUnit: ko.observable(),
                    //AssistHandlerId_One: ko.observable(),
                    //AssistHandlerType_One: ko.observable(),
                    //AssistHandlerNumber_One: ko.observable(),
                    //AssistHandlerName_One: ko.observable(),
                    //AssistHandlerCanine_One: ko.observable(),
                    //AssistHandlerUnit_One: ko.observable(),
                    AnnouncementWereMade: ko.observable(),
                    Area: ko.observable(),
                    Building: ko.observable(),
                    TOSOther: ko.observable(),
                    ApprehendingSuspect: ko.observable(),
                    ConductingSearch: ko.observable(),
                    ProtectingHandler: ko.observable(),
                    BOWOtherReason: ko.observable(),
                    Bite: ko.observable(),
                    TOIOther: ko.observable(),
                    BYAeroUnit: ko.observable(),
                    ByRadioCar: ko.observable(),
                    English: ko.observable(),
                    Spanish: ko.observable(),
                    Recorded: ko.observable(),
                    AnnouncementsNoneReason: ko.observable(),
                    AnnouncementsReason: ko.observable(),
                    AnnouncementMadeby: ko.observable(),
                    AnnouncementMadebyReason: ko.observable(),
                    CriminalHistory: ko.observable(),
                    Notifications: ko.observable(),
                    Handlers: ko.observableArray([])
                },
                getEmployeeDetails: function (empId, targetDiv) { uof.ui.Canine.getEmployeeDetails(empId, targetDiv); },
            },
            getEmployeeDetails: function (empId, targetDiv) {
                if ((empId != undefined) && (empId.length > 0)) {
                    // Search based on emp id
                    $.prototype.showProgressBar(targetDiv);
                    jQuery.ajax({
                        type: "GET",
                        url: EmployeeAPIUrl() + empId,
                        dataType: "json",
                        cache: false,
                        crossDomain: true,
                        processData: true,
                        success: function (empData) {

                            var dataSID = _.find(uof.ui.Canine.viewModel.canine.Handlers(), function (item) {
                                if (item.HandlerNumber() == empId)
                                    return item;
                            });
                            _.each(uof.ui.Canine.viewModel.canine.Handlers(), function (data) {
                                if (data.HandlerNumber() == dataSID.HandlerNumber())
                                    data.HandlerName(empData.FirstName + " " + empData.LastName + " " + empData.MiddleName);
                            });
                            $.prototype.hideProgressBar(targetDiv);
                        },
                        error: function (XMLHttpRequest, textStatus, errorThrown) {
                            showAlert("Error while getting the Employee Data");
                        }
                    });
                }
            },
            canineHandlers: function () {
                var self = this;
                self.HandlerNumber = ko.observable().extend({});
                self.HandlerName = ko.observable().extend({});
                self.CanineNumber = ko.observable().extend({});
                self.UnitNumber = ko.observable().extend({});
            },
            //load method, will be tirggered on document load
            load: function () {
                uof.ui.incident.detail.viewModel.incident.currentMode(localStorage.getItem('mode'));
                if (uof.ui.incident.detail.selectedContext.selectedIncident() > 0) {
                    uof.ui.Canine.viewModel.canine.IncidentId(uof.ui.incident.detail.selectedContext.selectedIncident());
                    uof.ui.Canine.viewModel.canine.Mode = ko.observable("Add");
                    uof.ui.Canine.incidentCanineInfo();
                }
                else {
                    //uof.ui.Canine.validateControls();

                    if (uof.ui.Canine.viewModel.canine.Handlers().length == 0) {
                        uof.ui.Canine.viewModel.canine.Handlers.push(new uof.ui.Canine.canineHandlers());
                        uof.ui.Canine.viewModel.canine.Handlers.push(new uof.ui.Canine.canineHandlers());
                        uof.ui.Canine.viewModel.canine.Handlers.push(new uof.ui.Canine.canineHandlers());
                    }
                }
                //binding Canine popup page
                ko.cleanNode($("#CanineDeployment").get(0));
                if ((uof.ui.incident.detail.viewModel.incident.currentMode() == 'edit')) {
                    uof.ui.Canine.SetFormControls(false);
                }
                if ((uof.ui.incident.detail.viewModel.incident.currentMode() == 'view')) {
                    uof.ui.Canine.SetFormControls(true);
                }
                
                //ko.applyBindings(uof.ui.HandlerRules.viewModel, $("#CanineDeployment").get(0));
              
            },
            SetFormControls: function (isDisable) {
                $("#CanineDeployment").find('input, select, textarea, button').each(function () {
                    $(this).attr('disabled', isDisable);
                    $('#dvCanineDeployment').prop('', isDisable);                    
                });
                $("#CanineDeployment").prop('disabled', isDisable);
                $("#HandlerNo").prop('disabled', isDisable);
            },
            //Cancel Data,on cancel button click
            cancelData: function () {
                for (var obj in uof.ui.Canine.viewModel) {
                    for (var prop in uof.ui.Canine.viewModel[obj]) {
                        if (uof.ui.Canine.viewModel[obj].hasOwnProperty(prop) && ko.isObservable(uof.ui.Canine.viewModel[obj][prop])) {
                            if (prop != "Handlers")
                            uof.ui.Canine.viewModel[obj][prop](undefined);
                        }
                    }
                }
                _.each(uof.ui.Canine.viewModel.canine.Handlers(), function (item) {
                    _.each(item, function (subItem) {
                        if (ko.isObservable(subItem)) {
                            subItem(undefined);
                        }
                    });
                });
                result = ko.validation.group(uof.ui.Canine.viewModel, { deep: true });
                result.showAllMessages(false);
                uof.ui.Canine.load();
            },
            submitfocus: function () {
                setTimeout(function () { $("#btnCanSave").focus(); }, 100);
            },
            saveCanineDetailsInfo: function () {
                //TODO: No validation required for Canine
                //if (uof.ui.Canine.validateCanineFields()) {
                uof.ui.Canine.saveCanineDetails();
                //}
            },
            buildCanineModel: function (CanineModel) {
                var handler = [{ HandlerNumber: CanineModel.PrimaryHandlerNumber, HandlerName: CanineModel.PrimaryHandlerName, HandlerType: "P", CanineNumber: CanineModel.PrimaryHandlerCanine, UnitNumber: CanineModel.PrimaryHandlerUnit },
                                             { HandlerNumber: CanineModel.AssistHandlerNumber, HandlerName: CanineModel.AssistHandlerName, HandlerType: "A1", CanineNumber: CanineModel.AssistHandlerCanine, UnitNumber: CanineModel.AssistHandlerUnit },
                                             { HandlerNumber: CanineModel.AssistHandlerNumber_One, HandlerName: CanineModel.AssistHandlerName_One, HandlerType: "A2", CanineNumber: CanineModel.AssistHandlerCanine_One, UnitNumber: CanineModel.AssistHandlerUnit_One },
                ];
                var oCanineData = new Object();
                oCanineData.Mode = CanineModel.Mode;
                oCanineData.IncidentCanineDeploymentId = CanineModel.IncidentCanineDeploymentId;
                oCanineData.IncidentId = uof.ui.incident.detail.selectedContext.selectedIncident();
                oCanineData.Area = CanineModel.Area ? "Y" : "N";
                oCanineData.Building = CanineModel.Building ? "Y" : "N";
                oCanineData.TOSOther = CanineModel.TOSOther ? "Y" : "N";
                oCanineData.ApprehendingSuspect = CanineModel.ApprehendingSuspect ? "Y" : "N";
                oCanineData.ConductingSearch = CanineModel.ConductingSearch ? "Y" : "N";
                oCanineData.ProtectingHandler = CanineModel.ProtectingHandler ? "Y" : "N";
                oCanineData.BOWOtherReason = CanineModel.BOWOtherReason ? "Y" : "N";
                oCanineData.Bite = CanineModel.Bite ? "Y" : "N";
                oCanineData.TOIOther = CanineModel.TOIOther ? "Y" : "N";
                oCanineData.BYAeroUnit = CanineModel.BYAeroUnit ? "Y" : "N";
                oCanineData.ByRadioCar = CanineModel.ByRadioCar ? "Y" : "N";
                oCanineData.English = CanineModel.English ? "Y" : "N";
                oCanineData.Spanish = CanineModel.Spanish ? "Y" : "N";
                oCanineData.Recorded = CanineModel.Recorded ? "Y" : "N";
                oCanineData.AnnouncementsNoneReason = CanineModel.AnnouncementsNoneReason;
                oCanineData.AnnouncementMadeby = CanineModel.AnnouncementMadeby ? "Y" : "N";
                oCanineData.AnnouncementMadebyReason = CanineModel.AnnouncementMadebyReason
                oCanineData.CriminalHistory = CanineModel.CriminalHistory;
                oCanineData.Notifications = CanineModel.Notifications;
                oCanineData.LoggedId = UoFParams.userId;
                oCanineData.Handlers = handler;
                return oCanineData;
            },

            saveCanineDetails: function () {
                //setting criteria
                $.prototype.showUofOverlay();
                //TODO: Assign data for handler before sending to controller
                //var oCanineData = uof.ui.Canine.buildCanineModel(uof.ui.Canine.viewModel.canine);
                var mappedData = ko.mapping.toJS(uof.ui.Canine.viewModel.canine);
                mappedData.LoggedId = UoFParams.userId;
                $.ajax(
                       {
                           url: window.location.uofAPIOrigin() + '/api/User/SaveCanine',
                           cache: false,
                           type: "POST",
                           dataType: 'json',
                           data: JSON.stringify(mappedData),
                           contentType: "application/json;charset=utf-8",
                           beforeSend: function myfunction() {

                           },
                           success: function (empData) {
                               $.prototype.hideUofOverlay();
                               showAlert(empData);

                           },
                           error: function (e) {
                               $.prototype.hideUofOverlay();
                               showAlert(e.responseText);
                           },
                       });
            },

            //Validate the controls on Add and duplicate popup
            //validateControls: function () {

            //    uof.ui.Canine.viewModel.canine.PrimaryHandlerNumber.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });
            //    uof.ui.Canine.viewModel.canine.PrimaryHandlerName.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });
            //    uof.ui.Canine.viewModel.canine.PrimaryHandlerCanine.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });
            //    uof.ui.Canine.viewModel.canine.PrimaryHandlerUnit.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });
            //    uof.ui.Canine.viewModel.canine.AssistHandlerNumber.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });
            //    uof.ui.Canine.viewModel.canine.AssistHandlerName.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });
            //    uof.ui.Canine.viewModel.canine.AssistHandlerCanine.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });
            //    uof.ui.Canine.viewModel.canine.AssistHandlerUnit.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });
            //    uof.ui.Canine.viewModel.canine.AssistHandlerNumber_One.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });
            //    uof.ui.Canine.viewModel.canine.AssistHandlerName_One.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });
            //    uof.ui.Canine.viewModel.canine.AssistHandlerCanine_One.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });
            //    uof.ui.Canine.viewModel.canine.AssistHandlerUnit_One.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });

            //    uof.ui.Canine.viewModel.canine.Area.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });
            //    uof.ui.Canine.viewModel.canine.TOSOther.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });
            //    uof.ui.Canine.viewModel.canine.Building.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });
            //    uof.ui.Canine.viewModel.canine.ApprehendingSuspect.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });
            //    uof.ui.Canine.viewModel.canine.ConductingSearch.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });
            //    uof.ui.Canine.viewModel.canine.ProtectingHandler.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });
            //    uof.ui.Canine.viewModel.canine.BOWOtherReason.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });
            //    uof.ui.Canine.viewModel.canine.Bite.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });
            //    uof.ui.Canine.viewModel.canine.TOIOther.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });
            //    uof.ui.Canine.viewModel.canine.AnnouncementMadeby.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });
            //    uof.ui.Canine.viewModel.canine.BYAeroUnit.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });
            //    uof.ui.Canine.viewModel.canine.ByRadioCar.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });
            //    uof.ui.Canine.viewModel.canine.English.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });
            //    uof.ui.Canine.viewModel.canine.Spanish.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });
            //    uof.ui.Canine.viewModel.canine.Recorded.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });
            //    uof.ui.Canine.viewModel.canine.AnnouncementsNoneReason.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });
            //    uof.ui.Canine.viewModel.canine.AnnouncementMadeby.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });
            //    uof.ui.Canine.viewModel.canine.CriminalHistory.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });
            //    uof.ui.Canine.viewModel.canine.Notifications.extend({
            //        required: {
            //            params: true,
            //            message: IncidentConstants.Required
            //        },
            //    });
            //},

            validateCanineFields: function () {
                var result = ko.validation.group(uof.ui.Canine.viewModel.canine, { deep: true });
                if (result().length > 0) {
                    //To show the message

                    uof.ui.Canine.viewModel.canine.PrimaryHandlerNumber.valueHasMutated();
                    uof.ui.Canine.viewModel.canine.PrimaryHandlerName.valueHasMutated();
                    uof.ui.Canine.viewModel.canine.PrimaryHandlerCanine.valueHasMutated();
                    uof.ui.Canine.viewModel.canine.PrimaryHandlerUnit.valueHasMutated();
                    uof.ui.Canine.viewModel.canine.AssistHandlerNumber.valueHasMutated();
                    uof.ui.Canine.viewModel.canine.AssistHandlerName.valueHasMutated();
                    uof.ui.Canine.viewModel.canine.AssistHandlerCanine.valueHasMutated();
                    uof.ui.Canine.viewModel.canine.AssistHandlerUnit.valueHasMutated();
                    uof.ui.Canine.viewModel.canine.AssistHandlerNumber_One.valueHasMutated();
                    uof.ui.Canine.viewModel.canine.AssistHandlerName_One.valueHasMutated();
                    uof.ui.Canine.viewModel.canine.AssistHandlerCanine_One.valueHasMutated();
                    uof.ui.Canine.viewModel.canine.AssistHandlerUnit_One.valueHasMutated();

                    uof.ui.Canine.viewModel.canine.TypeofSearch.valueHasMutated();
                    uof.ui.Canine.viewModel.canine.BiteOccuredWhile.valueHasMutated();
                    uof.ui.Canine.viewModel.canine.TypeofIncident.valueHasMutated();
                    uof.ui.Canine.viewModel.canine.AnnouncementsBy.valueHasMutated();
                    uof.ui.Canine.viewModel.canine.AnnouncementsIn.valueHasMutated();
                    uof.ui.Canine.viewModel.canine.AnnouncementsNoneReason.valueHasMutated();
                    uof.ui.Canine.viewModel.canine.AnnouncementMadeby.valueHasMutated();
                    uof.ui.Canine.viewModel.canine.CriminalHistory.valueHasMutated();
                    uof.ui.Canine.viewModel.canine.Notifications.valueHasMutated();
                    return false;
                }
                return true;
            },

            incidentCanineInfo: function () {
                $.prototype.showUofOverlay();
                $.ajax(
                {
                    url: window.location.uofAPIOrigin() + '/api/User/GetCanineData',
                    cache: false,
                    data: 'incidentId=' + String(uof.ui.incident.detail.selectedContext.selectedIncident()),
                    type: "GET",
                    dataType: 'json',
                    contentType: "application/json;charset=utf-8",
                    success: function (CanineData) {
                        $.prototype.hideUofOverlay();
                        if (CanineData != null) {
                           
                            uof.ui.Canine.viewModel.canine = ko.mapping.fromJS(CanineData, ko.mapping.toJS(uof.ui.Canine.viewModel.canine));
                            if (uof.ui.Canine.viewModel.canine.Handlers().length == 0) {
                                uof.ui.Canine.viewModel.canine.Handlers.push(new uof.ui.Canine.canineHandlers());
                                uof.ui.Canine.viewModel.canine.Handlers.push(new uof.ui.Canine.canineHandlers());
                                uof.ui.Canine.viewModel.canine.Handlers.push(new uof.ui.Canine.canineHandlers());
                            }
                            $.prototype.hideUofOverlay();
                            uof.ui.Canine.viewModel.hasError = ko.observable(false);
                            ko.cleanNode($("#CanineDeployment").get(0));
                            ko.applyBindings(uof.ui.Canine.viewModel, $("#CanineDeployment").get(0));
                            uof.ui.Canine.viewModel.canine.Mode('Edit');
                        }
                        if (uof.ui.Canine.viewModel.canine.Handlers().length == 0) {
                            uof.ui.Canine.viewModel.canine.Handlers.push(new uof.ui.Canine.canineHandlers());
                            uof.ui.Canine.viewModel.canine.Handlers.push(new uof.ui.Canine.canineHandlers());
                            uof.ui.Canine.viewModel.canine.Handlers.push(new uof.ui.Canine.canineHandlers());
                        }
                    },
                    error: function (e) {
                        $.prototype.hideUofOverlay();
                        showAlert("Error loading Data - Canine");
                    },
                });
            },

        }
    }();

}