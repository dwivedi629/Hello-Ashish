﻿var uof = uof || {};
uof.ui = uof.ui || {};
uof.ui.incident = uof.ui.incident || {};
if (uof.ui.incident) {
    uof.ui.EmployeeWitness = function () {
        return {
            parameters: null,
            isEmpWitnessDataChanged: false,
            init: function (args) {
                this.parameters = args;
            },
            empWitnessDataSource: null,
            empWitnessViewModel: {
                isWitnessEditmode: ko.observable(true),
                // To add different location, just add the one more item in this list
                empWitnessList:  ko.observableArray([]),
                Empwitness: {
                    Mode: ko.observable("Add"),
                    IncidentUserWitnessId: ko.observable(),
                    IncidentUserId: ko.observable(UoFParams.userId),
                    LoggedId: ko.observable(UoFParams.userId),
                    IncidentId: ko.observable(),
                    UserId: ko.observable(),
                    UserTypeId: ko.observable(3),
                    EmployeeId: ko.observable(),
                    LastName: ko.observable(),
                    FirstName: ko.observable(),
                    MiddleName: ko.observable(),
                    UnitOfAssignment: ko.observable(),
                    WorkAssignment: ko.observable(),
                    Shift: ko.observable(),
                    ShiftType: ko.observable(),
                    EmailId: ko.observable(),
                    WitnessIntAwayfromInmates: ko.observable(),
                    IsOnlySave: ko.observable(true),
                },
            },
            //load method, will be tirggered on document load
            empWitnessload: function () {
                if (uof.ui.incident.detail.selectedContext.selectedIncident() > 0) {
                    uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.IncidentId = uof.ui.incident.detail.selectedContext.selectedIncident();
                    uof.ui.EmployeeWitness.empWitnessValidateControls();
                    uof.ui.EmployeeWitness.getEmpWitnessData();
                }
                ko.validation.group(uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness).showAllMessages(false);
                //binding EmployeeWitness popup page
                ko.cleanNode($("#EmployeeWitnessInputs").get(0));
                ko.applyBindings(uof.ui.EmployeeWitness.empWitnessViewModel, $("#EmployeeWitnessInputs").get(0));



                uof.ui.incident.detail.viewModel.incident.currentMode(localStorage.getItem('mode'));
                // Set All Edit mode values here
                if ((uof.ui.incident.detail.viewModel.incident.currentMode() == 'Edit')) {
                    uof.ui.EmployeeWitness.empWitnessViewModel.isWitnessEditmode(true);
                    uof.ui.EmployeeWitness.SetFormControls(false);
                }
                else if ((uof.ui.incident.detail.viewModel.incident.currentMode() == 'view')) {
                    uof.ui.EmployeeWitness.empWitnessViewModel.isWitnessEditmode(false);
                    uof.ui.EmployeeWitness.SetFormControls(true);
                }

            },

            //Validate the controls on Add and duplicate popup
            empWitnessValidateControls: function () {
                //remove old validation
                $("#EmpWitness .validationMessage").each(function () {
                    $(this).remove();
                });

                //Validate the controls on Add and duplicate popup
                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.EmployeeId.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    }
                });
                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.Shift.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });
                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.ShiftType.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });
                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.UnitOfAssignment.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });
                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.WorkAssignment.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });
                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.WitnessIntAwayfromInmates.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });
            },

            //check the length of string
            lengthValidation: function (str, minChar) {
                var maxChar;
                if (uof.ui.EmployeeWitness.getCharCount(str) < minChar[0] ||
                    uof.ui.EmployeeWitness.getCharCount(str) > minChar[1])
                    return false;
                return true;
            },

            SetFormControls: function (isDisable) {
                $("#EmployeeWitnessInputs").find('input, select, textarea, button').each(function () {
                    $(this).attr('disabled', isDisable);
                });
            },

            //get character based on ascii value
            getCharCount: function (str) {
                var result = 0;
                if (str !== undefined) {
                    for (var n = 0; n < str.length; n++) {
                        var charCode = str.charCodeAt();
                        if (typeof charCode === "number") {
                            if (charCode < 128)
                            { result = result + 1; }
                            else if (charCode < 2048)
                            { result = result + 2; }
                            else if (charCode < 65536)
                            { result = result + 3; }
                            else if (charCode < 2097152)
                            { result = result + 4; }
                            else if (charCode < 67108864)
                            { result = result + 5; }
                            else
                            { result = result + 6; }
                        }
                    }
                }
                return result;
            },

            //check for special characters
            isSpecialChar: function (objValue) {
                var count = 0;
                var pattr = ["\\", ":", "/", "*", "?", ">", "<", "[", "]", "{", "}", "|", "'", "=", "+"];

                while (count < pattr.length) {
                    if (objValue.indexOf(pattr[count]) > -1) {
                        return false;
                    }
                    count++;
                }
            },
            submitfocus: function () {
                setTimeout(function () { $("#btnEWSave").focus(); }, 100);
            },
            // subscribe method
            empWitnessSubscribeMethod: function () {
                // Subscribing the name and code to get changes
                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.EmployeeId.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        uof.ui.EmployeeWitness.isEmpWitnessDataChanged = true;
                    }

                });

                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.Shift.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        uof.ui.EmployeeWitness.isEmpWitnessDataChanged = true;
                    }

                });
                //uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.RegularShift.subscribe(function (newValue) {
                //    if ($.trim(newValue) != "") {
                //        uof.ui.EmployeeWitness.isEmpWitnessDataChanged = true;
                //    }

                //});
                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.UnitOfAssignment.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        uof.ui.EmployeeWitness.isEmpWitnessDataChanged = true;
                    }

                });
                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.WorkAssignment.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        uof.ui.EmployeeWitness.isEmpWitnessDataChanged = true;
                    }

                });
                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.WitnessIntAwayfromInmates.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        uof.ui.EmployeeWitness.isEmpWitnessDataChanged = true;
                    }

                });

            },
            validateWitnessFields: function () {
               
                var result = ko.validation.group([uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.EmployeeId]);
                if (result().length > 0) {
                    uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.EmployeeId.valueHasMutated();
                    result.showAllMessages();
                    $("#Employee").focus();
                    return false;
                }
                return true;
            },
            validateWitnessEmployeeFields: function (model) {
                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness = {};
                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness = ko.mapping.fromJS(model, ko.mapping.toJS(uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee));
                uof.ui.EmployeeWitness.empWitnessValidateControls();
                var result = ko.validation.group(uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness, { deep: true });
                if (result().length > 0) {
                    uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.EmployeeId.valueHasMutated();
                    uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.UnitOfAssignment.valueHasMutated();
                    uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.WorkAssignment.valueHasMutated();
                    uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.WitnessIntAwayfromInmates.valueHasMutated();
                    result.showAllMessages();
                    $("#Employee").focus();
                    return false;
                }
                return true;
            },
            //
            listLoad: function () {
                $(".kendo-mini-pager").removeClass("k-pager-wrap");
                $(".kendo-mini-pager").removeClass("k-widget");
                $(".kendo-mini-pager").removeClass("k-floatwrap");
            },
            saveWitnessInfo: function (IsOnlySave) {
                if (uof.ui.EmployeeWitness.validateWitnessFields()) {
                    if (!uof.ui.CommonUILogic.detail.validateDuplicate(empWitnessDataSource._data, uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.EmployeeId(), 3, uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.Mode())) {
                        uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.IsOnlySave(IsOnlySave);
                        $.prototype.showUofOverlay();
                        if (UoFParams.IncidentId != "")
                            uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.IncidentId = UoFParams.IncidentId;
                        else
                            uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.IncidentId = uof.ui.incident.detail.selectedContext.selectedIncident()

                        var mappedData = ko.mapping.toJS(uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness);
                        mappedData.LoggedId = UoFParams.userId;
                        $.ajax(
                               {
                                   url: window.location.uofAPIOrigin() + '/api/User/SaveWitnessUser',
                                   cache: false,
                                   type: "POST",
                                   dataType: 'json',
                                   data: JSON.stringify(mappedData),
                                   contentType: "application/json;charset=utf-8",
                                   beforeSend: function myfunction() {

                                   },
                                   success: function (empData) {
                                       $.prototype.hideUofOverlay();
                                       //uof.ui.EmployeeWitness.fillWitnesslist(ko.mapping.toJS(ko.mapping.toJS(uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness)));
                                       uof.ui.EmployeeWitness.getEmpWitnessData();
                                       showAlert(empData);
                                       uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.Mode("Add");
                                       uof.ui.EmployeeWitness.cancelWitnessData();
                                   },
                                   error: function (e) {
                                       $.prototype.hideUofOverlay();
                                       showAlert("Error loading Data - Employee Witness");
                                   },
                               });
                    }
                    else
                        showAlert("Duplicate Witness");
                }
            },
            saveWitnessDetails: function () {
                if (uof.ui.EmployeeWitness.validateWitnessEmployeeFields()) {
                    uof.ui.EmployeeWitness.saveWitnessInfo(false);
                }
            },

            fillWitnesslist: function (EmployeeWitness) {
                uof.ui.EmployeeWitness.empWitnessViewModel.empWitnessList.push({
                    EmployeeID: EmployeeWitness.EmployeeId,
                    Name: EmployeeWitness.LastName + ' ' + EmployeeWitness.FirstName + ' ' + EmployeeWitness.Middle,
                    UnitofAssignment: EmployeeWitness.UnitofAssignment,
                    WorkAssignment: EmployeeWitness.WorkAssignment,
                    Type: "Employee",
                });
            },

            bindWitnessList: function () {
                var sortState = '';
                var InvolvedList = ko.mapping.toJS(uof.ui.EmployeeWitness.empWitnessViewModel.empWitnessList);
                var dataTb = [];
                $.grep(InvolvedList, function (i) {
                    dataTb.push({ EmployeeID: i.EmployeeID, Name: i.Name, UnitofAssignment: i.UnitofAssignment, WitnessType: i.Type });
                });
                var datasourcetbu = new kendo.data.DataSource({
                    data: dataTb,
                    pageSize: 10,
                    change: function (e) {
                        var newState = JSON.stringify(this.sort());
                        if (newState != sortState) {
                            sortState = newState;
                            e.preventDefault();
                            this.page(1);
                        }

                    }
                });
                var cntrl = $("#WitnessList");
                var grid = cntrl.kendoGrid({
                    dataSource: datasourcetbu,
                    selectable: false,
                    scrollable: true,
                    sortable: { allowUnsort: false },
                    height: "200",
                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [10, 20, 50],
                        buttonCount: 5,
                        messages: {
                            itemsPerPage: "users per page"
                        }
                    },
                    columns:
                            [
                                 {
                                     field: "EmployeeID",
                                     headerTemplate: kendo.format('<span  class="word-break-txt" title="{0}" >{1}</span>', "Employee Id", "Employee Id"),
                                     // template: $("#viewWitnessEmployee").html(),
                                     width: 50
                                 },
                                {
                                    field: "Name",
                                    headerTemplate: kendo.format('<span  class="word-break-txt">{0}</span>', "Name"),
                                    width: 100
                                },
                                 {
                                     field: "UnitofAssignment",
                                     headerTemplate: kendo.format('<span  class="word-break-txt">{0}</span>', "Unit of Work"),
                                     width: 150
                                 },
								 {
								     field: "WitnessType",
								     headerTemplate: kendo.format('<span  class="word-break-txt">{0}</span>', "EmployeeWitness Type"),
								     width: 50
								 }
                            ],
                    change: function (e) {
                    }
                }).data().kendoGrid;
                grid.refresh();
                $.prototype.hideUofOverlay();
                //var $template = kendo.template($("#name-tooltip-template").html());
                var tooltip = $("#WitnessList").kendoTooltip({
                    filter: "td:nth-child(2)", //this filter selects the first column cells                   
                    content: function (e) {
                        var dataItem = $("#WitnessList").data("kendoGrid").dataItem(e.target.closest("tr"));
                        return $template(dataItem);
                    },

                }).data("kendoTooltip");
                $("#WitnessList").kendoTooltip({
                    filter: ".cellTooltip",
                });
            },

            getEmployeeDetails: function (validateDuplicate) {

                var selectedEmpId = uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.EmployeeId();
                if ((selectedEmpId == undefined) || ((selectedEmpId != undefined) && (selectedEmpId.length <= 0))) {
                    uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.FirstName("");
                    uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.LastName("");
                    uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.MiddleName("");
                }
                else {
                    var isDuplicate = false;
                    if (validateDuplicate)
                        isDuplicate = uof.ui.CommonUILogic.detail.validateDuplicate(empWitnessDataSource._data, uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.EmployeeId(), 3, uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.Mode());
                    if (!isDuplicate) {
                        // Search based on emp id
                        $.prototype.showProgressBar("EmpWitness #Employee");
                        jQuery.ajax({
                            type: "GET",
                            url: InvolvedEmployeeAPIUrl() + selectedEmpId + "&eventDate=" + uof.ui.EmployeeWitness.formatLocalDate() + "",
                            dataType: "json",
                            cache: false,
                            crossDomain: true,
                            processData: true,
                            success: function (empData) {
                                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.FirstName(empData.FirstName);
                                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.LastName(empData.LastName);
                                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.MiddleName(empData.MiddleName);

                                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.UnitOfAssignment(empData.UnitOfAssignment);
                                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.WorkAssignment(empData.WorkAssignment);

                                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.EmailId(empData.EmailAddress);

                                if (empData.Shift != null) {
                                    uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.Shift("");
                                    uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.Shift(empData.Shift.toUpperCase());
                                }

                                if (empData.ShiftType != null) {
                                    uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.ShiftType("");
                                    switch (empData.ShiftType.toUpperCase()) {
                                        case "OFFDUTY":
                                        case "OFF":
                                            uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.ShiftType("OFF");
                                            break;
                                        case "OVERTIME":
                                        case "OT":
                                            uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.ShiftType("OT");
                                            break;
                                        case "REGULAR":
                                            uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.ShiftType("RS");
                                            break;
                                    }
                                }
                                $.prototype.hideProgressBar("EmpWitness #Employee");
                            },
                            error: function (XMLHttpRequest, textStatus, errorThrown) {
                                $.prototype.showProgressBar("EmpWitness #Employee");
                                showAlert(errorThrown);
                            },
                        });

                    }
                    else
                        showAlert("Employee Witness already Exists");
                }
            },
            formatLocalDate: function () {
                var now = new Date(),
                    tzo = -now.getTimezoneOffset(),
                    dif = tzo >= 0 ? '+' : '-',
                    pad = function (num) {
                        var norm = Math.abs(Math.floor(num));
                        return (norm < 10 ? '0' : '') + norm;
                    };
                return now.getFullYear()
                    + '-' + pad(now.getMonth() + 1)
                    + '-' + pad(now.getDate())
                    + 'T' + pad(now.getHours())
                    + ':' + pad(now.getMinutes())
                    + ':' + pad(now.getSeconds())
                    + dif + pad(tzo / 60)
                    + ':' + pad(tzo % 60);
            },
            //Grid Binding 
            getEmpWitnessData: function () {
                // Ajax call to server to get Organziation records
                $.prototype.showUofOverlay();
                var dlAjaxOption =
                    {
                        url: window.location.uofAPIOrigin() + '/api/User/GetWitnessUser',
                        cache: false,
                        type: "GET",
                        data: "incidentId=" + uof.ui.incident.detail.selectedContext.selectedIncident() + "&witnessType=3",
                        dataType: 'json',
                        contentType: "application/json;charset=utf-8",
                        success: function (witnessEmpl) {
                            uof.ui.EmployeeWitness.empWitnessViewModel.empWitnessList = ko.observableArray(witnessEmpl);
                            empWitnessDataSource = new kendo.data.DataSource({
                                data: witnessEmpl,
                                pageSize: 20
                            });


                            //setting all Org Data to kendo
                            $("#WitnessList").kendoGrid({
                                dataSource: empWitnessDataSource,
                                height: 240,
                                scrollable: true,
                                sortable: true,
                                filterable: false,
                                pageable: {
                                    refresh: false,
                                    pageSizes: true,
                                    pageSizes: [20, 50, 100],
                                    buttonCount: 5,
                                    messages: {
                                    },
                                },
                                columns: [
                                {
                                    field: "EmployeeId",
                                    headerTemplate: kendo.format('<span  class="word-break-txt" title="{0}" >{1}</span>', "Employee Id", "Employee Id"),
                                    //  template: $("#viewWitnessEmployee").html(),
                                    width: 150
                                },
                                 {
                                     field: "Name",
                                     headerTemplate: kendo.format('<span  class="word-break-txt" title="{0}" >{1}</span>', "Name", "Name"),
                                     width: 150
                                 },
                                 {
                                     field: "IncidentUserWitnessId",
                                     template: $("#editWitnessEmpDetails").html(),
                                     headerTemplate: '',
                                     width: 30,
                                 },
                                {
                                    field: "IncidentUserWitnessId",
                                    template: $("#deleteWitnessEmpDetails").html(),
                                    headerTemplate: '',
                                    width: 30,
                                    hidden: !uof.ui.EmployeeWitness.empWitnessViewModel.isWitnessEditmode()
                                }



                                ],
                                //  dataBound: athoc.iws.organizationManager.OnDataBound,
                                change: function (e) {
                                    var model = this.dataItem(this.select());
                                }
                            }).data().kendoGrid;
                            empWitnessDataSource.read();
                            $.prototype.hideUofOverlay();
                            uof.ui.EmployeeWitness.setKendoGridHeight();
                            if (!uof.ui.EmployeeWitness.empWitnessViewModel.isWitnessEditmode()) {
                                $("#WitnessList").find('button').html('View');
                            }
                        },
                        error: function (e) {
                            $.prototype.hideUofOverlay();
                            showAlert(e.responseText);
                        }

                    };
                // Call ajax
                var ajaxOptions = $.extend({}, 'GET', dlAjaxOption);
                $.ajax(ajaxOptions);

            },

            setKendoGridHeight: function () {
                $('.k-grid-content').attr('style', 'height:70%');
            },
            cancelWitnessData: function () {
                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.Mode("Add");
                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.IncidentId = ko.observable(0);
                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.UserTypeId = ko.observable(3);
                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.EmployeeId(null);
                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.LastName(null);
                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.FirstName(null);
                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.MiddleName(null);
                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.UnitOfAssignment(null);
                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.WorkAssignment(null);
                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.Shift(null);
                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.ShiftType(null);
                uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.WitnessIntAwayfromInmates(null);
                result = ko.validation.group(uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness, { deep: true });

                result.showAllMessages(false);
            },


            cancelWitnessView: function () {

                uof.ui.EmployeeWitness.empWitnessViewModel.isWitnessEditmode(true); return true;
            },

            viewWitnessEmployee: function (incidentUserWitnessId) {
                var selectedData = _.find(empWitnessDataSource.data(), function (item) {
                    return item.IncidentUserWitnessId == incidentUserWitnessId;
                });

                if (selectedData != null) {
                    uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness = {};
                    uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness = ko.mapping.fromJS(selectedData, ko.mapping.toJS(uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness));
                    uof.ui.EmployeeWitness.empWitnessViewModel.isWitnessEditmode(false);
                }
            },

            editWitnessEmpDetails: function (incidentUserWitnessId) {
                var selectedData = _.find(empWitnessDataSource.data(), function (item) {
                    return item.IncidentUserWitnessId == incidentUserWitnessId;
                });

                if (selectedData != null) {
                    uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness = {};
                    uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness = ko.mapping.fromJS(selectedData, ko.mapping.toJS(uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness));
                    uof.ui.EmployeeWitness.empWitnessValidateControls();
                    ko.cleanNode($("#EmployeeWitnessInputs").get(0));
                    ko.applyBindings(uof.ui.EmployeeWitness.empWitnessViewModel, $("#EmployeeWitnessInputs").get(0));
                    uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.Mode("Edit");
                    if (uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.UnitOfAssignment() == null && uof.ui.EmployeeWitness.empWitnessViewModel.Empwitness.WorkAssignment() == null) {
                        uof.ui.EmployeeWitness.getEmployeeDetails(false)
                    }

                }
            },

            deleteWitnessEmpDetails: function (incidentUserWitnessId) {
                var selectedData = _.find(empWitnessDataSource.data(), function (item) {
                    return item.IncidentUserWitnessId == incidentUserWitnessId;
                });

                $.prototype.showUofOverlay();
                $.ajax(
               {
                   url: window.location.uofAPIOrigin() + '/api/User/DeleteUser?incidentId=' + selectedData.IncidentId + '&userId=' + incidentUserWitnessId + '&employeeNumber=' + selectedData.BookingNumber + '&userType=3',
                   cache: false,
                   type: "DELETE",
                   dataType: 'json',
                   contentType: "application/json;charset=utf-8",
                   beforeSend: function myfunction() {

                   },
                   success: function (data) {
                       showAlert(data);
                       uof.ui.EmployeeWitness.getEmpWitnessData();
                       $.prototype.hideUofOverlay();
                   },
                   error: function (e) {
                       $.prototype.hideUofOverlay();
                       showAlert(e.responseText);
                   },
               });

            },
        }
    }();

}