﻿var uof = uof || {};
uof.ui = uof.ui || {};
uof.ui.incident = uof.ui.incident || {};
if (uof.ui.incident) {
    uof.ui.InvolvedEmployee = function () {
        return {
            parameters: null,
            isChanged: false,
            init: function (args) {
                this.parameters = args;
            },
            picklistObject: function (Code, Name) {
                this.Code = Code;
                this.Name = Name;
                return this;
            },
            empDataSource: null,
            RaceSource: null,
            SeveritiesSource: null,
            ForceSources: null,
            EnableValidation: false,
            changeLog: [],
            // TimeOutInterval: 10000,
            //InvolvedEmpTimeout: null,
            viewModel: {
                tempDatatoSave: ko.observableArray([]),
                Gender: ko.observableArray([]),
                Race: ko.observableArray([]),
                Dress: ko.observableArray([]),
                InjurySeverities: ko.observableArray([]),
                TypeOfForces: ko.observableArray([]),
                TypeofForceSelected: ko.observableArray([]),
                Sergeants: ko.observableArray([]),
                isEditmode: ko.observable(true),
                // To add different location, just add the one more item in this list
                Locations: [
                                { LocationName: 'Knife', LocationCode: 'KN' },
                                { LocationName: 'Blade or Stabing agent', LocationCode: 'BS' },
                                { LocationName: 'K-9 contact', LocationCode: 'K9' }
                ],

                InvolvedEmployeeList: ko.observableArray([]),
                InvolvedEmployee: {
                    IsOnlySave: ko.observable(true),
                    Mode: ko.observable("Add"),
                    IncidentId: ko.observable(),
                    EmployeeId: ko.observable(),
                    UserRole: ko.observable(),
                    LoggedId: ko.observable(),
                    ReviewerId: ko.observable(),
                    EmailId: ko.observable(),
                    LastName: ko.observable(),
                    FirstName: ko.observable(),
                    MiddleName: ko.observable(),
                    Rank: ko.observable(),
                    Sex: ko.observable(),
                    SelectedDress: ko.observable(),
                    Race: ko.observableArray([]),
                    Height: ko.observable(),
                    Weight: ko.observable(),
                    Age: ko.observable(),
                    Shift: ko.observable(),
                    //EM,DAY.PM
                    ShiftType: ko.observable(),
                    //OT Shift,Off Duty
                    UnitOfAssignment: ko.observable(),
                    WorkAssignment: ko.observable(),
                    //IndForceUsed: ko.observable(),
                    IsDirected: ko.observable(false),

                    DirectedEmpId: ko.observable(),
                    DirectedLastName: ko.observable(),
                    DirectedFirstName: ko.observable(),
                    DirectedRank: ko.observable(),
                    DirectedEmailId: ko.observable(),

                    IsRescue: ko.observable(false),
                    IsMedicalAssist: ko.observable(false),
                    IndividualCatId: ko.observable(),
                    ITA: ko.observable(),
                    RM: ko.observable(),
                    IsInjured: ko.observable(false),
                    IsTreated: ko.observable(false),
                    IsAdmitted: ko.observable(false),
                    Facility: ko.observable(""),
                    CoronerCaseId: ko.observable(""),
                    //Isdirected: ko.observable(""),
                    EmployeeNumber: ko.observable(""),
                    //LastName: ko.observable(""),
                    //FirstName: ko.observable(""),
                    //MiddleName: ko.observable(""),
                    EmployeeItemNumber: ko.observable(""),
                    DateOfBirth: ko.observable(),
                    DepartmentHireDate: ko.observable(),
                    LastPromotionDate: ko.observable(),
                    DepartmentTenureInDays: ko.observable(),
                    RankTenureIndays: ko.observable(),
                    IsEmployeeEscortSuspect: ko.observable(),


                    InjurySeverity: ko.observable(),
                    Isforecasting: ko.observable(""),

                    TypeOfForce: ko.observableArray([]),
                    DVert: ko.observable(false),
                    InvolType: ko.observable(""),
                    isDirty: ko.observable(),//~M

                },
                //Directed: {
                //    DirectedEmployeeNumber: ko.observable(),
                //    DirectedLastName: ko.observable(),
                //    DirectedFirstName: ko.observable(),
                //    DirectedRank: ko.observable(),
                //    DirectedEmailId: ko.observable(),
                //},
                getEmployeeDetails: function () { uof.ui.InvolvedEmployee.getEmployeeDetails(); }
            },
            //load method, will be tirggered on document load
            load: function () {
                uof.ui.InvolvedEmployee.validateControls();
                if (uof.ui.incident.detail.selectedContext.selectedIncident() > 0) {
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IncidentId = uof.ui.incident.detail.selectedContext.selectedIncident();
                    uof.ui.InvolvedEmployee.getInvolvedEmpInfo();

                }

                //binding InvolvedEmployee popup page
                ko.cleanNode($("#InvolvedEmpControls").get(0));
                ko.applyBindings(uof.ui.InvolvedEmployee.viewModel, $("#InvolvedEmpControls").get(0));

                //~M
                uof.ui.InvolvedEmployee.trackViewModel(uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee);

                // ko.cleanNode($("#InvolvedEmpView").get(0));
                // ko.applyBindings(uof.ui.InvolvedEmployee.viewModel, $("#InvolvedEmpView").get(0));

                //ko.cleanNode($("#divDirected").get(0));
                //ko.applyBindings(uof.ui.InvolvedEmployee.viewModel, $("#divDirected").get(0));


                // Set All Edit mode values here
                if ((uof.ui.incident.detail.viewModel.incident.currentMode() == 'Edit')) {
                    uof.ui.InvolvedEmployee.viewModel.isEditmode(true);
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Mode('Add');
                    uof.ui.InvolvedEmployee.SetFormControls(false);
                    $("#DeputyinjurySeverity").prop('disabled', false);
                }
                else if ((uof.ui.incident.detail.viewModel.incident.currentMode() == 'view')) {
                    uof.ui.InvolvedEmployee.viewModel.isEditmode(false);
                    uof.ui.InvolvedEmployee.SetFormControls(true);
                }


                uof.ui.InvolvedEmployee.listLoad();
                uof.ui.InvolvedEmployee.bindControlEvents();
                uof.ui.InvolvedEmployee.initiatePickers();
                uof.ui.InvolvedEmployee.subscribeMethod();
                //Based on the incident Category Individual  Category control will enabled/disbaled
                if (UoFParams.IncidentCategory == 1) {
                    $("#IC2").attr('disabled', true);
                    $("#IC3").attr('disabled', true);
                }
                else if (UoFParams.IncidentCategory == 2) {
                    $("#IC3").attr("disabled", true);
                }
                else if (UoFParams.IncidentCategory == 3) {
                    $("#IC1").attr("disabled", true);
                    $("#IC2").attr("disabled", true);
                }
                // uof.ui.InvolvedEmployee.InvolvedEmpTimeout = setTimeout(function () { uof.ui.InvolvedEmployee.saveInvlovedEmployeeDetailsTemp(true) }, uof.ui.InvolvedEmployee.TimeOutInterval);

                //$(window).on("unload", function () {
                //    uof.ui.InvolvedEmployee.saveInvlovedEmployeeDetailsTemp(true)
                //})
            },

            bindTypeofForce: function () {
                uof.ui.InvolvedEmployee.viewModel.TypeOfForces([]);
                _.each(uof.ui.InvolvedEmployee.viewModel.TypeofForceSelected(), function (item) {
                    _.each(uof.ui.incident.detail.viewModel.incident.ForceTypeId(), function (subItem) {
                        if (item.Code == subItem) {
                            uof.ui.InvolvedEmployee.viewModel.TypeOfForces.push(item);
                        }
                    });
                });
                var obj = new uof.ui.InvolvedEmployee.picklistObject("NN", "None");
                uof.ui.InvolvedEmployee.viewModel.TypeOfForces.push(obj);
                ForceSources = uof.ui.InvolvedEmployee.viewModel.TypeOfForces();
                $('#IncidentTypeOfForce').selectpicker('refresh');
                if (uof.ui.incident.detail.viewModel.incident.IsDeptyInjury() == "Y") {
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Isforecasting("");
                    $("#DeputyinjurySeverity").prop('disabled', false);
                    $('#DeputyinjurySeverity').selectpicker('refresh');
                    //$("#Injured").prop('disabled', false);
                    //$("#Treated").prop('disabled', false);
                    //$("#Admitted").prop('disabled', false);
                    //$("#Facility").prop('disabled', true);
                    $("#divInvolvedEmployeeDeath *").prop('disabled', true);
                    $("#cornerc").removeClass("disabled");
                }

                else {
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.CoronerCaseId("");
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Isforecasting("");
                    $("#DeputyinjurySeverity").prop('disabled', true);
                    //$("#Injured").prop('disabled', true);
                    //$("#Treated").prop('disabled', true);
                    //$("#Admitted").prop('disabled', true);
                    //$("#Facility").prop('disabled', true);
                    $("#divInvolvedEmployeeDeath *").prop('disabled', true);
                    //$("#cornerc").prop('disabled', true);
                    $("#cornerc").addClass("disabled");
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.InjurySeverity = ko.observable();
                    $('#DeputyinjurySeverity').selectpicker('refresh');
                }

            },

            setKendoGridHeight: function () {
                $('.k-grid-content').attr('style', 'height:70%');
            },

            bindControlEvents: function () {
                //$('#DeputyinjurySeverity').change(function () {
                //    var selected = $('#DeputyinjurySeverity').val();

                //    //newValue.join(',').match(/DH/g)
                //    if (selected != undefined && selected == "DH") {
                //        $("#divInvolvedEmployeeDeath *").prop('disabled', false);
                //        $("#cornerc *").removeClass('disabled');
                //        setTimeout(function () { $("#chkIsforecasting").focus(); }, 100);
                //    }
                //    else {
                //        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.CoronerCaseId("");
                //        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Isforecasting("");
                //        $("#cornerc *").addClass('disabled');
                //        $("#divInvolvedEmployeeDeath *").prop('disabled', true);
                //    }
                //});
                $('#DirectedEmployeeNumber').blur(function () {
                    uof.ui.InvolvedEmployee.getEmployeeDetails($('#DirectedEmployeeNumber').val(), 'D', false);
                });
                if (this.viewModel.InvolvedEmployee.IsDirected() == "Y" || this.viewModel.InvolvedEmployee.IsDirected()) {
                    this.getEmployeeDetails(this.viewModel.InvolvedEmployee.DirectedEmpId(), "D", false);
                }
            },

            // Generic method to open the popup page
            showModalPopup: function (IdOfdiv, intervalTime) {
                if (intervalTime == undefined)
                    intervalTime = 100;
                $('#' + IdOfdiv).show();
                $('#' + IdOfdiv).modal({
                    keyboard: true
                }).promise().done(function () {
                    setTimeout(function () {
                        if ($("#" + IdOfdiv).is(":visible"))
                            $("#" + IdOfdiv).focus();
                    }, intervalTime);
                });

            },
            SetFormControls: function (isDisable) {
                $("#InvolvedEmpControls").find('input, select, textarea, button').each(function () {
                    if ($(this).attr('id') != "chkdirected") {
                        $(this).attr('disabled', isDisable);
                    }
                });
            },
            showWhoDirected: function () {
                if ($("#chkdirected").is(":checked")) {
                    uof.ui.InvolvedEmployee.showModalPopup("divDirected", 100);
                    setTimeout(function () { $("#DirectedEmployeeNumber").focus(); }, 100);
                }


            },
            DirectedClose: function () {
                $("#chkdirected").attr("checked", false);
                setTimeout(function () { $("#chkdirected").focus(); }, 100);
                uof.ui.Suspects.hideModalPopup("divDirected");
            },
            validateSaveEmployeeFields: function () {
                result = ko.validation.group([uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.EmployeeId]);
                if (result().length > 0) {
                    //To show the message
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.EmployeeId.valueHasMutated();
                    result.showAllMessages();
                    return false;
                }
                return true;
            },
            validateEmployeeFields: function (model) {
                uof.ui.InvolvedEmployee.EnableValidation = true;
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee = {};
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee = ko.mapping.fromJS(model, ko.mapping.toJS(uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee));
                if (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.TypeOfForce() != null) {
                    var data = uof.ui.InvolvedEmployee.viewModel.TypeOfForces();
                    var TOF = $.grep(data, function (v) {
                        return v.Code.toUpperCase() === uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.TypeOfForce().toUpperCase();
                    });
                    if (TOF.length > 0) {
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.TypeOfForce(TOF[0].Name);
                    }
                    else {
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.TypeOfForce("NN");
                    }
                }
                else
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.TypeOfForce("NN");
                uof.ui.InvolvedEmployee.validateControls();
                result = ko.validation.group(uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee, { deep: true });
                if (result().length > 0) {
                    //To show the message
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.EmployeeId.valueHasMutated();
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Rank.valueHasMutated();
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Sex.valueHasMutated();
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.SelectedDress.valueHasMutated();
                    //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployeeee.InjurySeverity.valueHasMutated();
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Race.valueHasMutated();
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Height.valueHasMutated();
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Weight.valueHasMutated();
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Age.valueHasMutated();
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IndividualCatId.valueHasMutated();
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Shift.valueHasMutated();
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.ShiftType.valueHasMutated();
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DVert.valueHasMutated();
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.InvolType.valueHasMutated();
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsEmployeeEscortSuspect.valueHasMutated();
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.TypeOfForce.valueHasMutated();

                    return false;
                }
                return true;
            },

            //Validate the controls on Add and duplicate popup
            validateControls: function () {
                //remove old validation
                $("#InvolvedEmp .validationMessage").each(function () {
                    $(this).remove();
                });

                $("#InvolvedEmp .warning-msg").each(function () {
                    $(this).remove();
                });
                //warning-msg
                //Validate the controls on Add and duplicate popup
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.EmployeeId.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                    validation: {
                        validator: uof.ui.CommonUILogic.detail.lengthValidation,
                        message: "Employee Number should be 6 character length",
                        params: [6]
                    },
                    //,number: true,
                });

                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.SelectedDress.extend({
                    required: {
                        params: true,
                        message: "SelectedDress " + IncidentConstants.Required
                    }
                });

                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Sex.extend({
                //    required: {
                //        params: true,
                //        message: "A1" + IncidentConstants.Required
                //    },
                //});
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Race.extend({
                    required: {
                        params: true,
                        message: "Race " + IncidentConstants.Required,
                        onlyIf: function () {
                            return uof.ui.InvolvedEmployee.EnableValidation
                        }
                    },
                });
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Height.extend({
                //    required: true,
                //});
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Weight.extend({
                //    required: {
                //        params: true,
                //        message: "A4" + IncidentConstants.Required
                //    },
                //    maxLength: { params: 3, message: "Max length of 3" },
                //    number: true,
                //});

                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.ReviewerId.extend({
                //    required: {
                //        params: true,
                //        message: "Select Reviewer",
                //        onlyIf: function () {
                //            return uof.ui.InvolvedEmployee.viewModel.Sergeants().length > 0
                //        }
                //    },

                //});
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Shift.extend({
                    required: {
                        params: true,
                        message: "Shift " + IncidentConstants.Required,
                        onlyif: function () {
                            return (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsOnlySave() === false);
                        }
                    },
                });

                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.ShiftType.extend({
                    required: {
                        params: true,
                        message: "ShiftType " + IncidentConstants.Required,
                        onlyif: function () {
                            return (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsOnlySave() === false);
                        }
                    },
                });
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DVert.extend({
                    required: {
                        params: true,
                        message: "DVert " + IncidentConstants.Required,
                        onlyif: function () {
                            return (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsOnlySave() === false);
                        }
                    },
                });
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.InvolType.extend({
                    required: {
                        params: true,
                        message: "InvolType " + IncidentConstants.Required,
                        onlyif: function () {
                            return (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsOnlySave() === false);
                        }
                    },
                });

                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.UnitOfAssignment.extend({
                //    required: {
                //        params: true,
                //        message: "A6" + IncidentConstants.Required
                //    },
                //});
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.WorkAssignment.extend({
                //    required: {
                //        params: true,
                //        message: "A7" + IncidentConstants.Required
                //    },
                //});
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IndForceUsed.extend({
                //    required: {
                //        params: true,
                //        message: "A8" + IncidentConstants.Required
                //    },
                //});

                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IndividualCatId.extend({
                    required: {
                        params: true,
                        message: "IndividualCatId " + IncidentConstants.Required,
                        onlyif: function () {
                            return (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsOnlySave() === false);
                        }
                    },
                });
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.ITA.extend({
                //    required: {
                //        params: true,
                //        message: "A9" + IncidentConstants.Required
                //    },
                //});
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsInjured.extend({
                //    required: {
                //        params: true,
                //        message: IncidentConstants.Required
                //    },
                //});
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsTreated.extend({
                //    required: {
                //        params: true,
                //        message: IncidentConstants.Required
                //    },
                //});
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsAdmitted.extend({
                //    required: {
                //        params: true,
                //        message: IncidentConstants.Required
                //    },
                //});

                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.RM.extend({
                //    required: {
                //        params: true,
                //        message: IncidentConstants.Required,
                //        onlyIf: function () {
                //            return (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsDirected() == false || uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsDirected() != "Y")
                //        }
                //    },
                //});
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Facility.extend({
                    required: {
                        params: true,
                        message: "Facility " + IncidentConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsTreated() == true || uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsAdmitted() == true)
                        }
                    },
                });
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.CoronerCaseId.extend({
                    required: {
                        params: true,
                        message: "CoronerCaseId " + IncidentConstants.Required,
                        onlyIf: function () {
                            if (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.InjurySeverity() != null && uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.InjurySeverity() != "") {
                                return uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.InjurySeverity() == "DH"
                            }
                        }
                    },
                });
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.EmployeeItemNumber.extend({
                //    required: {
                //        params: true,
                //        message: "A11" + IncidentConstants.Required
                //    },
                //});
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DateOfBirth.extend({
                    required: {
                        params: true,
                        message: "DateOfBirth " + IncidentConstants.Required,
                        onlyif: function () {
                            return (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsOnlySave() === false);
                        }
                    },
                });
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DepartmentHireDate.extend({
                    required: {
                        params: true,
                        message: "DepartmentHireDate " + IncidentConstants.Required,
                        onlyif: function () {
                            return (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsOnlySave() === false);
                        }
                    },
                });
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.LastPromotionDate.extend({
                //    required: {
                //        params: true,
                //        message: IncidentConstants.Required
                //    },
                //});
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DepartmentTenureInDays.extend({
                //    required: {
                //        params: true, message: IncidentConstants.Required
                //    },
                //    validation: {
                //        validator: function (val, maxLength) {
                //            return !(val.toString().length > maxLength);
                //        },
                //        message: 'Max length of 5',
                //        params: 5
                //    }
                //});
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.RankTenureIndays.extend({
                //    required: {
                //        params: true, message: IncidentConstants.Required
                //    },
                //    validation: {
                //        validator: function (val, maxLength) {
                //            return !(val.toString().length > maxLength);
                //        },
                //        message: 'Max length of 5',
                //        params: 5
                //    }
                //});
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsEmployeeEscortSuspect.extend({
                    required: {
                        params: true,
                        message: "IsEmployeeEscortSuspect " + IncidentConstants.Required
                    },
                });
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DirectedEmpId.extend({
                    required: {
                        params: true,
                        message: "DirectedEmpId " + IncidentConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsDirected() == true)
                        }

                    },
                });
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.TypeOfForce.extend({
                    required: {
                        params: true,
                        message: "TypeOfForce " + IncidentConstants.Required,
                        onlyif: function () {
                            return (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsOnlySave() === false);
                        }
                    },
                });
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.InjurySeverity.extend({
                //    required: {
                //        params: true,
                //        message: IncidentConstants.Required,
                //        onlyIf: function () {
                //            return (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsInjured() == true)
                //        }
                //    },
                //});

            },

            //check the length of string
            lengthValidation: function (str, minChar) {
                var maxChar;
                if (uof.ui.InvolvedEmployee.getCharCount(str) < minChar[0] ||
                    uof.ui.InvolvedEmployee.getCharCount(str) > minChar[1])
                    return false;
                return true;
            },

            //get character based on ascii value
            getCharCount: function (str) {
                var result = 0;
                if (str !== undefined) {
                    for (var n = 0; n < str.length; n++) {
                        var charCode = str.charCodeAt();
                        if (typeof charCode === "number") {
                            if (charCode < 128)
                            { result = result + 1; }
                            else if (charCode < 2048)
                            { result = result + 2; }
                            else if (charCode < 65536)
                            { result = result + 3; }
                            else if (charCode < 2097152)
                            { result = result + 4; }
                            else if (charCode < 67108864)
                            { result = result + 5; }
                            else
                            { result = result + 6; }
                        }
                    }
                }
                return result;
            },

            //check for special characters
            isSpecialChar: function (objValue) {
                var count = 0;
                var pattr = ["\\", ":", "/", "*", "?", ">", "<", "[", "]", "{", "}", "|", "'", "=", "+"];

                while (count < pattr.length) {
                    if (objValue.indexOf(pattr[count]) > -1) {
                        return false;
                    }
                    count++;
                }
            },
            // subscribe method
            subscribeMethod: function () {
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsInjured.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.InjurySeverity.valueHasMutated();
                        uof.ui.InvolvedEmployee.isChanged = true;
                    }
                });
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsDirected.subscribe(function (newValue) {
                    if ($.trim(newValue) == "true") {
                        $("#DirectedEmployeeNumber").removeClass("disabled");
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DirectedEmpId.valueHasMutated();
                        uof.ui.InvolvedEmployee.isChanged = true;
                    }
                    else {
                        $("#DirectedEmployeeNumber").addClass("disabled");
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DirectedEmpId(null);
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DirectedFirstName(null);
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DirectedLastName(null);
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DirectedRank(null);
                    }
                });


                // Subscribing the name and code to get changes
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.EmployeeId.subscribe(function (newValue) {
                    if ($.trim(newValue) != "" && newValue.length == 6) {

                    }
                    uof.ui.InvolvedEmployee.isChanged = true;
                });
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.InjurySeverity.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        uof.ui.InvolvedEmployee.isChanged = true;
                        if ($.trim(newValue) == "DH") {
                            $("#cornerc").removeClass('disabled');
                            $("#divInvolvedEmployeeDeath *").prop('disabled', false);
                            $("#cornerc").prop('disabled', false);
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.CoronerCaseId.valueHasMutated();
                            $("#Injured").addClass('disabled');
                            $("#Treated").addClass('disabled');
                            $("#Admitted").addClass('disabled');
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsInjured(false);
                            return false;
                        }
                        else if ($.trim(newValue) == "IN") {
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.CoronerCaseId("");
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Isforecasting("");
                            $("#cornerc").prop('disabled', true);
                            $("#divInvolvedEmployeeDeath *").prop('disabled', true);
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsInjured(true);
                            $("#Injured").removeClass('disabled');
                            $("#Treated").removeClass('disabled');
                            $("#Admitted").removeClass('disabled');
                            return false;
                        }
                        else {
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.CoronerCaseId("");
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Isforecasting("");
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Facility("");
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsInjured(false);
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsTreated(false);
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsAdmitted(false);
                            $("#Injured").addClass('disabled');
                            $("#Treated").addClass('disabled');
                            $("#Admitted").addClass('disabled');
                            $("#Facility").addClass('disabled');
                            $("#cornerc *").addClass('disabled');
                            $("#divInvolvedEmployeeDeath *").prop('disabled', true);

                        }
                    }

                });
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Race.subscribe(function (newValue) {
                //    if ($.trim(newValue) != "") {
                //        uof.ui.InvolvedEmployee.isChanged = true;
                //    }

                //});
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Sex.subscribe(function (newValue) {
                //    if ($.trim(newValue) != "") {
                //        uof.ui.InvolvedEmployee.isChanged = true;
                //    }

                //});
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Height.subscribe(function (newValue) {
                //    if ($.trim(newValue) != "") {
                //        uof.ui.InvolvedEmployee.isChanged = true;
                //    }

                //});
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Weight.subscribe(function (newValue) {
                //    if ($.trim(newValue) != "") {
                //        uof.ui.InvolvedEmployee.isChanged = true;
                //    }

                //});
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Age.subscribe(function (newValue) {
                //    if ($.trim(newValue) != "") {
                //        uof.ui.InvolvedEmployee.isChanged = true;
                //    }

                //});
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Shift.subscribe(function (newValue) {
                //    if ($.trim(newValue) != "") {
                //        uof.ui.InvolvedEmployee.isChanged = true;
                //    }

                //});
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.RegularShift.subscribe(function (newValue) {
                //    if ($.trim(newValue) != "") {
                //        uof.ui.InvolvedEmployee.isChanged = true;
                //    }

                //});
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.UnitOfAssignment.subscribe(function (newValue) {
                //    if ($.trim(newValue) != "") {
                //        uof.ui.InvolvedEmployee.isChanged = true;
                //    }

                //});
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.WorkAssignment.subscribe(function (newValue) {
                //    if ($.trim(newValue) != "") {
                //        uof.ui.InvolvedEmployee.isChanged = true;
                //    }

                //});
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IndForceUsed.subscribe(function (newValue) {
                //    if ($.trim(newValue) != "") {
                //        uof.ui.InvolvedEmployee.isChanged = true;
                //    }

                //});
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Directed.subscribe(function (newValue) {
                //	if ($.trim(newValue) != "") {
                //		uof.ui.InvolvedEmployee.isChanged = true;
                //	}

                //});
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsRescue.subscribe(function (newValue) {
                //	if ($.trim(newValue) != "") {
                //		uof.ui.InvolvedEmployee.isChanged = true;
                //	}

                //});
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsMedicalAssist.subscribe(function (newValue) {
                //	if ($.trim(newValue) != "") {
                //		uof.ui.InvolvedEmployee.isChanged = true;
                //	}

                //});
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IndividualCatId.subscribe(function (newValue) {
                //	if ($.trim(newValue) != "") {
                //		uof.ui.InvolvedEmployee.isChanged = true;
                //	}

                //});
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Facility.subscribe(function (newValue) {
                //	if ($.trim(newValue) != "") {
                //		uof.ui.InvolvedEmployee.isChanged = true;
                //	}

                //});
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Injured.subscribe(function (newValue) {
                //	if ($.trim(newValue) != "") {
                //		uof.ui.InvolvedEmployee.isChanged = true;
                //	}

                //});
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsTreated.subscribe(function (newValue) {
                    if (!uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsAdmitted())
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Facility(null);
                    if ($.trim(newValue) != "") {
                        uof.ui.InvolvedEmployee.isChanged = true;
                        $("#Facility").removeClass('disabled');
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Facility.valueHasMutated();
                    }

                });
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsAdmitted.subscribe(function (newValue) {
                    if (!uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsTreated())
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Facility(null);
                    if ($.trim(newValue) != "") {
                        uof.ui.InvolvedEmployee.isChanged = true;
                        $("#Facility").removeClass('disabled');
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Facility.valueHasMutated();
                    }

                });
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.CoronerCaseId.subscribe(function (newValue) {
                //	if ($.trim(newValue) != "") {
                //		uof.ui.InvolvedEmployee.isChanged = true;
                //	}

                //});
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.EmployeeItemNumber.subscribe(function (newValue) {
                //	if ($.trim(newValue) != "") {
                //		uof.ui.InvolvedEmployee.isChanged = true;
                //	}

                //});
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DateOfBirth.subscribe(function (newValue) {
                //    if ($.trim(newValue) != "") {
                //        uof.ui.InvolvedEmployee.isChanged = true;
                //    }

                //});
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DepartmentHireDate.subscribe(function (newValue) {
                //	if ($.trim(newValue) != "") {
                //		uof.ui.InvolvedEmployee.isChanged = true;
                //	}

                //});
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.LastPromotionDate.subscribe(function (newValue) {
                //	if ($.trim(newValue) != "") {
                //		uof.ui.InvolvedEmployee.isChanged = true;
                //	}

                //});
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DepartmentTenureInDays.subscribe(function (newValue) {
                //	if ($.trim(newValue) != "") {
                //		uof.ui.InvolvedEmployee.isChanged = true;
                //	}

                //});
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.RankTenureIndays.subscribe(function (newValue) {
                //	if ($.trim(newValue) != "") {
                //		uof.ui.InvolvedEmployee.isChanged = true;
                //	}

                //});
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsEmployeeEscortSuspect.subscribe(function (newValue) {
                //	if ($.trim(newValue) != "") {
                //		uof.ui.InvolvedEmployee.isChanged = true;
                //	}

                //});

            },
            hideModalPopup: function (IdOfdiv) {
                $('#' + IdOfdiv).modal('hide');
            },
            initiatePickers: function () {

                $('#DDOB').datetimepicker({ format: 'MM/DD/YYYY' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DateOfBirth(newDate);
                    //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Age(uof.ui.CommonUILogic.detail.agefinding(newDate));
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Age(uof.ui.CommonUILogic.detail.findInmateAge(uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DateOfBirth(), UoFParams.IncidentDate));
                });
                $('#DHD').datetimepicker({ format: 'MM/DD/YYYY' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DepartmentHireDate(newDate);
                });
                $('#LPD').datetimepicker({ format: 'MM/DD/YYYY' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.LastPromotionDate(newDate);
                });

            },
            listLoad: function () {
                $(".kendo-mini-pager").removeClass("k-pager-wrap");
                $(".kendo-mini-pager").removeClass("k-widget");
                $(".kendo-mini-pager").removeClass("k-floatwrap");

            },
            getAllMethods: function (lookupData) {

                uof.ui.InvolvedEmployee.viewModel.TypeofForceSelected(lookupData);
                $('#IncidentTypeOfForce').selectpicker('refresh');
                $.prototype.hideUofOverlay();

            },
            getIncidentSergeants: function (SergeantInfo) {
                $.each(SergeantInfo, function (index, element) {
                    if (element.ID == uof.ui.incident.detail.selectedContext.selectedIncident()) {
                        var obj = new uof.ui.InvolvedEmployee.picklistObject(element.Code, element.Code + " - " + element.Name);
                        uof.ui.InvolvedEmployee.viewModel.Sergeants.push(obj);
                    }
                });
            },
            getInvolvedEmpInfo: function () {
                $.prototype.showUofOverlay();
                $.ajax(
                {
                    url: window.location.uofAPIOrigin() + '/api/Lookup/GetAllLookupInvolvedEmpInfo',
                    cache: false,
                    type: "GET",
                    dataType: 'json',
                    contentType: "application/json;charset=utf-8",
                    beforeSend: function myfunction() {

                    },
                    success: function (involvedEmpData) {
                        if (involvedEmpData != null) {
                            uof.ui.InvolvedEmployee.viewModel.Dress(involvedEmpData.DressInfo);
                            uof.ui.InvolvedEmployee.viewModel.InjurySeverities(involvedEmpData.CivilianInjurySeverityInfo)
                            uof.ui.InvolvedEmployee.viewModel.Race([]);
                            uof.ui.InvolvedEmployee.viewModel.Race(involvedEmpData.RacesInfo);
                            uof.ui.InvolvedEmployee.viewModel.Gender(involvedEmpData.GenderInfo);
                            uof.ui.InvolvedEmployee.getAllMethods(involvedEmpData.MethodsInfo);
                            uof.ui.InvolvedEmployee.getIncidentSergeants(involvedEmpData.SergeantInfo);
                            RaceSource = uof.ui.InvolvedEmployee.viewModel.Race();
                            SeveritiesSource = uof.ui.InvolvedEmployee.viewModel.InjurySeverities();
                            //uof.ui.InvolvedEmployee.viewModel.Race.valueHasMutated();
                            $('#IncEmpRace').selectpicker('refresh');
                            $('#DeputyinjurySeverity').prop('disabled', false);
                            $('#DeputyinjurySeverity').selectpicker('refresh');
                            

                            if (uof.ui.incident.detail.selectedContext.selectedIncident() > 0) {
                                uof.ui.InvolvedEmployee.bindInvolvedEmployeeList();
                            }
                        }
                        $.prototype.hideUofOverlay();
                    },
                    error: function (e) {
                        showAlert(e.responseText);
                    },
                });
            },

            getDirectInfo: function () {
                result = ko.validation.group(uof.ui.InvolvedEmployee.viewModel.Directed, { deep: true });
                if (result().length > 0) {
                    uof.ui.InvolvedEmployee.viewModel.Directed.DirectedEmployeeNumber.valueHasMutated();
                }
                else
                    uof.ui.InvolvedEmployee.hideModalPopup("divDirected");

                setTimeout(function () { $("#chkdirected").focus(); }, 100);
            },

            saveInvolvedEmpInfo: function (IsOnlySave) {
                if (uof.ui.InvolvedEmployee.validateSaveEmployeeFields()) {
                    if (!uof.ui.CommonUILogic.detail.validateDuplicate(empDataSource._data, uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.EmployeeId(), 1, uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Mode())) {
                        $.prototype.showUofOverlay();
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsOnlySave(IsOnlySave);
                        if (UoFParams.IncidentId != "")
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IncidentId = UoFParams.IncidentId;
                        else
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IncidentId = uof.ui.incident.detail.selectedContext.selectedIncident();
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.LoggedId(UoFParams.userId);
                        var race = uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Race().toString()
                        var mappedData = ko.mapping.toJS(uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee);

                        mappedData.Race = race;
                        if (mappedData.InjurySeverity != null)
                            mappedData.InjurySeverity = mappedData.InjurySeverity;
                        if (mappedData.TypeOfForce != null)
                            mappedData.TypeOfForce = mappedData.TypeOfForce.join(',');
                        $.ajax(
                               {
                                   url: window.location.uofAPIOrigin() + '/api/User/SaveInvolvedUser',
                                   cache: false,
                                   type: "POST",
                                   dataType: 'json',
                                   data: JSON.stringify(mappedData),
                                   contentType: "application/json;charset=utf-8",
                                   beforeSend: function myfunction() {

                                   },
                                   success: function (empData) {
                                       //clearTimeout(uof.ui.InvolvedEmployee.InvolvedEmpTimeout);
                                       $.prototype.hideUofOverlay();
                                       showAlert(empData);
                                       uof.ui.InvolvedEmployee.bindInvolvedEmployeeList();
                                       uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Mode("Add");
                                       uof.ui.InvolvedEmployee.cancelData();
                                   },
                                   error: function (e) {
                                       $.prototype.hideUofOverlay();
                                       $("#Employee").focus();
                                       showAlert(e.responseText);
                                   },
                               });
                    }
                    else
                        showAlert("Duplicate");
                }
            },

            saveInvolvedEmpData: function () {
                if (uof.ui.InvolvedEmployee.validateEmployeeFields()) {
                    uof.ui.InvolvedEmployee.saveInvolvedEmpInfo(false);
                }
            },

            submitfocus: function () {
                setTimeout(function () { $("#btnIESave").focus(); }, 100);
            },
            /* use a function for the exact format desired... */
            ISODateString: function (d) {
                function pad(n) { return n < 10 ? '0' + n : n }
                return d.getUTCFullYear() + '-'
                     + pad(d.getUTCMonth() + 1) + '-'
                     + pad(d.getUTCDate()) + 'T'
                     + pad(d.getUTCHours()) + ':'
                     + pad(d.getUTCMinutes()) + ':'
                     + pad(d.getUTCSeconds()) + 'Z'
            },

            formatLocalDate: function () {
                var now = new Date(),
                    tzo = -now.getTimezoneOffset(),
                    dif = tzo >= 0 ? '+' : '-',
                    pad = function (num) {
                        var norm = Math.abs(Math.floor(num));
                        return (norm < 10 ? '0' : '') + norm;
                    };
                return now.getFullYear()
                    + '-' + pad(now.getMonth() + 1)
                    + '-' + pad(now.getDate())
                    + 'T' + pad(now.getHours())
                    + ':' + pad(now.getMinutes())
                    + ':' + pad(now.getSeconds())
                    + dif + pad(tzo / 60)
                    + ':' + pad(tzo % 60);
            },
            /* use a function for the exact format desired... */
            ISODateString: function (d) {
                function pad(n) { return n < 10 ? '0' + n : n }
                return d.getUTCFullYear() + '-'
                     + pad(d.getUTCMonth() + 1) + '-'
                     + pad(d.getUTCDate()) + 'T'
                     + pad(d.getUTCHours()) + ':'
                     + pad(d.getUTCMinutes()) + ':'
                     + pad(d.getUTCSeconds()) + 'Z'
            },
            getEmployeeDetails: function (empId, mode, validateDuplicate) {

                if ((empId == undefined) || ((empId != undefined) && (empId.length <= 5))) {
                    switch (mode) {
                        case "E":
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.FirstName("");
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.LastName("");
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.MiddleName("");
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Rank("");
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Height("");
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Weight("");
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Age("");
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Sex("");
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Race([]);
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.SelectedDress("");
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.ShiftType("");
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Shift("");
                            break;
                        case "D":
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DirectedFirstName("");
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DirectedLastName("");
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DirectedRank("");
                            break;
                        default:
                            break;
                    }
                }
                else {
                    var isDuplicate = false;
                    if (validateDuplicate)
                        isDuplicate = uof.ui.CommonUILogic.detail.validateDuplicate(empDataSource._data, uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.EmployeeId(), 1, uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Mode())
                    if (!isDuplicate) {
                        // Search based on emp id
                        //console.log(uof.ui.InvolvedEmployee.formatLocalDate())
                        $.prototype.showProgressBar("InvolvedEmp #Employee");
                        jQuery.ajax({
                            type: "GET",
                            url: InvolvedEmployeeAPIUrl() + empId + "&eventDate=" + uof.ui.InvolvedEmployee.formatLocalDate() + "",
                            dataType: "json",
                            cache: false,
                            crossDomain: true,
                            processData: true,
                            success: function (empData) {
                                if (mode == 'E') {
                                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.FirstName(empData.FirstName);
                                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.LastName(empData.LastName);
                                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.MiddleName(empData.MiddleName);
                                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Rank(empData.Rank);

                                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Height(empData.Height);

                                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Weight(empData.Weight);

                                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Age(empData.Age);
                                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Sex(empData.Sex);

                                    if (moment(empData.DateOfBirth).format("MM/DD/YYYY") != "01/01/0001") {
                                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DateOfBirth(moment(empData.DateOfBirth).format("MM/DD/YYYY"));
                                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Age(uof.ui.CommonUILogic.detail.agefinding(moment(empData.DateOfBirth).format("MM/DD/YYYY")));
                                    }
                                    if (moment(empData.DepartmentHireDate).format("MM/DD/YYYY") != "01/01/0001")
                                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DepartmentHireDate(moment(empData.DepartmentHireDate).format("MM/DD/YYYY"));
                                    if (empData.DepartmentTenure != null)
                                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DepartmentTenureInDays(empData.DepartmentTenure.substring(0, empData.DepartmentTenure.indexOf('.')));
                                    if (moment(empData.LastPromotion).format("MM/DD/YYYY") != "01/01/0001")
                                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.LastPromotionDate(moment(empData.LastPromotion).format("MM/DD/YYYY"));
                                    if (empData.RankTenure != null)
                                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.RankTenureIndays(empData.RankTenure.substring(0, empData.RankTenure.indexOf('.')));

                                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.UnitOfAssignment(empData.UnitOfAssignment);

                                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.WorkAssignment(empData.WorkAssignment);

                                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.EmailId(empData.EmailAddress);

                                    if (empData.RankAbrev != null)
                                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.UserRole(empData.RankAbrev);

                                    if (empData.Shift != null) {
                                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Shift("");
                                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Shift(empData.Shift.toUpperCase());
                                    }
                                    if (empData.ShiftType != null) {
                                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.ShiftType("");
                                        switch ((empData.ShiftType).toUpperCase()) {
                                            case "OFFDUTY":
                                            case "OFF":
                                                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.ShiftType("OFF");
                                                break;
                                            case "OVERTIME":
                                            case "OT":
                                                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.ShiftType("OT");
                                                break;
                                            case "REGULAR":
                                                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.ShiftType("RS");
                                                break;
                                        }
                                    }
                                    if (empData.Race != null) {
                                        var data = uof.ui.InvolvedEmployee.viewModel.Race();
                                        var race = $.grep(data, function (v) {
                                            return v.Name.toUpperCase() === empData.Race.toUpperCase();
                                        });
                                        if (race.length > 0) {
                                            $("#IncEmpRace").selectpicker('destroy');
                                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Race([]);
                                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Race(race[0].Code);
                                            $('#IncEmpRace').selectpicker('refresh');
                                        }
                                        else {
                                            $("#IncEmpRace").selectpicker('destroy');
                                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Race([]);
                                            $('#IncEmpRace').selectpicker('refresh');
                                        }
                                    }
                                    //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.SelectedDress(empData.Dress);
                                }
                                else {
                                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DirectedFirstName(empData.FirstName);
                                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DirectedLastName(empData.LastName);
                                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DirectedRank(empData.Rank);
                                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DirectedEmailId(empData.EmailAddress);
                                }

                                $.prototype.hideProgressBar("InvolvedEmp #Employee");
                            },
                            error: function (XMLHttpRequest, textStatus, errorThrown) {
                                showAlert("Error while getting the Employee Data");
                            }
                        });
                    }
                    else
                        showAlert("Employee already Exists");
                }
            },

            //Grid Binding and view codes
            bindInvolvedEmployeeList: function () {
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IncidentId = uof.ui.incident.detail.selectedContext.selectedIncident();
                // Ajax call to server to get Organziation records
                $.prototype.showUofOverlay();
                var dlAjaxOption =
                    {
                        url: window.location.uofAPIOrigin() + '/api/User/GetInvolvedUser',
                        cache: false,
                        data: 'incidentId=' + String(uof.ui.incident.detail.selectedContext.selectedIncident()),
                        type: "GET",
                        dataType: 'json',
                        contentType: "application/json;charset=utf-8",
                        success: function (involvedEmployees) {
                            empDataSource = new kendo.data.DataSource({
                                data: involvedEmployees,
                                pageSize: 20
                            });
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployeeList = ko.observableArray(involvedEmployees);

                            //setting all Org Data to kendo
                            $("#InvolvedEmployeeList").kendoGrid({
                                dataSource: empDataSource,
                                height: 240,
                                scrollable: true,
                                sortable: true,
                                filterable: false,
                                pageable: {
                                    refresh: false,
                                    pageSizes: true,
                                    pageSizes: [20, 50, 100],
                                    buttonCount: 5,
                                    messages: {
                                    },
                                },
                                columns: [
                                 {
                                     field: "EmployeeId",
                                     headerTemplate: kendo.format('<span  class="word-break-txt" title="{0}" >{1}</span>', "EmployeeID", "EmployeeID"),
                                     width: 50
                                 },
                                {
                                    field: "FirstName",
                                    headerTemplate: kendo.format('<span  class="word-break-txt" title="{0}" >{1}</span>', "Employee Name", "Employee Name"),
                                    template: $("#involvedEmpName").html(),
                                    width: 150
                                },
                                 {
                                     field: "UnitOfAssignment",
                                     headerTemplate: kendo.format('<span  class="word-break-txt" title="{0}" >{1}</span>', "Unit Of Assignment", "Unit of Assignment"),
                                     width: 150
                                 },

                                {
                                    field: "IncidentId",
                                    template: $("#editIncident").html(),
                                    headerTemplate: '',
                                    width: 30,
                                },
                                 {
                                     field: "IncidentId",
                                     template: $("#deleteInvemployee").html(),
                                     headerTemplate: '',
                                     width: 30,
                                     hidden: !uof.ui.InvolvedEmployee.viewModel.isEditmode(),
                                 },


                                ],
                                //  dataBound: athoc.iws.organizationManager.OnDataBound,
                                change: function (e) {
                                    var model = this.dataItem(this.select());
                                }
                            }).data().kendoGrid;
                            empDataSource.read();
                            $.prototype.hideUofOverlay();
                            uof.ui.InvolvedEmployee.setKendoGridHeight();
                            if (!uof.ui.InvolvedEmployee.viewModel.isEditmode()) {
                                $("#InvolvedEmployeeList").find('button').html('View');
                            }
                        },
                        error: function (e) {
                            $.prototype.hideUofOverlay();
                            showAlert(e.responseText);
                        }

                    };
                // Call ajax
                var ajaxOptions = $.extend({}, 'GET', dlAjaxOption);
                $.ajax(ajaxOptions);

            },

            viewInvolvedEmployee: function (empId, incidentId) {

                var selectedData = _.find(empDataSource.data(), function (item) {
                    return ((item.EmployeeId == empId) && (item.IncidentId == incidentId));
                });

                if (selectedData != null) {
                    uof.ui.InvolvedEmployee.viewModel.isEditmode(false);

                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee = {};
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee = ko.mapping.fromJS(selectedData, uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee);
                    //this.setCustomizedProperty();
                    //formating
                    if (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DepartmentHireDate() != null)
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DepartmentHireDate(moment(uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DepartmentHireDate()).format("MM/DD/YYYY"));
                    if (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.LastPromotionDate())
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.LastPromotionDate(moment(uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.LastPromotionDate()).format("MM/DD/YYYY"));
                    if (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DepartmentHireDate())
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DateOfBirth(moment(uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DateOfBirth()).format("MM/DD/YYYY"));

                    if (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Sex() != null) {
                        var data = uof.ui.InvolvedEmployee.viewModel.Gender();
                        var gen = $.grep(data, function (v) {
                            return v.Code.toUpperCase() === uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Sex().toUpperCase();
                        });
                        if (gen.length > 0) {
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Sex(gen[0].Name);
                        }
                        else {
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Sex("");
                        }
                    }

                    if (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Race() != null) {
                        var data = uof.ui.InvolvedEmployee.viewModel.Race();
                        var race = $.grep(data, function (v) {
                            return v.Code.toUpperCase() === uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Race().toUpperCase();
                        });
                        if (race.length > 0) {
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Race(race[0].Name);
                        }
                        else {
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Race("");
                        }
                    }
                    if (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.TypeOfForce() != null) {
                        var data = uof.ui.InvolvedEmployee.viewModel.TypeOfForces();
                        var TOF = $.grep(data, function (v) {
                            return v.Code.toUpperCase() === uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.TypeOfForce().toUpperCase();
                        });
                        if (TOF.length > 0) {
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.TypeOfForce(TOF[0].Name);
                        }
                        else {
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.TypeOfForce("");
                        }
                    }
                    if (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.InjurySeverity() != null) {
                        var data = uof.ui.InvolvedEmployee.viewModel.InjurySeverities();
                        var TOF = $.grep(data, function (v) {
                            return v.Code.toUpperCase() === uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.InjurySeverity().toUpperCase();
                        });
                        if (TOF.length > 0) {
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.InjurySeverity(TOF[0].Name);
                        }
                        else {
                            uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.InjurySeverity("");
                        }
                    }
                    //end

                    //   ko.cleanNode($("#InvolvedEmpView").get(0));
                    //  ko.applyBindings(uof.ui.InvolvedEmployee.viewModel, $("#InvolvedEmpView").get(0));
                }
            },
            deleteInvolvedEmployee: function (empId, incidentId) {
                var selectedData = _.find(empDataSource.data(), function (item) {
                    return ((item.EmployeeId == empId) && (item.IncidentId == incidentId));
                });
                $.prototype.showUofOverlay();
                $.ajax(
               {
                   url: window.location.uofAPIOrigin() + '/api/User/DeleteUser?incidentId=' + incidentId + '&userId=' + selectedData.IncidentUserInvolvedId + '&employeeNumber=' + empId + '&userType=1',
                   cache: false,
                   type: "DELETE",
                   dataType: 'json',
                   contentType: "application/json;charset=utf-8",
                   beforeSend: function myfunction() {

                   },
                   success: function (data) {
                       showAlert(data);
                       uof.ui.InvolvedEmployee.bindInvolvedEmployeeList();
                       $.prototype.hideUofOverlay();
                   },
                   error: function (e) {
                       showAlert(e.responseText);
                   },
               });

            },
            editInvolvedEmployee: function (empId, incidentId) {

                var selectedData = _.find(empDataSource.data(), function (item) {
                    return ((item.EmployeeId == empId) && (item.IncidentId == incidentId));
                });

                if (selectedData != null) {
                    if (selectedData.DateOfBirth != null)
                        selectedData.DateOfBirth = moment(selectedData.DateOfBirth).format("MM/DD/YYYY");
                    if (selectedData.DepartmentHireDate != null)
                        selectedData.DepartmentHireDate = moment(selectedData.DepartmentHireDate).format("MM/DD/YYYY");
                    if (selectedData.LastPromotionDate != null)
                        selectedData.LastPromotionDate = moment(selectedData.LastPromotionDate).format("MM/DD/YYYY");
                    if (selectedData.DirectedEmplId != null)
                        uof.ui.InvolvedEmployee.viewModel.Directed.DirectedEmployeeNumber

                    uof.ui.InvolvedEmployee.viewModel.isEditmode(true);

                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee = {};
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee = ko.mapping.fromJS(selectedData, ko.mapping.toJS(uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee));
                    //this.setCustomizedProperty();
                    uof.ui.InvolvedEmployee.validateControls();
                    $("#IncEmpRace").selectpicker('destroy');
                    //$('#DeputyinjurySeverity').selectpicker('destroy');
                    $('#IncidentTypeOfForce').selectpicker('destroy');
                    if (uof.ui.InvolvedEmployee.viewModel.Race.length == 0)
                        uof.ui.InvolvedEmployee.viewModel.Race = ko.observableArray(RaceSource);

                    if (uof.ui.InvolvedEmployee.viewModel.InjurySeverities.length == 0)
                        uof.ui.InvolvedEmployee.viewModel.InjurySeverities = ko.observableArray(SeveritiesSource);

                    if (uof.ui.InvolvedEmployee.viewModel.TypeOfForces.length == 0)
                        uof.ui.InvolvedEmployee.viewModel.TypeOfForces = ko.observableArray(ForceSources);

                    if (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Race() != null)
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Race = ko.observableArray(uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Race().split(','));

                    //if (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.InjurySeverity() != null)
                    //    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.InjurySeverity = ko.observableArray(uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.InjurySeverity().split(','));

                    if (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.TypeOfForce() != null)
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.TypeOfForce = ko.observableArray(uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.TypeOfForce().split(','));


                    ko.cleanNode($("#InvolvedEmpControls").get(0));
                    ko.applyBindings(uof.ui.InvolvedEmployee.viewModel, $("#InvolvedEmpControls").get(0));
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Mode("Edit");

                    $('#IncEmpRace').selectpicker('refresh');
                    //$('#DeputyinjurySeverity').selectpicker('refresh');
                    $('#IncidentTypeOfForce').selectpicker('refresh');

                    // uof.ui.InvolvedEmployee.bindTypeofForce();
                    uof.ui.InvolvedEmployee.subscribeMethod();
                    uof.ui.InvolvedEmployee.bindControlEvents();
                    uof.ui.InvolvedEmployee.initiatePickers();
                    if (uof.ui.incident.detail.viewModel.incident.IsDeptyInjury() == "Y") {
                        $("#DeputyinjurySeverity").prop('disabled', false);
                        //$("#Injured").prop('disabled', false);
                        //$("#Treated").prop('disabled', false);
                        //$("#Admitted").prop('disabled', false);
                        //$("#Facility").prop('disabled', true);
                        $("#divInvolvedEmployeeDeath *").prop('disabled', false);
                        $("#cornerc").prop('disabled', true);
                    }

                    else {
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.CoronerCaseId(null);
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Isforecasting("");
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsTreated(false);
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsAdmitted(false);
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsInjured(false);
                        //$("#Injured").prop('checked', false);
                        //$("#Treated").prop('checked', false);
                        //$("#Admitted").prop('checked', false);
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Facility(null);
                        //$("#DeputyinjurySeverity").prop('disabled', true);
                        //$("#Injured").prop('disabled', true);
                        //$("#Treated").prop('disabled', true);
                        //$("#Admitted").prop('disabled', true);
                        //$("#Facility").prop('disabled', true);
                        $("#divInvolvedEmployeeDeath *").prop('disabled', true);
                        $("#cornerc").prop('disabled', true);
                        // $("#DeputyinjurySeverity").selectpicker('destroy');
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.InjurySeverity();
                        // $('#DeputyinjurySeverity').selectpicker('refresh');
                    }
                    if (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.InjurySeverity() == "DH") {
                        $("#divInvolvedEmployeeDeath *").prop('disabled', false);
                        $("#cornerc").prop('disabled', false);
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.CoronerCaseId.valueHasMutated();
                    }
                    else if (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.InjurySeverity() == "NI") {
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Facility(null);
                        $("#Injured").prop('disabled', true);
                        $("#Treated").prop('disabled', true);
                        $("#Admitted").prop('disabled', true);
                        $("#Facility").prop('disabled', true);
                    }
                    else if (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.InjurySeverity() == "IN") {
                        $("#Injured").prop('disabled', false);
                        $("#Treated").prop('disabled', false);
                        $("#Admitted").prop('disabled', false);
                    }
                    else {
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.CoronerCaseId(null);
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Isforecasting("");
                        $("#divInvolvedEmployeeDeath *").prop('disabled', true);
                        $("#cornerc").prop('disabled', true);
                    }
                    if (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsDirected()) {
                        $("#DirectedEmployeeNumber").removeClass("disabled");
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DirectedEmpId.valueHasMutated();
                    }
                    else {
                        $("#DirectedEmployeeNumber").addClass("disabled");
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DirectedEmpId(null);
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DirectedFirstName(null);
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DirectedLastName(null);
                        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DirectedRank(null);
                    }
                    if (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Sex() == null && uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DateOfBirth() == null) {
                        uof.ui.InvolvedEmployee.getEmployeeDetails(empId, 'E', false)
                    }

                }
            },

            setCustomizedProperty: function () {
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsDirected = ko.observable(false);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsRescue = ko.observable(false);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsMedicalAssist = ko.observable(false);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsInjured = ko.observable(false);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsTreated = ko.observable(false);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsAdmitted = ko.observable(false);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DVert = ko.observable(false);

                if (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsDirected() == "Y") {
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsDirected = ko.observable(true);
                }
                if (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsRescue() == "Y") {
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsRescue = ko.observable(true);
                }
                if (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsMedicalAssist() == "Y") {
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsMedicalAssist = ko.observable(true);
                }

                if (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsInjured() == "Y") {
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsInjured = ko.observable(true);
                }
                if (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsTreated() == "Y") {
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsTreated = ko.observable(true);
                }
                if (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsAdmitted() == "Y") {
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsAdmitted = ko.observable(true);
                }
                if (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DVert() == "Y") {
                    uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DVert = ko.observable(true);
                }
            },

            cancelView: function () {
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Mode("Add");
                uof.ui.InvolvedEmployee.viewModel.isEditmode(true); return true;
            },

            cancelData: function () {
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Mode("Add");
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IncidentId = ko.observable(0);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.EmployeeId(null);

                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DateOfBirth(null);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DepartmentHireDate(null);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.LastPromotionDate(null);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DepartmentTenureInDays(null);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.RankTenureIndays(null);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Shift("");
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.ShiftType("");
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.InvolType("");
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.UnitOfAssignment(null);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.WorkAssignment(null);

                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Isforecasting("");
                //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IndForceUsed(null);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IndividualCatId("");
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.ITA("");
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.RM("");
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Facility(null);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.CoronerCaseId(null);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsEmployeeEscortSuspect(null);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DVert(false);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.InvolTyp = ko.observable(null);
                $('#IncidentTypeOfForce').selectpicker('destroy');
                $('#IncEmpRace').selectpicker('destroy');
                $('#DeputyinjurySeverity').selectpicker('destroy');
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Race([]);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.TypeOfForce([]);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.InjurySeverity(null);

                $('#IncidentTypeOfForce').selectpicker('refresh');
                $('#IncEmpRace').selectpicker('refresh');
                $('#DeputyinjurySeverity').selectpicker('refresh');

                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.LastName("");
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.FirstName("");
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.MiddleName("");
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Rank(null);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Sex(null);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.SelectedDress(null);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Height(null);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Weight(null);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Age(null);

                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsDirected(false);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsRescue(false);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsMedicalAssist(false);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsInjured(false);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsTreated(false);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.IsAdmitted(false);

                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DirectedEmpId(null);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DirectedLastName(null);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DirectedFirstName(null);
                uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.DirectedRank(null);

                //uof.ui.InvolvedEmployee.viewModel.isDirty(false);
                result = ko.validation.group(uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee, { deep: true });
                result.showAllMessages(false);
            },
            trackViewModel: function (model) {
                var viewModel = model;
                // loop through all the properties in the model
                for (var property in viewModel) {
                    if (viewModel.hasOwnProperty(property)) {
                        // if they're observable
                        if (viewModel[property].subscribe) {
                            // subscribe to changes
                            viewModel[property].subscribe(function (value) {
                                uof.ui.InvolvedEmployee.catchChanges(property, value, viewModel);
                            });
                        }
                    }
                }
                viewModel.isDirty = false;
            },
            catchChanges: function (property, value, model) {
                //uof.ui.InvolvedEmployee.changeLog.push({ property: property, value: value });
                model.isDirty = true;
            },
            //End of Grid Binding and View code
        }
    }();

}