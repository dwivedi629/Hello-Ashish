﻿var uof = uof || {};
uof.ui = uof.ui || {};
uof.ui.incident = uof.ui.incident || {};

if (uof.ui.incident) {
    uof.ui.incident.statisticaldata = function () {
        return {
            staticalDataSource: null,
            parameters: null,
            isChanged: false,
            isSuccess: false,
            previousEmp: "",
            previousSuspect: "",
            init: function (args) {
                this.parameters = args;
            },
            viewModel: {
                Statistical: {
                    isEditMode: ko.observable(true),
                    IncidentId: ko.observable(),
                    //selectedMethod: ko.observable(),
                    //selectedTypeofInjury: ko.observable(),
                    //selectedBodyPartInvolved: ko.observable(),
                    //EmployeeId: ko.observable(),
                    //Name: ko.observable(),
                    //ForcedUsedById: ko.observable(),
                    //ForcedUsedAgainstId: ko.observable(),
                    StatisticalItems: ko.observableArray(),

                },

                //EmpSuspectID: [
                //    { IDText: 'None',ID: '0' },
                //    { IDText: '8888', ID: '8888' },
                //    { IDText: '8888', ID: '999' },
                //    { IDText: '8888', ID: '99912122' },
                //    { IDText: '8888', ID: '12121' },
                //    { IDText: '8888', ID: '121212' },
                //],
                EmpSuspectData: ko.observable([]),
                EmpSuspectID: ko.observable([]),
                SelectedSuspectID: ko.observable(),
                SelectedEmpID: ko.observable(),
                Method: ko.observable([]),
                TypeofInjury: ko.observable([]),
                BodyPartInvolved: ko.observable([]),

                getEmployeeDetails: function (value, mode) {
                    uof.ui.incident.statisticaldata.getEmployeeDetails(value, mode);

                },
            },
            AddStatisticalItems: function () {
                uof.ui.incident.statisticaldata.viewModel.Statistical.StatisticalItems.push(new uof.ui.incident.statisticaldata.StatisticalItem());
            },
            RemoveStatisticalItems: function (StatisticalItem) {
                uof.ui.incident.statisticaldata.viewModel.Statistical.StatisticalItems.remove(StatisticalItem);
            },
            StatisticalItem: function () {
                var self = this;
                self.ForcedUsedByName = ko.observable().extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });
                self.ForcedUsedById = ko.observable().extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });
                self.ForcedUsedAgainstId = ko.observable().extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });
                self.ForcedUsedAgainstName = ko.observable().extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });
                self.MethodCode = ko.observable().extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });
                self.InjuryTypeCode = ko.observable();
                //self.InjuryTypeCode = ko.observable().extend({
                //    required: {
                //        params: true,
                //        message: IncidentConstants.Required
                //    },
                //});
                self.BodyPartInvolvedCode = ko.observable();
                //self.BodyPartInvolvedCode = ko.observable().extend({
                //    required: {
                //        params: true,
                //        message: IncidentConstants.Required
                //    },
                //});
                self.IncidentId = ko.observable().extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });
                self.LoggedId = ko.observable(UoFParams.userId);

            },
            load: function () {

                if (uof.ui.incident.detail.selectedContext.selectedIncident() > 0) {
                    uof.ui.incident.statisticaldata.viewModel.Statistical.StatisticalItems().length = 0;
                    uof.ui.incident.statisticaldata.viewModel.Statistical.IncidentId = uof.ui.incident.detail.selectedContext.selectedIncident();
                    
                    uof.ui.incident.statisticaldata.getInvolvedUsersAndSuspects();


                }

                uof.ui.incident.statisticaldata.getAllStatsDataInfo();
                ko.cleanNode($("#StaticalInput").get(0));
                ko.applyBindings(uof.ui.incident.statisticaldata.viewModel, $("#StaticalInput").get(0));
                uof.ui.incident.detail.viewModel.incident.currentMode(localStorage.getItem('mode'));
                uof.ui.incident.statisticaldata.bindControlEvents();
                if (uof.ui.incident.statisticaldata.viewModel.Statistical.StatisticalItems().length == 0)
                    uof.ui.incident.statisticaldata.viewModel.Statistical.StatisticalItems.push(new uof.ui.incident.statisticaldata.StatisticalItem());
                if ((uof.ui.incident.detail.viewModel.incident.currentMode() == 'Edit')) {
                    uof.ui.incident.statisticaldata.viewModel.Statistical.isEditMode(true);
                    $("#txtForcedUsedByName").prop('disabled', false);
                    $("#TypeofInjury").prop('disabled', false);
                    $("#txtForcedUsedAgainstName").prop('disabled', false);
                    $("#Method").prop('disabled', false);
                    $("#empsuspectid").prop('disabled', false);
                    $("#BodyPartInvloved").prop('disabled', false);
                    $("#empsuspect").prop('disabled', false);
                }
                else if ((uof.ui.incident.detail.viewModel.incident.currentMode() == 'view')) {
                    uof.ui.incident.statisticaldata.viewModel.Statistical.isEditMode(false);
                    uof.ui.incident.statisticaldata.SetFormControls(true);
                }

                uof.ui.incident.statisticaldata.subscribeMethod();

            },

            //Cancel Data,on cancel button click
            cancelData: function () {
                
                for (var obj in uof.ui.incident.statisticaldata.viewModel) {
                    for (var prop in uof.ui.incident.statisticaldata.viewModel[obj]) {
                         if (uof.ui.incident.statisticaldata.viewModel[obj].hasOwnProperty(prop) && ko.isObservable(uof.ui.incident.statisticaldata.viewModel[obj][prop])) {
                             if (prop != "StatisticalItems")
                             uof.ui.incident.statisticaldata.viewModel[obj][prop](undefined);
                        }
                    }
                }
                _.each(uof.ui.incident.statisticaldata.viewModel.Statistical.StatisticalItems(), function (item) {
                    _.each(item, function (subItem) {
                        if (ko.isObservable(subItem)) {
                            subItem(undefined);
                        }
                    });
                });
                result = ko.validation.group(uof.ui.incident.statisticaldata.viewModel.Statistical, { deep: true });
                result.showAllMessages(false);
            },

            SetFormControls: function (isDisable) {
                $("#StaticalInput").find('input, select, textarea ,button').each(function () {
                    $(this).attr('disabled', isDisable);
                });
            },

            subscribeMethod: function () {
                //    uof.ui.incident.statisticaldata.viewModel.Statistical.StatisticalItems.subscribe(function (changes) {

                //        changes.forEach(function (change) {
                //            if (change.status === 'added' || change.status === 'deleted') {
                //                console.log("Added or removed! The added/removed element is:", change.value);
                //            }
                //        });

                //    }, null, "arrayChange");
            },
            bindControlEvents: function () {
                $(document).on('focus', ".fakeEsid", function (e) {
                    uof.ui.incident.statisticaldata.previousEmp = $(this).val();
                });
                $(document).on('focus', ".fakeSeid", function (e) {
                    uof.ui.incident.statisticaldata.previousSuspect = $(this).val();
                });

                $(document).on('change', ".fakeEsid", function (e) {
                    if (!uof.ui.incident.statisticaldata.isSuccess) {
                        var esidValue = $(this).val() == undefined ? $(".fakeEsid option:selected").val() : $(this).val();
                        var siedValue = $(this).parent().parent().find(".fakeSeid option:selected").val();

                        var self = $(this);
                        var dataESID = _.find(uof.ui.incident.statisticaldata.viewModel.EmpSuspectID(), function (item) {
                            if (item.Code == esidValue)
                                return item;
                        });
                        var dataSIED = _.find(uof.ui.incident.statisticaldata.viewModel.EmpSuspectID(), function (item) {
                            if (item.Code == siedValue)
                                return item;
                        });
                        if (dataESID != undefined && dataSIED != undefined) {
                            if (self.attr('id') == self.parent().parent().find(".fakeEsid").attr("id") && dataESID.UserTypeID == dataSIED.UserTypeID) {
                                $(this).val(uof.ui.incident.statisticaldata.previousEmp);
                                return false;
                            }
                            else {
                                _.each(uof.ui.incident.statisticaldata.viewModel.Statistical.StatisticalItems(), function (data) {
                                    if (data.ForcedUsedById() == dataESID.Code) {
                                        data.ForcedUsedByName(dataESID.Name.replace(/E+\d+/g, '').replace(/S+\d+/g, '').replace("(", "").replace(")", ""));
                                    }
                                });
                            }
                        }
                        else if (dataESID != null) {
                            _.each(uof.ui.incident.statisticaldata.viewModel.Statistical.StatisticalItems(), function (data) {
                                if (data.ForcedUsedById() == dataESID.Code) {
                                    data.ForcedUsedByName(dataESID.Name.replace(/E+\d+/g, '').replace(/S+\d+/g, '').replace("(", "").replace(")", ""));
                                }
                            });
                        }
                    }
                    else {
                        _.each(uof.ui.incident.statisticaldata.viewModel.Statistical.StatisticalItems(), function (data) {
                            _.each(uof.ui.incident.statisticaldata.viewModel.EmpSuspectID(), function (item) {
                                if (data.ForcedUsedById() == item.Code) {
                                    data.ForcedUsedByName(item.Name.replace(/E+\d+/g, '').replace(/S+\d+/g, '').replace("(", "").replace(")", ""));
                                }
                            });
                        });
                    }
                    return false;

                });

                $(document).on('change', ".fakeSeid", function (e) {
                    if (!uof.ui.incident.statisticaldata.isSuccess) {
                        var seidValue = $(this).val() == undefined ? $(".fakeSeid option:selected").val() : $(this).val();
                        var EsidValue = $(this).parent().parent().find(".fakeEsid option:selected").val();
                        var self = $(this);

                        var dataESID = _.find(uof.ui.incident.statisticaldata.viewModel.EmpSuspectID(), function (item) {
                            if (item.Code == seidValue)
                                return item;
                        });

                        var dataSIED = _.find(uof.ui.incident.statisticaldata.viewModel.EmpSuspectID(), function (item) {
                            if (item.Code == EsidValue)
                                return item;
                        });
                        if (dataESID != undefined && dataSIED != undefined) {
                            if (self.attr('id') == self.parent().parent().find(".fakeSeid").attr("id") && dataESID.UserTypeID == dataSIED.UserTypeID) {
                                $(this).val(uof.ui.incident.statisticaldata.previousSuspect);
                                return false;
                            }
                            else {
                                _.each(uof.ui.incident.statisticaldata.viewModel.Statistical.StatisticalItems(), function (data) {
                                    if (data.ForcedUsedAgainstId() == dataESID.Code) {
                                        data.ForcedUsedAgainstName(dataESID.Name.replace(/E+\d+/g, '').replace(/S+\d+/g, '').replace("(", "").replace(")", ""));
                                    }
                                });
                            }
                        }
                        else if (dataESID != null) {
                            _.each(uof.ui.incident.statisticaldata.viewModel.Statistical.StatisticalItems(), function (data) {
                                if (data.ForcedUsedAgainstId() == dataESID.Code) {
                                    data.ForcedUsedAgainstName(dataESID.Name.replace(/E+\d+/g, '').replace(/S+\d+/g, '').replace("(", "").replace(")", ""));
                                }
                            });
                        }
                    }
                    else {
                        _.each(uof.ui.incident.statisticaldata.viewModel.Statistical.StatisticalItems(), function (data) {
                            _.each(uof.ui.incident.statisticaldata.viewModel.EmpSuspectID(), function (item) {
                                if (data.ForcedUsedAgainstId() == item.Code) {
                                    data.ForcedUsedAgainstName(item.Name.replace(/E+\d+/g, '').replace(/S+\d+/g, '').replace("(", "").replace(")", ""));
                                }
                            });
                        });
                    }
                });

            },
            fillEmployeeorSuspectName: function () {
                //uof.ui.incident.statisticaldata.viewModel.EmpSuspectData.

            },
            getInvolvedUsersAndSuspects: function () {
                $.prototype.showUofOverlay();
                $.ajax(
                {
                    url: window.location.uofAPIOrigin() + '/api/User/GetInvolvedUsersAndSuspects',
                    data: 'incidentId=' + String(uof.ui.incident.statisticaldata.viewModel.Statistical.IncidentId),
                    cache: false,
                    type: "GET",
                    dataType: 'json',
                    contentType: "application/json;charset=utf-8",
                    beforeSend: function myfunction() {

                    },
                    success: function (lookupData) {
                        uof.ui.incident.statisticaldata.viewModel.EmpSuspectID(lookupData);
                        uof.ui.incident.statisticaldata.viewModel.EmpSuspectData(lookupData);
                        uof.ui.incident.statisticaldata.bindStaticalData();
                    },
                    error: function (e) {
                        $.prototype.hideUofOverlay();
                        showAlert(e.responseText);
                    },
                });
            },

            getAllStatsDataInfo: function () {
                $.prototype.showUofOverlay();
                $.ajax(
                    {
                        url: window.location.uofAPIOrigin() + '/api/Lookup/GetAllLookupInformationforStatsData',
                        cache: false,
                        type: "GET",
                        dataType: 'json',
                        contentType: "application/json;charset=utf-8",
                        beforeSend: function myfunction() {

                        },
                        success: function (statsDataDetail) {
                            if (statsDataDetail != null) {
                                uof.ui.incident.statisticaldata.viewModel.TypeofInjury(statsDataDetail.InjuriesInfo);
                                uof.ui.incident.statisticaldata.viewModel.BodyPartInvolved(statsDataDetail.BodyPartInfo);
                                uof.ui.incident.statisticaldata.viewModel.Method(statsDataDetail.MethodsInfo);
                            }
                            $.prototype.hideUofOverlay();
                        },
                        error: function (e) {
                            $.prototype.hideUofOverlay();
                            showAlert(e.responseText);
                        },
                    });
            },
            getEmployeeDetails: function (empId, mode) {
                if ((empId == undefined) || ((empId != undefined) && (empId.length <= 0))) { return false };
                var IdOfControls = (mode == 'OD' ? '#OD_Employee' : mode == 'WC' ? '#WC_Employee' : '#SCI_Employee');
                // Search based on emp id
                $.prototype.showProgressBar("On_Duty " + IdOfControls);
                $.ajax(
                {
                    url: window.location.uofAPIOrigin() + '/api/Incident/GetEmployeeDetails',
                    cache: false,
                    data: 'empId=' + String(empId),
                    type: "GET",
                    dataType: 'json',
                    contentType: "application/json;charset=utf-8",
                    success: function (empData) {
                        if (mode == 'OD') {
                            uof.ui.incident.statisticaldata.viewModel.Statistical.Name(empData.FirstName + ' ' + empData.LastName + ' ' + empData.MiddleName);
                            uof.ui.incident.statisticaldata.viewModel.Statistical.Rank(empData.EmployeeId);
                        }
                        $.prototype.hideProgressBar("On_Duty " + IdOfControls);
                    },
                    error: function (e) {
                        $.prototype.hideProgressBar("On_Duty " + IdOfControls);
                        showAlert(e.responseText);
                    },
                });

            },

            saveStaticalData: function () {
                //check for validation and after that if truw then below code will execute
                if (uof.ui.incident.statisticaldata.validateIncidentStatisticalItem()) {
                    $.prototype.showUofOverlay();
                    var mappedData = ko.mapping.toJS(uof.ui.incident.statisticaldata.viewModel.Statistical.StatisticalItems);
                    $.ajax(
                           {
                               url: window.location.uofAPIOrigin() + '/api/Incident/SaveStatiticalData',
                               cache: false,
                               type: "POST",
                               dataType: 'json',
                               data: JSON.stringify(mappedData),
                               contentType: "application/json;charset=utf-8",
                               beforeSend: function myfunction() {

                               },
                               success: function (empData) {
                                   $.prototype.hideUofOverlay();
                                   showAlert(empData);

                               },
                               error: function (e) {
                                   $.prototype.hideUofOverlay();
                                   showAlert(e.responseText);
                               },
                           });
                }
            },

            //Grid Binding 
            bindStaticalData: function () {
                // Ajax call to server to get Organziation records
                $.prototype.showUofOverlay();
                var dlAjaxOption =
                    {
                        url: window.location.uofAPIOrigin() + '/api/User/GetStaticalData',
                        cache: false,
                        data: "incidentId=" + uof.ui.incident.statisticaldata.viewModel.Statistical.IncidentId,
                        type: "GET",
                        dataType: 'json',
                        contentType: "application/json;charset=utf-8",
                        success: function (staticalData) {
                            if (staticalData.length > 0) {
                                uof.ui.incident.statisticaldata.isSuccess = true;
                                uof.ui.incident.statisticaldata.viewModel.Statistical.StatisticalItems().length = 0;
                                _.each(staticalData, function (item) {
                                    uof.ui.incident.statisticaldata.viewModel.Statistical.StatisticalItems.push(ko.mapping.fromJS(item));
                                });
                            }
                            $.prototype.hideUofOverlay();
                        },
                        complete: function () {
                            uof.ui.incident.statisticaldata.isSuccess = false;
                        },
                        error: function (e) {
                            uof.ui.incident.statisticaldata.isSuccess = false;
                            showAlert(e.responseText);
                        }

                    };
                // Call ajax
                var ajaxOptions = $.extend({}, 'GET', dlAjaxOption);
                $.ajax(ajaxOptions);

            },

            setKendoGridHeight: function () {
                $('.k-grid-content').attr('style', 'height:70%');
            },

            cancelStaticalView: function () {

                uof.ui.incident.statisticaldata.viewModel.Statistical.isEditMode(true); return true;
            },

            viewStaticalData: function (fname) {
                var selectedData = _.find(staticalDataSource.data(), function (item) {
                    return item.FirstName == fname;
                });

                if (selectedData != null) {

                    var bindClass = {
                        Statistical: selectedData
                    };

                    uof.ui.incident.statisticaldata.viewModel.Statistical.isEditMode(false);
                    bindClass.Statistical = ko.mapping.fromJS(bindClass.Statistical);
                    ko.cleanNode($("#StaticalView").get(0));
                    ko.applyBindings(bindClass, $("#StaticalView").get(0));
                }
            },

            validateIncidentStatisticalItem: function () {
                result = ko.validation.group(uof.ui.incident.statisticaldata.viewModel.Statistical, { deep: true });
                if (result().length > 0) {
                    result.showAllMessages();
                    return false;
                }

                return true;
            },
        }
    }();
}