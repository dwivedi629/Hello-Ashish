﻿var uof = uof || {};
uof.ui = uof.ui || {};
uof.ui.incident = uof.ui.incident || {};
if (uof.ui.incident) {
    uof.ui.Suspects = function () {
        return {
            parameters: null,
            isChanged: false,
            init: function (args) {
                this.parameters = args;
            },
            picklistObject: function (Code, Name) {
                this.Code = Code;
                this.Name = Name;
                return this;
            },
            allowedImageFile: allowedImageFilebyConfig.split(','),
            allowedVideoFile: allowedVideoFilebyConfig.split(','),
            allowedAudioFile: allowedAudioFilebyConfig.split(','),
            allowedFiles: ko.observable(),
            selectedFiles: ko.observableArray([]),
            allInterviewFiles: ko.observableArray([]),
            suspectDataSource: null,
            RaceSource: null,
            SuspectSHSource: null,
            CISource: null,
            fileupload: "fileupload",
            viewModel: {
                isEditMode: ko.observable(true),
                TypeOfForce: ko.observableArray([]),
                CInjurySeverity: ko.observableArray([]),
                TypeOfInjury: ko.observableArray([]),
                SuspectLocation: ko.observableArray([]),
                Dress: ko.observableArray([]),
                Sex: ko.observableArray([]),
                Resistances: ko.observableArray([]),
                Substance: ko.observableArray([]),
                PerceivedArmed: ko.observableArray([]),
                InjurySeverity: ko.observableArray([]),
                Race: ko.observableArray([]),
                SuspectArmed: ko.observableArray([]),
                ConfirmedArmed: ko.observableArray([]),
                SuspectList: ko.observableArray([]),
                SuspectLOC: ko.observableArray([]),
                ForceUsed: ko.observableArray([]),
                SuspectForceUsed: ko.observableArray([]),
                SecuritySource: ko.observableArray([]),
                SuspectEmployeeList: ko.observableArray([]),
                SHSource: ko.observableArray([]),
                ValidateOptions: ko.observable([
                                 { Name: 'Transient', Code: 'T' },
                                 { Name: 'Refuse', Code: 'F' },
                ]),
                PhoneMode: ko.observable([
                                { Name: 'Home', Code: 'Home' },
                                { Name: 'Work', Code: 'Work' },
                                { Name: 'Cell', Code: 'Cell' },
                                { Name: 'Transient', Code: 'Transient' },
                                { Name: 'Refuse', Code: 'Refuse' },
                                { Name: 'Emergency', Code: 'Emergency' },
                ]),
                Suspect: {
                    IsOnlySave: ko.observable(true),
                    Mode: ko.observable("Add"),
                    LoggedId: ko.observable(UoFParams.userId),
                    IncidentId: ko.observable(0),
                    BookingNumber: ko.observable(),
                    Armed: ko.observable(),
                    LastName: ko.observable(),
                    FirstName: ko.observable(),
                    MiddleName: ko.observable(),
                    Armed: ko.observable(),
                    AkaLastname: ko.observable(),
                    AkaFirstname: ko.observable(),
                    AkaMiddleName: ko.observable(),
                    TransorRefuse: ko.observable(),
                    Sex: ko.observable(),
                    Race: ko.observableArray([]),
                    Dress: ko.observable(),
                    Age: ko.observable(),
                    Height: ko.observable(),
                    Weight: ko.observable(),
                    Street: ko.observable(),
                    City: ko.observable(),
                    State: ko.observable(),
                    ZipCode: ko.observable(),
                    DateOfBirth: ko.observable(),
                    PrimaryPhno: ko.observable(),
                    SecondaryPhno: ko.observable(),
                    PhoneMode: ko.observable(),
                    SPhMode: ko.observable(),
                    PPhMode: ko.observable(),
                    PrimaryChargCode: ko.observable(),
                    SecondaryChargCode: ko.observable(),
                    CivilianResistance: ko.observable(),
                    Lifethreatening: ko.observable(),
                    Assulative: ko.observable(),
                    Perceivedarmed: ko.observable(),
                    CivilianConfirmedarmed: ko.observable(),
                    CivilianInjurySeverity: ko.observable(),
                    SuspectConfArmedOther: ko.observable(),
                    CivilianIn: ko.observable(), jurySeverity: ko.observable(),
                    forecasting: ko.observable(),
                    TypeofForce: ko.observableArray([]),
                    TypeOfInjury: ko.observableArray([]),
                    SafetyChairUsed: ko.observable("N"),
                    CriminalHistory: ko.observable(),
                    TreatedOnScene: ko.observable(false),
                    HospitalAdmission: ko.observable(false),
                    InmatePhysicallyAssaultive: ko.observable("N"),
                    InmateRecalcitrant: ko.observable("N"),
                    InmateonInmateViolenceProvoked: ko.observable("N"),
                    InmateonInmateViolence: ko.observable("N"),
                    MultiPointRestraintsUsed: ko.observable("N"),
                    OthertypesofRestraints: ko.observable("N"),
                    MedicalRecordschecked: ko.observable("N"),
                    MedicalRestraintsUsed: ko.observable("N"),
                    forceusedasDiscipline: ko.observable("N"),
                    CorporalPunishment: ko.observable("N"),
                    cellExtraction: ko.observable("N"),
                    Extractionordered: ko.observable("N"),
                    InmateHarassed: ko.observable("N"),
                    SuspectInterviewedAwayfromInmates: ko.observable("N"),
                    //SuspectPlannedForce: ko.observable(),
                    //OtherplannedUoF: ko.observable("N"),
                    UnderInfluence: ko.observable("N"),
                    Substance: ko.observable(),
                    factorinForce: ko.observable("N"),
                    SuspectLOC: ko.observableArray([]),
                    ForceUsed: ko.observableArray([]),
                    Interview: ko.observable(false),
                    InterviewDate: ko.observable(),
                    InterviewTime: ko.observable(),
                    Audiotape: ko.observable(),
                    Videotape: ko.observable(),
                    Photos: ko.observable(),
                    Announcements: ko.observable(),
                    Interview: ko.observable(false),
                    MentalHistory: ko.observable(),
                    CornerCase: ko.observable(),
                    IspregnantInmate: ko.observable("NA"),
                    SpecialHandle: ko.observableArray([]),
                    SecurityLevel: ko.observable(),
                },
                PlannedForceInfo: {
                    //Primary Agency
                    PFExtraction: ko.observable(),
                    PFPlannedUoF: ko.observable(),
                },
                HospitalInfo: {
                    RecdTreatmentAt: ko.observable(),
                    BY: ko.observable(),
                    HospitalAddress: ko.observable(),
                    HospitalPhone: ko.observable(),
                },
                TreatedInfo: {
                    TreatedName: ko.observable(),
                    TreatedUnit: ko.observable(),
                    TreatedPhone: ko.observable(),
                },
                Interview: {
                    Date: ko.observable(),
                    Time: ko.observable(),
                    Audiotape: ko.observable(),
                    Videotape: ko.observable(),
                    Photos: ko.observable(),
                    Announcements: ko.observable(),
                },
                getSuspectDetails: function () { uof.ui.Suspects.getSuspectDetails(); }
            },
            //load method, will be tirggered on document load
            load: function () {
                uof.ui.Suspects.bindMaskControl();
                uof.ui.Suspects.validateControls();
                if (uof.ui.incident.detail.selectedContext.selectedIncident() > 0)
                    uof.ui.Suspects.getSuspectInfo();

                uof.ui.Suspects.subscribeMethod();

                uof.ui.Suspects.listLoad();

                ////binding PlannedForce popup page
                //ko.cleanNode($("#divPlannedForce").get(0));
                //ko.applyBindings(uof.ui.Suspects.viewModel.PlannedForceInfo, $("#divPlannedForce").get(0));

                //binding Suspect popup page
                ko.cleanNode($("#SuspectInputs").get(0));
                ko.applyBindings(uof.ui.Suspects.viewModel, $("#SuspectInputs").get(0));
                
                if (uof.ui.incident.detail.viewModel.incident.currentMode() == 'view')
                {
                    $("#suspectRace").prop('disabled', true);
                    CivilianinjurySeverity
                    $("#CivilianinjurySeverity").prop('disabled', true);
                    $("#TypeOfInjury").prop('disabled', true);
                    $("#suspectLocationofForce").prop('disabled', true);
                    $("#SuspectLOF").prop('disabled', true);
                    $("#SuspectLOFB").prop('disabled', true);
                    $("#SpecialHandling").prop('disabled', true);                    
                }

                //ko.cleanNode($("#EmpSuspectView").get(0));
                // ko.applyBindings(uof.ui.Suspects.viewModel, $("#EmpSuspectView").get(0));

                uof.ui.Suspects.bindControlEvents();//
                uof.ui.Suspects.isFilesExist();

            },
            resetTreated: function () {
                uof.ui.Suspects.viewModel.TreatedInfo.TreatedName(null);
                uof.ui.Suspects.viewModel.TreatedInfo.TreatedUnit(null);
                uof.ui.Suspects.viewModel.TreatedInfo.TreatedPhone(null);
                $("#TreatedName").addClass("disabled");
                $("#TreatedUnit").addClass("disabled");
                $("#TreatedPhone").addClass("disabled");

            },
            resetHospital: function () {
                uof.ui.Suspects.viewModel.HospitalInfo.RecdTreatmentAt(null);
                uof.ui.Suspects.viewModel.HospitalInfo.BY(null);
                uof.ui.Suspects.viewModel.HospitalInfo.HospitalAddress(null);
                uof.ui.Suspects.viewModel.HospitalInfo.HospitalPhone(null);
                $("#TreatmentAt").addClass("disabled");
                $("#BY").addClass("disabled");
                $("#HospitalAddress").addClass("disabled");
                $("#HospitalPhone").addClass("disabled");
            },
            setIncidentProperties: function () {
                $("#divSuspectDeath *").prop('disabled', true);
                $("#CornerCase").prop('disabled', true);
                $("#TypeOfInjury").prop('disabled', true);
                $("#CivilianinjurySeverity").prop('disabled', true);
                if (uof.ui.incident.detail.viewModel.incident.IsSuspectInjury() == "Y") {
                    $("#TypeOfInjury").prop('disabled', false);

                    if(uof.ui.incident.detail.viewModel.incident.currentMode() == 'Edit')
                        $("#CivilianinjurySeverity").prop('disabled', false);
                }
            },

            removeAllFiles: function () {
                var arrFileName = [];
                $('[name^="chkfile_"]').each(function () {
                    if ($(this).is(':checked')) {
                        var idOfThisContext = $(this)[0].name.replace('chkfile_', '');
                        arrFileName.push({ FileName: $('#file_' + idOfThisContext).html(), SelectedFileType: $('#type_' + idOfThisContext).html() });
                    }
                });

                $.each(arrFileName, function (index, item) {
                    uof.ui.Suspects.DeleteUpload(item);
                });

                $('#suspectInterview').prop('checked', false);
                $('#removeAllCheckboxFiles').prop('checked', false);
            },

            allChecboxChecked: function () {
                $('[name^="chkfile_"]').each(function () {
                    if ($('#removeAllCheckboxFiles').is(':checked')) {
                        $(this).prop('checked', true);
                    } else {
                        $(this).prop('checked', false);
                    }
                });
            },

            checboxChecked: function () {
                var totalCount = 0;
                var chkCount = 0;
                $('[name^="chkfile_"]').each(function () {
                    totalCount += 1;
                });

                $('[name^="chkfile_"]').each(function () {
                    if ($(this).is(':checked')) {
                        chkCount += 1;
                    }
                });

                if (totalCount == chkCount) {
                    $('#removeAllCheckboxFiles').prop('checked', true);
                } else {
                    $('#removeAllCheckboxFiles').prop('checked', false);
                }
            },

            filterFiles: function () {
                $('#removeAllCheckboxFiles').prop('checked', false);
                var selectedValue = $('#filterOfFiles').val();
                var filterFiles = _.filter(uof.ui.Suspects.allInterviewFiles(), function (fName) {
                    return fName.SelectedFileType == selectedValue;
                });
                uof.ui.Suspects.selectedFiles([]);
                uof.ui.Suspects.selectedFiles.valueHasMutated();
                if (selectedValue == "all") {
                    uof.ui.Suspects.selectedFiles(uof.ui.Suspects.allInterviewFiles());
                } else {
                    uof.ui.Suspects.selectedFiles(filterFiles);
                }
                uof.ui.Suspects.selectedFiles.valueHasMutated();
            },


            getInterviewTypes: function () {
                $.ajax({
                    type: "GET",
                    url: "../FileUpload/GetInterviewType?bookingId=" + uof.ui.Suspects.viewModel.Suspect.BookingNumber(),
                    dataType: "json",
                    contentType: "application/json;charset=utf-8",
                    cache: false,
                    success: function (result) {
                        if (result != null && result != '') {
                            $.each(result, function (key, item) {
                                $('[name="grpType"]').each(function () {
                                    if ($(this).data('type') == key) {
                                        $(this).prop('checked', true);
                                        return;
                                    }
                                });
                            });
                        }
                        else {
                            $('[name="grpType"]').each(function () {
                                $(this).prop('checked', false);
                            });
                        }
                        $.prototype.hideUofOverlay();
                    },

                    error: function (e) {
                        $.prototype.hideUofOverlay();
                    },
                });
            },

            saveInterviewTypes: function () {
                var objContent = {};

                $('[name="grpType"]').each(function () {
                    if ($(this).is(':checked')) {
                        var propName = $(this).data('type');
                        if (propName == "Audiotape") {
                            objContent.Audiotape = "true";
                        } else if (propName == "Videotape") {
                            objContent.Videotape = "true";
                        } else {
                            objContent.PhotoesOfInjuries = "true";
                        }
                    }
                });

                $.ajax({
                    type: "POST",
                    url: "../FileUpload/SaveInterviewType",
                    dataType: "json",
                    contentType: "application/json;charset=utf-8",
                    data: JSON.stringify({ content: { InterviewType: objContent }, bookingId: uof.ui.Suspects.viewModel.Suspect.BookingNumber() }),
                    cache: false,
                    success: function (result) {
                        $('#suspectInterview').attr('checked', true);
                        $.prototype.hideUofOverlay();
                    },

                    error: function (e) {
                        $.prototype.hideUofOverlay();
                    },
                });
            },

            getAllFiles: function () {
                if (uof.ui.Suspects.allInterviewFiles().length == 0) {
                    if (uof.ui.Suspects.viewModel.Suspect.BookingNumber() != undefined && uof.ui.Suspects.viewModel.Suspect.BookingNumber().length > 0) {

                        $.prototype.showUofOverlay();
                        $.ajax({
                            type: "GET",
                            url: "../FileUpload/GetAllFiles?bookingId=" + uof.ui.Suspects.viewModel.Suspect.BookingNumber(),
                            dataType: "json",
                            contentType: "application/json;charset=utf-8",
                            cache: false,
                            success: function (result) {
                                if (result != 'NoData') {
                                    for (var i = 0; i < result.length; i++) {
                                        uof.ui.Suspects.selectedFiles.push(result[i]);
                                    }
                                    uof.ui.Suspects.selectedFiles.valueHasMutated();
                                    uof.ui.Suspects.allInterviewFiles([]);
                                    uof.ui.Suspects.allInterviewFiles(uof.ui.Suspects.selectedFiles());
                                }

                                $('[name="rdInterview"]').each(function () {
                                    if (uof.ui.Suspects.allInterviewFiles().length > 0 && $(this).val() == 'Y') {
                                        $(this).prop('checked', true);
                                    }
                                    else {
                                        $(this).prop('checked', false);
                                    }
                                });

                                $('[name="grpType"]').each(function () {
                                    $(this).click(function (element) {
                                        if (!$(this).is(':checked')) {
                                            var find = _.find(uof.ui.Suspects.allInterviewFiles(), function (item) {
                                                return (item.SelectedFileType == $($(element)[0].toElement).data('type'));
                                            });
                                            if (find !== undefined) {
                                                if (confirm("Are you sure you want to delete all associated files for selected type")) {
                                                    var arrFileName = [];
                                                    arrFileName = _.filter(uof.ui.Suspects.allInterviewFiles(), function (item) {
                                                        return (item.SelectedFileType == $($(element)[0].toElement).data('type'));
                                                    });

                                                    $.each(arrFileName, function (index, item) {
                                                        uof.ui.Suspects.DeleteUpload(item);
                                                    });
                                                }
                                                else {
                                                    $(this).prop('checked', true);
                                                }
                                            }
                                        }
                                    });

                                });

                                $.prototype.hideUofOverlay();
                            },

                            error: function (e) {
                                $.prototype.hideUofOverlay();
                            },
                        });

                        uof.ui.Suspects.getInterviewTypes();
                    }
                }
                else {
                    var uniqeValues = _.uniq(uof.ui.Suspects.allInterviewFiles(), function (item) {
                        return item.FileName;
                    });

                    uof.ui.Suspects.allInterviewFiles([]);
                    uof.ui.Suspects.allInterviewFiles(uniqeValues);
                    uof.ui.Suspects.selectedFiles([]);
                    uof.ui.Suspects.selectedFiles(uof.ui.Suspects.allInterviewFiles());
                    uof.ui.Suspects.selectedFiles.valueHasMutated();
                }

                $('[name="grpType"]').each(function () {
                    if (uof.ui.Suspects.viewModel.isEditMode()) {
                        $(this).prop('disabled', false);
                    }
                    else {
                        $(this).prop('disabled', true);
                    }

                });
            },


            DeleteUpload: function (fObject) {
                $.prototype.showUofOverlay();
                $.ajax({
                    type: "POST",
                    url: "../FileUpload/DeleteFile",
                    dataType: "json",
                    data: JSON.stringify({ fname: fObject.FileName, type: fObject.SelectedFileType, bookingId: uof.ui.Suspects.viewModel.Suspect.BookingNumber() }),
                    contentType: "application/json;charset=utf-8",
                    cache: false,
                    success: function (result) {
                        if (result) {
                            $('.progress-bar').css("width", "0%");
                            $('.file_name').html("");
                            var arrfiles = _.filter(uof.ui.Suspects.selectedFiles(), function (item) {
                                return item.FileName != fObject.FileName;
                            });
                            uof.ui.Suspects.selectedFiles(arrfiles);
                            uof.ui.Suspects.selectedFiles.valueHasMutated();

                            arrfiles = _.filter(uof.ui.Suspects.allInterviewFiles(), function (item) {
                                return item.FileName != fObject.FileName;
                            });

                            uof.ui.Suspects.allInterviewFiles([]);
                            uof.ui.Suspects.allInterviewFiles(arrfiles);
                            $('[name="grpType"]').each(function () {
                                var chkType = $(this);
                                var arrFileName;
                                arrFileName = _.find(uof.ui.Suspects.allInterviewFiles(), function (item) {
                                    return (item.SelectedFileType == $(chkType).data('type'));
                                });

                                if (arrFileName) {
                                    $(chkType).prop('checked', true);
                                }
                                else {
                                    $(chkType).prop('checked', false);
                                }
                            });

                            $('#removeAllCheckboxFiles').prop('checked', false);
                            $.prototype.hideUofOverlay();
                        }
                    },
                });
            },

            findFileType: function () {
                var ftype = $('#idOfFileType').val();
                if (ftype != "0" && uof.ui.Suspects.viewModel.isEditMode()) {

                    $('#fileupload').show();

                    if (ftype == 'Videotape') {
                        this.allowedFiles(this.allowedVideoFile.join(','));
                    }
                    else if (ftype == 'PhotoesOfInjuries') {
                        this.allowedFiles(this.allowedImageFile.join(','));
                    }
                    else {
                        this.allowedFiles(this.allowedAudioFile.join(','));
                    }
                    $("#fileupload").attr("accept", this.allowedFiles());
                    $('.progress-bar').css("width", "0%");

                }
            },

            validateFileType: function (fContainer) {
                var fileType = fContainer.files[0].type;
                if (fileType != undefined) {
                    var isFound = false;
                    $.each(fileType.split(','), function (i, item) {
                        isFound = _.find(uof.ui.Suspects.allowedFiles().split(','), function (child, j) {
                            return String(child).replace(' ', '') == String(item).replace(' ', '');
                        });

                        if (isFound == undefined) {
                            $('.progress-bar').css("width", "0%");
                            isFound = false;
                            return;
                        }
                    });
                    return isFound;
                }
                return false;
            },

            uploadAudioVideo: function (fContainer) {
                $('.file_name').html(fContainer.files[0].name);
                var selectedType = $('#idOfFileType').val();
                $('.progress-bar').css("width", "0%");
                if (this.validateFileType(fContainer)) {
                    $(fContainer).fileupload({
                        dataType: 'json',
                        url: '../FileUpload/UploadAudioVideoFile',
                        maxFileSize: 1000000,
                        formData: { bookingId: uof.ui.Suspects.viewModel.Suspect.BookingNumber(), selectedType: selectedType },
                        maxChunkSize: 1000000,
                        sequentialUploads: true,
                        beforeSend: function (jqXHR, settings) {
                            var isFound = _.find(uof.ui.Suspects.allowedImageFile, function (item) {
                                return item == settings.files[0].type
                            });
                            var totalFileCount = Math.round((settings.total / settings.maxChunkSize)) < (settings.total / settings.maxChunkSize)
                                                    ? (Math.round((settings.total / settings.maxChunkSize)) + 1) : Math.round((settings.total / settings.maxChunkSize));

                            if (isFound == undefined) {
                                var fName = settings.files[0].name + ".part_" + (settings.uploadedBytes / settings.maxChunkSize) +
                                    "." + totalFileCount;
                                jqXHR.setRequestHeader('X-Chunk-fname', fName);
                            }
                            else
                                jqXHR.setRequestHeader('X-Chunk-fname', settings.files[0].name);


                        },
                        done: function (e, data) {
                            var isDuplicate = _.find(uof.ui.Suspects.selectedFiles(), function (item) {
                                return (String(item.FileName).replace(' ', '') == String(data.result.name).replace(' ', ''));
                            });

                            if (isDuplicate == undefined) {
                                $('.file_name').html(data.result.name);
                                uof.ui.Suspects.selectedFiles.push({ FileName: data.result.name, SelectedFileType: selectedType });
                                uof.ui.Suspects.selectedFiles.valueHasMutated();
                                //  uof.ui.Suspects.allInterviewFiles.push({ FileName: data.result.name, SelectedFileType: selectedType });
                                uof.ui.Suspects.allInterviewFiles([]);
                                uof.ui.Suspects.allInterviewFiles(uof.ui.Suspects.selectedFiles());
                                $('[name="grpType"]').each(function () {
                                    var type = $(this).data('type');
                                    if (type == selectedType) {
                                        $(this).prop('checked', true);
                                    }
                                });
                            }
                            $('#suspectInterview').prop('checked', true);
                        }
                    }).on('fileuploadprogressall', function (e, data) {
                        var progress = parseInt(data.loaded / data.total * 100, 10);
                        $('.progress .progress-bar').css('width', progress + '%');
                    });
                }
            },

            getSuspectDetails: function (bookingNumber) {
                if (((bookingNumber != undefined) && (bookingNumber.length > 0))) {
                    if (!uof.ui.CommonUILogic.detail.validateDuplicate(suspectDataSource._data, uof.ui.Suspects.viewModel.Suspect.BookingNumber(), 2, uof.ui.Suspects.viewModel.Suspect.Mode())) {
                        uof.ui.Suspects.SuspectSHSource = uof.ui.Suspects.viewModel.SHSource;
                        var eventDate = uof.ui.CommonUILogic.detail.formatIncidentDateTime(UoFParams.IncidentDate);
                        $.prototype.showProgressBar("suspectInfo #Booking");
                        jQuery.ajax({
                            type: "GET",
                            url: InmateAPIUrl() + bookingNumber + "&eventDate=" + eventDate + "",
                            dataType: "json",
                            cache: false,
                            crossDomain: true,
                            processData: true,
                            success: function (inmateData) {
                                $.prototype.hideProgressBar("suspectInfo #Booking");
                                uof.ui.Suspects.viewModel.Suspect.Street(inmateData.Address);

                                uof.ui.Suspects.viewModel.Suspect.FirstName(inmateData.FirstName);
                                uof.ui.Suspects.viewModel.Suspect.LastName(inmateData.LastName);
                                uof.ui.Suspects.viewModel.Suspect.MiddleName(inmateData.MiddleName);
                                uof.ui.Suspects.viewModel.Suspect.AkaFirstname(inmateData.AkaFirstName);
                                uof.ui.Suspects.viewModel.Suspect.AkaLastname(inmateData.AkaLastName);
                                uof.ui.Suspects.viewModel.Suspect.AkaMiddleName(inmateData.AkaMiddleName);
                                uof.ui.Suspects.viewModel.Suspect.Height(inmateData.Height);
                                uof.ui.Suspects.viewModel.Suspect.Weight(inmateData.Weight);
                                uof.ui.Suspects.viewModel.Suspect.ZipCode(inmateData.ZipCode);
                                uof.ui.Suspects.viewModel.Suspect.Sex(inmateData.Sex);
                                uof.ui.Suspects.viewModel.Suspect.City(inmateData.City);
                                uof.ui.Suspects.toggoleInmatePrenant();
                                if (inmateData.DateOfBirth != null) {
                                    if (moment(inmateData.DateOfBirth).format("MM/DD/YYYY") != "01/01/0001") {
                                        uof.ui.Suspects.viewModel.Suspect.DateOfBirth(moment(inmateData.DateOfBirth).format("MM/DD/YYYY"));
                                        uof.ui.Suspects.viewModel.Suspect.Age(inmateData.Age);
                                    }
                                }
                                uof.ui.Suspects.viewModel.Suspect.PrimaryPhno(inmateData.Phone1);
                                uof.ui.Suspects.viewModel.Suspect.SecondaryPhno(inmateData.Phone2);
                                if (inmateData.BookingCharges != undefined && inmateData.BookingCharges != null) {
                                    var charges = inmateData.BookingCharges.split(';')
                                    var SCharges;
                                    if (charges.length > 0) {
                                        uof.ui.Suspects.viewModel.Suspect.PrimaryChargCode(charges[0]);
                                        if (charges[1] != null)
                                            uof.ui.Suspects.viewModel.Suspect.SecondaryChargCode(charges[1]);
                                    }
                                }
                                //uof.ui.Suspects.viewModel.Suspect.Race(inmateData.Race);
                                uof.ui.Suspects.viewModel.Suspect.State(inmateData.State);

                                if (inmateData.Race != null) {
                                    $("#suspectRace").selectpicker('destroy');
                                    $("[data-id='suspectRace']").remove();
                                    uof.ui.Suspects.viewModel.Suspect.Race([]);
                                    uof.ui.Suspects.viewModel.Suspect.Race.push(inmateData.Race);
                                    $('#suspectRace').selectpicker('render');
                                }
                                else {
                                    $("#suspectRace").selectpicker('destroy');
                                    $("[data-id='suspectRace']").remove();
                                    uof.ui.Suspects.viewModel.Suspect.Race([]);
                                    $('#suspectRace').selectpicker('render');
                                }


                                if (inmateData.SecurityLevel != null) {
                                    uof.ui.Suspects.viewModel.Suspect.SecurityLevel(inmateData.SecurityLevel);
                                }
                                if (inmateData.SpecialHandle != null) {
                                    $('#SpecialHandling').selectpicker('destroy');
                                    if (uof.ui.Suspects.viewModel.SHSource.length == 0)
                                        uof.ui.Suspects.viewModel.SHSource = ko.observableArray(uof.ui.Suspects.SuspectSHSource());
                                    //$("#SpecialHandling").selectpicker('destroy');
                                    //uof.ui.Suspects.viewModel.Suspect.SpecialHandle([]);
                                    //uof.ui.Suspects.viewModel.Suspect.SpecialHandle.push(inmateData.SpecialHandle);
                                    uof.ui.Suspects.viewModel.Suspect.SpecialHandle = ko.observableArray(inmateData.SpecialHandle.split(';'));

                                    $("#SuspectLOF").selectpicker('destroy');
                                    $('#SuspectLOFB').selectpicker('destroy');
                                    $('#TypeOfInjury').selectpicker('destroy');
                                    $('#suspectLocationofForce').selectpicker('destroy');
                                    //$('#CivilianinjurySeverity').selectpicker('destroy');
                                    uof.ui.Suspects.validateControls();
                                    ko.cleanNode($("#SuspectInputs").get(0));
                                    ko.applyBindings(uof.ui.Suspects.viewModel, $("#SuspectInputs").get(0));
                                    uof.ui.Suspects.bindControlEvents();
                                    $('#SpecialHandling').selectpicker('refresh');
                                    uof.ui.Suspects.viewModel.Suspect.CivilianInjurySeverity();
                                    uof.ui.Suspects.viewModel.Suspect.ForceUsed([]);
                                    uof.ui.Suspects.viewModel.Suspect.SuspectLOC([]);
                                    uof.ui.Suspects.viewModel.Suspect.TypeOfInjury([]);
                                    uof.ui.Suspects.viewModel.Suspect.TypeofForce([]);

                                    //$('#CivilianinjurySeverity').selectpicker('refresh');
                                    $('#SuspectLOFB').selectpicker('refresh');
                                    $('#TypeOfInjury').selectpicker('refresh');
                                    $("#SuspectLOF").selectpicker('refresh');
                                    $('#suspectLocationofForce').selectpicker('refresh');
                                }
                                uof.ui.Suspects.isFilesExist();
                            },
                            error: function (XMLHttpRequest, textStatus, errorThrown) {
                                $.prototype.hideProgressBar("suspectInfo #Booking");
                                showAlert("Error while getting the Suspect Data");
                            }
                        });
                    }
                    else
                        showAlert("Suspect already Exists");
                }
            },

            resetMultiSelects: function () {

                uof.ui.Suspects.viewModel.Suspect.CivilianInjurySeverity();
                uof.ui.Suspects.viewModel.Suspect.ForceUsed([]);
                uof.ui.Suspects.viewModel.Suspect.SuspectLOC([]);
                uof.ui.Suspects.viewModel.Suspect.TypeOfInjury([]);
                uof.ui.Suspects.viewModel.Suspect.TypeofForce([]);

                $('#SpecialHandling').selectpicker('refresh');
                //$('#CivilianinjurySeverity').selectpicker('refresh');
                $('#SuspectLOFB').selectpicker('refresh');
                $('#TypeOfInjury').selectpicker('refresh');
                $("#SuspectLOF").selectpicker('refresh');
                $('#suspectLocationofForce').selectpicker('refresh');

            },
            isFilesExist: function () {
                uof.ui.Suspects.allInterviewFiles([]);
                uof.ui.Suspects.selectedFiles([]);
                uof.ui.Suspects.selectedFiles.valueHasMutated();
                if (uof.ui.Suspects.viewModel.Suspect.BookingNumber() != undefined && uof.ui.Suspects.viewModel.Suspect.BookingNumber().length > 0) {
                    $.prototype.showUofOverlay();
                    $.ajax({
                        type: "GET",
                        url: "../FileUpload/isFilesExist?bookingId=" + uof.ui.Suspects.viewModel.Suspect.BookingNumber(),
                        dataType: "json",
                        contentType: "application/json;charset=utf-8",
                        cache: false,
                        success: function (result) {
                            $($('[name="rdInterview"]')[1]).prop('checked', true);
                            if (result) {
                                $($('[name="rdInterview"]')[0]).prop('checked', true);
                            }

                            $.prototype.hideUofOverlay();
                        },

                        error: function (e) {
                            $($('[name="rdInterview"]')[1]).prop('checked', true);
                            $.prototype.hideUofOverlay();
                        },
                    });
                }
            },

            ShowInterview: function () {

                if (uof.ui.Suspects.viewModel.Suspect.BookingNumber() != undefined && uof.ui.Suspects.viewModel.Suspect.BookingNumber().length > 0) {
                    this.selectedFiles([]);
                    if ($("#suspectInterview").is(":checked")) {
                        uof.ui.Suspects.viewModel.Suspect.Interview(true);
                        ko.cleanNode($("#divSuspectInterview").get(0));
                        ko.applyBindings(uof.ui.Suspects, $("#divSuspectInterview").get(0));
                        $("#fileupload").fileupload();
                        uof.ui.Suspects.showModalPopup("divSuspectInterview", 1000);
                        setTimeout(function () { $("#suspectInterview").focus(); }, 100);
                        uof.ui.Suspects.getAllFiles();
                        uof.ui.Suspects.bindControlEvents();//
                        $('#fileupload').hide();
                        $('#idOfFileType').val(0);
                    }
                    else
                        uof.ui.Suspects.viewModel.Suspect.Interview(false);
                }
                else {
                    showAlert("Booking number is missing.");
                }
            },

            refreshInterviewPage: function () {
                this.selectedFiles([]);
                $("#rdFileOptions").find("input:radio").prop("checked", false);
                $('.progress-bar').css("width", "0%");
                $('.file_name').html("");
            },

            InterviewInfoClose: function () {
                this.refreshInterviewPage();
                // $('#suspectInterview').attr('checked', false);
                uof.ui.Suspects.viewModel.Suspect.Interview(false);
                uof.ui.Suspects.hideModalPopup("divSuspectInterview");
                setTimeout(function () { $("#suspectInterview").focus(); }, 100);
            },
            InterviewInfoSubmit: function () {
                this.refreshInterviewPage();
                result = ko.validation.group(uof.ui.Suspects.viewModel.Interview, { deep: true });
                if (result().length > 0) {
                    uof.ui.Suspects.viewModel.Interview.Date.valueHasMutated();
                    uof.ui.Suspects.viewModel.Interview.Time.valueHasMutated();
                    return false;
                }
                uof.ui.Suspects.hideModalPopup("divSuspectInterview");
                uof.ui.Suspects.saveInterviewTypes();
            },
            getSuspectInfo: function () {
                $.prototype.showUofOverlay();
                $.ajax(
                    {
                        url: window.location.uofAPIOrigin() + '/api/Lookup/GetAllLookupInformationforSuspect',
                        cache: false,
                        type: "GET",
                        dataType: 'json',
                        contentType: "application/json;charset=utf-8",
                        beforeSend: function myfunction() {

                        },
                        success: function (suspectData) {
                            if (suspectData != null) {
                                //if (suspectData.DressInfo != null) {
                                //    var tempDress = [];
                                //    $.map(suspectData.DressInfo, function (n, i) {
                                //        if (n.Name != "Patrol Uniform")
                                //            tempDress.push(n);
                                //    });
                                //    var obj = new uof.ui.Suspects.picklistObject("IU", "Inmate Uniform");
                                //    tempDress.push(obj);
                                //    uof.ui.Suspects.viewModel.Dress(tempDress);
                                //}
                                uof.ui.Suspects.viewModel.Dress(suspectData.DressInfo);
                                uof.ui.Suspects.viewModel.SuspectArmed(suspectData.ArmedInfo);
                                uof.ui.Suspects.viewModel.Race([]);
                                uof.ui.Suspects.viewModel.Race(suspectData.RacesInfo);
                                RaceSource = uof.ui.Suspects.viewModel.Race();
                                //uof.ui.Suspects.viewModel.Race.valueHasMutated();
                                //$.each(suspectData.CivilianInjurySeverityInfo, function (index, data) {
                                //    uof.ui.Suspects.viewModel.CInjurySeverity.push(data);
                                //});
                                uof.ui.Suspects.viewModel.CInjurySeverity(suspectData.CivilianInjurySeverityInfo);
                                uof.ui.Suspects.getAllInjuries(suspectData.InjuriesInfo)
                                uof.ui.Suspects.viewModel.Resistances(suspectData.ResistanceInfo);
                                uof.ui.Suspects.viewModel.PerceivedArmed(suspectData.PerceivedArmedInfo);
                                uof.ui.Suspects.viewModel.SuspectLOC(suspectData.SuspectLocationofForceInfo);
                                uof.ui.Suspects.viewModel.SuspectForceUsed(suspectData.LocationofForceInfo);
                                uof.ui.Suspects.viewModel.ConfirmedArmed(suspectData.ArmedInfo);
                                uof.ui.Suspects.viewModel.Substance(suspectData.SubstanceInfo);
                                uof.ui.Suspects.viewModel.Sex(suspectData.GenderInfo);
                                uof.ui.Suspects.getAllMethods(suspectData.MethodsInfo);

                                if (suspectData.SecurityInfo != null) {
                                    var tempSecurity = [];
                                    var source = suspectData.SecurityInfo;
                                    $.each(source, function (index, data) {
                                        var name = data.Code + "(" + data.Name + ")";
                                        var obj = new uof.ui.Suspects.picklistObject(data.Code, name);
                                        tempSecurity.push(obj);
                                    });
                                    uof.ui.Suspects.viewModel.SecuritySource(tempSecurity);
                                }
                                if (suspectData.SpecialHandleInfo != null) {
                                    var tempSH = [];
                                    var source = suspectData.SpecialHandleInfo;
                                    $.each(source, function (index, data) {
                                        var name = data.Code + "(" + data.Name + ")";
                                        var obj = new uof.ui.Suspects.picklistObject(data.Code, name);
                                        tempSH.push(obj);
                                    });
                                    uof.ui.Suspects.viewModel.SHSource(tempSH);
                                }
                                $("#SuspectLOF").selectpicker('refresh');
                                $('#suspectRace').selectpicker('refresh');
                                $('#SuspectLOFB').selectpicker('refresh');
                                $('#TypeOfInjury').selectpicker('refresh');
                                $('#suspectLocationofForce').selectpicker('refresh');
                                $('#SpecialHandling').selectpicker('refresh');
                                //$('#CivilianinjurySeverity').selectpicker('refresh');
                                if (uof.ui.incident.detail.selectedContext.selectedIncident() > 0) {
                                    uof.ui.Suspects.viewModel.Suspect.IncidentId = uof.ui.incident.detail.selectedContext.selectedIncident();
                                    // Set All Edit mode values here
                                    if ((uof.ui.incident.detail.viewModel.incident.currentMode() == 'Edit')) {
                                        uof.ui.Suspects.viewModel.isEditMode(true);
                                        uof.ui.Suspects.SetFormControls(false);
                                    }
                                    else if ((uof.ui.incident.detail.viewModel.incident.currentMode() == 'view')) {
                                        uof.ui.Suspects.viewModel.isEditMode(false);
                                        uof.ui.Suspects.SetFormControls(true);
                                    }
                                    uof.ui.Suspects.bindSuspectData();
                                    $("#Substance").prop('disabled', true);
                                }
                            }
                            $.prototype.hideUofOverlay();
                        },
                        error: function (e) {
                            $.prototype.hideUofOverlay();
                            showAlert("Error loading Data - Suspect");
                        },
                    });
            },

            getAllMethods: function (lookupData) {

                uof.ui.Suspects.viewModel.TypeOfForce(lookupData)
                var obj = new uof.ui.Suspects.picklistObject("AN", "Animal");
                uof.ui.Suspects.viewModel.TypeOfForce.push(obj);
                var obj = new uof.ui.Suspects.picklistObject("KN", "Knife");
                uof.ui.Suspects.viewModel.TypeOfForce.push(obj);
                var obj = new uof.ui.Suspects.picklistObject("BS", "Blade or stabbing agent");
                uof.ui.Suspects.viewModel.TypeOfForce.push(obj);
                var obj = new uof.ui.Suspects.picklistObject("K9", "K-9 Contact");
                uof.ui.Suspects.viewModel.TypeOfForce.push(obj);
                var obj = new uof.ui.Suspects.picklistObject("NN", "None");
                uof.ui.Suspects.viewModel.TypeOfForce.push(obj);
            },
            SetFormControls: function (isDisable) {
                $("#SuspectInputs").find('input, select, textarea, button').each(function () {
                    if ($(this).hasClass("multi-selectpicker") || $(this).hasClass("dropdown-toggle")) {
                        $(this).attr('readOnly', isDisable);
                    }
                    else {
                        if (($(this).attr("id") != "suspectInterview") && ($(this).attr("id") != "TreatedOnScene")
                            && ($(this).attr("id") != "HospitalAdmission")) {
                            $(this).attr('disabled', isDisable);
                        }
                    }
                });
                // $(div).find('input:text, input:password, input:file, select, textarea')
            },
            getAllInjuries: function (injuryData) {
                $.each(injuryData, function (index, data) {
                    if (data.Type == "C" || data.Type == "B") {
                        uof.ui.Suspects.viewModel.InjurySeverity.push(data);
                    }
                    if (data.Type == "B") {
                        uof.ui.Suspects.viewModel.TypeOfInjury.push(data);
                    }

                });
                var obj = new uof.ui.Suspects.picklistObject("OD", "Obvious Disfigurement");
                uof.ui.Suspects.viewModel.TypeOfInjury.push(obj);
                var obj = new uof.ui.Suspects.picklistObject("SW", "Stabbing wound");
                uof.ui.Suspects.viewModel.TypeOfInjury.push(obj);
                var obj = new uof.ui.Suspects.picklistObject("NN", "None");
                uof.ui.Suspects.viewModel.TypeOfInjury.push(obj);
            },


            //getTypeOfInjury: function () {
            //    $.prototype.showUofOverlay();
            //    $.ajax(
            //    {
            //        url:window.location.uofAPIOrigin() + '/api/Lookup/GetAllInjuries',
            //        cache: false,
            //        type: "GET",
            //        dataType: 'json',
            //        contentType: "application/json;charset=utf-8",
            //        beforeSend: function myfunction() {

            //        },
            //        success: function (lookupData) {
            //            uof.ui.Suspects.viewModel.TypeOfInjury(lookupData);
            //            $.prototype.hideUofOverlay();
            //        },
            //        error: function (e) {
            //            showAlert(e.responseText);
            //        },
            //    });
            //},
            //getTypeOfForceCivilian: function () {
            //    $.prototype.showUofOverlay();
            //    $.ajax(
            //    {
            //        url:window.location.uofAPIOrigin() + '/api/Lookup/GetAllInjuries',
            //        data: 'type=C',
            //        cache: false,
            //        type: "GET",
            //        dataType: 'json',
            //        contentType: "application/json;charset=utf-8",
            //        beforeSend: function myfunction() {

            //        },
            //        success: function (lookupData) {
            //            uof.ui.Suspects.viewModel.TypeOfForceCivilian(lookupData);
            //            $.prototype.hideUofOverlay();
            //        },
            //        error: function (e) {
            //            showAlert(e.responseText);
            //        },
            //    });
            //},


            bindMaskControl: function () {
                ko.bindingHandlers.inputmask =
                {
                    init: function (element, valueAccessor, allBindingsAccessor) {

                        var mask = valueAccessor();

                        var observable = mask.value;

                        if (ko.isObservable(observable)) {

                            $(element).on('focusout change', function () {

                                if ($(element).inputmask('isComplete')) {
                                    observable($(element).val());
                                }
                                else {
                                    observable(null);
                                }

                            });
                        }

                        $(element).inputmask(mask);


                    },
                    update: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
                        var mask = valueAccessor();

                        var observable = mask.value;

                        if (ko.isObservable(observable)) {

                            var valuetoWrite = observable();

                            $(element).val(valuetoWrite);
                        }
                    }

                };
            },

            bindControlEvents: function () {
                $('#CivilianResistance').change(function () {
                    var selected = $('#CivilianResistance option:selected').val();
                    $("#divSuspectAssulative *").prop('disabled', true);
                    if (selected == "ASL") {
                        $("#divSuspectAssulative").removeClass("hide");
                        $("#divSuspectLifethreatening").addClass("hide");
                        $("#divSuspectAssulative *").prop('disabled', false);
                        setTimeout(function () { $("#chksAssulativeYes").focus(); }, 100);
                    }
                    else if (selected == "LT") {
                        $("#divSuspectLifethreatening").removeClass("hide");
                        $("#divSuspectAssulative").addClass("hide");
                        $("#divSuspectAssulative *").prop('disabled', true);
                        $("#divSuspectLifethreatening").prop('disabled', false);
                        setTimeout(function () { $("#chksLifethreateningYes").focus(); }, 100);
                    }
                    else {
                        $("#divSuspectAssulative *").prop('disabled', true);
                        $("#divSuspectLifethreatening").addClass("hide");
                        $("#divSuspectAssulative").removeClass("hide");
                    }

                });
                $('#CivilianinjurySeverity').change(function () {
                    $("#divSuspectDeath *").prop('disabled', true);
                    $("#CornerCase").attr("disabled", true);
                    var selected = $('#CivilianinjurySeverity').val();
                    if (selected != undefined && selected == "DH") {
                        $("#divSuspectDeath *").prop('disabled', false);
                        setTimeout(function () { $("#chkforeCasting").focus(); }, 100);
                        $("#CornerCase").attr("disabled", false);
                    }


                });
                $("#divSuspectDeath *").prop('disabled', true);
                $("#divSuspectAssulative *").prop('disabled', true);

                $('#SDOB').datetimepicker({ format: 'MM/DD/YYYY' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.Suspects.viewModel.Suspect.DateOfBirth(newDate);
                    uof.ui.Suspects.viewModel.Suspect.Age(uof.ui.CommonUILogic.detail.agefinding(newDate));
                });

                $('#InterviewDate').datetimepicker({ format: 'MM/DD/YYYY' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.Suspects.viewModel.Suspect.InterviewDate(newDate);
                });
                $(".timepicker").timepicker({
                    showInputs: false,
                    showMeridian: false,
                    minuteStep: 1
                });
                $('#SuspectIntTime').on('keydown', function (e) {
                    if (e.keyCode == 9) {
                        $(this).timepicker('hideWidget');
                    }
                });
            },
            fillAge: function (changeddate) {
                uof.ui.Suspects.viewModel.Suspect.Age(uof.ui.CommonUILogic.detail.agefinding(changeddate));
            },
            // Generic method to open the popup page
            showModalPopup: function (IdOfdiv, intervalTime) {
                if (intervalTime == undefined)
                    intervalTime = 100;
                $('#' + IdOfdiv).show();
                $('#' + IdOfdiv).modal({
                    keyboard: true
                }).promise().done(function () {
                    setTimeout(function () {
                        if ($("#" + IdOfdiv).is(":visible"))
                            $("#" + IdOfdiv).focus();
                    }, intervalTime);
                });

            },


            showTreatedOnScene: function () {
                if ($("#TreatedOnScene").is(":checked")) {
                    uof.ui.Suspects.validateTreatedControls();
                    uof.ui.Suspects.viewModel.Suspect.TreatedOnScene("Y");
                    //binding Treated popup page
                    ko.cleanNode($("#divTreated").get(0));
                    ko.applyBindings(uof.ui.Suspects.viewModel.TreatedInfo, $("#divTreated").get(0));
                    uof.ui.Suspects.showModalPopup("divTreated", 1000);
                }
                else
                    uof.ui.Suspects.viewModel.Suspect.TreatedOnScene("N");
            },

            showPlannedForce: function () {
                // if ($("#chkPlannedForce").is(":checked"))
                if ($("#plannedForce").is(":checked")) {
                    uof.ui.Suspects.validatePFControls();
                    uof.ui.Suspects.viewModel.Suspect.SuspectPlannedForce("Y");
                    uof.ui.Suspects.showModalPopup("divPlannedForce", 100);
                }
                else
                    uof.ui.Suspects.viewModel.Suspect.SuspectPlannedForce("N");
            },
            showHospitalAdmission: function () {
                if ($("#HospitalAdmission").is(":checked")) {
                    uof.ui.Suspects.validateHosptControls();
                    uof.ui.Suspects.viewModel.Suspect.HospitalAdmission("Y");
                    //binding Hospital Admission popup page
                    ko.cleanNode($("#divHospital").get(0));
                    ko.applyBindings(uof.ui.Suspects.viewModel.HospitalInfo, $("#divHospital").get(0));
                    uof.ui.Suspects.showModalPopup("divHospital", 100);
                }
                else
                    uof.ui.Suspects.viewModel.Suspect.HospitalAdmission("N");
            },

            //Validate the controls on Add and duplicate popup
            validateControls: function () {
                //remove old validation
                $("#suspectInfo .validationMessage").each(function () {
                    $(this).remove();
                });

                $("#suspectInfo .warning-msg").each(function () {
                    $(this).remove();
                });

                //Validate the controls on Add and duplicate popup
                uof.ui.Suspects.viewModel.Suspect.BookingNumber.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required,
                        validation: {
                            validator: uof.ui.CommonUILogic.detail.lengthValidation,
                            message: "Bookin Number should be 7 character length",
                            params: [7]
                        },
                    },
                });

                //uof.ui.Suspects.viewModel.Suspect.Armed.extend({
                //    required: {
                //        params: true,
                //        message: IncidentConstants.Required
                //    },
                //});

                uof.ui.Suspects.viewModel.Suspect.Sex.extend({
                    required: {
                        params: true,
                        message: "Sex " + IncidentConstants.Required
                    },
                });
                uof.ui.Suspects.viewModel.Suspect.Race.extend({
                    required: {
                        params: true,
                        message: "Race " + IncidentConstants.Required
                    },
                });
                //uof.ui.Suspects.viewModel.Suspect.TransorRefuse.extend({
                //    required: {
                //        params: true,
                //        message: IncidentConstants.Required
                //    },
                //});

                uof.ui.Suspects.viewModel.Suspect.ZipCode.extend({
                    required: {
                        params: true,
                        message: "ZipCode " + IncidentConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.Suspects.viewModel.Suspect.TransorRefuse() === "T");
                        }
                    },
                });
                //uof.ui.Suspects.viewModel.Suspect.Street.extend({
                //    required: {
                //        params: true,
                //        message: IncidentConstants.Required,
                //        onlyIf: function () {
                //            return (uof.ui.Suspects.viewModel.Suspect.TransorRefuse() === "T");
                //        }
                //    },
                //});

                uof.ui.Suspects.viewModel.Suspect.State.extend({
                    required: {
                        params: true,
                        message: "State " + IncidentConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.Suspects.viewModel.Suspect.TransorRefuse() === "T");
                        }
                    },
                });
                uof.ui.Suspects.viewModel.Suspect.City.extend({
                    required: {
                        params: true,
                        message: "City " + IncidentConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.Suspects.viewModel.Suspect.TransorRefuse() === "T");
                        }
                    },
                });
                uof.ui.Suspects.viewModel.Suspect.PrimaryChargCode.extend({
                    required: {
                        params: true,
                        message: "PrimaryChargCode " + IncidentConstants.Required
                    },
                });
                //uof.ui.Suspects.viewModel.Suspect.SecondaryChargCode.extend({
                //    required: {
                //        params: true,
                //        message: "A7" + IncidentConstants.Required
                //    },
                //});
                uof.ui.Suspects.viewModel.Suspect.TypeOfInjury.extend({
                    required: {
                        params: true,
                        message: "TypeOfInjury " + IncidentConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.incident.detail.viewModel.incident.IsSuspectInjury() == "Y");
                        }
                    },
                });
                uof.ui.Suspects.viewModel.Suspect.InmateRecalcitrant.extend({
                    required: {
                        params: true,
                        message: "InmateRecalcitrant " + IncidentConstants.Required
                    },
                });
                uof.ui.Suspects.viewModel.Suspect.Height.extend({
                    required: {
                        params: true,
                        message: "Height " + IncidentConstants.Required
                    },
                });
                uof.ui.Suspects.viewModel.Suspect.Weight.extend({
                    required: {
                        params: true,
                        message: "Weight " + IncidentConstants.Required
                    },
                });

                uof.ui.Suspects.viewModel.Suspect.Age.extend({
                    required: {
                        params: true,
                        message: "Age " + IncidentConstants.Required
                    },
                });

                uof.ui.Suspects.viewModel.Suspect.DateOfBirth.extend({
                    required: {
                        params: true,
                        message: "DateOfBirth " + IncidentConstants.Required
                    },
                });
                uof.ui.Suspects.viewModel.Suspect.PrimaryPhno.extend({
                    required: {
                        params: true,
                        message: "PrimaryPhno " + IncidentConstants.Required
                    },
                });
                //uof.ui.Suspects.viewModel.Suspect.SecondaryPhno.extend({
                //    validation: {
                //        validator: uof.ui.CommonUILogic.detail.lengthValidation,
                //        message: "Phone Number should be 10 character length",
                //        params: [10]
                //    },
                //});


                //uof.ui.Suspects.viewModel.Suspect.CriminalHistory.extend({
                //    required: {
                //        params: true,
                //        message: IncidentConstants.Required
                //    },
                //});
                uof.ui.Suspects.viewModel.Suspect.CivilianResistance.extend({
                    required: {
                        params: true,
                        message: "CivilianResistance " + IncidentConstants.Required
                    },
                });
                uof.ui.Suspects.viewModel.Suspect.CivilianResistance.extend({
                    required: {
                        params: true,
                        message: "CivilianResistance " + IncidentConstants.Required
                    },
                });

                uof.ui.Suspects.viewModel.Suspect.Perceivedarmed.extend({
                    required: {
                        params: true,
                        message: "Perceivedarmed " + IncidentConstants.Required
                    },
                });
                //uof.ui.Suspects.viewModel.Suspect.Dress.extend({
                //    required: {
                //        params: true,
                //        message: IncidentConstants.Required
                //    },
                //});
                uof.ui.Suspects.viewModel.Suspect.CivilianConfirmedarmed.extend({
                    required: {
                        params: true,
                        message: "CivilianConfirmedarmed " + IncidentConstants.Required
                    },
                });

                uof.ui.Suspects.viewModel.Suspect.SuspectConfArmedOther.extend({
                    required: {
                        params: true,
                        message: "SuspectConfArmedOther" + IncidentConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.Suspects.viewModel.Suspect.CivilianConfirmedarmed() === "ODW");
                        }
                    },
                });
                uof.ui.Suspects.viewModel.Suspect.CivilianInjurySeverity.extend({
                    required: {
                        params: true,
                        message: "CivilianInjurySeverity " + IncidentConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.incident.detail.viewModel.incident.IsSuspectInjury() == "Y");
                        }
                    },
                });

                uof.ui.Suspects.viewModel.Suspect.TypeofForce.extend({
                    required: {
                        params: true,
                        message: "TypeofForce " + IncidentConstants.Required
                    },
                });
                // uof.ui.Suspects.viewModel.Suspect.LocationOfForce.extend({
                //    required: {
                //        params: true,
                //        message: IncidentConstants.Required
                //    },
                //});
                //Radio
                uof.ui.Suspects.viewModel.Suspect.SafetyChairUsed.extend({
                    required: {
                        params: true,
                        message: "SafetyChairUsed " + IncidentConstants.Required
                    },
                });
                uof.ui.Suspects.viewModel.Suspect.SuspectInterviewedAwayfromInmates.extend({
                    required: {
                        params: true,
                        message: "SuspectInterviewedAwayfromInmates " + IncidentConstants.Required
                    },
                });
                uof.ui.Suspects.viewModel.Suspect.forceusedasDiscipline.extend({
                    required: {
                        params: true,
                        message: "forceusedasDiscipline " + IncidentConstants.Required
                    },
                });
                uof.ui.Suspects.viewModel.Suspect.ForceUsed.extend({
                    required: {
                        params: true,
                        message: "ForceUsed " + IncidentConstants.Required
                    },
                });

                uof.ui.Suspects.viewModel.Suspect.MultiPointRestraintsUsed.extend({
                    required: {
                        params: true,
                        message: "MultiPointRestraintsUsed " + IncidentConstants.Required
                    },
                });

                uof.ui.Suspects.viewModel.Suspect.InmatePhysicallyAssaultive.extend({
                    required: {
                        params: true,
                        message: "InmatePhysicallyAssaultive " + IncidentConstants.Required
                    },
                });

                //uof.ui.Suspects.viewModel.Suspect.OtherplannedUoF.extend({
                //    required: {
                //        params: true,
                //        message:  IncidentConstants.Required
                //    },
                //});

                uof.ui.Suspects.viewModel.Suspect.Extractionordered.extend({
                    required: {
                        params: true,
                        message: "Extractionordered " + IncidentConstants.Required
                    },
                });

                uof.ui.Suspects.viewModel.Suspect.InmateHarassed.extend({
                    required: {
                        params: true,
                        message: "InmateHarassed " + IncidentConstants.Required
                    },
                });

                uof.ui.Suspects.viewModel.Suspect.MedicalRestraintsUsed.extend({
                    required: {
                        params: true,
                        message: "MedicalRestraintsUsed  " + IncidentConstants.Required
                    },
                });

                uof.ui.Suspects.viewModel.Suspect.InmateonInmateViolence.extend({
                    required: {
                        params: true,
                        message: "InmateonInmateViolence " + IncidentConstants.Required
                    },
                });

                uof.ui.Suspects.viewModel.Suspect.cellExtraction.extend({
                    required: {
                        params: true,
                        message: "cellExtraction " + IncidentConstants.Required
                    },
                });
                uof.ui.Suspects.viewModel.Suspect.MedicalRecordschecked.extend({
                    required: {
                        params: true,
                        message: "MedicalRecordschecked " + IncidentConstants.Required
                    },
                });
                uof.ui.Suspects.viewModel.Suspect.InmateonInmateViolenceProvoked.extend({
                    required: {
                        params: true,
                        message: "InmateonInmateViolenceProvoked " + IncidentConstants.Required
                    },
                });
                uof.ui.Suspects.viewModel.Suspect.InmateRecalcitrant.extend({
                    required: {
                        params: true,
                        message: "InmateRecalcitrant " + IncidentConstants.Required
                    },
                });
                uof.ui.Suspects.viewModel.Suspect.OthertypesofRestraints.extend({
                    required: {
                        params: true,
                        message: "OthertypesofRestraints " + IncidentConstants.Required
                    },
                });
                uof.ui.Suspects.viewModel.Suspect.CorporalPunishment.extend({
                    required: {
                        params: true,
                        message: "CorporalPunishment " + IncidentConstants.Required
                    },
                });

                uof.ui.Suspects.viewModel.Suspect.CornerCase.extend({
                    required: {
                        params: true,
                        message: "CornerCase " + IncidentConstants.Required,
                        onlyIf: function () {
                            if (uof.ui.Suspects.viewModel.Suspect.CivilianInjurySeverity() != null && uof.ui.Suspects.viewModel.Suspect.CivilianInjurySeverity() != "") {
                                return uof.ui.Suspects.viewModel.Suspect.CivilianInjurySeverity() == "DH"
                            }
                        }
                    },
                });
                uof.ui.Suspects.viewModel.TreatedInfo.TreatedName.extend({
                    required: {
                        params: true,
                        message: "TreatedName " + IncidentConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.Suspects.viewModel.Suspect.TreatedOnScene());
                        }
                    },
                });
                uof.ui.Suspects.viewModel.TreatedInfo.TreatedUnit.extend({
                    required: {
                        params: true,
                        message: "TreatedUnit " + IncidentConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.Suspects.viewModel.Suspect.TreatedOnScene());
                        }
                    },
                });
                uof.ui.Suspects.viewModel.TreatedInfo.TreatedPhone.extend({
                    required: {
                        params: true,
                        message: "TreatedPhone " + IncidentConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.Suspects.viewModel.Suspect.TreatedOnScene());
                        }
                    },
                });
                uof.ui.Suspects.viewModel.HospitalInfo.HospitalAddress.extend({
                    required: {
                        params: true,
                        message: "HospitalAddress " + IncidentConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.Suspects.viewModel.Suspect.HospitalAdmission());
                        }
                    },
                });
                uof.ui.Suspects.viewModel.HospitalInfo.RecdTreatmentAt.extend({
                    required: {
                        params: true,
                        message: "RecdTreatmentAt " + IncidentConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.Suspects.viewModel.Suspect.HospitalAdmission());
                        }
                    },
                });
                uof.ui.Suspects.viewModel.HospitalInfo.BY.extend({
                    required: {
                        params: true,
                        message: "BY " + IncidentConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.Suspects.viewModel.Suspect.HospitalAdmission());
                        }
                    },
                });
                uof.ui.Suspects.viewModel.HospitalInfo.HospitalPhone.extend({
                    required: {
                        params: true,
                        message: "HospitalPhone " + IncidentConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.Suspects.viewModel.Suspect.HospitalAdmission());
                        }
                    },
                });
            },

            validatePFControls: function () {
                uof.ui.Suspects.viewModel.PlannedForceInfo.PFExtraction.extend({
                    required: {
                        params: true,
                        message: "P1" + IncidentConstants.Required
                    },
                });
                uof.ui.Suspects.viewModel.PlannedForceInfo.PFPlannedUoF.extend({
                    required: {
                        params: true,
                        message: "P2" + IncidentConstants.Required
                    },
                });
            },
            validateHosptControls: function () {
                uof.ui.Suspects.viewModel.HospitalInfo.RecdTreatmentAt.extend({
                    required: {
                        params: true,
                        message: "P3" + IncidentConstants.Required
                    },
                });
                //uof.ui.Suspects.viewModel.HospitalInfo.CornerCase.extend({
                //    required: {
                //        params: true,
                //        message: "P4" + IncidentConstants.Required
                //    },
                //});
                //uof.ui.Suspects.viewModel.HospitalInfo.MentalHistory.extend({
                //    required: {
                //        params: true,
                //        message: "P5" + IncidentConstants.Required
                //    },
                //});
                uof.ui.Suspects.viewModel.HospitalInfo.BY.extend({
                    required: {
                        params: true,
                        message: "P6" + IncidentConstants.Required
                    },
                });
                uof.ui.Suspects.viewModel.HospitalInfo.HospitalAddress.extend({
                    required: {
                        params: true,
                        message: "P7" + IncidentConstants.Required
                    },
                });
                uof.ui.Suspects.viewModel.HospitalInfo.HospitalPhone.extend({
                    required: {
                        params: true,
                        message: "P8" + IncidentConstants.Required
                    },
                });

            },
            validateTreatedControls: function () {
                if (uof.ui.Suspects.viewModel.TreatedInfo.TreatedName() == null || uof.ui.Suspects.viewModel.TreatedInfo.TreatedName() == undefined) {
                    $("#ErrorMsg_TreatedName").html(IncidentConstants.Required);
                    $("#ErrorMsg_TreatedName").css('display', "inline-block");
                }
                if (uof.ui.Suspects.viewModel.TreatedInfo.TreatedPhone() == null || uof.ui.Suspects.viewModel.TreatedInfo.TreatedPhone() == undefined) {
                    $("#ErrorMsg_TreatedPhone").html(IncidentConstants.Required);
                    $("#ErrorMsg_TreatedPhone").css('display', "inline-block");
                }
                if (uof.ui.Suspects.viewModel.TreatedInfo.TreatedUnit() == null || uof.ui.Suspects.viewModel.TreatedInfo.TreatedUnit() == undefined) {
                    $("#ErrorMsg_TreatedUnit").html(IncidentConstants.Required);
                    $("#ErrorMsg_TreatedUnit").css('display', "inline-block");
                }
                var bValid = !$("#divTreated").find(".warning-msg").is(':visible');
                return bValid;
            },

            //check the length of string
            lengthValidation: function (str, minChar) {
                var maxChar;
                if (uof.ui.Suspects.getCharCount(str) < minChar[0] ||
                    uof.ui.Suspects.getCharCount(str) > minChar[1])
                    return false;
                return true;
            },

            //get character based on ascii value
            getCharCount: function (str) {
                var result = 0;
                if (str !== undefined) {
                    for (var n = 0; n < str.length; n++) {
                        var charCode = str.charCodeAt();
                        if (typeof charCode === "number") {
                            if (charCode < 128)
                            { result = result + 1; }
                            else if (charCode < 2048)
                            { result = result + 2; }
                            else if (charCode < 65536)
                            { result = result + 3; }
                            else if (charCode < 2097152)
                            { result = result + 4; }
                            else if (charCode < 67108864)
                            { result = result + 5; }
                            else
                            { result = result + 6; }
                        }
                    }
                }
                return result;
            },

            //check for special characters
            isSpecialChar: function (objValue) {
                var count = 0;
                var pattr = ["\\", ":", "/", "*", "?", ">", "<", "[", "]", "{", "}", "|", "'", "=", "+"];

                while (count < pattr.length) {
                    if (objValue.indexOf(pattr[count]) > -1) {
                        return false;
                    }
                    count++;
                }
            },
            hideModalPopup: function (IdOfdiv) {
                $('#' + IdOfdiv).modal('hide');
            },

            validateHospInfo: function () {
                if (uof.ui.Suspects.viewModel.HospitalInfo.RecdTreatmentAt() == null || uof.ui.Suspects.viewModel.HospitalInfo.RecdTreatmentAt() == undefined) {
                    $("#ErrorMsg_RecdTreatmentAt").html(IncidentConstants.Required);
                    $("#ErrorMsg_RecdTreatmentAt").css('display', "inline-block");
                }
                //if (uof.ui.Suspects.viewModel.HospitalInfo.CornerCase() == null || uof.ui.Suspects.viewModel.HospitalInfo.CornerCase() == undefined) {
                //    $("#ErrorMsg_CornerCase").html(IncidentConstants.Required);
                //    $("#ErrorMsg_CornerCase").css('display', "inline-block");
                //}
                //if (uof.ui.Suspects.viewModel.HospitalInfo.MentalHistory() == null || uof.ui.Suspects.viewModel.HospitalInfo.MentalHistory() == undefined) {
                //    $("#ErrorMsg_MentalHistory").html(IncidentConstants.Required);
                //    $("#ErrorMsg_MentalHistory").css('display', "inline-block");
                //}
                if (uof.ui.Suspects.viewModel.HospitalInfo.BY() == null || uof.ui.Suspects.viewModel.HospitalInfo.BY() == undefined) {
                    $("#ErrorMsg_BY").html(IncidentConstants.Required);
                    $("#ErrorMsg_BY").css('display', "inline-block");
                }
                if (uof.ui.Suspects.viewModel.HospitalInfo.HospitalAddress() == null || uof.ui.Suspects.viewModel.HospitalInfo.HospitalAddress() == undefined) {
                    $("#ErrorMsg_HospitalAddress").html(IncidentConstants.Required);
                    $("#ErrorMsg_HospitalAddress").css('display', "inline-block");
                }
                if (uof.ui.Suspects.viewModel.HospitalInfo.HospitalPhone() == null || uof.ui.Suspects.viewModel.HospitalInfo.HospitalPhone() == undefined) {
                    $("#ErrorMsg_HospitalPhone").html(IncidentConstants.Required);
                    $("#ErrorMsg_HospitalPhone").css('display', "inline-block");
                }

                //!($("#CustomPlaceHolderDetails").find(".warning-msg").is(':visible'));
                var bValid = !$("#divHospital").find(".warning-msg").is(':visible');
                return bValid;
            },

            HospInfoClose: function () {
                $("#HospitalAdmission").prop("checked", false);
                //uof.ui.Suspects.viewModel.Suspect.HospitalAdmission("N");
                setTimeout(function () { $("#HospitalAdmission").focus(); }, 100);
                uof.ui.Suspects.hideModalPopup("divHospital");
            },
            TreatedInfoClose: function () {
                $("#TreatedOnScene").prop("checked", false);
                setTimeout(function () { $("#TreatedOnScene").focus(); }, 100);
                uof.ui.Suspects.hideModalPopup("divTreated");
            },
            PFInfoClose: function () {
                $("#plannedForce").attr("checked", false);
                uof.ui.Suspects.viewModel.Suspect.SuspectPlannedForce("N");
                setTimeout(function () { $("#plannedForce").focus(); }, 100);
                uof.ui.Suspects.hideModalPopup("divPlannedForce");
            },

            TreatedInfoSubmit: function () {
                if (uof.ui.Suspects.validateTreatedControls()) {
                    uof.ui.Suspects.hideModalPopup("divTreated");
                    $("#TreatedOnScene").prop("checked", true);
                    setTimeout(function () { $("#TreatedOnScene").focus(); }, 100);
                }
            },
            PFInfoSubmit: function () {
                result = ko.validation.group(uof.ui.Suspects.viewModel.PlannedForceInfo, { deep: true });
                if (result().length > 0) {
                    uof.ui.Suspects.viewModel.PlannedForceInfo.PFPlannedUoF.valueHasMutated();
                    uof.ui.Suspects.viewModel.PlannedForceInfo.PFExtraction.valueHasMutated();
                    return false;
                }
                setTimeout(function () { $("#plannedForce").focus(); }, 100);
                uof.ui.Suspects.hideModalPopup("divPlannedForce");
            },
            HospInfoSubmit: function () {
                if (uof.ui.Suspects.validateHospInfo()) {
                    uof.ui.Suspects.hideModalPopup("divHospital");
                    $("#HospitalAdmission").prop("checked", true);
                    setTimeout(function () { $("#HospitalAdmission").focus(); }, 100);
                }
            },
            validateSaveSuspectFields: function () {
                result = ko.validation.group([uof.ui.Suspects.viewModel.Suspect.BookingNumber]);
                if (result().length > 0) {
                    $("#btnSSave").focus();
                    uof.ui.Suspects.viewModel.Suspect.BookingNumber.valueHasMutated();
                    return false;
                }
                return true;

            },
            validateSuspectFields: function (model) {
                uof.ui.Suspects.viewModel.Suspect = {};
                uof.ui.Suspects.viewModel.Suspect = ko.mapping.fromJS(model, ko.mapping.toJS(uof.ui.Suspects.viewModel.Suspect));
                if (uof.ui.Suspects.viewModel.Suspect.TreatedOnScene() == "Y")
                    uof.ui.Suspects.viewModel.Suspect.TreatedOnScene(true);
                else
                    uof.ui.Suspects.viewModel.Suspect.TreatedOnScene(false);
                if (uof.ui.Suspects.viewModel.Suspect.HospitalAdmission() == "Y")
                    uof.ui.Suspects.viewModel.Suspect.HospitalAdmission(true);
                else
                    uof.ui.Suspects.viewModel.Suspect.HospitalAdmission(false);

                uof.ui.Suspects.validateControls();

                result = ko.validation.group(uof.ui.Suspects.viewModel.Suspect, { deep: true });
                if (result().length > 0) {
                    $("#btnSSave").focus();
                    uof.ui.Suspects.viewModel.Suspect.BookingNumber.valueHasMutated();
                    //uof.ui.Suspects.viewModel.Suspect.Armed.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.Sex.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.Race.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.TransorRefuse.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.ZipCode.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.State.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.PrimaryChargCode.valueHasMutated();
                    //uof.ui.Suspects.viewModel.Suspect.SecondaryChargCode.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.InmateRecalcitrant.valueHasMutated();

                    uof.ui.Suspects.viewModel.Suspect.Height.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.Weight.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.Age.valueHasMutated();


                    //uof.ui.Suspects.viewModel.Suspect.Dress.valueHasMutated();
                    //uof.ui.Suspects.viewModel.Suspect.Street.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.City.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.DateOfBirth.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.CivilianResistance.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.Perceivedarmed.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.CivilianConfirmedarmed.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.CivilianInjurySeverity.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.TypeofForce.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.PrimaryPhno.valueHasMutated();
                    //uof.ui.Suspects.viewModel.Suspect.SecondaryPhno.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.TypeOfInjury.valueHasMutated();
                    //uof.ui.Suspects.viewModel.Suspect.CriminalHistory.valueHasMutated();
                    //Radio
                    uof.ui.Suspects.viewModel.Suspect.SafetyChairUsed.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.SuspectInterviewedAwayfromInmates.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.forceusedasDiscipline.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.ForceUsed.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.MultiPointRestraintsUsed.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.InmatePhysicallyAssaultive.valueHasMutated();
                    //uof.ui.Suspects.viewModel.Suspect.OtherplannedUoF.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.Extractionordered.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.InmateHarassed.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.MedicalRestraintsUsed.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.InmateonInmateViolence.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.cellExtraction.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.MedicalRecordschecked.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.InmateonInmateViolenceProvoked.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.InmateRecalcitrant.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.OthertypesofRestraints.valueHasMutated();
                    uof.ui.Suspects.viewModel.Suspect.CorporalPunishment.valueHasMutated();

                    return false;
                }
                return true;

            },
            //
            listLoad: function () {
                $(".kendo-mini-pager").removeClass("k-pager-wrap");
                $(".kendo-mini-pager").removeClass("k-widget");
                $(".kendo-mini-pager").removeClass("k-floatwrap");
            },

            loadHospitalData: function () {
                var self = this;
                this.viewModel.Suspect.RecdTreatmentAt = this.viewModel.HospitalInfo.RecdTreatmentAt;
                //this.viewModel.Suspect.CornerCase = this.viewModel.HospitalInfo.CornerCase;
                //this.viewModel.Suspect.MentalHistory = this.viewModel.HospitalInfo.MentalHistory;
                this.viewModel.Suspect.BY = this.viewModel.HospitalInfo.BY;
                this.viewModel.Suspect.HospitalAddress = this.viewModel.HospitalInfo.HospitalAddress;
                this.viewModel.Suspect.HospitalPhone = this.viewModel.HospitalInfo.HospitalPhone;
            },
            loadTreatedData: function () {
                var self = this;
                this.viewModel.Suspect.TreatedName = this.viewModel.TreatedInfo.TreatedName;
                this.viewModel.Suspect.TreatedUnit = this.viewModel.TreatedInfo.TreatedUnit;
                this.viewModel.Suspect.TreatedPhone = this.viewModel.TreatedInfo.TreatedPhone;
            },
            loadPlannedData: function () {

            },
            saveSuspectInfo: function (IsOnlySave) {
                if (uof.ui.Suspects.validateSaveSuspectFields()) {
                    if (!uof.ui.CommonUILogic.detail.validateDuplicate(suspectDataSource._data, uof.ui.Suspects.viewModel.Suspect.BookingNumber(), 2, uof.ui.Suspects.viewModel.Suspect.Mode())) {
                        uof.ui.Suspects.viewModel.Suspect.IsOnlySave(IsOnlySave);
                        $.prototype.showUofOverlay();
                        //Loading Hospital,Treated,Planned Force data
                        uof.ui.Suspects.loadHospitalData();
                        uof.ui.Suspects.loadTreatedData();
                        if (UoFParams.IncidentId != "")
                            uof.ui.Suspects.viewModel.Suspect.IncidentId = UoFParams.IncidentId;
                        else
                            uof.ui.Suspects.viewModel.Suspect.IncidentId = uof.ui.incident.detail.selectedContext.selectedIncident()
                        var mappedData = ko.mapping.toJS(uof.ui.Suspects.viewModel.Suspect);
                        //mappedData.CivilianInjurySeverity = mappedData.CivilianInjurySeverity();
                        mappedData.Race = mappedData.Race != null ? mappedData.Race.join(',') : '';
                        mappedData.ForceUsed = mappedData.ForceUsed != null ? mappedData.ForceUsed.join(',') : '';
                        mappedData.TypeOfInjury = mappedData.TypeOfInjury != null ? mappedData.TypeOfInjury.join(',') : '';
                        mappedData.SuspectLOC = mappedData.SuspectLOC != null ? mappedData.SuspectLOC.join(',') : '';
                        mappedData.TypeofForce = mappedData.TypeofForce != null ? mappedData.TypeofForce.join(',') : '';
                        mappedData.SpecialHandle = mappedData.SpecialHandle != null ? mappedData.SpecialHandle.join(',') : '';
                        //mappedData.HospitalAdmission = $("#HospitalAdmission").is(":checked");
                        mappedData.MentalHistory = mappedData.MentalHistory ? 'Y' : 'N';

                        $.ajax(
                               {

                                   url: window.location.uofAPIOrigin() + '/api/User/SaveSuspectUser',
                                   cache: false,
                                   type: "POST",
                                   dataType: 'json',
                                   data: JSON.stringify(mappedData),
                                   contentType: "application/json;charset=utf-8",
                                   beforeSend: function myfunction() {

                                   },
                                   success: function (empData) {
                                       $.prototype.hideUofOverlay();
                                       uof.ui.Suspects.fillSuspectlist(ko.mapping.toJS(uof.ui.Suspects.viewModel.Suspect));
                                       uof.ui.Suspects.bindSuspectData();
                                       showAlert(empData);
                                       uof.ui.Suspects.viewModel.Suspect.Mode("Add");
                                       uof.ui.Suspects.cancelSuspectData();
                                       $("#btnSSave").focus();
                                   },
                                   error: function (e) {
                                       $.prototype.hideUofOverlay();
                                       $("#btnSSave").focus();
                                       showAlert(e.responseText);
                                   },
                               });
                    }
                    else
                        showAlert("Duplicate");
                }
            },
            saveSuspectDetails: function () {
                if (uof.ui.Suspects.validateSuspectFields()) {
                    uof.ui.Suspects.saveSuspectInfo(false);
                }
            },
            fillSuspectlist: function (suspect) {
                uof.ui.Suspects.viewModel.SuspectList.push({
                    BookingNumber: suspect.BookingNumber,
                    Name: suspect.LastName + ' ' + suspect.FirstName + ' ' + suspect.MiddleName,
                    PrimaryChargCode: suspect.PrimaryChargCode,
                    SecondaryChargCode: suspect.SecondaryChargCode
                });
            },

            // subscribe method
            subscribeMethod: function () {
                uof.ui.Suspects.viewModel.Suspect.TreatedOnScene.subscribe(function (newValue) {
                    if ($.trim(newValue) == "true" && $.trim(newValue) != "") {
                        $("#TreatedName").removeClass("disabled");
                        $("#TreatedUnit").removeClass("disabled");
                        $("#TreatedPhone").removeClass("disabled");
                        uof.ui.Suspects.viewModel.TreatedInfo.TreatedName.valueHasMutated();
                        uof.ui.Suspects.viewModel.TreatedInfo.TreatedUnit.valueHasMutated();
                        uof.ui.Suspects.viewModel.TreatedInfo.TreatedPhone.valueHasMutated();
                    }
                    else if ($.trim(newValue) == "false") {
                        $("#TreatedName").addClass("disabled");
                        $("#TreatedUnit").addClass("disabled");
                        $("#TreatedPhone").addClass("disabled");
                        uof.ui.Suspects.resetTreated();
                    }
                });
                uof.ui.Suspects.viewModel.Suspect.HospitalAdmission.subscribe(function (newValue) {
                    if ($.trim(newValue) == "true" && $.trim(newValue) != "") {
                        $("#TreatmentAt").removeClass("disabled");
                        $("#BY").removeClass("disabled");
                        $("#HospitalAddress").removeClass("disabled");
                        $("#HospitalPhone").removeClass("disabled");
                        uof.ui.Suspects.viewModel.HospitalInfo.RecdTreatmentAt.valueHasMutated();
                        uof.ui.Suspects.viewModel.HospitalInfo.BY.valueHasMutated();
                        uof.ui.Suspects.viewModel.HospitalInfo.HospitalAddress.valueHasMutated();
                        uof.ui.Suspects.viewModel.HospitalInfo.HospitalPhone.valueHasMutated();
                    }
                    else if ($.trim(newValue) == "false") {
                        $("#TreatmentAt").addClass("disabled");
                        $("#BY").addClass("disabled");
                        $("#HospitalAddress").addClass("disabled");
                        $("#HospitalPhone").addClass("disabled")
                        uof.ui.Suspects.resetHospital();
                    }

                });
                uof.ui.Suspects.viewModel.Suspect.CivilianConfirmedarmed.subscribe(function (newValue) {
                    $("#SuspectConfArmedOther").addClass("disabled");
                    if ($.trim(newValue) == "ODW") {
                        $("#SuspectConfArmedOther").removeClass("disabled");
                        uof.ui.Suspects.isChanged = true;
                        uof.ui.Suspects.viewModel.Suspect.SuspectConfArmedOther.valueHasMutated();
                    }
                    else
                        uof.ui.Suspects.viewModel.Suspect.SuspectConfArmedOther(null);

                });

                // Subscribing the name and code to get changes
                uof.ui.Suspects.viewModel.Suspect.BookingNumber.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        uof.ui.Suspects.isChanged = true;
                        $(".validationMessage").parent(".form-group").removeClass('has-error');
                    }

                });
                uof.ui.Suspects.viewModel.Suspect.Sex.subscribe(function (newValue) {
                    uof.ui.Suspects.toggoleInmatePrenant();
                });

                uof.ui.Suspects.viewModel.Suspect.UnderInfluence.subscribe(function (newValue) {
                    $("#Substance").prop('disabled', true);
                    if ($.trim(newValue) == "Y") {
                        $("#Substance").prop('disabled', false);
                    }

                });

                uof.ui.Suspects.viewModel.Suspect.TransorRefuse.subscribe(function (newValue) {
                    if ($.trim(newValue) != "T") {
                        uof.ui.Suspects.isChanged = true;
                        uof.ui.Suspects.viewModel.Suspect.State.valueHasMutated();
                        uof.ui.Suspects.viewModel.Suspect.ZipCode.valueHasMutated();
                        uof.ui.Suspects.viewModel.Suspect.City.valueHasMutated();
                        //uof.ui.Suspects.viewModel.Suspect.Street.valueHasMutated();
                        return false;
                    }
                });
                uof.ui.Suspects.viewModel.Suspect.CivilianInjurySeverity.subscribe(function (newValue) {

                    if ($.trim(newValue) != undefined) {
                        if (newValue == "DH") {
                            $("#CornerCase").attr('disabled', false);
                            uof.ui.Suspects.viewModel.Suspect.CornerCase.valueHasMutated();
                        }
                        else {
                            uof.ui.Suspects.viewModel.Suspect.CornerCase(null);
                            uof.ui.Suspects.viewModel.Suspect.forecasting(null);
                            $("#CornerCase").attr('disabled', true);
                            $("#divSuspectDeath").attr('disabled', true);
                        }
                    }
                    else {
                        uof.ui.Suspects.viewModel.Suspect.CornerCase(null);
                        uof.ui.Suspects.viewModel.Suspect.forecasting(null);
                        $("#CornerCase").attr('disabled', true);
                        $("#divSuspectDeath").attr('disabled', true);
                    }
                });
            },



            //Grid Binding 
            bindSuspectData: function () {
                // Ajax call to server to get Organziation records
                // $.prototype.showUofOverlay();
                var dlAjaxOption =
                    {
                        url: window.location.uofAPIOrigin() + '/api/User/GetSuspectUser',
                        cache: false,
                        data: 'incidentId=' + String(uof.ui.incident.detail.selectedContext.selectedIncident()),
                        type: "GET",
                        dataType: 'json',
                        contentType: "application/json;charset=utf-8",
                        success: function (nonSuspectEmpl) {
                            suspectDataSource = new kendo.data.DataSource({
                                data: nonSuspectEmpl,
                                pageSize: 20
                            });

                            uof.ui.Suspects.viewModel.SuspectEmployeeList = ko.observableArray(nonSuspectEmpl);
                            //setting all Org Data to kendo
                            $("#SuspectList").kendoGrid({
                                dataSource: suspectDataSource,
                                height: 240,
                                scrollable: true,
                                sortable: true,
                                filterable: false,
                                pageable: {
                                    refresh: false,
                                    pageSizes: true,
                                    pageSizes: [20, 50, 100],
                                    buttonCount: 5,
                                    messages: {
                                    },
                                },
                                columns: [
                                {
                                    field: "BookingNumber",
                                    headerTemplate: kendo.format('<span  class="word-break-txt" title="{0}" >{1}</span>', "Booking Number", "Booking Number"),
                                    // template: $("#viewSuspectDetails").html(),
                                    width: 150
                                },
                                 {
                                     field: "Name",
                                     headerTemplate: kendo.format('<span  class="word-break-txt" title="{0}" >{1}</span>', "Suspect Name", "Suspect Name"),
                                     width: 150
                                 },

                                {
                                    field: "IncidentUserSuspectId",
                                    template: $("#editSuspectDetails").html(),
                                    headerTemplate: '',
                                    width: 30,
                                },
                                {
                                    field: "IncidentUserSuspectId",
                                    template: $("#deleteSuspectDetails").html(),
                                    headerTemplate: '',
                                    width: 30,
                                    hidden: !uof.ui.Suspects.viewModel.isEditMode()
                                },
                                ],
                                //  dataBound: athoc.iws.organizationManager.OnDataBound,
                                change: function (e) {
                                    var model = this.dataItem(this.select());
                                }
                            }).data().kendoGrid;
                            suspectDataSource.read();
                            // $.prototype.hideUofOverlay();
                            uof.ui.Suspects.setKendoGridHeight();
                            if (!uof.ui.Suspects.viewModel.isEditMode()) {
                                $("#SuspectList").find('button').html('View');

                            }
                        },
                        error: function (e) {
                            showAlert(e.responseText);
                        }

                    };
                // Call ajax
                var ajaxOptions = $.extend({}, 'GET', dlAjaxOption);
                $.ajax(ajaxOptions);

            },

            setKendoGridHeight: function () {
                $('.k-grid-content').attr('style', 'height:70%');
            },
            cancelSuspectData: function () {
                uof.ui.Suspects.viewModel.Suspect.Mode("Add");
                uof.ui.Suspects.viewModel.Suspect.IncidentId = ko.observable(0);
                uof.ui.Suspects.viewModel.Suspect.BookingNumber(null);
                uof.ui.Suspects.viewModel.Suspect.Armed(null);
                uof.ui.Suspects.viewModel.Suspect.LastName(null);
                uof.ui.Suspects.viewModel.Suspect.FirstName(null);
                uof.ui.Suspects.viewModel.Suspect.MiddleName(null);
                uof.ui.Suspects.viewModel.Suspect.Armed(null);
                uof.ui.Suspects.viewModel.Suspect.AkaLastname(null);
                uof.ui.Suspects.viewModel.Suspect.AkaFirstname(null);
                uof.ui.Suspects.viewModel.Suspect.AkaMiddleName(null);
                uof.ui.Suspects.viewModel.Suspect.Sex(null);

                uof.ui.Suspects.viewModel.Suspect.Dress(null);
                uof.ui.Suspects.viewModel.Suspect.Age(null);
                uof.ui.Suspects.viewModel.Suspect.Height(null);
                uof.ui.Suspects.viewModel.Suspect.Weight(null);
                uof.ui.Suspects.viewModel.Suspect.Street(null);
                uof.ui.Suspects.viewModel.Suspect.City(null);
                uof.ui.Suspects.viewModel.Suspect.State(null);
                uof.ui.Suspects.viewModel.Suspect.ZipCode(null);
                uof.ui.Suspects.viewModel.Suspect.DateOfBirth(null)
                uof.ui.Suspects.viewModel.Suspect.PrimaryPhno(null)
                uof.ui.Suspects.viewModel.Suspect.SecondaryPhno(null)
                uof.ui.Suspects.viewModel.Suspect.PhoneMode(null);
                uof.ui.Suspects.viewModel.Suspect.SPhMode('Home');
                uof.ui.Suspects.viewModel.Suspect.PPhMode('Home');
                uof.ui.Suspects.viewModel.Suspect.PrimaryChargCode(null);
                uof.ui.Suspects.viewModel.Suspect.SecondaryChargCode(null);
                uof.ui.Suspects.viewModel.Suspect.CivilianResistance(null);
                uof.ui.Suspects.viewModel.Suspect.Lifethreatening(null);
                uof.ui.Suspects.viewModel.Suspect.Assulative(null);
                uof.ui.Suspects.viewModel.Suspect.Perceivedarmed(null);
                uof.ui.Suspects.viewModel.Suspect.CivilianConfirmedarmed(null);
                uof.ui.Suspects.viewModel.Suspect.CivilianInjurySeverity(null);
                uof.ui.Suspects.viewModel.Suspect.forecasting(null);
                uof.ui.Suspects.viewModel.Suspect.TypeofForce([]);
                uof.ui.Suspects.viewModel.Suspect.MentalHistory(false);
                uof.ui.Suspects.viewModel.Suspect.TypeOfInjury(null);
                uof.ui.Suspects.viewModel.Suspect.SafetyChairUsed("N");
                uof.ui.Suspects.viewModel.Suspect.CriminalHistory(null);
                uof.ui.Suspects.viewModel.Suspect.TreatedOnScene(null);
                uof.ui.Suspects.viewModel.Suspect.HospitalAdmission(null);
                $("#HospitalAdmission").prop("checked", false);
                $("#TreatedOnScene").prop("checked", false);
                $("#suspectInterview").prop("checked", false);
                uof.ui.Suspects.viewModel.Suspect.InmatePhysicallyAssaultive("N");
                uof.ui.Suspects.viewModel.Suspect.InmateRecalcitrant("N");
                uof.ui.Suspects.viewModel.Suspect.InmateonInmateViolenceProvoked("N");
                uof.ui.Suspects.viewModel.Suspect.InmateonInmateViolence("N");
                uof.ui.Suspects.viewModel.Suspect.MultiPointRestraintsUsed("N");
                uof.ui.Suspects.viewModel.Suspect.OthertypesofRestraints("N");
                uof.ui.Suspects.viewModel.Suspect.MedicalRecordschecked("N");
                uof.ui.Suspects.viewModel.Suspect.MedicalRestraintsUsed("N");
                uof.ui.Suspects.viewModel.Suspect.forceusedasDiscipline("N");
                uof.ui.Suspects.viewModel.Suspect.CorporalPunishment("N");
                uof.ui.Suspects.viewModel.Suspect.cellExtraction("N");
                uof.ui.Suspects.viewModel.Suspect.Extractionordered("N");
                uof.ui.Suspects.viewModel.Suspect.InmateHarassed("N");
                uof.ui.Suspects.viewModel.Suspect.SuspectInterviewedAwayfromInmates("N");
                uof.ui.Suspects.viewModel.Suspect.TransorRefuse(null)
                //uof.ui.Suspects.viewModel.Suspect.OtherplannedUoF("N");
                uof.ui.Suspects.viewModel.Suspect.UnderInfluence("N");
                uof.ui.Suspects.viewModel.Suspect.Substance(null)
                uof.ui.Suspects.viewModel.Suspect.factorinForce("N");
                uof.ui.Suspects.viewModel.Suspect.SuspectLOC(null)

                uof.ui.Suspects.viewModel.Suspect.Interview(null);
                uof.ui.Suspects.viewModel.Suspect.InterviewDate(null);
                uof.ui.Suspects.viewModel.Suspect.InterviewTime(null);
                uof.ui.Suspects.viewModel.Suspect.Audiotape(null);
                uof.ui.Suspects.viewModel.Suspect.Videotape(null);
                uof.ui.Suspects.viewModel.Suspect.Photos = ko.observable(null);
                uof.ui.Suspects.viewModel.Suspect.Announcements(null);
                uof.ui.Suspects.viewModel.Suspect.Interview(null);

                uof.ui.Suspects.viewModel.Suspect.IspregnantInmate(null);

                uof.ui.Suspects.viewModel.Suspect.SecurityLevel(null);

                $("#suspectRace").selectpicker('destroy');
                $("[data-id='suspectRace']").remove();
                $("#SuspectLOF").selectpicker('destroy');
                $('#SuspectLOFB').selectpicker('destroy');
                $('#TypeOfInjury').selectpicker('destroy');
                $('#SpecialHandling').selectpicker('destroy');
                //$('#CivilianinjurySeverity').selectpicker('destroy');
                $('#suspectLocationofForce').selectpicker('destroy');
                uof.ui.Suspects.viewModel.Suspect.Race([]);
                uof.ui.Suspects.viewModel.Suspect.ForceUsed([]);
                uof.ui.Suspects.viewModel.Suspect.TypeOfInjury([]);
                uof.ui.Suspects.viewModel.Suspect.SuspectLOC([]);
                uof.ui.Suspects.viewModel.Suspect.SpecialHandle([])
                uof.ui.Suspects.viewModel.Suspect.CivilianInjurySeverity()
                $('#suspectLocationofForce').selectpicker('refresh');
                $('#SuspectLOFB').selectpicker('refresh');
                $('#TypeOfInjury').selectpicker('refresh');
                $("#suspectRace").selectpicker('refresh');
                $("#SuspectLOF").selectpicker('refresh');
                $('#SpecialHandling').selectpicker('refresh');
                //$('#CivilianinjurySeverity').selectpicker('refresh');

                //if (uof.ui.Suspects.viewModel.Race.length == 0)
                //    uof.ui.Suspects.viewModel.Race = ko.observableArray(RaceSource);

                //if (uof.ui.Suspects.viewModel.ForceUsed.length == 0)
                //    uof.ui.Suspects.viewModel.ForceUsed = uof.ui.Suspects.viewModel.SuspectForceUsed();

                uof.ui.Suspects.refreshInterviewPage();
                uof.ui.Suspects.resetTreated();
                uof.ui.Suspects.resetHospital();
                result = ko.validation.group(uof.ui.Suspects.viewModel.Suspect, { deep: true });
                result.showAllMessages(false);
            },
            cancelSuspectView: function () {

                uof.ui.Suspects.viewModel.isEditMode(true); return true;
            },

            viewSuspectDetails: function (incidentUserSuspectId) {
                var selectedData = _.find(suspectDataSource.data(), function (item) {
                    return item.IncidentUserSuspectId == incidentUserSuspectId;
                });

                if (selectedData != null) {
                    uof.ui.Suspects.viewModel.isEditMode(false);
                    uof.ui.Suspects.viewModel.Suspect = {};
                    uof.ui.Suspects.viewModel.Suspect = ko.mapping.fromJS(selectedData, uof.ui.Suspects.viewModel.Suspect);
                    //Formating
                    if (uof.ui.Suspects.viewModel.Suspect.DateOfBirth() != null)
                        uof.ui.Suspects.viewModel.Suspect.DateOfBirth(moment(uof.ui.Suspects.viewModel.Suspect.DateOfBirth()).format("MM/DD/YYYY"));

                    if (uof.ui.Suspects.viewModel.Suspect.Race() != null) {
                        var data = uof.ui.Suspects.viewModel.Race();
                        var race = $.grep(data, function (v) {
                            return v.Code.toUpperCase() === uof.ui.Suspects.viewModel.Suspect.Race().toUpperCase();
                        });
                        if (race.length > 0) {
                            uof.ui.Suspects.viewModel.Suspect.Race(race[0].Name);
                        }
                        else {
                            uof.ui.Suspects.viewModel.Suspect.Race("");
                        }
                    }
                    if (uof.ui.Suspects.viewModel.Suspect.Sex() != null) {
                        var data = uof.ui.Suspects.viewModel.Sex();
                        var CIS = $.grep(data, function (v) {
                            return v.Code.toUpperCase() === uof.ui.Suspects.viewModel.Suspect.Sex().toUpperCase();
                        });
                        if (race.length > 0) {
                            uof.ui.Suspects.viewModel.Suspect.Sex(CIS[0].Name);
                        }
                        else {
                            uof.ui.Suspects.viewModel.Suspect.Sex("");
                        }
                    }
                    if (uof.ui.Suspects.viewModel.Suspect.CivilianInjurySeverity() != null) {
                        var data = uof.ui.Suspects.viewModel.CInjurySeverity();
                        var CIS = $.grep(data, function (v) {
                            return v.Code.toUpperCase() === uof.ui.Suspects.viewModel.Suspect.CivilianInjurySeverity().toUpperCase();
                        });
                        if (race.length > 0) {
                            uof.ui.Suspects.viewModel.Suspect.CivilianInjurySeverity(CIS[0].Name);
                        }
                        else {
                            uof.ui.Suspects.viewModel.Suspect.CivilianInjurySeverity("");
                        }
                    }
                    if (uof.ui.Suspects.viewModel.Suspect.Armed() != null) {
                        var data = uof.ui.Suspects.viewModel.SuspectArmed();
                        var CIS = $.grep(data, function (v) {
                            return v.Code.toUpperCase() === uof.ui.Suspects.viewModel.Suspect.Armed().toUpperCase();
                        });
                        if (race.length > 0) {
                            uof.ui.Suspects.viewModel.Suspect.Armed(CIS[0].Name);
                        }
                        else {
                            uof.ui.Suspects.viewModel.Suspect.Armed("");
                        }
                    }
                    if (uof.ui.Suspects.viewModel.Suspect.HospitalAdmission() != null) {
                        if (uof.ui.Suspects.viewModel.Suspect.HospitalAdmission() == "N")
                            uof.ui.Suspects.viewModel.Suspect.HospitalAdmission("No")
                        else
                            uof.ui.Suspects.viewModel.Suspect.HospitalAdmission("Yes")
                    }
                    if (uof.ui.Suspects.viewModel.Suspect.CivilianResistance() != null) {
                        var data = uof.ui.Suspects.viewModel.Resistances();
                        var TOF = $.grep(data, function (v) {
                            return v.Code.toUpperCase() === uof.ui.Suspects.viewModel.Suspect.CivilianResistance().toUpperCase();
                        });
                        if (TOF.length > 0) {
                            uof.ui.Suspects.viewModel.Suspect.CivilianResistance(TOF[0].Name);
                        }
                        else {
                            uof.ui.Suspects.viewModel.Suspect.CivilianResistance("");
                        }
                    }
                    if (uof.ui.Suspects.viewModel.Suspect.TypeOfInjury() != null) {
                        var data = uof.ui.Suspects.viewModel.TypeOfInjury();
                        var TOF = $.grep(data, function (v) {
                            return v.Code.toUpperCase() === uof.ui.Suspects.viewModel.Suspect.TypeOfInjury().toUpperCase();
                        });
                        if (TOF.length > 0) {
                            uof.ui.Suspects.viewModel.Suspect.TypeOfInjury(TOF[0].Name);
                        }
                        else {
                            uof.ui.Suspects.viewModel.Suspect.TypeOfInjury("");
                        }
                    }
                    if (uof.ui.Suspects.viewModel.Suspect.Perceivedarmed() != null) {
                        var data = uof.ui.Suspects.viewModel.PerceivedArmed();
                        var TOF = $.grep(data, function (v) {
                            return v.Code.toUpperCase() === uof.ui.Suspects.viewModel.Suspect.Perceivedarmed().toUpperCase();
                        });
                        if (TOF.length > 0) {
                            uof.ui.Suspects.viewModel.Suspect.Perceivedarmed(TOF[0].Name);
                        }
                        else {
                            uof.ui.Suspects.viewModel.Suspect.Perceivedarmed("");
                        }
                    }
                    if (uof.ui.Suspects.viewModel.Suspect.CivilianConfirmedarmed() != null) {
                        var data = uof.ui.Suspects.viewModel.ConfirmedArmed();
                        var TOF = $.grep(data, function (v) {
                            return v.Code.toUpperCase() === uof.ui.Suspects.viewModel.Suspect.CivilianConfirmedarmed().toUpperCase();
                        });
                        if (TOF.length > 0) {
                            uof.ui.Suspects.viewModel.Suspect.CivilianConfirmedarmed(TOF[0].Name);
                        }
                        else {
                            uof.ui.Suspects.viewModel.Suspect.CivilianConfirmedarmed("");
                        }
                    }
                    if (uof.ui.Suspects.viewModel.Suspect.TypeofForce() != null) {
                        var data = uof.ui.Suspects.viewModel.TypeOfForce();
                        var TOF = $.grep(data, function (v) {
                            return v.Code.toUpperCase() === uof.ui.Suspects.viewModel.Suspect.TypeofForce().toUpperCase();
                        });
                        if (TOF.length > 0) {
                            uof.ui.Suspects.viewModel.Suspect.TypeofForce(TOF[0].Name);
                        }
                        else {
                            uof.ui.Suspects.viewModel.Suspect.TypeofForce("");
                        }
                    }
                    if (uof.ui.Suspects.viewModel.Suspect.SuspectLOC() != null) {
                        var data = uof.ui.Suspects.viewModel.SuspectLOC();
                        var TOF = $.grep(data, function (v) {
                            return v.Code.toUpperCase() === uof.ui.Suspects.viewModel.Suspect.SuspectLOC().toUpperCase();
                        });
                        if (TOF.length > 0) {
                            uof.ui.Suspects.viewModel.Suspect.SuspectLOC(TOF[0].Name);
                        }
                        else {
                            uof.ui.Suspects.viewModel.Suspect.SuspectLOC("");
                        }
                    }
                    if (uof.ui.Suspects.viewModel.Suspect.TypeofForce() != null) {
                        var data = uof.ui.Suspects.viewModel.TypeOfForce();
                        var TOF = $.grep(data, function (v) {
                            return v.Code.toUpperCase() === uof.ui.Suspects.viewModel.Suspect.TypeofForce().toUpperCase();
                        });
                        if (TOF.length > 0) {
                            uof.ui.Suspects.viewModel.Suspect.TypeofForce(TOF[0].Name);
                        }
                        else {
                            uof.ui.Suspects.viewModel.Suspect.TypeofForce("");
                        }
                    }

                    if (uof.ui.Suspects.viewModel.Suspect.ForceUsed() != null) {
                        var data = uof.ui.Suspects.viewModel.SuspectForceUsed();
                        var TOF = $.grep(data, function (v) {
                            return v.Code.toUpperCase() === uof.ui.Suspects.viewModel.Suspect.ForceUsed().toUpperCase();
                        });
                        if (TOF.length > 0) {
                            uof.ui.Suspects.viewModel.Suspect.ForceUsed(TOF[0].Name);
                        }
                        else {
                            uof.ui.Suspects.viewModel.Suspect.ForceUsed("");
                        }
                    }
                    //End


                    //   ko.cleanNode($("#EmpSuspectView").get(0));
                    //  ko.applyBindings(uof.ui.Suspects.viewModel, $("#EmpSuspectView").get(0));
                }
            },
            deleteSuspect: function (incidentUserSuspectId) {
                var selectedData = _.find(suspectDataSource.data(), function (item) {
                    return item.IncidentUserSuspectId == incidentUserSuspectId;
                });
                $.prototype.showUofOverlay();
                $.ajax(
               {
                   url: window.location.uofAPIOrigin() + '/api/User/DeleteUser?incidentId=' + selectedData.IncidentId + '&userId=' + incidentUserSuspectId + '&employeeNumber=' + selectedData.BookingNumber + '&userType=2',
                   cache: false,
                   type: "DELETE",
                   dataType: 'json',
                   contentType: "application/json;charset=utf-8",
                   beforeSend: function myfunction() {

                   },
                   success: function (data) {
                       showAlert(data);
                       uof.ui.Suspects.bindSuspectData();
                       $.prototype.hideUofOverlay();
                   },
                   error: function (e) {
                       $.prototype.hideUofOverlay();
                       showAlert(e.responseText);
                   },
               });

            },
            editSuspectDetails: function (incidentUserSuspectId) {

                var selectedData = _.find(suspectDataSource.data(), function (item) {
                    return item.IncidentUserSuspectId == incidentUserSuspectId;
                });

                if (selectedData != null) {
                    selectedData.DateOfBirth = moment(selectedData.DateOfBirth).format("MM/DD/YYYY");
                    if (selectedData.InterviewDate != null)
                        selectedData.InterviewDate = moment(selectedData.InterviewDate).format("MM/DD/YYYY");
                    uof.ui.Suspects.viewModel.Suspect = {};
                    uof.ui.Suspects.viewModel.Suspect = ko.mapping.fromJS(selectedData, ko.mapping.toJS(uof.ui.Suspects.viewModel.Suspect));
                    $("#suspectRace").selectpicker('destroy');
                    $("[data-id='suspectRace']").remove();
                    $("#SuspectLOF").selectpicker('destroy');
                    $('#SuspectLOFB').selectpicker('destroy');
                    $('#TypeOfInjury').selectpicker('destroy');
                    $('#suspectLocationofForce').selectpicker('destroy');
                    $('#SpecialHandling').selectpicker('destroy');
                    //$('#CivilianinjurySeverity').selectpicker('destroy');
                    if (uof.ui.Suspects.viewModel.Race.length == 0)
                        uof.ui.Suspects.viewModel.Race = ko.observableArray(RaceSource);

                    if (uof.ui.Suspects.viewModel.Suspect.Race() != null)
                        uof.ui.Suspects.viewModel.Suspect.Race = ko.observableArray(uof.ui.Suspects.viewModel.Suspect.Race().split(','));

                    if (uof.ui.Suspects.viewModel.ForceUsed.length == 0)
                        uof.ui.Suspects.viewModel.ForceUsed = uof.ui.Suspects.viewModel.SuspectForceUsed();

                    if (uof.ui.Suspects.viewModel.Suspect.ForceUsed() != null)
                        uof.ui.Suspects.viewModel.Suspect.ForceUsed = ko.observableArray(uof.ui.Suspects.viewModel.Suspect.ForceUsed().split(','));

                    if (uof.ui.Suspects.viewModel.TypeOfInjury.length == 0)
                        uof.ui.Suspects.viewModel.TypeOfInjury = uof.ui.Suspects.viewModel.TypeOfInjury();

                    if (uof.ui.Suspects.viewModel.Suspect.TypeOfInjury() != null)
                        uof.ui.Suspects.viewModel.Suspect.TypeOfInjury = ko.observableArray(uof.ui.Suspects.viewModel.Suspect.TypeOfInjury().split(','));

                    if (uof.ui.Suspects.viewModel.SuspectLOC.length == 0)
                        uof.ui.Suspects.viewModel.SuspectLOC = uof.ui.Suspects.viewModel.SuspectLOC();

                    if (uof.ui.Suspects.viewModel.Suspect.SuspectLOC() != null)
                        uof.ui.Suspects.viewModel.Suspect.SuspectLOC = ko.observableArray(uof.ui.Suspects.viewModel.Suspect.SuspectLOC().split(','));

                    if (uof.ui.Suspects.viewModel.TypeOfForce.length == 0)
                        uof.ui.Suspects.viewModel.TypeOfForce = uof.ui.Suspects.viewModel.TypeOfForce();

                    if (uof.ui.Suspects.viewModel.Suspect.TypeofForce() != null)
                        uof.ui.Suspects.viewModel.Suspect.TypeofForce = ko.observableArray(uof.ui.Suspects.viewModel.Suspect.TypeofForce().split(','));


                    if (uof.ui.Suspects.viewModel.SHSource.length == 0)
                        uof.ui.Suspects.viewModel.SHSource = uof.ui.Suspects.viewModel.SHSource();

                    if (uof.ui.Suspects.viewModel.Suspect.SpecialHandle() != null)
                        uof.ui.Suspects.viewModel.Suspect.SpecialHandle = ko.observableArray(uof.ui.Suspects.viewModel.Suspect.SpecialHandle().split(','));

                    if (uof.ui.Suspects.viewModel.CInjurySeverity.length == 0)
                        uof.ui.Suspects.viewModel.CInjurySeverity = uof.ui.Suspects.viewModel.CInjurySeverity();

                    //if (uof.ui.Suspects.viewModel.Suspect.CivilianInjurySeverity() != null)
                    //    uof.ui.Suspects.viewModel.Suspect.CivilianInjurySeverity = ko.observableArray(uof.ui.Suspects.viewModel.Suspect.CivilianInjurySeverity().split(','));

                    uof.ui.Suspects.viewModel.TreatedInfo.TreatedName = ko.observable(selectedData.TreatedName);
                    uof.ui.Suspects.viewModel.TreatedInfo.TreatedPhone = ko.observable(selectedData.TreatedPhone);
                    uof.ui.Suspects.viewModel.TreatedInfo.TreatedUnit = ko.observable(selectedData.TreatedUnit);

                    uof.ui.Suspects.viewModel.HospitalInfo.HospitalAddress = ko.observable(selectedData.HospitalAddress);
                    uof.ui.Suspects.viewModel.HospitalInfo.RecdTreatmentAt = ko.observable(selectedData.RecdTreatmentAt);
                    uof.ui.Suspects.viewModel.HospitalInfo.HospitalPhone = ko.observable(selectedData.HospitalPhone);
                    uof.ui.Suspects.viewModel.HospitalInfo.BY = ko.observable(selectedData.BY);

                    uof.ui.Suspects.viewModel.Suspect.AkaFirstname = ko.observable(selectedData.AkaFirstname);
                    uof.ui.Suspects.viewModel.Suspect.AkaLastname = ko.observable(selectedData.AkaLastname);
                    uof.ui.Suspects.viewModel.Suspect.CornerCase = ko.observable(selectedData.CornerCase);

                    if (selectedData.HospitalAddress != null || selectedData.RecdTreatmentAt != null ||
                        selectedData.BY != null || selectedData.HospitalPhone != null) {
                        $('#HospitalAdmission').prop('checked', true);
                        $("#TreatmentAt").removeClass("disabled");
                        $("#BY").removeClass("disabled");
                        $("#HospitalAddress").removeClass("disabled");
                        $("#HospitalPhone").removeClass("disabled");
                        uof.ui.Suspects.viewModel.Suspect.HospitalAdmission(true);
                    }
                    else {
                        $('#HospitalAdmission').prop('checked', false);
                        uof.ui.Suspects.viewModel.Suspect.HospitalAdmission(false);
                    }

                    if (selectedData.TreatedName != null || selectedData.TreatedPhone != null || selectedData.TreatedUnit != null) {
                        $('#TreatedOnScene').prop('checked', true);
                        $("#TreatedName").removeClass("disabled");
                        $("#TreatedUnit").removeClass("disabled");
                        $("#TreatedPhone").removeClass("disabled");
                        uof.ui.Suspects.viewModel.Suspect.TreatedOnScene(true);

                    }
                    else {
                        $('#TreatedOnScene').prop('checked', false);
                        uof.ui.Suspects.viewModel.Suspect.TreatedOnScene(false);
                    }


                    uof.ui.Suspects.validateControls();
                    ko.cleanNode($("#SuspectInputs").get(0));
                    ko.applyBindings(uof.ui.Suspects.viewModel, $("#SuspectInputs").get(0));
                    //Suscpect Interivew
                    if (uof.ui.Suspects.viewModel.Suspect.Interview() == "True") {
                        uof.ui.Suspects.viewModel.Suspect.Interview(true);
                    }
                    else {
                        uof.ui.Suspects.viewModel.Suspect.Interview(false);
                    }

                    uof.ui.Suspects.toggoleInmatePrenant();
                    uof.ui.Suspects.bindControlEvents();
                    uof.ui.Suspects.subscribeMethod();
                    uof.ui.Suspects.viewModel.Suspect.Mode("Edit");
                    $("#suspectRace").selectpicker('refresh');
                    $("#SuspectLOF").selectpicker('refresh');
                    $('#SuspectLOFB').selectpicker('refresh');
                    $('#TypeOfInjury').selectpicker('refresh');
                    $('#suspectLocationofForce').selectpicker('refresh');
                    $('#SpecialHandling').selectpicker('refresh');
                    //$('#CivilianinjurySeverity').selectpicker('refresh');
                    uof.ui.Suspects.isFilesExist();
                    if (uof.ui.Suspects.viewModel.Suspect.CivilianResistance() == "LT") {
                        $("#divSuspectAssulative").addClass("hide");
                        $("#divSuspectLifethreatening").removeClass("hide");
                        $("#divSuspectLifethreatening *").prop('disabled', false);
                    }

                    else if (uof.ui.Suspects.viewModel.Suspect.CivilianResistance() == "ASL") {
                        $("#divSuspectAssulative").removeClass("hide");
                        $("#divSuspectLifethreatening").addClass("hide");
                        $("#divSuspectAssulative *").prop('disabled', false);
                    }
                }
                if ((uof.ui.incident.detail.viewModel.incident.currentMode() == 'view')) {
                    uof.ui.Suspects.viewModel.isEditMode(false);
                    uof.ui.Suspects.SetFormControls(true);
                }
                if (uof.ui.Suspects.viewModel.Suspect.CivilianInjurySeverity() == "DH") {
                    $("#divSuspectDeath *").prop('disabled', false);
                    $("#CornerCase").attr("disabled", false);
                }
                if (uof.ui.Suspects.viewModel.Suspect.CivilianConfirmedarmed() == "ODW") {
                    $("#SuspectConfArmedOther").removeClass('disabled');
                }
                $("#suspectInfo").find(".bootstrap-select").removeClass("disabled")
            },
            toggoleInmatePrenant: function () {
                $("#PregnantY").prop("disabled", false);
                $("#PregnantN").prop("disabled", false);
                $("#PregnantNA").prop("disabled", false);
                if (uof.ui.Suspects.viewModel.Suspect.Sex() != "") {
                    if (uof.ui.Suspects.viewModel.Suspect.Sex() == "M") {
                        $("#PregnantY").prop("disabled", true);
                        $("#PregnantN").prop("disabled", true);
                        $("#SpecialHandling").prop("disabled", true);
                        $("#SpecialHandling").selectpicker('refresh')
                    }
                    if (uof.ui.Suspects.viewModel.Suspect.Sex() == "F") {
                        $("#PregnantNA").prop("disabled", true);
                        $("#SpecialHandling").prop("disabled", false);
                        $("#SpecialHandling").selectpicker('refresh')
                    }
                }
            },
        }
    }();
}