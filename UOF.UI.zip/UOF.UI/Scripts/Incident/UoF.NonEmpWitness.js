﻿var uof = uof || {};
uof.ui = uof.ui || {};
uof.ui.incident = uof.ui.incident || {};
if (uof.ui.incident) {
    uof.ui.Witness = function () {
        return {
            parameters: null,
            isChanged: false,
            init: function (args) {
                this.parameters = args;
            },

            empNonWitnessDataSource: null,
            viewModel: {
                inmateType: ko.observable([
                                    { Name: 'Inmate', Code: 'IN' },
                                { Name: 'NonInmate', Code: 'NIN' }
                ]),
                ValidateOptions: ko.observable([
                                { Name: 'Transient', Code: 'T' },
                                { Name: 'Refuse', Code: 'F' },
                ]),
                // To add different location, just add the one more item in this list
                nonEmpWitnessList: ko.observableArray([]),
                isNonWitnessEditmode: ko.observable(true),
                NonEmpwitness: {
                    Mode: ko.observable(),
                    IncidentUserWitnessId: ko.observable(),
                    IncidentUserId: ko.observable(),
                    IncidentId: ko.observable(),
                    LoggedId: ko.observable(UoFParams.userId),
                    UserId: ko.observable(),
                    UserTypeId: ko.observable(4),
                    LastName: ko.observable(),
                    FirstName: ko.observable(),
                    MiddleName: ko.observable(),
                    Age: ko.observable(),
                    DateOfBirth: ko.observable(),
                    Street: ko.observable(),
                    City: ko.observable(),
                    ZipCode: ko.observable(),
                    PrimaryPhone: ko.observable(),
                    SecondaryPhone: ko.observable(),
                    InmateType: ko.observable(),
                    BookingNum: ko.observable(),
                    TransorRefuse: ko.observable(),
                    IsOnlySave: ko.observable(true),
                },
                getSuspectDetails: function () { uof.ui.Witness.getSuspectDetails(); }
            },
            getSuspectDetails: function (bookingNumber) {
                if (((bookingNumber != undefined) && (bookingNumber.length > 0))) {
                    var eventDate = uof.ui.CommonUILogic.detail.formatIncidentDateTime(UoFParams.IncidentDate);
                    $.prototype.showProgressBar("Booking");
                    jQuery.ajax({
                        type: "GET",
                        url: InmateAPIUrl() + bookingNumber + "&eventDate=" + eventDate + "",
                        dataType: "json",
                        cache: false,
                        crossDomain: true,
                        processData: true,
                        success: function (inmateData) {
                            $.prototype.hideProgressBar("Booking");
                            uof.ui.Witness.viewModel.NonEmpwitness.FirstName(inmateData.FirstName);
                            uof.ui.Witness.viewModel.NonEmpwitness.LastName(inmateData.LastName);
                            uof.ui.Witness.viewModel.NonEmpwitness.MiddleName(inmateData.MiddleName);
                            uof.ui.Witness.viewModel.NonEmpwitness.ZipCode(inmateData.ZipCode);
                            uof.ui.Witness.viewModel.NonEmpwitness.City(inmateData.City);
                            if (moment(inmateData.DateOfBirth) != null) {
                                if (moment(inmateData.DateOfBirth).format("MM/DD/YYYY") != "01/01/0001") {
                                    uof.ui.Witness.viewModel.NonEmpwitness.DateOfBirth(moment(inmateData.DateOfBirth).format("MM/DD/YYYY"));
                                    uof.ui.Witness.viewModel.NonEmpwitness.Age(inmateData.Age);
                                }
                            }
                            else {
                                uof.ui.Witness.viewModel.NonEmpwitness.DateOfBirth(null);
                                uof.ui.Witness.viewModel.NonEmpwitness.Age(null);
                            }

                            if (inmateData.Address != null)
                                uof.ui.Witness.viewModel.NonEmpwitness.Street(inmateData.Address);

                            uof.ui.Witness.viewModel.NonEmpwitness.PrimaryPhone(inmateData.Phone1);
                            uof.ui.Witness.viewModel.NonEmpwitness.SecondaryPhone(inmateData.Phone2);
                        },
                        error: function (XMLHttpRequest, textStatus, errorThrown) {
                            $.prototype.hideProgressBar("Booking");
                            showAlert("Error while getting the Suspect Data");
                        }
                    });
                }

            },
            //load method, will be tirggered on document load
            nonEmpWitnessload: function () {
                uof.ui.Witness.bindMaskControl();
                if (uof.ui.incident.detail.selectedContext.selectedIncident() > 0) {
                    uof.ui.Witness.nonEmpWitnessValidateMethod();
                    uof.ui.Witness.getEmpNonWitnessData();
                    //binding Witness popup page
                    uof.ui.Witness.viewModel.NonEmpwitness.IncidentId = uof.ui.incident.detail.selectedContext.selectedIncident();
                }
                ko.validation.group(uof.ui.Witness.viewModel.NonEmpwitness).showAllMessages(false);
                ko.cleanNode($("#EmployeeNonWitnessInputs").get(0));
                ko.applyBindings(uof.ui.Witness.viewModel, $("#EmployeeNonWitnessInputs").get(0));

               // ko.cleanNode($("#NonEmpWitnessView").get(0));
               // ko.applyBindings(uof.ui.Witness.viewModel, $("#NonEmpWitnessView").get(0));
                uof.ui.incident.detail.viewModel.incident.currentMode(localStorage.getItem('mode'));
                // Set All Edit mode values here
                if ((uof.ui.incident.detail.viewModel.incident.currentMode() == 'edit')) {
                    uof.ui.Witness.viewModel.isNonWitnessEditmode(true);
                    uof.ui.Witness.SetFormControls(false);

                }
                else if ((uof.ui.incident.detail.viewModel.incident.currentMode() == 'view')) {
                    uof.ui.Witness.viewModel.isNonWitnessEditmode(false);
                    uof.ui.Witness.SetFormControls(true);
                }

                $('#NEDOB').datetimepicker({ format: 'MM/DD/YYYY' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.Witness.viewModel.NonEmpwitness.DateOfBirth(newDate);
                    uof.ui.Witness.viewModel.NonEmpwitness.Age(uof.ui.CommonUILogic.detail.agefinding(newDate));
                });
                $('#NEImateType').change(function () {
                    var selected = $('#NEImateType option:selected').val();
                    if (selected == "NIN") {
                        uof.ui.Witness.viewModel.NonEmpwitness.LastName(null);
                        uof.ui.Witness.viewModel.NonEmpwitness.FirstName(null);
                        uof.ui.Witness.viewModel.NonEmpwitness.MiddleName(null);
                        uof.ui.Witness.viewModel.NonEmpwitness.SecondaryPhone(null);
                        uof.ui.Witness.viewModel.NonEmpwitness.PrimaryPhone(null);
                        uof.ui.Witness.viewModel.NonEmpwitness.DateOfBirth(null);
                        uof.ui.Witness.viewModel.NonEmpwitness.Age(null);
                        uof.ui.Witness.viewModel.NonEmpwitness.ZipCode(null);
                        uof.ui.Witness.viewModel.NonEmpwitness.Street(null);
                        uof.ui.Witness.viewModel.NonEmpwitness.City(null);
                    }
                    //else if (selected == "IN") {
                    //    uof.ui.Witness.viewModel.NonEmpwitness.LastName;
                    //    uof.ui.Witness.viewModel.NonEmpwitness.FirstName(null);
                    //    uof.ui.Witness.viewModel.NonEmpwitness.MiddleName(null);
                    //    uof.ui.Witness.viewModel.NonEmpwitness.SecondaryPhone(null);
                    //    uof.ui.Witness.viewModel.NonEmpwitness.PrimaryPhone(null);
                    //    uof.ui.Witness.viewModel.NonEmpwitness.DateOfBirth(null);
                    //    uof.ui.Witness.viewModel.NonEmpwitness.Age(null);
                    //    uof.ui.Witness.viewModel.NonEmpwitness.ZipCode(null);
                    //    uof.ui.Witness.viewModel.NonEmpwitness.Street(null);
                    //    uof.ui.Witness.viewModel.NonEmpwitness.City(null);
                    //}
                });

                $.prototype.hideUofOverlay();
            },
            fillAge: function (changeddate) {
                uof.ui.Witness.viewModel.NonEmpwitness.Age(uof.ui.CommonUILogic.detail.agefinding(changeddate));
            },
            bindMaskControl: function () {
                ko.bindingHandlers.inputmask =
                {
                    init: function (element, valueAccessor, allBindingsAccessor) {

                        var mask = valueAccessor();

                        var observable = mask.value;

                        if (ko.isObservable(observable)) {

                            $(element).on('focusout change', function () {

                                if ($(element).inputmask('isComplete')) {
                                    observable($(element).val());
                                } else {
                                    observable(null);
                                }

                            });
                        }

                        $(element).inputmask(mask);


                    },
                    update: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
                        var mask = valueAccessor();

                        var observable = mask.value;

                        if (ko.isObservable(observable)) {

                            var valuetoWrite = observable();

                            $(element).val(valuetoWrite);
                        }
                    }

                };
            },
            submitfocus: function () {
                setTimeout(function () { $("#btnNEWSubmit").focus(); }, 100);
            },

            SetFormControls: function (isDisable) {
                $("#EmployeeNonWitnessInputs").find('input, select, textarea, button').each(function () {
                    $(this).attr('disabled', isDisable);
                });
            },
            //Validate the controls on Add and duplicate popup
            nonEmpWitnessValidateMethod: function () {
                //remove old validation
                $("#NonEmpWitness .validationMessage").each(function () {
                    $(this).remove();
                });
                uof.ui.Witness.viewModel.NonEmpwitness.InmateType.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });
                uof.ui.Witness.viewModel.NonEmpwitness.BookingNum.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required,
                        onlyIf: function () {
                            return uof.ui.Witness.viewModel.NonEmpwitness.InmateType() === "IN"
                        }
                    },
                });
                uof.ui.Witness.viewModel.NonEmpwitness.LastName.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });
                uof.ui.Witness.viewModel.NonEmpwitness.FirstName.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });
                //uof.ui.Witness.viewModel.NonEmpwitness.MiddleName.extend({
                //    required: {
                //        params: true,
                //        message:  IncidentConstants.Required
                //    },
                //});
                //uof.ui.Witness.viewModel.NonEmpwitness.Age.extend({
                //    required: {
                //        params: true,
                //        message: IncidentConstants.Required,
                //        onlyIf: function () {
                //            return (uof.ui.Witness.viewModel.NonEmpwitness.InmateType() === "IN");
                //        }
                //    },
                //});
                uof.ui.Witness.viewModel.NonEmpwitness.DateOfBirth.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.Witness.viewModel.NonEmpwitness.InmateType() === "IN");
                        }
                    },
                });
                uof.ui.Witness.viewModel.NonEmpwitness.PrimaryPhone.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.Witness.viewModel.NonEmpwitness.InmateType() === "IN");
                        }
                    },
                });
                //uof.ui.Witness.viewModel.NonEmpwitness.SecondaryPhone.extend({
                //    required: {
                //        params: true,
                //        message: "a7" + IncidentConstants.Required
                //    },
                //});
                uof.ui.Witness.viewModel.NonEmpwitness.Street.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.Witness.viewModel.NonEmpwitness.TransorRefuse() === "T");
                        }
                    },
                });

                uof.ui.Witness.viewModel.NonEmpwitness.City.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.Witness.viewModel.NonEmpwitness.TransorRefuse() === "T");
                        }
                    },
                });
                uof.ui.Witness.viewModel.NonEmpwitness.ZipCode.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.Witness.viewModel.NonEmpwitness.TransorRefuse() === "T");
                        }
                    },
                });
            },

            //check the length of string
            lengthValidation: function (str, minChar) {
                var maxChar;
                if (uof.ui.Witness.getCharCount(str) < minChar[0] ||
                    uof.ui.Witness.getCharCount(str) > minChar[1])
                    return false;
                return true;
            },

            //get character based on ascii value
            getCharCount: function (str) {
                var result = 0;
                if (str !== undefined) {
                    for (var n = 0; n < str.length; n++) {
                        var charCode = str.charCodeAt();
                        if (typeof charCode === "number") {
                            if (charCode < 128)
                            { result = result + 1; }
                            else if (charCode < 2048)
                            { result = result + 2; }
                            else if (charCode < 65536)
                            { result = result + 3; }
                            else if (charCode < 2097152)
                            { result = result + 4; }
                            else if (charCode < 67108864)
                            { result = result + 5; }
                            else
                            { result = result + 6; }
                        }
                    }
                }
                return result;
            },

            //check for special characters
            isSpecialChar: function (objValue) {
                var count = 0;
                var pattr = ["\\", ":", "/", "*", "?", ">", "<", "[", "]", "{", "}", "|", "'", "=", "+"];

                while (count < pattr.length) {
                    if (objValue.indexOf(pattr[count]) > -1) {
                        return false;
                    }
                    count++;
                }
            },
            validateSaveNonWitFields: function () {
                var result = ko.validation.group([uof.ui.Witness.viewModel.NonEmpwitness.InmateType]);
                if (result().length > 0) {
                    uof.ui.Witness.viewModel.NonEmpwitness.InmateType.valueHasMutated();
                    result.showAllMessages();
                    $("#NewLastName").focus();
                    return false;
                }
                return true;
            },

            validateWitnessNonEmployeeFields: function (model) {
                uof.ui.Witness.viewModel.NonEmpwitness = {};
                uof.ui.Witness.viewModel.NonEmpwitness = ko.mapping.fromJS(model, ko.mapping.toJS(uof.ui.Witness.viewModel.NonEmpwitness));
                uof.ui.Witness.nonEmpWitnessValidateMethod();
                var result = ko.validation.group(uof.ui.Witness.viewModel.NonEmpwitness, { deep: true });
                if (result().length > 0) {
                    uof.ui.Witness.viewModel.NonEmpwitness.LastName.valueHasMutated();
                    uof.ui.Witness.viewModel.NonEmpwitness.FirstName.valueHasMutated();
                    uof.ui.Witness.viewModel.NonEmpwitness.MiddleName.valueHasMutated();
                    uof.ui.Witness.viewModel.NonEmpwitness.PrimaryPhone.valueHasMutated();
                    //uof.ui.Witness.viewModel.NonEmpwitness.SecondaryPhone.valueHasMutated();
                    uof.ui.Witness.viewModel.NonEmpwitness.ZipCode.valueHasMutated();
                    result.showAllMessages();
                    $("#NewLastName").focus();
                    return false;
                }
                return true;
            },
            //
            listLoad: function () {
                $(".kendo-mini-pager").removeClass("k-pager-wrap");
                $(".kendo-mini-pager").removeClass("k-widget");
                $(".kendo-mini-pager").removeClass("k-floatwrap");
            },
            saveNonWitnessInfo: function () {
                if (uof.ui.Witness.validateSaveNonWitFields()) {
                    uof.ui.Witness.viewModel.NonEmpwitness.IsOnlySave(true);
                    $.prototype.showUofOverlay();
                    if (UoFParams.IncidentId != "")
                        uof.ui.Witness.viewModel.NonEmpwitness.IncidentId = UoFParams.IncidentId;
                    else
                        uof.ui.Witness.viewModel.NonEmpwitness.IncidentId = uof.ui.incident.detail.selectedContext.selectedIncident()

                    var mappedData = ko.mapping.toJS(uof.ui.Witness.viewModel.NonEmpwitness);

                    $.ajax(
                           {
                               url: window.location.uofAPIOrigin() + '/api/User/SaveWitnessUser',
                               cache: false,
                               type: "POST",
                               dataType: 'json',
                               data: JSON.stringify(mappedData),
                               contentType: "application/json;charset=utf-8",
                               beforeSend: function myfunction() {

                               },
                               success: function (empData) {
                                   $.prototype.hideUofOverlay();
                                   //uof.ui.Witness.fillNonWitnesslist(ko.mapping.toJS(ko.mapping.toJS(uof.ui.Witness.viewModel.NonEmpwitness)));
                                   uof.ui.Witness.getEmpNonWitnessData();
                                   showAlert(empData);
                                   uof.ui.Witness.viewModel.NonEmpwitness.Mode = "Add";
                                   uof.ui.Witness.CancelDetails();
                                   $("#NewLastName").focus();
                               },
                               error: function (e) {
                                   $.prototype.hideUofOverlay();
                                   showAlert("Error loading Data - Non-Employee Witness");
                                   $("#NewLastName").focus();
                               },
                           });
                }
            },
            saveNonWitnessDetails: function () {
                if (uof.ui.Witness.validateWitnessNonEmployeeFields()) {
                    uof.ui.Witness.saveNonWitnessInfo();
                }
            },

            fillNonWitnesslist: function (witness) {
                uof.ui.Witness.viewModel.nonEmpWitnessList.push({
                    EmployeeID: witness.EmployeeId,
                    Name: witness.LastName + ' ' + witness.FirstName + ' ' + witness.Middle,
                    UnitofAssignment: witness.UnitofAssignment,
                    WorkAssignment: witness.WorkAssignment,
                    //Type: $("#EmpWitness").is(":checked") ? "EmployeeId" : "Non -EmployeeId",
                    Type: "Employee",
                });
            },

            bindNonEmpWitnessList: function () {
                var sortState = '';
                var InvolvedList = ko.mapping.toJS(uof.ui.Witness.viewModel.nonEmpWitnessList);
                var dataTb = [];
                $.grep(InvolvedList, function (i) {
                    dataTb.push({ Name: i.Name, Address: i.Address, City: i.City, WitnessType: i.Type });
                });
                var datasourcetbu = new kendo.data.DataSource({
                    data: dataTb,
                    pageSize: 10,
                    change: function (e) {
                        var newState = JSON.stringify(this.sort());
                        if (newState != sortState) {
                            sortState = newState;
                            e.preventDefault();
                            this.page(1);
                        }

                    }
                });
                var cntrl = $("#NonWitnessList");
                var grid = cntrl.kendoGrid({
                    dataSource: datasourcetbu,
                    selectable: false,
                    scrollable: true,
                    sortable: { allowUnsort: false },
                    height: "200",
                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [10, 20, 50],
                        buttonCount: 5,
                        messages: {
                            itemsPerPage: "wintness per page"
                        }
                    },
                    columns:
                            [
                                 {
                                     field: "Name",
                                     headerTemplate: kendo.format('<span  class="word-break-txt">{0}</span>', "Name"),
                                     width: 50
                                 },
                                {
                                    field: "Address",
                                    headerTemplate: kendo.format('<span  class="word-break-txt">{0}</span>', "Address"),
                                    width: 100
                                },
                                 {
                                     field: "City",
                                     headerTemplate: kendo.format('<span  class="word-break-txt">{0}</span>', "City"),
                                     width: 150
                                 },
								 {
								     field: "WitnessType",
								     headerTemplate: kendo.format('<span  class="word-break-txt">{0}</span>', "Witness Type"),
								     width: 50
								 }
                            ],
                    change: function (e) {
                    }
                }).data().kendoGrid;

                $.prototype.hideUofOverlay();
                var tooltip = $("#NonWitnessList").kendoTooltip({
                    filter: "td:nth-child(2)", //this filter selects the first column cells                   
                    content: function (e) {
                        var dataItem = $("#NonWitnessList").data("kendoGrid").dataItem(e.target.closest("tr"));
                        return $template(dataItem);
                    },

                }).data("kendoTooltip");
                $("#NonWitnessList").kendoTooltip({
                    filter: ".cellTooltip",
                });


                grid.refresh();
            },

            //Grid Binding 
            getEmpNonWitnessData: function () {
                // Ajax call to server to get Organziation records
                $.prototype.showUofOverlay();
                var dlAjaxOption =
                    {
                        url: window.location.uofAPIOrigin() + '/api/User/GetWitnessUser',
                        cache: false,
                        type: "GET",
                        data: "incidentId=" + uof.ui.incident.detail.selectedContext.selectedIncident() + "&witnessType=4",
                        dataType: 'json',
                        contentType: "application/json;charset=utf-8",
                        success: function (nonWitnessEmpl) {
                            uof.ui.Witness.viewModel.nonEmpWitnessList = ko.observableArray(nonWitnessEmpl);
                            empNonWitnessDataSource = new kendo.data.DataSource({
                                data: nonWitnessEmpl,
                                pageSize: 20
                            });


                            //setting all Org Data to kendo
                            $("#NonWitnessList").kendoGrid({
                                dataSource: empNonWitnessDataSource,
                                height: 240,
                                scrollable: true,
                                sortable: true,
                                filterable: false,
                                pageable: {
                                    refresh: false,
                                    pageSizes: true,
                                    pageSizes: [20, 50, 100],
                                    buttonCount: 5,
                                    messages: {
                                    },
                                },
                                columns: [
                                {
                                    field: "IncidentUserWitnessId",
                                    headerTemplate: kendo.format('<span  class="word-break-txt" title="{0}" >{1}</span>', "ID", "ID"),
                                   // template: $("#NonWitnessEmpDetails").html(),
                                    width: 50
                                },
                                 {
                                     field: "Name",
                                     headerTemplate: kendo.format('<span  class="word-break-txt" title="{0}" >{1}</span>', "Name", "Name"),
                                     width: 150
                                 },
                                 {
                                     field: "IncidentUserWitnessId",
                                     template: $("#editNonEmpWitnessEmpDetails").html(),
                                     headerTemplate: '',
                                     width: 30,
                                 },
                                 {
                                     field: "IncidentUserWitnessId",
                                     template: $("#deleteNonEmpWitnessEmpDetails").html(),
                                     headerTemplate: '',
                                     width: 30,
                                     hidden: !uof.ui.Witness.viewModel.isNonWitnessEditmode()
                                 }

                                ],
                                //  dataBound: athoc.iws.organizationManager.OnDataBound,
                                change: function (e) {
                                    var model = this.dataItem(this.select());
                                }
                            }).data().kendoGrid;
                            empNonWitnessDataSource.read();
                            $.prototype.hideUofOverlay();
                            uof.ui.Witness.setKendoGridHeight();
                            if (!uof.ui.Witness.viewModel.isNonWitnessEditmode()) {
                                $("#NonWitnessList").find('button').html('View');
                            }
                        },
                        error: function (e) {
                            $.prototype.hideUofOverlay();
                            showAlert(e.responseText);
                        }

                    };
                // Call ajax
                var ajaxOptions = $.extend({}, 'GET', dlAjaxOption);
                $.ajax(ajaxOptions);

            },

            setKendoGridHeight: function () {
                $('.k-grid-content').attr('style', 'height:70%');
            },

            cancelNonWitnessView: function () {

                uof.ui.Witness.viewModel.isNonWitnessEditmode(true); return true;
            },
            CancelDetails: function () {
                uof.ui.Witness.viewModel.NonEmpwitness.Mode = ("Add");
                uof.ui.Witness.viewModel.NonEmpwitness.IncidentId = ko.observable(0);
                uof.ui.Witness.viewModel.NonEmpwitness.UserId(null);
                uof.ui.Witness.viewModel.NonEmpwitness.UserTypeId = ko.observable(4);
                uof.ui.Witness.viewModel.NonEmpwitness.LastName(null);
                uof.ui.Witness.viewModel.NonEmpwitness.FirstName(null);
                uof.ui.Witness.viewModel.NonEmpwitness.MiddleName(null);
                uof.ui.Witness.viewModel.NonEmpwitness.Age(null);
                uof.ui.Witness.viewModel.NonEmpwitness.DateOfBirth(null);
                uof.ui.Witness.viewModel.NonEmpwitness.Street(null);
                uof.ui.Witness.viewModel.NonEmpwitness.City(null);
                uof.ui.Witness.viewModel.NonEmpwitness.ZipCode(null);
                uof.ui.Witness.viewModel.NonEmpwitness.PrimaryPhone(null);
                uof.ui.Witness.viewModel.NonEmpwitness.SecondaryPhone(null);
                uof.ui.Witness.viewModel.NonEmpwitness.InmateType(null);
                uof.ui.Witness.viewModel.NonEmpwitness.TransorRefuse(null);
                uof.ui.Witness.viewModel.NonEmpwitness.BookingNum(null);
                result = ko.validation.group(uof.ui.Witness.viewModel.NonEmpwitness, { deep: true });
                result.showAllMessages(false);

                $('#NEDOB').datetimepicker({ format: 'MM/DD/YYYY' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.Witness.viewModel.NonEmpwitness.DateOfBirth(newDate);
                });
            },
            viewNonWitnessEmployee: function (incidentUserWitnessId) {

                var selectedData = _.find(empNonWitnessDataSource.data(), function (item) {
                    return item.IncidentUserWitnessId == incidentUserWitnessId;
                });

                if (selectedData != null) {
                    uof.ui.Witness.viewModel.isNonWitnessEditmode(false);
                    uof.ui.Witness.viewModel.NonEmpwitness = {};
                    uof.ui.Witness.viewModel.NonEmpwitness = ko.mapping.fromJS(selectedData, ko.mapping.toJS(uof.ui.Witness.viewModel.NonEmpwitness));
                   // ko.cleanNode($("#NonEmpWitnessView").get(0));
                   // ko.applyBindings(uof.ui.Witness.viewModel, $("#NonEmpWitnessView").get(0));
                }
            },

            editNonWitnessEmployee: function (incidentUserWitnessId) {

                var selectedData = _.find(empNonWitnessDataSource.data(), function (item) {
                    return item.IncidentUserWitnessId == incidentUserWitnessId;
                });

                if (selectedData != null) {
                    uof.ui.Witness.viewModel.NonEmpwitness = {};
                    if (selectedData.DateOfBirth != null)
                        selectedData.DateOfBirth = moment(selectedData.DateOfBirth).format("MM/DD/YYYY");
                    uof.ui.Witness.viewModel.NonEmpwitness = ko.mapping.fromJS(selectedData, ko.mapping.toJS(uof.ui.Witness.viewModel.NonEmpwitness));
                    uof.ui.Witness.nonEmpWitnessValidateMethod();
                    ko.cleanNode($("#EmployeeNonWitnessInputs").get(0));
                    ko.applyBindings(uof.ui.Witness.viewModel, $("#EmployeeNonWitnessInputs").get(0));
                    uof.ui.Witness.viewModel.NonEmpwitness.Mode = "Edit";
                }
            },
            deleteNonWitnessEmployee: function (incidentUserWitnessId) {
                var selectedData = _.find(empNonWitnessDataSource.data(), function (item) {
                    return item.IncidentUserWitnessId == incidentUserWitnessId;
                });

                $.prototype.showUofOverlay();
                $.ajax(
               {
                   url: window.location.uofAPIOrigin() + '/api/User/DeleteUser?incidentId=' + selectedData.IncidentId + '&userId=' + incidentUserWitnessId + '&employeeNumber=' + selectedData.BookingNumber + '&userType=4',
                   cache: false,
                   type: "DELETE",
                   dataType: 'json',
                   contentType: "application/json;charset=utf-8",
                   beforeSend: function myfunction() {

                   },
                   success: function (data) {
                       showAlert(data);
                       uof.ui.Witness.getEmpNonWitnessData();
                       $.prototype.hideUofOverlay();
                   },
                   error: function (e) {
                       $.prototype.hideUofOverlay();
                       showAlert(e.responseText);
                   },
               });

            },

        }
    }();

}