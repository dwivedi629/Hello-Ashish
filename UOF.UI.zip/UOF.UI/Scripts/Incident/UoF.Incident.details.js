﻿var uof = uof || {};
uof.ui = uof.ui || {};
uof.ui.incident = uof.ui.incident || {};

if (uof.ui.incident) {
    uof.ui.incident.detail = function () {
        return {

            parameters: null,
            isChanged: false,
            selectedIncidentID: 0,
            SelectedPageNumber: 0,
            init: function (args) {
                this.parameters = args;
            },

            incidentDBSource: null,

            selectedContext: {
                selectedIncident: ko.observable(0),
                selectedCategory: ko.observable(0)
            },
            headerStatistics: {
                noOfNewIncidents: ko.observable(0),
                completedIncidents: ko.observable(0),
                inProcessIncidents: ko.observable(0),
                rejectedIncidents: ko.observable(0),
            },
            ExplanationCriteria: {
                userId: '',
                userRole: '',
                incidentId: 0,
                formId: 0
            },
            viewModel: {
                ErrorFields: ko.observable(),
                isInvestOfficer: ko.observable(false),
                hasError: ko.observable(false),
                // To add different location, just add the one more item in this list
                Locations: ko.observableArray([]),
                ReasonforContact: ko.observableArray([]),
                CustodyEvent: ko.observableArray([]),
                StationSource: ko.observableArray([]),
                //FacilitySource: ko.observableArray([]),
                StagingSource: ko.observableArray([]),
                //BureausSource: ko.observableArray([]),
                LocationOfForce: ko.observableArray([]),
                Resistances: ko.observableArray([]),
                PerceivedArmed: ko.observableArray([]),
                getEmployeeDetails: function (empId, optionCriteria) {
                    if (empId != undefined)
                        uof.ui.incident.detail.getEmployeeDetails(empId, optionCriteria);
                },
                TypeOfForce: ko.observableArray([]),

                PFDataSource: ko.observable([
                { Name: 'Cell Extraction', Code: 'CE' },
                { Name: 'Other Planned Force', Code: 'OPF' },
                ]),
                FormNames: ko.observableArray([]),
                InvolvedUsers: ko.observableArray([]),
                DuplicateURn: ko.observable(false),
                incident: {
                    isSRApproved: ko.observable(false),
                    IsOnlySave: ko.observable(true),
                    IncidentId: ko.observable(0),
                    AddressId: ko.observable(),
                    currentMode: ko.observable(),
                    URN: ko.observable(),
                    ReferenceNo: ko.observable(),
                    IncidentDate: ko.observable(),
                    Time: ko.observable(0),
                    IncidentLocationName: ko.observable(),
                    AddressNumber: ko.observable(),
                    Street: ko.observable(),
                    City: ko.observable(),
                    SelectedCity: ko.observable(),
                    ZipCode: ko.observable(),
                    //Business Address
                    BusinessName: ko.observable(),
                    //BusinessZipCode: ko.observable(),
                    //BusinessCity: ko.observable(),
                    //BusinessStreet: ko.observable(),
                    //BusinessAddressNumber: ko.observable(),
                    //StationFacility: ko.observable(),
                    //Bureau: ko.observable(),
                    Station: ko.observable(),
                    //Facility: ko.observable(),
                    AddressTypeId: ko.observable(1),
                    ContactTypeId: ko.observable(),
                    CTOthers: ko.observable(),
                    Perceivedarmed: ko.observable(),
                    IsByFootPursuit: ko.observable(),
                    IsByVehiclePursuit: ko.observable(),
                    IsAdminInvestigation: ko.observable("N"),
                    IncidentCategoryId: ko.observable(),
                    //ForceTypeId: ko.observable(),
                    ForceTypeId: ko.observableArray([]),
                    IsDeptyInjury: ko.observable("N"),
                    IsSuspectInjury: ko.observable("N"),
                    IsUnderlyingArrest: ko.observable("NA"),
                    IsUnderlyingCrime: ko.observable("N"),
                    IsOnK12Campus: ko.observable("NA"),
                    LevelofResistance: ko.observable(),
                    CiviliansUnderlyingArrest: ko.observable("N"),
                    CiviliansUnderlyingCrime: ko.observable("N"),
                    PrimaryAgency: ko.observable(),
                    CustodyEventId: ko.observable(),
                    AssaulatedofficersNumber: ko.observable(),

                    ExperiencedUOFNumber: ko.observable(),
                    DeputyUOFNumber: ko.observable(),
                    DeputyAssaulatedNumber: ko.observable(),

                    DeputyPresentonScene: ko.observable(),
                    SelectedCivilianResistance: ko.observable(),

                    SelectedCivilianConfirmedarmed: ko.observable(),
                    Location: ko.observable(),
                    Forecasting: ko.observable("N"),

                    IsIABNotified: ko.observable("N"),
                    IABNotifiedUserId: ko.observable(),
                    PersonNotified: ko.observable(),
                    IABNotifiedEmailId: ko.observable(),
                    IsIABHandling: ko.observable("N"),
                    IABHandlingUserId: ko.observable(),
                    IABHandlingFirstName: ko.observable(),
                    IABHandlingLastName: ko.observable(),
                    IABHandlingRank: ko.observable(),
                    IABHandlingEmailId: ko.observable(),
                    IsIABRollOut: ko.observable("N"),
                    IABRolloutEmployees: ko.observable(),

                    IsCFRTNotified: ko.observable("N"),
                    CFRTNotifiedUserId: ko.observable(),
                    CFRTNotifiedFirstName: ko.observable(),
                    CFRTNotifiedLastName: ko.observable(),
                    CFRTNotifiedRank: ko.observable(),
                    CFRTNotifiedEmailId: ko.observable(),
                    IsCFRTRollOut: ko.observable("N"),
                    CFRTRolloutEmployees: ko.observable(),
                    PPINo: ko.observable(),
                    eLOTS: ko.observable(),
                    elotsYN: ko.observable("Y"),
                    elotsNoReason: ko.observable(),

                    IsReactiveForce: ko.observable(false),
                    IsPlannedForce: ko.observable(false),
                    PRReason: ko.observable(),
                    IsInmateInjuryReportWritten: ko.observable("N"),
                    IsMedicalStaffPresent: ko.observable("N"),
                    IsMentalHealthPresent: ko.observable("N"),
                    IsSuperVisorPresent: ko.observable("N"),
                    IsMedicalRecordChecked: ko.observable("NA"),
                    IsExtractionOrderByMedical: ko.observable("NA"),
                    ExtractionEmpId: ko.observable(),
                    IsMentalHealthProfessional: ko.observable("NA"),
                    MentalHealthEmpId: ko.observable(),
                    MentalHealthEmpName: ko.observable(),
                    IsDepartmentSignAdmonishmentAndNotedChangesInReport: ko.observable("NA"),
                    //Added
                    IsInvestigatorDirectedTheForce: ko.observable(""),
                    SupervisorDirectedId: ko.observable(),
                    SupervisorDirectedFirstName: ko.observable(),
                    SupervisorDirectedLastName: ko.observable(),
                    SupervisorDirectedRank: ko.observable(),
                    SupervisorDirectedMailId: ko.observable(),

                    IsInvestigatorParticipatedInTheForce: ko.observable(""),
                    IsInvestigatorPlannedTheForce: ko.observable("NA"),
                    IsStaffEscortInvolvedInmates: ko.observable(""),
                    IsDepartmentMembersSeparated: ko.observable("NA"),

                    IsCCTVCoverage: ko.observable("Y"),
                    CCTVNoReason: ko.observable(),
                    CCTVExtracted: ko.observable("N"),
                    IsVideoOfIncident: ko.observable("Y"),
                    VideoShootedNoReason: ko.observable(),
                    ForceLocation: ko.observableArray([]),

                    Lifethreatening: ko.observable(),
                    Assulative: ko.observable(),



                    IsCFRTHandling: ko.observable("N"),
                    CFRTHandlingUserId: ko.observable(),
                    CFRTHandlingFirstName: ko.observable(),
                    CFRTHandlingLastName: ko.observable(),
                    CFRTHandlingRank: ko.observable(),
                    CFRTHandlingEmailId: ko.observable(),
                    PFData: ko.observable(),
                    //PFExtraction: ko.observable(),
                    //PFPlannedUoF: ko.observable(),
                    MedicalLife: ko.observable(),
                    MedRcdPrior: ko.observable(),
                    PlanAltered: ko.observable(),
                    MHS: ko.observable(),
                    MHSReason: ko.observable(),

                    selectedTypeOfInjury: ko.observable(),
                    EmpId: ko.observable(),
                    Staging: ko.observable(),
                    AddlSerg: ko.observable(false),
                    AdditionalSergeant: ko.observableArray(),



                },
                emailMode: {
                    EmailId: ko.observable(),
                    IncidentId: ko.observable(),
                },
                RCModel: {
                    IncidentId: ko.observable(),
                    FormId: ko.observable(),
                    CommentedBy: ko.observable(),
                    SubmitedId: ko.observable(),
                    ReviewComments: ko.observable(),
                },
                Cat3Model: {
                    IncidentId: ko.observable(),
                    WCID: ko.observable(),
                    WCLName: ko.observable(),
                    WCFName: ko.observable(),
                    WCMName: ko.observable(),
                    WCRank: ko.observable(),
                    WCEmailId: ko.observable(),
                },
                AssignModel: {
                    IncidentId: ko.observable(),
                    EID: ko.observable(),
                    ELName: ko.observable(),
                    EFName: ko.observable(),
                    EMName: ko.observable(),
                    ERank: ko.observable(),
                    EmailId: ko.observable(),
                    ERankAbrv: ko.observable(),
                    //WCID: ko.observable(),
                    //WCLName: ko.observable(),
                    //WCFName: ko.observable(),
                    //WCMName: ko.observable(),
                    //WCRank: ko.observable(),
                    //UCID: ko.observable(),
                    //UCLName: ko.observable(),
                    //UCFName: ko.observable(),
                    //UCMName: ko.observable(),
                    //UCRank: ko.observable(),
                    //CMID: ko.observable(),
                    //CMLName: ko.observable(),
                    //CMFName: ko.observable(),
                    //CMMName: ko.observable(),
                    //CMRank: ko.observable(),
                    //WCEmailId: ko.observable(),
                    //UCEmailId: ko.observable(),
                    //CMEmailId: ko.observable(),
                },
            },
            //load method, will be tirggered on document load
            loadIncident: function (incidentId, selectedPageNumber) {
                uof.ui.incident.detail.selectedIncidentID = incidentId != null ? incidentId : 0;
                uof.ui.incident.detail.SelectedPageNumber = selectedPageNumber != null ? selectedPageNumber : 0;
                this.bindIncidentDetails();
                this.headerStatisticalData();
                localStorage.setItem('formMode', "");
                localStorage.setItem('selectedIncidentId', 0);
                this.updateMenuURL();
                this.getAllForm();

                //binding Incident popup page
                ko.cleanNode($("#divAssignIncident").get(0));
                ko.applyBindings(uof.ui.incident.detail.viewModel, $("#divAssignIncident").get(0));

                ko.cleanNode($("#divAssignOthers").get(0));
                ko.applyBindings(uof.ui.incident.detail.viewModel, $("#divAssignOthers").get(0));

                ko.cleanNode($("#divReviewComments").get(0));
                ko.applyBindings(uof.ui.incident.detail.viewModel, $("#divReviewComments").get(0));

                ko.cleanNode($("#divAssignCat3").get(0));
                ko.applyBindings(uof.ui.incident.detail.viewModel, $("#divAssignCat3").get(0));
            },
            RemoveAddlSergants: function (serg) {
                uof.ui.incident.detail.viewModel.incident.AdditionalSergeant.remove(serg);
            },
            AddAddlSergants: function () {
                uof.ui.incident.detail.viewModel.incident.AdditionalSergeant.push(new uof.ui.incident.detail.AddlSeg());
            },



            load: function () {
                uof.ui.incident.detail.viewModel.incident.currentMode(localStorage.getItem('mode'));
                ko.validation.init({ insertMessages: true });
                uof.ui.incident.detail.initiateBindings();
                uof.ui.incident.detail.bindMaskControl();
                uof.ui.incident.detail.subscribeEvents();
                this.updateMenuURL();

                uof.ui.incident.detail.selectedContext.selectedIncident(localStorage.getItem('selectedIncidentId'));
                uof.ui.incident.detail.selectedContext.selectedCategory(localStorage.getItem('selectedCategory'));
                //binding Incident popup page
                ko.cleanNode($("#leftTabs").get(0));
                ko.applyBindings(uof.ui.incident.detail.selectedContext, $("#leftTabs").get(0));

                uof.ui.incident.detail.validateControls();
                //binding Incident popup page
                ko.cleanNode($("#Incident").get(0));
                ko.applyBindings(uof.ui.incident.detail.viewModel, $("#Incident").get(0));

                uof.ui.incident.detail.initiatePickers();
                uof.ui.readOnlyPageOnPermission.changeAllControlsToReadOnly('InvolvedEmp', 'InvolvedEmp');
                uof.ui.incident.detail.viewModel.incident.ContactTypeId.isModified(false);
                uof.ui.incident.detail.viewModel.incident.Station.isModified(false);
                uof.ui.incident.detail.changeFormControlMode();
                $(document).on('keyup', "#ReferenceNo", function () {
                    var foo = $('#ReferenceNo').val().replace(/-/g, ""); // remove hyphens
                    if (foo.length > 0) {
                        foo = uof.ui.incident.detail.format(foo, [4, 4, 4, 6], "-");
                    }
                    $(this).val(foo);
                });
                if (uof.ui.incident.detail.viewModel.incident.ContactTypeId() == 'ICE') {
                    $("#ddlCustodyEvent").prop('disabled', false);                
                }
                if (uof.ui.incident.detail.viewModel.incident.ContactTypeId() == 'OTH') {
                    $("#CTOther").prop('disabled', false);
                }
                if (uof.ui.incident.detail.viewModel.incident.IsPlannedForce())
                {
                    $("#PFData").prop('disabled', false);
                }                
                if (uof.ui.incident.detail.viewModel.incident.IsReactiveForce() && uof.ui.incident.detail.viewModel.incident.IsReactiveForce())
                {
                    $("#PRReason").prop('disabled', false);                    
                }
                if (uof.ui.incident.detail.viewModel.incident.currentMode() == 'view') {
                    $("#IncTypeOfForce").prop('disabled', true);
                    $("#IncidentLOF").prop('disabled', true);
                }
                if (uof.ui.incident.detail.viewModel.incident.IsCCTVCoverage() == 'N' ) {
                     $("#VideoNoReason").prop('disabled', false);                    
                }
                if (uof.ui.incident.detail.viewModel.incident.IsCCTVCoverage() == 'N') {
                    $("#VideoNoReason").prop('disabled', false);
                }
            },
            format: function (input, format, sep) {
                var output = "";
                var idx = 0;
                for (var i = 0; i < format.length && idx < input.length; i++) {
                    output += input.substr(idx, format[i]);
                    if (idx + format[i] < input.length) output += sep;
                    idx += format[i];
                }

                output += input.substr(idx);
                return output;
            },
            changeFormControlMode: function () {
                if ((uof.ui.incident.detail.viewModel.incident.currentMode() == 'Edit')) {
                    uof.ui.incident.detail.SetFormControls(false);
                }
                else if ((uof.ui.incident.detail.viewModel.incident.currentMode() == 'view')) {
                    uof.ui.incident.detail.SetFormControls(true);
                }
            },

            AddlSeg: function () {
                var self = this;
                self.EmployeeNumber = ko.observable().extend({
                    //required: {
                    //    params: true,
                    //    message: IncidentConstants.Required

                    //},
                });
                self.Name = ko.observable().extend({
                    //required: {
                    //    params: true,
                    //    message: IncidentConstants.Required
                    //},
                });
                self.EmailId = ko.observable().extend({
                    //required: {
                    //    params: true,
                    //    message: IncidentConstants.Required
                    //},
                });
            },

            getInvolvedUserWithName: function () {
                $.prototype.showUofOverlay();
                $.ajax(
                    {
                        url: window.location.uofAPIOrigin() + '/api/User/GetInvolvedUserWithName',
                        cache: false,
                        data: { IncidentId: uof.ui.incident.detail.selectedContext.selectedIncident() },
                        type: "GET",
                        dataType: 'json',
                        contentType: "application/json;charset=utf-8",
                        beforeSend: function myfunction() {

                        },
                        success: function (userData) {
                            if (userData != null) {
                                uof.ui.incident.detail.viewModel.InvolvedUsers(userData);
                                //var forms = [];
                                //forms = $.map($.grep(formData, function (d) {
                                //    return d.IsMenuItem && d.ParentId > 0;
                                //}), function (d) {
                                //    uof.ui.incident.detail.viewModel.InvolvedUsers.push(userData);
                                //});
                            }
                            $.prototype.hideUofOverlay();
                        },
                        error: function (e) {
                            $.prototype.hideUofOverlay();
                            showAlert(e.responseText);
                        },
                    });
            },
            getAllForm: function () {
                // $.prototype.showUofOverlay();
                $.ajax(
                    {
                        url: window.location.uofAPIOrigin() + '/api/Settings/GetFormsName',
                        cache: false,
                        type: "GET",
                        dataType: 'json',
                        contentType: "application/json;charset=utf-8",
                        beforeSend: function myfunction() {

                        },
                        success: function (formData) {
                            if (formData != null) {
                                var forms = [];
                                forms = $.map($.grep(formData, function (d) {
                                    return d.IsMenuItem && d.ParentId > 0;
                                }), function (d) {
                                    uof.ui.incident.detail.viewModel.FormNames.push({ Name: d.FormName, Code: d.FormId });
                                });
                            }
                            // $.prototype.hideUofOverlay();
                        },
                        error: function (e) {
                            $.prototype.hideUofOverlay();
                            showAlert(e.responseText);
                        },
                    });
            },
            setEmployeeInformation: function () {
                if (this.viewModel.incident.IsIABNotified() == "Y" && this.viewModel.incident.IABNotifiedUserId() != "") {
                    //IABHandlingUserId
                    this.getEmployeeDetails(this.viewModel.incident.IABNotifiedUserId(), "IABNotified");
                }
                if (this.viewModel.incident.IsIABHandling() == "Y" && this.viewModel.incident.IABHandlingUserId() != "") {
                    //IABHandlingUserId
                    this.getEmployeeDetails(this.viewModel.incident.IABHandlingUserId(), "IABHandling");
                }

                if (this.viewModel.incident.IsCFRTNotified() == "Y" && this.viewModel.incident.CFRTNotifiedUserId() != "") {

                    this.getEmployeeDetails(this.viewModel.incident.CFRTNotifiedUserId(), "CFRTNotified");
                }

                if (this.viewModel.incident.IsCFRTHandling() == "Y" && this.viewModel.incident.CFRTHandlingUserId() != "") {
                    this.getEmployeeDetails(this.viewModel.incident.CFRTHandlingUserId(), "CFRTHandling");
                }
                if (this.viewModel.incident.IsInvestigatorDirectedTheForce() == "Y" && this.viewModel.incident.IsInvestigatorDirectedTheForce() != "") {
                    this.getEmployeeDetails(this.viewModel.incident.SupervisorDirectedId(), "IsInvestigatorDirected");
                }
                if (this.viewModel.incident.IsMentalHealthProfessional() == "Y" && this.viewModel.incident.IsMentalHealthProfessional() != "") {
                    this.getEmployeeDetails(this.viewModel.incident.MentalHealthEmpId(), "MentalHealthEmpId");
                }


            },
            cancelAssign: function () {
                //$("#divAssignIncident").addClass('hide');
                $("#divAssignIncident").data("kendoWindow").close();
            },

            ValidateOnlyNumber: function (e) {
                // Allow: backspace, delete, tab, escape, enter and .
                if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
                    // Allow: Ctrl+A, Command+A
                    (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
                    // Allow: home, end, left, right, down, up
                    (e.keyCode >= 35 && e.keyCode <= 40)) {
                    // let it happen, don't do anything
                    return;
                }
                // Ensure that it is a number and stop the keypress
                if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
                    e.preventDefault();
                }
            },
            AssignCommanders: function () {
                if (uof.ui.incident.detail.validateAssignFields()) {
                    var commandersData = ko.observableArray();
                    var oData = new Object();
                    oData.IncidentId = uof.ui.incident.detail.viewModel.AssignModel.IncidentId();
                    oData.EmployeeId = uof.ui.incident.detail.viewModel.AssignModel.EID();
                    oData.FirstName = uof.ui.incident.detail.viewModel.AssignModel.EFName();
                    oData.LastName = uof.ui.incident.detail.viewModel.AssignModel.ELName();
                    oData.MiddleName = uof.ui.incident.detail.viewModel.AssignModel.EMName();
                    oData.Rank = uof.ui.incident.detail.viewModel.AssignModel.ERank();
                    oData.EmailId = uof.ui.incident.detail.viewModel.AssignModel.EmailId();

                    switch (uof.ui.incident.detail.viewModel.AssignModel.ERankAbrv()) {
                        case "WC":
                        case "LT":
                        case "L/T":
                            oData.UserTypeId = 5;
                            break;
                        case "CAPT":
                        case "CPT":
                            oData.UserTypeId = 6;
                            break;
                        case "CMDR":
                            oData.UserTypeId = 7;
                            break;
                        case "CHIEF":
                            oData.UserTypeId = 13;
                            break;

                    }

                    commandersData.push(oData);

                    var mappedData = ko.mapping.toJS(commandersData);
                    $.ajax(
                           {
                               url: window.location.uofAPIOrigin() + '/api/User/AssigntoCommander',
                               cache: false,
                               type: "POST",
                               dataType: 'json',
                               data: JSON.stringify(mappedData),
                               contentType: "application/json;charset=utf-8",
                               beforeSend: function myfunction() {

                               },
                               success: function (assignData) {
                                   $.prototype.hideUofOverlay();
                                   $("#divAssignIncident").data("kendoWindow").close();
                                   uof.ui.incident.detail.bindIncidentDetails();
                               },
                               error: function (e) {
                                   $.prototype.hideUofOverlay();
                                   showAlert(e.responseText);
                               },
                           });
                }

            },
            validateAssignFields: function () {
                result = ko.validation.group(uof.ui.incident.detail.viewModel.AssignModel, { deep: true });
                if ((result().length > 0)) {
                    //To show the message
                    uof.ui.incident.detail.viewModel.AssignModel.WCID.valueHasMutated();
                    uof.ui.incident.detail.viewModel.AssignModel.UCID.valueHasMutated();
                    uof.ui.incident.detail.viewModel.AssignModel.CMID.valueHasMutated();
                    return false;
                }
                return true;
            },
            validateEmailField: function () {
                result = ko.validation.group(uof.ui.incident.detail.viewModel.emailMode, { deep: true });
                if ((result().length > 0)) {
                    //To show the message
                    uof.ui.incident.detail.viewModel.emailMode.EmailId.valueHasMutated();
                    return false;
                }
                return true;


            },
            validateComments: function () {
                result = ko.validation.group(uof.ui.incident.detail.viewModel.RCModel, { deep: true });
                if ((result().length > 0)) {
                    //To show the message
                    uof.ui.incident.detail.viewModel.RCModel.FormId.valueHasMutated();
                    uof.ui.incident.detail.viewModel.RCModel.SubmitedId.valueHasMutated();
                    uof.ui.incident.detail.viewModel.RCModel.ReviewComments.valueHasMutated();
                    return false;
                }
                return true;


            },
            validateCatInc: function () {
                result = ko.validation.group(uof.ui.incident.detail.viewModel.Cat3Model, { deep: true });
                if ((result().length > 0)) {
                    //To show the message
                    uof.ui.incident.detail.viewModel.Cat3Model.WCID.valueHasMutated();
                    return false;
                }
                return true;


            },
            SetFormControls: function (isDisable) {
                $("#Incident").find('input, select, textarea, button').each(function () {
                    if ($(this).hasClass("multi-selectpicker") || $(this).hasClass("dropdown-toggle")) {
                        $(this).prop('readonly', isDisable);
                    }
                    else {
                        $(this).attr('disabled', isDisable);
                    }
                });
            },
            bindMaskControl: function () {
                ko.bindingHandlers.inputmask =
                {
                    init: function (element, valueAccessor, allBindingsAccessor) {

                        var mask = valueAccessor();

                        var observable = mask.value;

                        if (ko.isObservable(observable)) {

                            $(element).on('focusout change', function () {

                                if ($(element).inputmask('isComplete')) {
                                    observable($(element).val());
                                } else {
                                    observable(null);
                                }

                            });
                        }

                        $(element).inputmask(mask);


                    },
                    update: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
                        var mask = valueAccessor();

                        var observable = mask.value;

                        if (ko.isObservable(observable)) {

                            var valuetoWrite = observable();

                            $(element).val(valuetoWrite);
                        }
                    }

                };
            },
            initiatePickers: function () {

                $('#datetimepicker1').datetimepicker({ format: 'MM/DD/YYYY HH:mm', defaultDate: 'now' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY HH:mm");
                    uof.ui.incident.detail.viewModel.incident.IncidentDate(newDate);
                });

                uof.ui.incident.detail.getIncidentDetailInfo();
            },
            initiateBindings: function () {
                ko.validation.insertValidationMessage = function (element) {
                    var br = document.createElement("br");
                    element.appendChild(br);
                    var span = document.createElement('SPAN');
                    span.className = "warning-msg";
                    var inputGroups = $(element).closest(".date"); //This is for getting Date Fields
                    if (inputGroups.length > 0) {
                        // We're in an input-group so we place the message after
                        // the group rather than inside it in order to not break the design
                        $(span).insertAfter(inputGroups);
                    }
                    else {
                        // The default in knockout-validation
                        element.parentNode.insertBefore(span, element.nextSibling);
                    }
                    return span;
                };
                $("#Staging").attr('disabled', true);
            },




            //To show header count on every page
            headerStatisticalData: function () {
                ko.cleanNode($("#IncidentHeaderStatistics").get(0));
                ko.applyBindings(uof.ui.incident.detail.headerStatistics, $("#IncidentHeaderStatistics").get(0));
            },

            // Generic method to open the popup page
            showModalPopup: function (IdOfdiv, intervalTime) {
                if (intervalTime == undefined)
                    intervalTime = 100;
                $('#' + IdOfdiv).show();
                $('#' + IdOfdiv).modal({
                    keyboard: true
                }).promise().done(function () {
                    setTimeout(function () {
                        if ($("#" + IdOfdiv).is(":visible"))
                            $("#" + IdOfdiv).focus();
                    }, intervalTime);
                });

            },

            hideModalPopup: function (IdOfdiv) {
                $('#' + IdOfdiv).modal('hide');
            },

            showPlannedForce: function () {
                if ($("#chkPF").is(":checked")) {
                    uof.ui.incident.detail.showModalPopup("divIncidentPlannedForce")
                    setTimeout(function () { $("#chkPFExtraction").focus(); }, 100);
                }
            },

            getIncidentDetailInfo: function () {
                // $.prototype.showUofOverlay();
                $.ajax(
                    {
                        url: window.location.uofAPIOrigin() + '/api/Lookup/GetAllLookupInformationforIncident',
                        cache: false,
                        type: "GET",
                        dataType: 'json',
                        contentType: "application/json;charset=utf-8",
                        beforeSend: function myfunction() {

                        },
                        success: function (incidentDetailData) {
                            if (incidentDetailData != null) {
                                //$("#IncidentLOF").selectpicker('destroy');
                                uof.ui.incident.detail.viewModel.CustodyEvent(incidentDetailData.CustodyEventsInfo);
                                uof.ui.incident.detail.viewModel.TypeOfForce([]);
                                uof.ui.incident.detail.viewModel.TypeOfForce(incidentDetailData.MethodsInfo);
                                uof.ui.incident.detail.viewModel.TypeOfForce.valueHasMutated();
                                $('#IncTypeOfForce').selectpicker('refresh');

                                uof.ui.incident.detail.viewModel.Locations(incidentDetailData.CitiesInfo);
                                uof.ui.incident.detail.viewModel.ReasonforContact(incidentDetailData.ContactTypesInfo);
                                uof.ui.incident.detail.viewModel.PerceivedArmed(incidentDetailData.PerceivedArmedInfo);
                                uof.ui.incident.detail.viewModel.LocationOfForce([]);
                                uof.ui.incident.detail.viewModel.LocationOfForce(incidentDetailData.LocationofForceInfo);
                                uof.ui.incident.detail.viewModel.LocationOfForce.valueHasMutated();
                                $('#IncidentLOF').selectpicker('refresh');
                                uof.ui.incident.detail.viewModel.Resistances(incidentDetailData.ResistanceInfo);
                                uof.ui.incident.detail.viewModel.StationSource(incidentDetailData.GroupInfoforIR);
                                //uof.ui.incident.detail.viewModel.FacilitySource(incidentDetailData.FaciltiesInfo);
                                uof.ui.incident.detail.viewModel.StagingSource(incidentDetailData.StagingInfo);
                                //uof.ui.incident.detail.viewModel.BureausSource(incidentDetailData.BureausInfo);
                                //uof.ui.incident.detail.AddNoneItemInSelect();
                                if (uof.ui.incident.detail.selectedContext.selectedIncident() > 0) {
                                    // Set All Edit mode values here
                                    uof.ui.incident.detail.incidentDetailInfo();
                                }

                                uof.ui.incident.detail.changeFormControlMode();
                            }
                            // $.prototype.hideUofOverlay();
                        },
                        error: function (e) {
                            $.prototype.hideUofOverlay();
                            showAlert(e.responseText);
                        },
                    });
            },

            //Cancel Data,on cancel button click
            cancelData: function () {
                $('#IncTypeOfForce').selectpicker('destroy')
                $('#IncidentLOF').selectpicker('destroy')
                //for (var obj in uof.ui.incident.detail.viewModel) {
                //    for (var prop in uof.ui.incident.detail.viewModel[obj]) {
                //        if (uof.ui.incident.detail.viewModel[obj].hasOwnProperty(prop) && ko.isObservable(uof.ui.incident.detail.viewModel[obj][prop])) {
                //            if (prop == "ForceTypeId" || prop == "ForceLocation")
                //                uof.ui.incident.detail.viewModel[obj][prop]([]);
                //            else
                //                uof.ui.incident.detail.viewModel[obj][prop](undefined);
                //        }
                //    }
                //}
                ////uof.ui.incident.detail.viewModel.incident.ForceTypeId([]);
                ////uof.ui.incident.detail.viewModel.incident.ForceLocation([]);
                //$('#IncTypeOfForce').selectpicker('refresh');
                //$('#IncidentLOF').selectpicker('refresh');
                //result = ko.validation.group(uof.ui.incident.detail.viewModel, { deep: true });
                //result.showAllMessages(false);

                uof.ui.incident.detail.load();
            },
            AddNoneItemInSelect: function () {
                uof.ui.incident.detail.viewModel.CustodyEvent.push({ Name: 'None', Code: 'NN' });
                uof.ui.incident.detail.viewModel.TypeOfForce.push({ Name: 'None', Code: 'NN' });
                uof.ui.incident.detail.viewModel.Locations.push({ Name: 'None', Code: 'NN' });
                uof.ui.incident.detail.viewModel.ReasonforContact.push({ Name: 'None', Code: 'NN' });
                uof.ui.incident.detail.viewModel.PerceivedArmed.push({ Name: 'None', Code: 'NN' });
                uof.ui.incident.detail.viewModel.LocationOfForce.push({ Name: 'None', Code: 'NN' });
                uof.ui.incident.detail.viewModel.Resistances.push({ Name: 'None', Code: 'NN' });
                uof.ui.incident.detail.viewModel.StationSource.push({ Name: 'None', Code: 'NN' });
                uof.ui.incident.detail.viewModel.FacilitySource.push({ Name: 'None', Code: 'NN' });
                uof.ui.incident.detail.viewModel.StagingSource.push({ Name: 'None', Code: 'NN' });
            },
            buildUserObject: function () {
                var oUserData = new Object();
                oUserData.LastName = UoFParams.LoggedName.split(' ')[0];
                oUserData.FirstName = UoFParams.LoggedName.split(' ')[1];
                oUserData.ForceUserId = UoFParams.userId;
                return oUserData;
            },
            saveIncidentDetails: function () {
                uof.ui.incident.detail.viewModel.incident.IsOnlySave(false);
                if (uof.ui.incident.detail.viewModel.DuplicateURn()) {
                    showAlert("URN is already exist.");
                    return;
                }
                if (uof.ui.incident.detail.validateIncidentFields()) {
                    uof.ui.incident.detail.saveIncidentInfo(false);
                }
            },

            saveIncidentInfo: function (IsOnlySave) {
                uof.ui.incident.detail.viewModel.incident.IsOnlySave(IsOnlySave);
                if (uof.ui.incident.detail.validateOnlyURN()) {
                    $.prototype.showUofOverlay();
                    if (uof.ui.incident.detail.viewModel.incident.IncidentId() > 0)
                        uof.ui.incident.detail.viewModel.incident.currentMode("Edit");
                    else
                        uof.ui.incident.detail.viewModel.incident.currentMode(localStorage.getItem('mode'));

                    if ($("#IncTypeOfForce").val() != null)
                        uof.ui.incident.detail.viewModel.incident.ForceTypeId = $("#IncTypeOfForce").val().join(",");
                    if ($("#IncidentLOF").val() != null)
                        uof.ui.incident.detail.viewModel.incident.ForceLocation = $("#IncidentLOF").val().join(",");

                    uof.ui.incident.detail.viewModel.incident.UserDetails = uof.ui.incident.detail.buildUserObject(); //User Details

                    var mappedData = ko.mapping.toJS(uof.ui.incident.detail.viewModel.incident);
                    mappedData.EmpId = UoFParams.userId;
                    mappedData.IsByFootPursuit = $('#ChkFootPursuit').is(':checked') ? "Y" : "N";
                    mappedData.IsByVehiclePursuit = $('#ChkVehiclePursuit').is(':checked') ? "Y" : "N";

                    $.ajax(
                           {
                               url: window.location.uofAPIOrigin() + '/api/Incident/SaveIncident',
                               cache: false,
                               type: "POST",
                               dataType: 'json',
                               data: JSON.stringify(mappedData),
                               contentType: "application/json;charset=utf-8",
                               beforeSend: function myfunction() {

                               },
                               success: function (result) {
                                   $.prototype.hideUofOverlay();
                                   showAlert(result.Message);
                                   $("#newincident").hide();//modal-backdrop fade in
                                   $(".modal-backdrop").remove();
                                   localStorage.setItem('selectedIncidentId', result.IncidentId);
                                   localStorage.setItem('selectedCategory', uof.ui.incident.detail.viewModel.incident.IncidentCategoryId());
                                   uof.ui.incident.detail.selectedContext.selectedIncident(result.IncidentId);
                                   //uof.ui.incident.detail.setSelectedIncidentId(result.IncidentId, false);
                                   uof.ui.incident.detail.selectedContext.selectedCategory(uof.ui.incident.detail.viewModel.incident.IncidentCategoryId());
                                   uof.ui.incident.detail.viewModel.incident.IncidentId(result.IncidentId);
                                   uof.ui.incident.detail.viewModel.incident.currentMode("Edit");
                                   $('#datetimepicker1').datetimepicker({ format: 'MM/DD/YYYY HH:mm', defaultDate: 'now' }).on('dp.change', function (ev) {
                                       var newDate = null;
                                       if (ev.date != null)
                                           newDate = moment(ev.date).format("MM/DD/YYYY HH:mm:ss");
                                       uof.ui.incident.detail.viewModel.incident.IncidentDate(newDate);
                                   });
                                   if (uof.ui.incident.detail.viewModel.incident.IncidentCategoryId() == 3 && uof.ui.incident.detail.viewModel.incident.IsIABNotified() == "Y") // Category 3 Incidents no need to enter other sections. So redirecting to Main window
                                       window.location.href = window.location.uofUIOrigin() + '/Incident/IncidentDetail';
                                   else
                                       window.location.reload();
                               },
                               error: function (e) {
                                   $.prototype.hideUofOverlay();
                                   showAlert(e.responseText);
                               },
                           });
                }
            },
            validateAssignControls: function () {
                uof.ui.incident.detail.viewModel.AssignModel.EID.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });
                //uof.ui.incident.detail.viewModel.AssignModel.UCID.extend({
                //    required: {
                //        params: true,
                //        message: IncidentConstants.Required
                //    },
                //});
                //uof.ui.incident.detail.viewModel.AssignModel.CMID.extend({
                //    required: {
                //        params: true,
                //        message: IncidentConstants.Required
                //    },
                //});

            },
            validateEmailControl: function () {
                uof.ui.incident.detail.viewModel.emailMode.EmailId.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                    pattern: {
                        params: /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                        message: "Invalid Email"
                    },
                });
            },
            validateCommentControls: function () {
                uof.ui.incident.detail.viewModel.RCModel.FormId.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });
                uof.ui.incident.detail.viewModel.RCModel.SubmitedId.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });

                uof.ui.incident.detail.viewModel.RCModel.ReviewComments.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });
            },
            validateCat: function () {
                uof.ui.incident.detail.viewModel.Cat3Model.WCID.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });
            },
            lengthValidation: function (str, minChar) {
                var maxChar;
                if (uof.ui.incident.detail.getCharCount(str) < minChar[0])
                    return false;
                return true;
            },
            //Validate the controls on Add and duplicate popup
            validateControls: function () {
                //remove old validation
                $("#newincident .validationMessage").each(function () {
                    $(this).remove();
                });
                uof.ui.incident.detail.viewModel.incident.MedRcdPrior.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required,
                        onlyIf: function () {
                            if (uof.ui.incident.detail.viewModel.incident.ForceTypeId() != null && uof.ui.incident.detail.viewModel.incident.ForceTypeId() != "") {
                                return (uof.ui.incident.detail.viewModel.incident.ForceTypeId().join(',').match(/CE/g) == "CE" || uof.ui.incident.detail.viewModel.incident.ForceTypeId().join(',').match(/TG/g) == "TG" || uof.ui.incident.detail.viewModel.incident.ForceTypeId().join(',').match(/OC/g) == "OC")
                            }
                        }
                    }

                });

                //Validate the controls on Add and duplicate popup
                uof.ui.incident.detail.viewModel.incident.URN.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                    validation: {
                        validator: uof.ui.incident.detail.lengthValidation,
                        message: "URN should be 18 character length",
                        params: [15]
                    },

                });
                uof.ui.incident.detail.viewModel.incident.PFData.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.incident.detail.viewModel.incident.IsPlannedForce());
                        }
                    },
                });
                uof.ui.incident.detail.viewModel.incident.PlanAltered.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.incident.detail.viewModel.incident.MedRcdPrior() === "Y");
                        }
                    },
                });

                //PRReason
                uof.ui.incident.detail.viewModel.incident.PRReason.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.incident.detail.viewModel.incident.IsReactiveForce() && uof.ui.incident.detail.viewModel.incident.IsPlannedForce());
                        }
                    },
                });

                //For date
                uof.ui.incident.detail.viewModel.incident.IncidentDate.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required,
                        onlyif: function () {
                            return (uof.ui.incident.detail.viewmodel.incident.IsOnlySave() === false);
                        }
                    },
                });

                uof.ui.incident.detail.viewModel.incident.SelectedCity.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required,
                        onlyif: function () {
                            return (uof.ui.incident.detail.viewmodel.incident.IsOnlySave() === false);
                        }
                    },
                });
                uof.ui.incident.detail.viewModel.incident.Station.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                        //,
                        //onlyIf: function () {
                        //    return (uof.ui.incident.detail.viewModel.incident.Facility() != 'IRC' && uof.ui.incident.detail.viewModel.incident.Facility() == null && uof.ui.incident.detail.viewModel.incident.Bureau() == null && uof.ui.incident.detail.viewModel.incident.Facility() == undefined && uof.ui.incident.detail.viewModel.incident.Bureau() == undefined);
                        //}

                    },
                });
                uof.ui.incident.detail.viewModel.incident.ForceTypeId.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required,
                        onlyif: function () {
                            return (uof.ui.incident.detail.viewmodel.incident.IsOnlySave() === false);
                        }
                    },
                });

                uof.ui.incident.detail.viewModel.incident.IncidentLocationName.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required,
                        onlyif: function () {
                            return (uof.ui.incident.detail.viewmodel.incident.IsOnlySave() === false);
                        }
                    },
                });
                uof.ui.incident.detail.viewModel.incident.AddressNumber.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required,
                        onlyif: function () {
                            return (uof.ui.incident.detail.viewmodel.incident.IsOnlySave() === false);
                        }
                    },
                });
                uof.ui.incident.detail.viewModel.incident.Street.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required,
                        onlyif: function () {
                            return (uof.ui.incident.detail.viewmodel.incident.IsOnlySave() === false);
                        }
                    },
                });
                uof.ui.incident.detail.viewModel.incident.ZipCode.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required,
                        onlyif: function () {
                            return (uof.ui.incident.detail.viewmodel.incident.IsOnlySave() === false);
                        }
                    },
                });

                uof.ui.incident.detail.viewModel.incident.ContactTypeId.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required,
                        onlyIf: function () {
                            return uof.ui.incident.detail.viewModel.incident.currentMode() != 'view';
                        }
                    },
                });

                uof.ui.incident.detail.viewModel.incident.CustodyEventId.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.incident.detail.viewModel.incident.ContactTypeId() === 'ICE');
                        }
                    },
                });
                uof.ui.incident.detail.viewModel.incident.CTOthers.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.incident.detail.viewModel.incident.CustodyEventId() === 'OTH');
                        }
                    },
                });
                //uof.ui.incident.detail.viewModel.incident.ForceLocation.extend({
                //    required: {
                //        params: true,
                //        message: IncidentConstants.Required
                //    },
                //});
                uof.ui.incident.detail.viewModel.incident.IncidentCategoryId.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required,
                        onlyif: function () {
                            return (uof.ui.incident.detail.viewmodel.incident.IsOnlySave() === false);
                        }
                    },
                });
            },

            //check the length of string
            lengthValidation: function (str, minChar) {
                var maxChar;
                if (uof.ui.incident.detail.getCharCount(str) < minChar[0] ||
                    uof.ui.incident.detail.getCharCount(str) > minChar[1])
                    return false;
                return true;
            },

            //get character based on ascii value
            getCharCount: function (str) {
                var result = 0;
                if (str !== undefined) {
                    for (var n = 0; n < str.length; n++) {
                        var charCode = str.charCodeAt();
                        if (typeof charCode === "number") {
                            if (charCode < 128)
                            { result = result + 1; }
                            else if (charCode < 2048)
                            { result = result + 2; }
                            else if (charCode < 65536)
                            { result = result + 3; }
                            else if (charCode < 2097152)
                            { result = result + 4; }
                            else if (charCode < 67108864)
                            { result = result + 5; }
                            else
                            { result = result + 6; }
                        }
                    }
                }
                return result;
            },

            //check for special characters
            isSpecialChar: function (objValue) {
                var count = 0;
                var pattr = ["\\", ":", "/", "*", "?", ">", "<", "[", "]", "{", "}", "|", "'", "=", "+"];

                while (count < pattr.length) {
                    if (objValue.indexOf(pattr[count]) > -1) {
                        return false;
                    }
                    count++;
                }
            },
            validateOnlyURN: function () {
                if ($('#txtincidentDate').val() != "") uof.ui.incident.detail.viewModel.incident.IncidentDate($('#txtincidentDate').val());
                result = ko.validation.group([uof.ui.incident.detail.viewModel.incident.URN, uof.ui.incident.detail.viewModel.incident.IncidentDate]);
                if ((result().length > 0) || (uof.ui.incident.detail.viewModel.hasError())) {
                    //To show the message
                    uof.ui.incident.detail.viewModel.incident.URN.valueHasMutated();
                    uof.ui.incident.detail.viewModel.incident.IncidentDate.valueHasMutated();
                    result.showAllMessages();
                    return false;
                }
                return true;
            },
            validateIncidentFields: function () {
                if ($('#txtincidentDate').val() != "") uof.ui.incident.detail.viewModel.incident.IncidentDate($('#txtincidentDate').val());
                result = ko.validation.group(uof.ui.incident.detail.viewModel.incident, { deep: true });
                if ((result().length > 0) || (uof.ui.incident.detail.viewModel.hasError())) {
                    //To show the message
                    uof.ui.incident.detail.viewModel.incident.URN.valueHasMutated();
                    uof.ui.incident.detail.viewModel.incident.IncidentDate.valueHasMutated();
                    uof.ui.incident.detail.viewModel.incident.SelectedCity.valueHasMutated();
                    uof.ui.incident.detail.viewModel.incident.ForceTypeId.valueHasMutated();
                    uof.ui.incident.detail.viewModel.incident.IncidentLocationName.valueHasMutated();
                    uof.ui.incident.detail.viewModel.incident.AddressNumber.valueHasMutated();
                    uof.ui.incident.detail.viewModel.incident.Street.valueHasMutated();
                    uof.ui.incident.detail.viewModel.incident.ZipCode.valueHasMutated();
                    uof.ui.incident.detail.viewModel.incident.Station.valueHasMutated();
                    uof.ui.incident.detail.viewModel.incident.IncidentCategoryId.valueHasMutated();
                    uof.ui.incident.detail.viewModel.incident.ContactTypeId.valueHasMutated();
                    uof.ui.incident.detail.viewModel.incident.CustodyEventId.valueHasMutated();
                    result.showAllMessages();
                    return false;
                }
                return true;
            },

            changeSearchValue: function (event) {
                var controlModelName = $('#searchData').val();
                $('#URNSearch').val('');
                $('#endTime').val('');
                $('#endTime').hide();
                if (controlModelName == "IncidentCreateDate") {
                    $('#URNSearch').attr('type', 'date');
                    $('#endTime').show();
                }
                else {
                    $('#URNSearch').attr('type', 'text');
                }
                $("#incidentList").data("kendoGrid").dataSource.filter({});
            },

            searchIncident: function (e) {
                $('#endTime').hide();
                var controlModelName = $('#searchData').val();
                if (controlModelName == "IncidentCreateDate") {
                    $('#URNSearch').attr('type', 'date');
                    $('#endTime').show();
                    if ($('#endTime').val() != '' && $('#URNSearch').val() != '') {
                        $("#incidentList").data("kendoGrid").dataSource.filter({ field: controlModelName, operator: "ge", value: $('#URNSearch').val() });
                        $("#incidentList").data("kendoGrid").dataSource.filter({ field: controlModelName, operator: "le", value: $('#endTime').val() });
                    }
                    else if ($('#URNSearch').val() != '') {
                        $("#incidentList").data("kendoGrid").dataSource.filter({ field: controlModelName, operator: "lte", value: $('#URNSearch').val() });
                    }
                    else {
                        $("#incidentList").data("kendoGrid").dataSource.filter({ field: controlModelName, operator: "lte", value: e.value });
                    }
                }
                else {
                    $('#URNSearch').attr('type', 'text');
                    $("#incidentList").data("kendoGrid").dataSource.filter({ field: controlModelName, operator: "contains", value: e.value });
                }

            },

            bindIncidentDetails: function () {

                //  $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#' + athoc.iws.organizationManager.pageName_OrgMain), imageURL: athoc.iws.organizationManager.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: this.resources.General_LoadingMessage }).showLoader();
                // Ajax call to server to get Organziation records
                //$.prototype.showUofOverlay();
                var dlAjaxOption =
                    {
                        url: window.location.uofAPIOrigin() + '/api/Incident/GetUserIncidents',
                        cache: false,
                        data: { userId: UoFParams.userId, userRole: UoFParams.userRole },
                        type: "GET",
                        dataType: 'json',
                        contentType: "application/json;charset=utf-8",
                        success: function (incidentData) {
                            var geoDataSource = new kendo.data.DataSource({
                                data: incidentData,
                                pageSize: 20
                            });
                            geoDataSource.fetch(function () {
                                geoDataSource.page(parseInt(uof.ui.incident.detail.SelectedPageNumber) > 0 ? parseInt(uof.ui.incident.detail.SelectedPageNumber) : 1);
                            });
                            uof.ui.incident.detail.showHeaderStatistics(incidentData);

                            //setting all Org Data to kendo
                            $("#incidentList").kendoGrid({
                                dataSource: geoDataSource,
                                height: 600,
                                resizable: true,
                                sortable: true,
                                columnMenu: true,
                                detailInit: detailInit,
                                dataBound: uof.ui.incident.detail.OnMainGridDataBound,
                                // detailExpand: uof.ui.incident.detail.onDetailExpand,
                                pageable: {
                                    refresh: false,
                                    pageSizes: true,
                                    pageSizes: [20, 40, 100],
                                    buttonCount: 5,
                                    messages: {
                                        empty: "No Incidents to display",
                                        itemsPerPage: "Incidents Per Page",
                                    },
                                },
                                columns: [
                                            {
                                                field: "IncidentId",
                                                template: $("#rdIncidentOption").html(),
                                                headerTemplate: '',
                                                width: "90px",
                                            },
                                            {
                                                field: "URN",
                                                width: "150px",
                                                template: $("#incidentDetails").html(),
                                                headerTemplate: '<span> URN </span>',
                                            },
                                            {
                                                field: "IncidentCategoryId",
                                                width: "80px",
                                                headerTemplate: '<span> Category </span>',
                                            },
                                            {
                                                field: "IncidentApprovalStatus",
                                                width: "150px",
                                                headerTemplate: '<span>Incident Status</span>',
                                            },
                                            {
                                                field: "IncidentCreateDate",
                                                headerTemplate: '<span>Create Date</span>',
                                                width: "150px",
                                                type: "date",
                                                template: "#= kendo.toString(kendo.parseDate(IncidentCreateDate, 'yyyy-MM-dd'), 'MM/dd/yyyy') #"
                                            },

                                            {
                                                field: "IncidentId",
                                                width: "150px",
                                                headerTemplate: '<span>Assign</span>',
                                                template: $("#openAssignPage").html(),
                                                hidden: (UoFParams.userRole == "DSG" || UoFParams.userRole == "CFRT")
                                            },
                                            {
                                                field: "IncidentId",
                                                width: "150px",
                                                headerTemplate: '<span>Rollout to Chief</span>',
                                                template: $("#openCFRTRollout").html(),
                                                hidden: (UoFParams.userRole == "CFRT" ? false : true)
                                            },
                                             {
                                                 field: "UserStatusOnIncident",
                                                 width: "150px",
                                                 headerTemplate: '<span>Status</span>',
                                                 hidden: true
                                             },
                                            {
                                                field: "IncidentId",
                                                width: "150px",
                                                headerTemplate: '<span>Review Comments</span>',
                                                template: $("#openReviewCommentsPage").html(),
                                                hidden: true
                                            },

                                            {
                                                field: "IncidentId",
                                                template: $("#deleteIncident").html(),
                                                headerTemplate: '',
                                                width: "150px",
                                                hidden: (UoFParams.userRole == "DSG" || UoFParams.userRole == "WC" || UoFParams.userRole == "CAPT" || UoFParams.userRole == "CMDR" || UoFParams.userRole == "CFRT")
                                            },
                                             {
                                                 field: "ForceTypeId",
                                                 headerTemplate: '',
                                                 width: "40px",
                                                 hidden: true
                                             },
                                ],
                                change: function (e) {
                                    var model = this.dataItem(this.select());
                                }

                            }).data().kendoGrid;
                            // geoDataSource.read();

                            function detailInit(e) {
                                if (e.data.IncidentStatus.length > 0) {
                                    var childData = new kendo.data.DataSource({
                                        data: e.data.IncidentStatus,
                                        pageSize: 20
                                    });
                                    var subGrid = $("<div/>").appendTo(e.detailCell).kendoGrid({
                                        dataSource: childData,
                                        height: 500,
                                        scrollable: true,
                                        sortable: true,
                                        filterable: false,
                                        //detailInit: explainInit,
                                        pageable: {
                                            refresh: false,
                                            pageSizes: true,
                                            pageSizes: [20, 50, 100],
                                            buttonCount: 5,
                                            messages: {
                                                empty: "No Incidents to display",
                                                itemsPerPage: "Incidents Per Page",
                                            },
                                        },
                                        columns: [
                                            {
                                                field: "ReviewId",
                                                template: $("#rdIncidentReviewOption").html(),
                                                headerTemplate: '',
                                                width: "25px",
                                                hidden: ("#=EmployeeID#" == UoFParams.userId)
                                            },
                                                {
                                                    field: "EmployeeID",
                                                    template: $("#showName").html(),
                                                    width: 100,
                                                    headerTemplate: '<span>Submited Id </span>',
                                                },
                                                 {
                                                     field: "Role",
                                                     width: 30,
                                                     template: '<span class="cellTooltip" title="#=Role#">#=Role#</span>',
                                                     headerTemplate: '<span> Role </span>',
                                                 },
                                                 {
                                                     field: "FormName",
                                                     width: 150,
                                                     //template: '<span class="cellTooltip" title="#=FormName#">#=FormName#</span>',
                                                     template: $("#showFrmName").html(),
                                                     headerTemplate: '<span>Form Name</span>',
                                                 },

                                                   {
                                                       field: "FormStatus",
                                                       width: 40,
                                                       template: '<span class="cellTooltip" title="#=FormStatus#">#=FormStatus#</span>',
                                                       headerTemplate: '<span> Submitted Status </span>',
                                                   },
                                                   //{
                                                   //    field: "FormId",
                                                   //    width: 40,
                                                   //    headerTemplate: '<span>Approve</span>',
                                                   //    template: $("#deputyForm").html(),
                                                   //    hidden: (UoFParams.userRole != "DSP" && UoFParams.userRole != "CFRT")
                                                   //},
                                                   {
                                                       field: "FormId",
                                                       width: 40,
                                                       headerTemplate: '<span>Approve</span>',
                                                       template: $("#deputyForm").html(),
                                                       hidden: (UoFParams.userRole == "DSG" || UoFParams.userRole == "CFRT" || UoFParams.userRole == "MED")
                                                   },
                                                  {
                                                      field: "Status",
                                                      width: 40,
                                                      template: '<span class="cellTooltip" title="#=Status#">#=Status#</span>',
                                                      headerTemplate: '<span> Reviewer Status </span>',
                                                      hidden: (UoFParams.userRole == "DSG" || UoFParams.userRole == "CFRT" || UoFParams.userRole == "MED")
                                                  }

                                        ]
                                    }).data().kendoGrid;
                                }
                            }

                            function explainInit(e) {
                                if (e.data.ExplanationForms.length > 0) {
                                    //var url = window.location.uofAPIOrigin() + '/api/Incident/GetExplanationFormData';
                                    //uof.ui.incident.detail.ExplanationCriteria.userId = UoFParams.userId;
                                    //uof.ui.incident.detail.ExplanationCriteria.userRole = UoFParams.userRole;
                                    //uof.ui.incident.detail.ExplanationCriteria.incidentId = e.data.IncidentId;
                                    //uof.ui.incident.detail.ExplanationCriteria.formId = 17;//e.data.FormId;
                                    //var model = ko.mapping.fromJS(uof.ui.incident.detail.ExplanationCriteria);
                                    //var expData = new kendo.data.DataSource({
                                    //    transport: {
                                    //        read: {
                                    //            url: url,
                                    //            cache: false,
                                    //            data: ko.toJSON(model),
                                    //            contentType: "application/json; charset=utf-8",
                                    //            type: "POST"
                                    //        },
                                    //        parameterMap: function (options) {
                                    //            $.extend(options, uof.ui.incident.detail.ExplanationCriteria);
                                    //            return kendo.stringify(options);
                                    //        },
                                    //    },
                                    //    requestStart: function (e) {
                                    //    },
                                    //    requestEnd: function (e) {

                                    //        if (e.response) {

                                    //        }
                                    //    },
                                    //    schema: {
                                    //        data: "Data",
                                    //        total: "TotalCount",
                                    //    },
                                    //    serverPaging: true,
                                    //    serverSorting: true,
                                    //    serverFiltering: true,
                                    //    sort: { field: "EmployeeID", dir: "desc" },
                                    //    pageSize: 50,
                                    //    error: function (e) {
                                    //        var errorCallBack = function (returnedErrorObject) {

                                    //        };
                                    //    }
                                    //});
                                    var expData = new kendo.data.DataSource({
                                        data: e.data.ExplanationForms,
                                        pageSize: 20
                                    });
                                    var subGrid = $("<div/>").appendTo(e.detailCell).kendoGrid({
                                        dataSource: expData,
                                        height: 400,
                                        scrollable: true,
                                        sortable: true,
                                        filterable: false,
                                        pageable: {
                                            refresh: false,
                                            pageSizes: true,
                                            pageSizes: [20, 50, 100],
                                            buttonCount: 5,
                                            messages: {
                                                empty: "No Incidents to display",
                                                itemsPerPage: "Incidents Per Page",
                                            },
                                        },
                                        columns: [
                                                {
                                                    field: "EmployeeID",
                                                    template: $("#showName").html(),
                                                    width: 100,
                                                    headerTemplate: '<span>Submited Id </span>',
                                                },

                                                 {
                                                     field: "FormName",
                                                     width: 150,
                                                     //template: '<span class="cellTooltip" title="#=FormName#">#=FormName#</span>',
                                                     template: $("#showFrmName").html(),
                                                     headerTemplate: '<span>Form Name</span>',
                                                 },

                                                   {
                                                       field: "FormStatus",
                                                       width: 40,
                                                       template: '<span class="cellTooltip" title="#=FormStatus#">#=FormStatus#</span>',
                                                       headerTemplate: '<span> Submitted Status </span>',
                                                   },
                                                   {
                                                       field: "FormId",
                                                       width: 40,
                                                       headerTemplate: '<span>Approve</span>',
                                                       template: $("#deputyForm").html(),
                                                       hidden: (UoFParams.userRole == "DSG" || UoFParams.userRole == "CFRT")
                                                   },
                                                  {
                                                      field: "Status",
                                                      width: 40,
                                                      template: '<span class="cellTooltip" title="#=Status#">#=Status#</span>',
                                                      headerTemplate: '<span> Reviewer Status </span>',
                                                      hidden: (UoFParams.userRole == "DSG" || UoFParams.userRole == "CFRT")
                                                  }
                                        ]
                                    }).data().kendoGrid;
                                }
                            }

                            //$.prototype.hideUofOverlay();
                        },
                        error: function (e) {
                            showAlert(e.responseText);
                        }

                    };
                // Call ajax
                var ajaxOptions = $.extend({}, 'GET', dlAjaxOption);
                $.ajax(ajaxOptions);


                //var $template = kendo.template($("#name-tooltip-template").html());

                //var tooltip = $("#incidentList").kendoTooltip({
                //    filter: "td:nth-child(3)", //this filter selects the first column cells                   
                //    content: function (e) {
                //        var dataItem = $("#incidentList").data("kendoGrid").dataItem(e.sender.closest("tr")-1);
                //        return $template(dataItem);
                //    },

                //}).data("kendoTooltip");


                //$("#incidentList").kendoTooltip({
                //    filter: ".cellTooltip",
                //});

            },

            onDetailExpand: function (e) {
                $(e.detailRow[0]).attr('style', 'display:table-row');
            },

            showHeaderStatistics: function (incidentData) {

                if (incidentData.length > 0) {
                    uof.ui.incident.detail.headerStatistics.noOfNewIncidents(incidentData.length);

                    var find = _.filter(incidentData, function (item) {
                        return item.IncidentApprovalStatus != "Completed" && item.IncidentApprovalStatus != "Return";
                    });

                    if (find)
                        uof.ui.incident.detail.headerStatistics.inProcessIncidents(find.length);

                    find = _.filter(incidentData, function (item) {
                        return item.IncidentApprovalStatus == "Completed";
                    });

                    if (find)
                        uof.ui.incident.detail.headerStatistics.completedIncidents(find.length);

                    find = _.filter(incidentData, function (item) {
                        return item.IncidentApprovalStatus == "Return";
                    });

                    if (find)
                        uof.ui.incident.detail.headerStatistics.rejectedIncidents(find.length);
                }

            },

            OnMainGridDataBound: function (e) {
                $("#incidentList tbody").find("tr.k-master-row").attr("tabindex", "0");
                var grid = $("#incidentList").data("kendoGrid");

                $(grid.tbody).find('tr.k-master-row').each(function (e) {
                    var view = grid.dataSource.view();
                    var model = view[e];
                    if (model != null) {
                        if (UoFParams.userRank == "2") {
                            if (UoFParams.userId == model.InvestOfficerId && model.IncidentApprovalStatus == "AtSergeant")
                                $(this).find('td:eq(8)').find(".assign").css({ cursor: "hand", textDecoration: "", "pointer-events": "auto", color: "#8564a6" });
                            else
                                $(this).find('td:eq(8)').text("---");
                        }
                            //else if (UoFParams.userRank >= "3") {
                            //    if (model.IncidentApprovalStatus == "AtWatchCommander" || model.IncidentApprovalStatus == "AtUnitCommander" || model.IncidentApprovalStatus == "AtCommander" || model.IncidentApprovalStatus == "AtCFRT")
                            //        $(this).find('td:eq(8)').find(".assign").css({ cursor: "hand", textDecoration: "", "pointer-events": "auto", color: "#8564a6" });
                            //    else
                            //        $(this).find('td:eq(8)').text("---");
                            //}
                        else if (((UoFParams.userRank == '3') || (UoFParams.userRank == '4')) && (model.IncidentCategoryId == 2) && ((model.IncidentApprovalStatus == "AtUnitCommander") || (model.IncidentApprovalStatus == "AtWatchCommander")))
                            $(this).find('td:eq(8)').find(".assign").css({ cursor: "hand", textDecoration: "", "pointer-events": "auto", color: "#8564a6" });//$(this).find('td:eq(7)').outerHTML = "<a style='cursor:pointer' onclick='uof.ui.incident.detail.openAssignOthers(" + model.IncidentId + ");'>Assign to CRFT</a>";
                    }
                    //if (model != null) {
                    //    if ((model.IncidentApprovalStatus != "Completed") && (model.IncidentApprovalStatus != "ReadyforReview")) {
                    //        $(this).find('td:eq(6)').addClass("warning-msg");
                    //        if (((UoFParams.userRole == 'WC') || (UoFParams.userRole == 'CAPT')) && (model.IncidentCategoryId == 2) && (model.IncidentApprovalStatus != "AtCFRT"))
                    //            $(this).find('td:eq(8)').find(".assign").css({ cursor: "hand", textDecoration: "", "pointer-events": "auto", color: "#8564a6" });//$(this).find('td:eq(7)').outerHTML = "<a style='cursor:pointer' onclick='uof.ui.incident.detail.openAssignOthers(" + model.IncidentId + ");'>Assign to CRFT</a>";
                    //        else if ((UoFParams.userRole == 'SGT') && (model.IncidentCategoryId == 3)) {
                    //            if (model.IncidentApprovalStatus == "AtSergeant")
                    //                //$(this).find('td:eq(8)').outerHTML = "<a class='assign' style='cursor:pointer' onclick='uof.ui.incident.detail.AssigntoIAB(" + model.IncidentId + ");'>Assign to WC</a>";
                    //                $(this).find('td:eq(8)').find(".assign").css({ cursor: "hand", textDecoration: "", "pointer-events": "auto", color: "#8564a6" });//$(this).find('td:eq(8)').text("Assing to Watch Commander");
                    //            else
                    //                $(this).find('td:eq(8)').text("---");
                    //        }
                    //        else if ((UoFParams.userRole == 'WC') && (model.IncidentCategoryId == 3)) {
                    //            if (model.IncidentApprovalStatus == "Pending")
                    //                $(this).find('td:eq(8)').find(".assign").css({ cursor: "hand", textDecoration: "", "pointer-events": "auto", color: "#8564a6" });
                    //            else
                    //                $(this).find('td:eq(8)').text("---");
                    //        }
                    //        else if ((UoFParams.userRole == 'WC') && (model.IncidentApprovalStatus == "AtWatchCommander") && (model.UserStatusOnIncident == 'Completed')) {
                    //            $(this).find('td:eq(8)').find(".assign").css({ cursor: "pointer", textDecoration: "", "pointer-events": "auto", color: "#8564a6" });
                    //        }
                    //        else if ((UoFParams.userRole == 'CAPT') && (model.IncidentApprovalStatus == "AtUnitCommander") && (model.UserStatusOnIncident == 'Completed')) {
                    //            $(this).find('td:eq(8)').find(".assign").css({ cursor: "hand", textDecoration: "", "pointer-events": "auto", color: "#8564a6" });
                    //        }
                    //        else
                    //            $(this).find('td:eq(8)').text("---");

                    //        if (model.IncidentApprovalStatus == "AtDeputy" || model.IncidentApprovalStatus == "AtIAB") {
                    //            //$(this).find('td:eq(8)').find("#anReviewComments").css({ cursor: "Default", textDecoration: "none", "pointer-events": "none", color: "gray" });
                    //            $(this).find('td:eq(8)').text("---");
                    //        }
                    //        else
                    //            $(this).find('td:eq(8)').find(".comments").css({ cursor: "pointer", textDecoration: "", "pointer-events": "auto", color: "#8564a6" });
                    //    }
                    //    else if (model.IncidentApprovalStatus == "Completed") {
                    //        $(this).find('td:eq(6)').addClass("message-success");
                    //        if ((UoFParams.userRole == 'WC') && (model.IncidentCategoryId == 3))
                    //            $(this).find('td:eq(8)').text("");
                    //        else if ((UoFParams.userRole == 'WC') || (UoFParams.userRole == 'CAPT'))//&& ( IncidentCategoryId == 32)
                    //            $(this).find('td:eq(8)').find(".assign").css({ cursor: "pointer", textDecoration: "", "pointer-events": "auto", color: "#8564a6" }); //$(this).find('td:eq(8)').outerHTML = "<a style='cursor:pointer' onclick='uof.ui.incident.detail.openAssignOthers(" + model.IncidentId + ");'>Assign</a>";
                    //        else
                    //            $(this).find('td:eq(8)').text("Done");
                    //        $(this).find('td:eq(8)').find("#anReviewComments").css({ cursor: "Default", textDecoration: "none", "pointer-events": "none", color: "gray" });
                    //    }
                    //    else if (model.IncidentApprovalStatus == "ReadyforReview") {
                    //        $(this).find('td:eq(8)').find(".cmdr").css({ cursor: "pointer", textDecoration: "", "pointer-events": "auto", color: "#8564a6" });//$(this).find('td:eq(8)').outerHTML = "<a style='cursor:pointer' onclick='uof.ui.incident.detail.openAssignPopup(" + model.IncidentId + ", " + model.URN + ");'>Assign</a>";
                    //    }

                    //    //$(this).find('td:eq(8)').find(".comments").css({ cursor: "pointer", textDecoration: "", "pointer-events": "auto", color: "#8564a6" });

                    //    //if (model.IncidentApprovalStatus != "AtDeputy" && model.IncidentApprovalStatus != "Completed") {
                    //    //    $(this).find('td:eq(8)').find(".comments").css({ cursor: "pointer", textDecoration: "", "pointer-events": "auto", color: "#8564a6" });
                    //    //}
                    //    if (model.IncidentStatus.length == 0) {
                    //        // $(this).find('td:first').remove();
                    //    }
                    //    if (uof.ui.incident.detail.selectedIncidentID > 0) {

                    //        var val = $(this).find('td:eq(1)').find(':checkbox').prop("value");
                    //        if (val == uof.ui.incident.detail.selectedIncidentID) {
                    //            $(this).find('td:eq(1)').find(':input').prop("checked", true)
                    //            $(this).find('td:eq(0)').find('a').removeClass('k-icon.k-plus').addClass('k-icon.k-minus')
                    //            $("#rdIncidentOption").on("click", function () {
                    //                //alert($(this).text());
                    //                uof.ui.incident.detail.selectIncident(uof.ui.incident.detail.selectedIncidentID)
                    //            });
                    //            $("#rdIncidentOption").trigger("click");
                    //            $(this).find('td:eq(0)').find('a').trigger("click");


                    //        }
                    //    }
                    //}
                });

                if (grid.dataSource.total() == 0) {
                    var colCount = grid.columns.length;
                    $(e.sender.wrapper)
                        .find('tbody')
                        .append('<tr class="kendo-data-row"><td colspan="' + colCount + '" style="text-align:center; padding-top:10px; cursor:text;">No Record Found</td></tr>');
                }
            },
            OnChildGridDataBound: function (e) {
                $("#incidentList tbody").find("tr").attr("tabindex", "0");
                var grid = $("#incidentList").data("kendoGrid");

                $(grid.tbody).find('tr').each(function (e) {
                    var view = grid.dataSource.view();
                    var model = view[e];
                    if (model.IncidentStatus.length == 0) {
                        // $(this).find('td:first').remove();
                    }
                });


                if (grid.dataSource.total() == 0) {
                    var colCount = grid.columns.length;
                    $(e.sender.wrapper)
                        .find('tbody')
                        .append('<tr class="kendo-data-row"><td colspan="' + colCount + '" style="text-align:center; padding-top:10px; cursor:text;">No Record Found</td></tr>');
                }
            },

            bindIncidentStatusDetails: function () {
                $.prototype.showUofOverlay();
                var dlAjaxOption =
                    {
                        url: window.location.uofAPIOrigin() + '/api/Incident/GetIncidentStatusDetails',
                        cache: false,
                        data: { userId: UoFParams.userId, userRole: UoFParams.userRole },
                        type: "GET",
                        dataType: 'json',
                        contentType: "application/json;charset=utf-8",
                        success: function (incidentData) {
                            var geoDataSource = new kendo.data.DataSource({
                                data: incidentData,
                                pageSize: 20
                            });
                            $("#incidentStatusList").kendoGrid({
                                dataSource: geoDataSource,
                                height: 240,
                                scrollable: true,
                                sortable: true,
                                filterable: false,
                                pageable: {
                                    refresh: false,
                                    pageSizes: true,
                                    pageSizes: [20, 50, 100],
                                    buttonCount: 5,
                                    messages: {
                                        empty: "No Incidents to display",
                                        itemsPerPage: "Incidents Per Page",
                                    },
                                },
                                columns: [

                                            {
                                                field: "URN",
                                                width: 150,
                                                template: $("#incidentStatusURN").html(),
                                                headerTemplate: '<span> URN </span>',
                                            },
                                            {
                                                field: "EmployeeID",
                                                headerTemplate: '',
                                                width: 100,
                                                headerTemplate: '<span> Deputy Employee ID </span>',
                                            },
                                             {
                                                 field: "Role",
                                                 width: 150,
                                                 template: '<span class="cellTooltip" title="#=Role#">#=Role#</span>',
                                                 headerTemplate: '<span> Role </span>',
                                             },
                                             {
                                                 field: "FormName",
                                                 width: 150,
                                                 template: '<span class="cellTooltip" title="#=FormName#">#=FormName#</span>',
                                                 headerTemplate: '<span>Form Name</span>',
                                             },

                                               {
                                                   field: "FormStatus",
                                                   width: 100,
                                                   template: '<span class="cellTooltip" title="#=FormStatus#">#=FormStatus#</span>',
                                                   headerTemplate: '<span> Submitted Status </span>',
                                               },
                                               {
                                                   field: "FormId",
                                                   width: 150,
                                                   headerTemplate: '<span>Review</span>',
                                                   template: $("#deputyForm").html(),
                                               },
                                              {
                                                  field: "Status",
                                                  width: 100,
                                                  template: '<span class="cellTooltip" title="#=Status#">#=Status#</span>',
                                                  headerTemplate: '<span> Reviewer Status </span>',
                                              },

                                ],
                                //dataBound: uof.ui.incident.detail.OnDeputyDataBound,
                                change: function (e) {
                                    var model = this.dataItem(this.select());
                                }
                            }).data().kendoGrid;
                            geoDataSource.read();
                            $.prototype.hideUofOverlay();
                        },
                        error: function (e) {
                            showAlert(e.responseText);
                        }

                    };
                // Call ajax
                var ajaxOptions = $.extend({}, 'GET', dlAjaxOption);
                $.ajax(ajaxOptions);


                var $template = kendo.template($("#name-tooltip-template").html());

                var tooltip = $("#incidentList").kendoTooltip({
                    filter: "td:nth-child(2)", //this filter selects the first column cells                   
                    content: function (e) {
                        var dataItem = $("#incidentList").data("kendoGrid").dataItem(e.target.closest("tr"));
                        return $template(dataItem);
                    },

                }).data("kendoTooltip");


                $("#incidentList").kendoTooltip({
                    filter: ".cellTooltip",
                });
            },
            // Databound event of grid
            OnDeputyDataBound: function (e) {

                $("#incidentStatusList tbody").find("tr").attr("tabindex", "0");
                // this.pager.element.hide();

                var grid = $("#incidentStatusList").data("kendoGrid");
                var data = grid.dataSource.data();

                //$(grid.tbody).unbind("click");

                $(grid.tbody).on("click", "td", function (e) {
                    var row = $(this).closest("tr");
                    var rowIdx = $("tr", grid.tbody).index(row);
                    var view = grid.dataSource.view();
                    var model = view[rowIdx];
                    // window.location.href = window.location.href.replace(/\/*$/, "") + "/Edit/" + model.Id;
                    e.stopPropagation();
                });

                if (grid.dataSource.total() == 0) {
                    var colCount = grid.columns.length;
                    $(e.sender.wrapper)
                        .find('tbody')
                        .append('<tr class="kendo-data-row"><td colspan="' + colCount + '" style="text-align:center; padding-top:10px; cursor:text;">No Deputy Forms Found</td></tr>');
                }
            },

            deleteIncident: function (incidentId) {
                $.when(showConfirmationWindow('Are you sure you want to delete this incident?')).then(function (confirmed) {
                    if (confirmed) {
                        $.prototype.showUofOverlay();
                        $.ajax(
                        {
                            url: window.location.uofAPIOrigin() + '/api/Incident/DeleteIncident?incidentId=' + String(incidentId),
                            cache: false,
                            type: "DELETE",
                            dataType: 'json',
                            contentType: "application/json;charset=utf-8",
                            success: function () {
                                $.prototype.hideUofOverlay();
                                UoFParams.IncidentId = "";
                                uof.ui.incident.detail.bindIncidentDetails();

                            },
                            error: function (e) {
                                $.prototype.hideUofOverlay();
                                showAlert(e.responseText);
                            },
                        });
                    }
                });
            },

            chkSelectedForUrn: function (selectedIncidentId) {
                $("#btnAddIncident").attr('disabled', false);
                var isChecked = false;
                this.selectIncident(0);
                localStorage.setItem("selectedIncidentId", 0);
                uof.ui.assignforms.viewModel.AssignModel.Assignment([]);
                uof.ui.assignforms.viewModel.AssignModel.URN('');
                if ($('#chkUrnClicked' + selectedIncidentId).is(':checked')) {
                    this.selectIncident(selectedIncidentId);
                    isChecked = true;
                    localStorage.setItem("selectedIncidentId", selectedIncidentId);
                    $("#btnAddIncident").attr('disabled', true);

                }
                else
                    $('#IndDelete' + selectedIncidentId).addClass("disabled");


                $('[name*="chkUrnClickedName"]').each(function () {
                    $(this).attr('disabled', false);
                    if (isChecked && ($(this)[0].id != ('chkUrnClicked' + selectedIncidentId))) {
                        $(this).attr('disabled', true);
                        $(this).attr('checked', false);
                    }
                });

            },

            selectIncident: function (selectedIncidentId) {
                UoFParams.IncidentId = selectedIncidentId;
                this.selectedContext.selectedIncident(selectedIncidentId);
                uof.ui.incident.detail.selectedIncidentID = 0;
                uof.ui.incident.detail.SelectedPageNumber = 0;
                $('#editIncident').prop("disabled", false);
                localStorage.setItem('mode', 'Edit');
                uof.ui.incident.detail.viewModel.incident.currentMode(localStorage.getItem('mode'));
                localStorage.setItem('selectedIncidentId', uof.ui.incident.detail.selectedContext.selectedIncident())
                this.setSelectedIncidentId(selectedIncidentId, false);
                this.updateMenuURL();
            },

            setSelectedIncidentId: function (selectedIncidentId, isValidate, pageNumber) {
                $.ajax({
                    type: 'POST',
                    url: window.location.uofUIOrigin() + '/Incident/GetIncidentId',
                    data: { id: selectedIncidentId, PageNumber: pageNumber },
                    success: function (data) {
                        $('#IndDelete' + selectedIncidentId).addClass("disabled");
                        if (data.success == "true") {
                            uof.ui.CommonUILogic.detail.viewModel.UoFData = data.Data;
                            uof.ui.CommonUILogic.detail.enabledMenus(uof.ui.incident.detail.selectedContext.selectedIncident());

                            //if (data.Data.isDeletePermission)
                            //    $('#IndDelete' + selectedIncidentId).removeClass("disabled");
                            //else
                            //    $('#IndDelete' + selectedIncidentId).addClass("disabled");
                            if (data.Data.InvestSupervisor != null) {
                                if (data.Data.InvestSupervisor.length > 6) {
                                    var InvestOfficer = data.Data.InvestSupervisor.split('-')[0];
                                    if (InvestOfficer != "") {
                                        if (InvestOfficer == UoFParams.userId)
                                            $('#IndDelete' + selectedIncidentId).removeClass("disabled");
                                        else
                                            $('#IndDelete' + selectedIncidentId).addClass("disabled");
                                    }
                                }
                                else
                                    $('#IndDelete' + selectedIncidentId).removeClass("disabled");
                            }
                            else
                                $('#IndDelete' + selectedIncidentId).removeClass("disabled");

                        }
                    }
                });
                this.getInvolvedUserWithName();
            },

            updateMenuURL: function () {
                try {
                    if (UoFParams.superAdminRoleCode != UoFParams.userRole) {
                        $("#MainMenu").kendoMenu({
                            openOnClick: true
                        });
                        var menu = $("#MainMenu").data("kendoMenu");
                        var selectItem = localStorage.getItem("selectedIncidentId");
                        if (selectItem == null)
                            selectItem = uof.ui.incident.detail.selectedContext.selectedIncident();
                        $("#MainMenu #topWidgetMenuItem").each(function (index, element) {
                            menu.enable($(element), parseInt(selectItem) > 0);

                        });
                        $("#MainMenu #topWidgetRptItem").each(function (index, element) {
                            menu.enable($(element), parseInt(selectItem) > 0);

                        });

                    }
                } catch (e) { }
            },

            incidentDetails: function (mode, incidentId) {
                uof.ui.incident.detail.selectIncident(incidentId);
                uof.ui.incident.detail.viewModel.incident.currentMode(mode);
                mode == 'view' ? uof.ui.incident.detail.selectedContext.selectedIncident(incidentId) : mode;
                if (mode == 'Add') {
                    uof.ui.incident.detail.selectedContext.selectedIncident(0);
                }
                localStorage.setItem('selectedIncidentId', uof.ui.incident.detail.selectedContext.selectedIncident());
                localStorage.setItem('mode', mode);
                if (UoFParams.InvestSupervisor.length > 6) {
                    var InvestOfficer = UoFParams.InvestSupervisor.split('-')[0];
                    if (InvestOfficer == UoFParams.userId)
                        uof.ui.incident.detail.viewModel.isInvestOfficer(true);
                    else
                        uof.ui.incident.detail.viewModel.isInvestOfficer(false);
                }
                window.location.href = window.location.uofUIOrigin() + '/Incident/IncidentDetail';
            },
            viewDeputyForm: function (formId, DeputyId, incidentId, viewType, IncidentReviewId, formDataId) {
                //Get the Action Name and Controller Name based on the FormId
                var pageNumber = $("#incidentList").data("kendoGrid").dataSource.page();
                $.ajax(
                {
                    url: window.location.uofAPIOrigin() + '/api/UOFForm/GetFormURL',
                    cache: false,
                    data: 'formId=' + formId,
                    type: "GET",
                    dataType: 'json',
                    contentType: "application/json;charset=utf-8",
                    success: function (formData) {
                        $.prototype.hideUofOverlay();
                        uof.ui.incident.detail.setSelectedIncidentId(incidentId, false, pageNumber);
                        localStorage.setItem('formMode', viewType);//Setting the formode 
                        localStorage.setItem('SubmittedId', DeputyId);
                        localStorage.setItem('IncidentReviewId', IncidentReviewId);
                        localStorage.setItem('FormDataId', formDataId);
                        window.location.href = window.location.uofUIOrigin() + '/' + formData.ControllerName + '/' + formData.ActionName + '?FormId=' + formId + '&IncidentId=' + incidentId + '&SubmittedId=' + DeputyId;
                    },
                    error: function (e) {
                        $.prototype.hideUofOverlay();
                        showAlert("Error");
                    },
                });


            },
            // Refresh all select pickers , this is required when you enable and disable the dropdowns
            refreshPickers: function () {

                $("#IncidentReasonforContact").selectpicker('refresh');
                $("#ddlCustodyEvent").selectpicker('refresh');
                $("#IncidentCity").selectpicker('refresh');
                //$("#IncidentFacility").selectpicker('refresh');
                $("#Perceivedarmed").selectpicker('refresh');
                $("#IncTypeOfForce").selectpicker('refresh');
                $("#IncidentLOF").selectpicker('refresh');
                $("#IndResistance").selectpicker('refresh');


            },
            submitfocus: function () {
                setTimeout(function () { $("#btnInSave").focus(); }, 100);
            },
            incidentDetailInfo: function () {
                $.prototype.showUofOverlay();
                $.ajax(
                {
                    url: window.location.uofAPIOrigin() + '/api/Incident/GetIncidentDetails',
                    cache: false,
                    data: 'incidentId=' + String(uof.ui.incident.detail.selectedContext.selectedIncident()),
                    type: "GET",
                    dataType: 'json',
                    contentType: "application/json;charset=utf-8",
                    success: function (incidentData) {


                        incidentData.IncidentDate = moment(incidentData.IncidentDate).format("MM/DD/YYYY HH:mm");
                        uof.ui.incident.detail.viewModel.incident = ko.mapping.fromJS(incidentData, ko.mapping.toJS(uof.ui.incident.detail.viewModel.incident));
                        $("#IncTypeOfForce").selectpicker('destroy');
                        $("#IncidentLOF").selectpicker('destroy');
                        if (uof.ui.incident.detail.viewModel.incident.ForceTypeId() != null)
                            uof.ui.incident.detail.viewModel.incident.ForceTypeId = ko.observableArray(uof.ui.incident.detail.viewModel.incident.ForceTypeId().split(','));
                        if (incidentData.PlannedForceInfo != null)
                            uof.ui.incident.detail.viewModel.incident.PlannedForceInfo = ko.mapping.fromJS(incidentData.PlannedForceInfo, ko.mapping.toJS(uof.ui.incident.detail.viewModel.incident.PlannedForceInfo));

                        if (uof.ui.incident.detail.viewModel.incident.ForceLocation() != null)
                            uof.ui.incident.detail.viewModel.incident.ForceLocation = ko.observableArray(uof.ui.incident.detail.viewModel.incident.ForceLocation().split(','));
                        uof.ui.incident.detail.viewModel.hasError = ko.observable(false);


                        uof.ui.incident.detail.subscribeEvents();
                        uof.ui.incident.detail.validateControls();
                        uof.ui.incident.detail.setEmployeeInformation();
                        ko.cleanNode($("#Incident").get(0));
                        ko.applyBindings(uof.ui.incident.detail.viewModel, $("#Incident").get(0));
                        uof.ui.incident.detail.viewModel.incident.ContactTypeId.isModified(false);
                        uof.ui.incident.detail.viewModel.incident.Station.isModified(false);

                        if (incidentData.IsReactiveForce == "N")
                            uof.ui.incident.detail.viewModel.incident.IsReactiveForce(false);
                        else
                            uof.ui.incident.detail.viewModel.incident.IsReactiveForce(true);

                        if (incidentData.IsPlannedForce == "N")
                            uof.ui.incident.detail.viewModel.incident.IsPlannedForce(false);
                        else
                            uof.ui.incident.detail.viewModel.incident.IsPlannedForce(true);
                        $('#datetimepicker1').datetimepicker({ format: 'MM/DD/YYYY HH:mm', defaultDate: 'now' }).on('dp.change', function (ev) {
                            var newDate = null;
                            if (ev.date != null)
                                newDate = moment(ev.date).format("MM/DD/YYYY HH:mm");
                            uof.ui.incident.detail.viewModel.incident.IncidentDate(newDate);
                        });

                        $("#IncTypeOfForce").selectpicker('refresh');
                        $("#IncidentLOF").selectpicker('refresh');
                        $("#Staging").attr('disabled', true);
                        //Investigation Officer Check
                        if (UoFParams.InvestSupervisor.length > 6) {
                            var InvestOfficer = UoFParams.InvestSupervisor.split('-')[0];
                            if (InvestOfficer == UoFParams.userId) {
                                uof.ui.incident.detail.viewModel.isInvestOfficer(true);
                                $("#btnSubmit").removeClass("hide");
                            }

                            else {
                                uof.ui.incident.detail.viewModel.isInvestOfficer(false);
                                $("#btnSubmit").addClass("hide");
                            }
                        }
                        else {
                            uof.ui.incident.detail.viewModel.isInvestOfficer(false);
                            $("#btnSubmit").addClass("hide");
                        }

                        //WC Rank Verification
                        if (UoFParams.userRank == "3" || UoFParams.userRank == "4") {
                            $("#btnApprove").removeClass("hide");
                            $("#btnReject").removeClass("hide");
                        }
                        else {
                            $("#btnApprove").addClass("hide");
                            $("#btnReject").addClass("hide");
                        }
                        //Setting the readonly of the form based on the approval done by the WC
                        if (uof.ui.incident.detail.viewModel.incident.isSRApproved()) {
                            $("#btnSubmit").addClass("hide");
                            localStorage.setItem('mode', 'view');
                            uof.ui.incident.detail.viewModel.incident.currentMode("view");
                            uof.ui.incident.detail.changeFormControlMode();
                            uof.ui.InvolvedEmployee.viewModel.isEditmode(false);
                            uof.ui.InvolvedEmployee.SetFormControls(true);
                            uof.ui.Suspects.viewModel.isEditMode(false);
                            uof.ui.Suspects.SetFormControls(true);
                        }
                        $.prototype.hideUofOverlay();
                    },
                    error: function (e) {
                        $.prototype.hideUofOverlay();
                        showAlert("Error");
                    },
                });
            },

            // This method will call API to get employee information based on empname
            getEmployeeDetails: function (empId, optionCriteria) {

                // Search based on emp id
                $.prototype.showProgressBar("emplSection");
                if (empId != "") {


                    jQuery.ajax({
                        type: "GET",
                        url: EmployeeAPIUrl() + empId,
                        dataType: "json",
                        cache: false,
                        crossDomain: true,
                        processData: true,
                        success: function (empData) {
                            uof.ui.incident.detail.viewModel.hasError(false);

                            if (optionCriteria == 'IABNotified') {
                                uof.ui.incident.detail.viewModel.incident.PersonNotified(empData.FirstName + " " + empData.LastName);
                                uof.ui.incident.detail.viewModel.incident.IABNotifiedEmailId(empData.EmailAddress);
                            }
                            else if (optionCriteria == 'IABHandling') {
                                uof.ui.incident.detail.viewModel.incident.IABHandlingFirstName(empData.FirstName);
                                uof.ui.incident.detail.viewModel.incident.IABHandlingLastName(empData.LastName);
                                uof.ui.incident.detail.viewModel.incident.IABHandlingRank(empData.Rank);
                                uof.ui.incident.detail.viewModel.incident.IABHandlingEmailId(empData.EmailAddress);
                            }
                            else if (optionCriteria == 'CFRTNotified') {
                                uof.ui.incident.detail.viewModel.incident.CFRTNotifiedFirstName(empData.FirstName);
                                uof.ui.incident.detail.viewModel.incident.CFRTNotifiedLastName(empData.LastName);
                                uof.ui.incident.detail.viewModel.incident.CFRTNotifiedRank(empData.Rank);
                                uof.ui.incident.detail.viewModel.incident.CFRTNotifiedEmailId(empData.EmailAddress);
                            }
                            else if (optionCriteria == 'CFRTHandling') {
                                uof.ui.incident.detail.viewModel.incident.CFRTHandlingFirstName(empData.FirstName);
                                uof.ui.incident.detail.viewModel.incident.CFRTHandlingLastName(empData.LastName);
                                uof.ui.incident.detail.viewModel.incident.CFRTHandlingRank(empData.Rank);
                                uof.ui.incident.detail.viewModel.incident.CFRTHandlingEmailId(empData.EmailAddress);
                            }
                            if (optionCriteria == 'WC') {
                                uof.ui.incident.detail.viewModel.AssignModel.EFName(empData.FirstName);
                                uof.ui.incident.detail.viewModel.AssignModel.ELName(empData.LastName);
                                uof.ui.incident.detail.viewModel.AssignModel.EMName(empData.MiddleName);
                                uof.ui.incident.detail.viewModel.AssignModel.ERank(empData.Rank);
                                uof.ui.incident.detail.viewModel.AssignModel.EmailId(empData.EmailAddress);
                                if (empData.RankAbrev != null)
                                    uof.ui.incident.detail.viewModel.AssignModel.ERankAbrv(empData.RankAbrev.toUpperCase());
                            }
                                //else if (optionCriteria == 'UC') {
                                //    uof.ui.incident.detail.viewModel.AssignModel.UCFName(empData.FirstName);
                                //    uof.ui.incident.detail.viewModel.AssignModel.UCLName(empData.LastName);
                                //    uof.ui.incident.detail.viewModel.AssignModel.UCMName(empData.LastName);
                                //    uof.ui.incident.detail.viewModel.AssignModel.UCRank(empData.Rank);
                                //    uof.ui.incident.detail.viewModel.AssignModel.UCEmailId(empData.EmailAddress);
                                //}
                                //else if (optionCriteria == 'CM') {
                                //    uof.ui.incident.detail.viewModel.AssignModel.CMFName(empData.FirstName);
                                //    uof.ui.incident.detail.viewModel.AssignModel.CMLName(empData.LastName);
                                //    uof.ui.incident.detail.viewModel.AssignModel.CMMName(empData.MiddleName);
                                //    uof.ui.incident.detail.viewModel.AssignModel.CMRank(empData.Rank);
                                //    uof.ui.incident.detail.viewModel.AssignModel.CMEmailId(empData.EmailAddress);
                                //}
                            else if (optionCriteria == 'Cat3') {
                                uof.ui.incident.detail.viewModel.Cat3Model.WCFName(empData.FirstName);
                                uof.ui.incident.detail.viewModel.Cat3Model.WCLName(empData.LastName);
                                uof.ui.incident.detail.viewModel.Cat3Model.WCMName(empData.MiddleName);
                                uof.ui.incident.detail.viewModel.Cat3Model.WCRank(empData.Rank);
                                uof.ui.incident.detail.viewModel.Cat3Model.WCEmailId(empData.EmailAddress);
                            }
                            else if (optionCriteria == 'tblAddlSer #bNumber') {
                                var dataSID = _.find(uof.ui.incident.detail.viewModel.incident.AdditionalSergeant(), function (item) {
                                    if (item.EmployeeNumber() == empId)
                                        return item;
                                });
                                _.each(uof.ui.incident.detail.viewModel.incident.AdditionalSergeant(), function (data) {
                                    if (data.EmployeeNumber() == dataSID.EmployeeNumber())
                                        data.Name(empData.FirstName + " " + empData.LastName + " " + empData.MiddleName);
                                });
                            }
                            else if (optionCriteria == 'IsInvestigatorDirected') {
                                uof.ui.incident.detail.viewModel.incident.SupervisorDirectedFirstName(empData.FirstName);
                                uof.ui.incident.detail.viewModel.incident.SupervisorDirectedLastName(empData.LastName);
                                uof.ui.incident.detail.viewModel.incident.SupervisorDirectedRank(empData.Rank);
                                uof.ui.incident.detail.viewModel.incident.SupervisorDirectedMailId(empData.EmailAddress);
                            }
                            else if (optionCriteria == 'MentalHealthEmpId') {
                                uof.ui.incident.detail.viewModel.incident.MentalHealthEmpName(empData.FirstName + " " + empData.LastName + " " + empData.MiddleName);
                            }

                            $.prototype.hideProgressBar("emplSection");
                        },
                        error: function (XMLHttpRequest, textStatus, errorThrown) {
                            $.prototype.hideProgressBar("emplSection");
                            showAlert("error");
                        }
                    });
                }
            },

            subscribeEvents: function () {

                //uof.ui.incident.detail.viewModel.incident.IsDeptyInjury.subscribe(function (newValue) {
                //    if ($.trim(newValue) == "Y")
                //        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.isInjurySeverityEnabled(true);
                //    else
                //        uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.isInjurySeverityEnabled(false);
                //});
                //uof.ui.incident.detail.viewModel.incident.IsSuspectInjury.subscribe(function (newValue) {
                //    //TypeOfInjury
                //    //CivilianinjurySeverity
                //    if ($.trim(newValue) == "Y")
                //        uof.ui.incident.detail.viewModel.incident.PlannedForceInfo.MHSReason.valueHasMutated();
                //});

                uof.ui.incident.detail.viewModel.incident.MedRcdPrior.subscribe(function (newValue) {
                    if ($.trim(newValue) == "Y")
                        uof.ui.incident.detail.viewModel.incident.PlanAltered.valueHasMutated();
                    else
                        uof.ui.incident.detail.viewModel.incident.PlanAltered("");
                });
                uof.ui.incident.detail.viewModel.incident.ForceTypeId.subscribe(function (newValue) {
                    if (newValue != null && newValue.length > 0) {
                        if (newValue.join(',') == "CE" || newValue.join(',') == "TG" || newValue.join(',') == "OC" || newValue.join(',').match(/CE/g) != null || newValue.join(',').match(/TG/g) != null || newValue.join(',').match(/OC/g) != null) {
                            uof.ui.incident.detail.viewModel.incident.MedRcdPrior.valueHasMutated();
                        }
                        else {
                            uof.ui.incident.detail.viewModel.incident.MedRcdPrior();
                            uof.ui.incident.detail.viewModel.incident.MedRcdPrior.isModified(false);
                            //$("#MedRcdPrior").css('display', "hidden");
                        }
                    }
                });
                uof.ui.incident.detail.viewModel.incident.IsInvestigatorDirectedTheForce.subscribe(function (newValue) {
                    if ($.trim(newValue) != "Y") {
                        uof.ui.incident.detail.viewModel.incident.SupervisorDirectedId(null);
                        uof.ui.incident.detail.viewModel.incident.SupervisorDirectedFirstName(null);
                        uof.ui.incident.detail.viewModel.incident.SupervisorDirectedLastName(null);
                        uof.ui.incident.detail.viewModel.incident.SupervisorDirectedRank(null);
                    }
                });
                uof.ui.incident.detail.viewModel.incident.MHS.subscribe(function (newValue) {
                    if ($.trim(newValue) == "Y")
                        uof.ui.incident.detail.viewModel.incident.MHSReason.valueHasMutated();

                });
                //uof.ui.incident.detail.viewModel.incident.PlannedForceInfo.Investienter.subscribe(function (newValue) {
                //    if ($.trim(newValue) == "N")
                //        uof.ui.incident.detail.viewModel.incident.PlannedForceInfo.InvestiExplain.valueHasMutated();
                //    else if ($.trim(newValue) == "Y")
                //        uof.ui.incident.detail.viewModel.incident.eLOTS.valueHasMutated();
                //});


                uof.ui.incident.detail.viewModel.incident.IsReactiveForce.subscribe(function (newValue) {
                    if ($.trim(newValue) == "true" && uof.ui.incident.detail.viewModel.incident.IsReactiveForce())
                        uof.ui.incident.detail.viewModel.incident.PRReason.valueHasMutated();
                    else if ($.trim(newValue) == "false") {
                        uof.ui.incident.detail.viewModel.incident.PRReason(null);
                        $("#PRReason").prop("disabled", true);
                    }
                });
                uof.ui.incident.detail.viewModel.incident.IsPlannedForce.subscribe(function (newValue) {
                    if ($.trim(newValue) == "true" && uof.ui.incident.detail.viewModel.incident.IsPlannedForce()) {
                        uof.ui.incident.detail.viewModel.incident.PRReason.valueHasMutated();
                        uof.ui.incident.detail.viewModel.incident.PFData.valueHasMutated();
                    }

                    else if ($.trim(newValue) == "false") {
                        uof.ui.incident.detail.viewModel.incident.PRReason(null);
                        //uof.ui.incident.detail.viewModel.incident.PlannedForceInfo.PFExtraction(null);
                        //uof.ui.incident.detail.viewModel.incident.PlannedForceInfo.PFPlannedUoF(null);
                        //uof.ui.incident.detail.viewModel.incident.PlannedForceInfo.MHS(null);
                        //uof.ui.incident.detail.viewModel.incident.PlannedForceInfo.MHSReason(null);
                        //uof.ui.incident.detail.viewModel.incident.PlannedForceInfo.MedicalLife(null);
                        //uof.ui.incident.detail.viewModel.incident.PlannedForceInfo.Investienter(null);
                        //uof.ui.incident.detail.viewModel.incident.PlannedForceInfo.InvestiExplain(null);
                        uof.ui.incident.detail.viewModel.incident.PFData(null);
                        $("#PFData").prop("disabled", true);
                        $("#PRReason").prop("disabled", true);
                    }
                });

                uof.ui.incident.detail.viewModel.incident.CustodyEventId.subscribe(function (newValue) {
                    uof.ui.incident.detail.viewModel.hasError(false);
                    if ($.trim(newValue) == "OTH") {
                        uof.ui.incident.detail.viewModel.incident.CTOthers.valueHasMutated();
                    }

                });
                uof.ui.incident.detail.viewModel.incident.IsIABNotified.subscribe(function (newValue) {
                    uof.ui.incident.detail.viewModel.hasError(false);
                    if ($.trim(newValue) != "N") {
                        uof.ui.incident.detail.viewModel.hasError(true);
                    }
                    else {
                        uof.ui.incident.detail.viewModel.incident.PersonNotified('');
                        uof.ui.incident.detail.viewModel.incident.IABNotifiedUserId('');
                    }

                });
                uof.ui.incident.detail.viewModel.incident.IsIABRollOut.subscribe(function (newValue) {
                    uof.ui.incident.detail.viewModel.hasError(false);
                    if ($.trim(newValue) != "N") {
                        uof.ui.incident.detail.viewModel.hasError(true);
                    }
                    else {
                        uof.ui.incident.detail.viewModel.incident.IABRolloutEmployees('');
                    }

                });
                uof.ui.incident.detail.viewModel.incident.IsIABHandling.subscribe(function (newValue) {
                    uof.ui.incident.detail.viewModel.hasError(false);
                    if ($.trim(newValue) != "N") {
                        uof.ui.incident.detail.viewModel.hasError(true);
                    }
                    else {
                        uof.ui.incident.detail.viewModel.incident.IABHandlingUserId('');
                        uof.ui.incident.detail.viewModel.incident.IABHandlingFirstName('');
                        uof.ui.incident.detail.viewModel.incident.IABHandlingLastName('');
                        uof.ui.incident.detail.viewModel.incident.IABHandlingRank('');
                    }

                });
                uof.ui.incident.detail.viewModel.incident.IsCFRTNotified.subscribe(function (newValue) {
                    uof.ui.incident.detail.viewModel.hasError(false);
                    if ($.trim(newValue) != "N") {
                        uof.ui.incident.detail.viewModel.hasError(true);
                    }
                    else {
                        uof.ui.incident.detail.viewModel.incident.CFRTNotifiedFirstName('');
                        uof.ui.incident.detail.viewModel.incident.CFRTNotifiedRank('');
                        uof.ui.incident.detail.viewModel.incident.CFRTNotifiedLastName('');
                        uof.ui.incident.detail.viewModel.incident.CFRTNotifiedUserId('');
                    }

                });
                uof.ui.incident.detail.viewModel.incident.IsCFRTRollOut.subscribe(function (newValue) {
                    uof.ui.incident.detail.viewModel.hasError(false);
                    if ($.trim(newValue) != "N") {
                        uof.ui.incident.detail.viewModel.hasError(true);
                    }
                    else {
                        uof.ui.incident.detail.viewModel.incident.CFRTRolloutEmployees('');
                    }

                });
                uof.ui.incident.detail.viewModel.incident.IsCFRTHandling.subscribe(function (newValue) {
                    uof.ui.incident.detail.viewModel.hasError(false);
                    if ($.trim(newValue) != "N") {
                        uof.ui.incident.detail.viewModel.hasError(true);
                    }
                    else {
                        uof.ui.incident.detail.viewModel.incident.CFRTHandlingFirstName('');
                        uof.ui.incident.detail.viewModel.incident.CFRTHandlingFirstName('');
                        uof.ui.incident.detail.viewModel.incident.CFRTHandlingLastName('');
                        uof.ui.incident.detail.viewModel.incident.CFRTHandlingRank('');
                    }

                });
                //uof.ui.incident.detail.viewModel.incident.IsExtractionOrderByMedical.subscribe(function (newValue) {
                //    if (newValue) {
                //        uof.ui.incident.detail.viewModel.hasError(false);
                //        uof.ui.incident.detail.viewModel.incident.ExtractionEmpId.valueHasMutated();
                //        if (newValue != "Y")
                //            uof.ui.incident.detail.viewModel.incident.ExtractionEmpId("");
                //        return false;
                //    }
                //});
                uof.ui.incident.detail.viewModel.incident.IsMentalHealthProfessional.subscribe(function (newValue) {
                    if (newValue) {
                        uof.ui.incident.detail.viewModel.hasError(false);
                        uof.ui.incident.detail.viewModel.incident.MentalHealthEmpId.valueHasMutated();
                        if (newValue != "Y") {
                            uof.ui.incident.detail.viewModel.incident.MentalHealthEmpId("");
                            uof.ui.incident.detail.viewModel.incident.MentalHealthEmpName("");
                            return false;
                        }
                    }
                });
                //uof.ui.incident.detail.viewModel.incident.ExtractionEmpId.extend({
                //    required: {
                //        message: IncidentConstants.Required,
                //        onlyIf: function () {
                //            return (uof.ui.incident.detail.viewModel.incident.IsExtractionOrderByMedical() === 'Y');
                //        }
                //    }
                //});
                uof.ui.incident.detail.viewModel.incident.MentalHealthEmpId.extend({
                    required: {
                        message: IncidentConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.incident.detail.viewModel.incident.IsMentalHealthProfessional() === 'Y');
                        }
                    }
                });

                uof.ui.incident.detail.viewModel.incident.IsCCTVCoverage.subscribe(function (newValue) {
                    if (newValue) {
                        uof.ui.incident.detail.viewModel.hasError(false);
                        uof.ui.incident.detail.viewModel.incident.CCTVNoReason.valueHasMutated();
                        if (newValue != "N")
                            uof.ui.incident.detail.viewModel.incident.CCTVNoReason("");
                        return false;
                    }
                });
                uof.ui.incident.detail.viewModel.incident.elotsYN.subscribe(function (newValue) {
                    if (newValue) {
                        uof.ui.incident.detail.viewModel.hasError(false);
                        uof.ui.incident.detail.viewModel.incident.elotsNoReason.valueHasMutated();
                        if (newValue != "N")
                            uof.ui.incident.detail.viewModel.incident.elotsNoReason("");
                        return false;
                    }
                });
                uof.ui.incident.detail.viewModel.incident.ForceLocation.subscribe(function (newValue) {
                    $("#Staging").attr('disabled', true);
                    if (newValue.length > 0) {
                        if (newValue.join(',') == "SA" || newValue.join(',').match(/SA/g) != null) {
                            $("#Staging").attr('disabled', false);
                            uof.ui.incident.detail.viewModel.incident.Staging.valueHasMutated();
                        }
                        else
                            uof.ui.incident.detail.viewModel.incident.Staging(null);
                    }
                });

                uof.ui.incident.detail.viewModel.incident.IsVideoOfIncident.subscribe(function (newValue) {
                    if (newValue) {
                        uof.ui.incident.detail.viewModel.hasError(false);
                        uof.ui.incident.detail.viewModel.incident.VideoShootedNoReason.valueHasMutated();
                        if (newValue != "N")
                            uof.ui.incident.detail.viewModel.incident.VideoShootedNoReason("");
                        return false;
                    }
                });
                uof.ui.incident.detail.viewModel.incident.CCTVNoReason.extend({
                    required: {
                        message: IncidentConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.incident.detail.viewModel.incident.IsCCTVCoverage() === 'N');
                        }
                    }
                });
                uof.ui.incident.detail.viewModel.incident.VideoShootedNoReason.extend({
                    required: {
                        message: IncidentConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.incident.detail.viewModel.incident.IsVideoOfIncident() === 'N');
                        }
                    }
                });
                uof.ui.incident.detail.viewModel.incident.Staging.extend({
                    required: {
                        message: IncidentConstants.Required,
                        onlyIf: function () {
                            if (uof.ui.incident.detail.viewModel.incident.ForceLocation() != null && uof.ui.incident.detail.viewModel.incident.ForceLocation() != "") {
                                return uof.ui.incident.detail.viewModel.incident.ForceLocation().toString().match(/SA/g) == "SA"
                            }
                        }
                    }
                });

                uof.ui.incident.detail.viewModel.incident.elotsNoReason.extend({
                    required: {
                        message: IncidentConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.incident.detail.viewModel.incident.elotsYN() === 'N');
                        }
                    }
                });

            },

            AssigntoIAB: function (incidentId) {
                $.prototype.showUofOverlay();
                $.ajax({
                    type: 'GET',
                    url: window.location.uofAPIOrigin() + '/api/Review/AssigntoIAB',
                    data: { incidentId: incidentId },
                    success: function (data) {
                        $.prototype.hideUofOverlay();
                        if (data) {
                            showAlert("Email Notification sent");
                            uof.ui.incident.detail.bindIncidentDetails();
                        }
                        else
                            showAlert("Please fill the IAB and WC related forms");
                    },
                    error: function (e) {
                        $.prototype.hideUofOverlay();
                        showAlert(e.responseText);
                    },
                });
            },

            openAssignPopup: function (incidentId, URN) {
                //uof.ui.incident.detail.verifyCategoryOneIncident(incidentId, 14);
                uof.ui.incident.detail.viewModel.AssignModel.IncidentId(incidentId);

                uof.ui.incident.detail.verifyPackageisReady();
            },
            verifyPackageisReady: function () {
                $.prototype.showUofOverlay();
                $.ajax({
                    type: "GET",
                    url: window.location.uofAPIOrigin() + '/api/UOFForm/ReadyforPackage?incidentId=' + uof.ui.incident.detail.viewModel.AssignModel.IncidentId() + '&rank=' + UoFParams.userRank,
                    cache: false,
                    dataType: 'json',
                    contentType: "application/json;charset=utf-8",
                    success: function (data) {
                        var title = '';
                        if (data == "OK") {
                            $.prototype.hideUofOverlay();
                            if (UoFParams.userRank == 2)
                                title = "Watch Commander";
                            if (UoFParams.userRank == 3)
                                title = "Unit Commander";
                            if (UoFParams.userRank == 4)
                                title = "Commander";
                            if (UoFParams.userRank == 5)
                                title = "Division Chief";
                            $("#divAssignIncident").show();
                            $("#divAssignIncident").kendoWindow({
                                width: "35%",
                                title: "Assign to " + title,
                                visible: false,
                                modal: true,
                                actions: [
                                        "Pin",
                                        "Close"
                                ],
                            }).data("kendoWindow").center().open();
                            uof.ui.incident.detail.validateAssignControls();
                        }
                        else {
                            $.prototype.hideUofOverlay();
                            showAlert(data);
                        }
                    },
                    error: function (e) {
                        $.prototype.hideUofOverlay();
                        showAlert(e.responseText);
                    },
                });
            },
            verifyCategoryOneIncident: function (selectedIncidentId, formId) {
                $.ajax({
                    type: 'POST',
                    url: window.location.uofUIOrigin() + '/Incident/verifyIncidentCategory',
                    data: { id: selectedIncidentId, formID: formId },
                    success: function (data) {
                        if (data == "true") {
                            uof.ui.incident.detail.viewModel.AssignModel.IncidentId(selectedIncidentId);
                            uof.ui.incident.detail.viewModel.AssignModel.WCID("");
                            uof.ui.incident.detail.viewModel.AssignModel.UCID("");
                            uof.ui.incident.detail.viewModel.AssignModel.CMID("");
                            uof.ui.incident.detail.viewModel.AssignModel.WCLName("");
                            uof.ui.incident.detail.viewModel.AssignModel.WCFName("");
                            uof.ui.incident.detail.viewModel.AssignModel.WCMName("");
                            uof.ui.incident.detail.viewModel.AssignModel.WCRank("");
                            uof.ui.incident.detail.viewModel.AssignModel.UCLName("");
                            uof.ui.incident.detail.viewModel.AssignModel.UCFName("");
                            uof.ui.incident.detail.viewModel.AssignModel.UCMName("");
                            uof.ui.incident.detail.viewModel.AssignModel.UCRank("");
                            uof.ui.incident.detail.viewModel.AssignModel.CMLName("");
                            uof.ui.incident.detail.viewModel.AssignModel.CMFName("");
                            uof.ui.incident.detail.viewModel.AssignModel.CMMName("");
                            uof.ui.incident.detail.viewModel.AssignModel.CMRank("");
                            $("#divAssignIncident").show();
                            $("#divAssignIncident").kendoWindow({
                                width: "65%",
                                title: "Assign this incident for Review",
                                visible: false,
                                modal: true,
                                actions: [
                                        "Pin",
                                        "Close"
                                ],
                            }).data("kendoWindow").center().open();
                            uof.ui.incident.detail.validateAssignControls();
                        }
                        else
                            showAlert("Please fill Use of Force Category One Incidents");
                    }
                });
            },
            openAssignCat3: function (incidentId) {
                uof.ui.incident.detail.viewModel.Cat3Model.IncidentId(incidentId);
                $("#divAssignCat3").show();
                $("#divAssignCat3").kendoWindow({
                    title: "Assign to Watch Commander",
                    visible: false,
                    modal: true,
                    actions: [
                            "Pin",
                            "Close"
                    ],
                }).data("kendoWindow").center().open();

            },
            AssignCat: function () {
                uof.ui.incident.detail.validateCat();
                if (uof.ui.incident.detail.validateCatInc()) {
                    $.prototype.showUofOverlay();
                    var oWCData = new Object();
                    oWCData.IncidentId = uof.ui.incident.detail.viewModel.Cat3Model.IncidentId();
                    oWCData.EmployeeId = uof.ui.incident.detail.viewModel.Cat3Model.WCID();
                    oWCData.FirstName = uof.ui.incident.detail.viewModel.Cat3Model.WCFName();
                    oWCData.LastName = uof.ui.incident.detail.viewModel.Cat3Model.WCLName();
                    oWCData.MiddleName = uof.ui.incident.detail.viewModel.Cat3Model.WCMName();
                    oWCData.Rank = uof.ui.incident.detail.viewModel.Cat3Model.WCRank();
                    oWCData.EmailId = uof.ui.incident.detail.viewModel.Cat3Model.WCEmailId();
                    var mappedData = ko.mapping.toJS(oWCData);
                    $.ajax(
                           {

                               url: window.location.uofAPIOrigin() + '/api/Review/AssignCat3',
                               cache: false,
                               type: "POST",
                               dataType: 'json',
                               data: JSON.stringify(mappedData),
                               contentType: "application/json;charset=utf-8",
                               beforeSend: function myfunction() {

                               },
                               success: function (data) {
                                   $.prototype.hideUofOverlay();
                                   showAlert("Assign to Watch Commander");
                                   uof.ui.incident.detail.bindIncidentDetails();
                                   $("#divAssignCat3").data("kendoWindow").close();
                               },
                               error: function (e) {
                                   $.prototype.hideUofOverlay();
                                   showAlert(e.responseText);
                                   $("#divAssignCat3").data("kendoWindow").close();
                               },
                           });

                }
            },
            cancelCat: function () {
                uof.ui.incident.detail.viewModel.Cat3Model.WCID("");
                uof.ui.incident.detail.viewModel.Cat3Model.WCLName("");
                uof.ui.incident.detail.viewModel.Cat3Model.WCFName("");
                uof.ui.incident.detail.viewModel.Cat3Model.WCLName("");
                uof.ui.incident.detail.viewModel.Cat3Model.WCRank("");
                $("#divAssignCat3").data("kendoWindow").close();
            },
            openReviewCommentsPage: function (incidentId) {
                uof.ui.incident.detail.viewModel.RCModel.IncidentId(incidentId);
                //uof.ui.incident.detail.viewModel.RCModel.FormId("");
                //uof.ui.incident.detail.viewModel.RCModel.Comments("");
                $("#divReviewComments").show();
                $("#divReviewComments").kendoWindow({
                    width: "35%",
                    title: "Review Comments",
                    visible: false,
                    modal: true,
                    actions: [
                            "Pin",
                            "Close"
                    ],
                }).data("kendoWindow").center().open();

            },
            RCSubmit: function () {
                uof.ui.incident.detail.validateCommentControls();
                if (uof.ui.incident.detail.validateComments()) {

                    $.prototype.showUofOverlay();
                    //uof.ui.incident.detail.viewModel.RCModel.IncidentId(UoFParams.IncidentId);
                    uof.ui.incident.detail.viewModel.RCModel.CommentedBy(UoFParams.userId);
                    var mappedData = ko.mapping.toJS(uof.ui.incident.detail.viewModel.RCModel);
                    $.ajax(
                           {

                               url: window.location.uofAPIOrigin() + '/api/UOFForm/SaveReviewComments',
                               cache: false,
                               type: "POST",
                               dataType: 'json',
                               data: JSON.stringify(mappedData),
                               contentType: "application/json;charset=utf-8",
                               beforeSend: function myfunction() {

                               },
                               success: function (data) {
                                   $.prototype.hideUofOverlay();
                                   showAlert(data);
                               },
                               error: function (e) {
                                   $.prototype.hideUofOverlay();
                                   showAlert(e.responseText);
                               },
                           });

                }
            },
            cancelRC: function () {
                uof.ui.incident.detail.viewModel.RCModel.FormId("");
                uof.ui.incident.detail.viewModel.RCModel.ReviewComments("");
                $("#divReviewComments").data("kendoWindow").close();
            },

            openAssignOthers: function (incidentId) {
                uof.ui.incident.detail.viewModel.emailMode.EmailId("");
                //this.setSelectedIncidentId(incidentId, true);
                uof.ui.incident.detail.viewModel.emailMode.IncidentId(incidentId);

                $("#divAssignOthers").show();
                $("#divAssignOthers").kendoWindow({
                    width: "55%",
                    title: "Assign this incident for CFRT",
                    visible: false,
                    modal: true,
                    actions: [
                            "Pin",
                            "Close"
                    ],
                }).data("kendoWindow").center().open();
                uof.ui.incident.detail.validateEmailControl();
                $("#CFRTEmailId").focus();
            },
            AssignOthers: function () {
                if (uof.ui.incident.detail.validateEmailField()) {
                    //var parameters = { emailId: uof.ui.incident.detail.viewModel.emailMode.EmailId(), IncidentId: uof.ui.incident.detail.viewModel.emailMode.IncidentId(), LoggedInRole: UoFParams.userRole };
                    //var mappedData = ko.mapping.toJS(parameters);
                    $.ajax(
                           {
                               url: window.location.uofAPIOrigin() + '/api/Review/SentToCFRT?emailId=' + uof.ui.incident.detail.viewModel.emailMode.EmailId() + '&IncidentId=' + uof.ui.incident.detail.viewModel.emailMode.IncidentId() + '&LoggedInRole=' + UoFParams.userRole,
                               cache: false,
                               type: "GET",
                               dataType: 'json',
                               contentType: "application/json;charset=utf-8",
                               beforeSend: function myfunction() {

                               },
                               success: function (assignData) {
                                   $.prototype.hideUofOverlay();
                                   if (assignData == false)
                                       showAlert("Error");
                                   uof.ui.incident.detail.bindIncidentDetails();
                                   $("#divAssignOthers").data("kendoWindow").close();

                               },
                               error: function (e) {
                                   $.prototype.hideUofOverlay();
                                   showAlert(e.responseText);
                               },
                           });
                }
            },
            cancelOther: function () {
                $("#divAssignOthers").data("kendoWindow").close();
            },

            CheckDuplicateURN: function () {
                var URN = uof.ui.incident.detail.viewModel.incident.URN();
                uof.ui.incident.detail.viewModel.DuplicateURn(false);
                if (URN != null && URN != '') {

                    $.prototype.showUofOverlay();
                    $.ajax(
                        {
                            url: window.location.uofAPIOrigin() + '/api/Incident/CheckDuplicateURN',
                            cache: false,
                            type: "GET",
                            data: { URN: URN, incidentId: uof.ui.incident.detail.selectedContext.selectedIncident() },
                            dataType: 'json',
                            contentType: "application/json;charset=utf-8",
                            beforeSend: function myfunction() {

                            },
                            success: function (isExists) {
                                $.prototype.hideUofOverlay();

                                if (isExists) {
                                    uof.ui.incident.detail.viewModel.DuplicateURn(true);
                                    showAlert("URN is already exist.");
                                    //$('#URN').focus();
                                }
                            },
                            error: function (e) {
                                $.prototype.hideUofOverlay();
                                showAlert(e.responseText);
                            },
                        });
                }
            },
            buildARObject: function (isApprove) {
                var oARData = new Object();
                oARData.IncidentId = uof.ui.incident.detail.selectedContext.selectedIncident();
                oARData.FormId = 48;
                oARData.DeputyEmpId = uof.ui.incident.detail.viewModel.incident.EmpId();
                oARData.isApprove = isApprove;
                oARData.ReviewerReviewId = UoFParams.userId;
                oARData.ReviewerRole = UoFParams.userRole;
                oARData.isSRForm = true;
                return oARData;
            },
            approveOrReject: function (isApprove) {
                var str = isApprove == "Y" ? "Do you want to Approve?" : "Do you want to Reject?";
                $.when(showConfirmationWindow(str)).then(function (confirmed) {
                    var oARData = uof.ui.incident.detail.buildARObject(isApprove);
                    var mappedData = ko.mapping.toJS(oARData);
                    $.ajax(
                        {
                            url: window.location.uofAPIOrigin() + '/api/UOFForm/ApproveorReject',
                            cache: false,
                            type: "POST",
                            dataType: 'json',
                            data: JSON.stringify(mappedData),
                            contentType: "application/json;charset=utf-8",
                            beforeSend: function myfunction() {

                            },
                            success: function (data) {
                                $.prototype.hideUofOverlay();
                                showAlert((isApprove == "Y" ? "Approved" : "Rejected") + " Succesfully");
                                $("#btnApprove").addClass("hide"); $("#btnReject").addClass("hide");
                            },
                            error: function (e) {
                                $.prototype.hideUofOverlay();
                                showAlert(e.responseText);
                            },
                        });
                });
            },
            submitIncident: function () {
                if (uof.ui.incident.detail.validateAllSections()) {
                    $.when(showConfirmationWindow('Do you want to submit the for the review ? ')).then(function (confirmed) {
                        if (confirmed) {
                            $.ajax(
                            {
                                url: window.location.uofAPIOrigin() + '/api/Incident/SubmitIncident?incidentId=' + uof.ui.incident.detail.selectedContext.selectedIncident() + '&sergeantId=' + UoFParams.userId,
                                type: "POST",
                                beforeSend: function myfunction() {

                                },
                                success: function (response) {
                                    $.prototype.hideUofOverlay();
                                    showAlert(response);
                                },
                                error: function (e) {
                                    $.prototype.hideUofOverlay();
                                    showAlert(e.responseText);
                                },
                            });
                        }

                    });
                }

            },
            validateAllSections: function () {
                var isValidIncident = uof.ui.incident.detail.validateIncidentFields();
                var isValidDupties = uof.ui.incident.deputy.validateDeputiesInfoFields();
                var InvEmp = uof.ui.InvolvedEmployee.viewModel.InvolvedEmployeeList();
                var InvCnt = "";
                var SuspCnt = "";
                var EWLCnt = "";
                var NEWLCnt = "";
                if (InvEmp.length > 0) {
                    $.each(InvEmp, function (index, element) {
                        var isValid = uof.ui.InvolvedEmployee.validateEmployeeFields(element);
                        if (!isValid) {
                            if (InvCnt == "")
                                InvCnt = index.toString()
                            else
                                InvCnt = InvCnt + "," + index.toString()
                        }

                    });
                }
                var isValidInvolved = (InvCnt == "" && InvEmp.length > 0) ? true : false;
                var SusList = uof.ui.Suspects.viewModel.SuspectEmployeeList();
                if (SusList.length > 0) {
                    $.each(SusList, function (index, element) {
                        var isValid = uof.ui.Suspects.validateSuspectFields(element);
                        if (!isValid) {
                            if (SuspCnt == "")
                                SuspCnt = index.toString()
                            else
                                SuspCnt = SuspCnt + "," + index.toString()
                        }

                    });
                }
                var isValidsuspect = (SuspCnt == "" && SusList.length > 0) ? true : false;
                var EWLlist = uof.ui.EmployeeWitness.empWitnessViewModel.empWitnessList();
                if (EWLlist.length > 0) {
                    $.each(EWLlist, function (index, element) {
                        var model = ko.mapping.toJS(element);
                        var isValid = uof.ui.EmployeeWitness.validateWitnessEmployeeFields(element);
                        if (!isValid) {
                            if (EWLCnt == "")
                                EWLCnt = index.toString()
                            else
                                EWLCnt = EWLCnt + "," + index.toString()
                        }

                    });
                }
                var NEWLlist = uof.ui.Witness.viewModel.nonEmpWitnessList();
                if (NEWLlist.length > 0) {
                    $.each(NEWLlist, function (index, element) {
                        var isValid = uof.ui.Witness.validateWitnessNonEmployeeFields(element);
                        if (!isValid) {
                            if (NEWLCnt == "")
                                NEWLCnt = index.toString()
                            else
                                NEWLCnt = NEWLCnt + "," + index.toString()
                        }

                    });
                }
                var isValidWitness = (EWLCnt == "" && EWLlist.length > 0) ? true : false;
                var isValidNonWitness = (NEWLCnt == "" && NEWLlist.length > 0) ? true : false;

                var Msg = "";
                if (!isValidIncident)
                    Msg = "Incident Section is not completed" + "<br/>";
                if (!isValidInvolved)
                    Msg = Msg + "Involved Section is not completed" + "<br/>";
                if (!isValidsuspect)
                    Msg = Msg + "Suspect Section is not completed" + "<br/>";
                if (!isValidDupties)
                    Msg = Msg + "Supervisory Section is not completed" + "<br/>";
                if (!isValidWitness)
                    Msg = Msg + "Employee Witness Section is not completed" + "<br/>";
                if (!isValidNonWitness)
                    Msg = Msg + "Non Employee Witness Section is not completed" + "<br/>";
                if (Msg != "")
                    showAlert(Msg);
                return isValidIncident && isValidInvolved && isValidsuspect & isValidDupties & isValidWitness & isValidNonWitness;

            },
            DeleteIncidentForms: function (ReviewId) {
                $.when(showConfirmationWindow('Are you sure you want to delete this form?')).then(function (confirmed) {
                    if (confirmed) {
                        $.prototype.showUofOverlay();
                        $.ajax(
                        {
                            url: window.location.uofAPIOrigin() + '/api/Incident/DeleteIncidentForm?ReviewId=' + ReviewId,
                            cache: false,
                            type: "DELETE",
                            dataType: 'json',
                            contentType: "application/json;charset=utf-8",
                            success: function () {
                                $.prototype.hideUofOverlay();
                                uof.ui.incident.detail.bindIncidentDetails();

                            },
                            error: function (e) {
                                $.prototype.hideUofOverlay();
                                showAlert(e.responseText);
                            },
                        });
                    }
                });
            },
            rolloutToChief: function (incidentId) {
                $.when(showConfirmationWindow('Do you want to send to Cheif ? ')).then(function (confirmed) {
                    if (confirmed) {
                        $.prototype.showUofOverlay();
                        $.ajax(
                              {
                                  url: window.location.uofAPIOrigin() + '/api/Review/RolloutToChief?incidentId=' + incidentId,
                                  cache: false,
                                  type: "POST",
                                  dataType: 'json',
                                  contentType: "application/json;charset=utf-8",
                                  beforeSend: function myfunction() {

                                  },
                                  success: function (data) {
                                      $.prototype.hideUofOverlay();
                                      showAlert("Incident assigned to Chief Succesfully");
                                      uof.ui.incident.detail.bindIncidentDetails();
                                  },
                                  error: function (e) {
                                      $.prototype.hideUofOverlay();
                                      showAlert(e.responseText);
                                  },
                              });
                    }
                });

            },
        }
    }();

}