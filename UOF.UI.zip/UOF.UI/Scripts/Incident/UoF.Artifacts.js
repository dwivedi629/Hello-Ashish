﻿var uof = uof || {};
uof.ui = uof.ui || {};
uof.ui.artifacts = uof.ui.artifacts || {};
if (uof.ui.artifacts) {
    uof.ui.artifacts = function () {
        return {

            load: function (ui) {
                this.bindArtifactsDetails();
                $("#artifactFileupload").fileupload();
                $('.progress-bar').css("width", "0%");
                if ((uof.ui.incident.detail.viewModel.incident.currentMode() == 'Edit')) {
                    uof.ui.artifacts.SetFormControls(false);
                }
                else if ((uof.ui.incident.detail.viewModel.incident.currentMode() == 'view')) {
                    uof.ui.artifacts.SetFormControls(true);
                }
            },
            SetFormControls: function (isDisable) {
                $("#ArtifactsInfo").find('input, select, textarea, button').each(function () {
                    $(this).attr('disabled', isDisable);
                });
            },
            bindArtifactsDetails: function () {

                $.prototype.showUofOverlay();
                var dlAjaxOption =
                    {
                        url: window.location.uofAPIOrigin() + '/api/Artifacts/GetIncidentArtifacts',
                        cache: false,
                        data: { incidentId: uof.ui.incident.detail.selectedContext.selectedIncident() },
                        type: "GET",
                        dataType: 'json',
                        contentType: "application/json;charset=utf-8",
                        success: function (artifactData) {
                            var geoDataSource = new kendo.data.DataSource({
                                data: artifactData,
                                pageSize: 20
                            });

                            //setting all Org Data to kendo
                            $("#artifactsGridData").kendoGrid({
                                dataSource: geoDataSource,
                                height: 400,
                                resizable: true,
                                sortable: true,
                                groupable: false,
                                columnMenu: true,
                                pageable: {
                                    refresh: false,
                                    pageSizes: true,
                                    pageSizes: [20, 40, 100],
                                    buttonCount: 5,
                                    messages: {
                                        empty: "No Arifacts Found",
                                        itemsPerPage: "Arifacts Per Page",
                                    },
                                },
                                columns: [
                                            {
                                                field: "ArtifactId",
                                                headerTemplate: $("#chkHeaderArtifactsOption").html(),
                                                template: $("#chkArtifactsOption").html(),
                                                width: "20px",
                                                sortable: false,
                                            },
                                            {
                                                field: "FileName",
                                                width: "150px",
                                                headerTemplate: '<span> File Name </span>',
                                                template: $("#fileNameLink").html(),
                                            },
                                            {
                                                field: "UploadedDate",
                                                width: "100px",
                                                headerTemplate: '<span>Uploaded Date</span>',
                                                type: "date",
                                                template: "#= kendo.toString(kendo.parseDate(UploadedDate, 'yyyy-MM-dd'), 'MM/dd/yyyy') #"
                                            },
                                             {
                                                 field: "ArtifactId",
                                                 sortable: false,
                                                 headerTemplate: $("#btnDeleteAllSelectedArtifacts").html(),
                                                 width: "40px",
                                                 template: $("#btnDeleteArtifacts").html(),
                                             },
                                ],

                            }).data().kendoGrid;

                            $.prototype.hideUofOverlay();
                        },
                        error: function (e) {
                            showAlert(e.responseText);
                        }

                    };
                // Call ajax
                var ajaxOptions = $.extend({}, 'GET', dlAjaxOption);
                $.ajax(ajaxOptions);

            },

            chkAllArtifactIds: function () {
                $('[name^="chkArtifact_"]').each(function () {
                    if ($('#headerChk').is(':checked')) {
                        $(this).prop('checked', true);
                    } else {
                        $(this).prop('checked', false);
                    }
                });
            },

            chkSelectedArtifactId: function () {
                var totalCount = 0;
                var chkCount = 0;
                $('[name^="chkArtifact_"]').each(function () {
                    totalCount += 1;
                });

                $('[name^="chkArtifact_"]').each(function () {
                    if ($(this).is(':checked')) {
                        chkCount += 1;
                    }
                });

                if (totalCount == chkCount) {
                    $('#headerChk').prop('checked', true);
                } else {
                    $('#headerChk').prop('checked', false);
                }
            },

            deleteAllSelectedArtifacts: function () {
                var arrFileName = [];
                $('[name^="chkArtifact_"]').each(function () {
                    if ($(this).is(':checked')) {
                        var idOfThisContext = $(this)[0].name.replace('chkArtifact_', '');
                        var fname = $('#file_' + idOfThisContext).data('filename');
                        arrFileName.push({ ArtifactId: idOfThisContext, FileName: fname });
                    }
                });

                $.each(arrFileName, function (index, item) {
                    uof.ui.artifacts.deleteArtifact(item.ArtifactId, item.FileName);
                });

                $('#headerChk').prop('checked', false);
            },

            deleteArtifact: function (artifactId, filename) {
                $.prototype.showUofOverlay();
                $.ajax({
                    type: "POST",
                    url: "../ArtifactsUpload/DeleteFile",
                    dataType: "json",
                    data: JSON.stringify({ artifactId: artifactId, incidentId: uof.ui.incident.detail.selectedContext.selectedIncident(), fileName: filename }),
                    contentType: "application/json;charset=utf-8",
                    cache: false,
                    success: function (result) {
                        if (result) {
                            $('.progress-bar').css("width", "0%");
                            $('.file_name').html("");
                            $('#headerChk').prop('checked', false);
                            $.prototype.hideUofOverlay();
                            uof.ui.artifacts.bindArtifactsDetails();
                        }
                    },
                });
            },

            validateFileType: function (fContainer) {
                var fileName = fContainer.files[0].name;

                if (fileName != undefined) {
                    return (new RegExp("(.*?)\.(" + artifactAcceptFiles + ")$")).test(String(fileName).toLowerCase());
                };

                return false;
            },

            uploadArtifactFiles: function (fContainer) {
                $('.file_name').html(fContainer.files[0].name);
                $('.progress-bar').css("width", "0%");
                var validateTypes = this.validateFileType(fContainer);
                if (!validateTypes) {
                    $("#artifactFileupload").fileupload();
                }
                if (validateTypes === true) {
                    $(fContainer).fileupload({
                        dataType: 'json',
                        url: '../ArtifactsUpload/UploadArtifactFiles',
                        maxFileSize: 1000000,
                        formData: { incidentId: uof.ui.incident.detail.selectedContext.selectedIncident() },
                        maxChunkSize: 1000000,
                        sequentialUploads: true,
                        beforeSend: function (jqXHR, settings) {
                            var isFound = (new RegExp("(.*?)\.(jpeg|jpg|gif|png|pjpeg)$")).test(String(settings.files[0].name).toLowerCase());

                            var totalFileCount = Math.round((settings.total / settings.maxChunkSize)) < (settings.total / settings.maxChunkSize)
                                                    ? (Math.round((settings.total / settings.maxChunkSize)) + 1) : Math.round((settings.total / settings.maxChunkSize));

                            if (isFound == false) {
                                var fName = settings.files[0].name + ".part_" + (settings.uploadedBytes / settings.maxChunkSize) +
                                    "." + totalFileCount;
                                jqXHR.setRequestHeader('X-Chunk-fname', fName);
                            }
                            else
                                jqXHR.setRequestHeader('X-Chunk-fname', settings.files[0].name);

                        },
                        stop: function (e, data) {
                            uof.ui.artifacts.bindArtifactsDetails();
                        }
                    }).on('fileuploadprogressall', function (e, data) {
                        var progress = parseInt(data.loaded / data.total * 100, 10);
                        $('.progress .progress-bar').css('width', progress + '%');
                    });
                }
            },

            changeSearchValue: function () {
                var controlModelName = $('#artifactsSearchData').val();
                $('#FileSearch').val('');
                $('#artifactEndTime').val('');
                $('#artifactEndTime').hide();
                if (controlModelName == "UploadedDate") {
                    $('#FileSearch').attr('type', 'date');
                    $('#artifactEndTime').show();
                }
                else {
                    $('#FileSearch').attr('type', 'text');
                }
                $("#artifactsGridData").data("kendoGrid").dataSource.filter({});
            },

            searchIncident: function (e) {
                $('#artifactEndTime').hide();
                var controlModelName = $('#artifactsSearchData').val();
                if (controlModelName == "UploadedDate") {
                    $('#FileSearch').attr('type', 'date');
                    $('#artifactEndTime').show();
                    if ($('#artifactEndTime').val() != '' && $('#FileSearch').val() != '') {
                        $("#artifactsGridData").data("kendoGrid").dataSource.filter({ field: controlModelName, operator: "ge", value: $('#FileSearch').val() });
                        $("#artifactsGridData").data("kendoGrid").dataSource.filter({ field: controlModelName, operator: "lte", value: $('#artifactEndTime').val() });
                    }
                    else if ($('#FileSearch').val() != '') {
                        $("#artifactsGridData").data("kendoGrid").dataSource.filter({ field: controlModelName, operator: "lte", value: $('#FileSearch').val() });
                    }
                    else {
                        $("#artifactsGridData").data("kendoGrid").dataSource.filter({ field: controlModelName, operator: "lte", value: e.value });
                    }
                }
                else {
                    $('#FileSearch').attr('type', 'text');
                    $("#artifactsGridData").data("kendoGrid").dataSource.filter({ field: controlModelName, operator: "contains", value: e.value });
                }

            },

        }
    }();
}