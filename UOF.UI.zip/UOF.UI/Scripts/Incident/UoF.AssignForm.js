﻿var uof = uof || {};
uof.ui = uof.ui || {};
uof.ui.incident = uof.ui.incident || {};
if (uof.ui.incident) {
    uof.ui.assignforms = function () {
        return {

            parameters: null,
            isChanged: false,
            selectedIncidentID: 0,
            isIncidentReportSelected: false,
            init: function (args) {
                this.parameters = args;
            },
            AssignObject: function (Id, EmpId, FirstName, LastName, Rank, MailId, FormIds, instanceCnt, InvolvedEmployee, EmployeeWitness, IncidentId, EmpRole) {
                this.Id = Id;
                this.EmpId = EmpId;
                this.FirstName = FirstName;
                this.LastName = LastName;
                this.MailId = MailId;
                this.FormIds = FormIds;
                this.instanceCnt = instanceCnt;
                this.InvolvedEmployee = InvolvedEmployee;
                this.EmployeeWitness = EmployeeWitness;
                this.IncidentId = IncidentId;
                this.EmpRole = EmpRole;
                return this;
            },
            AssignedDBSource: null,

            viewModel: {

                hasError: ko.observable(false),
                // To add different location, just add the one more item in this list

                FormNames: ko.observableArray([]),
                DeletedUser: ko.observableArray([]),
                Mode: ko.observable('Add'),
                FormModel: ko.observableArray(),
                AssignModel: {
                    LoggedRole: ko.observable(),
                    Mode: ko.observable('Add'),
                    LoggedId: ko.observable(),
                    IncidentId: ko.observable(0),
                    URN: ko.observable(),
                    Date: ko.observable(),
                    Assignment: ko.observableArray(),
                    DeletedUsers: ko.observableArray(),
                },
                getEmployeeDetails: function (empId, optionCriteria) { uof.ui.assignforms.getEmployeeDetails(empId, optionCriteria); },
                validateInstanceCount: function (instanceCnt, EmployeeId, FormIds) { uof.ui.assignforms.validateInstanceCount(instanceCnt, EmployeeId, FormIds); },
                VerifyURN: function (URN, optionCriteria) { uof.ui.assignforms.VerifyURN(URN, optionCriteria); },
            },
            validateInstanceCount: function (instanceCnt, EmployeeId, FormIds) {
                var isExists = $.grep(uof.ui.assignforms.AssignedDBSource.Assignment, function (item) {
                    return (item.EmployeeId == EmployeeId && item.FormIds == FormIds);
                });

                if (isExists.length == 1) {
                    if (instanceCnt < isExists[0].instanceCnt) {
                        $("#txtCount" + isExists[0].ID).val(isExists[0].instanceCnt);
                        showAlert("Should not be less than existing count");
                        return false;
                    }
                }
            },
            getEmployeeDetails: function (empId, targetDiv) {
                // Search based on emp id
                $.prototype.showProgressBar(targetDiv);
                jQuery.ajax({
                    type: "GET",
                    url: EmployeeAPIUrl() + empId,
                    dataType: "json",
                    cache: false,
                    crossDomain: true,
                    processData: true,
                    success: function (empData) {
                        var dataSID = _.find(uof.ui.assignforms.viewModel.AssignModel.Assignment(), function (item) {
                            if (item.EmployeeId() == empId)
                                return item;
                        });
                        _.each(uof.ui.assignforms.viewModel.AssignModel.Assignment(), function (data) {
                            if (data.EmployeeId() == dataSID.EmployeeId()) {
                                data.FirstName(empData.FirstName);
                                data.LastName(empData.LastName);
                                data.Rank(empData.Rank);
                                data.MailId(empData.EmailAddress);
                                if (empData.RankAbrev != null)
                                    data.EmpRole(empData.RankAbrev.toUpperCase());

                                var chk = uof.ui.assignforms.checkInvolvedandWitness();
                                if (chk != undefined && chk != null) {
                                    data.InvolvedEmployee(chk[0].InvolvedEmployee);
                                    data.EmployeeWitness(chk[0].EmployeeWitness);
                                }
                            }
                        });
                        $.prototype.hideProgressBar(targetDiv);
                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                        $.prototype.hideProgressBar(targetDiv);
                        showAlert("Error while getting the Employee Data");
                    }
                });

            },

            getEmployeeDetailsold: function (empId, targetDiv) {
                if ((empId != undefined) && (empId.length > 0)) {
                    var isExists = $.grep(uof.ui.assignforms.viewModel.AssignModel.Assignment(), function (item) {
                        return (item.EmployeeId() == empId);
                    });

                    if (isExists.length == 1) {
                        // Search based on emp id
                        $.prototype.showProgressBar(targetDiv);
                        jQuery.ajax({
                            type: "GET",
                            url: EmployeeAPIUrl() + empId,
                            dataType: "json",
                            cache: false,
                            crossDomain: true,
                            processData: true,
                            success: function (empData) {
                                var dataSID = _.find(uof.ui.assignforms.viewModel.AssignModel.Assignment(), function (item) {
                                    if (item.EmployeeId() == empId)
                                        return item;
                                });
                                _.each(uof.ui.assignforms.viewModel.AssignModel.Assignment(), function (data) {
                                    if (data.EmployeeId() == dataSID.EmployeeId()) {
                                        data.FirstName(empData.FirstName);
                                        data.LastName(empData.LastName);
                                        data.Rank(empData.Rank);
                                        data.MailId(empData.EmailAddress);
                                        if (empData.RankAbrev != null)
                                            data.EmpRole(empData.RankAbrev.toUpperCase());
                                    }
                                });
                                //_.each(uof.ui.assignforms.viewModel.AssignModel.Assignment(), function (item) {
                                //    if (item.EmployeeId() == EmployeeId) {
                                //        item.FirstName(empData.FirstName);
                                //        item.LastName(empData.LastName);
                                //        item.Rank(empData.Rank);
                                //        item.MailId(empData.MailId);
                                //    }
                                //    else {
                                //        item.FirstName(empData.FirstName);
                                //        item.LastName(empData.LastName);
                                //        item.Rank(empData.Rank);
                                //        item.MailId(empData.MailId);
                                //    }

                                //});
                                $.prototype.hideProgressBar(targetDiv);
                            },
                            error: function (XMLHttpRequest, textStatus, errorThrown) {
                                $.prototype.hideProgressBar(targetDiv);
                                showAlert("Error while getting the Employee Data");
                            }
                        });

                    }
                    else {
                        $.prototype.hideUofOverlay();
                        $("#txtEmpName" + isExists[0].ID).val("");
                        showAlert("User Already Exists");
                    }
                }
            },
            //load method, will be tirggered on document load
            load: function (IncidentId) {
                ko.validation.init({ insertMessages: true });
                this.initiateBindings();
                uof.ui.assignforms.validateControl();
                uof.ui.assignforms.bindMaskControl();
                uof.ui.assignforms.bindCustomValidation();
                this.getAllForm();
                if (UoFParams.IncidentId != "") {
                    uof.ui.assignforms.viewModel.AssignModel.URN(UoFParams.IncidentURN);
                    //this.getAssignFormsInfo();
                }
                //$(document).on('click', ".input-group.date", function () {
                //    uof.ui.assignforms.SetDatePicker($(this));
                //});


                //uof.ui.assignforms.SetDatePicker($(".input-group.date"));
                uof.ui.assignforms.validateControl();
                //binding 
                ko.cleanNode($("#divAssign").get(0));
                ko.applyBindings(uof.ui.assignforms.viewModel, $("#divAssign").get(0));

                uof.ui.assignforms.initiatePickers();
            },
            RemoveItems: function (item) {

                uof.ui.assignforms.viewModel.AssignModel.Assignment.remove(item);
                var Ritem = ko.mapping.toJS(item);
                uof.ui.assignforms.viewModel.DeletedUser.push({
                    EmployeeId: Ritem.EmployeeId,
                    LastName: Ritem.LastName,
                    FirstName: Ritem.FirstName,
                    Rank: Ritem.Rank,
                    EmployeeWitness: Ritem.EmployeeWitness,
                    InvolvedEmployee: Ritem.InvolvedEmployee,
                    IncidentId: Ritem.IncidentId,
                    FormIds: Ritem.FormIds,
                });
                $("#btnAddNew").attr("disabled", false);
            },
            AddNewItms: function () {

                //if (uof.ui.assignforms.isIncidentReportwithCAorCSSelected()) {
                uof.ui.assignforms.viewModel.AssignModel.Assignment.push(new uof.ui.assignforms.AssingFrms());
                //uof.ui.assignforms.SetDatePicker($(".input-group.date"));
                uof.ui.assignforms.refreshMulti();
                //}


            },
            checkInvolvedandWitness: function () {
                var tempAF = [];
                if (uof.ui.assignforms.viewModel.AssignModel.Assignment().length >= 2) {
                    var index = uof.ui.assignforms.viewModel.AssignModel.Assignment().length - 1;
                    var isExists = $.grep(uof.ui.assignforms.viewModel.AssignModel.Assignment(), function (item) {
                        if (index != (item.ID - 1)) {
                            if (item.EmployeeId() != null) {
                                var empName = $("#txtEmpName" + index).val();
                                return (item.EmployeeId() == empName);
                            }
                        }
                    });
                    return ko.mapping.toJS(isExists);
                }
            },
            validateForms: function () {
                var tempAF = [];
                if (uof.ui.assignforms.viewModel.AssignModel.Assignment().length >= 2) {
                    var index = uof.ui.assignforms.viewModel.AssignModel.Assignment().length - 1;
                    var isExists = $.grep(uof.ui.assignforms.viewModel.AssignModel.Assignment(), function (item) {
                        if (index != (item.ID - 1)) {
                            if (item.FormIds() != null && item.EmployeeId() != null) {
                                var selectedValue = $("#ddlformName" + index).val();
                                var empName = $("#txtEmpName" + index).val();
                                return (item.FormIds() == selectedValue && item.EmployeeId() == empName);
                            }
                        }
                    });
                    if (isExists.length == 1) {
                        showAlert("Already selected");
                        $("#ddlformName" + index).val("")
                    }
                }
            },

            refreshMulti: function () {
                var self = this;
                var valID = Math.max.apply(null, uof.ui.assignforms.viewModel.AssignModel.Assignment().map(function (a) { return a.ID; }))

                $.each(uof.ui.assignforms.viewModel.AssignModel.Assignment(), function (index, value) {
                    if (index == valID - 1) {
                        var id = valID - 1;
                        // $("#ddlformName" + id).selectpicker('destroy');
                        //$("#ddlformName" + id).selectpicker('refresh');
                    }
                });
            },

            SetDatePicker: function (obj) {
                $(obj).datetimepicker({ format: 'MM/DD/YYYY HH:mm' }).on('dp.change', function (ev) {
                    var self = $(this);
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY HH:mm");
                    $.each(uof.ui.assignforms.viewModel.AssignModel.Assignment(), function (index, value) {
                        if (self.attr('id') != undefined && self.attr('id') == value.ID) {
                            value.Date(newDate);
                        }
                    });


                });
            },
            bindMaskControl: function () {
                ko.bindingHandlers.inputmask =
                {
                    init: function (element, valueAccessor, allBindingsAccessor) {

                        var mask = valueAccessor();

                        var observable = mask.value;

                        if (ko.isObservable(observable)) {

                            $(element).on('focusout change', function () {

                                if ($(element).inputmask('isComplete')) {
                                    observable($(element).val());
                                } else {
                                    observable(null);
                                }

                            });
                        }

                        $(element).inputmask(mask);


                    },
                    update: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
                        var mask = valueAccessor();

                        var observable = mask.value;

                        if (ko.isObservable(observable)) {

                            var valuetoWrite = observable();

                            $(element).val(valuetoWrite);
                        }
                    }

                };
            },
            initiatePickers: function () {
                if (uof.ui.assignforms.viewModel.AssignModel.Assignment().length == 0) {
                    uof.ui.assignforms.viewModel.AssignModel.Assignment.push(new uof.ui.assignforms.AssingFrms());
                    uof.ui.assignforms.refreshMulti();
                    // uof.ui.assignforms.SetDatePicker($(".input-group.date"));
                }
                $('#IncidentDT').datetimepicker({ format: 'MM/DD/YYYY HH:mm', defaultDate: 'now' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY HH:mm");
                    uof.ui.assignforms.viewModel.AssignModel.Date(newDate);
                });

            },
            showAssignedForms: function () {
                //To Check whether Incident is Selected or Not.
                var grid = $("#incidentList").data("kendoGrid");
                var checkboxes = $(grid.tbody).find("[type='checkbox']");
                if (checkboxes.length != 0) {
                    var checkedCheckboxes = $(grid.tbody).find("input:checked");
                    if (checkedCheckboxes.length == 0)
                        uof.ui.assignforms.viewModel.AssignModel.URN(null);
                }
                //End
                uof.ui.assignforms.viewModel.AssignModel.Assignment().length = 0;
                ko.cleanNode($("#divAssign").get(0));
                ko.applyBindings(uof.ui.assignforms.viewModel, $("#divAssign").get(0));
                uof.ui.assignforms.initiatePickers();
                uof.ui.assignforms.viewModel.AssignModel.Date(moment(new Date()).format("MM/DD/YYYY HH:mm:ss"));
                uof.ui.assignforms.getAssignFormsInfo();
                //uof.ui.assignforms.showModalPopup("divAssign")
                $("#divAssign").show();
                $("#divAssign").kendoWindow({
                    width: "85%",
                    title: "Assign Forms",
                    visible: false,
                    modal: true,
                    actions: [
                            "Pin",
                            "Close"
                    ],
                }).data("kendoWindow").center().open();
                //$("#divAssign").modal('show');
                //$("#divAssign").append('<div id="displayPA" class="modal-backdrop fade in"></div>');


            },
            cancelAssignForms: function () {
                uof.ui.assignforms.viewModel.AssignModel.Assignment([]);
                $("#divAssign").data("kendoWindow").close();
                uof.ui.assignforms.viewModel.AssignModel.URN('');
                $('.multi-selectpicker').selectpicker('refresh');
                //uof.ui.assignforms.hideModalPopup("divAssign")
                //$("#divAssign").modal('hide');
                //$("#divAssign").find('#displayPA').remove();
                //$("#divAssign").css("display", "none");
                //$(".modal-backdrop").removeClass("in");
            },
            // Generic method to open the popup page
            showModalPopup: function (IdOfdiv, intervalTime) {
                if (intervalTime == undefined)
                    intervalTime = 100;
                $('#' + IdOfdiv).show();
                $('#' + IdOfdiv).modal({
                    keyboard: true
                }).promise().done(function () {
                    setTimeout(function () {
                        if ($("#" + IdOfdiv).is(":visible"))
                            $("#" + IdOfdiv).focus();
                    }, intervalTime);
                });

            },

            hideModalPopup: function (IdOfdiv) {
                $('#' + IdOfdiv).modal('hide');
            },
            AssingFrms: function () {
                var self = this;
                //self.URN = ko.observable().extend({
                //    required: {
                //        params: true,
                //        message: IncidentConstants.Required

                //    },
                //});
                //self.Date = ko.observable().extend({
                //    required: {
                //        params: true,
                //        message: IncidentConstants.Required
                //    },
                //});
                self.EmployeeId = ko.observable().extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });
                self.FirstName = ko.observable().extend({
                    //required: {
                    //	params: true,
                    //	message: IncidentConstants.Required
                    //},
                });
                self.LastName = ko.observable().extend({
                    //required: {
                    //	params: true,
                    //	message: IncidentConstants.Required
                    //},
                });
                self.Rank = ko.observable().extend({
                    //required: {
                    //	params: true,
                    //	message: IncidentConstants.Required
                    //},
                });
                //self.instanceCnt = ko.observable(1);
                self.isIRExist = ko.observable(false);
                self.isIRwithCACSExist = ko.observable(false);
                //self.FormIds = ko.observableArray([]).extend({
                //    //required: {
                //    //    params: true,
                //    //    message: IncidentConstants.Required,
                //    //    onlyIf: function () {
                //    //        return self.isIRExist() === false;
                //    //    }
                //    //},
                //});
                self.FormIds = ko.observable();
                self.InvolvedEmployee = ko.observable(false).extend({
                    //required: {
                    //	params: true,
                    //	message: IncidentConstants.Required
                    //},
                });
                self.EmployeeWitness = ko.observable(false).extend({
                    //required: {
                    //	params: true,
                    //	message: IncidentConstants.Required
                    //},
                });
                self.ID = ko.observable();
                self.MailId = ko.observable();
                self.EmpRole = ko.observable();
                self.isDisabled = ko.observable(true);
                self.customRule = ko.observable().extend({
                    mustSelect: {
                        params: { CA: 21, CS: 18, IR: 16 },
                        message: 'Select CA or CS if IR selected',
                        onlyIf: function () {
                            return self.isIRwithCACSExist() == false;
                        }

                    },

                });

                self.customIRRule = ko.observable().extend({
                    Exist: {
                        params: { IR: 16 },
                        message: 'Form Already Selected',
                        onlyIf: function () {
                            return self.isIRExist() == true;
                        }
                    },


                });
                self.instanceCnt = ko.observable(1).extend({
                    Exist: {
                        params: { IR: 0 },
                        message: 'Should be 1 or more'
                    },
                });
                self.FormIds.subscribe(function (newValue) {

                    if (uof.ui.assignforms.isIncidentReportSelected($.trim(newValue))) {
                        self.customIRRule($.trim(newValue))
                        self.isIRExist(true);
                        $("#btnAddNew").attr("disabled", true);
                    }
                    else {
                        self.isIRExist(false);
                        $("#btnAddNew").attr("disabled", false);
                    }

                });
            },
            isIncidentReportSelected: function (formID) {
                var count = 0;
                $.each(uof.ui.assignforms.viewModel.AssignModel.Assignment(), function (index, item) {
                    if ($.inArray("16", item.FormIds()) != -1)
                        count++;
                });

                return count > 1 ? true : false;
            },
            isIncidentReportwithCAorCSSelected: function () {
                var isIRCACSExist = false;
                $.each(uof.ui.assignforms.viewModel.AssignModel.Assignment(), function (index, item) {
                    if (item.FormIds().indexOf("16") != -1) {
                        if (item.FormIds().indexOf("18") != -1) {
                            isIRCACSExist = true;
                            item.isIRwithCACSExist(true)
                        }
                        else if (item.FormIds().indexOf("21") != -1) {
                            isIRCACSExist = true;
                            item.isIRwithCACSExist(true)
                        }
                        else {
                            isIRCACSExist = false;
                            item.customRule(item.FormIds())
                            item.customRule.valueHasMutated();
                            item.isIRwithCACSExist(false)
                        }

                    }
                });
                return isIRCACSExist;
            },
            bindCustomValidation: function () {
                ko.validation.rules['Exist'] = {
                    validator: function (val, params) {
                        return String(val).indexOf(params.IR) != -1 ? false : true
                        // return val === String(params.IR) ? false:true;
                    },

                };

                ko.validation.rules['mustSelect'] = {
                    validator: function (val, params) {
                        var str = "";
                        return String(val).indexOf(params.IR) != -1 && (String(val).indexOf(params.CA) != -1 || String(val).indexOf(params.CS) != -1) ? false : true;
                    },
                };
                ko.validation.registerExtenders();

            },

            initiateBindings: function () {
                ko.validation.insertValidationMessage = function (element) {
                    var br = document.createElement("br");
                    element.appendChild(br);
                    var span = document.createElement('SPAN');
                    span.className = "warning-msg";
                    var inputGroups = $(element).closest(".date"); //This is for getting Date Fields
                    if (inputGroups.length > 0) {
                        // We're in an input-group so we place the message after
                        // the group rather than inside it in order to not break the design
                        $(span).insertAfter(inputGroups);
                    }
                    else {
                        // The default in knockout-validation
                        element.parentNode.insertBefore(span, element.nextSibling);
                    }
                    return span;
                };

            },

            bindMaskControl: function () {
                ko.bindingHandlers.inputmask =
                {
                    init: function (element, valueAccessor, allBindingsAccessor) {

                        var mask = valueAccessor();

                        var observable = mask.value;

                        if (ko.isObservable(observable)) {

                            $(element).on('focusout change', function () {

                                if ($(element).inputmask('isComplete')) {
                                    observable($(element).val());
                                } else {
                                    observable(null);
                                }

                            });
                        }

                        $(element).inputmask(mask);


                    },
                    update: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
                        var mask = valueAccessor();

                        var observable = mask.value;

                        if (ko.isObservable(observable)) {

                            var valuetoWrite = observable();

                            $(element).val(valuetoWrite);
                        }
                    }

                };
            },
            VerifyURN: function (URN) {
                if (URN != null && URN != '') {

                    $.prototype.showUofOverlay();
                    $.ajax(
                        {
                            url: window.location.uofAPIOrigin() + '/api/Incident/VerifyURN',
                            cache: false,
                            type: "GET",
                            data: { URN: URN },
                            dataType: 'json',
                            contentType: "application/json;charset=utf-8",
                            beforeSend: function myfunction() {

                            },
                            success: function (response) {
                                $.prototype.hideUofOverlay();
                                if (response.isExists) {
                                    $.when(showConfirmationWindow('URN was already created do u need to USE IT? ')).then(function (confirmed) {
                                        if (!confirmed) {
                                            ko.cleanNode($("#divAssign").get(0));
                                            ko.applyBindings(uof.ui.assignforms.viewModel, $("#divAssign").get(0));
                                            uof.ui.assignforms.initiatePickers();
                                            uof.ui.assignforms.viewModel.AssignModel.URN(null);
                                            $("#txtURN").focus();
                                            $("#divAssign").kendoWindow({
                                                width: "85%",
                                                title: "Assign Forms",
                                                visible: false,
                                                modal: true,
                                                actions: [
                                                        "Pin",
                                                        "Close"
                                                ],
                                            }).data("kendoWindow").center().open();
                                        }
                                        else {
                                            //Binding the Existing
                                            localStorage.setItem('selectedIncidentId', response.incidentId);
                                            uof.ui.assignforms.viewModel.AssignModel.Mode("Edit");
                                            uof.ui.assignforms.getAssignFormsInfo();
                                        }
                                    });
                                }
                            },
                            error: function (e) {
                                $.prototype.hideUofOverlay();
                                showAlert(e.responseText);
                            },
                        });
                }
            },
            getAllForm: function () {
                $.prototype.showUofOverlay();
                $.ajax(
                    {
                        url: window.location.uofAPIOrigin() + '/api/Settings/GetFormsName',
                        cache: false,
                        type: "GET",
                        dataType: 'json',
                        contentType: "application/json;charset=utf-8",
                        beforeSend: function myfunction() {

                        },
                        success: function (formData) {
                            if (formData != null) {
                                var forms = [];
                                forms = $.map($.grep(formData, function (d) {
                                    return d.IsMenuItem && (d.ParentId == 1 || d.ParentId == 4 || d.ParentId == 5 || d.ParentId == 6 || d.ParentId == 7) && d.FormCode != "WC_UofRNotice" && d.FormCode != "UC_UofRNotice";
                                }), function (d) {
                                    uof.ui.assignforms.viewModel.FormNames.push({ Name: d.FormName, Code: String(d.FormId) });
                                });
                            }
                            $.prototype.hideUofOverlay();
                        },
                        error: function (e) {
                            uof.ui.assignforms.viewModel.AssignModel.Mode("Add");
                            $.prototype.hideUofOverlay();
                            showAlert(e.responseText);
                        },
                    });
            },

            getAssignFormsInfo: function () {
                var isExisting = false;
                if (UoFParams.IncidentId > 0)
                    isExisting = true;
                var indId = UoFParams.IncidentId;
                if (localStorage.getItem("selectedIncidentId") != null)
                    indId = parseInt(localStorage.getItem("selectedIncidentId"))
                if (indId != null && indId > 0) {
                    $.ajax(
                          {
                              url: window.location.uofAPIOrigin() + '/api/Incident/GetIncidentFormAssignInfo',
                              cache: false,
                              type: "GET",
                              dataType: 'json',
                              data: { incidentId: parseInt(indId) },
                              contentType: "application/json;charset=utf-8",
                              beforeSend: function myfunction() {

                              },
                              success: function (result) {
                                  if (result != null) {
                                      uof.ui.assignforms.AssignedDBSource = result;
                                      uof.ui.assignforms.viewModel.AssignModel = ko.mapping.fromJS(result, ko.mapping.toJS(uof.ui.assignforms.viewModel.AssignModel));
                                      ;
                                      uof.ui.assignforms.viewModel.AssignModel.Assignment.valueHasMutated();
                                      _.each(uof.ui.assignforms.viewModel.AssignModel.Assignment(), function (item) {
                                          if (item.FormIds() != null)
                                              item.FormIds = ko.observableArray(item.FormIds().split(','));
                                          $("#txtEmpName" + item.ID()).attr("disabled", "disabled");
                                          item.isDisabled = ko.observable(false);
                                      });

                                      uof.ui.assignforms.viewModel.AssignModel.Date(moment(uof.ui.assignforms.viewModel.AssignModel.Date()).format("MM/DD/YYYY HH:mm:ss"));
                                      uof.ui.assignforms.viewModel.AssignModel.Mode("Edit");
                                      ko.cleanNode($("#divAssign").get(0));
                                      ko.applyBindings(uof.ui.assignforms.viewModel, $("#divAssign").get(0));
                                      $('.multi-selectpicker').selectpicker('refresh');
                                      $('#IncidentDT').datetimepicker({ format: 'MM/DD/YYYY HH:mm', defaultDate: 'now' }).on('dp.change', function (ev) {
                                          var newDate = null;
                                          if (ev.date != null)
                                              newDate = moment(ev.date).format("MM/DD/YYYY HH:mm:ss");
                                          uof.ui.assignforms.viewModel.AssignModel.Date(newDate);
                                      });

                                      $("#divAssign").kendoWindow({
                                          width: "85%",
                                          title: "Assign Forms",
                                          visible: false,
                                          modal: true,
                                          actions: [
                                                  "Pin",
                                                  "Close"
                                          ],
                                      }).data("kendoWindow").center().open();
                                  }
                                  $.prototype.hideUofOverlay();
                              },
                              error: function (e) {
                                  $.prototype.hideUofOverlay();
                                  showAlert(e.responseText);
                              },
                          });
                }
            },

            saveAssignFormForNewUrnOnEdit: function () {
                uof.ui.assignforms.viewModel.AssignModel.LoggedRole('');
                uof.ui.assignforms.viewModel.AssignModel.LoggedId(0);
                uof.ui.assignforms.viewModel.AssignModel.IncidentId(0);
                uof.ui.assignforms.viewModel.AssignModel.URN(null);
                uof.ui.assignforms.viewModel.AssignModel.Date(null);
                uof.ui.assignforms.viewModel.AssignModel.Assignment([]);
                uof.ui.assignforms.viewModel.AssignModel.Assignment.valueHasMutated();
                uof.ui.assignforms.viewModel.AssignModel.Mode('Add');
                uof.ui.assignforms.validateControl();
            },

            buildModel: function (data) {

                $.each(ko.mapping.toJS(data), function (index, value) {
                    if (uof.ui.assignforms.viewModel.FormModel().length == 0) {
                        uof.ui.assignforms.viewModel.FormModel.push({
                            EmployeeId: value.EmployeeId,
                            LastName: value.LastName,
                            FirstName: value.FirstName,
                            Rank: value.Rank,
                            EmployeeWitness: value.EmployeeWitness,
                            InvolvedEmployee: value.InvolvedEmployee,
                            instanceCnt: value.instanceCnt,
                            IncidentId: value.IncidentId,
                        });
                    }
                    else {
                        $.each(uof.ui.assignforms.viewModel.FormModel(), function (newIndex, newVal) {
                            if (newVal.EmployeeId() == value.EmployeeId()) {

                            }
                            else {
                                uof.ui.assignforms.viewModel.FormModel.push({
                                    EmployeeId: value.EmployeeId,
                                    LastName: value.LastName,
                                    FirstName: value.FirstName,
                                    Rank: value.Rank,
                                    EmployeeWitness: value.EmployeeWitness,
                                    InvolvedEmployee: value.InvolvedEmployee,
                                    instanceCnt: value.instanceCnt,
                                    IncidentId: value.IncidentId,
                                });
                            }
                        });
                    }
                });
            },

            saveAssignForms: function () {
                if (uof.ui.assignforms.validateFields()) {
                    var temp = uof.ui.assignforms.viewModel.AssignModel.Assignment();
                    $.each(uof.ui.assignforms.viewModel.AssignModel.Assignment(), function (index, value) {
                        value.FormIds(value.FormIds().toString());
                    });
                    uof.ui.assignforms.viewModel.AssignModel.DeletedUsers = uof.ui.assignforms.viewModel.DeletedUser();
                    var mappedData = ko.mapping.toJS(uof.ui.assignforms.viewModel.AssignModel);
                    mappedData.LoggedId = UoFParams.userId;
                    mappedData.LoggedRole = UoFParams.userRole;
                    uof.ui.assignforms.viewModel.AssignModel.Assignment(temp); //Reassigning 
                    $.prototype.showUofOverlay();
                    $.ajax(
                          {
                              url: window.location.uofAPIOrigin() + '/api/Incident/AssingIncidentForms',
                              cache: false,
                              type: "POST",
                              dataType: 'json',
                              data: JSON.stringify(mappedData),
                              contentType: "application/json;charset=utf-8",
                              beforeSend: function myfunction() {

                              },
                              success: function (result) {
                                  uof.ui.incident.detail.SelectedPageNumber = 0;
                                  $.prototype.hideUofOverlay();
                                  showAlert(result.Message);
                                  uof.ui.assignforms.cancelAssignForms();
                                  localStorage.setItem("selectedIncidentId", 0);
                                  UoFParams.IncidentId = 0;
                                  uof.ui.assignforms.viewModel.AssignModel.Mode('Add');
                                  uof.ui.assignforms.viewModel.AssignModel.URN(null);
                                  uof.ui.assignforms.viewModel.AssignModel.Date(null);
                                  uof.ui.incident.detail.updateMenuURL();
                                  $("#incidentList").data('kendoGrid').destroy();
                                  uof.ui.incident.detail.bindIncidentDetails();
                              },
                              error: function (e) {
                                  $.prototype.hideUofOverlay();
                                  showAlert(e.responseText);
                              },
                          });
                }
            },
            validateControl: function () {
                //Validate the controls on Add and duplicate popup
                uof.ui.assignforms.viewModel.AssignModel.URN.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    }

                });

                //For date
                //uof.ui.assignforms.viewModel.AssignModel.Date.extend({
                //    required: {
                //        params: true,
                //        message: IncidentConstants.Required
                //    }
                //});
            },
            validateFields: function () {
                result = ko.validation.group(uof.ui.assignforms.viewModel.AssignModel, { deep: true });
                if (result().length > 0) {
                    result.showAllMessages();
                    return false;
                }
                return true;
            },

        }
    }();
}