﻿var uof = uof || {};
uof.ui = uof.ui || {};
uof.ui.incident = uof.ui.incident || {};
if (uof.ui.incident) {
    uof.ui.IncidentInfo = function () {
        return {
            init: function (args) {
                this.parameters = args;
            },
            load: function () 
            {
                $("a").on("click", function (e) {

                    // Id of the element that was clicked
                    var elementId = $(this).attr("id");

                    if (elementId == "IncidentInfo")
                        uof.ui.incident.detail.load();
                    else if (elementId == "InvolvedEmpInfo")
                        uof.ui.InvolvedEmployee.load();
                    else if (elementId == "suspectInformation")
                        uof.ui.Suspects.load();
                    else if (elementId == "EmpWitnessInfo")
                        uof.ui.EmployeeWitness.empWitnessload();
                    else if (elementId == "NonEmpWitnessInfo")
                        uof.ui.Witness.nonEmpWitnessload();
                    else if (elementId == "StatDataInfo")
                        uof.ui.incident.statisticaldata.load();
                    else if (elementId == "DeputyInfo")
                        uof.ui.incident.deputy.load();
                    else if (elementId == "CanineInfo")
                        uof.ui.Canine.load();

                });
            },
        }
    }();
}