﻿var uof = uof || {};
uof.ui = uof.ui || {};
uof.ui.incident = uof.ui.incident || {};
if (uof.ui.incident) {
    uof.ui.formSettings = function () {
        return {
            viewModel: {
                cachedPermissionsArray: [],
                roleType: ko.observableArray([]),
                formsName: ko.observableArray([]),
                dbFormsName: [],
                selectedRoleId: ko.observable(""),
                selectedCurrentRoleId: ko.observable(0),
                selectedRoleName: ko.observable(),
                db_roleType: [],
                db_formsNameType: [],
                db_frmPermission: [],
                refreshGrid: function (selectedData) {
                    uof.ui.formSettings.cacheFormPermission(selectedData);
                },
                updateFormChecked: function (data) {
                    uof.ui.formSettings.updateFormChecked(data);
                },
                cancelFormSetting: function () {
                    uof.ui.formSettings.cancelFormSetting();
                },
                childFormBind: function () {
                    uof.ui.formSettings.childFormBind();
                },
                RoleModel: {
                    RoleCode: ko.observable(),
                    RoleName: ko.observable(),
                    Description: ko.observable(),
                    Rank: ko.observable(),
                    //Readonly: ko.observable(false),
                },

            },


            load: function () {
                //  uof.ui.formSettings.treeFormNameBinding();
                //Get the form name from database
                uof.ui.formSettings.getFormsName();
                //Bind the viewmodel to DOM object
                uof.ui.formSettings.getRoles();
                uof.ui.formSettings.viewModel.selectionCache = [];
                uof.ui.formSettings.viewModel.cachedPermissionsArray = [];

                ko.cleanNode($("#roleTypesDiv").get(0));
                ko.applyBindings(uof.ui.formSettings.viewModel, $("#roleTypesDiv").get(0));
                ko.cleanNode($("#formTypesDiv").get(0));
                ko.applyBindings(uof.ui.formSettings.viewModel, $("#formTypesDiv").get(0));

                ko.cleanNode($("#divAddRole").get(0));
                ko.applyBindings(uof.ui.formSettings.viewModel, $("#divAddRole").get(0));

            },

            cacheFormPermission: function (selectedData) {
                uof.ui.formSettings.viewModel.selectedRoleName(selectedData.RoleName);
                uof.ui.formSettings.viewModel.selectedCurrentRoleId(selectedData.RoleId);
                var checkedNodes = [],
                    treeView = $("#treeview").data("kendoTreeView");

                uof.ui.formSettings.checkedNodeIds(treeView.dataSource.view(), checkedNodes);

                if (uof.ui.formSettings.viewModel.selectedRoleId() == "") {
                    uof.ui.formSettings.viewModel.selectedRoleId(selectedData.RoleId);
                }

                if (checkedNodes.length > 0) {
                    var isAlreadyExist = _.find(uof.ui.formSettings.viewModel.cachedPermissionsArray, function (item) {
                        return item.Key == uof.ui.formSettings.viewModel.selectedRoleId();
                    });

                    if (isAlreadyExist) {
                        uof.ui.formSettings.removeFromArray(uof.ui.formSettings.viewModel.selectedRoleId());
                    }

                    _.each(checkedNodes, function (item) {
                        uof.ui.formSettings.viewModel.cachedPermissionsArray.push({ Key: uof.ui.formSettings.viewModel.selectedRoleId(), Value: [item] });
                    });
                };

                isAlreadyExist = _.filter(uof.ui.formSettings.viewModel.cachedPermissionsArray, function (item) {
                    if (item.Key == selectedData.RoleId) {
                        return item;
                    }
                });

                //returns the nodes
                var nodes = treeView.dataSource.view();
                for (var i = 0; i < nodes.length; i++) {
                    var node = nodes[i];
                    if (isAlreadyExist) {
                        if (node.items.length > 0) {
                            _.each(node.items, function (cNode) {
                                var isExist = _.find(isAlreadyExist, function (itemchild) {
                                    if(itemchild.Value[0].FormId == cNode.id)
                                    {
                                        return itemchild;
                                    }
                                });

                                if (isExist) {
                                    //sets the child node check property to true
                                    cNode.set("checked", true);
                                    $('[data-uid=' + cNode.uid + ']').find('#viewonly-' + cNode.id).prop('checked', isExist.Value[0].isViewOnly);
                                }
                                else {
                                    cNode.set("checked", false);
                                    $('[data-uid=' + cNode.uid + ']').find('#viewonly-' + cNode.id).prop('checked', false);
                                }
                            });
                        }
                        else {
                            var isExist = _.find(isAlreadyExist, function (itemchild) {
                                return itemchild.Value[0].FormId == node.id;
                            });
                            if (isExist)
                                //sets the parent node check property to true
                                node.set("checked", true);
                            else
                                node.set("checked", false);
                        }
                    }
                    else {
                        //All should be blank
                        node.set("checked", false);
                    }

                };

                uof.ui.formSettings.viewModel.selectedRoleId(selectedData.RoleId);
            },

            removeFromArray: function (filterValue) {
                uof.ui.formSettings.viewModel.cachedPermissionsArray.splice(
                    _.findIndex(uof.ui.formSettings.viewModel.cachedPermissionsArray, function (item) {
                        return item.Key == filterValue;
                    }), 1);
                var isExist = _.find(uof.ui.formSettings.viewModel.cachedPermissionsArray, function (arrItem) {
                    return arrItem.Key == filterValue;
                });

                if (isExist)
                    uof.ui.formSettings.removeFromArray(filterValue);
            },

            getFormsName: function () {
                $.prototype.showProgressBar("divForProgressBar");
                $.ajax(
                {
                    url: window.location.uofAPIOrigin() + '/api/Settings/GetFormsName',
                    cache: false,
                    type: "GET",
                    dataType: 'json',
                    contentType: "application/json;charset=utf-8",
                    success: function (frmsName) {
                        frmsName = _.filter(frmsName, function (item) {
                            return item.IsSettingItem;
                        });
                        uof.ui.formSettings.viewModel.formsName([]);
                        uof.ui.formSettings.viewModel.formsName(_.filter(frmsName, function (item) {
                            return item.ParentId == 0;
                        }));
                        uof.ui.formSettings.viewModel.formsName.valueHasMutated();
                        uof.ui.formSettings.viewModel.dbFormsName = [];
                        uof.ui.formSettings.viewModel.dbFormsName = uof.ui.formSettings.viewModel.dbFormsName.concat(frmsName);
                        $.prototype.hideProgressBar("divForProgressBar");
                        uof.ui.formSettings.getFormPermission();
                        uof.ui.formSettings.treeFormNameBinding(frmsName);
                    },
                    error: function (e) {
                        $.prototype.hideProgressBar("divForProgressBar");
                    },
                });
            },

            getRoles: function () {
                $.prototype.showProgressBar("divForProgressBar");
                $.ajax(
                {
                    url: window.location.uofAPIOrigin() + '/api/Settings/GetRoles',
                    cache: false,
                    type: "GET",
                    dataType: 'json',
                    contentType: "application/json;charset=utf-8",
                    success: function (roleTypes) {
                        uof.ui.formSettings.viewModel.roleType([]);
                        uof.ui.formSettings.viewModel.roleType(roleTypes);
                        uof.ui.formSettings.viewModel.roleType.valueHasMutated();
                        $.prototype.hideProgressBar("divForProgressBar");
                    },
                    error: function (e) {
                        $.prototype.hideProgressBar("divForProgressBar");
                    },
                });
            },

            getFormPermission: function () {
                $.prototype.showProgressBar("divForProgressBar");
                $.ajax(
                {
                    url: window.location.uofAPIOrigin() + '/api/Settings/GetFormPermission',
                    cache: false,
                    type: "GET",
                    dataType: 'json',
                    contentType: "application/json;charset=utf-8",
                    success: function (formPermission) {
                        uof.ui.formSettings.viewModel.db_frmPermission = ([]);
                        uof.ui.formSettings.viewModel.db_frmPermission = formPermission;
                        if (uof.ui.formSettings.viewModel.db_frmPermission.length > 0) {

                            uof.ui.formSettings.viewModel.cachedPermissionsArray = [];
                            _.each(uof.ui.formSettings.viewModel.db_frmPermission, function (item) {
                                var frmInfo = _.find(uof.ui.formSettings.viewModel.dbFormsName, function (frmItem) {
                                    return frmItem.FormId == item.FormId;
                                });


                                if (frmInfo) {
                                    uof.ui.formSettings.viewModel.cachedPermissionsArray.push({
                                        Key: item.RoleId,
                                        Value: [{
                                            FormId: item.FormId,
                                            FormName: frmInfo.FormName,
                                            FormCode: frmInfo.FormCode,
                                            Description: frmInfo.Description,
                                            isFormChecked: true,
                                            isViewOnly: item.IsViewOnly == undefined ? false : item.IsViewOnly
                                        }],
                                    });
                                }

                            });
                        }

                        $.prototype.hideProgressBar("divForProgressBar");
                    },
                    error: function (e) {
                        $.prototype.hideProgressBar("divForProgressBar");
                    },
                });
            },

            saveFormPermission: function () {
                if ((uof.ui.formSettings.viewModel.selectedRoleName() == undefined) || (uof.ui.formSettings.viewModel.selectedRoleName() == "")) return false;
                uof.ui.formSettings.viewModel.db_frmPermission = [];


                var checkedNodes = [], treeView = $("#treeview").data("kendoTreeView");

                uof.ui.formSettings.checkedNodeIds(treeView.dataSource.view(), checkedNodes);

                if (checkedNodes.length > 0) {
                    var isAlreadyExist = _.find(uof.ui.formSettings.viewModel.cachedPermissionsArray, function (item) {
                        return item.Key == uof.ui.formSettings.viewModel.selectedRoleId();
                    });

                    if (isAlreadyExist) {
                        uof.ui.formSettings.removeFromArray(uof.ui.formSettings.viewModel.selectedRoleId());
                    }


                    _.each(checkedNodes, function (item) {
                        uof.ui.formSettings.viewModel.cachedPermissionsArray.push({ Key: uof.ui.formSettings.viewModel.selectedRoleId(), Value: [item] });
                    });

                } else {
                    uof.ui.formSettings.removeFromArray(uof.ui.formSettings.viewModel.selectedRoleId());
                }

                _.each(uof.ui.formSettings.viewModel.cachedPermissionsArray, function (item) {
                    if (item.Value.length > 0)
                        uof.ui.formSettings.viewModel.db_frmPermission.push({
                            RoleId: item.Key,
                            FormId: item.Value[0].FormId,
                            IsViewOnly: item.Value[0].isViewOnly,
                        });
                });

                if (uof.ui.formSettings.viewModel.db_frmPermission.length > 0) {
                    $.prototype.showProgressBar("divForProgressBar");
                    var objformPermission = ko.mapping.toJSON(uof.ui.formSettings.viewModel.db_frmPermission);
                    $.ajax(
                    {
                        url: window.location.uofAPIOrigin() + '/api/Settings/SaveFormPermissions',
                        cache: false,
                        data: objformPermission,
                        type: "POST",
                        dataType: 'json',
                        contentType: "application/json;charset=utf-8",
                        success: function (result) {
                            showAlert("Role to Forms mapping done successfully");
                            $.prototype.hideProgressBar("divForProgressBar");
                        },
                        error: function (e) {
                            $.prototype.hideProgressBar("divForProgressBar");
                        },
                    });
                }
            },

            updateFormChecked: function (data) {
                if (data.isViewOnly()) { data.isFormChecked(true); }
            },

            cancelFormSetting: function () {

            },

            childFormBind: function (data) {
                return _.filter(uof.ui.formSettings.viewModel.dbFormsName, function (item) {
                    item.ParentId == data.FormId();
                });
            },


            treeFormNameBinding: function (frmsName) {
                var dbSource = [];
                var parentFrmName = _.filter(frmsName, function (pform) {
                    return pform.ParentId == 0;
                });

                var clsItems = {
                    id: 0, text: "", expanded: true, spriteCssClass: "rootfolder", items: []
                };

                _.each(parentFrmName, function (fName) {
                    var filterChildFrm = _.filter(frmsName, function (pform) {
                        return pform.ParentId == fName.FormId;
                    });
                    var childFrm = [];
                    _.each(filterChildFrm, function (cForm) {
                        childFrm.push({
                            id: cForm.FormId,
                            text: cForm.FormName,
                        });
                    });

                    dbSource.push({
                        id: fName.FormId,
                        text: fName.FormName,
                        items: childFrm,
                        expanded: true, spriteCssClass: "rootfolder",
                    });
                });

                $("#treeview").kendoTreeView({
                    checkboxes: {
                        checkChildren: true
                    },
                    check: uof.ui.formSettings.onCheck,
                    dataSource: dbSource
                });

                var treeView = $("#treeview").data("kendoTreeView");
                
                $.each(treeView.dataSource.view(), function (index, item) {
                    $.each(item.items, function (i, child) {
                        //$("#span-" + child.id).remove();
                        $("[data-uid=" + child.uid + "] div")[0].innerHTML = $("[data-uid=" + child.uid + "] div")[0].innerHTML + '<span><input id=viewonly-' + child.id + ' type="checkbox" /> ViewOnly</span>';
                    });
                });
            },

            // function that gathers IDs of checked nodes
            checkedNodeIds: function (nodes, checkedNodes) {
                for (var i = 0; i < nodes.length; i++) {
                    if (nodes[i].checked) {
                        var isViewCheckd = $('#viewonly-' + nodes[i].id).is(':checked');
                        checkedNodes.push({ FormId: nodes[i].id, isViewOnly: isViewCheckd });
                    }

                    if (nodes[i].hasChildren) {
                        uof.ui.formSettings.checkedNodeIds(nodes[i].children.view(), checkedNodes);
                    }
                }
            },

            // show checked node IDs on datasource change
            onCheck: function () {
                var checkedNodes = [],
                    treeView = $("#treeview").data("kendoTreeView"),
                    message;

                uof.ui.formSettings.checkedNodeIds(treeView.dataSource.view(), checkedNodes);

                if (checkedNodes.length > 0) {
                    message = "IDs of checked nodes: " + checkedNodes.join(",");
                } else {
                    message = "No nodes checked.";
                }

                $("#result").html(message);
            },

            //Add Role
            displayRoleSection: function () {
                uof.ui.formSettings.validateRoleControls();
                $("#divSettings").hide();
                $("#divAddRole").show();
                
            },
            cancelRole: function () {
                $("#divSettings").show();
                $("#divAddRole").hide();
            },
            AddRole: function () {
                if (uof.ui.formSettings.validateRoleInc()) {
                    var roleData = ko.mapping.toJSON(uof.ui.formSettings.viewModel.RoleModel);
                    $.ajax(
                        {
                            url: window.location.uofAPIOrigin() + '/api/Settings/SaveRole',
                            cache: false,
                            type: "POST",
                            data: roleData,
                            dataType: 'json',
                            contentType: "application/json;charset=utf-8",
                            success: function (data) {
                                showAlert("Role added successfully");
                                uof.ui.formSettings.getRoles();
                                $.prototype.hideUofOverlay();
                            },
                            error: function (e) {
                                $.prototype.hideUofOverlay();
                                showAlert(e.responseText);
                            },
                        });
                }
            },
            validateRoleControls: function () {
                uof.ui.formSettings.viewModel.RoleModel.RoleCode.extend({
                    required: {
                        params: true,
                        message: "Required"
                    },
                });
                uof.ui.formSettings.viewModel.RoleModel.RoleName.extend({
                    required: {
                        params: true,
                        message: "Required"
                    },
                });
                uof.ui.formSettings.viewModel.RoleModel.Rank.extend({
                    required: {
                        params: true,
                        message: "Required"
                    },
                });
            },
            validateRoleInc: function () {
                result = ko.validation.group(uof.ui.formSettings.viewModel.RoleModel, { deep: true });
                if ((result().length > 0)) {
                    uof.ui.formSettings.viewModel.RoleModel.RoleCode.valueHasMutated();
                    uof.ui.formSettings.viewModel.RoleModel.RoleName.valueHasMutated();
                    uof.ui.formSettings.viewModel.RoleModel.Rank.valueHasMutated();
                    result.showAllMessages(true);
                    return false;
                }
                return true;


            },
        }
    }();
}
