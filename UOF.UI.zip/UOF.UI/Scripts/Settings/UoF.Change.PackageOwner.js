﻿var uof = uof || {};
uof.ui = uof.ui || {};
uof.ui.ChangePackageOwner = uof.ui.ChangePackageOwner || {};
if (uof.ui.ChangePackageOwner) {
    uof.ui.ChangePackageOwner = function () {
        return {
            SelectedPageNumber: 0,
            source:'',
            viewModel: {
                CP: {

                    URN: ko.observable(),
                    IncidentId: ko.observable(),
                    Rank: ko.observable(),
                    FormId: ko.observable(),

                },
                AssignModel: {
                    ExistingEmpId: ko.observable(),
                    IncidentId: ko.observable(),
                    UserTypeId: ko.observable(),
                    EID: ko.observable(),
                    ELName: ko.observable(),
                    EFName: ko.observable(),
                    EMName: ko.observable(),
                    ERank: ko.observable(),
                    EmailId: ko.observable(),
                    ERankAbrv: ko.observable(),
                },
                getEmployeeDetails: function (empId, optionCriteria) {
                    if (empId != undefined)
                        uof.ui.ChangePackageOwner.getEmployeeDetails(empId, optionCriteria);
                },
            },
            bindMaskControl: function () {
                ko.bindingHandlers.inputmask =
                {
                    init: function (element, valueAccessor, allBindingsAccessor) {

                        var mask = valueAccessor();

                        var observable = mask.value;

                        if (ko.isObservable(observable)) {

                            $(element).on('focusout change', function () {

                                if ($(element).inputmask('isComplete')) {
                                    observable($(element).val());
                                } else {
                                    observable(null);
                                }

                            });
                        }

                        $(element).inputmask(mask);


                    },
                    update: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
                        var mask = valueAccessor();

                        var observable = mask.value;

                        if (ko.isObservable(observable)) {

                            var valuetoWrite = observable();

                            $(element).val(valuetoWrite);
                        }
                    }

                };
            },
            load: function () {

                uof.ui.ChangePackageOwner.bindMaskControl();
                uof.ui.ChangePackageOwner.validateControls();
                ko.cleanNode($("#divChangePackage").get(0));
                ko.applyBindings(uof.ui.ChangePackageOwner.viewModel, $("#divChangePackage").get(0));

                //binding Incident popup page
                ko.cleanNode($("#divAssignIncident").get(0));
                ko.applyBindings(uof.ui.ChangePackageOwner.viewModel, $("#divAssignIncident").get(0));

            },

            validateControls: function () {
                uof.ui.ChangePackageOwner.viewModel.CP.URN.extend({
                    required: {
                        params: true,
                        message: 'Required'
                    },
                });
            },
            getEmployeeDetails: function (empId, optionCriteria) {

                // Search based on emp id
                $.prototype.showProgressBar("emplSection");
                if (empId != "") {


                    jQuery.ajax({
                        type: "GET",
                        url: EmployeeAPIUrl() + empId,
                        dataType: "json",
                        cache: false,
                        crossDomain: true,
                        processData: true,
                        success: function (empData) {
                            if (optionCriteria == 'WC') {
                                uof.ui.ChangePackageOwner.viewModel.AssignModel.EFName(empData.FirstName);
                                uof.ui.ChangePackageOwner.viewModel.AssignModel.ELName(empData.LastName);
                                uof.ui.ChangePackageOwner.viewModel.AssignModel.ERankAbrv(empData.RankAbrev.toUpperCase());
                                uof.ui.ChangePackageOwner.viewModel.AssignModel.ERank(empData.Rank);
                                uof.ui.ChangePackageOwner.viewModel.AssignModel.EmailId(empData.EmailAddress);
                            }

                            $.prototype.hideProgressBar("emplSection");
                        },
                        error: function (XMLHttpRequest, textStatus, errorThrown) {
                            $.prototype.hideProgressBar("emplSection");
                            showAlert("error");
                        }
                    });
                }
            },
            getData: function (URN) {
                $.prototype.showUofOverlay();
                var dlAjaxOption =
                    {
                        url: window.location.uofAPIOrigin() + '/api/Settings/GetPackageInfo',
                        cache: false,
                        data: { URN: URN },
                        type: "GET",
                        dataType: 'json',
                        contentType: "application/json;charset=utf-8",
                        success: function (incidentData) {
                            $.prototype.hideUofOverlay();
                            var geoDataSource = new kendo.data.DataSource({
                                data: incidentData,
                                pageSize: 20
                            });
                            geoDataSource.fetch(function () {
                                geoDataSource.page(parseInt(uof.ui.ChangePackageOwner.SelectedPageNumber) > 0 ? parseInt(uof.ui.ChangePackageOwner.SelectedPageNumber) : 1);
                            });
                            //setting all Org Data to kendo
                            $("#formData").kendoGrid({
                                dataSource: geoDataSource,
                                height: 200,
                                resizable: true,
                                sortable: true,
                                columnMenu: true,
                                dataBound: uof.ui.ChangePackageOwner.OnMainGridDataBound,
                                pageable: {
                                    refresh: false,
                                    pageSizes: true,
                                    pageSizes: [20, 40, 100],
                                    buttonCount: 5,
                                    messages: {
                                        empty: "No Forms to display",
                                        itemsPerPage: "Forms Per Page",
                                    },
                                },
                                columns: [
                                             {
                                                 field: "URN",
                                                 width: 120,
                                                 template: '<span class="cellTooltip" title="#=URN#">#=URN#</span>',
                                                 headerTemplate: '<span> URN </span>',
                                             },
                                               {
                                                   field: "WCID",
                                                   width: 90,
                                                   template: '<span class="cellTooltip" title="#=WCID#">#=WCID#</span>',
                                                   headerTemplate: '<span> WC ID </span>',
                                               },
                                                {
                                                    field: "WCStatus",
                                                    width: 90,
                                                    template: $("#openAssignPage").html(),
                                                    headerTemplate: '<span> WC Status </span>',
                                                },
                                                 {
                                                     field: "UCID",
                                                     width: 90,
                                                     template: '<span class="cellTooltip" title="#=UCID#">#=UCID#</span>',
                                                     headerTemplate: '<span> UC </span>',
                                                 },
                                                  {
                                                      field: "UCStatus",
                                                      width: 90,
                                                      template: $("#openAssignPage").html(),
                                                      headerTemplate: '<span> UC Status </span>',
                                                  },
                                                {
                                                    field: "CFRCID",
                                                    width: 90,
                                                    template: '<span class="cellTooltip" title="#=CFRCID#">#=CFRCID#</span>',
                                                    headerTemplate: '<span> CFRC ID </span>',
                                                },
                                                    {
                                                        field: "CFRCStatus",
                                                        width: 90,
                                                        template: $("#openAssignPage").html(),
                                                        headerTemplate: '<span> CFRC Status </span>',
                                                    },
                                                    {
                                                        field: "CMID",
                                                        width: 90,
                                                        template: '<span class="cellTooltip" title="#=CMID#">#=CMID#</span>',
                                                        headerTemplate: '<span> CM ID </span>',
                                                    },
                                                        {
                                                            field: "CMStatus",
                                                            width: 90,
                                                            template: '<span class="cellTooltip" title="#=CMStatus#">#=CMStatus#</span>',
                                                            headerTemplate: '<span> CM Status </span>',
                                                        },
                                                        {
                                                            field: "DCID",
                                                            width: 90,
                                                            template: '<span class="cellTooltip" title="#=DCID#">#=DCID#</span>',
                                                            headerTemplate: '<span> DC ID </span>',
                                                        },
                                                        {
                                                            field: "DCStatus",
                                                            width: 90,
                                                            template: '<span class="cellTooltip" title="#=DCStatus#">#=DCStatus#</span>',
                                                            headerTemplate: '<span> DC Status </span>',
                                                        },



                                ],
                                change: function (e) {
                                    var model = this.dataItem(this.select());
                                }

                            }).data().kendoGrid;

                        },
                        error: function (e) {
                            $.prototype.hideUofOverlay();
                            showAlert(e.responseText);
                        }

                    };
                // Call ajax
                var ajaxOptions = $.extend({}, 'GET', dlAjaxOption);
                $.ajax(ajaxOptions);
            },
            OnMainGridDataBound: function (e) {
                $("#formData tbody").find("tr").attr("tabindex", "0");
                var grid = $("#formData").data("kendoGrid");

                $(grid.tbody).find('tr').each(function (e) {
                    var view = grid.dataSource.view();
                    var model = view[e];
                    if (model != null) {
                        if (model.WCStatus == "Pending")
                            $(this).find('td:eq(2)').outerHTML = "<a style='cursor:pointer,textDecoration:'',pointer-events: auto,color: #8564a6' onclick='uof.ui.ChangePackageOwner.openAssignPopup(" + model.IncidentId + ", " + model.WCID + ", 'WC');'>Pending</a>";
                        else
                            $(this).find('td:eq(2)').text(model.WCStatus);
                        if (model.UCStatus == "Pending")
                            $(this).find('td:eq(4)').outerHTML = "<a style='cursor:pointer,textDecoration:'',pointer-events: auto,color: #8564a6' onclick='uof.ui.ChangePackageOwner.openAssignPopup(" + model.IncidentId + ", " + model.UCID + ", 'UC');'>Pending</a>";
                        else
                            $(this).find('td:eq(4)').text(model.UCStatus);
                        if (model.CFRCStatus == "Pending")
                            $(this).find('td:eq(6)').outerHTML = "<a style='cursor:pointer,textDecoration:'',pointer-events: auto,color: #8564a6' onclick='uof.ui.ChangePackageOwner.openAssignPopup(" + model.IncidentId + ", " + model.CFRCID + ", 'CFRC');'>Pending</a>";
                        else
                            $(this).find('td:eq(6)').text(model.CFRCStatus);
                        if (model.CMStatus == "Pending")
                            $(this).find('td:eq(8)').outerHTML = "<a style='cursor:pointer,textDecoration:'',pointer-events: auto,color: #8564a6' onclick='uof.ui.ChangePackageOwner.openAssignPopup(" + model.IncidentId + ", " + model.CMID + ", 'CM');'>Pending</a>";
                        else
                            $(this).find('td:eq(8)').text(model.CMStatus);

                    }
                });

                if (grid.dataSource.total() == 0) {
                    var colCount = grid.columns.length;
                    $(e.sender.wrapper)
                        .find('tbody')
                        .append('<tr class="kendo-data-row"><td colspan="' + colCount + '" style="text-align:center; padding-top:10px; cursor:text;">No Record Found</td></tr>');
                }
            },
            resetData: function () {
                uof.ui.ChangePackageOwner.viewModel.Assign.EmpEmailId(null);
                uof.ui.ChangePackageOwner.viewModel.Assign.EmpID(null);
                uof.ui.ChangePackageOwner.viewModel.Assign.EmpFName(null);
                uof.ui.ChangePackageOwner.viewModel.Assign.EmpLName(null);
                uof.ui.ChangePackageOwner.viewModel.Assign.EmpRank(null);
            },
            openAssignPopup: function (incidentId, ID, model, UCID) {
                uof.ui.ChangePackageOwner.viewModel.AssignModel.ExistingEmpId(ID);
                uof.ui.ChangePackageOwner.viewModel.AssignModel.IncidentId(incidentId);
                uof.ui.ChangePackageOwner.source = model;
                var title = '';
                if (model == 'WC')
                    title = "Watch Commander";
                if (model == 'UC')
                    title = "Unit Commander";
                if (model == 'CFRCStatus')
                    title = "Commander";
                if (model == 'CM')
                    title = "Commander";
                //if (model == "CFRCStatus") {
                //    $.when(showConfirmationWindow('Do you want to assign the package to next level (Chief) ? ')).then(function (confirmed) {
                //        if (confirmed) {
                //            var oCOObject = new Object();
                //            oCOObject.IncidentId = uof.ui.ChangePackageOwner.viewModel.AssignModel.IncidentId();
                //            oCOObject.ExistingEmpId = uof.ui.ChangePackageOwner.viewModel.AssignModel.ExistingEmpId();
                //            oCOObject.ChangedEmpId = UCID;
                //            oCOObject.CreatedBy = UoFParams.userId;
                //            oCOObject.UserTypeId = 6
                //            oCOObject.isCFRT = true;
                //            var mappedData = ko.mapping.toJS(oCOObject);
                //            $.ajax(
                //                   {
                //                       url: window.location.uofAPIOrigin() + '/api/User/AssignPackage',
                //                       cache: false,
                //                       type: "POST",
                //                       dataType: 'json',
                //                       data: JSON.stringify(mappedData),
                //                       contentType: "application/json;charset=utf-8",
                //                       beforeSend: function myfunction() {

                //                       },
                //                       success: function (assignData) {
                //                           $.prototype.hideUofOverlay();
                //                           showAlert("Package assign to Unit Commander");
                //                           uof.ui.ChangePackageOwner.getData(uof.ui.ChangePackageOwner.viewModel.CP.URN());
                //                       },
                //                       error: function (e) {
                //                           $.prototype.hideUofOverlay();
                //                           showAlert(e.responseText);
                //                       },
                //                   });

                //        }
                //    });
                //}
                //else {
                    $("#divAssignIncident").show();
                    $("#divAssignIncident").kendoWindow({
                        width: "55%",
                        title: "Assign to " + title,
                        visible: false,
                        modal: true,
                        actions: [
                                "Pin",
                                "Close"
                        ],
                    }).data("kendoWindow").center().open();
                    uof.ui.ChangePackageOwner.validateAssignControls();
                //}
            },
            validateAssignControls: function () {
                uof.ui.ChangePackageOwner.viewModel.AssignModel.EID.extend({
                    required: {
                        params: true,
                        message: 'Required'
                    },
                });
            },
            validateAssignFields: function () {
                result = ko.validation.group(uof.ui.incident.detail.viewModel.AssignModel, { deep: true });
                if ((result().length > 0)) {
                    //To show the message
                    uof.ui.ChangePackageOwner.detail.viewModel.AssignModel.EID.valueHasMutated();
                    return false;
                }
                return true;
            },
            AssignPackage: function () {
                if (uof.ui.ChangePackageOwner.validateAssignFields()) {
                    var oCOObject = new Object();
                    oCOObject.IncidentId = uof.ui.ChangePackageOwner.viewModel.AssignModel.IncidentId();
                    oCOObject.ExistingEmpId = uof.ui.ChangePackageOwner.viewModel.AssignModel.ExistingEmpId();
                    oCOObject.ChangedEmpId = uof.ui.ChangePackageOwner.viewModel.AssignModel.EID();
                    oCOObject.ChangedEmpLastName = uof.ui.ChangePackageOwner.viewModel.AssignModel.ELName();
                    oCOObject.ChangedEmmFirstName = uof.ui.ChangePackageOwner.viewModel.AssignModel.EFName();
                    oCOObject.ChangedEmpRank = uof.ui.ChangePackageOwner.viewModel.AssignModel.ERank();
                    oCOObject.CreatedBy = UoFParams.userId;
                    oCOObject.EmailId = uof.ui.ChangePackageOwner.viewModel.AssignModel.EmailId();
                    switch (uof.ui.ChangePackageOwner.viewModel.AssignModel.ERankAbrv()) {
                        case "WC":
                        case "LT":
                        case "L/T":
                            oCOObject.UserTypeId = 5;
                            break;
                        case "CAPT":
                        case "CPT":
                            oCOObject.UserTypeId = 6;
                            break;
                        case "CMDR":
                            oCOObject.UserTypeId = 7;
                            break;
                        case "DC":
                            oCOObject.UserTypeId = 13;
                            break;

                    }
                    var mappedData = ko.mapping.toJS(oCOObject);
                    $.ajax(
                           {
                               url: window.location.uofAPIOrigin() + '/api/User/AssignPackage',
                               cache: false,
                               type: "POST",
                               dataType: 'json',
                               data: JSON.stringify(mappedData),
                               contentType: "application/json;charset=utf-8",
                               beforeSend: function myfunction() {

                               },
                               success: function (assignData) {
                                   $.prototype.hideUofOverlay();
                                   $("#divAssignIncident").data("kendoWindow").close();
                                   uof.ui.ChangePackageOwner.getData(uof.ui.ChangePackageOwner.viewModel.CP.URN());
                               },
                               error: function (e) {
                                   $.prototype.hideUofOverlay();
                                   showAlert(e.responseText);
                               },
                           });
                }

            },
            cancelAssign: function () {
                $("#divAssignIncident").data("kendoWindow").close();
            },

        }

    }();
}