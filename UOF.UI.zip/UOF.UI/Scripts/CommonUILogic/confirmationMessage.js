﻿function showConfirmationWindow(message) {
    return showWindow('#confirmationTemplate', message)
};

function showWindow(template, message) {

    var dfd = new jQuery.Deferred();
    var result = false;

    $("<div id='popupWindow'></div>")
    .appendTo("body")
    .kendoWindow({
        width: "400px",
        modal: true,
        title: "",
        modal: true,
        visible: false,
        close: function (e) {
            this.destroy();
            dfd.resolve(result);
        }
    }).data('kendoWindow').content($(template).html()).center().open();

    $('.confirmTemplateMessage').html(message);

    $('#popupWindow .confirm_yes').val('OK');
    $('#popupWindow .confirm_no').val('Cancel');

    $('#popupWindow .confirm_no').click(function () {
        $('#popupWindow').data('kendoWindow').close();
    });

    $('#popupWindow .confirm_yes').click(function () {
        result = true;
        $('#popupWindow').data('kendoWindow').close();
    });

    return dfd.promise();
};

