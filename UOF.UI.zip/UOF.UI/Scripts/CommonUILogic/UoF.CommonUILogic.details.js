﻿var uof = uof || {};
uof.ui = uof.ui || {};
uof.ui.CommonUILogic = uof.ui.CommonUILogic || {};

if (uof.ui.CommonUILogic) {
    uof.ui.CommonUILogic.detail = function () {
        return {

            isFormStatusCompleted: function (formId, incidentId, SubmitedId) {
                if (UoFParams.userId == "CFRT")
                    return true;
                else {
                    var frmStatus = this.getFormCurrentStatus(formId, incidentId, SubmitedId);
                    return frmStatus;
                    //return frmStatus == "COMPLETED";
                }
            },
            viewModel: {
                IncidentId: ko.observable(0),
                URL: ko.observable(),
                RC: {
                    Comments: ko.observable(),
                },
                ReportGenerateConfirm: {
                    InvolvedUsers: ko.observableArray([]),
                    involvedUser: ko.observable()
                },
                UoFData: {}
            },

            getFormCurrentStatus: function (formId, incidentId, SubmitedId) {
                var frmStatus = "";
                $.ajax({
                    type: 'GET',
                    async: false,
                    url: window.location.uofAPIOrigin() + '/api/UOFForm/FormStatus?formId=' + formId + '&incidentId=' + incidentId + '&reviewerId=' + UoFParams.userId + '&reviewerRole=' + UoFParams.userRole + '&IncidentReviewId=' + SubmitedId,
                    success: function (data) {
                        if (data.response) {
                            frmStatus = data.frmStatus;
                        }
                    },
                    error: function (data) {
                        showAlert(data.response);
                    },
                });
                return frmStatus;
            },
            formatIncidentDateTime: function (incidentDateTime) {
                var now = new Date(incidentDateTime),
                    tzo = -now.getTimezoneOffset(),
                    dif = tzo >= 0 ? '+' : '-',
                    pad = function (num) {
                        var norm = Math.abs(Math.floor(num));
                        return (norm < 10 ? '0' : '') + norm;
                    };
                return now.getFullYear()
                    + '-' + pad(now.getMonth() + 1)
                    + '-' + pad(now.getDate())
                    + 'T' + pad(now.getHours())
                    + ':' + pad(now.getMinutes())
                    + ':' + pad(now.getSeconds())
                    + dif + pad(tzo / 60)
                    + ':' + pad(tzo % 60);
            },
            formatLocalDate: function () {
                var now = new Date(),
                    tzo = -now.getTimezoneOffset(),
                    dif = tzo >= 0 ? '+' : '-',
                    pad = function (num) {
                        var norm = Math.abs(Math.floor(num));
                        return (norm < 10 ? '0' : '') + norm;
                    };
                return now.getFullYear()
                    + '-' + pad(now.getMonth() + 1)
                    + '-' + pad(now.getDate())
                    + 'T' + pad(now.getHours())
                    + ':' + pad(now.getMinutes())
                    + ':' + pad(now.getSeconds())
                    + dif + pad(tzo / 60)
                    + ':' + pad(tzo % 60);
            },
            ValidateOnlyNumber: function (e) {
                // Allow: backspace, delete, tab, escape, enter and .
                if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
                    // Allow: Ctrl+A, Command+A
                    (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
                    // Allow: home, end, left, right, down, up
                    (e.keyCode >= 35 && e.keyCode <= 40)) {
                    // let it happen, don't do anything
                    return;
                }
                // Ensure that it is a number and stop the keypress
                if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
                    e.preventDefault();
                }
            },
            ClearFormElements: function (targetDIV) {
                $("#" + targetDIV).find(':input').each(function () {
                    switch (this.type) {
                        case 'password':
                        case 'text':
                        case 'textarea':
                        case 'file':
                        case 'select-one':
                            $(this).val('');
                            break;
                        case 'checkbox':
                        case 'radio':
                            this.checked = false;
                    }
                });
            },
            validateDuplicate: function (source, input, userType, mode) {
                if (mode == "Edit") { return false; }
                var user = _.find(source, function (employee) {
                    if (userType == 2)
                        return (employee.BookingNumber == $.trim(input))
                    else
                        return (employee.EmployeeId == $.trim(input))
                });
                if (user != null) {
                    return true;
                }
                return false;
            },
            agefinding: function (inputValue) {
                var birthDay = inputValue;
                var DOB = new Date(birthDay);
                var today = new Date();
                var age = today.getTime() - DOB.getTime();
                age = Math.floor(age / (1000 * 60 * 60 * 24 * 365.25));
                // alert(age);
                return age;
            },
            findInmateAge: function (inputValue, incidentDate) {
                var birthDay = inputValue;
                var DOB = new Date(birthDay);
                var today = new Date(incidentDate);
                var age = today.getTime() - DOB.getTime();
                age = Math.floor(age / (1000 * 60 * 60 * 24 * 365.25));
                // alert(age);
                return age;
            },
            GetQueryStringParams: function (sParam) {
                var sPageURL = uof.ui.CommonUILogic.detail.viewModel.URL();
                var sURLVariables = sPageURL.split('?');
                for (var i = 0; i < sURLVariables.length; i++) {
                    var sParameterName = sURLVariables[i].split('=');
                    if (sParameterName[0] == sParam) {
                        return sParameterName[1].subs;

                    }
                }
            },
            LaunchDialogWindow: function (targetID, title, IncidentID, Url) {
                uof.ui.CommonUILogic.detail.viewModel.ReportGenerateConfirm.InvolvedUsers([]);
                uof.ui.CommonUILogic.detail.viewModel.ReportGenerateConfirm.involvedUser();
                //binding Comment popup page
                ko.cleanNode($("#" + targetID).get(0));
                ko.applyBindings(uof.ui.CommonUILogic.detail.viewModel, $("#" + targetID).get(0));
                uof.ui.CommonUILogic.detail.validateCommentContrl();
                uof.ui.CommonUILogic.detail.validateReportGenerationContrl();
                uof.ui.CommonUILogic.detail.viewModel.URL(Url);

                var formId = Url.split('?')[1].split('&')[0].split('=')[1];
                uof.ui.CommonUILogic.detail.GetUsersByFormId(IncidentID, formId);
                //uof.ui.CommonUILogic.detail.getInvolvedUsers(IncidentID);

                result = ko.validation.group(uof.ui.CommonUILogic.detail.viewModel.ReportGenerateConfirm, { deep: true });
                result.showAllMessages(false);


                $("#" + targetID).show();
                $("#" + targetID).kendoWindow({
                    width: "58%",
                    title: title,
                    visible: false,
                    modal: true,
                    actions: [
                            "Pin",
                            "Close"
                    ],
                }).data("kendoWindow").center().open();
                return false;


            },
            cancelDialogWindow: function (targetID) {
                result = ko.validation.group(uof.ui.CommonUILogic.detail.viewModel.ReportGenerateConfirm, { deep: true });
                result.showAllMessages(false);
                $("#" + targetID).data("kendoWindow").close();
            },

            validateCommentContrl: function () {
                uof.ui.CommonUILogic.detail.viewModel.RC.Comments.extend({
                    required: {
                        params: true,
                        message: "Required"
                    },
                });
            },

            validateComments: function () {
                result = ko.validation.group(uof.ui.CommonUILogic.detail.viewModel.RC, { deep: true });
                if ((result().length > 0)) {
                    //To show the message
                    uof.ui.CommonUILogic.detail.viewModel.RC.Comments.valueHasMutated();
                    return false;
                }
                return true;
            },

            SaveComments: function () {
                if (uof.ui.CommonUILogic.detail.validateComments()) {
                    return true;
                }
            },


            enabledMenus: function (incidentId) {
                uof.ui.CommonUILogic.detail.viewModel.IncidentId(incidentId);
                if (uof.ui.CommonUILogic.detail.viewModel.UoFData.UserAccess == undefined) {
                    $.ajax({
                        type: 'POST',
                        url: window.location.uofUIOrigin() + '/Incident/GetIncidentId',
                        data: { id: incidentId },
                        success: function (data) {
                            if (data.success == "true") {
                                uof.ui.CommonUILogic.detail.viewModel.UoFData = data.Data;
                                //uof.ui.CommonUILogic.detail.ToggleMenus(uof.ui.CommonUILogic.detail.viewModel.UoFData.UserAccess, incidentId);
                            }
                        }
                    });
                }
                //else
                //uof.ui.CommonUILogic.detail.ToggleMenus(uof.ui.CommonUILogic.detail.viewModel.UoFData.UserAccess, incidentId);
            },
            ToggleMenus: function (data, incidentId) {

                var menu = $("#MainMenu").data("kendoMenu");
                $("#MainMenu #topWidgetMenuItem").each(function (index, element) {
                    menu.enable($(element), parseInt(incidentId) > 0);
                });
                $("#MainMenu #topWidgetRptItem").each(function (index, element) {
                    menu.enable($(element), parseInt(incidentId) > 0);
                });
                $('#MainMenu li ul li a').each(function (i, li) {
                    if (uof.ui.CommonUILogic.detail.viewModel.UoFData.UserDetails.UoFUserRole.toUpperCase() != "SERGEANT")
                        $(li).addClass('disabled');
                    // your code goes here
                });
                if (data != null) {
                    $.each(data, function (index, element) {
                        var Elem = $("#MainMenu").find("#frm" + element.FormId);
                        if (Elem.length > 0)
                            $(Elem).find("a").removeClass('disabled');
                        var rptElem = $("#MainMenu").find("#rpt" + element.FormId);
                        if (rptElem.length > 0)
                            $(rptElem).find("a").removeClass('disabled');
                    });
                }

            },

            //Report Generation confirmation Section

            GetUsersByFormId: function (incidentId, formId) {
                $.prototype.showUofOverlay();
                $.ajax(
                {
                    url: window.location.uofAPIOrigin() + '/api/User/GetUsersByFormId',
                    data: { IncidentId: uof.ui.CommonUILogic.detail.viewModel.IncidentId(), formId: formId },
                    cache: false,
                    type: "GET",
                    dataType: 'json',
                    contentType: "application/json;charset=utf-8",
                    beforeSend: function myfunction() {

                    },
                    success: function (Data) {
                        uof.ui.CommonUILogic.detail.viewModel.ReportGenerateConfirm.InvolvedUsers(Data);
                        $.prototype.hideUofOverlay();
                        //_.each(Data, function (item, index) {
                        //    uof.ui.CommonUILogic.detail.viewModel.ReportGenerateConfirm.InvolvedUsers.push({ Name: item.FirstName, Code: item.UserId });
                        //});
                    },
                    error: function (e) {
                        $.prototype.hideUofOverlay();
                        showAlert(e.responseText);
                    },
                });
            },

            getInvolvedUsers: function (incidentId) {

                $.prototype.showUofOverlay();
                $.ajax(
                {
                    url: window.location.uofAPIOrigin() + '/api/User/GetInvolvedUserWithName',
                    data: 'incidentId=' + uof.ui.CommonUILogic.detail.viewModel.IncidentId(),
                    cache: false,
                    type: "GET",
                    dataType: 'json',
                    contentType: "application/json;charset=utf-8",
                    beforeSend: function myfunction() {

                    },
                    success: function (Data) {

                        uof.ui.CommonUILogic.detail.viewModel.ReportGenerateConfirm.InvolvedUsers(Data);
                        $.prototype.hideUofOverlay();
                        //_.each(Date, function (item, index) {
                        //    uof.ui.CommonUILogic.detail.viewModel.ReportGenerateConfirm.InvolvedUsers.push({
                        //        Name: item.FirstName + "" + item.MiddleName + "" + item.LastName,
                        //        Code: item.UserId
                        //    });
                        //});
                    },
                    error: function (e) {
                        $.prototype.hideUofOverlay();
                        showAlert(e.responseText);
                    },
                });
            },

            PrintReport: function (targetID) {

                $("#dvGenerateReport").find(".validationMessage").remove();
                $("#dvGenerateReport").find(".warning-msg").remove();
                if (uof.ui.CommonUILogic.detail.validateReportGeneration()) {
                    $("#" + targetID).data("kendoWindow").close();
                    window.location = uof.ui.CommonUILogic.detail.viewModel.URL() + "&userID=" + uof.ui.CommonUILogic.detail.viewModel.ReportGenerateConfirm.involvedUser();
                }
            },

            validateReportGeneration: function () {
                result = ko.validation.group(uof.ui.CommonUILogic.detail.viewModel.ReportGenerateConfirm, { deep: true });
                if ((result().length > 0)) {
                    //To show the message
                    uof.ui.CommonUILogic.detail.viewModel.ReportGenerateConfirm.involvedUser.valueHasMutated();
                    // $("#dvGenerateReport").find(".validationMessage").remove();
                    return false;
                }
                return true;
            },

            validateReportGenerationContrl: function () {
                uof.ui.CommonUILogic.detail.viewModel.ReportGenerateConfirm.involvedUser.extend({
                    required: {
                        params: true,
                        message: "Required"
                    },
                });
            },
            lengthValidation: function (str, minChar) {
                var maxChar;
                if (uof.ui.CommonUILogic.detail.getCharCount(str) < minChar[0] ||
                    uof.ui.CommonUILogic.detail.getCharCount(str) > minChar[1])
                    return false;
                return true;
            },
            getCharCount: function (str) {
                var result = 0;
                if (str !== undefined) {
                    for (var n = 0; n < str.length; n++) {
                        var charCode = str.charCodeAt();
                        if (typeof charCode === "number") {
                            if (charCode < 128)
                            { result = result + 1; }
                            else if (charCode < 2048)
                            { result = result + 2; }
                            else if (charCode < 65536)
                            { result = result + 3; }
                            else if (charCode < 2097152)
                            { result = result + 4; }
                            else if (charCode < 67108864)
                            { result = result + 5; }
                            else
                            { result = result + 6; }
                        }
                    }
                }
                return result;
            },
            ValidateOnlyNumber: function (e) {
                // Allow: backspace, delete, tab, escape, enter and .
                if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
                    // Allow: Ctrl+A, Command+A
                    (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
                    // Allow: home, end, left, right, down, up
                    (e.keyCode >= 35 && e.keyCode <= 40)) {
                    // let it happen, don't do anything
                    return;
                }
                // Ensure that it is a number and stop the keypress
                if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
                    e.preventDefault();
                }
            },
        }
    }();

}