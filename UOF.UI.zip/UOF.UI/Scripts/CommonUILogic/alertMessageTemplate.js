﻿function showAlert(message) {
    return showAlertWindow('#alertTemplate', message)
};

function showAlertWindow(template, message) {

    var dfd = new jQuery.Deferred();
    var result = false;

    $("<div id='alertPopupWindow'></div>")
    .appendTo("body")
    .kendoWindow({
        width: "400px",
        modal: true,
        title: "Use of Force  !",
        modal: true,
        visible: false,
        close: function (e) {
            this.destroy();
            dfd.resolve(result);
        }
    }).data('kendoWindow').content($(template).html()).center().open();

    $('.alertTemplateMessage').html(message);

    $('#alertPopupWindow .confirm_yes').val('OK');

    $('#alertPopupWindow .confirm_yes').click(function () {
        result = true;
        $('#alertPopupWindow').data('kendoWindow').close();
    });

    return dfd.promise();
};

