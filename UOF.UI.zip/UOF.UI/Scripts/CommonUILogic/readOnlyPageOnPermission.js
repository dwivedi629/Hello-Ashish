﻿var uof = uof || {};
uof.ui = uof.ui || {};
uof.ui.readOnlyPageOnPermission = uof.ui.readOnlyPageOnPermission || {};

if (uof.ui.readOnlyPageOnPermission) {
    uof.ui.readOnlyPageOnPermission = function () {
        return {
            changeAllControlsToReadOnly: function (formCode, frmId) {
                $.ajax(
                    {
                        url: window.location.uofAPIOrigin() + '/api/Settings/GetFormPermission',
                        cache: false,
                        type: "GET",
                        dataType: 'json',
                        contentType: "application/json;charset=utf-8",
                        success: function (getAllPermission) {
                            var isReadOnly = _.find(getAllPermission, function (item) {
                                if ((String(item.FormCode).toLowerCase() == String(formCode).toLowerCase()) && item.IsViewOnly) {
                                    return item;
                                }
                            });

                            if (isReadOnly) {
                                $('#' + frmId + ' input').attr('readonly', 'readonly');
                                $('#' + frmId + ' input').attr('disabled', 'disabled');
                                $('#' + frmId + ' select').attr('readonly', 'readonly');
                                $('#' + frmId + ' button').attr('disabled', 'disabled');
                            }
                        },
                        error: function (e) {
                        },
                    });               
            },

        }
    }();

}