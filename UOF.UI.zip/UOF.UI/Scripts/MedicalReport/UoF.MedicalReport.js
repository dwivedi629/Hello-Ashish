﻿var uof = uof || {};
uof.ui = uof.ui || {};
uof.ui.MedicalReport = uof.ui.MedicalReport || {};
if (uof.ui.MedicalReport) {
    var imageCropWidth = 0;
    var imageCropHeight = 0;
    var cropPointX = 0;
    var cropPointY = 0;
    uof.ui.MedicalReport = function () {
        return {
            parameters: null,
            isChanged: false,
            init: function (args) {
                this.parameters = args;
            },
            MedicalReportDBSource: null,
            ParameterCriteria: {
                IncidentReviewId: 0,
                employeeId: '',
                incidentId: 0,
                formId: 0,
                formDataId: 0
            },
            viewModel: {
                IncidentReviewId: ko.observable(0),
                FormDataId: ko.observable(0),
                IsFormOwner: ko.observable(false),
                IsIncidentOwner: ko.observable(false),
                IsLock: ko.observable(false),
                IsSupervisorStatus: ko.observable(),
                IsSupervisorOrApprover: ko.observable(false),
                IsOnlyApproval: ko.observable(true),
                isMedical: ko.observable(false),
                IsOnlySave: ko.observable(true),
                Race: ko.observable([]),
                Sex: ko.observableArray([]),
                IncidentID: ko.observable(),
                UserRole: ko.observable(),
                FormID: ko.observable(),
                EmpId: ko.observable(UoFParams.userId),
                SubmitedId: ko.observable(),
                ActionType: ko.observable("E"),
                getSuspectDetails: function (bookingId, optionCriteria) {
                    if (bookingId != undefined)
                        uof.ui.MedicalReport.getSuspectDetails(bookingId, optionCriteria);
                },
                UniformInformation: {
                    URN: ko.observable(),
                    ReferenceNumber: ko.observable(),
                },
                InmateInformation: {
                    InmateName: ko.observable(),
                    BookingNumber: ko.observable(),
                    InmateAge: ko.observable(),
                    Sex: ko.observable(),
                    InmateRace: ko.observableArray(),
                    InmateDOB: ko.observable(),
                    HousingFacility: ko.observable(),
                    InmateBarrack: ko.observable(),
                    InmateCell: ko.observable(),
                    InmateSegregation: ko.observable(false),
                    InmateGeneralPopulation: ko.observable(false),
                    InmateMentalHealthHousing: ko.observable(false),
                    InmateMedicalHousing: ko.observable(false),
                    InmateDiscipline: ko.observable(false),
                    InmateSegregationReason: ko.observable(),
                    ImageURL: ko.observable(),
                },
                IncidentInformation: {
                    IncidentLocation: ko.observable(),
                    IncidentTypeOfLocation: ko.observable(),
                    IncidentDate: ko.observable(),
                    IncidentTime: ko.observable(),
                    IntiatedNo: ko.observable(),
                    IntiatedName: ko.observable(),
                    IntiatedDate: ko.observable(),
                },
                EscortInformation: {
                    InmateEscorted: ko.observable(false),
                    EscortFacility: ko.observable(),
                    EscortNumber: ko.observable(),
                    EscortNameAndNumber: ko.observable(),
                    EscortTime: ko.observable(),
                    EstFacility: ko.observable(),
                    EstNumber: ko.observable(),
                    EstNameAndNumber: ko.observable(),
                    EstTime: ko.observable(),
                    InmateTransported: ko.observable(false),
                    TransportedHospital: ko.observable(),
                    TransportedMedia: ko.observable(),
                    EscortedNumber: ko.observable(),
                    EscortedNameAndNumber: ko.observable(),
                    EscortedDate: ko.observable(),
                    EscortedTime: ko.observable(),
                    EstedNumber: ko.observable(),
                    EstedNameAndNumber: ko.observable(),
                    EstedDate: ko.observable(),
                    EstedTime: ko.observable(),
                    InmateTreatedby: ko.observable(),
                    InmateTreatedDate: ko.observable(),
                    InmateTreatedTime: ko.observable(),
                    InmateReturnedFacility: ko.observable(),
                    InmateReturnedDate: ko.observable(),
                    InmateReturnedTime: ko.observable(),
                    InmateOther: ko.observable(),
                    InmateOtherReason: ko.observable(),
                    InmateAdmitted: ko.observable(),
                },
                SupervisorInformation: {
                    SupervisorName: ko.observable(),
                    SupervisorEmployeeNumber: ko.observable(),
                    SupervisorAssesmentDate: ko.observable(),
                    SupervisorAssesmentTime: ko.observable(),
                    InmateInvolved: ko.observable(false),
                    InmateAlleged: ko.observable(false),
                    InmatePriorToDuring: ko.observable(false),
                    ChemicalAgent: ko.observable(false),
                    ControlHolds: ko.observable(false),
                    Takedown: ko.observable(false),
                    PersonalWeapons: ko.observable(false),
                    TaserApplication: ko.observable(false),
                    ImpactWeapon: ko.observable(false),
                    Stunbag: ko.observable(false),
                    PepperballGun: ko.observable(false),
                    CarotidRestraint: ko.observable(false),
                    k9: ko.observable(false),
                    Firearm: ko.observable(false),
                    OtherForce: ko.observable(),
                    AllegedUOFHandledby: ko.observable(),
                    AllegedUOFHandledbyName: ko.observable(),
                    UnderFileNumber: ko.observable(),
                    SupervisoryURN: ko.observable(),
                    SupReferenceNumber: ko.observable(),
                    BriefDescription: ko.observable(),

                },
                MedicalInformation: {
                    EvaluatedBy: ko.observable(),
                    EvaluatedEmployeeNumber: ko.observable(),
                    DateEvaluated: ko.observable(),
                    TimeEvaluated: ko.observable(),
                    MedicalAssessment: ko.observable(),
                    VisibleYes: ko.observable(false),
                    VisibleNo: ko.observable(false),
                    Abrasion: ko.observable(false),
                    Active: ko.observable(false),
                    Bruise: ko.observable(false),
                    Deformity: ko.observable(false),
                    Dried: ko.observable(false),
                    Cut: ko.observable(false),
                    OC: ko.observable(false),
                    Complaint: ko.observable(false),
                    Protrusion: ko.observable(false),
                    Puncture: ko.observable(false),
                    Reddened: ko.observable(false),
                    Skin: ko.observable(false),
                    Swollen: ko.observable(false),
                    Other1: ko.observable(false),
                    Other2: ko.observable(false),
                    Other3: ko.observable(false),
                    SprayExposureYN: ko.observable(),
                    DecontaminatedYN: ko.observable(),
                    RefusedMedicalTreatmentYN: ko.observable(),
                    RefusalVideotapedYN: ko.observable(),
                    FollowUpTreatmentYN: ko.observable(),
                    ImageURL: ko.observable(),
                },
                DiagnosisInformation: {
                    sec: ko.observable(false),
                    OutsideTreatedBy: ko.observable(),
                    OutsideTreatedByName: ko.observable(),
                    OutsideEmployeeNumber: ko.observable(),
                    OutsideDateTreated: ko.observable(),
                    OutsideTimeTreated: ko.observable(),
                    OutsideAppearsYes: ko.observable(false),
                    OutsideAppearsNo: ko.observable(false),
                    OutsideDescription: ko.observable(),
                    OutsideInfluenceYes: ko.observable(false),
                    OutsideInfluenceNo: ko.observable(false),
                    OutsideInfluenceUnable: ko.observable(false),

                    OutsideTreatementYes: ko.observable(false),
                    OutsideTreatementNo: ko.observable(false),

                    OutsideAdmited: ko.observable(false),
                    OutsideCustodyfacility: ko.observable(false),
                    OutsideMediaRadiocar: ko.observable(false),
                    OutsideMediaAmbulance: ko.observable(false),

                    OutsideSuicideYes: ko.observable(false),
                    OutsideSuicideNo: ko.observable(false),
                    DischargeForm: ko.observable(false),
                    FollowupTreatment: ko.observable(false),
                    FollowupTreatmentYes: ko.observable(false),
                    FollowupTreatmentNo: ko.observable(false),
                    WatchCommander: ko.observable(),
                    EmployeeNumber: ko.observable(),
                    RejectComments: ko.observable(),
                },
            },
            load: function () {
                ko.validation.init({ insertMessages: true });

                uof.ui.MedicalReport.initiateBindings();
                uof.ui.MedicalReport.validateControls();
                uof.ui.MedicalReport.subscribeMethod();
                //binding UniformInfo Report page
                ko.cleanNode($("#UniformInfo").get(0));
                ko.applyBindings(uof.ui.MedicalReport.viewModel, $("#UniformInfo").get(0));

                //InmateInfo
                ko.cleanNode($("#InmateInfo").get(0));
                ko.applyBindings(uof.ui.MedicalReport.viewModel, $("#InmateInfo").get(0));

                ////IncidentInfo
                //ko.cleanNode($("#IncidentInfo").get(0));
                //ko.applyBindings(uof.ui.MedicalReport.viewModel, $("#IncidentInfo").get(0));

                //Deputy
                ko.cleanNode($("#EscortInfo").get(0));
                ko.applyBindings(uof.ui.MedicalReport.viewModel, $("#EscortInfo").get(0));

                ////Vehicle
                ko.cleanNode($("#SupervisorInfo").get(0));
                ko.applyBindings(uof.ui.MedicalReport.viewModel, $("#SupervisorInfo").get(0));
                //Screening
                ko.cleanNode($("#MedicalInfo").get(0));
                ko.applyBindings(uof.ui.MedicalReport.viewModel, $("#MedicalInfo").get(0));
                //Property
                ko.cleanNode($("#DiagnosisInfo").get(0));
                ko.applyBindings(uof.ui.MedicalReport.viewModel, $("#DiagnosisInfo").get(0));
                uof.ui.MedicalReport.initiatePickers();
                uof.ui.MedicalReport.GetRace();
                uof.ui.MedicalReport.GetSex();
                uof.ui.MedicalReport.bindApproveorEdit();


                //uof.ui.MedicalReport.initCrop();



                //$("#hl-crop-image").on("click", function (e) {
                //    e.preventDefault();
                //    uof.ui.MedicalReport.cropImage();
                //});
                //$(document).on('keyup', "#txtReject", function (e) {
                //    var Commtstring = $.trim($("#txtReject").val());
                //    if (Commtstring.length > 0) {
                //        $("#btnReject").prop('disabled', false);
                //        $("#btnApprove").prop('disabled', true);
                //    }
                //    else {
                //        $("#btnReject").prop('disabled', true);
                //        $("#btnApprove").prop('disabled', false);
                //    }
                //});

                uof.ui.MedicalReport.setTabbing();

                //uof.ui.readOnlyPageOnPermission.changeAllControlsToReadOnly('D_MedicalReport', 'MedicalInfo');

            },

            setTabbing: function () {
                var tab = 1;
                $("#dvMedicalTab *").filter(':input').each(function () {
                    $(this).attr('tabindex', tab++);
                });


            },
            initCrop: function () {
                $('#my-origin-image').Jcrop({
                    onChange: uof.ui.MedicalReport.setCoordsAndImgSize,
                    aspectRatio: 1
                });
            },
            setCoordsAndImgSize: function (e) {
                imageCropWidth = e.w;
                imageCropHeight = e.h;

                cropPointX = e.x;
                cropPointY = e.y;
            },
            cropImage: function () {
                if (imageCropWidth == 0 && imageCropHeight == 0) {
                    showAlert("Please select crop area.");
                    return;
                }
                $.ajax({
                    url: window.location.uofUIOrigin() + '/ImageProcessing/CropImage',
                    type: 'POST',
                    data: {
                        imagePath: $("#my-origin-image").attr("src"),
                        cropPointX: cropPointX,
                        cropPointY: cropPointY,
                        imageCropWidth: imageCropWidth,
                        imageCropHeight: imageCropHeight
                    },
                    success: function (data) {
                        $("#my-cropped-image")
                            .attr("src", data.photoPath + "?t=" + new Date().getTime())
                            .show();
                    },
                    error: function (data) { }
                });
            },
            getSuspectDetails: function (bookingNumber, targetDiv) {
                if (((bookingNumber != undefined) && (bookingNumber.length > 0) && localStorage.getItem('formMode') != "View")) {
                    var eventDate = uof.ui.CommonUILogic.detail.formatIncidentDateTime(UoFParams.IncidentDate);
                    $.prototype.showProgressBar(targetDiv);
                    jQuery.ajax({
                        type: "GET",
                        url: InmateAPIUrl() + bookingNumber + "&eventDate=" + eventDate + "",
                        dataType: "json",
                        cache: false,
                        crossDomain: true,
                        processData: true,
                        success: function (inmateData) {
                            $.prototype.hideProgressBar(targetDiv);
                            if (targetDiv == 'InmateInfo #BookingNumber') {
                                uof.ui.MedicalReport.viewModel.InmateInformation.InmateName(inmateData.LastName + ' ' + inmateData.FirstName + ' ' + inmateData.MiddleName);
                                if (moment(inmateData.DateOfBirth) != null)
                                    uof.ui.MedicalReport.viewModel.InmateInformation.InmateDOB(moment(inmateData.DateOfBirth).format("MM/DD/YYYY"));

                                uof.ui.MedicalReport.viewModel.InmateInformation.Sex(inmateData.Sex);
                                $('#IncSex').selectpicker('refresh');
                                //uof.ui.MedicalReport.viewModel.InmateInformation.InmateAge(inmateData.Age);
                                if (inmateData.Race != null) {
                                    $("#IncMedicalRace").selectpicker('destroy');
                                    uof.ui.MedicalReport.viewModel.InmateInformation.InmateRace([]);

                                    uof.ui.MedicalReport.viewModel.InmateInformation.InmateAge(uof.ui.CommonUILogic.detail.findInmateAge(uof.ui.MedicalReport.viewModel.InmateInformation.InmateDOB(), UoFParams.IncidentDate));
                                    uof.ui.MedicalReport.viewModel.InmateInformation.InmateRace(inmateData.Race);
                                    $('#IncMedicalRace').selectpicker('refresh');
                                }
                                else {
                                    $("#IncMedicalRace").selectpicker('destroy');
                                    uof.ui.MedicalReport.viewModel.InmateInformation.InmateRace([]);
                                    $('#IncMedicalRace').selectpicker('refresh');
                                }
                                //if (inmateData.HousingBunk != null) {
                                //    uof.ui.MedicalReport.viewModel.InmateInformation.InmateBarrack(inmateData.HousingBunk)
                                //}
                                var cellBunk = "";
                                if (inmateData.HousingCell != null)
                                    cellBunk = inmateData.InmateCell;
                                if (inmateData.HousingBunk != null) {
                                    if (cellBunk != "")
                                        cellBunk + "/" + inmateData.HousingBunk
                                }
                                uof.ui.MedicalReport.viewModel.InmateInformation.InmateCell(cellBunk);

                                if (inmateData.HousingFacility != null) {
                                    uof.ui.MedicalReport.viewModel.InmateInformation.HousingFacility(inmateData.HousingFacility)
                                }
                                var BMD = "";
                                if (inmateData.HousingModule != null)
                                    BMD = inmateData.HousingModule;
                                if (inmateData.HousingRow != null) {
                                    if (BMD != "")
                                        BMD + "/" + inmateData.HousingRow
                                }
                                uof.ui.MedicalReport.viewModel.InmateInformation.InmateBarrack(BMD)
                            }
                        },
                        error: function (XMLHttpRequest, textStatus, errorThrown) {
                            $.prototype.hideProgressBar(targetDiv);
                            showAlert("Error while getting the Suspect Data");
                        }
                    });
                }

            },

            uploadFile: function () {

                var data = new FormData();
                var files = $("#ImageData").get(0).files;
                if (files.length > 0) {
                    data.append("MyImages", files[0]);
                }
                $.ajax({
                    url: "../FileUpload/FileUpload",
                    type: "POST",
                    processData: false,
                    contentType: false,
                    data: data,
                    success: function (response) {
                        if (response.Success)
                            uof.ui.MedicalReport.viewModel.MedicalInformation.ImageURL(response.relativePath);
                        else
                            uof.ui.MedicalReport.viewModel.MedicalInformation.ImageURL = ko.observable();
                        // $("#txtImg").val(response);
                        //$("#imgMedical").attr('src',  response);
                    },
                    error: function (er) {
                        alert(er);
                    }

                });
            },
            GetuploadedFile: function () {

                $.ajax({
                    url: "../FileUpload/GetMedicalUploadedFile",
                    type: "POST",
                    processData: false,
                    contentType: false,
                    data: null,
                    success: function (response) {
                        if (response.Success)
                            uof.ui.MedicalReport.viewModel.MedicalInformation.ImageURL(response.relativePath);
                        else
                            uof.ui.MedicalReport.viewModel.MedicalInformation.ImageURL = ko.observable();
                        // $("#txtImg").val(response);
                        //$("#imgMedical").attr('src', response);
                    },
                    error: function (er) {
                        alert(er);
                    }

                });
            },
            getEmployeeDetails: function (empId, targetDiv) {
                if (((empId != undefined) && (empId.length > 0) && localStorage.getItem('formMode') != "View")) {
                    // Search based on emp id
                    $.prototype.showProgressBar(targetDiv);
                    jQuery.ajax({
                        type: "GET",
                        url: EmployeeAPIUrl() + empId,
                        dataType: "json",
                        cache: false,
                        crossDomain: true,
                        processData: true,
                        success: function (empData) {
                            if (targetDiv == "SupervisorInfo #SupervisorEmployeeNumber")
                                uof.ui.MedicalReport.viewModel.SupervisorInformation.SupervisorName(empData.LastName + ' ' + empData.FirstName.charAt(0));
                            else if (targetDiv == "MedicalInfo #EvaluatedEmployeeNumber") {
                                uof.ui.MedicalReport.viewModel.MedicalInformation.EvaluatedBy(empData.LastName + ' ' + empData.FirstName.charAt(0));
                            }
                            else if (targetDiv == "EscortInfo #EscortedNameAndNumber")
                                uof.ui.MedicalReport.viewModel.EscortInformation.EscortedNameAndNumber(empData.LastName + ' ' + empData.FirstName.charAt(0));
                            else if (targetDiv == "EscortInfo #EscortNumber")
                                uof.ui.MedicalReport.viewModel.EscortInformation.EscortNameAndNumber(empData.LastName + ' ' + empData.FirstName.charAt(0));
                            else if (targetDiv == "SupervisorInfo #divApproval")
                                uof.ui.MedicalReport.viewModel.DiagnosisInformation.WatchCommander(empData.LastName + ' ' + empData.FirstName.charAt(0));
                            else if (targetDiv == "AllegedUOFHandledby")
                                uof.ui.MedicalReport.viewModel.SupervisorInformation.AllegedUOFHandledbyName(empData.LastName + ' ' + empData.FirstName.charAt(0));
                            else if (targetDiv == "OutsideTreatedBy")
                                uof.ui.MedicalReport.viewModel.DiagnosisInformation.OutsideTreatedByName(empData.LastName + ' ' + empData.FirstName.charAt(0));
                            else if (targetDiv == "IntiatedNo")
                                uof.ui.MedicalReport.viewModel.IncidentInformation.IntiatedName(empData.LastName + ' ' + empData.FirstName.charAt(0));
                            else if (targetDiv == "EstedNumber")
                                uof.ui.MedicalReport.viewModel.EscortInformation.EstedNameAndNumber(empData.LastName + ' ' + empData.FirstName.charAt(0));
                            else if (targetDiv == "EstNumber")
                                uof.ui.MedicalReport.viewModel.EscortInformation.EstNameAndNumber(empData.LastName + ' ' + empData.FirstName.charAt(0));


                            $.prototype.hideProgressBar(targetDiv);
                        },
                        error: function (XMLHttpRequest, textStatus, errorThrown) {
                            showAlert("Error while getting the Employee Data");
                        }
                    });
                }
            },
            bindApproveorEdit: function () {
                if (localStorage.getItem('formMode') == "View" || localStorage.getItem('formMode') == "Approve") {
                    if ($.IncidentId.length > 0 && $.UoFformId.length > 0 && $.SubmitedId.length > 0) {
                        uof.ui.MedicalReport.viewModel.IncidentID($.IncidentId);
                        uof.ui.MedicalReport.viewModel.FormID($.UoFformId);
                        uof.ui.MedicalReport.viewModel.EmpId($.SubmitedId);
                        uof.ui.MedicalReport.viewModel.SubmitedId($.SubmitedId);
                        uof.ui.MedicalReport.viewModel.UserRole(UoFParams.userRole);
                        uof.ui.MedicalReport.viewModel.IncidentReviewId(localStorage.getItem('IncidentReviewId') == null ? 0 : localStorage.getItem('IncidentReviewId'));
                        uof.ui.MedicalReport.viewModel.FormDataId(localStorage.getItem('FormDataId') == null ? 0 : localStorage.getItem('FormDataId'));

                    }
                }
                else {
                    uof.ui.MedicalReport.viewModel.IncidentID(UoFParams.IncidentId);
                    uof.ui.MedicalReport.viewModel.FormID($.UoFformId);
                    uof.ui.MedicalReport.viewModel.EmpId(localStorage.getItem('SubmittedId') == null ? UoFParams.userId : localStorage.getItem('SubmittedId'));
                    uof.ui.MedicalReport.viewModel.SubmitedId(localStorage.getItem('SubmittedId') == null ? UoFParams.userId : localStorage.getItem('SubmittedId'));
                    uof.ui.MedicalReport.viewModel.IncidentReviewId(localStorage.getItem('IncidentReviewId') == null ? 0 : localStorage.getItem('IncidentReviewId'));
                    uof.ui.MedicalReport.viewModel.FormDataId(localStorage.getItem('FormDataId') == null ? 0 : localStorage.getItem('FormDataId'));
                }
                uof.ui.MedicalReport.bindMedicalDetails()
            },

            bindMedicalDetails: function () {
                if (uof.ui.MedicalReport.viewModel.FormDataId() == 0) {
                    uof.ui.MedicalReport.MedicalSection();
                    uof.ui.MedicalReport.SupervisorySection();
                    return;
                }
                $.prototype.showUofOverlay();
                uof.ui.MedicalReport.ParameterCriteria.IncidentReviewId = uof.ui.MedicalReport.viewModel.IncidentReviewId();
                uof.ui.MedicalReport.ParameterCriteria.formDataId = uof.ui.MedicalReport.viewModel.FormDataId();
                uof.ui.MedicalReport.ParameterCriteria.employeeId = uof.ui.MedicalReport.viewModel.EmpId();
                uof.ui.MedicalReport.ParameterCriteria.incidentId = uof.ui.MedicalReport.viewModel.IncidentID();
                uof.ui.MedicalReport.ParameterCriteria.formId = uof.ui.MedicalReport.viewModel.FormID();//e.data.FormId;
                var model = ko.mapping.toJS(uof.ui.MedicalReport.ParameterCriteria);
                $.ajax(
                       {
                           url: window.location.uofAPIOrigin() + '/api/UOFForm/GetMedicalReport',
                           cache: false,
                           data: JSON.stringify(model),
                           //data: { FormId: uof.ui.MedicalReport.viewModel.FormID(), IncidentId: uof.ui.MedicalReport.viewModel.IncidentID(), DeputyId: uof.ui.MedicalReport.viewModel.EmpId() },
                           type: "POST",
                           dataType: 'json',
                           contentType: "application/json;charset=utf-8",
                           beforeSend: function myfunction() {

                           },
                           success: function (data) {
                               if (data != null) {
                                   uof.ui.MedicalReport.viewModel.UniformInformation = ko.mapping.fromJS(data.uniformInformation, ko.mapping.toJS(uof.ui.MedicalReport.viewModel.UniformInformation));
                                   uof.ui.MedicalReport.viewModel.InmateInformation = ko.mapping.fromJS(data.inmateInformation, ko.mapping.toJS(uof.ui.MedicalReport.viewModel.InmateInformation));
                                   uof.ui.MedicalReport.viewModel.IncidentInformation = ko.mapping.fromJS(data.incidentInformation, ko.mapping.toJS(uof.ui.MedicalReport.viewModel.IncidentInformation));
                                   uof.ui.MedicalReport.viewModel.EscortInformation = ko.mapping.fromJS(data.escortInformation, ko.mapping.toJS(uof.ui.MedicalReport.viewModel.EscortInformation));
                                   uof.ui.MedicalReport.viewModel.SupervisorInformation = ko.mapping.fromJS(data.supervisorInformation, ko.mapping.toJS(uof.ui.MedicalReport.viewModel.SupervisorInformation));
                                   uof.ui.MedicalReport.viewModel.MedicalInformation = ko.mapping.fromJS(data.medicalInformation, ko.mapping.toJS(uof.ui.MedicalReport.viewModel.MedicalInformation));
                                   uof.ui.MedicalReport.viewModel.DiagnosisInformation = ko.mapping.fromJS(data.diagnosisInformation, ko.mapping.toJS(uof.ui.MedicalReport.viewModel.DiagnosisInformation));
                                   $("#IncMedicalRace").selectpicker('destroy');
                                   $('#IncSex').selectpicker('destroy');

                                   uof.ui.MedicalReport.initiateBindings();
                                   uof.ui.MedicalReport.validateControls();
                                   uof.ui.MedicalReport.subscribeMethod();

                                   //binding UniformInfo Report page
                                   ko.cleanNode($("#UniformInfo").get(0));
                                   ko.applyBindings(uof.ui.MedicalReport.viewModel, $("#UniformInfo").get(0));

                                   //InmateInfo
                                   ko.cleanNode($("#InmateInfo").get(0));
                                   ko.applyBindings(uof.ui.MedicalReport.viewModel, $("#InmateInfo").get(0));

                                   ////IncidentInfo
                                   //ko.cleanNode($("#IncidentInfo").get(0));
                                   //ko.applyBindings(uof.ui.MedicalReport.viewModel, $("#IncidentInfo").get(0));

                                   //Deputy
                                   ko.cleanNode($("#EscortInfo").get(0));
                                   ko.applyBindings(uof.ui.MedicalReport.viewModel, $("#EscortInfo").get(0));

                                   ////Vehicle
                                   ko.cleanNode($("#SupervisorInfo").get(0));
                                   ko.applyBindings(uof.ui.MedicalReport.viewModel, $("#SupervisorInfo").get(0));
                                   //Screening
                                   ko.cleanNode($("#MedicalInfo").get(0));
                                   ko.applyBindings(uof.ui.MedicalReport.viewModel, $("#MedicalInfo").get(0));
                                   //Property
                                   ko.cleanNode($("#DiagnosisInfo").get(0));
                                   ko.applyBindings(uof.ui.MedicalReport.viewModel, $("#DiagnosisInfo").get(0));

                                   if (uof.ui.MedicalReport.viewModel.InmateInformation.InmateRace() != null)
                                       uof.ui.MedicalReport.viewModel.InmateInformation.InmateRace = ko.observableArray(uof.ui.MedicalReport.viewModel.InmateInformation.InmateRace().split(','));


                                   $("#IncMedicalRace").selectpicker('refresh');
                                   if (UoFParams.IncidentURN != "") {
                                       uof.ui.MedicalReport.viewModel.UniformInformation.URN(UoFParams.IncidentURN);
                                       //Commented by As need to show the data entered by DSG User
                                       //uof.ui.MedicalReport.viewModel.UniformInformation.ReferenceNumber(UoFParams.ReferenceNo);

                                       //uof.ui.MedicalReport.viewModel.SupervisorInformation.SupReferenceNumber(UoFParams.ReferenceNo);
                                       //uof.ui.MedicalReport.viewModel.IncidentInformation.IncidentLocation(UoFParams.IncidentLocation);
                                       //uof.ui.MedicalReport.viewModel.SupervisorInformation.UnderFileNumber(UoFParams.IncidentURN);
                                       //uof.ui.MedicalReport.viewModel.IncidentInformation.IncidentTypeOfLocation(UoFParams.IncidentForceLocation);

                                       if (UoFParams.WC.length > 6) {
                                           uof.ui.MedicalReport.viewModel.DiagnosisInformation.EmployeeNumber(UoFParams.WC.split('-')[0]);
                                           uof.ui.MedicalReport.viewModel.DiagnosisInformation.WatchCommander(UoFParams.WC.split('-')[1]);
                                       }
                                       if (UoFParams.InvestSupervisor.length > 6) {
                                           uof.ui.MedicalReport.viewModel.SupervisorInformation.AllegedUOFHandledby(UoFParams.InvestSupervisor.split('-')[0]);
                                           uof.ui.MedicalReport.viewModel.SupervisorInformation.AllegedUOFHandledbyName(UoFParams.InvestSupervisor.split('-')[1]);
                                       }
                                   }
                                   if (uof.ui.MedicalReport.viewModel.DiagnosisInformation.RejectComments() != "") {
                                       $(".fakeclass").removeClass('hide');
                                       $("#txtReject").attr('disabled', false);
                                   }
                                   uof.ui.MedicalReport.GetuploadedFile();
                                   uof.ui.MedicalReport.initiatePickers();

                               }
                               else {
                                   uof.ui.MedicalReport.viewModel.IsOnlyApproval(false),
                                   $("#btnApprove").addClass('hide'); $("#btnReject").addClass('hide');
                               }
                               uof.ui.MedicalReport.toggleControls();

                               $.prototype.hideUofOverlay();
                           },
                           error: function (e) {
                               $.prototype.hideUofOverlay();
                               showAlert(e.responseText);

                           },
                       });
            },
            toggleControls: function () {
                var isDisable = true;
                uof.ui.MedicalReport.viewModel.IncidentReviewId(localStorage.getItem('IncidentReviewId') == null ? 0 : localStorage.getItem('IncidentReviewId'))
                uof.ui.MedicalReport.viewModel.SubmitedId(localStorage.getItem('SubmittedId') == null ? 0 : localStorage.getItem('SubmittedId'));
                var formData = uof.ui.CommonUILogic.detail.isFormStatusCompleted($.UoFformId, UoFParams.IncidentId, uof.ui.MedicalReport.viewModel.IncidentReviewId());
                // if (UoFParams.userRank == "2")
                //     isDisable=false
                //if (UoFParams.userRank == "3")
                //     isDisable = false
                if (formData != "") {
                    var formStatus = formData.split('\r\n');

                    uof.ui.MedicalReport.viewModel.IsFormOwner(formStatus[0].split(':')[1].toLowerCase() == "true" ? true : false);
                    uof.ui.MedicalReport.viewModel.IsIncidentOwner(formStatus[1].split(':')[1].toLowerCase() == "true" ? true : false);
                    uof.ui.MedicalReport.viewModel.IsLock(formStatus[2].split(':')[1].toLowerCase() == "true" ? true : false);
                    uof.ui.MedicalReport.viewModel.IsSupervisorStatus(formStatus[3].split(':')[1].toLowerCase());
                    if (uof.ui.MedicalReport.viewModel.IsLock()) {
                        //if (isDisable) {
                        $("#vertical-tabs *").find('input, select, textarea').each(function () {
                            $(this).attr('disabled', true);
                        });
                        //}
                        uof.ui.MedicalReport.SupervisorySection();

                        $('.fakeSave').addClass('hide');
                        $("#btnReset").addClass('hide'); $("#btnSave").addClass('hide');
                        $("#btnApprove").addClass('hide'); $("#btnReject").addClass('hide');
                        if (localStorage.getItem('formMode') == "Approve") {

                            $("#btnApprove").prop('disabled', false); $("#btnApprove").removeClass('hide');
                            $("#btnReject").prop('disabled', false); $("#btnReject").removeClass('hide');
                            uof.ui.MedicalReport.viewModel.IsSupervisorOrApprover(true);
                            $(".fakeclass").removeClass('hide');
                            $("#txtReject").attr('disabled', false);
                            //$('#divApproval:first > *').find('input').each(function () {
                            //    $(this).attr('disabled', false);
                            //});
                            //uof.ui.SupplementalReport.Redtip.validateControls();

                        }
                    }
                    else {
                        $("#btnApprove").addClass('hide'); $("#btnReject").addClass('hide');
                        if (!uof.ui.MedicalReport.viewModel.IsFormOwner() && (uof.ui.MedicalReport.viewModel.IsSupervisorStatus() == "pending" || uof.ui.MedicalReport.viewModel.IsSupervisorStatus() == "rejected")) {
                            //if (isDisable)  {
                            $("#vertical-tabs *").find('input, select, textarea').each(function () {
                                $(this).attr('disabled', true);
                            });
                            uof.ui.MedicalReport.SupervisorySection();
                            uof.ui.MedicalReport.MedicalSection();
                            //}
                            $("#btnReset").addClass('hide'); $("#btnSave").addClass('hide');
                            $("#btnApprove").addClass('hide'); $("#btnReject").addClass('hide');
                            if (localStorage.getItem('formMode') == "View") {
                                $('.fakeSave').addClass('hide');
                            }
                            if (localStorage.getItem('formMode') == "Approve") {
                                $('.fakeSave').addClass('hide');
                                $("#btnApprove").prop('disabled', false); $("#btnApprove").removeClass('hide');
                                $("#btnReject").prop('disabled', false); $("#btnReject").removeClass('hide');
                                uof.ui.MedicalReport.viewModel.IsSupervisorOrApprover(true);
                                $(".fakeclass").removeClass('hide');
                                $("#txtReject").attr('disabled', false);
                                $("#divApproval").css({ style: "display:block" });
                                $('#divApproval:first > *').find('input').each(function () {
                                    $(this).attr('disabled', false);
                                });
                                $("#SupervisorInfo").css({ style: "display:block" });
                                $('#SupervisorInfo:first > *').find('input,textarea').each(function () {
                                    $(this).attr('disabled', false);
                                });

                            }
                        }
                        else if (localStorage.getItem('formMode') == "View")
                        {
                            $("#vertical-tabs *").find('input, select, textarea').each(function () {
                                $(this).attr('disabled', true);
                            });
                            //}
                            $('.fakeSave').addClass('hide');
                            $("#btnReset").addClass('hide'); $("#btnSave").addClass('hide');
                            $("#btnApprove").addClass('hide'); $("#btnReject").addClass('hide');
                        }
                    }
                }
                uof.ui.MedicalReport.MedicalSection();
            },
            MedicalSection: function () {
                if (UoFParams.userRole == "MED" || UoFParams.userRank == "9") {
                    uof.ui.MedicalReport.redirecttoValidationScreen("anchorMedical");
                    $("#vertical-tabs *").find('input, select, textarea').each(function () {
                        $(this).attr('disabled', true);
                    });
                    $('.fakeSave').addClass('hide');
                    $("#btnReset").addClass('hide'); $("#btnSave").addClass('hide');
                    $("#btnApprove").addClass('hide'); $("#btnReject").addClass('hide');
                    if (uof.ui.MedicalReport.viewModel.IsSupervisorStatus() != "pending")
                        $("#btnMedicalSave").addClass("hide");
                    else
                        $("#btnMedicalSave").removeClass("hide");
                    if (localStorage.getItem('formMode') != "Approve") {
                        if ($("#EvaluatedEmployeeNumber").val() == "") {
                            $("#MedicalInfo *").find('input, select, textarea').each(function () {
                                $(this).attr('disabled', false);
                            });
                            $("#btnMedicalSave").removeClass("hide");
                        }
                    }
                   
                }
            },
            SupervisorySection: function () {
                if (UoFParams.userRank == "2") {
                    if ($("#SupervisorEmployeeNumber").val() == "") {
                        $("#SupervisorInfo *").find('input, select, textarea').each(function () {
                            $(this).attr('disabled', false);
                        });
                    }
                }
                if (UoFParams.userRank == "3") {
                    if ($("#EmployeeNumber").val() == "") {
                        $("#divApproval *").find('input, select, textarea').each(function () {
                            $(this).attr('disabled', false);
                        });
                    }
                }
            },
            buildMedicalDataObject: function (isApprove) {
                var oMedicalData = new Object();
                oMedicalData.IncidentId = uof.ui.MedicalReport.viewModel.IncidentID();
                oMedicalData.FormId = uof.ui.MedicalReport.viewModel.FormID();
                oMedicalData.DeputyEmpId = uof.ui.MedicalReport.viewModel.EmpId();
                oMedicalData.isApprove = isApprove;
                oMedicalData.ReviewerReviewId = UoFParams.userId;
                oMedicalData.ReviewerRole = UoFParams.userRole;
                oMedicalData.Comment = uof.ui.MedicalReport.viewModel.DiagnosisInformation.RejectComments();
                oMedicalData.IncidentReviewId = uof.ui.MedicalReport.viewModel.IncidentReviewId();
                return oMedicalData;
            },
            approveMedicalDetails: function (isApprove) {
                if (uof.ui.MedicalReport.validateMedicalReportFieldsonApprove(isApprove == "Y" ? true : false)) {
                    var str = isApprove == "Y" ? "Do you want to Approve?" : "Do you want to Reject?";
                    $.when(showConfirmationWindow(str)).then(function (confirmed) {
                        if (confirmed) {
                            if (isApprove == "Y") {
                                if (uof.ui.MedicalReport.viewModel.IsOnlyApproval() == true)
                                    uof.ui.MedicalReport.saveMedicalReportInfo(isApprove == "Y" ? true : false, false);
                                else {
                                    var oMedicalData = uof.ui.MedicalReport.buildMedicalDataObject(isApprove);
                                    var mappedData = ko.mapping.toJS(oMedicalData);
                                    $.ajax(
                                        {
                                            url: window.location.uofAPIOrigin() + '/api/UOFForm/ApproveorReject',
                                            cache: false,
                                            type: "POST",
                                            dataType: 'json',
                                            data: JSON.stringify(mappedData),
                                            contentType: "application/json;charset=utf-8",
                                            beforeSend: function myfunction() {

                                            },
                                            success: function (data) {
                                                $.prototype.hideUofOverlay();
                                                showAlert((isApprove == "Y" ? "Approved" : "Rejected") + " Succesfully");
                                                uof.ui.MedicalReport.setApprovedIncidentinSession(oMedicalData.IncidentId);
                                                //window.location.href = window.location.uofUIOrigin() + '/Incident/Incident';
                                            },
                                            error: function (e) {
                                                $.prototype.hideUofOverlay();
                                                showAlert(e.responseText);
                                            },
                                        });
                                }
                            }
                            else {
                                var oMedicalData = uof.ui.MedicalReport.buildMedicalDataObject(isApprove);
                                var mappedData = ko.mapping.toJS(oMedicalData);
                                $.ajax(
                                    {
                                        url: window.location.uofAPIOrigin() + '/api/UOFForm/ApproveorReject',
                                        cache: false,
                                        type: "POST",
                                        dataType: 'json',
                                        data: JSON.stringify(mappedData),
                                        contentType: "application/json;charset=utf-8",
                                        beforeSend: function myfunction() {

                                        },
                                        success: function (data) {
                                            $.prototype.hideUofOverlay();
                                            showAlert((isApprove == "Y" ? "Approved" : "Rejected") + " Succesfully");
                                            uof.ui.MedicalReport.setApprovedIncidentinSession(oMedicalData.IncidentId);
                                        },
                                        error: function (e) {
                                            $.prototype.hideUofOverlay();
                                            showAlert(e.responseText);
                                        },
                                    });
                            }
                        }
                    });

                }
            },
            setApprovedIncidentinSession: function (incidentId) {
                $.ajax(
                     {
                         url: window.location.uofUIOrigin() + '/Incident/setApprovedIncident',
                         type: "POST",
                         data: { incidentID: incidentId },
                         success: function (data) {
                             if (data == "true")
                                 window.location.href = window.location.uofUIOrigin() + '/Incident/Incident';
                         },
                         error: function (e) {
                             showAlert(e.responseText);
                         },
                     });
            },
            GetRace: function () {
                $.prototype.showUofOverlay();
                $.ajax(
                {
                    url: window.location.uofAPIOrigin() + '/api/Lookup/GetRacies',
                    cache: false,
                    type: "GET",
                    dataType: 'json',
                    contentType: "application/json;charset=utf-8",
                    beforeSend: function myfunction() {

                    },
                    success: function (lookupData) {
                        $('#IncMedicalRace').selectpicker('destroy')
                        uof.ui.MedicalReport.viewModel.Race([]);
                        uof.ui.MedicalReport.viewModel.Race(lookupData);
                        uof.ui.MedicalReport.viewModel.Race.valueHasMutated();
                        $('#IncMedicalRace').selectpicker('refresh')
                        $.prototype.hideUofOverlay();
                    },
                    error: function (e) {
                        showAlert(e.responseText);
                    },
                });
            },
            GetSex: function () {
                $.prototype.showUofOverlay();
                $.ajax(
                {
                    url: window.location.uofAPIOrigin() + '/api/Lookup/GetGender',
                    cache: false,
                    type: "GET",
                    dataType: 'json',
                    contentType: "application/json;charset=utf-8",
                    beforeSend: function myfunction() {

                    },
                    success: function (lookupData) {
                        uof.ui.MedicalReport.viewModel.Sex(lookupData);
                        $('#IncSex').selectpicker('refresh');
                        $.prototype.hideUofOverlay();
                    },
                    error: function (e) {
                        showAlert(e.responseText);
                    },
                });
            },
            initiateBindings: function () {
                if (UoFParams.IncidentURN != "") {
                    uof.ui.MedicalReport.viewModel.UniformInformation.URN(UoFParams.IncidentURN);
                    uof.ui.MedicalReport.viewModel.SupervisorInformation.SupervisoryURN(UoFParams.IncidentURN);
                    uof.ui.MedicalReport.viewModel.UniformInformation.ReferenceNumber(UoFParams.ReferenceNo);
                    uof.ui.MedicalReport.viewModel.SupervisorInformation.SupReferenceNumber(UoFParams.ReferenceNo);
                    uof.ui.MedicalReport.viewModel.IncidentInformation.IncidentLocation(uof.ui.MedicalReport.viewModel.IncidentInformation.IncidentLocation() == "" ? UoFParams.IncidentLocation : uof.ui.MedicalReport.viewModel.IncidentInformation.IncidentLocation());
                    uof.ui.MedicalReport.viewModel.SupervisorInformation.UnderFileNumber(UoFParams.IncidentURN);
                }
                if (UoFParams.IncidentDate != "")
                    uof.ui.MedicalReport.viewModel.IncidentInformation.IncidentDate(UoFParams.IncidentDate);
                if (UoFParams.WC.length > 6) {
                    uof.ui.MedicalReport.viewModel.DiagnosisInformation.EmployeeNumber(UoFParams.WC.split('-')[0]);
                    uof.ui.MedicalReport.viewModel.DiagnosisInformation.WatchCommander(UoFParams.WC.split('-')[1]);
                }
                if (UoFParams.InvestSupervisor.length > 6) {
                    uof.ui.MedicalReport.viewModel.SupervisorInformation.AllegedUOFHandledby(UoFParams.InvestSupervisor.split('-')[0]);
                    uof.ui.MedicalReport.viewModel.SupervisorInformation.AllegedUOFHandledbyName(UoFParams.InvestSupervisor.split('-')[1]);
                }

                ko.validation.insertValidationMessage = function (element) {
                    var br = document.createElement("br");
                    element.appendChild(br);
                    var span = document.createElement('SPAN');
                    span.className = "warning-msg";
                    var inputGroups = $(element).closest(".date"); //This is for getting Date Fields
                    if (inputGroups.length > 0) {
                        // We're in an input-group so we place the message after
                        // the group rather than inside it in order to not break the design
                        $(span).insertAfter(inputGroups);
                    }
                    else {
                        // The default in knockout-validation
                        element.parentNode.insertBefore(span, element.nextSibling);
                    }
                    return span;
                };
                $("#ReferenceNumber").focus();
                //$("#anchorInmate").keyup(function (e) {
                //    if ($.hotkeys.enter(e)) {
                //        uof.ui.MedicalReport.validateUniformInformation('anchorInmate');
                //    }
                //});
                //$("#anchorUniform").keyup(function (e) {
                //    if ($.hotkeys.enter(e)) {
                //        uof.ui.MedicalReport.redirecttoValidationScreen('anchorUniform');
                //    }
                //});
                //$("#anchorIncident").keyup(function (e) {
                //    if ($.hotkeys.enter(e)) {
                //        uof.ui.MedicalReport.validateInmate('anchorIncident');
                //    }
                //});


            },
            initiatePickers: function () {

                $('#InmateReturnedDate').datetimepicker({ format: 'MM/DD/YYYY' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.MedicalReport.viewModel.EscortInformation.InmateReturnedDate(newDate);
                });

                $('#DOB').datetimepicker({ format: 'MM/DD/YYYY' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.MedicalReport.viewModel.InmateInformation.InmateDOB(newDate);
                    uof.ui.MedicalReport.viewModel.InmateInformation.InmateAge(uof.ui.CommonUILogic.detail.agefinding(newDate));
                });
                $('#supDate').datetimepicker({ format: 'MM/DD/YYYY' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.MedicalReport.viewModel.SupervisorInformation.SupervisorAssesmentDate(newDate);
                });
                $('#IntiatedDate').datetimepicker({ format: 'MM/DD/YYYY' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.MedicalReport.viewModel.IncidentInformation.IntiatedDate(newDate);
                });
                $('#DateEval').datetimepicker({ format: 'MM/DD/YYYY' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.MedicalReport.viewModel.MedicalInformation.DateEvaluated(newDate);
                });
                $('#DateTreated').datetimepicker({ format: 'MM/DD/YYYY' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.MedicalReport.viewModel.DiagnosisInformation.OutsideDateTreated(newDate);
                });
                $('#Incdate').datetimepicker({ format: 'MM/DD/YYYY' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.MedicalReport.viewModel.IncidentInformation.IncidentDate(newDate);
                });
                $('#EscortOn').datetimepicker({ format: 'MM/DD/YYYY' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.MedicalReport.viewModel.EscortInformation.EscortedDate(newDate);
                });
                $('#EstedDate').datetimepicker({ format: 'MM/DD/YYYY' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.MedicalReport.viewModel.EscortInformation.EstedDate(newDate);
                });

                $('#InmateTreatedDate').datetimepicker({ format: 'MM/DD/YYYY' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.MedicalReport.viewModel.EscortInformation.InmateTreatedDate(newDate);
                });
                $('#InmateReturnedDate').datetimepicker({ format: 'MM/DD/YYYY' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.MedicalReport.viewModel.EscortInformation.InmateReturnedDate(newDate);
                });
                $('#IncidentTime').on('keydown', function (e) {
                    if (e.keyCode == 9) {
                        $(this).timepicker('hideWidget');
                    }
                });
                $('#EscortTime').on('keydown', function (e) {
                    if (e.keyCode == 9) {
                        $(this).timepicker('hideWidget');
                    }
                });
                $('#EstTime').on('keydown', function (e) {
                    if (e.keyCode == 9) {
                        $(this).timepicker('hideWidget');
                    }
                });
                $('#EscortedTime').on('keydown', function (e) {
                    if (e.keyCode == 9) {
                        $(this).timepicker('hideWidget');
                    }
                });
                $('#EstedTime').on('keydown', function (e) {
                    if (e.keyCode == 9) {
                        $(this).timepicker('hideWidget');
                    }
                });

                $('#InmateTreatedTime').on('keydown', function (e) {
                    if (e.keyCode == 9) {
                        $(this).timepicker('hideWidget');
                    }
                });
                $('#InmateReturnedTime').on('keydown', function (e) {
                    if (e.keyCode == 9) {
                        $(this).timepicker('hideWidget');
                    }
                });
                $('#SupervisorAssesmentTime').on('keydown', function (e) {
                    if (e.keyCode == 9) {
                        $(this).timepicker('hideWidget');
                    }
                });
                $('#TimeEvaluated').on('keydown', function (e) {
                    if (e.keyCode == 9) {
                        $(this).timepicker('hideWidget');
                    }
                });
                $('#OutsideTimeTreated').on('keydown', function (e) {
                    if (e.keyCode == 9) {
                        $(this).timepicker('hideWidget');
                    }
                });
                $(".timepicker").attr("maxlength", 4);
                $(".timepicker").timepicker({
                    showInputs: false,
                    showMeridian: false,
                    minuteStep: 1
                });
            },
            saveMedicalReportDetails: function () {
                if (UoFParams.userRole == "MED" || UoFParams.userRank == "9") {
                    uof.ui.MedicalReport.viewModel.isMedical(true);
                    if (uof.ui.MedicalReport.validateMedical()) {
                        $.when(showConfirmationWindow('Do you want to submit the for the review ? ')).then(function (confirmed) {
                            if (confirmed)
                                uof.ui.MedicalReport.saveMedicalReportInfo(false, false);
                        });
                    }
                }
                else {
                    if (uof.ui.MedicalReport.validateMedicalReportFields()) {
                        $.when(showConfirmationWindow('Do you want to submit the for the review ? ')).then(function (confirmed) {
                            if (confirmed)
                                uof.ui.MedicalReport.saveMedicalReportInfo(false, false);
                        });

                    }
                }
            },
            saveMedicalReportInfo: function (isApproval, IsOnlySave) {
                //Placeholder for calling API method to save MedicalReport Report data
                //Save Method
                uof.ui.MedicalReport.viewModel.IsOnlySave(IsOnlySave);
                uof.ui.MedicalReport.viewModel.FormID($.UoFformId);
                uof.ui.MedicalReport.viewModel.EmpId(UoFParams.userId);
                uof.ui.MedicalReport.viewModel.UserRole(UoFParams.userRole);

                if ($.IncidentId.length > 0)
                    uof.ui.MedicalReport.viewModel.IncidentID($.IncidentId);
                else
                    uof.ui.MedicalReport.viewModel.IncidentID(UoFParams.IncidentId);

                if (uof.ui.MedicalReport.viewModel.InmateInformation.InmateRace() != null) {
                    uof.ui.MedicalReport.viewModel.InmateInformation.InmateRace(uof.ui.MedicalReport.viewModel.InmateInformation.InmateRace().toString());
                }

                var jsonDate = ko.mapping.toJS(uof.ui.MedicalReport.viewModel);
                //if (jsonDate.InmateInformation.InmateRace != null) {
                //    jsonDate.InmateInformation.InmateRace = jsonDate.InmateInformation.InmateRace.join
                //    jsonDate.InmateInformation.InmateRace = jsonDate.InmateInformation.InmateRace.toString();
                //}
                jsonDate.isApproval = isApproval;

                $.prototype.showUofOverlay();
                $.ajax(
                  {
                      url: window.location.uofAPIOrigin() + '/api/UOFForm/SaveMedicalReport',
                      cache: false,
                      type: "POST",
                      dataType: 'json',
                      data: JSON.stringify(jsonDate),
                      contentType: "application/json;charset=utf-8",
                      beforeSend: function myfunction() {

                      },
                      success: function (data) {
                          $.prototype.hideUofOverlay();
                          localStorage.setItem('formMode', ""); //Setting the formode to null.
                          if (isApproval) {
                              showAlert("Approve Successfully");
                              uof.ui.MedicalReport.setApprovedIncidentinSession(UoFParams.IncidentId);
                          }
                          else {
                              uof.ui.MedicalReport.viewModel.FormDataId(data);
                              showAlert(IsOnlySave ? "Data saved successfully" : "submited successfully");
                          }
                      },
                      error: function (e) {
                          $.prototype.hideUofOverlay();
                          showAlert(e.responseText);
                      },
                  });
            },
            //$("#IncRace").selectpicker('destroy');
            //if (uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Race()!= null)
            //uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Race = ko.observableArray(uof.ui.InvolvedEmployee.viewModel.InvolvedEmployee.Race().split(','));

            subscribeMethod: function () {


                uof.ui.MedicalReport.viewModel.SupervisorInformation.SupervisorEmployeeNumber.subscribe(function (newValue) {
                //    if ($.trim(newValue) != "") {
                //        if (newValue == uof.ui.MedicalReport.viewModel.SupervisorInformation.AllegedUOFHandledby()) {
                //            showAlert("Already entered this employee , please enter different one");
                //            uof.ui.MedicalReport.viewModel.SupervisorInformation.SupervisorEmployeeNumber(null);
                //            uof.ui.MedicalReport.viewModel.SupervisorInformation.SupervisorName(null);
                //            return false;
                //        }
                //    }
                //});
                //uof.ui.MedicalReport.viewModel.SupervisorInformation.AllegedUOFHandledby.subscribe(function (newValue) {
                //    if ($.trim(newValue) != "") {
                //        if (newValue == uof.ui.MedicalReport.viewModel.SupervisorInformation.SupervisorEmployeeNumber()) {
                //            showAlert("Already entered this employee , please enter different one");
                //            uof.ui.MedicalReport.viewModel.SupervisorInformation.AllegedUOFHandledby(null);
                //            uof.ui.MedicalReport.viewModel.SupervisorInformation.AllegedUOFHandledbyName(null);
                //            return false;
                //        }
                //    }
                //});

                uof.ui.MedicalReport.viewModel.EscortInformation.EscortNumber.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        if (newValue == uof.ui.MedicalReport.viewModel.EscortInformation.EstNumber()) {
                            showAlert("Already entered this employee , please enter different one");
                            uof.ui.MedicalReport.viewModel.EscortInformation.EscortNumber(null);
                            uof.ui.MedicalReport.viewModel.EscortInformation.EscortNameAndNumber(null);
                            return false;
                        }
                    }
                });
                uof.ui.MedicalReport.viewModel.EscortInformation.EstNumber.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        if (newValue == uof.ui.MedicalReport.viewModel.EscortInformation.EscortNumber()) {
                            showAlert("Already entered this employee , please enter different one");
                            uof.ui.MedicalReport.viewModel.EscortInformation.EstNumber(null);
                            uof.ui.MedicalReport.viewModel.EscortInformation.EstNameAndNumber(null);
                            return false;
                        }
                    }
                });
                uof.ui.MedicalReport.viewModel.EscortInformation.EscortedNumber.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        if (newValue == uof.ui.MedicalReport.viewModel.EscortInformation.EstedNumber()) {
                            showAlert("Already entered this employee , please enter different one");
                            uof.ui.MedicalReport.viewModel.EscortInformation.EscortedNumber(null);
                            uof.ui.MedicalReport.viewModel.EscortInformation.EscortedNameAndNumber(null);
                            return false;
                        }
                    }
                });
                uof.ui.MedicalReport.viewModel.EscortInformation.EstedNumber.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        if (newValue == uof.ui.MedicalReport.viewModel.EscortInformation.EscortedNumber()) {
                            showAlert("Already entered this employee , please enter different one");
                            uof.ui.MedicalReport.viewModel.EscortInformation.EstedNumber(null);
                            uof.ui.MedicalReport.viewModel.EscortInformation.EstedNameAndNumber(null);
                            return false;
                        }
                    }
                });
                uof.ui.MedicalReport.viewModel.EscortInformation.InmateOther.subscribe(function (newValue) {
                    $("#OtherReason").prop("disabled", true);
                    if ($.trim(newValue) != "false") {
                        uof.ui.MedicalReport.viewModel.EscortInformation.InmateOtherReason.valueHasMutated();
                    }
                    else {
                        uof.ui.MedicalReport.viewModel.EscortInformation.InmateOtherReason(null);
                        uof.ui.MedicalReport.viewModel.EscortInformation.InmateOtherReason.isModified(false);
                    }
                });

                uof.ui.MedicalReport.viewModel.InmateInformation.InmateSegregation.subscribe(function (newValue) {
                    if (newValue) {
                        uof.ui.MedicalReport.viewModel.InmateInformation.InmateSegregationReason.valueHasMutated();
                        return false;
                    }
                    else if (!newValue)
                        uof.ui.MedicalReport.viewModel.InmateInformation.InmateSegregationReason(null);
                });

                uof.ui.MedicalReport.viewModel.EscortInformation.InmateEscorted.subscribe(function (newValue) {
                    if (newValue) {
                        uof.ui.MedicalReport.viewModel.EscortInformation.EscortFacility.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.EscortInformation.EscortNumber.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.EscortInformation.EscortTime.valueHasMutated();
                        return false;
                    }
                });
                uof.ui.MedicalReport.viewModel.EscortInformation.InmateTransported.subscribe(function (newValue) {
                    if (newValue) {
                        uof.ui.MedicalReport.viewModel.EscortInformation.TransportedHospital.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.EscortInformation.TransportedMedia.valueHasMutated();

                        uof.ui.MedicalReport.viewModel.EscortInformation.EscortedNumber.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.EscortInformation.EscortedDate.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.EscortInformation.InmateTreatedby.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.EscortInformation.InmateTreatedDate.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.EscortInformation.InmateReturnedFacility.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.EscortInformation.InmateReturnedDate.valueHasMutated();
                        return false;
                    }
                });
                uof.ui.MedicalReport.viewModel.DiagnosisInformation.sec.subscribe(function (newValue) {
                    if (newValue) {
                        uof.ui.MedicalReport.viewModel.DiagnosisInformation.OutsideEmployeeNumber.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.DiagnosisInformation.OutsideTreatedBy.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.DiagnosisInformation.OutsideDateTreated.valueHasMutated();
                        return false;
                    }
                });
                uof.ui.MedicalReport.viewModel.DiagnosisInformation.OutsideAppearsYes.subscribe(function (newValue) {
                    if (newValue) {
                        uof.ui.MedicalReport.viewModel.DiagnosisInformation.OutsideAppearsNo(false);
                        uof.ui.MedicalReport.viewModel.DiagnosisInformation.OutsideDescription.valueHasMutated();
                        return false;
                    }
                    else if (!newValue)
                        uof.ui.MedicalReport.viewModel.DiagnosisInformation.OutsideDescription(null);
                });
                uof.ui.MedicalReport.viewModel.DiagnosisInformation.OutsideAppearsNo.subscribe(function (newValue) {
                    if (newValue) {
                        uof.ui.MedicalReport.viewModel.DiagnosisInformation.OutsideAppearsYes(false);
                        uof.ui.MedicalReport.viewModel.DiagnosisInformation.OutsideDescription(null);
                        return false;
                    }
                })
            },
            validateControls: function () {

                uof.ui.MedicalReport.viewModel.EscortInformation.InmateOtherReason.extend({
                    required: {
                        params: true,
                        message: "InmateOtherReason " + UoFMedicalReportConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.MedicalReport.viewModel.EscortInformation.InmateOtherReason() === true)
                        }
                    }
                });
                //URN
                uof.ui.MedicalReport.viewModel.UniformInformation.URN.extend({
                    required: {
                        params: true,
                        message: "URN " + UoFMedicalReportConstants.Required
                        //message:"Required"
                    }
                });
                //uof.ui.MedicalReport.viewModel.UniformInformation.ReferenceNumber.extend({
                //    required: {
                //        params: true,
                //        message: UoFMedicalReportConstants.Required
                //        //message:"Required"
                //    },
                //    pattern: {
                //        params: "^[a-zA-Z0-9 _@#-.~!$%&()={}^]+$",
                //        message: UoFMedicalReportConstants.ReferenceNumber + ' \\ / : * ? ` ; " < > | [ ]'
                //        //message: "Required " + ' \\ / : * ? ` ; " < > | [ ]'
                //    },
                //    maxLength: {
                //        params: 100,
                //        message: 'ReferenceNumber maximum character should be 100 only.'
                //    },
                //});

                //uof.ui.MedicalReport.viewModel.InmateInformation.InmateName.extend({
                //    required: {
                //        params: true,
                //        message: UoFMedicalReportConstants.Required
                //        //message:"Required"
                //    },
                //    pattern: {
                //        params: "^[a-zA-Z0-9 _@#-.~!$%&()={}^]+$",
                //        message: UoFMedicalReportConstants.InmateName + ' \\ / : * ? ` ; " < > | [ ]'
                //        //message: "Required " + ' \\ / : * ? ` ; " < > | [ ]'
                //    },
                //    maxLength: {
                //        params: 100,
                //        message: 'InmateName  maximum character should be 100 only.'
                //    },
                //});
                uof.ui.MedicalReport.viewModel.InmateInformation.BookingNumber.extend({
                    required: {
                        params: true,
                        message: "Booking Number " + UoFMedicalReportConstants.Required
                        //message:"Required"
                    }
                });

                //uof.ui.MedicalReport.viewModel.InmateInformation.InmateRace.extend({
                //    required: {
                //        params: true,
                //        message: UoFMedicalReportConstants.Required
                //        //message:"Required"
                //    }
                //});
                //uof.ui.MedicalReport.viewModel.InmateInformation.InmateDOB.extend({
                //    required: {
                //        params: true,
                //        message: UoFMedicalReportConstants.Required
                //        //message:"Required"
                //    }
                //});
                //uof.ui.MedicalReport.viewModel.InmateInformation.HousingFacility.extend({
                //    required: {
                //        params: true,
                //        message: UoFMedicalReportConstants.Required
                //        //message:"Required"
                //    },
                //    pattern: {
                //        params: "^[a-zA-Z0-9 _@#-.~!$%&()={}^]+$",
                //        message: UoFMedicalReportConstants.HousingFacility + ' \\ / : * ? ` ; " < > | [ ]'
                //        //message: "Required " + ' \\ / : * ? ` ; " < > | [ ]'
                //    },
                //    maxLength: {
                //        params: 100,
                //        message: 'HousingFacility maximum character should be 100 only.'
                //    },
                //});

                //uof.ui.MedicalReport.viewModel.InmateInformation.InmateSegregationReason.extend({
                //    required: {
                //        params: true,
                //        message: UoFMedicalReportConstants.Required, onlyIf: function () {
                //            return (uof.ui.MedicalReport.viewModel.InmateInformation.InmateSegregation() === true);
                //        }
                //        //message:"Required"
                //    },

                //});
                uof.ui.MedicalReport.viewModel.IncidentInformation.IncidentLocation.extend({
                    required: {
                        params: true,
                        message: "Incident Location " + UoFMedicalReportConstants.Required
                        //message:"Required"
                    }
                });
                uof.ui.MedicalReport.viewModel.IncidentInformation.IncidentTypeOfLocation.extend({
                    required: {
                        params: true,
                        message: "Type of location " + UoFMedicalReportConstants.Required
                        //message:"Required"
                    }
                });
                uof.ui.MedicalReport.viewModel.IncidentInformation.IncidentDate.extend({
                    required: {
                        params: true,
                        message: "Date " + UoFMedicalReportConstants.Required
                        //message:"Required"
                    }
                });
                uof.ui.MedicalReport.viewModel.IncidentInformation.IncidentTime.extend({
                    required: {
                        params: true,
                        message: UoFMedicalReportConstants.Required
                        //message:"Required"
                    }
                });
                uof.ui.MedicalReport.viewModel.EscortInformation.EscortFacility.extend({
                    required: {
                        params: true,
                        message: UoFMedicalReportConstants.Required, onlyIf: function () {
                            return (uof.ui.MedicalReport.viewModel.EscortInformation.InmateEscorted() === true);
                        }
                        //message:"Required"
                    }
                });
                uof.ui.MedicalReport.viewModel.EscortInformation.EscortNumber.extend({
                    required: {
                        params: true,
                        message: UoFMedicalReportConstants.Required, onlyIf: function () {
                            return (uof.ui.MedicalReport.viewModel.EscortInformation.InmateEscorted() === true);
                        }
                    }
                });
                uof.ui.MedicalReport.viewModel.EscortInformation.EscortTime.extend({
                    required: {
                        params: true,
                        message: UoFMedicalReportConstants.Required, onlyIf: function () {
                            return (uof.ui.MedicalReport.viewModel.EscortInformation.InmateEscorted() === true);
                        }
                        //message:"Required"
                    }
                });
                uof.ui.MedicalReport.viewModel.EscortInformation.TransportedHospital.extend({
                    required: {
                        params: true,
                        message: UoFMedicalReportConstants.Required, onlyIf: function () {
                            return (uof.ui.MedicalReport.viewModel.EscortInformation.InmateTransported() === true);
                        }
                        //message:"Required"
                    }
                });
                uof.ui.MedicalReport.viewModel.EscortInformation.TransportedMedia.extend({
                    required: {
                        params: true,
                        message: UoFMedicalReportConstants.Required, onlyIf: function () {
                            return (uof.ui.MedicalReport.viewModel.EscortInformation.InmateTransported() === true);
                        }
                        //message:"Required"
                    }
                });
                uof.ui.MedicalReport.viewModel.EscortInformation.EscortedNumber.extend({
                    required: {
                        params: true,
                        message: UoFMedicalReportConstants.Required, onlyIf: function () {
                            return (uof.ui.MedicalReport.viewModel.EscortInformation.InmateTransported() === true);
                        }
                        //message:"Required"
                    }
                });
                uof.ui.MedicalReport.viewModel.EscortInformation.EscortedDate.extend({
                    required: {
                        params: true,
                        message: UoFMedicalReportConstants.Required, onlyIf: function () {
                            return (uof.ui.MedicalReport.viewModel.EscortInformation.InmateTransported() === true);
                        }
                        //message:"Required"
                    }
                });
                uof.ui.MedicalReport.viewModel.EscortInformation.EscortedTime.extend({
                    required: {
                        params: true,
                        message: UoFMedicalReportConstants.Required
                        //message:"Required"
                    }
                });
                uof.ui.MedicalReport.viewModel.EscortInformation.InmateTreatedby.extend({
                    required: {
                        params: true,
                        message: UoFMedicalReportConstants.Required, onlyIf: function () {
                            return (uof.ui.MedicalReport.viewModel.EscortInformation.InmateTransported() === true);
                        }
                        //message:"Required"
                    }
                });
                uof.ui.MedicalReport.viewModel.EscortInformation.InmateTreatedDate.extend({
                    required: {
                        params: true,
                        message: UoFMedicalReportConstants.Required, onlyIf: function () {
                            return (uof.ui.MedicalReport.viewModel.EscortInformation.InmateTransported() === true);
                        }
                        //message:"Required"
                    }
                });
                uof.ui.MedicalReport.viewModel.EscortInformation.InmateTreatedTime.extend({
                    required: {
                        params: true,
                        message: UoFMedicalReportConstants.Required
                        //message:"Required"
                    }
                });
                //uof.ui.MedicalReport.viewModel.EscortInformation.InmateReturnedFacility.extend({
                //    required: {
                //        params: true,
                //        message: UoFMedicalReportConstants.Required, onlyIf: function () {
                //            return (uof.ui.MedicalReport.viewModel.EscortInformation.InmateTransported() === true);
                //        }
                //        //message:"Required"
                //    },
                //    pattern: {
                //        params: "^[a-zA-Z0-9 _@#-.~!$%&()={}^]+$",
                //        message: UoFMedicalReportConstants.InmateReturnedFacility + ' \\ / : * ? ` ; " < > | [ ]'
                //        //message: "Required " + ' \\ / : * ? ` ; " < > | [ ]'
                //    },
                //    maxLength: {
                //        params: 100,
                //        message: 'InmateReturnedFacility maximum character should be 100 only.'
                //    },
                //});
                uof.ui.MedicalReport.viewModel.EscortInformation.InmateReturnedDate.extend({
                    required: {
                        params: true,
                        message: UoFMedicalReportConstants.Required, onlyIf: function () {
                            return (uof.ui.MedicalReport.viewModel.EscortInformation.InmateTransported() === true);
                        }
                        //message:"Required"
                    }
                });
                uof.ui.MedicalReport.viewModel.EscortInformation.InmateReturnedTime.extend({
                    required: {
                        params: true,
                        message: UoFMedicalReportConstants.Required
                        //message:"Required"
                    }
                });

                //uof.ui.MedicalReport.viewModel.SupervisorInformation.SupervisorName.extend({
                //    required: {
                //        params: true,
                //        message: UoFMedicalReportConstants.Required
                //        //message:"Required"
                //    }
                //});

                uof.ui.MedicalReport.viewModel.SupervisorInformation.SupervisorEmployeeNumber.extend({
                    required: {
                        params: true,
                        message: "SupervisorEmployeeNumber " + UoFMedicalReportConstants.Required,
                        onlyIf: function () {
                            return (UoFParams.userRank == "2" || UoFParams.userRank == "3")
                            // return uof.ui.SupervisorInformation.EnableValidation
                        }
                    },
                });
                uof.ui.MedicalReport.viewModel.SupervisorInformation.SupervisorAssesmentDate.extend({
                    required: {
                        params: true,
                        message: UoFMedicalReportConstants.Required,
                        onlyIf: function () {
                            return (UoFParams.userRank == "2" || UoFParams.userRank == "3")
                        }
                    },
                });
                uof.ui.MedicalReport.viewModel.SupervisorInformation.SupervisorAssesmentTime.extend({
                    required: {
                        params: true,
                        message: UoFMedicalReportConstants.Required,
                        onlyIf: function () {
                            return (UoFParams.userRank == "2" || UoFParams.userRank == "3")
                        }
                    },
                });
                uof.ui.MedicalReport.viewModel.SupervisorInformation.OtherForce.extend({
                    required: {
                        params: true,
                        message: "Please enter Others",
                        onlyIf: function () {
                            return (uof.ui.MedicalReport.viewModel.SupervisorInformation.ChemicalAgent() === false && uof.ui.MedicalReport.viewModel.SupervisorInformation.ControlHolds() === false && uof.ui.MedicalReport.viewModel.SupervisorInformation.Takedown() === false && uof.ui.MedicalReport.viewModel.SupervisorInformation.PersonalWeapons() === false
                                && uof.ui.MedicalReport.viewModel.SupervisorInformation.TaserApplication() === false && uof.ui.MedicalReport.viewModel.SupervisorInformation.ImpactWeapon() === false && uof.ui.MedicalReport.viewModel.SupervisorInformation.Stunbag() === false
                                && uof.ui.MedicalReport.viewModel.SupervisorInformation.PepperballGun() === false && uof.ui.MedicalReport.viewModel.SupervisorInformation.CarotidRestraint() === false && uof.ui.MedicalReport.viewModel.SupervisorInformation.k9() === false
                                & uof.ui.MedicalReport.viewModel.SupervisorInformation.Firearm() === false && (UoFParams.userRank == "2" || UoFParams.userRank == "3"));
                        }

                    }
                });
                uof.ui.MedicalReport.viewModel.SupervisorInformation.BriefDescription.extend({
                    required: {
                        params: true,
                        message: UoFMedicalReportConstants.Required,
                        onlyIf: function () {
                            return (UoFParams.userRank == "2" || UoFParams.userRank == "3")
                        }
                    },
                });

                uof.ui.MedicalReport.viewModel.SupervisorInformation.AllegedUOFHandledby.extend({
                    required: {
                        params: true,
                        message: UoFMedicalReportConstants.Required,
                        onlyIf: function () {
                            return (UoFParams.userRank == "2" || UoFParams.userRank == "3")
                        }
                    },
                    pattern: {
                        params: "^[a-zA-Z0-9 _@#-.~!$%&()={}^]+$",
                        message: UoFMedicalReportConstants.AllegedUOFHandledby + ' \\ / : * ? ` ; " < > | [ ]'
                        //message: "Required " + ' \\ / : * ? ` ; " < > | [ ]'
                    }
                });

                uof.ui.MedicalReport.viewModel.SupervisorInformation.UnderFileNumber.extend({
                    required: {
                        params: true,
                        message: UoFMedicalReportConstants.Required,
                        onlyIf: function () {
                            return (UoFParams.userRank == "2" || UoFParams.userRank == "3")
                        }
                    },
                    pattern: {
                        params: "^[a-zA-Z0-9 _@#-.~!$%&()={}^]+$",
                        message: UoFMedicalReportConstants.UnderFileNumber + ' \\ / : * ? ` ; " < > | [ ]'
                        //message: "Required " + ' \\ / : * ? ` ; " < > | [ ]'
                    }
                });
                //Medical Information
                uof.ui.MedicalReport.viewModel.MedicalInformation.EvaluatedEmployeeNumber.extend({
                    required: {
                        params: true,
                        message: "EvaluatedEmployeeNumber " + UoFMedicalReportConstants.Required,
                        onlyIf: function () {
                            return (UoFParams.userRole == "MED" || UoFParams.userRank == "9")
                        }
                    }
                });
                uof.ui.MedicalReport.viewModel.MedicalInformation.DateEvaluated.extend({
                    required: {
                        params: true,
                        message: "DateEvaluated " + UoFMedicalReportConstants.Required,
                        onlyIf: function () {
                            return (UoFParams.userRole == "MED" || UoFParams.userRank == "9")
                        }
                    }
                });
                uof.ui.MedicalReport.viewModel.MedicalInformation.TimeEvaluated.extend({
                    required: {
                        params: true,
                        message: UoFMedicalReportConstants.Required,
                        onlyIf: function () {
                            return (UoFParams.userRole == "MED" || UoFParams.userRank == "9")
                        }
                    }
                });
                uof.ui.MedicalReport.viewModel.MedicalInformation.MedicalAssessment.extend({
                    required: {
                        params: true,
                        message: UoFMedicalReportConstants.Required,
                        onlyIf: function () {
                            return (UoFParams.userRole == "MED" || UoFParams.userRank == "9")
                        }
                    }
                });
                uof.ui.MedicalReport.viewModel.MedicalInformation.SprayExposureYN.extend({
                    required: {
                        params: true,
                        message: UoFMedicalReportConstants.Required,
                        onlyIf: function () {
                            return (UoFParams.userRole == "MED" || UoFParams.userRank == "9")
                        }
                    },
                });
                uof.ui.MedicalReport.viewModel.MedicalInformation.DecontaminatedYN.extend({
                    required: {
                        params: true,
                        message: UoFMedicalReportConstants.Required,
                        onlyIf: function () {
                            return (UoFParams.userRole == "MED" || UoFParams.userRank == "9")
                        }
                    },
                });
                uof.ui.MedicalReport.viewModel.MedicalInformation.FollowUpTreatmentYN.extend({
                    required: {
                        params: true,
                        message: UoFMedicalReportConstants.Required,
                        onlyIf: function () {
                            return (UoFParams.userRole == "MED" || UoFParams.userRank == "9")
                        }
                    },
                });
                uof.ui.MedicalReport.viewModel.MedicalInformation.RefusedMedicalTreatmentYN.extend({
                    required: {
                        params: true,
                        message: UoFMedicalReportConstants.Required,
                        onlyIf: function () {
                            return (UoFParams.userRole == "MED" || UoFParams.userRank == "9")
                        }
                    },
                });
                uof.ui.MedicalReport.viewModel.MedicalInformation.RefusalVideotapedYN.extend({
                    required: {
                        params: true,
                        message: UoFMedicalReportConstants.Required,
                        onlyIf: function () {
                            return (UoFParams.userRole == "MED" || UoFParams.userRank == "9")
                        }
                    },
                });

                uof.ui.MedicalReport.viewModel.DiagnosisInformation.OutsideTreatedBy.extend({
                    required: {
                        params: true,
                        message: "OutsideTreatedBy " + UoFMedicalReportConstants.Required,
                        onlyIf: function () {
                            return uof.ui.MedicalReport.viewModel.DiagnosisInformation.sec();
                        }
                        //message:"Required"
                    },

                });
                uof.ui.MedicalReport.viewModel.DiagnosisInformation.OutsideDescription.extend({
                    required: {
                        params: true,
                        message: "OutsideDescription" + UoFMedicalReportConstants.Required,
                        onlyIf: function () {
                            return uof.ui.MedicalReport.viewModel.DiagnosisInformation.OutsideAppearsYes();
                        }
                    },
                });
                uof.ui.MedicalReport.viewModel.DiagnosisInformation.OutsideEmployeeNumber.extend({
                    required: {
                        params: true,
                        message: "OutsideEmployeeNumber " + UoFMedicalReportConstants.Required,
                        onlyIf: function () {
                            return uof.ui.MedicalReport.viewModel.DiagnosisInformation.sec();
                        }
                        //message:"Required"
                    }
                });
                uof.ui.MedicalReport.viewModel.DiagnosisInformation.OutsideDateTreated.extend({
                    required: {
                        params: true,
                        message: "OutsideDateTreated " + UoFMedicalReportConstants.Required,
                        onlyIf: function () {
                            return uof.ui.MedicalReport.viewModel.DiagnosisInformation.sec();
                        }
                        //message:"Required"
                    }
                });
                uof.ui.MedicalReport.viewModel.DiagnosisInformation.OutsideTimeTreated.extend({
                    required: {
                        params: true,
                        message: UoFMedicalReportConstants.Required,
                        onlyIf: function () {
                            return "OutsideTimeTreated " + uof.ui.MedicalReport.viewModel.DiagnosisInformation.sec();
                        }
                        //message:"Required"
                    }
                });
                uof.ui.MedicalReport.viewModel.DiagnosisInformation.EmployeeNumber.extend({
                    required: {
                        params: true,
                        message: "EmployeeNumber" + UoFMedicalReportConstants.Required,
                        onlyIf: function () {
                            return (UoFParams.userRank == "3")
                        }
                    }
                });


            },
            validateMedicalReportFields: function () {
                if (!uof.ui.MedicalReport.validateUniformInformation()) {
                    uof.ui.MedicalReport.redirecttoValidationScreen("anchorUniform");
                    return false;
                }
                if (!uof.ui.MedicalReport.validateInmate()) {
                    uof.ui.MedicalReport.redirecttoValidationScreen("anchorInmate");
                    return false;
                }

                if (!uof.ui.MedicalReport.validateEscort()) {
                    uof.ui.MedicalReport.redirecttoValidationScreen("anchorEscort");
                    return false;
                }
                if (!uof.ui.MedicalReport.validateSupervisor()) {
                    uof.ui.MedicalReport.redirecttoValidationScreen("anchorSupervisor");
                    return false;
                }
                if (!uof.ui.MedicalReport.validateMedical()) {
                    uof.ui.MedicalReport.redirecttoValidationScreen("anchorMedical");
                    return false;
                }
                if (!uof.ui.MedicalReport.validateDiagnosis(null, false)) {
                    return false;
                }
                uof.ui.MedicalReport.removeActiveONSuccessValidation();
                return true;
            },

            validateMedicalReportFieldsonApprove: function (isApprove) {
                if (isApprove) {
                    if (!uof.ui.MedicalReport.validateSupervisor()) {
                        uof.ui.MedicalReport.redirecttoValidationScreen("anchorSupervisor");
                        return false;
                    }
                    if (!uof.ui.MedicalReport.validateDiagnosis(null, false)) {
                        return false;
                    }
                    return true;
                }
                return true;
            },
            removeActiveONSuccessValidation: function () {
                $("#liUniformInfo").removeClass("active");
                $("#liInmateInfo").removeClass("active");
                // $("#liIncidentInfo").removeClass("active");
                $("#liEscortInfo").removeClass("active");
                $("#liSupervisorInfo").removeClass("active");
                $("#liMedicalInfo").removeClass("active");
                $("#liDiagnosisInfo").removeClass("active");
            },
            redirecttoValidationScreen: function (anchorInfo) {
                $("#" + anchorInfo).trigger("click");
                $("#BookingNumber").focus();
                $("#IncidentLocation").focus();
                $("#ie").focus();
                $("#SupervisorEmployeeNumber").focus();
                $("#MedicalAssessment").focus();
                $("#sec").focus();
            },
            validateUniformInformation: function (obj) {
                if (UoFParams.userRank == "1") {
                    result = ko.validation.group(uof.ui.MedicalReport.viewModel.UniformInformation, { deep: true, observable: false });
                    var isValid = true;
                    if (result().length > 0) {
                        //uof.ui.MedicalReport.viewModel.UniformInformation.URN.valueHasMutated();
                        //uof.ui.MedicalReport.viewModel.UniformInformation.ReferenceNumber.valueHasMutated();
                        isValid = false;
                    }
                    result = ko.validation.group(uof.ui.MedicalReport.viewModel.IncidentInformation, { deep: true, observable: false });
                    if (result().length > 0) {
                        uof.ui.MedicalReport.viewModel.IncidentInformation.IncidentTypeOfLocation.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.IncidentInformation.IncidentLocation.valueHasMutated();
                        isValid = false;
                    }
                    if (!isValid)
                        return isValid;

                    if (obj != undefined)
                        uof.ui.MedicalReport.redirecttoValidationScreen(obj);
                    else
                        return true;
                }
                else
                    uof.ui.MedicalReport.redirecttoValidationScreen(obj);

            },
            validateInmate: function (obj) {
                if (UoFParams.userRank == "1") {
                    result = ko.validation.group(uof.ui.MedicalReport.viewModel.InmateInformation, { deep: true, observable: false });
                    if (result().length > 0) {
                        //uof.ui.MedicalReport.viewModel.InmateInformation.InmateName.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.InmateInformation.BookingNumber.valueHasMutated();
                        //uof.ui.MedicalReport.viewModel.InmateInformation.InmateAge.valueHasMutated();
                        //uof.ui.MedicalReport.viewModel.InmateInformation.InmateRace.valueHasMutated();
                        //uof.ui.MedicalReport.viewModel.InmateInformation.InmateDOB.valueHasMutated();
                        //uof.ui.MedicalReport.viewModel.InmateInformation.HousingFacility.valueHasMutated();
                        //uof.ui.MedicalReport.viewModel.InmateInformation.InmateBarrack.valueHasMutated();
                        //uof.ui.MedicalReport.viewModel.InmateInformation.InmateCell.valueHasMutated();
                        //uof.ui.MedicalReport.viewModel.InmateInformation.InmateSegregation.valueHasMutated();
                        return false;
                    }
                    if (obj != undefined)
                        uof.ui.MedicalReport.redirecttoValidationScreen(obj);
                    else
                        return true;
                }
                else
                    uof.ui.MedicalReport.redirecttoValidationScreen(obj);
            },
            validateIncident: function (obj) {
                result = ko.validation.group(uof.ui.MedicalReport.viewModel.IncidentInformation, { deep: true });
                if (result().length > 0) {
                    uof.ui.MedicalReport.viewModel.IncidentInformation.IncidentLocation.valueHasMutated();
                    uof.ui.MedicalReport.viewModel.IncidentInformation.IncidentTypeOfLocation.valueHasMutated();
                    uof.ui.MedicalReport.viewModel.IncidentInformation.IncidentDate.valueHasMutated();
                    uof.ui.MedicalReport.viewModel.IncidentInformation.IncidentTime.valueHasMutated();
                    return false;
                }
                if (obj != undefined)
                    uof.ui.MedicalReport.redirecttoValidationScreen(obj);
                else
                    return true;
            },
            validateEscort: function (obj) {
                if (UoFParams.userRank == "1") {
                    result = ko.validation.group(uof.ui.MedicalReport.viewModel.EscortInformation, { deep: true });
                    if (result().length > 0) {
                        uof.ui.MedicalReport.viewModel.EscortInformation.EscortedNumber.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.EscortInformation.EscortedDate.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.EscortInformation.EscortedTime.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.EscortInformation.InmateTreatedby.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.EscortInformation.InmateTreatedDate.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.EscortInformation.InmateTreatedTime.valueHasMutated();
                        //uof.ui.MedicalReport.viewModel.EscortInformation.InmateReturnedFacility.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.EscortInformation.InmateReturnedDate.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.EscortInformation.InmateReturnedTime.valueHasMutated();
                        return false;
                    }
                    if (obj != undefined)
                        uof.ui.MedicalReport.redirecttoValidationScreen(obj);
                    else
                        return true;
                }
                if (obj != undefined)
                    uof.ui.MedicalReport.redirecttoValidationScreen(obj);
                else
                    return true;
            },
            validateSupervisor: function (obj) {
                if (UoFParams.userRank == "2") {
                    result = ko.validation.group(uof.ui.MedicalReport.viewModel.SupervisorInformation, { deep: true });
                    if (result().length > 0) {
                        uof.ui.MedicalReport.viewModel.SupervisorInformation.SupervisorName.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.SupervisorInformation.SupervisorEmployeeNumber.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.SupervisorInformation.SupervisorAssesmentDate.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.SupervisorInformation.SupervisorAssesmentTime.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.SupervisorInformation.OtherForce.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.SupervisorInformation.AllegedUOFHandledby.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.SupervisorInformation.UnderFileNumber.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.SupervisorInformation.SupervisoryURN.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.SupervisorInformation.SupReferenceNumber.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.SupervisorInformation.BriefDescription.valueHasMutated();

                        return false;
                    }
                    if (obj != undefined)
                        uof.ui.MedicalReport.redirecttoValidationScreen(obj);
                    else
                        return true;
                }
                else
                    if (obj != undefined)
                        uof.ui.MedicalReport.redirecttoValidationScreen(obj);
                    else
                        return true;
            },
            validateMedical: function (obj) {
                if (UoFParams.userRank == "9") {
                    result = ko.validation.group(uof.ui.MedicalReport.viewModel.MedicalInformation, { deep: true });
                    if (result().length > 0) {
                        //uof.ui.MedicalReport.viewModel.SupervisorInformation.EvaluatedBy.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.MedicalInformation.EvaluatedEmployeeNumber.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.MedicalInformation.DateEvaluated.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.MedicalInformation.TimeEvaluated.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.MedicalInformation.MedicalAssessment.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.MedicalInformation.SprayExposureYN.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.MedicalInformation.DecontaminatedYN.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.MedicalInformation.FollowUpTreatmentYN.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.MedicalInformation.RefusalVideotapedYN.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.MedicalInformation.RefusedMedicalTreatmentYN.valueHasMutated();
                        return false;
                    }
                    if (obj != undefined)
                        uof.ui.MedicalReport.redirecttoValidationScreen(obj);
                    else
                        return true;
                }
                else
                    if (obj != undefined)
                        uof.ui.MedicalReport.redirecttoValidationScreen(obj);
                    else
                        return true;
            },
            validateDiagnosis: function (obj, isApproval) {
                result = ko.validation.group(uof.ui.MedicalReport.viewModel.DiagnosisInformation, { deep: true });
                if (isApproval) {

                    if (result().length > 0) {
                        result.showAllMessages(true);
                        //uof.ui.MedicalReport.viewModel.DiagnosisInformation.EmployeeNumber.valueHasMutated();
                        //uof.ui.MedicalReport.viewModel.DiagnosisInformation.WatchCommander.valueHasMutated();
                        return false;
                    }
                }
                else {
                    if (result().length > 0) {
                        uof.ui.MedicalReport.viewModel.DiagnosisInformation.EmployeeNumber.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.DiagnosisInformation.OutsideTreatedBy.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.DiagnosisInformation.OutsideEmployeeNumber.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.DiagnosisInformation.OutsideDateTreated.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.DiagnosisInformation.OutsideTimeTreated.valueHasMutated();
                        uof.ui.MedicalReport.viewModel.DiagnosisInformation.FollowupTreatmentNo.valueHasMutated();

                        return false;
                    }
                }
                if (obj != undefined)
                    uof.ui.MedicalReport.redirecttoValidationScreen(obj);
                else
                    return true;
            },
        }
    }();
}