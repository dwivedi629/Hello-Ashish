﻿var uof = uof || {};
uof.ui = uof.ui || {};
uof.ui.login = uof.ui.login || {};
if (uof.ui.login) {
    uof.ui.login = function () {
        return {
            afterLogginUrl: "",
            logginUrl: "",
            viewModel: {

                roleType: ko.observable([
                                 { RoleName: 'Sergeant', RoleCode: 'SGT' },
                                 { RoleName: 'Deputy', RoleCode: 'DSG' },
                                 { RoleName: 'Watch Commander', RoleCode: 'WC' },
                                 { RoleName: 'Unit Commander', RoleCode: 'CAPT' },
                                 { RoleName: 'Commander', RoleCode: 'CMDR' },
                                 { RoleName: 'Division Chief', RoleCode: 'DC' },
                                 { RoleName: 'CTSB-CFRT', RoleCode: 'CFRT' },
                                 { RoleName: 'Medical User', RoleCode: 'MED' },
                                 { RoleName: 'SuperAdmin', RoleCode: 'SuperAdmin' }

                ]),
                //roleType: ko.observableArray([]),
                selectedValue: ko.observable(),
                userName: ko.observable(),
                userPassword: ko.observable(),
                loginSubmit: function () {
                    uof.ui.login.loginSubmit();
                },
            },
            //load method, will be tirggered on document load
            load: function (logginUrl) {

                var fullText = "The 1918 New Year Honours were appointments by King George V to various orders and honours to reward and highlight good works by citizens of the British Empire. The appointments were published in The London Gazette and The Times in January, February and March 1918. Unlike the 1917 New Year Honours, the 1918 honours included a long list of new knights bachelor";

                var maxcharacters = 290;
                if(fullText.length > maxcharacters)
                {
                    var trunc = fullText.substring(0, maxcharacters).replace(/\w+$/, '');
                    var id = "messageBody";
                    var remainder = "";
                    remainder = fullText.substring(maxcharacters, fullText.length);
                    var final = '<span>' + trunc + '<span class="hidden" id="Overflow">' + remainder + '</span></span>&amp;nbsp;<a id="' + id + 'MoreLink" href="#!" onclick="showMore(\'' + id + '\');"><img id="more" style="border:0px;" src="https://uadev.athocdevo.com/athoc-cdn/images/Down.png&amp;#xD;&amp;#xA;              "></a><a class="hidden" href="#!" id="' + id + 'LessLink" onclick="showLess(\'' + id + '\');"><img id="less" style="border:0px;" src="https://uadev.athocdevo.com/athoc-cdn/images/Up.png&amp;#xD;&amp;#xA;"></a>';

                }

                uof.ui.login.logginUrl = logginUrl;
                //uof.ui.login.getRoles();
                //binding Canine popup page
                ko.cleanNode($("#LoginPage").get(0));
                ko.applyBindings(uof.ui.login.viewModel, $("#LoginPage").get(0));
                localStorage.clear();
            },

            getRoles: function () {
                $.ajax(
                {
                    url: window.location.uofAPIOrigin() + '/api/Settings/GetRoles',
                    cache: false,
                    type: "GET",
                    dataType: 'json',
                    contentType: "application/json;charset=utf-8",
                    success: function (roleTypes) {
                        uof.ui.login.viewModel.roleType([]);
                        uof.ui.login.viewModel.roleType(roleTypes);
                        uof.ui.login.viewModel.roleType.valueHasMutated();
                    },
                    error: function (e) {
                    },
                });
            },

            loginSubmit: function () {
                $.prototype.showUofOverlay();
                $.ajax(
               {
                   url: uof.ui.login.logginUrl,
                   data: "roleCode=" + uof.ui.login.viewModel.selectedValue(),
                   cache: false,
                   type: "GET",
                   dataType: 'json',
                   contentType: "application/json;charset=utf-8",
                   success: function (roleTypes) {
                       //var lastUrl = localStorage.getItem(roleTypes.UserId + "_" + roleTypes.LoggedInRole + "_lastUrl");
                       //if ((roleTypes.success != "unauthorized") && ((lastUrl != "") && (lastUrl != undefined))) {
                       //    window.location.href = lastUrl;
                       //    return;
                       //}

                       window.location.href = roleTypes.data;
                       $.prototype.hideUofOverlay();
                   },
                   error: function (e) {
                       $.prototype.hideUofOverlay();
                   },
               });

            },

        }
    }();

}