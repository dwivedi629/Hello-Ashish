﻿var CommanderReviewConstants = {
    Required: 'Required',
    DateTime:'Date/Time is required',
    URN: 'URN is required',
    Facility:'Facility is required',
    ReferenceNumber: 'Reference Number is required',   
}