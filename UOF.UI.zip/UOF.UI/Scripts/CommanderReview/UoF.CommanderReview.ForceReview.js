﻿var uof = uof || {};
uof.ui = uof.ui || {};
uof.ui.CommanderReview = uof.ui.CommanderReview || {};

if (uof.ui.CommanderReview) {
    uof.ui.CommanderReview.ForceReview = function () {
        return {
            parameters: null,
            isChanged: false,
            init: function (args) {
                this.parameters = args;
            },
            CommanderReviewDBSource: null,
            ParameterCriteria: {
                IncidentReviewId: 0,
                employeeId: '',
                incidentId: 0,
                formId: 0,
                formDataId: 0
            },
            viewModel: {
                IncidentReviewId: ko.observable(0),
                FormDataId: ko.observable(0),
                IsFormOwner: ko.observable(false),
                IsIncidentOwner: ko.observable(false),
                IsLock: ko.observable(false),
                IsSupervisorStatus: ko.observable(false),
                IsSupervisorOrApprover: ko.observable(false),
                SubmitedId: ko.observable(),
                ObservableInputArray: ko.observableArray(),
                IncidentID: ko.observable(),
                FormID: ko.observable(),
                UserRoleId: ko.observable(),
                IsOnlySave: ko.observable(true),
                UserRole: ko.observable(),
                EmpId: ko.observable(),
                Section1: {
                    DateTime: ko.observable(),
                    URN: ko.observable(),
                    Facility: ko.observable(),
                    ReferenceNumber: ko.observable(),
                    Q1: ko.observable(false),
                    Q2: ko.observable(),
                    Q3: ko.observable(),
                    Q4: ko.observable(),
                    Q1TextValue: ko.observable(false),
                    Q2TextValue: ko.observable(false),
                    Q3TextValue: ko.observable(false),
                    Q4TextValue: ko.observable(false),

                    Q1TextData: ko.observable(),
                    Q2TextData: ko.observable(),
                    Q3TextData: ko.observable(),
                    Q4TextData: ko.observable(),
                },
                Section2: {

                    Q5: ko.observable(),
                    Q6: ko.observable(),
                    Q7: ko.observable(),
                    Q8: ko.observable(),

                    Q5TextValue: ko.observable(false),
                    Q6TextValue: ko.observable(false),
                    Q7TextValue: ko.observable(false),
                    Q8TextValue: ko.observable(false),

                    Q5TextData: ko.observable(),
                    Q6TextData: ko.observable(),
                    Q7TextData: ko.observable(),
                    Q8TextData: ko.observable(),
                },
                Section3: {
                    Q9: ko.observable(),
                    Q10: ko.observable(),
                    Q11: ko.observable(),
                    Q12: ko.observable(),
                    Q13: ko.observable(),
                    


                    Q9TextValue: ko.observable(false),
                    Q10TextValue: ko.observable(false),
                    Q11TextValue: ko.observable(false),
                    Q12TextValue: ko.observable(false),
                    Q13TextValue: ko.observable(false),

                    Q9TextData: ko.observable(),
                    Q10TextData: ko.observable(),
                    Q11TextData: ko.observable(),
                    Q12TextData: ko.observable(),
                    Q13TextData: ko.observable(),

                    CorrectiveAction: ko.observable(false),
                    AdministrativeInvestigation: ko.observable(false),
                    ConcurFinding: ko.observable(false),
                    ConcurwithCFRTYes: ko.observable(false),
                    ConcurwithCFRTNo: ko.observable(false),
                    ConcurwithCFRTNoTextData: ko.observable(),
                    ReferenceIABTextData: ko.observable(),
                    ReferenceCAPTextData: ko.observable(),
                    Reviewed: ko.observable(),
                    Employeeno: ko.observable(),
                    RejectComments: ko.observable(),

                },
                getEmployeeDetails: function (empId, targetDiv) { uof.ui.CommanderReview.ForceReview.getEmployeeDetails(empId, targetDiv); },

            },
            getEmployeeDetails: function (empId, targetDiv) {
                if ((empId != undefined) && (empId.length > 0)) {
                    // Search based on emp id
                    $.prototype.showProgressBar(targetDiv);
                    jQuery.ajax({
                        type: "GET",
                        url: EmployeeAPIUrl() + empId,
                        dataType: "json",
                        cache: false,
                        crossDomain: true,
                        processData: true,
                        success: function (empData) {
                            uof.ui.CommanderReview.ForceReview.viewModel.Section3.Reviewed(empData.LastName + ' ' + empData.FirstName);
                            $.prototype.hideProgressBar(targetDiv);
                        },
                        error: function (XMLHttpRequest, textStatus, errorThrown) {
                            showAlert("Error while getting the Employee Data");
                        }
                    });
                }
            },
            load: function () {
                ko.validation.init({ insertMessages: true });
                uof.ui.CommanderReview.ForceReview.initiateBindings();
                ko.validation.rules['checked'] = {
                    validator: function (value) {
                        if (!value) {
                            return false;
                        }
                        return true;
                    }
                };
                ko.validation.registerExtenders();

                uof.ui.CommanderReview.ForceReview.validateControls();
                uof.ui.CommanderReview.ForceReview.subscribeMethod();
                //binding Incident popup page
                ko.cleanNode($("#Section1").get(0));
                ko.applyBindings(uof.ui.CommanderReview.ForceReview.viewModel, $("#Section1").get(0));
                ko.applyBindings(uof.ui.CommanderReview.ForceReview.viewModel, $("#Section2").get(0));
                ko.applyBindings(uof.ui.CommanderReview.ForceReview.viewModel, $("#Section3").get(0));
                $('#COMDateTime').datetimepicker({ format: 'MM/DD/YYYY HH:mm:ss' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY HH:mm:ss");
                    uof.ui.CommanderReview.ForceReview.viewModel.Section1.DateTime(newDate);
                });
                
                uof.ui.CommanderReview.ForceReview.ApproveBindings();
                uof.ui.CommanderReview.ForceReview.setTabbing();
            },
            setTabbing: function () {
                var tab = 1;
                $("#dvCommanderTab *").filter(':input').each(function () {
                    $(this).attr('tabindex', tab++);
                });

            },

            saveCommanderForceReview: function () {
                if (uof.ui.CommanderReview.ForceReview.validateCommanderReviewForceReviewFields()) {
                    $.when(showConfirmationWindow('Do you want to submit the for the review ? ')).then(function (confirmed) {
                        if (confirmed)
                            uof.ui.CommanderReview.ForceReview.saveCommanderForceReviewInfo(false);
                    });
                    //Placeholder for calling API method to save Force Review Injury data
                    

                }
            },
            ApproveBindings: function () {
                //$("#btnSave").removeClass('hide')
                //$("#btnApprove").addClass('hide');
                //$("#btnReject").addClass('hide')
                if ($.IncidentId.length > 0 && $.UoFformId.length > 0 && $.SubmitedId.length > 0) {
                    uof.ui.CommanderReview.ForceReview.viewModel.IncidentID($.IncidentId);
                    uof.ui.CommanderReview.ForceReview.viewModel.FormID($.UoFformId);
                    uof.ui.CommanderReview.ForceReview.viewModel.EmpId($.SubmitedId);
                    uof.ui.CommanderReview.ForceReview.viewModel.UserRole(UoFParams.userRole);
                    uof.ui.CommanderReview.ForceReview.viewModel.SubmitedId(localStorage.getItem('SubmittedId') == null ? UoFParams.userId : localStorage.getItem('SubmittedId'));
                    uof.ui.CommanderReview.ForceReview.viewModel.IncidentReviewId(localStorage.getItem('IncidentReviewId') == null ? 0 : localStorage.getItem('IncidentReviewId'));
                    uof.ui.CommanderReview.ForceReview.viewModel.FormDataId(localStorage.getItem('FormDataId') == null ? 0 : localStorage.getItem('FormDataId'));
                }
                else {
                    uof.ui.CommanderReview.ForceReview.viewModel.IncidentID(UoFParams.IncidentId);
                    uof.ui.CommanderReview.ForceReview.viewModel.FormID($.UoFformId);
                    uof.ui.CommanderReview.ForceReview.viewModel.EmpId(UoFParams.userId);
                    uof.ui.CommanderReview.ForceReview.viewModel.SubmitedId(localStorage.getItem('SubmittedId') == null ? UoFParams.userId : localStorage.getItem('SubmittedId'));
                    uof.ui.CommanderReview.ForceReview.viewModel.IncidentReviewId(localStorage.getItem('IncidentReviewId') == null ? 0 : localStorage.getItem('IncidentReviewId'));
                    uof.ui.CommanderReview.ForceReview.viewModel.FormDataId(localStorage.getItem('FormDataId') == null ? 0 : localStorage.getItem('FormDataId'));
                }
                
                //if (uof.ui.CommonUILogic.detail.isFormStatusCompleted($.UoFformId, UoFParams.IncidentId)) {
                //    $("#btnReset").addClass('hide');
                //    $("#btnSave").addClass('hide');
                //    $("#btnApprove").addClass('hide');
                //    $("#btnReject").addClass('hide');
                //}
                uof.ui.CommanderReview.ForceReview.GetQuestionnare();
            },
            initiateBindings: function () {
                if (UoFParams.IncidentURN != "") {
                    uof.ui.CommanderReview.ForceReview.viewModel.Section1.URN(UoFParams.IncidentURN);
                    uof.ui.CommanderReview.ForceReview.viewModel.Section1.DateTime(moment(UoFParams.IncidentDate).format("MM/DD/YYYY HH:mm"));
                    uof.ui.CommanderReview.ForceReview.viewModel.Section1.ReferenceNumber(UoFParams.ReferenceNo);
                    //var facility = UoFParams.IncidentFacility;
                    //if (UoFParams.IncidentStation != "") {
                    //    if (facility != "")
                    //        facility = facility + "-" + UoFParams.IncidentStation
                    //    else
                    //        facility = UoFParams.IncidentStation
                    //}
                    //if (UoFParams.IncidentBureau != "") {
                    //    if (facility != "")
                    //        facility = facility + "-" + UoFParams.IncidentBureau
                    //    else
                    //        facility = UoFParams.IncidentBureau
                    //}
                    uof.ui.CommanderReview.ForceReview.viewModel.Section1.Facility(UoFParams.IncidentStation);
                }

                ko.validation.insertValidationMessage = function (element) {
                    var br = document.createElement("br");
                    element.appendChild(br);
                    var span = document.createElement('SPAN');
                    span.className = "warning-msg";
                    var inputGroups = $(element).closest(".date"); //This is for getting Date Fields
                    if (inputGroups.length > 0) {
                        // We're in an input-group so we place the message after
                        // the group rather than inside it in order to not break the design
                        $(span).insertAfter(inputGroups);
                    }
                    else {
                        // The default in knockout-validation
                        element.parentNode.insertBefore(span, element.nextSibling);
                    }
                    return span;
                };

            },


            GetQuestionnare: function () {
                $.prototype.showUofOverlay();
                uof.ui.CommanderReview.ForceReview.ParameterCriteria.IncidentReviewId = uof.ui.CommanderReview.ForceReview.viewModel.IncidentReviewId();
                uof.ui.CommanderReview.ForceReview.ParameterCriteria.formDataId = uof.ui.CommanderReview.ForceReview.viewModel.FormDataId();
                uof.ui.CommanderReview.ForceReview.ParameterCriteria.employeeId = uof.ui.CommanderReview.ForceReview.viewModel.EmpId();
                uof.ui.CommanderReview.ForceReview.ParameterCriteria.incidentId = uof.ui.CommanderReview.ForceReview.viewModel.IncidentID();
                uof.ui.CommanderReview.ForceReview.ParameterCriteria.formId = uof.ui.CommanderReview.ForceReview.viewModel.FormID();//e.data.FormId;
                var model = ko.mapping.toJS(uof.ui.CommanderReview.ForceReview.ParameterCriteria);
                $.ajax(
                           {
                               url:window.location.uofAPIOrigin() + '/api/Review/GetCommanderReviewData',
                               cache: false,
                               //data: { FormId: uof.ui.CommanderReview.ForceReview.viewModel.FormID(), IncidentId: uof.ui.CommanderReview.ForceReview.viewModel.IncidentID(), CMID: uof.ui.CommanderReview.ForceReview.viewModel.EmpId() },
                               data: JSON.stringify(model),
                               type: "POST",
                               dataType: 'json',
                               contentType: "application/json;charset=utf-8",
                               beforeSend: function myfunction() {

                               },
                               success: function (data) {

                                   if (data != null) {
                                       uof.ui.CommanderReview.ForceReview.setAllInputonLoad(data.ReviewBusinessModel);
                                       if (UoFParams.IncidentURN != "") {
                                           uof.ui.CommanderReview.ForceReview.viewModel.Section1.URN(UoFParams.IncidentURN);
                                           uof.ui.CommanderReview.ForceReview.viewModel.Section1.DateTime(moment(UoFParams.IncidentDate).format("MM/DD/YYYY HH:mm"));
                                           uof.ui.CommanderReview.ForceReview.viewModel.Section1.ReferenceNumber(UoFParams.ReferenceNo);
                                           //if (UoFParams.IncidentStation != "") {
                                           //    if (facility != "")
                                           //        facility = facility + "-" + UoFParams.IncidentStation
                                           //    else
                                           //        facility = UoFParams.IncidentStation
                                           //}
                                           //if (UoFParams.IncidentBureau != "") {
                                           //    if (facility != "")
                                           //        facility = facility + "-" + UoFParams.IncidentBureau
                                           //    else
                                           //        facility = UoFParams.IncidentBureau
                                           //}
                                           uof.ui.CommanderReview.ForceReview.viewModel.Section1.Facility(UoFParams.IncidentStation);
                                       }
                                   }
                                   uof.ui.CommanderReview.ForceReview.toggleControls();
                                   $.prototype.hideUofOverlay();
                                   //showAlert(empData);

                               },
                               error: function (e) {
                                   $.prototype.hideUofOverlay();
                                   showAlert(e.responseText);
                               },
                           });
            },
            toggleControls: function () {
                uof.ui.CommanderReview.ForceReview.viewModel.SubmitedId(localStorage.getItem('SubmittedId') == null ? UoFParams.userId : localStorage.getItem('SubmittedId'));
                uof.ui.CommanderReview.ForceReview.viewModel.IncidentReviewId(localStorage.getItem('IncidentReviewId') == null ? 0 : localStorage.getItem('IncidentReviewId'))
                var formData = uof.ui.CommonUILogic.detail.isFormStatusCompleted($.UoFformId, UoFParams.IncidentId, uof.ui.CommanderReview.ForceReview.viewModel.IncidentReviewId());
                if (formStatus != "") {
                    var formStatus = formData.split('\r\n');
                    uof.ui.CommanderReview.ForceReview.viewModel.IsFormOwner(formStatus[0].split(':')[1].toLowerCase() == "true" ? true : false);
                    uof.ui.CommanderReview.ForceReview.viewModel.IsIncidentOwner(formStatus[1].split(':')[1].toLowerCase() == "true" ? true : false);
                    if (formStatus.length > 2) {
                        uof.ui.CommanderReview.ForceReview.viewModel.IsLock(formStatus[2].split(':')[1].toLowerCase() == "true" ? true : false);
                        uof.ui.CommanderReview.ForceReview.viewModel.IsSupervisorStatus(formStatus[3].split(':')[1].toLowerCase());
                    }
                    if (uof.ui.CommanderReview.ForceReview.viewModel.IsLock()) {
                        //$("#vertical-tabs *").find('input, select, textarea').each(function () {
                        //    $(this).attr('disabled', true);
                        //});
                        $('.fakeSave').addClass('hide');
                        $("#btnReset").addClass('hide'); $("#btnSave").addClass('hide');
                        $("#btnApprove").addClass('hide'); $("#btnReject").addClass('hide');
                        if (localStorage.getItem('formMode') == "Approve") {
                            $("#btnApprove").prop('disabled', false); $("#btnApprove").removeClass('hide');
                            $("#btnReject").prop('disabled', true); $("#btnReject").removeClass('hide');
                            uof.ui.CommanderReview.ForceReview.viewModel.IsSupervisorOrApprover(true);
                            $(".fakeclass").removeClass('hide');
                            $("#txtReject").attr('disabled', false);
                        }
                    }
                    else {
                        $("#btnApprove").addClass('hide'); $("#btnReject").addClass('hide');
                        if (!uof.ui.CommanderReview.ForceReview.viewModel.IsFormOwner() && uof.ui.CommanderReview.ForceReview.viewModel.IsSupervisorStatus() == "pending") {
                            //$("#vertical-tabs *").find('input, select, textarea').each(function () {
                            //    $(this).attr('disabled', true);
                            //});
                            $('.fakeSave').addClass('hide');
                            $("#btnReset").addClass('hide'); $("#btnSave").addClass('hide');
                            $("#btnApprove").addClass('hide'); $("#btnReject").addClass('hide');
                            if (localStorage.getItem('formMode') == "Approve") {
                                $("#btnApprove").prop('disabled', false); $("#btnApprove").removeClass('hide');
                                $("#btnReject").prop('disabled', true); $("#btnReject").removeClass('hide');
                                uof.ui.CommanderReview.ForceReview.viewModel.IsSupervisorOrApprover(true);
                                $(".fakeclass").removeClass('hide');
                                $("#txtReject").attr('disabled', false);
                            }
                        }
                    }
                }
            },
            buildCMObject: function () {
                uof.ui.CommanderReview.ForceReview.viewModel.ObservableInputArray.length = 0;
                uof.ui.CommanderReview.ForceReview.setAllInput();
                var reviewsResponse = new Object();
                reviewsResponse.IsOnlySave = uof.ui.CommanderReview.ForceReview.viewModel.IsOnlySave();
                reviewsResponse.IncidentID = UoFParams.IncidentId;
                reviewsResponse.FormID = $.UoFformId;
                reviewsResponse.EmpId = UoFParams.userId;
                reviewsResponse.UserRole = UoFParams.userRole;
                reviewsResponse.IncidentReviewId = uof.ui.CommanderReview.ForceReview.viewModel.IncidentReviewId();
                reviewsResponse.FormDataId = uof.ui.CommanderReview.ForceReview.viewModel.FormDataId();
                reviewsResponse.ReviewBusinessModel = uof.ui.CommanderReview.ForceReview.viewModel.ObservableInputArray();
                return reviewsResponse;
            },

            saveCommanderForceReviewInfo: function (IsOnlySave) {
                uof.ui.CommanderReview.ForceReview.viewModel.IsOnlySave(IsOnlySave);
                var CMObject = uof.ui.CommanderReview.ForceReview.buildCMObject();
                model = ko.mapping.toJS(CMObject);
                $.prototype.showUofOverlay();
                $.ajax(
                       {
                           url:window.location.uofAPIOrigin() + '/api/Review/SaveCommanderReviewInfo',
                           cache: false,
                           type: "POST",
                           dataType: 'json',
                           data: JSON.stringify(model),
                           contentType: "application/json;charset=utf-8",
                           beforeSend: function myfunction() {

                           },
                           success: function (data) {
                               $.prototype.hideUofOverlay();
                               showAlert(IsOnlySave ? "Data saved successfully" : "submited successfully");
                               uof.ui.CommanderReview.ForceReview.viewModel.FormDataId(data);
                           },
                           error: function (e) {
                               $.prototype.hideUofOverlay();
                               showAlert(e.responseText);
                           },
                       });

            },

            buildApproveCMObject: function (isApprove) {
                var oCMData = new Object();
                oCMData.IncidentId = $.IncidentId;
                oCMData.FormId = $.UoFformId;
                oCMData.DeputyEmpId = $.SubmitedId;
                oCMData.isApprove = isApprove;
                oCMData.ReviewerReviewId = UoFParams.userId;
                oCMData.ReviewerRole = UoFParams.userRole;
                //oMemoData.ReviewerStatus=""
                return oCMData;
            },
            approveCMDetails: function (isApprove) {
                var str = isApprove == "Y" ? "Do you want to Approve?" : "Do you want to Reject?";
                $.when(showConfirmationWindow(str)).then(function (confirmed) {
                    if (confirmed)
                    {
                        var oCMData = uof.ui.CommanderReview.ForceReview.buildApproveCMObject(isApprove);
                        var mappedData = ko.mapping.toJS(oCMData);
                        $.ajax(
                              {
                                  url: window.location.uofAPIOrigin() + '/api/UOFForm/ApproveorReject',
                                  cache: false,
                                  type: "POST",
                                  dataType: 'json',
                                  data: JSON.stringify(mappedData),
                                  contentType: "application/json;charset=utf-8",
                                  beforeSend: function myfunction() {

                                  },
                                  success: function (data) {
                                      $.prototype.hideUofOverlay();
                                      showAlert(data);
                                      uof.ui.CommanderReview.ForceReview.setApprovedIncidentinSession(oCMData.IncidentId);
                                  },
                                  error: function (e) {
                                      $.prototype.hideUofOverlay();
                                      showAlert(e.responseText);
                                  },
                              });
                    }
                });
                
            },
            setApprovedIncidentinSession: function (incidentId) {
                $.ajax(
                     {
                         url: window.location.uofUIOrigin() + '/Incident/setApprovedIncident',
                         type: "POST",
                         data: { incidentID: incidentId },
                         success: function (data) {
                             if (data == "true")
                                 window.location.href = window.location.uofUIOrigin() + '/Incident/Incident';
                         },
                         error: function (e) {
                             showAlert(e.responseText);
                         },
                     });
            },
            setAllInput: function () {
                $("#dvCommanderTab .tab-pane").each(function (i) {
                    var dvId = $(this).attr('id');
                    $('#' + (dvId) + ' *').filter(':input').each(function () {
                        var id = $(this).attr('id');
                        uof.ui.CommanderReview.ForceReview.createArrayofCollection($(this), dvId);

                    });
                });
            },

            ///setting the values to the control on load
            setAllInputonLoad: function (modelQuestion) {
                $('#dvCommanderTab *').filter(':input').each(function (index, item) {
                    $.each(modelQuestion, function (key, value) {
                        if (value.Type == "radio" && $(item).attr('name') == value.ID) {
                            uof.ui.CommanderReview.ForceReview.viewModel[value.Observer][value.ID](value.Answer);
                        }
                        else if ($(item).attr('id') == value.ID) {
                            console.log(value.Observer);
                            console.log(value.ID);
                            console.log(value.Answer);
                            uof.ui.CommanderReview.ForceReview.viewModel[value.Observer][value.ID](value.Answer);
                        }
                    });
                });
            },

            ///creating the array of controls
            createArrayofCollection: function (obj, dvId) {
                if (obj.attr('type') == "checkbox" && obj.is(':checked')) {
                    uof.ui.CommanderReview.ForceReview.viewModel.ObservableInputArray.push(
                                {
                                    ID: obj.attr('id'),
                                    Type: obj.attr('type'),
                                    Answer: obj.is(':checked'),
                                    Observer: dvId
                                }
                               );

                }
                if (obj.attr('type') == "radio" && obj.is(':checked')) {
                    uof.ui.CommanderReview.ForceReview.viewModel.ObservableInputArray.push(
                                {
                                    ID: obj.attr('name'),
                                    Type: obj.attr('type'),
                                    Answer: obj.attr('value'),
                                    Observer: dvId

                                }
                               );

                }
                if (obj.attr('type') == "text" && obj.val() != "") {
                    uof.ui.CommanderReview.ForceReview.viewModel.ObservableInputArray.push(
                                {
                                    ID: obj.attr('id'),
                                    Type: obj.attr('type'),
                                    Answer: obj.val(),
                                    Observer: dvId

                                }
                               );

                }
                if (obj.is('textarea') && obj.val() != "") {
                    uof.ui.CommanderReview.ForceReview.viewModel.ObservableInputArray.push(
                                {
                                    ID: obj.attr('id'),
                                    Type: "textarea",
                                    Answer: obj.val(),
                                    Observer: dvId

                                }
                               );

                }
                if (obj.is('select') && obj.val() != "") {
                    uof.ui.CommanderReview.ForceReview.viewModel.ObservableInputArray.push(
                                {
                                    ID: obj.attr('id'),
                                    Type: "select",
                                    Answer: obj.val(),
                                    Observer: dvId

                                }
                               );

                }
                if (obj.attr('type') == "number" && obj.val() != "") {
                    uof.ui.CommanderReview.ForceReview.viewModel.ObservableInputArray.push(
                                {
                                    ID: obj.attr('id'),
                                    Type: obj.attr('type'),
                                    Answer: obj.val(),
                                    Observer: dvId
                                }
                               );

                }
            },

            //Validate the controls on Add and duplicate popup
            validateControls: function () {
                ////remove old validation
                //$("#newincident .warning").each(function () {
                //    $(this).parent().remove();
                //});

                //Validate the controls on Add and duplicate popup
                //Date/Time
                uof.ui.CommanderReview.ForceReview.viewModel.Section1.DateTime.extend({
                    required: {
                        params: true,
                        message: CommanderReviewConstants.Required
                    }
                });
               
                //Facility
                //uof.ui.CommanderReview.ForceReview.viewModel.Section1.Facility.extend({
                //    required: {
                //        params: true,
                //        message: CommanderReviewConstants.Required
                //    },
                //    maxLength: {
                //         params: 400,
                //        message: 'Facility maximum character should be 400 only.'
                //    },
                //});
                ////Reference#
                //uof.ui.CommanderReview.ForceReview.viewModel.Section1.ReferenceNumber.extend({
                //    required: {
                //        params: true,
                //        message: CommanderReviewConstants.Required
                //    },
                //    maxLength: {
                //         params: 400,
                //        message: 'Reference# maximum character should be 400 only.'
                //    },
                //});
                //Q1
                uof.ui.CommanderReview.ForceReview.viewModel.Section1.Q1.extend({
                    required: {
                        params: true,
                        message: CommanderReviewConstants.Required
                    },
                    maxLength: {
                         params: 400,
                        message: CommanderReviewConstants.Required
                    },
                });
                //Q2
                uof.ui.CommanderReview.ForceReview.viewModel.Section1.Q2.extend({
                    required: {
                        params: true,
                        message: CommanderReviewConstants.Required
                    },
                    maxLength: {
                         params: 400,
                        message: 'Q2 maximum character should be 400 only.'
                    },
                });
                //Q3
                uof.ui.CommanderReview.ForceReview.viewModel.Section1.Q3.extend({
                    required: {
                        params: true,
                        message: CommanderReviewConstants.Required
                    },
                    maxLength: {
                         params: 400,
                        message: 'Q3 maximum character should be 400 only.'
                    },
                });
                //Q4
                uof.ui.CommanderReview.ForceReview.viewModel.Section1.Q4.extend({
                    required: {
                        params: true,
                        message: CommanderReviewConstants.Required
                    },
                    maxLength: {
                         params: 400,
                        message: 'Q4 maximum character should be 400 only.'
                    },
                });
                //Q5
                uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q5.extend({
                    required: {
                        params: true,
                        message: CommanderReviewConstants.Required
                    },
                    maxLength: {
                         params: 400,
                        message: 'Q5 maximum character should be 400 only.'
                    },
                });
                //Q6
                uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q6.extend({
                    required: {
                        params: true,
                        message: CommanderReviewConstants.Required
                    },
                    maxLength: {
                         params: 400,
                        message: 'Q6 maximum character should be 400 only.'
                    },
                });
              
                //Q7
                uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q7.extend({
                    required: {
                        params: true,
                        message: CommanderReviewConstants.Required
                    },
                    maxLength: {
                         params: 400,
                        message: 'Q7 maximum character should be 400 only.'
                    },
                });        
                //Q8
                uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q8.extend({
                    required: {
                        params: true,
                        message: CommanderReviewConstants.Required
                    },
                    maxLength: {
                         params: 400,
                        message: 'Q8 maximum character should be 400 only.'
                    },
                });
                //Q9
                uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q9.extend({
                    required: {
                        params: true,
                        message: CommanderReviewConstants.Required
                    },
                    maxLength: {
                         params: 400,
                        message: 'Q9 maximum character should be 400 only.'
                    },
                });
                //Q10
                uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q10.extend({
                    required: {
                        params: true,
                        message: CommanderReviewConstants.Required
                    },
                    maxLength: {
                         params: 400,
                        message: 'Q10 maximum character should be 400 only.'
                    },
                });
                //Q11
                uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q11.extend({
                    required: {
                        params: true,
                        message: CommanderReviewConstants.Required
                    },
                    maxLength: {
                         params: 400,
                        message: 'Q11 maximum character should be 400 only.'
                    },
                });

                  //Q12
                uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q12.extend({
                    required: {
                        params: true,
                        message: CommanderReviewConstants.Required
                    },
                    maxLength: {
                         params: 400,
                        message: 'Q12 maximum character should be 400 only.'
                    },
                });
              //Q13
                uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q13.extend({
                    required: {
                        params: true,
                        message: CommanderReviewConstants.Required
                    },
                    maxLength: {
                         params: 400,
                        message: 'Q13 maximum character should be 400 only.'
                    },
                });
               
              //Recommendations
                //uof.ui.CommanderReview.ForceReview.viewModel.Section3.Recommendations.extend({
                //    required: {
                //        params: true,
                //        message: CommanderReviewConstants.Required
                //    },
                //    maxLength: {
                //         params: 400,
                //        message: 'Recommendations maximum character should be 400 only.'
                //    },
                //});

                ////CorrectiveAction
                //uof.ui.CommanderReview.ForceReview.viewModel.Section3.CorrectiveAction.extend({
                //    checked: {
                //        message: CommanderReviewConstants.Required
                //    }
                    
                //});

                uof.ui.CommanderReview.ForceReview.viewModel.Section1.Q1TextData.extend({
                    required: {
                        params: true,
                        message: CommanderReviewConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.CommanderReview.ForceReview.viewModel.Section1.Q1() === 'Y');
                        }
                    }
                });
                uof.ui.CommanderReview.ForceReview.viewModel.Section1.Q2TextData.extend({
                    required: {
                        params: true,
                        message: CommanderReviewConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.CommanderReview.ForceReview.viewModel.Section1.Q2() === 'Y');
                        }
                    }
                });
                uof.ui.CommanderReview.ForceReview.viewModel.Section1.Q3TextData.extend({
                    required: {
                        params: true,
                        message: CommanderReviewConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.CommanderReview.ForceReview.viewModel.Section1.Q3() === 'Y');
                        }
                    }
                });
                uof.ui.CommanderReview.ForceReview.viewModel.Section1.Q4TextData.extend({
                    required: {
                        params: true,
                        message: CommanderReviewConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.CommanderReview.ForceReview.viewModel.Section1.Q4() === 'N');
                        }
                    }
                });
                uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q5TextData.extend({
                    required: {
                        params: true,
                        message: CommanderReviewConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q5() === 'N');
                        }
                    }
                });
                uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q6TextData.extend({
                    required: {
                        params: true,
                        message: CommanderReviewConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q6() === 'N' || uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q6() === 'Y');
                        }
                    }
                });
               
                uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q7TextData.extend({
                    required: {
                        params: true,
                        message: CommanderReviewConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q7() === 'N');
                        }
                    }
                });
                uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q8TextData.extend({
                    required: {
                        params: true,
                        message: CommanderReviewConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q8() === 'N');
                        }
                    }
                });

                uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q9TextData.extend({
                    required: {
                        params: true,
                        message: CommanderReviewConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q9() === 'N');
                        }
                    }
                });
                uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q10TextData.extend({
                    required: {
                        params: true,
                        message: CommanderReviewConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q10() === 'Y');
                        }
                    }
                });
                uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q11TextData.extend({
                    required: {
                        params: true,
                        message: CommanderReviewConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q11() === 'Y');
                        }
                    }
                });
                uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q12TextData.extend({
                    required: {
                        params: true,
                        message: CommanderReviewConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q12() === 'Y');
                        }
                    }
                });
                uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q13TextData.extend({
                    required: {
                        params: true,
                        message: CommanderReviewConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q13() === 'Y');
                        }
                    }
                });
            },
            subscribeMethod: function () {
                //Section 
                uof.ui.CommanderReview.ForceReview.viewModel.Section1.Q1.subscribe(function (newValue) {
                    if ($.trim(newValue) == "Y") {
                        uof.ui.CommanderReview.ForceReview.viewModel.Section1.Q1TextData.valueHasMutated();
                        return false;
                    }
                    else if ($.trim(newValue) == "N")
                        uof.ui.CommanderReview.ForceReview.viewModel.Section1.Q1TextData(null);
                });
                uof.ui.CommanderReview.ForceReview.viewModel.Section1.Q2.subscribe(function (newValue) {
                    if ($.trim(newValue) == "Y") {
                        uof.ui.CommanderReview.ForceReview.viewModel.Section1.Q2TextData.valueHasMutated();
                        return false;
                    }
                    else if ($.trim(newValue) == "N")
                        uof.ui.CommanderReview.ForceReview.viewModel.Section1.Q2TextData(null);
                });
                uof.ui.CommanderReview.ForceReview.viewModel.Section1.Q3.subscribe(function (newValue) {
                    if ($.trim(newValue) == "Y") {
                        uof.ui.CommanderReview.ForceReview.viewModel.Section1.Q3TextData.valueHasMutated();
                        return false;
                    }
                    else if ($.trim(newValue) == "N")
                        uof.ui.CommanderReview.ForceReview.viewModel.Section1.Q3TextData(null);
                });

                //Section 2
                uof.ui.CommanderReview.ForceReview.viewModel.Section1.Q4.subscribe(function (newValue) {
                    if ($.trim(newValue) == "N") {
                        uof.ui.CommanderReview.ForceReview.viewModel.Section1.Q4TextData.valueHasMutated();
                        return false;
                    }
                    else if ($.trim(newValue) == "Y")
                        uof.ui.CommanderReview.ForceReview.viewModel.Section1.Q4TextData(null);
                });
                uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q5.subscribe(function (newValue) {
                    if ($.trim(newValue) == "N") {
                        uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q5TextData.valueHasMutated();
                        return false;
                    }
                    else if ($.trim(newValue) == "Y")
                        uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q5TextData(null);
                });
                uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q6.subscribe(function (newValue) {
                    if ($.trim(newValue)) {
                        uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q6TextData.valueHasMutated();
                        uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q6TextData(null);
                        return false;
                    }
                    else if ($.trim(newValue)=="Y")
                        uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q6TextData(null);
                    else if ($.trim(newValue) == "N")
                        uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q6TextData(null);
                });

                uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q7.subscribe(function (newValue) {
                    if ($.trim(newValue) == "N") {
                        uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q7TextData.valueHasMutated();
                        return false;
                    }
                    else if ($.trim(newValue) == "Y")
                        uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q7TextData(null);
                });
                uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q8.subscribe(function (newValue) {
                    if ($.trim(newValue) == "N") {
                        uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q8TextData.valueHasMutated();
                        return false;
                    }
                    else if ($.trim(newValue) == "Y")
                        uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q8TextData(null);
                });
               

                //End Section 2
                //Section 3
                uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q9.subscribe(function (newValue) {
                    if ($.trim(newValue) == "N") {
                        uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q9TextData.valueHasMutated();
                        return false;
                    }
                    else if ($.trim(newValue) == "Y")
                        uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q9TextData(null);
                });
                uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q10.subscribe(function (newValue) {
                    if ($.trim(newValue) == "Y") {
                        uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q10TextData.valueHasMutated();
                        return false;
                    }
                    else if ($.trim(newValue) == "N")
                        uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q10TextData(null);
                });
                uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q11.subscribe(function (newValue) {
                    if ($.trim(newValue) == "Y") {
                        uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q11TextData.valueHasMutated();
                        return false;
                    }
                    else if ($.trim(newValue) == "N")
                        uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q11TextData(null);
                });
                uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q12.subscribe(function (newValue) {
                    if ($.trim(newValue) == "Y") {
                        uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q12TextData.valueHasMutated();
                        return false;
                    }
                    else if ($.trim(newValue) == "N")
                        uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q12TextData(null);
                });
                uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q13.subscribe(function (newValue) {
                    if ($.trim(newValue) == "Y") {
                        uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q13TextData.valueHasMutated();
                        return false;
                    }
                    else if ($.trim(newValue) == "N")
                        uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q13TextData(null);
                });


                uof.ui.CommanderReview.ForceReview.viewModel.Section3.ConcurwithCFRTNo.subscribe(function (newValue) {
                    if (newValue) {
                        uof.ui.CommanderReview.ForceReview.viewModel.Section3.ConcurwithCFRTNoTextData.valueHasMutated();
                        return false;
                    }
                    else if (!newValue)
                        uof.ui.CommanderReview.ForceReview.viewModel.Section3.ConcurwithCFRTNoTextData(null);
                });
                //End Section 3
            },
            //Validate before save
            validateCommanderReviewForceReviewFields: function () {
                if (!uof.ui.CommanderReview.ForceReview.validateSection1Information()) {
                    uof.ui.CommanderReview.ForceReview.redirecttoValidationScreen("anchorSection1");
                    return false;
                }
                if (!uof.ui.CommanderReview.ForceReview.validateSection2Information()) {
                    uof.ui.CommanderReview.ForceReview.redirecttoValidationScreen("anchorSection2");
                    return false;
                }
                if (!uof.ui.CommanderReview.ForceReview.validateSection3Information()) {
                    return false;
                }
                uof.ui.CommanderReview.ForceReview.removeActiveONSuccessValidation();
                return true;
            },

            //remove active css on success validation
            removeActiveONSuccessValidation: function () {
                //$("#liSection1").removeClass("active")
                $("#liSection2").removeClass("active");
                $("#liSection3").removeClass("active");
                $("#liSection4").removeClass("active");
            },

            //validate section 1 information
            validateSection1Information: function (obj) {
                result = ko.validation.group(uof.ui.CommanderReview.ForceReview.viewModel.Section1, { deep: true });
                if (result().length > 0) {
                    //uof.ui.CommanderReview.ForceReview.viewModel.Section1.DateTime.valueHasMutated();
                    //uof.ui.CommanderReview.ForceReview.viewModel.Section1.URN.valueHasMutated();
                    //uof.ui.CommanderReview.ForceReview.viewModel.Section1.Facility.valueHasMutated();
                    //uof.ui.CommanderReview.ForceReview.viewModel.Section1.ReferenceNumber.valueHasMutated();
                    uof.ui.CommanderReview.ForceReview.viewModel.Section1.Q1.valueHasMutated();
                    uof.ui.CommanderReview.ForceReview.viewModel.Section1.Q2.valueHasMutated();
                    uof.ui.CommanderReview.ForceReview.viewModel.Section1.Q3.valueHasMutated();
                    uof.ui.CommanderReview.ForceReview.viewModel.Section1.Q4.valueHasMutated();
                    return false;
                }
                if (obj != undefined)
                    uof.ui.CommanderReview.ForceReview.redirecttoValidationScreen(obj);
                else
                    return true;
            },

            //validate section 2 information
            validateSection2Information: function (obj) {
                result = ko.validation.group(uof.ui.CommanderReview.ForceReview.viewModel.Section2, { deep: true });
                if (result().length > 0) {
                    uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q5.valueHasMutated();
                    uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q6.valueHasMutated();
                    uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q7.valueHasMutated();
                    uof.ui.CommanderReview.ForceReview.viewModel.Section2.Q8.valueHasMutated();

                    return false;
                }
                if (obj != undefined)
                    uof.ui.CommanderReview.ForceReview.redirecttoValidationScreen(obj);
                else
                    return true;
            },

            //validate section 3 information
            validateSection3Information: function (obj) {
                result = ko.validation.group(uof.ui.CommanderReview.ForceReview.viewModel.Section3, { deep: true });
                if (result().length > 0) {
                    uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q9.valueHasMutated();
                    uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q10.valueHasMutated();
                    uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q11.valueHasMutated();
                    uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q12.valueHasMutated();
                    uof.ui.CommanderReview.ForceReview.viewModel.Section3.Q13.valueHasMutated();
                    
                    //uof.ui.CommanderReview.ForceReview.viewModel.Section3.Recommendations.valueHasMutated();
                    return false;
                }
                return true;
            },

            //redirting to validation failed section
            redirecttoValidationScreen: function (anchorInfo) {
                $("#" + anchorInfo).trigger("click");
            },

        }
    }();
}