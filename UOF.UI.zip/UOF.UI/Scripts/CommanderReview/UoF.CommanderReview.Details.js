﻿var uof = uof || {};
uof.ui = uof.ui || {};
uof.ui.CommanderReview = uof.ui.CommanderReview || {};

if (uof.ui.CommanderReview) {
    uof.ui.CommanderReview.Details = function () {
        return {
            parameters: null,
            isChanged: false,
            init: function (args) {
                this.parameters = args;
            },
            viewModel: {
                CommanderReview: {
                    EmployeeNumber: ko.observable(""),
                    Lastname: ko.observable(""),
                    Firstname: ko.observable(""),
                    Middlename: ko.observable(""),
                    Rank: ko.observable(),
                    Present: ko.observable(),
                    WitnesstoIncident: ko.observable()
                },
            },
            load: function () {
                uof.ui.incident.deputy.validateControls();
                uof.ui.incident.deputy.subscribeMethod();
                ko.cleanNode($("#OD").get(0));
                ko.applyBindings(uof.ui.incident.deputy.viewModel, $("#OD").get(0));

                //ko.cleanNode($("#SC").get(0));
                //ko.applyBindings(uof.ui.incident.deputy.viewModel, $("#SC").get(0));

                //ko.cleanNode($("#CommanderReview").get(0));
                //ko.applyBindings(uof.ui.incident.deputy.viewModel, $("#CommanderReview").get(0));


            },
            //Validate the controls on Add
            validateControls: function () {
                uof.ui.incident.deputy.viewModel.OnDupty.EmployeeNumber.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });

                uof.ui.incident.deputy.viewModel.OnDupty.Rank.extend({
                    required: {
                        params: true,
                    },
                });
                uof.ui.incident.deputy.viewModel.OnDupty.Present.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });

                uof.ui.incident.deputy.viewModel.OnDupty.WitnesstoIncident.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });
                //*********************************************
                uof.ui.incident.deputy.viewModel.SupervisorComplInvest.EmployeeNumber.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });

                uof.ui.incident.deputy.viewModel.SupervisorComplInvest.Rank.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });
                uof.ui.incident.deputy.viewModel.SupervisorComplInvest.Present.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });

                uof.ui.incident.deputy.viewModel.SupervisorComplInvest.WitnesstoIncident.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });
                uof.ui.incident.deputy.viewModel.WatchCommander.EmployeeNumber.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });

                uof.ui.incident.deputy.viewModel.WatchCommander.Rank.extend({
                    required: {
                        params: true,
                        message: IncidentConstants.Required
                    },
                });
            },
            // subscribe method
            subscribeMethod: function () {
                // Subscribing the name and code to get changes
                uof.ui.incident.deputy.viewModel.OnDupty.Rank.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        uof.ui.incident.deputy.isChanged = true;
                    }

                });
                uof.ui.incident.deputy.viewModel.OnDupty.Present.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        uof.ui.incident.deputy.isChanged = true;
                    }

                });
                uof.ui.incident.deputy.viewModel.OnDupty.WitnesstoIncident.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        uof.ui.incident.deputy.isChanged = true;
                    }

                });

                uof.ui.incident.deputy.viewModel.SupervisorComplInvest.Rank.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        uof.ui.incident.deputy.isChanged = true;
                    }

                });
                uof.ui.incident.deputy.viewModel.SupervisorComplInvest.Present.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        uof.ui.incident.deputy.isChanged = true;
                    }

                });
                uof.ui.incident.deputy.viewModel.SupervisorComplInvest.WitnesstoIncident.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        uof.ui.incident.deputy.isChanged = true;
                    }

                });


                uof.ui.incident.deputy.viewModel.WatchCommander.EmployeeNumber.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        uof.ui.incident.deputy.isChanged = true;
                    }

                });
                uof.ui.incident.deputy.viewModel.WatchCommander.Rank.subscribe(function (newValue) {
                    if ($.trim(newValue) != "") {
                        uof.ui.incident.deputy.isChanged = true;
                    }

                });

            },

            AddDeputies: function () {
                if (uof.ui.incident.deputy.validateDeputiesFields()) {
                    showAlert("Done");
                }
            },

            AddOnDupty: function () {
                if (uof.ui.incident.deputy.validateOnDuptyFields()) {
                    showAlert("Done");
                }
            },
            AddSupervisoryInvest: function () {
                if (uof.ui.incident.deputy.validateSupervisorComplInvestFields()) {
                    showAlert("Done");
                }
            },
            AddCommanderReview: function () {
                if (uof.ui.incident.deputy.validateCommanderReviewFields()) {
                    showAlert("Done");
                }
            },
            validateOnDuptyFields: function () {
                result = ko.validation.group(uof.ui.incident.deputy.viewModel.OnDupty, { deep: true });
                if (result().length > 0) {
                    uof.ui.incident.deputy.viewModel.OnDupty.EmployeeNumber.valueHasMutated();
                    uof.ui.incident.deputy.viewModel.OnDupty.Rank.valueHasMutated();
                    uof.ui.incident.deputy.viewModel.OnDupty.Present.valueHasMutated();
                    uof.ui.incident.deputy.viewModel.OnDupty.WitnesstoIncident.valueHasMutated();
                    return false;
                }
                return true;
            },
            validateDeputiesFields: function () {
                result = ko.validation.group(uof.ui.incident.deputy.viewModel, { deep: true });
                if (result().length > 0) {
                    uof.ui.incident.deputy.viewModel.OnDupty.EmployeeNumber.valueHasMutated();
                    uof.ui.incident.deputy.viewModel.OnDupty.Rank.valueHasMutated();
                    uof.ui.incident.deputy.viewModel.OnDupty.Present.valueHasMutated();
                    uof.ui.incident.deputy.viewModel.OnDupty.WitnesstoIncident.valueHasMutated();

                    uof.ui.incident.deputy.viewModel.SupervisorComplInvest.EmployeeNumber.valueHasMutated();
                    uof.ui.incident.deputy.viewModel.SupervisorComplInvest.Rank.valueHasMutated();
                    uof.ui.incident.deputy.viewModel.SupervisorComplInvest.Present.valueHasMutated();
                    uof.ui.incident.deputy.viewModel.SupervisorComplInvest.WitnesstoIncident.valueHasMutated();

                    uof.ui.incident.deputy.viewModel.WatchCommander.EmployeeNumber.valueHasMutated();
                    uof.ui.incident.deputy.viewModel.WatchCommander.Rank.valueHasMutated();
                    return false;
                }
                return true;
            },
            validateSupervisorComplInvestFields: function () {
                result = ko.validation.group(uof.ui.incident.deputy.viewModel.SupervisorComplInvest, { deep: true });
                if (result().length > 0) {
                    uof.ui.incident.deputy.viewModel.SupervisorComplInvest.EmployeeNumber.valueHasMutated();
                    uof.ui.incident.deputy.viewModel.SupervisorComplInvest.Rank.valueHasMutated();
                    uof.ui.incident.deputy.viewModel.SupervisorComplInvest.Present.valueHasMutated();
                    uof.ui.incident.deputy.viewModel.SupervisorComplInvest.WitnesstoIncident.valueHasMutated();
                    return false;
                }
                return true;
            },
            validateCommanderReviewFields: function () {
                result = ko.validation.group(uof.ui.incident.deputy.viewModel.WatchCommander, { deep: true });
                if (result().length > 0) {
                    uof.ui.incident.deputy.viewModel.WatchCommander.EmployeeNumber.valueHasMutated();
                    uof.ui.incident.deputy.viewModel.WatchCommander.Rank.valueHasMutated();
                    return false;
                }
                return true;
            },
            setApprovedIncidentinSession: function (incidentId) {
                $.ajax(
                     {
                         url: window.location.uofUIOrigin() + '/Incident/setApprovedIncident',
                         type: "POST",
                         data: { incidentID: incidentId },
                         success: function (data) {
                             if (data == "true")
                                 window.location.href = window.location.uofUIOrigin() + '/Incident/Incident';
                         },
                         error: function (e) {
                             showAlert(e.responseText);
                         },
                     });
            },
        }
    }();
}