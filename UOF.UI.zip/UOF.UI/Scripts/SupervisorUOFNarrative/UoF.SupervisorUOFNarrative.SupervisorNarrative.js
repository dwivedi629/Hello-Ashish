﻿var uof = uof || {};
uof.ui = uof.ui || {};
uof.ui.SupervisorUOFNarrative = uof.ui.SupervisorUOFNarrative || {};

if (uof.ui.SupervisorUOFNarrative) {
    uof.ui.SupervisorUOFNarrative.detail = function () {
        return {
            parameters: null,
            isChanged: false,
            init: function (args) {
                this.parameters = args;
            },
            SupervisorUOFNarrativeDBSource: null,

            ParameterCriteria: {
                IncidentReviewId: 0,
                employeeId: '',
                incidentId: 0,
                formId: 0,
                formDataId: 0
            },
            viewModel: {
                IncidentReviewId: ko.observable(0),
                FormDataId: ko.observable(0),
                IsFormOwner: ko.observable(false),
                IsOnlySave: ko.observable(true),
                IsIncidentOwner: ko.observable(false),
                IsLock: ko.observable(false),
                IsSupervisorStatus: ko.observable(false),
                IsSupervisorOrApprover: ko.observable(false),
                SubmitedId: ko.observable(),
                IncidentID: ko.observable(),
                FormID: ko.observable(),
                EmpID: ko.observable(),
                UserRoleId: ko.observable(),
                UserRole: ko.observable(),
                IncidentInformation: {
                    SceneDescription: ko.observable(),
                    MedicalOrder: ko.observable(false),
                    CourtOrder: ko.observable(false),
                    PassiveResistance: ko.observable(false),
                    ActiveverbalResistance: ko.observable(false),
                    ActivephysicalResistance: ko.observable(false),
                    LawEnforcement: ko.observable(false),
                    SeriousBodilyInjury: ko.observable(false),
                    AssaultiveOthers: ko.observable(false),
                    DeathTowardOthers: ko.observable(false),
                    OtherThreats: ko.observable(false),
                    OtherThreatsReason: ko.observable(""),
                    PersonnelOtherReason: ko.observable(""),
                    MechanicalOthersReason: ko.observable(""),
                    ThreatDescription: ko.observable(),
                    ChemicalAgent: ko.observable(false),
                    Pepperball: ko.observable(false),
                    PersonalWeapon: ko.observable(false),
                    TaserApplication: ko.observable(false),
                    ControlTechniques: ko.observable(false),
                    Takedown: ko.observable(false),
                    ImpactWeapon: ko.observable(false),
                    Stunbag: ko.observable(false),
                    CarotidRestraint: ko.observable(false),
                    Personnelk9: ko.observable(false),
                    Firearm: ko.observable(false),
                    PersonnelOther: ko.observable(false),
                    DescribeType: ko.observable(),
                    ForceUsedNo: ko.observable(false),
                    Handcuffs: ko.observable(false),
                    HobbleRestraint: ko.observable(false),
                    SafetyChair: ko.observable(false),
                    FixedObject: ko.observable(false),
                    WaistChain: ko.observable(false),
                    TARP: ko.observable(false),
                    Wheelchair: ko.observable(false),
                    Mechanicalk9: ko.observable(false),
                    MechanicalOthers: ko.observable(false),
                    suspectArmed: ko.observable(false),
                    suspectArmedReason: ko.observable(""),
                    Struck: ko.observable(false),
                    StruckReason: ko.observable(""),
                    Kicked: ko.observable(false),
                },
                Forcemitigation: {
                    VerbalCommands: ko.observable(),
                    SupervisorRequested: ko.observable(),
                    SupervisorPresent: ko.observable(),
                    BackUp: ko.observable(),
                    MitigationOthers: ko.observable(),
                    MitigationOthersReason: ko.observable(""),

                    //Enchacements
                    LastResort: ko.observable(),
                    InvolvedMinforce: ko.observable(),
                    Forceterminated: ko.observable(),
                    Noevidenceofprovocation: ko.observable(),
                    Noevidenceofforce: ko.observable(),
                    Noevidenceofexcessiveforce: ko.observable(),
                    ExcessiveforceReason: ko.observable(),
                    StaffMembers: ko.observable(),
                    Noevidenceofunreasonable: ko.observable(),
                    chemicalsORelectronicdevices: ko.observable(),
                    DepartmentMembers: ko.observable(),
                    Extentpossible: ko.observable(),
                    Inmatewascontrolled: ko.observable(),
                    UseofSafetyChair: ko.observable(),
                    UseofMultiPoint: ko.observable(),
                },
                Reported: {
                    ForceReportingYN: ko.observable(),
                    ForceReportingNoReason: ko.observable(),
                    WrittenReportYN: ko.observable(),
                    WrittenReportNoReason: ko.observable(""),
                    InconsistenciesDocYN: ko.observable(),
                    InconsistenciesDocYesReason: ko.observable(""),
                    AdmonishmentYN: ko.observable(),
                    AdmonishmentNoReason: ko.observable(""),

                    //Added
                    DeptMemberYN: ko.observable(),
                    DeptMemberReason: ko.observable(""),

                    DMUsingForceYN: ko.observable(),
                    DMUsingForceReason: ko.observable(""),

                },
                Notification: {
                    NotificationsToIABYN: ko.observable(),
                    NotificationsToIABNoReason: ko.observable(""),

                    NotificationsToCFRTYN: ko.observable(),
                    NotificationsToCFRTNoReason: ko.observable(),
                },
                Witness: {
                    InmateWitYN: ko.observable(),
                    InmateWitReason: ko.observable(),

                    WitnessInterview: ko.observable(),
                },
                WC: {
                    PersonnelInvolvedYN: ko.observable(),
                    PersonnelInvolvedYesReason: ko.observable(""),
                    SuspectStatement: ko.observable(),
                    //Added
                    PerInvolvedYN: ko.observable(),
                    PerInvolvedReason: ko.observable(""),
                },
                Medical: {
                    SuspectInjuredYN: ko.observable(),
                    SuspectInjuredYesReason: ko.observable(""),

                    SuspectAllegedYN: ko.observable(),
                    SuspectAllegedYesReason: ko.observable(""),

                    SuspectReceiveYN: ko.observable(),
                    SuspectReceiveNoReason: ko.observable(""),

                    MedicalTreatmentYN: ko.observable(),
                    MedicalTreatmentNoReason: ko.observable(""),

                    SuspectTransportedYN: ko.observable(),
                    SuspectTransportedNoReason: ko.observable(""),

                    InjuriesDocumentedYN: ko.observable(),
                    InjuriesDocumentedNoReason: ko.observable(""),
                    //InjuriesDocumentedNAReason: ko.observable(),

                    InjuriesAppearsConsistentYN: ko.observable(),
                    InjuriesAppearsConsistentNoReason: ko.observable(""),
                    //InjuriesAppearsConsistentNAReason: ko.observable(),

                    SuspectKnowsInjuriesYN: ko.observable(),
                    SuspectKnowsInjuriesYesReason: ko.observable(),

                    InvolvedEmpInjConsistentYN: ko.observable(),
                    InvolvedEmpInjConsistentNoReason: ko.observable(""),
                    //InvolvedEmpInjConsistentNAReason: ko.observable(),


                    InjuriesWereNotBelivedYN: ko.observable(),
                    InjuriesWereNotBelivedYesReason: ko.observable(""),

                    //Added
                    InjuriesAddtionalYN: ko.observable(),
                    InjuriesAddtionalReason: ko.observable(""),

                    PhotographsYN: ko.observable(),
                    DocumentationYN: ko.observable(),
                },
                Training: {
                    OtherForceOptions: ko.observable(),
                    Reassessment: ko.observable(),
                    TrainingRecommendations: ko.observable(),

                    WeaponsUsedYN: ko.observable(),
                    WeaponsUsedNoReason: ko.observable(""),

                    WeaponsAppDeptYN: ko.observable(),
                    WeaponsAppDeptNoReason: ko.observable(""),

                    PersonTrainedYN: ko.observable(),
                    PersonTrainedNoReason: ko.observable(""),

                    ListAnyEquipment: ko.observable(),

                    IncidentDebriefingYN: ko.observable(),
                    IncidentDebriefingNoReason: ko.observable(),

                    OtherTopics: ko.observable(),
                },
                CaseStatus: {
                    SubmittedToAttorneyYes: ko.observable(false),
                    SubmittedToAttorneyNo: ko.observable(false),
                    SubmittedToAttorneyNoReason: ko.observable(""),
                    CaseNumber: ko.observable(),
                    DateFiled: ko.observable(),
                    Charges: ko.observable(),
                    CaseDisposition: ko.observable(),
                    RejectComments: ko.observable(),
                },

            },

            load: function () {
                ko.validation.init({ insertMessages: true });

                uof.ui.SupervisorUOFNarrative.detail.validateControls();
                uof.ui.SupervisorUOFNarrative.detail.subscribeMethod();

                //binding SupervisorUOFNarrative Report page
                ko.cleanNode($("#IncidentInfo").get(0));
                ko.applyBindings(uof.ui.SupervisorUOFNarrative.detail.viewModel, $("#IncidentInfo").get(0));
                ////Victim
                ko.cleanNode($("#Forcemitigation").get(0));
                ko.applyBindings(uof.ui.SupervisorUOFNarrative.detail.viewModel, $("#Forcemitigation").get(0));

                //Suspect
                ko.cleanNode($("#Reported").get(0));
                ko.applyBindings(uof.ui.SupervisorUOFNarrative.detail.viewModel, $("#Reported").get(0));

                //Deputy
                ko.cleanNode($("#Notification").get(0));
                ko.applyBindings(uof.ui.SupervisorUOFNarrative.detail.viewModel, $("#Notification").get(0));
                ////Vehicle
                ko.cleanNode($("#Witness").get(0));
                ko.applyBindings(uof.ui.SupervisorUOFNarrative.detail.viewModel, $("#Witness").get(0));
                //Screening
                ko.cleanNode($("#WC").get(0));
                ko.applyBindings(uof.ui.SupervisorUOFNarrative.detail.viewModel, $("#WC").get(0));
                //Property
                ko.cleanNode($("#Medical").get(0));
                ko.applyBindings(uof.ui.SupervisorUOFNarrative.detail.viewModel, $("#Medical").get(0));
                //Property
                ko.cleanNode($("#Training").get(0));
                ko.applyBindings(uof.ui.SupervisorUOFNarrative.detail.viewModel, $("#Training").get(0));
                ////Property
                ko.cleanNode($("#CaseStatus").get(0));
                ko.applyBindings(uof.ui.SupervisorUOFNarrative.detail.viewModel, $("#CaseStatus").get(0));

                uof.ui.SupervisorUOFNarrative.detail.initiateBindings();
                if (UoFParams.IncidentId > 0) {
                    uof.ui.SupervisorUOFNarrative.detail.viewModel.FormID($.UoFformId);
                    uof.ui.SupervisorUOFNarrative.detail.viewModel.EmpID($.SubmitedId);
                    uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentID(UoFParams.IncidentId);
                }
                uof.ui.SupervisorUOFNarrative.detail.bindApproveorEdit();
                $(document).on('keyup', "#txtReject", function (e) {
                    var Commtstring = $.trim($("#txtReject").val());
                    if (Commtstring.length > 0) {
                        $("#btnReject").prop('disabled', false);
                        $("#btnApprove").prop('disabled', true);
                    }
                    else {
                        $("#btnReject").prop('disabled', true);
                        $("#btnApprove").prop('disabled', false);
                    }
                });
            },

            bindApproveorEdit: function () {
                if (localStorage.getItem('formMode') == "View" || localStorage.getItem('formMode') == "Approve") {
                    if ($.IncidentId.length > 0 && $.UoFformId.length > 0 && $.SubmitedId.length > 0) {
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentID($.IncidentId);
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.FormID($.UoFformId);
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.EmpID($.SubmitedId);
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.SubmitedId($.SubmitedId);
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.UserRole(UoFParams.userRole);
                    }
                    uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentReviewId(localStorage.getItem('IncidentReviewId') == null ? 0 : localStorage.getItem('IncidentReviewId'));
                    uof.ui.SupervisorUOFNarrative.detail.viewModel.FormDataId(localStorage.getItem('FormDataId') == null ? 0 : localStorage.getItem('FormDataId'));
                }
                else {
                    uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentID(UoFParams.IncidentId);
                    uof.ui.SupervisorUOFNarrative.detail.viewModel.FormID($.UoFformId);
                    uof.ui.SupervisorUOFNarrative.detail.viewModel.EmpID(UoFParams.userId);
                    uof.ui.SupervisorUOFNarrative.detail.viewModel.SubmitedId(localStorage.getItem('SubmittedId') == null ? UoFParams.userId : localStorage.getItem('SubmittedId'));
                    uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentReviewId(localStorage.getItem('IncidentReviewId') == null ? 0 : localStorage.getItem('IncidentReviewId'));
                    uof.ui.SupervisorUOFNarrative.detail.viewModel.FormDataId(localStorage.getItem('FormDataId') == null ? 0 : localStorage.getItem('FormDataId'));
                }

                //if (uof.ui.CommonUILogic.detail.isFormStatusCompleted($.UoFformId, UoFParams.IncidentId)) {
                //    $("#btnReset").addClass('hide');
                //    $("#btnSave").addClass('hide');
                //    $("#btnApprove").addClass('hide');
                //    $("#btnReject").addClass('hide');
                //}

                uof.ui.SupervisorUOFNarrative.detail.bindNarrativeDetails();
            },

            buildNarrObject: function (isApprove) {
                var oNRData = new Object();
                oNRData.IncidentId = $.IncidentId;
                oNRData.FormId = $.UoFformId;
                oNRData.DeputyEmpId = $.SubmitedId;
                oNRData.isApprove = isApprove;
                oNRData.ReviewerReviewId = UoFParams.userId;
                oNRData.ReviewerRole = UoFParams.userRole;
                oNRData.Comment = uof.ui.SupervisorUOFNarrative.detail.viewModel.CaseStatus.RejectComments();
                oNRData.IncidentReviewId = uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentReviewId();
                return oNRData;
            },
            approveNarrDetails: function (isApprove) {
                var str = isApprove == "Y" ? "Do you want to Approve?" : "Do you want to Reject?";
                $.when(showConfirmationWindow(str)).then(function (confirmed) {
                    if (confirmed) {
                        var oNRData = uof.ui.SupervisorUOFNarrative.detail.buildNarrObject(isApprove);
                        var mappedData = ko.mapping.toJS(oNRData);
                        $.ajax(
                              {
                                  url: window.location.uofAPIOrigin() + '/api/UOFForm/ApproveorReject',
                                  cache: false,
                                  type: "POST",
                                  dataType: 'json',
                                  data: JSON.stringify(mappedData),
                                  contentType: "application/json;charset=utf-8",
                                  beforeSend: function myfunction() {

                                  },
                                  success: function (data) {
                                      $.prototype.hideUofOverlay();
                                      showAlert((isApprove == "Y" ? "Approved" : "Rejected") + " Succesfully");
                                      uof.ui.SupervisorUOFNarrative.detail.setApprovedIncidentinSession(oNRData.IncidentId);
                                      // window.location.href = window.location.uofUIOrigin() + '/Incident/Incident' + '?IncidentId=' + oNRData.IncidentId;
                                  },
                                  error: function (e) {
                                      $.prototype.hideUofOverlay();
                                      showAlert(e.responseText);
                                  },
                              });
                    }

                });
            },
            setApprovedIncidentinSession: function (incidentId) {
                $.ajax(
                     {
                         url: window.location.uofUIOrigin() + '/Incident/setApprovedIncident',
                         type: "POST",
                         data: { incidentID: incidentId },
                         success: function (data) {
                             if (data == "true")
                                 window.location.href = window.location.uofUIOrigin() + '/Incident/Incident';
                         },
                         error: function (e) {
                             showAlert(e.responseText);
                         },
                     });
            },
            saveSupervisorUOFNarrativeReportDetails: function () {
                if (uof.ui.SupervisorUOFNarrative.detail.validateSupervisorUOFNarrativeReportFields()) {
                    //Placeholder for calling API method to save SupervisorUOFNarrative Report data
                }
            },
            initiateBindings: function () {
                ko.validation.insertValidationMessage = function (element) {
                    var br = document.createElement("br");
                    element.appendChild(br);
                    var span = document.createElement('SPAN');
                    span.className = "warning-msg";
                    var inputGroups = $(element).closest(".date"); //This is for getting Date Fields
                    if (inputGroups.length > 0) {
                        // We're in an input-group so we place the message after
                        // the group rather than inside it in order to not break the design
                        $(span).insertAfter(inputGroups);
                    }
                    else {
                        // The default in knockout-validation
                        element.parentNode.insertBefore(span, element.nextSibling);
                    }
                    return span;
                };
                $('#DateField').datetimepicker().on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.SupervisorUOFNarrative.detail.viewModel.CaseStatus.DateFiled(newDate);
                });
            },



            subscribeMethod: function () {
                // Subscribing the name and code to get changes

                uof.ui.SupervisorUOFNarrative.detail.viewModel.Forcemitigation.Noevidenceofexcessiveforce.subscribe(function (newValue) {
                    if (newValue) {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Forcemitigation.ExcessiveforceReason.valueHasMutated();
                        return false;
                    }
                    else if (!newValue)
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Forcemitigation.ExcessiveforceReason(null);
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Forcemitigation.MitigationOthers.subscribe(function (newValue) {
                    if (newValue) {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Forcemitigation.MitigationOthersReason.valueHasMutated();
                        return false;
                    }
                    else if (!newValue)
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Forcemitigation.MitigationOthersReason(null);
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.OtherThreats.subscribe(function (newValue) {
                    if (newValue) {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.OtherThreatsReason.valueHasMutated();
                        return false;
                    }
                    else if (!newValue)
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.OtherThreatsReason(null);

                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.suspectArmed.subscribe(function (newValue) {
                    if (newValue) {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.suspectArmedReason.valueHasMutated();
                        return false;
                    }
                    else if (!newValue)
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.suspectArmedReason(null);

                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.PersonnelOther.subscribe(function (newValue) {
                    if (newValue) {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.PersonnelOtherReason.valueHasMutated();
                        return false;
                    }
                    else if (!newValue)
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.PersonnelOtherReason(null);
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.Struck.subscribe(function (newValue) {
                    if (newValue) {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.StruckReason.valueHasMutated();
                        return false;
                    }
                    else if (!newValue)
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.StruckReason(null);
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.MechanicalOthers.subscribe(function (newValue) {
                    if (newValue) {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.MechanicalOthersReason.valueHasMutated();
                        return false;
                    }
                    else if (!newValue)
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.MechanicalOthersReason(null);
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported.ForceReportingYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "N") {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported.ForceReportingNoReason.valueHasMutated();
                        return false;
                    }
                    else if (!($.trim(newValue) == "N"))
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported.ForceReportingNoReason(null);
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported.WrittenReportYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "N") {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported.WrittenReportNoReason.valueHasMutated();
                        return false;
                    }
                    else if (!($.trim(newValue) == "N"))
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported.WrittenReportNoReason(null);
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported.InconsistenciesDocYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "Y") {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported.InconsistenciesDocYesReason.valueHasMutated();
                        return false;
                    }
                    else if (!($.trim(newValue) == "Y"))
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported.InconsistenciesDocYesReason(null);
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported.AdmonishmentYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "N") {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported.AdmonishmentNoReason.valueHasMutated();
                        return false;
                    }
                    else if (!($.trim(newValue) == "N"))
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported.AdmonishmentNoReason(null);
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported.DeptMemberYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "N") {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported.DeptMemberReason.valueHasMutated();
                        return false;
                    }
                    else if (!($.trim(newValue) == "N"))
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported.DeptMemberReason(null);
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported.DMUsingForceYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "N") {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported.DMUsingForceReason.valueHasMutated();
                        return false;
                    }
                    else if (!($.trim(newValue) == "N"))
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported.DMUsingForceReason(null);
                });

                //Notifications
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Notification.NotificationsToIABYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "N") {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Notification.NotificationsToIABNoReason.valueHasMutated();
                        return false;
                    }
                    else if (!($.trim(newValue) == "N"))
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Notification.NotificationsToIABNoReason(null);
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Notification.NotificationsToCFRTYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "N") {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Notification.NotificationsToCFRTNoReason.valueHasMutated();
                        return false;
                    }
                    else if (!($.trim(newValue) == "N"))
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Notification.NotificationsToCFRTNoReason(null);
                });
                //End
                //Witeness

                uof.ui.SupervisorUOFNarrative.detail.viewModel.Witness.InmateWitYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "N") {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Witness.InmateWitReason.valueHasMutated();
                        return false;
                    }
                    else if (!($.trim(newValue) == "N"))
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Witness.InmateWitReason(null);
                });
                //End
                //Watch Commander
                uof.ui.SupervisorUOFNarrative.detail.viewModel.WC.PersonnelInvolvedYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "Y") {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.WC.PersonnelInvolvedYesReason.valueHasMutated();
                        return false;
                    }
                    else if (!($.trim(newValue) == "Y"))
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.WC.PersonnelInvolvedYesReason(null);
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.WC.PerInvolvedYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "Y") {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.WC.PerInvolvedReason.valueHasMutated();
                        return false;
                    }
                    else if (!($.trim(newValue) == "Y"))
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.WC.PerInvolvedReason(null);
                });
                //End
                //Medical
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.SuspectInjuredYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "Y") {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.SuspectInjuredYesReason.valueHasMutated();
                        return false;
                    }
                    else if (!($.trim(newValue) == "Y"))
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.SuspectInjuredYesReason(null);
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.SuspectAllegedYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "Y") {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.SuspectAllegedYesReason.valueHasMutated();
                        return false;
                    }
                    else if (!($.trim(newValue) == "Y"))
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.SuspectAllegedYesReason(null);
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.SuspectReceiveYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "N") {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.SuspectReceiveNoReason.valueHasMutated();
                        return false;
                    }
                    else if (!($.trim(newValue) == "N"))
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.SuspectReceiveNoReason(null);
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.MedicalTreatmentYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "N") {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.MedicalTreatmentNoReason.valueHasMutated();
                        return false;
                    }
                    else if (!($.trim(newValue) == "N"))
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.MedicalTreatmentNoReason(null);
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.SuspectTransportedYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "N") {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.SuspectTransportedNoReason.valueHasMutated();
                        return false;
                    }
                    else if (!($.trim(newValue) == "N"))
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.SuspectTransportedNoReason(null);
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.InjuriesDocumentedYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "N") {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.InjuriesDocumentedNoReason.valueHasMutated();
                        return false;
                    }
                    else if (!($.trim(newValue) == "N"))
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.InjuriesDocumentedNoReason(null);
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.InjuriesAppearsConsistentYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "N") {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.InjuriesAppearsConsistentNoReason.valueHasMutated();
                        return false;
                    }
                    else if (!($.trim(newValue) == "N"))
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.InjuriesAppearsConsistentNoReason(null);
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.SuspectKnowsInjuriesYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "Y") {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.SuspectKnowsInjuriesYesReason.valueHasMutated();
                        return false;
                    }
                    else if (!($.trim(newValue) == "Y"))
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.SuspectKnowsInjuriesYesReason(null);
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.InvolvedEmpInjConsistentYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "N") {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.InvolvedEmpInjConsistentNoReason.valueHasMutated();
                        return false;
                    }
                    if (!($.trim(newValue) == "N"))
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.InvolvedEmpInjConsistentNoReason(null);
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.InjuriesWereNotBelivedYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "Y") {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.InjuriesWereNotBelivedYesReason.valueHasMutated();
                        return false;
                    }
                    else if (!($.trim(newValue) == "Y"))
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.InjuriesWereNotBelivedYesReason(null);
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.InjuriesAddtionalYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "Y") {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.InjuriesAddtionalReason.valueHasMutated();
                        return false;
                    }
                    else if (!($.trim(newValue) == "Y"))
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.InjuriesAddtionalReason(null);
                });

                //End
                //Training
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.WeaponsUsedYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "N") {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.WeaponsUsedNoReason.valueHasMutated();
                        return false;
                    }
                    else if (!($.trim(newValue) == "N"))
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.WeaponsUsedNoReason(null);
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.WeaponsAppDeptYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "N") {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.WeaponsAppDeptNoReason.valueHasMutated();
                        return false;
                    }
                    else if (!($.trim(newValue) == "N"))
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.WeaponsAppDeptNoReason(null);
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.PersonTrainedYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "N") {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.PersonTrainedNoReason.valueHasMutated();
                        return false;
                    }
                    else if (!($.trim(newValue) == "N"))
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.PersonTrainedNoReason(null);
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.IncidentDebriefingYN.subscribe(function (newValue) {
                    if ($.trim(newValue)) {
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.IncidentDebriefingNoReason(null);
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.IncidentDebriefingNoReason.valueHasMutated();
                        return false;
                    }
                    //else if (!($.trim(newValue) == "N"))
                    //    uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.IncidentDebriefingNoReason(null);
                    //else if (!($.trim(newValue) == "Y"))
                    //    uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.IncidentDebriefingNoReason(null);
                });

                //End
                //Case Status
                uof.ui.SupervisorUOFNarrative.detail.viewModel.CaseStatus.SubmittedToAttorneyYes.subscribe(function (newValue) {
                    if (newValue) {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.CaseStatus.CaseNumber.valueHasMutated();
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.CaseStatus.DateFiled.valueHasMutated();
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.CaseStatus.Charges.valueHasMutated();
                        return false;
                    }
                    else if (!newValue)
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.CaseStatus.CaseNumber(null);
                    uof.ui.SupervisorUOFNarrative.detail.viewModel.CaseStatus.DateFiled(null);
                    uof.ui.SupervisorUOFNarrative.detail.viewModel.CaseStatus.Charges(null);
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.CaseStatus.SubmittedToAttorneyNo.subscribe(function (newValue) {
                    if (newValue) {
                        uof.ui.SupervisorUOFNarrative.detail.isChanged = true;
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.CaseStatus.SubmittedToAttorneyNoReason.valueHasMutated();
                        return false;
                    }
                    else if (!newValue)
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.CaseStatus.SubmittedToAttorneyNoReason(null);
                });
                //End
            },
            validateControls: function () {
                $(".validationMessage").each(function () {
                    $(this).remove();
                });
                //SceneDescription
                uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.SceneDescription.extend({
                    required: {
                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required
                        //message:"Required"
                    }
                });
                //ThreatDescription
                uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.ThreatDescription.extend({
                    required: {
                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required
                    }
                });
                ////DescribeType
                uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.DescribeType.extend({
                    required: {
                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.OtherThreatsReason.extend({
                    required: {
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.OtherThreats() === true);
                        }
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.suspectArmedReason.extend({
                    required: {
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.suspectArmed() === true);
                        }
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.MechanicalOthersReason.extend({
                    required: {
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.MechanicalOthers() === true);
                        }
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.PersonnelOtherReason.extend({
                    required: {
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.PersonnelOther() === true);
                        }
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.StruckReason.extend({
                    required: {
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.Struck() === true);
                        }
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Forcemitigation.MitigationOthersReason.extend({
                    required: {
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.Forcemitigation.MitigationOthers() === true);
                        }
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Forcemitigation.ExcessiveforceReason.extend({
                    required: {
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.Forcemitigation.Noevidenceofexcessiveforce() === true);
                        }
                    }
                });

                //Witness
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Witness.WitnessInterview.extend({
                    required: {
                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required
                    }
                });
                //**************** Reported *******
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported.ForceReportingNoReason.extend({
                    required: {
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported.ForceReportingYN() === 'N');
                        }
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported.WrittenReportNoReason.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported.WrittenReportYN() === 'N');
                        }
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported.InconsistenciesDocYesReason.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported.InconsistenciesDocYN() === 'Y');
                        }
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported.AdmonishmentNoReason.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported.AdmonishmentYN() === 'N');
                        }
                    }
                });

                uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported.DeptMemberReason.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported.DeptMemberYN() === 'N');
                        }
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported.DMUsingForceReason.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported.DMUsingForceYN() === 'N');
                        }
                    }
                });
                //**** End Reported ****
                //**** NOtification
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Notification.NotificationsToIABNoReason.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.Notification.NotificationsToIABYN() === 'N');
                        }
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Notification.NotificationsToCFRTNoReason.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.Notification.NotificationsToCFRTYN() === 'N');
                        }
                    }
                });
                ///**** End of Notification ***
                //Witness
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Witness.InmateWitReason.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.Witness.InmateWitYN() === 'N');
                        }
                    }
                });
                //End
                //**** Watch Commander
                uof.ui.SupervisorUOFNarrative.detail.viewModel.WC.PersonnelInvolvedYesReason.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.WC.PersonnelInvolvedYN() === 'Y');
                        }
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.WC.PerInvolvedReason.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.WC.PerInvolvedYN() === 'Y');
                        }
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.WC.SuspectStatement.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required
                    }
                });
                //*** Medical
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.SuspectInjuredYesReason.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.SuspectInjuredYN() === 'Y');
                        }
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.SuspectAllegedYesReason.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.SuspectAllegedYN() === 'Y');
                        }
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.SuspectReceiveNoReason.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.SuspectReceiveYN() === 'N');
                        }
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.MedicalTreatmentNoReason.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.MedicalTreatmentYN() === 'N');
                        }
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.SuspectTransportedNoReason.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.SuspectTransportedYN() === 'N');
                        }
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.InjuriesDocumentedNoReason.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.InjuriesDocumentedYN() === 'N');
                        }
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.InjuriesAppearsConsistentNoReason.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.InjuriesAppearsConsistentYN() === 'N');
                        }
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.SuspectKnowsInjuriesYesReason.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.SuspectKnowsInjuriesYN() === 'Y');
                        }
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.InvolvedEmpInjConsistentNoReason.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.InvolvedEmpInjConsistentYN() === 'N');
                        }
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.InjuriesWereNotBelivedYesReason.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.InjuriesWereNotBelivedYN() === 'Y');
                        }
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.InjuriesAddtionalReason.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical.InjuriesAddtionalYN() === 'Y');
                        }
                    }
                });

                //End

                //Training

                uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.OtherForceOptions.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.TrainingRecommendations.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.Reassessment.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.ListAnyEquipment.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.OtherTopics.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.PersonTrainedNoReason.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.PersonTrainedYN() === 'N');
                        }
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.IncidentDebriefingNoReason.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.IncidentDebriefingYN() === 'N' || uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.IncidentDebriefingYN() === 'Y');
                        }
                    }
                });




                uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.WeaponsAppDeptNoReason.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.WeaponsAppDeptYN() === 'N');
                        }
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.WeaponsUsedNoReason.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.WeaponsUsedYN() === 'N');
                        }
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.TrainingRecommendations.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required
                    }
                });
                //End
                //Case
                uof.ui.SupervisorUOFNarrative.detail.viewModel.CaseStatus.CaseNumber.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.CaseStatus.SubmittedToAttorneyYes() === true);
                        }
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.CaseStatus.DateFiled.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.CaseStatus.SubmittedToAttorneyYes() === true);
                        }
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.CaseStatus.Charges.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.CaseStatus.SubmittedToAttorneyYes() === true);
                        }
                    }
                });
                uof.ui.SupervisorUOFNarrative.detail.viewModel.CaseStatus.SubmittedToAttorneyNoReason.extend({
                    required: {

                        params: true,
                        message: UoFSupervisorUOFNarrativeConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.SupervisorUOFNarrative.detail.viewModel.CaseStatus.SubmittedToAttorneyNo() === true);
                        }
                    }
                });
                //End

            },
            bindNarrativeDetails: function () {
                uof.ui.SupervisorUOFNarrative.detail.ParameterCriteria.IncidentReviewId = uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentReviewId();
                uof.ui.SupervisorUOFNarrative.detail.ParameterCriteria.formDataId = uof.ui.SupervisorUOFNarrative.detail.viewModel.FormDataId();
                uof.ui.SupervisorUOFNarrative.detail.ParameterCriteria.employeeId = uof.ui.SupervisorUOFNarrative.detail.viewModel.EmpID();
                uof.ui.SupervisorUOFNarrative.detail.ParameterCriteria.incidentId = uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentID();
                uof.ui.SupervisorUOFNarrative.detail.ParameterCriteria.formId = uof.ui.SupervisorUOFNarrative.detail.viewModel.FormID();//e.data.FormId;
                var model = ko.mapping.toJS(uof.ui.SupervisorUOFNarrative.detail.ParameterCriteria);
                $.prototype.showUofOverlay();
                $.ajax(
                       {
                           url: window.location.uofAPIOrigin() + '/api/UOFForm/GetUoFNarrativeInfo',
                           cache: false,
                           //data: { FormId: uof.ui.SupervisorUOFNarrative.detail.viewModel.FormID(), IncidentId: uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentID(), EmpId: uof.ui.SupervisorUOFNarrative.detail.viewModel.EmpID() },
                           data: JSON.stringify(model),
                           type: "POST",
                           dataType: 'json',
                           contentType: "application/json;charset=utf-8",
                           beforeSend: function myfunction() {

                           },
                           success: function (data) {
                               if (data != null) {
                                   uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation = ko.mapping.fromJS(data.incidentInformation, ko.mapping.toJS(uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation));
                                   uof.ui.SupervisorUOFNarrative.detail.viewModel.Forcemitigation = ko.mapping.fromJS(data.forceMitigation, ko.mapping.toJS(uof.ui.SupervisorUOFNarrative.detail.viewModel.Forcemitigation));
                                   uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported = ko.mapping.fromJS(data.reported, ko.mapping.toJS(uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported));
                                   uof.ui.SupervisorUOFNarrative.detail.viewModel.Notification = ko.mapping.fromJS(data.notification, ko.mapping.toJS(uof.ui.SupervisorUOFNarrative.detail.viewModel.Notification));
                                   uof.ui.SupervisorUOFNarrative.detail.viewModel.Witness = ko.mapping.fromJS(data.witness, ko.mapping.toJS(uof.ui.SupervisorUOFNarrative.detail.viewModel.Witness));
                                   uof.ui.SupervisorUOFNarrative.detail.viewModel.WC = ko.mapping.fromJS(data.wc, ko.mapping.toJS(uof.ui.SupervisorUOFNarrative.detail.viewModel.WC));
                                   uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical = ko.mapping.fromJS(data.medical, ko.mapping.toJS(uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical));
                                   uof.ui.SupervisorUOFNarrative.detail.viewModel.Training = ko.mapping.fromJS(data.training, ko.mapping.toJS(uof.ui.SupervisorUOFNarrative.detail.viewModel.Training));
                                   uof.ui.SupervisorUOFNarrative.detail.viewModel.CaseStatus = ko.mapping.fromJS(data.caseStatus, ko.mapping.toJS(uof.ui.SupervisorUOFNarrative.detail.viewModel.CaseStatus));

                                   uof.ui.SupervisorUOFNarrative.detail.validateControls();
                                   uof.ui.SupervisorUOFNarrative.detail.subscribeMethod();

                                   //binding SupervisorUOFNarrative Report page
                                   ko.cleanNode($("#IncidentInfo").get(0));
                                   ko.applyBindings(uof.ui.SupervisorUOFNarrative.detail.viewModel, $("#IncidentInfo").get(0));
                                   ////Victim
                                   ko.cleanNode($("#Forcemitigation").get(0));
                                   ko.applyBindings(uof.ui.SupervisorUOFNarrative.detail.viewModel, $("#Forcemitigation").get(0));

                                   //Suspect
                                   ko.cleanNode($("#Reported").get(0));
                                   ko.applyBindings(uof.ui.SupervisorUOFNarrative.detail.viewModel, $("#Reported").get(0));

                                   //Deputy
                                   ko.cleanNode($("#Notification").get(0));
                                   ko.applyBindings(uof.ui.SupervisorUOFNarrative.detail.viewModel, $("#Notification").get(0));
                                   ////Vehicle
                                   ko.cleanNode($("#Witness").get(0));
                                   ko.applyBindings(uof.ui.SupervisorUOFNarrative.detail.viewModel, $("#Witness").get(0));
                                   //Screening
                                   ko.cleanNode($("#WC").get(0));
                                   ko.applyBindings(uof.ui.SupervisorUOFNarrative.detail.viewModel, $("#WC").get(0));
                                   //Property
                                   ko.cleanNode($("#Medical").get(0));
                                   ko.applyBindings(uof.ui.SupervisorUOFNarrative.detail.viewModel, $("#Medical").get(0));
                                   //Property
                                   ko.cleanNode($("#Training").get(0));
                                   ko.applyBindings(uof.ui.SupervisorUOFNarrative.detail.viewModel, $("#Training").get(0));
                                   ////Property
                                   ko.cleanNode($("#CaseStatus").get(0));
                                   ko.applyBindings(uof.ui.SupervisorUOFNarrative.detail.viewModel, $("#CaseStatus").get(0));

                                   if (uof.ui.SupervisorUOFNarrative.detail.viewModel.CaseStatus.RejectComments() != "") {
                                       $(".fakeclass").removeClass('hide');
                                       $("#txtReject").attr('disabled', false);
                                   }

                               }
                               uof.ui.SupervisorUOFNarrative.detail.toggleControls();
                               $.prototype.hideUofOverlay();
                           },
                           error: function (e) {
                               $.prototype.hideUofOverlay();
                               showAlert(e.responseText);

                           },
                       });

            },
            toggleControls: function () {
                uof.ui.SupervisorUOFNarrative.detail.viewModel.SubmitedId(localStorage.getItem('SubmittedId') == null ? UoFParams.userId : localStorage.getItem('SubmittedId'));
                uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentReviewId(localStorage.getItem('IncidentReviewId') == null ? 0 : localStorage.getItem('IncidentReviewId'))
                var formData = uof.ui.CommonUILogic.detail.isFormStatusCompleted($.UoFformId, UoFParams.IncidentId, uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentReviewId());
                if (formStatus != "") {
                    var formStatus = formData.split('\r\n');
                    uof.ui.SupervisorUOFNarrative.detail.viewModel.IsFormOwner(formStatus[0].split(':')[1].toLowerCase() == "true" ? true : false);
                    uof.ui.SupervisorUOFNarrative.detail.viewModel.IsIncidentOwner(formStatus[1].split(':')[1].toLowerCase() == "true" ? true : false);
                    if (formStatus.length > 2) {
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.IsLock(formStatus[2].split(':')[1].toLowerCase() == "true" ? true : false);
                        uof.ui.SupervisorUOFNarrative.detail.viewModel.IsSupervisorStatus(formStatus[3].split(':')[1].toLowerCase());
                    }
                    if (uof.ui.SupervisorUOFNarrative.detail.viewModel.IsLock()) {
                        $("#vertical-tabs *").find('input, select, textarea').each(function () {
                            $(this).attr('disabled', true);
                        });
                        $('.fakeSave').addClass('hide');
                        $("#btnReset").addClass('hide'); $("#btnSave").addClass('hide');
                        $("#btnApprove").addClass('hide'); $("#btnReject").addClass('hide');
                        if (localStorage.getItem('formMode') == "Approve") {
                            $("#btnApprove").prop('disabled', false); $("#btnApprove").removeClass('hide');
                            $("#btnReject").prop('disabled', true); $("#btnReject").removeClass('hide');
                            uof.ui.SupervisorUOFNarrative.detail.viewModel.IsSupervisorOrApprover(true);
                            $(".fakeclass").removeClass('hide');
                            $("#txtReject").attr('disabled', false);
                            //$('#divApproval:first > *').find('input').each(function () {
                            //    $(this).attr('disabled', false);
                            //});
                            //uof.ui.inmate.detail.validateControls();
                        }
                    }
                    else {
                        $("#btnApprove").addClass('hide'); $("#btnReject").addClass('hide');
                        if (!uof.ui.SupervisorUOFNarrative.detail.viewModel.IsFormOwner() && uof.ui.SupervisorUOFNarrative.detail.viewModel.IsSupervisorStatus() == "pending") {
                            $("#vertical-tabs *").find('input, select, textarea').each(function () {
                                $(this).attr('disabled', true);
                            });
                            $("#btnReset").addClass('hide'); $("#btnSave").addClass('hide');
                            $("#btnApprove").addClass('hide'); $("#btnReject").addClass('hide');
                            $('.fakeSave').addClass('hide');
                            if (localStorage.getItem('formMode') == "Approve") {
                                $("#btnApprove").prop('disabled', false); $("#btnApprove").removeClass('hide');
                                $("#btnReject").prop('disabled', true); $("#btnReject").removeClass('hide');
                                uof.ui.SupervisorUOFNarrative.detail.viewModel.IsSupervisorOrApprover(true);
                                $(".fakeclass").removeClass('hide');
                                $("#txtReject").attr('disabled', false);
                                //$("#divApproval").css({ style: "display:block" });
                                //$('#divApproval:first > *').find('input').each(function () {
                                //    $(this).attr('disabled', false);
                                //});
                            }
                        }
                    }
                }
            },
            saveNarrativeInfo: function (IsOnlySave) {
                //Save Method
                uof.ui.SupervisorUOFNarrative.detail.viewModel.IsOnlySave(IsOnlySave);
                uof.ui.SupervisorUOFNarrative.detail.viewModel.FormID($.UoFformId);
                uof.ui.SupervisorUOFNarrative.detail.viewModel.UserRole(UoFParams.userRole);
                uof.ui.SupervisorUOFNarrative.detail.viewModel.EmpID(UoFParams.userId);
                if (UoFParams.IncidentId > 0)
                    uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentID(UoFParams.IncidentId);
                else
                    uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentID($.IncidentId);

                var jsonDate = ko.mapping.toJS(uof.ui.SupervisorUOFNarrative.detail.viewModel);
                $.prototype.showUofOverlay();
                $.ajax(
                  {
                      url: window.location.uofAPIOrigin() + '/api/UOFForm/SaveUoFNarrative',
                      cache: false,
                      type: "POST",
                      dataType: 'json',
                      data: JSON.stringify(jsonDate),
                      contentType: "application/json;charset=utf-8",
                      beforeSend: function myfunction() {

                      },
                      success: function (data) {
                          $.prototype.hideUofOverlay();
                          uof.ui.SupervisorUOFNarrative.detail.viewModel.FormDataId(data);
                          showAlert(IsOnlySave ? "Data saved successfully" : "submited successfully");
                      },
                      error: function (e) {
                          $.prototype.hideUofOverlay();
                          showAlert(e.responseText);
                          localStorage.setItem('selectedIncidentId', 4);//just for testing, Put actual incidentId here
                          uof.ui.incident.detail.selectedContext.selectedIncident(4);
                          
                      },
                  });
            },
            saveNarrativeDetails: function () {
                if (uof.ui.SupervisorUOFNarrative.detail.validateNarrativeDetails()) {
                    $.when(showConfirmationWindow('Do you want to submit the for the review ? ')).then(function (confirmed) {
                        if (confirmed)
                            uof.ui.SupervisorUOFNarrative.detail.saveNarrativeInfo(false);
                    });

                }
            },

            validateNarrativeDetails: function () {
                if (!uof.ui.SupervisorUOFNarrative.detail.validateIncidentInformation()) {
                    uof.ui.SupervisorUOFNarrative.detail.redirecttoValidationScreen("anchorIncidentInfo");
                    return false;
                }
                if (!uof.ui.SupervisorUOFNarrative.detail.validateForce()) {
                    uof.ui.SupervisorUOFNarrative.detail.redirecttoValidationScreen("anchorForceInfo");
                    return false;
                }
                if (!uof.ui.SupervisorUOFNarrative.detail.validateNarrativeReport()) {
                    uof.ui.SupervisorUOFNarrative.detail.redirecttoValidationScreen("anchorReportInfo");
                    return false;
                }
                if (!uof.ui.SupervisorUOFNarrative.detail.validateNotification()) {
                    uof.ui.SupervisorUOFNarrative.detail.redirecttoValidationScreen("anchorNotificationInfo");
                    return false;
                }
                if (!uof.ui.SupervisorUOFNarrative.detail.validateWitness()) {
                    uof.ui.SupervisorUOFNarrative.detail.redirecttoValidationScreen("anchorWitnessInfo");
                    return false;
                }
                if (!uof.ui.SupervisorUOFNarrative.detail.validateWC()) {
                    uof.ui.SupervisorUOFNarrative.detail.redirecttoValidationScreen("anchorWCInfo");
                    return false;
                }
                if (!uof.ui.SupervisorUOFNarrative.detail.validateMedical()) {
                    uof.ui.SupervisorUOFNarrative.detail.redirecttoValidationScreen("anchorMedicalInfo");
                    return false;
                }
                if (!uof.ui.SupervisorUOFNarrative.detail.validateTraining()) {
                    uof.ui.SupervisorUOFNarrative.detail.redirecttoValidationScreen("anchorTrainingInfo");
                    return false;
                }
                if (!uof.ui.SupervisorUOFNarrative.detail.validateCaseSatus()) {
                    return false;
                }
                uof.ui.SupervisorUOFNarrative.detail.removeActiveONSuccessValidation();
                return true;
            },
            removeActiveONSuccessValidation: function () {
                $("#liIncidentInfo").removeClass("active");
                $("#liForcemitigation").removeClass("active");
                $("#liReported").removeClass("active");
                $("#liNotification").removeClass("active");
                $("#liWitness").removeClass("active");
                $("#liWC").removeClass("active");
                $("#liMedical").removeClass("active");
                $("#liTraining").removeClass("active");
            },
            redirecttoValidationScreen: function (anchorInfo) {
                $("#" + anchorInfo).trigger("click");
            },

            validateIncidentInformation: function (obj) {
                result = ko.validation.group(uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation, { deep: true });
                if (result().length > 0) {
                    uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.SceneDescription.valueHasMutated();
                    uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.DescribeType.valueHasMutated();
                    uof.ui.SupervisorUOFNarrative.detail.viewModel.IncidentInformation.ThreatDescription.valueHasMutated();
                    return false;
                }
                if (obj != undefined)
                    uof.ui.SupervisorUOFNarrative.detail.redirecttoValidationScreen(obj);
                else
                    return true;
            },
            validateForce: function (obj) {
                result = ko.validation.group(uof.ui.SupervisorUOFNarrative.detail.viewModel.Forcemitigation, { deep: true });
                if (result().length > 0) {
                    return false;
                }
                if (obj != undefined)
                    uof.ui.SupervisorUOFNarrative.detail.redirecttoValidationScreen(obj);
                else
                    return true;
            },
            validateNarrativeReport: function (obj) {
                result = ko.validation.group(uof.ui.SupervisorUOFNarrative.detail.viewModel.Reported, { deep: true });
                if (result().length > 0) {
                    return false;
                }
                if (obj != undefined)
                    uof.ui.SupervisorUOFNarrative.detail.redirecttoValidationScreen(obj);
                else
                    return true;
            },
            validateNotification: function (obj) {
                result = ko.validation.group(uof.ui.SupervisorUOFNarrative.detail.viewModel.Notification, { deep: true });
                if (result().length > 0) {
                    return false;
                }
                if (obj != undefined)
                    uof.ui.SupervisorUOFNarrative.detail.redirecttoValidationScreen(obj);
                else
                    return true;
            },
            validateWitness: function (obj) {
                result = ko.validation.group(uof.ui.SupervisorUOFNarrative.detail.viewModel.Witness, { deep: true });
                if (result().length > 0) {
                    uof.ui.SupervisorUOFNarrative.detail.viewModel.Witness.WitnessInterview.valueHasMutated();
                    return false;
                }
                if (obj != undefined)
                    uof.ui.SupervisorUOFNarrative.detail.redirecttoValidationScreen(obj);
                else
                    return true;
            },
            validateWC: function (obj) {
                result = ko.validation.group(uof.ui.SupervisorUOFNarrative.detail.viewModel.WC, { deep: true });
                if (result().length > 0) {
                    uof.ui.SupervisorUOFNarrative.detail.viewModel.WC.SuspectStatement.valueHasMutated();
                    return false;
                }
                if (obj != undefined)
                    uof.ui.SupervisorUOFNarrative.detail.redirecttoValidationScreen(obj);
                else
                    return true;
            },
            validateMedical: function (obj) {
                result = ko.validation.group(uof.ui.SupervisorUOFNarrative.detail.viewModel.Medical, { deep: true });
                if (result().length > 0) {
                    return false;
                }
                if (obj != undefined)
                    uof.ui.SupervisorUOFNarrative.detail.redirecttoValidationScreen(obj);
                else
                    return true;
            },
            validateTraining: function (obj) {
                result = ko.validation.group(uof.ui.SupervisorUOFNarrative.detail.viewModel.Training, { deep: true });
                if (result().length > 0) {
                    uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.OtherForceOptions.valueHasMutated();
                    uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.Reassessment.valueHasMutated();
                    uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.TrainingRecommendations.valueHasMutated();
                    uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.ListAnyEquipment.valueHasMutated();
                    uof.ui.SupervisorUOFNarrative.detail.viewModel.Training.OtherTopics.valueHasMutated();
                    return false;
                }
                if (obj != undefined)
                    uof.ui.SupervisorUOFNarrative.detail.redirecttoValidationScreen(obj);
                else
                    return true;
            },
            validateCaseSatus: function () {
                result = ko.validation.group(uof.ui.SupervisorUOFNarrative.detail.viewModel.CaseStatus, { deep: true });
                if (result().length > 0) {
                    uof.ui.SupervisorUOFNarrative.detail.viewModel.CaseStatus.CaseDisposition.valueHasMutated();
                    return false;
                }
                else
                    return true;
            },
        }

    }();
}