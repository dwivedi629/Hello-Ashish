﻿var uof = uof || {};
uof.ui = uof.ui || {};
uof.ui.ForceReview = uof.ui.ForceReview || {};
if (uof.ui.ForceReview) {
    uof.ui.ForceReview.ForceReviewChecklist = function () {
        return {
            parameters: null,
            isChanged: false,
            init: function (args) {
                this.parameters = args;
            },
            ForceReviewDBSource: null,
            ParameterCriteria: {
                IncidentReviewId: 0,
                employeeId: '',
                incidentId: 0,
                formId: 0,
                formDataId: 0
            },
            viewModel: {
                
                IsFormOwner: ko.observable(false),
                IsIncidentOwner: ko.observable(false),
                IsLock: ko.observable(false),
                IsSupervisorStatus: ko.observable(false),
                IsSupervisorOrApprover: ko.observable(false),
                SubmitedId: ko.observable(),
                ForceReview: {
                    IncidentReviewId: ko.observable(0),
                    FormDataId: ko.observable(0),
                    IsOnlySave: ko.observable(true),
                    IncidentID: ko.observable(),
                    FormID: ko.observable(),
                    EmpId: ko.observable(),
                    UserRole: ko.observable(),
                    Time: ko.observable(),
                    URN: ko.observable(),
                    Facility: ko.observable(),
                    Reference: ko.observable(),
                    Location: ko.observable(),
                    eLots: ko.observable(),

                    ForceNotification: ko.observable(false),
                    SupervisorReport: ko.observable(false),
                    ForceMemo: ko.observable(false),
                    MedicalReport: ko.observable(false),
                    InService: ko.observable(false),
                    AudioVideoOfInterviews: ko.observable(false),
                    AudioVideoOfincidentScene: ko.observable(false),


                    IABNotification: ko.observable(false),
                    IncidentReport: ko.observable(false),
                    InmateAssaultSheet: ko.observable(false),
                    MentalHealth: ko.observable(false),
                    SafetyChair: ko.observable(false),
                    TaserDownload: ko.observable(false),
                    InmateExtraction: ko.observable(false),
                    DormPurge: ko.observable(false),
                    OtherRelevantDocuments: ko.observable(false),
                    Other: ko.observable(),
                    RejectComments: ko.observable(),
                },
            },
            load: function () {
                ko.validation.init({ insertMessages: true });
                uof.ui.ForceReview.ForceReviewChecklist.initiateBindings();
                uof.ui.ForceReview.ForceReviewChecklist.validateControls();
                uof.ui.ForceReview.ForceReviewChecklist.subscribeMethod();
                //binding ForceReview ForceReviewChecklist page
                ko.cleanNode($("#FReview").get(0));
                ko.applyBindings(uof.ui.ForceReview.ForceReviewChecklist.viewModel, $("#FReview").get(0));
                
                uof.ui.ForceReview.ForceReviewChecklist.initiatePickers();

                if (UoFParams.IncidentId > 0) {
                    uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.FormID($.UoFformId);
                    uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.EmpId($.SubmitedId);
                    uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.IncidentID(UoFParams.IncidentId);
                    uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.UserRole(UoFParams.userRole);
                    //if (localStorage.getItem('formMode') == "View") {
                    //    $("#btnReset").addClass('hide');
                    //    $("#btnSave").addClass('hide');
                    //    $("#btnApprove").addClass('hide');
                    //    $("#btnReject").addClass('hide')
                    //    $("#vertical-tabs").find('input, select, textarea').each(function () {
                    //        $(this).attr('disabled', true);
                    //    });
                    //    $(".fakeclass").removeClass('hide');
                    //    $("#txtReject").attr('disabled', false);

                    //    $("#btnApprove").prop('disabled', false);
                    //    $("#btnReject").prop('disabled', true);
                    //    $("#anchorIncidentInfo").prop('disabled', false);
                    //    $("#btnApprove").removeClass('hide');
                    //    $("#btnReject").removeClass('hide');
                    //}
                    //uof.ui.ForceReview.ForceReviewChecklist.bindReviewCheckListDetails();
                    //if (uof.ui.CommonUILogic.detail.isFormStatusCompleted($.UoFformId, UoFParams.IncidentId)) {
                    //    $("#btnReset").addClass('hide');
                    //    $("#btnSave").addClass('hide');
                    //    $("#btnApprove").addClass('hide');
                    //    $("#btnReject").addClass('hide');
                    //}
                }
                uof.ui.ForceReview.ForceReviewChecklist.bindApproveorEdit();
                if (UoFParams.IncidentURN != "") {
                    uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.URN(UoFParams.IncidentURN);
                    uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.Time(moment(UoFParams.IncidentDate).format("MM/DD/YYYY HH:mm"));
                    uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.Reference(UoFParams.ReferenceNo);
                    uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.Location(UoFParams.IncidentLocation);
                    uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.eLots(UoFParams.eLot);
                    
                    //var facility = UoFParams.IncidentFacility;
                    //if (UoFParams.IncidentStation != "") {
                    //    if (facility != "")
                    //        facility = facility + "-" + UoFParams.IncidentStation
                    //    else
                    //        facility = UoFParams.IncidentStation
                    //}
                    //if (UoFParams.IncidentBureau != "") {
                    //    if (facility != "")
                    //        facility = facility + "-" + UoFParams.IncidentBureau
                    //    else
                    //        facility = UoFParams.IncidentBureau
                    //}
                    uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.Facility(UoFParams.IncidentStation);
                }
                $(document).on('keyup', "#txtReject", function (e) {
                    var Commtstring = $.trim($("#txtReject").val());
                    if (Commtstring.length > 0) {
                        $("#btnReject").prop('disabled', false);
                        $("#btnApprove").prop('disabled', true);
                    }
                    else {
                        $("#btnReject").prop('disabled', true);
                        $("#btnApprove").prop('disabled', false);
                    }
                });
            },
            bindApproveorEdit: function () {
                if (localStorage.getItem('formMode') == "View" || localStorage.getItem('formMode') == "Approve") {
                    if ($.IncidentId.length > 0 && $.UoFformId.length > 0 && $.SubmitedId.length > 0) {
                        uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.IncidentID($.IncidentId);
                        uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.FormID($.UoFformId);
                        uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.EmpId($.SubmitedId);
                        uof.ui.ForceReview.ForceReviewChecklist.viewModel.SubmitedId($.SubmitedId);
                        uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.UserRole(UoFParams.userRole);
                        uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.IncidentReviewId(localStorage.getItem('IncidentReviewId') == null ? 0 : localStorage.getItem('IncidentReviewId'));
                        uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.FormDataId(localStorage.getItem('FormDataId') == null ? 0: localStorage.getItem('FormDataId'));
                    }
                    //$("#btnReset").addClass('hide');
                    //$("#btnSave").addClass('hide');
                    //$("#btnApprove").addClass('hide');
                    //$("#btnReject").addClass('hide')
                    //$("#vertical-tabs").find('input, select, textarea').each(function () {
                    //    $(this).attr('disabled', true);
                    //});
                    //$(".fakeclass").removeClass('hide');
                    //$("#txtReject").attr('disabled', false);

                    //$("#btnSave").addClass('hide')
                    //$("#btnApprove").prop('disabled', false);
                    //$("#btnReject").prop('disabled', true);
                    //$("#anchorIncidentInfo").prop('disabled', false);
                    //$("#btnApprove").removeClass('hide');
                    //$("#btnReject").removeClass('hide');
                }
                else {
                    uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.IncidentID(UoFParams.IncidentId);
                    uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.FormID($.UoFformId);
                    uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.EmpId(UoFParams.userId);
                    uof.ui.ForceReview.ForceReviewChecklist.viewModel.SubmitedId(localStorage.getItem('SubmittedId') == null ? UoFParams.userId : localStorage.getItem('SubmittedId'));
                    uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.IncidentReviewId(localStorage.getItem('IncidentReviewId') == null ? 0 : localStorage.getItem('IncidentReviewId'));
                    uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.FormDataId(localStorage.getItem('FormDataId') == null ? 0 : localStorage.getItem('FormDataId'));
                }

                //if (uof.ui.CommonUILogic.detail.isFormStatusCompleted($.UoFformId, UoFParams.IncidentId)) {
                //    $("#btnReset").addClass('hide');
                //    $("#btnSave").addClass('hide');
                //    $("#btnApprove").addClass('hide');
                //    $("#btnReject").addClass('hide');
                //}

                uof.ui.ForceReview.ForceReviewChecklist.bindReviewCheckListDetails();
            },
            buildCOObject: function (isApprove) {
                var oCOData = new Object();
                oCOData.IncidentId = $.IncidentId;
                oCOData.FormId = $.UoFformId;
                oCOData.DeputyEmpId = $.SubmitedId;
                oCOData.isApprove = isApprove;
                oCOData.ReviewerReviewId = UoFParams.userId;
                oCOData.ReviewerRole = UoFParams.userRole;
                oCOData.Comment = uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.RejectComments();
                oCOData.IncidentReviewId = uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.IncidentReviewId();
                return oCOData;
            },
            approveCODetails: function (isApprove) {
                var oCOData = uof.ui.ForceReview.ForceReviewChecklist.buildCOObject(isApprove);
                var mappedData = ko.mapping.toJS(oCOData);
                $.ajax(
                      {
                          url: window.location.uofAPIOrigin() + '/api/UOFForm/ApproveorReject',
                          cache: false,
                          type: "POST",
                          dataType: 'json',
                          data: JSON.stringify(mappedData),
                          contentType: "application/json;charset=utf-8",
                          beforeSend: function myfunction() {

                          },
                          success: function (data) {
                              $.prototype.hideUofOverlay();
                              showAlert(data);
                              uof.ui.ForceReview.ForceReviewChecklist.setApprovedIncidentinSession(oCOData.IncidentId);
                             // window.location.href = window.location.uofUIOrigin() + '/Incident/Incident' + '?IncidentId=' + oCOData.IncidentId;
                          },
                          error: function (e) {
                              $.prototype.hideUofOverlay();
                              showAlert(e.responseText);
                          },
                      });
            },
            setApprovedIncidentinSession: function (incidentId) {
                $.ajax(
                     {
                         url: window.location.uofUIOrigin() + '/Incident/setApprovedIncident',
                         type: "POST",
                         data: { incidentID: incidentId },
                         success: function (data) {
                             if (data == "true")
                                 window.location.href = window.location.uofUIOrigin() + '/Incident/Incident';
                         },
                         error: function (e) {
                             showAlert(e.responseText);
                         },
                     });
            },
            initiateBindings: function () {
                if (UoFParams.IncidentURN != "") {
                    uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.URN(UoFParams.IncidentURN);
                }
                ko.validation.insertValidationMessage = function (element) {
                    var br = document.createElement("br");
                    element.appendChild(br);
                    var span = document.createElement('SPAN');
                    span.className = "warning-msg";
                    var inputGroups = $(element).closest(".date"); //This is for getting Date Fields
                    if (inputGroups.length > 0) {
                        // We're in an input-group so we place the message after
                        // the group rather than inside it in order to not break the design
                        $(span).insertAfter(inputGroups);
                    }
                    else {
                        // The default in knockout-validation
                        element.parentNode.insertBefore(span, element.nextSibling);
                    }
                    return span;
                };

            },
            initiatePickers: function () {
                $('#FRDT').datetimepicker().on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY HH:mm:ss");
                    uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.Time(newDate);
                });
            },
            bindReviewCheckListDetails: function () {
                $.prototype.showUofOverlay();
                uof.ui.ForceReview.ForceReviewChecklist.ParameterCriteria.IncidentReviewId = uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.IncidentReviewId();
                uof.ui.ForceReview.ForceReviewChecklist.ParameterCriteria.formDataId = uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.FormDataId();
                uof.ui.ForceReview.ForceReviewChecklist.ParameterCriteria.employeeId = uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.EmpId();
                uof.ui.ForceReview.ForceReviewChecklist.ParameterCriteria.incidentId = uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.IncidentID();
                uof.ui.ForceReview.ForceReviewChecklist.ParameterCriteria.formId = uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.FormID();//e.data.FormId;
                var model = ko.mapping.toJS(uof.ui.ForceReview.ForceReviewChecklist.ParameterCriteria);
                $.ajax(
                       {
                           url: window.location.uofAPIOrigin() + '/api/UOFForm/GetForceReview',
                           cache: false,
                           //data: { FormId: uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.FormID(), IncidentId: uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.IncidentID(), empId: uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.EmpId() },
                           data: JSON.stringify(model),
                           type: "POST",
                           dataType: 'json',
                           contentType: "application/json;charset=utf-8",
                           beforeSend: function myfunction() {

                           },
                           success: function (data) {
                               uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.URN = ko.observable(UoFParams.IncidentURN);
                               if (data != null) {
                                   ko.validation.init({ insertMessages: true });
                                   uof.ui.ForceReview.ForceReviewChecklist.initiateBindings();
                                   uof.ui.ForceReview.ForceReviewChecklist.validateControls();
                                   uof.ui.ForceReview.ForceReviewChecklist.subscribeMethod();
                                   uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview = ko.mapping.fromJS(data, ko.mapping.toJS(uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview));
                                   //binding ForceReview ForceReviewChecklist page
                                   uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.URN = ko.observable(UoFParams.IncidentURN);
                                   ko.cleanNode($("#FReview").get(0));
                                   ko.applyBindings(uof.ui.ForceReview.ForceReviewChecklist.viewModel, $("#FReview").get(0));
                                   uof.ui.ForceReview.ForceReviewChecklist.initiatePickers();
                                   if (uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.RejectComments() != "") {
                                       $(".fakeclass").removeClass('hide');
                                       $("#txtReject").attr('disabled', false);
                                   }
                                   if (UoFParams.IncidentURN != "") {
                                       uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.URN(UoFParams.IncidentURN);
                                       uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.Time(moment(UoFParams.IncidentDate).format("MM/DD/YYYY HH:mm"));
                                       uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.Reference(UoFParams.ReferenceNo);
                                       uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.Location(UoFParams.IncidentLocation);
                                       uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.eLots(UoFParams.eLot);
                                       //var facility = UoFParams.IncidentFacility;
                                       //if (UoFParams.IncidentStation != "") {
                                       //    if (facility != "")
                                       //        facility = facility + "-" + UoFParams.IncidentStation
                                       //    else
                                       //        facility = UoFParams.IncidentStation
                                       //}
                                       //if (UoFParams.IncidentBureau != "") {
                                       //    if (facility != "")
                                       //        facility = facility + "-" + UoFParams.IncidentBureau
                                       //    else
                                       //        facility = UoFParams.IncidentBureau
                                       //}
                                       uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.Facility(UoFParams.IncidentStation);
                                   }
                               }
                               uof.ui.ForceReview.ForceReviewChecklist.toggleControls();
                               $.prototype.hideUofOverlay();
                           },
                           error: function (e) {
                               $.prototype.hideUofOverlay();
                               showAlert(e.responseText);

                           },
                       });

            },
            toggleControls: function () {
                uof.ui.ForceReview.ForceReviewChecklist.viewModel.SubmitedId(localStorage.getItem('SubmittedId') == null ? UoFParams.userId : localStorage.getItem('SubmittedId'));
                uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.IncidentReviewId(localStorage.getItem('IncidentReviewId') == null ? 0 : localStorage.getItem('IncidentReviewId'))
                var formData = uof.ui.CommonUILogic.detail.isFormStatusCompleted($.UoFformId, UoFParams.IncidentId, uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.IncidentReviewId());
                if (formData != "") {
                    var formStatus = formData.split('\r\n');
                    uof.ui.ForceReview.ForceReviewChecklist.viewModel.IsFormOwner(formStatus[0].split(':')[1].toLowerCase() == "true" ? true : false);
                    uof.ui.ForceReview.ForceReviewChecklist.viewModel.IsIncidentOwner(formStatus[1].split(':')[1].toLowerCase() == "true" ? true : false);
                    if (formStatus.length > 2) {
                        uof.ui.ForceReview.ForceReviewChecklist.viewModel.IsLock(formStatus[2].split(':')[1].toLowerCase() == "true" ? true : false);
                        uof.ui.ForceReview.ForceReviewChecklist.viewModel.IsSupervisorStatus(formStatus[3].split(':')[1].toLowerCase());
                    }
                    if (uof.ui.ForceReview.ForceReviewChecklist.viewModel.IsLock()) {
                        $("#vertical-tabs *").find('input, select, textarea').each(function () {
                            $(this).attr('disabled', true);
                        });
                        $('.fakeSave').addClass('hide');
                        $("#btnReset").addClass('hide'); $("#btnSave").addClass('hide');
                        $("#btnApprove").addClass('hide'); $("#btnReject").addClass('hide');
                        if (localStorage.getItem('formMode') == "Approve") {
                            $("#btnApprove").prop('disabled', false); $("#btnApprove").removeClass('hide');
                            $("#btnReject").prop('disabled', true); $("#btnReject").removeClass('hide');
                            uof.ui.ForceReview.ForceReviewChecklist.viewModel.IsSupervisorOrApprover(true);
                            $(".fakeclass").removeClass('hide');
                            $("#txtReject").attr('disabled', false);
                            //$('#divApproval:first > *').find('input').each(function () {
                            //    $(this).attr('disabled', false);
                            //});
                            //uof.ui.inmate.detail.validateControls();
                        }
                    }
                    else {
                        $("#btnApprove").addClass('hide'); $("#btnReject").addClass('hide');
                        if (!uof.ui.ForceReview.ForceReviewChecklist.viewModel.IsFormOwner() && uof.ui.ForceReview.ForceReviewChecklist.viewModel.IsSupervisorStatus() == "pending") {
                            $("#vertical-tabs *").find('input, select, textarea').each(function () {
                                $(this).attr('disabled', true);
                            });
                            $('.fakeSave').addClass('hide');
                            $("#btnReset").addClass('hide'); $("#btnSave").addClass('hide');
                            $("#btnApprove").addClass('hide'); $("#btnReject").addClass('hide');
                            if (localStorage.getItem('formMode') == "Approve") {
                                $("#btnApprove").prop('disabled', false); $("#btnApprove").removeClass('hide');
                                $("#btnReject").prop('disabled', true); $("#btnReject").removeClass('hide');
                                uof.ui.ForceReview.ForceReviewChecklist.viewModel.IsSupervisorOrApprover(true);
                                $(".fakeclass").removeClass('hide');
                                $("#txtReject").attr('disabled', false);
                                //$("#divApproval").css({ style: "display:block" });
                                //$('#divApproval:first > *').find('input').each(function () {
                                //    $(this).attr('disabled', false);
                                //});
                            }
                        }
                    }
                }
            },
            saveForceReviewInfo: function (IsOnlySave) {
                uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.IsOnlySave(IsOnlySave);
                uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.FormID($.UoFformId);
                uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.EmpId(UoFParams.userId);
                uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.IncidentID(UoFParams.IncidentId);
                uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.UserRole(UoFParams.userRole);
                var jsonDate = ko.mapping.toJS(uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview);
                $.prototype.showUofOverlay();
                $.ajax(
                  {
                      url: window.location.uofAPIOrigin() + '/api/UOFForm/SaveOperationForceReview',
                      cache: false,
                      type: "POST",
                      dataType: 'json',
                      data: JSON.stringify(jsonDate),
                      contentType: "application/json;charset=utf-8",
                      beforeSend: function myfunction() {

                      },
                      success: function (data) {
                          $.prototype.hideUofOverlay();
                          uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.FormDataId(data);
                          showAlert(IsOnlySave ? "Data saved successfully" : "submited successfully");
                      },
                      error: function (e) {
                          $.prototype.hideUofOverlay();
                          showAlert(e.responseText);
                      },
                  });
            },
            saveForceReviewDetails: function () {
                if (uof.ui.ForceReview.ForceReviewChecklist.validateForceReviewFields()) {
                    $.when(showConfirmationWindow('Do you want to submit the for the review ? ')).then(function (confirmed) {
                        if (confirmed)
                            uof.ui.ForceReview.ForceReviewChecklist.saveForceReviewInfo(false);
                    });
                    
                }
            },
            subscribeMethod: function () {
                uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.OtherRelevantDocuments.subscribe(function (newValue) {
                    if (newValue) {
                        uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.Other.valueHasMutated();
                        return false;
                    }
                    else if (!newValue)
                        uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.Other(null);
                });
            },
            validateControls: function () {
            
                //uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.Time.extend({
                //    required: {
                //        params: true,
                //        message: ForceReviewConstants.Required
                //        //message:"Required"
                //    }
                //});

                //uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.URN.extend({
                //    required: {
                //        params: true,
                //        message: ForceReviewConstants.Required
                //        //message:"Required"
                //    },
                //    pattern: {
                //        params: "^[a-zA-Z0-9 _@#-.~!$%&()={}^]+$",
                //        message: ForceReviewConstants.URN + ' \\ / : * ? ` ; " < > | [ ]'
                //        //message: "Required " + ' \\ / : * ? ` ; " < > | [ ]'
                //    },
                //    maxLength: {
                //        params: 400,
                //        message: 'URN  maximum character should be 400 only.'
                //    },
                //});
                //uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.Facility.extend({
                //    required: {
                //        params: true,
                //        message: ForceReviewConstants.Required
                //        //message:"Required"
                //    },
                //    pattern: {
                //        params: "^[a-zA-Z0-9 _@#-.~!$%&()={}^]+$",
                //        message: ForceReviewConstants.Facility + ' \\ / : * ? ` ; " < > | [ ]'
                //        //message: "Required " + ' \\ / : * ? ` ; " < > | [ ]'
                //    },
                //    maxLength: {
                //        params: 400,
                //        message: 'Facility maximum character should be 100 only.'
                //    },
                //});
                //uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.Reference.extend({
                //    required: {
                //        params: true,
                //        message: ForceReviewConstants.Required
                //        //message:"Required"
                //    },
                //    pattern: {
                //        params: "^[a-zA-Z0-9 _@#-.~!$%&()={}^]+$",
                //        message: ForceReviewConstants.Reference + ' \\ / : * ? ` ; " < > | [ ]'
                //        //message: "Required " + ' \\ / : * ? ` ; " < > | [ ]'
                //    },
                //    maxLength: {
                //        params: 100,
                //        message: 'Reference   maximum character should be 100 only.'
                //    },
                //});
                //uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.Location.extend({
                //    required: {
                //        params: true,
                //        message: ForceReviewConstants.Required
                //        //message:"Required"
                //    },
                //    maxLength: {
                //        params: 400,
                //        message: 'Location maximum character should be 400 only.'
                //    },
                //});
                //uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.eLots.extend({
                //    required: {
                //        params: true,
                //        message: ForceReviewConstants.Required
                //        //message:"Required"
                //    },
                //    pattern: {
                //        params: "^[a-zA-Z0-9 _@#-.~!$%&()={}^]+$",
                //        message: ForceReviewConstants.eLots + ' \\ / : * ? ` ; " < > | [ ]'
                //        //message: "Required " + ' \\ / : * ? ` ; " < > | [ ]'
                //    },
                //    maxLength: {
                //        params: 400,
                //        message: 'eLots maximum character should be 100 only.'
                //    },
                //});
                uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.Other.extend({
                    required: {
                        params: true,
                        message: ForceReviewConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.OtherRelevantDocuments() === true);
                        }
                        
                    }
                });
                
                
                   },
            validateForceReviewFields: function () {
                result = ko.validation.group(uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview, { deep: true });
                if (result().length > 0) {
                                        
                    uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.Time.valueHasMutated();
                    uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.URN.valueHasMutated();
                    uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.Facility.valueHasMutated();
                    uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.Reference.valueHasMutated();
                    uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.Location.valueHasMutated();
                    uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.eLots.valueHasMutated();
                    uof.ui.ForceReview.ForceReviewChecklist.viewModel.ForceReview.Other.valueHasMutated();

                    return false;
                }
                return true;
            },        
        }
    }();
}