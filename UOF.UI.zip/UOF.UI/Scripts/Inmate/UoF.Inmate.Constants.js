﻿var InmateConstants = {
    Required:'Required',
    URN: 'URN is required',
    ReferenceNumber: 'Reference Number is required',
    BookingNumber: 'Booking Number is required',
    EmployeeName: 'Name is required',
    Race: 'Race is required',
    Sex: 'Sex is required',
    DateOfBirth: 'Date of Birth is required',
    HousingFacility: 'Housing Facility is required',
    Barrack: 'Barrack/Module/DORM is required',
    Cell: 'Cell/Bunk is required',
}