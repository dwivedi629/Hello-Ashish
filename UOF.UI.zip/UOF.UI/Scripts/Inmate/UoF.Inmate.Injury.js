﻿var uof = uof || {};
uof.ui = uof.ui || {};
uof.ui.inmate = uof.ui.inmate || {};

if (uof.ui.inmate) {
    uof.ui.inmate.detail = function () {

        return {
            parameters: null,
            isChanged: false,
            isChecked: false,
            init: function (args) {
                this.parameters = args;
            },
            inmateDBSource: null,
            ParameterCriteria: {
                IncidentReviewId: 0,
                employeeId: '',
                incidentId: 0,
                formId: 0,
                formDataId: 0
            },
            viewModel: {
                IncidentReviewId: ko.observable(0),
                FormDataId: ko.observable(0),
                IsFormOwner: ko.observable(false),
                IsIncidentOwner: ko.observable(false),
                IsLock: ko.observable(false),
                IsOnlyApproval: ko.observable(true),
                isMedical: ko.observable(false),
                IsOnlySave: ko.observable(true),
                IsSupervisorStatus: ko.observable(),
                IsSupervisorOrApprover: ko.observable(false),
                SubmitedId: ko.observable(),
                IncidentID: ko.observable(),
                FormID: ko.observable(),
                UserRole: ko.observable(),
                EmpID: ko.observable(),
                ActionType: ko.observable("E"),
                Sex: ko.observable([]),
                Race: ko.observable([]),



                validationEnabled: ko.observable(true),
                getEmployeeDetails: function () { uof.ui.inmate.detail.getEmployeeDetails(); },
                getSuspectDetails: function (bookingId, optionCriteria) {
                    if (bookingId != undefined)
                        uof.ui.inmate.detail.getSuspectDetails(bookingId, optionCriteria);
                },
                inmateInformation: {

                    //Inmate Information Starts
                    PersonNotified: ko.observable(),
                    URN: ko.observable(),
                    ReferenceNumber: ko.observable(),
                    BookingNumber: ko.observable(),
                    EmployeeName: ko.observable(''),
                    // Race: ko.observable(''),
                    // Sex: ko.observable(''),
                    Race: ko.observableArray(),
                    Sex: ko.observable(),
                    DateOfBirth: ko.observable(),
                    HousingFacility: ko.observable(''),
                    Barrack: ko.observable(''),
                    Cell: ko.observable(''),
                    TypeOfHousing: ko.observable(),
                    Segregation: ko.observable(),
                    chkGeneralPopulation: ko.observable(false),
                    chkMentalHealthHousing: ko.observable(false),
                    chkMedicalHousing: ko.observable(false),
                    chkDiscipline: ko.observable(false),
                    chkSegregation: ko.observable(false),
                },
                incidentInformation:
                   {

                       // incedent Info
                       //--------------------------
                       IncidentLocation: ko.observable(),
                       TypeOfLocation: ko.observable(),
                       IncidentDate: ko.observable(),
                       IncidentTime: ko.observable(),
                       SickOrIllY: ko.observable(false),
                       SickOrIllN: ko.observable(false),
                       InjuredY: ko.observable(false),
                       InjuredN: ko.observable(false),
                       // Removed Controls : ForeOrAllegationY ForeOrAllegationN finaldiagnosisby DiagnosisDateTime PersonContacted FinalDiagnosis 
                       ForeOrAllegationY: ko.observable(),
                       // ForeOrAllegationN: ko.observable(),
                       // FinalDiagnosisBy: ko.observable(),
                       // FinalDiagnosisDateTime: ko.observable(),
                       //  PersonContacted: ko.observable(''),
                       // FinalDiagnosis: ko.observable(''),
                       Accident: ko.observable(),
                       furtherInvestigation: ko.observable(false),
                       InvestigationURN: ko.observable(),
                       Alone: ko.observable(),
                       Segregated: ko.observable(),
                       WithOthers: ko.observable(),
                       wasEscorted: ko.observable(),
                       EscortedToClinic: ko.observable(),
                       EscortedToAt: ko.observable(),
                       wasTransported: ko.observable(false),
                       TransportedToClinic: ko.observable(),
                       TransportedToAt: ko.observable(),
                       wasEscortedBy: ko.observable(false),
                       EscortedByClinic: ko.observable(),
                       EscortedBy: ko.observable(),
                       EscortedByAt: ko.observable(),
                       SeenByClinic: ko.observable(),
                       //   AdmittedToEmerRoom: ko.observable(),
                       SeenByAt: ko.observable(),
                       //  SeenByAtHours: ko.observable(),
                       InmateTreatedBy: ko.observable(false),
                       EscortingPersonnelEID: ko.observable(),
                       EscortingPersonnelName: ko.observable(),
                       EscortedByClinic: ko.observable(),
                       DeputyEscortingtoHospitalDate: ko.observable(),
                       DoctorTreatedDate: ko.observable(),
                       DoctorTreatedTime: ko.observable(),
                       chkReturnedtoFacility: ko.observable(false),
                       chkAdmittedtoHospital: ko.observable(false),
                       chkOther: ko.observable(false),
                       OtherInmateDisposition: ko.observable(),
                       InmateDispoDate: ko.observable(),
                       InmateDispoTime: ko.observable(),

                       //...............................
                       //New controls added below:
                       //..............................
                       //EscortingPersonnelEID
                       //EscortingPersonnelName
                       //EscortedByClinic-------------FacilityClinic
                       //DeputyEscortingtoHospitalDate
                       //DoctorTreatedDate
                       //DoctorTreatedTime

                       //	chkReturnedtoFacility
                       //chkAdmittedtoHospital
                       //chkOther
                       //OtherInmateDisposition
                       //DoctorTreatedDate	
                       //DoctorTreatedTime------------------SeenByAtHours

                   },

                incidentNarrative:
                    {
                        //Incident Narrative
                        IncidentNarrative_EmployeeNumber: ko.observable(),
                        IncidentNarrative_NameOfSergeant: ko.observable(),
                        IncidentNarrative_Date: ko.observable(),
                        IncidentNarrative: ko.observable(),
                        SubmittedBy_EmployeeNumber: ko.observable(),
                        SubmittedBy_NameOfSergeant: ko.observable(''),
                        SubmittedBy_Date: ko.observable(''),
                        ApprovedBy_EmployeeNumber: ko.observable(''),
                        ApprovedBy_NameOfSergeant: ko.observable(),
                        ApprovedBy_Date: ko.observable(),

                        chkInmateInterviewed: ko.observable(),
                        chkNoAllegationForce: ko.observable(),
                        SergeantNotesNarrative: ko.observable(),
                        //                        IncidentNarrative	Narrative
                        //.......................................
                        //New Controls	

                        //incidentNarrative.chkInmateInterviewed
                        //incidentNarrative.chkNoAllegationForce
                        //incidentNarrative.SergeantNotesNarrative
                        //.......................................

                    },
                MSIL:
                    {
                        //MSIL
                        TreatedBy: ko.observable(),
                        EmployeeNumber: ko.observable(),
                        DateTreated: ko.observable(),
                        TimeTreated: ko.observable(),
                        MSIncidentNarrative: ko.observable(),
                        Injury: ko.observable(false),
                        Illness: ko.observable(false),
                        ConsistentYes: ko.observable(false),
                        ConsistentNo: ko.observable(false),
                        FollowupYes: ko.observable(false),
                        FollowupNo: ko.observable(false),
                        RC: ko.observable(false),
                        Ambulance: ko.observable(false),
                        Paramedics: ko.observable(false),

                        //                        MSIL Medical Statement(LASD MEDICAL PERSONNEL ONLY) 


                        //				Removed Controls:MSIL.ConsistentYes MSIL.ConsistentNo 

                        //...............................................
                    },
                MSH:
                    {
                        //MSH
                        applicable: ko.observable(false),
                        MSHTreatedBy: ko.observable(),
                        MSHEmployeeNumber: ko.observable(),
                        MSHTimeTreated: ko.observable(),
                        MSHDateTreated: ko.observable(""),
                        MSSickOrIllY: ko.observable(false),
                        MSSickOrIllN: ko.observable(false),
                        MSchkDiagonsisY: ko.observable(false),
                        MSchkDiagonsisN: ko.observable(false),
                        MSinjuredY: ko.observable(false),
                        MSinjuredN: ko.observable(false),
                        MSdescriptionY: ko.observable(false),
                        MSdescriptionN: ko.observable(false),
                        MSfinalDiagnosticY: ko.observable(false),
                        MSfinalDiagnosticN: ko.observable(false),
                        MSAdmittedY: ko.observable(false),
                        MSAdmittedN: ko.observable(false),
                        MSradioCare: ko.observable(false),
                        MSambulance: ko.observable(false),
                        MSsafetyCell: ko.observable(false),
                        MSlowBunk: ko.observable(false),
                        // MSobservationY: ko.observable(false),
                        // MSobservationN: ko.observable(false),
                        MSPrecautionsY: ko.observable(false),
                        MSPrecautionsN: ko.observable(false),
                        MShospitalDischarge: ko.observable(false),
                        MStreatmentRecommended: ko.observable(false),
                        MStreatmentRecommendedY: ko.observable(false),
                        MStreatmentRecommendedN: ko.observable(false),
                        TransferredTo: ko.observable(),
                        // Communicabledisease: ko.observable(false),
                        // Communicable: ko.observable(),
                        BookDoctor: ko.observable(),

                        MSHEmployeeNumber2: ko.observable(),
                        MSHTreatedBy2: ko.observable(),
                        MSHDateTreated2: ko.observable(""),
                        MSHTimeTreated2: ko.observable(),
                        DiagDescriptionInjuryExplanation: ko.observable(),

                        //...............................................
                        //MSH	Medical Statement - Hospital
                        //...............................................

                        //New Controls:

                        //SergeantEmployeeNumber2
                        //MSH.MSHTreatedBy2
                        //MSH.MSHDateTreated2
                        //MSH.MSHTimeTreated2

                        //MSH.DiagDescriptionInjuryExplanation

                        //				Removed Controls:MSH.MSobservationY MSH.MSobservationN  MSH.Communicabledisease  MSH.Communicable
                        //..............................................
                    },
                inmateStatement:
                    {
                        //Inmate Statement
                        Refused: ko.observable(false),
                        Incapacitated: ko.observable(false),
                        InmateStatement: ko.observable(),
                        InmateSignature: ko.observable(),
                        //Incapacitated: ko.observable(),


                        // InmateStatement	Inmate Statement	
                        //..................................
                        //New Controls
                        //inmateStatement.InmateSignature
                        //inmateStatement.InmateSignature
                        //inmateStatement.Incapacitated
                        //...................................

                    },
                wittnessStatement:
                    {
                        //Witness  Statement
                        WTBookingNumber: ko.observable(),
                        WTName: ko.observable(),
                        WTHousingLocation: ko.observable(),
                        WitnessStatement: ko.observable(),
                        WCEmpNumber: ko.observable(),
                        WCName: ko.observable(),
                        WCLog: ko.observable(false),
                        Quality: ko.observable(),
                        NotifiedBy: ko.observable(),
                        Telephone: ko.observable(false),
                        Email: ko.observable(false),
                        RejectComments: ko.observable(),
                        WitnessSignature: ko.observable(),
                        QANurseEmployeeNumber: ko.observable(),

                        //WitnessStatement	13 Witness Statement
                        //...........................................

                        //New Control/Missed in Last Implementation:

                        //wittnessStatement.WitnessSignature
                        //wittnessStatement.QANurseEmployeeNumber




                    },
            },
            //targetDiv = MSH #SergeantEmployeeNumber
            getEmployeeDetails: function (empId, targetDiv) {
                if (((empId != undefined) && (empId.length > 0) && localStorage.getItem('formMode') != "View")) {
                    // Search based on emp id
                    $.prototype.showProgressBar(targetDiv);
                    jQuery.ajax({
                        type: "GET",
                        url: EmployeeAPIUrl() + empId,
                        dataType: "json",
                        cache: false,
                        crossDomain: true,
                        processData: true,
                        success: function (empData) {
                            if (targetDiv == "MSH #SergeantEmployeeNumber")
                                uof.ui.inmate.detail.viewModel.MSH.MSHTreatedBy(empData.LastName + ' ' + empData.FirstName);
                            else if (targetDiv == "MSH #SergeantEmployeeNumber2")
                                uof.ui.inmate.detail.viewModel.MSH.MSHTreatedBy2(empData.LastName + ' ' + empData.FirstName);
                            else if (targetDiv == "IncidentNarrative #SergeantEmployeeNumber") {
                                uof.ui.inmate.detail.viewModel.incidentNarrative.IncidentNarrative_NameOfSergeant(empData.LastName + ' ' + empData.FirstName);
                            }
                            else if (targetDiv == "IncidentNarrative #SubmittedEmployeeNumber") {
                                uof.ui.inmate.detail.viewModel.incidentNarrative.SubmittedBy_NameOfSergeant(empData.LastName + ' ' + empData.FirstName);
                            }
                            else if (targetDiv == "IncidentNarrative #ApprovedEmployeeNumber") {
                                uof.ui.inmate.detail.viewModel.incidentNarrative.ApprovedBy_NameOfSergeant(empData.LastName + ' ' + empData.FirstName);
                            }
                            else if (targetDiv == "MSIL #SergeantEmployeeNumber") {
                                uof.ui.inmate.detail.viewModel.MSIL.TreatedBy(empData.LastName + ' ' + empData.FirstName);
                            }
                            else if (targetDiv == "WitnessStatement #WCEmpNumber") {
                                uof.ui.inmate.detail.viewModel.wittnessStatement.WCName(empData.LastName + ' ' + empData.FirstName);
                            }
                            else if (targetDiv == "EID") {
                                uof.ui.inmate.detail.viewModel.incidentInformation.EscortedBy(empData.LastName + ' ' + empData.FirstName.charAt(0));
                            }
                            else if (targetDiv == "Approve") {
                                uof.ui.inmate.detail.viewModel.incidentNarrative.ApprovedBy_NameOfSergeant(empData.LastName + ' ' + empData.FirstName.charAt(0));
                            }
                            else if (targetDiv == "EscortingPersonnelEID") {
                                uof.ui.inmate.detail.viewModel.incidentInformation.EscortingPersonnelName(empData.LastName + ' ' + empData.FirstName.charAt(0));
                            }
                            else if (targetDiv == "WitnessStatement #QANurseEmployeeNumber") {
                                uof.ui.inmate.detail.viewModel.wittnessStatement.Quality(empData.LastName + ' ' + empData.FirstName.charAt(0));
                            }

                            $.prototype.hideProgressBar(targetDiv);
                        },
                        error: function (XMLHttpRequest, textStatus, errorThrown) {
                            showAlert("Error while getting the Employee Data");
                        }
                    });
                }
            },
            //targetDiv = Inmate #BookingNumber
            getSuspectDetails: function (bookingNumber, targetDiv) {
                if (((bookingNumber != undefined) && (bookingNumber.length > 0) && localStorage.getItem('formMode') != "View")) {
                    var eventDate = uof.ui.CommonUILogic.detail.formatIncidentDateTime(UoFParams.IncidentDate);
                    $.prototype.showProgressBar(targetDiv);
                    jQuery.ajax({
                        type: "GET",
                        url: InmateAPIUrl() + bookingNumber + "&eventDate=" + eventDate + "",
                        dataType: "json",
                        cache: false,
                        crossDomain: true,
                        processData: true,
                        success: function (inmateData) {
                            $.prototype.hideProgressBar(targetDiv);
                            if (targetDiv == 'Inmate #BookingNumber') {
                                uof.ui.inmate.detail.viewModel.inmateInformation.EmployeeName(inmateData.LastName + ' ' + inmateData.FirstName + ' ' + inmateData.MiddleName);
                                uof.ui.inmate.detail.viewModel.inmateInformation.Sex(inmateData.Sex);
                                uof.ui.inmate.detail.viewModel.inmateInformation.DateOfBirth(moment(inmateData.DateOfBirth).format("MM/DD/YYYY"));
                                //uof.ui.inmate.detail.viewModel.inmateInformation.Race(inmateData.Race);
                                if (inmateData.Height != null) {
                                    //uof.ui.inmate.detail.viewModel.inmateInformation
                                }
                                if (inmateData.Weight != null) {
                                }

                                //if (inmateData.Race != null) {
                                //    $("#InmateRace").selectpicker('destroy');
                                //    uof.ui.inmate.detail.viewModel.inmateInformation.Race([]);
                                //    uof.ui.inmate.detail.viewModel.inmateInformation.Race(inmateData.Race);
                                //    $('#InmateRace').selectpicker('refresh');
                                //}
                                //else {
                                //    $("#InmateRace").selectpicker('destroy');
                                //    uof.ui.inmate.detail.viewModel.inmateInformation.Race([]);
                                //    $('#InmateRace').selectpicker('refresh');
                                //}
                                if (inmateData.Race != null) {
                                    $("#InmateRace").selectpicker('destroy');
                                    uof.ui.inmate.detail.viewModel.inmateInformation.Race([]);
                                    uof.ui.inmate.detail.viewModel.inmateInformation.Race(inmateData.Race);
                                    $('#InmateRace').selectpicker('refresh');
                                }
                                else {
                                    $("#InmateRace").selectpicker('destroy');
                                    uof.ui.inmate.detail.viewModel.inmateInformation.Race([]);
                                    $('#InmateRace').selectpicker('refresh');
                                }
                                var cellBunk = "";
                                if (inmateData.HousingCell != null)
                                    cellBunk = inmateData.InmateCell;
                                if (inmateData.HousingBunk != null) {
                                    if (cellBunk != "")
                                        cellBunk + "/" + inmateData.HousingBunk
                                }
                                uof.ui.inmate.detail.viewModel.inmateInformation.Cell(cellBunk);

                                if (inmateData.HousingFacility != null) {
                                    uof.ui.inmate.detail.viewModel.inmateInformation.HousingFacility(inmateData.HousingFacility)
                                }
                                var BMD = "";
                                if (inmateData.HousingModule != null)
                                    BMD = inmateData.HousingModule;
                                if (inmateData.HousingRow != null) {
                                    if (BMD != "")
                                        BMD + "/" + inmateData.HousingRow
                                }
                                uof.ui.inmate.detail.viewModel.inmateInformation.Barrack(BMD)

                            }
                            else if (targetDiv == 'WitnessStatement #WTBookingNumber') {
                                uof.ui.inmate.detail.viewModel.wittnessStatement.WTName(inmateData.LastName + ' ' + inmateData.FirstName + ' ' + inmateData.MiddleName);
                            }
                        },
                        error: function (XMLHttpRequest, textStatus, errorThrown) {
                            $.prototype.hideProgressBar(targetDiv);
                            showAlert("Error while getting the Suspect Data");
                        }
                    });
                }

            },
            bindValidation: function () {
                uof.ui.inmate.detail.bindMaskedControl();
                uof.ui.inmate.detail.subscribeMethod();
                uof.ui.inmate.detail.bindCustomValidation();
                ko.validation.init({ insertMessages: true });
                uof.ui.inmate.detail.initiateBindings();
                uof.ui.inmate.detail.initiatePickers();
            },
            load: function () {
                uof.ui.inmate.detail.bindValidation();
                uof.ui.inmate.detail.getRace();
                uof.ui.inmate.detail.getGender();
                uof.ui.inmate.detail.applybindingtoModel();
                uof.ui.inmate.detail.bindApproveorEdit();
                uof.ui.inmate.detail.setTabbing();

                //$(document).on('keyup', "#txtReject", function (e) {
                //    var Commtstring = $.trim($("#txtReject").val());
                //    if (Commtstring.length > 0) {
                //        $("#btnReject").prop('disabled', false);
                //        $("#btnApprove").prop('disabled', true);
                //    }
                //    else {
                //        $("#btnReject").prop('disabled', true);
                //        $("#btnApprove").prop('disabled', false);
                //    }
                //});

            },
            setTabbing: function () {
                var tab = 1;
                $("#dvInmateInjury *").filter(':input').each(function () {
                    $(this).attr('tabindex', tab++);
                });

            },

            bindApproveorEdit: function () {
                if (localStorage.getItem('formMode') == "View" || localStorage.getItem('formMode') == "Approve") {
                    if ($.IncidentId.length > 0 && $.UoFformId.length > 0 && $.SubmitedId.length > 0) {
                        uof.ui.inmate.detail.viewModel.IncidentID($.IncidentId);
                        uof.ui.inmate.detail.viewModel.FormID($.UoFformId);
                        uof.ui.inmate.detail.viewModel.EmpID($.SubmitedId);
                        uof.ui.inmate.detail.viewModel.SubmitedId($.SubmitedId);
                        uof.ui.inmate.detail.viewModel.UserRole(UoFParams.userRole);
                        uof.ui.inmate.detail.viewModel.IncidentReviewId(localStorage.getItem('IncidentReviewId') == null ? 0 : localStorage.getItem('IncidentReviewId'));
                        uof.ui.inmate.detail.viewModel.FormDataId(localStorage.getItem('FormDataId') == null ? 0 : localStorage.getItem('FormDataId'));
                        uof.ui.inmate.detail.viewModel.ActionType("V");
                    }
                }
                else {
                    uof.ui.inmate.detail.viewModel.IncidentID(UoFParams.IncidentId);
                    uof.ui.inmate.detail.viewModel.FormID($.UoFformId);
                    uof.ui.inmate.detail.viewModel.EmpID(UoFParams.userId);
                    uof.ui.inmate.detail.viewModel.SubmitedId(localStorage.getItem('SubmittedId') == null ? UoFParams.userId : localStorage.getItem('SubmittedId'));
                    uof.ui.inmate.detail.viewModel.IncidentReviewId(localStorage.getItem('IncidentReviewId') == null ? 0 : localStorage.getItem('IncidentReviewId'));
                    uof.ui.inmate.detail.viewModel.FormDataId(localStorage.getItem('FormDataId') == null ? 0 : localStorage.getItem('FormDataId'));
                }
                uof.ui.inmate.detail.bindInmateInjuryDetails();
            },
            subscribeMethod: function () {

                uof.ui.inmate.detail.viewModel.MSH.MSHEmployeeNumber.subscribe(function (newValue) {
                    if ($.trim(newValue) != "" && $.trim(newValue).length == 6) {
                        if (newValue == uof.ui.inmate.detail.viewModel.MSH.MSHEmployeeNumber2()) {
                            showAlert("Already entered this employee , please enter different one");
                            uof.ui.inmate.detail.viewModel.MSH.MSHEmployeeNumber(null);
                            uof.ui.inmate.detail.viewModel.MSH.MSHTreatedBy(null);
                            return false;
                        }
                    }
                });

                uof.ui.inmate.detail.viewModel.MSH.MSHEmployeeNumber2.subscribe(function (newValue) {
                    if ($.trim(newValue) != "" && $.trim(newValue).length == 6) {
                        if (newValue == uof.ui.inmate.detail.viewModel.MSH.MSHEmployeeNumber()) {
                            showAlert("Already entered this employee , please enter different one");
                            uof.ui.inmate.detail.viewModel.MSH.MSHEmployeeNumber2(null);
                            uof.ui.inmate.detail.viewModel.MSH.MSHTreatedBy2(null);
                            return false;
                        }
                    }
                });


                uof.ui.inmate.detail.viewModel.incidentNarrative.IncidentNarrative_EmployeeNumber.subscribe(function (newValue) {
                    if ($.trim(newValue) != "" && $.trim(newValue).length == 6) {
                        if (newValue == uof.ui.inmate.detail.viewModel.incidentNarrative.SubmittedBy_EmployeeNumber()) {
                            showAlert("Already entered this employee , please enter different one");
                            uof.ui.inmate.detail.viewModel.incidentNarrative.IncidentNarrative_EmployeeNumber(null);
                            uof.ui.inmate.detail.viewModel.incidentNarrative.IncidentNarrative_NameOfSergeant(null);
                            return false;
                        }
                    }
                });

                uof.ui.inmate.detail.viewModel.incidentNarrative.SubmittedBy_EmployeeNumber.subscribe(function (newValue) {
                    if ($.trim(newValue) != "" && $.trim(newValue).length == 6) {
                        if (newValue == uof.ui.inmate.detail.viewModel.incidentNarrative.IncidentNarrative_EmployeeNumber()) {
                            showAlert("Already entered this employee , please enter different one");
                            uof.ui.inmate.detail.viewModel.incidentNarrative.SubmittedBy_EmployeeNumber(null);
                            uof.ui.inmate.detail.viewModel.incidentNarrative.ApprovedBy_NameOfSergeant(null);
                            return false;
                        }
                    }
                });



                uof.ui.inmate.detail.viewModel.MSH.applicable.subscribe(function (newValue) {
                    if ($.trim(newValue)) {
                        uof.ui.inmate.detail.viewModel.MSH.MSHEmployeeNumber.valueHasMutated();
                        //uof.ui.inmate.detail.viewModel.MSH.MSHDateTreated.valueHasMutated();
                        //uof.ui.inmate.detail.viewModel.MSH.MSHTreatedBy.valueHasMutated();
                        uof.ui.inmate.detail.viewModel.MSH.MSHTimeTreated.valueHasMutated();
                        uof.ui.inmate.detail.viewModel.MSH.TransferredTo.valueHasMutated();
                        uof.ui.inmate.detail.viewModel.MSH.BookDoctor.valueHasMutated();
                        uof.ui.inmate.detail.viewModel.MSH.Communicable.valueHasMutated();
                        return false;
                    }

                });
                uof.ui.inmate.detail.viewModel.incidentInformation.InjuredY.subscribe(function (newValue) {
                    if (newValue) {
                        uof.ui.inmate.detail.viewModel.incidentInformation.ForeOrAllegationY.valueHasMutated();
                        // uof.ui.inmate.detail.viewModel.incidentInformation.ForeOrAllegationN.valueHasMutated();
                        // uof.ui.inmate.detail.viewModel.incidentInformation.FinalDiagnosisBy.valueHasMutated();
                        //  uof.ui.inmate.detail.viewModel.incidentInformation.FinalDiagnosisDateTime.valueHasMutated();
                        // uof.ui.inmate.detail.viewModel.incidentInformation.PersonContacted.valueHasMutated();
                        //  uof.ui.inmate.detail.viewModel.incidentInformation.FinalDiagnosis.valueHasMutated();
                        uof.ui.inmate.detail.viewModel.incidentInformation.Accident.valueHasMutated();
                        uof.ui.inmate.detail.viewModel.incidentInformation.furtherInvestigation.valueHasMutated();
                        uof.ui.inmate.detail.viewModel.incidentInformation.Alone.valueHasMutated();
                        uof.ui.inmate.detail.viewModel.incidentInformation.Segregated.valueHasMutated();
                        uof.ui.inmate.detail.viewModel.incidentInformation.WithOthers.valueHasMutated();
                        return false;
                    }

                });
                uof.ui.inmate.detail.viewModel.incidentInformation.furtherInvestigation.subscribe(function (newValue) {
                    uof.ui.inmate.detail.viewModel.incidentInformation.InvestigationURN.valueHasMutated();
                });
                uof.ui.inmate.detail.viewModel.inmateInformation.chkSegregation.subscribe(function (newValue) {
                    if (newValue) {
                        uof.ui.inmate.detail.viewModel.inmateInformation.Segregation.valueHasMutated();
                        return false;
                    }
                    else if (!newValue)
                        uof.ui.inmate.detail.viewModel.inmateInformation.Segregation(null);
                });
                //uof.ui.inmate.detail.viewModel.inmateInformation.chkGeneralPopulation.subscribe(function (newValue) {
                //        uof.ui.inmate.detail.toggleValidation(newValue)
                //});
                //uof.ui.inmate.detail.viewModel.inmateInformation.chkMentalHealthHousing.subscribe(function (newValue) {
                //    uof.ui.inmate.detail.toggleValidation(newValue)
                //});
                //uof.ui.inmate.detail.viewModel.inmateInformation.chkMedicalHousing.subscribe(function (newValue) {
                //    uof.ui.inmate.detail.toggleValidation(newValue)
                //});
                //uof.ui.inmate.detail.viewModel.inmateInformation.chkDiscipline.subscribe(function (newValue) {
                //    uof.ui.inmate.detail.toggleValidation(newValue)
                //});
                //uof.ui.inmate.detail.viewModel.inmateInformation.chkSegregation.subscribe(function (newValue) {
                //    uof.ui.inmate.detail.toggleValidation(newValue)
                //});


            },



            getGender: function () {
                $.prototype.showUofOverlay();
                $.ajax(
                {
                    url: window.location.uofAPIOrigin() + '/api/Lookup/getGender',
                    cache: false,
                    type: "GET",
                    dataType: 'json',
                    contentType: "application/json;charset=utf-8",
                    beforeSend: function myfunction() {

                    },
                    success: function (lookupData) {
                        uof.ui.inmate.detail.viewModel.Sex(lookupData);
                        $.prototype.hideUofOverlay();
                    },
                    error: function (e) {
                        showAlert(e.responseText);
                    },
                });
            },
            getRace: function () {
                $.prototype.showUofOverlay();
                $.ajax(
                {
                    url: window.location.uofAPIOrigin() + '/api/Lookup/GetRacies',
                    cache: false,
                    type: "GET",
                    dataType: 'json',
                    contentType: "application/json;charset=utf-8",
                    beforeSend: function myfunction() {

                    },
                    success: function (lookupData) {
                        uof.ui.inmate.detail.viewModel.Race([]);
                        uof.ui.inmate.detail.viewModel.Race(lookupData);
                        uof.ui.inmate.detail.viewModel.Race.valueHasMutated();
                        $('#InmateRace').selectpicker('refresh')

                        $.prototype.hideUofOverlay();
                    },
                    error: function (e) {
                        showAlert(e.responseText);
                    },
                });
            },
            bindMaskedControl: function () {
                if (UoFParams.IncidentURN != "") {
                    uof.ui.inmate.detail.viewModel.inmateInformation.URN(UoFParams.IncidentURN);
                    uof.ui.inmate.detail.viewModel.incidentInformation.InvestigationURN(UoFParams.IncidentURN);
                    uof.ui.inmate.detail.viewModel.inmateInformation.ReferenceNumber(UoFParams.ReferenceNo);
                    uof.ui.inmate.detail.viewModel.incidentInformation.IncidentDate(UoFParams.IncidentDate);
                    uof.ui.inmate.detail.viewModel.incidentInformation.IncidentLocation(UoFParams.IncidentLocation);
                    //if (UoFParams.WC.length > 6) {
                    //    uof.ui.inmate.detail.viewModel.wittnessStatement.WCEmpNumber(UoFParams.WC.split('-')[0]);
                    //    uof.ui.inmate.detail.viewModel.wittnessStatement.WCName(UoFParams.WC.split('-')[1]);
                    //}
                    uof.ui.inmate.detail.viewModel.incidentInformation.TypeOfLocation(UoFParams.IncidentForceLocation);
                }

                ko.bindingHandlers.inputmask =
                {
                    init: function (element, valueAccessor, allBindingsAccessor) {

                        var mask = valueAccessor();

                        var observable = mask.value;

                        if (ko.isObservable(observable)) {

                            $(element).on('focusout change', function () {

                                if ($(element).inputmask('isComplete')) {
                                    observable($(element).val());
                                } else {
                                    observable(null);
                                }

                            });
                        }

                        $(element).inputmask(mask);


                    },
                    update: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
                        var mask = valueAccessor();

                        var observable = mask.value;

                        if (ko.isObservable(observable)) {

                            var valuetoWrite = observable();

                            $(element).val(valuetoWrite);
                        }
                    }

                };
            },

            bindCustomValidation: function () {
                ko.validation.rules['checked'] = {
                    validator: function (value) {
                        if (!value) {
                            return false;
                        }
                        return true;
                    }
                };

                ko.validation.registerExtenders();

            },

            initiatePickers: function () {

                $('#IncidentDate').datetimepicker({ format: 'MM/DD/YYYY' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.inmate.detail.viewModel.incidentInformation.IncidentDate(newDate);
                });
                //$('#DiagnosisDateTime').datetimepicker({ format: 'MM/DD/YYYY HH:mm', defaultDate: 'now' }).on('dp.change', function (ev) {
                //    var newDate = null;
                //    if (ev.date != null)
                //        newDate = moment(ev.date).format("MM/DD/YYYY HH:mm:ss");
                //    uof.ui.inmate.detail.viewModel.incidentInformation.FinalDiagnosisDateTime(newDate);
                //});
                $('#IDOB').datetimepicker({ format: 'MM/DD/YYYY' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.inmate.detail.viewModel.inmateInformation.DateOfBirth(newDate);
                });
                $('#INDate1').datetimepicker({ format: 'MM/DD/YYYY' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.inmate.detail.viewModel.incidentNarrative.IncidentNarrative_Date(newDate);
                });
                $('#INDate2').datetimepicker({ format: 'MM/DD/YYYY' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.inmate.detail.viewModel.incidentNarrative.SubmittedBy_Date(newDate);
                });
                $('#INDate3').datetimepicker({ format: 'MM/DD/YYYY', defaultDate: 'now' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.inmate.detail.viewModel.incidentNarrative.ApprovedBy_Date(newDate);
                });

                $('#DateTreatedLoc').datetimepicker({ format: 'MM/DD/YYYY' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.inmate.detail.viewModel.MSIL.DateTreated(newDate);
                });
                $('#DateTreatedHosp').datetimepicker({ format: 'MM/DD/YYYY' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.inmate.detail.viewModel.MSH.MSHDateTreated(newDate);
                });
                $('#DeputyEscortingtoHospitalDate').datetimepicker({ format: 'MM/DD/YYYY' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.inmate.detail.viewModel.incidentInformation.DeputyEscortingtoHospitalDate(newDate);
                });
                $('#DoctorTreatedDate').datetimepicker({ format: 'MM/DD/YYYY' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.inmate.detail.viewModel.incidentInformation.DoctorTreatedDate(newDate);
                });
                $('#DoctorTreatedDate').datetimepicker({ format: 'MM/DD/YYYY' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.inmate.detail.viewModel.incidentInformation.InmateDispoDate(newDate);
                });
                $('#MSHDateT').datetimepicker({ format: 'MM/DD/YYYY' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.inmate.detail.viewModel.MSH.MSHDateTreated2(newDate);
                });
                $('#IncidentTime').on('keydown', function (e) {
                    if (e.keyCode == 9) {
                        $(this).timepicker('hideWidget');
                    }
                });
                $('#EscortedToAt').on('keydown', function (e) {
                    if (e.keyCode == 9) {
                        $(this).timepicker('hideWidget');
                    }
                });
                $('#TransportedToAt').on('keydown', function (e) {
                    if (e.keyCode == 9) {
                        $(this).timepicker('hideWidget');
                    }
                });

                $('#EscortedByAt').on('keydown', function (e) {
                    if (e.keyCode == 9) {
                        $(this).timepicker('hideWidget');
                    }
                });
                $('#SeenByAtHours').on('keydown', function (e) {
                    if (e.keyCode == 9) {
                        $(this).timepicker('hideWidget');
                    }
                });
                $('#TimeTreated').on('keydown', function (e) {
                    if (e.keyCode == 9) {
                        $(this).timepicker('hideWidget');
                    }
                });
                $('#MSHTimeTreated').on('keydown', function (e) {
                    if (e.keyCode == 9) {
                        $(this).timepicker('hideWidget');
                    }
                });
                $('#NotifiedBy').on('keydown', function (e) {
                    if (e.keyCode == 9) {
                        $(this).timepicker('hideWidget');
                    }
                });
                $(".timepicker").attr("maxlength", 4);
                $(".timepicker").timepicker({
                    showInputs: false,
                    showMeridian: false,
                    minuteStep: 1
                });

            },

            initiateBindings: function () {
                ko.validation.insertValidationMessage = function (element) {
                    var br = document.createElement("br");
                    element.appendChild(br);
                    var span = document.createElement('SPAN');
                    span.className = "warning-msg";
                    var inputGroups = $(element).closest(".date"); //This is for getting Date Fields
                    if (inputGroups.length > 0) {
                        // We're in an input-group so we place the message after
                        // the group rather than inside it in order to not break the design
                        $(span).insertAfter(inputGroups);
                    }
                    else {
                        // The default in knockout-validation
                        element.parentNode.insertBefore(span, element.nextSibling);
                    }
                    return span;
                };

            },
            applybindingtoModel: function () {
                uof.ui.inmate.detail.validateControls();
                //binding Inmate Info page
                ko.cleanNode($("#Inmate").get(0));
                ko.applyBindings(uof.ui.inmate.detail.viewModel, $("#Inmate").get(0));

                //binding IncidentInfo page
                ko.cleanNode($("#IncidentInfo").get(0));
                ko.applyBindings(uof.ui.inmate.detail.viewModel, $("#IncidentInfo").get(0));

                //binding IncidentNarrative page
                ko.cleanNode($("#IncidentNarrative").get(0));
                ko.applyBindings(uof.ui.inmate.detail.viewModel, $("#IncidentNarrative").get(0));

                //binding MSIL page
                ko.cleanNode($("#MSIL").get(0));
                ko.applyBindings(uof.ui.inmate.detail.viewModel, $("#MSIL").get(0));

                //binding MSH page
                ko.cleanNode($("#MSH").get(0));
                ko.applyBindings(uof.ui.inmate.detail.viewModel, $("#MSH").get(0));

                //binding InmateStatement page
                ko.cleanNode($("#InmateStatement").get(0));
                ko.applyBindings(uof.ui.inmate.detail.viewModel, $("#InmateStatement").get(0));

                //binding WitnessStatement page
                ko.cleanNode($("#WitnessStatement").get(0));
                ko.applyBindings(uof.ui.inmate.detail.viewModel, $("#WitnessStatement").get(0));

                //if (UoFParams.IncidentURN != "") {
                //    uof.ui.inmate.detail.inmateInformation.URN(UoFParams.IncidentURN);
                //    uof.ui.inmate.detail.incidentInformation.InvestigationURN(UoFParams.IncidentURN);
                //}

            },
            // binding inmate injury data onloads
            bindInmateInjuryDetails: function () {
                if (uof.ui.inmate.detail.viewModel.FormDataId() == 0) {
                    uof.ui.inmate.detail.MedicalSection();
                    uof.ui.inmate.detail.SupervisorySection();
                    return;
                }
                $.prototype.showUofOverlay();
                uof.ui.inmate.detail.ParameterCriteria.IncidentReviewId = uof.ui.inmate.detail.viewModel.IncidentReviewId();
                uof.ui.inmate.detail.ParameterCriteria.formDataId = uof.ui.inmate.detail.viewModel.FormDataId();
                uof.ui.inmate.detail.ParameterCriteria.employeeId = uof.ui.inmate.detail.viewModel.EmpID();
                uof.ui.inmate.detail.ParameterCriteria.incidentId = uof.ui.inmate.detail.viewModel.IncidentID();
                uof.ui.inmate.detail.ParameterCriteria.formId = uof.ui.inmate.detail.viewModel.FormID();//e.data.FormId;
                var model = ko.mapping.toJS(uof.ui.inmate.detail.ParameterCriteria);
                $.ajax(
                       {
                           url: window.location.uofAPIOrigin() + '/api/InmateInjury/GetInmateInjuryInfo',
                           cache: false,
                           data: JSON.stringify(model),
                           //data: { FormId: uof.ui.inmate.detail.viewModel.FormID(), IncidentId: uof.ui.inmate.detail.viewModel.IncidentID(), DeputyId: uof.ui.inmate.detail.viewModel.EmpID() },
                           type: "POST",
                           dataType: 'json',
                           contentType: "application/json;charset=utf-8",
                           beforeSend: function myfunction() {

                           },
                           success: function (data) {
                               if (data != null) {
                                   uof.ui.inmate.detail.bindValidation();
                                   uof.ui.inmate.detail.setInmateInjuryInformation(data);

                               }
                               else
                                   uof.ui.inmate.detail.viewModel.IsOnlyApproval(false);
                               $.prototype.hideUofOverlay();
                           },
                           error: function (e) {
                               $.prototype.hideUofOverlay();
                               showAlert(e.responseText);

                           },
                       });

            },

            //binding inmate information
            setInmateInjuryInformation: function (data) {
                $("#InmateRace").selectpicker('destroy');
                uof.ui.inmate.detail.viewModel.inmateInformation = ko.mapping.fromJS(data.inmateInformation, ko.mapping.toJS(uof.ui.inmate.detail.viewModel.inmateInformation));
                uof.ui.inmate.detail.viewModel.incidentInformation = ko.mapping.fromJS(data.incidentInformation, ko.mapping.toJS(uof.ui.inmate.detail.viewModel.incidentInformation));
                uof.ui.inmate.detail.viewModel.incidentNarrative = ko.mapping.fromJS(data.incidentNarrative, ko.mapping.toJS(uof.ui.inmate.detail.viewModel.incidentNarrative));
                uof.ui.inmate.detail.viewModel.MSIL = ko.mapping.fromJS(data.msil, ko.mapping.toJS(uof.ui.inmate.detail.viewModel.MSIL));
                uof.ui.inmate.detail.viewModel.MSH = ko.mapping.fromJS(data.msh, ko.mapping.toJS(uof.ui.inmate.detail.viewModel.MSH));
                uof.ui.inmate.detail.viewModel.inmateStatement = ko.mapping.fromJS(data.inmateStatement, ko.mapping.toJS(uof.ui.inmate.detail.viewModel.inmateStatement));
                uof.ui.inmate.detail.viewModel.wittnessStatement = ko.mapping.fromJS(data.wittnessStatement, ko.mapping.toJS(uof.ui.inmate.detail.viewModel.wittnessStatement));


                uof.ui.inmate.detail.applybindingtoModel();
                uof.ui.inmate.detail.initiatePickers();
                var rInfo = uof.ui.inmate.detail.viewModel.inmateInformation.Race()
                uof.ui.inmate.detail.viewModel.inmateInformation.Race(rInfo);
                $("#InmateRace").selectpicker('refresh');

                if (uof.ui.inmate.detail.viewModel.wittnessStatement.RejectComments() != "") {
                    $(".fakeclass").removeClass('hide');
                    $("#txtReject").attr('disabled', false);
                }

                //if (localStorage.getItem('formMode') == "View" || localStorage.getItem('formMode') == "Approve") {
                //    $("#vertical-tabs *").find('input, select, textarea').each(function () {
                //        $(this).attr('disabled', true);
                //    });
                //    if (localStorage.getItem('formMode') == "Approve") {
                //        uof.ui.inmate.detail.viewModel.IsSupervisorOrApprover(true);
                //    }
                //}
                //if (uof.ui.inmate.detail.viewModel.IsSupervisorOrApprover()) {
                //    $(".fakeclass").removeClass('hide');
                //    $("#txtReject").attr('disabled', false);
                //    $('#divApproval:first > *').find('input').each(function () {
                //        $(this).attr('disabled', false);
                //    });
                //    uof.ui.inmate.detail.initiatePickers();
                //}
                uof.ui.inmate.detail.toggleControls();

            },
            toggleControls: function () {
                uof.ui.inmate.detail.viewModel.SubmitedId(localStorage.getItem('SubmittedId') == null ? UoFParams.userId : localStorage.getItem('SubmittedId'));
                uof.ui.inmate.detail.viewModel.IncidentReviewId(localStorage.getItem('IncidentReviewId') == null ? 0 : localStorage.getItem('IncidentReviewId'))
                var formData = uof.ui.CommonUILogic.detail.isFormStatusCompleted($.UoFformId, UoFParams.IncidentId, uof.ui.inmate.detail.viewModel.IncidentReviewId());
                if (formStatus != "") {
                    var formStatus = formData.split('\r\n');
                    uof.ui.inmate.detail.viewModel.IsFormOwner(formStatus[0].split(':')[1].toLowerCase() == "true" ? true : false);
                    uof.ui.inmate.detail.viewModel.IsIncidentOwner(formStatus[1].split(':')[1].toLowerCase() == "true" ? true : false);
                    if (formStatus.length > 2) {
                        uof.ui.inmate.detail.viewModel.IsLock(formStatus[2].split(':')[1].toLowerCase() == "true" ? true : false);
                        uof.ui.inmate.detail.viewModel.IsSupervisorStatus(formStatus[3].split(':')[1].toLowerCase());
                    }
                    if (uof.ui.inmate.detail.viewModel.IsLock()) {
                        $("#vertical-tabs *").find('input, select, textarea').each(function () {
                            $(this).attr('disabled', true);
                        });
                        $('.fakeSave').addClass('hide');
                        $("#btnReset").addClass('hide'); $("#btnSave").addClass('hide');
                        $("#btnApprove").addClass('hide'); $("#btnReject").addClass('hide');
                        if (localStorage.getItem('formMode') == "Approve") {
                            $("#btnApprove").prop('disabled', false); $("#btnApprove").removeClass('hide');
                            $("#btnReject").prop('disabled', false); $("#btnReject").removeClass('hide');
                            uof.ui.inmate.detail.viewModel.IsSupervisorOrApprover(true);
                            $(".fakeclass").removeClass('hide');
                            $("#txtReject").attr('disabled', false);
                            //$('#divApproval:first > *').find('input').each(function () {
                            //    $(this).attr('disabled', false);
                            //});
                            //uof.ui.inmate.detail.validateControls();
                        }
                        uof.ui.inmate.detail.getEmployeeDetails(uof.ui.inmate.detail.viewModel.incidentNarrative.ApprovedBy_EmployeeNumber(), 'Approve');
                        uof.ui.inmate.detail.MedicalSection();
                        uof.ui.inmate.detail.SupervisorySection();
                    }
                    else {
                        $("#btnApprove").addClass('hide'); $("#btnReject").addClass('hide');
                        if (!uof.ui.inmate.detail.viewModel.IsFormOwner() && (uof.ui.inmate.detail.viewModel.IsSupervisorStatus() == "pending" || uof.ui.inmate.detail.viewModel.IsSupervisorStatus() == "rejected")) {
                            $("#vertical-tabs *").find('input, select, textarea').each(function () {
                                $(this).attr('disabled', true);
                            });
                            $("#btnReset").addClass('hide'); $("#btnSave").addClass('hide');
                            $("#btnApprove").addClass('hide'); $("#btnReject").addClass('hide');
                            if (localStorage.getItem('formMode') == "Approve") {
                                $('.fakeSave').addClass('hide');
                                $("#btnApprove").prop('disabled', false); $("#btnApprove").removeClass('hide');
                                $("#btnReject").prop('disabled', false); $("#btnReject").removeClass('hide');
                                uof.ui.inmate.detail.viewModel.IsSupervisorOrApprover(true);
                                $(".fakeclass").removeClass('hide');
                                $("#txtReject").attr('disabled', false);
                                $("#divApproval").css({ style: "display:block" });
                                $('#divApproval:first > *').find('input').each(function () {
                                    $(this).attr('disabled', false);
                                });
                                $('#divSergeantNarrative:first > *').find('input').each(function () {
                                    $(this).attr('disabled', false);
                                });
                                $('#divSerNarrative:first > *').find('input, select, textarea').each(function () {
                                    $(this).attr('disabled', false);
                                });
                                uof.ui.inmate.detail.initiatePickers();
                                uof.ui.inmate.detail.validateControls();
                            }
                            uof.ui.inmate.detail.MedicalSection();
                            uof.ui.inmate.detail.SupervisorySection();
                        }

                    }
                    if (uof.ui.inmate.detail.viewModel.IsSupervisorOrApprover()) {
                        uof.ui.inmate.detail.viewModel.incidentNarrative.ApprovedBy_Date(moment(new Date()).format("MM/DD/YYYY"));
                        uof.ui.inmate.detail.viewModel.incidentNarrative.ApprovedBy_EmployeeNumber(UoFParams.userId);
                        uof.ui.inmate.detail.getEmployeeDetails(UoFParams.userId, 'Approve');
                    }
                }
            },
            MedicalSection: function () {
                if (UoFParams.userRole == "MED" || UoFParams.userRank == "9") {
                    uof.ui.inmate.detail.redirecttoValidationScreen("anchormsilInfo");
                    $("#vertical-tabs *").find('input, select, textarea').each(function () {
                        $(this).attr('disabled', true);
                    });
                    $('.fakeSave').addClass('hide');
                    $("#btnReset").addClass('hide'); $("#btnSave").addClass('hide');
                    $("#btnApprove").addClass('hide'); $("#btnReject").addClass('hide');
                    if (uof.ui.inmate.detail.viewModel.IsSupervisorStatus() != "pending")
                        $("#btnMedicalSave").addClass("hide");
                    else
                        $("#btnMedicalSave").removeClass("hide");
                    if (uof.ui.inmate.detail.viewModel.MSIL.EmployeeNumber() == "" || uof.ui.inmate.detail.viewModel.MSIL.EmployeeNumber() == null) {
                        $("#MSIL *").find('input, select, textarea').each(function () {
                            $(this).attr('disabled', false);
                        });
                        $("#btnMedicalSave").removeClass("hide");
                    }
                    else
                        $("#btnMedicalSave").addClass("hide");

                }
            },
            SupervisorySection: function () {
                if (UoFParams.userRank == "2") {
                    if ($("#ApprovedEmployeeNumber").val() == "") {
                        $("#divApproval *").find('input, select, textarea').each(function () {
                            $(this).attr('disabled', false);
                        });
                        $('#divSergeantNarrative:first > *').find('input').each(function () {
                            $(this).attr('disabled', false);
                        });
                        $('#divSerNarrative:first > *').find('input,textarea').each(function () {
                            $(this).attr('disabled', false);
                        });
                    }
                }
                if (UoFParams.userRank == "3") {
                    if ($("#WCEmpNumber").val() == "") {
                        $("#divWCApprove *").find('input, select, textarea').each(function () {
                            $(this).attr('disabled', false);
                        });
                    }
                }
            },

            //save inmate injury records
            saveInmateDetails: function () {
                if (UoFParams.userRole == "MED" || UoFParams.userRank == "9") {
                    uof.ui.inmate.detail.viewModel.isMedical(true);
                    if (uof.ui.inmate.detail.validateMSIL()) {
                        $.when(showConfirmationWindow('Do you want to submit the for the review ? ')).then(function (confirmed) {
                            if (confirmed)
                                uof.ui.inmate.detail.SaveInmateInjuryInfo(false, false);
                        });
                    }
                }
                else {
                    if (uof.ui.inmate.detail.validateInmatateDetail()) {
                        $.when(showConfirmationWindow('Do you want to submit the for the review ? ')).then(function (confirmed) {
                            if (confirmed)
                                uof.ui.inmate.detail.SaveInmateInjuryInfo(false, false);
                        });
                    }
                }
            },
            buildDeputyObject: function (isApprove) {
                var oDeputyData = new Object();
                oDeputyData.IncidentId = uof.ui.inmate.detail.viewModel.IncidentID();
                oDeputyData.FormId = uof.ui.inmate.detail.viewModel.FormID();
                oDeputyData.DeputyEmpId = uof.ui.inmate.detail.viewModel.EmpID();
                oDeputyData.isApprove = isApprove;
                if (uof.ui.inmate.detail.viewModel.incidentNarrative.ApprovedBy_EmployeeNumber() != UoFParams.userId)
                    oDeputyData.ReviewerReviewId = uof.ui.inmate.detail.viewModel.incidentNarrative.ApprovedBy_EmployeeNumber();
                else
                    oDeputyData.ReviewerReviewId = UoFParams.userId;

                oDeputyData.ReviewerRole = UoFParams.userRole;
                oDeputyData.Comment = uof.ui.inmate.detail.viewModel.wittnessStatement.RejectComments();
                oDeputyData.IncidentReviewId = uof.ui.inmate.detail.viewModel.IncidentReviewId();
                return oDeputyData;
            },
            approveInmateDetails: function (isApprove) {
                if (uof.ui.inmate.detail.validateIncidentNarrative(undefined, isApprove == "Y" ? true : false)) {
                    var str = isApprove == "Y" ? "Do you want to Approve?" : "Do you want to Reject?";
                    $.when(showConfirmationWindow(str)).then(function (confirmed) {
                        if (confirmed) {
                            if (isApprove == "Y") {
                                if (uof.ui.inmate.detail.viewModel.IsOnlyApproval())
                                    uof.ui.inmate.detail.SaveInmateInjuryInfo(true, false);
                                else {
                                    var oDeputyData = uof.ui.inmate.detail.buildDeputyObject(isApprove);
                                    var mappedData = ko.mapping.toJS(oDeputyData);
                                    $.ajax(
                                          {
                                              url: window.location.uofAPIOrigin() + '/api/UOFForm/ApproveorReject',
                                              cache: false,
                                              type: "POST",
                                              dataType: 'json',
                                              data: JSON.stringify(mappedData),
                                              contentType: "application/json;charset=utf-8",
                                              beforeSend: function myfunction() {

                                              },
                                              success: function (data) {
                                                  $.prototype.hideUofOverlay();
                                                  showAlert((isApprove == "Y" ? "Approved" : "Rejected") + " Succesfully");
                                                  uof.ui.inmate.detail.setApprovedIncidentinSession(oDeputyData.IncidentId);
                                              },
                                              error: function (e) {
                                                  $.prototype.hideUofOverlay();
                                                  showAlert(e.responseText);
                                              },
                                          });
                                }
                            }
                            else {
                                var oDeputyData = uof.ui.inmate.detail.buildDeputyObject(isApprove);
                                var mappedData = ko.mapping.toJS(oDeputyData);
                                $.ajax(
                                      {
                                          url: window.location.uofAPIOrigin() + '/api/UOFForm/ApproveorReject',
                                          cache: false,
                                          type: "POST",
                                          dataType: 'json',
                                          data: JSON.stringify(mappedData),
                                          contentType: "application/json;charset=utf-8",
                                          beforeSend: function myfunction() {

                                          },
                                          success: function (data) {
                                              $.prototype.hideUofOverlay();
                                              showAlert((isApprove == "Y" ? "Approved" : "Rejected") + " Succesfully");
                                              uof.ui.inmate.detail.setApprovedIncidentinSession(oDeputyData.IncidentId);
                                              // window.location.href = window.location.uofUIOrigin() + '/Incident/Incident';
                                          },
                                          error: function (e) {
                                              $.prototype.hideUofOverlay();
                                              showAlert(e.responseText);
                                          },
                                      });
                            }
                        }
                    });
                }
            },
            setApprovedIncidentinSession: function (incidentId) {
                $.ajax(
                     {
                         url: window.location.uofUIOrigin() + '/Incident/setApprovedIncident',
                         type: "POST",
                         data: { incidentID: incidentId },
                         success: function (data) {
                             if (data == "true")
                                 window.location.href = window.location.uofUIOrigin() + '/Incident/Incident';
                         },
                         error: function (e) {
                             showAlert(e.responseText);
                         },
                     });
            },
            SaveInmateInjuryInfo: function (isApproval, IsOnlySave) {
                uof.ui.inmate.detail.viewModel.FormID($.UoFformId);
                var inMateRace = uof.ui.inmate.detail.viewModel.inmateInformation.Race();
                uof.ui.inmate.detail.viewModel.inmateInformation.Race(inMateRace);
                uof.ui.inmate.detail.viewModel.IncidentID(UoFParams.IncidentId);
                uof.ui.inmate.detail.viewModel.IsOnlySave(IsOnlySave);
                if (uof.ui.inmate.detail.viewModel.inmateInformation.Race() != null) {
                    uof.ui.inmate.detail.viewModel.inmateInformation.Race(uof.ui.inmate.detail.viewModel.inmateInformation.Race().toString());
                }
                var jsonData = ko.mapping.toJS(uof.ui.inmate.detail.viewModel);
                jsonData.EmpID = UoFParams.userId;
                jsonData.UserRole = UoFParams.userRole;
                jsonData.isApproval = isApproval;

                $.prototype.showUofOverlay();


                $.ajax(
                       {
                           url: window.location.uofAPIOrigin() + '/api/InmateInjury/SaveInmateInjuryInfo',
                           cache: false,
                           type: "POST",
                           dataType: 'json',
                           data: JSON.stringify(jsonData),
                           contentType: "application/json;charset=utf-8",
                           beforeSend: function myfunction() {

                           },
                           success: function (empData) {
                               $.prototype.hideUofOverlay();
                               localStorage.setItem('formMode', ""); //Setting the formode to null.
                               if (isApproval) {
                                   showAlert("Approved/Reject Successfully");
                                   uof.ui.incident.detail.setApprovedIncidentinSession(UoFParams.IncidentId);
                               }
                               else {
                                   showAlert(IsOnlySave ? "Data saved successfully" : "submited successfully");
                                   uof.ui.inmate.detail.viewModel.FormDataId(empData);
                               }
                           },
                           error: function (e) {
                               $.prototype.hideUofOverlay();
                               showAlert(e.responseText);
                               localStorage.setItem('selectedIncidentId', 4);//just for testing, Put actual incidentId here
                               uof.ui.incident.detail.selectedContext.selectedIncident(4);
                           },
                       });

            },
            //Validate the controls on Add and duplicate popup
            validateControls: function () {

                //Inmate Information Starts

                ////remove old validation
                //$("#newincident .warning").each(function () {
                //    $(this).parent().remove();
                //});

                //Validate the controls on Add and duplicate popup
                uof.ui.inmate.detail.viewModel.inmateInformation.URN.extend({
                    required: {
                        params: true,
                        message: InmateConstants.Required
                    },
                    pattern: {
                        params: "^[a-zA-Z0-9 _@#-.~!$%&()={}^]+$",
                        message: InmateConstants.URN + ' \\ / : * ? ` ; " < > | [ ]'
                    },
                    maxLength: {
                        params: 100,
                        message: 'URN maximum character should be 100 only.'
                    },
                });
                ////Reference Number
                //uof.ui.inmate.detail.viewModel.inmateInformation.ReferenceNumber.extend({
                //    required: {
                //        params: true,
                //        message:  InmateConstants.Required
                //    },
                //    maxLength: {
                //        params: 100,
                //        message: 'Reference Number maximum character should be 100 only.'
                //    },
                //});
                //Booking Number
                uof.ui.inmate.detail.viewModel.inmateInformation.BookingNumber.extend({
                    required: {
                        params: true,
                        message: InmateConstants.Required,
                        onlyIf: function () {
                            return (UoFParams.userRank == "1")
                        }
                    },
                    maxLength: {
                        params: 100,
                        message: 'Booking Number maximum character should be 100 only.'
                    },
                });


                // incedent Info
                uof.ui.inmate.detail.viewModel.incidentInformation.IncidentLocation.extend({
                    required: {
                        params: true,
                        message: "Incident Location" + InmateConstants.Required,
                        onlyIf: function () {
                            return (UoFParams.userRank == "1")
                        }
                    }
                });
                //Type of Location
                uof.ui.inmate.detail.viewModel.incidentInformation.TypeOfLocation.extend({
                    required: {
                        params: true,
                        message: "Type of Location" + InmateConstants.Required,
                        onlyIf: function () {
                            return (UoFParams.userRank == "1")
                        }
                    }
                });
                //Incident Date
                uof.ui.inmate.detail.viewModel.incidentInformation.IncidentDate.extend({
                    required: {
                        params: true,
                        message: "Incident Date" + InmateConstants.Required,
                        onlyIf: function () {
                            return (UoFParams.userRank == "1")
                        }
                    }
                });
                //Incident Time
                uof.ui.inmate.detail.viewModel.incidentInformation.IncidentTime.extend({
                    required: {
                        params: true,
                        message: "Incident Time" + InmateConstants.Required,
                        onlyIf: function () {
                            return (UoFParams.userRank == "1")
                        }
                    }
                });

                //uof.ui.inmate.detail.viewModel.incidentInformation.PersonContacted.extend({
                //    required: {
                //        params: true,
                //        message: InmateConstants.Required,
                //        onlyIf: function () {
                //            return uof.ui.inmate.detail.viewModel.incidentInformation.InjuredY();
                //        }
                //    }
                //});

                uof.ui.inmate.detail.viewModel.incidentInformation.InvestigationURN.extend({
                    required: {
                        params: true,
                        message: "Investigation URN" + InmateConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.inmate.detail.viewModel.incidentInformation.furtherInvestigation() === true);
                        }
                    }
                });


                //Escorted To Clinic
                uof.ui.inmate.detail.viewModel.incidentInformation.EscortedToClinic.extend({
                    required: {
                        params: true,
                        message: "Escorted Clinic " + InmateConstants.Required,
                        onlyIf: function () {
                            return uof.ui.inmate.detail.viewModel.incidentInformation.wasEscorted();
                        }
                    }
                });
                //Escorted To At
                uof.ui.inmate.detail.viewModel.incidentInformation.EscortedToAt.extend({
                    required: {
                        params: true,
                        message: "Escorted At" + InmateConstants.Required,
                        onlyIf: function () {
                            return uof.ui.inmate.detail.viewModel.incidentInformation.wasEscorted();
                        }
                    }
                });
                //Transported To Clinic
                uof.ui.inmate.detail.viewModel.incidentInformation.TransportedToClinic.extend({
                    required: {
                        params: true,
                        message: "Transported to Clinic " + InmateConstants.Required,
                        onlyIf: function () {
                            return uof.ui.inmate.detail.viewModel.incidentInformation.wasTransported();
                        }
                    }
                });
                //Transported To At
                uof.ui.inmate.detail.viewModel.incidentInformation.TransportedToAt.extend({
                    required: {
                        params: true,
                        message: "Transported To At " + InmateConstants.Required,
                        onlyIf: function () {
                            return uof.ui.inmate.detail.viewModel.incidentInformation.wasTransported();
                        }
                    }
                });
                //Escorted By Clinic
                uof.ui.inmate.detail.viewModel.incidentInformation.EscortedByClinic.extend({
                    required: {
                        params: true,
                        message: "Escorted By Clinic " + InmateConstants.Required,
                        onlyIf: function () {
                            return uof.ui.inmate.detail.viewModel.incidentInformation.wasTransported();
                        }
                    }
                });
                //Escorted By At
                uof.ui.inmate.detail.viewModel.incidentInformation.EscortedByAt.extend({
                    required: {
                        params: true,
                        message: "Escorted By At" + InmateConstants.Required,
                        onlyIf: function () {
                            return uof.ui.inmate.detail.viewModel.incidentInformation.wasTransported();
                        }
                    }
                });
                //Seen By Clinic
                uof.ui.inmate.detail.viewModel.incidentInformation.SeenByClinic.extend({
                    required: {
                        params: true,
                        message: "Seen By Clinic" + InmateConstants.Required,
                        onlyIf: function () {
                            return uof.ui.inmate.detail.viewModel.incidentInformation.wasTransported();
                        }
                    }
                });
                //AdmittedToEmerRoom
                //uof.ui.inmate.detail.viewModel.incidentInformation.AdmittedToEmerRoom.extend({
                //    required: {
                //        params: true,
                //        message: "Admitted to Emergency Room" + InmateConstants.Required,
                //        onlyIf: function () {
                //            return uof.ui.inmate.detail.viewModel.incidentInformation.wasTransported();
                //        }
                //    }
                //});
                //Seen By At
                //uof.ui.inmate.detail.viewModel.incidentInformation.SeenByAt.extend({
                //    required: {
                //        params: true,
                //        message: "A20" + InmateConstants.Required
                //    },
                //    maxLength: {
                //        params: 400,
                //        message: 'Seen By At maximum character should be 100 only.'
                //    },
                //});
                //Incident Narrative
                uof.ui.inmate.detail.viewModel.incidentNarrative.IncidentNarrative_EmployeeNumber.extend({
                    required: {
                        params: true,
                        message: "Employee Number" + InmateConstants.Required,
                        onlyIf: function () {
                            return uof.ui.inmate.detail.viewModel.incidentInformation.ForeOrAllegationY();
                        }
                    },
                    pattern: {
                        params: "^[a-zA-Z0-9 _@#-.~!$%&()={}^]+$",
                        message: InmateConstants.Required + ' \\ / : * ? ` ; " < > | [ ]'
                    },
                    maxLength: {
                        params: 100,
                        message: 'Employee Number maximum character should be 100 only.'
                    },
                });
                //Incident Narrative Name Of Sergeant
                uof.ui.inmate.detail.viewModel.incidentNarrative.IncidentNarrative_NameOfSergeant.extend({
                    required: {
                        params: true,
                        message: "Name Of Sergeant" + InmateConstants.Required,
                        onlyIf: function () {
                            return uof.ui.inmate.detail.viewModel.incidentInformation.ForeOrAllegationY();
                        }
                    }
                });
                //Incident Narrative Date
                uof.ui.inmate.detail.viewModel.incidentNarrative.IncidentNarrative_Date.extend({
                    required: {
                        params: true,
                        message: "Incident Narrative Date" + InmateConstants.Required,
                        onlyIf: function () {
                            return uof.ui.inmate.detail.viewModel.incidentInformation.ForeOrAllegationY();
                        }
                    }
                });
                //Incident Narrative
                uof.ui.inmate.detail.viewModel.incidentNarrative.IncidentNarrative.extend({
                    required: {
                        params: true,
                        message: "Incident Narrative" + InmateConstants.Required,
                        onlyIf: function () {
                            return uof.ui.inmate.detail.viewModel.incidentInformation.ForeOrAllegationY();
                        }
                    }
                });
                //Submitted By Employee Number
                uof.ui.inmate.detail.viewModel.incidentNarrative.SubmittedBy_EmployeeNumber.extend({
                    required: {
                        params: true,
                        message: "SubmittedBy EmployeeNumber" + InmateConstants.Required,
                        onlyIf: function () {
                            return uof.ui.inmate.detail.viewModel.incidentInformation.ForeOrAllegationY();
                        }
                    }
                });
                //Submitted By Name Of Sergeant
                uof.ui.inmate.detail.viewModel.incidentNarrative.SubmittedBy_NameOfSergeant.extend({
                    required: {
                        params: true,
                        message: "SubmittedBy NameOfSergeant" + InmateConstants.Required,
                        onlyIf: function () {
                            return uof.ui.inmate.detail.viewModel.incidentInformation.ForeOrAllegationY();
                        }
                    }
                });
                //Submitted By Date
                uof.ui.inmate.detail.viewModel.incidentNarrative.SubmittedBy_Date.extend({
                    required: {
                        params: true,
                        message: "SubmittedBy Date" + InmateConstants.Required,
                        onlyIf: function () {
                            return uof.ui.inmate.detail.viewModel.incidentInformation.ForeOrAllegationY();
                        }
                    }
                });
                //Approved By Employee Number
                uof.ui.inmate.detail.viewModel.incidentNarrative.ApprovedBy_EmployeeNumber.extend({
                    required: {
                        params: true,
                        message: "ApprovedBy EmployeeNumber" + InmateConstants.Required,
                        onlyIf: function () {
                            return (UoFParams.userRank == "2")
                        }
                    }
                });
                ////Approved By Name Of Sergeant
                //uof.ui.inmate.detail.viewModel.incidentNarrative.ApprovedBy_NameOfSergeant.extend({
                //    required: {
                //        params: true,
                //        message: "A8" + InmateConstants.Required,
                //        onlyIf: function () {
                //            return uof.ui.inmate.detail.viewModel.incidentInformation.ForeOrAllegationY();
                //        }
                //    }
                //});
                //Approved By Date
                uof.ui.inmate.detail.viewModel.incidentNarrative.ApprovedBy_Date.extend({
                    required: {
                        params: true,
                        message: "ApprovedBy Date" + InmateConstants.Required,
                        onlyIf: function () {
                            return (UoFParams.userRank == "2")
                        }
                    }
                });

                //MSIL

                //Treated By
                uof.ui.inmate.detail.viewModel.MSIL.TreatedBy.extend({
                    required: {
                        params: true,
                        message: InmateConstants.Required,
                        onlyIf: function () {
                            return uof.ui.inmate.detail.viewModel.incidentInformation.ForeOrAllegationY();
                        }
                    },
                    pattern: {
                        params: "^[a-zA-Z0-9 _@#-.~!$%&()={}^]+$",
                        message: InmateConstants.Required + ' \\ / : * ? ` ; " < > | [ ]'
                    },
                    maxLength: {
                        params: 100,
                        message: 'Treated By maximum character should be 100 only.'
                    },
                });
                //Employee#
                uof.ui.inmate.detail.viewModel.MSIL.EmployeeNumber.extend({
                    required: {
                        params: true,
                        message: InmateConstants.Required,
                        onlyIf: function () {
                            return (UoFParams.userRole == "MED" || UoFParams.userRank == "9")
                        }
                    }
                });
                //Date Treated
                uof.ui.inmate.detail.viewModel.MSIL.DateTreated.extend({
                    required: {
                        params: true,
                        message: InmateConstants.Required,
                        onlyIf: function () {
                            return (UoFParams.userRole == "MED" || UoFParams.userRank == "9")
                        }
                    }
                });
                //Time Treated
                uof.ui.inmate.detail.viewModel.MSIL.TimeTreated.extend({
                    required: {
                        params: true,
                        message: InmateConstants.Required,
                        onlyIf: function () {
                            return (UoFParams.userRole == "MED" || UoFParams.userRank == "9")
                        }
                    }
                });
                //Incident Narrative
                uof.ui.inmate.detail.viewModel.MSIL.MSIncidentNarrative.extend({
                    required: {
                        params: true,
                        message: InmateConstants.Required,
                        onlyIf: function () {
                            return uof.ui.inmate.detail.viewModel.incidentInformation.ForeOrAllegationY();
                        }
                    }
                });
                //MSH
                uof.ui.inmate.detail.viewModel.MSH.MSHTreatedBy.extend({
                    required: {
                        params: true,
                        message: "5" + InmateConstants.Required,
                        onlyIf: function () {
                            return !uof.ui.inmate.detail.viewModel.MSH.applicable();
                        }
                    }
                });
                uof.ui.inmate.detail.viewModel.MSH.MSHEmployeeNumber.extend({
                    required: {
                        params: true,
                        message: "1" + InmateConstants.Required,
                        onlyIf: function () {
                            return !uof.ui.inmate.detail.viewModel.MSH.applicable();
                        }
                    }
                });
                uof.ui.inmate.detail.viewModel.MSH.MSHEmployeeNumber2.extend({
                    required: {
                        params: true,
                        message: "2" + InmateConstants.Required,
                        onlyIf: function () {
                            return !uof.ui.inmate.detail.viewModel.MSH.applicable();
                        }
                    }
                });
                uof.ui.inmate.detail.viewModel.MSH.MSHTimeTreated.extend({
                    required: {
                        params: true,
                        message: "3" + InmateConstants.Required,
                        onlyIf: function () {
                            return !uof.ui.inmate.detail.viewModel.MSH.applicable();
                        }
                    }
                });
                uof.ui.inmate.detail.viewModel.MSH.MSHDateTreated.extend({
                    required: {
                        params: true,
                        message: "4" + InmateConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.inmate.detail.viewModel.MSH.applicable());
                        }
                    }
                });
                //Transferred To
                uof.ui.inmate.detail.viewModel.MSH.TransferredTo.extend({
                    required: {
                        params: true,
                        message: "6" + InmateConstants.Required,
                        onlyIf: function () {
                            return !uof.ui.inmate.detail.viewModel.MSH.applicable();
                        }
                    }
                });
                //Communicable
                //uof.ui.inmate.detail.viewModel.MSH.Communicable.extend({
                //    required: {
                //        params: true,
                //        message: InmateConstants.Required,
                //        onlyIf: function () {
                //            return !uof.ui.inmate.detail.viewModel.MSH.applicable();
                //        }
                //    }
                //});
                //Book Doctor
                uof.ui.inmate.detail.viewModel.MSH.BookDoctor.extend({
                    required: {
                        params: true,
                        message: "6" + InmateConstants.Required,
                        onlyIf: function () {
                            return !uof.ui.inmate.detail.viewModel.MSH.applicable();
                        }
                    }
                });

                //Inmate Statement

                //InmateStatement
                uof.ui.inmate.detail.viewModel.inmateStatement.InmateStatement.extend({
                    required: {
                        params: true,
                        message: InmateConstants.Required
                    }
                });

                //Wittness Statement

                //Booking Number
                uof.ui.inmate.detail.viewModel.wittnessStatement.WCEmpNumber.extend({
                    required: {
                        params: true,
                        message: "WCEmpNumber " + InmateConstants.Required,
                        onlyIf: function () {
                            return (UoFParams.userRank == "3")
                        }
                    }
                });
                uof.ui.inmate.detail.viewModel.wittnessStatement.WCLog.extend({
                    required: {
                        params: true,
                        message: "WCLog " + InmateConstants.Required,
                        onlyIf: function () {
                            return (UoFParams.userRank == "3")
                        }
                    }
                });
                ////Name
                //uof.ui.inmate.detail.viewModel.wittnessStatement.WTName.extend({
                //    required: {
                //        params: true,
                //        message: InmateConstants.Required
                //    },
                //    maxLength: {
                //        params: 100,
                //        message: 'Name maximum character should be 100 only.'
                //    },
                //});
                ////Housing Location
                //uof.ui.inmate.detail.viewModel.wittnessStatement.WTHousingLocation.extend({
                //    required: {
                //        params: true,
                //        message: InmateConstants.Required
                //    },
                //    maxLength: {
                //        params: 100,
                //        message: 'Housing Location maximum character should be 100 only.'
                //    },
                //});
                ////Witness Statement
                //uof.ui.inmate.detail.viewModel.wittnessStatement.WitnessStatement.extend({
                //    required: {
                //        params: true,
                //        message: InmateConstants.Required
                //    }

                //});

                //chkGeneralPopulation Statement
                uof.ui.inmate.detail.viewModel.inmateInformation.chkGeneralPopulation.extend({
                    checked: {
                        params: true,
                        message: InmateConstants.Required,
                        onlyIf: function () {
                            if (UoFParams.userRank == "1") {
                                if (uof.ui.inmate.detail.viewModel.inmateInformation.chkMentalHealthHousing())
                                    return false;
                                if (uof.ui.inmate.detail.viewModel.inmateInformation.chkMedicalHousing())
                                    return false;
                                if (uof.ui.inmate.detail.viewModel.inmateInformation.chkDiscipline())
                                    return false;
                                if (uof.ui.inmate.detail.viewModel.inmateInformation.chkSegregation())
                                    return false;
                            }

                            return true;

                        }
                    },

                });

                //chkMentalHealthHousing Statement
                uof.ui.inmate.detail.viewModel.inmateInformation.chkMentalHealthHousing.extend({
                    checked: {
                        params: true,
                        message: InmateConstants.Required,
                        onlyIf: function () {
                            if (UoFParams.userRank == "1") {
                                if (uof.ui.inmate.detail.viewModel.inmateInformation.chkGeneralPopulation())
                                    return false;
                                if (uof.ui.inmate.detail.viewModel.inmateInformation.chkMedicalHousing())
                                    return false;
                                if (uof.ui.inmate.detail.viewModel.inmateInformation.chkDiscipline())
                                    return false;
                                if (uof.ui.inmate.detail.viewModel.inmateInformation.chkSegregation())
                                    return false;
                            }
                            return true;
                        }
                    },

                });
                //chkMedicalHousing Statement
                uof.ui.inmate.detail.viewModel.inmateInformation.chkMedicalHousing.extend({
                    checked: {
                        params: true,
                        message: InmateConstants.Required,
                        onlyIf: function () {
                            if (UoFParams.userRank == "1") {
                                if (uof.ui.inmate.detail.viewModel.inmateInformation.chkGeneralPopulation())
                                    return false;
                                if (uof.ui.inmate.detail.viewModel.inmateInformation.chkMentalHealthHousing())
                                    return false;
                                if (uof.ui.inmate.detail.viewModel.inmateInformation.chkDiscipline())
                                    return false;
                                if (uof.ui.inmate.detail.viewModel.inmateInformation.chkSegregation())
                                    return false;
                            }
                            return true;
                        }
                    },

                });
                //chkDiscipline Statement
                uof.ui.inmate.detail.viewModel.inmateInformation.chkDiscipline.extend({
                    checked: {
                        params: true,
                        message: InmateConstants.Required,
                        onlyIf: function () {
                            if (UoFParams.userRank == "1") {
                                if (uof.ui.inmate.detail.viewModel.inmateInformation.chkGeneralPopulation())
                                    return false;
                                if (uof.ui.inmate.detail.viewModel.inmateInformation.chkMentalHealthHousing())
                                    return false;
                                if (uof.ui.inmate.detail.viewModel.inmateInformation.chkMedicalHousing())
                                    return false;
                                if (uof.ui.inmate.detail.viewModel.inmateInformation.chkSegregation())
                                    return false;
                            }
                            return true;
                        }
                    },

                });
                //chkSegregation Statement
                uof.ui.inmate.detail.viewModel.inmateInformation.chkSegregation.extend({
                    checked: {
                        params: true,
                        message: InmateConstants.Required,
                        onlyIf: function () {
                            if (UoFParams.userRank == "1") {
                                if (uof.ui.inmate.detail.viewModel.inmateInformation.chkGeneralPopulation())
                                    return false;
                                if (uof.ui.inmate.detail.viewModel.inmateInformation.chkMentalHealthHousing())
                                    return false;
                                if (uof.ui.inmate.detail.viewModel.inmateInformation.chkMedicalHousing())
                                    return false;
                                if (uof.ui.inmate.detail.viewModel.inmateInformation.chkDiscipline())
                                    return false;
                            }
                            return true;
                        }
                    },

                });

                uof.ui.inmate.detail.viewModel.inmateInformation.Segregation.extend({
                    required: {
                        params: true,
                        message: InmateConstants.Required,
                        onlyIf: function () {
                            return (uof.ui.inmate.detail.viewModel.inmateInformation.chkSegregation() === true);
                        }
                    }
                });


                //ForeOrAllegationY Statement
                //uof.ui.inmate.detail.viewModel.incidentInformation.ForeOrAllegationY.extend({
                //    checked: {
                //        params: true,
                //        message: InmateConstants.Required,
                //        onlyIf: function () {
                //            if (uof.ui.inmate.detail.viewModel.incidentInformation.ForeOrAllegationN())
                //                return false;

                //            return uof.ui.inmate.detail.viewModel.incidentInformation.InjuredY()

                //        }
                //    },

                //});

                //ForeOrAllegationY Statement
                //uof.ui.inmate.detail.viewModel.incidentInformation.ForeOrAllegationN.extend({
                //    checked: {
                //        params: true,
                //        message: InmateConstants.Required,
                //        onlyIf: function () {
                //            if (uof.ui.inmate.detail.viewModel.incidentInformation.ForeOrAllegationY())
                //                return false;
                //            return uof.ui.inmate.detail.viewModel.incidentInformation.InjuredY()
                //        }
                //    },

                //});


            },

            //validate data before save
            validateInmatateDetail: function () {


                if (!uof.ui.inmate.detail.validateInmateInformation()) {
                    uof.ui.inmate.detail.redirecttoValidationScreen("anchorInmateInfo");
                    return false;
                }
                if (!uof.ui.inmate.detail.validateIncidentInformation()) {
                    uof.ui.inmate.detail.redirecttoValidationScreen("anchorIncidentInfo");
                    return false;
                }

                if (!uof.ui.inmate.detail.validateIncidentNarrative()) {
                    uof.ui.inmate.detail.redirecttoValidationScreen("anchorNarrativeInfo");
                    return false;
                }

                if (!uof.ui.inmate.detail.validateInmateStatement()) {
                    uof.ui.inmate.detail.redirecttoValidationScreen("anchorinmateStatementInfo");
                    return false;
                }

                if (!uof.ui.inmate.detail.validateMSIL()) {
                    uof.ui.inmate.detail.redirecttoValidationScreen("anchormsilInfo");
                    return false;
                }

                if (!uof.ui.inmate.detail.validateMSH()) {
                    uof.ui.inmate.detail.redirecttoValidationScreen("anchormshInfo");
                    return false;
                }

                if (!uof.ui.inmate.detail.validateWittnessStatement()) {
                    return false;
                }
                uof.ui.inmate.detail.removeActiveONSuccessValidation();
                return true;
            },

            //remove active css on success validation
            removeActiveONSuccessValidation: function () {
                //$("#liInmateInfo").removeClass("active")
                $("#liIncidentInfo").removeClass("active");
                $("#liInmateStatementInfo").removeClass("active");
                $("#liNarrativeInfo").removeClass("active");
                $("#liMSHInfo").removeClass("active");
                $("#liWittnessInfo").removeClass("active");
                $("#liMSILInfo").removeClass("active");
            },

            redirecttoValidationScreen: function (anchorInfo) {
                $("#" + $.trim(anchorInfo)).trigger("click");
            },

            //validate inmate info
            validateInmateInformation: function (obj) {
                //inmateInformation

                //$("#chkGPopulation").prop("checked", false)
                if (UoFParams.userRank == "1") {
                    result = ko.validation.group(uof.ui.inmate.detail.viewModel.inmateInformation, { deep: true });
                    if (result().length > 0) {
                        //To show the message
                        uof.ui.inmate.detail.viewModel.inmateInformation.URN.valueHasMutated();
                        uof.ui.inmate.detail.viewModel.inmateInformation.ReferenceNumber.valueHasMutated();
                        uof.ui.inmate.detail.viewModel.inmateInformation.BookingNumber.valueHasMutated();
                        uof.ui.inmate.detail.viewModel.inmateInformation.EmployeeName.valueHasMutated();
                        uof.ui.inmate.detail.viewModel.inmateInformation.Race.valueHasMutated();
                        uof.ui.inmate.detail.viewModel.inmateInformation.Sex.valueHasMutated();
                        uof.ui.inmate.detail.viewModel.inmateInformation.DateOfBirth.valueHasMutated();
                        uof.ui.inmate.detail.viewModel.inmateInformation.HousingFacility.valueHasMutated();
                        uof.ui.inmate.detail.viewModel.inmateInformation.Barrack.valueHasMutated();
                        uof.ui.inmate.detail.viewModel.inmateInformation.Cell.valueHasMutated();
                        uof.ui.inmate.detail.viewModel.inmateInformation.chkGeneralPopulation.valueHasMutated();
                        uof.ui.inmate.detail.viewModel.inmateInformation.chkMentalHealthHousing.valueHasMutated();
                        uof.ui.inmate.detail.viewModel.inmateInformation.chkMedicalHousing.valueHasMutated();
                        uof.ui.inmate.detail.viewModel.inmateInformation.chkDiscipline.valueHasMutated();
                        uof.ui.inmate.detail.viewModel.inmateInformation.chkSegregation.valueHasMutated();

                        uof.ui.inmate.detail.viewModel.inmateInformation.Segregation.valueHasMutated();
                        //uof.ui.inmate.detail.isChecked = false;
                        return false;
                    }
                    if (obj != undefined)
                        uof.ui.inmate.detail.redirecttoValidationScreen(obj);
                    else
                        return true;
                }
                else
                    if (obj != undefined)
                        uof.ui.inmate.detail.redirecttoValidationScreen(obj);
                    else
                        return true;
            },



            //validate incident info
            validateIncidentInformation: function (obj) {
                //incidentInformation
                result = ko.validation.group(uof.ui.inmate.detail.viewModel.incidentInformation, { deep: true });
                if (result().length > 0) {
                    //To show the message
                    uof.ui.inmate.detail.viewModel.incidentInformation.IncidentLocation.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.TypeOfLocation.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.IncidentDate.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.IncidentTime.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.SickOrIllY.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.SickOrIllN.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.InjuredY.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.InjuredN.valueHasMutated();
                    // uof.ui.inmate.detail.viewModel.incidentInformation.ForeOrAllegationY.valueHasMutated();
                    //uof.ui.inmate.detail.viewModel.incidentInformation.ForeOrAllegationN.valueHasMutated();
                    //  uof.ui.inmate.detail.viewModel.incidentInformation.FinalDiagnosisBy.valueHasMutated();
                    //  uof.ui.inmate.detail.viewModel.incidentInformation.FinalDiagnosisDateTime.valueHasMutated();
                    // uof.ui.inmate.detail.viewModel.incidentInformation.PersonContacted.valueHasMutated();
                    //  uof.ui.inmate.detail.viewModel.incidentInformation.FinalDiagnosis.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.Accident.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.furtherInvestigation.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.Alone.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.Segregated.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.WithOthers.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.wasEscorted.valueHasMutated();

                    //uof.ui.inmate.detail.viewModel.incidentInformation.InmateAppearsToBe.valueHasMutated();
                    //uof.ui.inmate.detail.viewModel.incidentInformation.InmateWas.valueHasMutated();

                    uof.ui.inmate.detail.viewModel.incidentInformation.EscortedToClinic.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.EscortedToAt.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.wasTransported.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.TransportedToClinic.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.TransportedToAt.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.wasEscortedBy.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.EscortedByClinic.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.EscortedByAt.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.SeenByClinic.valueHasMutated();
                    // uof.ui.inmate.detail.viewModel.incidentInformation.AdmittedToEmerRoom.valueHasMutated();
                    // uof.ui.inmate.detail.viewModel.incidentInformation.SeenByAt.valueHasMutated();
                    //uof.ui.inmate.detail.viewModel.incidentInformation.SeenByAtHours.valueHasMutated();


                    uof.ui.inmate.detail.viewModel.incidentInformation.EscortingPersonnelEID.valueHasMutated();
                    //uof.ui.inmate.detail.viewModel.incidentInformation.EscortingPersonnelName.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.EscortedByClinic.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.DeputyEscortingtoHospitalDate.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.DoctorTreatedDate.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.DoctorTreatedTime.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.chkReturnedtoFacility.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.chkAdmittedtoHospital.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.chkOther.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.OtherInmateDisposition.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.InmateDispoDate.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.incidentInformation.InmateDispoTime.valueHasMutated();

                    return false;
                }
                if (obj != undefined)
                    uof.ui.inmate.detail.redirecttoValidationScreen(obj);
                else
                    return true;
            },

            //validate narrative info
            validateIncidentNarrative: function (obj, isApproval) {
                if (isApproval) {
                    if (UoFParams.userRank == "2") {
                        result = ko.validation.group(uof.ui.inmate.detail.viewModel.incidentNarrative, { deep: true });
                        if (result().length > 0) {
                            uof.ui.inmate.detail.viewModel.incidentNarrative.ApprovedBy_EmployeeNumber.valueHasMutated();
                            uof.ui.inmate.detail.viewModel.incidentNarrative.ApprovedBy_NameOfSergeant.valueHasMutated();
                            uof.ui.inmate.detail.viewModel.incidentNarrative.ApprovedBy_Date.valueHasMutated();
                            uof.ui.inmate.detail.redirecttoValidationScreen("anchorNarrativeInfo");
                        }
                        return true;
                    }
                    if (UoFParams.userRank == "3") {
                        result = ko.validation.group([uof.ui.inmate.detail.viewModel.wittnessStatement.WCEmpNumber, uof.ui.inmate.detail.viewModel.wittnessStatement.WCLog]);
                        if (result().length > 0) {
                            uof.ui.inmate.detail.viewModel.wittnessStatement.WCEmpNumber.valueHasMutated();
                            uof.ui.inmate.detail.viewModel.wittnessStatement.WCLog.valueHasMutated();
                            return false;
                        }
                        return true;
                    }
                }
                else {
                    result = ko.validation.group(uof.ui.inmate.detail.viewModel.incidentNarrative, { deep: true });
                    if (obj != undefined) {
                        if (result().length > 0) {
                            //To show the message
                            //uof.ui.inmate.detail.viewModel.incidentNarrative.IncidentNarrative_EmployeeNumber.valueHasMutated();
                            //uof.ui.inmate.detail.viewModel.incidentNarrative.IncidentNarrative_NameOfSergeant.valueHasMutated();
                            //uof.ui.inmate.detail.viewModel.incidentNarrative.IncidentNarrative_Date.valueHasMutated();
                            uof.ui.inmate.detail.viewModel.incidentNarrative.IncidentNarrative.valueHasMutated();
                            //uof.ui.inmate.detail.viewModel.incidentNarrative.SubmittedBy_EmployeeNumber.valueHasMutated();
                            //uof.ui.inmate.detail.viewModel.incidentNarrative.SubmittedBy_NameOfSergeant.valueHasMutated();
                            //uof.ui.inmate.detail.viewModel.incidentNarrative.SubmittedBy_Date.valueHasMutated();
                            //uof.ui.inmate.detail.viewModel.incidentNarrative.chkInmateInterviewed.valueHasMutated();
                            //uof.ui.inmate.detail.viewModel.incidentNarrative.chkNoAllegationForce.valueHasMutated();
                            //uof.ui.inmate.detail.viewModel.incidentNarrative.SergeantNotesNarrative.valueHasMutated();
                            return false;
                        }
                    }
                    if (obj != undefined)
                        uof.ui.inmate.detail.redirecttoValidationScreen(obj);
                    else
                        return true;
                }
            },



            //validate MSIL info
            validateMSIL: function (obj) {
                //MSIL
                result = ko.validation.group(uof.ui.inmate.detail.viewModel.MSIL, { deep: true });
                if (result().length > 0) {
                    //To show the message
                    uof.ui.inmate.detail.viewModel.MSIL.TreatedBy.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.MSIL.EmployeeNumber.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.MSIL.DateTreated.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.MSIL.TimeTreated.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.MSIL.MSIncidentNarrative.valueHasMutated();
                    return false;
                }
                if (obj != undefined)
                    uof.ui.inmate.detail.redirecttoValidationScreen(obj);
                else
                    return true;
            },

            //validate MSH info
            validateMSH: function (obj) {
                //MSH
                if (UoFParams.userRank == "1") {
                    result = ko.validation.group(uof.ui.inmate.detail.viewModel.MSH, { deep: true });
                    if (result().length > 0) {
                        //To show the message
                        //uof.ui.inmate.detail.viewModel.MSH.MSHTreatedBy.valueHasMutated();
                        uof.ui.inmate.detail.viewModel.MSH.MSHEmployeeNumber.valueHasMutated();
                        //uof.ui.inmate.detail.viewModel.MSH.MSHDateTreated.valueHasMutated();
                        uof.ui.inmate.detail.viewModel.MSH.TransferredTo.valueHasMutated();
                        //uof.ui.inmate.detail.viewModel.MSH.Communicable.valueHasMutated();
                        uof.ui.inmate.detail.viewModel.MSH.BookDoctor.valueHasMutated();
                        uof.ui.inmate.detail.viewModel.MSH.MSHEmployeeNumber2.valueHasMutated();
                        //uof.ui.inmate.detail.viewModel.MSH.MSHTreatedBy2.valueHasMutated();
                        //uof.ui.inmate.detail.viewModel.MSH.MSHDateTreated2.valueHasMutated();
                        uof.ui.inmate.detail.viewModel.MSH.DiagDescriptionInjuryExplanation.valueHasMutated();
                        result.showAllMessages();
                        return false;
                    }
                    if (obj != undefined)
                        uof.ui.inmate.detail.redirecttoValidationScreen(obj);
                    else
                        return true;
                }
                else
                    if (obj != undefined)
                        uof.ui.inmate.detail.redirecttoValidationScreen(obj);
                    else
                        return true;
            },

            //validate inmate statement info
            validateInmateStatement: function (obj) {
                //InmateStatement
                if (UoFParams.userRank == "1") {
                    result = ko.validation.group(uof.ui.inmate.detail.viewModel.inmateStatement, { deep: true });
                    if (result().length > 0) {
                        //To show the message
                        uof.ui.inmate.detail.viewModel.inmateStatement.InmateStatement.valueHasMutated();
                        //uof.ui.inmate.detail.viewModel.inmateStatement.InmateSignature.valueHasMutated();
                        uof.ui.inmate.detail.viewModel.inmateStatement.Refused.valueHasMutated();
                        uof.ui.inmate.detail.viewModel.inmateStatement.Incapacitated.valueHasMutated();
                        return false;
                    }
                    if (obj != undefined)
                        uof.ui.inmate.detail.redirecttoValidationScreen(obj);
                    else
                        return true;
                }
                else
                    if (obj != undefined)
                        uof.ui.inmate.detail.redirecttoValidationScreen(obj);
                    else
                        return true;
            },

            //validate Wittness Statement info
            validateWittnessStatement: function () {
                //Wittness Statement
                result = ko.validation.group(uof.ui.inmate.detail.viewModel.wittnessStatement, { deep: true });
                if (result().length > 0) {
                    //To show the message
                    uof.ui.inmate.detail.viewModel.wittnessStatement.WTBookingNumber.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.wittnessStatement.WTName.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.wittnessStatement.WTHousingLocation.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.wittnessStatement.WitnessStatement.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.wittnessStatement.WitnessSignature.valueHasMutated();
                    uof.ui.inmate.detail.viewModel.wittnessStatement.QANurseEmployeeNumber.valueHasMutated();
                    return false;
                }
                return true;

            },

        }
    }();
}