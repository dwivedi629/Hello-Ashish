﻿var uof = uof || {};
uof.ui = uof.ui || {};
uof.ui.alerts = uof.ui.alerts || {};
if (uof.ui.alerts) {
    uof.ui.incidentalerts = function () {
        return {

            parameters: null,
            isChanged: false,
            init: function (args) {
                this.parameters = args;
            },

            viewModel: {
                TypeOfForces: ko.observableArray([]),
                IAModel: {
                    FormID: ko.observable(),
                    IncidentID: ko.observable(),
                    Attention: ko.observable(),
                    hasError: ko.observable(false),
                    URN: ko.observable(),
                    Reference: ko.observable(),
                    eLOTS: ko.observable(),
                    Date: ko.observable(),
                    Time: ko.observable(),
                    Location: ko.observable(),
                    TypeOfIncident: ko.observable(),
                    TypeofForce: ko.observableArray(),
                    DirectedYN: ko.observable(),
                    DirectedId: ko.observable(),
                    DirectedName: ko.observable(),
                    DirectedMailId: ko.observable(),
                    WCID: ko.observable(),
                    WCName: ko.observable(),
                    WCMailId: ko.observable(),
                    SerID: ko.observable(),
                    SerName: ko.observable(),
                    SerMailId: ko.observable(),
                    Synopsis: ko.observable(),
                    MentalHistoryYN: ko.observable(false),
                    MentalHealthYN: ko.observable(false),
                    IncidentCategoryId: ko.observable(),
                    HandheldYN: ko.observable(false),
                    //HandheldId: ko.observable(),
                   // HandheldName: ko.observable(),
                    //HandheldMailId: ko.observable(),
                    CCTVYN: ko.observable(false),
                    //CCTVId: ko.observable(),
                    CCTVLocation: ko.observable(),
                    //CCTVMailId: ko.observable(),
                    CFRTYN: ko.observable(false),
                    CFRTID: ko.observable(),
                    CFRTName: ko.observable(),
                    CFRTMailId: ko.observable(),
                    CFRTRolloutYN: ko.observable(false),
                    CFRTRolloutID: ko.observable(),
                    CFRTRolloutName: ko.observable(),
                    CFRTRollMailId: ko.observable(),
                    IABYN: ko.observable(false),
                    IABID: ko.observable(),
                    IABName: ko.observable(),
                    IABMailId: ko.observable(),
                    HomicideYN: ko.observable(false),
                    HomicideID: ko.observable(),
                    HomicideName: ko.observable(),
                    HomicidelMailId: ko.observable(),

                    InvolvedSuspect: ko.observableArray(),
                    InvolvedEmployee: ko.observableArray(),

                    LoggedId: ko.observable(),
                    LoggedRole: ko.observable(),
                    CodeYN: ko.observable(false),
                    PrunoYN: ko.observable(false),
                    PillYN: ko.observable(false),
                    RejectComments: ko.observable(),
                },
                getSuspectDetails: function (optionCriteria, bookingNumber) { uof.ui.incidentalerts.getSuspectDetails(optionCriteria, bookingNumber); },
                getEmployeeDetails: function (empId, optionCriteria) { uof.ui.incidentalerts.getEmployeeDetails(empId, optionCriteria); }
            },
            getEmployeeDetails: function (empId, optionCriteria) {
                if ((empId != undefined) && (empId.length > 0)) {
                    // Search based on emp id
                    $.prototype.showProgressBar(optionCriteria);
                    jQuery.ajax({
                        type: "GET",
                        url: EmployeeAPIUrl() + empId,
                        dataType: "json",
                        cache: false,
                        crossDomain: true,
                        processData: true,
                        success: function (empData) {
                            if (optionCriteria == 'Directed') {
                                uof.ui.incidentalerts.viewModel.IAModel.DirectedName(empData.LastName + ' ' + empData.FirstName);
                                uof.ui.incidentalerts.viewModel.IAModel.DirectedMailId(empData.EmailAddress);
                            }
                            if (optionCriteria == 'WC') {
                                uof.ui.incidentalerts.viewModel.IAModel.WCName(empData.LastName + ' ' + empData.FirstName);
                                uof.ui.incidentalerts.viewModel.IAModel.WCMailId(empData.EmailAddress);
                            }
                            if (optionCriteria == 'SER') {
                                uof.ui.incidentalerts.viewModel.IAModel.SerName(empData.LastName + ' ' + empData.FirstName);
                                uof.ui.incidentalerts.viewModel.IAModel.SerMailId(empData.EmailAddress);
                            }
                            if (optionCriteria == 'Handheld') {
                                uof.ui.incidentalerts.viewModel.IAModel.HandheldName(empData.LastName + ' ' + empData.FirstName);
                                uof.ui.incidentalerts.viewModel.IAModel.HandheldMailId(empData.EmailAddress);
                            }
                            if (optionCriteria == 'CCTV') {
                                uof.ui.incidentalerts.viewModel.IAModel.CCTVName(empData.LastName + ' ' + empData.FirstName);
                                uof.ui.incidentalerts.viewModel.IAModel.CCTVMailId(empData.EmailAddress);
                            }
                            if (optionCriteria == 'CFRT') {
                                uof.ui.incidentalerts.viewModel.IAModel.CFRTName(empData.LastName + ' ' + empData.FirstName);
                                uof.ui.incidentalerts.viewModel.IAModel.CFRTMailId(empData.EmailAddress);
                            }
                            if (optionCriteria == 'CFRTRoll') {
                                uof.ui.incidentalerts.viewModel.IAModel.CFRTRolloutName(empData.LastName + ' ' + empData.FirstName);
                                uof.ui.incidentalerts.viewModel.IAModel.CFRTRollMailId(empData.EmailAddress);
                            }
                            if (optionCriteria == 'IAB') {
                                uof.ui.incidentalerts.viewModel.IAModel.IABName(empData.LastName + ' ' + empData.FirstName);
                                uof.ui.incidentalerts.viewModel.IAModel.IABMailId(empData.EmailAddress);
                            }
                            if (optionCriteria == 'Homicide') {
                                uof.ui.incidentalerts.viewModel.IAModel.HomicideName(empData.LastName + ' ' + empData.FirstName);
                                uof.ui.incidentalerts.viewModel.IAModel.HomicidelMailId(empData.EmailAddress);
                            }
                            if (optionCriteria == 'tblLASDPers') {
                                var dataSID = _.find(uof.ui.incidentalerts.viewModel.IAModel.InvolvedEmployee(), function (item) {
                                    if (item.EmpNum() == empId)
                                        return item;
                                });
                                _.each(uof.ui.incidentalerts.viewModel.IAModel.InvolvedEmployee(), function (data) {
                                    if (data.EmpNum() == dataSID.EmpNum()) {
                                        data.Name(empData.LastName + ' ' + empData.FirstName);
                                        data.MailId(empData.EmailAddress);
                                    }
                                });
                            }

                            $.prototype.hideProgressBar(optionCriteria);
                        },
                        error: function (XMLHttpRequest, textStatus, errorThrown) {
                            $.prototype.hideProgressBar(targetDiv);
                            showAlert("Error while getting the Employee Data");
                        }
                    });
                }
            },
            getSuspectDetails: function (bookingNumber, targetDiv) {
                if ((bookingNumber != undefined) && (bookingNumber.length > 0)) {
                    var eventDate = uof.ui.CommonUILogic.detail.formatIncidentDateTime(UoFParams.IncidentDate);
                    jQuery.ajax({
                        type: "GET",
                        url: InmateAPIUrl() + bookingNumber + "&eventDate=" + eventDate + "",
                        dataType: "json",
                        cache: false,
                        crossDomain: true,
                        processData: true,
                        success: function (InmateData) {
                            if (targetDiv == 'tblSusPers') {
                                var dataSID = _.find(uof.ui.incidentalerts.viewModel.IAModel.InvolvedSuspect(), function (item) {
                                    if (item.BookNum() == bookingNumber)
                                        return item;
                                });
                                _.each(uof.ui.incidentalerts.viewModel.IAModel.InvolvedSuspect(), function (data) {
                                    if (data.BookNum() == dataSID.BookNum()) {
                                        data.Name(InmateData.LastName + ' ' + InmateData.FirstName);
                                        data.MailId(InmateData.EmailAddress);
                                    }
                                });
                            }
                        },
                        error: function (XMLHttpRequest, textStatus, errorThrown) {
                            showAlert("Error while getting the Suspect Data");
                        }
                    });
                }
            },
            //load method, will be tirggered on document load
            load: function () {
                ko.validation.init({ insertMessages: true });
                uof.ui.incidentalerts.bindMaskControl();
                uof.ui.incidentalerts.validateFields();
                uof.ui.incidentalerts.subscribeMethod();
                ko.cleanNode($("#IndAlert").get(0));
                ko.applyBindings(uof.ui.incidentalerts.viewModel, $("#IndAlert").get(0));
                uof.ui.incidentalerts.initiatePickers();
                uof.ui.incidentalerts.getForcesInfo();
                $('#IncidentTime').on('keydown', function (e) {
                    if (e.keyCode == 9) {
                        $(this).timepicker('hideWidget');
                    }
                });
            },

            bindMaskControl: function () {
                ko.bindingHandlers.inputmask =
                {
                    init: function (element, valueAccessor, allBindingsAccessor) {

                        var mask = valueAccessor();

                        var observable = mask.value;

                        if (ko.isObservable(observable)) {

                            $(element).on('focusout change', function () {

                                if ($(element).inputmask('isComplete')) {
                                    observable($(element).val());
                                } else {
                                    observable(null);
                                }

                            });
                        }

                        $(element).inputmask(mask);


                    },
                    update: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
                        var mask = valueAccessor();

                        var observable = mask.value;

                        if (ko.isObservable(observable)) {

                            var valuetoWrite = observable();

                            $(element).val(valuetoWrite);
                        }
                    }

                };

                ko.validation.insertValidationMessage = function (element) {
                    var br = document.createElement("br");
                    element.appendChild(br);
                    var span = document.createElement('SPAN');
                    span.className = "warning-msg";
                    var inputGroups = $(element).closest(".date"); //This is for getting Date Fields
                    if (inputGroups.length > 0) {
                        // We're in an input-group so we place the message after
                        // the group rather than inside it in order to not break the design
                        $(span).insertAfter(inputGroups);
                    }
                    else {
                        // The default in knockout-validation
                        element.parentNode.insertBefore(span, element.nextSibling);
                    }
                    return span;
                };
            },
            initiatePickers: function () {
                if (uof.ui.incidentalerts.viewModel.IAModel.InvolvedSuspect().length == 0) {
                    uof.ui.incidentalerts.viewModel.IAModel.InvolvedSuspect.push(new uof.ui.incidentalerts.InvSuspect());
                }
                if (uof.ui.incidentalerts.viewModel.IAModel.InvolvedEmployee().length == 0) {
                    uof.ui.incidentalerts.viewModel.IAModel.InvolvedEmployee.push(new uof.ui.incidentalerts.InvEmployee());
                }
                $('#IndDate').datetimepicker().on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.incidentalerts.viewModel.IAModel.Date(newDate);
                });

            },
            RemoveInvolvedSuspect: function (Personnel) {
                uof.ui.incidentalerts.viewModel.IAModel.InvolvedSuspect.remove(Personnel);
            },
            AddInvolvedSuspect: function () {
                uof.ui.incidentalerts.viewModel.IAModel.InvolvedSuspect.push(new uof.ui.incidentalerts.InvSuspect());
            },

            RemoveInvolvedEmployee: function (Personnel) {
                uof.ui.incidentalerts.viewModel.IAModel.InvolvedEmployee.remove(Personnel);
            },
            AddInvolvedEmployee: function () {
                uof.ui.incidentalerts.viewModel.IAModel.InvolvedEmployee.push(new uof.ui.incidentalerts.InvEmployee());
            },
            InvSuspect: function () {
                var self = this;
                self.BookNum = ko.observable().extend({
                    required: {
                        params: true,
                        message: "Required"
                    },
                });
                self.Name = ko.observable().extend({
                    required: {
                        params: true,
                        message: "Required"
                    },
                });
                self.MailId = ko.observable();
                self.Injuries = ko.observable();
            },
            InvEmployee: function () {
                var self = this;
                self.EmpNum = ko.observable().extend({
                    required: {
                        params: true,
                        message: "Required"
                    },
                });
                self.Name = ko.observable().extend({
                    required: {
                        params: true,
                        message: "Required"
                    },
                });
                self.MailId = ko.observable();
                self.Injuries = ko.observable();
            },
            saveAlerts: function () {
                if (uof.ui.incidentalerts.IsValid()) {
                    var mappedData = ko.mapping.toJS(uof.ui.incidentalerts.viewModel.IAModel);
                    mappedData.LoggedId = UoFParams.userId;
                    mappedData.LoggedRole = UoFParams.userRole;
                    mappedData.FormID = 99;
                    mappedData.IncidentID = 99;
                    $.ajax(
                     {
                         url: window.location.uofAPIOrigin() + '/api/UOFForm/SaveIncidentAlert',
                         cache: false,
                         type: "POST",
                         dataType: 'json',
                         data: JSON.stringify(mappedData),
                         contentType: "application/json;charset=utf-8",
                         beforeSend: function myfunction() {

                         },
                         success: function (data) {
                             $.prototype.hideUofOverlay();
                             showAlert(data);
                         },
                         error: function (e) {
                             $.prototype.hideUofOverlay();
                             showAlert(e.responseText);
                         },
                     });
                }
            },
            approveAlertDetails: function () { },
            getForcesInfo: function () {
                $.prototype.showUofOverlay();
                $.ajax(
                    {
                        url: window.location.uofAPIOrigin() + '/api/Lookup/GetAllMethods',
                        cache: false,
                        type: "GET",
                        dataType: 'json',
                        contentType: "application/json;charset=utf-8",
                        beforeSend: function myfunction() {

                        },
                        success: function (methodData) {
                            if (methodData != null) {
                                uof.ui.incidentalerts.viewModel.TypeOfForces([]);
                                uof.ui.incidentalerts.viewModel.TypeOfForces(methodData);
                                $('#IncTypeOfForce').selectpicker('refresh');
                            }
                            $.prototype.hideUofOverlay();
                        },
                        error: function (e) {
                            $.prototype.hideUofOverlay();
                            showAlert(e.responseText);
                        },
                    });
            },
            validateFields: function () {
                uof.ui.incidentalerts.viewModel.IAModel.URN.extend({
                    required: {
                        params: true,
                        message: "URN Required"
                    },
                });
                uof.ui.incidentalerts.viewModel.IAModel.Reference.extend({
                    required: {
                        params: true,
                        message: "Reference Required"
                    },
                });
                uof.ui.incidentalerts.viewModel.IAModel.eLOTS.extend({
                    required: {
                        params: true,
                        message: "eLOTS Required"
                    },
                });
                uof.ui.incidentalerts.viewModel.IAModel.Date.extend({
                    required: {
                        params: true,
                        message: "Date Required"
                    },
                });
                uof.ui.incidentalerts.viewModel.IAModel.Location.extend({
                    required: {
                        params: true,
                        message: "Location Required"
                    },
                });
                uof.ui.incidentalerts.viewModel.IAModel.TypeOfIncident.extend({
                    required: {
                        params: true,
                        message: "TypeOfIncident Required"
                    },
                });
                uof.ui.incidentalerts.viewModel.IAModel.TypeofForce.extend({
                    required: {
                        params: true,
                        message: "TypeofForce Required"
                    },
                });
                uof.ui.incidentalerts.viewModel.IAModel.DirectedId.extend({
                    required: {
                        params: true,
                        message: "DirectedId Required",
                        onlyIf: function () {
                            return (uof.ui.incidentalerts.viewModel.IAModel.DirectedYN() == "Y");
                        }
                    },
                });
                uof.ui.incidentalerts.viewModel.IAModel.WCID.extend({
                    required: {
                        params: true,
                        message: "WCID Required"
                    },
                });
                uof.ui.incidentalerts.viewModel.IAModel.SerID.extend({
                    required: {
                        params: true,
                        message: "SerID Required"
                    },
                });
                //uof.ui.incidentalerts.viewModel.IAModel.HandheldId.extend({
                //    required: {
                //        params: true,
                //        message: "HandheldId Required",
                //        onlyIf: function () {
                //            return (uof.ui.incidentalerts.viewModel.IAModel.HandheldYN() == "Y");
                //        }
                //    },
                //});
                uof.ui.incidentalerts.viewModel.IAModel.CCTVLocation.extend({
                    required: {
                        params: true,
                        message: "CCTVLocation Required",
                        onlyIf: function () {
                            return (uof.ui.incidentalerts.viewModel.IAModel.CCTVYN() == "Y");
                        }
                    },
                });
                uof.ui.incidentalerts.viewModel.IAModel.CFRTID.extend({
                    required: {
                        params: true,
                        message: "CFRTID Required",
                        onlyIf: function () {
                            return (uof.ui.incidentalerts.viewModel.IAModel.CFRTYN() == "Y");
                        }
                    },
                });
                uof.ui.incidentalerts.viewModel.IAModel.CFRTRolloutID.extend({
                    required: {
                        params: true,
                        message: "CFRTRolloutID Required",
                        onlyIf: function () {
                            return (uof.ui.incidentalerts.viewModel.IAModel.CFRTRolloutYN() == "Y");
                        }
                    },
                });
                uof.ui.incidentalerts.viewModel.IAModel.IABID.extend({
                    required: {
                        params: true,
                        message: "IABID Required",
                        onlyIf: function () {
                            return (uof.ui.incidentalerts.viewModel.IAModel.IABYN() == "Y");
                        }
                    },
                });
                uof.ui.incidentalerts.viewModel.IAModel.HomicideID.extend({
                    required: {
                        params: true,
                        message: "HomicideID Required",
                        onlyIf: function () {
                            return (uof.ui.incidentalerts.viewModel.IAModel.HomicideYN() == "Y");
                        }
                    },
                });

            },
            subscribeMethod: function () {
                uof.ui.incidentalerts.viewModel.IAModel.HomicideYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "Y") {
                        uof.ui.incidentalerts.viewModel.IAModel.HomicideID.valueHasMutated();
                        return false;
                    }
                });
                uof.ui.incidentalerts.viewModel.IAModel.IABYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "Y") {
                        uof.ui.incidentalerts.viewModel.IAModel.IABID.valueHasMutated();
                        return false;
                    }
                });
                uof.ui.incidentalerts.viewModel.IAModel.CFRTRolloutYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "Y") {
                        uof.ui.incidentalerts.viewModel.IAModel.CFRTRolloutID.valueHasMutated();
                        return false;
                    }
                });
                uof.ui.incidentalerts.viewModel.IAModel.HomicideYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "Y") {
                        uof.ui.incidentalerts.viewModel.IAModel.HomicideID.valueHasMutated();
                        return false;
                    }
                });
                uof.ui.incidentalerts.viewModel.IAModel.CFRTYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "Y") {
                        uof.ui.incidentalerts.viewModel.IAModel.CFRTID.valueHasMutated();
                        return false;
                    }
                });
                uof.ui.incidentalerts.viewModel.IAModel.CCTVYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "Y") {
                        uof.ui.incidentalerts.viewModel.IAModel.CCTVLocation.valueHasMutated();
                        return false;
                    }
                });
                //uof.ui.incidentalerts.viewModel.IAModel.HandheldYN.subscribe(function (newValue) {
                //    if ($.trim(newValue) == "Y") {
                //        uof.ui.incidentalerts.viewModel.IAModel.HandheldId.valueHasMutated();
                //        return false;
                //    }
                //});
                uof.ui.incidentalerts.viewModel.IAModel.DirectedYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "Y") {
                        uof.ui.incidentalerts.viewModel.IAModel.DirectedId.valueHasMutated();
                        return false;
                    }
                });
            },
            IsValid: function () {
                result = ko.validation.group(uof.ui.incidentalerts.viewModel.IAModel, { deep: true });
                if (result().length > 0) {
                    result.showAllMessages();
                    return false;
                }
                return true;
            },
            bindIncidentAlertDetails: function () {
                $.prototype.showUofOverlay();

                $.ajax(
                       {
                           url: window.location.uofAPIOrigin() + '/api/UOFForm/GetIncidentAlerDetails',
                           cache: false,
                           data: { FormId: uof.ui.incidentalerts.viewModel.IAModel.FormID(), IncidentId: uof.ui.incidentalerts.viewModel.IAModel.IncidentID(), EmpId: uof.ui.incidentalerts.viewModel.IAModel.LoggedId() },
                           type: "GET",
                           dataType: 'json',
                           contentType: "application/json;charset=utf-8",
                           beforeSend: function myfunction() {

                           },
                           success: function (data) {
                               if (data != null) {
                                   uof.ui.incidentalerts.viewModel.IAModel = ko.mapping.fromJS(data, ko.mapping.toJS(uof.ui.incidentalerts.viewModel.IAModel));
                                   uof.ui.ReviewNotice.report.validateControls();

                                   ko.cleanNode($("#IndAlert").get(0));
                                   ko.applyBindings(uof.ui.incidentalerts.viewModel, $("#IndAlert").get(0));
                                   if (uofuof.ui.incidentalerts.viewModel.IAModel.RejectComments() != "") {
                                       $(".fakeclass").removeClass('hide');
                                       $("#txtReject").attr('disabled', false);
                                   }
                                   $('#IncidentDate').datetimepicker({ format: 'MM/DD/YYYY' });
                               }
                               $.prototype.hideUofOverlay();
                           },
                           error: function (e) {
                               $.prototype.hideUofOverlay();
                               showAlert(e.responseText);

                           },
                       });

            },
        }
    }();
}