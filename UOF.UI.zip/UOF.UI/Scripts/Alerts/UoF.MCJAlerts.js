﻿var uof = uof || {};
uof.ui = uof.ui || {};
uof.ui.alerts = uof.ui.alerts || {};
if (uof.ui.alerts) {
    uof.ui.MCJAlerts = function () {
        return {

            parameters: null,
            isChanged: false,
            init: function (args) {
                this.parameters = args;
            },

            viewModel: {
                TypeOfForces: ko.observableArray([]),
                MCJModel: {
                    FormID: ko.observable(),
                    IncidentID: ko.observable(),
                    Attention: ko.observable(),
                    URN: ko.observable(),
                    Reference: ko.observable(),
                    eLOTS: ko.observable(),
                    Date: ko.observable(),
                    Time: ko.observable(),
                    Location: ko.observable(),

                    Subject: ko.observable(),
                    BookingNo: ko.observable(),
                    SuspectName: ko.observable(),
                    SuspectMailId: ko.observable(),
                    SuspectSPHDL: ko.observable(),
                    By: ko.observable(),
                    ByName: ko.observable(),
                    ByMailId: ko.observable(),
                    DeputyID: ko.observable(),
                    DeputyName: ko.observable(),
                    DeputyMailId: ko.observable(),
                    Synopsis: ko.observable(),
                    SupervisorID: ko.observable(),
                    SupervisorName: ko.observable(),
                    SupervisorMailId: ko.observable(),

                    Weapons: ko.observable(),
                    Summary: ko.observable(),
                    CodeYN: ko.observable(false),
                    PrunoYN: ko.observable(false),
                    PillYN: ko.observable(false),

                    LoggedId: ko.observable(),
                    LoggedRole: ko.observable(),
                    RejectComments: ko.observable(),
                },
                getSuspectDetails: function (optionCriteria, bookingNumber) { uof.ui.MCJAlerts.getSuspectDetails(optionCriteria, bookingNumber); },
                getEmployeeDetails: function (empId, optionCriteria) { uof.ui.MCJAlerts.getEmployeeDetails(empId, optionCriteria); }
            },
            getEmployeeDetails: function (empId, optionCriteria) {
                if ((empId != undefined) && (empId.length > 0)) {
                    // Search based on emp id
                    $.prototype.showProgressBar(optionCriteria);
                    jQuery.ajax({
                        type: "GET",
                        url: EmployeeAPIUrl() + empId,
                        dataType: "json",
                        cache: false,
                        crossDomain: true,
                        processData: true,
                        success: function (empData) {
                            if (optionCriteria == 'By') {
                                uof.ui.MCJAlerts.viewModel.MCJModel.ByName(empData.LastName + ' ' + empData.FirstName);
                                uof.ui.MCJAlerts.viewModel.MCJModel.ByMailId(empData.EmailAddress);
                            }
                            if (optionCriteria == 'Deputy') {
                                uof.ui.MCJAlerts.viewModel.MCJModel.DeputyName(empData.LastName + ' ' + empData.FirstName);
                                uof.ui.MCJAlerts.viewModel.MCJModel.DeputyMailId(empData.EmailAddress);
                            }
                            if (optionCriteria == 'Supervisor') {
                                uof.ui.MCJAlerts.viewModel.MCJModel.SupervisorName(empData.LastName + ' ' + empData.FirstName);
                                uof.ui.MCJAlerts.viewModel.MCJModel.SupervisorMailId(empData.EmailAddress);
                            }
                            $.prototype.hideProgressBar(optionCriteria);
                        },
                        error: function (XMLHttpRequest, textStatus, errorThrown) {
                            $.prototype.hideProgressBar(targetDiv);
                            showAlert("Error while getting the Employee Data");
                        }
                    });
                }
            },
            getSuspectDetails: function (bookingNumber, targetDiv) {
                if ((bookingNumber != undefined) && (bookingNumber.length > 0)) {
                    jQuery.ajax({
                        type: "GET",
                        url: InmateAPIUrl() + bookingNumber,
                        dataType: "json",
                        cache: false,
                        crossDomain: true,
                        processData: true,
                        success: function (InmateData) {
                            if (targetDiv == 'Booking') {
                                uof.ui.MCJAlerts.viewModel.MCJModel.SuspectName(InmateData.LastName + ' ' + InmateData.FirstName);
                                //uof.ui.MCJAlerts.viewModel.MCJModel.SuspectMailId(empData.EmailAddress);
                            }
                        },
                        error: function (XMLHttpRequest, textStatus, errorThrown) {
                            showAlert("Error while getting the Suspect Data");
                        }
                    });
                }
            },
            //load method, will be tirggered on document load
            load: function () {
                ko.validation.init({ insertMessages: true });
                uof.ui.MCJAlerts.bindMaskControl();
                uof.ui.MCJAlerts.validateFields();
                ko.cleanNode($("#MCJAlert").get(0));
                ko.applyBindings(uof.ui.MCJAlerts.viewModel, $("#MCJAlert").get(0));
                uof.ui.MCJAlerts.initiatePickers();
                $('#IncidentTime').on('keydown', function (e) {
                    if (e.keyCode == 9) {
                        $(this).timepicker('hideWidget');
                    }
                });
            },

            bindMaskControl: function () {
                ko.bindingHandlers.inputmask =
                {
                    init: function (element, valueAccessor, allBindingsAccessor) {

                        var mask = valueAccessor();

                        var observable = mask.value;

                        if (ko.isObservable(observable)) {

                            $(element).on('focusout change', function () {

                                if ($(element).inputmask('isComplete')) {
                                    observable($(element).val());
                                } else {
                                    observable(null);
                                }

                            });
                        }

                        $(element).inputmask(mask);


                    },
                    update: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
                        var mask = valueAccessor();

                        var observable = mask.value;

                        if (ko.isObservable(observable)) {

                            var valuetoWrite = observable();

                            $(element).val(valuetoWrite);
                        }
                    }

                };
                ko.validation.insertValidationMessage = function (element) {
                    var br = document.createElement("br");
                    element.appendChild(br);
                    var span = document.createElement('SPAN');
                    span.className = "warning-msg";
                    var inputGroups = $(element).closest(".date"); //This is for getting Date Fields
                    if (inputGroups.length > 0) {
                        // We're in an input-group so we place the message after
                        // the group rather than inside it in order to not break the design
                        $(span).insertAfter(inputGroups);
                    }
                    else {
                        // The default in knockout-validation
                        element.parentNode.insertBefore(span, element.nextSibling);
                    }
                    return span;
                };
            },
            initiatePickers: function () {
                $('#IndDate').datetimepicker().on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.MCJAlerts.viewModel.MCJModel.Date(newDate);
                });

            },
            saveAlerts: function () {
                if (uof.ui.MCJAlerts.IsValid()) {
                    var mappedData = ko.mapping.toJS(uof.ui.MCJAlerts.viewModel.MCJModel);
                    mappedData.LoggedId = UoFParams.userId;
                    mappedData.LoggedRole = UoFParams.userRole;
                    mappedData.FormID =  98;
                    mappedData.IncidentID =  99;
                    $.prototype.showUofOverlay();
                    $.ajax(
                      {
                          url: window.location.uofAPIOrigin() + '/api/UOFForm/SaveMCJAlert',
                          cache: false,
                          type: "POST",
                          dataType: 'json',
                          data: JSON.stringify(mappedData),
                          contentType: "application/json;charset=utf-8",
                          beforeSend: function myfunction() {

                          },
                          success: function (data) {
                              $.prototype.hideUofOverlay();
                              showAlert(data);
                          },
                          error: function (e) {
                              $.prototype.hideUofOverlay();
                              showAlert(e.responseText);
                          },
                      });
                }
            },
            bindMCJAlertDetails: function () {
                $.prototype.showUofOverlay();

                $.ajax(
                       {
                           url: window.location.uofAPIOrigin() + '/api/UOFForm/GetMCJAlertDetails',
                           cache: false,
                           data: { FormId: uof.ui.MCJAlerts.viewModel.MCJModel.FormID(), IncidentId: uof.ui.MCJAlerts.viewModel.MCJModel.IncidentID(), EmpId: uof.ui.MCJAlerts.viewModel.MCJModel.LoggedId() },
                           type: "GET",
                           dataType: 'json',
                           contentType: "application/json;charset=utf-8",
                           beforeSend: function myfunction() {

                           },
                           success: function (data) {
                               if (data != null) {
                                   uof.ui.MCJAlerts.viewModel.MCJModel = ko.mapping.fromJS(data, ko.mapping.toJS(uof.ui.MCJAlerts.viewModel.MCJModel));
                                   //uof.ui.MCJAlerts.viewModel.validateControls();

                                   ko.cleanNode($("#MCJAlert").get(0));
                                   ko.applyBindings(uof.ui.MCJAlerts.viewModel, $("#MCJAlert").get(0));
                                   if (uofuof.ui.MCJAlerts.viewModel.MCJModel.RejectComments() != "") {
                                       $(".fakeclass").removeClass('hide');
                                       $("#txtReject").attr('disabled', false);
                                   }
                                   $('#IncidentDate').datetimepicker({ format: 'MM/DD/YYYY' });
                               }
                               $.prototype.hideUofOverlay();
                           },
                           error: function (e) {
                               $.prototype.hideUofOverlay();
                               showAlert(e.responseText);
                           },
                       });

            },
            approveAlertDetails: function () { },
            validateFields: function () {
                uof.ui.MCJAlerts.viewModel.MCJModel.URN.extend({
                    required: {
                        params: true,
                        message: "URN Required"
                    },
                });
                uof.ui.MCJAlerts.viewModel.MCJModel.Reference.extend({
                    required: {
                        params: true,
                        message: "Reference Required"
                    },
                });
                uof.ui.MCJAlerts.viewModel.MCJModel.eLOTS.extend({
                    required: {
                        params: true,
                        message: "eLOTS Required"
                    },
                });
                uof.ui.MCJAlerts.viewModel.MCJModel.Date.extend({
                    required: {
                        params: true,
                        message: "Date Required"
                    },
                });
                uof.ui.MCJAlerts.viewModel.MCJModel.Location.extend({
                    required: {
                        params: true,
                        message: "Location Required"
                    },
                });

            },
            IsValid: function () {
                result = ko.validation.group(uof.ui.MCJAlerts.viewModel.MCJModel, { deep: true });
                if (result().length > 0) {
                    result.showAllMessages();
                    return false;
                }
                return true;
            },

        }
    }();
}