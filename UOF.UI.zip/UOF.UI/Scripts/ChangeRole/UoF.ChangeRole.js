﻿var uof = uof || {};
uof.ui = uof.ui || {};
uof.ui.ChangeRole = uof.ui.ChangeRole || {};

if (uof.ui.ChangeRole) {
    uof.ui.ChangeRole = function () {
        return {
            viewModel: {
                roleType: ko.observable([
                                 { RoleName: 'Sergeant', RoleCode: 'SGT' },
                                 { RoleName: 'Deputy', RoleCode: 'DSG' },
                                 { RoleName: 'Watch Commander', RoleCode: 'WC' },
                                 { RoleName: 'Unit Commander', RoleCode: 'CAPT' },
                                 { RoleName: 'Commander', RoleCode: 'CMDR' },
                                 { RoleName: 'Divisinal Chief', RoleCode: 'DC' }

                ]),
                CR: {
                    RoleId: ko.observable(),
                    IncidentId: ko.observable(),
                    FormID: ko.observable(),
                    URN: ko.observable(),
                    EmployeeId: ko.observable(),
                    Name: ko.observable(),
                    ForceRank: ko.observable(),
                    UoFRank: ko.observable(),
                    ValidStill: ko.observable(),
                    Active: ko.observable(),
                    CreatedOn: ko.observable(),
                    CreatedBy: ko.observable(),
                    loggedId: ko.observable(),
                }
            },
            bindMaskControl: function () {
                ko.bindingHandlers.inputmask =
                {
                    init: function (element, valueAccessor, allBindingsAccessor) {

                        var mask = valueAccessor();

                        var observable = mask.value;

                        if (ko.isObservable(observable)) {

                            $(element).on('focusout change', function () {

                                if ($(element).inputmask('isComplete')) {
                                    observable($(element).val());
                                } else {
                                    observable(null);
                                }

                            });
                        }

                        $(element).inputmask(mask);


                    },
                    update: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
                        var mask = valueAccessor();

                        var observable = mask.value;

                        if (ko.isObservable(observable)) {

                            var valuetoWrite = observable();

                            $(element).val(valuetoWrite);
                        }
                    }

                };
            },
            initiatePickers: function () {

                $('#Date').datetimepicker({ format: 'MM/DD/YYYY', defaultDate: 'now' }).on('dp.change', function (ev) {
                    var newDate = null;
                    if (ev.date != null)
                        newDate = moment(ev.date).format("MM/DD/YYYY");
                    uof.ui.ChangeRole.viewModel.CR.ValidStill(newDate);
                });

            },
            initiateBindings: function () {
                ko.validation.insertValidationMessage = function (element) {
                    var br = document.createElement("br");
                    element.appendChild(br);
                    var span = document.createElement('SPAN');
                    span.className = "warning-msg";
                    var inputGroups = $(element).closest(".date"); //This is for getting Date Fields
                    if (inputGroups.length > 0) {
                        // We're in an input-group so we place the message after
                        // the group rather than inside it in order to not break the design
                        $(span).insertAfter(inputGroups);
                    }
                    else {
                        // The default in knockout-validation
                        element.parentNode.insertBefore(span, element.nextSibling);
                    }
                    return span;
                };
                $("#Staging").attr('disabled', true);
            },


            load: function () {

                uof.ui.ChangeRole.bindMaskControl();
                uof.ui.ChangeRole.initiateBindings();
                uof.ui.ChangeRole.validateControls();
                ko.cleanNode($("#dvChangeRole").get(0));
                ko.applyBindings(uof.ui.ChangeRole.viewModel, $("#dvChangeRole").get(0));
                uof.ui.ChangeRole.initiatePickers();

            },
            lengthValidation: function (str, minChar) {
                var maxChar;
                if (uof.ui.ChangeRole.getCharCount(str) < minChar[0])
                    return false;
                return true;
            },
            getCharCount: function (str) {
                var result = 0;
                if (str !== undefined) {
                    for (var n = 0; n < str.length; n++) {
                        var charCode = str.charCodeAt();
                        if (typeof charCode === "number") {
                            if (charCode < 128)
                            { result = result + 1; }
                            else if (charCode < 2048)
                            { result = result + 2; }
                            else if (charCode < 65536)
                            { result = result + 3; }
                            else if (charCode < 2097152)
                            { result = result + 4; }
                            else if (charCode < 67108864)
                            { result = result + 5; }
                            else
                            { result = result + 6; }
                        }
                    }
                }
                return result;
            },
            validateControls: function () {

                uof.ui.ChangeRole.viewModel.CR.EmployeeId.extend({
                    required: {
                        params: true,
                        message: 'Required',
                        validation: {
                            validator: uof.ui.ChangeRole.lengthValidation,
                            message: "Employee Number should be 6 character length",
                            params: [6]
                        },
                    },
                });
                uof.ui.ChangeRole.viewModel.CR.UoFRank.extend({
                    required: {
                        params: true,
                        message: 'Required'
                    },
                });
                uof.ui.ChangeRole.viewModel.CR.URN.extend({
                    required: {
                        params: true,
                        message: 'Required'
                    },
                });
                uof.ui.ChangeRole.viewModel.CR.ValidStill.extend({
                    required: {
                        params: true,
                        message: 'Required'
                    },
                });
            },


            validateCRFields: function () {
                result = ko.validation.group(uof.ui.ChangeRole.viewModel, { deep: true });
                if (result().length > 0) {
                    uof.ui.ChangeRole.viewModel.CR.URN.valueHasMutated();
                    uof.ui.ChangeRole.viewModel.CR.EmployeeId.valueHasMutated();
                    uof.ui.ChangeRole.viewModel.CR.UoFRank.valueHasMutated();
                    uof.ui.ChangeRole.viewModel.CR.ValidStill.valueHasMutated();
                    return false;
                };
                return true;
            },
            saveChangeRole: function () {
                if (uof.ui.ChangeRole.validateCRFields()) {
                    uof.ui.ChangeRole.viewModel.CR.loggedId(UoFParams.userId);
                    var mappedData = ko.mapping.toJS(uof.ui.ChangeRole.viewModel.CR);
                    $.ajax(
                          {
                              url: window.location.uofAPIOrigin() + '/api/UOFForm/SaveChangeRole',
                              cache: false,
                              type: "POST",
                              dataType: 'json',
                              data: JSON.stringify(mappedData),
                              contentType: "application/json;charset=utf-8",
                              beforeSend: function myfunction() {

                              },
                              success: function (data) {
                                  showAlert(data);
                                  $.prototype.hideUofOverlay();
                                  uof.ui.ChangeRole.resetData();
                              },
                              error: function (e) {
                                  $.prototype.hideUofOverlay();
                                  showAlert(e.responseText);
                              },
                          });
                }

            },
            cancelCRDetails: function () {
                uof.ui.ChangeRole.resetData();
            },
            bindChangeRole: function () {
                if (localStorage.getItem('formMode') == "View") {
                    if ($.IncidentId.length > 0 && $.UoFformId.length > 0 && $.SubmitedId.length > 0) {
                        uof.ui.ChangeRole.viewModel.CR.IncidentID($.IncidentId);
                        uof.ui.ChangeRole.viewModel.CR.FormID($.UoFformId);
                        //   uof.ui.ChangeRole.viewModel.CR.EmployeeId($.EmployeeId);
                        //uof.ui.CustodyService.detail.viewModel.SupplementalReport.ActionType("V");
                        $("#vertical-tabs").find('input, select, textarea').each(function () {
                            $(this).attr('disabled', true);
                        });
                        uof.ui.ChangeRole.viewModel.CR.detail.GetIABDetails();
                        if (UoFParams.IncidentURN != "") {
                            uof.ui.ChangeRole.viewModel.CR.detail.viewModel.URN(UoFParams.IncidentURN);
                            uof.ui.ChangeRole.viewModel.CR.detail.viewModel.ValidStill(moment(UoFParams.IncidentDate).format("MM/DD/YYYY HH:mm"));
                        }

                    }
                }
                else {
                    uof.ui.ChangeRole.viewModel.CR.detail.viewModel.IncidentID(UoFParams.IncidentId);
                    uof.ui.ChangeRole.viewModel.CR.detail.viewModel.FormID($.UoFformId);
                    // uof.ui.ChangeRole.viewModel.CR.detail.viewModel.EmployeeId(UoFParams.EmployeeId);
                    uof.ui.ChangeRole.viewModel.CR.detail.GetIABDetails();
                }
            },

            GetChangeRole: function () {
                $.prototype.showUofOverlay();
                $.ajax(
                       {
                           url: window.location.uofAPIOrigin() + '/api/UOFFormController/SaveChangeRole',
                           cache: false,
                           //   data: { FormId: uof.ui.ChangeRole.viewModel.CR.FormID(), IncidentId: uof.ui.ChangeRole.viewModel.CR.IncidentID(), DeputyId: uof.ui.ChangeRole.viewModel.CR.EmployeeId() },
                           type: "GET",
                           dataType: 'json',
                           contentType: "application/json;charset=utf-8",
                           beforeSend: function myfunction() {

                           },
                           success: function (data) {
                               if (data != null) {
                                   uof.ui.ChangeRole.viewModel.CR = ko.mapping.fromJS(data, ko.mapping.toJS(uof.ui.ChangeRole.viewModel.CR));
                                   uof.ui.ChangeRole.viewModel.CR.detail.LASDPersonnel();
                                   ko.cleanNode($("#IAB").get(0));
                                   ko.applyBindings(uof.ui.ChangeRole.viewModel, $("#IAB").get(0));
                               }
                               $.prototype.hideUofOverlay();
                           },
                           error: function (e) {
                               $.prototype.hideUofOverlay();
                               showAlert(e.responseText);

                           },
                       });
            },
            resetData: function () {
                for (var objCR in uof.ui.ChangeRole.viewModel) {
                    for (var prop in uof.ui.ChangeRole.viewModel[objCR]) {
                        if (uof.ui.ChangeRole.viewModel[objCR].hasOwnProperty(prop) && ko.isObservable(uof.ui.ChangeRole.viewModel[objCR][prop])) {
                            uof.ui.ChangeRole.viewModel[objCR][prop](undefined);
                        }
                    }
                }
                result = ko.validation.group(uof.ui.ChangeRole.viewModel, { deep: true });
                result.showAllMessages(false);
            },
            getEmployeeDetails: function (empId, targetDiv) {
                if (((empId != undefined) && (empId.length > 0))) {
                    // Search based on emp id
                    $.prototype.showProgressBar(targetDiv);
                    jQuery.ajax({
                        type: "GET",
                        url: EmployeeAPIUrl() + empId,
                        dataType: "json",
                        cache: false,
                        crossDomain: true,
                        processData: true,
                        success: function (Data) {
                            if (targetDiv == "ChangeRole") {
                                uof.ui.ChangeRole.viewModel.CR.Name(Data.LastName + ' ' + Data.FirstName.charAt(0) + '-' + Data.Rank);
                            }


                            $.prototype.hideProgressBar(targetDiv);
                        },
                        error: function (XMLHttpRequest, textStatus, errorThrown) {
                            showAlert("Error while getting the Employee Data");
                        }
                    });
                }
            },
        }

    }();
}