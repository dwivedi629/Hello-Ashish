﻿var uof = uof || {};
uof.ui = uof.ui || {};
uof.ui.ChangeOwner = uof.ui.ChangeOwner || {};

if (uof.ui.ChangeOwner) {
    uof.ui.ChangeOwner = function () {
        return {
            viewModel: {
                CO: {
                    RoleId: ko.observable(),
                    IncidentId: ko.observable(),
                    FormID: ko.observable(),

                    URN: ko.observable(),
                }
            },
            validateControls: function () {

                
                uof.ui.ChangeOwner.viewModel.CO.URN.extend({
                    required: {
                        params: true,
                        message: 'Required'
                    },
                });
                
            },
            validateCOFields: function () {
                result = ko.validation.group(uof.ui.ChangeOwner.viewModel, { deep: true });
                if (result().length > 0) {
                    uof.ui.ChangeOwner.viewModel.CO.URN.valueHasMutated();
                    return false;
                };
                return true;
            },
            saveChangeRole: function () {
                if (uof.ui.ChangeOwner.validateCOFields()) {
                    var mappedData = ko.mapping.toJS(uof.ui.ChangeOwner.viewModel.CO);
                    $.ajax(
                          {
                              url: window.location.uofAPIOrigin() + '/api/UOFForm/SaveChangeOwner',
                              cache: false,
                              type: "POST",
                              dataType: 'json',
                              data: JSON.stringify(mappedData),
                              contentType: "application/json;charset=utf-8",
                              beforeSend: function myfunction() {

                              },
                              success: function (data) {
                                  $.prototype.hideUofOverlay();
                              },
                              error: function (e) {
                                  $.prototype.hideUofOverlay();
                                  showAlert(e.responseText);
                              },
                          });
                }

            },
  
            bindChangeRole: function () {
                if (localStorage.getItem('formMode') == "View") {
                    if ($.IncidentId.length > 0 && $.UoFformId.length > 0 && $.SubmitedId.length > 0) {
                        uof.ui.ChangeOwner.viewModel.CR.IncidentID($.IncidentId);
                        uof.ui.ChangeOwner.viewModel.CR.FormID($.UoFformId);

                       // uof.ui.ChangeRole.viewModel.CR.detail.GetIABDetails();
                        if (UoFParams.IncidentURN != "") {
                            uof.ui.ChangeOwner.viewModel.CO.detail.viewModel.URN(UoFParams.IncidentURN);
                            //uof.ui.ChangeRole.viewModel.CR.detail.viewModel.ValidStill(moment(UoFParams.IncidentDate).format("MM/DD/YYYY HH:mm"));
                        }

                    }
                }
            },

            bindMaskControl: function () {
                ko.bindingHandlers.inputmask =
                {
                    init: function (element, valueAccessor, allBindingsAccessor) {

                        var mask = valueAccessor();

                        var observable = mask.value;

                        if (ko.isObservable(observable)) {

                            $(element).on('focusout change', function () {

                                if ($(element).inputmask('isComplete')) {
                                    observable($(element).val());
                                } else {
                                    observable(null);
                                }

                            });
                        }

                        $(element).inputmask(mask);


                    },
                    update: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
                        var mask = valueAccessor();

                        var observable = mask.value;

                        if (ko.isObservable(observable)) {

                            var valuetoWrite = observable();

                            $(element).val(valuetoWrite);
                        }
                    }

                };
            },
            //initiateBindings: function () {
            //    ko.validation.insertValidationMessage = function (element) {
            //        var br = document.createElement("br");
            //        element.appendChild(br);
            //        var span = document.createElement('SPAN');
            //        span.className = "warning-msg";
            //        var inputGroups = $(element).closest(".date"); //This is for getting Date Fields
            //        if (inputGroups.length > 0) {
            //            // We're in an input-group so we place the message after
            //            // the group rather than inside it in order to not break the design
            //            $(span).insertAfter(inputGroups);
            //        }
            //        else {
            //            // The default in knockout-validation
            //            element.parentNode.insertBefore(span, element.nextSibling);
            //        }
            //        return span;
            //    };
            //    $("#Staging").attr('disabled', true);
            //},

            load: function () {
                //uof.ui.ChangeOwner.validateCOFields();
                uof.ui.ChangeOwner.bindMaskControl();
                uof.ui.ChangeOwner.bindChangeRole();
                uof.ui.ChangeOwner.validateControls();
                ko.cleanNode($("#dvChangeOwnner").get(0));
                ko.applyBindings(uof.ui.ChangeOwner.viewModel, $("#dvChangeOwnner").get(0));
                

            },


        }

    }();
}