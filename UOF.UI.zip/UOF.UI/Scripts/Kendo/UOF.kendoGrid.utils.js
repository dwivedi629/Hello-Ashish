﻿var uof = uof || {};
uof.kendoGrid = uof.kendoGrid || {};

if (uof.kendoGrid) {
    uof.kendoGrid.utils = function () {
        return {
            setStickyHeader: function() { //set sticky header since Kendo doesn't support out of the box
                var gridHeader = $(".kgrid-fix-header").find(".k-grid-header");
                if (gridHeader) {
                    gridHeader.addClass('table-header affix');
                    var headerStartPos = parseInt($(".table-crown-wrap").css("top"), 10) + parseInt($(".table-crown-wrap").css("height"), 10) + 15;
                    $(".k-grid-header").css("top", headerStartPos);
                    $(".whiteout").css("height", headerStartPos);
                    $(".kgrid-fix-header").css("top", parseInt($(".k-grid-header").css("top"), 10) + parseInt($(".k-grid-header").css("height"), 10));
                }
            },
            
            setStickyHeaderIncludingMessagePanel: function () { //set sticky header since Kendo doesn't support out of the box
                $(".kgrid-fix-header").css("top", parseInt($(".k-grid-header").css("top"), 10) + parseInt($(".k-grid-header").css("height"), 10));
                
            },
        }
    }();
}