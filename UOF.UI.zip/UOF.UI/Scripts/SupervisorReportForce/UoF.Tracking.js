﻿var uof = uof || {};
uof.ui = uof.ui || {};
uof.ui.Tracking = uof.ui.Tracking || {};
if (uof.ui.Tracking) {
    uof.ui.Tracking.details = function () {
        return {
            parameters: null,
            isChanged: false,
            init: function (args) {
                this.parameters = args;
            },
            viewModel: {
                IsFormOwner: ko.observable(false),
                IsIncidentOwner: ko.observable(false),
                IsLock: ko.observable(false),
                IsSupervisorStatus: ko.observable(false),
                IsSupervisorOrApprover: ko.observable(false),
                SubmitedId: ko.observable(),
              

                TrackingModel: {
                    IncidentID: ko.observable(),
                    FormID: ko.observable(),
                    EmpId: ko.observable(),
                    UserRoleId: ko.observable(),
                    UserRole: ko.observable(),
                    Cat1: ko.observable(false),
                    Cat2: ko.observable(false),
                    Cat3: ko.observable(false),
                    ForceTypeIdOC: ko.observable(false),
                    ForceTypeIdPK: ko.observable(false),
                    ForceTypeIdTR: ko.observable(false),
                    ForceTypeIdCT: ko.observable(false),
                    ForceTypeIdTT: ko.observable(false),
                    ForceTypeIdST: ko.observable(false),
                    ForceTypeIdCR: ko.observable(false),
                    ForceTypeIdFH: ko.observable(false),
                    Medical: ko.observable(),
                    MedicalOther: ko.observable(),
                    Rescue: ko.observable(),
                    CFRTRolloutEmployees: ko.observable(),
                    IABRolloutEmployees: ko.observable(),
                    CCTVcoverage: ko.observable(),
                    AllegationForce: ko.observable(),
                    OtherVideos: ko.observable(),
                    Others: ko.observable(),
                    Station: ko.observable(),
                    eLOTS: ko.observable(),
                    FileNumber: ko.observable(),
                    ReferenceNumber: ko.observable(),
                    IncidentDate: ko.observable(),
                    HandlingSupervisor: ko.observable(),
                    ReviewingSupervisor: ko.observable(),
                    SubmittedtoOperations: ko.observable(),
                    SubmittedtoCFRT: ko.observable(),
                    SubmittedtoCommander: ko.observable(),
                    SubmittedtoDiscovery: ko.observable(),
                    isSupervisorySubmitted: ko.observable(false),
                    isSHR49Submitted: ko.observable(false),
                    isSHR438Submitted: ko.observable(false),
                    isTimecopySubmitted: ko.observable(false),
                    isUOFMemoSubmitted: ko.observable(false),
                    isInmateRptSubmitted: ko.observable(false),
                    isCDSubmitted: ko.observable(false),
                    isPhotographsSubmitted: ko.observable(false),
                    isTeaserDownloadedSubmitted: ko.observable(false),
                    isOtherDocsSubmitted: ko.observable(false),
                    isSuppRptSubmitted: ko.observable(),
                    isWCReviewSubmitted: ko.observable(),
                    isUCReviewSubmitted: ko.observable(),
                    isCMReviewSubmitted: ko.observable(),
                    isWCReviewDate: ko.observable(),
                    isUCReviewDate: ko.observable(),
                    isCMReviewDate: ko.observable(),
                    comments: ko.observable(),
                },
            },
            load: function () {
                uof.ui.Tracking.details.validateControl();
                ko.cleanNode($("#vertical-tabs").get(0));
                ko.applyBindings(uof.ui.Tracking.details.viewModel.TrackingModel, $("#vertical-tabs").get(0));
                uof.ui.Tracking.details.bindData();
            },
            validateFields: function () {
                result = ko.validation.group(uof.ui.Tracking.details.viewModel.TrackingModel, { deep: true });
                if (result().length > 0) {
                    uof.ui.Tracking.details.viewModel.TrackingModel.comments.valueHasMutated();
                    return false;
                }
                return true;
            },
            validateControl: function () {
                uof.ui.Tracking.details.viewModel.TrackingModel.comments.extend({
                    required: {
                        params: true,
                        message: "Required"
                    }
                });
            },
            bindData: function () {

                uof.ui.Tracking.details.viewModel.TrackingModel.IncidentID(UoFParams.IncidentId);
                uof.ui.Tracking.details.viewModel.TrackingModel.FormID($.UoFformId);
                uof.ui.Tracking.details.viewModel.TrackingModel.EmpId(UoFParams.userId);
                //uof.ui.Tracking.details.viewModel.TrackingModel.SubmitedId(localStorage.getItem('SubmittedId') == null ? UoFParams.userId : localStorage.getItem('SubmittedId'));
                $.prototype.showUofOverlay();
                $.ajax(
                       {
                           url: window.location.uofAPIOrigin() + '/api/SupervisorsReportforce/GetTracking',
                           cache: false,
                           data: { FormId: uof.ui.Tracking.details.viewModel.TrackingModel.FormID(), IncidentId: uof.ui.Tracking.details.viewModel.TrackingModel.IncidentID() },
                           type: "GET",
                           dataType: 'json',
                           contentType: "application/json;charset=utf-8",
                           beforeSend: function myfunction() {

                           },
                           success: function (data) {
                               if (data != null) {
                                   uof.ui.Tracking.details.viewModel.TrackingModel = ko.mapping.fromJS(data, ko.mapping.toJS(uof.ui.Tracking.details.viewModel.TrackingModel));
                                   ko.cleanNode($("#vertical-tabs").get(0));
                                   ko.applyBindings(uof.ui.Tracking.details.viewModel.TrackingModel, $("#vertical-tabs").get(0));
                                   uof.ui.Tracking.details.validateControl();
                               }
                               $.prototype.hideUofOverlay();
                           },
                           error: function (e) {
                               $.prototype.hideUofOverlay();
                               showAlert(e.responseText);
                           },
                       });
            },
            saveTrackingDetails: function () {
                if (uof.ui.Tracking.details.validateFields()) {
                    uof.ui.Tracking.details.viewModel.TrackingModel.FormID($.UoFformId);
                    uof.ui.Tracking.details.viewModel.TrackingModel.UserRole(UoFParams.userRole);
                    uof.ui.Tracking.details.viewModel.TrackingModel.EmpId(UoFParams.userId);
                    uof.ui.Tracking.details.viewModel.TrackingModel.IncidentID(UoFParams.IncidentId);
                    var jsonDate = ko.mapping.toJS(uof.ui.Tracking.details.viewModel.TrackingModel);
                    $.prototype.showUofOverlay();

                    $.ajax(
                           {
                               url: window.location.uofAPIOrigin() + '/api/SupervisorsReportforce/SaveTracking',
                               cache: false,
                               type: "POST",
                               dataType: 'json',
                               data: JSON.stringify(jsonDate),
                               contentType: "application/json;charset=utf-8",
                               beforeSend: function myfunction() {

                               },
                               success: function (empData) {
                                   $.prototype.hideUofOverlay();
                                   showAlert(empData);
                               },
                               error: function (e) {
                                   $.prototype.hideUofOverlay();
                                   showAlert(e.responseText);
                               },
                           });
                }
            },

        }
    }();
}