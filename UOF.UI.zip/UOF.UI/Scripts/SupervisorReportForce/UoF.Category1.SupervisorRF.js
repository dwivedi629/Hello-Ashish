﻿var uof = uof || {};
uof.ui = uof.ui || {};
uof.ui.Category1 = uof.ui.Category1 || {};
if (uof.ui.Category1) {
    uof.ui.Category1.SupervisorRF = function () {
        return {
            parameters: null,
            isChanged: false,
            init: function (args) {
                this.parameters = args;
            },
            Category1DBSource: null,
            ParameterCriteria: {
                IncidentReviewId: 0,
                employeeId: '',
                incidentId: 0,
                formId: 0,
                formDataId: 0
            },
            viewModel: {
                IncidentReviewId: ko.observable(0),
                FormDataId: ko.observable(0),
                IsFormOwner: ko.observable(false),
                IsOnlySave: ko.observable(true),
                IsIncidentOwner: ko.observable(false),
                IsLock: ko.observable(false),
                IsSupervisorStatus: ko.observable(false),
                IsSupervisorOrApprover: ko.observable(false),
                SubmitedId: ko.observable(),
                IncidentID: ko.observable(),
                FormID: ko.observable(),
                EmpId: ko.observable(),
                UserRoleId: ko.observable(),
                UserRole: ko.observable(),

                Category1: {
                    URN: ko.observable(UoFParams.IncidentURN),
                    BriefSceneDescription: ko.observable(),
                    chkChemicalAgent: ko.observable(),
                    chkControlTechniques: ko.observable(),
                    chkHobble: ko.observable(),
                    chkTakedowns: ko.observable(),

                    DescribeThreat: ko.observable(),
                    Debriefing: ko.observable(),
                    MechanicalRestraintsYN: ko.observable(),
                    HandcuffsMechanicalRestraints: ko.observable(false),
                    WaistChainMechanicalRestraints: ko.observable(false),
                    HobbleRestraintMechanicalRestraints: ko.observable(false),
                    SafetyChairMechanicalRestraints: ko.observable(false),
                    WheelchairMechanicalRestraints: ko.observable(false),
                    FixedObjectMechanicalRestraints: ko.observable(false),
                    chkIncidentReview1: ko.observable(false),
                    chkIncidentReview2: ko.observable(false),
                    chkIncidentReview3: ko.observable(false),
                    chkIncidentReview4: ko.observable(false),
                    chkIncidentReview5: ko.observable(false),
                    chkIncidentReview6: ko.observable(false),
                    chkIncidentReview7: ko.observable(false),
                    chkIncidentReview8: ko.observable(false),
                    chkIncidentReview9: ko.observable(false),
                    chkIncidentReview10: ko.observable(false),
                    chkIncidentReview11: ko.observable(false),
                    chkIncidentReview12: ko.observable(false),
                    chkIncidentReview13: ko.observable(),
                    ThreatMedicalOrder: ko.observable(),
                    ThreatCourtOrder: ko.observable(),
                    ThreatPassiveResistance: ko.observable(),
                    ThreatActiveResistanceverbal: ko.observable(),
                    ThreatActiveResistancephysical: ko.observable(),
                    ThreatAssaultiveOthers: ko.observable(),
                    ThreatAssaultiveLawenforcement: ko.observable(),
                    ThreatOther: ko.observable(false),
                    ThreatOtherTextbox: ko.observable(),

                    Standing: ko.observable(false),
                    Walking: ko.observable(false),
                    Running: ko.observable(false),
                    Sitting: ko.observable(false),
                    Kneeling: ko.observable(false),
                    Lying: ko.observable(false),
                    BOther: ko.observable(false),
                    BOtherReason: ko.observable(),

                    AggressiveStance: ko.observable(false),
                    Pushing: ko.observable(false),
                    Pulling: ko.observable(false),
                    Grabbing: ko.observable(false),
                    Spitting: ko.observable(false),
                    Punching: ko.observable(false),
                    Kicking: ko.observable(false),
                    Fighting: ko.observable(false),
                    Lunging: ko.observable(false),
                    POther: ko.observable(false),
                    POtherReason: ko.observable(),

                    VerbalCommands: ko.observable(false),
                    SupervisorRequested: ko.observable(false),
                    SupervisorPresent: ko.observable(false),
                    BackupRequested: ko.observable(false),
                    FOther: ko.observable(false),
                    FOtherReason: ko.observable(),
                    RejectComments: ko.observable(),
                },


            },




            load: function () {
                //if (UoFParams.IncidentId > 0) {
                //    uof.ui.Category1.SupervisorRF.viewModel.URN(UoFParams.IncidentURN),
                //    uof.ui.Category1.SupervisorRF.viewModel.FormID($.UoFformId);
                //    uof.ui.Category1.SupervisorRF.viewModel.EmpId($.SubmitedId);
                //    uof.ui.Category1.SupervisorRF.viewModel.IncidentID(UoFParams.IncidentId);
                //    uof.ui.Category1.SupervisorRF.viewModel.UserRole(UoFParams.UserRole);
                //    //if (localStorage.getItem('formMode') == "View") {
                //    //    $("#btnReset").addClass('hide');
                //    //    $("#btnSave").addClass('hide');
                //    //    $("#btnApprove").addClass('hide');
                //    //    $("#btnReject").addClass('hide')
                //    //    $("#vertical-tabs").find('input, select, textarea').each(function () {
                //    //        $(this).attr('disabled', true);
                //    //    });
                //    //    $(".fakeclass").removeClass('hide');
                //    //    $("#txtReject").attr('disabled', false);

                //    //    $("#btnSave").addClass('hide')
                //    //    $("#btnApprove").prop('disabled', false);
                //    //    $("#btnReject").prop('disabled', true);
                //    //    $("#anchorIncidentInfo").prop('disabled', false);
                //    //    $("#btnApprove").removeClass('hide');
                //    //    $("#btnReject").removeClass('hide');
                //    //}
                //    //else {
                //    //    uof.ui.Category1.SupervisorRF.viewModel.EmpId(UoFParams.userId);
                //    //}
                //    //if (uof.ui.CommonUILogic.detail.isFormStatusCompleted($.UoFformId, UoFParams.IncidentId)) {
                //    //    $("#btnReset").addClass('hide');
                //    //    $("#btnSave").addClass('hide');
                //    //    $("#btnApprove").addClass('hide');
                //    //    $("#btnReject").addClass('hide');
                //    //}
                //    //uof.ui.Category1.SupervisorRF.bindSupervisorRFDetails();
                //}
                uof.ui.Category1.SupervisorRF.bindApproveorEdit();
                uof.ui.Category1.SupervisorRF.bindCustomValidation();
                uof.ui.Category1.SupervisorRF.applyModelbinding();
                uof.ui.Category1.SupervisorRF.subscribeMethod();
                $(document).on('keyup', "#txtReject", function (e) {
                    var Commtstring = $.trim($("#txtReject").val());
                    if (Commtstring.length > 0) {
                        $("#btnReject").prop('disabled', false);
                        $("#btnApprove").prop('disabled', true);
                    }
                    else {
                        $("#btnReject").prop('disabled', true);
                        $("#btnApprove").prop('disabled', false);
                    }
                });

            },
            bindApproveorEdit: function () {
                if (localStorage.getItem('formMode') == "View" || localStorage.getItem('formMode') == "Approve") {
                    if ($.IncidentId.length > 0 && $.UoFformId.length > 0 && $.SubmitedId.length > 0) {
                        uof.ui.Category1.SupervisorRF.viewModel.IncidentID($.IncidentId);
                        uof.ui.Category1.SupervisorRF.viewModel.FormID($.UoFformId);
                        uof.ui.Category1.SupervisorRF.viewModel.EmpId($.SubmitedId);
                        uof.ui.Category1.SupervisorRF.viewModel.SubmitedId($.SubmitedId);
                        uof.ui.Category1.SupervisorRF.viewModel.UserRole(UoFParams.userRole);
                        uof.ui.Category1.SupervisorRF.viewModel.IncidentReviewId(localStorage.getItem('IncidentReviewId') == null ? 0 : localStorage.getItem('IncidentReviewId'));
                        uof.ui.Category1.SupervisorRF.viewModel.FormDataId(localStorage.getItem('FormDataId') == null ? 0: localStorage.getItem('FormDataId'));
                    }
                }
                else {
                    uof.ui.Category1.SupervisorRF.viewModel.IncidentID(UoFParams.IncidentId);
                    uof.ui.Category1.SupervisorRF.viewModel.FormID($.UoFformId);
                    uof.ui.Category1.SupervisorRF.viewModel.EmpId(UoFParams.userId);
                    uof.ui.Category1.SupervisorRF.viewModel.SubmitedId(localStorage.getItem('SubmittedId') == null ? UoFParams.userId : localStorage.getItem('SubmittedId'));
                    uof.ui.Category1.SupervisorRF.viewModel.IncidentReviewId(localStorage.getItem('IncidentReviewId') == null ? 0 : localStorage.getItem('IncidentReviewId'));
                    uof.ui.Category1.SupervisorRF.viewModel.FormDataId(localStorage.getItem('FormDataId') == null ? 0 : localStorage.getItem('FormDataId'));
                }

                uof.ui.Category1.SupervisorRF.bindSupervisorRFDetails();
            },
            buildSRObject: function (isApprove) {
                var oSRData = new Object();
                oSRData.IncidentId = $.IncidentId;
                oSRData.FormId = $.UoFformId;
                oSRData.DeputyEmpId = $.SubmitedId;
                oSRData.isApprove = isApprove;
                oSRData.ReviewerReviewId = UoFParams.userId;
                oSRData.ReviewerRole = UoFParams.userRole;
                oSRData.Comment = uof.ui.Category1.SupervisorRF.viewModel.Category1.RejectComments();
                oSRData.IncidentReviewId = uof.ui.Category1.SupervisorRF.viewModel.IncidentReviewId();
                return oSRData;
            },
            approveSRDetails: function (isApprove) {
                var str = isApprove == "Y" ? "Do you want to Approve?" : "Do you want to Reject?";
                $.when(showConfirmationWindow(str)).then(function (confirmed) {
                    if (confirmed) {
                        var oSRData = uof.ui.Category1.SupervisorRF.buildSRObject(isApprove);
                        var mappedData = ko.mapping.toJS(oSRData);
                        $.ajax(
                              {
                                  url: window.location.uofAPIOrigin() + '/api/UOFForm/ApproveorReject',
                                  cache: false,
                                  type: "POST",
                                  dataType: 'json',
                                  data: JSON.stringify(mappedData),
                                  contentType: "application/json;charset=utf-8",
                                  beforeSend: function myfunction() {

                                  },
                                  success: function (data) {
                                      $.prototype.hideUofOverlay();
                                      showAlert((isApprove == "Y" ? "Approved" : "Rejected") + " Succesfully");
                                      uof.ui.Category1.SupervisorRF.setApprovedIncidentinSession(oSRData.IncidentId);
                                      // window.location.href = window.location.uofUIOrigin() + '/Incident/Incident' + '?IncidentId=' + oSRData.IncidentId;
                                  },
                                  error: function (e) {
                                      $.prototype.hideUofOverlay();
                                      showAlert(e.responseText);
                                  },
                              });
                    }

                });
            },
            setApprovedIncidentinSession: function (incidentId) {
                $.ajax(
                     {
                         url: window.location.uofUIOrigin() + '/Incident/setApprovedIncident',
                         type: "POST",
                         data: { incidentID: incidentId },
                         success: function (data) {
                             if (data == "true")
                                 window.location.href = window.location.uofUIOrigin() + '/Incident/Incident';
                         },
                         error: function (e) {
                             showAlert(e.responseText);
                         },
                     });
            },
            bindCustomValidation: function () {
                ko.validation.rules['checked'] = {
                    validator: function (value) {
                        if (!value) {
                            return false;
                        }
                        return true;
                    }
                };

                ko.validation.registerExtenders();

            },
            subscribeMethod: function () {
                uof.ui.Category1.SupervisorRF.viewModel.Category1.ThreatOther.subscribe(function (newValue) {
                    if (newValue) {
                        uof.ui.Category1.SupervisorRF.viewModel.Category1.ThreatOtherTextbox.valueHasMutated();
                        return false;
                    }
                    else if (!newValue)
                        uof.ui.Category1.SupervisorRF.viewModel.Category1.ThreatOtherTextbox(null);
                });
                uof.ui.Category1.SupervisorRF.viewModel.Category1.BOther.subscribe(function (newValue) {
                    if (newValue) {
                        uof.ui.Category1.SupervisorRF.viewModel.Category1.BOtherReason.valueHasMutated();
                        return false;
                    }
                    else if (!newValue)
                        uof.ui.Category1.SupervisorRF.viewModel.Category1.BOtherReason(null);
                });
                uof.ui.Category1.SupervisorRF.viewModel.Category1.FOther.subscribe(function (newValue) {
                    if (newValue) {
                        uof.ui.Category1.SupervisorRF.viewModel.Category1.FOtherReason.valueHasMutated();
                        return false;
                    }
                    else if (!newValue)
                        uof.ui.Category1.SupervisorRF.viewModel.Category1.FOtherReason(null);
                });
                uof.ui.Category1.SupervisorRF.viewModel.Category1.POther.subscribe(function (newValue) {
                    if (newValue) {
                        uof.ui.Category1.SupervisorRF.viewModel.Category1.POtherReason.valueHasMutated();
                        return false;
                    }
                    else if (!newValue)
                        uof.ui.Category1.SupervisorRF.viewModel.Category1.POtherReason(null);
                });
                uof.ui.Category1.SupervisorRF.viewModel.Category1.MechanicalRestraintsYN.subscribe(function (newValue) {
                    if ($.trim(newValue) == "Y") {
                        uof.ui.Category1.SupervisorRF.viewModel.Category1.HandcuffsMechanicalRestraints.valueHasMutated();
                        uof.ui.Category1.SupervisorRF.viewModel.Category1.WaistChainMechanicalRestraints.valueHasMutated();
                        uof.ui.Category1.SupervisorRF.viewModel.Category1.HobbleRestraintMechanicalRestraints.valueHasMutated();
                        uof.ui.Category1.SupervisorRF.viewModel.Category1.SafetyChairMechanicalRestraints.valueHasMutated();
                        uof.ui.Category1.SupervisorRF.viewModel.Category1.WheelchairMechanicalRestraints.valueHasMutated();
                        uof.ui.Category1.SupervisorRF.viewModel.Category1.FixedObjectMechanicalRestraints.valueHasMutated();
                        return false;
                    }
                    else {
                        uof.ui.Category1.SupervisorRF.viewModel.Category1.HandcuffsMechanicalRestraints(false);
                        uof.ui.Category1.SupervisorRF.viewModel.Category1.WaistChainMechanicalRestraints(false);
                        uof.ui.Category1.SupervisorRF.viewModel.Category1.HobbleRestraintMechanicalRestraints(false);
                        uof.ui.Category1.SupervisorRF.viewModel.Category1.SafetyChairMechanicalRestraints(false);
                        uof.ui.Category1.SupervisorRF.viewModel.Category1.WheelchairMechanicalRestraints(false);
                        uof.ui.Category1.SupervisorRF.viewModel.Category1.FixedObjectMechanicalRestraints(false);
                        return false;
                    }
                });

            },
            applyModelbinding: function () {
                uof.ui.Category1.SupervisorRF.validateControls();
                //binding Category1 SupervisorRF page
                ko.cleanNode($("#vertical-tabs").get(0));
                ko.applyBindings(uof.ui.Category1.SupervisorRF.viewModel, $("#vertical-tabs").get(0));
            },

            bindSupervisorRFDetails: function () {
                uof.ui.Category1.SupervisorRF.ParameterCriteria.IncidentReviewId = uof.ui.Category1.SupervisorRF.viewModel.IncidentReviewId();
                uof.ui.Category1.SupervisorRF.ParameterCriteria.formDataId = uof.ui.Category1.SupervisorRF.viewModel.FormDataId();
                uof.ui.Category1.SupervisorRF.ParameterCriteria.employeeId = uof.ui.Category1.SupervisorRF.viewModel.EmpId();
                uof.ui.Category1.SupervisorRF.ParameterCriteria.incidentId = uof.ui.Category1.SupervisorRF.viewModel.IncidentID();
                uof.ui.Category1.SupervisorRF.ParameterCriteria.formId = uof.ui.Category1.SupervisorRF.viewModel.FormID();//e.data.FormId;
                var model = ko.mapping.toJS(uof.ui.Category1.SupervisorRF.ParameterCriteria);
                $.prototype.showUofOverlay();
                $.ajax(
                       {
                           url: window.location.uofAPIOrigin() + '/api/SupervisorsReportforce/GetSupervisorsReportforceInfo',
                           cache: false,
                           //data: { FormId: uof.ui.Category1.SupervisorRF.viewModel.FormID(), IncidentId: uof.ui.Category1.SupervisorRF.viewModel.IncidentID(), EmpId: uof.ui.Category1.SupervisorRF.viewModel.EmpId() },
                           data: JSON.stringify(model),
                           type: "POST",
                           dataType: 'json',
                           contentType: "application/json;charset=utf-8",
                           beforeSend: function myfunction() {

                           },
                           success: function (data) {
                               if (data != null && data.Category1 != null) {
                                   uof.ui.Category1.SupervisorRF.setSupervisorRFInformation(data.Category1);
                                   if (uof.ui.Category1.SupervisorRF.viewModel.Category1.RejectComments() != "") {
                                       $(".fakeclass").removeClass('hide');
                                       $("#txtReject").attr('disabled', false);
                                   }
                               }
                               $.prototype.hideUofOverlay();
                           },
                           error: function (e) {
                               $.prototype.hideUofOverlay();
                               showAlert(e.responseText);

                           },
                       });
            },

            setSupervisorRFInformation: function (SupervisorRFInfo) {
                uof.ui.Category1.SupervisorRF.viewModel.Category1 = ko.mapping.fromJS(SupervisorRFInfo, ko.mapping.toJS(uof.ui.Category1.SupervisorRF.viewModel.Category1));
                uof.ui.Category1.SupervisorRF.bindCustomValidation();
                uof.ui.Category1.SupervisorRF.applyModelbinding();
                uof.ui.Category1.SupervisorRF.subscribeMethod();
                uof.ui.Category1.SupervisorRF.toggleControls();
            },

            saveCategory1ReportDetails: function () {

                //Placeholder for calling API method to save Category1 Report data
                if (uof.ui.Category1.SupervisorRF.validateCategory1ReportFields()) {
                    $.when(showConfirmationWindow('Do you want to submit the for the review ? ')).then(function (confirmed) {
                        if (confirmed)
                            uof.ui.Category1.SupervisorRF.SaveSupervisorRFInfo(false);
                    });


                }
            },
            toggleControls: function () {
                uof.ui.Category1.SupervisorRF.viewModel.SubmitedId(localStorage.getItem('SubmittedId') == null ? UoFParams.userId : localStorage.getItem('SubmittedId'));
                uof.ui.Category1.SupervisorRF.viewModel.IncidentReviewId(localStorage.getItem('IncidentReviewId') == null ? 0 : localStorage.getItem('IncidentReviewId'))
                var formData = uof.ui.CommonUILogic.detail.isFormStatusCompleted($.UoFformId, UoFParams.IncidentId, uof.ui.Category1.SupervisorRF.viewModel.IncidentReviewId());
                if (formStatus != "") {
                    var formStatus = formData.split('\r\n');
                    uof.ui.Category1.SupervisorRF.viewModel.IsFormOwner(formStatus[0].split(':')[1].toLowerCase() == "true" ? true : false);
                    uof.ui.Category1.SupervisorRF.viewModel.IsIncidentOwner(formStatus[1].split(':')[1].toLowerCase() == "true" ? true : false);
                    uof.ui.Category1.SupervisorRF.viewModel.IsLock(formStatus[2].split(':')[1].toLowerCase() == "true" ? true : false);
                    uof.ui.Category1.SupervisorRF.viewModel.IsSupervisorStatus(formStatus[3].split(':')[1].toLowerCase());
                    if (uof.ui.Category1.SupervisorRF.viewModel.IsLock()) {
                        $("#vertical-tabs *").find('input, select, textarea').each(function () {
                            $(this).attr('disabled', true);
                        });
                        $("#btnReset").addClass('hide'); $("#btnSave").addClass('hide');
                        $("#btnApprove").addClass('hide'); $("#btnReject").addClass('hide');
                        if (localStorage.getItem('formMode') == "Approve") {
                            $("#btnApprove").prop('disabled', false); $("#btnApprove").removeClass('hide');
                            $("#btnReject").prop('disabled', true); $("#btnReject").removeClass('hide');
                            uof.ui.Category1.SupervisorRF.viewModel.IsSupervisorOrApprover(true);
                            $(".fakeclass").removeClass('hide');
                            $("#txtReject").attr('disabled', false);
                        }
                    }
                    else {
                        $("#btnApprove").addClass('hide'); $("#btnReject").addClass('hide');
                        if (!uof.ui.Category1.SupervisorRF.viewModel.IsFormOwner() && uof.ui.Category1.SupervisorRF.viewModel.IsSupervisorStatus() == "pending") {
                            $("#vertical-tabs *").find('input, select, textarea').each(function () {
                                $(this).attr('disabled', true);
                            });
                            $("#btnReset").addClass('hide'); $("#btnSave").addClass('hide');
                            $("#btnApprove").addClass('hide'); $("#btnReject").addClass('hide');
                            if (localStorage.getItem('formMode') == "Approve") {
                                $("#btnApprove").prop('disabled', false); $("#btnApprove").removeClass('hide');
                                $("#btnReject").prop('disabled', true); $("#btnReject").removeClass('hide');
                                uof.ui.Category1.SupervisorRF.viewModel.IsSupervisorOrApprover(true);
                                $(".fakeclass").removeClass('hide');
                                $("#txtReject").attr('disabled', false);
                            }
                        }
                    }
                }
            },
            SaveSupervisorRFInfo: function (IsOnlySave) {
                uof.ui.Category1.SupervisorRF.viewModel.IsOnlySave(IsOnlySave);
                uof.ui.Category1.SupervisorRF.viewModel.FormID($.UoFformId);
                uof.ui.Category1.SupervisorRF.viewModel.UserRole(UoFParams.userRole);
                uof.ui.Category1.SupervisorRF.viewModel.EmpId(UoFParams.userId);
                uof.ui.Category1.SupervisorRF.viewModel.IncidentID(UoFParams.IncidentId);
                var jsonDate = ko.mapping.toJS(uof.ui.Category1.SupervisorRF.viewModel);
                $.prototype.showUofOverlay();

                $.ajax(
                       {
                           url: window.location.uofAPIOrigin() + '/api/SupervisorsReportforce/SaveSupervisorsReportforceInfo',
                           cache: false,
                           type: "POST",
                           dataType: 'json',
                           data: JSON.stringify(jsonDate),
                           contentType: "application/json;charset=utf-8",
                           beforeSend: function myfunction() {

                           },
                           success: function (empData) {
                               $.prototype.hideUofOverlay();
                               uof.ui.Category1.SupervisorRF.viewModel.FormDataId(empData);
                               showAlert(IsOnlySave ? "Data saved successfully" : "submited successfully");
                           },
                           error: function (e) {
                               $.prototype.hideUofOverlay();
                               showAlert(e.responseText);
                               localStorage.setItem('selectedIncidentId', 4);//just for testing, Put actual incidentId here
                               uof.ui.incident.detail.selectedContext.selectedIncident(4);
                           },
                       });
            },
            validateControls: function () {

                //BriefSceneDescription
                uof.ui.Category1.SupervisorRF.viewModel.Category1.BriefSceneDescription.extend({
                    required: {
                        params: true,
                        message: UoFCategory1Constants.Required
                        //message:"Required"
                    }
                });
                //uof.ui.Category1.SupervisorRF.viewModel.Category1.DescribeThreat.extend({
                //    required: {
                //        params: true,
                //        message: UoFCategory1Constants.Required
                //        //message:"Required"
                //    },
                //    pattern: {
                //        params: "^[a-zA-Z0-9 _@#-.~!$%&()={}^]+$",
                //        message: UoFCategory1Constants.DescribeThreat + ' \\ / : * ? ` ; " < > | [ ]'
                //        //message: "Required " + ' \\ / : * ? ` ; " < > | [ ]'
                //    },
                //    maxLength: {
                //        params: 400,
                //        message: 'Describe Threat maximum character should be 100 only.'
                //    },
                //});
                uof.ui.Category1.SupervisorRF.viewModel.Category1.ThreatOtherTextbox.extend({
                    required: {

                        params: true,
                        message: UoFCategory1Constants.Required,
                        onlyIf: function () {
                            return (uof.ui.Category1.SupervisorRF.viewModel.Category1.ThreatOther() === true);
                        }
                    }
                });
                uof.ui.Category1.SupervisorRF.viewModel.Category1.BOtherReason.extend({
                    required: {

                        params: true,
                        message: UoFCategory1Constants.Required,
                        onlyIf: function () {
                            return (uof.ui.Category1.SupervisorRF.viewModel.Category1.BOther() === true);
                        }
                    }
                });
                uof.ui.Category1.SupervisorRF.viewModel.Category1.POtherReason.extend({
                    required: {

                        params: true,
                        message: UoFCategory1Constants.Required,
                        onlyIf: function () {
                            return (uof.ui.Category1.SupervisorRF.viewModel.Category1.POther() === true);
                        }
                    }
                });
                uof.ui.Category1.SupervisorRF.viewModel.Category1.FOtherReason.extend({
                    required: {

                        params: true,
                        message: UoFCategory1Constants.Required,
                        onlyIf: function () {
                            return (uof.ui.Category1.SupervisorRF.viewModel.Category1.FOther() === true);
                        }
                    }
                });
                uof.ui.Category1.SupervisorRF.viewModel.Category1.chkIncidentReview13.extend({
                    required: {

                        params: true,
                        message: "Please enter description",
                        onlyIf: function () {
                            return (uof.ui.Category1.SupervisorRF.viewModel.Category1.chkIncidentReview1() === false && uof.ui.Category1.SupervisorRF.viewModel.Category1.chkIncidentReview2() === false && uof.ui.Category1.SupervisorRF.viewModel.Category1.chkIncidentReview3() === false && uof.ui.Category1.SupervisorRF.viewModel.Category1.chkIncidentReview4() === false
                                && uof.ui.Category1.SupervisorRF.viewModel.Category1.chkIncidentReview5() === false && uof.ui.Category1.SupervisorRF.viewModel.Category1.chkIncidentReview6() === false && uof.ui.Category1.SupervisorRF.viewModel.Category1.chkIncidentReview7() === false && uof.ui.Category1.SupervisorRF.viewModel.Category1.chkIncidentReview8() === false
                                && uof.ui.Category1.SupervisorRF.viewModel.Category1.chkIncidentReview9() === false && uof.ui.Category1.SupervisorRF.viewModel.Category1.chkIncidentReview10() === false && uof.ui.Category1.SupervisorRF.viewModel.Category1.chkIncidentReview11() === false && uof.ui.Category1.SupervisorRF.viewModel.Category1.chkIncidentReview12() == false);
                        }
                    }
                });
                uof.ui.Category1.SupervisorRF.viewModel.Category1.Debriefing.extend({
                    required: {

                        params: true,
                        message: "Please enter Debriefing ",
                        onlyIf: function () {
                            return (uof.ui.Category1.SupervisorRF.viewModel.Category1.MechanicalRestraintsYN() === 'Y' && uof.ui.Category1.SupervisorRF.viewModel.Category1.HandcuffsMechanicalRestraints() === false && uof.ui.Category1.SupervisorRF.viewModel.Category1.WaistChainMechanicalRestraints() === false && uof.ui.Category1.SupervisorRF.viewModel.Category1.HobbleRestraintMechanicalRestraints() === false && uof.ui.Category1.SupervisorRF.viewModel.Category1.SafetyChairMechanicalRestraints() === false
                                && uof.ui.Category1.SupervisorRF.viewModel.Category1.WheelchairMechanicalRestraints() === false && uof.ui.Category1.SupervisorRF.viewModel.Category1.FixedObjectMechanicalRestraints() === false);
                        }
                    }
                });

                uof.ui.Category1.SupervisorRF.viewModel.Category1.HandcuffsMechanicalRestraints.extend({
                    checked: {
                        params: true,
                        message: UoFCategory1Constants.Required,
                        onlyIf: function () {

                            if (uof.ui.Category1.SupervisorRF.viewModel.Category1.WaistChainMechanicalRestraints())
                                return false;
                            if (uof.ui.Category1.SupervisorRF.viewModel.Category1.HobbleRestraintMechanicalRestraints())
                                return false;
                            if (uof.ui.Category1.SupervisorRF.viewModel.Category1.SafetyChairMechanicalRestraints())
                                return false;
                            if (uof.ui.Category1.SupervisorRF.viewModel.Category1.WheelchairMechanicalRestraints())
                                return false;
                            if (uof.ui.Category1.SupervisorRF.viewModel.Category1.FixedObjectMechanicalRestraints())
                                return false;

                            return (uof.ui.Category1.SupervisorRF.viewModel.Category1.MechanicalRestraintsYN() === 'Y');
                        }
                    }

                });
                uof.ui.Category1.SupervisorRF.viewModel.Category1.WaistChainMechanicalRestraints.extend({
                    checked: {
                        params: true,
                        message: UoFCategory1Constants.Required,
                        onlyIf: function () {
                            if (uof.ui.Category1.SupervisorRF.viewModel.Category1.HandcuffsMechanicalRestraints())
                                return false;
                            if (uof.ui.Category1.SupervisorRF.viewModel.Category1.HobbleRestraintMechanicalRestraints())
                                return false;
                            if (uof.ui.Category1.SupervisorRF.viewModel.Category1.SafetyChairMechanicalRestraints())
                                return false;
                            if (uof.ui.Category1.SupervisorRF.viewModel.Category1.WheelchairMechanicalRestraints())
                                return false;
                            if (uof.ui.Category1.SupervisorRF.viewModel.Category1.FixedObjectMechanicalRestraints())
                                return false;

                            return (uof.ui.Category1.SupervisorRF.viewModel.Category1.MechanicalRestraintsYN() === 'Y');
                        }
                    }

                });

                uof.ui.Category1.SupervisorRF.viewModel.Category1.HobbleRestraintMechanicalRestraints.extend({
                    checked: {
                        params: true,
                        message: UoFCategory1Constants.Required,
                        onlyIf: function () {
                            if (uof.ui.Category1.SupervisorRF.viewModel.Category1.HandcuffsMechanicalRestraints())
                                return false;
                            if (uof.ui.Category1.SupervisorRF.viewModel.Category1.WaistChainMechanicalRestraints())
                                return false;
                            if (uof.ui.Category1.SupervisorRF.viewModel.Category1.SafetyChairMechanicalRestraints())
                                return false;
                            if (uof.ui.Category1.SupervisorRF.viewModel.Category1.WheelchairMechanicalRestraints())
                                return false;
                            if (uof.ui.Category1.SupervisorRF.viewModel.Category1.FixedObjectMechanicalRestraints())
                                return false;

                            return (uof.ui.Category1.SupervisorRF.viewModel.Category1.MechanicalRestraintsYN() === 'Y');
                        }
                    }

                });
                uof.ui.Category1.SupervisorRF.viewModel.Category1.SafetyChairMechanicalRestraints.extend({
                    checked: {
                        params: true,
                        message: UoFCategory1Constants.Required,
                        onlyIf: function () {
                            if (uof.ui.Category1.SupervisorRF.viewModel.Category1.HandcuffsMechanicalRestraints())
                                return false;
                            if (uof.ui.Category1.SupervisorRF.viewModel.Category1.WaistChainMechanicalRestraints())
                                return false;
                            if (uof.ui.Category1.SupervisorRF.viewModel.Category1.HobbleRestraintMechanicalRestraints())
                                return false;
                            if (uof.ui.Category1.SupervisorRF.viewModel.Category1.WheelchairMechanicalRestraints())
                                return false;
                            if (uof.ui.Category1.SupervisorRF.viewModel.Category1.FixedObjectMechanicalRestraints())
                                return false;

                            return (uof.ui.Category1.SupervisorRF.viewModel.Category1.MechanicalRestraintsYN() === 'Y');
                        }
                    }

                });

                uof.ui.Category1.SupervisorRF.viewModel.Category1.WheelchairMechanicalRestraints.extend({
                    checked: {
                        params: true,
                        message: UoFCategory1Constants.Required,
                        onlyIf: function () {
                            if (uof.ui.Category1.SupervisorRF.viewModel.Category1.HandcuffsMechanicalRestraints())
                                return false;
                            if (uof.ui.Category1.SupervisorRF.viewModel.Category1.WaistChainMechanicalRestraints())
                                return false;
                            if (uof.ui.Category1.SupervisorRF.viewModel.Category1.HobbleRestraintMechanicalRestraints())
                                return false;
                            if (uof.ui.Category1.SupervisorRF.viewModel.Category1.SafetyChairMechanicalRestraints())
                                return false;
                            if (uof.ui.Category1.SupervisorRF.viewModel.Category1.FixedObjectMechanicalRestraints())
                                return false;

                            return (uof.ui.Category1.SupervisorRF.viewModel.Category1.MechanicalRestraintsYN() === 'Y');
                        }
                    }

                });

                uof.ui.Category1.SupervisorRF.viewModel.Category1.FixedObjectMechanicalRestraints.extend({
                    checked: {
                        params: true,
                        message: UoFCategory1Constants.Required,
                        onlyIf: function () {
                            if (uof.ui.Category1.SupervisorRF.viewModel.Category1.HandcuffsMechanicalRestraints())
                                return false;
                            if (uof.ui.Category1.SupervisorRF.viewModel.Category1.WaistChainMechanicalRestraints())
                                return false;
                            if (uof.ui.Category1.SupervisorRF.viewModel.Category1.HobbleRestraintMechanicalRestraints())
                                return false;
                            if (uof.ui.Category1.SupervisorRF.viewModel.Category1.SafetyChairMechanicalRestraints())
                                return false;
                            if (uof.ui.Category1.SupervisorRF.viewModel.Category1.WheelchairMechanicalRestraints())
                                return false;

                            return (uof.ui.Category1.SupervisorRF.viewModel.Category1.MechanicalRestraintsYN() === 'Y');
                        }
                    }

                });

                //uof.ui.Category1.SupervisorRF.viewModel.TheCheckboxListOptions= ko.observableArray().extend({
                //    required: { message: "At least one option is required." }
                //}),
            },
            validateCategory1ReportFields: function () {
                result = ko.validation.group(uof.ui.Category1.SupervisorRF.viewModel.Category1, { deep: true });
                if (result().length > 0) {
                    uof.ui.Category1.SupervisorRF.viewModel.Category1.BriefSceneDescription.valueHasMutated();
                    uof.ui.Category1.SupervisorRF.viewModel.Category1.DescribeThreat.valueHasMutated();
                    uof.ui.Category1.SupervisorRF.viewModel.Category1.Debriefing.valueHasMutated();
                    uof.ui.Category1.SupervisorRF.viewModel.Category1.chkIncidentReview13.valueHasMutated();
                    uof.ui.Category1.SupervisorRF.viewModel.Category1.ThreatOtherTextbox.valueHasMutated();
                    return false;
                }
                return true;
            },
        }
    }();
}