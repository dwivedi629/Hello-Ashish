﻿var UoFCategory1Constants = {
    Required: 'Required',
    BSD: 'Action is required',
   
    Facility: 'Facility is required',
    ReferenceNumber: 'Reference Number is required',
    NumberOfAdultArrests: '# of Adult Arrests is required',
    URN: 'URN is required',
    Classification1LevelStatCode: 'Classification 1 Level Stat Code is required',
    SexOffenseVictimInfo: 'Sex Offense Victim Info is required',
    Classification2LevelStatCode: 'Classification 2 Level Stat Code is required',
    DomesticViolence: 'Domestic Violence is required',
    Classification3LevelStatCode: 'Classification 3 Level Stat Code is required',
    DateTimeDayOfOccurrence: 'Date Time Day Of Occurrence is required',
    By: 'By is required',
    Time: 'Time is required',
    Injury: 'Injury is required',
    LocationOfOccurrence: 'Location Of Occurrence is required',
    BusinessName: 'Bus. Name is required',
    ResAddress: 'ResAddress is required'

}