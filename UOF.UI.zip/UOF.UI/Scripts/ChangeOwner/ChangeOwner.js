﻿var uof = uof || {};
uof.ui = uof.ui || {};
uof.ui.ChangeOwner = uof.ui.ChangeOwner || {};

if (uof.ui.ChangeOwner) {
    uof.ui.ChangeOwner = function () {
        return {
            SelectedPageNumber: 0,
            viewModel: {
                CO: {

                    URN: ko.observable(),
                    IncidentId: ko.observable(),
                    IncidentReviewId: ko.observable(),
                    FormId: ko.observable(),
                    ExistingEmpId: ko.observable(),
                },
                Assign: {
                    IncidentId: ko.observable(),
                    EmpID: ko.observable(""),
                    EmpLName: ko.observable(),
                    EmpFName: ko.observable(),
                    EmpMName: ko.observable(),
                    EmpRank: ko.observable(),
                    EmpEmailId: ko.observable(),
                    owner: ko.observable(""),
                },
                getEmployeeDetails: function (empId, optionCriteria) {
                    if (empId != undefined)
                        uof.ui.ChangeOwner.getEmployeeDetails(empId, optionCriteria);
                },
            },
            bindMaskControl: function () {
                ko.bindingHandlers.inputmask =
                {
                    init: function (element, valueAccessor, allBindingsAccessor) {

                        var mask = valueAccessor();

                        var observable = mask.value;

                        if (ko.isObservable(observable)) {

                            $(element).on('focusout change', function () {

                                if ($(element).inputmask('isComplete')) {
                                    observable($(element).val());
                                } else {
                                    observable(null);
                                }

                            });
                        }

                        $(element).inputmask(mask);


                    },
                    update: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
                        var mask = valueAccessor();

                        var observable = mask.value;

                        if (ko.isObservable(observable)) {

                            var valuetoWrite = observable();

                            $(element).val(valuetoWrite);
                        }
                    }

                };
            },
            load: function () {

                uof.ui.ChangeOwner.bindMaskControl();
                uof.ui.ChangeOwner.validateControls();
                ko.cleanNode($("#dvChangeOwner").get(0));
                ko.applyBindings(uof.ui.ChangeOwner.viewModel, $("#dvChangeOwner").get(0));

                ko.cleanNode($("#divCO").get(0));
                ko.applyBindings(uof.ui.ChangeOwner.viewModel, $("#divCO").get(0));
                //uof.ui.ChangeOwner.viewModel.Assign.EmpLName
                uof.ui.ChangeOwner.validateControlsAssign();
            },

            validateControls: function () {
                uof.ui.ChangeOwner.viewModel.CO.URN.extend({
                    required: {
                        params: true,
                        message: 'Required'
                    },
                });
            },
            validateCOFields: function () {
                result = ko.validation.group(uof.ui.ChangeOwner.viewModel, { deep: true });
                if (result().length > 0) {
                    uof.ui.ChangeOwner.viewModel.CO.URN.valueHasMutated();
                    uof.ui.ChangeOwner.viewModel.CO.owner.valueHasMutated();
                    return false;
                };
                return true;
            },
            chkSelectedForUrn: function (ReviewId) {
                var isChecked = false;
                if ($('#chkUrnClicked' + ReviewId).is(':checked')) {
                    isChecked = true;
                    localStorage.setItem("selectedIncidentId", ReviewId);

                }

                $('[name*="chkUrnClickedName"]').each(function () {
                    $(this).attr('disabled', false);
                    if (isChecked && ($(this)[0].id != ('chkUrnClicked' + ReviewId))) {
                        $(this).attr('disabled', true);
                        $(this).attr('checked', false);
                    }
                });
            },
            getEmployeeDetails: function (empId, optionCriteria) {

                // Search based on emp id
                $.prototype.showProgressBar("emplSection");
                if (empId != "") {


                    jQuery.ajax({
                        type: "GET",
                        url: EmployeeAPIUrl() + empId,
                        dataType: "json",
                        cache: false,
                        crossDomain: true,
                        processData: true,
                        success: function (empData) {
                            uof.ui.incident.detail.viewModel.hasError(false);

                            if (optionCriteria == 'Assign') {
                                uof.ui.ChangeOwner.viewModel.Assign.EmpFName(empData.FirstName);
                                uof.ui.ChangeOwner.viewModel.Assign.EmpLName(empData.LastName);
                                uof.ui.ChangeOwner.viewModel.Assign.EmpMName(empData.MiddleName);
                                uof.ui.ChangeOwner.viewModel.Assign.EmpRank(empData.Rank);
                                uof.ui.ChangeOwner.viewModel.Assign.EmpEmailId(empData.EmailAddress);
                            }

                            $.prototype.hideProgressBar("emplSection");
                        },
                        error: function (XMLHttpRequest, textStatus, errorThrown) {
                            $.prototype.hideProgressBar("emplSection");
                            showAlert("error");
                        }
                    });
                }
            },
            buildCOObject: function () {
                var oCOObject = new Object();
                oCOObject.IncidentId = uof.ui.ChangeOwner.viewModel.CO.IncidentId();
                oCOObject.IncidentReviewId = uof.ui.ChangeOwner.viewModel.CO.IncidentReviewId();
                oCOObject.owner = uof.ui.ChangeOwner.viewModel.Assign.owner("S");
                oCOObject.FormId = uof.ui.ChangeOwner.viewModel.CO.FormId();;
                oCOObject.ExistingEmpId = uof.ui.ChangeOwner.viewModel.CO.ExistingEmpId();
                oCOObject.ChangedEmpId = uof.ui.ChangeOwner.viewModel.Assign.EmpID();
                oCOObject.ChangedEmpLastName = uof.ui.ChangeOwner.viewModel.Assign.EmpLName();
                oCOObject.ChangedEmmFirstName = uof.ui.ChangeOwner.viewModel.Assign.EmpFName();
                oCOObject.ChangedEmpRank = uof.ui.ChangeOwner.viewModel.Assign.EmpRank();
                oCOObject.CreatedBy = UoFParams.userId;
                oCOObject.EmailId = uof.ui.ChangeOwner.viewModel.Assign.EmpEmailId();
                return oCOObject;
            },
            Assign: function (IncidentId, IncidentReviewId, FormId, ExistingEmpId) {
                uof.ui.ChangeOwner.viewModel.CO.IncidentId(IncidentId);
                uof.ui.ChangeOwner.viewModel.CO.IncidentReviewId(IncidentReviewId);
                uof.ui.ChangeOwner.viewModel.CO.FormId(FormId);
                uof.ui.ChangeOwner.viewModel.CO.ExistingEmpId(ExistingEmpId);
                $("#divCO").show();
                $("#divCO").kendoWindow({
                    width: "65%",
                    title: "Change Owership",
                    visible: false,
                    modal: true,
                    actions: [
                            "Pin",
                            "Close"
                    ],
                }).data("kendoWindow").center().open();
            },
            ResetReviewer: function (IncidentId, IncidentReviewId, FormId, ExistingEmpId) {
                $.when(showConfirmationWindow('Do you want to reset the reviewer ? ')).then(function (confirmed) {
                    if (confirmed) {
                        var oCOObject = new Object();
                        oCOObject.IncidentId = IncidentId;
                        oCOObject.IncidentReviewId = IncidentReviewId;
                        oCOObject.owner = "R";
                        oCOObject.FormId = FormId;
                        oCOObject.ExistingEmpId = ExistingEmpId;
                        oCOObject.CreatedBy = UoFParams.userId;
                        var mappedData = ko.mapping.toJS(oCOObject);
                        $.prototype.showUofOverlay();
                        $.ajax(
                              {
                                  url: window.location.uofAPIOrigin() + '/api/Settings/ChangeOwnerShip',
                                  cache: false,
                                  type: "POST",
                                  dataType: 'json',
                                  data: JSON.stringify(mappedData),
                                  contentType: "application/json;charset=utf-8",
                                  beforeSend: function myfunction() {

                                  },
                                  success: function (data) {
                                      showAlert("Reset is done Succesfully");
                                      uof.ui.ChangeOwner.getData(uof.ui.ChangeOwner.viewModel.CO.URN()); // Calling the grid binding which bind with udpated data 
                                      $.prototype.hideUofOverlay();
                                  },
                                  error: function (e) {
                                      $.prototype.hideUofOverlay();
                                      showAlert(e.responseText);
                                  },
                              });
                    }
                });
            },
            AssignUser: function () {
                if (uof.ui.ChangeOwner.validateFieldsAssign()) {
                    var data = uof.ui.ChangeOwner.buildCOObject();
                    // var mappedData = ko.mapping.toJS(data);
                    var mappedData = ko.mapping.toJS(data);
                    $.prototype.showUofOverlay();
                    $.ajax(
                          {
                              url: window.location.uofAPIOrigin() + '/api/Settings/ChangeOwnerShip',
                              cache: false,
                              type: "POST",
                              dataType: 'json',
                              data: JSON.stringify(mappedData),
                              contentType: "application/json;charset=utf-8",
                              beforeSend: function myfunction() {

                              },
                              success: function (data) {
                                  showAlert("OwnerShip Changed Succesfully");
                                  uof.ui.ChangeOwner.resetData();
                                  $("#divCO").data("kendoWindow").close();
                                  uof.ui.ChangeOwner.getData(uof.ui.ChangeOwner.viewModel.CO.URN()); // Calling the grid binding which bind with udpated data 
                                  $.prototype.hideUofOverlay();
                              },
                              error: function (e) {
                                  $.prototype.hideUofOverlay();
                                  showAlert(e.responseText);
                              },
                          });
                }
            },
            canceluser: function () {
                uof.ui.ChangeOwner.resetData();
                $("#divCO").data("kendoWindow").close();
            },
            validateControlsAssign: function () {
                uof.ui.ChangeOwner.viewModel.Assign.EmpID.extend({
                    required: {
                        params: true,
                        message: 'Required'
                    },
                });
            },
            validateFieldsAssign: function () {
                result = ko.validation.group([uof.ui.ChangeOwner.viewModel.Assign.EmpID, uof.ui.ChangeOwner.viewModel.Assign.owner]);
                if (result().length > 0) {
                    uof.ui.ChangeOwner.viewModel.Assign.EmpID.valueHasMutated();
                    result.showAllMessages(true);
                    return false;
                };
                return true;
            },
            validateCOFieldsAssign: function () {
                result = ko.validation.group(uof.ui.ChangeOwner.viewModel, { deep: true });
                if (result().length > 0) {
                    uof.ui.ChangeOwner.viewModel.Assign.EmpID.valueHasMutated();
                    return false;
                };
                return true;
            },
            getData: function (URN) {
                $.prototype.showUofOverlay();
                var dlAjaxOption =
                    {
                        url: window.location.uofAPIOrigin() + '/api/Settings/GetIncidentForms',
                        cache: false,
                        data: { URN: URN },
                        type: "GET",
                        dataType: 'json',
                        contentType: "application/json;charset=utf-8",
                        success: function (incidentData) {
                            $.prototype.hideUofOverlay();
                            var geoDataSource = new kendo.data.DataSource({
                                data: incidentData,
                                pageSize: 20
                            });
                            geoDataSource.fetch(function () {
                                geoDataSource.page(parseInt(uof.ui.ChangeOwner.SelectedPageNumber) > 0 ? parseInt(uof.ui.ChangeOwner.SelectedPageNumber) : 1);
                            });
                            //setting all Org Data to kendo
                            $("#formData").kendoGrid({
                                dataSource: geoDataSource,
                                height: 600,
                                resizable: true,
                                sortable: true,
                                columnMenu: true,
                                pageable: {
                                    refresh: false,
                                    pageSizes: true,
                                    pageSizes: [20, 40, 100],
                                    buttonCount: 5,
                                    messages: {
                                        empty: "No Forms to display",
                                        itemsPerPage: "Forms Per Page",
                                    },
                                },
                                columns: [
                                            //{
                                            //    field: "ReviewId",
                                            //    template: $("#rdIncidentOption").html(),
                                            //    headerTemplate: '',
                                            //    width: "90px",
                                            //},
                                             {
                                                 field: "URN",
                                                 width: 150,
                                                 template: '<span class="cellTooltip" title="#=URN#">#=URN#</span>',
                                                 headerTemplate: '<span> URN </span>',
                                             },
                                            {
                                                field: "EmployeeID",
                                                template: $("#showName").html(),
                                                width: 100,
                                                headerTemplate: '<span> Submited Employee ID </span>',
                                            },
                                             {
                                                 field: "IncidentId",
                                                 width: "10px",
                                                 hidden: true
                                             },
                                              {
                                                  field: "FormId",
                                                  width: 5,
                                                  headerTemplate: '',
                                                  hidden: true
                                              },
                                             {
                                                 field: "FormName",
                                                 width: 150,
                                                 template: '<span class="cellTooltip" title="#=FormName#">#=FormName#</span>',
                                                 headerTemplate: '<span>Form Name</span>',
                                             },

                                               {
                                                   field: "FormStatus",
                                                   width: 100,
                                                   template: $("#openCO").html(),
                                                   headerTemplate: '<span> Submitted Status </span>',
                                               },
                                              {
                                                  field: "Status",
                                                  width: 100,
                                                  template: $("#openRO").html(),
                                                  headerTemplate: '<span> Reviewer Status </span>',
                                              },


                                ],
                                change: function (e) {
                                    var model = this.dataItem(this.select());
                                }

                            }).data().kendoGrid;

                        },
                        error: function (e) {
                            $.prototype.hideUofOverlay();
                            showAlert(e.responseText);
                        }

                    };
                // Call ajax
                var ajaxOptions = $.extend({}, 'GET', dlAjaxOption);
                $.ajax(ajaxOptions);
            },
            resetData: function () {
                uof.ui.ChangeOwner.viewModel.Assign.EmpEmailId(null);
                uof.ui.ChangeOwner.viewModel.Assign.EmpID(null);
                uof.ui.ChangeOwner.viewModel.Assign.EmpFName(null);
                uof.ui.ChangeOwner.viewModel.Assign.EmpLName(null);
                uof.ui.ChangeOwner.viewModel.Assign.EmpRank(null);
            },
        }

    }();
}

