﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.Infrastructure.Accessor
{
    public interface IAccessorService
    {
        object Get(object instance, string propertyName, object defaultValue);
        T Get<T>(object instance, string propertyName, T defaultValue);
        void Set(object instance, string propertyName, object value);
        void Set<T>(object instance, string propertyName, T value);
    }
}
