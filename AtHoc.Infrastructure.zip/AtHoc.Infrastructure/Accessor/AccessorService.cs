﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Ioc;

namespace AtHoc.Infrastructure.Accessor
{
    public static class AccessorService
    {
        public static IAccessorService Current { get; set; }

        static AccessorService()
        {
            AccessorService.Current = ServiceLocator.Resolve<IAccessorService>();
        }
    }
}
