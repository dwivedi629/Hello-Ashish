﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Entity;

namespace AtHoc.Infrastructure.Accessor.Default
{
    public class DefaultAccessorService : IAccessorService
    {
        public object Get(object instance, string propertyName, object defaultValue)
        {
            var retValue = defaultValue;
            try
            {
                var obj = instance as IPropertyAccessor;
                if (obj == null)
                {
                    var propertyInfo = instance.GetType().GetProperty(propertyName);
                    retValue = propertyInfo.GetValue(instance);
                }
                else
                {
                    retValue = obj.Get(propertyName, defaultValue);
                }
            }
            catch 
            { }
            return retValue;
        }

        public T Get<T>(object instance, string propertyName, T defaultValue)
        {
            return (T)this.Get(instance, propertyName, (object)defaultValue);
        }

        public void Set(object instance, string propertyName, object value)
        {
            try
            {
                var obj = instance as IPropertyAccessor;
                if (obj == null)
                {
                    var propertyInfo = instance.GetType().GetProperty(propertyName);
                    propertyInfo.SetValue(instance, value);
                }
                else
                {
                    obj.Set(propertyName, value);
                }
            }
            catch
            { }
        }

        public void Set<T>(object instance, string propertyName, T value)
        {
            this.Set(instance, propertyName, (object)value);
        }
    }
}
