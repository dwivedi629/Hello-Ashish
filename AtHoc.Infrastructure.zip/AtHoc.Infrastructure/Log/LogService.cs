﻿using AtHoc.Infrastructure.Ioc;

namespace AtHoc.Infrastructure.Log
{
	public static class LogService
	{
		public static ILogService Current { get; set; }

		static LogService()
		{
			Current = ServiceLocator.Resolve<ILogService>();
		}
	}
}