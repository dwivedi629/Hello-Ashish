﻿using System;
using AtHoc.Infrastructure.Resources;
using NLog;

namespace AtHoc.Infrastructure.Log.NLog
{
    public class NLogService : ILogService
    {
        public string DefaultLogger { get; set; }

        public NLogService()
        {
            this.DefaultLogger = "Default";
        }

        public void Error(Func<object> outputMessageFunc)
        {
            this.Error(this.DefaultLogger, outputMessageFunc);
        }

        public void Warn(Func<object> outputMessageFunc)
        {
            this.Warn(this.DefaultLogger, outputMessageFunc);
        }

        public void Info(Func<object> outputMessageFunc)
        {
            this.Info(this.DefaultLogger, outputMessageFunc);
        }

        public void Debug(Func<object> outputMessageFunc)
        {
            this.Debug(this.DefaultLogger, outputMessageFunc);
        }

        public void Fatal(Func<object> outputMessageFunc)
        {
            this.Fatal(this.DefaultLogger, outputMessageFunc);
        }

        public void Messages(Messages messages)
        {
            this.Messages(this.DefaultLogger, messages);
        }

        public void SetContextItem(string name, object value)
        {
        }

        public void Error(string name, Func<object> outputMessageFunc)
        {
            LogManager.GetLogger(name).Error(outputMessageFunc());
        }

        public void Warn(string name, Func<object> outputMessageFunc)
        {
            LogManager.GetLogger(name).Warn(outputMessageFunc());
        }

        public void Info(string name, Func<object> outputMessageFunc)
        {
            LogManager.GetLogger(name).Info(outputMessageFunc());
        }

        public void Debug(string name, Func<object> outputMessageFunc)
        {
            LogManager.GetLogger(name).Debug(outputMessageFunc());
        }

        public void Fatal(string name, Func<object> outputMessageFunc)
        {
            LogManager.GetLogger(name).Fatal(outputMessageFunc());
        }

        public void Verbose(Func<object> outputMessageFunc)
        {
            this.Debug(this.DefaultLogger, outputMessageFunc);
        }

        public void Messages(string name, Messages messages)
        {
            if (messages != null)
            {
                foreach (var message in messages)
                {
                    switch (message.Type)
                    {
                        case MessageType.Error:
                            this.Error(name, () => message.Value);
                            break;
                        case MessageType.Information:
                        case MessageType.Success:
                            this.Info(name, () => message.Value);
                            break;
                        case MessageType.Warning:
                            this.Warn(name, () => message.Value);
                            break;
                    }
                }
            }
        }
    }
}