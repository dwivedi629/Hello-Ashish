﻿using System;

using AtHoc.Diagnostics;
using AtHoc.Infrastructure.Resources;
using AtHoc.Runtime;

namespace AtHoc.Infrastructure.Log.EventLog
{
	public class AtHocEventLogger : ILogService
	{
	    private readonly string[] _logWrapperNames = {"AtHocEventLogger"};

		#region AtHoc EventLogger

		public void Error(Func<object> outputMessageFunc)
		{
			if (!EventLogger.IsErrorEnabled) return;
			var value = outputMessageFunc();
			if (value is Exception)
                EventLogger.WriteError(value as Exception, _logWrapperNames);
			else
                EventLogger.WriteError(value.ToString(), _logWrapperNames);
		}

		public void Warn(Func<object> outputMessageFunc)
		{
			if (!EventLogger.IsWarningEnabled) return;
			var value = outputMessageFunc();
			if (value is Exception)
                EventLogger.WriteWarning(value as Exception, _logWrapperNames);
			else
                EventLogger.WriteWarning(value.ToString(), _logWrapperNames);
		}

		public void Info(Func<object> outputMessageFunc)
		{
			if (!EventLogger.IsInformationEnabled) return;
			var value = outputMessageFunc();
			if (value is Exception)
                EventLogger.WriteInformation(value as Exception, _logWrapperNames);
			else
                EventLogger.WriteInformation(value.ToString(), _logWrapperNames);
		}

		public void Verbose(Func<object> outputMessageFunc)
		{
			if (!EventLogger.IsVerboseEnabled) return;
			var value = outputMessageFunc();
			if (value is Exception)
                EventLogger.WriteVerbose(value as Exception, _logWrapperNames);
			else
                EventLogger.WriteVerbose(value.ToString(), _logWrapperNames);
		}

		#endregion

		#region Not Implemented

		public void Debug(Func<object> outputMessageFunc)
		{
			throw new NotImplementedException();
		}

		public void Fatal(Func<object> outputMessageFunc)
		{
			throw new NotImplementedException();
		}

		public void Messages(Messages messages)
		{
			throw new NotImplementedException();
		}

	    public void SetContextItem(string name, object value)
	    {
	        AtHocContext.Current.Logging().SetContextItem(name, value);
	    }

	    #endregion
	}
}