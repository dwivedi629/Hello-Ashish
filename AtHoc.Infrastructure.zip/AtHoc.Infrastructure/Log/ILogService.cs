﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Resources;

namespace AtHoc.Infrastructure.Log
{
    public interface ILogService
    {
        void Error(Func<object> outputMessageFunc);
        void Warn(Func<object> outputMessageFunc);
        void Info(Func<object> outputMessageFunc);
        void Verbose(Func<object> outputMessageFunc);
        void Debug(Func<object> outputMessageFunc);
        void Fatal(Func<object> outputMessageFunc);
        void Messages(Messages messages);

        void SetContextItem(string name, object value);
    }
}
