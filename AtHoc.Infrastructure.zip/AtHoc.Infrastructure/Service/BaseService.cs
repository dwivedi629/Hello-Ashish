﻿using System;

using AtHoc.Infrastructure.Domain;
using AtHoc.Infrastructure.Log;

namespace AtHoc.Infrastructure.Service
{
	public abstract class Service<TResult, TParameter> : IService<TResult, TParameter>
		where TParameter : class
	{
		public virtual IActionResult<TResult> Process(TParameter parameter)
		{
			var result = CreateActionResult();
			try
			{
				ProcessParameter(parameter, result);
				if (result.IsValid)
					result.Messages.CreateSuccessMessage(GetSuccessMessageText());
				return result;
			}
			catch (Exception ex)
			{
				OnServiceError(ex, result);
			}
			return result;
		}

		protected abstract IActionResult<TResult> CreateActionResult();

		protected virtual string GetSuccessMessageText()
		{
			return "Action completed.";
		}

		protected abstract void ProcessParameter(TParameter parameter, IActionResult<TResult> result);

		protected virtual void OnServiceError(Exception ex, IActionResult<TResult> result)
		{
			result.Messages.CreateErrorMessage(ex);
			LogService.Current.Error(() => ex);
		}
	}
}
