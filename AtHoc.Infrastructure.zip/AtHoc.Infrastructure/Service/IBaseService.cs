﻿using AtHoc.Infrastructure.Domain;

namespace AtHoc.Infrastructure.Service
{
	public interface IService<TResult, in TParameter> where TParameter : class
	{
		IActionResult<TResult> Process(TParameter parameter);
	}
}
