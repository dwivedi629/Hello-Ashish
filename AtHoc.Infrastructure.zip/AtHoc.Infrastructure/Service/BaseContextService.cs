﻿using System;

using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Domain;

namespace AtHoc.Infrastructure.Service
{
	public abstract class ContextService<TResult, TParameter, TContext> : Service<TResult, TParameter>
		where TParameter : class
		where TContext : IUnitOfWork
	{
		protected override void ProcessParameter(TParameter parameter, IActionResult<TResult> result)
		{
			using (var context = CreateContext())
			{
				try
				{
					context.UseTransaction = true;
					ProcessParameter(context, parameter, result);
					if (result.IsValid)
						context.Commit();
				}
				catch (Exception)
				{
					context.Rollback();
					throw;
				}
			}
		}

		protected abstract TContext CreateContext();

		protected abstract void ProcessParameter(TContext context, TParameter parameter, IActionResult<TResult> result);
	}
}
