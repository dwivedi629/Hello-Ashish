﻿using System;

namespace AtHoc.Infrastructure.Database
{
	public static class DbUtils
	{
		public static string Escape(string columnName)
		{
			return columnName.Replace("]", "]]");
		}

		public static string AddBrackets(string columnName)
		{
			return String.Concat("[", columnName, "]");
		}

		public static string Refine(string columnName, string alias = null)
		{
		    var result = AddBrackets(Escape(columnName));
		    
            if (!string.IsNullOrWhiteSpace(alias))
		        result = string.Format("{0}.{1}", alias, result);

			return result;
		}
	}
}
