﻿using System;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

using AtHoc.Infrastructure.Encryption;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Sql;

using Microsoft.SqlServer.Types;

using SqlParameter = AtHoc.Infrastructure.Sql.SqlParameter;

namespace AtHoc.Infrastructure.Database.MsSql
{
	public abstract class MsSql2008DbContext : DbContext
	{
		protected MsSql2008DbContext(string name, string connStr, bool useTransaction = false, string delimiter = "split")
			: base(name, connStr, useTransaction, delimiter)
		{
		}

		public override SqlDialect SqlDialect
		{
			get { return SqlDialect.MSSql2008; }
		}

		protected override DbConnection GetConnection(string connStr)
		{
			return new SqlConnection(connStr);
		}

		public override SqlParameter CreateParameter(string name, object value, int? size)
		{
			var param = new SqlParameter(name, value);
			if (size.HasValue)
				param.Size = size.Value;
			return param;
		}

		protected override DbDataAdapter GetDataAdapter()
		{
			return new SqlDataAdapter();
		}

		protected override DbParameter ToDbParameter(SqlParameter parameter)
		{
			string udtTypeName;
			var sqlDbType = GetSqlDbType(parameter.MetaProperty, out udtTypeName);
			if (sqlDbType == null) sqlDbType = GetSqlDbType(parameter, out udtTypeName);
			var dbValue = ObjectToDbValue(parameter, sqlDbType.Value, udtTypeName);

			var sqlParameter = new System.Data.SqlClient.SqlParameter
			{
				ParameterName = parameter.Name,
				Direction = parameter.Direction,
				Value = dbValue,
				SqlDbType = sqlDbType.Value,
				UdtTypeName = udtTypeName
			};

			if (parameter.Size.HasValue)
				sqlParameter.Size = parameter.Size.Value;

			return sqlParameter;
		}

		protected override SqlDbType? GetSqlDbType(MetaProperty metaProperty, out string udtTypeName)
		{
			udtTypeName = null;
			var success = false;
			var sqlDbType = SqlDbType.NVarChar;

			//mapping from meta property
			if (metaProperty != null && metaProperty.DbTypeName.IsNotNullOrEmpty())
			{
				success = Enum.TryParse(metaProperty.DbTypeName, true, out sqlDbType);
			}

			return success ? sqlDbType : (SqlDbType?) null;
		}

		protected override SqlDbType? GetSqlDbType(SqlParameter parameter, out string udtTypeName)
		{
			udtTypeName = null;
			SqlDbType? sqlDbType = SqlDbType.NVarChar;

			//default mapping
			if (parameter.Value != null)
			{
				var type = parameter.Value.GetType();
				if (type == typeof (bool))
				{
					sqlDbType = SqlDbType.Bit;
				}
				else if (type == typeof (Guid))
				{
					sqlDbType = SqlDbType.UniqueIdentifier;
				}
				else if (type == typeof (DateTime))
				{
					sqlDbType = SqlDbType.DateTime;
				}
				else if (type == typeof (int))
				{
					sqlDbType = SqlDbType.Int;
				}
				else if (type == typeof (short))
				{
					sqlDbType = SqlDbType.SmallInt;
				}
				else if (type == typeof (decimal))
				{
					sqlDbType = SqlDbType.Decimal;
				}
				else if (type == typeof (long))
				{
					sqlDbType = SqlDbType.BigInt;
				}
				else if (type == typeof (string))
				{
					sqlDbType = (((string) parameter.Value).Length > 4000) ? SqlDbType.NText : SqlDbType.NVarChar;
				}
				else if (type == typeof (SqlGeography))
				{
					sqlDbType = SqlDbType.Udt;
					udtTypeName = "geography";
				}
				else if (type == typeof (SqlGeometry))
				{
					sqlDbType = SqlDbType.Udt;
					udtTypeName = "geometry";
				}
				else if (type == typeof (byte[]))
				{
					sqlDbType = SqlDbType.Binary;
				}
				else if (type.IsEnum)
				{
					sqlDbType = SqlDbType.Int;
				}
				else
				{
					throw new NotSupportedException("Unable to get SqlDbType from type ({0})".FormatWith(type.FullName));
				}
			}
			return sqlDbType;
		}

		public override object ObjectToDbValue(SqlParameter parameter, SqlDbType sqlDbType, string udtTypeName)
		{
			var dbValue = parameter.Value;

			//by default everything should be mapped nicely
			if (parameter.Value == null)
			{
				dbValue = DBNull.Value;
			}
			else
			{
				if (parameter.MetaProperty != null)
				{
					if (parameter.MetaProperty.IsEncrypted && parameter.MetaProperty.CryptoType != CryptoType.OneWayHash &&
						parameter.MetaProperty.PropertyType == typeof (string))
					{
						var crypto = CryptoFactory.Current.Create(parameter.MetaProperty.CryptoType);
						dbValue = crypto.Encrypt(dbValue as string);
					}
				}
			}

			return dbValue;
		}

		public override object DbValueToObject(object dbValue, MetaProperty metaProperty)
		{
			object value = null;
			if (dbValue != null && dbValue != DBNull.Value)
			{
				value = dbValue;
				if (metaProperty.PropertyType == typeof (bool))
				{
					value = dbValue.ConvertTo<bool>(throwException: true);
				}
				else if (metaProperty.PropertyType.IsEnum)
				{
					value = Enum.Parse(metaProperty.PropertyType, dbValue.ToString());
				}
				else if (metaProperty.PropertyType == typeof (string) && metaProperty.IsEncrypted &&
						metaProperty.CryptoType != CryptoType.OneWayHash)
				{
					var crypto = CryptoFactory.Current.Create(metaProperty.CryptoType);
					value = crypto.Decrypt(dbValue as string);
				}
				else if (metaProperty.PropertyType.IsNullable())
				{
					var underlyingType = Nullable.GetUnderlyingType(metaProperty.PropertyType);
					if (underlyingType != null && underlyingType.IsEnum)
						value = Enum.Parse(underlyingType, dbValue.ToString());
				}
			}
			return value;
		}
	}
}