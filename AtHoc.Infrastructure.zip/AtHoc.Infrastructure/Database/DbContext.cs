﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text.RegularExpressions;

using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Sql;

namespace AtHoc.Infrastructure.Database
{

	public abstract class DbContext : IDbContext
	{
		public DbConnection connection { get; private set; }

		public abstract SqlParameter CreateParameter(string name, object value, int? size);

		private DbTransaction txn;

		private readonly List<string> sqlChanges;

		private readonly List<SqlParameter> sqlParameters;

		public string Name { get; private set; }

		public SqlMapper Map { get; private set; }

		public string Delimiter { get; set; }

		public abstract SqlDialect SqlDialect { get; }

		protected abstract DbConnection GetConnection(string connStr);

		protected abstract DbDataAdapter GetDataAdapter();

		protected abstract DbParameter ToDbParameter(SqlParameter parameter);

		protected abstract SqlDbType? GetSqlDbType(MetaProperty metaProperty, out string udtTypeName);

		protected abstract SqlDbType? GetSqlDbType(SqlParameter parameter, out string udtTypeName);

		public abstract object ObjectToDbValue(SqlParameter parameter, SqlDbType sqlDbType, string udtTypeName);

		public abstract object DbValueToObject(object dbValue, MetaProperty metaProperty);

		public bool UseTransaction { get; set; }

		public SqlBuilder CreateSqlBuilder()
		{
			return SqlBuilderFactory.Current.Create(SqlDialect);
		}

		protected DbContext(string name, string connStr, bool useTransaction = false, string delimiter = "split")
		{
			Name = name;
			UseTransaction = useTransaction;
			Delimiter = delimiter;
			Map = new SqlMapper(this);

			connection = GetConnection(connStr);

			if (sqlChanges == null)
				sqlChanges = new List<string>();

			if (sqlParameters == null)
				sqlParameters = new List<SqlParameter>();
		}

		private string ToRawSql(string sql, IEnumerable<SqlParameter> parameters, List<SqlParameter> newParameters)
		{
			if (newParameters != null && parameters != null)
			{
				foreach (var parameter in parameters)
				{
					if ((parameter.Value is string || parameter.Value is byte[]) == false && parameter.Value is IEnumerable)
					{
						var index = 1;
						var newSqlParameters =
							((IEnumerable) parameter.Value).Cast<object>().Select(
								x =>
									new SqlParameter("{0}{1}".FormatWith(parameter.Name, index++), x, parameter.MetaProperty, parameter.Direction,
										parameter.Size)).ToArray();

						newParameters.AddRange(newSqlParameters);
						sql = Regex.Replace(sql, "@" + parameter.Name,
							"({0})".FormatWith(newSqlParameters.Select(x => "@" + x.Name).Join()));
					}
					else
					{
						newParameters.Add(parameter);
					}
				}
			}
			return sql;
		}

		public int SaveChanges()
		{
			var result = 0;
			if (sqlChanges != null && sqlChanges.Count > 0)
			{
				try
				{
					var command = CreateCommand(sqlChanges.Join(Environment.NewLine), sqlParameters);
					result = command.ExecuteNonQuery();
				}
				finally
				{
					sqlChanges.Clear();
					sqlParameters.Clear();
				}
			}
			return result;
		}

		public bool HasChanges()
		{
			return (sqlChanges != null && sqlChanges.Count > 0);
		}

		private void OpenConnection()
		{
			if (connection.State != ConnectionState.Open)
			{
				connection.Open();

				if (UseTransaction)
					txn = connection.BeginTransaction();
			}
		}

		public virtual void Commit()
		{
			if (UseTransaction == false)
				throw new InvalidOperationException("Unable to commit because no transaction was detected");

			txn.Commit();
		}

		public virtual void Rollback()
		{
			if (UseTransaction == false)
				throw new InvalidOperationException("Unable to commit because no transaction was detected");

			txn.Rollback();
		}

		public IEnumerable<T> Query<T>(string sql, IEnumerable<SqlParameter> parameters,
										Func<T, DbResultItem, SqlMapperContext, bool> onTranslatedFunc = null) where T : IEntity, new()
		{
			return Query(sql, onTranslatedFunc, parameters.ToArray());
		}

		public IEnumerable<T> Query<T>(string sql, params SqlParameter[] parameters) where T : IEntity, new()
		{
			return Query<T>(sql, null, parameters.ToArray());
		}

		public IEnumerable<T> Query<T>(string sql, Func<T, DbResultItem, SqlMapperContext, bool> onTranslatedFunc = null,
										params SqlParameter[] parameters) where T : IEntity, new()
		{
			using (var dbResult = new DataTableDbResult(ExecuteDataTable(sql, parameters)))
			{
				return Map.Translate(dbResult, null, onTranslatedFunc);
			}
		}

		public int ExecuteNonQuery(string sql, IEnumerable<SqlParameter> parameters)
		{
			return ExecuteNonQuery(sql, parameters.ToArray());
		}

		public int ExecuteNonQuery(string sql, params SqlParameter[] parameters)
		{
			var command = CreateCommand(sql, parameters);
			return command.ExecuteNonQuery();
		}

		public T ExecuteScalar<T>(string sql, IEnumerable<SqlParameter> parameters)
		{
			return ExecuteScalar<T>(sql, parameters.ToArray());
		}

		public T ExecuteScalar<T>(string sql, params SqlParameter[] parameters)
		{
			return (T) ExecuteScalar(sql, parameters);
		}

		public object ExecuteScalar(string sql, IEnumerable<SqlParameter> parameters)
		{
			return ExecuteScalar(sql, parameters.ToArray());
		}

		public object ExecuteScalar(string sql, params SqlParameter[] parameters)
		{
			var command = CreateCommand(sql, parameters);
			return command.ExecuteScalar();
		}

		public DbDataReader ExecuteDataReader(string sql, IEnumerable<SqlParameter> parameters)
		{
			return ExecuteDataReader(sql, parameters.ToArray());
		}

		public DbDataReader ExecuteDataReader(string sql, params SqlParameter[] parameters)
		{
			var command = CreateCommand(sql, parameters);
			return command.ExecuteReader();
		}

		public DataTable ExecuteDataTable(string sql, IEnumerable<SqlParameter> parameters)
		{
			return ExecuteDataTable(sql, parameters.ToArray());
		}

		public void ExecuteStoredProcedure(string spName, params SqlParameter[] parameters)
		{
			ExecuteNonQuery(String.Concat("exec ", spName), parameters);
		}

		public DataTable ExecuteDataTable(string sql, params SqlParameter[] parameters)
		{
			return ExecuteDataSet(sql, parameters).Tables[0];
		}

		public DataSet ExecuteDataSet(string sql, IEnumerable<SqlParameter> parameters)
		{
			return ExecuteDataSet(sql, parameters.ToArray());
		}

		public DataSet ExecuteDataSet(string sql, params SqlParameter[] parameters)
		{
			var command = CreateCommand(sql, parameters);
			var dataAdapter = GetDataAdapter();
			dataAdapter.SelectCommand = command;

			var dataSet = new DataSet();
			dataAdapter.Fill(dataSet);

			return dataSet;
		}

		private DbCommand CreateCommand(string sql, IEnumerable<SqlParameter> parameters)
		{
			var newParameters = new List<SqlParameter>();
			sql = ToRawSql(sql, parameters, newParameters);

			var commandType = CommandType.Text;
			if (sql.StartsWith("exec", StringComparison.OrdinalIgnoreCase))
			{
				commandType = CommandType.StoredProcedure;
				sql = sql.Substring(5);
			}

			OpenConnection();

			var command = connection.CreateCommand();
			command.CommandText = sql;
			command.Transaction = txn;
			command.CommandType = commandType;
		    command.CommandTimeout = 600;
			command.Parameters.AddRange(newParameters.Select(item =>
			{
				var dbParameter = ToDbParameter(item);
				item.DbParameter = dbParameter;
				return dbParameter;
			}).ToArray());
			return command;
		}

		public void Dispose()
		{
			if (connection != null)
			{
				connection.Close();
				connection.Dispose();
				connection = null;
			}

			if (sqlChanges != null)
				sqlChanges.Clear();

			if (sqlParameters != null)
				sqlParameters.Clear();
		}

	}
}