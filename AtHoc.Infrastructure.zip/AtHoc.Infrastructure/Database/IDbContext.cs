﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Sql;

namespace AtHoc.Infrastructure.Database
{
	public interface IDbContext : IUnitOfWork
	{
		string Name { get; }

		SqlMapper Map { get; }

		string Delimiter { get; set; }

		SqlDialect SqlDialect { get; }

		SqlBuilder CreateSqlBuilder();

		object ObjectToDbValue(Sql.SqlParameter parameter, SqlDbType sqlDbType, string udtTypeName);

		object DbValueToObject(object dbValue, MetaProperty metaProperty);

		IEnumerable<T> Query<T>(string sql, IEnumerable<SqlParameter> parameters,
			Func<T, DbResultItem, SqlMapperContext, bool> onTranslatedFunc = null)
			where T : IEntity, new();

		IEnumerable<T> Query<T>(string sql, params SqlParameter[] parameters)
			where T : IEntity, new();

		IEnumerable<T> Query<T>(string sql, Func<T, DbResultItem, SqlMapperContext, bool> onTranslatedFunc = null,
			params SqlParameter[] parameters)
			where T : IEntity, new();

		int ExecuteNonQuery(string sql, IEnumerable<SqlParameter> parameters);

		int ExecuteNonQuery(string sql, params SqlParameter[] parameters);

		T ExecuteScalar<T>(string sql, IEnumerable<SqlParameter> parameters);

		T ExecuteScalar<T>(string sql, params SqlParameter[] parameters);

		object ExecuteScalar(string sql, IEnumerable<SqlParameter> parameters);

		object ExecuteScalar(string sql, params SqlParameter[] parameters);

		DbDataReader ExecuteDataReader(string sql, IEnumerable<SqlParameter> parameters);

		DbDataReader ExecuteDataReader(string sql, params SqlParameter[] parameters);

		DataTable ExecuteDataTable(string sql, IEnumerable<SqlParameter> parameters);

		DataTable ExecuteDataTable(string sql, params SqlParameter[] parameters);

		DataSet ExecuteDataSet(string sql, IEnumerable<SqlParameter> parameters);

		DataSet ExecuteDataSet(string sql, params SqlParameter[] parameters);

		void Dispose();

		DbConnection connection { get; }

		SqlParameter CreateParameter(string name, object value, int? size = null);
	}
}