﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Sql;
using AtHoc.Infrastructure.Meta;

namespace AtHoc.Infrastructure.Database
{
	public abstract class DbRepository<T, S> : IRepository<T, S>
		where T : IEntity, new()
		where S : EntitySpec
	{
		protected DbContext Context { get; set; }

		protected virtual void TranslateSpec(S spec, SqlBuilder builder, bool query) {}

		protected virtual void TranslateSpecForUpdate(S spec, SqlBuilder builder, bool query) { }

		protected virtual void SetSorting(S spec, SqlBuilder builder)
		{
			string columnToSort = null;
			
			if (spec.OrderByValue.HasValue())
				columnToSort = spec.OrderByValue;
			else if (spec.OrderBy != null)
				columnToSort = builder.Column(spec.OrderBy);


		    if (columnToSort.HasValue())
		    {
                var alias = GetSortFieldAlias(columnToSort);
                builder.OrderBy("{0} {1}".FormatWith(DbUtils.Refine(columnToSort, alias), spec.OrderAsc == false ? "DESC" : "ASC"));
		    }
		}

        /// <summary>
        /// Method to get alias name that can be used in query builder if field is repeting
        /// </summary>
        /// <param name="field">Name of the field on which user is trying to sort data</param>
        /// <returns>Alias name by default this is empty</returns>
	    protected virtual string GetSortFieldAlias(string field)
	    {
	        return string.Empty;
	    }

		protected virtual bool OnItemDataBound(S spec, T obj, DbResultItem resultItem, SqlMapperContext mapContext) { return true;}

		protected DbRepository(IUnitOfWork context)
		{
			this.Context = context as DbContext;

			if (this.Context == null)
				throw new InvalidOperationException("Expected DbContext instance but found {0}".FormatWith(context.GetType()));
		}

		public virtual PagingInfo<T> GetPagingInfo(S spec)
		{
			return new PagingInfo<T> { Data = FindBySpec(spec), Count = CountBySpec(spec) };
		}

		public virtual IEnumerable<T> FindBySpec(S spec)
		{
			SqlString sql;
			var builder = GetSelectBuilder(spec, out sql);

			return this.Context.Query<T>(
				builder.ToRawSql(sql), sql.Parameters,
				(obj, resultItem, mapContext) => this.OnItemDataBound(spec, obj, resultItem, mapContext)
				);
		}

		public T SingleOrDefaultBySpec(S spec)
		{
			return FindBySpec(spec).SingleOrDefault();
		}

		public virtual DataTable GetDataTableBySpec(S spec)
		{
			SqlString sql;
			var builder = GetSelectBuilder(spec, out sql);
			return this.Context.ExecuteDataTable(builder.ToRawSql(sql), sql.Parameters);
		}

		public virtual IDataReader GetDataReaderBySpec(S spec)
		{
			SqlString sql;
			var builder = GetSelectBuilder(spec, out sql);
			return this.Context.ExecuteDataReader(builder.ToRawSql(sql), sql.Parameters);
		}

		public virtual int CountBySpec(S spec)
		{
			var builder = this.Context.CreateSqlBuilder();
			var sql = builder.NewSql("select count(*) as Counter <<from>> <<innerjoin>> <<leftjoin>> <<rightjoin>> <<where>> <<orderby>> <<groupby>> <<having>>");

			this.TranslateSpec(spec, builder, false);

			return this.Context.ExecuteScalar<int>(builder.ToRawSql(sql), sql.Parameters);
		}

		public virtual T FindById(int id)
		{
			var builder = this.Context.CreateSqlBuilder();
			var sql = builder.NewSql("select * <<from>> <<where>>");

			builder.From(builder.Table<T>());

			var whereSql = "{0} = @Id".FormatWith(builder.Column<T>("Id"));
			builder.Where(whereSql, new SqlParameter("Id", id));

			return this.Context.Query<T>(builder.ToRawSql(sql), sql.Parameters).FirstOrDefault();
		}

		public virtual Messages UpdateBySpec(S spec)
		{
			var messages = new Messages();
			try
			{
				var builder = this.Context.CreateSqlBuilder();
				var sql = builder.NewSql("update {0} <<update>> <<from>> <<innerjoin>> <<leftjoin>> <<rightjoin>> <<where>>".FormatWith(builder.Table<T>()));
				this.TranslateSpec(spec, builder, false);
				this.Context.ExecuteNonQuery(builder.ToRawSql(sql), sql.Parameters);
			}
			catch (Exception ex)
			{
				messages.CreateErrorMessage(ex);
			}
			return messages;
		}

		public virtual Messages DeleteBySpec(S spec)
		{
			var messages = new Messages();
			try
			{
				var builder = this.Context.CreateSqlBuilder();
				var sql = builder.NewSql("delete <<from>> <<innerjoin>> <<leftjoin>> <<rightjoin>> <<where>>");
				this.TranslateSpec(spec, builder, false);
				this.Context.ExecuteNonQuery(builder.ToRawSql(sql), sql.Parameters);
			}
			catch (Exception ex)
			{
				messages.CreateErrorMessage(ex);
			}
			return messages;
		}

		public Messages Save(T obj, bool returnId = false)
		{
			return this.Save(obj, returnId, null);
		}

		public virtual Messages Save(T obj, bool returnId = false, params MetaProperty[] idProperties)
		{
			var messages = new Messages();
			if (obj != null)
				try
				{
					if (obj.RuntimeStatus == RuntimeStatus.New)
						messages.Add(this.Insert(obj, returnId));
					else
						messages.Add(this.Update(obj, idProperties));
				}
				catch (Exception ex)
				{
					messages.CreateErrorMessage(ex);
				}
			return messages;
		}

		public Messages Update(T obj)
		{
			return this.Update(obj, null);
		}

		public Messages Delete(int id)
		{
			var messages = new Messages();
			try
			{
				var builder = this.Context.CreateSqlBuilder();
				var sql = builder.NewSql("delete {0} <<where>>".FormatWith(builder.Table<T>()));

				var whereSql = "{0} = @Id".FormatWith(builder.Column<T>("Id"));
				builder.Where(whereSql, new SqlParameter("Id", id));
				this.Context.ExecuteNonQuery(builder.ToRawSql(sql), sql.Parameters);
			}
			catch (Exception ex)
			{
				messages.CreateErrorMessage(ex);
			}
			return messages;
		}

		public Messages Insert(T obj, bool returnId = false)
		{
			var messages = new Messages();
			try
			{
				if (obj == null || obj.RuntimeStatus != RuntimeStatus.New) return messages;
				var metaObject = MetaObject.Get(typeof(T));
				if (metaObject.HasEntityKey() && obj.Get(metaObject.GetEntityKeyName(), 0) != 0 && returnId)
					returnId = false;

				var builder = this.Context.CreateSqlBuilder();
				var sql = builder.NewSql("insert into {0} <<columns>> values <<parameters>>{1}"
					.FormatWith(builder.Table<T>(),
						returnId ? "; select scope_identity()" : ""));

				var keyGenerated = GenerateKey(obj, metaObject);

				BuildInsertQueryColumns(obj, metaObject, builder);

				if (returnId && !keyGenerated)
				{
					var id = this.Context.ExecuteScalar<decimal>(builder.ToRawSql(sql), sql.Parameters);
					obj.Set(metaObject.GetEntityKeyName(), id.ConvertTo<int>(throwException: true));
				}
				else
				{
					this.Context.ExecuteNonQuery(builder.ToRawSql(sql), sql.Parameters);
				}
				if (obj.DirtyProperties != null) obj.DirtyProperties.Clear();
				obj.RuntimeStatus = RuntimeStatus.Loaded;
				messages.CreateSuccessMessage("Object has been created");
			}
			catch (Exception ex)
			{
				messages.CreateErrorMessage(ex);
			}
			return messages;
		}

		private Messages Update(T obj, params MetaProperty[] idProperties)
		{
			var messages = new Messages();
			try
			{
				if (obj == null || obj.RuntimeStatus != RuntimeStatus.Dirty) return messages;
				var metaObject = MetaObject.Get(typeof(T));
				var builder = this.Context.CreateSqlBuilder();
				var sql = builder.NewSql(@"update {0} <<update>> <<where>>".FormatWith(builder.Table<T>()));

				//updated
				var updatedMetaProperty = metaObject["Updated"];
				if (updatedMetaProperty != null && obj.DirtyProperties.ContainsKey("Updated") == false)
					obj.Set("Updated", DateTime.Now);

				var index = 1;
				foreach (var metaProperty in metaObject.Where(x => x.IsPersistable && obj.DirtyProperties.ContainsKey(x.Name)))
				{
					var paramName = "value{0}".FormatWith(index);

					var updateSql = "{0} = @{1}".FormatWith(metaProperty.ColumnName, paramName);
					builder.Update(updateSql, new SqlParameter(paramName, obj.Get(metaProperty.Name, null), metaProperty));
					index++;
				}

				if (idProperties.HasValue())
				{
					foreach (var item in idProperties)
					{
						var whereSql = "{0} = @{1}".FormatWith(item.ColumnName, item.Name);
						builder.Where(whereSql, new SqlParameter(item.Name, obj.Get(item.Name, null)));
					}
				}
				else
				{
					var whereSql = "{0} = @Id".FormatWith(builder.Column<T>("Id"));
					builder.Where(whereSql, new SqlParameter("Id", obj.Get("Id", null)));
				}

				this.Context.ExecuteNonQuery(builder.ToRawSql(sql), sql.Parameters);
				if (obj.DirtyProperties != null) obj.DirtyProperties.Clear();
				obj.RuntimeStatus = RuntimeStatus.Loaded;
				messages.CreateSuccessMessage("Object has been updated");
			}
			catch (Exception ex)
			{
				messages.CreateErrorMessage(ex);
			}
			return messages;
		}

		private bool GenerateKey(T obj, IEnumerable<MetaProperty> metaProperties)
		{
			var keyProperties = metaProperties.Where(x => x.IsPersistable && x.IsKey).ToArray();
			if (!keyProperties.Any())
			{
				return false;
				//throw new InvalidOperationException("There is no attribute key defined");
			}
			if (keyProperties.Many())
			{
				//throw new InvalidOperationException("Can`t generate new sequence. Multiple attribute key defined");
				return false;
			}
			var keyProperty = keyProperties.SingleOrDefault();
			var propertyValue = obj.Get(keyProperty.Name, 0);
			if (propertyValue != 0 || keyProperty.IsIdentity) return false;

			if (!keyProperty.SequenceType.HasValue())
				throw new InvalidOperationException("Key property which is not an identity must have a sequence type or value greater than zero");
			
			var sequenceHelper = new SequenceHelper(Context);
			var keyValue = sequenceHelper.GetSequence(keyProperty.SequenceType);
			if (keyValue < 0)
			{
				throw new InvalidOperationException(String.Format("Can`t generate new sequence for sequence type '{0}'", keyProperty.SequenceType));
			}
			obj.Set(keyProperty.Name, keyValue);
			return true;
		}

		private void BuildInsertQueryColumns(T obj, IEnumerable<MetaProperty> metaProperties, SqlBuilder builder)
		{
			var index = 1;
			foreach (var metaProperty in metaProperties.Where(x => x.IsPersistable && x.IsIdentity == false))
			{
				var paramName = "value{0}".FormatWith(index);
				builder.Columns(metaProperty.ColumnName);
				builder.Parameters("@{0}".FormatWith(paramName),
					new SqlParameter(paramName, obj.Get(metaProperty.Name, null), metaProperty));
				index++; 
			}
		}

		private SqlBuilder GetSelectBuilder(S spec, out SqlString sql)
		{
			var builder = this.Context.CreateSqlBuilder();
			sql = builder.NewSql(
					"select <<selectmodifier>> <<select>> <<from>> <<innerjoin>> <<leftjoin>> <<rightjoin>> <<where>> <<orderby>> <<groupby>> <<having>>");

			this.TranslateSpec(spec, builder, true);
			this.SetSorting(spec, builder);

			if (spec.Page.HasValue)
				builder.Page(spec.Page, spec.PageSize);

			return builder;
		}
	}
}
