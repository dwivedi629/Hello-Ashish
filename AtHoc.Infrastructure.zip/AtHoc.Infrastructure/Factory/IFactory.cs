﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AtHoc.Infrastructure.Factory
{
    public interface IFactory
    {
        object Create(object key);
    }

    public interface IFactory<P, K> : IFactory
    {
        P Create(K key);
    }
}
