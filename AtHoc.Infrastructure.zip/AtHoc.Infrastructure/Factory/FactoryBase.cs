﻿namespace AtHoc.Infrastructure.Factory
{
    public abstract class FactoryBase<P, K> : IFactory<P, K>
    {
        protected abstract P CreateImpl(K key);
        protected abstract K ConvertToKey(object key);

        protected FactoryBase() {}

        public P Create(K key)
        {
            P product = default(P);

            if (key != null)
            {
                return this.CreateImpl(key);
            }

            return product;
        }

        #region IFactory Members
        object IFactory.Create(object key)
        {
            return this.Create(this.ConvertToKey(key));
        }
        #endregion
    }
}
