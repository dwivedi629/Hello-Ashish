﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace AtHoc.Infrastructure.Encryption
{
    public static class CookieEncryption
    {
        public static string Protect(string text)
        {
            if (string.IsNullOrEmpty(text))
                return null;

            var stream = Encoding.UTF8.GetBytes(text);
            return HttpServerUtility.UrlTokenEncode(stream);
        }
        public static string UnProtect(string text)
        {
            if (string.IsNullOrEmpty(text))
                return null;

            var stream = HttpServerUtility.UrlTokenDecode(text);
            return Encoding.UTF8.GetString(stream);
        }
        public static CultureInfo GetCultureInfoByBaseLocale(string value)
        {
            if (!string.IsNullOrEmpty(value))
            {
                var cookie = UnProtect(value);
                try
                {
                    return CultureInfo.CreateSpecificCulture(cookie);
                }
                catch (Exception)
                {

                }
            }
            return System.Threading.Thread.CurrentThread.CurrentUICulture;
        }
    }
}
