﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.Infrastructure.Encryption
{
    public class DefaultCryptoSettings : ICryptoSettings
    {
        public string Password
        {
            get { throw new NotImplementedException(); }
        }

        public byte[] Salt
        {
            get { throw new NotImplementedException(); }
        }
    }
}
