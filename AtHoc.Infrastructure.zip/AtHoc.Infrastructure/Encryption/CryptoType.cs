﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AtHoc.Infrastructure.Encryption
{
    /// <summary>
    /// 
    /// </summary>
    public enum CryptoType
    {
        TripleDESMD5,
        Rijndael,
        OneWayHash
    }
}
