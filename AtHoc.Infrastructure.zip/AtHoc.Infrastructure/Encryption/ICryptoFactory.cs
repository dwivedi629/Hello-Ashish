﻿using AtHoc.Infrastructure.Factory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.Infrastructure.Encryption
{
    public interface ICryptoFactory : IFactory<ICrypto, CryptoType>
    {
    }
}
