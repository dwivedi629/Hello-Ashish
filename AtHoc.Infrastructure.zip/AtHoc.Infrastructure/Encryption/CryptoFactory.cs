﻿using AtHoc.Infrastructure.Ioc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.Infrastructure.Encryption
{
    public static class CryptoFactory
    {
        public static ICryptoFactory Current { get; set; }

        static CryptoFactory()
        {
            CryptoFactory.Current = ServiceLocator.Resolve<ICryptoFactory>();
        }
    }
}
