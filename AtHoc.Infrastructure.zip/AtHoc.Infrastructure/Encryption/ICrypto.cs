﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AtHoc.Infrastructure.Encryption
{
    public interface ICrypto
    {
        string Encrypt(string clearText);
        string Decrypt(string cipherText);
        string Encrypt(string clearText, string pwd, byte[] salt);
        string Decrypt(string cipherText, string pwd, byte[] salt);
    }
}
