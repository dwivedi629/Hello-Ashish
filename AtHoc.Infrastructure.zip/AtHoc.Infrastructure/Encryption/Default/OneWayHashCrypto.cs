﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.Infrastructure.Encryption.Default
{
    public class OneWayHashCrypto : ICrypto
    {
        private ICryptoSettings cryptoSettings = null;

        public OneWayHashCrypto(ICryptoSettings cryptoSettings)
        {
            if (cryptoSettings == null)
                throw new ArgumentNullException("cryptoSettings");

            this.cryptoSettings = cryptoSettings;
        }

        public string Encrypt(string clearText)
        {
            return this.Encrypt(clearText, this.cryptoSettings.Password, this.cryptoSettings.Salt);
        }

        public string Decrypt(string cipherText)
        {
            throw new NotSupportedException("Unable to decrypt because this is a one way cryptography");
        }

        public string Encrypt(string clearText, string pwd, byte[] salt)
        {
            var hasher = new SHA1CryptoServiceProvider();
            var pdb = new Rfc2898DeriveBytes(pwd, salt);

            var textWithSaltBytes = Encoding.UTF8.GetBytes(string.Concat(Encoding.ASCII.GetString(pdb.GetBytes(16)), clearText));
            var hashedBytes = hasher.ComputeHash(textWithSaltBytes);
            hasher.Clear();

            return Convert.ToBase64String(hashedBytes);
        }

        public string Decrypt(string cipherText, string pwd, byte[] salt)
        {
            throw new NotSupportedException("Unable to decrypt because this is a one way cryptography");
        }
    }
}
