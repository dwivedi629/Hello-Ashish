﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AtHoc.Infrastructure.Factory;
using AtHoc.Infrastructure.Encryption.Default;
using AtHoc.Infrastructure.Ioc;

namespace AtHoc.Infrastructure.Encryption.Default
{
    public class DefaultCryptoFactory : FactoryBase<ICrypto, CryptoType>, ICryptoFactory
    {
        private ICryptoSettings cryptoSettings = null;

        public DefaultCryptoFactory(ICryptoSettings cryptoSettings)
        {
            if (cryptoSettings == null)
                throw new ArgumentNullException("cryptoSettings");

            this.cryptoSettings = cryptoSettings;
        }

        protected override ICrypto CreateImpl(CryptoType key)
        {
            ICrypto crypto = null;
            switch (key)
            {
                case CryptoType.TripleDESMD5:
                    crypto = new TripleDESMD5Crypto(this.cryptoSettings);
                    break;
                case CryptoType.Rijndael:
                    crypto = new RijndaelCrypto(this.cryptoSettings);
                    break;
                case CryptoType.OneWayHash:
                    crypto = new OneWayHashCrypto(this.cryptoSettings);
                    break;
                default:
                    throw (new NotSupportedException(string.Format("CryptoType ({0}) not supported", key.ToString())));
            }
            return crypto;
        }

        protected override CryptoType ConvertToKey(object key)
        {
            return (CryptoType)key;
        }
    }
}
