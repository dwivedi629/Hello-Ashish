﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;

namespace AtHoc.Infrastructure.Encryption.Default
{
    public class TripleDESMD5Crypto : ICrypto
    {
        private ICryptoSettings cryptoSettings = null;

        public TripleDESMD5Crypto(ICryptoSettings cryptoSettings)
        {
            if (cryptoSettings == null)
                throw new ArgumentNullException("cryptoSettings");

            this.cryptoSettings = cryptoSettings;
        }

        public string Encrypt(string clearText, string pwd, byte[] salt)
        {
            byte[] buffer = Encoding.ASCII.GetBytes(clearText);
            TripleDESCryptoServiceProvider des = new TripleDESCryptoServiceProvider();
            MD5CryptoServiceProvider MD5 = new MD5CryptoServiceProvider();
            des.Key = MD5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(pwd));
            des.IV = salt;
            string encryptedValue = Convert.ToBase64String(
                des.CreateEncryptor().TransformFinalBlock(
                buffer,
                0,
                buffer.Length
                ));

            return encryptedValue;
        }

        public string Decrypt(string cipherText, string pwd, byte[] salt)
        {
            byte[] buffer = Convert.FromBase64String(cipherText);
            TripleDESCryptoServiceProvider des = new TripleDESCryptoServiceProvider();
            MD5CryptoServiceProvider MD5 = new MD5CryptoServiceProvider();
            des.Key = MD5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(pwd));
            des.IV = salt;

            return Encoding.ASCII.GetString(
                des.CreateDecryptor().TransformFinalBlock(
                buffer,
                0,
                buffer.Length
                )
                );
        }

        public string Encrypt(string clearText)
        {
            return this.Encrypt(clearText, cryptoSettings.Password, cryptoSettings.Salt);
        }

        public string Decrypt(string cipherText)
        {
            return this.Decrypt(cipherText, cryptoSettings.Password, cryptoSettings.Salt);
        }
    }
}
