﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace AtHoc.Infrastructure.Security
{
    public class XmlValidation
    {
        public static XmlDocument ValidateXml (string strXmlDoc)
        {
            var xml = new XmlDocument();
            xml.XmlResolver = null;
            xml.LoadXml(strXmlDoc);
            return xml;
        }

        public static bool IsDocType(XmlDocument xmlDocument)
        {
            if (xmlDocument.DocumentType != null)
            {
                return true;
            }
            return false;
        }

        public static bool ValidateXmlRoot(XmlDocument xmlDoc, string elementName, string attrName, string attrValue)
        {
            return xmlDoc.DocumentElement.Name.ToUpper().Equals(elementName.ToUpper()) &&
                   (xmlDoc.DocumentElement.Attributes[attrName].Value.ToUpper().Equals(attrValue.ToUpper()));

        }
    }
}
