﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Drawing.Imaging;

namespace AtHoc.Infrastructure.Security
{
    public enum FileType
    {
        Audio,
        Image
    }
    public static class FileMimeTypeValidation
    {
        [DllImport(@"urlmon.dll", CharSet = CharSet.Auto)]
        private extern static UInt32 FindMimeFromData(
            UInt32 pBC,
            [MarshalAs(UnmanagedType.LPStr)] String pwzUrl,
            [MarshalAs(UnmanagedType.LPArray)] byte[] pBuffer,
            UInt32 cbSize,
            [MarshalAs(UnmanagedType.LPStr)] String pwzMimeProposed,
            UInt32 dwMimeFlags,
            out UInt32 ppwzMimeOut,
            UInt32 dwReserverd
        );

        private static readonly Dictionary<string, FileType> MimeTypesDictionary = new Dictionary<string, FileType>
        {
            //{"bmp", "image/bmp"},
            {"image/gif", FileType.Image},
            {"image/jpeg", FileType.Image},
            {"image/pjpeg", FileType.Image},
            //{"pdf", "application/pdf"},
            {"image/png", FileType.Image},
            {"audio/wav", FileType.Audio}
        };

        public static string GetMimeFromFile(string filename)
        {
            if (!File.Exists(filename))
                throw new FileNotFoundException(filename + " not found");

            var buffer = new byte[256];
            using (var fs = new FileStream(filename, FileMode.Open))
            {
                if (fs.Length >= 256)
                    fs.Read(buffer, 0, 256);
                else
                    fs.Read(buffer, 0, (int)fs.Length);
            }
            return GetMime(buffer);
        }

        public static string GetMimeFromStream(Stream fileStream)
        {
            var buffer = new byte[256];
            if (fileStream.Length >= 256)
                fileStream.Read(buffer, 0, 256);
            else
                fileStream.Read(buffer, 0, (int)fileStream.Length);
            return GetMime(buffer);
        }


        public static bool ValidateMimeType(Stream fileStream, FileType fileType)
        {
            var fileMimeType = GetMimeFromStream(fileStream);

            fileMimeType = fileMimeType.Contains("x-") ? fileMimeType.Replace("x-", "") : fileMimeType;
            return !string.IsNullOrEmpty(fileMimeType) && MimeTypesDictionary.ContainsKey(fileMimeType) && MimeTypesDictionary[fileMimeType] == fileType;
        }
        private static string GetMime(byte[] buffer)
        {
            try
            {
                UInt32 mimetype;
                FindMimeFromData(0, null, buffer, 256, null, 0, out mimetype, 0);
                var mimeTypePtr = new IntPtr(mimetype);
                var mime = Marshal.PtrToStringUni(mimeTypePtr);
                Marshal.FreeCoTaskMem(mimeTypePtr);
                return mime;
            }
            catch (Exception e)
            {
                return "unknown/unknown";
            }
        }
    }
}
