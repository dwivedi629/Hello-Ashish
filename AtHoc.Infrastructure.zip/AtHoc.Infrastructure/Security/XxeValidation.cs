﻿using System;
using System.Web;
using System.Web.Security.AntiXss;

namespace AtHoc.Infrastructure.Security
{
    public class XxeValidation
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="conversionString"></param>
        /// <returns></returns>
        public static string GetHtmlEncode(string conversionString)
        {
            if (string.IsNullOrEmpty(conversionString))
                return string.Empty;
            return AntiXssEncoder.HtmlEncode(HttpUtility.HtmlDecode(conversionString),false);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="conversionString"></param>
        /// <returns></returns>
        public static string GetUrlEncode(string conversionString)
        {
            if (string.IsNullOrEmpty(conversionString))
                 return string.Empty;
            return AntiXssEncoder.UrlEncode(HttpUtility.UrlDecode(conversionString));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="conversionString"></param>
        /// <returns></returns>
        public static string GetJavascriptEncode(string conversionString)
        {
            return HttpUtility.JavaScriptStringEncode(conversionString);
        }

        public static string GetUrlDecode(string conversionString)
        {
            return HttpUtility.UrlDecode(conversionString);
        }
    }
}
