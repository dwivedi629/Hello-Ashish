﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Meta;

namespace AtHoc.Infrastructure.Sql
{
    #region SqlBuilder
    public abstract class SqlBuilder
    {
        protected static Regex findRegex = new Regex(@"<<.+?>>", RegexOptions.Compiled | RegexOptions.Singleline);
        protected static Regex removeSpacesRegex = new Regex(@"[ ]{2,}", RegexOptions.Compiled | RegexOptions.Singleline);
        protected static HashSet<string> reservedPlaceholderNames = new HashSet<string>(new string[] { "select", "from", "innerjoin", "leftjoin", "rightjoin", "where", "groupby", "orderby", "having", "update" }, StringComparer.OrdinalIgnoreCase);
        protected Dictionary<string, SqlClauses> data = new Dictionary<string, SqlClauses>();

        public int? CurrentPage { get; set; }
        public int PageSize { get; set; }

        private object parameterSeqLock = new object();
        private int parameterSeqIndex = 0;
        private string GetNextParameterName()
        {
            lock (parameterSeqLock)
            {
                return "p{0}".FormatWith(parameterSeqIndex++);
            }
        }

        public SqlBuilder From(string sql, params SqlParameter[] parameters)
        {
            this.AddClause(sql, "from", parameters, null, "from ", null, false);
            return this;
        }

        public SqlBuilder InnerJoin(string sql, params SqlParameter[] parameters)
        {
            this.AddClause(sql, "innerjoin", parameters, " inner join ", "inner join ", null);
            return this;
        }

        public SqlBuilder LeftJoin(string sql, params SqlParameter[] parameters)
        {
            this.AddClause(sql, "leftjoin", parameters, " left join ", "left join ", null);
            return this;
        }

        public SqlBuilder RightJoin(string sql, params SqlParameter[] parameters)
        {
            this.AddClause(sql, "rightjoin", parameters, " right join ", "right join ", null);
            return this;
        }

        public SqlBuilder Where(ISqlString sql)
        {
            return this.Where(this.ToRawSql(sql), sql.Parameters.ToArray());
        }

        public SqlBuilder Where(string sql, string parameterName, object parameterValue)
        {
            return Where(sql, new[] { new SqlParameter(parameterName, parameterValue) });
        }

        public SqlBuilder Where(string sql, SqlParameter parameter)
        {
            return Where(sql, new[] { parameter});
        }

        public SqlBuilder Where(string sql, params SqlParameter[] parameters)
        {
            this.AddClause(sql, "where", parameters, " and ", "where ", null);
            return this;
        }

        public SqlBuilder StartWhereGroup(GroupOperator groupOperator = GroupOperator.And)
        {
            this.AddStartContext("where", (groupOperator == GroupOperator.And) ? " and " : " or ", "(", ")");
            return this;
        }

        public SqlBuilder EndWhereGroup()
        {
            this.AddEndContext("where");
            return this;
        }

        public SqlBuilder OrderBy(string sql, params SqlParameter[] parameters)
        {
            this.AddClause(sql, "orderby", parameters, ", ", "order by ", null);
            return this;
        }

        public SqlBuilder SelectAll(string sql, params SqlParameter[] parameters)
        {
            this.AddClause(sql, "select", parameters, ", null split, ", "", null);
            return this;
        }

        public SqlBuilder SelectAll<T>(string tableAlias = null, string postfix = null,
            bool propertyAlias = true, params SqlParameter[] parameters)
        {
            return this.SelectAll<T>(null, tableAlias, postfix, propertyAlias, parameters);
        }

        public SqlBuilder SelectAll<T>(IEnumerable<MetaProperty> properties, string tableAlias = null, 
            string postfix = null, bool propertyAlias = true, params SqlParameter[] parameters)
        {
            if (properties == null || !properties.Any())
                properties = MetaObject.Get(typeof(T));

            var builder = new StringBuilder();
            foreach (var metaProperty in properties.Where(x => x.IsPersistable))
            {
                if (builder.Length > 0)
                    builder.Append(",");

                if (tableAlias.IsNotNullOrEmpty())
                    builder.Append(tableAlias).Append(".");

                builder.Append(metaProperty.ColumnName);

                if (propertyAlias)
                    builder.Append(" as ").Append(metaProperty.Name);

                if (postfix.IsNotNullOrEmpty())
                    builder.Append(postfix);
            }

            this.AddClause(builder.ToString(), "select", parameters, ", null split, ", "", null);
            return this;
        }

        public SqlBuilder Select(string sql, bool includeSplit = false, params SqlParameter[] parameters)
        {
            this.AddClause(sql, "select", parameters, includeSplit ? ", null split, " : ", ", "", null);
            return this;
        }

        public SqlBuilder SelectModifier(string sql, params SqlParameter[] parameters)
        {
            this.AddClause(sql, "selectmodifier", parameters, " ", "", null);
            return this;
        }

        public SqlBuilder GroupBy(string sql, params SqlParameter[] parameters)
        {
            this.AddClause(sql, "groupby", parameters, ", ", "group by ", null);
            return this;
        }

        public SqlBuilder Update(string sql, params SqlParameter[] parameters)
        {
            this.AddClause(sql, "update", parameters, ", ", "set ", null);
            return this;
        }

        public SqlBuilder Having(string sql, params SqlParameter[] parameters)
        {
            this.AddClause(sql, "having", parameters, "and ", "having ", null);
            return this;
        }

        public SqlBuilder Columns(string sql, params SqlParameter[] parameters)
        {
            this.AddClause(sql, "columns", parameters, ", ", "(", ")");
            return this;
        }

        public SqlBuilder Parameters(string sql, params SqlParameter[] parameters)
        {
            this.AddClause(sql, "parameters", parameters, ", ", "(", ")");
            return this;
        }

        public SqlBuilder Page(int? currentPage, int pageSize = 15)
        {
            var orderByClauses = this.GetClauses("orderby");
            if (orderByClauses == null || orderByClauses.Count == 0)
                throw (new InvalidOperationException("In order to use paging feature, you must provide at least one order by"));

            this.CurrentPage = currentPage;
            this.PageSize = pageSize;
            return this;
        }

        private void AddClause(string sql, string name, SqlParameter[] parameters, string joiner, string prefix = null, string postfix = null, bool multiple = true)
        {
            SqlClauses clauses;
            if (!data.TryGetValue(name, out clauses))
            {
                clauses = new SqlClauses();
                data[name] = clauses;
            }

            clauses.Joiner = joiner;
            clauses.Prefix = prefix;
            clauses.Postfix = postfix;

            if (multiple == false && clauses.Count > 0)
                throw new InvalidOperationException("SqlClause ({0}) cannot have more than multiple instances".FormatWith(name));

            clauses.Add(new SqlClause { Sql = sql, Parameters = parameters });
        }

        private void AddStartContext(string name, string joiner, string prefix = null, string postfix = null)
        {
            SqlClauses clauses;
            if (!data.TryGetValue(name, out clauses))
            {
                clauses = new SqlClauses();
                data[name] = clauses;
            }

            clauses.Add(new SqlStartContext { Joiner = joiner, Prefix = prefix, Postfix = postfix });
        }

        private void AddEndContext(string name)
        {
            SqlClauses clauses = data[name];
            clauses.Add(new SqlEndContext());
        }

        public SqlClauses GetClauses(string name)
        {
            return this.data.ContainsKey(name) ? this.data[name] : null;
        }

        public SqlString NewSql(string sql, params SqlParameter[] parameters)
        {
            return new SqlString(sql, parameters);
        }

        public abstract string ToRawSql(ISqlString sqlString);

        public static string EscapeValueForSqlLike(string value)
        {
            return value.Replace("[", "[[]").Replace("_", "[_]").Replace("'", "''").Replace("%", "[%]");
        }

		public static string EscapeValue(string value)
		{
		    return value.Replace("'", "''");
			//return value.Replace("[", "[[]").Replace("!", "[[!]").Replace("^", "[[^]").Replace("_", "[[_]").Replace("'", "''").Replace("%", "[[%]");

		}

        #region Helper methods to generate SQL from object model
        public string Table<T>(string alias = null)
        {
            var metaObject = MetaObject.Get(typeof(T));

            return alias.IsNotNullOrEmpty()
                ? "{0} {1}".FormatWith(metaObject.TableName, alias)
                : metaObject.TableName;
        }

        public string Column<T>(string propertyName, string table = null, bool aliasWithPropertyName = false)
        {
            return this.Columns(MetaObject.Get(typeof(T)), table, aliasWithPropertyName, SelectMode.Include, new string[] { propertyName });
        }

        public string Column(MetaProperty property, string table = null, bool aliasWithPropertyName = false)
        {
            return this.Columns(property.Parent, table, aliasWithPropertyName, SelectMode.Include, new string[] { property.Name });
        }

        public ISqlString Condition(MetaProperty property, ConditionOperator op, object value,
            string table = null, bool aliasWithPropertyName = false)
        {
            var operatorSql = string.Empty;
            var parameterName = this.GetNextParameterName();

            switch (op)
            {
                case ConditionOperator.Equals:
                    operatorSql = "=";
                    break;
                case ConditionOperator.GreaterThanEquals:
                    operatorSql = ">=";
                    break;
                case ConditionOperator.LessThanEquals:
                    operatorSql = "<=";
                    break;
                case ConditionOperator.GreaterThan:
                    operatorSql = ">";
                    break;
                case ConditionOperator.In:
                    operatorSql = "in";
                    break;
                case ConditionOperator.LessThan:
                    operatorSql = "<";
                    break;
                case ConditionOperator.StartsWith:
                case ConditionOperator.EndsWith:
                case ConditionOperator.Contains:
                    operatorSql = "like";
                    break;
                case ConditionOperator.Empty:
                    operatorSql = "is null";
                    break;
                case ConditionOperator.NotEquals:
                    operatorSql = "!=";
                    break;
                case ConditionOperator.NotGreaterThanEquals:
                    operatorSql = "<";
                    break;
                case ConditionOperator.NotLessThanEquals:
                    operatorSql = ">";
                    break;
                case ConditionOperator.NotGreaterThan:
                    operatorSql = "<=";
                    break;
                case ConditionOperator.NotIn:
                    operatorSql = "not in";
                    break;
                case ConditionOperator.NotLessThan:
                    operatorSql = ">=";
                    break;
                case ConditionOperator.NotStartsWith:
                case ConditionOperator.NotEndsWith:
                case ConditionOperator.NotContains:
                    operatorSql = "not like";
                    break;
                case ConditionOperator.NotEmpty:
                    operatorSql = "is not null";
                    break;
                case ConditionOperator.EqualsWithIsNull:
                    operatorSql = "ISNULL({0}, '') = ";
                    break;
                case ConditionOperator.NotEqualsWithIsNull:
                    operatorSql = "ISNULL({0}, '') <> ";
                    break;
                default:
                    throw (new NotImplementedException("Unknown condition operator ({0})".FormatWith(op)));
            }

            if (value is string)
            {
                switch (op)
                {
                    case ConditionOperator.StartsWith:
                    case ConditionOperator.NotStartsWith:
                        value = "{0}%".FormatWith(value);
                        break;
                    case ConditionOperator.EndsWith:
                    case ConditionOperator.NotEndsWith:
                        value = "%{0}".FormatWith(value);
                        break;
                    case ConditionOperator.Contains:
                    case ConditionOperator.NotContains:
                        value = "%{0}%".FormatWith(value);
                        break;
                    default:
                        break;
                }
            }
            var sql = string.Empty;
            if (op == ConditionOperator.NotEqualsWithIsNull)
            {
                sql = "ISNULL({0}, '') <> @{1}".FormatWith(this.Column(property, table, aliasWithPropertyName),
                    parameterName);
            }
            else if (op == ConditionOperator.EqualsWithIsNull)
            {
                sql = "ISNULL({0}, '') = @{1}".FormatWith(this.Column(property, table, aliasWithPropertyName),
                    parameterName);
            }
            else if (op == ConditionOperator.Empty || op == ConditionOperator.NotEmpty)
            {
                sql = "{0} {1}".FormatWith(this.Column(property, table, aliasWithPropertyName), operatorSql);
            }
            else
            {
                sql = "{0} {1} @{2}".FormatWith(this.Column(property, table, aliasWithPropertyName), operatorSql,
                    parameterName);
            }
            return new SqlString(sql, new SqlParameter(parameterName, value, property));

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="table">This can be actual table name or just an alias</param>
        /// <param name="aliasWithPropertyName"></param>
        /// <param name="mode"></param>
        /// <param name="properties"></param>
        /// <returns></returns>
        private string Columns(MetaObject metaObject, string table, bool aliasWithPropertyName, SelectMode mode, IEnumerable<string> properties)
        {
            var builder = new StringBuilder();

            bool looped = false;
            var propLookup = properties.AsEnumerableEmpty<string>()
                .Where(x => x.IsNotNullOrEmpty())
                .ToLookup(x => x);

            foreach (var property in metaObject
                .Where(x => x.IsPersistable &&
                            (propLookup == null || propLookup.Count == 0 ||
                             (mode == SelectMode.Exclude && propLookup.Contains(x.Name) == false) ||
                             (mode == SelectMode.Include && propLookup.Contains(x.Name)))))
            {
                if (looped)
                    builder.Append(", ");

                if (table.IsNotNullOrEmpty())
                    builder.AppendFormat("{0}.", table);

                builder.Append(property.ColumnName);

                if (aliasWithPropertyName)
                    builder.AppendFormat(" as {0}", property.Name);

                looped = true;
            }

            return builder.ToString();
        }
        #endregion Helper methods to generate SQL from object model
    }
    #endregion SqlBuilder

    #region SqlString
    public interface ISqlString
    {
        string Sql { get; set; }
        IEnumerable<SqlParameter> Parameters { get; set; }
        IEnumerable<SqlParameter> InitParams { get; }
    }

    public class SqlString : ISqlString
    {
        public SqlString(string sql, params SqlParameter[] parameters)
        {
            this.Sql = sql;
            this.InitParams = parameters;
        }

        public string Sql { get; set; }
        public IEnumerable<SqlParameter> InitParams { get; private set; }
        public IEnumerable<SqlParameter> Parameters { get; set; }
    }
    #endregion SqlString

    #region SqlClause
    public class SqlClause
    {
        public string Sql { get; set; }
        public SqlParameter[] Parameters { get; set; }
    }
    #endregion SqlClause

    public class SqlStartContext : SqlClause
    {
        public string Joiner { get; set; }
        public string Prefix { get; set; }
        public string Postfix { get; set; }
    }

    public class SqlEndContext : SqlClause
    {
    }

    #region SqlParameter
    public class SqlParameter
    {
        public SqlParameter(string name, object value,
            MetaProperty metaProperty = null,
            ParameterDirection direction = ParameterDirection.Input,
            int? size = null)
        {
            this.Name = name;
            this.Value = value;
            this.MetaProperty = metaProperty;
            this.Direction = direction;
            this.Size = size;
        }

        public string Name { get; set; }
        public object Value { get; set; }
        public MetaProperty MetaProperty { get; set; }
        public ParameterDirection Direction { get; set; }
        public int? Size { get; set; }
        internal DbParameter DbParameter { private get; set; }
        public object OutputValue
        {
            get { return this.DbParameter == null ? null : this.DbParameter.Value; }
        }
    }
    #endregion SqlParameter

    #region SqlClauses
    public class SqlClauses : List<SqlClause>
    {
        public string Joiner { get; set; }
        public string Prefix { get; set; }
        public string Postfix { get; set; }

        public string ToRawSql(List<SqlParameter> parameters)
        {
            bool? looped = null;
            var builder = new StringBuilder(this.Prefix);
            var groupStack = new Stack<SqlStartContext>();

            foreach (var item in this)
            {
                if (item is SqlStartContext)
                {
                    if (looped == true)
                    {
                        builder.Append(groupStack.Count > 0 ? groupStack.Peek().Joiner : this.Joiner);
                        looped = false;
                    }

                    groupStack.Push(item as SqlStartContext);
                    builder.Append(groupStack.Peek().Prefix);
                }
                else if (item is SqlEndContext)
                {
                    builder.Append(groupStack.Peek().Postfix);
                    groupStack.Pop();
                }
                else
                {
                    if (looped == true)
                        builder.Append(groupStack.Count > 0 ? groupStack.Peek().Joiner : this.Joiner);
                    
                    builder.Append(item.Sql);

                    if (parameters != null)
                        parameters.AddRange(item.Parameters);

                    looped = true;
                }
            }

            builder.Append(this.Postfix);
            return builder.ToString();
        }
    }
    #endregion SqlClauses

    #region SelectMode
    public enum SelectMode
    {
        Include,
        Exclude
    }
    #endregion SelectMode
}
