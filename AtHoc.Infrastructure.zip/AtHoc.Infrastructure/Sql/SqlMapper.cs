﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Common;
using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Collections;
using AtHoc.Infrastructure.Database;
using System.Text.RegularExpressions;

namespace AtHoc.Infrastructure.Sql
{
    public class SqlMapper
    {
        private static Regex TrimEndNumeric = new Regex("[0-9]+$", RegexOptions.Compiled | RegexOptions.Singleline);
        private DbContext context = null;

        public SqlMapper(DbContext context)
        {
            this.context = context;
        }

        public IEnumerable<T> Translate<T>(DbResult result, SqlMapperContext mapContext, Func<T, DbResultItem, SqlMapperContext, bool> onTranslatedFunc = null)
            where T : IEntity, new()
        {
            return result.Select(x => this.Translate<T>(x, mapContext, onTranslatedFunc));
        }

        public void CompleteTranslation(DbResultItem resultItem, SqlMapperContext mapContext)
        {
            for (; mapContext.CurrentRowIndex < resultItem.Count; mapContext.CurrentRowIndex++)
            {
                var columnName = resultItem.Parent.ColumnNames[mapContext.CurrentRowIndex];
                if (columnName.StartsWith(this.context.Delimiter, StringComparison.OrdinalIgnoreCase))
                    break;
            }
        }

        public T Translate<T>(DbResultItem resultItem, SqlMapperContext mapContext = null, Func<T, DbResultItem, SqlMapperContext, bool> onTranslatedFunc = null)
            where T : IEntity, new()
        {
            T instance = default(T);
            if (resultItem != null)
            {
                if (mapContext == null)
                    mapContext = new SqlMapperContext();

                var type = typeof(T);
                var metaObject = MetaObject.Get(type);
                var columnNameLookup = metaObject.ToLookup(x => x.ColumnName, StringComparer.OrdinalIgnoreCase);
                var looped = false;
                var hasValue = false;

                //create new instance
                instance = new T();

                //populate object
                for (; mapContext.CurrentRowIndex < resultItem.Count; mapContext.CurrentRowIndex++)
                {
                    var columnName = resultItem.Parent.ColumnNames[mapContext.CurrentRowIndex];

                    //do I need to make sure column name is REALLY Id post fixed with numbers
                    if (looped && columnName.StartsWith(this.context.Delimiter, StringComparison.OrdinalIgnoreCase))
                        break;

                    //check column name
                    if (columnNameLookup.Contains(columnName) == false)
                        columnName = TrimEndNumeric.Replace(columnName, "");

                    var metaProperty = (columnNameLookup.Contains(columnName))
                        ? columnNameLookup[columnName].First()
                        : metaObject[columnName];

                    if (metaProperty != null)
                    {
                        var value = this.context.DbValueToObject(resultItem[mapContext.CurrentRowIndex], metaProperty);

                        if (value != null)
                            hasValue = true;

                        instance.Set(metaProperty.Name, value);
                    }

                    looped = true;
                }

                if (instance != null)
                {
                    if (hasValue == false)
                    {
                        instance = default(T);
                    }
                    else 
                    {
                        //runtime status
                        instance.RuntimeStatus = RuntimeStatus.Loaded;
                        if (instance.DirtyProperties != null)
                            instance.DirtyProperties.Clear();
                    }
                }

                //multiple map
                if (onTranslatedFunc != null)
                {
                    onTranslatedFunc(instance, resultItem, mapContext);
                    instance.RuntimeStatus = RuntimeStatus.Loaded;
                    if (instance.DirtyProperties != null)
                        instance.DirtyProperties.Clear();
                }
            }

            return instance;
        }
    }

    #region SqlMapperContext
    public class SqlMapperContext
    {
        public int CurrentRowIndex { get; set; }
    }
    #endregion SqlMapperContext

    #region DbResult
    public abstract class DbResult : IEnumerable<DbResultItem>, IDisposable
    {
        public abstract string[] ColumnNames { get; }
        public abstract IEnumerator<DbResultItem> GetEnumerator();

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        public abstract void Dispose();
    }
    #endregion DbResult

    #region DbResultItem
    public abstract class DbResultItem
    {
        public DbResultItem(DbResult parent)
        {
            if (parent == null)
                throw new ArgumentNullException("Parent cannot be null.");

            this.Parent = parent;
        }

        public DbResult Parent { get; private set; }
        public abstract object this[string columnName] { get; }
        public abstract object this[int index] { get; }
        public abstract int Count { get; }
    }
    #endregion DbResultItem

    #region DataTableDbResult
    public class DataTableDbResult : DbResult, IDisposable
    {
        private DataTable dataTable = null;
        private string[] columnNames = null;

        public DataTableDbResult(DataTable dataTable)
        {
            if (dataTable == null) throw (new ArgumentNullException("DataSet cannot be null."));

            this.dataTable = dataTable;
        }

        public override string[] ColumnNames
        {
            get
            {
                if (this.columnNames == null)
                {
                    this.columnNames = this.dataTable.Columns
                        .Cast<DataColumn>()
                        .Select(x => x.ColumnName)
                        .ToArray();
                }
                return this.columnNames;
            }
        }

        public override IEnumerator<DbResultItem> GetEnumerator()
        {
            return new EnumeratorConverter<DbResultItem>(this.dataTable.Rows.GetEnumerator(),
                x => new DataTableDbResultItem(this, (DataRow)x));
        }

        public override void Dispose()
        {
            this.dataTable.Dispose();
        }
    }
    #endregion DataTableDbResult

    #region DataTableDbResultItem
    public class DataTableDbResultItem : DbResultItem
    {
        private DataRow dataRow = null;

        public DataTableDbResultItem(DataTableDbResult parent, DataRow dataRow)
            : base(parent)
        {
            this.dataRow = dataRow;
        }

        public override object this[string columnName]
        {
            get { return this.dataRow[columnName]; }
        }

        public override object this[int index]
        {
            get { return this.dataRow[index]; }
        }

        public override int Count
        {
            get { return this.dataRow.Table.Columns.Count; }
        }
    }
    #endregion DataTableDbResultItem

    #region DataReaderDbResult
    public class DataReaderDbResult : DbResult
    {
        private DbDataReader dataReader = null;
        private string[] columnNames = null;

        internal DataReaderDbResult(DbDataReader dataReader)
        {
            this.dataReader = dataReader;
        }

        public override string[] ColumnNames
        {
            get
            {
                if (this.columnNames == null)
                {
                    this.columnNames = new string[this.dataReader.FieldCount];
                    for (int i = 0; i < this.dataReader.FieldCount; i++)
                        this.columnNames[i] = this.dataReader.GetName(i);

                }
                return this.columnNames;
            }
        }

        public override IEnumerator<DbResultItem> GetEnumerator()
        {
            return new EnumeratorConverter<DbResultItem>(this.dataReader.GetEnumerator(),
                x => new DataReaderDbResultItem(this, this.dataReader));
        }

        public override void Dispose()
        {
            this.dataReader.Dispose();
        }
    }
    #endregion DataReaderDbResult

    #region DataReaderDbResultItem
    public class DataReaderDbResultItem : DbResultItem
    {
        private DataReaderDbResult parent = null;
        private DbDataReader dataReader = null;

        public DataReaderDbResultItem(DataReaderDbResult parent, DbDataReader dataReader)
            : base(parent)
        {
            this.parent = parent;
            this.dataReader = dataReader;
        }

        public override object this[string columnName]
        {
            get { return this.dataReader[columnName]; }
        }

        public override object this[int index]
        {
            get { return this.dataReader[index]; }
        }

        public override int Count
        {
            get { return this.dataReader.FieldCount; }
        }
    }
    #endregion DataReaderDbResultItem
}
