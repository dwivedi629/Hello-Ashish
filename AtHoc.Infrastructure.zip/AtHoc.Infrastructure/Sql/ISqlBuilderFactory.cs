﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Factory;

namespace AtHoc.Infrastructure.Sql
{
    public interface ISqlBuilderFactory : IFactory<SqlBuilder, SqlDialect>
    {

    }
}
