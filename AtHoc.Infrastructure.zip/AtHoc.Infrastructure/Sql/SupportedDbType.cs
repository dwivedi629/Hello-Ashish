﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.Infrastructure.Sql
{
    public partial class SupportedDbType
    {
        public const string Bit = "bit";
        public const string UniqueIdentifier = "uniqueidentifier";
        public const string DateTime = "datetime";
        public const string DateTime2 = "datetime2";
        public const string Int = "int";
        public const string SmallInt = "smallint";
        public const string Decimal = "decimal";
        public const string BigInt = "bigint";
        public const string VarChar = "varchar";
        public const string Text = "text";
        public const string NText = "ntext";
    }
}
