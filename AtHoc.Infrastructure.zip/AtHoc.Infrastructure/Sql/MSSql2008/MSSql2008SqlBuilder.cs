﻿using System;
using System.Text;
using System.Collections.Generic;

namespace AtHoc.Infrastructure.Sql.MSSql2008
{
    public class MSSql2008SqlBuilder : SqlBuilder
    {
        public override string ToRawSql(ISqlString sqlString)
        {
            var parameters = new List<SqlParameter>(sqlString.InitParams);
            sqlString.Parameters = parameters;

            var rawSql = findRegex.Replace(sqlString.Sql, match =>
            {
                var key = match.Value.Trim('<', '>');
                if (key.IsNotNullOrEmpty())
                {
                    var clauses = this.GetClauses(key);

                    return (clauses != null && (key != "orderby" || this.CurrentPage == null))
                        ? clauses.ToRawSql(parameters)
                        : null;
                }
                return null;
            }).Trim();

            rawSql = removeSpacesRegex.Replace(rawSql, " ");

            if (this.CurrentPage.HasValue)
            {
                var orderByClauses = this.GetClauses("orderby");

                if (orderByClauses != null &&
                    orderByClauses.Count > 0)
                {
                    if (rawSql.StartsWith("select", StringComparison.OrdinalIgnoreCase))
                    {
                        var sql = new StringBuilder(rawSql);
                        var startRowNum = (this.CurrentPage - 1) * this.PageSize + 1;
                        var stopRowNum = this.CurrentPage * this.PageSize;

                        sql.Replace("select", "select ROW_NUMBER() OVER ({0}) as RowNum,".FormatWith(orderByClauses.ToRawSql(null)), 0, 6);
                        sql.Insert(0, "select * from (");
                        sql.Append(") Results where RowNum between @StartRowNum and @StopRowNum");

                        parameters.Add(new SqlParameter("StartRowNum", startRowNum));
                        parameters.Add(new SqlParameter("StopRowNum", stopRowNum));

                        rawSql = sql.ToString();
                    }
                    else
                    {
                        throw (new InvalidOperationException("Paging feature can only be applied to select statement"));
                    }
                }
            }
            return rawSql;
        }
    }
}
