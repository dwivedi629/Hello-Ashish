﻿using System;

using AtHoc.Infrastructure.Factory;
using AtHoc.Infrastructure.Sql.MSSql2008;

namespace AtHoc.Infrastructure.Sql
{
    public class DefaultSqlBuilderFactory : FactoryBase<SqlBuilder, SqlDialect>, ISqlBuilderFactory
    {
        protected override SqlBuilder CreateImpl(SqlDialect key)
        {
            switch (key)
            {
                case SqlDialect.MSSql2008:
                    return new MSSql2008SqlBuilder();
                default:
                    throw (new NotSupportedException("Dialect ({0}) is not currently supported".FormatWith(key)));
            }
        }

        protected override SqlDialect ConvertToKey(object key)
        {
            return (SqlDialect)key;
        }
    }
}
