﻿using AtHoc.Infrastructure.Ioc;

namespace AtHoc.Infrastructure.Sql
{
    public static class SqlBuilderFactory
    {
        static SqlBuilderFactory()
        {
            Current = ServiceLocator.Resolve<ISqlBuilderFactory>();
        }

        public static ISqlBuilderFactory Current { get; private set; }
    }
}
