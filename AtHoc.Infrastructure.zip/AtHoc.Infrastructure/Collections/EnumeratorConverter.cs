﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.Infrastructure.Collections
{
    /// <summary>
    /// 
    /// </summary>
    public class EnumeratorConverter<T> : IEnumerator<T>
    {
        private IEnumerator enumerator = null;
        private Func<object, T> converterFunc = null;

        public EnumeratorConverter(IEnumerator enumerator, Func<object, T> converterFunc = null)
        {
            this.enumerator = enumerator;
            this.converterFunc = converterFunc;
        }

        public T Current
        {
            get
            {
                return this.converterFunc == null
                    ? (T)this.enumerator.Current
                    : this.converterFunc(this.enumerator.Current);
            }
        }

        public void Dispose()
        {
        }

        object IEnumerator.Current
        {
            get { return this.Current; }
        }

        public bool MoveNext()
        {
            return this.enumerator.MoveNext();
        }

        public void Reset()
        {
            this.enumerator.Reset();
        }
    }
}
