﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.Infrastructure.Validation
{
    public class EmailValidation : RuleValidationAttribute
    {
        private StringValidation validation = new StringValidation();

        public EmailValidation()
        {
            this.validation.MatchInRegexPattern = @"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*";
        }

        protected override ValidationResult IsValidImpl(object value, ValidationContext validationContext)
        {
            return validation.GetValidationResult(value, validationContext);
        }
    }
}
