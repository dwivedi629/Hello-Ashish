﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Resources;

namespace AtHoc.Infrastructure.Validation
{
    public interface IValidatorService
    {
        Messages ValidateObject(object instance, ValidationContext validationContext = null, Messages messages = null, 
            ValidationMode mode = ValidationMode.PropertiesThenClass, params string[] excludeProperties);

        Messages ValidateObject(object instance, string ruleName, ValidationContext validationContext = null, Messages messages = null,
            ValidationMode mode = ValidationMode.PropertiesThenClass, params string[] excludeProperties);

        Messages ValidateObject(object instance, string[] ruleNames, ValidationContext validationContext = null, Messages messages = null,
            ValidationMode mode = ValidationMode.PropertiesThenClass, params string[] excludeProperties);
    }

    #region ValidationMode
    public enum ValidationMode
    {
        All,
        ClassOnly,
        PropertiesOnly,
        ClassThenProperties,
        PropertiesThenClass
    }
    #endregion ValidationMode
}
