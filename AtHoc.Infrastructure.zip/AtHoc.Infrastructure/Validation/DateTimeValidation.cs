﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Resources;

namespace AtHoc.Infrastructure.Validation
{
    public class DateTimeValidation : RuleValidationAttribute
    {
        public DateTime GreaterThan { get; set; }
        public string GreaterThanErrorMessage { get; set; }
        public DateTime GreaterThanOrEquals { get; set; }
        public string GreaterThanOrEqualsErrorMessage { get; set; }
        public DateTime LessThan { get; set; }
        public string LessThanErrorMessage { get; set; }
        public DateTime LessThanOrEquals { get; set; }
        public string LessThanOrEqualsErrorMessage { get; set; }

        public DateTimeValidation()
        {
            this.GreaterThan = DateTime.MinValue;
            this.GreaterThanOrEquals = DateTime.MinValue;
            this.LessThan = DateTime.MinValue;
            this.LessThanOrEquals = DateTime.MinValue;

            var resourceManager = this.GetResourceManager(DefaultResources.ResourceManager);
            this.GreaterThanErrorMessage = resourceManager.GetString("Validation_MustBeGreaterThan");
            this.GreaterThanOrEqualsErrorMessage = resourceManager.GetString("Validation_MustBeGreaterThanOrEquals");
            this.LessThanErrorMessage = resourceManager.GetString("Validation_MustBeLessThan");
            this.LessThanOrEqualsErrorMessage = resourceManager.GetString("Validation_MustBeLessThanOrEquals");
        }

        protected override ValidationResult IsValidImpl(object value, ValidationContext validationContext)
        {
            var result = ValidationResult.Success;
            var displayName = validationContext.DisplayName.IsNullOrEmpty() ? "Property" : validationContext.DisplayName;
            var strValue = value.ConvertTo<string>();

            string[] memberNames = null;
            if (validationContext.MemberName.IsNotNullOrEmpty())
                memberNames = new string[] { validationContext.MemberName };

            var dateTimeValue = value.ConvertTo<DateTime>();

            if (this.GreaterThan > DateTime.MinValue &&
                dateTimeValue <= this.GreaterThan)
            {
                result = new ValidationResult(this.GreaterThanErrorMessage
                    .FormatWith(displayName, this.GreaterThan.ToString("d")), memberNames);
            }

            if (this.GreaterThanOrEquals > DateTime.MinValue &&
                dateTimeValue < this.GreaterThanOrEquals)
            {
                result = new ValidationResult(this.GreaterThanOrEqualsErrorMessage
                    .FormatWith(displayName, this.GreaterThanOrEquals.ToString("d")), memberNames);
            }

            if (this.LessThan > DateTime.MinValue &&
                dateTimeValue >= this.LessThan)
            {
                result = new ValidationResult(this.LessThanErrorMessage
                    .FormatWith(displayName, this.LessThan.ToString("d")), memberNames);
            }

            if (this.LessThanOrEquals > DateTime.MinValue &&
                dateTimeValue > this.LessThanOrEquals)
            {
                result = new ValidationResult(this.LessThanOrEqualsErrorMessage
                    .FormatWith(displayName, this.LessThanOrEquals.ToString("d")), memberNames);
            }

            return result;
        }
    }
}
