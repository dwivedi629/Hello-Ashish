﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Ioc;

namespace AtHoc.Infrastructure.Validation
{
    public static class ValidatorService
    {
        public static IValidatorService Current { get; private set; }

        static ValidatorService()
        {
            ValidatorService.Current = ServiceLocator.Resolve<IValidatorService>();
        }
    }
}
