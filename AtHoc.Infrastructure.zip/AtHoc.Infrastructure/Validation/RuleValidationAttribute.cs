﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.Infrastructure.Validation
{
    public abstract class RuleValidationAttribute : ValidationAttribute
    {
        public string RuleName { get; set; }
        protected abstract ValidationResult IsValidImpl(object value, ValidationContext validationContext);

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var rulesNames = (this.RuleName.IsNotNullOrEmpty() && validationContext.Items.ContainsKey("RuleNames")) 
                ? validationContext.Items["RuleNames"] as string[] 
                : null;

            if (rulesNames == null ||
                rulesNames.Contains(this.RuleName, StringComparer.OrdinalIgnoreCase))
            {
                return this.IsValidImpl(value, validationContext);
            }

            return ValidationResult.Success;
        }    
    }
}
