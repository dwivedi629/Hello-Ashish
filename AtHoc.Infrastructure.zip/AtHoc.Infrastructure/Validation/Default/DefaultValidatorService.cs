﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Accessor;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Resources;

namespace AtHoc.Infrastructure.Validation.Default
{
    public class DefaultValidatorService : IValidatorService
    {
        public Messages ValidateObject(object instance, ValidationContext validationContext = null, Messages messages = null,
            ValidationMode mode = ValidationMode.PropertiesThenClass, params string[] excludeProperties)
        {
            return this.ValidateObject(instance, (string[])null, validationContext, messages, mode, excludeProperties);
        }

        public Messages ValidateObject(object instance, string ruleName, ValidationContext validationContext = null, Messages messages = null,
            ValidationMode mode = ValidationMode.PropertiesThenClass, params string[] excludeProperties)
        {
            return this.ValidateObject(instance, new string[] { ruleName }, validationContext, messages, mode, excludeProperties);
        }

        public Messages ValidateObject(object instance, string[] ruleNames, ValidationContext validationContext = null, Messages messages = null, 
            ValidationMode mode = ValidationMode.PropertiesThenClass, params string[] excludeProperties)
        {
            if (messages == null)
                messages = new Messages();

            switch (mode)
            {
                case ValidationMode.All:
                    this.ValidateClass(instance, validationContext, messages, ruleNames);
                    this.ValidateProperties(instance, validationContext, messages, ruleNames, excludeProperties);
                    break;
                case ValidationMode.ClassOnly:
                    this.ValidateClass(instance, validationContext, messages, ruleNames);
                    break;
                case ValidationMode.ClassThenProperties:
                    this.ValidateClass(instance, validationContext, messages, ruleNames);
                    if (messages.NoErrors())
                        this.ValidateProperties(instance, validationContext, messages, ruleNames, excludeProperties);
                    break;
                case ValidationMode.PropertiesOnly:
                    this.ValidateProperties(instance, validationContext, messages, ruleNames, excludeProperties);
                    break;
                case ValidationMode.PropertiesThenClass:
                    this.ValidateProperties(instance, validationContext, messages, ruleNames, excludeProperties);
                    if (messages.NoErrors())
                        this.ValidateClass(instance, validationContext, messages, ruleNames);
                    break;
                default:
                    throw new NotImplementedException("Not implemented mode ({0})".FormatWith(mode));
            }

            return messages;
        }

        private void ValidateClass(object instance, ValidationContext validationContext, Messages messages, string[] ruleNames)
        {
            if (instance == null)
                throw new ArgumentNullException("instance");

            if (validationContext == null)
                validationContext = new ValidationContext(instance);

            if (ruleNames != null && ruleNames.Length > 0)
                validationContext.Items["RuleNames"] = ruleNames;

            var metaObject = MetaObject.Get(instance.GetType());
            var validationResults = new List<ValidationResult>();
            var validations = (ruleNames == null || ruleNames.Length == 0)
                ? metaObject.ValidationAttributes.Where(x => (x is RuleValidationAttribute) == false || (x as RuleValidationAttribute).RuleName.IsNullOrEmpty())
                : metaObject.ValidationAttributes.Where(x => x is RuleValidationAttribute && ruleNames.Contains((x as RuleValidationAttribute).RuleName, StringComparer.OrdinalIgnoreCase));

            foreach (var validation in validations)
            {
                messages.Add(validation.GetValidationResult(instance, validationContext));
            }
        }

        private void ValidateProperties(object instance, ValidationContext validationContext,
            Messages messages, string[] ruleNames, string[] excludeProperties)
        {
            if (instance == null)
                throw new ArgumentNullException("instance");

            if (validationContext == null)
                validationContext = new ValidationContext(instance, null, null);

            if (ruleNames != null && ruleNames.Length > 0)
                validationContext.Items["RuleNames"] = ruleNames;

            var metaObject = MetaObject.Get(instance.GetType());
            var validationResults = new List<ValidationResult>();

            foreach (var metaProperty in metaObject)
            {
                validationContext.MemberName = metaProperty.Name;
                validationContext.DisplayName = metaProperty.Name;
                var propertyValue = AccessorService.Current.Get(instance, metaProperty.Name, null);
                var validations = (ruleNames == null || ruleNames.Length == 0)
                    ? metaProperty.ValidationAttributes.Where(x => (x is RuleValidationAttribute) == false || (x as RuleValidationAttribute).RuleName.IsNullOrEmpty())
                    : metaProperty.ValidationAttributes.Where(x => x is RuleValidationAttribute && ruleNames.Contains((x as RuleValidationAttribute).RuleName, StringComparer.OrdinalIgnoreCase));

                foreach (var validation in validations)
                {
                    messages.Add(validation.GetValidationResult(propertyValue, validationContext));
                }
            }

            if (validationResults.Count > 0)
                messages.Add(validationResults);
        }
    }
}
