﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Resources;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Resources;

namespace AtHoc.Infrastructure.Validation
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = true)]
    public class NumberValidation : RuleValidationAttribute
    {
        public string IsInvalidNumberMessage { get; set; }
        public bool IsPositiveOnly { get; set; }
        public string IsPositiveOnlyErrorMessage { get; set; }
        public double GreaterThan { get; set; }
        public string GreaterThanErrorMessage { get; set; }
        public double GreaterThanOrEquals { get; set; }
        public string GreaterThanOrEqualsErrorMessage { get; set; }
        public double LessThan { get; set; }
        public string LessThanErrorMessage { get; set; }
        public double LessThanOrEquals { get; set; }
        public string LessThanOrEqualsErrorMessage { get; set; }
        public bool UseEmptyValue { get; set; }
        public double EmptyValue { get; set; }

        public NumberValidation()
        {
            this.GreaterThan = double.MinValue;
            this.GreaterThanOrEquals = double.MinValue;
            this.LessThan = double.MinValue;
            this.LessThanOrEquals = double.MinValue;

            var resourceManager = this.GetResourceManager(DefaultResources.ResourceManager);
            this.IsInvalidNumberMessage = resourceManager.GetString("Validation_InvalidNumber");
            this.IsPositiveOnlyErrorMessage = resourceManager.GetString("Validation_PositiveOnly");
            this.GreaterThanErrorMessage = resourceManager.GetString("Validation_MustBeGreaterThan");
            this.GreaterThanOrEqualsErrorMessage = resourceManager.GetString("Validation_MustBeGreaterThanOrEquals");
            this.LessThanErrorMessage = resourceManager.GetString("Validation_MustBeLessThan");
            this.LessThanOrEqualsErrorMessage = resourceManager.GetString("Validation_MustBeLessThanOrEquals");            
        }

        protected override ValidationResult IsValidImpl(object value, ValidationContext validationContext)
        {
            var result = ValidationResult.Success;
            var displayName = validationContext.DisplayName.IsNullOrEmpty() ? "Property" : validationContext.DisplayName;
            var strValue = value.ConvertTo<string>();

            string[] memberNames = null;
            if (validationContext.MemberName.IsNotNullOrEmpty())
                memberNames = new string[] { validationContext.MemberName };

            var number = value.ConvertTo<double>();

            if (this.IsPositiveOnly &&
                number < 0)
            {
                result = new ValidationResult(this.IsPositiveOnlyErrorMessage
                    .FormatWith(displayName), memberNames);
            }

            if (this.GreaterThan > double.MinValue &&
                number <= this.GreaterThan)
            {
                result = new ValidationResult(this.GreaterThanErrorMessage
                    .FormatWith(displayName, this.GreaterThan), memberNames);
            }

            if (this.GreaterThanOrEquals > double.MinValue &&
                number < this.GreaterThanOrEquals)
            {
                result = new ValidationResult(this.GreaterThanOrEqualsErrorMessage
                    .FormatWith(displayName, this.GreaterThanOrEquals), memberNames);
            }

            if (this.LessThan > double.MinValue &&
                number >= this.LessThan)
            {
                result = new ValidationResult(this.LessThanErrorMessage
                    .FormatWith(displayName, this.LessThan), memberNames);
            }

            if (this.LessThanOrEquals > int.MinValue &&
                number > this.LessThanOrEquals)
            {
                result = new ValidationResult(this.LessThanOrEqualsErrorMessage
                    .FormatWith(displayName, this.LessThanOrEquals), memberNames);
            }

            return result;
        }
    }
}
