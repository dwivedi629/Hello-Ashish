﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Resources;

namespace AtHoc.Infrastructure.Validation
{
    public class StringValidation : RuleValidationAttribute
    {
        public int MaxLength { get; set; }
        public string MaxLengthErrorMessage { get; set; }
        public int MinLength { get; set; }
        public string MinLengthErrorMessage { get; set; }
        public string MatchInRegexPattern { get; set; }
        public string MatchInRegexErrorMessage { get; set; }
        public string NotMatchInRegexPattern { get; set; }
        public string NotMatchInRegexErrorMessage { get; set; }

        public StringValidation()
        {
            this.MinLength = int.MinValue;
            this.MaxLength = int.MinValue;

            var resourceManager = this.GetResourceManager(DefaultResources.ResourceManager);
            this.MaxLengthErrorMessage = resourceManager.GetString("Validation_MoreThanMaxLength");
            this.MinLengthErrorMessage = resourceManager.GetString("Validation_LessThanMinLength");
            this.MatchInRegexErrorMessage = resourceManager.GetString("Validation_InvalidField");
            this.NotMatchInRegexErrorMessage = resourceManager.GetString("Validation_InvalidField");
        }

        protected override ValidationResult IsValidImpl(object value, ValidationContext validationContext)
        {
            var result = ValidationResult.Success;
            var displayName = validationContext.DisplayName.IsNullOrEmpty() ? "Property" : validationContext.DisplayName;
            string strValue = value.ConvertTo<string>();

            string[] memberNames = null;
            if (validationContext.MemberName.IsNotNullOrEmpty())
                memberNames = new string[] { validationContext.MemberName };

            if (strValue.IsNotNullOrEmpty())
            {
                if (this.MaxLength > int.MinValue &&
                    strValue.Length > this.MaxLength)
                {
                    result = new ValidationResult(this.MaxLengthErrorMessage.FormatWith(displayName, this.MaxLength), memberNames);
                }

                if (this.MinLength > int.MinValue &&
                    this.MinLength > strValue.Length)
                {
                    result = new ValidationResult(this.MinLengthErrorMessage.FormatWith(displayName, this.MinLength), memberNames);
                }

                if (this.MatchInRegexPattern.IsNotNullOrEmpty() &&
                    Regex.Match(strValue, this.MatchInRegexPattern, RegexOptions.Compiled).Success == false)
                {
                    result = new ValidationResult(this.MatchInRegexErrorMessage.FormatWith(displayName), memberNames);
                }

                if (this.NotMatchInRegexPattern.IsNotNullOrEmpty() &&
                    Regex.Match(strValue, this.NotMatchInRegexPattern, RegexOptions.Compiled).Success)
                {
                    result = new ValidationResult(this.NotMatchInRegexErrorMessage.FormatWith(displayName), memberNames);
                }
            }

            return result;
        }
    }
}
