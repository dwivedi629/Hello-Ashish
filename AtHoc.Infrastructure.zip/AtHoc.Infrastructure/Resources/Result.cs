﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.Infrastructure.Resources
{
    public class Result<T>
    {
        public T Value { get; set; }
        public Messages Messages { get; set; }

        public Result(T value, Messages messages)
        {
            this.Value = value;
            this.Messages = messages;
        }
    }
}
