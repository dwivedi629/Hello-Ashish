﻿using System;
using System.Web;
using System.Threading;

using AtHoc.Diagnostics;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Log.EventLog;
using AtHoc.Operators;
using AtHoc.Runtime;
using AtHoc.Infrastructure.Resources;
using System.Configuration;

namespace AtHoc.Infrastructure.SessionWrapper
{
    public static class SessionActivityHandler
    {
        #region Cache singletone
        private static ProcessCache _sessionActivityCache;
        private static readonly object _syncRoot = new object();
        private static ProcessCache SessionActivityCache
        {
            get
            {
                if (_sessionActivityCache == null)
                    lock (_syncRoot)
                        if (_sessionActivityCache == null)
                        {
                            var configuration = new ProcessCacheConfiguration
                                {
                                    DefaultExpiration = TimeSpan.FromSeconds(5),
                                    DefaultExpirationType = ExpirationType.Absolute,
                                    Name = "SESSION_ACTIVITY_CACHE"
                                };
                            _sessionActivityCache = new ProcessCache(configuration);
                        }
                return _sessionActivityCache;
            }
        }
        #endregion Cache singletone

        public static void HandleSessionActivity(HttpApplication application)
        {
            if(!HttpContext.Current.Request.ServerVariables["URL"].Contains("/client/media/get"))
            try
            {
                if (!HttpContext.Current.User.Identity.IsAuthenticated) return;
                if (application.Request.Path.ToLower().Contains("sessionexpiredsoon") || application.Request.Path.ToLower().Contains("stayloggedin")) return;
                if (SessionActivityCache.Contains(application.Session.SessionID)) return;

                SessionActivityCache.Set(application.Session.SessionID, String.Empty);
                ProcessHandleSessionActivity(application);
            }
            catch (ThreadAbortException)
            {
                // This should be first catch block i.e. before generic Exception
                // This Catch block is to absorb exception thrown by Response.End
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => "Exception thrown from Global-Sessionhandling: " + ex.Message);
                application.Response.Redirect(string.Format("/athoc-iws/"));
            }
        }

        private static void ProcessHandleSessionActivity(HttpApplication application)
        {
            var sessionOutCheck = HandleSessionOut(application.Session.SessionID);

            LogService.Current.Verbose(() => "After handleSessionOut for:" + application.Request.Url.AbsolutePath);

            if (sessionOutCheck == String.Empty)
            {
                OperatorManager.UpdateSessionActivity(application.Session.SessionID, AtHocContext.Current.OperatorId, SessionStatus.IN.ToString());
                LogService.Current.Verbose(
                    () => "session activity time updated. Operator: " + AtHocContext.Current.OperatorId +
                          " . Host Address: " + application.Request.UserHostAddress + "Request URL:" + application.Request.Url.AbsolutePath);
                //Utilities.handlePwExpiredCase();
            }
            else
            {
                LogService.Current.Verbose(() => "This session has expired. Reason: " + sessionOutCheck);
                application.Response.Redirect(string.Format("{0}/client/error/show?errorCode=3&expired={1}", "{0}://{1}".FormatWith(HttpContext.Current.Request.Url.Scheme,HttpContext.Current.Request.Url.Host), sessionOutCheck));
            }
        }

        internal static string HandleSessionOut(string sessionId)
        {
            var displayStr = String.Empty;
            var sessionStatus = String.Empty;
            var sessionSubStatus = String.Empty;
            OperatorManager.GetSessionStatus(sessionId, out sessionStatus, out sessionSubStatus);

            if (sessionStatus == "OUT")
            {
                switch (sessionSubStatus)
                {

                    case "OUT_MAXLIMIT":
                        displayStr = "max limit"; //DefaultResources.ResourceManager.GetString("AUTH_ManageAccess_SessionEndedByAnotherSession");
                        break;
                    case "OUT_TIMEOUT":
                        displayStr = "timeout"; //DefaultResources.AUTH_ManageAccess_SessionEndedByTimeout;
                        break;
                    default:
                        displayStr = "session ended"; //DefaultResources.AUTH_ManageAccess_SessionEnded;
                        break;

                }
                LogService.Current.Verbose(() => "session substatus: " + sessionSubStatus + ". Session ended. - " + displayStr);
            }
            return displayStr;
        }

    }
}