﻿using System;

namespace AtHoc.Infrastructure
{
	public static class TypeExtensions
	{
		public static bool IsAssignableTo(this Type sourceType, Type targetType)
		{
			return targetType.IsAssignableFrom(sourceType);
		}

		public static bool IsNullable(this Type type)
		{
			return type == typeof (string) || (type.IsGenericType && type.GetGenericTypeDefinition() == typeof (Nullable<>));
		}

		public static object DefaultValue(this Type type)
		{
			return (type.IsValueType && !type.IsNullable()) ? Activator.CreateInstance(type) : null;
		}

		public static bool IsNumber(this object value)
		{
			return value is short || value is int || value is float || value is double || value is decimal
				|| value is long || value is byte || value is sbyte || value is UInt16 || value is UInt32 || value is UInt64;
		}
       
        /// <summary>
       /// Check if property belogs to the Entity.
       /// </summary>
       /// <typeparam name="T">Entity</typeparam>
       /// <param name="propertyName">property Name</param>
       /// <returns>boolean</returns>
        public static bool IsProperty<T>(string propertyName)
        {
            return typeof(T).GetProperty(propertyName) != null;
        }
	}
}