﻿using System.Collections.Generic;
using System.Linq;
using System.Collections;

namespace AtHoc.Infrastructure.Extensions
{
	public static class EnumerableExtensions
	{
		public static int Count(this IEnumerable source)
		{
			return source == null ? 0 : Enumerable.Count(source.Cast<object>());
		}

		public static bool HasValue(this IEnumerable source)
		{
			return source != null && source.Count() > 0;
		}

		public static T FirstOrDefault<T>(this IEnumerable source)
		{
			return ((IEnumerable<T>) source).FirstOrDefault();
		}
	}
}
