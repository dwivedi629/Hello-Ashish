﻿using System.Linq;
using System.Collections.Generic;

namespace AtHoc.Infrastructure
{
	public static class IEnumerableExtensions
	{
		public static string DEFAULT_SEPARATOR = ",";

		public static IEnumerable<T> AsEnumerableEmpty<T>(this IEnumerable<T> instance)
		{
			return instance == null ? Enumerable.Empty<T>() : instance.AsEnumerable();
		}

		public static bool HasValue<T>(this IEnumerable<T> instance)
		{
			return instance != null && instance.Any();
		}

		public static string Join<T>(this IEnumerable<T> instance, string separator = null)
		{
			separator = separator ?? DEFAULT_SEPARATOR;
			return string.Join(separator, instance);
		}

		public static bool Many<T>(this IEnumerable<T> instance)
		{
			return instance != null && instance.Count() > 1;
		}
	}
}