﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Xml;

namespace AtHoc.Infrastructure
{
	public static class StringExtensions
	{
		private static readonly Regex IsNumericRegex = new Regex(@"[.,\-0-9]+", RegexOptions.Compiled);

		private static readonly Regex IsBase64StringRegex = new Regex(@"^[a-zA-Z0-9\+/]*={0,3}$", RegexOptions.Compiled);

		public static bool IsNullOrEmpty(this string instance)
		{
			return IsNullOrEmpty(instance, true);
		}

		public static bool IsNullOrEmpty(this string instance, bool trim)
		{
			return string.IsNullOrEmpty(instance) || string.IsNullOrEmpty(instance.Trim());
		}

		public static bool IsNotNullOrEmpty(this string instance)
		{
			return IsNotNullOrEmpty(instance, true);
		}

		public static bool HasValue(this string instance)
		{
			return IsNotNullOrEmpty(instance, true);
		}

		public static string GetValue(this string instance)
		{
			return instance.HasValue() ? instance : String.Empty;
		}

		public static bool IsNotNullOrEmpty(this string instance, bool trim)
		{
			return !IsNullOrEmpty(instance, trim);
		}

		public static string FormatWith(this string instance, params object[] args)
		{
			return string.Format(instance, args);
		}

		public static bool IsNumeric(this string instance)
		{
			return IsNumericRegex.IsMatch(instance);
		}

        public static bool IsNumber(this string instance)
        {
            Int64 number;
            return Int64.TryParse(instance, out number);
        }

		public static bool IsBase64String(this string instance)
		{
			instance = instance.Trim();
			return (instance.Length%4 == 0) && IsBase64StringRegex.IsMatch(instance);
		}

		public static XmlDocument ToXmlDocument(this string instance)
		{
			if (instance.HasValue())
			{
				var doc = new XmlDocument();
				doc.LoadXml(instance);
				return doc;
			}
			return null;
		}

		public static IEnumerable<T> Split<T>(this string instance, string separator = ",", bool simulateEmptyValue = false)
		{
			if (!instance.HasValue())
				return simulateEmptyValue ? new[] { default(T) } : Enumerable.Empty<T>();
			var array = instance.Split(new[] { separator }, StringSplitOptions.RemoveEmptyEntries);
			return array.Select(value => (T)Convert.ChangeType(value, typeof(T)));
		}
	}
}