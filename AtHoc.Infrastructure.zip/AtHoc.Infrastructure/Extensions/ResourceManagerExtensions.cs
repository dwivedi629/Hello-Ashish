﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Resources;
using System.Text.RegularExpressions;

namespace AtHoc.Infrastructure
{
    public static class ResourceManagerExtensions
    {
        public static string GetString(this ResourceManager instance, object key, string defaultKey = null)
        {
            var value = string.Empty;
            if (key != null)
            {
                if (key is string)
                {
                    value = instance.GetString(key.ToString());
                }
                else
                {
                    var type = key.GetType();
                    if (type.IsEnum ||
                        (type.IsNullable() && Nullable.GetUnderlyingType(type).IsEnum))
                    {
                        var enumType = type.IsNullable() ? Nullable.GetUnderlyingType(type) : type;
                        value = instance.GetString("{0}_{1}".FormatWith(enumType.Name, key.ToString()));
                    }
                    else
                    {
                        value = instance.GetString(key.ToString());
                    }
                }
            }
            return value.IsNotNullOrEmpty() 
                ? value
                : defaultKey.IsNotNullOrEmpty() ? instance.GetString(defaultKey) : null;
        }

        public static IEnumerable<string> Keys(this ResourceManager instance)
        {
            var engCulture = CultureInfo.CreateSpecificCulture("en-US");
            var resourceSet = instance.GetResourceSet(engCulture, true, true);
            IDictionaryEnumerator enumerator = resourceSet.GetEnumerator();

            while (enumerator.MoveNext())
            {
                yield return (string)enumerator.Key;
            }
        }

        /// <summary>
        /// Get the dictionary for Resource set.
        /// </summary>
        /// <param name="resourceManager"></param>
        /// <param name="keyPattern"></param>
        /// <returns></returns>
        public static Dictionary<string,string> GetResourceSetByPattern(this ResourceManager resourceManager, string keyPattern)
        {
            var resourceSet = new Dictionary<string, string>();

            if (keyPattern  == null)
            {
                throw (new ArgumentNullException("keyPattern"));
            }

            if (resourceManager == null)
            {
                throw (new ArgumentNullException("resourceManager"));
            }

            if (keyPattern.Equals(string.Empty))
            {
                foreach (var key in resourceManager.Keys())
                {
                    if (!resourceSet.ContainsKey(key))
                    {
                        resourceSet.Add(key, resourceManager.GetString(key));
                    }
                }
            }
            else
            {
                foreach (var key in resourceManager.Keys().Where(x => Regex.IsMatch(x, keyPattern)))
                {
                    if (!resourceSet.ContainsKey(key))
                    {
                        resourceSet.Add(key, resourceManager.GetString(key));
                    }
                }
            }

            return resourceSet;
        }
        public static string GetEscapeStringValue(this String strValue)
        {
            return System.Web.HttpUtility.JavaScriptStringEncode(strValue);
        }
    }
}
