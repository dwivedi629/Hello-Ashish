﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Ioc;

namespace AtHoc.Infrastructure.Serialization
{
    public static class BinarySerializerService
    {
        public static IBinarySerializer Current { get; set; }

        static BinarySerializerService()
        {
            BinarySerializerService.Current = ServiceLocator.Resolve<IBinarySerializer>();
        }
    }
}
