﻿using AtHoc.Infrastructure.Ioc;

namespace AtHoc.Infrastructure.Serialization
{
	public class JsonSerializerService
	{
		public static IJsonSerializer Current { get; set; }

		static JsonSerializerService()
		{
			Current = ServiceLocator.Resolve<IJsonSerializer>();
		}

		public static T Deserialize<T>(string value)
		{
			return (T) Current.Deserialize(value, typeof (T));
		}
	}
}