﻿using System;

using Microsoft.SqlServer.Types;
using Newtonsoft.Json;

namespace AtHoc.Infrastructure.Serialization.JsonNet
{
    public class SqlGeographyConverter : JsonConverter
    {
        public override bool CanConvert(Type objectType)
        {
            return objectType.IsAssignableTo(typeof(SqlGeography));
        }

        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            return existingValue;
        }

        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            writer.WriteValue(value.ToString());
        }
    }
}
