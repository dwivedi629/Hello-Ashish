﻿using CsvHelper;
using AtHoc.Infrastructure.Factory;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.Infrastructure.Csv.CsvHelper
{
    public class CsvHelperCsvReaderFactory : FactoryBase<ICsvReader, CsvReaderSettings>, ICsvReaderFactory
    {

        protected override ICsvReader CreateImpl(CsvReaderSettings key)
        {
            return new CsvHelperCsvReader(key);
        }

        protected override CsvReaderSettings ConvertToKey(object key)
        {
            return key as CsvReaderSettings;
        }
    }
}
