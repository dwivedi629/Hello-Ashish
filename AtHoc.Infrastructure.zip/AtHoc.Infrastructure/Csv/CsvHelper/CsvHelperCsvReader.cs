﻿using CsvHelper;
using CsvHelper.Configuration;
using System.Text;

namespace AtHoc.Infrastructure.Csv.CsvHelper
{
    public class CsvHelperCsvReader : CsvReader, ICsvReader
    {
        public CsvHelperCsvReader(CsvReaderSettings settings)
            : base(settings.Reader, ToCsvConfiguration(settings))
        {
            
        }

        private static CsvConfiguration ToCsvConfiguration(CsvReaderSettings settings)
        {
            return new CsvConfiguration
            {
                HasHeaderRecord = settings.HasHeaderRecord,
                IsHeaderCaseSensitive = false,
                Encoding = Encoding.GetEncoding(1252)
               
                
            };
        }
    }
}
