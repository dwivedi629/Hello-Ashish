﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.Infrastructure.Csv
{
    public interface ICsvReader : IDisposable
    {
        bool Read();
        T GetField<T>(int index);
        T GetField<T>(string name);
        int Row { get; }
    }
}
