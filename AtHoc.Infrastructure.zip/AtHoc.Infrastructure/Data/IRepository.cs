﻿using System.Collections.Generic;
using System.Data;

using AtHoc.Infrastructure.Entity;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Resources;

namespace AtHoc.Infrastructure.Data
{
	public interface IRepository<T, S>
		where T : IEntity
		where S : ISpec
	{
		T FindById(int id);

		IEnumerable<T> FindBySpec(S spec);

		T SingleOrDefaultBySpec(S spec);

		int CountBySpec(S spec);

		DataTable GetDataTableBySpec(S spec);

		IDataReader GetDataReaderBySpec(S spec);

		PagingInfo<T> GetPagingInfo(S spec);

		Messages UpdateBySpec(S spec);

		Messages DeleteBySpec(S spec);

		Messages Save(T obj, bool returnId = false);

		Messages Save(T obj, bool returnId = false, params MetaProperty[] idProperties);

		Messages Insert(T obj, bool returnId = false);

		Messages Update(T obj);

		Messages Delete(int id);
	}
}
