﻿using System.Collections.Generic;

namespace AtHoc.Infrastructure.Data
{
	public class PagingInfo<T>
	{
		public IEnumerable<T> Data { get; set; }

		public int Count { get; set; }
	}
}
