﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

using AtHoc.Infrastructure.Database;
using AtHoc.Infrastructure.Sql;

namespace AtHoc.Infrastructure.Data
{
	public abstract class BaseDbQuery
	{
		protected string _commandText { get; set; }
		protected IDbContext _dbContext { get; set; }
		protected List<SqlParameter> _parameters { get; set; }

		protected BaseDbQuery(IDbContext dbContext, string commandText)
		{
			_dbContext = dbContext;
			_commandText = commandText;
			_parameters = new List<SqlParameter>();
		}

		public SqlParameter AddOutputParameter(string name, object value, int? size = null)
		{
			var parameter = AddParameter(name, value, size);
			parameter.Direction = ParameterDirection.Output;
			return parameter;
		}

		public SqlParameter AddParameter(string name, object value, int? size = null)
		{
			if (_parameters.Any(p => p.Name == name))
			{
				throw new ApplicationException("Duplicate parameter added.");
			}
			var parameter = _dbContext.CreateParameter(name, value, size);
			_parameters.Add(parameter);
			return parameter;
		}

		public void Execute()
		{
			_dbContext.ExecuteNonQuery(_commandText, _parameters);
		}

		protected virtual object GetResult()
		{
			return _dbContext.ExecuteScalar(_commandText, _parameters);
		}

		public T ExecuteScalar<T>()
		{
			return (T)Convert.ChangeType(GetResult(), typeof(T));
		}

		public IEnumerable<T> SelectColumnValues<T>(string columnName)
		{
			var result = new List<T>();
			using (var reader = ExecuteReader())
			{
				while (reader.Read())
				{
					result.Add((T)reader[columnName]);
				}
				return result;
			}
		}

		public virtual IDataReader ExecuteReader()
		{
			return _dbContext.ExecuteDataReader(_commandText, _parameters);
		}

		protected abstract CommandType GetCommandType();
	}
}
