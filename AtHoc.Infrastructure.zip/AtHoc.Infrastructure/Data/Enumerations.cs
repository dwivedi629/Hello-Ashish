﻿namespace AtHoc.Infrastructure.Data
{
    public enum GroupOperator
    {
        And,
        Or
    }

    public enum BitwiseOperator
    {
        Undefined,
        And,
        Or,
        Xor
    }

    public enum ConditionOperator
    {
        Equals,                 // 1
        NotEquals,              // 2
        LessThan,               // 7
        NotLessThan,            // 10
        LessThanEquals,         // 9
        NotLessThanEquals,      // 8
        GreaterThan,            // 8
        NotGreaterThan,         // 9
        GreaterThanEquals,      // 10
        NotGreaterThanEquals,   // 9
        In,
        NotIn,
        StartsWith,             // 5
        NotStartsWith,          // ##
        EndsWith,               // 6
        NotEndsWith,            // ##
        Contains,               // 3
        NotContains,            // 4
        Empty,                  // 11
        NotEmpty,               // 12
        Inside,                 // 13
        Outside,                // 14
        EqualsWithIsNull,
        NotEqualsWithIsNull
    }

	/*
    <OperatorDetail id="1" commonName="Equals" requireValue="Y"/>
    <OperatorDetail id="2" commonName="Not_Equals" requireValue="Y"/>
    <OperatorDetail id="3" commonName="Contains" requireValue="Y"/>
    <OperatorDetail id="4" commonName="Does_Not_Contain" requireValue="Y"/>
    <OperatorDetail id="5" commonName="Starts_With" requireValue="Y"/>
    <OperatorDetail id="6" commonName="Ends_With" requireValue="Y"/>
    <OperatorDetail id="7" commonName="Less_Than" requireValue="Y"/>
    <OperatorDetail id="8" commonName="Greater_Than" requireValue="Y"/>
    <OperatorDetail id="9" commonName="Less_Than_Equal" requireValue="Y"/>
    <OperatorDetail id="10" commonName="Greater_Than_Equal" requireValue="Y"/>
    <OperatorDetail id="11" commonName="Is_Empty" requireValue="N"/>
    <OperatorDetail id="12" commonName="Is_Not_Empty" requireValue="N"/>
    <OperatorDetail id="13" commonName="Is_Inside" requireValue="Y"/>
    <OperatorDetail id="14" commonName="Is_Outside" requireValue="Y"/>
  </OperatorDetails>
</OperatorMetadata>

	 
	 */
}
