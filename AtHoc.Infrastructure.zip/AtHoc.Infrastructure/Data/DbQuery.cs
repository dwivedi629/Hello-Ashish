﻿using System.Data;

using AtHoc.Infrastructure.Database;

namespace AtHoc.Infrastructure.Data
{
	public class DbQuery : BaseDbQuery
	{
		public DbQuery(IDbContext dbContext, string commandText) : base(dbContext, commandText) { }

		protected override CommandType GetCommandType()
		{
			return CommandType.Text;
		}
	}
}
