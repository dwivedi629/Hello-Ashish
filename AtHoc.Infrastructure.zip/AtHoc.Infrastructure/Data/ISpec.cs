﻿using AtHoc.Infrastructure.Meta;

namespace AtHoc.Infrastructure.Entity
{
	public interface ISpec
	{
		int? Page { get; set; }

		int PageSize { get; set; }

		MetaProperty OrderBy { get; set; }

		bool? OrderAsc { get; set; }
	}
}
