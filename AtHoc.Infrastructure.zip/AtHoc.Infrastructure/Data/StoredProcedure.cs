﻿using System;
using System.Data;

using AtHoc.Infrastructure.Database;

namespace AtHoc.Infrastructure.Data
{
	public class StoredProcedure : BaseDbQuery
	{
		public StoredProcedure(IDbContext dbContext, string name) : base(dbContext, String.Concat("exec ", name)) {}

		protected override CommandType GetCommandType()
		{
			return CommandType.StoredProcedure;
		}
	}
}
