﻿using System;

namespace AtHoc.Infrastructure.Data
{
	public interface IUnitOfWork : IDisposable
	{
		bool UseTransaction { get; set; }

		int SaveChanges();

		bool HasChanges();

		void Commit();

		void Rollback();
	}
}