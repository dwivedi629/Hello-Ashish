﻿using System;

using AtHoc.Infrastructure.Database;

namespace AtHoc.Infrastructure.Data
{
	public class SequenceHelper
	{
		private readonly IDbContext _dbContext;

		public SequenceHelper(IDbContext dbContext)
		{
			_dbContext = dbContext;
		}

		public int GetSequence(string sequenceType, int sequenceRange = 1)
		{
			try
			{
				var proc = new StoredProcedure(_dbContext, "dbo.GET_NEW_SEQUENCE");
				proc.AddParameter("@seqType", sequenceType, 30);
				proc.AddParameter("@seqRange", sequenceRange, 10);
				var resultParam = proc.AddOutputParameter("@startSeq", null, 10);
				proc.Execute();
				return Convert.ToInt32(resultParam.OutputValue);
			}
			catch(Exception)
			{
				// call EventLogger...
				return -1;
			}
		}
	}
}
