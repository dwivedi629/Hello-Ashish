﻿using System.Data;

using AtHoc.Infrastructure.Database;
using AtHoc.Infrastructure.Sql;

namespace AtHoc.Infrastructure.Data
{
	public class DbFunction : StoredProcedure
	{
		private readonly SqlParameter _result;

		public DbFunction(IDbContext dbContext, string name)
			: base(dbContext, name)
		{
			_result = AddParameter("Result", null);
			_result.Direction = ParameterDirection.ReturnValue;
		}

		protected override object GetResult()
		{
			base.GetResult();
			return _result.OutputValue;
		}
	}
}
