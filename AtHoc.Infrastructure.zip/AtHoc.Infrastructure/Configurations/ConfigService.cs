﻿using AtHoc.Infrastructure.Ioc;

namespace AtHoc.Infrastructure.Configurations
{
	public static class ConfigService
	{
		public static IConfigurations Current { get; set; }

		static ConfigService()
		{
			Current = ServiceLocator.Resolve<IConfigurations>();
		}
	}
}