﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.Infrastructure.Configurations.Registry
{
    public class RegistryConfigurations
    {
        private Dictionary<string, object> configurations = new Dictionary<string, object>();
        private string basePath = null;

        public RegistryConfigurations(string basePath)
        {
            this.basePath = basePath;
        }

        public object Get(string relativePath, string name, object defaultValue = null, Func<object, object> converter = null)
        {
            if (this.configurations.ContainsKey(name) == false)
            {
                var value = Microsoft.Win32.Registry.GetValue("{0}{1}".FormatWith(basePath, relativePath), name, defaultValue);
                if (converter != null)
                    value = converter((string)value);

                this.configurations[name] = value;
            }

            return this.configurations[name];
        }

        public void Set(string relativePath, string name, object value, Func<object, object> converter = null)
        {
            this.configurations[name] = value;

            if (converter != null)
                value = converter(value);

            Microsoft.Win32.Registry.SetValue("{0}{1}".FormatWith(basePath, relativePath), name, value);
        }
    }
}
