﻿namespace AtHoc.Infrastructure.Configurations
{
	public interface IConfigurations
	{
		string CdnBaseUrl { get; set; }

		string FilesBasePath { get; }

		byte[] CryptoSalt { get; set; }

		string CryptoPassword { get; set; }

		string Version { get; set; }

        string IwsBaseUrl { get; set; }
	}
}