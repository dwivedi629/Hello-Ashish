﻿using AtHoc.Infrastructure.Resources;

namespace AtHoc.Infrastructure.Domain
{
	public interface IActionResult<T>
	{
		T Value { get; set; }

		Messages Messages { get; set; }

		bool IsValid { get; }

		Message CreateErrorMessage(string message);

		Message CreateSuccessMessage(string message);

		void AddMessage(Messages messages);
	}

	public abstract class ActionResult<T> : IActionResult<T>
	{
		protected ActionResult()
		{
			Messages = new Messages();
		}

		public T Value { get; set; }

		public Messages Messages { get; set; }

		public bool IsValid
		{
			get { return !Messages.HasErrors(); }
		}

		public Message CreateErrorMessage(string message)
		{
			return Messages.CreateErrorMessage(message);
		}

		public Message CreateSuccessMessage(string message)
		{
			return Messages.CreateSuccessMessage(message);
		}

		public void AddMessage(Messages messages)
		{
			this.Messages.Add(messages);
		}
	}
}
