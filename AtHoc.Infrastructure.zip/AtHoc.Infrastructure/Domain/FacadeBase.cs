﻿using System;

namespace AtHoc.Infrastructure.Domain
{
	public abstract class FacadeBase<TFactory> : MarshalByRefObject
		where TFactory : class
	{
		protected readonly TFactory ContextFactory;

		protected FacadeBase() {}

		protected FacadeBase(TFactory contextFactory)
		{
			ContextFactory = contextFactory;
		}
	}
}