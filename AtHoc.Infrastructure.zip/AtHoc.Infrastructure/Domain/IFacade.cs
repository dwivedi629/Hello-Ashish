﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Data;

namespace AtHoc.Infrastructure.Domain
{
    /*
    public interface IFacade : IDisposable
    {
        void SetContext<T>(T context) 
            where T : IUnitOfWork;
    }
     */
}
