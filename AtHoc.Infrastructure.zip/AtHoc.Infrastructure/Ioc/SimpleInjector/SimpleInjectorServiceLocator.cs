﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using AtHoc.Diagnostics;
using SimpleInjector;
using SimpleInjector.Integration.Web;

namespace AtHoc.Infrastructure.Ioc.SimpleInjector
{
    public class SimpleInjectorServiceLocator : IServiceLocator
    {
        private Container container = new Container();

        public SimpleInjectorServiceLocator()
        {
            this.container.Options.AllowOverridingRegistrations = true;
        }

        public void LoadAll()
        {
            try
            {
                var allassemblies = AppDomain.CurrentDomain.GetAssemblies();
                var types = new List<Type>();
                var loaders = new List<IServiceLoader>();

                foreach (var assembly in allassemblies)
                {
                    types.AddRange(assembly.GetTypes());
                }

                foreach (var type in types)
                {
                    if (type.IsClass && type.IsAssignableTo(typeof(IServiceLoader)))
                    {
                        loaders.Add((IServiceLoader)Activator.CreateInstance(type));
                    }
                }

                var serviceLoaders = loaders.OrderBy(x => x.SortOrder).ToArray();

                if (serviceLoaders.Any())
                {
                    foreach (var item in serviceLoaders)
                    {
                        item.Load(this);
                    }
                }
            }
            catch (ReflectionTypeLoadException ex)
            {
                var sb = new StringBuilder();
                foreach (var exSub in ex.LoaderExceptions)
                {
                    sb.AppendLine(exSub.Message);
                    var exFileNotFound = exSub as FileNotFoundException;
                    if (exFileNotFound != null)
                    {
                        if (!string.IsNullOrEmpty(exFileNotFound.FusionLog))
                        {
                            sb.AppendLine("Fusion Log:");
                            sb.AppendLine(exFileNotFound.FusionLog);
                        }
                    }
                    sb.AppendLine();
                }
                string errorMessage = sb.ToString();
                EventLogger.WriteError(String.Format("Error while loading assembly - {0}", errorMessage));
                throw new Exception(errorMessage);
            }
            catch (Exception ex)
            {
                EventLogger.WriteError("Failed to Load Assemblies : ", ex);
                throw;
            }

        }

        public object IocContainer
        {
            get { return container; }
        }

        public void Register(Type serviceType, Type concreteType, ServiceLifecycle lifecycle = ServiceLifecycle.PerCall)
        {
            container.Register(serviceType, concreteType, this.GetLifestyle(lifecycle));
        }

        public void Register<ServiceType, ConcreteType>(ServiceLifecycle lifecycle = ServiceLifecycle.PerCall)
            where ServiceType : class
            where ConcreteType : class, ServiceType
        {
            container.Register<ServiceType, ConcreteType>(this.GetLifestyle(lifecycle));
        }

        public void RegisterInstance(Type serviceType, object instance)
        {
            container.RegisterSingle(serviceType, instance);
        }

        public void RegisterInstance<ServiceType>(ServiceType instance) where ServiceType : class
        {
            container.RegisterSingle<ServiceType>(instance);
        }

        public object Resolve(Type serviceType)
        {
            return container.GetInstance(serviceType);
        }

        public ServiceType Resolve<ServiceType>() where ServiceType : class
        {
            return container.GetInstance<ServiceType>();
        }

        public void Dispose()
        {
            container = null;
        }

        private Lifestyle GetLifestyle(ServiceLifecycle lifecycle)
        {
            switch (lifecycle)
            {
                case ServiceLifecycle.PerCall:
                    return Lifestyle.Transient;
                case ServiceLifecycle.Singleton:
                    return Lifestyle.Singleton;
                case ServiceLifecycle.PerWebRequest:
                    return new WebRequestLifestyle();
                default:
                    throw new NotImplementedException("Lifecycle ({0}) not implemented".FormatWith(lifecycle));
            }
        }
    }
}
