﻿using Microsoft.Practices.Unity;

namespace AtHoc.Infrastructure.Ioc
{
	public static class ServiceLocator
	{
		public static IServiceLocator Current { get; set; }

		public static T Resolve<T>() where T : class
		{
			var result = Current.Resolve<T>();
			var unityContainer = Current.Resolve<IUnityContainer>();
			if (unityContainer.IsRegistered(result.GetType()))
				return (T) unityContainer.Resolve(result.GetType());
			return result;
		}
	}
}