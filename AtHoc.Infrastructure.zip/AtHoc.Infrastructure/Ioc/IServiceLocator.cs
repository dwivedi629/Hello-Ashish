﻿using System;

namespace AtHoc.Infrastructure.Ioc
{
    public interface IServiceLocator : IDisposable
    {
        void LoadAll();
        
        void Register(Type serviceType, Type concreteType, ServiceLifecycle lifecycle = ServiceLifecycle.PerCall);
        
        void Register<ServiceType, ConcreteType>(ServiceLifecycle lifecycle = ServiceLifecycle.PerCall) where ServiceType: class  where ConcreteType : class, ServiceType;
        
        void RegisterInstance(Type serviceType, object instance);
        
        void RegisterInstance<ServiceType>(ServiceType instance) where ServiceType: class;
        
        object Resolve(Type serviceType);
        
        ServiceType Resolve<ServiceType>() where ServiceType : class;
        
        object IocContainer { get; }
    }

    #region ServiceLifecycle
    public enum ServiceLifecycle
    {
        PerCall,
        Singleton,
        PerWebRequest
    }
    #endregion ServiceLifecycle
}
