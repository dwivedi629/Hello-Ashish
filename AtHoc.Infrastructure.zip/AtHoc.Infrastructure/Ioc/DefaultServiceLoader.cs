﻿using System;

using AtHoc.Infrastructure.Accessor;
using AtHoc.Infrastructure.Accessor.Default;
using AtHoc.Infrastructure.Converter;
using AtHoc.Infrastructure.Converter.Default;
using AtHoc.Infrastructure.Serialization;
using AtHoc.Infrastructure.Serialization.DataContract;
using AtHoc.Infrastructure.Serialization.JsonNet;
using AtHoc.Infrastructure.Validation;
using AtHoc.Infrastructure.Validation.Default;
using AtHoc.Infrastructure.Encryption;
using AtHoc.Infrastructure.Encryption.Default;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Log.NLog;
using AtHoc.Infrastructure.Csv;
using AtHoc.Infrastructure.Csv.CsvHelper;
using AtHoc.Infrastructure.Sql;

namespace AtHoc.Infrastructure.Ioc
{
    public class DefaultServiceLoader : IServiceLoader
    {
        public int SortOrder
        {
            //should be loaded before everyone else
            get { return Int32.MinValue; }
        }

        public void Load(IServiceLocator container)
        {
            container.Register<IConverterService, DefaultConverterService>(ServiceLifecycle.Singleton);
            container.Register<IValidatorService, DefaultValidatorService>(ServiceLifecycle.Singleton);
            container.Register<IAccessorService, DefaultAccessorService>(ServiceLifecycle.Singleton);
            container.Register<IJsonSerializer, JsonNetSerializer>(ServiceLifecycle.Singleton);
            container.Register<IBinarySerializer, BsonNetSerializer>(ServiceLifecycle.Singleton);
            container.Register<IXmlSerializer, XmlDataContractSerializer>(ServiceLifecycle.Singleton);
            container.Register<ILogService, NLogService>(ServiceLifecycle.Singleton);
            container.Register<ICryptoSettings, DefaultCryptoSettings>();
            container.Register<ICryptoFactory, DefaultCryptoFactory>(ServiceLifecycle.Singleton);
            container.Register<ISqlBuilderFactory, DefaultSqlBuilderFactory>(ServiceLifecycle.Singleton);
            container.Register<ICsvReaderFactory, CsvHelperCsvReaderFactory>(ServiceLifecycle.Singleton);
        }
    }
}
