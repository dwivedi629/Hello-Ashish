﻿namespace AtHoc.Infrastructure.Ioc
{
	public interface IServiceLoader
	{
		int SortOrder { get; }

		void Load(IServiceLocator container);
	}
}