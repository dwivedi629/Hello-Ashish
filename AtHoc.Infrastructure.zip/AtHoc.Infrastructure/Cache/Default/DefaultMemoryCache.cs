﻿using System;
using System.Runtime.Caching;

namespace AtHoc.Infrastructure.Cache.Default
{
	public abstract class DefaultMemoryCache<T> : ICache<T>
	{
		private readonly MemoryCache cache;

		private readonly ICacheDependency cacheDependency;

		private readonly CacheItemPolicy defaultPolicy;

		protected DefaultMemoryCache(string name, ICacheDependency cacheDependency, CacheItemPolicy defaultPolicy)
		{
			if (name.IsNullOrEmpty()) throw new ArgumentException("name cannot be null or empty");
			if (cacheDependency == null) throw new ArgumentNullException("cacheDependency");

			cache = new MemoryCache(name);
			this.cacheDependency = cacheDependency;
			this.defaultPolicy = (defaultPolicy == null)
				? new CacheItemPolicy {SlidingExpiration = new TimeSpan(8, 0, 0)}
				: defaultPolicy;
		}

		public T Get(string key)
		{
			if (key.IsNullOrEmpty()) throw new ArgumentNullException("key");

			if (cache.Contains(key) == false || cacheDependency.IsExpired(Name, key))
			{
				var value = LoadCacheItem(key);
				cache.Set(key, value, defaultPolicy);

				cacheDependency.Refreshed(Name, key);
			}

			return cache.Contains(key) ? (T) cache[key] : default(T);
		}

		public string Name
		{
			get { return cache.Name; }
		}

		public abstract T LoadCacheItem(string key);

		public void Expired(string key)
		{
			cacheDependency.Expired(Name, key);
		}
	}
}