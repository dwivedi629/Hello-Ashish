﻿namespace AtHoc.Infrastructure.Cache
{
	public interface ICache<T>
	{
		T Get(string key);

		T LoadCacheItem(string key);
	}
}