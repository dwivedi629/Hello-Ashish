﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.Infrastructure.Cache
{
    public interface ICacheDependency
    {
        bool IsExpired(string cacheName, string key);
        DateTime Expired(string cacheName, string key);
        void Refreshed(string cacheName, string key);
    }
}
