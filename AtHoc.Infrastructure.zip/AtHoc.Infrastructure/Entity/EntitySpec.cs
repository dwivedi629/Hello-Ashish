﻿using System;

using AtHoc.Infrastructure.Meta;

namespace AtHoc.Infrastructure.Entity
{
	public abstract class EntitySpec : ISpec
	{
		public int? Page { get; set; }

		public int PageSize { get; set; }

		protected EntitySpec()
		{
			this.Page = null;
			this.PageSize = 15;
		}

		[Obsolete("Use OrderBy instead")]
		public string OrderByValue { get; set; }

		public MetaProperty OrderBy { get; set; }

		public bool? OrderAsc { get; set; }

        /// <summary>
        /// Get or Set Base Locale of Vps 
        /// </summary>
        public string BaseLocale { get; set; }
	}
}
