﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.Infrastructure.Entity
{
    public interface IPropertyAccessor
    {
        object Get(string propertyName, object defaultValue);
        T Get<T>(string propertyName, T defaultValue);
        void Set(string propertyName, object value);
        void Set<T>(string propertyName, T value);
    }
}
