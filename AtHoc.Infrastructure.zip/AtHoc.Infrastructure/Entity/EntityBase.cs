﻿using System;
using System.Collections;
using System.Collections.Generic;

using AtHoc.Infrastructure.Encryption;
using AtHoc.Infrastructure.Meta;

namespace AtHoc.Infrastructure.Entity
{
	public abstract class EntityBase : IEntity
	{
		private readonly MetaObject metaObject = null;
		private readonly IDictionary<string, object> values = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);

		[MetaProperty(IsPersistable = false)]
		public IDictionary<string, object> DirtyProperties { get; private set; }

		[MetaProperty(IsPersistable = false)]
		public RuntimeStatus RuntimeStatus { get; set; }

		protected EntityBase()
		{
			this.metaObject = MetaObject.Get(this.GetType());
		}
        
        [MetaProperty(IsPersistable = false)]
		public bool IsNew
		{
			get { return RuntimeStatus == RuntimeStatus.New; }
		}

        [MetaProperty(IsPersistable = false)]
		public bool IsDirty
		{
			get { return RuntimeStatus == RuntimeStatus.Dirty; }
		}
        
        [MetaProperty(IsPersistable = false)]
		public bool IsLoaded
		{
			get { return RuntimeStatus == RuntimeStatus.Loaded; }
		}

		public T Get<T>(string propertyName)
		{
			return (T)this.Get(typeof(T), propertyName, (object)default(T));
		}

		public T Get<T>(string propertyName, T defaultValue)
		{
			return (T)this.Get(typeof(T), propertyName, (object)defaultValue);
		}

		public object Get(string propertyName, object defaultValue = null)
		{
			return this.Get(null, propertyName, defaultValue);
		}

		private object Get(Type type, string propertyName, object defaultValue = null)
		{
			if (type == null)
				type = this.metaObject[propertyName].PropertyType;

			var found = this.values.ContainsKey(propertyName);
			if (found == false || this.values[propertyName] is DBNull)
				this.values[propertyName] = defaultValue ?? type.DefaultValue();

			return this.values[propertyName];
		}

		public void Set<T>(string propertyName, T value)
		{
			this.Set(typeof(T), propertyName, value);
		}

		public void Set(string propertyName, object value)
		{
			this.Set(null, propertyName, value);
		}

		public void Set(Type type, string propertyName, object value)
		{
			if (propertyName.IsNullOrEmpty())
				throw new ArgumentNullException("propertyName");

			var metaProperty = this.metaObject[propertyName];
			if (type == null && metaProperty != null)
				type = metaProperty.PropertyType;

            //if (value != null && value.GetType().IsAssignableTo(type) == false)
            //    throw new InvalidOperationException("Cannot assign value ({0}) of type ({1}, {2}) to value of type ({3}, {4})"
            //        .FormatWith(value, value.GetType(), value.GetType().AssemblyQualifiedName, type, type.AssemblyQualifiedName));

			if (value == null)
				value = type.DefaultValue();

			//update runtime status
			this.ValidateIsDirty(propertyName, this.Get(type, propertyName), value);

			//apply metaproperty behaviors
			if (metaProperty != null &&
				value is string)
			{
				var strValue = value as string;
				if (metaProperty.AutoTrim)
					strValue = strValue.Trim();

				//if (metaProperty.MaxLength > 0 && strValue.Length > metaProperty.MaxLength)
				//	strValue = strValue.Substring(0, metaProperty.MaxLength);

				if (metaProperty.IsEncrypted &&
					metaProperty.CryptoType == Encryption.CryptoType.OneWayHash &&
					strValue.IsNotNullOrEmpty() &&
					strValue.IsBase64String() == false)
				{
					var crypto = CryptoFactory.Current.Create(CryptoType.OneWayHash);
					strValue = crypto.Encrypt(strValue);
				}

				value = strValue;
			}

			this.values[propertyName] = value;
		}

		protected virtual void ValidateIsDirty(string propertyName, object currentValue, object newValue)
		{
			if (this.DirtyProperties != null &&
				this.DirtyProperties.ContainsKey(propertyName) &&
				this.DirtyProperties[propertyName].IsEquals(newValue))
			{
				this.DirtyProperties.Remove(propertyName);
				if (this.DirtyProperties.Count == 0)
				{
					this.RuntimeStatus = RuntimeStatus.Loaded;
				}
			}
			else
			{
				if ((this.RuntimeStatus == RuntimeStatus.Loaded ||
						this.RuntimeStatus == RuntimeStatus.Dirty) && 
					currentValue.IsEquals(newValue) == false)
				{
					this.RuntimeStatus = RuntimeStatus.Dirty;

					if (this.DirtyProperties == null)
						this.DirtyProperties = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);

					if (this.DirtyProperties.ContainsKey(propertyName) == false)
						this.DirtyProperties.Add(propertyName, currentValue);
				}
			}
		}

		#region IReadOnlyDictionary
		public bool ContainsKey(string key)
		{
			return this.values.ContainsKey(key);
		}

		[MetaProperty(IsPersistable = false)]
		public IEnumerable<string> Keys
		{
			get { return this.values.Keys; }
		}

		public bool TryGetValue(string key, out object value)
		{
			return this.values.TryGetValue(key, out value);
		}

		[MetaProperty(IsPersistable = false)]
		public IEnumerable<object> Values
		{
			get { return this.values.Values; }
		}

		[MetaProperty(IsPersistable = false)]
		public object this[string key]
		{
			get { return this.values[key]; }
		}

		[MetaProperty(IsPersistable = false)]
		public int Count
		{
			get { return this.values.Count; }
		}

		public IEnumerator<KeyValuePair<string, object>> GetEnumerator()
		{
			return this.values.GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.GetEnumerator();
		}
		#endregion IReadOnlyDictionary
    
	}

	#region RuntimeStatus
	public enum RuntimeStatus
	{
		New,
		Loaded,
		Dirty
	}
	#endregion RuntimeStatus
}
