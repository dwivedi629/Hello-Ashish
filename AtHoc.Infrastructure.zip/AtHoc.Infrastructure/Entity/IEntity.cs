﻿using System.Collections.Generic;

namespace AtHoc.Infrastructure.Entity
{
	public interface IEntity : IPropertyAccessor, IReadOnlyDictionary<string, object>
	{
		IDictionary<string, object> DirtyProperties { get; }

		RuntimeStatus RuntimeStatus { get; set; }

		bool IsNew { get; }

		bool IsDirty { get; }

		bool IsLoaded { get; }
	}
}
