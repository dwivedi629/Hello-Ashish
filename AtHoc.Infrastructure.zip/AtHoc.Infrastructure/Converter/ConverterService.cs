﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure.Ioc;

namespace AtHoc.Infrastructure.Converter
{
    public static class ConverterService
    {
        public static IConverterService Current { get; private set; }

        static ConverterService()
        {
            ConverterService.Current = ServiceLocator.Resolve<IConverterService>();
        }
    }
}
