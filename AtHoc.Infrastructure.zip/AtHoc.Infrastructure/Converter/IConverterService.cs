﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.Infrastructure.Converter
{
    public interface IConverterService : IConverter
    {
        void Register(Type targetType, IConverter converter);
    }
}
