﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.Infrastructure.Template
{
    public interface ITemplateService
    {
        string FileToString(string file, object data);
        void FileToFile(string file, object data, string outputFile);
        string StringToString(string template, object data);
        void StringToFile(string template, object data, string outputFile);
    }
}
