﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Nustache.Core;

namespace AtHoc.Infrastructure.Template.Nustache
{
    public class NustacheTemplateService : ITemplateService
    {
        public string FileToString(string file, object data)
        {
            return Render.FileToString(file, data);
        }

        public void FileToFile(string file, object data, string outputFile)
        {
            Render.FileToFile(file, data, outputFile);
        }

        public string StringToString(string template, object data)
        {
            return Render.StringToString(template, data);
        }

        public void StringToFile(string template, object data, string outputFile)
        {
            Render.StringToFile(template, data, outputFile);
        }
    }
}
