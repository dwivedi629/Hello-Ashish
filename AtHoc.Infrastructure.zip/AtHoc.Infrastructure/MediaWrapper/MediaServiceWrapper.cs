﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using AtHoc.MediaServices;
using System.IO;


namespace AtHoc.Infrastructure.MediaWrapper
{
    public class MediaServiceWrapper
    {
        public static Stream GetMedia(string guid, out string fileName)
        {
            fileName = "not found";

            var logoGuid = Guid.Empty;
            var isGuid = Guid.TryParse(guid, out logoGuid);
            if (isGuid)
            {
                try
                {
                    var mediaService = MediaService.Instance;
                    IMedia retValue = null;
                    Stream mediaStream = null;
                    var media = mediaService.GetMedia(logoGuid);
                   
                    if (media != null)
                    {
                        if (media.MediaInfo.ContentType.StartsWith("image", StringComparison.OrdinalIgnoreCase) &&
                            media.MediaInfo.Rotation > 0)
                        {
                            //need to check rotation flag
                            mediaStream = mediaService.AdjustImageRotation(media);
                        }
                        retValue = media;
                    }

                    if (retValue != null && retValue.MediaInfo != null)
                    {
                        var contentType = retValue.MediaInfo.ContentType;
                        fileName = retValue.MediaInfo.FileName;
                        if (string.IsNullOrEmpty(fileName))
                        {
                            fileName = retValue.MediaGuid.ToString();
                        }

                        if (fileName.EndsWith(retValue.MediaInfo.Extension, StringComparison.OrdinalIgnoreCase) == false)
                        {
                             
                            fileName = string.Format("{0}.{1}", fileName, retValue.MediaInfo.Extension);
                        }

                        return retValue.MediaContent.GetContent();
                    }
                }
                catch (Exception)
                {
                    return null;
                }
            }
        
            return null;
        }

        public static string SaveMedia(Stream stream, string fileName, string fileExtension, string fileType, string source, int createdBy = 0)
        {
            var mediaInfo = new MediaInfo()
            {
               Source  = source,
               ContentType = fileType,
               AllowWebAccess = true,
               FileName = fileName,
               Extension = fileExtension,
            };

            Guid mediaId;
            var mediaService = MediaService.Instance;
            var media = mediaService.CreateMedia(mediaInfo, out mediaId, MediaStatus.Act, createdBy);
            media.SetContent(stream);

            return mediaId.ToString();
        }
    }
}
