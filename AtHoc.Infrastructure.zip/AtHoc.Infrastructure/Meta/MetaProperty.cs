﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

using AtHoc.Infrastructure.Encryption;

namespace AtHoc.Infrastructure.Meta
{
	[AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
	public class MetaProperty : Attribute
	{
		public MetaProperty()
		{
			this.IsPersistable = true;
		}

		public MetaProperty(string columnName) : this()
		{
			this.ColumnName = columnName;
		}

		public MetaObject Parent { get; set; }

		public string Name { get; set; }

		public Type PropertyType { get; set; }

		public string DbTypeName { get; set; }

		public string ColumnName { get; set; }

		public bool IsIdentity { get; set; }

		public string SequenceType { get; set; }

		public bool IsKey { get; set; }

		public bool IsPersistable { get; set; }

		public int MaxLength { get; set; }

		public IEnumerable<ValidationAttribute> ValidationAttributes { get; set; }

		public bool IsEncrypted { get; set; }

		public bool AutoTrim { get; set; }

		public CryptoType CryptoType { get; set; }

		public override string ToString()
		{
			return "{0}.{1}".FormatWith(this.Parent.ToString(), this.Name);
		}
	}
}
