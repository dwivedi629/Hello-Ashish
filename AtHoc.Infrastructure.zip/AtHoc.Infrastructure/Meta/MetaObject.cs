﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Reflection;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using System.Collections.Concurrent;

namespace AtHoc.Infrastructure.Meta
{
	/// <summary>
	/// 
	/// </summary>
	[AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
	public class MetaObject : Attribute, IEnumerable<MetaProperty>
	{        
		#region Static
		private static IDictionary<string, MetaObject> cache = null;

		static MetaObject()
		{
			MetaObject.cache = new ConcurrentDictionary<string, MetaObject>(StringComparer.OrdinalIgnoreCase);            
		}

		public static T Get<T>() where T : MetaObject
		{
			var typeFullName = typeof(T).FullName;
			return (T)(MetaObject.cache.ContainsKey(typeFullName)
				? MetaObject.cache[typeFullName] : null);
		}

		/// <summary>
		/// Get MetaObject from CLR Type, to extend this feature, we can implement Get MetaObject from DB, etc...
		/// </summary>
		/// <param name="type"></param>
		/// <param name="forceRefresh">If "true" it will re-create meta object even if it is already cached</param>
		/// <returns></returns>
		public static MetaObject Get(Type type, bool forceRefresh = false)
		{
			var typeFullName = string.Format("{0}Meta", type.FullName);
			var metaObject = (MetaObject.cache.ContainsKey(typeFullName)
				? MetaObject.cache[typeFullName] : null);

			if (metaObject == null || forceRefresh)
			{
				//MetadataTypeAttribute
				RegisterMetadataType(type);

				//MetaObject
				RegisterMetaObject(type, ref metaObject);
			}

			return metaObject;
		}

		private static MetaObject RegisterMetaObject(Type type, ref MetaObject metaObject)
		{
			metaObject = type.GetCustomAttribute<MetaObject>(false);
			if (metaObject == null)
				metaObject = new MetaObject();

			var propertyInfoCollection = type.GetProperties(BindingFlags.Instance | BindingFlags.FlattenHierarchy | BindingFlags.Public);

			List<ValidationAttribute> classValidationAttributes = null;
			IDictionary<string, List<ValidationAttribute>> propertiesValidationAttributes = null;
			GetValidationAttributes(type, propertyInfoCollection, out classValidationAttributes, out propertiesValidationAttributes);

			metaObject.Name = type.Name;
			metaObject.FullName = type.FullName;
			if (metaObject.TableName.IsNullOrEmpty()) metaObject.TableName = type.Name;
			metaObject.ValidationAttributes = classValidationAttributes;

			foreach (var propertyInfo in propertyInfoCollection)
			{
				var metaProperty = propertyInfo.GetCustomAttribute<MetaProperty>(false);
				if (metaProperty == null)
					metaProperty = new MetaProperty();

				if (metaProperty != null)
				{
					metaProperty.Name = propertyInfo.Name;
					metaProperty.PropertyType = propertyInfo.PropertyType;
					metaProperty.Parent = metaObject;
					if (metaProperty.ColumnName.IsNullOrEmpty()) metaProperty.ColumnName = propertyInfo.Name;
					if (propertiesValidationAttributes.ContainsKey(propertyInfo.Name)) metaProperty.ValidationAttributes = propertiesValidationAttributes[propertyInfo.Name];

					metaObject.Add(metaProperty);
				}
			}

			MetaObject.Set(metaObject);
			return metaObject;
		}

		private static void GetValidationAttributes(Type type,
			IEnumerable<PropertyInfo> propertyInfoCollection,
			out List<ValidationAttribute> classValidationAttributes,
			out IDictionary<string, List<ValidationAttribute>> propertiesValidationAttributes)
		{
			if (type == null)
				throw new ArgumentNullException("type");

			if (propertyInfoCollection == null)
				throw new ArgumentNullException("propertyInfoCollection");

			var metadataTypeAttribute = type.GetCustomAttribute<MetadataTypeAttribute>();
			var metadataType = (metadataTypeAttribute != null) ? metadataTypeAttribute.MetadataClassType : null;

			classValidationAttributes = new List<ValidationAttribute>();
			propertiesValidationAttributes = new ConcurrentDictionary<string, List<ValidationAttribute>>();

			classValidationAttributes.AddRange(type.GetCustomAttributes<ValidationAttribute>());
			if (metadataType != null)
				classValidationAttributes.AddRange(metadataType.GetCustomAttributes<ValidationAttribute>());

			foreach (var propertyInfo in propertyInfoCollection)
			{
				var propertyValidationAttributes = new List<ValidationAttribute>();
				propertyValidationAttributes.AddRange(propertyInfo.GetCustomAttributes<ValidationAttribute>());

				if (metadataType != null)
				{
					var metadataTypePropertyInfo = metadataType.GetProperty(propertyInfo.Name);

					if (metadataTypePropertyInfo != null)
						propertyValidationAttributes.AddRange(metadataTypePropertyInfo.GetCustomAttributes<ValidationAttribute>());
				}

				//propertiesValidationAttributes.Add(propertyInfo.Name, propertyValidationAttributes);
				propertiesValidationAttributes[propertyInfo.Name] = propertyValidationAttributes;
			}
		}

		private static void RegisterMetadataType(Type type)
		{
			var metaDataType = type.GetCustomAttribute<MetadataTypeAttribute>(false);
			if (metaDataType != null)
			{
				TypeDescriptor.AddProviderTransparent(
					new AssociatedMetadataTypeTypeDescriptionProvider(type, metaDataType.MetadataClassType),
					type);
			}
		}

		public static void Set(MetaObject metaObject)
		{
			MetaObject.cache["{0}Meta".FormatWith(metaObject.FullName)] = metaObject;
		}

		#endregion Static

		private IDictionary<string, MetaProperty> properties = new ConcurrentDictionary<string, MetaProperty>(StringComparer.OrdinalIgnoreCase);
        
		private IList<ValidationAttribute> validationAttributes = null;
        
		public string FullName { get; set; }
        
		public string Name { get; set; }
        
		public string TableName { get; set; }
        
		public IEnumerable<ValidationAttribute> ValidationAttributes { get; set; }

		public MetaObject() {}

		public MetaObject(string tableName) : this()
		{
			this.TableName = tableName;
		}

		public bool HasEntityKey()
		{
			return GetEntityKey() != null;
		}

		public MetaProperty GetEntityKey()
		{
			var data = this.Where(p => p.IsKey).ToArray();
			return data.Count() == 1 ? data.FirstOrDefault() : null;
		}

		public string GetEntityKeyName()
		{
			var entityKey = GetEntityKey();
			return entityKey != null ? entityKey.Name : String.Empty;
		}

		public MetaProperty this[string propertyName]
		{
			get 
			{ 
				return this.properties.ContainsKey(propertyName) 
					? this.properties[propertyName] : null; 
			}
			set 
			{
				if (value.Parent == null)
					value.Parent = this;

				this.properties[propertyName] = value; 
			}
		}
		public void Add(MetaProperty metaProperty)
		{
			this.properties[metaProperty.Name] = metaProperty;
		}

		public override string ToString()
		{
			return this.Name;
		}

		public IEnumerator<MetaProperty> GetEnumerator()
		{
			return this.properties.Values.GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.GetEnumerator();
		}
	}
}
