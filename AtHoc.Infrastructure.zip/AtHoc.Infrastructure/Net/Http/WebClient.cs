﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;

namespace AtHoc.Infrastructure.Net.Http
{
    /// <summary>
    /// 
    /// </summary>
    public class WebClient : System.Net.WebClient
    {
        /// <summary>
        /// 
        /// </summary>
        private CookieContainer cookieContainer = null;

        /// <summary>
        /// 
        /// </summary>
        public WebClient()
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cookieContainer"></param>
        public WebClient(CookieContainer cookieContainer)
        {
            this.cookieContainer = cookieContainer;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="address"></param>
        /// <returns></returns>
        protected override WebRequest GetWebRequest(Uri address)
        {
            var webRequest = base.GetWebRequest(address);

            if (this.cookieContainer != null &&
                webRequest is HttpWebRequest)
            {
                (webRequest as HttpWebRequest).CookieContainer = this.cookieContainer;
            }

            return webRequest;
        }
    }
}
