﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Net;
using System.IO;
using System.Collections.Specialized;
using Krystalware.UploadHelper;
using AtHoc.Infrastructure.Serialization;
using AtHoc.Infrastructure.Ioc;
using System.IO.Compression;

namespace AtHoc.Infrastructure.Net.Http
{
    /// <summary>
    /// 
    /// </summary>
    public class HttpCommunication
    {
        /// <summary>
        /// 
        /// </summary>
        private string response = null;
        private Uri responseUri = null;
        private Dictionary<string, object> parameters = new Dictionary<string, object>();
        private List<HttpFileUpload> fileUploads = new List<HttpFileUpload>();
        private ISerializer serializer = ServiceLocator.Resolve<IJsonSerializer>();
        private CookieContainer cookieContainer = null;

        /// <summary>
        /// 
        /// </summary>
        public HttpCommunication()
        {
            this.EncodeParameters = true;
            this.ParameterEncryptedName = "p";
        }

        /// <summary>
        /// 
        /// </summary>
        public string Url { get; private set; }

        /// <summary>
        /// 
        /// </summary>
        public bool EncodeParameters { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public bool EncryptParameters { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string ParameterEncryptedName { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Referer { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string UserAgent { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public string Response
        {
            get { return this.response; }
        }

        /// <summary>
        /// 
        /// </summary>
        public Uri ResponseUri
        {
            get { return this.responseUri; }
        }

        /// <summary>
        /// 
        /// </summary>
        public void Clear()
        {
            if (this.parameters != null)
            {
                this.parameters.Clear();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="url"></param>
        /// <param name="cookieContainer"></param>
        /// <returns></returns>
        public HttpCommunication Connect(string url, 
            CookieContainer cookieContainer = null)
        {
            if (this.Url.IsNotNullOrEmpty())
                this.Referer = this.Url;
            this.Url = url;
            this.cookieContainer = cookieContainer;

            this.Clear();

            return this;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        /// <param name="value"></param>
        public HttpCommunication Add(string name, object value)
        {
            name = name.Trim();
            if (string.IsNullOrEmpty(name) == false &&
                value != null)
            {
                this.parameters.Add(name, value);
            }
            return this;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        /// <param name="value"></param>
        public HttpCommunication Add(string name, string value)
        {
            if (string.IsNullOrEmpty(name) == false &&
                value != null)
            {
                this.parameters.Add(name, value);
            }
            return this;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        public HttpCommunication Add(HttpRequestBase request)
        {
            this.Add(request.QueryString);
            this.Add(request.Form);
            return this;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="nameValueCollection"></param>
        public HttpCommunication Add(NameValueCollection nameValueCollection)
        {
            if (nameValueCollection != null)
            {
                for (int i = 0; i < nameValueCollection.Count; i++)
                {
                    this.Add(nameValueCollection.GetKey(i), nameValueCollection[i]);
                }
            }
            return this;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fileUpload"></param>
        public HttpCommunication Add(HttpFileUpload fileUpload)
        {
            if (fileUpload != null)
            {
                this.fileUploads.Add(fileUpload);
            }
            return this;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private string GenerateParameterString()
        {
            if (this.parameters.Count > 0)
            {
                bool looped = false;
                StringBuilder parameterString = new StringBuilder();

                foreach (var item in this.parameters)
                {
                    string value = string.Empty;
                    if (item.Value != null)
                    {
                        if (item.Value is string)
                        {
                            value = (string)item.Value;
                        }
                        else
                        {
                            if (this.serializer != null) 
                                value = this.serializer.Serialize(item.Value); else value = item.Value.ToString();
                        }
                        if (this.EncodeParameters) value = HttpUtility.UrlEncode(value);
                    }

                    if (looped) parameterString.Append("&");
                    parameterString.Append(item.Key).Append("=").Append(value);
                    looped = true;
                }

                return parameterString.ToString();
            }
            else
            {
                return string.Empty;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="contentType"></param>
        /// <returns></returns>
        public string InvokePost(string contentType = "application/x-www-form-urlencoded")
        {
            this.response = null;
            this.responseUri = null;
            string parameterString = this.GenerateParameterString();
            HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(this.Url);
            webRequest.CookieContainer = this.cookieContainer;
            webRequest.UserAgent = this.UserAgent;
            webRequest.Referer = this.Referer;
            webRequest.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8";
            webRequest.Headers.Add("Accept-Language", "en-us,en;q=0.5");
            webRequest.Headers.Add("Accept-Encoding", "gzip,deflate");
            webRequest.Headers.Add("Accept-Charset", "ISO-8859-1,utf-8;q=0.7,*;q=0.7");
            webRequest.KeepAlive = true;
            webRequest.Method = "POST";

            if (this.fileUploads.Count > 0)
            {
                return InvokePostWithUpload(parameterString, webRequest);
            }
            else
            {
                return InvokePostWithoutUpload(parameterString, webRequest, contentType);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="parameterString"></param>
        /// <param name="webRequest"></param>
        /// <returns></returns>
        private string InvokePostWithUpload(string parameterString, HttpWebRequest webRequest)
        {
            using (var webResponse = HttpUploadHelper.Upload(webRequest, this.fileUploads.ConvertAll(x => new UploadFile(x.FileName, x.Name)), parameterString.ToNameValueCollection()))
            using (StreamReader streamReader = new StreamReader(webResponse.GetResponseStream()))
            {
                this.response = streamReader.ReadToEnd();
                this.responseUri = webResponse.ResponseUri;
            }

            return this.response;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="parameterString"></param>
        /// <param name="webRequest"></param>
        /// <param name="contentType"></param>
        /// <returns></returns>
        private string InvokePostWithoutUpload(string parameterString, HttpWebRequest webRequest, string contentType)
        {
            webRequest.ContentLength = parameterString.Length;
            webRequest.ContentType = contentType;

            using (StreamWriter streamWriter = new StreamWriter(webRequest.GetRequestStream()))
            {
                streamWriter.Write(parameterString);
                streamWriter.Flush();
            }

            using (HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse())
            using (StreamReader streamReader = new StreamReader(webResponse.GetResponseStream()))
            {
                this.response = streamReader.ReadToEnd();
                this.responseUri = webResponse.ResponseUri;
            }

            return this.response;
        }

        /// <summary>
        /// 
        /// </summary>
        public string InvokeGet()
        {
            if (this.fileUploads.Count > 0) throw (new InvalidOperationException("InvokeGet cannot contains file uploads, please use InvokePost."));

            this.response = null;
            this.responseUri = null;
            string parameterString = this.GenerateParameterString();
            string appendParameter = (this.Url.IndexOf("?") > -1) ? "&" : "?";

            string url = this.Url + ((parameterString.Length > 0) ? appendParameter + parameterString : string.Empty);

            HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);
            webRequest.CookieContainer = this.cookieContainer;
            webRequest.UserAgent = this.UserAgent;
            webRequest.Referer = this.Referer;
            webRequest.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8";
            webRequest.Headers.Add("Accept-Language", "en-us,en;q=0.5");
            webRequest.Headers.Add("Accept-Encoding", "gzip,deflate");
            webRequest.Headers.Add("Accept-Charset", "ISO-8859-1,utf-8;q=0.7,*;q=0.7");
            webRequest.KeepAlive = true;
            webRequest.Method = "GET";

            using (HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse())
            using (StreamReader streamReader = new StreamReader(webResponse.GetResponseStream()))
            {
                var contentEncoding = webResponse.ContentEncoding;

                if (contentEncoding.IsNotNullOrEmpty() &&
                    contentEncoding.ToLower().Contains("gzip"))
                {
                    byte[] bytes = DecompressGzip(streamReader.BaseStream);
                    this.response = Encoding.GetEncoding(webResponse.CharacterSet).GetString(bytes);
                }
                else if (contentEncoding.IsNotNullOrEmpty() &&
                    contentEncoding.ToLower().Contains("deflate"))
                {
                    byte[] bytes = DecompressDeflate(streamReader.BaseStream);
                    this.response = Encoding.GetEncoding(webResponse.CharacterSet).GetString(bytes);
                }
                else
                {
                    this.response = streamReader.ReadToEnd();
                }
                this.responseUri = webResponse.ResponseUri;
            }

            return this.response;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public T InvokeGet<T>()
        {
            this.InvokeGet();
            return (T)this.serializer.Deserialize(this.Response, typeof(T));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="contentType"></param>
        /// <returns></returns>
        public T InvokePost<T>(string contentType = "application/x-www-form-urlencoded")
        {
            this.InvokePost(contentType);
            return (T)this.serializer.Deserialize(this.Response, typeof(T));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="file"></param>
        public void SaveAs(string fileName)
        {
            using (var webClient = new WebClient(this.cookieContainer))
            {
                webClient.DownloadFile(this.Url, fileName);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="streamInput"></param>
        /// <returns></returns>
        private byte[] DecompressDeflate(Stream streamInput)
        {
            Stream streamOutput = new MemoryStream();
            int iOutputLength = 0;
            try
            {
                byte[] readBuffer = new byte[4096];

                /// read from input stream and write to gzip stream

                using (DeflateStream streamDeflate = new DeflateStream(streamInput, CompressionMode.Decompress))
                {

                    int i;
                    while ((i = streamDeflate.Read(readBuffer, 0, readBuffer.Length)) != 0)
                    {
                        streamOutput.Write(readBuffer, 0, i);
                        iOutputLength = iOutputLength + i;
                    }
                }
            }
            catch
            {
                // todo: handle exception
            }

            /// read uncompressed data from output stream into a byte array

            byte[] buffer = new byte[iOutputLength];
            streamOutput.Position = 0;
            streamOutput.Read(buffer, 0, buffer.Length);

            return buffer;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="streamInput"></param>
        /// <returns></returns>
        private byte[] DecompressGzip(Stream streamInput)
        {
            Stream streamOutput = new MemoryStream();
            int iOutputLength = 0;
            try
            {
                byte[] readBuffer = new byte[4096];

                /// read from input stream and write to gzip stream

                using (GZipStream streamGZip = new GZipStream(streamInput, CompressionMode.Decompress))
                {

                    int i;
                    while ((i = streamGZip.Read(readBuffer, 0, readBuffer.Length)) != 0)
                    {
                        streamOutput.Write(readBuffer, 0, i);
                        iOutputLength = iOutputLength + i;
                    }
                }
            }
            catch
            {
                // todo: handle exception
            }

            /// read uncompressed data from output stream into a byte array

            byte[] buffer = new byte[iOutputLength];
            streamOutput.Position = 0;
            streamOutput.Read(buffer, 0, buffer.Length);

            return buffer;
        }
    }
}
