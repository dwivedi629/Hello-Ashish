﻿
namespace AtHoc.SingleSignOn
{
    public class SSOServiceFactory
    {
        public static ISSOService GetSSOService()
        {
            return new EasySSOService();
        }
    }
}
