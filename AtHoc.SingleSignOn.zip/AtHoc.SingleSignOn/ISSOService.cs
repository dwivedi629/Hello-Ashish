﻿using System.Collections.Generic;
using System.Web;

namespace AtHoc.SingleSignOn
{
    public interface ISSOService
    {
        SSOResult SPReceiveSSO(HttpRequest request);

        void IdPInitiateSSO(HttpResponse httpResponse, string partnerSPName,string username, IDictionary<string, IList<string>> attributes);
    }
}