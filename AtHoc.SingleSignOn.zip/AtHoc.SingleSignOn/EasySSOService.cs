﻿using SSOEasy.EasyConnect.Integration;
using System.Collections.Generic;
using System.Web;

namespace AtHoc.SingleSignOn
{
    public class EasySSOService : ISSOService
    {
        public SSOResult SPReceiveSSO(HttpRequest request)
        {
            var ssoEasyResult = ServiceProvider.ReceiveSSO(request);
            return new SSOResult(ssoEasyResult.Attributes,ssoEasyResult.AuthnContext,ssoEasyResult.DomainName,ssoEasyResult.TargetSPUrl,ssoEasyResult.UserName);
        }

        public void IdPInitiateSSO(HttpResponse httpResponse, string partnerSPName,  string username, IDictionary<string, IList<string>> attributes)
        {
            IdentityProvider.InitiateSSO(httpResponse, partnerSPName, null, username, attributes,null);
        }
    }
}
