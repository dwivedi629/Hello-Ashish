﻿using System.Collections.Generic;
using System.Linq;

namespace AtHoc.SingleSignOn
{
    public class SSOResult
    {
        private IDictionary<string, IList<string>> _attributes;
        private string _authnContext;
        private string _domainName;
        private string _targetSPUrl;
        private string _username;

        public SSOResult(IDictionary<string, IList<string>> attributes, string authnContext, string domainName, string targetSPUrl, string username)
        {
            _attributes = attributes;
            _authnContext = authnContext;
            _domainName = domainName;
            _targetSPUrl = targetSPUrl;
            _username = username;
        }

        public string GetAttributeValue(string key)
        {
            string value = null;
            IList<string> values;
            if(Attributes.TryGetValue(key,out values))
            {
                value = values.FirstOrDefault();
            }

            return value;
        }

        public IList<string> GetAttributeValues(string key)
        {
            IList<string> values;
            return Attributes.TryGetValue(key, out values) ? values : null;
        }

        public IDictionary<string, IList<string>> Attributes
        {
            get { return _attributes; }
        }

        public string AuthnContext
        {
            get { return _authnContext; }
        }

        public string DomainName
        {
            get { return _domainName; }
        }

        public string TargetSPUrl
        {
            get { return _targetSPUrl; }
        }

        public string Username
        {
            get { return _username; }
        }
    }
}