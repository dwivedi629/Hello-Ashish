﻿using AtHoc.Infrastructure.Ioc;
using AtHoc.Infrastructure.Ioc.SimpleInjector;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Log.EventLog;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Entities;
using System.Collections.Generic;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace AtHoc.IWS.WebApi
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            GlobalConfiguration.Configure(WebApiConfig.Register);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            //Database.SetInitializer<AtHocDbContext>(null);
            //DatabaseNotification.StartMonitor();

            //ServiceLocator.Current = new SimpleInjectorServiceLocator();
            //var l = new ProvisioningServiceLoader();
            //l.Load(ServiceLocator.Current);
            ////ServiceLocator.Current.LoadAll();
            //ServiceLocator.Current.InitializeDependencyResolver(Assembly.GetExecutingAssembly());

            if (ServiceLocator.Current == null || ServiceLocator.Current.Resolve<IRuntimeContext>() == null)
            {
                ServiceLocator.Current = new SimpleInjectorServiceLocator();
                ServiceLocator.Current.LoadAll();
                ServiceLocator.Current.Register<ILogService, AtHocEventLogger>(ServiceLifecycle.Singleton);
                ServiceLocator.Current.Register<IRuntimeContext, StandAloneRuntimeContext>(ServiceLifecycle.Singleton);
            }
        }
    }

    /// <summary>
    /// Standalone Implementation of IRuntimeContext.
    /// This is required for background job, which does not have HTTPContext, thus explictly Implement IRuntimecontext with only required property.
    /// DI won't work, in case of background job.
    /// </summary>
    public class StandAloneRuntimeContext : IRuntimeContext
    {
        public StandAloneRuntimeContext()
        {

            Provider = new Provider { Id = 1, BaseLocale = "en-US" };
            Operator = new OperatorUser
            {
                Id = 1,
                Username = "athocadmin",
                OperatorAccess = new List<OperatorAccess>
				{
					new OperatorAccess { ActionType = ActionType.Modify, ObjectId = (int) SystemObject.Organization },
					new OperatorAccess { ActionType = ActionType.View, ObjectId = (int) SystemObject.Organization}
				}
            };
        }

        public Provider Provider { get; private set; }

        public OperatorUser Operator { get; private set; }
        public User LoggedOnUser { get; private set; }

        public OperatorUser RefreshedOperatorContext() { return null; }

        public Provider RefreshedProviderContext() { return null; }

    }
}
