﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AtHoc.Infrastructure.Ioc;
using AtHoc.IWS.Business.Context;
//using AtHoc.IWS.Web.Context;
//using AtHoc.IWS.Web.Converter;
//using AtHoc.IWS.Web.Converter.SearchCriteria;
//using AtHoc.IWS.Web.Helpers;


namespace AtHoc.IWS.WebApi
{
    //public class ProvisioningServiceLoader : IServiceLoader
    //{
    //    public int SortOrder
    //    {
    //        get { return 99; }
    //    }

    //    public void Load(IServiceLocator container)
    //    {
    //        //TEMP CODE
    //        var serviceLoader = new AtHoc.IWS.Business.Ioc.AtHocServiceLoader();
    //        serviceLoader.Load(container);

    //        //container.Register<IRuntimeContext, HttpRuntimeContext>(ServiceLifecycle.Singleton);
    //        //container.Register<ISearchCriteriaConverter, SearchCriteriaConverter>(ServiceLifecycle.Singleton);
    //        //container.Register<IIpListConverter, IpListConverter>(ServiceLifecycle.Singleton);
    //        //container.Register<IUserManagerHelper, UserManagerHelper>(ServiceLifecycle.Singleton);
    //    }
    //}
}