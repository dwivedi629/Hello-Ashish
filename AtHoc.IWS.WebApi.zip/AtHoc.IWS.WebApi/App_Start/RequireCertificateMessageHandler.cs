﻿using AtHoc.Diagnostics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography.X509Certificates;
using System.Security.Principal;
using System.Threading;
using System.Threading.Tasks;
using System.Web;

namespace AtHoc.NDS.Provisioning.Web.Api
{
    public class RequireCertificateMessageHandler : DelegatingHandler
    {
        private string AcceptedThumbprint = string.Empty;
        private bool ValidateCertificate(X509Certificate2 cert, out string message)
        {
            if (cert == null)
            {
                message = "A trusted client certificate was not provided.";
                return false;
            }
            if (!cert.Thumbprint.Equals(AcceptedThumbprint, StringComparison.OrdinalIgnoreCase))
            {
                message = "\"" + cert.Thumbprint + "\" is not a trusted client certificate thumbprint.";
                return false;
            }
            message = string.Empty;
            return true;
        }

        public RequireCertificateMessageHandler(string thumbprint)
        {
            if (string.IsNullOrEmpty(thumbprint))
            {
                throw new Exception("A client certificate thumbprint must be configured.");
            }
            this.AcceptedThumbprint = thumbprint;
        }

        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            X509Certificate2 cert = request.GetClientCertificate();
            string message;

            if (!ValidateCertificate(cert, out message))
            {
                EventLogger.WriteError(message);
                return Task.Factory.StartNew(() => request.CreateResponse(HttpStatusCode.Unauthorized));
            }

            Thread.CurrentPrincipal = new GenericPrincipal(new GenericIdentity(cert.Subject, "ClientCertificate"), null);
            return base.SendAsync(request, cancellationToken);
        }
    }
}