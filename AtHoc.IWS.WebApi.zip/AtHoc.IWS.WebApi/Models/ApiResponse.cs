﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AtHoc.IWS.WebApi.Models
{
    public class ApiResponse<T>
    {
        /// <summary>
        /// OK - success or error code
        /// </summary>
        public string StatusCode { get; set; }
        public string StatusMessage { get; set; }
        public T Result { get; set; }
    }
}