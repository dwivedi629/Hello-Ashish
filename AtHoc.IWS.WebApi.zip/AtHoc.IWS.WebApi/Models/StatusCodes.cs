﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AtHoc.IWS.WebApi.Models
{
    public static class StatusCodes
    {
        public const string Ok = "OK";

        public const string OrgInvalidName = "252222";
        public const string OrgExists = "252223";
        public const string OrgNotFound = "252224";

        public const string UserInvalidName = "252301";
        public const string UserDuplicateName = "252302";
        public const string InvalidPassword = "252303";

        public const string GatewayInvalidId = "252422";
        public const string GatewayInvalidServiceUrl = "252423";
        public const string GatewayInvalidUsername = "252424";
        public const string GatewayInvalidPassword = "252425";
        public const string GatewayNotFound = "252426";

        public const string SystemInternalError = "25ZZZZ";
    }
}