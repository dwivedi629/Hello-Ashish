﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace AtHoc.IWS.WebApi.Models
{
    public class Gateway
    {
        public string Id { get; set; }
        public string Url{ get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }
}