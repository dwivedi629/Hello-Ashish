﻿using System;
using System.Collections.Generic;

namespace AtHoc.IWS.WebApi.Models
{
    public class OrganizationSpec
    {
        public OrganizationSpec()
        {
            TemplateOrgId = 0;
            Name = String.Empty;
            OrgCode = String.Empty;
            Logo = new LogoInfo();
        }

        public int TemplateOrgId { get; set; }
        public string Name { get; set; }
        public string OrgCode { get; set; }
        public LogoInfo Logo { get; set; }
    }

    public class LogoInfo
    {
        public LogoInfo()
        {
            LogoContent = String.Empty;
            Extension = "jpg";
        }

        public string LogoContent { get; set; }
        public string Extension { get; set; }
    }
}