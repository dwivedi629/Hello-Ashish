﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AtHoc.IWS.WebApi.Models;

namespace AtHoc.IWS.WebApi.IWS
{
    public static class ApiUtility
    {
        public static void FillStatus<T>(ApiResponse<T> rep, string statusCode, string statusMessage = null)
        {
            rep.StatusCode = statusCode;
            rep.StatusMessage = statusMessage ?? Resource.ResourceManager.GetString(statusCode);
        }
    }
}