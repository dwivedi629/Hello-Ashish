﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;
using AtHoc.Infrastructure;
using AtHoc.IWS.WebApi.Models;
using AtHoc.MediaServices;
using AtHoc.VirtualSystems;
using WebGrease.Css.Extensions;

namespace AtHoc.IWS.WebApi.IWS
{
    public class IwsOrganizationService
    {
        private VirtualSystemService _vpsSvc;
        public IwsOrganizationService()
        {
            _vpsSvc = new VirtualSystemService();
        }
        public bool OrgExists(int orgId)
        {
            return !string.IsNullOrEmpty(_vpsSvc.GetProviderNameById(orgId));
        }
        public bool OrgExists(string orgName)
        {
            return _vpsSvc.GetProviderIdByName(orgName) > 0;
        }

        public int CreateOrganization(int templateOrgId, string name, string orgCode, LogoInfo logo)
        {
            var vpsId = _vpsSvc.DuplicateProvider(templateOrgId, name, orgCode, 1, true);
            
            var webLogoImageGuid = UploadImage(logo);
            if (webLogoImageGuid != Guid.Empty)
            {
                var vps = _vpsSvc.GetById(vpsId);
                vps.WebLogoImageId = webLogoImageGuid.ToString().ToUpper();
                _vpsSvc.UpdateVps(vps);
            }

            return vpsId;
        }

        public IEnumerable<VPSInfo> GetOrganizations()
        {
            var vs = _vpsSvc.GetAll();
            var list = new List<VPSInfo>();
            vs.ForEach(v => list.Add(new VPSInfo(v.Id, v.Name, v.OrgCode, v.ProviderType)));
            return list;
        }

        public VPSInfo GetOrganizationById(int id)
        {
            var vs = _vpsSvc.GetById(id);

            return new VPSInfo(vs.Id, vs.Name, vs.OrgCode, vs.ProviderType);
        }

        public Guid UploadImage(LogoInfo logo)
        {
            if (logo == null || logo.LogoContent.IsNullOrEmpty() || logo.LogoContent.Trim().IsNullOrEmpty()) return Guid.Empty;

            //http://stackoverflow.com/questions/351126/convert-a-string-to-stream

            var rawLogo = Convert.FromBase64String(logo.LogoContent);
            var streamLogo = new MemoryStream(rawLogo);

            var wMediaInfo = new MediaInfo
            {
                Source = @"Web Logo",
                Description = "",
                AllowWebAccess = true,
                ContentType = "image/" + logo.Extension,
                Extension = logo.Extension,
                Height = 0,
                Width = 0,
                Rotation = 0
            };

            Guid mediaId;
            var service = new MediaService();
            var content = service.CreateMedia(wMediaInfo, out mediaId);
            content.SetContent(streamLogo);
            return mediaId;
        }
    }

    public class VPSInfo
    {
        public VPSInfo(int providerId)
        {
            ProviderId = providerId;
        }

        public VPSInfo(int providerId, string name) : this(providerId)
        {
            Name = name;
        }

        public VPSInfo(int providerId, string name, string orgCode) : this(providerId, name)
        {
            OrgCode = orgCode;
        }

        public VPSInfo(int providerId, string name, string orgCode, VPSType providerType) : this(providerId, name, orgCode)
        {
            switch (providerType)
            {
                case VPSType.Parking:
                    ProviderType = "PARKING";
                    break;
                case VPSType.System:
                    ProviderType = "SYSTEM";
                    break;
                case VPSType.EnterpriseTemplate:
                    ProviderType = "ENTTEMPLATE";
                    break;
                case VPSType.Enterprise:
                    ProviderType = "ENTERPRISE";
                    break;
                case VPSType.Sub:
                    ProviderType = "SUB";
                    break;
                case VPSType.Affiliate25Template:
                    ProviderType = "AFF25TEMPLATE";
                    break;
                case VPSType.Affiliate25:
                    ProviderType = "AFF25";
                    break;
                default:
                    throw new Exception("Invalid ProviderType Encountered in PRV_EXTENDED_PARAMS_TAB");
            }
        }

        public VPSInfo(int providerId, string name, string orgCode, VPSType providerType, string base64Logo) : this(providerId, name, orgCode, providerType)
        {
            Base64Logo = base64Logo;
        }

        public int ProviderId { get; set; }
        public string Name { get; set; }
        public string OrgCode { get; set; }
        public string ProviderType { get; set; }
        public string Base64Logo { get; set; }
    }
}