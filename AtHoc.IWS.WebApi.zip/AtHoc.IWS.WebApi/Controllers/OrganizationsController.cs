﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using AtHoc.Data;
using AtHoc.Diagnostics;
using AtHoc.IWS.WebApi.IWS;
using AtHoc.IWS.WebApi.Models;
using AtHoc.Utilities;


namespace AtHoc.IWS.WebApi
{
    public class OrganizationsController : ApiController
    {
        [Route("Organizations")]
        public ApiResponse<IEnumerable<Organization>> Get()
        {
            var rep = new ApiResponse<IEnumerable<Organization>>();
            try
            {
                var svc = new IwsOrganizationService();
                var orgs = svc.GetOrganizations();
                rep.StatusCode = StatusCodes.Ok;
                rep.Result = (from o in orgs orderby o.ProviderId select new Organization { Id = o.ProviderId, Name = o.Name, OrgCode = o.OrgCode, Type = o.ProviderType}).ToList();
            }
            catch (Exception ex)
            {
                rep.StatusCode = StatusCodes.SystemInternalError;
                rep.StatusMessage = ex.Message;
                EventLogger.WriteError(string.Format("Get All Organizations"), ex);
            }

            return rep;
        }

        [Route("Organizations/{organizationId}")]
        public ApiResponse<IEnumerable<Organization>> Get(int organizationId)
        {
            var rep = new ApiResponse<IEnumerable<Organization>>();
            try
            {
                var svc = new IwsOrganizationService();
                var orgs = svc.GetOrganizations();
                rep.StatusCode = StatusCodes.Ok;
                rep.Result = (from o in orgs where o.ProviderId == organizationId select new Organization { Id = o.ProviderId, Name = o.Name, OrgCode = o.OrgCode, Type = o.ProviderType }).ToList();
            }
            catch (Exception ex)
            {
                rep.StatusCode = StatusCodes.SystemInternalError;
                rep.StatusMessage = ex.Message;
                EventLogger.WriteError(string.Format("Get Organization"), ex);
            }

            return rep;
        }

        [Route("Organizations")]
        public ApiResponse<Organization> Post([FromBody]OrganizationSpec spec)
        {
            var rep = new ApiResponse<Organization>();

            try
            {
                if (ValidateNewOrgSpec(spec, rep))
                {
                    var svc = new IwsOrganizationService();
                    var orgId = svc.CreateOrganization(spec.TemplateOrgId, spec.Name, spec.OrgCode, spec.Logo);

                    if (orgId > 0)
                    {
                        var vs = svc.GetOrganizationById(orgId);

                        rep.StatusCode = StatusCodes.Ok;
                        rep.Result = new Organization {Id = vs.ProviderId, Name = vs.Name, OrgCode = vs.OrgCode, Type = vs.ProviderType};
                    }
                    else
                    {
                        ApiUtility.FillStatus(rep, StatusCodes.SystemInternalError);
                    }
                }
            }
            catch (Exception ex)
            {
                rep.StatusCode = StatusCodes.SystemInternalError;
                rep.StatusMessage = ex.Message;
                EventLogger.WriteError(string.Format("New Organization Request: {0}, ", spec.Serialize()), ex);
            }

            return rep;
        }

        private static bool ValidateNewOrgSpec(OrganizationSpec spec, ApiResponse<Organization> rep)
        {
            var svc = new IwsOrganizationService();

            if (string.IsNullOrEmpty(spec.Name))
            {
                ApiUtility.FillStatus(rep, StatusCodes.OrgInvalidName);
                return false;
            }

            if (svc.OrgExists(spec.Name))
            {
                ApiUtility.FillStatus(rep, StatusCodes.OrgExists);
                return false;
            }

            if (!svc.OrgExists(spec.TemplateOrgId))
            {
                ApiUtility.FillStatus(rep, StatusCodes.OrgNotFound);
                return false;
            }

            return true;
        }
    }
}