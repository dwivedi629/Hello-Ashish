﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Web.Http;
using AtHoc.Infrastructure.Ioc;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.Devices.Impl;
using AtHoc.IWS.Business.Domain.Devices.Spec;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Users;
using AtHoc.IWS.Business.Domain.Users.Impl;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.IWS.Business.Domain.VirtualSystem.Impl;
using AtHoc.IWS.Business.Domain.VirtualSystem.Spec;
using AtHoc.IWS.WebApi.IWS;
using AtHoc.IWS.WebApi.Models;
using AtHoc.Security;
using User = AtHoc.IWS.WebApi.Models.User;
using IwsUser = AtHoc.IWS.Business.Domain.Entities.User;
using UserSpec = AtHoc.IWS.WebApi.Models.UserSpec;

namespace AtHoc.IWS.WebApi.Controllers
{
    public class UsersController : ApiController
    {
        [Route("Organizations/{organizationId}/Users")]
        public ApiResponse<User> Post(int organizationId, [FromBody]UserSpec user)
        {
            var rep = new ApiResponse<User>();
            try
            {
                if (ValidateNewUserSpec(user, rep, organizationId))
                {
                    var userId = CreateOrgAdmin(organizationId, user);
                    if (userId > 0)
                    {
                        rep.StatusCode = StatusCodes.Ok;
                        rep.Result = new User { Id = userId, Password = user.Password, FirstName = user.FirstName, LastName = user.LastName, Username = user.Username, WorkEmail = user.WorkEmail, WorkPhone = user.WorkPhone, TextPhone = user.TextPhone };
                    }
                }
            }
            catch (Exception ex)
            {
                rep.StatusCode = StatusCodes.SystemInternalError;
                rep.StatusMessage = ex.Message;
            }

            return rep;
        }

        private static bool ValidateNewUserSpec(UserSpec user, ApiResponse<User> rep, int organizationId)
        {
            var validateUsername = UserHelper.VerfiyUsername(user.Username, true, organizationId);
            if (!validateUsername.IsValid)
            {
                ApiUtility.FillStatus(rep, StatusCodes.UserInvalidName, validateUsername.Messages[0].ToString());
                return false;
            }

            var passwordComplexity = UserHelper.VerifyPasswordComplexity(user.Password, organizationId);
            if (!passwordComplexity.IsValid)
            {
                var messages = passwordComplexity.Messages;
                var errors = new StringBuilder();

                foreach (var message in messages)
                    errors.AppendLine(message.ToString());

                ApiUtility.FillStatus(rep, StatusCodes.InvalidPassword, errors.ToString());
                return false;
            }

            return true;
        }

        private static int CreateOrgAdmin(int orgId, UserSpec user)
        {
            ServiceLocator.Resolve<IRuntimeContext>().Provider.Id = orgId;
            ServiceLocator.Resolve<IRuntimeContext>().Operator.Id = 1;

            var userFacade = new UserFacade();
            var deviceFacade = new DeviceFacade(AtHocDbContextFactory.CreateFactory());
            var vpsFacade = new VirtualSystemFacade(AtHocDbContextFactory.CreateFactory());

            var endUser = new IwsUser { UserName = user.Username, Token = "athoc", FirstName = user.FirstName, LastName = user.LastName, ProviderId = orgId };

            #region Save User

            var systemUser = new SystemUser
            {
                User = endUser,
                OperatorUser = new OperatorUser { Username = user.Username, MappingId = user.Username }
            };

            userFacade.SaveUser(new UserSaveSpec { SystemUser = systemUser, });

            #endregion

            #region Update User Properties

            #region Get and Update User Attributes

            var providerAttributes = RuntimeContext.CustomAttributesWithouMassDevices;
            var attributes = new List<CustomAttribute>();

            //regardless of whether it's Manual Authentication or not, inserting the USER_RANDOM_ID attribute value for the user
            var userRandomId = providerAttributes.FirstOrDefault(c => c.CommonName == "USER_RANDOM_ID");
            if (userRandomId != null)
            {
                userRandomId.UserAttributeValue = PegasusSecurityHelper.GenerateSecureRandom(16);
                attributes.Add(userRandomId);
            }
            
            //set the org hierarchy to root org hierarchy
            var orgHierarchy =  userFacade.GetHierarchyBySpec(new HierarchySpec
            {
                ProviderId = orgId,
                AvailableForLists = false,
                HierarchyType = HierarchyType.ORG
            }).FirstOrDefault();

            if (orgHierarchy != null)
            {
                var orgHierarchyCommonName = orgHierarchy.CommonName;
                var orgHierarchyAttr = providerAttributes.FirstOrDefault(c => String.Compare(c.CommonName,orgHierarchyCommonName,StringComparison.OrdinalIgnoreCase)==0);
                if (orgHierarchyAttr != null)
                {
                    orgHierarchyAttr.UserAttributeValue = "/";
                    attributes.Add(orgHierarchyAttr);
                }
            }

            #endregion

            #region Get and Update User Devices

            var providerDevices = deviceFacade.GetDevicesBySpec(new DeviceSpec
                {
                    ProviderId = orgId,
                    IncludeDeviceProvider = true,
                    IncludeDeviceGroup = true,
                    GetDeletedDevices = true,
                    EnabledOnly = true,
                    CommonNames = new List<string> { "Email-Work", "workPhone", "sms" },
                },RuntimeContext.Provider.BaseLocale);

            var devices = new List<Device>();

            var enumerable = providerDevices as Device[] ?? providerDevices.ToArray();
            var emailWork = enumerable.FirstOrDefault(x => x.CommonName == "Email-Work");
            if (emailWork != null)
            {
                emailWork.UserAddressValue = user.WorkEmail;
                devices.Add(emailWork);
            }

            var workPhone = enumerable.FirstOrDefault(x => x.CommonName == "workPhone");
            if (workPhone != null)
            {
                workPhone.UserAddressValue = user.WorkPhone;
                devices.Add(workPhone);
            }

            var sms = enumerable.FirstOrDefault(x => x.CommonName == "sms");
            if (sms != null)
            {
                sms.UserAddressValue = user.TextPhone;
                devices.Add(sms);
            }

            #endregion

            userFacade.UpdateCustomAttributesForEndUser(new UserAttributesUpdateSpec
                {
                    ProviderId = orgId,
                    UserId = systemUser.User.Id,
                    UpdatedBy = 1,
                    Attributes = attributes,
                    Devices = devices,
                    LogAudit = false
                });

            #endregion

            #region Save Operator Properties

            var endUserDetails = userFacade.GetUserBySpec(new Business.Domain.Users.Spec.UserSpec
                {
                    ProviderId = orgId,
                    UserId = systemUser.User.Id,
                    GetUserAttributes = true,
                    GetDevices = true
                });

            var opUser = new OperatorUser
            {
                Id = endUserDetails.Id,
                Password = user.Password,
                PasswordNeverExpires = "No",
                NextLoginChangePw = "Yes",
                ExpirationDate = null
            };

            var vps = vpsFacade.GetProviderBySpec(new VirtualSystemSpec { Id = orgId, IncludeExtendedParams = true });

            int roleId;

            switch (vps.ExtendedParams.ProviderType)
            {
                case "AFF25":
                case "AFF25TEMPLATE":
                    roleId = 35; // Affiliate Admin
                    break;
                case "ENTERPRISE":
                case "ENTTEMPLATE":
                    roleId = 21; // Enterprise Admin
                    break;
                case "PARKING":
                case "SUB":
                    roleId = 3; // Organization Admin
                    break;
                case "SYSTEM":
                    roleId = 31; // System Admin
                    break;
                default:
                    throw new Exception("Error. Unknown PROVIDER_TYPE found for VPS " + orgId);
            }

            systemUser = new SystemUser
            {
                User = endUserDetails,
                OperatorUser = opUser,
                Roles = new List<OperatorUserRole> { new OperatorUserRole { RoleId = roleId } }
            };

            systemUser.UnrestrictUserBase();
            systemUser.UnrestrictChannels();
            systemUser.UnrestrictEntityAccess();

            var result = userFacade.SaveUser(
                new UserSaveSpec
                {
                    OperatorId = systemUser.User.Id,
                    SystemUser = systemUser,
                    UserName = endUserDetails.UserName
                }
            );

            #endregion

            return systemUser.User.Id;
        }
    }
}
