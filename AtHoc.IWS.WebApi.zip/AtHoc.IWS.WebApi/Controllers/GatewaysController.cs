﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using AtHoc.Devices;
using AtHoc.Diagnostics;
using AtHoc.EntityExtension;
using AtHoc.IWS.WebApi.IWS;
using AtHoc.IWS.WebApi.Models;
using AtHoc.Utilities;

namespace AtHoc.IWS.WebApi.Controllers
{
    public class GatewaysController : ApiController
    {
        [Route("Organizations/{organizationId}/Gateways/{gatewayId}")]
        public ApiResponse<Gateway> Put(int organizationId, string gatewayId, [FromBody]Gateway gateway)
        {
            var rep = new ApiResponse<Gateway>();
            try
            {
                if (ValidateGatewayParameters(organizationId, gatewayId, gateway, rep))
                {
                    if (UpdateOrgGateway(organizationId, gatewayId, gateway, rep))
                    {
                        rep.StatusCode = StatusCodes.Ok;
                        rep.Result = gateway;
                    }
                }
            }
            catch (Exception ex)
            {
                rep.StatusCode = StatusCodes.SystemInternalError;
                rep.StatusMessage = ex.Message;
                EventLogger.WriteError(string.Format("Update gateway request: {0}, ", gateway.Serialize()), ex);
            }

            return rep;
        }

        private bool ValidateGatewayParameters(int orgId, string gatewayId, Gateway g, ApiResponse<Gateway> rep)
        {
            var svc = new IwsOrganizationService();
            if (!svc.OrgExists(orgId))
            {
                ApiUtility.FillStatus(rep, StatusCodes.OrgNotFound);
                return false;
            }
            if (string.IsNullOrEmpty(gatewayId))
            {
                ApiUtility.FillStatus(rep, StatusCodes.GatewayInvalidId);
                return false;
            }
            if (string.IsNullOrEmpty(g.Url))
            {
                ApiUtility.FillStatus(rep, StatusCodes.GatewayInvalidServiceUrl);
                return false;
            }
            if (string.IsNullOrEmpty(g.Username))
            {
                ApiUtility.FillStatus(rep, StatusCodes.GatewayInvalidUsername);
                return false;
            }
            if (string.IsNullOrEmpty(g.Password))
            {
                ApiUtility.FillStatus(rep, StatusCodes.GatewayInvalidPassword);
                return false;
            }
            return true;
        }

        private bool UpdateOrgGateway(int orgId, string gatewayId, Gateway g, ApiResponse<Gateway> rep)
        {
            var protocolCn = gatewayId;
            //protocolCN = GetProtocolCN(g.DeviceType);

            var protocol = DeviceProtocol.GetProtocol(protocolCn);
            if (protocol == null)
            {
                ApiUtility.FillStatus(rep, StatusCodes.GatewayInvalidId);
                return false;
            }

            var mgr = new ExtensionManager();
            var settings = mgr.GetSettings(protocol, protocol.Id, "Setup", orgId,
                protocol.UIContextExtensionMap["Setup"]);
            if (settings != null)
            {
                SetSettings(settings, g.Url, g.Username, g.Password);

                var def = mgr.GetDefinition(protocol, protocol.Id, "Setup", orgId);
                mgr.SetSettings(protocol, protocol.Id, "Setup", orgId, def.Id, settings);

                // Disable device if username is empty
                //if (string.IsNullOrEmpty(g.Username))
                //    DisableDevice(vpsId, GetDeviceId(g.DeviceType));

                return true;
            }
            
            ApiUtility.FillStatus(rep, StatusCodes.GatewayNotFound);
            return false;
        }

        private void SetSettings(ExtensionSettings settings, string url, string username, string password)
        {
            var urlNode = settings.Transformed.SelectSingleNode("//endPoint");
            if (urlNode != null) urlNode.InnerText = url;

            var unNode = settings.Transformed.SelectSingleNode("//username");
            if (unNode != null) unNode.InnerText = username;

            var pswNode = settings.Transformed.SelectSingleNode("//password");
            if (pswNode != null) pswNode.InnerText = password;

            var list = settings.Raw.SelectNodes("//data/element");
            if (list != null)
            {
                for (var i = 0; i < list.Count; i++)
                {
                    var node = list[i];
                    if (node.Attributes != null)
                    {
                        var attr = node.Attributes["id"];
                        if (attr.Value.Contains("ServerURL"))
                        {
                            node.InnerText = url;
                        }
                        else if (attr.Value.Contains("Username"))
                        {
                            node.InnerText = username;
                        }
                        else if (attr.Value.Contains("Password"))
                        {
                            node.InnerText = password;
                        }
                    }
                }
            }
        }

        //private void DisableDevice(int vpsId, int deviceId)
        //{
        //    var mgr = new DeviceManager(vpsId);
        //    var device = mgr.GetDevice(deviceId);
        //    var list = new List<Device>();
        //    list.Add(device);
        //    DeviceManager.Disable(list, vpsId);
        //}

        //private string GetProtocolCN(string deviceType)
        //{
        //    switch (deviceType)
        //    {
        //        case "TAS":
        //            return "ATHOC-NDMS-EAST";
        //        case "SMS":
        //            return "ATHOC-NDMS-WEST";
        //        case "EMAIL":
        //            return "UAP_SMTP";
        //        case "MPN":
        //            return "UAP_MPN";
        //        default:
        //            return "";
        //    }
        //}

        //private int GetDeviceId(string deviceType)
        //{
        //    switch (deviceType)
        //    {
        //        case "TAS":
        //            return 1001;
        //        case "SMS":
        //            return 1006;
        //        case "EMAIL":
        //            return 11;
        //        case "MPN":
        //            return 1033;
        //        default:
        //            return 0;
        //    }
        //}
    }
}