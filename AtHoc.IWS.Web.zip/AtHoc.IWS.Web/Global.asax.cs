﻿using System.Globalization;
using System.Threading;
using System.Web.Optimization;
using System.Web.Security;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Encryption;
using AtHoc.Infrastructure.Ioc;
using AtHoc.Infrastructure.Ioc.SimpleInjector;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Web.Mvc.ActionFilters;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Web;
using AtHoc.IWS.Web.Helpers;
using AtHoc.IWS.Web.Models.Publishing;
using System;
using System.Data.Entity;
using System.Reflection;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using AtHoc.IWS.Web.Models.Accountability;
using AtHoc.VirtualSystems;
using AtHoc.IWS.Business.Domain.Settings.Impl;
using System.Collections.Generic;
namespace AtHoc.IWS.Web
{
    // Note: For instructions on enabling IIS6 or IIS7 classic mode, 
    // visit http://go.microsoft.com/?LinkId=9394801
    public class MvcApplication : HttpApplication
    {
        #region Application Events

        void Application_Start()
        {
            Database.SetInitializer<AtHocDbContext>(null);
            Database.SetInitializer<AtHocGeoDbContext>(null);

            ServiceLocator.Current = new SimpleInjectorServiceLocator();
            ServiceLocator.Current.LoadAll();
            ServiceLocator.Current.InitializeDependencyResolver(Assembly.GetExecutingAssembly());

            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            CheckUserSessionAttribute.SignOutUrl = "/client/auth/signout";

            EO.Pdf.Runtime.AddLicense(
               "fBrtdpm1x9mvW5ezz7iJWZekseeumuPwACK9RoGkscufdeb29RDxguXqAMvj" +
               "muvpzs23aKm3wN2vaq2msR70m7z8ARTxnurFBeihcaa2xNqxaai7s8v1nun3" +
               "+hrtdpm1x82faLWRm8ufWZfABBTmp9j4Bh3kd9m20+G3bOW5xeLWeq+14xu4" +
               "bKn53BK8drOzBBTmp9j4Bh3kd4SOzdrrotrp/x7kd4SOdePt9BDtrNzCnrWf" +
               "WZekzRfonNzyBBDInbXH4d6zjqe949ywbLDAwBfonNzyBBDInbWRm8ufWZfA" +
               "/RTinuX39hC9dabw+g7kp+rp9umMQ5ekscu7muPwACK9RoGkscufWZeksefg" +
               "ndukBSTvnrSm1vqtidvqs8v1nun3+g==");
            //Register MVCToPDF filter
            EO.Pdf.Mvc.MVCToPDF.RegisterFilter(typeof(GlobalFilters));

            DatabaseNotification.StartMonitor();

            ModelBinders.Binders.Add(typeof(PublishingModel), new CustomModelBinder<PublishingModel>());
            ModelBinders.Binders.Add(typeof(PlaceholderModel), new CustomModelBinder<PlaceholderModel>());
            ModelBinders.Binders.Add(typeof(GeneralSettings), new CustomModelBinder<GeneralSettings>());
            ModelBinders.Binders.Add(typeof(TemplateModel), new CustomModelBinder<TemplateModel>());

        }

        void Application_BeginRequest(object sender, EventArgs e)
        {
            var signalrUrls = GetSignalrUrls();
            var urlReferrerHost = (Request.UrlReferrer == null) ? string.Empty : (Request.UrlReferrer.Host == null ? string.Empty : Request.UrlReferrer.Host);

            if (Request.Path.ToLower().Contains("/signalr/"))
            {
                if (!signalrUrls.Contains(Request.Path.ToLower()))
                {
                    throw new HttpException(404,"Not Found"); 
                }
            }
            if (!string.IsNullOrEmpty(urlReferrerHost) && (urlReferrerHost.ToLower() != Request.Url.Host.ToLower()))
            {
                throw new Exception("Invalid Url Referrer");
            }

            var httpCookie = Request.Cookies[Constants.IwsLanguageCookie];
            if (httpCookie != null && CookieEncryption.UnProtect(httpCookie.Value).ToLower() != Thread.CurrentThread.CurrentUICulture.Name.ToLower())
            {
                // Setting  the selected language to current thread
                Thread.CurrentThread.CurrentUICulture = CookieEncryption.GetCultureInfoByBaseLocale(httpCookie.Value);
            }

            var pathAndQuery = Request.Url.PathAndQuery.ToLower();
            if (pathAndQuery.Contains("/client/auth/login") || pathAndQuery.Contains("/client/auth/signout"))
            {
                var authenticationCookie = HttpContext.Current.Request.Cookies[FormsAuthentication.FormsCookieName];
                if (authenticationCookie != null)
                {
                    var authenticationTicket = FormsAuthentication.Decrypt(authenticationCookie.Value);
                    if (authenticationTicket != null && authenticationTicket.UserData != String.Empty && authenticationTicket.Expired)
                    {
                        var authData = new AuthTicketUserData(authenticationTicket.UserData);
                        if (authData.AuthType == AuthType.SSO)
                        {
                            var SSOSignOutUrl = SystemConfiguration.GetValue(authData.DefaultProviderId, "EXTERNAL_SIGNOUT_URL").Trim();
                            if (!SSOSignOutUrl.IsNullOrEmpty())
                            {
                                authenticationCookie.Expires = DateTime.Now.AddYears(-1);
                                Response.Cookies.Add(authenticationCookie);

                                Response.Redirect(SSOSignOutUrl);
                                Context.ApplicationInstance.CompleteRequest();
                            }
                        }
                    }
                }
            }

        }

        void Application_PreRequestHandlerExecute(Object sender, EventArgs e)
        {
            var userData = AuthHelper.GetAuthTicketUserData();

            if (userData != null)
            {
                var pathAndQuery = Request.Url.PathAndQuery.ToLower();
                if (!pathAndQuery.Contains("/client/auth/changepassword") && !pathAndQuery.Contains("/client/auth/login") && !pathAndQuery.Contains("/client/images/"))
                {
                    if (userData.HasPasswordExpired || userData.IsPasswordChangeRequired)
                    {
                        Response.Redirect("/client/auth/ChangePassword");
                        Context.ApplicationInstance.CompleteRequest();
                    }
                }

                if (userData != null && userData.ProviderId == null && (!pathAndQuery.ToLower().Contains("changeorganization")) && 
                    (!pathAndQuery.ToLower().Contains("/client/auth/getauthcookieexpiration")) && 
                    (!pathAndQuery.ToLower().Contains("/client/auth/keepalive")) && (!pathAndQuery.ToLower().Contains("javascriptresourcehandler")))
                {
                    if (pathAndQuery.ToLower().Contains("/athoc-iws"))
                    {
                        Response.Redirect("/athoc-iws/settings/ChangeOrganization", false);
                        Context.ApplicationInstance.CompleteRequest();
                    }
                }

            }

            if (HttpContext.Current.Session != null && RuntimeContext.Provider != null && RuntimeContext.Operator != null)
            {
                LogService.Current.SetContextItem("Providerid", RuntimeContext.Provider.Id);
                LogService.Current.SetContextItem("operatorusername", RuntimeContext.Operator.Username);
                LogService.Current.SetContextItem("clientip", Request.UserHostAddress);
            }
        }

        protected void Application_EndRequest()
        {
            var context = new HttpContextWrapper(Context);
            if (context.Request.IsAjaxRequest() && context.Response.StatusCode == 302)
            {
                Context.Response.Clear();
                Context.Response.StatusCode = 401;
            }
        }

        void Application_Error(object sender, EventArgs e)
        {
            var error = Server.GetLastError();

            if (error == null)
            {
                if ((Context.AllErrors != null) && (Context.AllErrors.Length > 0))
                {
                    error = Context.AllErrors[Context.AllErrors.Length - 1];
                    LogService.Current.Error(() => "inside Context.AllErrors != null check: " + error.Message);
                }
            }
            else
            {
                while (error.InnerException != null) error = error.InnerException;
                LogService.Current.Error(() => "inside ex.InnerException != null check: " + error.Message);
            }


            if (new HttpContextWrapper(Context).Request.IsAjaxRequest())
            {
                //AJAX Call - Simply return, ajax error handler (helper.js) will handle the application error
            }
            else
            {
                Response.Redirect("/client/error/ShowWarningMessage");
            }

        }

        private List<string> GetSignalrUrls()
        {
            List<string> signalrUrls = new List<string>();
            signalrUrls.Add("/athoc-iws/signalr/connect");
            signalrUrls.Add("/athoc-iws/signalr/poll");
            signalrUrls.Add("/athoc-iws/signalr/send");
            signalrUrls.Add("/athoc-iws/signalr/abort");
            signalrUrls.Add("/athoc-iws/signalr/start");
            signalrUrls.Add("/athoc-iws/signalr/negotiate");
            signalrUrls.Add("/athoc-iws/signalr/reconnect");
            signalrUrls.Add("/athoc-iws/signalr/ping");
            return signalrUrls;

        }
        #endregion
    }
}
