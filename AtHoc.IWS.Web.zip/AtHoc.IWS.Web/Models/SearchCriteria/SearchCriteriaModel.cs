﻿using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Web.Models.UserManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AtHoc.IWS.Web.Models.SearchCriteria
{
  
    public class Display
    {
        public string DisplayText { get; set; }
    }

    public abstract class BaseSelection
    {
        public virtual string entityType { get; set; }

        public virtual int id { get; set; }

        public virtual string commonName { get; set; }
    }


    public class Entity : BaseSelection
    {

        public string dataType { get; set; }
        public int dataTypeId { get; set; }

        public string name { get; set; }

        public int? hierarchyId { get; set; }
    }


    public class Value : BaseSelection
    {
        public string text { get; set; }
        public string lineage { get; set; }
        //public string fullPath { get; set; }
    }

    public class Selection
    {
        public Selection()
        {
            this.value = new List<Value>();
            this.operand = 1;
            this.operandName = "";
            this.commonName = "";
            useCommonNameValue = false;
        }

        //used for converting targeting xml into query builder object format. 
        public Selection(int entityId,
                        CustomAttributeDataType dataType,
                        GroupType entityType,
                        string entityName, 
                        int? hierarchyId,
                        int operand) :this()
        {
            CreateEntity(entityId, "", dataType,entityType,entityName,hierarchyId);
            this.operand = operand;
        }


        //used for converting targeting xml into query builder object format. 
        public Selection(int entityId,
                        CustomAttributeDataType dataType,
                        GroupType entityType,
                        string entityName,
                        int? hierarchyId,
                        int operand,
                        string commonName
                        )
            : this()
        {
            CreateEntity(entityId, commonName, dataType, entityType, entityName, hierarchyId);
            this.operand = operand;
            this.commonName = commonName;
        }

        public int operand { get; set; }
        public string operandName { get; set; }

        public Entity entity { get;  set; }

        public bool useCommonNameValue { get; set; }

        public List<Value> value { get; set; }

        public void CreateEntity(int id, string commonName = "", CustomAttributeDataType dataType = CustomAttributeDataType.String, GroupType entityType = GroupType.ATTRIBUTE, string name = "", int? hierarchyId = 0)
        {
            var _hierarchyId = hierarchyId.HasValue ? hierarchyId.Value : 0;
            this.entity = new Entity { commonName = commonName, dataType = dataType.ToString(), entityType = entityType.ToString(), id = id, name = name, hierarchyId = _hierarchyId };
        }

        public void CreateValue(int id, GroupType entityType = GroupType.ATTRIBUTE, string text = "", string lineage = "")
        {
            this.value.Add(new Value { entityType = entityType.ToString(), id = id, text = text, lineage = lineage });
        }

        public string commonName { get; set;  }
    }

    public class SearchCriteriaModel
    {
        public SearchCriteriaModel()
        {

        }

        public SearchCriteriaModel(List<Display> display, List<Selection> selections, List<string> displayNoStyle)
        {
            this.display = display.Select(s => s.DisplayText).ToList();
            this.selections = selections;
            this.displayNoStyle = displayNoStyle;
        }

        public SearchCriteriaModel(List<Display> display, List<Selection> selections)
        {
            this.display = display.Select(s => s.DisplayText).ToList();
            this.selections = selections;
        }      
        public List<string> display { get; set; }
        public List<Selection> selections { get; set; }
        public List<string> displayNoStyle { get; set; }

    }
}