﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AtHoc.IWS.Web.Models.UserManager
{
    public class ExportViewModelItem
    {
        public int Id { get; set; }
        public int CustomAttributeId { get; set; }
        public string CommonName { get; set; }
        public string DisplayName { get; set; }
        public string EntityType { get; set; }
        public bool IsRemovable { get; set; }
    }

    public class ExportViewModel
    {
        public List<ExportViewModelItem> Available { get; private set; }
        public List<ExportViewModelItem> Existing { get; private set; }

        public ExportViewModel()
        {
            Available = new List<ExportViewModelItem>();
            Existing = new List<ExportViewModelItem>();
        }
    }
}