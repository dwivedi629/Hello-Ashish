﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AtHoc.IWS.Web.Models.UserManager
{
    public class GroupSearchNode
    {
        private int _parentId = -1;

        public int ParentId
        {
            get { return _parentId; }
            set { _parentId = value; }
        }


        private string _parentGroupType = GroupType.OTHERS.ToString();

        public string ParentGroupType
        {
            get { return _parentGroupType; }
            set { _parentGroupType = value; }
        }

        private string _Status = CheckboxStatus.NO.ToString();

        public string Status
        {
            get { return _Status; }
            set { _Status = value; }
        }

        public string Name { get; set; }
        public bool ShowCheckbox { get; set; }
        public bool IsCheckbox { get; set; }
        public bool HasChildren { get; set; }
        public int Id { get; set; }
        public int RootId { get; set; }
        public string CurrentGroupType { get; set; }
        public string Lineage { get; set; }
        public int DisplayOrder { get; set; }
        public string DescendantLists { get; set; }


 
    }

    public enum CheckboxStatus
    {
        EXP,
        IMP,
        PRT,
        NO
    }

    public enum GroupType
    {
        ATTRIBUTE,
        ATTRIBUTEVALUE,
        LISTITEM,
        HIERARCHY,
        HIERARCHYITEM,
        DEVICE,
        ROLE,
        VPS,
        OTHERS
    }

    public enum HierarchyContext
    {
        DistributionList,
        OrgHierarchy,
        Location
    }

    public class PreselectedGroupNode
    {
        public int value  { get; set; }
        public string type { get; set; }
        public string display  { get; set; }
        public string lineage  { get; set; }
        public int rootId { get; set; }
    }
}