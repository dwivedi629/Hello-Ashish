﻿using System.Web;
using System.Web.Mvc;
using AtHoc.IWS.Web.Filters;

namespace AtHoc.IWS.Web.Models.UserManager
{
    public class SingleFileModel
    {
        [ValidateFile(AllowedExtensions=".csv", AllowedSizeInMB=100)]
        public HttpPostedFileBase File { get; set; }
       
    }
}