﻿using System;

namespace AtHoc.IWS.Web.Models.UserManager
{
	public class VPSModel
	{
		public string DateFormat { get; set; }

		public string DateTimeFormat { get; set; }

		public TimeZoneInfo VPSTimeZone { get; set; }

		public double UtcOffsetInMinutes { get; set; }

		public double VPSOffsetFromSystemInMinutes { get; set; }

		public bool SupportsDaylightSavingTime { get; set; }
	}
}