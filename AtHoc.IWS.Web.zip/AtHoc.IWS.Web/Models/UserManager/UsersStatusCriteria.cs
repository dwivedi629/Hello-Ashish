﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AtHoc.IWS.Web.Models.UserManager
{
    public class UsersStatusCriteria
    {
        public int CriteriaType { get; set; }
        public List<int> EntityIds { get; set; }
        public SearchCriteria SearchCriteria { get; set; }
    }

    public class SearchCriteria
    {
        public int[] userIds { get; set; }
        public int[] listItemIds { get; set; }
        public int[] hierarchyIds { get; set; }
        public int[] attributeValueIds { get; set; }
        public int[] attributeIds { get; set; }
        public string[] searchStrings { get; set; }
        public string queryCriteria { get; set; }
        public bool isOperator { get; set; }
        public bool isEnabled { get; set; }
        public int[] includeUserIds { get; set; }
        public int[] excludeUserIds { get; set; }
    }


    public enum ListCriteriaType
    {
        ALL_USERS = -1,
        USER_LIST = 0,
        EXCEPTION_LIST = 1,
    }

}