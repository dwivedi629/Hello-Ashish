﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AtHoc.IWS.Web.Models.UserManager
{
    public class CustomAttributeForQuery
    { 
        public string name { get; set; }
        public string dataType  { get; set; }

        public int dataTypeId { get; set; }

        public int id { get; set; }
        public string entityType { get; set; }
        public string commonName  { get; set; }
        
        public bool useCommonNameValue { get; set; }
        public IEnumerable<CustomAttributeValueForQuery> values { get; set; }
        public int hierarchyId { get; set; }
        public string pathDelimiter { get; set; }


    }

    public class CustomAttributeValueForQuery
    {
        public string name { get; set; }
        public int id { get; set; }
        public string commonName { get; set; }
    }
}