﻿using System;
using System.Linq;
using System.Web;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Web.WebPages;
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.Business.Extensions;
using AtHoc.IWS.Business.Domain.Authorization;
using AtHoc.Infrastructure.Extensions;
using AtHoc.IWS.Business.Data;
using AtHoc.IWS.Web.Models.SearchCriteria;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Web.Models.UserManager
{
    public class OperatorPermissionsViewModel
    {

        public int UserId { get; set; }
        public SystemUser EndUseroperator { get; set; }
        public IEnumerable<OperatorRole> Roles { get; set; }

        public IEnumerable<OperatorRole> AllRoles { get; set; }
        public IEnumerable<AlertChannel> Channels { get; set; }
        public IEnumerable<AlertChannel> VPSChannels { get; set; }
        public IEnumerable<DistributionList> DistributionLists { get; set; }
        public IEnumerable<OperatorAccess> OperatorAccess { get; set; }
        public IEnumerable<OperatorAudit> AuditEvents { get; set; }
        public string UserStatus { get; set; }
        public string SSOMappingId { get; set; }
        public string UserName { get; set; }


        List<string> SelectedOperatorRoleNames = new List<string>();

        //flag which says whether current user has auto/virtual roles by default w.r.t System Admin or Enterprise Chain
        private bool _hasVirtualRoles;
        private bool _hasExternalRoleEntAdmin;
        private List<string> _externalRoleNames = new List<string>();

        List<int> SelectedChannels = new List<int>();
        IEnumerable<DistributionListPermissions> OperatorDistributionListsPermissions = null;
        IEnumerable<OperatorEntityAccess> targetLists = null;
        IEnumerable<OperatorEntityAccess> manageLists = null;
        public OperatorPermissions Permissions { get; private set; }



        public OperatorPermissionsViewModel(int userId,
                                                IEnumerable<OperatorRole> roles,
                                                IEnumerable<OperatorRole> allRoles,
                                            IEnumerable<AlertChannel> channels,
                                            IEnumerable<DistributionList> distributionLists,
                                            string userStatus,
                                            string ssoMappingId,
                                            string userName,
                                            IEnumerable<AlertChannel> vpsChannels)
        {
            UserId = userId;
            Roles = roles;
            Channels = channels;
            DistributionLists = distributionLists;
            UserStatus = userStatus;
            SSOMappingId = ssoMappingId;
            UserName = userName;
            VPSChannels = vpsChannels;
            AllRoles = allRoles;
            this.Permissions = new OperatorPermissions(userId);
            IntializePermissions();
        }


        public OperatorPermissionsViewModel(int userId,
            SystemUser systemUser,
            IEnumerable<OperatorRole> roles,
            IEnumerable<OperatorRole> allRoles,
            IEnumerable<AlertChannel> channels,
            IEnumerable<DistributionList> distributionLists,
            IEnumerable<OperatorAccess> operatorAccess,
            IEnumerable<OperatorAudit> auditEvents,
            IEnumerable<OperatorUserBase> operatorUserBase,
            string userStatus,
            string ssoMappingId,
            string userName,
            IEnumerable<AlertChannel> vpsChannels,
            bool isNewOperator = false)
        {
            UserId = userId;
            EndUseroperator = systemUser;
            Roles = roles;
            Channels = channels;
            DistributionLists = distributionLists;
            OperatorAccess = operatorAccess;
            AuditEvents = auditEvents;
            UserStatus = userStatus;
            SSOMappingId = ssoMappingId;
            VPSChannels = vpsChannels;
            UserName = userName;
            AllRoles = allRoles;
            this.Permissions = new OperatorPermissions(userId, systemUser.OperatorUser.Id, operatorUserBase);
            InitializePermissions(isNewOperator);
        }

        private void IntializePermissions()
        {
            OperatorDistributionListsPermissions = PrepareDistributionListOperatorPermissions(null, DistributionLists);

            Permissions.OperatorId = UserId;
            Permissions.UserId = UserId;
            Permissions.Status = "";
            Permissions.UserStatus = UserStatus;
            Permissions.IsAccessible = "";
            Permissions.LoginInfo = null;
            Permissions.AvailableRoles = Roles.OrderBy(role => role.RoleName);
            Permissions.AvailableChannels =
                            Channels.Select(c => new Channel { ChannelName = c.Name, Id = c.Id, IsReadOnly = false }).OrderBy(channel => channel.ChannelName)
                                                    .OrderBy(cn => cn.ChannelName);
            Permissions.VPSChannels = GetOperatorChannelAccessibility(Channels, VPSChannels);
            Permissions.SelectedRoles = SelectedOperatorRoleNames;
            Permissions.IsChannelListUnrestricted = "Unrestricted";
            Permissions.SelectedChannels = SelectedChannels;
            Permissions.IsManageDLUnrestricted = "Unrestricted";
            Permissions.IsPublishDLUnrestricted = "Unrestricted";
            Permissions.SelectedPublishLists = null;
            Permissions.SelectedManageLists = null;
            Permissions.AvailableDistributionLists = OperatorDistributionListsPermissions;
            Permissions.IsUserBaseUnrestricted = "Unrestricted";
            Permissions.MappingId = string.Empty;
            Permissions.MappingId = SSOMappingId;
            Permissions.UserName = UserName;
            Permissions.HasVirtualRoles = _hasVirtualRoles;
            Permissions.HasExternalRoleEntAdmin = _hasExternalRoleEntAdmin;
            Permissions.ExternalRoleNames = _externalRoleNames;
            Permissions.AllRoles = AllRoles;
        }



        private void InitializePermissions(bool isNewOperator)
        {
            if (EndUseroperator.Roles != null)
            {
                foreach (var role in EndUseroperator.Roles)
                {
                    string roleName = (Roles.Count(x => x.Id == role.RoleId) > 0) ? Roles.First(r => r.Id == role.RoleId).RoleName : string.Empty;

                    if (roleName.IsEmpty())
                    {
                        SelectedOperatorRoleNames.Add(role.RoleName);
                        _externalRoleNames.Add(role.RoleName);
                        _hasVirtualRoles = true;
                        //Check if the external roles have Enterprise Admin to disable the edit operator permissiosn feature
                        //IWS-18455 -> Edit Operator Permission Disappears
                        var externalRole = AllRoles.FirstOrDefault(exRole => exRole.Id == role.RoleId);
                        if (externalRole != null && externalRole.CommonName.ToUpper() == "RENTADM")
                            _hasExternalRoleEntAdmin = true;
                    }
                    else
                        SelectedOperatorRoleNames.Add(roleName);
                }
                // Fix for IWS-23550
                if (SelectedOperatorRoleNames.Count > 0)
                    SelectedOperatorRoleNames.Sort();
            }

            if (!EndUseroperator.IsChannelListUnrestricted())
            {
                if (EndUseroperator.Channels != null)
                {
                    foreach (var userChannel in EndUseroperator.Channels)
                    {
                        if (VPSChannels.Any(channel => channel.Id == userChannel.ChannelId))
                        {
                            SelectedChannels.Add(VPSChannels.First(channel => channel.Id == userChannel.ChannelId).Id);
                        }
                    }
                }
            }
            targetLists = EndUseroperator.GetTargetableAccessList();
            manageLists = EndUseroperator.GetManagableAccessList();

            var SelectedPublishLists = (targetLists != null)
                                ? (from order in targetLists
                                   join plan in DistributionLists on order.EntityId equals plan.Id
                                   select new { Id = order.EntityId, ListName = plan.Name, })
                                : null;

            var SelectedManageLists = (manageLists != null)
                                ? (from MDL in manageLists
                                   join ADL in DistributionLists on MDL.EntityId equals ADL.Id
                                   select new { Id = MDL.EntityId, ListName = ADL.Name, })
                                : null;
            Permissions.OperatorId = EndUseroperator.OperatorUser.Id;
            Permissions.UserId = UserId;
            Permissions.UserStatus = UserStatus;
            Permissions.IsAccessible = (EndUseroperator.IsLocked) ? "Locked" : "";
            Permissions.LoginInfo = GetLoginOperatorLoginInfo(EndUseroperator.OperatorUser, AuditEvents);
            Permissions.AvailableRoles = Roles.OrderBy(role => role.RoleName);
            Permissions.AvailableChannels =
                Channels.Select(c => new Channel { ChannelName = c.Name, Id = c.Id, IsReadOnly = false })
                    .OrderBy(channel => channel.ChannelName);

            Permissions.VPSChannels = GetOperatorChannelAccessibility(Channels, VPSChannels);

            Permissions.SelectedRoles = SelectedOperatorRoleNames;


            Permissions.SelectedChannels = SelectedChannels;

            OperatorDistributionListsPermissions = PrepareDistributionListOperatorPermissions(EndUseroperator, DistributionLists);

            Permissions.SelectedPublishLists = SelectedPublishLists;

            Permissions.SelectedManageLists = SelectedManageLists;

            Permissions.AvailableDistributionLists = OperatorDistributionListsPermissions;

            Permissions.MappingId = SSOMappingId;

            Permissions.UserName = UserName;

            Permissions.HasVirtualRoles = _hasVirtualRoles;

            Permissions.HasExternalRoleEntAdmin = _hasExternalRoleEntAdmin;

            Permissions.ExternalRoleNames = _externalRoleNames;

            Permissions.AllRoles = AllRoles;

            //var list = from role in AllRoles
            //           join oprRole in EndUseroperator.Roles on role.Id equals oprRole.RoleId
            //           select new { oprRole.RoleId, role.UnrestrictedEntityAccess, role.UnrestrictedAlertFolders, role.UnrestrictedUserBase };

            if (EndUseroperator.HasUnrestrictedAlertFolders)
                Permissions.IsChannelListUnrestricted = "Unrestricted";
            else if (EndUseroperator.IsChannelListUnrestricted())
                Permissions.IsChannelListUnrestricted = "Unrestricted";
            else
                Permissions.IsChannelListUnrestricted = "Restricted";

            if (EndUseroperator.HasUnrestrictedUserBaseAccess)
                Permissions.IsUserBaseUnrestricted = "Unrestricted";
            else if (EndUseroperator.IsUserBaseUnrestricted())
                Permissions.IsUserBaseUnrestricted = "Unrestricted";
            else
                Permissions.IsUserBaseUnrestricted = "Restricted";

            if (isNewOperator)
                Permissions.IsManageDLUnrestricted = "Unrestricted";
            else if (EndUseroperator.HasUnrestrictedEntityAccess)
                Permissions.IsManageDLUnrestricted = "Unrestricted";
            else if (EndUseroperator.IsManagableAccessListUnrestricted())
                Permissions.IsManageDLUnrestricted = "Unrestricted";
            else
                Permissions.IsManageDLUnrestricted = "Restricted";

            if (isNewOperator)
                Permissions.IsPublishDLUnrestricted = "Unrestricted";
            else if (EndUseroperator.HasUnrestrictedEntityAccess)
                Permissions.IsPublishDLUnrestricted = "Unrestricted";
            else if (EndUseroperator.IsTargetableAccessListUnrestricted())
                Permissions.IsPublishDLUnrestricted = "Unrestricted";
            else
                Permissions.IsPublishDLUnrestricted = "Restricted";
        }

        private IEnumerable<Channel> GetSelectedChannelsOperatorAccess(IEnumerable<OperatorChannel> selectedChannels, IEnumerable<AlertChannel> oprChannels,
            IEnumerable<AlertChannel> VPSChannels)
        {
            List<Channel> selectedChannelsOperatorAccess = new List<Channel>();
            string channelName = string.Empty;
            bool readOnly = false;

            if (selectedChannels != null)
            {
                foreach (var userChannel in selectedChannels)
                {
                    if (VPSChannels.Any(channel => channel.Id == userChannel.ChannelId))
                    {
                        channelName = VPSChannels.First(channel => channel.Id == userChannel.ChannelId).Name;
                        readOnly = (oprChannels != null && oprChannels.Any(channel => channel.Id == userChannel.ChannelId)) ? false : true;
                        selectedChannelsOperatorAccess.Add(new Channel { Id = userChannel.ChannelId, ChannelName = channelName, IsReadOnly = readOnly });
                    }
                }
            }
            return selectedChannelsOperatorAccess.OrderBy(channel => channel.ChannelName);
        }

        private IEnumerable<Channel> GetOperatorChannelAccessibility(IEnumerable<AlertChannel> oprChannels, IEnumerable<AlertChannel> vpsChannels)
        {
            List<Channel> ChannelsAccessibility = new List<Channel>();

            foreach (var channel in VPSChannels)
            {
                if (oprChannels != null && oprChannels.Any(x => x.Id == channel.Id))
                    ChannelsAccessibility.Add(new Channel { ChannelName = channel.Name, Id = channel.Id, IsReadOnly = false });
                else
                    ChannelsAccessibility.Add(new Channel { ChannelName = channel.Name, Id = channel.Id, IsReadOnly = true });
            }
            return ChannelsAccessibility.OrderBy(channel => channel.ChannelName);
        }

        private dynamic GetLoginOperatorLoginInfo(OperatorUser opUser, IEnumerable<OperatorAudit> auditEvents)
        {
            var provider = RuntimeContext.Provider;

            var strCurrentLoginTime = (opUser.CurrentLoginTime.HasValue && opUser.CurrentLoginTime > 0)
                ? provider.GetVpsDateTimeFromSecondsFormated(opUser.CurrentLoginTime.Value)
                : string.Empty;

            var strLastLoginTime = (opUser.LastLoginTime.HasValue && opUser.LastLoginTime > 0)
                ? provider.GetVpsDateTimeFromSecondsFormated(opUser.LastLoginTime.Value)
                : string.Empty;

            var strCurrentLoginMachine = opUser.CurrentLoginMachineName.GetValue();
            var strLastLoginMachine = opUser.LastLoginMachineName.GetValue();

            var auditEventList = new List<dynamic>();
            foreach (var auditEvent in auditEvents)
            {
                auditEventList.Add(new
                {
                    DateTime = auditEvent.ActionDateTime.Value.ToVpsDateTimeString(),
                    IP = auditEvent.ClientIp
                });
            }

            var loginInfo = new
            {
                CurrentLogin = new { DateTime = strCurrentLoginTime, IP = strCurrentLoginMachine },
                LastLogin = new { DateTime = strLastLoginTime, IP = strLastLoginMachine },
                FailedLoginAttempts = opUser.LastFailedAttempts.GetString(),
                FailedLoginSummary = auditEventList.Take((opUser.LastFailedAttempts.HasValue) ? opUser.LastFailedAttempts.Value : 0)
            };
            return loginInfo;
        }

        private IEnumerable<DistributionListPermissions> PrepareDistributionListOperatorPermissions(SystemUser EndUseroperator,
            IEnumerable<DistributionList> OperatorAccessibleDistributionLists)
        {
            var availableDistributionLists =
                OperatorAccessibleDistributionLists.Select(
                    dl =>
                        new DistributionListPermissions
                        {
                            Id = dl.Id,
                            ListName = dl.Name,
                            Path = dl.Lineage,
                            Type = dl.ListType.ToString(),
                            Publish = false,
                            Manage = false
                        });

            if (EndUseroperator == null) return availableDistributionLists.OrderBy(x => x.ListName);
            var selectedPublishLists = (!EndUseroperator.IsTargetableAccessListUnrestricted())
                ? EndUseroperator.GetTargetableAccessList().Select(publishList => publishList.EntityId)
                : null;

            var selectedManageLists = (!EndUseroperator.IsManagableAccessListUnrestricted())
                ? EndUseroperator.GetManagableAccessList().Select(manageList => manageList.EntityId)
                : null;

            var dlList = from lst in availableDistributionLists
                         select
                             new DistributionListPermissions
                             {
                                 Id = lst.Id,
                                 ListName = lst.ListName,
                                 Path = lst.Path,
                                 Type = lst.Type,
                                 Publish = selectedPublishLists != null && (selectedPublishLists.Any(x => x == lst.Id)),
                                 Manage = selectedManageLists != null && (selectedManageLists.Any(x => x == lst.Id))
                             };
            return dlList.OrderBy(x => x.ListName);
        }

    }

    public class Channel
    {
        public string ChannelName { get; set; }
        public int Id { get; set; }
        public bool IsReadOnly { get; set; }
    }



    public class OperatorPermissions
    {
        public OperatorPermissions(int userId)
        {
            this.UserId = userId;
            OperatorPassword = new OperatorPassword(userId, userId);
        }
        public OperatorPermissions(int userId, int operatorId, IEnumerable<OperatorUserBase> operatorUserBase)
        {
            this.UserId = userId;
            this.OperatorId = operatorId;
            this.OperatorUserBase = operatorUserBase;
            OperatorPassword = new OperatorPassword(userId, operatorId);
        }

        public OperatorPassword OperatorPassword { get; set; }

        //TODO - going forward there will be no operatorID
        public int OperatorId { get; set; }
        public int UserId { get; set; }
        public string Status { get; set; }
        public string IsAccessible { get; set; }
        public dynamic LoginInfo { get; set; }

        public List<string> SelectedRoles { get; set; }

        //flag which says whether current user has auto/virtual roles by default w.r.t System Admin or Enterprise Chain
        public bool HasVirtualRoles { get; set; }

        //flag which says whether current user has external role which is 'Enterprise Admin'
        public bool HasExternalRoleEntAdmin { get; set; }
        public List<string> ExternalRoleNames { get; set; }
        public IEnumerable<OperatorRole> AvailableRoles { get; set; }

        public IEnumerable<OperatorRole> AllRoles { get; set; }
        public string IsChannelListUnrestricted { get; set; }
        public List<int> SelectedChannels { get; set; }
        public IEnumerable<Channel> AvailableChannels { get; set; }
        public IEnumerable<Channel> VPSChannels { get; set; }
        public string IsManageDLUnrestricted { get; set; }
        public string IsPublishDLUnrestricted { get; set; }
        public IEnumerable<dynamic> SelectedPublishLists { get; set; }
        public IEnumerable<dynamic> SelectedManageLists { get; set; }

        public IEnumerable<DistributionListPermissions> AvailableDistributionLists { get; set; }
        public string IsUserBaseUnrestricted { get; set; }

        public string UserStatus { get; set; }

        public IEnumerable<OperatorUserBase> OperatorUserBase { get; set; }

        public string MappingId { get; set; }
        public string UserName { get; set; }

        public string RolesDescription { get; set; }
    }

    public class EndUserOperatorPermissionsForSave
    {
        public int UserId { get; set; }

        public int OperatorId { get; set; }

        public IEnumerable<OperatorRole> EndUserOperatorRoles { get; set; }

        public IEnumerable<AlertChannel> EndUserOperatorChannels { get; set; }

        public IEnumerable<OperatorEntityAccess> EntityAccessList { get; set; }

        public bool IsUserBaseRestricted { get; set; }

        public IEnumerable<OperatorUserBase> UserBaseCriteriaList { get; set; }

        public OperatorPassword OperatorPassword { get; set; }

        public IEnumerable<Selection> OperatorUserBase { get; set; }

        public string MappingId { get; set; }
    }

    public class DistributionListPermissions
    {
        public int Id { get; set; }

        public string ListName { get; set; }

        public string Path { get; set; }

        public string Type { get; set; }

        public bool Publish { get; set; }

        public bool Manage { get; set; }
    }

    /*
    public class UsersStatusCriteria
    {
        public int CriteriaType { get; set; }
        public List<int> EntityIds { get; set; }
        public SearchCriteria SearchCriteria { get; set; }

        
    }

 


    public class SearchCriteria
    {
        public int[] userIds { get; set; }
        public int[] listItemIds { get; set; }
        public int[] hierarchyIds { get; set; }
        public int[] attributeValueIds { get; set; }
        public int[] attributeIds { get; set; }
        public string[] searchStrings { get; set; }
        public string queryCriteria { get; set; }
        public bool isOperator { get; set; }
        public bool isEnabled { get; set; }
    }

    public class SearchCriteria2
    {
        public int[] userIds { get; set; }
        public int[] listItemIds { get; set; }
        public int[] hierarchyIds { get; set; }
        public int[] attributeValueIds { get; set; }
        public int[] attributeIds { get; set; }
        public string[] searchStrings { get; set; }

        public string queryCriteria { get; set; }
        public bool isOperator { get; set; }
        public bool isEnabled { get; set; }
    }
     
    public enum ListCriteriaType
    {
         ALL_USERS = -1,    
        USER_LIST =  0,
        EXCEPTION_LIST = 1,
    } */


    public class OperatorPassword
    {
        public OperatorPassword(int endUserId, int userId)
        {
            this.EndUserId = endUserId;
            this.UserId = userId;
        }

        public OperatorPassword()
        {
            this.EndUserId = 0;
            this.UserId = 0;
        }

        public int EndUserId { get; private set; }
        public int UserId { get; private set; }

        public string Password { get; set; }

        public string NewPassword { get; set; }

        public DateTime? ExpirationDate { get; set; }

        public string PasswordUpdatedOn { get; set; }

        public string NextLoginChangePw { get; set; }

        public string PasswordNeverExpires { get; set; }

        public int? CurrentFailedAttempts { get; set; }

    }


}