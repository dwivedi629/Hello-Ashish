﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Script.Serialization;

using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Data;

using AtHoc.IWS.Business.Data;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Users.Search;

namespace AtHoc.IWS.Web.Models.UserManager
{
	public class Criterion : IAttributeCriteriaParameter
	{
		public CriterionEntity entity { get; set; }

		public int operand { get; set; }

		public CriterionValue[] value { get; set; }

		[ScriptIgnore]
		public object Value
		{
			get
			{
				if (!value.Any())
					return new[] { String.Empty };

				if (AttributeType == CustomAttributeDataType.Checkbox || AttributeType == CustomAttributeDataType.Picklist
					|| AttributeType == CustomAttributeDataType.MultiPicklist)
					return value.Select(v => v.id).ToArray();

				if (AttributeType == CustomAttributeDataType.Path)
					return value.Select(v => v.lineage).ToArray();

				if (value.Count() == 1 && value.First().text.Contains(","))
					return value.First().text.Split<string>().ToArray();

				return value.Select(v => v.text).ToArray();
			}
			set { throw new NotSupportedException(); }
		}

		[ScriptIgnore]
		public ConditionOperator Operator
		{
			get { return ConditionOperatorConvertor.Convert(operand); }
			set { throw new NotSupportedException(); }
		}

		[ScriptIgnore]
		public CriteriaParameterComparison ParameterComparison { get; set; }

		[ScriptIgnore]
		public string UniqueId
		{
			get { throw new NotSupportedException(); }
			set { throw new NotSupportedException(); }
		}

		[ScriptIgnore]
		public int ObjectId
		{
			get { return entity.id; }
			set { throw new NotSupportedException(); }
		}

		[ScriptIgnore]
		public CriteriaObjectType ObjectType
		{
			get
			{
				return EnumUtils<GroupType>.Parse(entity.entityType) == GroupType.ATTRIBUTE
					? CriteriaObjectType.ATTRIBUTE
					: CriteriaObjectType.DEVICE;
			}
			set { throw new NotSupportedException(); }
		}

		[ScriptIgnore]
		public CustomAttributeDataType AttributeType
		{
			get { return EnumUtils<CustomAttributeDataType>.Parse(entity.dataType); }
			set { throw new NotSupportedException(); }
		}
	}

	public class CriterionEntity
	{
		public string name { get; set; }

		public int id { get; set; }

		public string dataType { get; set; }

		public string commonName { get; set; }

		public string entityType { get; set; }

		public int hierarchyId { get; set; }
	}

	public class CriterionValue
	{
		public string text { get; set; }

		public int id { get; set; }

		public string entityType { get; set; }

		public string lineage { get; set; }
	}

	public class Operand
	{
		public int id { get; set; }

		public string name { get; set; }

		public bool isValueRequired { get; set; }

		public string displayTextTemplate { get; set; }

		public RelativeDateTimeOperandDisplay relativeDateTimeDisplayText { get; set; }

		public bool showAdvancedValueSelector { get; set; }
	}

	public class RelativeDateTimeOperandDisplay
	{
		public string pastShortSingular { get; set; }

		public string pastShortPlural { get; set; }

		public string pastLong { get; set; }

		public string nowShort { get; set; }

		public string nowLong { get; set; }

		public string nextShortSingular { get; set; }

		public string nextShortPlural { get; set; }

		public string nextLong { get; set; }

		public string absoluteDateShort { get; set; }

		public string absoluteDateLong { get; set; }
	}

	public class OperandCollection
	{
		public string name { get; set; }

		public IEnumerable<Operand> operands { get; set; }
	}
}