﻿using System;
using System.Collections.Generic;
using System.Linq;
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.Devices;
using AtHoc.IWS.Business.Domain.Devices.Spec;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Business.Context;

namespace AtHoc.IWS.Web.Models.UserManager
{
    public class DownloadImportFileTemplate
    {
        private readonly ICustomAttributeCache _customAttributeCache;
        private readonly IDeviceFacade _deviceFacade;
        private readonly Provider _provider;
        private CustomAttributeLookup _cachedAttributes;
        private readonly IUserFacade _userFacade ;
        public DownloadImportFileTemplate(IUserFacade userFacade, ICustomAttributeCache customAttributeCache, IDeviceFacade deviceFacade,
            Provider provider)
        {
            _customAttributeCache = customAttributeCache;
            _deviceFacade = deviceFacade;
            _provider = provider;
            _userFacade = userFacade;

        }

        public byte[] GetBytes()
        {
            var validAttributes = new List<string>();
            _cachedAttributes = _customAttributeCache.Get(_provider.Id,RuntimeContext.Provider.BaseLocale);
            validAttributes.AddRange(_cachedAttributes.GetByCommonNames("USERNAME STATUS").Select(z=>z.AttributeName));
            validAttributes.AddRange(
                _cachedAttributes.Where(x => x.IsSearchable == "Y" && x.EditLevel > 0).OrderBy(x=>x.AttributeName)
                    .Select(x => x.AttributeName)
                    .ToList());
            var y = validAttributes.Join();

            var devices =
                _deviceFacade.GetDevicesBySpec(new DeviceSpec
                {
                    IsMassDevice = false,
                    ProviderId = _provider.Id,
                    EnabledOnly = true,
                    OrderBy = Device.Meta.Name
                },RuntimeContext.Provider.BaseLocale).Select(q => q.Name).Join();

            var staticDistributionList = _userFacade.GetStaticDistributionLists(
                new DistributionListSpec
                {
                    ProviderId = _provider.Id, 
                    OrderBy = DistributionList.Meta.Name, 
                    Status = UserStatusType.Active
                    
                }
            ).Select(p=>p.Name);



            var dlList = staticDistributionList.Join();
            var csvTemplate = String.Concat(y, "," + devices);
            csvTemplate = String.Concat(csvTemplate, "," + dlList);
            return AtHocConfigService.Current.DefaultEncoding.GetBytes(csvTemplate);





        }
    }
}