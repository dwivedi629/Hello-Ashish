﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Web.Models.UserManager
{
    public class CustomViewColumn
    {
        public int Id { get; set; }
        public string DisplayName { get; set; }
        public string Key { get; set; }
        public bool IsRequired { get; set; }
        public bool IsSortable { get; set; }
        public string CustomViewColumnType { get; set; }
        public CustomAttributeDataType? DataType { get; set; }
        public string DataFormat { get; set; }
        public int ViewId { get; set; }

        public bool IsHierarchy { get; set; }
        public bool IsDefault { get; set; }

        public int ColumnDisplayOrder { get; set; }
    }

   
}