﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.Global.Resources;

namespace AtHoc.IWS.Web.Models.UserManager
{
    public class ActivityFeedDisplayViewModel
    {
        public int? UserId { get; set; }
        public int? EventId { get; set; }
        public string EventType { get; set; }
        public string Body { get; set; }

        public string Title { get; set; }

        public DateTime? EventTime { get; set; }

        public string Status { get; set; }

        public string Publisher { get; set; }

        public AlertDeliveryStatus? DeliveryStatus { get; set; }

        public string DeviceAddress { get; set; }

        public string DeviceCommonName { get; set; }

        public string RespondedText { get; set; }

        public int? NoResponse { get; set; }

        public int? Sent { get; set; }

        public int IsFirstResponded { get; set; }

        public string DisplayEventDate { get; set; }

        public string DisplayEventTime { get; set; }

        public string DisplayRespondedDate { get; set; }

        public string DisplayRespondedTime { get; set; }



        public string ProviderName { get; set; }

        public string DeviceName { get; set; }

        public string DeliveryStatusValue { get; set; }

        public string ListDeliveryStatusValue { get; set; }

        public string DetailDeliveryStatus { get; set; }

        public string DeliveryState { get; set; }

        public string LocalizedStatus { get; set; }
        public string LocalizedDeliveryStatus { get; set; }

        public string DisplayListDeliveryStatus
        {
            get
            {
                if (String.Equals(DeliveryState, "Responded", StringComparison.OrdinalIgnoreCase))
                {
                    return String.Format("{0} ({1} {2})", LocalizedDeliveryStatus, DisplayRespondedDate,
                        DisplayRespondedTime);
                }

                return LocalizedDeliveryStatus;

            }
        }

        public string DisplayListDeliveryDetail
        {
            get
            {
                //best to convert these values to Enum
                if (String.Equals(DeliveryState, "Responded", StringComparison.OrdinalIgnoreCase))
                {
                    return RespondedText;
                }

                return LocalizedDeliveryStatus;
            }
        }

        public string DisplayDetailResponse
        {
            get
            {
                if (RespondedText.IsNotNullOrEmpty())
                {
                    return IWSResources.ActivityFeed_List_RespondedText + " - \"" + RespondedText + "\"";
                }

                return IWSResources.ActivityFeed_List_RespondedText;
            }
        }


        public string DisplayDetailResponseVia
        {
            get
            {
                if (DeviceName.IsNotNullOrEmpty())
                {
                    return IWSResources.ActivityFeed_List_RespondedVia + " " + DeviceName;
                }

                return IWSResources.ActivityFeed_List_RespondedText;
            }
        }

        public string DisplayDetailDeliveryStatus
        {
            get
            {
                if (String.Equals(DeliveryState, "Responded", StringComparison.OrdinalIgnoreCase) &&
                    IsFirstResponded == 0)
                {
                    return LocalizedDeliveryStatus + " (" + IWSResources.ActivityFeed_List_IgnoredBySystem + ")";
                }

                return LocalizedDeliveryStatus;
            }

        }


        public string DisplayDetailDeliveryDetail
        {
            get
            {
                if (String.Equals(DeliveryState, "Responded", StringComparison.OrdinalIgnoreCase))
                    return RespondedText;

                return LocalizedDeliveryStatus;
            }
        }




    }
}