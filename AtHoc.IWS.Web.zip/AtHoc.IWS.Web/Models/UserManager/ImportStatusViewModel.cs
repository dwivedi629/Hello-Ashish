﻿using System;
using System.Collections.Generic;

using AtHoc.Business.Extensions;
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.Global.Resources;

namespace AtHoc.IWS.Web.Models.UserManager
{
	public class ImportStatusViewModel
	{
		public List<ImportStatusLine> Data { get; private set; }

		public UserImportStatusType? Status { get; set; }

		public string OperatorName { get; set; }

		public string SimpleProgress { get; set; }

        public bool AllRecordsFailed { get; set; }

		public ImportStatusViewModel()
		{
			Data = new List<ImportStatusLine>();
		    AllRecordsFailed = false;
		}

		public void AddData(UserImportStatus result, string operatorName)
		{
			Status = result.Status;
		    if (result.ProcessedRecords == result.FailedRecords || result.TotalRecords == result.FailedRecords)
		    {
		        AllRecordsFailed = true;
		    }

			OperatorName = operatorName;

		    Data.Add(new ImportStatusLine()
		    {
                Label = IWSResources.UserManager_Import_Status_TotalUsersLabel,
                StatusText = result.TotalRecords.ToString(),
                Order=-1
		    });

			Data.Add(new ImportStatusLine
			{
				Label = @IWSResources.UserManager_Import_Status_TotalUsersProcessedLabel,
				StatusText = result.ProcessedRecords.ToString(),
				Order = 1
			});
			Data.Add(new ImportStatusLine
			{
				Label = @IWSResources.UserManager_Import_Status_UsersSuccessfullyProcessedLabel,
				StatusText = result.SuccessRecords.ToString(),
				Order = 2
			});
			 
			Data.Add(new ImportStatusLine
			{
				Label = IWSResources.UserManager_Import_Status_UsersFailedLabel,
				StatusText = result.FailedRecords.ToString(),
				Order = 3
			});
			/*
            Data.Add(new ImportStatusLine
            {
               Label=IWSResources.UserManager_Import_Status_FileLabel,
               StatusText = "abcd.csv",
               Order=5
            });*/

			Data.Add(new ImportStatusLine
			{
				Label = IWSResources.UserManager_Import_Status_ImportedByLabel,
				StatusText = operatorName,
				Order = 6
			});

			Data.Add(new ImportStatusLine
			{
				Label = IWSResources.UserManager_Import_Status_ImportStartedOnLabel,
				StatusText = result.StartTime.ToVpsDateTimeString(),
				Order = 7,
			});

		    if (result.Status != UserImportStatusType.New && result.Status != UserImportStatusType.InProgress)
		    {
		        Data.Add(new ImportStatusLine
		        {
		            Label = IWSResources.UserManager_Import_Status_ImportConcludedOnLabel,
		            StatusText = result.EndTime.ToVpsDateTimeString(),
		            Order = 8,
                    StatusField="ImportConcludedOn"
		        });
		    }

		    SimpleProgress = IWSResources.UserManager_Import_View_ImportStatusMessage.FormatWith(result.TotalRecords,
				result.ProcessedRecords) + " (" + OperatorName + ")";
		}
	}

	public class ImportStatusLine
	{
		public string StatusField { get; set; }

		public string Label { get; set; }

		public string StatusText { get; set; }

		public int Order { get; set; }

        
	}
}