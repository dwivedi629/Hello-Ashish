﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;

using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Ioc;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Web.Models.PageLayout;
using AtHoc.IWS.Web.Configurations.Constants;
using PhoneNumbers;
using AtHoc.Global.Resources;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business;
using AtHoc.Global.Resources.Implementations;
using AtHoc.Global.Resources.Entities;

namespace AtHoc.IWS.Web.Models.UserManager
{
    public class EndUserDetails
    {
        public EndUserDetails(User endUser, Provider provider, XmlDocument pageLayoutXml, IEnumerable<CustomAttributeValue> customAttributeValues = null)
        {
            EndUser = endUser;
            PageLayoutXml = pageLayoutXml;
            Provider = provider;
            CustomAttributeValues = customAttributeValues;
        }

        public User EndUser { get; private set; }

        public XmlDocument PageLayoutXml { get; private set; }

        public Provider Provider { get; private set; }

        public IEnumerable<CustomAttributeValue> CustomAttributeValues { get; private set; }

        public virtual IEnumerable<PageLayoutRow> LoadPageLayoutRows(int userId, CustomAttributeLookup customAttributeLookup,
                                                            IEnumerable<Device> devices, bool loadEmptyAttribute = false, bool passwordRequired = false)
        {
            var allRowsFromXml = new List<PageLayoutRow>();
            var xnList1 = PageLayoutXml.SelectNodes("/page/row");
            var sectionCounter = 0;

            foreach (XmlNode xn in xnList1)
            {
                var columns = new List<Column>();
                //Columns Tag
                foreach (XmlNode columnNode in xn.ChildNodes)
                {
                    var colSpan = columnNode.Attributes["colSpan"].Value;
                    var cssClass = columnNode.Attributes["cssClass"].Value;

                    var column = new Column(colSpan.ConvertTo(0));
                    //Buckets
                    foreach (XmlNode bucket in columnNode.ChildNodes)
                    {
                        var bucketCss = "bucket";
                        if (bucket.Attributes["cssClass"] != null)
                        {
                            bucketCss = bucket.Attributes["cssClass"].Value;
                        }
                        var collapsable = false;
                        if (bucket.Attributes["collapsable"] != null)
                        {
                            collapsable = bucket.Attributes["collapsable"].Value.ConvertTo<bool>();
                        }
                        var firstBucket = new Bucket(bucketCss, collapsable);

                        //Sections

                        var allEnabledSections = bucket.SelectNodes("section[@enabled='true']");

                        foreach (XmlNode section in allEnabledSections)
                        {
                            var sec = GetSectionAttributes(section, customAttributeLookup, devices, colSpan.ConvertTo<int>(),
                                cssClass, null, loadEmptyAttribute);


                            var childSections = section.SelectNodes("section");
                            if (childSections.Count > 0)
                            {
                                foreach (XmlNode childSection in childSections)
                                {
                                    var childSec = GetSectionAttributes(childSection, customAttributeLookup, devices,
                                        colSpan.ConvertTo<int>(), cssClass, sec, loadEmptyAttribute);
                                    sec.ChildSections.Add(childSec);
                                }
                            }
                            if (sectionCounter == 0 && userId > 0)
                            {
                                sec.AddAttribute(attributeMeta: null, commonName: "User_Id", attributeId: 1, name: IWSResources.User_ID, value: userId, displayValue: userId, cssClass: cssClass, attributeType: CustomAttributeDataType.String, readOnly: true);
                                sectionCounter++;
                            }
                            if (userId <= 0 && (sec.Id == SectionLayoutConfig.LoginAndLocation || sec.Id == SectionLayoutConfig.MobileAndDesktopNotifier))
                            {
                                //firstBucket.AddSection(sec);
                            }
                            else
                            {
                                if (sec.Id != SectionLayoutConfig.Password)
                                {
                                    firstBucket.AddSection(sec);
                                }
                                else
                                {
                                    if (passwordRequired)
                                    {
                                        /*
                                         * string name,
                                            object value, object displayValue, string cssClass = "row",
                                            CustomAttributeDataType? attributeType = CustomAttributeDataType.String, string updatedOn = "",
                                            string metaData = "", DateTime? updatedTimeStamp = null
                                         */
                                        //Add Confirm Password
                                        //var confirmPassword = sec.Attributes.Where(a => a.CommonName == CommonNames.UserPassword).FirstOrDefault();
                                        //if (confirmPassword != null) {
                                        //    sec.AddAttribute(confirmPassword.AttributeMeta, "USR_PSWD_CONFIRM", confirmPassword.AttributeId, "Retype Password", confirmPassword.Value, confirmPassword.DisplayValue);
                                        //}
                                        firstBucket.AddSection(sec);
                                    }
                                }
                            }
                        }
                        if (firstBucket.Sections.Any())
                        {
                            column.AddBucket(firstBucket);
                        }
                    }
                    columns.Add(column);
                }
                var row = new PageLayoutRow(columns);
                allRowsFromXml.Add(row);
            }
            return allRowsFromXml;
        }

        private Section GetSectionAttributes(XmlNode section, CustomAttributeLookup customAttributeLookup,
                                            IEnumerable<Device> devices, int colSpan = 0, string cssClass = "",
                                            Section parentSection = null, bool loadEmptyAttribute = false)
        {
            var sectionName = section["title"].InnerText;
            var showGeoLocationOnMap = parentSection != null && parentSection.ShowGeoLocationOnMap;
            var sectionType = "attributes";
            var id = sectionName.Replace(" ", "");
            var sectionCss = parentSection != null ? parentSection.CssClass : "";
            var displayEmptyAttributes = true;
            var emptyMessage = string.Empty;
            var description = string.Empty;
            string attributeDisplayValue = string.Empty;
            string userAttributeValue = string.Empty;


            if (section["EmptySectionMessage"] != null)
            {
                emptyMessage = section["EmptySectionMessage"].InnerText;
            }
            if (section["description"] != null)
            {
                description = section["description"].InnerText;
            }

            if (section.Attributes["id"] != null)
            {
                id = section.Attributes["id"].Value;
            }
            if (section.Attributes["showGeoLocationOnMap"] != null)
            {
                showGeoLocationOnMap = section.Attributes["showGeoLocationOnMap"].Value.ConvertTo<bool>();
            }

            if (section.Attributes["type"] != null)
            {
                sectionType = section.Attributes["type"].Value;
            }
            if (section.Attributes["cssClass"] != null)
            {
                sectionCss = section.Attributes["cssClass"].Value; //"row mar-bot20";
            }

            var collapsable = false;
            if (section.Attributes["collapsable"] != null)
            {
                collapsable = section.Attributes["collapsable"].Value.ConvertTo<bool>();
            }

            if (section.Attributes["displayEmptyAttributes"] != null)
            {
                displayEmptyAttributes = section.Attributes["displayEmptyAttributes"].Value.ConvertTo<bool>();
            }

            GlobalEntityLocaleFacade globalEntityLocaleFacade = new GlobalEntityLocaleFacade(new GlobalEntityLocaleRepository());
            var pageLayoutSectionType = PageLayoutSectionTypes.Attributes;
            Enum.TryParse(sectionType, true, out pageLayoutSectionType);
            var sec = new Section(id, sectionName, sectionCss, showGeoLocationOnMap, collapsable, pageLayoutSectionType);
            sec.EmptySectionMessage = emptyMessage;
            sec.Description = description;

            //devices in Group
            var deviceGroup = section.Attributes["groupCommonName"] != null ? section.Attributes["groupCommonName"].Value : "";
            if (deviceGroup.IsNotNullOrEmpty())
            {
                if (pageLayoutSectionType == PageLayoutSectionTypes.Devices)
                {
                    var groupDevices = devices.Where(d => d.DeviceGroup.CommonName == deviceGroup);
                    foreach (var device in groupDevices)
                    {
                        addDeviceToLayout(device, loadEmptyAttribute, displayEmptyAttributes, sec);
                    }
                }
            }
            else
            {
                //Attributes
                var idx = 0;
                foreach (XmlNode attribute in section["fields"].ChildNodes)
                {
                    if (attribute.InnerText.IsNullOrEmpty())
                    {
                        //sec.AddAttribute(null, "", -100, "", "", "", cssClass + marginRightCssClass);
                        continue;
                    }
                    var marginRightCssClass = "";
                    idx++;
                    if (pageLayoutSectionType == PageLayoutSectionTypes.Attributes)
                    {
                        var customAttribute = customAttributeLookup.GetByCommonName(attribute.InnerText);
                        if (customAttribute == null)
                        {
                            idx--;
                            continue;
                        }
                        if (customAttribute != null)
                        {
                            var userAttribute = EndUser.UserAttributes.Where(x => x.CommonName == customAttribute.CommonName).FirstOrDefault();
                           // string attributeDisplayValue;
                           // string userAttributeValue;
                            if (customAttribute.CommonName.ToUpper() == CommonNames.Organizations.ToUpper())
                            {
                                var providerFacade = ServiceLocator.Current.Resolve<IProviderFacade>();

                                attributeDisplayValue = providerFacade.GetProviderName( EndUser.ProviderId==null?RuntimeContext.ProviderId:(int)EndUser.ProviderId);
                                userAttributeValue = (EndUser.ProviderId == null ? RuntimeContext.ProviderId : (int)EndUser.ProviderId).ToString();
                                var providerList = providerFacade.GetEnterpriseProviderList(RuntimeContext.ProviderId);
                                var values = providerList.Select(provider => new CustomAttributeValue
                                {
                                    ValueId = provider.Key, ValueName = provider.Value
                                }).ToList();
                                customAttribute.Values = values;
                                customAttribute.EditLevel = 0;
                            }
                            else
                            {
                                var userAttributeDisplayValues =
                                    EndUser.UserAttributes.Where(x => x.CommonName == customAttribute.CommonName)
                                        .Select(s => s.DisplayValue)
                                        .ToArray
                                        ();

                               var userAttributeValues =
                                    EndUser.UserAttributes.Where(x => x.CommonName == customAttribute.CommonName)
                                        .Select(s => s.Value)
                                        .ToArray();


                                attributeDisplayValue = userAttributeDisplayValues != null &&
                                                        userAttributeDisplayValues.Length > 0
                                    ? userAttributeDisplayValues.Join(", ")
                                    : string.Empty;
                                 userAttributeValue = userAttributeValues != null && userAttributeValues.Length > 0
                                    ? userAttributeValues.Join()
                                    : string.Empty;
                            }
                            var metaData = userAttribute != null ? userAttribute.MetaData : "";
                            var alwaysSendBackToServer = false;
                            DateTime? updatedTimeStamp = null;

                            if (userAttribute != null)
                            {
                                updatedTimeStamp = userAttribute.UpdatedOn;
                            }

                            //var lastUpdatedOn = userAttribute != null
                            //    ? userAttribute.UpdatedOn.ToString(Provider.GetDateTimeFormat().Replace("TT", "tt"))
                            //    : "";

                            var lastUpdatedOn = (userAttribute != null && userAttribute.UpdatedOn != null)
                                ? Provider.SystemToVpsDateTimeFormated(userAttribute.UpdatedOn)
                                : "";

                            var lastUpdatedBy = (userAttribute != null && userAttribute.UpdatedBy != null)
                              ? userAttribute.UpdatedBy
                              : "";

                            if (customAttribute.AttributeTypeId == CustomAttributeDataType.DateTime)
                            {
                                var dtTme = userAttributeValue.ConvertTo<DateTime>();
                                //Converting the Min and Max value to DateTime
                                customAttribute.MaxValue = !string.IsNullOrWhiteSpace(customAttribute.MaxValue) ? RuntimeContext.Provider.SystemToVpsDateTimeFormated(Convert.ToDateTime(customAttribute.MaxValue)) : customAttribute.MaxValue;
                                customAttribute.MinValue = !string.IsNullOrWhiteSpace(customAttribute.MinValue) ? RuntimeContext.Provider.SystemToVpsDateTimeFormated(Convert.ToDateTime(customAttribute.MinValue)) : customAttribute.MinValue;
                                if (dtTme != DateTime.MinValue)
                                {
                                    //attributeDsiplayValue = dtTme.ToString();
                                    attributeDisplayValue = Provider.SystemToVpsDateTimeFormated(dtTme);
                                    //provider.SystemToVpsTime(attributeDsiplayValue.ConvertTo<DateTime>()).ToString(provider.GetDateTimeFormat().Replace("TT", "tt"));
                                    userAttributeValue = attributeDisplayValue;
                                }
                                else
                                {
                                    attributeDisplayValue = string.Empty;
                                    userAttributeValue = string.Empty;

                                }
                            }
                            if (customAttribute.AttributeTypeId == CustomAttributeDataType.Date)
                            {
                                var dtTme = userAttributeValue.ConvertTo<DateTime>();
                                //Converting the Min and Max value to Date
                                customAttribute.MaxValue = !string.IsNullOrWhiteSpace(customAttribute.MaxValue) ? RuntimeContext.Provider.SystemToVpsDateTimeFormated(Convert.ToDateTime(customAttribute.MaxValue)) : customAttribute.MaxValue;
                                customAttribute.MinValue = !string.IsNullOrWhiteSpace(customAttribute.MinValue) ? RuntimeContext.Provider.SystemToVpsDateTimeFormated(Convert.ToDateTime(customAttribute.MinValue)) : customAttribute.MinValue;
                                if (dtTme != DateTime.MinValue)
                                {
                                    attributeDisplayValue = Provider.SystemToVpsDateFormated(dtTme);
                                    //provider.SystemToVpsTime(attributeDsiplayValue.ConvertTo<DateTime>()).ToString(provider.GetDateFormat());
                                    userAttributeValue = attributeDisplayValue;
                                }
                                else
                                {
                                    attributeDisplayValue = string.Empty;
                                    userAttributeValue = string.Empty;
                                }
                            }


                            if (!attributeDisplayValue.IsNullOrEmpty() ||
                                (attributeDisplayValue.IsNullOrEmpty() && (displayEmptyAttributes || loadEmptyAttribute)))
                            {
                                if (colSpan > 6)
                                {
                                    if (idx % 2 != 0)
                                    {
                                        marginRightCssClass = " mar-right50";
                                    }
                                }

                                var readOnly = false;
                                if (EndUser.Id <= 0)
                                {
                                    if (customAttribute.EditLevel <= 0)
                                    {
                                        //customAttribute.UpdateOnlyOnce = "N";
                                        //customAttribute.EditLevel = -1;
                                        readOnly = true;
                                    }
                                    else if (customAttribute.EditLevel != 0)
                                    {
                                        readOnly = false;
                                    }
                                    else
                                    {
                                        readOnly = true;
                                    }
                                    //Any attributes created in system set (3) having User Can Update is "No" and Is Mandatory "Y" then should be readonly in End User manager
                                    if (customAttribute.EditLevel == 2 && customAttribute.IsMandatory == "Y" && customAttribute.IsSystemAttribute == "N" && customAttribute.IsStandard == "N" && customAttribute.ProviderId == 3)
                                    {
                                        readOnly = true;
                                    }

                                    if (customAttribute.DefaultValue.IsNotNullOrEmpty())
                                    {

                                        if (customAttribute.AttributeTypeId == CustomAttributeDataType.Picklist || customAttribute.AttributeTypeId == CustomAttributeDataType.MultiPicklist)
                                        {
                                            userAttributeValue = customAttribute.DefaultValue;
                                            var attrValues = customAttribute.Values.Where(v => userAttributeValue.Split(',').Contains(v.ValueId.ToString())).Select(c => c.ValueName).ToArray().Join(", ");
                                            attributeDisplayValue = attrValues;
                                        }
                                        //Todo: temporary code for checkbox, since legacy is storing value name in default value column and not the value id.
                                        else if (customAttribute.AttributeTypeId == CustomAttributeDataType.Checkbox)
                                        {
                                            userAttributeValue = customAttribute.DefaultValue;
                                            if (userAttributeValue.IsNumeric())
                                            {
                                                var attrValues = customAttribute.Values.Where(v => userAttributeValue.Split(',').Contains(v.ValueId.ToString())).Select(c => c.ValueName).ToArray().Join(", ");
                                                attributeDisplayValue = attrValues;
                                            }
                                            else
                                            {
                                                var attrValues = customAttribute.Values.Where(v => userAttributeValue.Split(',').Contains(v.ValueName.ToString())).Select(c => c.ValueName).ToArray().Join(", ");
                                                var attrDefaultValue = customAttribute.Values.Where(v => userAttributeValue.Split(',').Contains(v.ValueName.ToString())).Select(c => c.ValueId).FirstOrDefault();
                                                userAttributeValue = attrDefaultValue.ConvertTo<string>();
                                                attributeDisplayValue = attrValues;
                                            }
                                        }
                                        else
                                        {
                                            userAttributeValue = customAttribute.DefaultValue;
                                            attributeDisplayValue = userAttributeValue;
                                        }
                                    }
                                }
                                else
                                {
                                    if (customAttribute.EditLevel == 0 || customAttribute.UpdateOnlyOnce == "Y")
                                    {
                                        readOnly = true;
                                    }


                                    //Requirement is to have value of 'No' in case checkbox user attribute attribute value is null.
                                    if (customAttribute.AttributeTypeId == CustomAttributeDataType.Checkbox && userAttribute == null)
                                    {
                                        var noValue = customAttribute.Values.FirstOrDefault(a => a.CommonName == "NO");
                                        attributeDisplayValue = noValue == null ? string.Empty : noValue.ValueName;

                                        attributeDisplayValue = globalEntityLocaleFacade.GetLocalizedValue(attributeDisplayValue, BusinessEntity.CheckBox, "Name", RuntimeContext.Provider.BaseLocale);

                                        userAttributeValue = noValue == null ? "0" : noValue.ValueId.ToString();
                                        alwaysSendBackToServer = true;
                                    }
                                }

                                if (((customAttribute.CommonName != CommonNames.Status && customAttribute.CommonName != CommonNames.CreatedOn) && EndUser.Id <= 0) || EndUser.Id > 0)
                                {
                                    //do not add operator user name
                                    if (CommonNames.OperatorUserName != customAttribute.CommonName)
                                    {
                                        sec.AddAttribute(customAttribute, customAttribute.CommonName, customAttribute.Id, customAttribute.AttributeName,
                                            userAttributeValue, attributeDisplayValue, cssClass + marginRightCssClass, customAttribute.AttributeTypeId, readOnly,
                                            lastUpdatedOn, metaData, updatedTimeStamp, alwaysSendBackToServer).UpdatedBy = lastUpdatedBy;
                                    }
                                }
                            }
                            else
                            {
                                idx--;
                            }
                        }
                    }
                    else if (pageLayoutSectionType == PageLayoutSectionTypes.Static)
                    {
                        //sec.AddAttribute(null, "BADGE_" + attribute.InnerText, 0, attribute.InnerText, attribute.Attributes["text"].Value,
                        //    attribute.Attributes["text"].Value, attribute.Attributes["type"].Value, CustomAttributeDataType.String);
                    }
                    else if (pageLayoutSectionType == PageLayoutSectionTypes.SubscriptionsAndMembership)
                    {
                        //var membership = customAttributeLookup.GetByCommonName(attribute.InnerText);
                        //if (membership != null)
                        //{
                        //    var userAttribute = EndUser.UserAttributes.Where(x => x.CommonName == membership.CommonName).FirstOrDefault();
                        //    var userAttributeDsiplayValues =
                        //        EndUser.UserAttributes.Where(x => x.CommonName == membership.CommonName).Select(s => s.DisplayValue)
                        //                .FirstOrDefault();
                        //    if (userAttributeDsiplayValues.IsNotNullOrEmpty() && userAttributeDsiplayValues.ToUpperInvariant() == "YES")
                        //    {
                        //        sec.AddAttribute(membership, membership.CommonName, membership.Id, userAttribute.AttributeName,
                        //            userAttribute.Value, userAttribute.AttributeName, cssClass + marginRightCssClass, membership.AttributeTypeId);
                        //    }
                        //}
                    }
                    else if (pageLayoutSectionType == PageLayoutSectionTypes.Devices)
                    {
                        //Todo: add message, or log it.
                        if (!devices.HasValue())
                        {
                            continue;
                        }
                        var device = devices.Where(d => d.CommonName == attribute.InnerText && d.DeviceProvider.IsEnabled == "Y").FirstOrDefault();
                        addDeviceToLayout(device, loadEmptyAttribute, displayEmptyAttributes, sec);
                    }
                }
            }
            return sec;
        }

        private void addDeviceToLayout(Device device, bool loadEmptyAttribute, bool displayEmptyAttributes, Section sec)
        {
            if (device != null)
            {
                var userDevice = EndUser.UserAttributes.Where(x => x.CommonName == device.CommonName).FirstOrDefault();
                //var att = attribute.InnerText.Split('-');
                //var attributeName = att.Length > 1 ? att[1].Trim() : attribute.InnerText;
                var phoneCss = (device.GroupId == 3 || device.GroupId == 6 || device.GroupId == 7) ? "row phone" : "row";
                //var attributeValue = endUser.Get<object>(device.CommonName);
                var attributeDisplayValue = userDevice != null ? userDevice.DisplayValue : "";
                var attributeValue = userDevice != null ? userDevice.Value : "";
                var readOnly = device.DeviceProvider.EditLevel <= 0;
                bool IsValidNumber = true;
                if (!attributeDisplayValue.IsNullOrEmpty() ||
                    (attributeDisplayValue.IsNullOrEmpty() && (displayEmptyAttributes || loadEmptyAttribute)))
                {
                    //for phone number with extension
                    if (device.DeviceGroup.CommonName == "PHONE" || device.DeviceGroup.CommonName == "FAX" || device.DeviceGroup.CommonName == "TEXT-MESSAGING")
                    {
                        string extension = string.Empty;
                        if ((attributeDisplayValue.Contains("x")) && (device.DeviceGroup.CommonName == "PHONE" || device.DeviceGroup.CommonName == "FAX"))
                        {
                            string[] attributeValues = attributeDisplayValue.Split(new[] { 'x' }, 2);
                            attributeDisplayValue = attributeValues[0];
                            extension = attributeValues[1];

                            if (attributeDisplayValue != "")
                            {
                                //Phone Number library call
                                var phoneUtil = PhoneNumberUtil.GetInstance();
                                //quickly guessing whether a number is a possible phonenumber by using only the length information, much faster than a full validation
                                if (phoneUtil.IsPossibleNumber(attributeDisplayValue, ""))
                                {
                                    var numberProto = phoneUtil.Parse(attributeDisplayValue.ToString(), "");
                                    if (phoneUtil.IsValidNumber(numberProto))
                                    {
                                        //formats phone numbers as INTERNATIONAL Number
                                        attributeDisplayValue = phoneUtil.Format(numberProto, PhoneNumberFormat.INTERNATIONAL);
                                    }
                                    else
                                    {
                                        //sent to UI for page load validation for existing number.
                                        IsValidNumber = false;
                                    }
                                }
                                else
                                {
                                    //sent to UI for page load validation for existing number.
                                    IsValidNumber = false;
                                }
                            }
                            sec.AddAttribute(null, device.CommonName, 1, device.Name, attributeValue, attributeDisplayValue, phoneCss,
                             CustomAttributeDataType.Device, readOnly, "", "", null, false, extension, IsValidNumber).DeviceMeta = device;
                        }
                        else
                        {
                            if (attributeDisplayValue != "")
                            {
                                //return instance  Phone Number library 
                                var phoneUtil = PhoneNumberUtil.GetInstance();
                                //quickly guessing whether a number is a possible phonenumber by using only the length information, much faster than a full validation
                                if (phoneUtil.IsPossibleNumber(attributeDisplayValue, ""))
                                {
                                    var numberProto = phoneUtil.Parse(attributeDisplayValue, "");
                                    //Full validation of a phone number for a region using length and prefix information
                                    if (phoneUtil.IsValidNumber(numberProto))
                                    {
                                        //formats phone numbers as INTERNATIONAL Number for display number
                                        attributeDisplayValue = phoneUtil.Format(numberProto, PhoneNumberFormat.INTERNATIONAL);
                                    }
                                    else
                                    {
                                        //sent to UI for page load validation for existing number.
                                        IsValidNumber = false;
                                    }
                                }
                                else
                                {
                                    //sent to UI for page load validation for existing number.
                                    IsValidNumber = false;
                                }
                            }


                            sec.AddAttribute(null, device.CommonName, 1, device.Name, attributeValue, attributeDisplayValue, phoneCss,
                             CustomAttributeDataType.Device, readOnly, "", "", null, false, "", IsValidNumber).DeviceMeta = device;
                        }
                    }
                    else
                    {
                        sec.AddAttribute(null, device.CommonName, 1, device.Name, attributeValue, attributeDisplayValue, phoneCss,
                            CustomAttributeDataType.Device, readOnly).DeviceMeta = device;
                    }
                }
            }
        }
    }

    public class EndUserForSave
    {
        public int UserId { get; set; }
        public int ProviderId { get; set; }
        public IEnumerable<CustomUserAttribute> CustomAttributes { get; set; }
    }

    public class CustomUserAttribute
    {
        public int AttributeId { get; set; }

        public string CommonName { get; set; }

        public string Value { get; set; }

        public int EditLevel { get; set; }

        public string MetaData { get; set; }

        public CustomAttributeDataType? AttributeTypeId { get; set; }

        public DateTime? UpdatedTimeStamp { get; set; }

        public string Extension { get; set; }
    }

    public enum PageLayoutSectionTypes
    {
        Attributes,

        Static,

        Devices,

        SubscriptionsAndMembership
    }

    public class SectionAttribute
    {
        public SectionAttribute()
        {
        }

        public SectionAttribute(string commonName, string updatedOn = "", bool readOnly = false)
        {
            CommonName = commonName;
            UpdatedOn = updatedOn;
            ReadOnly = readOnly;
        }

        public int AttributeId { get; set; }

        public string Name { get; set; }

        public object Value { get; set; }

        public object DisplayValue { get; set; }

        public CustomAttributeDataType? AttributeType { get; set; }

        public string CssClass { get; set; }

        public string CommonName { get; set; }

        public string UpdatedBy { get; set; }

        public string UpdatedOn { get; set; }

        public bool UpdateOnlyOnce { get; set; }

        public bool ReadOnly { get; set; }

        public string MetaData { get; set; }


        public DateTime UpdatedTimeStamp { get; set; }

        public CustomAttribute AttributeMeta { get; set; }

        public Device DeviceMeta { get; set; }
        public bool AlwaysSendBackToServer { get; set; }

        public string Extension { get; set; }

        public bool IsValidNumber { get; set; }
    }

    public class Column
    {
        public Column()
        {
            ColSpan = 1;
            Buckets = new List<Bucket>();
            //this.Buckets = buckets;
        }

        public Column(IList<Bucket> buckets, int colSpan)
        {
            Buckets = buckets;
            ColSpan = colSpan;
        }

        public Column(int colSpan)
        {
            Buckets = new List<Bucket>();
            ColSpan = colSpan;
        }

        public void AddBucket(Bucket bucket)
        {
            Buckets.Add(bucket);
        }

        public int ColSpan { get; private set; }

        //public IList<Section> Sections { get; private set; }
        public IList<Bucket> Buckets { get; set; }
    }

    public class Bucket
    {
        public Bucket(List<Section> sections)
        {
            CssClass = "";
            IsCollapsable = false;
            Sections = sections; // new List<Section>();
        }

        public Bucket(string cssClass, bool isCollapsable = false)
        {
            CssClass = cssClass;
            IsCollapsable = isCollapsable;
            Sections = new List<Section>();
        }

        public Bucket(IList<Section> sections)
        {
            Sections = sections;
        }

        public void AddSection(Section section)
        {
            Sections.Add(section);
        }

        public IList<Section> Sections { get; set; }

        public string CssClass { get; set; }

        public bool IsCollapsable { get; set; }
    }

    public class PageLayoutModel
    {
        public IEnumerable<PageLayoutRow> PageLayoutRows { get; set; }
    }

    public class PageLayoutRow
    {
        public PageLayoutRow(IList<Column> columns)
        {
            Columns = columns;
        }

        public PageLayoutRow()
        {
            Columns = new List<Column>();
        }

        public IList<Column> Columns { get; set; }
    }

    public class Section
    {
        public Section()
        {
            Name = "NewSection";
            Id = "NewSection";
            _attributes = new List<SectionAttribute>();
            ChildSections = new List<Section>();
            EmptySectionMessage = string.Empty;
            Description = string.Empty;
        }

        public Section(string name)
        {
            Name = name;
            Id = name.Replace(" ", "");
            _attributes = new List<SectionAttribute>();
            CssClass = "";
            ShowGeoLocationOnMap = false;
            ChildSections = new List<Section>();
            IsCollapsable = false;
            EmptySectionMessage = string.Empty;
            Description = string.Empty;
        }

        public Section(string id, string name, string cssClass, bool showGeoLocationOnMap = false, bool isCollapsable = false,
                        PageLayoutSectionTypes pageLayoutSectionType = PageLayoutSectionTypes.Attributes)
        {
            Id = id;
            Name = name;
            _attributes = new List<SectionAttribute>();
            CssClass = cssClass;
            ShowGeoLocationOnMap = showGeoLocationOnMap;
            ChildSections = new List<Section>();
            IsCollapsable = isCollapsable;
            PageLayoutSectionType = pageLayoutSectionType;
            EmptySectionMessage = string.Empty;
            Description = string.Empty;
        }

        private readonly List<SectionAttribute> _attributes;

        public string Id { get; set; }

        public string CssClass { get; set; }

        public string Name { get; set; }

        public string HelpText { get; set; }

        public string Description { get; set; }


        public string EmptySectionMessage { get; set; }


        public bool ShowGeoLocationOnMap { get; private set; }

        public List<SectionAttribute> Attributes
        {
            get { return _attributes; }
        }

        public bool IsCollapsable { get; set; }

        public List<Section> ChildSections { get; set; }

        public PageLayoutSectionTypes PageLayoutSectionType { get; set; }


        public SectionAttribute AddAttribute(SectionAttribute attribute)
        {
            _attributes.Add(attribute);
            return attribute;
        }

        public SectionAttribute AddAttribute(CustomAttribute attributeMeta, string commonName, int attributeId, string name,
                                            object value, object displayValue, string cssClass = "row",
                                            CustomAttributeDataType? attributeType = CustomAttributeDataType.String, bool readOnly = false, string updatedOn = "",
                                            string metaData = "", DateTime? updatedTimeStamp = null, bool alwaysSendBackToServer = false, string Extension = "", bool IsValidNumber = true)
        {
            if ((commonName == CommonNames.UserPassword || commonName == CommonNames.Pin) && attributeType == CustomAttributeDataType.String)
            {
                displayValue = (displayValue == null || string.IsNullOrWhiteSpace(displayValue.ToString())) ? string.Empty : "*******";
            }
            var sectionAttribute = new SectionAttribute(commonName, updatedOn, readOnly)
            {
                AttributeId = attributeId,
                Name = name,
                Value = value,
                DisplayValue = displayValue,
                CssClass = cssClass,
                AttributeType = attributeType,
                AlwaysSendBackToServer = alwaysSendBackToServer,
                Extension = Extension,
                IsValidNumber = IsValidNumber

            };
            sectionAttribute.MetaData = metaData;
            //This code is placed here to trigger validation for maximum range of integers on client side. 
            // If the custom attribute which is of type number doesn't have MaxValue set, then we should set it to Int32.MaxVal, so the UI will not allow values larger than that.
            if (attributeType == CustomAttributeDataType.Number && (attributeMeta.MaxValue.IsNullOrEmpty()))
                attributeMeta.MaxValue = Int32.MaxValue.ToString();
            sectionAttribute.AttributeMeta = attributeMeta;
            sectionAttribute.UpdatedTimeStamp = updatedTimeStamp.HasValue ? updatedTimeStamp.Value : DateTime.MinValue;
            _attributes.Add(sectionAttribute);
            return sectionAttribute;
        }
    }
}