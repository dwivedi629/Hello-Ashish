﻿using System;
using System.Data;
using AtHoc.Infrastructure.Ioc;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Entities.Accountability;
using AtHoc.IWS.Web.Helpers;
using AtHoc.IWS.Web.Models.Publishing;
using AtHoc.Utilities;

namespace AtHoc.IWS.Web.Models.Accountability
{
    public class JsonResponseModel
    {
        public JsonResponseModel(bool success, object data= null, string error = null)
        {
            Data = data;
            Success = success;
            ErrorMessage = error;
            TimeStamp = RuntimeContext.Provider.UtcToVpsTime(DateTime.UtcNow).ToString(RuntimeContext.Provider.GetDateTimeFormat());
        }
        public bool Success { get; set; }
        public String ErrorMessage { get; set; }
        public object Data { get; set; }

        public string TimeStamp { get; set; }               
        
    }    
}