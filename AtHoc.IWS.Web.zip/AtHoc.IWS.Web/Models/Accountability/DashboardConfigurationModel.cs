﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AtHoc.IWS.Web.Models.Accountability
{
    /// <summary>    
    /// </summary>
    public class DashboardConfigurationModel
    {
        public string Type { get; set; } // "event", "alert"
        public List<int> Ids { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string StatusAttributeId { get; set; }
        public int SessionId { get; set; }        
        public Dictionary<string, Tab> Tabs { set; get; }
        public DashboardConfigurationModel()
        {
            Tabs = new Dictionary<string, Tab>();
            Tabs.Add(TabId.Dashboard, new Tab(TabId.Dashboard));
            Tabs.Add(TabId.Users, new Tab(TabId.Users));
            Tabs.Add(TabId.Analysis, new Tab(TabId.Analysis));
            Tabs.Add(TabId.Activity, new Tab(TabId.Activity));
            Tabs.Add(TabId.Setting, new Tab(TabId.Setting));            
        }
    }

    public class Tab
    {
        public string Id { set; get; }//future
        public string Name { set; get; }//future
        public bool Visible { set; get; }
        public Dictionary<string, object> Settings { set; get; }

        public Tab(string id)
        {
            Id = id;            
            Settings = new Dictionary<string, object>();
            Visible = true;
        }        
    }

    public class TabId
    {        
        public const string Dashboard =  "dashboard";        
        public const string Users =  "users";
        public const string Analysis =  "analysis";
        public const string Activity =  "activity";
        public const string Setting =  "setting";
    }
}