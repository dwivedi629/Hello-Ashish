﻿using System;
using System.Collections.Generic;
using System.Linq;
using AtHoc.Publishing;

namespace AtHoc.IWS.Web.Models.Accountability
{
    /// <summary>
    /// A lightweight model for the home page live PA events
    /// </summary>
    public class LiveEventModel
    {
        public int EventId { get; set; }
        public int AlertBaseId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string TimeLeft { get; set; }
        public IList<AlertResponse> Responses { get; set; }
        public DateTime StartTime { get; set; }
        public string StartTimeDisplay { get; set; }
        public decimal Affected { get; set; }
        public decimal UsersResponded { get; set; }
        public decimal UsersNotResponded { get; set; }
    }
}