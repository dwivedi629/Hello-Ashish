﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Web;
using AtHoc.IWS.Business.Domain.Authorization;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Web.Models.Accountability
{
    public class PermissionModel
    {

        public PermissionModel(IAuthFacade authFacade,IEnumerable<OperatorAccess> operatorAccessCollection )
        {
            var accessCollection = operatorAccessCollection as OperatorAccess[] ?? operatorAccessCollection.ToArray();
            var eventModifyRole= authFacade.HasAccess(accessCollection, SystemObject.AccountabilityEvent, ActionType.Modify);
            var eventPublishRole = authFacade.HasAccess(accessCollection, SystemObject.AccountabilityEvent, ActionType.Publish);
            var eventViewRole = authFacade.HasAccess(accessCollection, SystemObject.AccountabilityEvent, ActionType.View);
            var templateModifyRole = authFacade.HasAccess(accessCollection, SystemObject.AccountabilityTemplate, ActionType.Modify);
            var templatePublishRole = authFacade.HasAccess(accessCollection, SystemObject.AccountabilityTemplate, ActionType.Publish);
            var templateViewRole = authFacade.HasAccess(accessCollection, SystemObject.AccountabilityTemplate, ActionType.View);

        }
        public bool IsAlertPublisher { get; set; }
        public bool IsEventPublisher { get; set; }
        public bool IsAllowedToUpdateStatus { get; set; }

    }
}