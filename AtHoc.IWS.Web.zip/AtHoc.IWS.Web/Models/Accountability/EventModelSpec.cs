﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AtHoc.IWS.Web.Models.Accountability
{
    public class EventModelSpec
    {
        public int ProviderId { get; set; }
        public int OperatorId { get; set; }

        public string ProviderBaseLocale { get; set; }
        public bool HasAlertPublisherRole { get; set; }
        public bool HasEventPublisherRole { get; set; }
        public DateTime CurrentSystemDateTime { get; set; }
    }
}