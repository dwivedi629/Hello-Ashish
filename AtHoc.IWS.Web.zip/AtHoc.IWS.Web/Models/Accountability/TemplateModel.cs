﻿using System;
using System.Linq;
using AtHoc.Infrastructure.Extensions;
using AtHoc.Infrastructure.Ioc;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Entities.Accountability;
using AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Business.Domain.Publishing.Impl;
using AtHoc.IWS.Web.Helpers;
using AtHoc.IWS.Web.Models.Publishing;
using AtHoc.Systems;
using AtHoc.Utilities;
using AtHoc.IWS.Business.Domain.Entities;
using System.Collections.Generic;
using AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel;
using AtHoc.Infrastructure;
using System.ComponentModel;
using AtHoc.Global.Resources;
using AtHoc.IWS.Business.Configurations;
using System.Threading;
using EO.Internal;
using AtHoc.IWS.Business.Domain.Targeting.Model;

namespace AtHoc.IWS.Web.Models.Accountability
{
    public class TemplateModel
    {

        public TemplateModel()
        {
            AccountabilityOfficers = new List<UserNode>();
        }
        public int AlertBaseId { get; set; }
        public int? OperatorAlertBaseId { get; set; }
        public PublishingModel AlertBaseModel { get; set; }
        public PublishingModel OperatorAlertBaseModel { get; set; }
        public GeneralSectionModel GeneralSectionModel { get; set; }
        public ProcessSectionModel ProcessSectionModel { get; set; }
        public OfficerSectionModel OfficerSectionModel { get; set; }
        public IList<UserNode> AccountabilityOfficers { get; set; }
        public int Id { get; set; }

        public string Name { get; set; }
        public string Description { get; set; }
        public string CommonName { get; set; }
        public int CreatedBy { get; set; }

        public string CreatedByName { get; set; }
        public DateTime CreatedOn { get; set; }

        public string CreatedOnString { get; set; }
        public string UpdatedByName { get; set; }

        public int UpdatedBy { get; set; }
        public DateTime UpdatedOn { get; set; }
        public string UpdatedOnString { get; set; }

        public DateTime LastEventPublishedOn { get; set; }

        public string LastEventPublishedOnString { get; set; }

        public static TemplateModel FromTemplate(AccountabilityTemplate template, bool loadAlertSpec)
        {
            GeneralSectionModel generalSectionModel = new GeneralSectionModel()
            {
                Name = template.Name,
                Description = template.Description
            };

            ProcessSectionModel processingSectionModel = ProcessSectionModel.FromTemplate(template);
            var model = new TemplateModel()
          {
              Id = template.TemplateId,
              Name = template.Name,
              Description = template.Description,
              CommonName = template.CommonName,
              CreatedBy = template.CreatedBy,
              CreatedByName = template.CreatedByName,
              CreatedOn = template.CreatedOn,
              CreatedOnString = RuntimeContext.Provider.SystemToVpsDateTimeFormated(template.CreatedOnInSystemTimeZone),
              UpdatedBy = template.UpdatedBy,
              UpdatedByName = template.UpdatedByName,
              UpdatedOnString = RuntimeContext.Provider.SystemToVpsDateTimeFormated(template.UpdatedOnInSystemTimeZone),
              UpdatedOn = template.UpdatedOn,
              GeneralSectionModel = generalSectionModel,
              ProcessSectionModel = processingSectionModel,
              OfficerSectionModel = OfficerSectionModel.FromDomainModel(template),
              AlertBaseId = template.AlertId,
              //officer alert base Id
              OperatorAlertBaseId = template.OperatorAlertBaseId,
              LastEventPublishedOn = template.LastEventPublishedOnDateTime,
              LastEventPublishedOnString = template.LastEventPublishedOnDateTime == DateTime.MinValue ? "" : RuntimeContext.Provider.SystemToVpsDateTimeFormated(template.LastEventPublishedOnDateTime)
          };


            var providerId = RuntimeContext.ProviderId;
            var operatorId = RuntimeContext.OperatorId;
            IPublishingDomainToModel publishingHelper = ServiceLocator.Resolve<IPublishingDomainToModel>();
            if (loadAlertSpec)
            {
                //parentId: 8240,
                var alertModel = publishingHelper.GetPublishingModel(template, RuntimeContext.Provider, operatorId, RuntimeContext.CustomAttributesWithouMassDevices, RuntimeContext.Provider.BaseLocale);
                //todo: review this. ugly.
                alertModel.ScenarioSection.ChannelId = template.AlertSpec.Category.Id;
                //override the response list to show only 'Status' attribute types for PA
                alertModel.Content.ResponseOptionList = RuntimeContext.CustomAttributesWithouMassDevices.Where(
                    a => a.IsStatus())
                .OrderBy(a => a.AttributeName)
                .Select(
                    a =>
                        new KeyValueModel
                        {
                            Id = a.Id,
                            Name = a.AttributeName,
                            Values =
                                (!a.Values.HasValue()) ? new List<string>() : a.Values.Select(v => v.ValueName).ToList()
                        })
                .ToList();
                model.AlertBaseModel = alertModel;
                model.AlertBaseModel.Context = PublishingContext.AccountTemplate;
                model.AlertBaseModel.ParentId = model.AlertBaseId;

                //operator alert 
                if (template.OperatorAlertBase!=null)
                {
                    /*
                    var operatorAlertModel = publishingHelper.GetPublishingModel(template.OperatorAlertBase, RuntimeContext.Provider, operatorId, RuntimeContext.CustomAttributesWithouMassDevices, RuntimeContext.Provider.BaseLocale);
                    //todo: review this. ugly.
                    operatorAlertModel.ScenarioSection.ChannelId = template.AlertSpec.Category.Id;
                    //override the response list to show only 'Status' attribute types for PA
                    
                    model.OperatorAlertBaseModel = alertModel;
                    model.OperatorAlertBaseModel.Context = PublishingContext.AccountTemplate;
                    model.OperatorAlertBaseModel.ParentId = model.AlertBaseId;
                     * */
                    model.AccountabilityOfficers=  publishingHelper.GetAccountabilityOfficers(template.OperatorAlertBase.AlertSpec.Targeting, RuntimeContext.ProviderId, RuntimeContext.OperatorId);
                }
              
               
            }

            return model;
        }

        public AccountabilityTemplate ToTemplate(IPublishingModelToDomain publishingModelToDomain)
        {
            var acctTemplate = new AccountabilityTemplate {ProviderId = RuntimeContext.ProviderId};

             PublishingModelToDomain.SetScenarioSectionSettings(AlertBaseModel, acctTemplate, RuntimeContext.ProviderId, RuntimeContext.OperatorId);
            // set scenario schedule settings on alertbase
            // todo: review. a hack. need to set the channel id in order to save theh base template
            acctTemplate.AlertSpec.Category = AtHoc.Publishing.Category.GetCategory(AlertBaseModel.ScenarioSection.ChannelId);
            if (AccountabilityOfficers != null && AccountabilityOfficers.Any())
            {
                acctTemplate.OperatorAlertBase = new AccountabilityAlertBase();
                PublishingModelToDomain.SetScenarioSectionSettings(AlertBaseModel, acctTemplate.OperatorAlertBase, RuntimeContext.ProviderId, RuntimeContext.OperatorId);
                publishingModelToDomain.SetAccountabilityOfficers(AccountabilityOfficers, acctTemplate.OperatorAlertBase.AlertSpec.Targeting, RuntimeContext.ProviderId, RuntimeContext.OperatorId);

                acctTemplate.OperatorAlertBase.AlertSpec.Category = AtHoc.Publishing.Category.GetCategory(AlertBaseModel.ScenarioSection.ChannelId);
               
                if (OperatorAlertBaseId != null) acctTemplate.OperatorAlertBase.AlertId = (int)OperatorAlertBaseId;
                acctTemplate.OperatorAlertBase.AlertSpec.LiveDuration = ProcessSectionModel.LiveDuration.ToDuration();
            }
            
           
           
            if (GeneralSectionModel != null)
            {
                acctTemplate.Name = GeneralSectionModel.Name;
                acctTemplate.Description = GeneralSectionModel.Description ?? string.Empty;
            }
            acctTemplate.TemplateId = Id;
            acctTemplate.AlertId = AlertBaseId;
            acctTemplate.AlertSpec.LiveDuration = ProcessSectionModel.LiveDuration.ToDuration();
            acctTemplate.PastStatusValidityDuration = ProcessSectionModel.PastStatusValidityDurationEnabled
               ? ProcessSectionModel.PastStatusValidityDuration.ToDuration()
               : null;
            acctTemplate.FirstAlertUserMessage = ProcessSectionModel.FirstAlertUserMessage.ToAccountabilityMessage();
            acctTemplate.ReminderAlertUserMessage = ProcessSectionModel.ReminderAlertUserMessage.ToAccountabilityMessage();
            acctTemplate.CloseAlertUserMessage = ProcessSectionModel.CloseAlertUserMessage.ToAccountabilityMessage();

            acctTemplate.FirstAlertOperatorMessage = OfficerSectionModel.InitialMessage.ToAccountabilityMessage();
            acctTemplate.CloseAlertOperatorMessage = OfficerSectionModel.EndingMessage.ToAccountabilityMessage();
            return acctTemplate;
        }
    }

    public class GeneralSectionModel
    {
        public string Name { get; set; }
        public string Description { get; set; }
    }

    public class ProcessSectionModel
    {
        public ProcessSectionModel()
        {
            TimeFormat = (from DurationFormatEnum tformat in Enum.GetValues(typeof(DurationFormatEnum))
                          select new MultiSelectListModel()
                          {
                              Value = tformat.ToString(),
                              Text = tformat.Display() ?? tformat.ToString()
                          }).ToList();
        }

        //todo: MUSt unify this code between AccountabilityEvent and AccountabilityTemplate
        public static ProcessSectionModel FromEvent(AccountabilityEvent ae)
        {
            ProcessSectionModel processingSectionModel = new ProcessSectionModel()
            {
                PastStatusValidityDurationEnabled = (ae.PastStatusValidityDuration != null ? true : false)
            };

            if (ae.TemplateId == 0)
            {
                processingSectionModel.PastStatusValidityDurationEnabled = false;
            }

            if (ae.AlertSpec.LiveDuration != null)
            {
                processingSectionModel.LiveDuration = new CustomDuration().FromDuration(ae.AlertSpec.LiveDuration);
            }
            if (ae.PastStatusValidityDuration != null)
            {
                processingSectionModel.PastStatusValidityDuration = new CustomDuration().FromDuration(ae.PastStatusValidityDuration);
            }

            processingSectionModel.FirstAlertUserMessage = new AccountabilityMessageModel().FromAccountabilityMessage(ae.FirstAlertUserMessage);
            processingSectionModel.ReminderAlertUserMessage = new AccountabilityMessageModel().FromAccountabilityMessage(ae.ReminderAlertUserMessage);
            processingSectionModel.CloseAlertUserMessage = new AccountabilityMessageModel().FromAccountabilityMessage(ae.CloseAlertUserMessage);

            return processingSectionModel;
        }

        //todo:MUSt unify this code between AccountabilityEvent and AccountabilityTemplate
        public static ProcessSectionModel FromTemplate(AccountabilityTemplate at)
        {
            ProcessSectionModel processingSectionModel = new ProcessSectionModel()
            {
                PastStatusValidityDurationEnabled = (at.PastStatusValidityDuration != null ? true : false)
            };

            if (at.TemplateId == 0)
            {
                processingSectionModel.PastStatusValidityDurationEnabled = false;
            }

            if (at.AlertSpec.LiveDuration != null)
            {
                processingSectionModel.LiveDuration = new CustomDuration().FromDuration(at.AlertSpec.LiveDuration);
            }
            if (at.PastStatusValidityDuration != null)
            {
                processingSectionModel.PastStatusValidityDuration = new CustomDuration().FromDuration(at.PastStatusValidityDuration);
            }
            else
            {
                processingSectionModel.PastStatusValidityDuration = new CustomDuration
                {
                    Unit = DurationFormatEnum.Hour.ToString(),
                    Value = 0
                };
            }

            processingSectionModel.FirstAlertUserMessage = new AccountabilityMessageModel().FromAccountabilityMessage(at.FirstAlertUserMessage);
            processingSectionModel.ReminderAlertUserMessage = new AccountabilityMessageModel().FromAccountabilityMessage(at.ReminderAlertUserMessage);
            processingSectionModel.CloseAlertUserMessage = new AccountabilityMessageModel().FromAccountabilityMessage(at.CloseAlertUserMessage);
            return processingSectionModel;
        }

        public CustomDuration LiveDuration { get; set; }
        public CustomDuration PastStatusValidityDuration { get; set; }

        public bool PastStatusValidityDurationEnabled { get; set; }
        public AccountabilityMessageModel FirstAlertUserMessage { get; set; }
        public AccountabilityMessageModel ReminderAlertUserMessage { get; set; }
        public AccountabilityMessageModel CloseAlertUserMessage { get; set; }
        public List<MultiSelectListModel> TimeFormat { get; set; }
        public List<EventPlaceholders> EventPlaceholderList { get; set; }
    }

    public class OfficerSectionModel
    {
        internal static OfficerSectionModel FromDomainModel(AccountabilityEventBase model)
        {
            OfficerSectionModel ret = null;
            if (model != null)
            {
                ret = new OfficerSectionModel();
                ret.InitialMessage = new AccountabilityMessageModel
                {
                    Title = model.FirstAlertOperatorMessage != null ? model.FirstAlertOperatorMessage.Title : string.Empty,
                    Body = model.FirstAlertOperatorMessage != null ? model.FirstAlertOperatorMessage.Body : string.Empty,
                    MessageId = model.FirstAlertOperatorMessage != null ? model.FirstAlertOperatorMessage.MessageId : -1,
                    IsEnabled = model.FirstAlertOperatorMessage != null ? model.FirstAlertOperatorMessage.IsEnabled : true
                };

                ret.EndingMessage = new AccountabilityMessageModel
                {
                    Title = model.CloseAlertOperatorMessage != null ? model.CloseAlertOperatorMessage.Title : string.Empty,
                    Body = model.CloseAlertOperatorMessage != null ? model.CloseAlertOperatorMessage.Body : string.Empty,
                    MessageId = model.CloseAlertOperatorMessage != null ? model.CloseAlertOperatorMessage.MessageId : -1,
                    IsEnabled = model.CloseAlertOperatorMessage != null ? model.CloseAlertOperatorMessage.IsEnabled : true
                };
            }
            return ret;
        }

        public AccountabilityMessageModel InitialMessage { get; set; }
        public AccountabilityMessageModel EndingMessage { get; set; }
        public List<EventPlaceholders> EventPlaceholderList { get; set; }
    }

    public enum DurationFormatEnum
    {
        [Description("DurationFormat_Minutes")]
        Minute,
        [Description("DurationFormat_Hours")]
        Hour,
        [Description("DurationFormat_Days")]
        Day,
    }

    public class CustomDuration
    {
        public string Unit { get; set; }
        public int Value { get; set; }

        public Duration ToDuration()
        {
            return new Duration(Unit, Value);
        }
        public CustomDuration FromDuration(Duration duration)
        {
            return duration != null ? new CustomDuration() { Value = duration.Value, Unit = duration.Unit.ToString() } : null;
        }

    }
    public static class DurationFormatEnumExtension
    {
        private static readonly System.Resources.ResourceManager Resource = new System.Resources.ResourceManager(Constants.resourceAssembly, typeof(IWSResources).Assembly);
        public static string Display(this DurationFormatEnum format)
        {
            return Resource.GetString(format.GetDescription(), Thread.CurrentThread.CurrentUICulture);
        }
    }
    public class AccountabilityMessageModel
    {
        public int MessageId { get; set; }
        public string Title { get; set; }
        public string Body { get; set; }
        public bool IsEnabled { get; set; }
        public CustomDuration AlertRepeatDuration { get; set; }

        public AccountabilityMessage ToAccountabilityMessage()
        {
            return new AccountabilityMessage
            {
                MessageId = MessageId,
                Title = Title,
                Body = Body,
                IsEnabled = IsEnabled,
                //AlertRepeatDuration = new Duration(AlertRepeatDuration.Unit,AlertRepeatDuration.Value)
                AlertRepeatDuration = AlertRepeatDuration != null ? AlertRepeatDuration.ToDuration() : null
            };

        }

        public AccountabilityMessageModel FromAccountabilityMessage(AccountabilityMessage alertMesage)
        {
            return alertMesage != null ? new AccountabilityMessageModel
            {
                MessageId = alertMesage.MessageId,
                Title = alertMesage.Title,
                Body = alertMesage.Body,
                IsEnabled = alertMesage.IsEnabled,
                //AlertRepeatDuration = alertMesage.AlertRepeatDuration != null ? new CustomDuration { Unit = alertMesage.AlertRepeatDuration.Unit.ToString(), Value = alertMesage.AlertRepeatDuration.Value } : null
                AlertRepeatDuration = new CustomDuration().FromDuration(alertMesage.AlertRepeatDuration)
            } : null;
        }

    }
}