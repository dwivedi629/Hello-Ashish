﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Web.Helpers;
using System.Web.Script.Serialization;
using AtHoc.Diagnostics;
using AtHoc.Global.Resources;
using AtHoc.Infrastructure.Ioc;
using AtHoc.Infrastructure.Log;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Data.SearchSpec;
using AtHoc.IWS.Business.Domain.Accountability;
using AtHoc.IWS.Business.Domain.Accountability.Specs;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Entities.Accountability;
using AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel;
using AtHoc.IWS.Business.Domain.Events;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Web.Controllers;
using AtHoc.IWS.Web.Helpers;
using AtHoc.IWS.Web.Models.Accountability;
using AtHoc.IWS.Web.Models.Publishing;
using AtHoc.Publishing;
using AtHoc.Utilities;
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Domain.Targeting.Model;

namespace AtHoc.IWS.Web.Models.Accoutability
{
    public class EventModel
    {
        public EventModel()
        {

            AccountabilityOfficers = new List<UserNode>();
        }
        public int InitialAlertId { get; set; }
        public PublishingModel AlertBaseModel { get; set; }
        public ProcessSectionModel ProcessSectionModel { get; set; }
        public OfficerSectionModel OfficerSectionModel { get; set; }
        public IList<UserNode> AccountabilityOfficers { get; set; }
        public int Id { get; set; }
        public int TemplateId { get; set; }
        public string Name { get; set; }
        public string Status { get; set; }

        public string StartDate { get; set; }
        public DateTime StartDateUtc { get; set; }
        public double StartDateDstDelta { get; set; }
        public string EndDate { get; set; }
        public DateTime EndDateUtc { get; set; }
        public double EndDateDstDelta { get; set; }
        public string StartedOn { get; set; }
        public double StartedOnDstDelta { get; set; }
        public int? StartedBy { get; set; }
        public string StartedByName { get; set; }
        public string EndedOn { get; set; }
        public double EndedOnDstDelta { get; set; }
        public int? EndedBy { get; set; }
        public string EndedByName { get; set; }
        public decimal Affected { get; set; }
        public decimal UsersResponded { get; set; }
        public decimal UsersNotResponded { get; set; }
        public EventRuntimeModel RuntimeModel { get; set; }
        public bool IsAlertPublisher { get; set; }
        public bool IsEventPublisher { get; set; }
        public bool IsAllowedToUpdateStatus
        {
            get { return true; }//hardcode to true for now since both PA Manager and Officer can do ROBO
        }

        public bool IsCurrentVps { get; set; }
        public string ProviderName { get; set; }

        public static EventModel FromEvent(AccountabilityEvent ae, bool loadAlertSpec, bool loadRuntime, EventModelSpec modelSpec)
        {
            ProcessSectionModel processingSectionModel = ProcessSectionModel.FromEvent(ae);
            DateTime? endTime = ae.Status == AccountabilityEventStatus.Live ? ae.EndDate : ae.EndedOn;


            var model = new EventModel()
            {
                Id = ae.EventId,
                Status = ae.Status.ToString(),
                StartDate =
                    RuntimeContext.Provider.SystemToVpsTime(ae.StartDate)
                        .ToString(RuntimeContext.Provider.GetDateTimeFormat()),
                StartDateUtc =
                    ae.StartDate.ToUniversalTime(),
                StartDateDstDelta = DaylightSavingTimeDelta.CalculateDstDelta(RuntimeContext.Provider.GetVpsTimeZoneFromId(), RuntimeContext.Provider.SystemToVpsTime(ae.StartDate)),
                EndDate =
                    ae.EndDate.HasValue
                        ? RuntimeContext.Provider.SystemToVpsTime(ae.EndDate.Value)
                            .ToString(RuntimeContext.Provider.GetDateTimeFormat())
                        : "",
                EndDateUtc =
                    (endTime.HasValue
                        ? endTime.Value
                        : RuntimeContext.Provider.CurrentSystemTime()).ToUniversalTime(),
                EndDateDstDelta = ae.EndDate.HasValue ? DaylightSavingTimeDelta.CalculateDstDelta(RuntimeContext.Provider.GetVpsTimeZoneFromId(), RuntimeContext.Provider.SystemToVpsTime(ae.EndDate.Value)) : 0,
                StartedByName = ae.StartedByName,
                StartedBy = ae.StartedBy,
                StartedOn =
                    ae.StartedOn.HasValue
                        ? RuntimeContext.Provider.SystemToVpsTime(ae.StartedOn.Value)
                            .ToString(RuntimeContext.Provider.GetDateTimeFormat())
                        : "",
                StartedOnDstDelta = ae.StartedOn.HasValue ? DaylightSavingTimeDelta.CalculateDstDelta(RuntimeContext.Provider.GetVpsTimeZoneFromId(), RuntimeContext.Provider.SystemToVpsTime(ae.StartedOn.Value)) : 0,
                EndedBy = ae.EndedBy,
                EndedByName = ae.EndedByName,
                EndedOn =
                    ae.EndedOn.HasValue
                        ? RuntimeContext.Provider.SystemToVpsTime(ae.EndedOn.Value)
                            .ToString(RuntimeContext.Provider.GetDateTimeFormat())
                        : "",
                EndedOnDstDelta = ae.EndedOn.HasValue ? DaylightSavingTimeDelta.CalculateDstDelta(RuntimeContext.Provider.GetVpsTimeZoneFromId(), RuntimeContext.Provider.SystemToVpsTime(ae.EndedOn.Value)) : 0,
                Name = ae.Name,
                Affected = ae.CountOfUserAffected,
                UsersResponded = ae.CountOfUserWithResponse,
                UsersNotResponded = ae.CountOfUserWithNoResponse,
                ProcessSectionModel = processingSectionModel,
                InitialAlertId = ae.AssociatedAlerts!= null && ae.AssociatedAlerts.Any() ?ae.AssociatedAlerts.First().AlertId:0,                
                OfficerSectionModel = OfficerSectionModel.FromDomainModel(ae),
            };

            var providerId = modelSpec.ProviderId;
            var operatorId = modelSpec.OperatorId;

            IPublishingDomainToModel publishingDomainToModel = ServiceLocator.Resolve<IPublishingDomainToModel>();
            if (loadAlertSpec)
            {
                var provider = RuntimeContext.Provider;
                provider.Id = ae.ProviderId;//IWS-31574 ae.ProviderId will always be the correct provider Id.
                var alertModel = publishingDomainToModel.GetPublishingModel(ae, provider, operatorId, RuntimeContext.CustomAttributesWithouMassDevices, RuntimeContext.Provider.BaseLocale);
                //todo: review this. ugly.
                alertModel.ScenarioSection.ChannelId = ae.AlertSpec.Category.Id;
                model.AlertBaseModel = alertModel;
                model.AlertBaseModel.Context = PublishingContext.AccountEvent;
                if (ae.OperatorAlertBase != null)
                {
                    model.AccountabilityOfficers = publishingDomainToModel.GetAccountabilityOfficers(ae.OperatorAlertBase.AlertSpec.Targeting, providerId, operatorId);
                }
               
				//Make sure the Event Name and Description is coming from ACCT_EVENT_TAB
                model.AlertBaseModel.Content.Title = ae.Name;
                model.AlertBaseModel.Content.Body = ae.Description;

            }

            if (loadRuntime)
            {
                model.RuntimeModel = GetRuntimeModel(ae, modelSpec);
            }

            return model;
        }
        public static EventRuntimeModel GetRuntimeModel(AccountabilityEvent eventObj, EventModelSpec modelSpec)
        {
            var status = GetStatusModel(new List<int> { eventObj.EventId }, modelSpec);
            var overtime = GetStatusOverModel(eventObj, status, modelSpec);
            var activity = GetActivityModel(eventObj, modelSpec);
            return new EventRuntimeModel()
            {
                Status = status,
                Overtime = overtime,
                Activity = activity
            };
        }

        public static ActivityModel GetActivityModel(AccountabilityEvent eventObj, EventModelSpec modelSpec)
        {
            try
            {
                int sentAlertCountForUser = 0;
                //todo: move to server side
                var now = modelSpec.CurrentSystemDateTime;
                List<EventAlertModel> alertSent = new List<EventAlertModel>();
                // add the alerts that where sent
                var lastAlertTime = eventObj.CreatedOn;
                AccountabilityEventAlert closingAlert = null;
                foreach (AccountabilityEventAlert eventAlert in eventObj.AssociatedAlerts)
                {
                    DateTime publishedTime;
                    if (!eventAlert.PublishedOn.HasValue)
                    {
                        string errorMessage =
                            string.Format(
                                "Method PA->GetActivityModel()->For ProviderId={2}, EventId={0} and AlertId={1}, PublishedOn value cannot be null",
                                eventObj.EventId,eventAlert.AlertId,modelSpec.ProviderId);
                        EventLogger.WriteWarning(errorMessage);
                        publishedTime = eventAlert.StartDate;
                    }
                    else
                    {
                        publishedTime = eventAlert.PublishedOn.Value;
                    }

                    lastAlertTime = publishedTime;
                    var eventAlertModel = new EventAlertModel
                    {
                        AlertId = eventAlert.AlertId,
                        Status = eventAlert.AlertStatus.ToEnum<AlertStatus>(),
                        Name = eventAlert.AlertTitle,
                        TargetedUsers = eventAlert.TotalUser.GetValueOrDefault(),
                        CreatedOnUtc = publishedTime.ToUniversalTime(),
                        CreatedOn = RuntimeContext.Provider.SystemToVpsTime(publishedTime).ToString(RuntimeContext.Provider.GetDateTimeFormat()),
                        CreatedOnDstDelta = DaylightSavingTimeDelta.CalculateDstDelta(RuntimeContext.Provider.GetVpsTimeZoneFromId(), RuntimeContext.Provider.SystemToVpsTime(publishedTime)),
                        ErrorCount = eventAlert.ErrorCount,
                        AlertEventType = eventAlert.AlertInitType,
                    };
                    var alertTpyeDisplay = "";
                    if (eventAlert.AlertInitType == AccountabilityEventAlertType.Start.GetDescription())
                    {
                        if (eventAlert.AlertType == AccountabilityEventUserType.User.GetDescription())
                        {
                            sentAlertCountForUser++;
                            alertTpyeDisplay = IWSResources.PA_Event_Details_Activity_StartAlert_Label + " - " + IWSResources.PA_Event_Details_Activity_User_Alert;
                        }
                        else if (eventAlert.AlertType == AccountabilityEventUserType.Operator.GetDescription())
                        {
                            alertTpyeDisplay = IWSResources.PA_Event_Details_Activity_StartAlert_Label + " - " + IWSResources.PA_Event_Details_Activity_Operator_Alert;
                        }
                    }
                    else if (eventAlert.AlertInitType == AccountabilityEventAlertType.Reminder.GetDescription())
                    {
                        sentAlertCountForUser++;
                        alertTpyeDisplay = IWSResources.PA_Event_Details_Activity_ReminderAlert_Label;
                    }
                    else if (eventAlert.AlertInitType == AccountabilityEventAlertType.Close.GetDescription())
                    {
                        
                        if (eventAlert.AlertType == AccountabilityEventUserType.User.GetDescription())
                        {
                            sentAlertCountForUser++;
                            alertTpyeDisplay = IWSResources.PA_Event_Details_Activity_EndingAlert_Label + " - " + IWSResources.PA_Event_Details_Activity_User_Alert;
                        }
                        else if (eventAlert.AlertType == AccountabilityEventUserType.Operator.GetDescription())
                        {
                            alertTpyeDisplay = IWSResources.PA_Event_Details_Activity_EndingAlert_Label + " - " + IWSResources.PA_Event_Details_Activity_Operator_Alert;
                        }
                    }
                    eventAlertModel.AlertType = alertTpyeDisplay;
                    eventAlertModel.IsAlertPublisher = modelSpec.HasAlertPublisherRole;
                    alertSent.Add(eventAlertModel);

                    if (eventAlert.AlertInitType.Equals(AccountabilityEventAlertType.Close.ToString(), StringComparison.InvariantCultureIgnoreCase))
                    {
                        closingAlert = eventAlert;
                    }
                }

                List<EventAlertModel> pendingAlerts = new List<EventAlertModel>();
                // when is the next alert
                // add alerts that where suppose to be sent until now. all errors
                var numberOfMin = eventObj.ReminderAlertUserMessage.AlertRepeatDuration.GetSeconds() / 60;
                var endTime = eventObj.Status == AccountabilityEventStatus.Live ? eventObj.EndDate : eventObj.EndedOn;
                if (eventObj.ReminderAlertUserMessage.IsEnabled && eventObj.Status == AccountabilityEventStatus.Live)
                {
                    //
                    if (lastAlertTime + TimeSpan.FromMinutes(numberOfMin) < endTime)
                    {
                        lastAlertTime += TimeSpan.FromMinutes(numberOfMin);
                        // show the next reminder alert                    
                        pendingAlerts.Add(new EventAlertModel()
                        {
                            AlertId = 0,
                            Status = AlertStatus.Standby,
                            Name = eventObj.ReminderAlertUserMessage.Title,
                            ErrorCount = 0,
                            IsNextAlert = true,
                            AlertEventType = AccountabilityEventAlertType.Reminder.GetDescription(),
                            AlertType = IWSResources.PA_Event_Details_Activity_ReminderAlert_Label
                        });

                        // if all alerts are stuck in queue, we are getting lastAlertTime as 1/1/2000. we should not display it
                        if (lastAlertTime >= eventObj.StartDate)
                        {
                            pendingAlerts.Last().CreatedOn = RuntimeContext.Provider.SystemToVpsTime(lastAlertTime).ToString(RuntimeContext.Provider.GetDateTimeFormat());
                        }
                    }
                }

                if (closingAlert == null && eventObj.Status == AccountabilityEventStatus.Live)
                {
                    if (endTime < now)
                    {
                        // there is an error here... 
                        // todo: show to user
                    }
                    else
                    {
                        // show the next reminder alert
                        lastAlertTime += TimeSpan.FromMinutes(numberOfMin);
                        if (eventObj.CloseAlertUserMessage.IsEnabled)
                        {
                            pendingAlerts.Add(new EventAlertModel()
                            {
                                AlertId = 0,
                                Status = AlertStatus.Standby,
                                Name = eventObj.CloseAlertUserMessage.Title,
                                CreatedOn =
                                    RuntimeContext.Provider.SystemToVpsTime(endTime.Value)
                                        .ToString(RuntimeContext.Provider.GetDateTimeFormat()),
                                CreatedOnDstDelta = DaylightSavingTimeDelta.CalculateDstDelta(RuntimeContext.Provider.GetVpsTimeZoneFromId(), RuntimeContext.Provider.SystemToVpsTime(endTime.Value)),
                                ErrorCount = 0,
                                IsNextAlert = true,
                                AlertEventType = AccountabilityEventAlertType.Close.GetDescription(),
                                AlertType =
                                    IWSResources.PA_Event_Details_Activity_EndingAlert_Label + " - " +
                                    IWSResources.PA_Event_Details_Activity_User_Alert

                            });
                        }
                        if (eventObj.OperatorAlertBaseId != null && eventObj.OperatorAlertBaseId > 0 && eventObj.CloseAlertOperatorMessage.IsEnabled)
                        {
                            pendingAlerts.Add(new EventAlertModel()
                            {
                                AlertId = 0,
                                Status = AlertStatus.Standby,
                                Name = eventObj.CloseAlertOperatorMessage.Title,
                                CreatedOn =
                                    RuntimeContext.Provider.SystemToVpsTime(endTime.Value)
                                        .ToString(RuntimeContext.Provider.GetDateTimeFormat()),
                                CreatedOnDstDelta = DaylightSavingTimeDelta.CalculateDstDelta(RuntimeContext.Provider.GetVpsTimeZoneFromId(), RuntimeContext.Provider.SystemToVpsTime(endTime.Value)),
                                ErrorCount = 0,
                                IsNextAlert = true,
                                AlertEventType = AccountabilityEventAlertType.Close.GetDescription(),
                                AlertType =
                                    IWSResources.PA_Event_Details_Activity_EndingAlert_Label + " - " +
                                    IWSResources.PA_Event_Details_Activity_Operator_Alert
                            });
                        }
                    }
                }

                var model = new ActivityModel
                {
                    SentAlerts = alertSent,
                    PendingAlerts = pendingAlerts,
                    SentAlertCountForUser = sentAlertCountForUser
                };

                return model;
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                var errorMessage = string.Format("Error in GetActivityModel() -> Parameters(EventId={0},OperatorId={1})", eventObj.EventId, modelSpec.OperatorId);
                LogService.Current.Error(() => errorMessage);
                return null;
            }
        }
        public static StatusModel GetStatusModel(List<int> eventIds, EventModelSpec modelSpec, int sessionId = 0)
        {
            try
            {
                IAccountabilityFacade acctFacade = ServiceLocator.Current.Resolve<IAccountabilityFacade>();
                var providerId = modelSpec.ProviderId;
                var operatorId = modelSpec.OperatorId;

                var spec = new EventStatusSpec()
                {
                    EventIds = eventIds,
                    BaseLocale = modelSpec.ProviderBaseLocale,
                    OperatorId = operatorId,
                    ProviderId = providerId,
                    SessionId = sessionId,
                };

                var statusReport = acctFacade.GetEventStatus(spec);
                var totalUsers = statusReport.TotalUsers;
                var usersWithStatus = new Measure()
                {
                    Value = statusReport.TotalResponses.Responses,
                    Percent = totalUsers == 0 ? 0 : (int)Math.Round(((float)statusReport.TotalResponses.Responses) / totalUsers * 100)
                };
                var usersWithoutStatus = new Measure()
                {
                    Value = totalUsers - usersWithStatus.Value,
                    Percent = totalUsers == 0 ? 0 : 100 - usersWithStatus.Percent
                };

                var responsesByUser = new Measure()
                {
                    Value = statusReport.TotalResponses.ResponsesByUser,
                    Percent = totalUsers == 0 ? 0 : (int)Math.Round(((float)statusReport.TotalResponses.ResponsesByUser) / totalUsers * 100)
                };
                var responsesByOperator = new Measure()
                {
                    Value = statusReport.TotalResponses.ResponsesByOperator,
                    Percent = totalUsers == 0 ? 0 : usersWithStatus.Percent - responsesByUser.Percent
                };


                var status = new StatusModel()
                {
                    //users with restricated user base.
                    TotalAffectedUsers = statusReport.TotalAffectedUsers,
                    IsRestrictedUser = statusReport.IsRestricted,
                    TotalUsers = totalUsers,
                    UsersWithStatus = usersWithStatus,
                    UsersWithoutStatus = usersWithoutStatus,
                    ResponsesByUser = responsesByUser,
                    ResponsesByOperator = responsesByOperator
                };

                List<decimal> percentage = GetPerfectRounding(statusReport.StatusByResponse.Select(
                    x => totalUsers == 0 ? 0 : ((decimal)x.Responses) / totalUsers * 100)
                    .ToList(), usersWithStatus.Percent/*, 0*/);
                var index = 0;
                foreach (var response in statusReport.StatusByResponse)
                {
                    var resCount = response.Responses;
                    var resPercent = (int)percentage[index];//status.UsersWithStatus.Value == 0 ? 0 : (int)(((float)resCount) / totalUsers * 100);
                    var responseModel = new ResponseOptionStatusModel()
                    {
                        Id = response.ResponseId,
                        Name = response.StatusAttribute.ValueName,
                        SortOrder = response.StatusAttribute.SortOrder,
                        Value = new Measure()
                        {
                            Value = resCount,
                            Percent = resPercent
                        },
                        Color = TrackingColors.Responses[(response.ResponseId - 1) % 10]
                    };
                    status.StatusByResponse.Add(responseModel);
                    index++;
                }

                return status;
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                var errorMessage = string.Format("Error in GetStatusModel() -> Parameters(EventId={0},OperatorId={1})", eventIds[0], modelSpec.OperatorId);
                LogService.Current.Error(() => errorMessage);

                return null;
            }
        }
        public static StatusOverTimeModel GetStatusOverModel(AccountabilityEvent eventObj, StatusModel statusModel, EventModelSpec modelSpec)
        {
            try
            {

                int providerId = modelSpec.ProviderId;
                int operatorId = modelSpec.OperatorId;
                string baseLocale = modelSpec.ProviderBaseLocale;

                IAccountabilityFacade acctFacade = ServiceLocator.Current.Resolve<IAccountabilityFacade>();
                var now = modelSpec.CurrentSystemDateTime;
                var endTime = eventObj.Status == AccountabilityEventStatus.Live ? eventObj.EndDate.GetValueOrDefault() : eventObj.EndedOn.GetValueOrDefault();
                endTime = endTime < now ? endTime : now;
                TimeSpan span = endTime - eventObj.StartDate;

                int numberOfSeconds = (int)span.TotalSeconds;
                // we want 10 samples;
                TimeSpan sliceByDuration = TimeSpan.FromSeconds(Math.Max(1, numberOfSeconds / 20));

                var res = acctFacade.GetEventResponsesOvertime(eventObj.EventId, providerId, operatorId, baseLocale, sliceByDuration, eventObj.StartDate, endTime);

                var statusOverTime = new StatusOverTimeModel();
                var total = 0;
                foreach (var responseModel in res.EventSummaryUserWithResponseCountModel)
                {
                    total += responseModel.UserCount;
                    var dateTimeUtc = responseModel.GroupStartTime;
                    statusOverTime.StatusOverTime.Add(new StatusOvertimeItem()
                    {
                        DateTimeUtc = dateTimeUtc,
                        Value = total,
                        DstDelta = DaylightSavingTimeDelta.CalculateDstDelta(RuntimeContext.Provider.GetVpsTimeZoneFromId(), RuntimeContext.Provider.SystemToVpsTime(responseModel.GroupStartTime)),
                    });
                }

                // add the last node                               
                var dateTimeLastUtc = endTime.ToUniversalTime();

                statusOverTime.StatusOverTime.Add(new StatusOvertimeItem()
                {
                    DateTimeUtc = dateTimeLastUtc,
                    Value = statusModel.UsersWithStatus.Value,
                    DstDelta = DaylightSavingTimeDelta.CalculateDstDelta(RuntimeContext.Provider.GetVpsTimeZoneFromId(), RuntimeContext.Provider.SystemToVpsTime(endTime)),
                });

                return statusOverTime;
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                var errorMessage = string.Format("Error in GetStatusOverModel() -> Parameters(EventId={0},OperatorId={1})", eventObj.EventId, modelSpec.OperatorId);
                LogService.Current.Error(() => errorMessage);
                return null;
            }
        }
        public static List<decimal> GetPerfectRounding(List<decimal> original, decimal forceSum)
        {
            // floor all.
            var rounded = original.Select(x => Math.Floor(x)).ToList();
            var delta = forceSum - rounded.Sum();
            if (delta == 0) return rounded;

            int index = 0;
            List<Tuple<decimal, int>> originalToIndex = new List<Tuple<decimal, int>>();
            foreach (var round in rounded)
            {
                originalToIndex.Add(new Tuple<decimal, int>(round, index));
                index++;
            }

            var orderedOriginal = originalToIndex.OrderByDescending(a => a.Item1).ToList();

            for (int i = 0; i < delta; i++)
            {
                rounded[orderedOriginal[i].Item2] += 1;
            }

            return rounded;
        }
    }
    

    public class ActivityModel
    {
        public ActivityModel()
        {
            SentAlerts = new List<EventAlertModel>();
            PendingAlerts = new List<EventAlertModel>();
            
        }

        public List<EventAlertModel> SentAlerts { get; set; }
        public List<EventAlertModel> PendingAlerts { get; set; }
        public int SentAlertCountForUser { get; set; }
    }

    public class EventAlertModel
    {
        public int Id { get; set; }
        public int AlertId { get; set; }
        public string Name { get; set; }
        public AlertStatus Status { get; set; }
        public DateTime CreatedOnUtc { get; set; }
        public string CreatedOn { get; set; }
        public double CreatedOnDstDelta { get; set; }
        public int TargetedUsers { get; set; }
        public int ErrorCount { get; set; }
        public bool IsNextAlert { get; set; }
        /// <summary>
        /// Start,Reminder,Close
        /// </summary>
        public string AlertEventType { get; set; }

        public bool IsAlertPublisher { get; set; }

        public string AlertType { get; set; }

    }

    /*public class EventAlertOvertimeItem
    {
        public int Value { get; set; }
        public DateTime Time { get; set; }

    }*/

    public class StatusOvertimeItem
    {
        public int Value { get; set; }
        public DateTime DateTimeUtc { get; set; }
        public double DstDelta { get; set; }
    }

    public class StatusOverTimeModel
    {
        public StatusOverTimeModel()
        {
            StatusOverTime = new List<StatusOvertimeItem>();
        }
        public List<StatusOvertimeItem> StatusOverTime { get; set; }

    }
    public class StatusModel
    {
        public StatusModel()
        {
            StatusByResponse = new List<ResponseOptionStatusModel>();
        }

        public int TotalUsers { get; set; }
        public Measure UsersWithStatus { get; set; }
        public Measure UsersWithoutStatus { get; set; }
        public bool IsRestrictedUser { get; set; }
        public int TotalAffectedUsers { get; set; }//Total Users and total affected users count differ when restricted user .
        public Measure ResponsesByUser { get; set; }
        public Measure ResponsesByOperator { get; set; }

        public List<ResponseOptionStatusModel> StatusByResponse { get; set; }
    }

    public class ResponseOptionStatusModel
    {
        public ResponseOptionStatusModel()
        {
            Value = new Measure();
        }

        public string Color { get; set; }
        public int Id { get; set; }
        public int SortOrder { get; set; }
        public string Name { get; set; }
        public Measure Value { get; set; }
    }

    public class Measure
    {
        public int Value { get; set; }
        public int Percent { get; set; }
    }


    public class EventOrganizationReportBuilder
    {
        public int SessionId { get; set; }
        public List<EventOrganizationHierarchyEntry> Hierarchy { get; set; }
        public List<EventOrganizationReportEntry> Entries { get; set; }
    }

    public class EventOrganizationHierarchyEntry
    {
        public string Id { get; set; }
        public string Name { get; set; }

        public static EventOrganizationHierarchyEntry FromEventOrganizationHierarchy(EventOrganizationHierarchy entry)
        {
            return new EventOrganizationHierarchyEntry
            {
                Id = entry.Id,
                Name = entry.Name
            };
        }
    }

    // reports
    public class EventOrganizationReportEntry
    {
        public int Id { get; set; }
        public int ParentId { get; set; }
        public bool HasChildren { get; set; }
        public string Name { get; set; }
        public Dictionary<string, int> ResponseValues { get; set; }
        public int Depth { get; set; }
        public int TotalCount { get; set; }

        public static EventOrganizationReportEntry FromEventOrganizationReport(EventOrganizationReport entry)
        {
            return new EventOrganizationReportEntry
            {
                Id = entry.Id,
                ParentId = entry.ParentId,
                HasChildren = entry.HasChildren,
                Name = entry.Name,
                ResponseValues = entry.ResponseValues,
                Depth = entry.Depth,
                TotalCount = entry.TotalCount
            };
        }
    }


    public static class TrackingColors
    {
        public static String Targeted = "#FF6699";
        public static String Sent = "#066FFCC";

        public static String Ack = "#9CB57B";

        public static String NoResponse = "#BBBBBB";
        public static String Response = "#0000FF";

        // tod: we should move it to CSS (used by the charts and needed rgb)
        public static String[] Responses =
        {
            "#9c00ff", "#ff6c00", "#ff00c0", "#fff000", "#9b3e00", "#00c6ff",  "#dfa6ff",  "#8ab286",  "#3d7d89", "#98c4ff"
        };
    }

    public static class DaylightSavingTimeDelta
    {
        public static double CalculateDstDelta(TimeZoneInfo vpstimeZone, DateTime vpsDateTime)
        {
            const int dstDelta = 0;

            if (vpstimeZone.SupportsDaylightSavingTime && vpstimeZone.IsDaylightSavingTime(vpsDateTime))
            {
                var adjustmentRules = vpstimeZone.GetAdjustmentRules();

                if (adjustmentRules.Any())
                {
                    return adjustmentRules.First(date => vpsDateTime >= date.DateStart && vpsDateTime <= date.DateEnd)
                        .DaylightDelta.TotalMinutes;
                }
            }

            return dstDelta;
        }
    }
}