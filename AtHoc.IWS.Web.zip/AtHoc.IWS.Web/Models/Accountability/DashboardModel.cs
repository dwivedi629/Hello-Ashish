﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AtHoc.IWS.Business.Domain.Targeting.Model;
using AtHoc.IWS.Web.Models.Accoutability;
using AtHoc.IWS.Web.Models.Publishing;

namespace AtHoc.IWS.Web.Models.Accountability
{    
    public class DashboardModel
    {
        public DashboardModel()
        {
          DashboardItems= new List<DashboardItemModel>();  
        } 
        public List<int> Ids { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        
        public string Type { get; set; }

        public string Status { get; set; }
        
        public IList<ResponseOption> ResponseOptions { get; set; }        
        //public bool IsAlertPublisher { get; set; }
        //public bool IsEventPublisher { get; set; }
        public bool IsAllowedToUpdateStatus { get; set; }        
        //TODO rename to dashboard
        public RuntimeModel RuntimeModel { get; set; }
        public List<DashboardItemModel> DashboardItems { get; set; }

        public int SessionId { get; set; }
    }

    public class RuntimeModel
    {
        public RuntimeModel()
        {
            CurrentTimeUtc = DateTime.UtcNow;
        }

        public DateTime CurrentTimeUtc { get; set; }
        public StatusModel Status { get; set; }
        public StatusOverTimeModel Overtime { get; set; }
    }

    public class EventRuntimeModel : RuntimeModel
    {
        public ActivityModel Activity { get; set; }
        public EventModel EventModel { get; set; }
    }
   
    public class ReportRuntimeModel : RuntimeModel
    {

    }

    public class DashboardItemModel
    {
        public int Id { get; set; }        
        public string Name { get; set; }
        //public string Description { get; set; }
        public string Status { get; set; }
        public int StatusAttributeId { get; set; }
        public string StatusAttributeName { get; set; }        
        public string StartDate { get; set; }
        public DateTime StartDateUtc { get; set; }
        public string EndDate { get; set; }
        public DateTime EndDateUtc { get; set; }
        public string StartedOn { get; set; }
        public int? StartedBy { get; set; }
        public string StartedByName { get; set; }
        public string EndedOn { get; set; }
        public int? EndedBy { get; set; }
        public string EndedByName { get; set; }

        
    }
}