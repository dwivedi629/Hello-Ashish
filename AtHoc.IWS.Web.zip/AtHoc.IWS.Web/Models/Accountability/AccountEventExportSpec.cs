﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AtHoc.IWS.Web.Models.Accountability
{
    /// <summary>
    /// Account Event Export Specifications.
    /// </summary>
    public class AccountEventExportSpec
    {
        public int EventId { get; set; }
        public string DownloadFormat { get; set; }
        public int UserResponseType { get; set; }
        public string CurrentUserFilter { get; set; }
        public bool IncludeSummary { get; set; }
        public bool IncludeHierarchy { get; set; }
        public bool IncludeUsers { get; set; }
        public string ExportDescription { get; set; }
        public string UserAttriubuteCsv { get; set; }
        public string UsrrQueryCriteria { get; set; }
        public string SortUsersBy { get; set; }
        public string UserSortingOrder { get; set; }
        public string OrgHrchyFilter { get; set; }
        public string OrgHrchyHeaderTitle { get; set; }
        public Dictionary<string, int> OrgHrchyOptions { get; set; }
        public string[] UserSearchOptions { get; set; }
        public int[] UserattributeIds { get; set; }
        public int[] UserhierarchyIds { get; set; }
        public int[] UserlistItemIds { get; set; }
        public int ProviderId { get; set; }
    }
}