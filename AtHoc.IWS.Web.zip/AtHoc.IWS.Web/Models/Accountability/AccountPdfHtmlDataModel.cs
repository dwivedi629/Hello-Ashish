﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AtHoc.IWS.Web.Configurations;
using AtHoc.IWS.Web.Models.Shared;

namespace AtHoc.IWS.Web.Models.Accountability
{
    public class AccountPdfHtmlDataModel : ExportDataModel
    {
        public List<PdfHtmlDataModel> AccountSectionsDataModels { get; set; }
        public PdfGridConfiguration PdfSpeConfiguration { get; set; }
    }
}
