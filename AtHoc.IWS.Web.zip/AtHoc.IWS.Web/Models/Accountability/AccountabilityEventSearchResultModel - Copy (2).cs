﻿using System;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel;
using EO.Internal;

namespace AtHoc.IWS.Web.Models.Accountability
{
    public class AccountabilityEventSearchResultModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int StatusAttributeId { get; set; }
        public string StatusAttributeName { get; set; }
        public int CreatedBy { get; set; }
        public string CreatedByName { get; set; }
        public string Status { get; set; }
        public int UpdatedBy { get; set; }
        public string UpdatedByName { get; set; }
        public string CreatedOn { get; set; }
        public string UpdatedOn { get; set; }
        public int Priority { get; set; }
        public int ProviderId { get; set; }
        public string ProviderName { get; set; }
        public int StartedBy { get; set; }
        public string StartedByName { get; set; }
        public string StartedOn { get; set; }
        public int? Affected { get; set; }
        public int? UsersResponded { get; set; }
        public int? UsersNotResponded { get; set; }
        public bool IsAlertPublisher { get; set; }
        public bool IsEventPublisher { get; set; }
        public bool IsAllowedToUpdateStatus { get; set; }
        public bool IsInCurrentVPS { get; set; }

        public static AccountabilityEventSearchResultModel FromSearchResult(AccountabilityEventSearchResult accountabilitySearchResult)
        {
            var model = new AccountabilityEventSearchResultModel()
            {
                Id = accountabilitySearchResult.EventId,
                Name = accountabilitySearchResult.EventName,
                StatusAttributeId = accountabilitySearchResult.StatusAttributeId,
                StatusAttributeName = accountabilitySearchResult.StatusAttributeName,
                CreatedBy = accountabilitySearchResult.CreatedById,
                CreatedByName = accountabilitySearchResult.CreatedBy,
                Status = accountabilitySearchResult.Status,
                UpdatedBy = accountabilitySearchResult.UpdatedById,
                UpdatedByName = accountabilitySearchResult.UpdatedBy,
                CreatedOn = RuntimeContext.Provider.SystemToVpsTime(accountabilitySearchResult.CreatedOn)
                        .ToString(RuntimeContext.Provider.GetDateTimeFormat()),
                UpdatedOn = RuntimeContext.Provider.SystemToVpsTime(accountabilitySearchResult.UpdatedOn)
                        .ToString(RuntimeContext.Provider.GetDateTimeFormat()),
                Priority = accountabilitySearchResult.Priority,
                ProviderId = accountabilitySearchResult.ProviderId,
                ProviderName = accountabilitySearchResult.ProviderName,
                StartedBy = accountabilitySearchResult.StartedBy,
                StartedByName = accountabilitySearchResult.PublishedBy,
                StartedOn = RuntimeContext.Provider.SystemToVpsTime(accountabilitySearchResult.StartedOn)
                        .ToString(RuntimeContext.Provider.GetDateTimeFormat()),
                Affected = accountabilitySearchResult.Affected ?? 0,
                UsersResponded = accountabilitySearchResult.UsersResponded ?? 0,
                UsersNotResponded = accountabilitySearchResult.UsersNotResponded ?? 0,
                IsInCurrentVPS = accountabilitySearchResult.ProviderId == RuntimeContext.ProviderId,
            };

            return model;
        }
    }
}