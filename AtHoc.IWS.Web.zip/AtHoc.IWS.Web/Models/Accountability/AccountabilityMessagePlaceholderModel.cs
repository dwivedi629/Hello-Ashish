﻿using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Web.Models.Publishing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AtHoc.IWS.Web.Models.Accountability
{
    public class AccountabilityMessagePlaceholderModel
    {
        public AccountabilityMessagePlaceholderModel()
        {
            PlaceholderReplacementModels = new List<PlaceholderReplacementModel>();
            SelectedPlaceHolders = new List<AtHoc.IWS.Web.Models.Publishing.PlaceHolder>();
            SystemPlaceholders = new SystemPlaceholders();
        }

        public SystemPlaceholders SystemPlaceholders { get; set; }
        public List<PlaceholderReplacementModel> PlaceholderReplacementModels { get; set; }

        public List<AtHoc.IWS.Web.Models.Publishing.PlaceHolder> SelectedPlaceHolders { get; set; }
    }
}