﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using AtHoc.IWS.Business.Domain.Users.Search.UserExport;
using AtHoc.IWS.Web.Configurations;
using AtHoc.IWS.Web.Models.Shared;
using EO.Pdf;

namespace AtHoc.IWS.Web.Models.Export
{
    /// <summary>
    /// Export Model.
    /// </summary>
    public class ExportModel
    {
        public string Title { get; set; }
        public string GridHeaderLocalizationKey { get; set; }
        public string SubHeadline { get; set; }
        public List<Dictionary<string, object>> GridRows { get; set; }
        public List<ExportGridColumnConfig> GridHeaders { get; set; }

        public DataTable GridDataTable { get; set; }
    }
}