﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AtHoc.IWS.Web.Models.Export
{
    /// <summary>
    /// ExportGrid Column Config Class.
    /// </summary>
    public class ExportGridColumnConfig
    {
       public ExportGridColumnConfig(string columnName )
        {
            ColumnName = columnName;
            IsLocalizationRequired = false;
        }
        public string ColumnName { get; set; }
        public bool IsLocalizationRequired { get; set; }
        public string ValueLocalizationKey { get; set; }
        public string FormatValue { get; set; }
        public string ValueStyle { get; set; }
        public string HeaderStyle { get; set; }
      
    }
}