﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Helpers;
using AtHoc.Global.Resources;
using AtHoc.Infrastructure.Log;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Data.SearchSpec;
using AtHoc.IWS.Business.Domain.Entities.Rule.Enum;

using AtHoc.IWS.Business.Domain.RuleModel;
using AtHoc.IWS.Business.Domain.RuleModel.Spec;
using AtHoc.IWS.Web.Models.SearchCriteria;

namespace AtHoc.IWS.Web.Models.Rule
{
    public class RulesModel
    {
        public RulesModel()
        {
            Rules = new List<Rule>();
        }
        public List<Rule> Rules { get; set; }
        public List<ScenarioInfo> AlertScenarios { get; set; }
        public List<ScenarioInfo> WamAlertScenarios { get; set; }
        public int GridTotalCount { get; set; }

        public static RulesModel GetModel(IRuleFacade ruleFacade, AtHoc.IWS.Business.Domain.Publishing.IScenarioFacade scenarioFacade, string ruleType)
        {
            try
            {
                var provider = RuntimeContext.Provider;
                var operatorId = RuntimeContext.OperatorId;
                var scenarioSpec = new ScenarioSearchSpec { QuickOnly = false, ExcludeSystemScenarios = false };
                var scenarios = scenarioFacade.GetScenarios(provider.Id, operatorId, scenarioSpec);
                var allScenarioInfos = new Dictionary<int, ScenarioInfo>();
                var allScenarioInfosByCommonNames = new Dictionary<string, ScenarioInfo>();
                var scenarioInfos = new Dictionary<int, ScenarioInfo>();
                // first add all ready scenarios
                foreach (var scenario in scenarios)
                {
                    var scenarioInfo = new ScenarioInfo
                    {
                        Id = scenario.ScenarioId,
                        CommonName = scenario.CommonName,
                        IsReady = scenario.IsReadyForPublish,
                        Name = scenario.Name,
                        Enabled = scenario.Enabled
                    };
                    allScenarioInfos.Add(scenario.ScenarioId, scenarioInfo);
                    if (!string.IsNullOrEmpty(scenarioInfo.CommonName))
                    {
                        ScenarioInfo tempScenario;
                        if (!allScenarioInfosByCommonNames.TryGetValue(scenario.CommonName, out tempScenario))
                        {
                            allScenarioInfosByCommonNames.Add(scenario.CommonName, scenarioInfo);
                        }
                        else
                        {
                            LogService.Current.Warn(() => string.Format("Duplicate Scenario with similar common Name ={0} for provider id= {1}", scenario.CommonName, provider.Id));
                        }

                    }
                    if (scenario.IsReadyForPublish)
                    {
                        scenarioInfos.Add(scenarioInfo.Id, scenarioInfo);
                    }
                }

                // add not ready scenarios from rules settings
                var model = new RulesModel();
                IEnumerable<Business.Domain.RuleModel.Rule> rules = ruleFacade.Get(new RuleSpec() { ProviderId = provider.Id }, ruleType);

                foreach (Business.Domain.RuleModel.Rule r in rules)
                {
                    Rule rule = new Rule(r);
                    // resolve scenario common name to Id;
                    if (rule.Scenario == 0 && !string.IsNullOrEmpty(rule.ScenarioCommonName))
                    {
                        ScenarioInfo scenario = null;
                        if (allScenarioInfosByCommonNames.TryGetValue(rule.ScenarioCommonName, out scenario))
                        {
                            rule.Scenario = scenario.Id;
                        }
                    }

                    // find scenario by common name or id
                    if (rule.Scenario > 0)
                    {
                        ScenarioInfo selectedScenario = null;
                        if (allScenarioInfos.TryGetValue(rule.Scenario, out selectedScenario))
                        {
                            if (!selectedScenario.IsReady && !scenarioInfos.ContainsKey(selectedScenario.Id))
                            {
                                scenarioInfos.Add(selectedScenario.Id, selectedScenario);
                            }
                        }
                        else
                        {
                            // scenario does not exist anymore, clear it.
                            rule.Scenario = 0;
                            rule.DelegateResponses = false;
                        }
                        if (ruleType == RuleTypes.INCOMING_FEED_RULE.ToString())
                        {
                            if (selectedScenario != null)
                            {
                                rule.isReady = selectedScenario.IsReady;
                                rule.ScenarioName = rule.isReady ? selectedScenario.Name : IWSResources.WAMRule_Template_Not_Ready + selectedScenario.Name;
                            }

                        }
                    }

                    model.Rules.Add(rule);
                }

                model.GridTotalCount = model.Rules.Count;
                model.AlertScenarios = scenarioInfos.Values.OrderBy(o => o.Name).ToList();
                model.WamAlertScenarios = scenarioInfos.Values.Where(x => x.IsReady == true).OrderBy(o => o.Name).ToList();

                return model;
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return null;
            }
        }
    }

    public class Rule
    {
        public Rule() { }

        public Rule(Business.Domain.RuleModel.Rule rule)
        {
            Id = rule.Id;
            Name = rule.Name;
            StopProcessing = rule.StopProcessing;
            CriteriaEntityId = rule.CriteriaEntityId;
            Order = rule.Order;
            isEnable = rule.isEnable;
            WeatherCounty = rule.WeatherCounty;
            WeatherSeverityType = rule.WeatherSeverityType;
            WeatherEventType = rule.WeatherEventType;
            weatherKeywords = rule.weatherKeywords;
            foreach (RuleAction action in rule.Actions)
            {
                object delegateResponse;
                if (action.ActionValues.TryGetValue(RuleAction.RuleActionParameterKeys.DELEGATE_RESPONSES, out delegateResponse))
                {
                    DelegateResponses = Convert.ToBoolean(delegateResponse);
                }
                object value;
                if (action.ActionValues.TryGetValue(RuleAction.RuleActionParameterKeys.SCENARIO_ID, out value))
                {
                    Scenario = Convert.ToInt32(value);
                }
                else if (action.ActionValues.TryGetValue(RuleAction.RuleActionParameterKeys.SCENARIO_COMMON_NAME, out value))
                {
                    ScenarioCommonName = Convert.ToString(value);
                }
                if (action.ActionValues.TryGetValue(RuleAction.RuleActionParameterKeys.GEOENABLED, out value))
                {
                    GeoEnabled = Convert.ToString(value);
                }
            }
            CriteriaEntityId = rule.CriteriaEntityId;
        }

        public Business.Domain.RuleModel.Rule ToBusinessRule()
        {
            Business.Domain.RuleModel.Rule r = new Business.Domain.RuleModel.Rule()
            {
                Id = this.Id,
                Name = this.Name,
                //Scenario = 
                StopProcessing = this.StopProcessing,
                Order = this.Order,
                isEnable = this.isEnable,
                isWeatherModule = this.isWeatherModule,
                GeoEnabled = this.GeoEnabled,
            };

            //Actions
            r.Actions = new List<RuleAction>();
            if (this.Scenario > 0)
            {
                var rlAction = new Business.Domain.RuleModel.RuleAction();
                var actionValues = new Dictionary<string, object>();
                rlAction.ActionName = ActionType.ExecuteScenario;
                rlAction.ActionContext = Scenario.ToString();
                actionValues.Add(RuleAction.RuleActionParameterKeys.SCENARIO_ID, Scenario.ToString());
                if (this.DelegateResponses)
                {
                    actionValues.Add(RuleAction.RuleActionParameterKeys.DELEGATE_RESPONSES, this.DelegateResponses);
                }
                if (r.isWeatherModule)
                    actionValues.Add(RuleAction.RuleActionParameterKeys.GEOENABLED, r.GeoEnabled);

                rlAction.ActionValues = actionValues;

                r.Actions.Add(rlAction);
            }

            return r;
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public int Order { get; set; }
        public bool StopProcessing { get; set; }
        public bool DelegateResponses { get; set; }
        public int Scenario { get; set; }
        public string ScenarioCommonName { get; set; }
        //public SearchCriteriaModel Conditions { get; set; }        
        public int CriteriaEntityId { get; set; }

        // this is only set form the UI, not form the database
        public SearchCriteriaModel SearchCriteriaInput { get; set; }
        public string isEnable { get; set; }
        public bool isWeatherModule { get; set; }

        public bool isReady { get; set; }

        public string ScenarioName { get; set; }
        public string WeatherCounty { get; set; }
        public string WeatherSeverityType { get; set; }

        public string WeatherEventType { get; set; }

        public string weatherKeywords { get; set; }

        public string GeoEnabled { get; set; }
    }

    public class Condition
    {
        public string Name { get; set; }
        public int EntityType { get; set; }
        public int Operator { get; set; }
        public List<string> Value { get; set; }
    }

    public class ScenarioInfo
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string CommonName { get; set; }
        public bool IsReady { get; set; }

        public bool Enabled { get; set; }
    }

    public class WeatherInfo
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Counties { get; set; }
        public string Action { get; set; }
        public string Enabled { get; set; }
    }
}