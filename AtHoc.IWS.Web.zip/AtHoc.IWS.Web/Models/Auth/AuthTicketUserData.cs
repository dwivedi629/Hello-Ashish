﻿using AtHoc.IWS.Web.Helpers;
using Newtonsoft.Json;

namespace AtHoc.IWS.Web
{
    public class AuthTicketUserData
    {
        #region Properties

        public int? ProviderId { get; set; }
        public int DefaultProviderId { get; set; }
        public int UserId { get; set; }
        public bool HasPasswordExpired { get;  set; }
        public bool IsPasswordChangeRequired { get;  set; }
        public AuthType AuthType { get; set; }
        #endregion

        #region Constructors

        public AuthTicketUserData()
        {
        }       

        public AuthTicketUserData(string data)
        {
            var authTicketUserData = JsonConvert.DeserializeObject<AuthTicketUserData>(data);

            UserId = authTicketUserData.UserId;
            ProviderId = authTicketUserData.ProviderId;
            DefaultProviderId = authTicketUserData.DefaultProviderId;
            HasPasswordExpired = authTicketUserData.HasPasswordExpired;
            IsPasswordChangeRequired = authTicketUserData.IsPasswordChangeRequired;
            AuthType = authTicketUserData.AuthType;
        }

        #endregion

        #region Override Methods

        public override string ToString()
        {
            return JsonConvert.SerializeObject(this);
        }

        #endregion
    }
}
