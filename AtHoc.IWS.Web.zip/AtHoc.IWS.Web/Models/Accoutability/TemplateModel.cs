﻿using System;
using System.Linq;
using AtHoc.Infrastructure.Extensions;
using AtHoc.Infrastructure.Ioc;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Entities.Accountability;
using AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel;
using AtHoc.IWS.Web.Helpers;
using AtHoc.IWS.Web.Models.Publishing;
using AtHoc.Systems;
using AtHoc.Utilities;
using AtHoc.IWS.Business.Domain.Entities;
using System.Collections.Generic;
using AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel;
using AtHoc.Infrastructure;

namespace AtHoc.IWS.Web.Models.Accoutability
{
    public class TemplateModel
    {
        public TemplateModel()
        {
        }
        public int AlertBaseId { get; set; }
        public PublishingModel AlertBaseModel { get; set; }
        public GeneralSectionModel GeneralSectionModel { get; set; }
        public ProcessSectionModel ProcessSectionModel { get; set; }
        public int Id { get; set; }

        public string Name { get; set; }
        public string Description { get; set; }
        public string CommonName { get; set; }
        public int CreatedBy { get; set; }

        public string CreatedByName { get; set; }
        public DateTime CreatedOn { get; set; }

        public string CreatedOnString { get; set; }
        public string UpdatedByName { get; set; }

        public int UpdatedBy { get; set; }
        public DateTime UpdatedOn { get; set; }
        public string UpdatedOnString { get; set; }

        public DateTime LastEventPublishedOn { get; set; }

        public string LastEventPublishedOnString { get; set; }

        public static TemplateModel FromTemplate(AccountabilityTemplate template, bool loadAlertSpec)
        {
            GeneralSectionModel generalSectionModel = new GeneralSectionModel()
            {
                Name = template.Name,
                Description = template.Description
            };

            ProcessSectionModel processingSectionModel = ProcessSectionModel.FromTemplate(template);           

            var model = new TemplateModel()
            {
                Id = template.TemplateId,
                Name = template.Name,
                Description = template.Description,
                CommonName = template.CommonName,
                CreatedBy = template.CreatedBy,
                CreatedByName = template.CreatedByName,
                CreatedOn = template.CreatedOn,
                CreatedOnString =  RuntimeContext.Provider.SystemToVpsDateTimeFormated(template.CreatedOnInSystemTimeZone),
                UpdatedBy = template.UpdatedBy,
                UpdatedByName = template.UpdatedByName,
                UpdatedOnString = RuntimeContext.Provider.SystemToVpsDateTimeFormated(template.UpdatedOnInSystemTimeZone),
                UpdatedOn = template.UpdatedOn,
                GeneralSectionModel = generalSectionModel,
                ProcessSectionModel = processingSectionModel,
                AlertBaseId = template.AlertId,
                LastEventPublishedOn = template.LastEventPublishedOnDateTime,
                LastEventPublishedOnString = template.LastEventPublishedOnDateTime == DateTime.MinValue ? "" : RuntimeContext.Provider.SystemToVpsDateTimeFormated(template.LastEventPublishedOnDateTime)
            };

            
            var providerId = RuntimeContext.ProviderId;
            var operatorId = RuntimeContext.OperatorId;
            IPublishingDomainToModel publishingHelper = ServiceLocator.Resolve<IPublishingDomainToModel>();
            if (loadAlertSpec)
            {
                //parentId: 8240,
                var alertModel = publishingHelper.GetPublishingModel(template, RuntimeContext.Provider, operatorId, RuntimeContext.CustomAttributesWithouMassDevices, RuntimeContext.Provider.BaseLocale);
                //todo: review this. ugly.
                alertModel.ScenarioSection.ChannelId = template.AlertSpec.Category.Id;
                //override the response list to show only 'Status' attribute types for PA
                alertModel.Content.ResponseOptionList = RuntimeContext.CustomAttributesWithouMassDevices.Where(
                    a => a.IsStatus())
                .OrderBy(a => a.AttributeName)
                .Select(
                    a =>
                        new KeyValueModel
                        {
                            Id = a.Id,
                            Name = a.AttributeName,
                            Values = 
                                (!a.Values.HasValue()) ? new List<string>() : a.Values.Select(v => v.ValueName).ToList()
                        })
                .ToList();
                model.AlertBaseModel = alertModel;
                model.AlertBaseModel.Context = PublishingContext.AccountTemplate;
                model.AlertBaseModel.ParentId = model.AlertBaseId;
            }
            
            return model;
        }

        public AccountabilityTemplate ToTemplate(IPublishingModelToDomain publishingModelToDomain)
        {
            AccountabilityTemplate at = new AccountabilityTemplate();
            at.ProviderId = RuntimeContext.ProviderId;
            publishingModelToDomain.SetAlertSpec(AlertBaseModel, at, RuntimeContext.ProviderId, AtHocSystem.Local.ConnectDeviceCommonName, RuntimeContext.OperatorId);
            PublishingModelToDomain.SetScenarioSectionSettings(AlertBaseModel, at, RuntimeContext.ProviderId, RuntimeContext.OperatorId);
            // set scenario schedule settings on alertbase
            // todo: review. a hack. need to set the channel id in order to save theh base template
            at.AlertSpec.Category = AtHoc.Publishing.Category.GetCategory(AlertBaseModel.ScenarioSection.ChannelId);
            if (GeneralSectionModel != null)
            {
                at.Name = GeneralSectionModel.Name;
                at.Description = GeneralSectionModel.Description;
            }            
            at.TemplateId = Id;
            at.AlertId = AlertBaseId;
            at.AlertSpec.LiveDuration = ProcessSectionModel.LiveDuration;
            at.PastStatusValidityDuration = ProcessSectionModel.PastStatusValidityDuration;
            at.FirstAlertUserMessage = ProcessSectionModel.FirstAlertUserMessage;
            at.ReminderAlertUserMessage = ProcessSectionModel.ReminderAlertUserMessage;
            at.CloseAlertUserMessage = ProcessSectionModel.CloseAlertUserMessage;
            return at;
        }
    }

    public class GeneralSectionModel
    {
        public string Name { get; set; }
        public string Description { get; set; }
    }

    public class ProcessSectionModel
    {
        public ProcessSectionModel()
        {
            TimeFormat = (from DurationUnit tformat in Enum.GetValues(typeof(DurationUnit))
                          select new MultiSelectListModel()
                          {
                              Value = Convert.ToInt32(tformat).ToString(),
                              Text = tformat.ToString()
                          }).ToList();

            PastStatusValidityDuration= new Duration(DurationUnit.Hour,0);                    
        }

        //todo: MUSt unify this code between AccountabilityEvent and AccountabilityTemplate
        public static ProcessSectionModel FromEvent(AccountabilityEvent ae)
        {
            ProcessSectionModel processingSectionModel = new ProcessSectionModel()
            {
                PastStatusValidityDurationEnabled = (ae.PastStatusValidityDuration != null ? true : false)
            };

            if (ae.TemplateId == 0)
            {
                processingSectionModel.PastStatusValidityDurationEnabled = false;
            }

            if (ae.AlertSpec.LiveDuration != null)
            {
                processingSectionModel.LiveDuration = ae.AlertSpec.LiveDuration;
            }
            if (ae.PastStatusValidityDuration != null)
            {
                processingSectionModel.PastStatusValidityDuration = ae.PastStatusValidityDuration;
            }

            processingSectionModel.FirstAlertUserMessage = ae.FirstAlertUserMessage;
            processingSectionModel.ReminderAlertUserMessage = ae.ReminderAlertUserMessage;
            processingSectionModel.CloseAlertUserMessage = ae.CloseAlertUserMessage;

            return processingSectionModel;
        }

        //todo:MUSt unify this code between AccountabilityEvent and AccountabilityTemplate
        public static ProcessSectionModel FromTemplate(AccountabilityTemplate at)
        {
            ProcessSectionModel processingSectionModel = new ProcessSectionModel()
            {
                PastStatusValidityDurationEnabled = (at.PastStatusValidityDuration != null ? true : false)
            };

            if (at.TemplateId == 0)
            {
                processingSectionModel.PastStatusValidityDurationEnabled = false;
            }

            if (at.AlertSpec.LiveDuration != null)
            {
                processingSectionModel.LiveDuration = at.AlertSpec.LiveDuration;
            }
            if (at.PastStatusValidityDuration != null)
            {
                processingSectionModel.PastStatusValidityDuration = at.PastStatusValidityDuration;
            }

            processingSectionModel.FirstAlertUserMessage = at.FirstAlertUserMessage;
            processingSectionModel.ReminderAlertUserMessage = at.ReminderAlertUserMessage;
            processingSectionModel.CloseAlertUserMessage = at.CloseAlertUserMessage;

            return processingSectionModel;
        }

        public Duration LiveDuration { get; set; }
        public Duration PastStatusValidityDuration { get; set; }
        public bool PastStatusValidityDurationEnabled { get; set; }
        public AccountabilityMessage FirstAlertUserMessage { get; set; }
        public AccountabilityMessage ReminderAlertUserMessage { get; set; }
        public AccountabilityMessage CloseAlertUserMessage { get; set; }
        public List<MultiSelectListModel> TimeFormat { get; set; }
    }
}