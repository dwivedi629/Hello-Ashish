﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Web.Helpers;
using AtHoc.Infrastructure.Ioc;
using AtHoc.Infrastructure.Log;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Data.SearchSpec;
using AtHoc.IWS.Business.Domain.Accountability;
using AtHoc.IWS.Business.Domain.Accountability.Specs;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Entities.Accountability;
using AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel;
using AtHoc.IWS.Business.Domain.Events;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Web.Controllers;
using AtHoc.IWS.Web.Helpers;
using AtHoc.IWS.Web.Models.Publishing;
using AtHoc.Publishing;
using AtHoc.Utilities;

namespace AtHoc.IWS.Web.Models.Accoutability
{
    public class EventModel
    {
        public EventModel()
        {
        }

        public PublishingModel AlertBaseModel { get; set; }

        public ProcessSectionModel ProcessSectionModel { get; set; }
        public int Id { get; set; }
        public int TemplateId { get; set; }
        public string Name { get; set; }
        public string Status { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string StartedOn { get; set; }
        public int? StartedBy { get; set; }
        public string StartedByName { get; set; }
        public string EndedOn { get; set; }
        public int? EndedBy { get; set; }
        public string EndedByName { get; set; }
        public EventRuntimeModel RuntimeModel { get; set; }

        public static EventModel FromEvent(AccountabilityEvent ae, bool loadAlertSpec, bool loadRuntime)
        {
            ProcessSectionModel processingSectionModel = ProcessSectionModel.FromEvent(ae);

            var model = new EventModel()
            {
                Id = ae.EventId,
                Status = ae.Status.ToString(),
                StartDate =
                    RuntimeContext.Provider.SystemToVpsTime(ae.StartDate)
                        .ToString(RuntimeContext.Provider.GetDateTimeFormat()),
                EndDate =
                    ae.EndDate.HasValue
                        ? RuntimeContext.Provider.SystemToVpsTime(ae.EndDate.Value)
                            .ToString(RuntimeContext.Provider.GetDateTimeFormat())
                        : "",
                StartedByName = ae.StartedByName,
                StartedBy = ae.StartedBy,
                StartedOn =
                    ae.StartedOn.HasValue
                        ? RuntimeContext.Provider.SystemToVpsTime(ae.StartedOn.Value)
                            .ToString(RuntimeContext.Provider.GetDateTimeFormat())
                        : "",
                EndedBy = ae.EndedBy,
                EndedByName = ae.EndedByName,
                EndedOn =
                    ae.EndedOn.HasValue
                        ? RuntimeContext.Provider.SystemToVpsTime(ae.EndedOn.Value)
                            .ToString(RuntimeContext.Provider.GetDateTimeFormat())
                        : "",
                Name = ae.Name,
                ProcessSectionModel = processingSectionModel,
            };

            var providerId = RuntimeContext.ProviderId;
            var operatorId = RuntimeContext.OperatorId;

            IPublishingDomainToModel publishingDomainToModel = ServiceLocator.Resolve<IPublishingDomainToModel>();
            if (loadAlertSpec)
            {                
                var alertModel = publishingDomainToModel.GetPublishingModel(ae, RuntimeContext.Provider, operatorId, RuntimeContext.CustomAttributesWithouMassDevices, RuntimeContext.Provider.BaseLocale);
                //todo: review this. ugly.
                alertModel.ScenarioSection.ChannelId = ae.AlertSpec.Category.Id;
                model.AlertBaseModel = alertModel;
                model.AlertBaseModel.Context = PublishingContext.AccountEvent;
            }

            if (loadRuntime)
            {
                model.RuntimeModel = GetRuntimeModel(ae);    
            }
            
            return model;
        }
        public static EventRuntimeModel GetRuntimeModel(AccountabilityEvent eventObj)
        {
            return new EventRuntimeModel()
            {
                Dashboard = GetDashboardModel(eventObj),
                Activity = GetActivityModel(eventObj)
            };
        }
        private static DashboardModel GetDashboardModel(AccountabilityEvent eventObj)
        {
            Random random = new Random();
            try
            {
                IAccountabilityFacade acctFacade = ServiceLocator.Current.Resolve<IAccountabilityFacade>();
                var providerId = RuntimeContext.ProviderId;
                var operatorId = RuntimeContext.OperatorId;

                AccountabilityReportingSpec.AccountabilityEventStatusTrackingSpec spec = new AccountabilityReportingSpec.AccountabilityEventStatusTrackingSpec()
                {
                   GroupBy = "Status",
                   SubGroupBy = "UpdatedFrom",
                   AccountabilityEventId = eventObj.EventId,
                   BaseLocale = RuntimeContext.Provider.BaseLocale,                   
                   OperatorId = operatorId,
                   ProviderId = providerId,                   
                };

                var statusReport = acctFacade.GetEventStatus(spec);
                
                DashboardModel dashboard = new DashboardModel();
                var totalUsers = statusReport.TotalUsers;                
                var usersWithStatus = new Measure()
                {
                    Value = statusReport.Status.Responses,
                    Percent = totalUsers == 0 ? 0 : (int)(((float)statusReport.Status.Responses) / totalUsers * 100)
                };
                var usersWithoutStatus = new Measure()
                {
                    Value = totalUsers - usersWithStatus.Value,
                    Percent = 100 - usersWithStatus.Percent
                };

                var responsesByUser = new Measure()
                {
                    Value = statusReport.Status.ResponsesByUser,
                    Percent = totalUsers == 0 ? 0 :  (int)(((float)statusReport.Status.ResponsesByUser) / totalUsers)
                };
                var responsesByOperator = new Measure()
                {
                    Value = statusReport.Status.ResponsesByOperator,
                    Percent = totalUsers == 0 ? 0 : (int)(((float)statusReport.Status.ResponsesByOperator) / totalUsers)
                };

                dashboard.Status = new StatusModel()
                {
                    TotalUsers = totalUsers,
                    UsersWithStatus = usersWithStatus,
                    UsersWithoutStatus = usersWithoutStatus,
                    ResponsesByUser = responsesByUser,
                    ResponsesByOperator = responsesByOperator
                };                
                
                foreach (var response in statusReport.StatusByResponse)
                {
                    var resCount = response.Responses;
                    var resPercent = (int)((float)resCount * 100 / dashboard.Status.UsersWithStatus.Value);
                    var responseModel = new ResponseOptionStatusModel()
                    {
                        Id = response.ResponseId,
                        Name = response.StatusAttribute.ValueName,
                        Value = new Measure()
                        {
                            Value = resCount,
                            Percent = resPercent
                        },
                        Color = TrackingColors.Responses[(response.ResponseId % 9)]
                    };
                    dashboard.Status.OptionStatus.Add(responseModel);                    
                }                
               
                int lastValue = 0;
                DateTime time = RuntimeContext.Provider.CurrentSystemTime() - TimeSpan.FromDays(1);
                for (int j = 0; j < 40; j++)
                {
                    dashboard.Status.StatusOverTime.Add(new StatusOvertimeItem()
                    {
                        Time = RuntimeContext.Provider.SystemToVpsTime(time).ToString(RuntimeContext.Provider.GetDateTimeFormat()),
                        Value = lastValue
                    });
                    time += TimeSpan.FromMinutes(5);
                    lastValue += (dashboard.Status.UsersWithStatus.Value - lastValue) / random.Next(4, 10);
                }

                return dashboard;
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return null;
            }
        }
        private static ActivityModel GetActivityModel(AccountabilityEvent eventObj)
        {
            //todo: move to server side
            var now = RuntimeContext.Provider.CurrentSystemTime();
            var providerId = RuntimeContext.ProviderId;
            var operatorId = RuntimeContext.OperatorId;
            List<EventAlertModel> alertSent = new List<EventAlertModel>();

            IAlertFacade alertFacade = ServiceLocator.Current.Resolve<IAlertFacade>();

            // add the alerts that where sent
            var lastAlertTime = eventObj.CreatedOn;            
            foreach (AccountabilityEventAlert alert in eventObj.UserReminderAlerts)
            {                
                var alertInfo = alertFacade.GetAlert(alert.AlertId, providerId, operatorId);
                lastAlertTime = alertInfo.CreatedOn;
                alertSent.Add(new EventAlertModel()
                {
                    AlertId = alertInfo.AlertId,
                    Status = alertInfo.Status,
                    Name = alertInfo.Name,
                    TargetedUsers = alertInfo.TargetedUserCount,
                    CreatedOnDateTime = RuntimeContext.Provider.SystemToVpsTime(lastAlertTime),
                    CreatedOn = RuntimeContext.Provider.SystemToVpsTime(lastAlertTime).ToString(RuntimeContext.Provider.GetDateTimeFormat()),
                    ErrorCount = alertInfo.ErrorCount,
                });
            }

            List<EventAlertModel> pendingAlerts = new List<EventAlertModel>();
/*
            // todo: UGLY logic. temporary. find a better way 
            // add alerts that where suppose to be sent until now. all errors
            var numberOfMin = eventObj.UserReminderDuration.GetSeconds()/60;
            //var totalScheduledAlerts = 0;
            var endTime = eventObj.Status == AccountabilityEventStatus.Live ? eventObj.EndDate : eventObj.EndedOn;
            while (lastAlertTime + TimeSpan.FromMinutes(numberOfMin) < now && lastAlertTime + TimeSpan.FromMinutes(numberOfMin) < endTime)
            {
                lastAlertTime += TimeSpan.FromMinutes(numberOfMin);
                pendingAlerts.Add(new EventAlertModel()
                {
                    AlertId = 0,
                    Status = AlertStatus.Standby,
                    Name = eventObj.Name,
                    CreatedOn = RuntimeContext.Provider.SystemToVpsTime(lastAlertTime).ToString(RuntimeContext.Provider.GetDateTimeFormat()),
                    ErrorCount = 1,
                });
            }

            // now add the upcomming alert    
            var isNextAlert = true;
            while (true)
            {
                lastAlertTime += TimeSpan.FromMinutes(numberOfMin);
                if (lastAlertTime > endTime)
                {
                    break;
                }

                pendingAlerts.Add(new EventAlertModel()
                {
                    AlertId = 0,
                    Status = AlertStatus.Standby,
                    Name = eventObj.Name,
                    CreatedOn = RuntimeContext.Provider.SystemToVpsTime(lastAlertTime).ToString(RuntimeContext.Provider.GetDateTimeFormat()),
                    ErrorCount = 0,
                    IsNextAlert = isNextAlert
                });
                //totalScheduledAlerts++;
                isNextAlert = false;
            }*/

            var model = new ActivityModel
            {
                //EventAlertOvertimeMeasures = 
                SentAlerts = alertSent,
                PendingAlerts = pendingAlerts
            };

            return model;

            //return Json(new { Success = true, Items = alertSent, TotalCount = alertSent.Count, TotalScheduledAlerts = totalScheduledAlerts });
        }
    }

    public class EventRuntimeModel
    {
        public DashboardModel Dashboard { get; set; }
        public ActivityModel Activity { get; set; }         
    }

    public class DashboardModel
    {
        public StatusModel Status { get; set; }
        //public OvertimeModel Overtime { get; set; }
        public ActivityModel Activity { get; set; }
    }

    public class ActivityModel
    {
        public ActivityModel()
        {
            SentAlerts = new List<EventAlertModel>();
            PendingAlerts = new List<EventAlertModel>();
            EventAlertOvertimeMeasures = new List<EventAlertOvertimeItem>();
        }
        public List<EventAlertModel> SentAlerts { get; set; }
        public List<EventAlertModel> PendingAlerts { get; set; }
        public List<EventAlertOvertimeItem> EventAlertOvertimeMeasures { get; set; }
    }

    public class EventAlertModel
    {        
        public int Id { get; set; } 
        public int AlertId { get; set; } 
        public string Name { get; set; } 
        public AlertStatus Status { get; set; }
        public DateTime CreatedOnDateTime { get; set; }
        public string CreatedOn { get; set; }
        public int TargetedUsers {get; set;}
        public int ErrorCount { get; set; }
        public bool IsNextAlert { get; set; }
    }

    public class EventAlertOvertimeItem
    {
        public int Value { get; set; }
        public DateTime Time { get; set; }

    }

    public class StatusOvertimeItem
    {
        public int Value { get; set; }
        public String Time { get; set; }

    }    

    public class StatusModel
    {
        public StatusModel()
        {
            OptionStatus = new List<ResponseOptionStatusModel>(); 
            StatusOverTime = new List<StatusOvertimeItem>();
        }

        public int TotalUsers { get; set; }
        public Measure UsersWithStatus { get; set; }       
        public Measure UsersWithoutStatus { get; set; }

        public Measure ResponsesByUser { get; set; }
        public Measure ResponsesByOperator { get; set; }

        public List<ResponseOptionStatusModel> OptionStatus { get; set; }

        public List<StatusOvertimeItem> StatusOverTime { get; set; }
    }

    public class ResponseOptionStatusModel

    {
        public ResponseOptionStatusModel()
        {
            Value = new Measure();
        }

        public string Color { get; set; }
        public int Id { get; set; }
        public string Name { get; set; }
        public Measure Value { get; set; }
    }    

    public class Measure
    {
        public int Value { get; set; }
        public int Percent { get; set; }
    }


    public class EventOrganizationReport
    {        
        public List<EventOrganizationHierarchyEntry> Hierarchy { get; set; }
        public List<EventOrganizationReportEntry> Entries { get; set; }
    }

    public class EventOrganizationHierarchyEntry
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }

    // reports
    public class EventOrganizationReportEntry
    {
        public int Id { get; set; }
        public int ParentId { get; set; }
        public bool HasChildren { get; set; }
        public string Name { get; set; }        
        public List<int> ResponseValues{ get; set; }

        public int NoResponse { get; set; }
    }


    public static class TrackingColors
    {
        public static String Targeted = "#FF6699";
        public static String Sent = "#066FFCC";
        public static String Recieved = "#FFF79C";
        public static String NoResponse = "#A5A5A5";
        public static String Ack = "#9CB57B";

        public static String[] Responses =
        {
            "#FFBD42", "#9cBDDE", "#DEA59C", "#D6BDDE", "#B37BB3", "#FBAF5C",
            "#448CCB", "#AB947C", "#B27F7F", "#CEB37F"
        };
    }
}