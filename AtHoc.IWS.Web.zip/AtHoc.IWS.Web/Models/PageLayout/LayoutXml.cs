﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;

namespace AtHoc.IWS.Web.Models.PageLayout
{
    public class LayoutXml
    {
        public IEnumerable<LayoutSection> LayoutSections { get; set; }


        public IEnumerable<LayoutSection> GetAllSections(string pageLayoutXml, string attributeName)
        {
            var xml = new XmlDocument();
            xml.LoadXml(pageLayoutXml);
            var layoutSection = new List<LayoutSection>();
            var xnList1 = xml.SelectNodes("/page/row");
            foreach (XmlNode xn in xnList1)
            {
                foreach (XmlNode columnNode in xn.ChildNodes)
                {
                    //Buckets
                    foreach (XmlNode bucket in columnNode.ChildNodes)
                    {
                        //Sections
                        var allEnabledSections = bucket.SelectNodes("section[@enabled='true']");

                        foreach (XmlNode section in allEnabledSections)
                        {
                            var sectionLayout = GetSectionAttributes(section, attributeName);
                            var childSections = section.SelectNodes("section");
                            sectionLayout.IsParent = childSections.Count > 0;
                            //layoutSection.Add(sectionLayout);
                            if (childSections.Count > 0)
                            {
                                foreach (XmlNode childSection in childSections)
                                {
                                    var childSectionLayout = GetSectionAttributes(childSection, attributeName, true);
                                    childSectionLayout.IsChild = true;                                   
                                    //layoutSection.Add(childSectionLayout);
                                    sectionLayout.Children.Add(childSectionLayout);
                                }
                            }
                            layoutSection.Add(sectionLayout);
                        }
                    }
                }
            }
            return layoutSection;
        }

        private LayoutSection GetSectionAttributes(XmlNode section, string attributeName = "", bool isChild = false)
        {
            var type=string.Empty;
            var method = string.Empty;
            if (attributeName == null)
            {
                attributeName = "";
            }
            var sectionName = section["title"].InnerText;

            if (section.Attributes["id"] != null)
            {
                var id = section.Attributes["id"].Value;
            }
            if (section.Attributes["type"] != null)
            {
                type= section.Attributes["type"].Value;
            }
            if (section.Attributes["method"] != null)
            {
                method = section.Attributes["method"].Value;
            }
            var sec = new LayoutSection { Name = sectionName, DisplayName = isChild ? "  " + sectionName : sectionName, Type = type, Method=method };

            //Attributes
            foreach (XmlNode attribute in section["fields"].ChildNodes)
            {
                if (!string.IsNullOrEmpty(attribute.InnerText))
                {
                    if (attributeName.Trim().Length > 0 && attribute.InnerText.ToUpperInvariant() == attributeName.ToUpperInvariant())
                    {
                        sec.IsSelected = true;
                    }
                    sec.Attributes.Add(attribute.InnerText);
                }
            }
            return sec;
        }

    }

    public class LayoutSection
    {
        public LayoutSection()
        {
            this.IsParent = false;
            this.IsSelected = false;
            this.IsChild = false;
            this.Attributes = new List<string>();           
            this.Children = new List<LayoutSection>();
        }

        public string Name { get; set; }
        public string DisplayName { get; set; }
        public bool IsSelected { get; set; }
        public bool IsParent { get; set; }
        public bool IsChild { get; set; }
        public List<string> Attributes { get; set; }
        public List<LayoutSection> Children { get; set; }
        public string Type { get; set; }
        public string Method { get; set; }

    }


    public class LayoutAttributes
    {
        public IEnumerable<LayoutAttribute> Attributes { get; set; }
    }

    public class LayoutAttribute
    {
        public string AttributeName { get; set; }
        public string AttributeType { get; set; }
        public int Id { get; set; }
    }
}