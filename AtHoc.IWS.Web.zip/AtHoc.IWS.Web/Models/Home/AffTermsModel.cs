﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text.RegularExpressions;
using System.Web;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.VirtualSystem;

namespace AtHoc.IWS.Web.Models.Home
{
    public class AffTermsModel
    {
        private readonly IVirtualSystemFacade _virtualSystemFacade;
        
        public AffTermsModel(IVirtualSystemFacade virtualSystemFacade)
        {
            
            _virtualSystemFacade = virtualSystemFacade;

        }

        public bool ShowTermsConditions
        {
            get
            {
                if (RuntimeContext.Provider.ProviderType() == VPSType.Affiliate25)
                {
                    return !_virtualSystemFacade.IsAffiliateTermsConditionsAccepted(RuntimeContext.Provider.Id,
                        RuntimeContext.Operator.Id);
                }
                
                    return false;
                
            }
            
        }

        public string TermsConditionsText
        {
            get { return SanitizeHtml(_virtualSystemFacade.GetAffiliateTermsConditions()); }
        }

        public string UserDisplayName
        {
            get { return RuntimeContext.Operator.DisplayName; }
        }

        public string ProviderDisplayName
        {
            get { return RuntimeContext.Provider.DisplayName; }
        }

        public int UserId {
            get { return RuntimeContext.Operator.Id; }
        }

        public int ProviderId
        {
            get { return RuntimeContext.Provider.Id; } 
            
        }

       private string SanitizeHtml(string inputString)
        {
            const string htmlTagPattern = "</?(?i:script|embed|input|object|frameset|frame|iframe|meta|link|style)(.|\n)*?>";
            return Regex.Replace(inputString, htmlTagPattern, string.Empty);
        }
    }
}