﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Systems;

namespace AtHoc.IWS.Web.Models.Home
{
    /// <summary>
    /// UI Model for home page
    /// </summary>
    public class HomeModel
    {
        public HomeModel()
        {
            Errors = new List<string>();
        }

        /// <summary>
        /// Indicates if current VPS is affiliate or not to toggle affiliate functionality
        /// </summary>
        public bool IsAffiliate { get; set; }


        /// <summary>
        /// Guid for VPS logo, converted to string
        /// Empty is VPS does not have logo image or not configured to show
        /// </summary>
        public string VpsLogoGuid { get; set; }
 
        /// <summary>
        /// VPS welcome message
        /// Show on home page header (or branding) section
        /// </summary>
        public string WelcomeMessage { get; set; }

        /// <summary>
        /// Last updated date time (last page refreshed) 
        /// DateTime converted to VPS formated datetime
        /// </summary>
        public string UpdatedOn { get; set; }

        /// <summary>
        /// Count of active users for currently logged in operator
        /// </summary>
        public int ActiveUsers { get; set; }
        
        /// <summary>
        /// Number of online desktop users
        /// </summary>
        public int OnlineUsers { get; set; }

        /// <summary>
        /// Number of mobile users
        /// </summary>
        public int MobileUsers { get; set; }

        /// <summary>
        /// Number of users with no devices
        /// </summary>
        public int NoDeviceUsers { get; set; }
        
        /// <summary>
        /// Health status of the system/vps
        /// </summary>
        public SystemHealthStatus HealthStatus { get; set; }

        /// <summary>
        /// Does currently logged in operator has access to Alerts?
        /// </summary>
        public bool HasAccessToAlerts { get; set; }

        /// <summary>
        /// Does currently logged in operator has access to scenario
        /// </summary>
        public bool HasAccessToScenarios { get; set; }

        /// <summary>
        /// Does currently logged in operator has access to events
        /// </summary>
        public bool HasAccessToEvents { get; set; }

        /// <summary>
        /// Can currently logged in operator publish any alerts
        /// </summary>
        public bool CanPublishAlert { get; set; }

        /// <summary>
        /// Can currently logged in operator manager users
        /// </summary>
        public bool CanManagerUsers { get; set; }

        /// <summary>
        /// Can currently logged in operator connect to org
        /// </summary>
        public bool CanConnectToOrg { get; set; }

        /// <summary>
        /// Count of organization
        /// </summary>
        public int OrganizationCount { get; set; }

        /// <summary>
        /// Invitation count
        /// </summary>
        public int OrganizationInviteCount { get; set; }

        /// <summary>
        /// Current user last login time
        /// </summary>
        public string LastLoginTime { get; set; }

        /// <summary>
        /// Failed login attempts by current user
        /// </summary>
        public int? LoginFailedAttempts { get; set; }

        /// <summary>
        /// Last password change date time string
        /// </summary>
        public string PasswordUpdatedOn { get; set; }

        /// <summary>
        /// Identifier for current user, combination of user and vps
        /// </summary>
        public string Identifier { get; set; }

        /// <summary>
        /// Flag for if Organization is connected
        /// </summary>
        public bool IsOrganizationConnected { get; set; }

        /// <summary>
        /// Contains errors if occurred during geting home model
        /// </summary>
        public IList<string> Errors { get; set; }

        /// <summary>
        /// Tooltip for vps logo image
        /// </summary>
        public string WebImageAlternateText { get; set; }

        /// <summary>
        /// Does currently logged in operator has access to accountability
        /// </summary>
        public bool HasAccessToAccountability { get; set; }
        /// <summary>
        /// Can currently logged in operator start accountability event
        /// </summary>
        public bool CanStartAccountabilityEvent { get; set; }
    }
}