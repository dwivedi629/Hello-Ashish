﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web.Script.Serialization;
using System.Xml;
using System.Xml.Linq;
using AtHoc.Business.Extensions;
using AtHoc.Infrastructure.Ioc;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.Authorization;
using AtHoc.d911;
using AtHoc.d911.Model.Organization;
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;
using AtHoc.IWS.Business.Domain.Events;
using AtHoc.IWS.Business.Domain.Users.Impl.Search;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.IWS.Business.Service;
using AtHoc.IWS.Web.Helpers;
using Microsoft.Practices.ObjectBuilder2;
using models = AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Event.Impl;
using AtHoc.Global.Resources;
using Microsoft.Practices.EnterpriseLibrary.Logging.Instrumentation;
using Microsoft.Practices.Unity.InterceptionExtension;

namespace AtHoc.IWS.Web.Models.Event
{
    /// <summary>
    /// Event View Model for Event List
    /// </summary>
    public class EventModel
    {

        public static readonly IDictionary<int, string> Severities = new Dictionary<int, string>();

        static EventModel()
        {
            var severiteis = PublishingDomainToModel.GetSeverities();
            severiteis.ForEach(kv => Severities.Add(kv.Id, kv.Name));
        }
        class Constant
        {
            public static readonly string HubComm = "HubComm";
            public static readonly string Alert = "Alert";
            public static readonly string Log = "Log";     

            public static string ConnectUpdates
            {
                get { return IWSResources.Event_ConnectUpdates; }                
            }
        }

        #region Property

        /// <summary>
        /// repliable
        /// </summary>
        public Boolean CanReply { get; set; }//to enbale/disable reply 
        public Boolean CanAcceptDecline { get; set; }//to enable/disable accpet/decline
        public bool CanReviewed { get; set; }//to enable/disable review
        public bool ShowReview { get; set; }//to show/hide Review 
        public bool ShowPublish { get; set; }//to show/hide forward
        public bool ShowReply { get; set; }//to show/hide Reply
        public bool ShowAcceptDecline { get; set; }//to show/hide Accpet/Decline
        public bool ShowModify { get; set; }//to show/hide Edit/new
       
        public string AlertUrl { get; set; }

        /// <summary>
        /// Event Category Type
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// Event Category Name
        /// </summary>
        public string EventCategoryName { get; set; }
        public int EventCategoryId { get; set; }
        
        public string CommonName { get; set; }

        /// <summary>
        /// Event Category
        /// </summary>
        public string Category { get; set; }
        /// <summary>
        /// Additional Info
        /// </summary>
        public Dictionary<string, string> AdditionalInfo { get; set; }
        /// <summary>
        /// URL computed based on IMAGE_ID in Event_Category table.
        /// </summary>
        public string TypeIcon { get; set; }

        /// <summary>
        /// Event Title
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// This is the original message body, it is different from teh Descriotion field which is a concutination of all the additional description field
        /// </summary>
        public string Body { get; set; }

        /// <summary>
        /// Event Time
        /// </summary>
        public string Time { get; set; }

        /// <summary>
        /// Event Created On
        /// </summary>
        public string CreatedOn { get; set; }

        /// <summary>
        /// Event Updated On
        /// </summary>
        public string UpdatedOn { get; set; }

        /// <summary>
        /// Event Responded On
        /// </summary>
        public string RespondedOn { get; set; }

        /// <summary>
        /// Response Description with "respond" type, and get the description value.
        /// </summary>
        public string Response { get; set; }
        /// <summary>
        /// Responded By (User Name)
        /// </summary>
        public int? RespondedBy { get; set; }

        public string RespondedByDisplayName { get; set; }

        /// <summary>
        /// Event Geo Location Latitude
        /// </summary>
        public double? Latitude { get; set; }

        /// <summary>
        /// Event Geo Location Longitude
        /// </summary>
        public double? Longitude { get; set; }

        /// <summary>
        /// UserId or OrgId who created the event.
        /// </summary>
        public int? UserId { get; set; }

        /// <summary>
        /// Event Generated By (USER ID/SOURCE ID)
        /// </summary>
        public string SourceId { get; set; }

        /// <summary>
        /// Event Source Name (Organization Name/User Name)
        /// </summary>
        public string SourceName { get; set; }

        /// <summary>
        /// Event Source Type (USER/ORGANIZATION)
        /// </summary>
        public string SourceType { get; set; }

        /// <summary>
        /// Event End Time
        /// </summary>
        public string EndTime;

        /// <summary>
        /// Event ID
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Is Event Responded?
        /// </summary>
        public bool? Responded { get; set; }

        /// <summary>
        /// Is Event reviewed?
        /// Computed. if reviewed_by is not null, this is true, otherwise, it’s false
        /// </summary>
        public bool Reviewed { get; set; }


        /// <summary>
        /// Reviewer of User.
        /// </summary>
        public string ReviewedByDisplayName { get; set; }

        /// <summary>
        /// Reviewer User ID
        /// </summary>
        public int? ReviewedBy { get; set; }

        /// <summary>
        /// Review on Date
        /// </summary>
        public string ReviewedOn { get; set; }


        /// <summary>
        /// Does event has Geo Location?
        ///: true, // computed. If the event has any geoInfo in the detailed_tab/media_tab, it’s true.
        /// </summary>
        public bool HasGeo { get; set; }


        /// <summary>
        /// Has Media Attached?
        /// //: true, //if the detail tab has any mediaId, it’s true
        /// </summary>
        public bool HasMedia { get; set; }

        /// <summary>
        /// Is it Editable?
        /// //: false,//Is_editable in event tab
        /// </summary>
        public bool? Editable { get; set; }

        /// <summary>
        /// Visibility Level of Event (Shared,Team,only user)
        //: -2,//computed. if visibility_level in event tab is null, then use the “default_visibility” value in category tab
        /// </summary>
        public int VisibilityLevel { get; set; }

        /// <summary>
        /// Event priority
        ///: 1,// computed. if PRIORITY in event tab is null, then use the “default_priority” value in category tab
        /// </summary>
        public int? Priority { get; set; }
        private string _severity;
        /// <summary>
        /// Computed Severity string based on Priority and Current Locale
        /// </summary>
        public string SeverityText
        {
            get
            {
                return convertSeverity(this._severity);
            }
            set
            {
                this._severity = value;
            }
        }

        private string convertSeverity(string severity)
        {

            switch (severity)
            {
                case "Extreme":
                    return IWSResources.Event_Severity_Extreme;
                case "Severe":
                case "High":
                    return IWSResources.Event_Severity_High;
                case "Moderate":
                    return IWSResources.Event_Severity_Moderate;
                case "Minor":
                    return IWSResources.Event_Severity_Minor;
                case "Informational":
                    return IWSResources.Event_Severity_Informational;
                case "Unknown":
                    return IWSResources.Event_Severity_Unknown;
                default:
                    return severity;
            }
        }
        /// <summary>
        /// Event Description (Message Body + Concatination of all the description)
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Collection of attachments associated to Event
        /// </summary>
        public List<EventAttachment> Medias { get; set; }

        /// <summary>
        /// Event is expired or not
        /// </summary>
        public bool? IsExpired { get; set; }

        public string GeoJson { get; set; }

        public bool IsConnectActionRequired { get; set; }

        public long ConnectInvitationId { get; set; }
        public string EventCategoryType { get; set; }

        public string LocalAlertId { get; set; }

        public List<HistoryEntry> HistoryInfo { get; set; }

        #endregion

        #region Method

        private static CustomAttributeLookup _providerAttributes;

        

        /// <summary>
        /// Get Event View Model for Collection of Events
        /// </summary>
        /// <param name="userFacade"></param>
        /// <param name="domainEvents">Collection of Events</param>
        /// <param name="eventCategories"></param>
        /// <param name="mediaAttachments">Collection of Event Media Attachments (Optional)</param>
        /// <returns>Collection of EventViewModel</returns>
        public static List<EventModel> GenerateEventModels(IUserFacade userFacade, IEnumerable<models.Event> domainEvents, IDictionary<int, models.EventCategory> eventCategories, IEnumerable<models.Media> mediaAttachments = null,  IAuthFacade authFacade = null)
        {
            var dbEvents = domainEvents as models.Event[] ?? domainEvents.ToArray();
            var displayNameById  = GetDisplayNameById(userFacade, dbEvents);

            var eventModels = new List<EventModel>();
            foreach (var domainEvent in dbEvents)
            {
                var attachments = mediaAttachments != null ? mediaAttachments.Where(a => a.TargetId == domainEvent.EventId) : null;
                models.EventCategory ec = null;
                if (domainEvent.EventCategoryId != null && !eventCategories.TryGetValue(domainEvent.EventCategoryId.Value, out ec))
                {
                    throw new Exception("Event Category not found.");
                }

                var eventModel = GenerateEventModel(domainEvent, ec, displayNameById,attachments, authFacade);
                eventModels.Add(eventModel);
            }

            return eventModels;
        }

        private static IDictionary<int, string> GetDisplayNameById(IUserFacade userFacade, IEnumerable<models.Event> domainEvents)
        {
            var userIds = new HashSet<int>();
            var attributeList = new List<string> {"DISPLAYNAME", "FIRSTNAME", "LASTNAME", "LOGIN_ID"};

            foreach (var domainEvent in domainEvents)
            {
                if (domainEvent.ReviewedBy != null && domainEvent.ReviewedBy > 0)
                {
                    userIds.Add(domainEvent.ReviewedBy.Value);
                }

                foreach (var eventDescription in domainEvent.EventDescriptions)
                {
                    if (eventDescription.SourceId != null)
                    {
                        userIds.Add(eventDescription.SourceId.Value);
                    }
                }
            }
            IDictionary<int, string> disaplyNameById = new Dictionary<int, string>();

            if (userIds.Count == 0)
            {
                return disaplyNameById;
            }
            var users = userFacade.GetSystemUsersByIds(userIds.ToList(), attributeList, null);

           
            users.ForEach(user => disaplyNameById.Add(user.Id, user.GetDisplayName()));
            return disaplyNameById;
        }


        /// <summary>
        /// Get Event Model for Single Event
        /// </summary>
        /// <param name="domainEvent">Event</param>
        /// <param name="eventCategory"></param>
        /// <param name="displayNamesById"></param>
        /// <param name="mediaAttachments">true/false</param>
        /// <param name="authFacade"></param>
        /// <returns></returns>
        private static EventModel GenerateEventModel(models.Event domainEvent, models.EventCategory eventCategory, IDictionary<int, string> displayNamesById, IEnumerable<models.Media> mediaAttachments = null, IAuthFacade authFacade = null)
        {
            const string DESCRIPTIONTYPE = "response";
            var eventModel = new EventModel();
            
            var additionalInfo = domainEvent.GetCustomData();

            
            eventModel.Title = domainEvent.MsgTitle;
            eventModel.EventCategoryId = domainEvent.EventCategoryId.GetValueOrDefault();
            eventModel.Body = domainEvent.MsgBody;
            if (domainEvent.EventCategoryType.Equals("Alert", StringComparison.OrdinalIgnoreCase))
            {
                eventModel.AdditionalInfo = new Dictionary<string, string>();
                eventModel.AdditionalInfo.Add("OriginalTitle", domainEvent.MsgTitle);
                eventModel.AdditionalInfo.Add("OriginalBody", domainEvent.MsgBody);
                var originalEventCatId = GetAdditionalDataItemValue(additionalInfo,
                    OrganizationEventCustomAttrIds.EventCategoryId);
                eventModel.AdditionalInfo.Add("OriginalEventCategoryId", originalEventCatId);
                var totalAlertTargeting = GetAdditionalDataItemValue(additionalInfo, OrganizationEventCustomAttrIds.AlertTotalTargeted);
                //overide title and body
                eventModel.Title = string.Format(IWSResources.Event_Log_Alert_Title_Template, domainEvent.MsgTitle);
                var body1 = string.Format(IWSResources.Event_Log_Alert_Body_Template1, domainEvent.MsgTitle, totalAlertTargeting);
                var body2 = string.Format(IWSResources.Event_Log_Alert_Body_Template2);
                eventModel.Body = string.Format("{0} \n{1} \n{2}", body1, body2, domainEvent.MsgBody);
            }            

            var vpsdateFormat = AtHoc.IWS.Business.Context.RuntimeContext.Provider.GetDateTimeFormat();
            eventModel.CreatedOn = domainEvent.CreatedOn.HasValue
                ? RuntimeContext.Provider.UtcToVpsTime(domainEvent.CreatedOn.Value).ToString(vpsdateFormat)
                : string.Empty;

            eventModel.UpdatedOn = RuntimeContext.Provider.UtcToVpsTime(domainEvent.UpdatedOn).ToString(vpsdateFormat);


            eventModel.EndTime = domainEvent.EventEnd.HasValue
                ? RuntimeContext.Provider.UtcToVpsTime(domainEvent.EventEnd.Value).ToString(vpsdateFormat)
                : string.Empty;
            var response =
                domainEvent.EventDescriptions.FirstOrDefault(
                    a => a.Type != null && a.Type.Equals(DESCRIPTIONTYPE, StringComparison.OrdinalIgnoreCase));
            if (response != null)
            {
                //find the description with "respond" type, and get the created_on value
                eventModel.RespondedOn = RuntimeContext.Provider.UtcToVpsTime(response.CreatedOn)
                    .ToString(vpsdateFormat);

                //find the description with "respond" type, and get the description value
                eventModel.Response = response.Description;

                //find the description with "respond" type, and get the SourceId value, then query the user table to get the display name
                eventModel.RespondedBy = response.SourceId;
               if (response.SourceId != null)
                {
                    string userDisplayName;
                    if (displayNamesById.TryGetValue(response.SourceId.Value, out userDisplayName))
                    {
                        eventModel.RespondedByDisplayName = userDisplayName;
                    }
                }                
            }

            //Concatinate all event description excluding Event_Desction_Type = "response". All events from mobile comes with empty type, we show only updates from mobile here.                     
            eventModel.Description = eventModel.Body +
                                     string.Join("\n", (
                                         domainEvent.EventDescriptions.Where(a => string.IsNullOrEmpty(a.Type)).OrderByDescending(des => des.CreatedOn)
                                             .Select(e => e.Description)));            

            eventModel.AlertUrl = GetAdditionalDataItemValue(additionalInfo, OrganizationEventCustomAttrIds.Url);  //GetAlertUrl(domainEvent.EventData);

            eventModel.EventCategoryName = eventCategory.Name; //domainEvent.EventCategoryName;            
            

            eventModel.Type = eventCategory.EventCategoryType;

            eventModel.CanAcceptDecline = false; //Default Accept Decline should be false. Only for Connect Update - it can be true.
            eventModel.ShowReply = true;
            eventModel.ShowReview = true;
            eventModel.CanReviewed = true;
            eventModel.ShowPublish = true;
            eventModel.ShowModify = false;
            string baseUrl = ConfigurationManager.GetURL();
            //Activity Log - Manual
            if(string.Equals(eventCategory.EventCategoryType, "LOG", StringComparison.InvariantCultureIgnoreCase))
            {
                eventModel.TypeIcon = Path.Combine(baseUrl, "/athoc-cdn/Images/icon-log-manual.png");
                eventModel.ShowModify = true;
                eventModel.ShowReply = false;
                eventModel.ShowReview = false;
                eventModel.CanReviewed = false;
            }
            //Activity Log - Alert
            else if (string.Equals(eventCategory.EventCategoryType, "ALERT", StringComparison.InvariantCultureIgnoreCase))
            {
                eventModel.TypeIcon = Path.Combine(baseUrl, "/athoc-cdn/Images/icon-log-alert.png");
                eventModel.ShowReply = false;
                eventModel.ShowReview = false;
            }
             //HubComm event
            else if (string.Equals(eventCategory.EventCategoryType, EventModel.Constant.HubComm, StringComparison.InvariantCultureIgnoreCase))
            {
                eventModel.TypeIcon = Path.Combine(baseUrl, "/athoc-cdn/Images/icon-connect-32.png");
                eventModel.ConnectInvitationId = domainEvent.ConnectInvitationId;
                eventModel.ShowPublish = false;
                eventModel.ShowReply = false;
                eventModel.EventCategoryName = EventModel.Constant.ConnectUpdates;
                bool isConnectActionRequired = false;
                if (domainEvent.ActionPerformed.HasValue)
                {
                    isConnectActionRequired = domainEvent.ActionPerformed.Value == models.ActionPerformed.ConnectRequestActionRequired;
                }
                // Changed for IWS-21927
                var connectActionPermission = authFacade != null && authFacade.HasAccess(RuntimeContext.Operator,
                    RuntimeContext.ProviderId, models.SystemObject.Organization, models.ActionType.Modify);


                if (string.Equals(eventCategory.LogicalId, "Invite", StringComparison.InvariantCultureIgnoreCase))
                {
                    eventModel.ShowAcceptDecline = true;
                    eventModel.CanAcceptDecline = isConnectActionRequired && connectActionPermission;
                    eventModel.CanReviewed = isConnectActionRequired;
                }
            }
            else
            {
                eventModel.TypeIcon = eventCategory.ImageId == null ? string.Empty : baseUrl + "/client/map/iconimage/" + eventCategory.ImageId;    
            }
            

           
           
            
			eventModel.Title = domainEvent.MsgTitle;

            if (domainEvent.EventTime.HasValue)
            {
                eventModel.Time =
                    RuntimeContext.Provider.SystemToVpsDateTimeFormated(
                        RuntimeContext.Provider.UtcToVpsTime(domainEvent.EventTime.Value));
            }
            eventModel.Latitude = domainEvent.Latitude;
            eventModel.Longitude = domainEvent.Longitude;
            eventModel.GeoJson = domainEvent.GeoJson;

            eventModel.SourceId = domainEvent.SourceId;
            eventModel.UserId = domainEvent.UserId;
            eventModel.SourceName = domainEvent.SourceName;
            eventModel.SourceType = domainEvent.SourceType;
            eventModel.Id = domainEvent.EventId;
            eventModel.Responded = domainEvent.IsResponded != null
                ? domainEvent.IsResponded.ToUpper() == "Y"
                : eventModel.Responded;
            if (domainEvent.ReviewedBy != null && domainEvent.ReviewedBy > 0)
            {
               eventModel.Reviewed = true;
               eventModel.ReviewedBy = domainEvent.ReviewedBy;
               string userDisplayName;
               if (displayNamesById.TryGetValue(domainEvent.ReviewedBy.Value, out userDisplayName))
               {
                   eventModel.ReviewedByDisplayName = userDisplayName;
               }
            }

            if (domainEvent.EventEnd.HasValue)
            {
                eventModel.IsExpired = RuntimeContext.Provider.UtcToVpsTime(domainEvent.EventEnd.Value) <
                                       RuntimeContext.Provider.CurrentSystemTimeToVps();
            }

            eventModel.CanReply = (eventModel.Responded.HasValue && eventModel.Responded.Value) || (eventModel.IsExpired.HasValue && eventModel.IsExpired.Value) ||
                                  eventModel.SourceType != "ORGANIZATION" || EventModel.GetResponseOption(additionalInfo) == null
                ? false
                : true;

            if (domainEvent.ReviewedOn.HasValue)
            {
                eventModel.ReviewedOn =
                    RuntimeContext.Provider.UtcToVpsTime(domainEvent.ReviewedOn.Value).ToString(vpsdateFormat);
            }
            eventModel.Editable = domainEvent.IsEditable == "Y";
            eventModel.VisibilityLevel = domainEvent.VisibilityLevel;
            eventModel.Priority = domainEvent.Priority;
            
            string tempSeverityString;
            Severities.TryGetValue(eventModel.Priority.Value, out tempSeverityString);
            eventModel.SeverityText = tempSeverityString;

            

            eventModel.LocalAlertId = GetAdditionalDataItemValue(additionalInfo, OrganizationEventCustomAttrIds.AlertId);

            eventModel.Medias = new List<EventAttachment>();

            if (mediaAttachments != null)
            {
                var attachments = mediaAttachments.Where(a => a.TargetId == domainEvent.EventId).ToList();
                if (attachments.Any())
                {
                    //Loop thru all the Media entry in EventMidea table
                    foreach (var em in domainEvent.EventMedia)
                    {
                        var mediaAttachment = new EventAttachment();
                        mediaAttachment.CreatedOn =
                            RuntimeContext.Provider.UtcToVpsTime(em.CreatedOn).ToString(vpsdateFormat);
                        //Get Original Image/Video
                        mediaAttachment.OriginalImage = GenerateMediaUrl(em.MediaGuid.ToString()) + "?download=true";

                        var originalMedia = attachments.FirstOrDefault(b => b.MediaGuid == em.MediaGuid);

                        if (originalMedia != null && originalMedia.ContentType != null)
                        {
                            mediaAttachment.ContentType = originalMedia.ContentType;
                            mediaAttachment.OriginalHeight = originalMedia.Height;
                            mediaAttachment.OriginalWidth = originalMedia.Width;
                            mediaAttachment.Rotation = originalMedia.Rotation;
                        }

                        //Get Thumbnail Image
                        var tnMedia =
                            attachments.FirstOrDefault(
                                b =>
                                    b.ParentMediaGuid == em.MediaGuid && b.Description.ToLower().StartsWith("small"));

                        if (tnMedia != null)
                        {
                            mediaAttachment.ThumbnailImage = GenerateMediaUrl(tnMedia.MediaGuid.ToString());
                        }

                        //Get Medium Size IMage
                        var midiumMedia =
                            attachments.FirstOrDefault(
                                b =>
                                    b.ParentMediaGuid == em.MediaGuid &&
                                    b.Description.ToLower().StartsWith("middle"));

                        if (midiumMedia != null && midiumMedia.MediaGuid != null)
                        {
                            mediaAttachment.MediumImage = GenerateMediaUrl(midiumMedia.MediaGuid.ToString());
                        }

                        //Get MP4 Video
                        var videoMP4Media =
                            attachments.FirstOrDefault(
                                b =>
                                    b.ParentMediaGuid == em.MediaGuid && b.ContentType.ToLower().StartsWith("video/mp4"));

                        if (videoMP4Media != null && videoMP4Media.MediaGuid != null)
                        {
                            mediaAttachment.VideoMP4 = GenerateMediaUrl(videoMP4Media.MediaGuid.ToString());
                        }

                        //Get MPEG video
                        var videoMpeg =
                            attachments.FirstOrDefault(
                                b =>
                                    b.ParentMediaGuid == em.MediaGuid &&
                                    b.ContentType.ToLower().StartsWith("video/mpeg"));

                        if (videoMpeg != null && videoMpeg.MediaGuid != null)
                        {
                            mediaAttachment.VideoMpeg = GenerateMediaUrl(videoMpeg.MediaGuid.ToString());
                        }

                        //Get Quick Time Video
                        var videoQT =
                            attachments.FirstOrDefault(
                                b =>
                                    b.ParentMediaGuid == em.MediaGuid &&
                                    b.ContentType.ToLower().StartsWith("video/quicktime"));

                        if (videoQT != null && videoQT.MediaGuid != null)
                        {
                            mediaAttachment.VideoQT = GenerateMediaUrl(videoQT.MediaGuid.ToString());
                        }
                        else if (!string.IsNullOrEmpty(mediaAttachment.ContentType) &&
                                 mediaAttachment.ContentType.Contains("video"))
                        //For Quick Time Type Video = It is always Original MediaGuid from EventMedia
                        {
                            mediaAttachment.VideoQT = GenerateMediaUrl(em.MediaGuid.ToString());
                        }

                        //Get video/WEBM Video
                        var videoWM =
                            attachments.FirstOrDefault(
                                b =>
                                    b.ParentMediaGuid == em.MediaGuid &&
                                    b.ContentType.ToLower().StartsWith("video/webm"));
                        if (videoWM != null && videoWM.MediaGuid != null)
                        {
                            mediaAttachment.VideoWM = GenerateMediaUrl(videoWM.MediaGuid.ToString());
                        }
                        eventModel.Medias.Add(mediaAttachment);
                    }
                }
            }

            eventModel.HistoryInfo = BuildHistoryInfo(domainEvent, eventModel, displayNamesById);

            return eventModel;
        }

        public static List<LiveIncomingAlertModel> GetLiveIncomingAlerts(IUserFacade userFacade, IEnumerable<models.Event> domainEvents, IDictionary<int, models.EventCategory> eventCategories)
        {
            var dbEvents = domainEvents as models.Event[] ?? domainEvents.ToArray();
            var displayNameById = GetDisplayNameById(userFacade, dbEvents);

            var liveIncomingAlerts = new List<LiveIncomingAlertModel>();
            foreach (var domainEvent in dbEvents)
            {
                
                models.EventCategory ec = null;
                if (domainEvent.EventCategoryId != null && !eventCategories.TryGetValue(domainEvent.EventCategoryId.Value, out ec))
                {
                    throw new Exception("Event Category not found.");
                }

                var liveIncomingAlertModel = GetLiveIncomingAlert(domainEvent, ec, displayNameById);
                liveIncomingAlerts.Add(liveIncomingAlertModel);
            }
            return liveIncomingAlerts;
        }

        private static LiveIncomingAlertModel GetLiveIncomingAlert(models.Event domainEvent, models.EventCategory eventCategory,IDictionary<int, string> displayNamesById)
        {
            var liveIncomingAlertModel = new LiveIncomingAlertModel();
            liveIncomingAlertModel.Title = domainEvent.MsgTitle;
            liveIncomingAlertModel.Id = domainEvent.EventId;
            //Concatinate all event description excluding Event_Desction_Type = "response". All events from mobile comes with empty type, we show only updates from mobile here.                     
            liveIncomingAlertModel.Description = domainEvent.MsgBody +string.Join("\n", (
                                         domainEvent.EventDescriptions.Where(a => string.IsNullOrEmpty(a.Type)).OrderByDescending(des => des.CreatedOn)
                                             .Select(e => e.Description)));

            liveIncomingAlertModel.AlertType =  eventCategory.EventCategoryType;

           
            string baseUrl = ConfigurationManager.GetURL();
            //Activity Log - Manual
            if (string.Equals(eventCategory.EventCategoryType, "LOG", StringComparison.InvariantCultureIgnoreCase))
            {
                liveIncomingAlertModel.AlertTypeIcon= Path.Combine(baseUrl, "/athoc-cdn/Images/icon-log-manual.png");
            }
            //Activity Log - Alert
            else if (string.Equals(eventCategory.EventCategoryType, "ALERT", StringComparison.InvariantCultureIgnoreCase))
            {
                liveIncomingAlertModel.AlertTypeIcon = Path.Combine(baseUrl, "/athoc-cdn/Images/icon-log-alert.png");
            }
            //HubComm event
            else if (string.Equals(eventCategory.EventCategoryType, EventModel.Constant.HubComm, StringComparison.InvariantCultureIgnoreCase))
            {
                liveIncomingAlertModel.AlertTypeIcon = Path.Combine(baseUrl, "/athoc-cdn/Images/icon-connect-32.png");
               
            }
            else
            {
                liveIncomingAlertModel.AlertTypeIcon = eventCategory.ImageId == null ? string.Empty : baseUrl + "/client/map/iconimage/" + eventCategory.ImageId;
            }

            var vpsdateFormat = RuntimeContext.Provider.GetDateTimeFormat();
            liveIncomingAlertModel.CreatedOn = domainEvent.CreatedOn.HasValue
                ? RuntimeContext.Provider.UtcToVpsTime(domainEvent.CreatedOn.Value).ToString(vpsdateFormat)
                : string.Empty;
            liveIncomingAlertModel.SourceName = domainEvent.SourceName;
            liveIncomingAlertModel.SourceType = domainEvent.SourceType;

            //TODO:Need to get priority from enum
            const int defaultPriority = 5; //5 = Unknown
            liveIncomingAlertModel.Priority = domainEvent.Priority.HasValue ? domainEvent.Priority.Value : defaultPriority;
            liveIncomingAlertModel.Latitude = domainEvent.Latitude.GetValueOrDefault();
            liveIncomingAlertModel.Longitude = domainEvent.Longitude.GetValueOrDefault();
            liveIncomingAlertModel.GeoJson = domainEvent.GeoJson;

            return liveIncomingAlertModel;
        }
        private static List<HistoryEntry> BuildHistoryInfo(models.Event domainEvent, EventModel eventModel, IDictionary<int, string> userDisaplyNameById)
        {
            // set the privious values
            Dictionary<string, string> historyTypeToLastValue = new Dictionary<string, String>();
            historyTypeToLastValue.Add(EventDescriptionType.BodyUpdate, domainEvent.MsgBody);
            historyTypeToLastValue.Add(EventDescriptionType.TitleUpdate, domainEvent.MsgTitle);
            historyTypeToLastValue.Add(EventDescriptionType.UrlUpdate, eventModel.AlertUrl);
            
            string severityStr = Severities[0];            
            if (eventModel.Priority != null)
            {
                Severities.TryGetValue(eventModel.Priority.Value, out severityStr);                 
            }                
            historyTypeToLastValue.Add(EventDescriptionType.SeverityUpdate, severityStr);           
            
            var sortedDescriptions = domainEvent.EventDescriptions.Where(a => !string.IsNullOrEmpty(a.Type) && !a.Type.Equals(EventDescriptionType.Response, StringComparison.InvariantCultureIgnoreCase))
                .OrderByDescending(des => des.CreatedOn);             

            Dictionary<long, HistoryEntry> histories = new Dictionary<long, HistoryEntry>();
            var vpsdateFormat = RuntimeContext.Provider.GetDateTimeFormat();

            // sort descriptions into entries
            foreach (var eventDescription in sortedDescriptions)
            {
                long key = eventDescription.CreatedOn.Ticks;
                HistoryEntry history;
                if (! histories.TryGetValue(key, out history))
                {
                    history = new HistoryEntry();
                    history.FieldEntries = new List<HistoryFieldEntry>();
                    histories.Add(key, history);
                    string sourceName = "";
                    if (eventDescription.SourceId != null)
                    {
                        userDisaplyNameById.TryGetValue(eventDescription.SourceId.Value, out sourceName);
                        history.SourceId = eventDescription.SourceId.Value;                        
                    }
                    history.SourceName = sourceName;
                    history.UpdatedOn = RuntimeContext.Provider.UtcToVpsTime(eventDescription.CreatedOn).ToString(vpsdateFormat);
                }
                history.FieldEntries.Add(BuildHistoryFieldEntry(historyTypeToLastValue, eventDescription));
            }

            return histories.Values.ToList();
        }

        private static HistoryFieldEntry BuildHistoryFieldEntry(Dictionary<string, string> historyTypeToLastValue, models.EventDescription desc)
        {            
            if (desc == null) return null;
            HistoryFieldEntry history = new HistoryFieldEntry();
            if (!string.IsNullOrEmpty( desc.Type))
            {                
                string fieldName = null;
                string prevFieldValue = desc.Description;
                string currentFieldValue = ""; 
                if (desc.Type.Equals(EventDescriptionType.BodyUpdate, StringComparison.InvariantCultureIgnoreCase))
                {
                    historyTypeToLastValue.TryGetValue(EventDescriptionType.BodyUpdate, out currentFieldValue);
                    historyTypeToLastValue[EventDescriptionType.BodyUpdate] = prevFieldValue;
                    fieldName = IWSResources.Event_Body;                    
                }
                if (desc.Type.Equals(EventDescriptionType.TitleUpdate, StringComparison.InvariantCultureIgnoreCase))
                {
                    historyTypeToLastValue.TryGetValue(EventDescriptionType.TitleUpdate, out currentFieldValue);
                    historyTypeToLastValue[EventDescriptionType.TitleUpdate] = prevFieldValue;
                    fieldName = IWSResources.Event_Title;
                }
                if (desc.Type.Equals(EventDescriptionType.SeverityUpdate, StringComparison.InvariantCultureIgnoreCase))
                {
                    //  need to localize this severity....
                    prevFieldValue = desc.Description;                    
                    try
                    {
                        string severityStr = "";
                        Severities.TryGetValue(int.Parse(desc.Description), out severityStr);
                        {
                            prevFieldValue = severityStr;
                        }
                    }
                    catch (Exception e)
                    {
//                        EventLogger.writeError
                    }
                    historyTypeToLastValue.TryGetValue(EventDescriptionType.SeverityUpdate, out currentFieldValue);
                    historyTypeToLastValue[EventDescriptionType.SeverityUpdate] = prevFieldValue;
                    fieldName = IWSResources.Event_Severity;
                }
                if (desc.Type.Equals(EventDescriptionType.UrlUpdate, StringComparison.InvariantCultureIgnoreCase))
                {
                    fieldName = IWSResources.Event_Create_Log_Addotional_Link_Text;
                    prevFieldValue = desc.Description;
                    historyTypeToLastValue.TryGetValue(EventDescriptionType.UrlUpdate, out currentFieldValue);
                    historyTypeToLastValue[EventDescriptionType.UrlUpdate] = prevFieldValue;
                }
                                
                history.FieldName = fieldName;
                history.NewValue = currentFieldValue;
                history.OldValue = prevFieldValue;
            }
            
            return history;
        }

        public static string GetSeverityText(int priority)
        {
            string tempSeverityString;
            Severities.TryGetValue(priority, out tempSeverityString);

            return tempSeverityString;
        }

        /// <summary>
        /// Get Media URL
        /// </summary>
        /// <param name="attachment">filename</param>
        /// <returns>Return complete URL of Media file</returns>
        private static string GenerateMediaUrl(string attachment)
        {
#if DEBUG
            return string.Format("http://localhost/client/media/get/" + attachment);
#else
            return ConfigurationManager.GetURL() + "/client/media/get/" + attachment;
#endif
        }


        /// <summary>
        /// Get Event Category Type
        /// </summary>
        /// <param name="eventCategories"></param>
        /// <returns></returns>
        public static IEnumerable<dynamic> GenerateEventCategoryModel(List<models.EventCategory> eventCategories)
        {
            
            var evtCategories = from s in eventCategories
                              
                                select new models.EventCategory()
                                {
                                    EventCategoryId = s.EventCategoryId,
                                    Name = s.EventCategoryType == EventModel.Constant.HubComm ? (s.LogicalId=="Invite"?"Request":s.LogicalId) : s.Name,
                                    EventCategoryType = s.EventCategoryType == EventModel.Constant.HubComm ? EventModel.Constant.ConnectUpdates : s.EventCategoryType,
                                    ImageId = s.ImageId
                                };

            //ConfigurationManager.GetURL() + "/athoc-cdn/Images/icon-connect-32.png";
            var groups = evtCategories.GroupBy(g => g.EventCategoryType).Select(grp => new
            {
                CategoryType = grp.Key, 
                Items = grp.Select(
                    s => new
                    {
                        EventCategoryId = s.EventCategoryId, 
                        Name = s.Name, 
                        EventCategoryType = s.EventCategoryType,
                        ImageId = s.EventCategoryType ==EventModel.Constant.ConnectUpdates
                            ? ConfigurationManager.GetURL() + "/athoc-cdn/Images/icon-connect-32.png"
                            :ConfigurationManager.GetURL() + "/client/map/iconimage/" + s.ImageId.ToString()
                    })
            });
            return groups;
        }

        /// <summary>
        /// Get Response option from response xml
        /// </summary>
        /// <param name="additionalInfo"></param>
        /// <returns></returns>
        public static object GetResponseOption(Dictionary<OrganizationEventCustomAttrIds, string> additionalInfo)
        {
            /*var xmlDoc1 = new XmlDocument();
            xmlDoc1.LoadXml(responseXML);
            var root = XElement.Parse(responseXML);
            var matchingNode =
                root.Descendants().Where(i => i.Name == "CommonName" && String.Equals(i.Value, OrganizationEventCustomAttrIds.ResponseOptions.Description(), StringComparison.InvariantCultureIgnoreCase)).Select(i => i.Parent);
            var responseValue = matchingNode.Descendants().Where(i => i.Name == "Value").FirstOrDefault();*/
            var responseValue = GetAdditionalDataItemValue(additionalInfo, OrganizationEventCustomAttrIds.ResponseOptions);
            if (!string.IsNullOrEmpty(responseValue))
            {
                return GetEventResponseOptions(responseValue);
            }
            else
            {
                return null;
            }

        }



        /// <summary>
        /// Get JSON of response option values
        /// </summary>
        /// <param name="jsonString"></param>
        /// <returns></returns>
        private static object GetEventResponseOptions(string jsonString)
        {
            var jsonSerializer = new JavaScriptSerializer();
            var evtResponseOptions = jsonSerializer.Deserialize<IEnumerable<EventResponseOption>>(jsonString);
            return evtResponseOptions;
        }

        public static string GetAdditionalDataItemValue(Dictionary<OrganizationEventCustomAttrIds, string> additionalAttributes, OrganizationEventCustomAttrIds key)
        {
            string value = null;
            if (additionalAttributes.TryGetValue(key, out value))
            {
                return value;
            }

            return null;
        }

        public static string GetDeliveryContext(Dictionary<OrganizationEventCustomAttrIds, string> additionalInfo)
        {      
            return GetAdditionalDataItemValue(additionalInfo, OrganizationEventCustomAttrIds.DeliveryContext);            
        }
        #endregion
    }


    public class EventDetail
    {
        //public EventSource Source { get; set; }
        public DateTime? Time { get; set; } //: Time, //updated_on in detail tab
        public String Description { get; set; }  //: "I'm coming", //conversation in detail tab
        public EventAttachment Attachment { get; set; }
        public EventGeoGraphic GeoGraphic { get; set; }
    }

    /// <summary>
    /// Event attachment ViewModel
    /// </summary>
    public class EventAttachment
    {
        /// <summary>
        /// Thumbnail Image for image/videos (Description contains "small" in database.
        /// </summary>
        public string ThumbnailImage { get; set; }

        /// <summary>
        /// Medium size image only available for contentType = Image
        /// </summary>
        public string MediumImage { get; set; }
        /// <summary>
        /// OriginalImage only available for content Type = Image
        /// </summary>
        public string OriginalImage { get; set; }

        /// <summary>
        /// Content Type of Media
        /// </summary>
        public string ContentType { get; set; }

        /// <summary>
        /// Video Type = MPEG only available for content Type Video
        /// </summary>
        public string VideoMpeg { get; set; }
        /// <summary>
        /// MP4 Video only available for content Type Video
        /// </summary>
        public string VideoMP4 { get; set; }

        /// <summary>
        /// Quick Time Video only available for content Type Video
        /// </summary>
        public string VideoQT { get; set; }

        /// <summary>
        /// WM video Type only available for content Type Video
        /// </summary>
        public string VideoWM { get; set; }

        /// <summary>
        /// Original Height Of Media
        /// </summary>
        public int OriginalHeight { get; set; }

        /// <summary>
        /// Original Width of Media
        /// </summary>
        public int OriginalWidth { get; set; }

        /// <summary>
        /// Rotation value for Video
        /// </summary>
        public int Rotation { get; set; }

        /// <summary>
        /// Media Created On (Formated String)
        /// </summary>
        public string CreatedOn { get; set; }
    }

    public enum MediaType
    {
        Image,
        Video,
        Text
    }

    public enum MediaSize
    {
        Orginial,
        Small,
        Medium
    }
    public class EventGeoGraphic
    {
        public string Geometry { get; set; }
        //:"POINT(-120 37) convert geoInfo(geometry type) in detail tab to WKT by calling AsTextZM. http://msdn.microsoft.com/en-us/library/microsoft.sqlserver.types.sqlgeometry_methods.aspx
        public string Symbol { get; set; } //null //GeoSymbol in detail tab
    }

    public class HistoryEntry
    {
        public int SourceId { get; set; }
        public string SourceName { get; set; }
        public string UpdatedOn { get; set; }
        public List<HistoryFieldEntry> FieldEntries { get; set; }
    }

    public class HistoryFieldEntry
    {
        public string FieldName { get; set; }
        public string OldValue { get; set; }
        public string NewValue { get; set; }                
    }
}