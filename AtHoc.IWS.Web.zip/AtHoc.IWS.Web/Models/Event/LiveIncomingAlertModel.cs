﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AtHoc.IWS.Web.Models.Event
{
    public class LiveIncomingAlertModel
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string AlertType { get; set; }
        public string AlertTypeIcon { get; set; }
        public string CreatedOn { get; set; }
        public string SourceName { get; set; }

        public string SourceType { get; set; }
        public int Priority { get; set; }

        public string GeoJson { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
    }
}