﻿using System.Collections.Generic;

namespace AtHoc.IWS.Web.Models.Event
{
    /// <summary>
    /// Viewmodel for Inbox view.
    /// </summary>
    public class InboxViewModel
    {
        /// <summary>
        /// List of Events after filter (If filter parameter provided)
        /// </summary>
        public IList<EventModel> Events { get; set; }

        /// <summary>
        /// Total number of Events before filter.
        /// </summary>
        public int TotalEvent { get; set; }
    }
}