﻿
namespace AtHoc.IWS.Web.Models.Report
{
    public class ReportItem
    {
        public int? ID { get; set; }
        public string Category { get; set; }
        public int Value { get; set; }
        /// <summary>
        /// For plotting the bar chart
        /// </summary>
        public double NormalizedValue { get; set; }
        public FillCountItem FillCount { get; set; }
        /// <summary>
        /// This field is used for the RBT parameter
        /// </summary>
        public string RecipientType { get; set; }
    }

    public class FillCountItem
    {
        public bool IsAnyFillCount { get; set; }
        /// <summary>
        /// Fill Count #
        /// </summary>
        public int FillCount { get; set; }
        /// <summary>
        /// Above Fill Count #
        /// </summary>
        public int AboveFillCount { get; set; }

    }
}