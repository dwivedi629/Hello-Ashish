﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AtHoc.IWS.Web.Models.DistributionLists
{
    public class DistributionListCriteria
    {
        public int Page { get; set; }
        public int PageSize { get; set; }
        public string OrderBy { get; set; }
        public bool OrderAsc { get; set; }
        public int[] DistributionListTypes { get; set; }
        public string SearchString { get; set; }
        public int[] ListIds { get; set; }
        public bool IsInclude { get; set; }
        public int CurrentId { get; set; }
    }
}