﻿using System.Collections.Generic;

using AtHoc.IWS.Web.Models.SearchCriteria;

namespace AtHoc.IWS.Web.Models.DistributionLists
{
	public class DistributionModel
	{
		public int Id { get; set; }

		public string Name { get; set; }

		public string CommonName { get; set; }

		public string Description { get; set; }

		public int EditLevel { get; set; }

		public int ListType { get; set; }

		public string ListTypeDisplay { get; set; }

		public int UserCount { get; set; }

        public int TotalUsersCount { get; set; }

        public int UserBaseCount { get; set; }

		public string Lineage { get; set; }

		public int[] Nested { get; set; }

		public List<int> Users { get; set; }

		public dynamic IPList { get; set; }

		public SearchCriteriaModel DynamicCriteria { get; set; }

		public string UpdatedBy { get; set; }

		public string CreatedBy { get; set; }

		public string UpdatedOn { get; set; }

		public string CreatedOn { get; set; }

		public int TotalUsers { get; set; }

		public string IPAddressesCSV { get; set; }

		public bool IsCascaded { get; set; }

		public int TemporaryStaticDLId { get; set; }
	    public int NotNestedCount { get; set; }

        public string IsAvailableForMap { get; set; }

	    public int GetStaticListIdToSave()
		{
			return TemporaryStaticDLId != 0 ? TemporaryStaticDLId : Id;
		}

        public bool ShowOverrideWarning { get; set; }
	}
}