﻿using System;
using System.Collections.Generic;
using AtHoc.d911.Model.Organization;
using AtHoc.IWS.Business.Context;
using AtHoc.Global.Resources;

namespace AtHoc.IWS.Web.Models.Organization
{
    public class ConnectModel
    {
        public List<OrganizationModel> Organizations { set; get; }
        public List<AgreementModel> Agreements { set; get; }
        public List<InvitationModel> Invitations { set; get; }        
        public List<string> GridOrganizationIds { set; get; }
        public int GridTotalCount { set; get; }
        public List<MessageModel> Messages { set; get; }

        public List<InvitationModel> ExternalInvitations { get; set; }

        public string ProviderDateFormat { get; set; }
    }    

    public class AgreementModel
    {
        public AgreementModel(OrganizationAgreementInfoModel agreementInfoModel, string sectorName)
        {
            Id = agreementInfoModel.Id;
            Guid = agreementInfoModel.OtherOrganizationGuid;
            IsSend = agreementInfoModel.IsSend;
            IsRecv = agreementInfoModel.IsReceive;
            SectorName = sectorName;
        }
        public int Id { set; get; }         
        public string Guid { set; get; }        
        public string SectorName { set; get; }        
        public bool IsSend { get; set; }
        public bool IsRecv { get; set; }
    }
    public class InvitationModel
    {

        public InvitationModel(string selfGuid, OrganizationInvitationInfoModel invitationInfoModel)
        {
            IsSelfInviter = invitationInfoModel.InviterOrganizationGuid.Equals(selfGuid, StringComparison.InvariantCultureIgnoreCase);
            Id = invitationInfoModel.Id;
            IsSend = IsSelfInviter ? invitationInfoModel.IsSend : invitationInfoModel.IsReceive;
            IsRecv = IsSelfInviter ? invitationInfoModel.IsReceive : invitationInfoModel.IsSend;
            Message = invitationInfoModel.Message;
            Status = invitationInfoModel.Status;            
            OtherOrgGuid = IsSelfInviter ? invitationInfoModel.InviteeOrganizationGuid : invitationInfoModel.InviterOrganizationGuid;
            InviteeEmail = invitationInfoModel.InviteeEmail ?? string.Empty;
            OrganizationName = invitationInfoModel.OrganizationName ?? string.Empty;
            SenderName = invitationInfoModel.SenderName ?? string.Empty;
            UpdatedOn = RuntimeContext.Provider.UtcToVpsTime(invitationInfoModel.UpdatedOn);
            //StatusString is only used for SentInvitation
            StatusString = GetOrganizationInvitationStatusDisplay(Status);
            ContactName = invitationInfoModel.ContactName ?? string.Empty;
           
        }

        private string GetOrganizationInvitationStatusDisplay(OrganizationInvitationStatus status)
        {
            switch (status)
            {
                case OrganizationInvitationStatus.Pending:
                    return IWSResources.Organization_SentInvitation_Status_Pending;
                case OrganizationInvitationStatus.Accepted:
                    return IWSResources.Organization_SentInvitation_Status_Accepted;
                case OrganizationInvitationStatus.Declined:
                    return IWSResources.Organization_SentInvitation_Status_Declined;
                case OrganizationInvitationStatus.Cancelled:
                    return IWSResources.Organization_SentInvitation_Status_Cancelled;
                case OrganizationInvitationStatus.Connected:
                    return IWSResources.Organization_SentInvitation_Status_Connected;
                case OrganizationInvitationStatus.UnConnected:
                    return IWSResources.Organization_SentInvitation_Status_Unconnected;
                case OrganizationInvitationStatus.Failed:
                    return IWSResources.Organization_SentInvitation_Status_Failed;
                case OrganizationInvitationStatus.Expired:
                    return IWSResources.Organization_SentInvitation_Status_Expired;
                default:
                    throw new ArgumentOutOfRangeException("status");
            }
        }
        public int Id { set; get; }
        public bool IsSelfInviter { get; set; }
        public string OtherOrgGuid { get; set; }                  
        public OrganizationInvitationStatus Status { set; get; }
        public bool IsSend { get; set; }
        public bool IsRecv { get; set; }
        public string Message { get; set; }

        public string InviteeEmail { get; private set; }

        public string SenderName { get; private set; }

        public string OrganizationName { get; private set; }

        public DateTime UpdatedOn { get; private set; }

        public string StatusString { get;  set; }

        public string ContactName { get; private set; }

    }


    public class MessageModel
    {
        public MessageModel(OrganizationMessageInfo messageInfo)
        {
            Id = messageInfo.Id;
            OtherOrganizationGuid = messageInfo.CreatedBy;
            Message = messageInfo.Message;
            ContextType = messageInfo.ContextType;
            ContextId = messageInfo.ContextId;
            ContextSubType = messageInfo.ContextSubType;
            CreatedOnUtc = messageInfo.CreatedOn;
            CreatedOnVpsTime = RuntimeContext.Provider.UtcToVpsTime(messageInfo.CreatedOn).ToString(RuntimeContext.Provider.GetDateTimeFormat());            
        }

        public int Id { get; set; }
        public string OtherOrganizationGuid { get; set; }
        public string Message { get; set; }
        public OrganizationMessageInfo.MessageContextType ContextType { get; set; }

        public int ContextId { get; set; }
        public OrganizationMessageInfo.MessageContextSubType ContextSubType { get; set; }

        public DateTime CreatedOnUtc { get; set; }
        public string CreatedOnVpsTime { get; set; }
    }
}