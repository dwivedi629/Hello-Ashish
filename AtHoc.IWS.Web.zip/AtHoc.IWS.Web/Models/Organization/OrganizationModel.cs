﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AtHoc.d911.Model.Organization;
using System.Data.Entity.Spatial;

namespace AtHoc.IWS.Web.Models.Organization
{
    public class OrganizationModel : OrganizationInfo
    {
        public OrganizationModel(OrganizationInfo organizationInfo)
        {
            ContactInfo = organizationInfo.ContactInfo;
            Description = string.IsNullOrEmpty(organizationInfo.Description) ? string.Empty : organizationInfo.Description;
            Guid = organizationInfo.Guid;
            LogoVersion = organizationInfo.LogoVersion;
            Name = organizationInfo.Name;
            OrganizationSector = organizationInfo.OrganizationSector;
            PhysicalAddress = organizationInfo.PhysicalAddress;
            Sector = organizationInfo.Sector;
            Url = organizationInfo.Url;
            NodeType = organizationInfo.NodeType;

            if (!string.IsNullOrEmpty(organizationInfo.Location))
            {
                try
                {                    
                    DbGeography dbLocation = DbGeography.FromText(organizationInfo.Location);
                    Latitude = dbLocation.Latitude;
                    Longitude = dbLocation.Longitude;                     
                }
                catch (Exception ex)
                {

                }
            }            
        }
        public double? Latitude { set; get; }
        public double? Longitude { set; get; }
    }
}