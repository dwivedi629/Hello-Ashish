﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AtHoc.IWS.Web.Models.Publishing
{
    public class InboxEvent
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public string Url { get; set; }
        public string GeoJson { get; set; }
        public int SeverityId { get; set; }
        public string Severity { get; set; }

        [Obsolete("Instead use EventCategoryId. ")]
        public int TypeId { get; set; }
        public string Type { get; set; }
        public int EventCategoryId { get; set; }
    }
}