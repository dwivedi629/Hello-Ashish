﻿using System.Diagnostics.Eventing.Reader;
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Targeting.Model;
using System.Collections.Generic;
using AtHoc.IWS.Business.Domain.Users.Search;
using System.Linq;
using System;
using AtHoc.Publishing;
using AtHoc.IWS.Web.Models.SearchCriteria;
using AtHoc.Publishing.Configuration;
using AtHoc.IWS.Business.Domain.Targeting.Impl;
using AtHoc.Publishing.Entity;
using AtHoc.IWS.Business.Context;
using AtHoc.Utilities;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;

namespace AtHoc.IWS.Web.Models.Publishing
{
    public enum PublishingContext
    {
        Alert,
        Scenario,
        AccountEvent,
        AccountTemplate
    }

    public enum PublishingOrigin
    {
        AlertDetail, //AlertDetail is origin from edit alert screen
        ScenarioPublisher, //ScenarioPublisher is origin from home page or scenario publisher
        AlertManager, //AlertManager is origin from Alert list screen
    }

    public class PublisherSettings
    {
        public bool IsGroupBlockSupported { get; set; }
        public bool IsAdvancedQuerySuuported { get; set; }
        public bool IsIndividualUserTargetingSupported { get; set; }
        public bool IsTargetByAreaSupported { get; set; }
        public bool IsDropboxSupported { get; set; }
        public bool IsMassDeviceTargetSupported { get; set; }
        public bool IsCallbridgeOptionSupported { get; set; }
        public bool IsLyncEnabled { get; set; }
        public bool IsSchedulingSupported { get; set; }
        public bool IsTestAlertSupported { get; set; }
        public bool IsPrintAlertSupported { get; set; }
        public bool IsDeviceOptionSupported { get; set; }
        public bool IsAlertTemplateSettingSupported { get; set; }
        public bool IsPlaceholderSupported { get; set; }
        public bool IsDeviceDeliveryOrderSupported { get; set; }
        public bool IsChannelSupported { get; set; }
        public int IndividualUserTargetSelectionLimit { get; set; }
        public bool IsOrgHierarchySupported { get; set; }
        public bool IsRecordedAudioSupported { get; set; }
        public bool IsFillCountSupported { get; set; }
        public bool EnableDeviceOptionCache { get; set; }
    }

    public class PublishingModel
    {
        public PublishingModel()
        {
            Content = new PublishingContent();
            ScenarioSection = new ScenarioSection();
            TargetUsers = new TargetUsers();
            TargetOrg = new TargetOrg();
            DeviceList = new List<Device>();
            MassDevices = new List<Device>();
            AllPlaceHolderIds = new List<int>();
            MassDeviceGroupOptions = new List<DeviceGroupOptions>();
        }

        /// <summary>
        /// Origin from where the publisher is publishing scenario
        /// </summary>
        public PublishingOrigin Origin { get; set; }

        public OriginType AlertOrigin { get; set; }
        public int EntityId { get; set; }
        public int ParentId { get; set; }
        public bool IsReadyToPublish { get; set; }
        public ScenarioSection ScenarioSection { get; set; }
        public PublishingContent Content { get; set; }
        public TargetUsers TargetUsers { get; set; }
        public IList<Device> DeviceList { get; set; }
        public IList<DeviceAddress> TestDeviceList { get; set; }
        public IList<Device> MassDevices { get; set; }

        public List<DeviceGroupOptions> MassDeviceGroupOptions { get; set; }

        public List<int> AllPlaceHolderIds { get; set; }

        public PublishingContext Context { get; set; }
        public string ContextName { get { return Context.ToString(); } }
        public ScenarioInfo ScenarioInfo { get; set; }
        public ScenarioSettings ScenarioSettings { get; set; }
        public TargetOrg TargetOrg { get; set; }
        public String AlertStatus { get; set; }
        public ScheduleModel ScenarioScheduleSettings { get; set; }
        public AlertScheduleModel AlertScheduleSettings { get; set; }
        public List<DeviceGroupPresetOptions> PresetDeviceGroupOptions { get; set; }
        public List<DeviceGroupOptions> PresetDeviceGroupOption { get; set; }

        public List<PlaceHolder> CustomPlaceHolders { get; set; }

        public IList<Node> TargetingTree { get; set; }
        public bool IsTestAlertSupportOperator { get; set; }

        public ResultBasedTargeting rbt { get; set; }

        public AlertFillCountSpec FillCount { get; set; }

        public IList<KeyValueModel> EscalationAttributes
        {
            get
            {
                var customAttributes = new CustomAttributeCache();

                var ret = from ca in customAttributes.Get(RuntimeContext.ProviderId, RuntimeContext.Provider.BaseLocale, true, true) //this property is retrived from a cache...
                          where ca.IsSystemAttribute == "N" && ca.AttributeTypeId != CustomAttributeDataType.GeoLocation
                                && ca.AttributeTypeId != CustomAttributeDataType.Memo && (ca.EntityId.ToUpper() != CustomAttributeType.Placeholder.ToString().ToUpper())
                          orderby ca.AttributeName
                          select new KeyValueModel
                          {
                              Id = ca.Id,
                              Name = ca.AttributeName,
                              Values = (ca.AttributeTypeId == CustomAttributeDataType.MultiPicklist || ca.AttributeTypeId == CustomAttributeDataType.Picklist) ? (ca.Values.HasValue() ? ca.Values.Select(v => v.ValueName).ToList() : null) : null
                          };


                return ret.ToList();
            }
        }

        public IList<KeyValueModel> SequencingAttributes
        {
            get { return new List<KeyValueModel>(); }
        }


    }

    public class ScenarioSection
    {
        public string Name { get; set; }
        public string CommonName { get; set; }
        public bool AvailableForQuickPublish { get; set; }
        public string Description { get; set; }
        public bool IsSystemScenario { get; set; }
        public int ChannelId { get; set; }
    }

    public class ScenarioInfo
    {
        public string CreatedBy { get; set; }
        public string CreatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedOn { get; set; }
    }

    public class ScenarioSettings
    {
        public ScenarioSettings()
        {
            Content = new ContentSettings();
            Advanced = new AdvancedSettings();
            Organization = new OrganizationSettings();
            Delivery = new DeliverySettings();
            Targeting = new TargettingSettings();
            AccountabilityWorkflow = new AccountabilityWorkflowSettings();
        }

        public int Id { get; internal set; }
        public ContentSettings Content { get; set; }
        public AdvancedSettings Advanced { get; set; }
        public OrganizationSettings Organization { get; set; }
        public DeliverySettings Delivery { get; set; }
        public TargettingSettings Targeting { get; set; }

        public AccountabilityWorkflowSettings AccountabilityWorkflow { get; set; }
        public AccountabilityOfficerSectionConfiguration AccountabilityOfficer { get; set; }
        public List<Device> PersonalDeviceList { get; set; }
        public List<Device> MassDeviceList { get; set; }
    }

    public class ContentSettings
    {
        public bool ResponseOptionEnabled { get; set; }
        public bool LocationEnabled { get; set; }
        public bool LocationMandatoryEnabled { get; set; }
        public bool DropboxEnabled { get; set; }
        public string Visible { get; set; }
        public bool Readonly { get; set; }
        public bool Collapsed { get; set; }
    }

    public class AdvancedSettings
    {
        public string Visible { get; set; }
        public bool Readonly { get; set; }
        public bool Collapsed { get; set; }
    }

    public class OrganizationSettings
    {
        public bool TargetByAreaEnabled { get; set; }
        public bool TargetByNameEnabled { get; set; }
        public string Visible { get; set; }
        public bool Readonly { get; set; }
        public bool Collapsed { get; set; }
    }

    public class AccountabilityWorkflowSettings
    {
        /// <summary>
        /// 
        /// </summary>
        public bool IsContentSeverityVisible { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public bool IsContentTypeVisible { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public bool IsAccountabilityMessagesReadonly { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public bool IsAccountabilityMessagesCollapsed { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public bool IsAccountabilityMessagesVisible { get; set; }
    }

    public class DeliverySettings
    {
        public List<int> EnabledDevices { get; set; }
        public string Visible { get; set; }
        public bool Readonly { get; set; }
        public bool Collapsed { get; set; }
        public bool EnableMassDevices { get; set; }
    }

    public class TargettingSettings
    {
        public bool EnablePersonalDevices { get; set; }
        public string Visible { get; set; }
        public bool Readonly { get; set; }
        public bool Collapsed { get; set; }
        public bool FillCount { get; set; }
        public List<AtHoc.Targeting.TargetingType> EnabledTargetingTypes { get; set; }
    }

    public class PublishingContent
    {
        public PublishingContent()
        {
            Severities = new List<KeyValueModel>();
            Channels = new List<KeyValueModel>();
            Types = new List<KeyValueModel>();
            Languages = new List<LanguageModel>();
            ResponseOptionList = new List<KeyValueModel>();
            ResponseOptions = new List<ResponseOption>();
        }

        public int SeverityId { get; set; }

        public string SeverityName { get; set; }

        public IList<KeyValueModel> Severities { get; set; }

        public IList<KeyValueModel> Channels { get; set; }

        public IList<KeyValueModel> Types { get; set; }

        public IList<LanguageModel> Languages { get; set; }

        public string Title { get; set; }

        public string Body { get; set; }

        public string TargetUrl { get; set; }

        public int TypeId { get; set; }

        public KeyValueModel CategoryType { get; set; }

        public string TypeName { get; set; }

        /// <summary>
        /// This is the selected language for the alert
        /// </summary>
        public string Local { get; set; }

        public int ResponseOptionId { get; set; }

        /// <summary>
        /// This is the actual responses
        /// </summary>
        public IList<ResponseOption> ResponseOptions { get; set; }

        /// <summary>
        /// This is the response option list (dropdown)
        /// </summary>
        public IList<KeyValueModel> ResponseOptionList { get; set; }

        public string LocationGeo { get; set; }
    }

    public class TargetUsers
    {
        public TargetUsers()
        {
            TargetingNodes = new List<Node>();
            Devices = new List<Device>();
            DeviceGroupOptions = new List<DeviceGroupOptions>();

        }

        public IList<Node> TargetingNodes { get; set; }

        public IList<UserNode> TargetedBlockedUsers { get; set; }

        public IEnumerable<Device> Devices { get; set; }

        public int MaxDelivery { get; set; }

        //this is used for save purpose. 
        public List<DeviceGroupOptions> DeviceGroupOptions { get; set; }


        public int TargetedUserCountForLiveEndedAlert { get; set; }

        public SearchCriteriaModel TargetedCriteria { get; set; }

        public bool TargetUsersByArea { get; set; }
    }

    public class DeviceGroup
    {
        public int GroupId { get; set; }

        public string GroupName { get; set; }
    }


    public class Device
    {
        public int DeviceId { get; set; }
        public string DeviceName { get; set; }

        public string CommonName { get; set; }

        public int? GroupId { get; set; }
        public string GroupName { get; set; }
        public string GroupCommonName { get; set; }
        public bool Selected { get; set; }
        public decimal Reach { get; set; }

        private bool _hideInReadOnlyView = false;

        public bool HideInReadOnlyView
        {
            get { return _hideInReadOnlyView; }
            set { _hideInReadOnlyView = value; }
        }
        public bool GroupChange { get; set; }
        public string Address { get; set; }
        public bool Enabled { get; set; }
        public int DeliveryOrder { get; set; }
        public string WarningText { get; set; }

        private bool _hideMassDeviceUsers = false;

        public bool HideMassDeviceUsers
        {
            get { return _hideMassDeviceUsers; }
            set { _hideMassDeviceUsers = value; }
        }

        private bool _isAreaRequired = false;

        public bool IsAreaRequired
        {
            get { return _isAreaRequired; }
            set { _isAreaRequired = value; }
        }

        private bool _extractFIPS = false;

        public bool ExtractFIPS
        {
            get { return _extractFIPS; }
            set { _extractFIPS = value; }
        }

        private IList<MassDeviceTargetingEndPoint> endPoints = new List<MassDeviceTargetingEndPoint>();
        public IList<MassDeviceTargetingEndPoint> EndPoints
        {
            get { return endPoints; }
            set { endPoints = value; }
        }

        private IList<int> selectedUsers = new List<int>();
        public IList<int> SelectedUsers
        {
            get { return selectedUsers; }
            set { selectedUsers = value; }
        }

        public bool IsKeyUserTargetted
        {
            get;
            set;
        }

        //Property for showing custom text on Review and publish
        // changing stirng to object so that no other modal will impact.Some case need string and some case collections
        public object CustomText { get; set; }

        //property for recorded message
        public object RecordedMessage { get; set; }

        public bool IsPhone { get; set; }
    }


    public class DeviceEndPoints
    {
        public int DeviceId { get; set; }


        public string CommonName { get; set; }

        private IList<MassDeviceTargetingEndPoint> endPoints = new List<MassDeviceTargetingEndPoint>();
        public IList<MassDeviceTargetingEndPoint> EndPoints
        {
            get { return endPoints; }
            set { endPoints = value; }
        }
        private bool _hideMassDeviceUsers = false;

        public bool HideMassDeviceUsers
        {
            get { return _hideMassDeviceUsers; }
            set { _hideMassDeviceUsers = value; }
        }

        private bool _isAreaRequired = false;

        public bool IsAreaRequired
        {
            get { return _isAreaRequired; }
            set { _isAreaRequired = value; }
        }

        private bool _extractFIPS = false;

        public bool ExtractFIPS
        {
            get { return _extractFIPS; }
            set { _extractFIPS = value; }
        }
        public bool Enabled { get; set; }
    }
    public class MassDeviceTargetingEndPoint
    {
        private bool _isVisible = true;
        public int UserId { get; set; }
        public string UserName { get; set; }

        public bool IsKeyUser { get; set; }

        public bool IsTargetable { get; set; }

        public bool IsSelected { get; set; }

        public bool IsVisible
        {
            get { return _isVisible; }
            set { _isVisible = value; }
        }


    }


    public class DeviceAddress
    {
        public int UserId { get; set; }
        public int AddressId { get; set; }
        public int DeviceId { get; set; }
        public string Address { get; set; }
    }

    public class TargetOrg
    {
        public TargetOrg()
        {
            TargetedOrganizations = new List<TargetableOrganization>();
        }

        public IList<TargetableOrganization> TargetedOrganizations { get; set; }

        //Field to indicate flag for targeting all organizations
        public bool TargetAllOrganizations { get; set; }

        //Indicates if to target by area for organization or not
        public bool TargetOrganizationsByArea { get; set; }
    }

    public class KeyValueModel
    {
        public KeyValueModel()
        {
            Values = new List<string>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string LogicalId { get; set; }

        public IList<string> Values { get; set; }
    }

    public class MultiSelectListModel
    {

        public string Text { get; set; }

        public string Value { get; set; }
    }

    public class DeviceGroupOptions
    {
        public int GroupId { get; set; }

        public int DeviceId { get; set; }
        public List<DeviceGroupOptionKeyValue> Options { get; set; }

    }

    public class MassDeviceUser
    {
        public int Id { get; set; }
        public string Name { get; set; }

    }
    public class DeviceGroupOptionKeyValue
    {
        public string Name { get; set; }
        public string Value { get; set; }
    }

    public class DeviceGroupPresetOptions
    {
        public int Id { get; set; }
        public string selection { get; set; }
        public int GroupId { get; set; }

    }

    public class ResponseOption
    {
        public ResponseOption()
        {
            ResponseText = string.Empty;
            CallBridgeNumber = string.Empty;
            PassCode = string.Empty;
            ConferenceUrl = string.Empty;
        }

        public string ResponseText { get; set; }
        public bool ShowCallBridge
        {
            get
            {
                return !string.IsNullOrEmpty(CallBridgeNumber) || !string.IsNullOrEmpty(PassCode) ||
                       !string.IsNullOrEmpty(ConferenceUrl);
            }
        }
        public string CallBridgeNumber { get; set; }
        public string PassCode { get; set; }
        public string ConferenceUrl { get; set; }
    }

    public class LanguageModel
    {
        public string Code { get; set; }
        public string Name { get; set; }
        public string DisplayCode { get; set; }
    }

    public class TargetedUserCriteria
    {
        private List<Node> _targetedNodes;
        private List<Node> _blockedNodes;
        public SearchCriteriaModel TargetedCriteria { get; set; }
        public List<Node> SelectedTreeNodes { get; set; }
        private List<int> _blockedUsers = new List<int>();
        private List<int> _targetedUsers = new List<int>();
        private string _targetedArea = string.Empty;
        public ResultBasedTargeting rbtCriteria { get; set; }


        public TargetedUserCriteria()
        {
            SelectedTreeNodes = new List<Node>();
        }
        /// <summary>
        /// Users that are blocked
        /// </summary>
        public List<int> BlockedUsers
        {
            get { return _blockedUsers; }
            set { _blockedUsers = value; }
        }

        /// <summary>
        /// Targeted Users that are unblocked
        /// </summary>
        public List<int> TargetedUsers
        {
            get { return _targetedUsers; }
            set { _targetedUsers = value; }
        }
        /// <summary>
        /// Geojson representation of Targeted Area
        /// </summary>
        public string TargetedArea
        {
            get { return _targetedArea; }
            set { _targetedArea = value; }
        }



        public List<Node> TargetedTreeNodes
        {
            get
            {
                _targetedNodes = _targetedNodes ?? SelectedTreeNodes.Where(n => !n.IsBlocked).ToList();
                return _targetedNodes;
            }
        }

        public List<Node> BlockedTreeNodes
        {
            get
            {
                _blockedNodes = _blockedNodes ?? SelectedTreeNodes.Where(n => n.IsBlocked).ToList();
                return _blockedNodes;
            }
        }

        private List<int> _selectedDevices = new List<int>();

        private List<int> _listIds = new List<int>();


        private int _entityId = 0;

        private PublishingContext _publishingContext = PublishingContext.Alert;

        public void ResetCriteria()
        {
            SelectedTreeNodes = new List<Node>();
            _selectedDevices = new List<int>();
            _listIds = new List<int>();
            _attributes = new List<GenericCriteria>();
            _hierarchyIds = new List<int>();
            _isAllUserBaseSelected = false;
        }

        public PublishingContext PublishingContext
        {
            get { return _publishingContext; }
            set { _publishingContext = value; }
        }


        public int EntityId
        {
            get { return _entityId; }
            set { _entityId = value; }
        }

        public List<int> SelectedDevices
        {
            get { return _selectedDevices; }
            set { _selectedDevices = value; }
        }

        public List<int> TargetedListIds
        {

            get
            {
                if (TargetedTreeNodes != null)
                {
                    _listIds = (from tn in TargetedTreeNodes
                                where tn.Type == NodeType.DistributionList || tn.Type == NodeType.Folder
                                select tn.Id).ToList();
                }
                return _listIds;
            }
            set { _listIds = value; }
        }

        public List<int> BlockedListIds
        {
            get
            {
                if (BlockedTreeNodes != null)
                    return (from tn in BlockedTreeNodes
                            where tn.Type == NodeType.DistributionList || tn.Type == NodeType.Folder
                            select tn.Id).ToList();
                return new List<int>();
            }
        }

        private List<GenericCriteria> _attributes =
            new List<GenericCriteria>();

        public List<GenericCriteria> TargetedAttributes
        {
            get
            {
                if (TargetedTreeNodes != null)
                {
                    _attributes = getAttributes(TargetedTreeNodes);
                }

                return _attributes;
            }
            set { _attributes = value; }
        }

        public List<GenericCriteria> BlockedAttributes
        {
            get { return getAttributes(BlockedTreeNodes); }
        }

        private List<GenericCriteria> getAttributes(List<Node> nodes)
        {
            var ret = new List<GenericCriteria>();

            if (nodes == null)
                return ret;

            foreach (var treeNode in nodes)
            {
                if (treeNode.Type == NodeType.CustomAttribute)
                {
                    ret.Add(new AttributeCriteria(treeNode.Id,
                        CriteriaOperator.IsNotEmpty, 0));
                }
            }

            var attrValues = from n in nodes.Where(b => b.Type == NodeType.CustomAttributeValue)
                             group n by n.ParentId
                                 into g
                                 select new
                                 {
                                     ParentId = g.Key,
                                     ValueIds = g.Select(m => m.Id)
                                 };

            foreach (var temp in attrValues)
            {
                ret.Add(new AttributeCriteria(temp.ParentId,
                    CriteriaOperator.Equals,
                    String.Join(",", temp.ValueIds)));
            }
            return ret;
        }

        private List<int> _hierarchyIds = new List<int>();

        public List<int> TargetedHierarchyIds
        {
            get
            {
                if (TargetedTreeNodes != null)
                {
                    _hierarchyIds = (from tn in TargetedTreeNodes
                                     where tn.Type == NodeType.Root
                                     select tn.Id).ToList();
                }
                return _hierarchyIds;
            }
            set
            {
                _hierarchyIds = value;
            }
        }

        public List<int> BlockedHierarchyIds
        {
            get
            {
                if (BlockedTreeNodes != null)
                    return (from tn in BlockedTreeNodes
                            where tn.Type == NodeType.Root
                            select tn.Id).ToList();
                return new List<int>();
            }
        }

        private bool _isAllUserBaseSelected;

        public bool IsAllUserBaseSelected
        {
            get
            {
                if (SelectedTreeNodes != null && SelectedTreeNodes.Count != 0)
                {
                    _isAllUserBaseSelected = false;
                    _isAllUserBaseSelected = SelectedTreeNodes.Exists(element => element.Type == (int)NodeType.AllUserBase);
                }
                return _isAllUserBaseSelected;
            }
            set
            {
                _isAllUserBaseSelected = value;
            }

        }

    }

    public class PlaceholderModel
    {
        public PlaceholderModel()
        {
            PlaceholderReplacementModels = new List<PlaceholderReplacementModel>();
            SelectedPlaceHolders = new List<PlaceHolder>();
            DeviceGroupOptions = new List<DeviceGroupOptions>();
            DeviceGroupOptionsRawXML = new List<DeviceGroupPresetOptions>();
            RecordingPreviewModels = new List<RecordingPreviewModel>();
            systemPlaceholders = new SystemPlaceholders();
        }

        public SystemPlaceholders systemPlaceholders { get; set; }
        public List<PlaceholderReplacementModel> PlaceholderReplacementModels { get; set; }

        public List<PlaceHolder> SelectedPlaceHolders { get; set; }

        public List<DeviceGroupOptions> DeviceGroupOptions { get; set; }

        public List<DeviceGroupPresetOptions> DeviceGroupOptionsRawXML { get; set; }

        public List<RecordingPreviewModel> RecordingPreviewModels { get; set; }


    }

    public class PlaceholderValueModel
    {
        public string Key { get; set; }
        public string Value { get; set; }
    }

    public class RecordingPreviewModel
    {
        public int GroupId { get; set; }
        public string Id { get; set; }
        public string Name { get; set; }
        public string Stream { get; set; }
    }

    public class PlaceholderReplacementModel
    {
        public int GroupId { get; set; }
        public string FieldId { get; set; }
        public string Label { get; set; }

        public string Value { get; set; }
        public int MinLength { get; set; }
        public int MaxLength { get; set; }
        public bool IsTextArea { get; set; }
        public bool IsValid
        {
            get
            {
                if (string.IsNullOrWhiteSpace(Value))
                    return false;

                return Value.Length >= MinLength && Value.Length <= MaxLength;
            }
        }
    }

    public class CustomContentPreviewModel
    {
        public string FieldId { get; set; }
        public string Label { get; set; }
        public string Value { get; set; }

        public int MinLength { get; set; }
        public int MaxLength { get; set; }
        public bool IsTextArea { get; set; }
        public bool IsValid
        {
            get { return Value.Length >= MinLength && Value.Length <= MaxLength; }
        }

    }
}