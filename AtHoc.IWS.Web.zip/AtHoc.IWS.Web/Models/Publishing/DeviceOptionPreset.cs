﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace AtHoc.IWS.Web.Models.Publishing
{

    [XmlRoot("AlertExtension")]
    public class DeviceOptionPreset
    {
        public int Id { get; set; }

        public int GroupId { get; set; }

        [XmlAttribute("ExtensionID")]
        public int ExtensionID { get; set; }

        [XmlArray("data")]
        [XmlArrayItem("element", typeof(Element))]
        public Element[] Elements { get; set; }
    }

    public class Element
    {
        [XmlAttribute("id")]
        public string Id { get; set; }

        [XmlText]
        public string Value { get; set; }
    }
}