﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNet.SignalR.Owin;
using AtHoc.Global.Resources.Entities;

namespace AtHoc.IWS.Web.Models.Publishing
{
    public class SeverityModel
    {
         [LocalizationEntityId(BusinessEntity.Severity)]
        public string SeverityId { get; set; }
         [LocalizationEntityProperty(BusinessEntity.Severity, "Name")]
        public string SeverityName { get; set; }
    }
}