﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Text;
using System.Text.RegularExpressions;
using System.Reflection;
using System.Globalization;
using System.Xml.Linq;
using System.Xml;
using System.Web.Mvc;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.SSA.Business.Facades.Service.Incident;
using AtHoc.IWS.Web.Context;
using EO.Pdf;
using System.IO;
using AtHoc.VirtualSystems;
using AtHoc.Publishing;
using AtHoc.IWS.SSA.Business.Facades;
using AtHoc.IWS.SSA.Business;
using AtHoc.IWS.SSA.Business.Dictionaries;
using AtHoc.Devices;

namespace AtHoc.IWS.Web.Models.Publishing
{
    public class PlaceHolder
    {

        internal const int SYSTEM_PLACEHOLDERS_VPS_ID = 3;

        public int ProviderId { get; set; }

        public int ScenarioId { get; set; }

        public int Id { get; set; }

        public string CommonName { get; set; }

        public string Name { get; set; }

        public string ControlType { get; set; }

        public string DisplayType { get; set; }

        public int MinimumLength { get; set; }

        public int MaximumLength { get; set; }

        public int DisplayLines { get; set; }

        public List<Business.Domain.Entities.PlaceHolderValue> Values { get; set; }
        public string SelectedValue { get; set; }
        public bool IsSystem
        {
            get { return ProviderId == SYSTEM_PLACEHOLDERS_VPS_ID; }
        }
    }
    public class PlaceHolderValue
    {
        public int Id;

        public String Name;

        public String Value;

        public bool IsDefault;
    }
    public enum PlaceHolderType
    {
        System,
        Custom
    }

    public enum PlaceHolderControlType
    {
        SingleSelection,
        MultiSelection,
        Memo,
        Text,
        Date,
        DateTime,
        Time
    }

    public class DatetimeUtility
    {
        public static DateTime? ConvertToDateTime(string value, string timeFormat)
        {
            DateTime outDate;

            if (DateTime.TryParseExact(value, timeFormat, CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces, out outDate) == true)
            {
                return outDate;
            }

            else return null;
        }


        public static string ConvertToUTCDateTicks(string value, string timeFormat, bool timeformat = false)
        {
            DateTime outDate;
            var format = timeFormat;

            if (timeformat)
            {
                format = "MM/dd/yy " + timeFormat;
            }

            if (DateTime.TryParseExact(value, format, CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces, out outDate) == true)
            {
                return outDate.ToUniversalTime().Ticks.ToString();
            }

            else return DateTime.Now.Ticks.ToString();
        }

        public static string ConvertToUTCTimeTicks(string value, string timeFormat)
        {
            return ConvertToUTCDateTicks("01/01/01 " + value, timeFormat, true);
        }

        public static string GetCurrentDate(int timeformat = 0)
        {
            var format = timeformat == 1 ? GetTimeFormat() : timeformat == 2 ? GetDateTimeFormat() : GetDateFormat();
            return string.Format("{0:" + format + "}", DateTime.Now.ToLocalTime());
        }

        public static string ConvertFromUTCTicksToDate(string value, int timeformat = 0)
        {
            long lDateInUtcTicks = 0;

            if (string.IsNullOrEmpty(value)) return null;

            if (long.TryParse(value, out lDateInUtcTicks) == false) return value;

            var format = timeformat == 1 ? GetTimeFormat() : timeformat == 2 ? GetDateTimeFormat() : GetDateFormat();

            return string.Format("{0:" + format + "}", new DateTime(lDateInUtcTicks).ToLocalTime());
        }

        public static string ConvertFromUTCTicksToTime(string value)
        {
            return ConvertFromUTCTicksToDate(value, 1);
        }

        public static string ConvertFromUTCTicksToDateTime(string value)
        {
            return ConvertFromUTCTicksToDate(value, 2);
        }

        public static string GetDateTimeFormat()
        {
            return RuntimeContext.Provider.GetDateTimeFormat();
        }

        public static string GetTimeFormat()
        {
            return RuntimeContext.Provider.GetTimeFormat();
        }

        public static string GetDateFormat()
        {
            return RuntimeContext.Provider.GetDateFormat();
        }

    }
}