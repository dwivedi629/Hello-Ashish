﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Resources;
using System.Threading;
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Web.Helpers;
using AtHoc.Global.Resources;
using AtHoc.Scheduling;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Web.Models.Publishing
{

    public class ScheduleModel
    {

        public ScheduleModel()
        {
            ScheduleRecurrenceWeekly = new List<string>();
        }

        public bool ScheduleActivateRecurrenceCheck { get; set; }
        public int ScheduleDurationInput { get; set; }
        public string ScheduleDurationUnitSelect { get; set; }
        public string ScheduleRecurrenceStartHourSelect { get; set; }
        public string ScheduleRecurrenceStartMinuteSelect { get; set; }
        public string ScheduleRecurrenceStartAmpmSelect { get; set; }
        // recurrence Pattern
        public string ScheduleRecurrenceRadio { get; set; }
        //Daily settings
        public string ScheduleRecurrenceDailyRadiogroup { get; set; }
        public int ScheduleRecurrenceDailyFrequencyInput { get; set; }
        //Weekly settings
        public List<string> ScheduleRecurrenceWeekly { get; set; }
        public int ScheduleRecurrenceWeeklyFrequencyInput { get; set; }
        //Monthly settings
        public string ScheduleRecurrenceMonthlyRadiogroup { get; set; }
        public int ScheduleRecurrenceMonthlyFrequencyInput { get; set; }
        public int ScheduleRecurrenceMonthlyAbsoluteDaySelect { get; set; }
        public int ScheduleRecurrenceMonthlyRelativeDayofweekSelect { get; set; }
        public int ScheduleRecurrenceMonthlyRelativeWeeknumSelect { get; set; }
        //yearly settings
        public string ScheduleRecurrenceYearlyModeRadiogroup { get; set; }
        public int ScheduleRecurrenceYearlyAbsoluteMonthSelect { get; set; }
        public int ScheduleRecurrenceYearlyAbsoluteDayInput { get; set; }
        public int ScheduleRecurrenceYearlyRelativeWeeknumSelect { get; set; }
        public int ScheduleRecurrenceYearlyRelativeDayofweekSelect { get; set; }
        public int ScheduleRecurrenceYearlyRelativeMonthSelect { get; set; }
        //recurrence period
        public string ScheduleRecurrenceEndRadiogroup { get; set; }
        public int ScheduleRecurrenceEndCountInput { get; set; }
        public string ScheduleRecurrenceEnddateInput { get; set; }
        public string ScheduleRecurrenceStartDateInput { get; set; }

        public IList<MultiSelectListModel> TimeFormat { get; set; }
        public IList<MultiSelectListModel> Meridian { get; set; }
        public IList<MultiSelectListModel> TimePeriod { get; set; }
        public IList<MultiSelectListModel> DayNames { get; set; }
        public IList<MultiSelectListModel> NumberNames { get; set; }
        public IList<MultiSelectListModel> MonthNames { get; set; }
        public string recurrenceTime { get; set; }

    }

    public class AlertScheduleModel
    {

        public AlertScheduleModel()
        {

            ScheduleAlertPublishStartModeSettime = AlertingStartTime.ASAP.ToString();
            ScheduleDurationInput = 4;
            ScheduleDurationInputUnit = "Hour";
            StartDateTimeHelper = new DateTimeHelper();
            ScheduleAlertpublishStartDateInput = StartDateTimeHelper.TheDateTimeFormatted;
        }

        public AlertScheduleModel(Provider provider)
        {

            ScheduleAlertPublishStartModeSettime = AlertingStartTime.ASAP.ToString();
            ScheduleDurationInput = 4;
            ScheduleDurationInputUnit = "Hour";
            StartDateTimeHelper = new DateTimeHelper(DateTime.Today.AddHours(8), provider);
            ScheduleAlertpublishStartDateInput = StartDateTimeHelper.TheDateTimeFormatted;
            ScheduleAlertpublishStartdateHourSelect = StartDateTimeHelper.TheHour.ToString();
            ScheduleAlertpublishStartdateMinuteSelect = StartDateTimeHelper.TheMinute.ToString();
            ScheduleAlertpublishStartdateAmpmSelect = StartDateTimeHelper.TheAmpm;
              
        }

        public DateTimeHelper StartDateTimeHelper { get; set; }
        public string ScheduleAlertPublishStartModeSettime { get; set; }
        public string ScheduleAlertpublishStartDateInput { get; set; }
        public string ScheduleAlertpublishStartdateHourSelect { get; set; }
        public string ScheduleAlertpublishStartdateMinuteSelect { get; set; }
        public string ScheduleAlertpublishStartdateAmpmSelect { get; set; }


        public DateTimeHelper EndDateTimeHelper { get; set; }
        public string ScheduleAlertpublishEndDateInput { get; set; }
        public string ScheduleAlertpublishEnddateHourSelect { get; set; }
        public string ScheduleAlertpublishEnddateMinuteSelect { get; set; }
        public string ScheduleAlertpublishEnddateAmpmSelect { get; set; }

        public int? ScheduleDurationInput { get; set; }
        public string ScheduleDurationInputUnit { get; set; }

        public IList<MultiSelectListModel> TimeFormat { get; set; }


    }

    public enum AlertingStartTime
    {
        ASAP,
        SetTime
    }
    public enum TimeFormatEnum
    {

        [Description("TimeFormat_Minutes")]
        Minute,
        [Description("TimeFormat_Hours")]
        Hour,
        [Description("TimeFormat_Days")]
        Day,
    }
    public static class TimeFormatEnumExtension
    {
        private static readonly ResourceManager Resource = new
           ResourceManager(Constants.resourceAssembly, typeof(IWSResources).Assembly);
        public static string Display(this TimeFormatEnum format)
        {
            return Resource.GetString(format.GetDescription(), Thread.CurrentThread.CurrentUICulture);
        }

    }

    public enum TimePeriodEnum
    {

        [Description("Time_Period_Daily")]
        Daily = 4,
        [Description("Time_Period_Weekly")]
        Weekly = 8,
        [Description("Time_Period_Monthly")]
        Monthly = 16,
        [Description("Time_Period_Yearly")]
        Yearly = 64,
    }
    public static class TimePerioEnumExtension
    {
        private static readonly ResourceManager Resource = new
           ResourceManager(Constants.resourceAssembly, typeof(IWSResources).Assembly);
        public static string Display(this TimePeriodEnum format)
        {
            return Resource.GetString(format.GetDescription(), Thread.CurrentThread.CurrentUICulture);
        }

    }

    public enum DayNamesEnum
    {

        [Description("Day_Names_Sunday")]
        Sunday = 1,
        [Description("Day_Names_Monday")]
        Monday = 2,
        [Description("Day_Names_Tuesday")]
        Tuesday = 3,
        [Description("Day_Names_Wednesday")]
        Wednesday = 4,
        [Description("Day_Names_Thursday")]
        Thursday = 5,
        [Description("Day_Names_Friday")]
        Friday = 6,
        [Description("Day_Names_Saturday")]
        Saturday = 7,
       
    }
    public static class DayNamesEnumExtension
    {
        private static readonly ResourceManager Resource = new
           ResourceManager(Constants.resourceAssembly, typeof(IWSResources).Assembly);
        public static string Display(this DayNamesEnum format)
        {
            return Resource.GetString(format.GetDescription(), Thread.CurrentThread.CurrentUICulture);
        }

    }

    public enum NumberNamesEnum
    {
        [Description("Number_Names_First")]
        First=1,
        [Description("Number_Names_Second")]
        Second=2,
        [Description("Number_Names_Third")]
        Third=4,
        [Description("Number_Names_Fourth")]
        Fourth=8,
        [Description("Number_Names_Last")]
        Last=16,
    }
    public static class NumberNamesEnumExtension
    {
        private static readonly ResourceManager Resource = new
           ResourceManager(Constants.resourceAssembly, typeof(IWSResources).Assembly);
        public static string Display(this NumberNamesEnum format)
        {
            return Resource.GetString(format.GetDescription(), Thread.CurrentThread.CurrentUICulture);
        }

    }

    
     public enum MonthNamesEnum
    {
        [Description("Month_Names_January")]
        January=1,
        [Description("Month_Names_Feburary")]
        Feburary=2,
        [Description("Month_Names_March")]
        March=3,
        [Description("Month_Names_April")]
        April=4,
        [Description("Month_Names_May")]
        May=5,
        [Description("Month_Names_June")]
        June=6,
        [Description("Month_Names_July")]
        July=7,
        [Description("Month_Names_August")]
        August=8,
        [Description("Month_Names_September")]
        September=9,
        [Description("Month_Names_October")]
        October=10,
        [Description("Month_Names_November")]
        November=11,
        [Description("Month_Names_December")]
        December=12,

    }
    public static class MonthNamesEnumExtension
    {
        private static readonly ResourceManager Resource = new
           ResourceManager(Constants.resourceAssembly, typeof(IWSResources).Assembly);
        public static string Display(this MonthNamesEnum format)
        {
            return Resource.GetString(format.GetDescription(), Thread.CurrentThread.CurrentUICulture);
        }

    }

    public class ScenarioScheduleModel
    {
        #region properties

        public bool ActivateRecurrence { get; set; }
        public int ProviderId { get; set; }

        public DateTimeHelper RecurrenceStartDateTimeHelper { get; set; }

        public FrequencyType RecurrencePattern { get; set; }

        public FrequencyTypeDaily RecurrenceDailyMode { get; set; }
        public int RecurrenceDailyFrequency { get; set; }

        public int RecurrenceWeeklyFrequency { get; set; }
        public int RecurrenceWeeklyMask { get; set; }

        public FrequencyType RecurrenceMonthlyMode { get; set; }
        public int RecurrenceMonthlyFrequency { get; set; }
        public int RecurrenceMonthlyAbsoluteDay { get; set; }
        public int RecurrenceMonthlyRelativeWeekNum { get; set; }
        public int RecurrenceMonthlyRelativeDayofWeek { get; set; }

        public FrequencyType RecurrenceYearlyMode { get; set; }
        public int RecurrenceYearlyAbsoluteMonth { get; set; }
        public int RecurrenceYearlyAbsoluteDay { get; set; }
        public int RecurrenceYearlyRelativeWeekNum { get; set; }
        public int RecurrenceYearlyRelativeDayofWeek { get; set; }
        public int RecurrenceYearlyRelativeMonth { get; set; }

        public DateTime? RecurrenceEndDate { get; set; }

        public string RecurrenceEndDateFormatted
        {
            get
            {
                var _provider = RuntimeContext.Provider;
                return (RecurrenceEndDate == null) ? "" :
                    string.Format("{0:" + _provider.GetDateFormat() + "}", RecurrenceEndDate);
            }
            private set { }
        }

        public enum RecurrenceEndEnum
        {
            NoEndDate = 1,
            EndAfterSetNumber = 2,
            EndByDate = 3
        }
        public RecurrenceEndEnum RecurrenceEnd { get; set; }
        public int RecurrenceEndCount { get; set; }

        #endregion

        #region constructors

        public ScenarioScheduleModel()
        {
            ActivateRecurrence = false;
            RecurrenceStartDateTimeHelper = new DateTimeHelper();
            RecurrencePattern = FrequencyType.Daily;
            RecurrenceDailyMode = FrequencyTypeDaily.Everyday;
            RecurrenceDailyFrequency = 1;
            RecurrenceWeeklyFrequency = 1;
            RecurrenceWeeklyMask = 1;
            RecurrenceMonthlyMode = FrequencyType.MonthlyAbsolute;
            RecurrenceMonthlyFrequency = 1;
            RecurrenceMonthlyAbsoluteDay = 1;
            RecurrenceMonthlyRelativeWeekNum = 1;
            RecurrenceMonthlyRelativeDayofWeek = 1;
            RecurrenceYearlyMode = FrequencyType.YearlyAbsolute;
            RecurrenceYearlyAbsoluteMonth = 1;
            RecurrenceYearlyAbsoluteDay = 1;
            RecurrenceYearlyRelativeWeekNum = 1;
            RecurrenceYearlyRelativeDayofWeek = 1;
            RecurrenceYearlyRelativeMonth = 1;
            RecurrenceEndDate = DateTime.Today.AddMonths(1);
            RecurrenceEnd = RecurrenceEndEnum.NoEndDate;
            RecurrenceEndCount = 10;
        }

        #endregion


    }

}