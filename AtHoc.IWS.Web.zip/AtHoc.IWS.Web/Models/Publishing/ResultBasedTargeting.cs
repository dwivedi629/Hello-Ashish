﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AtHoc.d911.Common.Model;

namespace AtHoc.IWS.Web.Models.Publishing
{
    public class ResultBasedTargeting
    {
        public int AlertId { get; set; }
        public string GroupByType { get; set; }
        public int GroupById { get; set; }
        public bool IncludeChildren { get; set; }
        public string EntityFilterId { get; set; }
        public string FillCountType { get; set; }
        public bool IncludeGroups { get; set; }
        public bool IncludeHierarchy { get; set; }
        public bool IncludeDevices { get; set; }
        public string AlertHeader { get; set; }
        public string HorizontalFilterName { get; set; }
        public string VerticalFilterName { get; set; }
        public string OperatorId { get; set; }
        public int DeviceId { get; set; }
        public string Source { get; set; }
        public int AccountabilityEventId { get; set; }
    }

    public class ReportGenerator
    {
        public ReportGenerator()
        {
        }

        private int _totalUsersFound = 0;
        private int _totalEnabledUsers = 0;
        private int _cachedUsersSessionId = 0;
        public ReportProperties Properties = new ReportProperties();

        public int TotalUsersFound
        {
            //this property returns users found for given search criteria excluding disabled and NPD users.
            get
            {
                return _totalUsersFound;
            }
        }

        public int TotalEnabledUsers
        {
            //this property 
            get
            {
                return _totalEnabledUsers;
            }

        }

        public int CachedUsersSessionId
        {
            get
            {
                return _cachedUsersSessionId;
            }
        }

        public class ReportProperties
        {
            public ReportProperties()
            {
                GroupById = 0;
                IncludeChildNodes = false;
                MessageType = "sent";
                PageNo = 1;
                PageSize = 1000;
                SortBy = "Display Name";
                SortAscending = false;
                IncludeGroups = false;
                IncludeHierarchy = false;
                IncludeDevices = false;
                IncludeUserDetail = false;
                IncludeDeviceDetail = false;
                StartRowIndex = 0;
                IsOutputFormatCSV = true;
            }
            public int ProviderId { get; set; }
            public string GroupByType { get; set; }
            public int GroupById { get; set; }
            public bool IncludeChildNodes { get; set; }
            public string MessageType { get; set; }
            public int PageNo { get; set; }
            public int PageSize { get; set; }
            public string SortBy { get; set; }
            public bool SortAscending { get; set; }
            public bool IncludeGroups { get; set; }
            public bool IncludeHierarchy { get; set; }
            public int UserSearchSessionId { get; set; }
            public string DeviceAttributeIdList { get; set; }
            public string ReportType { get; set; }
            public UserDetailedReportEntityFilter FilterBy { get; set; }
            public string EntityFilterId
            {
                get; set; }

            public bool IncludeDevices { get; set; }
            public bool IncludeUserDetail { get; set; } //for Alert Tracking Report SDK extension
            public bool IncludeDeviceDetail { get; set; } //for Alert Tracking Report SDK extension
            public int StartRowIndex { get; set; } //0 = export as usual; -1 = for sdk, SP will determine start record; > 0 = sdk, subsequent calls return a page with records beginning here
            public bool IsOutputFormatCSV { get; set; }
            public int EndRowIndex { get; set; } //record id of last record returned by SP
            public int UsersRetrieved { get; set; }
        }
    }

    public enum UserDetailedReportEntityFilter
    {
        AllSelectedUsers,
        AllCoveredUsers,
        AllNotCoveredUsers,
        EntityIdCoveredUsers,   //need entityID as input as well
        EntityIdNotCoveredUsers //need entityID as input as well
    }


    
}