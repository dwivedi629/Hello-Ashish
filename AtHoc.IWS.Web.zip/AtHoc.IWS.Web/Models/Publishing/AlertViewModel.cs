﻿using AtHoc.Publishing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtHoc.IWS.Web.Models.Publishing
{
    public class AlertViewModel
    {
        public int AlertId { get; set; }
        public string Title { get; set; }
        public string Status { get; set; }
        public string StatusLabel { get; set; }
        public string StartTimeDisplayString { get; set; }
        public DateTime? StartTime { get; set; }
        public string Publisher { get; set; }
        public int Targeted { get; set; }
        public int Sent { get; set; }
        public int Responded { get; set; }
        public bool ErrorExists { get; set; }

        public bool CanEdit { get; set; }
        public bool CanPublish { get; set; }
        public bool CanDelete { get; set; }
        public bool CanEnd { get; set; }
        public bool CanDuplicate { get; set; }
        public string Body { get; set; }
        public IList<AlertResponse> Responses { get; set; }
        public string TimeRemaining { get; set; }

        public string Severity { get; set; }

        public string Event { get; set; }

        public string SeverityLabel { get; set; }

        public string EventLabel { get; set; }
    }
}
