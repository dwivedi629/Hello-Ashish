﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AtHoc.IWS.Web.Models.Publishing
{
    public class AlertBaseViewModel
    {
    
        public AlertBaseViewModel(PublishingContext _context, bool isPreview = false)
        {
            Context = _context;
            IsPreview = isPreview;
        }

        public PublishingContext Context { get; set; }
        public bool IsPreview { get; set; }
    }
}