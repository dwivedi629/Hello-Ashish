﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AtHoc.IWS.Web.Models.Shared
{
    /// <summary>
    /// Export Data Model class.
    /// </summary>
    public class ExportDataModel
    {
        public string FileName { get; set; }
    }
}