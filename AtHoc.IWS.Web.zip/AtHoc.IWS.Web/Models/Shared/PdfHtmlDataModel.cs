﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AtHoc.IWS.Web.Configurations;

namespace AtHoc.IWS.Web.Models.Shared
{
    /// <summary>
    /// Pdf Html Data Model.
    /// </summary>
    public class PdfHtmlDataModel : ExportDataModel
    {
        public string Header { get; set; }
        public string Rows { get; set; }
        public PdfGridConfiguration PdfSpeConfiguration { get; set; }
        public string TableSubTitle { get; set; }
      
    }
}