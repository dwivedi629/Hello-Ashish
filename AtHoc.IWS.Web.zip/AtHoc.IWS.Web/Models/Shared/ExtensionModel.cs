﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Script.Serialization;
using System.Xml;
using System.Xml.Linq;
using AtHoc.d911;
using AtHoc.d911.Model.Organization;
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Business.Context;
using models = AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Event.Impl;
using AtHoc.Systems;
using System.Reflection;
using System.Xml.XPath;
using System.Collections;
namespace AtHoc.IWS.Web.Models.Shared
{
    public class CustomOptionsExtension
    {
        public int GroupID { get; set; }

        public CustomOptionsExtension(int groupId)
        {
            GroupID = groupId;
        }

        protected Hashtable _Elements = new Hashtable();
        //protected List<string> _DirtyElements = new List<string>();
        public Boolean RegisterFeature(string name)
        {
            _Elements[name] = false;
            return true;
        }
        public string MarkAsDirty(string name)
        {
            //_DirtyElements.Add(name);
            _Elements[name] = true;
            return string.Empty;
        }
        public string GetDirtyFeatures()
        {
            // compile the l first //
            List<string> output = new List<string>();
            foreach (DictionaryEntry key in _Elements)
            {
                if ((Boolean)key.Value)
                {
                    output.Add(key.Key.ToString());
                }
            }
            return string.Join(",", output.ToArray());
        }
        public string GetAllFeatures()
        {
            // compile the l first //
            List<string> output = new List<string>();
            foreach (DictionaryEntry key in _Elements)
            {
                output.Add(key.Key.ToString());
            }
            return string.Join(",", output.ToArray());
        }

        public XPathNavigator GetNode(
            XPathNodeIterator root,
            string name
            )
        {

            XPathNavigator output = null;
            try
            {
                output = root.Current.SelectSingleNode(name);
            }
            catch
            {
                try
                {
                    root.MoveNext();
                    output = root.Current.SelectSingleNode(name);
                }
                catch
                {
                    output = null;
                }
            }
            return output;
        }

        public string GetNodeValue(
            XPathNodeIterator root,
            string name
            )
        {
            string output = string.Empty;
            XPathNavigator temp = GetNode(root, name);
            if (temp != null)
            {
                output = temp.Value;
            }
            temp = null;
            return output;
        }

        public XPathNodeIterator SplitDelimitedString(
            String pattern,
            String delimiter
            )
        {
            XElement array = new XElement("Array");
            String[] items = pattern.Split(new String[] { delimiter }, StringSplitOptions.RemoveEmptyEntries);
            foreach (String item in items)
            {
                array.Add(new XElement("Item", item));
            }
            return array.CreateNavigator().SelectChildren("Item", String.Empty);
        }

        public XPathNodeIterator GetBindableList(
            string assembly,
            string module,
            string method,
            XPathNodeIterator arguments
            )
        {
            return GetBindableList(assembly, module, method, arguments, null);
        }

        public XPathNodeIterator GetBindableList(
            string assembly,
            string module,
            string method,
            XPathNodeIterator arguments,
            XPathNodeIterator instanceArguments
            )
        {
            /*
              <Binding type="xPath | assembly">
                <XPath>blah</XPath>
                <Assembly>Assembly.Name</Assembly>
                <Module>ClassName</Module>
                <Method>someMethodName</Method>
                <InstanceArguments>
                  <Argument Source="Environment">Provider.ID</Argument>
                </InstanceArguments>
                <Arguments>
                  <Argument Source="Environment">Provider.ID</Argument>
                  <Argument Source="Literal">ATHOC-GV-TYPE</Argument>
                  <Argument Source="Literal">Key</Argument>
                </Arguments>
                <ValueSource>xPath</ValueSource>
                <LabelSource>xPath</LabelSource>
              </Binding>
            */

            // they pass in an assembly, method name and arguments l //
            // we return an Xml Node with a simple enumerated internal structure //

            XPathNodeIterator output = null;
            Assembly assy = null;
            Object target = null;
            Type classType = null;
            MethodInfo meth = null;

            try
            {
                // retrieve the l of method arguments //
                List<Object> args = new List<Object>();
                List<Object> instanceArgs = new List<Object>();
                foreach (XPathNavigator item in arguments)
                {
                    args.Add(GetArgumentValue(item.GetAttribute("Source", String.Empty), item.GetAttribute("Type", String.Empty), item.Value));
                }

                if (instanceArguments != null)
                {
                    foreach (XPathNavigator item in instanceArguments)
                    {
                        instanceArgs.Add(GetArgumentValue(item.GetAttribute("Source", String.Empty), item.GetAttribute("Type", String.Empty), item.Value));
                    }
                }

                // load up the assembly //
                // check to see if it's a static member first //

                assy = Assembly.Load(assembly);
                classType = assy.GetType(module);
                meth = classType.GetMethod(method);

                if (meth.IsStatic)
                {
                    // just call it //
                    output = (XPathNodeIterator)meth.Invoke(null, args.ToArray());
                }
                else
                {
                    // instantiate an object //
                    // then just call the method //
                    target = assy.CreateInstance(classType.FullName, true, BindingFlags.CreateInstance, null, instanceArgs.ToArray(), null, null);
                    output = (XPathNodeIterator)meth.Invoke(target, args.ToArray());
                }
            }
            catch (Exception e)
            {
                output = null;
                //EventLogger.WriteError("Error retrieving bindable list using reflection.\n\n" + assembly + "\n" + module + "\n" + method, e);
            }
            finally
            {
                assy = null;
                target = null;
                classType = null;
            }

            return output;
        }

    public string GetBoundString(
    string assembly,
    string module,
    string method,
    XPathNodeIterator arguments,
    XPathNodeIterator instanceArguments
    )
        {
            /*
              <Binding type="xPath | assembly">
                <XPath>blah</XPath>
                <Assembly>Assembly.Name</Assembly>
                <Module>ClassName</Module>
                <Method>someMethodName</Method>
                <InstanceArguments>
                  <Argument Source="Environment">Provider.ID</Argument>
                </InstanceArguments>
                <Arguments>
                  <Argument Source="Environment">Provider.ID</Argument>
                  <Argument Source="Literal">ATHOC-GV-TYPE</Argument>
                  <Argument Source="Literal">Key</Argument>
                </Arguments>
                <ValueSource>xPath</ValueSource>
                <LabelSource>xPath</LabelSource>
              </Binding>
            */

            // they pass in an assembly, method name and arguments l //
            // we return an Xml Node with a simple enumerated internal structure //

            string output = null;
            Assembly assy = null;
            Object target = null;
            Type classType = null;
            MethodInfo meth = null;

            try
            {
                // retrieve the l of method arguments //
                List<Object> args = new List<Object>();
                List<Object> instanceArgs = new List<Object>();
                foreach (XPathNavigator item in arguments)
                {
                    args.Add(GetArgumentValue(item.GetAttribute("Source", String.Empty), item.GetAttribute("Type", String.Empty), item.Value));
                }

                if (instanceArguments != null)
                {
                    foreach (XPathNavigator item in instanceArguments)
                    {
                        instanceArgs.Add(GetArgumentValue(item.GetAttribute("Source", String.Empty), item.GetAttribute("Type", String.Empty), item.Value));
                    }
                }

                // load up the assembly //
                // check to see if it's a static member first //

                assy = Assembly.Load(assembly);
                classType = assy.GetType(module);
                meth = classType.GetMethod(method);

                if (meth.IsStatic)
                {
                    // just call it //
                    output = (string)meth.Invoke(null, args.ToArray());
                }
                else
                {
                    // instantiate an object //
                    // then just call the method //
                    target = assy.CreateInstance(classType.FullName, true, BindingFlags.CreateInstance, null, instanceArgs.ToArray(), null, null);
                    output = (string)meth.Invoke(target, args.ToArray());
                }
            }
            catch (Exception e)
            {
                output = null;
                //EventLogger.WriteError("Error retrieving bindable list using reflection.\n\n" + assembly + "\n" + module + "\n" + method, e);
            }
            finally
            {
                assy = null;
                target = null;
                classType = null;
            }

            return output;
        }

        private object GetArgumentValue(string source, string type, string value)
        {
            string[] env;
            object tmp = string.Empty;
            object context = null;

            try
            {
                switch (source.ToUpper())
                {
                    case "ENVIRONMENT":
                        // HttpRuntimeContext.getRuntimeContext().getProviderContext().Id;
                        // [TYPE].[ReflectedPropertyName]
                        env = value.Split(char.Parse("."));
                        switch (env[0].ToUpper())
                        {
                            case "PROVIDER":
                                context = RuntimeContext.Provider;
                                break;

                            case "SYSTEM":

                                context = new SystemContextForCustomOption(AtHocSystem.Local);
                                break;

                            case "USER":
                                context = RuntimeContext.Operator;
                                break;

                            case "ENTITY":
                                context = this;
                                break;

                            default:
                                // do nothing //
                                break;
                        }

                        if (context != null)
                        {
                            Type cType = context.GetType();
                            PropertyInfo cProp = cType.GetProperty(env[1]);
                            tmp = cProp.GetValue(context, null);
                        }

                        break;

                    case "LITERAL":
                    default:
                        tmp = value;
                        break;
                }
            }
            catch
            {
                tmp = string.Empty;
            }

            // convert //
            object output = null;
            if (tmp != null)
            {
                Type outType = Type.GetType(type);
                output = Convert.ChangeType(tmp, outType);
            }

            return output;
        }

    }

    public class SystemContextForCustomOption
    {
        public string BaseURL { get; protected set; }

        public SystemContextForCustomOption(AtHoc.Systems.LocalSystem system)
        {
            this.BaseURL = system.BaseUrl;
        }
    }
    /*
     * This was copied from legacy code. Not sure if we need full blown system context for device option. Creating a lightweight object.
     * 
    public class SystemContext
    {
        public string Name { get; protected set; }
        public string BaseURL { get; protected set; }
        public bool ShowDisclaimer { get; set; }
        public string Disclaimer { get; protected set; }
        public int SessionTimeout { get; protected set; }   // in minutes
        public int MaxSessionsPerOperator { get; protected set; }   // in minutes

        public string ProductLogoClass { get; protected set; }

        public bool DebugMode { get; protected set; }
        public int CopyrightYear { get; protected set; }

        public SystemContext(AtHoc.Systems.LocalSystem system)
        {

            try
            {
                //this.Name = system.Name;
                this.BaseURL = "something";

                //this.Disclaimer = system.SecurityPolicy.SecurityDisclaimer;
                //this.ShowDisclaimer = !string.IsNullOrEmpty(this.Disclaimer);

                //this.SessionTimeout = system.SecurityPolicy.OperatorSessionTimeout;

                ////TODO: enable this once it is available
                //this.MaxSessionsPerOperator = system.SecurityPolicy.MaxSessionsPerOperator;

                //ProductLogoClass = "AtHocImage" + system.Type.ToString();

                //if ((system.Type == SystemType.IWSAlerts) &&
                //    (system.InstallationType == SysInstallationType.Mobile))
                //{
                //    ProductLogoClass += system.InstallationType.ToString();
                //}

                // if outside of IIS limit, use current/default session timeout
                //if ((this.SessionTimeout < 1) || (this.SessionTimeout > 1440))
                //{
                //    this.SessionTimeout = HttpContext.Current.Session.Timeout;
                //    //EventLogger.WriteInformation(string.Format("HttpContext.Current.Session.Timeout = {0}", HttpContext.Current.Session.Timeout));
                //}

                //CopyrightYear = DateTime.Now.Year;
                //string syear = ConfigurationManager.AppSettings["CopyrightYear"];
                //if (!string.IsNullOrEmpty(syear))
                //{
                //    int year = 0;
                //    if (int.TryParse(syear, out year))
                //    {
                //        CopyrightYear = year;
                //    }
                //}

                //DebugMode = false;
                //string sdebug = ConfigurationManager.AppSettings["DebugMode"];
                //if (!string.IsNullOrEmpty(sdebug))
                //{
                //    bool debug = false;
                //    if (bool.TryParse(sdebug, out debug))
                //    {
                //        DebugMode = debug;                    //    }
                //}
            }
            catch (Exception ex)
            {
                // EventLogger.WriteError(ex);
            }
        }

    }
    */
    public class DeviceGroupModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public bool Selected { get; set; }
        public bool DeviceOptionLoaded { get; set; }
        public string HTML { get; set; }

        public List<String> ElementList { get; set; }
        public bool HasExtension { get; set; }

    }

    public class DeviceOptionModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public bool Selected { get; set; }
        public string HTML { get; set; }

        public List<String> ElementList { get; set; }
    }

}