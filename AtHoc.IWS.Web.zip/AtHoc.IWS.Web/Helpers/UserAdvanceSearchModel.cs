﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Web.Models.SearchCriteria;
using AtHoc.Publishing;

namespace AtHoc.IWS.Web.Helpers
{
    public static class UserAdvanceSearchModel
    {
        public static SearchCriteria ConvertSearchCriteriaModel(SearchCriteriaModel selectedQuery)
        {
            var criteria = new SearchCriteria { NodeType = SearchNodeType.Query };
            foreach (var criterion in selectedQuery.selections)
            {
                if (criteria.SearchQueries == null)
                    criteria.SearchQueries = new List<SearchQuery>();

                var searchQuery = new SearchQuery(criterion.entity.id);
                switch (criterion.entity.entityType.ToUpper())
                {
                    case "ATTRIBUTE":
                        searchQuery.QueryType = SearchQueryType.Attribute;
                        break;
                    case "DEVICE":
                        searchQuery.QueryType = SearchQueryType.Device;
                        break;
                    case "ROLE":
                        searchQuery.QueryType = SearchQueryType.OperatorRole;
                        break;
                    case "VPS":
                        searchQuery.QueryType = SearchQueryType.VirtualSystem;
                        break;
                }
                searchQuery.Operator = (SearchOperators)criterion.operand;
                searchQuery.SearchValueCollections = new List<SearchValueCollection>();
                if (searchQuery.Operator.Equals(SearchOperators.IsEmpty) || searchQuery.Operator.Equals(SearchOperators.IsNotEmpty))
                {
                    searchQuery.SearchValueCollections.Add(new SearchValueCollection { SearchValueCollectionID = 0, SearchValue = "0" });
                }
                else
                {
                    if (criterion.value != null)
                    {
                        foreach (var criterionValue in criterion.value)
                        {
                            CustomAttributeDataType datatype = EnumUtils<CustomAttributeDataType>.Parse(criterion.entity.dataType);

                            if (datatype.Equals(CustomAttributeDataType.Path))
                            {
                                searchQuery.SearchValueCollections.Add(new SearchValueCollection { SearchValue = criterionValue.lineage });
                            }
                            else
                            {
                                searchQuery.SearchValueCollections.Add(new SearchValueCollection { SearchValue = !criterion.useCommonNameValue ? (criterionValue.id < 1 ? criterionValue.text : criterionValue.id.ToString()) : criterionValue.commonName });
                            }
                        }
                    }
                }
                criteria.SearchQueries.Add(searchQuery);
            }

            return criteria;
        }

    }
}
