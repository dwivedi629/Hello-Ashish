﻿using System;
using AtHoc.Infrastructure.Ioc;
using AtHoc.Infrastructure.Log;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Events;

namespace AtHoc.IWS.Web.Helpers
{
    public class InboxHelper
    {
        /// <summary>
        /// Get the Connect Request Count
        /// </summary>
        /// <returns></returns>
        public static dynamic GetConnnectRequestCount()
        {
            dynamic response = new System.Dynamic.ExpandoObject();
            
            response.RequestCount = 0;

            try
            {
                var eventFacade = ServiceLocator.Current.Resolve<IEventFacade>();
                var count = eventFacade.GetConnectRequestCount(RuntimeContext.ProviderId);
                response.RequestCount = count;
                return response;
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
            }
            return response;

        }    
    }
}