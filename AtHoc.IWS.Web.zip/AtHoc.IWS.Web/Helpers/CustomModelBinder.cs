﻿using System;
using System.IO;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using AtHoc.IWS.Web.Models.Publishing;
using Newtonsoft.Json;


namespace AtHoc.IWS.Web.Helpers
{
    public class CustomModelBinder <T> : DefaultModelBinder where T: class
    {
        public override object BindModel(ControllerContext controllerContext, ModelBindingContext bindingContext)
        {
            if (bindingContext.ModelType == typeof(T))
            {
                var s = controllerContext.RequestContext.HttpContext.Request.InputStream;
                s.Seek(0, SeekOrigin.Begin);

                var jsJson = new JavaScriptSerializer();
                jsJson.MaxJsonLength = Int32.MaxValue;
                using (var sw = new StreamReader(s))
                {
                    return jsJson.Deserialize<T>(sw.ReadToEnd());
                }
            }
            return base.BindModel(controllerContext, bindingContext);
        }
    }
}
