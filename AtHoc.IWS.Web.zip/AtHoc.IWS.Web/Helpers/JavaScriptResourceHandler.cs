﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Web;
using System.Web.Caching;
using AtHoc.Global.Resources;
using AtHoc.Infrastructure;
using EO.Internal;

namespace AtHoc.IWS.Web.Helpers
{
    public class JavaScriptResourceHandler : IHttpHandler
    {
        static readonly object Locker = new object();
        static Dictionary<string,  string> _localeResources = new Dictionary<string, string>();

        public bool IsReusable
        {
            get { return true; }
        }

        public void ProcessRequest(HttpContext context)
        {
            var resourceVariable = "Resources";
            var response = HttpContext.Current.Response;
            var javaScript = string.Empty;
            var locale = Thread.CurrentThread.CurrentUICulture.Name;

            lock (Locker)
            {
                if (!_localeResources.ContainsKey(locale))
                {
                    lock (Locker)
                    {
                        var localeRes = IWSResources.ResourceManager.GetResourceSetByPattern(string.Empty);
                        javaScript = SerializeResourceDictionary(localeRes, resourceVariable);
                        _localeResources.Add(locale, javaScript);
                    }
                }
            }

            response.Cache.SetLastModified(DateTime.UtcNow);
            response.AppendHeader("Accept-Ranges", "bytes");
            var cache = response.Cache;
            var utcNow = DateTime.UtcNow;
            cache.VaryByParams["locale"] = true;
            cache.VaryByParams["v"] = true;
            cache.SetCacheability(HttpCacheability.Private);
            cache.SetExpires(utcNow + TimeSpan.FromDays(180.0));
            cache.SetValidUntilExpires(true);
            cache.SetLastModified(utcNow);
            SendTextOutput(_localeResources[locale], "application/javascript");
        }

        private string SerializeResourceDictionary(Dictionary<string, string> resxDict, string varname)
        {
            var sb = new StringBuilder(2048);
            sb.Append("var " + varname + " = {\r\n");
            
            foreach (var item in resxDict)
            {
                var value = item.Value;
                var key = item.Key;
                key = key.Replace(".", "_");
                key = key.Replace(" ", "_");
                key = key.Replace(@"""", "");
                key = key.Replace(":", "");
                key = key.Replace(",", "");
                sb.Append("\t\"" + key + "\":");
                sb.Append(EncodeJsString(value));
                sb.Append(",\r\n");
            }

            sb.Append("}");

            // strip off ,/r/n at end of string (if any)
            sb.Replace(",\r\n}", "\r\n}");
            sb.Append(";\r\n");

            return sb.ToString();
        }

        public string EncodeJsString(string s)
        {
            if (s == null)
            {
                return "null";
            }

            var sb = new StringBuilder();
            sb.Append("\"");

            foreach (char c in s)
            {
                switch (c)
                {
                    case '\"':
                        sb.Append("\\\"");
                        break;
                    case '\\':
                        sb.Append("\\\\");
                        break;
                    case '\b':
                        sb.Append("\\b");
                        break;
                    case '\f':
                        sb.Append("\\f");
                        break;
                    case '\n':
                        sb.Append("\\n");
                        break;
                    case '\r':
                        sb.Append("\\r");
                        break;
                    case '\t':
                        sb.Append("\\t");
                        break;
                    default:
                        var i = (int)c;

                        if (i < 32 || i > 127)
                        {
                            sb.AppendFormat("\\u{0:X04}", i);
                        }
                        else
                        {
                            sb.Append(c);
                        }

                        break;
                }
            }

            sb.Append("\"");
            return sb.ToString();
        }

       private void SendTextOutput(string text, string contentType)
        {
           var response = HttpContext.Current.Response;

           if (IsGZipSupported())
           {
               response.Filter = new System.IO.Compression.GZipStream(response.Filter,
                   System.IO.Compression.CompressionMode.Compress);
               response.Headers.Remove("Content-Encoding");
               response.AppendHeader("Content-Encoding", "gzip");
           }

           response.AppendHeader("Vary", "Content-Encoding");
           response.ContentType = contentType;
           response.Charset = "utf-8";
           response.Write(text);
        }

       public static bool IsGZipSupported()
       {
           var acceptEncoding = HttpContext.Current.Request.Headers["Accept-Encoding"];
           return !string.IsNullOrEmpty(acceptEncoding) &&
                  (acceptEncoding.Contains("gzip") || acceptEncoding.Contains("deflate"));
       }
    }
}