﻿using System;
using System.Globalization;
using AtHoc.IWS.Business.Context;
using AtHoc.VirtualSystems;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Web.Helpers
{
    public class DateTimeHelper
    {
        private DateTime _theDateTime;
        private Provider _provider;
        public DateTime TheDateTime
        {
            get
            {
                return _theDateTime;
            }
            set
            {
                _theDateTime = value;
                TheDate = value.Date;
                TheHour = value.Hour;
                TheMinute = value.Minute;

                if (TheHour == 0)
                {
                    TheHour = 12;
                    TheAmpm = "AM";
                }
                else if (TheHour < 12)
                {
                    TheAmpm = "AM";
                }
                else if (TheHour >= 12)
                {
                    TheAmpm = "PM";
                    if (TheHour > 12)
                    {
                        TheHour -= 12;
                    }
                }

                TheTime = TheHour + ":" + TheMinute + " " + TheAmpm;
            }
        }

        public DateTime TheDate { get; private set; }
        public int TheHour { get; private set; }
        public int TheMinute { get; private set; }
        public string TheAmpm { get; private set; }

        public string TheTime { get; private set; }
        public Provider Provider
        {
            get { return _provider ?? RuntimeContext.Provider; }
            private set { _provider = value; }
        }


        public string TheDateFormatted
        {
            get
            {
                return string.Format("{0:" + Provider.GetDateFormat() + "}", TheDateTime);
            }

        }

        public string TheTimeFormatted
        {
            get
            {
                return string.Format("{0:" + Provider.GetTimeFormat() + "}", TheDateTime);
            }

        }

        public string TheDateTimeFormatted
        {
            get
            {
                return string.Format("{0:" + Provider.GetDateTimeFormat() + "}", TheDateTime);
            }
        }

        public string TheTimeFormattedWithoutSeconds
        {
            get
            {
                return string.Format("{0:" + Provider.GetTimeFormat().Replace(":ss", "") + "}", TheDateTime);
            }

        }
        public DateTimeHelper(DateTime val, Provider provider)
        {
            TheDateTime = val;
            Provider = provider;
        }

        public DateTimeHelper(DateTime val)
        {
            TheDateTime = val;
        }
        public DateTimeHelper()
        {
        }

        public static DateTime? ConvertToDateTime(string value, string timeFormat)
        {
            DateTime outDate;

            if (DateTime.TryParseExact(value, timeFormat, CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces, out outDate) == true)
            {
                return outDate;
            }

            else return null;
        }


        public static string ConvertToUTCDateTicks(string value, string timeFormat, bool timeformat = false)
        {
            DateTime outDate;
            var format = timeFormat;

            if (timeformat)
            {
                format = "MM/dd/yy " + timeFormat;
            }

            if (DateTime.TryParseExact(value, format, CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces, out outDate) == true)
            {
                return outDate.ToUniversalTime().Ticks.ToString();
            }

            else return DateTime.Now.Ticks.ToString();
        }

        public static string ConvertToUTCTimeTicks(string value)
        {
            return ConvertToUTCDateTicks("01/01/01 " + value, GetTimeFormat(), true);
        }

        public static string GetCurrentDate(int timeformat = 0)
        {
            var format = timeformat == 1 ? GetTimeFormat() : timeformat == 2 ? GetDateTimeFormat() : GetDateFormat();
            return string.Format("{0:" + format + "}", DateTime.Now.ToLocalTime());
        }

        public static string ConvertFromUTCTicksToDate(string value, int timeformat = 0)
        {
            long lDateInUtcTicks = 0;

            if (string.IsNullOrEmpty(value)) return null;

            if (long.TryParse(value, out lDateInUtcTicks) == false) return value;

            var format = timeformat == 1 ? GetTimeFormat() : timeformat == 2 ? GetDateTimeFormat() : GetDateFormat();

            return string.Format("{0:" + format + "}", new DateTime(lDateInUtcTicks).ToLocalTime());
        }

        public static string ConvertFromUTCTicksToTime(string value)
        {
            return ConvertFromUTCTicksToDate(value, 1);
        }

        public static string ConvertFromUTCTicksToDateTime(string value)
        {
            return ConvertFromUTCTicksToDate(value, 2);
        }

        public static string GetDateTimeFormat()
        {
            return RuntimeContext.Provider.GetDateTimeFormat();
        }

        public static string GetTimeFormat()
        {
            return RuntimeContext.Provider.GetTimeFormat();
        }

        public static string GetDateFormat()
        {
            return RuntimeContext.Provider.GetDateFormat();
        }


    }
}
