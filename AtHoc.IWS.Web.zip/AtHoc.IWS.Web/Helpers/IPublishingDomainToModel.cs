﻿using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Organization;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Business.Domain.Targeting.Model;
using AtHoc.IWS.Web.Models.Publishing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Web.Models.SearchCriteria;
using AtHoc.Publishing;
using Scenario = AtHoc.Publishing.Scenario;

namespace AtHoc.IWS.Web.Helpers
{
    public interface IPublishingDomainToModel
    {
        PublishingModel GetPublishingModel(AlertBase entity, Provider provider, int operatorId, CustomAttributeLookup customAttributeLookup, string locale,
            bool isSystem = false, int parentId = 0, string recipientType = null, bool loadTargetingTree = false, bool loadTargetUser = true);

        bool OrganizationEnabled(IOrganizationFacade organizationFacade, int providerId);

        /// <summary>
        /// Populate the group targeting selection in the targeting tree.
        /// As well as adding dummy nodes for the treeview
        /// </summary>
        /// <param name="tree">targeting tree</param>
        /// <param name="tCriteria">group targeting selection</param>
        void PopulateGroupTargetingSelection(IList<Node> tree, IList<ISearchCriteria> tCriteria);

        void ExtractTargetAndDeviceInfoFromEntity(AlertBase ab, int providerId, int operatorId, IPublishingFacade publishingFacade, ref TargetedUserCriteria criteria);

        PublisherSettings GetPublisherSettings(Provider provider);


        PlaceholderModel ReplacePlaceholders(int providerId, int operatorId, PlaceholderModel model);
        
        IList<MassDeviceTargetingEndPoint> GetEndPointFromDevice(int providerId, AtHoc.IWS.Web.Models.Publishing.Device device);

        IList<MassDeviceTargetingEndPoint> GetEndPointFromDevices(int providerId, AtHoc.IWS.Web.Models.Publishing.DeviceEndPoints device);

        PlaceholderModel ConvertDeviceOptionToPlaceholderReplacementModel(PlaceholderModel model);

        bool GetCustomPlaceHoldersStatus(int sid, int operatorId, int providerId);

        PlaceholderModel RetrieveCustomTexts(List<DeviceGroupPresetOptions> optionPresets);

        SearchCriteriaModel GetAdvancedQueryCriteria(TargetingSpecification spec, Provider provider);

        IList<KeyValueModel> GetEventCategories(Provider providerId);

        void SetRbtProperties(PublishingModel model, int entity);

        List<UserNode> GetAccountabilityOfficers(TargetingSpecification spec, int providerId, int operatorId);
    }

}
