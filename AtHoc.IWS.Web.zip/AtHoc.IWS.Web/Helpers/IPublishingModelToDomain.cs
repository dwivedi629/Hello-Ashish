﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtHoc.IWS.Web.Models.Publishing;
using AtHoc.Publishing;
using Scenario = AtHoc.Publishing.Scenario;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Targeting.Model;

namespace AtHoc.IWS.Web.Helpers
{
    public interface IPublishingModelToDomain
    {
        Scenario GetScenario(PublishingModel model, int providerId, int operatorId, string orgDeviceCommonName);

        Alert GetAlert(PublishingModel model, int providerId, OperatorUser operatorUser, string orgDeviceCommonName, int scenarioId = 0);

        AlertBase GetAlertBase(PublishingContext publishingContext, int id, int providerId, int operatorId);

        void SetAlertSpec(PublishingModel model, AlertBase alertBase, int providerId, string orgDeviceCommonName,
            int operatorId = 0);

        /// <summary>
        /// Helper method to save audio Id
        /// </summary>
        /// <param name="audioStream"></param>
        /// <returns></returns>
        string SaveAudio(string audioStream, string fileName);

        void SetAccountabilityOfficers(IList<UserNode> uNodes, TargetingSpecification spec, int providerId, int operatorId);
        

    }
}
