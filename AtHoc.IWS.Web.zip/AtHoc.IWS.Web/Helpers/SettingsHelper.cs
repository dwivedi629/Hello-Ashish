﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.Publishing;
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Web.Areas.Settings.Models;
using AtHoc.IWS.Web.Models.Publishing;
using AtHoc.Global.Resources;

namespace AtHoc.IWS.Web.Helpers
{
    public static class SettingsHelper
    {

        public static DesktopFormatModel GetDesktopFormatModel()
        {
            var desktopFormatModel = new DesktopFormatModel
            {
                FontList = (from FontEnum tformat in Enum.GetValues(typeof(FontEnum))
                            select new MultiSelectListModel()
                            {
                                Value = tformat.ToString().Replace('_', ' '),
                                Text = GetResourceString(tformat.GetDescription()) ?? tformat.ToString()
                            }).ToList(),
                FontTypeList = (from FontTypeEnum tformat in Enum.GetValues(typeof(FontTypeEnum))
                                select new MultiSelectListModel()
                                {
                                    Value = tformat.ToString().Replace('_', ' '),
                                    Text = GetResourceString(tformat.GetDescription()) ?? tformat.ToString()
                                }).ToList(),
                ImagePositionList = (from ImagePositionEnum tformat in Enum.GetValues(typeof(ImagePositionEnum))
                                     select new MultiSelectListModel()
                                     {
                                         Value = tformat.ToString(),
                                         Text = GetResourceString(tformat.GetDescription()) ?? tformat.ToString()
                                     }).ToList(),
                PopupPositionList = (from PopupPositionEnum tformat in Enum.GetValues(typeof(PopupPositionEnum))
                                     select new MultiSelectListModel()
                                     {
                                         Value = tformat.ToString(),
                                         Text = GetResourceString(tformat.GetDescription()) ?? tformat.ToString()
                                     }).ToList(),
                DesktopTimeList = (from DesktopTimeEnum tformat in Enum.GetValues(typeof(DesktopTimeEnum))
                                   select new MultiSelectListModel()
                                   {
                                       Value = tformat.ToString(),
                                       Text = GetResourceString(tformat.GetDescription()) ?? tformat.ToString()
                                   }).ToList(),
                DisplayStyleList = (from DisplayStyleEnum tformat in Enum.GetValues(typeof(DisplayStyleEnum))
                                    select new MultiSelectListModel()
                                    {
                                        Value = Convert.ToInt16(tformat).ToString(CultureInfo.InvariantCulture),
                                        Text = GetResourceString(tformat.GetDescription()) ?? tformat.ToString()
                                    }).ToList(),

                ExitMotionStyleList = (from ExitMotionStyleEnum tformat in Enum.GetValues(typeof(ExitMotionStyleEnum))
                                       select new MultiSelectListModel()
                                       {
                                           Value = tformat.ToString(),
                                           Text = GetResourceString(tformat.GetDescription()) ?? tformat.ToString()
                                       }).ToList(),


                EntranceMotionStyleList = (from EntranceMotionStyleEnum tformat in Enum.GetValues(typeof(EntranceMotionStyleEnum))
                                           select new MultiSelectListModel()
                                           {
                                               Value = tformat.ToString(),
                                               Text = GetResourceString(tformat.GetDescription()) ?? tformat.ToString()
                                           }).ToList(),
            };
            return desktopFormatModel;
        }

        public static SystemSettingsFormatModel GetSystemSettingsFormatModel()
        {
            var systemSettingsFormatModel = new SystemSettingsFormatModel
            {

                StoreLocationList = (from StoreLocationEnum tformat in Enum.GetValues(typeof(StoreLocationEnum))
                                     select new MultiSelectListModel()
                                     {
                                         Value = tformat.ToString(),
                                         Text = GetResourceString(tformat.GetDescription()) ?? tformat.ToString()
                                     }).ToList(),

                StoreNameList = (from StoreNameEnum tformat in Enum.GetValues(typeof(StoreNameEnum))
                                 select new MultiSelectListModel()
                                 {
                                     Value = tformat.ToString(),
                                     Text = GetResourceString(tformat.GetDescription()) ?? tformat.ToString()
                                 }).ToList(),
            };
            return systemSettingsFormatModel;

        }
        public static IList<MultiSelectListModel> GetOrgTypes(VPSType providerType)
        {

            var orgTypeList = (from OrgTypes tformat in Enum.GetValues(typeof(OrgTypes))
                               select new MultiSelectListModel()
                               {
                                   Value = tformat.ToString(),
                                   Text = GetResourceString(tformat.GetDescription()) ?? tformat.ToString()
                               }).AsQueryable();
            if (providerType.ToString() == VPSType.Enterprise.ToString())
                return orgTypeList.Where(e => e.Value == OrgTypes.TPL_SUB.ToString()).ToList();
            else
            {
                if (providerType.ToString() == VPSType.System.ToString())
                    return orgTypeList.Where(e => e.Value != OrgTypes.TPL_SUB.ToString() && e.Value != OrgTypes.TPL_UNK.ToString()).ToList();
            }

            return orgTypeList.ToList();

        }

        public static List<MultiSelectListModel> SeverityList()
        {
            var severityList = (from Priority p in Enum.GetValues(typeof(Priority))
                                where p != Priority.Severe
                                select
                                    new MultiSelectListModel()
                                    {
                                        Value = p.ToString(CultureInfo.InvariantCulture),
                                        Text = GetResourceString(p.GetDescription())
                                    }).ToList();
            return severityList;
        }

        public static List<SeverityModel> Severities()
        {
            var severityList = (from Priority p in Enum.GetValues(typeof(Priority))
                                where p != Priority.Severe
                                select
                                    new SeverityModel()
                                    {
                                        SeverityId = p.ToString(),
                                        SeverityName = p.ToString()
                                    }).ToList();
            return severityList;
        }
        public static List<MultiSelectListModel> AttributeList()
        {
            var attributeList = (from CustomAttributeDataType p in Enum.GetValues(typeof(CustomAttributeDataType))
                                 where p != CustomAttributeDataType.Unknown && p != CustomAttributeDataType.AttributeValue && p != CustomAttributeDataType.Device && p != CustomAttributeDataType.Entity && p != CustomAttributeDataType.Object
                                 select
                                     new MultiSelectListModel()
                                     {
                                         Value = p.ToString(CultureInfo.InvariantCulture),
                                         Text = GetResourceString(p.GetDescription())
                                     }).ToList();
            return attributeList;
        }

        public static string GetLocalizedAttributeType(string attributeType)
        {
            var pAttributeType = (CustomAttributeDataType)Enum.Parse(typeof(CustomAttributeDataType), attributeType);
            return GetResourceString(pAttributeType.GetDescription());
        }

        public static string GetLocalizedTimeZone(string timeZoneId)
        {

            var localizedString= System.Web.HttpUtility.HtmlDecode(
                  GetResourceString(String.Concat("TimeZone_",
                      Regex.Replace(timeZoneId.Trim(), "[^a-zA-Z0-9]", "_")
                          .TrimEnd('_')
                          .Replace("__", "_"))));
            return string.IsNullOrEmpty(localizedString) ? timeZoneId.Trim() : localizedString;
        }

        public static string GetPageDependencyLocalizeString(string value)
        {
            var val = string.Empty;
            if (value.Contains('-'))
            {
                val = string.Concat(" - ", value.Split('-')[1]);
                value = value.Split('-')[0].Trim();
            }
            var key = from UsedInPages p in Enum.GetValues(typeof(UsedInPages))
                      where p.ToString().Equals(value.Replace(" ", "_"))
                      select p.GetDescription();

            return string.Concat(GetResourceString(key.FirstOrDefault()), val);
        }

        public static string GetSectionDependencyLocalizeString(string value)
        {
            var val = string.Empty;
            if (value.Contains('-'))
            {
                val = string.Concat(" - ", value.Split('-')[1]);
                value = value.Split('-')[0].Trim();
            }
            var key = from UsedForSection p in Enum.GetValues(typeof(UsedForSection))
                      where p.ToString().Equals(value.Replace(" ", "_"))
                      select p.GetDescription();

            return string.Concat(GetResourceString(key.FirstOrDefault()), val);
        }

        public static string GetResourceString(string strDescription)
        {
            var resource = new System.Resources.ResourceManager(Constants.resourceAssembly, typeof(IWSResources).Assembly);
            return resource.GetString(strDescription, Thread.CurrentThread.CurrentUICulture);
        }

        /// <summary>
        /// Getting the Purge Duration List from resource file
        /// </summary>
        /// <returns></returns>
        public static List<MultiSelectListModel> PurgeDurationList()
        {
            var purgeDurationList = (from PurgeUserDurationEnum p in Enum.GetValues(typeof(PurgeUserDurationEnum))
                                     select
                                         new MultiSelectListModel()
                                         {
                                             Value = Convert.ToInt32(p).ToString(CultureInfo.InvariantCulture),
                                             Text = GetResourceString(p.GetDescription())
                                         }).ToList();
            return purgeDurationList;
        }

        /// <summary>
        /// getting the report column names from the resource file.
        /// </summary>
        /// <returns></returns>
        public static List<MultiSelectListModel> DisableDeleteReportColumnList()
        {
            var disableDeleteReportColumnList = (from DisableDeleteReportColumnEnum p in Enum.GetValues(typeof(DisableDeleteReportColumnEnum))
                                                 select
                                                     new MultiSelectListModel()
                                                     {
                                                         Value = p.ToString(CultureInfo.InvariantCulture),
                                                         Text = GetResourceString(p.GetDescription()).Replace(",", "").ToUpper().Replace("_", " ")
                                                     }).ToList();
            return disableDeleteReportColumnList;

        }
    }
}