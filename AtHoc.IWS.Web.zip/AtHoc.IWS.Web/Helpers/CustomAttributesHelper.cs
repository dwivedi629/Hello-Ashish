﻿using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AtHoc.IWS.Web.Helpers
{
    public static class CustomAttributesHelper
    {

        /// <summary>
        /// Returns Provider Custom Attributes from Database/Cache based on parameters.
        /// </summary>
        /// <param name="customAttributeCache">ICustomAttributeCache Interface</param>
        /// <param name="providerId">ProviderId</param>
        /// <param name="baseLocale">BaseLocale of Provider</param>
        /// <param name="hideMassDevices">Set True/False to hide mass devices</param>
        /// <param name="readFromCache">Set True to read from Cache</param>
        /// <returns>CustomAttributeLookup</returns>
        public static CustomAttributeLookup GetProviderAttributes(ICustomAttributeCache customAttributeCache,int providerId, string baseLocale, bool hideMassDevices = false, bool readFromCache = false)
        {
            var customAttributes = customAttributeCache.Get(providerId, baseLocale, hideMassDevices, readFromCache);
            return new CustomAttributeLookup(customAttributes);
        }
    }
}