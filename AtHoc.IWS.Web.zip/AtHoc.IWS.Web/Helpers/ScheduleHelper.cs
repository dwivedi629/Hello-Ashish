﻿using System;
using System.Globalization;
using AtHoc.Publishing;
using AtHoc.IWS.Business.Context;
using  AtHoc.IWS.Web.Models.Publishing;
using AtHoc.Scheduling;
using AtHoc.Utilities;

namespace AtHoc.IWS.Web.Helpers
{
    public class ScheduleHelper
    {
        /// <summary>
        /// 
        /// </summary>
        public static void SaveAlertStartTime(Alert alert, AlertScheduleModel aschedulesettings)
        {
            alert.PublishAtCurrentTime = aschedulesettings.ScheduleAlertPublishStartModeSettime.Equals(AlertingStartTime.ASAP.ToString());
            if (!alert.PublishAtCurrentTime)
            {
                DateTime? dt = GetForm_DateTime(
                    aschedulesettings.ScheduleAlertpublishStartDateInput);
                if (dt != null)
                {
                    alert.StartTime = (DateTime) dt;
                }
            }
            SaveDurationAndTime(alert, aschedulesettings);
        
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="alert"></param>
        public static void SaveAlertEndTime(Alert alert, AlertScheduleModel aschedulesettings)
        {
            DateTime? dt = GetForm_DateTime(aschedulesettings.ScheduleAlertpublishEndDateInput
               );
            alert.EndTime = (DateTime) dt;
        }

        /// <summary>
        /// /
        /// </summary>
        /// <param name="alert"></param>
        public static void SaveDurationAndTime(Alert alert, AlertScheduleModel aschedulesettings)
        {
            alert.AlertSpec.LiveDuration.Value = (int) aschedulesettings.ScheduleDurationInput;
            alert.AlertSpec.LiveDuration.Unit =
                (DurationUnit)
                    Enum.Parse(typeof(DurationUnit), aschedulesettings.ScheduleDurationInputUnit);
        }

        //sModel.one is used on scn only
        public Schedule SetScenarioSchedule(Scenario s, int operatorId, ScheduleModel smodel)
        {
            Schedule scheduleToReturn = null;
            // save duration parameters on scenario
            s.AlertSpec.LiveDuration.Value = smodel.ScheduleDurationInput;
            s.AlertSpec.LiveDuration.Unit =
                (AtHoc.Utilities.DurationUnit)
                    Enum.Parse(typeof (AtHoc.Utilities.DurationUnit), smodel.ScheduleDurationUnitSelect);
            // now save the schedule/recurrence
            var so = SyncScheduleFromRequest(smodel);
            var scheduleManager = new ScheduleManager(s.ProviderId, operatorId);
            if (s.IsNew)
            {
                if (so.ActivateRecurrence)
                {
                    Schedule schedule = scheduleManager.CreateSchedule();
                    schedule = SerializeToBackend(schedule,so); // serialize frontend model object to backend
                    // sModel.is a hack so we can save schedule after scenario is saved
                    // we put it in ViewData then retrive it later to save
                    scheduleToReturn = schedule;
                }
            }
            else // existing scenario
            {
                Schedule schedule = scheduleManager.GetSchedule(s.ScenarioId, "SCENARIO");
                if (schedule == null)
                {
                    if (so.ActivateRecurrence)
                    {
                        schedule = scheduleManager.CreateSchedule();
                        schedule = SerializeToBackend(schedule,so);
                        scheduleToReturn = schedule;
                    }
                }
                else
                {
                    if (so.ActivateRecurrence)
                    {
                        schedule = SerializeToBackend(schedule,so);
                        scheduleToReturn = schedule;
                    }
                    else
                    {
                        schedule.Status = ScheduleStatus.DISABLED;
                        scheduleToReturn = schedule;
                    }
                }
            }

            return scheduleToReturn;
        }


        public Schedule SerializeToBackend(Schedule ss,ScenarioScheduleModel sModel)
        {
            ss.Status = (sModel.ActivateRecurrence) ? ScheduleStatus.ACTIVE : ScheduleStatus.DISABLED;
            ss.StartDate = sModel.RecurrenceStartDateTimeHelper.TheDateTime;

            ss.FrequencyType = sModel.RecurrencePattern;
            switch (sModel.RecurrencePattern)
            {
                case FrequencyType.Daily:
                    switch (sModel.RecurrenceDailyMode)
                    {
                        case FrequencyTypeDaily.Everyday:
                        case FrequencyTypeDaily.EveryWeekday:
                            ss.FrequencyInterval = (int)sModel.RecurrenceDailyMode;
                            break;
                        case FrequencyTypeDaily.EveryNDay:
                            ss.FrequencyInterval = (int)sModel.RecurrenceDailyMode;
                            ss.FrequencySubDayInterval = sModel.RecurrenceDailyFrequency;
                            break;
                    }
                    break;
                case FrequencyType.Weekly:
                    ss.FrequencyRecurrenceFactor = sModel.RecurrenceWeeklyFrequency;
                    ss.FrequencyInterval = sModel.RecurrenceWeeklyMask;
                    break;
                case FrequencyType.MonthlyAbsolute:
                    ss.FrequencyRecurrenceFactor = sModel.RecurrenceMonthlyFrequency;
                    ss.FrequencyInterval = sModel.RecurrenceMonthlyAbsoluteDay;
                    break;
                case FrequencyType.MonthlyRelative:
                    ss.FrequencyRecurrenceFactor = sModel.RecurrenceMonthlyFrequency;
                    ss.FrequencyInterval = sModel.RecurrenceMonthlyRelativeDayofWeek;
                    ss.FrequencyRelativeInterval = sModel.RecurrenceMonthlyRelativeWeekNum;
                    break;
                case FrequencyType.YearlyAbsolute:
                    ss.FrequencySubMonthType = sModel.RecurrenceYearlyAbsoluteMonth;
                    ss.FrequencyInterval = sModel.RecurrenceYearlyAbsoluteDay;
                    break;
                case FrequencyType.YearlyRelative:
                    ss.FrequencySubMonthType = sModel.RecurrenceYearlyRelativeMonth;
                    ss.FrequencyInterval = sModel.RecurrenceYearlyRelativeDayofWeek;
                    ss.FrequencyRelativeInterval = sModel.RecurrenceYearlyRelativeWeekNum;
                    break;
            }

            switch (sModel.RecurrenceEnd)
            {
                case ScenarioScheduleModel.RecurrenceEndEnum.NoEndDate:
                    ss.ScheduleNeverEnds = true;
                    break;
                case ScenarioScheduleModel.RecurrenceEndEnum.EndAfterSetNumber:
                    ss.EndRecurrenceCount = sModel.RecurrenceEndCount;
                    break;
                case ScenarioScheduleModel.RecurrenceEndEnum.EndByDate:
                    ss.EndDate = sModel.RecurrenceEndDate;
                    break;
            }

            return ss;
        }

        public ScenarioScheduleModel SyncScheduleFromRequest(ScheduleModel s)
        {
            var schedule = new ScenarioScheduleModel { ActivateRecurrence = s.ScheduleActivateRecurrenceCheck };

            if (schedule.ActivateRecurrence)
            {
                // read start date, which includes start date, hour, and minute
                DateTime? dt = GetFormattedDateTime(s.ScheduleRecurrenceStartDateInput + ' ' + s.recurrenceTime);
                if (dt != null )
                {
                    schedule.RecurrenceStartDateTimeHelper = new DateTimeHelper((DateTime)dt);
                }

                // read recurrence pattern section
                schedule.RecurrencePattern = (FrequencyType)Enum.Parse(typeof(FrequencyType), s.ScheduleRecurrenceRadio);
                switch (schedule.RecurrencePattern)
                {
                    case FrequencyType.Daily:
                        {
                            schedule.RecurrenceDailyMode = (FrequencyTypeDaily)Enum.Parse(typeof(FrequencyTypeDaily), s.ScheduleRecurrenceDailyRadiogroup);
                            switch (schedule.RecurrenceDailyMode)
                            {
                                case FrequencyTypeDaily.Everyday:
                                    schedule.RecurrenceDailyFrequency = 1;
                                    break;
                                case FrequencyTypeDaily.EveryWeekday:
                                    break;
                                case FrequencyTypeDaily.EveryNDay:
                                    schedule.RecurrenceDailyFrequency = s.ScheduleRecurrenceDailyFrequencyInput;
                                    break;
                            }
                            break;
                        }
                    case FrequencyType.Weekly:
                        {
                            schedule.RecurrenceWeeklyFrequency = s.ScheduleRecurrenceWeeklyFrequencyInput;
                            schedule.RecurrenceWeeklyMask = 0;

                            if (s.ScheduleRecurrenceWeekly != null)
                            {
                                foreach (var item in s.ScheduleRecurrenceWeekly)
                                {
                                    int mask = 1;
                                    int.TryParse(item, out mask);
                                    schedule.RecurrenceWeeklyMask += mask;
                                }
                            }

                            break;
                        }
                    case FrequencyType.MonthlyAbsolute:
                        // UI will combine absolute and relative, need to check schedule_recurrence_monthly_radiogroup
                        schedule.RecurrencePattern = (FrequencyType)Enum.Parse(typeof(FrequencyType), s.ScheduleRecurrenceMonthlyRadiogroup);
                        schedule.RecurrenceMonthlyFrequency = s.ScheduleRecurrenceMonthlyFrequencyInput;
                        switch (schedule.RecurrencePattern)
                        {
                            case FrequencyType.MonthlyAbsolute:
                                schedule.RecurrenceMonthlyAbsoluteDay = s.ScheduleRecurrenceMonthlyAbsoluteDaySelect;
                                break;
                            case FrequencyType.MonthlyRelative:
                                schedule.RecurrenceMonthlyRelativeDayofWeek = s.ScheduleRecurrenceMonthlyRelativeDayofweekSelect;
                                schedule.RecurrenceMonthlyRelativeWeekNum = s.ScheduleRecurrenceMonthlyRelativeWeeknumSelect;
                                break;
                        }
                        break;
                    case FrequencyType.YearlyAbsolute:
                        // UI will combine absolute and relative, need to check schedule_recurrence_yearly_mode_radiogroup
                        schedule.RecurrencePattern = (FrequencyType)Enum.Parse(typeof(FrequencyType), s.ScheduleRecurrenceYearlyModeRadiogroup);
                        schedule.RecurrenceYearlyMode = schedule.RecurrencePattern;
                        switch (schedule.RecurrencePattern)
                        {
                            case FrequencyType.YearlyAbsolute:
                                schedule.RecurrenceYearlyAbsoluteMonth = s.ScheduleRecurrenceYearlyAbsoluteMonthSelect;
                                schedule.RecurrenceYearlyAbsoluteDay = s.ScheduleRecurrenceYearlyAbsoluteDayInput;
                                break;
                            case FrequencyType.YearlyRelative:
                                schedule.RecurrenceYearlyRelativeWeekNum = s.ScheduleRecurrenceYearlyRelativeWeeknumSelect;
                                schedule.RecurrenceYearlyRelativeDayofWeek = s.ScheduleRecurrenceYearlyRelativeDayofweekSelect;
                                schedule.RecurrenceYearlyRelativeMonth = s.ScheduleRecurrenceYearlyRelativeMonthSelect;
                                break;
                        }
                        break;
                } // end - read recurrence pattern section

                // read End Date
                schedule.RecurrenceEnd = (ScenarioScheduleModel.RecurrenceEndEnum)Enum.Parse(typeof(ScenarioScheduleModel.RecurrenceEndEnum), s.ScheduleRecurrenceEndRadiogroup);
                switch (schedule.RecurrenceEnd)
                {
                    case ScenarioScheduleModel.RecurrenceEndEnum.NoEndDate:
                        break;
                    case ScenarioScheduleModel.RecurrenceEndEnum.EndAfterSetNumber:
                        schedule.RecurrenceEndCount = s.ScheduleRecurrenceEndCountInput;
                        break;
                    case ScenarioScheduleModel.RecurrenceEndEnum.EndByDate:
                        var formDate = GetForm_Date(s.ScheduleRecurrenceEnddateInput);
                        if (formDate != null)
                            schedule.RecurrenceEndDate = formDate;
                        break;
                }
            }

            return schedule;
        }

        public static ScenarioScheduleModel SerializeFromBackend(Schedule ss )
        {

            var ssModel = new ScenarioScheduleModel {ProviderId = ss.ProviderId};
            ssModel.ActivateRecurrence = (ss.Status == ScheduleStatus.DISABLED ? false : true);

            ssModel.RecurrenceStartDateTimeHelper = new DateTimeHelper(ss.StartDate);

            ssModel.RecurrencePattern = ss.FrequencyType;

            switch (ssModel.RecurrencePattern)
            {
                case FrequencyType.Daily:
                    switch (ss.FrequencyInterval)
                    {
                        case 0:
                            ssModel.RecurrenceDailyMode = FrequencyTypeDaily.EveryWeekday;
                            break;
                        case 1:
                            ssModel.RecurrenceDailyMode = FrequencyTypeDaily.Everyday;
                            ssModel.RecurrenceDailyFrequency = 1;
                            break;
                        default:
                            ssModel.RecurrenceDailyMode = FrequencyTypeDaily.EveryNDay;
                            ssModel.RecurrenceDailyFrequency = ss.FrequencySubDayInterval;
                            break;
                    }
                    break;
                case FrequencyType.Weekly:
                    ssModel.RecurrenceWeeklyFrequency = ss.FrequencyRecurrenceFactor;
                    ssModel.RecurrenceWeeklyMask = ss.FrequencyInterval;
                    break;
                case FrequencyType.MonthlyAbsolute:
                    ssModel.RecurrenceMonthlyMode = ssModel.RecurrencePattern;
                    ssModel.RecurrenceMonthlyFrequency = ss.FrequencyRecurrenceFactor;
                    ssModel.RecurrenceMonthlyAbsoluteDay = ss.FrequencyInterval;
                    break;
                case FrequencyType.MonthlyRelative:
                    ssModel.RecurrenceMonthlyMode = ssModel.RecurrencePattern;
                    ssModel.RecurrenceMonthlyFrequency = ss.FrequencyRecurrenceFactor;
                    ssModel.RecurrenceMonthlyRelativeDayofWeek = ss.FrequencyInterval;
                    ssModel.RecurrenceMonthlyRelativeWeekNum = ss.FrequencyRelativeInterval;
                    break;
                case FrequencyType.YearlyAbsolute:
                    ssModel.RecurrenceYearlyMode = ssModel.RecurrencePattern;
                    ssModel.RecurrenceYearlyAbsoluteMonth = ss.FrequencySubMonthType;
                    ssModel.RecurrenceYearlyAbsoluteDay = ss.FrequencyInterval;
                    break;
                case FrequencyType.YearlyRelative:
                    ssModel.RecurrenceYearlyMode = ssModel.RecurrencePattern;
                    ssModel.RecurrenceYearlyRelativeWeekNum = ss.FrequencyRelativeInterval;
                    ssModel.RecurrenceYearlyRelativeDayofWeek = ss.FrequencyInterval;
                    ssModel.RecurrenceYearlyRelativeMonth = ss.FrequencySubMonthType;
                    break;
            }

            if (ss.EndDate != null)
            {
                ssModel.RecurrenceEndDate = ss.EndDate;
                ssModel.RecurrenceEnd = ScenarioScheduleModel.RecurrenceEndEnum.EndByDate;
            }
            else
            {
                if (ss.EndRecurrenceCount == null)
                {
                    ssModel.RecurrenceEnd = ScenarioScheduleModel.RecurrenceEndEnum.NoEndDate;
                }
                else
                {
                    ssModel.RecurrenceEnd = ScenarioScheduleModel.RecurrenceEndEnum.EndAfterSetNumber;
                    ssModel.RecurrenceEndCount = (int)ss.EndRecurrenceCount;
                }

            }
            return ssModel;
        }

        public static DateTime? GetForm_Date(string value)
        {

            if (!string.IsNullOrEmpty(value))
            {
                try
                {
                    string format = RuntimeContext.Provider.GetDateFormat();
                    return DateTime.ParseExact(value, format, CultureInfo.InvariantCulture);
                }
                catch (Exception)
                { }   // no need to handle exception, return null.  TODO: nice to add a log debug
            }
            return null;
        }

        public static DateTime? GetForm_DateTime(string value)
        {

            if (!string.IsNullOrEmpty(value))
            {
                try
                {
                    string format = RuntimeContext.Provider.GetDateTimeFormat();
                    return DateTime.ParseExact(value, format, CultureInfo.InvariantCulture);
                }
                catch (Exception)
                { }   // no need to handle exception, return null.  TODO: nice to add a log debug
            }
            return null;
        }

        public static DateTime? GetFormattedDateTime(string value)
        {
            bool ampmInput = false;

            DateTime? retVal;
            retVal = GetForm_Date(value.Split(Convert.ToChar(" "))[0]);

            if (retVal != null)
            {
                var startHour = Convert.ToInt16(value.Split(Convert.ToChar(" "))[1].Split(Convert.ToChar(":"))[0]);
                int startMinute = Convert.ToInt16(value.Split(Convert.ToChar(" "))[1].Split(Convert.ToChar(":"))[1]);

                if (value.Contains("AM") &&
                    (startHour == 12))
                {
                    startHour = 0;
                }
                else if (value.Contains("PM") && (startHour != 12))
                {
                    startHour += 12;
                }
                return ((DateTime)retVal).AddHours(startHour).AddMinutes(startMinute);
            }
            else
            {

                return null;
            }

        }


        public ScenarioScheduleModel GetScenarioSchedule(int scenarioId,int providerId)
        {
            var sm = new ScheduleManager();
          

            var ss = sm.GetSchedule(scenarioId, "SCENARIO");
            if (ss != null)
            {
                return  SerializeFromBackend(ss);
            }
            return  new ScenarioScheduleModel { ProviderId = providerId };
        }

     
    }


}
