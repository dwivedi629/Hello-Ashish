﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using AtHoc.Devices;
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.Accountability;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;
using AtHoc.IWS.Business.Domain.Users.Impl;
using AtHoc.IWS.Business.Domain.Users.Impl.Search;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.SSA.Business.Dictionaries;
using AtHoc.IWS.SSA.Business.Facades;
using AtHoc.IWS.SSA.Dictionaries;
using AtHoc.IWS.Web.Models.Publishing;
using AtHoc.Publishing;
using AtHoc.Targeting;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Business.Domain.Targeting.Model;
using AtHoc.IWS.Business.Domain.Targeting.Impl;
using AtHoc.IWS.Web.Models.SearchCriteria;
using AtHoc.IWS.SSA.Business;
using AtHoc.IWS.Business.Domain.Map;
using AtHoc.Systems;
using System.IO;
using AtHoc.Infrastructure.MediaWrapper;
using System.Xml.Linq;
using AtHoc.IWS.Business.Domain.Entities;
using Microsoft.Practices.ObjectBuilder2;
using System.Threading.Tasks;

namespace AtHoc.IWS.Web.Helpers
{
    public class PublishingModelToDomain : IPublishingModelToDomain
    {
        private readonly IAlertFacade _alertFacade;
        private readonly IScenarioFacade _scenarioFacade;
        private readonly IMapFacade _mapFacade;
        private readonly IUserFacade _userFacade;
        private readonly IAccountabilityFacade _acctFacade;
        public PublishingModelToDomain(IAlertFacade alertFacade, IScenarioFacade scenarioFacade, IMapFacade mapFacade, IUserFacade userFacade, IAccountabilityFacade acctFacade)
        {
            _alertFacade = alertFacade;
            _scenarioFacade = scenarioFacade;
            _mapFacade = mapFacade;
            _userFacade = userFacade;
            _acctFacade = acctFacade;
        }

        public Publishing.Scenario GetScenario(PublishingModel model, int providerId, int operatorId, string orgDeviceCommonName)
        {
            var scenario = model.EntityId > 0 ?
                _scenarioFacade.GetScenario(model.EntityId, providerId, operatorId) :
                _scenarioFacade.CreateScenario(providerId, operatorId);

            scenario.Name = model.ScenarioSection.Name.Trim();

            if (model.ScenarioSection.ChannelId > 0)
            {
                scenario.Channel = new Publishing.AlertChannel(string.Empty, model.ScenarioSection.ChannelId);
            }

            scenario.CommonName = (model.ScenarioSection.CommonName == null) ? null : model.ScenarioSection.CommonName.Trim();
            scenario.AvailableForQuickPublish = model.ScenarioSection.AvailableForQuickPublish;
            scenario.Description = (model.ScenarioSection.Description == null) ? null : model.ScenarioSection.Description.Trim();

            //moving setting alert spec to different function so we can share when we work on alerts
            SetAlertSpec(model, scenario, providerId, orgDeviceCommonName, operatorId);
            // set  scenario settings on alert base
            SetScenarioSectionSettings(model, scenario, providerId, operatorId);
            // set scenario schedule settings on alertbase
            return scenario;
        }


        public Alert GetAlert(PublishingModel model, int providerId, OperatorUser operatorUser, string orgDeviceCommonName, int scenarioId = 0)
        {
            Alert alert;
            if (model.EntityId > 0)
                alert = _alertFacade.GetAlert(model.EntityId, providerId, operatorUser.Id);
            else if (scenarioId > 0)
                alert = _alertFacade.CreateAlertFromScenario(providerId, operatorUser.Id, scenarioId);
            else
                alert = _alertFacade.CreateAlert(providerId, operatorUser.Id);

            if (model.AlertOrigin == OriginType.ResultBased)
            {
                alert.Origin.Type = OriginType.ResultBased;
                model.ParentId = scenarioId;
            }

            //follow user name rules
            string publisherName;
            if (!string.IsNullOrWhiteSpace(operatorUser.DisplayName))
            {
                publisherName = operatorUser.DisplayName;
            }
            else if (!string.IsNullOrWhiteSpace(operatorUser.FirstName) ||
                     !string.IsNullOrWhiteSpace(operatorUser.LastName))
            {
                publisherName = operatorUser.FirstName + " " + operatorUser.LastName;
            }
            else
            {
                publisherName = operatorUser.Username;
            }

            alert.Origin.PublishedByName = publisherName.Trim();

            //moving setting alert spec to different function so we can share when we work on alerts
            SetAlertSpec(model, alert, providerId, orgDeviceCommonName, operatorUser.Id);

            if (model.AlertScheduleSettings != null)
            {
                if (alert.Status == AlertStatus.Live)
                    ScheduleHelper.SaveAlertEndTime(alert, model.AlertScheduleSettings);
                else
                    ScheduleHelper.SaveAlertStartTime(alert, model.AlertScheduleSettings);
            }
            return alert;
        }
        public AlertBase GetAlertBase(PublishingContext publishingContext, int id, int providerId, int operatorId)
        {
            AlertBase ret = null;
            switch (publishingContext)
            {
                case PublishingContext.Alert:
                    ret = id == 0 ? (AlertBase)_alertFacade.CreateAlert(providerId, operatorId) : (AlertBase)_alertFacade.GetAlert(id, providerId, operatorId);
                    break;
                case PublishingContext.Scenario:
                    ret = id == 0 ? (AlertBase)_scenarioFacade.CreateScenario(providerId, operatorId)
                            : (AlertBase)_scenarioFacade.GetScenario(id, providerId, operatorId);
                    break;
                case PublishingContext.AccountTemplate:
                case PublishingContext.AccountEvent:
                    ret = (AlertBase)_acctFacade.GetTemplate(providerId, operatorId, id);
                    break;
                /*case PublishingContext.AccountEvent:
                    ret = _acctFacade.GetEvent(providerId, operatorId, id, true);
                    // todo: a hack to make it work for now. need to be removed!!!
                    // when we publish we do not have EventId yet, so we need to load the Tempalte Id
                    if (ret == null)
                    {
                        ret = _acctFacade.GetTemplate(providerId, operatorId, id);
                    }

                    break;*/
            }
            return ret;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="model"></param>
        /// <param name="alertBase"></param>
        /// <param name="providerId"></param>
        /// <param name="orgDeviceCommonName"></param>
        /// <param name="operatorId"></param>
        /// History-[1]-IWS-26990 : Refactore the code into single responsibility and then converted calles to Async and Parallel.
        public void SetAlertSpec(PublishingModel model, AlertBase alertBase, int providerId, string orgDeviceCommonName, int operatorId = 0)
        {
            //Validate Users Target Nodes
            ValidateTargetingSection(model);

            var tasks = new List<Action>();
            Task userTargetTask = null;

            //Save Alert Info
            if (model.AlertOrigin == OriginType.ResultBased)
            {
                SaveAlertCriteria(model, alertBase.AlertSpec.Targeting);
            }
            else
            {
                SaveGroupTargetingInfo(model.TargetUsers.TargetingNodes, alertBase.AlertSpec.Targeting);
                
                userTargetTask = Task.Factory.StartNew(() => SaveUserTargetingInfo(model.TargetUsers.TargetedBlockedUsers, alertBase.AlertSpec.Targeting, providerId, operatorId));
                tasks.Add(() => SaveQueryTargetingInfo(model.TargetUsers.TargetedCriteria, alertBase.AlertSpec.Targeting));             
            }

            //Attach AlertSpec content details from model
            SetAlertSpecDetails(model, alertBase);

            #region Map related

            tasks.Add(() =>
            {
                //Attach Map Details
                SetAlertAttachments(alertBase, model, providerId, operatorId);
                //SetTargetAreaCriteria(model, alertBase);
            });
	        #endregion


            var providerDevices = GetDevices(providerId);
            alertBase.AlertSpec.Delivery.RemoveAllDevices();

            tasks.Add(
                () => {
                    //Set devices from target user and mass devices
                    if ((model.TargetUsers != null && model.TargetUsers.Devices.Any()) || (model.MassDevices != null && model.MassDevices.Any()))
                    {
                        //compile two lists together
                        var deviceGroups = CombineAllDevices(model, alertBase);
                        SetTargetUserDevices(model, alertBase, providerDevices, deviceGroups);
                    }               

                    if (model.MassDevices.Count > 0)
                    {
                        SaveMassDeviceTargetingInfo(model.MassDevices, alertBase.AlertSpec.Targeting);
                    }
               
                    // target by organization - use new targeting criteria schema
                    SetOrganizationCriteria(model, alertBase, providerId, orgDeviceCommonName, providerDevices);
                });

            Parallel.Invoke(tasks.ToArray());
            
            if(userTargetTask != null)
            {
                userTargetTask.Wait();
            }

            alertBase.IsReadyForPublish = model.IsReadyToPublish;

            //IWS-11073
            alertBase.AlertSpec.Advanced.ConsolidateDuplicateMessages = true;

            //setting fill count spec...
            alertBase.AlertSpec.FillCount = model.FillCount;
        }

        protected virtual List<Devices.Device> GetDevices(int providerId)
        {
            var dm = new DeviceManager(providerId);
            var providerDevices = dm.GetDevices(true, false);
            return providerDevices;
        }

        private void SetTargetUserDevices(PublishingModel model, AlertBase alertBase, List<Devices.Device> providerDevices, IEnumerable<IGrouping<int?, Models.Publishing.Device>> deviceGroups)
        {
            foreach (var group in deviceGroups)
            {
                var extension = providerDevices.First(d => d.Id == @group.First().DeviceId).Group.Extension;

                if (extension != null) //gropu has device option
                {
                    //try to find device option
                    if (model.TargetUsers.DeviceGroupOptions != null)
                    {
                        var deviceoptionGroup = model.TargetUsers.DeviceGroupOptions.Where(d => d.GroupId == group.First().GroupId);
                        if (deviceoptionGroup.Count() == 0)
                        {
                            //try to find in new device option
                            deviceoptionGroup = model.MassDeviceGroupOptions.Where(d => d.GroupId == group.First().GroupId);
                        }

                        if (deviceoptionGroup.Count() != 0)
                        {
                            Dictionary<string, string> deviceOptions = deviceoptionGroup.First().Options.ToDictionary(g => g.Name, g => g.Value);

                            //had to duplicate dictionary since you cannot modify dictionary while iterating
                            Dictionary<string, string> doCopy = new Dictionary<string, string>(deviceOptions);

                            var recordings = deviceOptions.Where(k => k.Key.EndsWith("Recorded.Stream"));

                            //this device option has an audio
                            foreach (var recording in recordings)
                            {
                                String stream = recording.Value;

                                Regex rgx = new Regex(".[a-zA-Z]*$");
                                String audioName = deviceOptions[rgx.Replace(recording.Key, ".Name")];
                                String audioId = string.Empty;
                                if (!stream.IsNullOrEmpty())
                                {
                                    audioId = SaveAudio(stream, audioName);
                                }
                                if (audioId.IsNotNullOrEmpty())
                                {
                                    //retrieve audio Id key from stream key
                                    string audioIdKey = rgx.Replace(recording.Key, ".Id");

                                    if (deviceOptions.ContainsKey(audioIdKey))
                                    {
                                        doCopy[audioIdKey] = audioId;

                                        //reset audio stream to empty since we save the audio stream
                                        doCopy[recording.Key] = "";
                                    }
                                }

                            }

                            deviceOptions = doCopy;

                            alertBase.AlertSpec.Delivery.CustomOption.FillValuesFromDictionary(extension, deviceOptions);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Set Target User and Org by Area Criteria
        /// </summary>
        /// <param name="model"></param>
        /// <param name="alertBase"></param>
        private void SetTargetAreaCriteria(PublishingModel model, AlertBase alertBase)
        {
            

            // target by area criteria
            if (model.TargetUsers.TargetUsersByArea)
                SetTargetByAreaCriteria(alertBase);

            // target org by area criteria
            if (model.TargetOrg.TargetOrganizationsByArea)
                SetTargetOrgByAreaCriteria(alertBase);
        }

        /// <summary>
        /// Attach AlertSpec content details from model
        /// </summary>
        /// <param name="model"></param>
        /// <param name="alertBase"></param>
        private void SetAlertSpecDetails(PublishingModel model, AlertBase alertBase)
        {
            //assign content details
            alertBase.AlertSpec.Content.Header = (model.Content.Title == null) ? string.Empty : model.Content.Title.Trim();
            alertBase.AlertSpec.Content.Body = (model.Content.Body == null) ? string.Empty : model.Content.Body.Trim();
            alertBase.AlertSpec.Content.Url = model.Content.TargetUrl ?? string.Empty;
            alertBase.AlertSpec.EventCategoryId = model.Content.TypeId;
            alertBase.AlertSpec.Priority = (Priority)model.Content.SeverityId;
            alertBase.AlertSpec.Content.ResponseOptionsAttributeID = model.Content.ResponseOptionId;
            alertBase.AlertSpec.Content.ResponseOptions.Clear();

            // assign correct geo flags to domain model
            alertBase.AlertSpec.Targeting.TargetUsersByArea = model.TargetUsers.TargetUsersByArea;
            alertBase.AlertSpec.Targeting.TargetOrganizationsByArea = model.TargetOrg.TargetOrganizationsByArea;
            alertBase.AlertSpec.Targeting.TargetAllOrganizations = model.TargetOrg.TargetAllOrganizations;

            // channel info
            if (alertBase is Publishing.Scenario && model.ScenarioSection != null)
            {
                alertBase.AlertSpec.Category = Category.GetCategory(model.ScenarioSection.ChannelId);
            }

            //Set Response options
            try
            {
                foreach (var ro in model.Content.ResponseOptions)
                {
                    if (!string.IsNullOrEmpty(ro.ResponseText))
                        alertBase.AlertSpec.Content.ResponseOptions.Add(ro.ResponseText.Trim(), HttpUtility.HtmlDecode(ro.CallBridgeNumber), HttpUtility.HtmlDecode(ro.PassCode), ro.ConferenceUrl);
                }
            }
            catch (Exception ex)
            {
                throw new DuplicateResponseOptionException();
            }

            if (model.Content.Local != null)
            {
                alertBase.Locale = new LocaleInfo(model.Content.Local);
            }

        }

        /// <summary>
        /// target by organization - use new targeting criteria schema
        /// </summary>
        /// <param name="model"></param>
        /// <param name="alertBase"></param>
        /// <param name="providerId"></param>
        /// <param name="orgDeviceCommonName"></param>
        /// <param name="providerDevices"></param>
        private void SetOrganizationCriteria(PublishingModel model, AlertBase alertBase, int providerId, string orgDeviceCommonName, List<Devices.Device> providerDevices)
        {
            if (model.TargetOrg.TargetedOrganizations != null && model.TargetOrg.TargetedOrganizations.Count > 0)
            {
                //target org device
                //set device extension //hardcoding until type can be handled at the delivery level
                var trMgr = new TargetingManager(providerId);
                var orgDevice = providerDevices.FirstOrDefault(d => d.CommonName == orgDeviceCommonName);
                if (orgDevice != null)
                {
                    var orgExtensionDataStr =
                        String.Format(GetAlertExtensionTemplate(trMgr.GetGatewayConfigAsXml(providerId, orgDevice.Id)),
                            (model.Content.CategoryType != null && !string.IsNullOrWhiteSpace(model.Content.CategoryType.LogicalId))
                                ? model.Content.CategoryType.LogicalId : string.Empty);

                    alertBase.AlertSpec.Delivery.TargetDevice(orgDevice.Id);

                    // TODO: why is Extension null?
                    if (orgDevice.Group.Extension != null)
                        alertBase.AlertSpec.Delivery.CustomOption.SetFullExtension(orgDevice.Group.Extension.ID, orgExtensionDataStr, "<data/>", "<data/>");
                }

                //add orgs to targeting criteria
                SaveOrganizationTargetingInfo(model.TargetOrg.TargetedOrganizations, alertBase.AlertSpec.Targeting);
            }
        }


        private static IEnumerable<IGrouping<int?, Models.Publishing.Device>> CombineAllDevices(PublishingModel model, AlertBase alertBase)
        {
            List<Models.Publishing.Device> allDevices = model.TargetUsers.Devices.ToList();
            allDevices.AddRange(model.MassDevices);

            foreach (var device in allDevices)
            {
                if (device.DeliveryOrder > 0)
                {
                    alertBase.AlertSpec.Delivery.TargetDevice(device.DeviceId, device.DeliveryOrder);
                }
                else
                {
                    alertBase.AlertSpec.Delivery.TargetDevice(device.DeviceId);
                }
            }

            //set device extension
            var deviceGroups = allDevices.GroupBy(d => d.GroupId);
            return deviceGroups;
        }


        private static void ValidateTargetingSection(PublishingModel model)
        {
            if (model.TargetUsers.TargetingNodes.Any(n => (n.Type == NodeType.CustomAttribute || n.Type == NodeType.CustomAttributeValue || n.Type == NodeType.DistributionList) && n.Id == 0))
            {
                throw new Exception(string.Format("Cannot save Alert: '{0}' due to invalid targeting information", model.Content.Title));
            }
        }

        private void SaveAlertCriteria(PublishingModel model, TargetingSpecification spec)
        {
            spec.TargetAllUserBase = false;
            spec.TargetAllOrganizations = false;
            spec.TargetUsersByArea = false;
            spec.TargetOrganizationsByArea = false;

            if (spec.TargetingCriteria == null)
                spec.TargetingCriteria = new List<ISearchCriteria>();
            else
                spec.TargetingCriteria.Clear();
            var newCriteria = new SearchCriteria
            {
                SearchCriteriaID = !string.IsNullOrEmpty(model.rbt.FillCountType) ? (int)((ResultBasedCriteriaOperator)Enum.Parse(typeof(ResultBasedCriteriaOperator), model.rbt.FillCountType)) : -1,
                NodeType = SearchNodeType.Query,
                IsBlocked = false,
                SearchValue = model.rbt.DeviceId > 0 ? model.rbt.DeviceId.ToString() : string.Empty,
                SearchQueries = new List<SearchQuery>()
            };
            var alertQuery = new SearchQuery
            {
                QueryType = model.rbt.AccountabilityEventId > 0 ? SearchQueryType.PAEvent : SearchQueryType.Alert,
                QueryEntityID = model.rbt.AccountabilityEventId > 0 ? model.rbt.AccountabilityEventId : model.rbt.AlertId,
                AlertOperator = (AlertOperators)Enum.Parse(typeof(AlertOperators), model.rbt.EntityFilterId.ToUpper()),
                AccountabilityOperator = (model.rbt.EntityFilterId.ToUpper() == AccountabilityOperator.NORESPONSE.ToString()) ? AccountabilityOperator.NORESPONSE : AccountabilityOperator.MULTIPLERESPONSE,
                SearchValueCollections = new List<SearchValueCollection>()
            };
            //  This condition will be executed in case of Multiple Response Option
            if (alertQuery.QueryType == SearchQueryType.PAEvent && (alertQuery.AccountabilityOperator.ToString() == AccountabilityOperator.MULTIPLERESPONSE.ToString()))
            {
                alertQuery.SearchValueCollections.Add(new SearchValueCollection
                {
                    SearchValue = model.rbt.EntityFilterId.ToUpper()
                });
            }
            else
            {
                // This condition will be executed in case of AnyResponse, Targeted, NoResponse and  all scenarios of Alert RBT
                alertQuery.SearchValueCollections.Add(new SearchValueCollection
                {
                    SearchValue = string.Empty
                });
            }
            newCriteria.SearchQueries.Add(alertQuery);
            spec.TargetingCriteria.Add(newCriteria);
        }

        /// <summary>
        /// Save the targeting nodes object model to alert/scenario
        /// </summary>
        /// <param name="tNodes">targeting nodes</param>
        /// <param name="spec">targeting spec which has the targeting criteria property</param>
        private void SaveGroupTargetingInfo(IList<Node> tNodes, TargetingSpecification spec)
        {
            //IWS-12945
            //this gets called when alert/scenario is edited on the UI so we need to take care of allUserBase flag here
            //since it is always loaded from the db prior to this call...
            if (tNodes.Count(n => n.Type == NodeType.AllUserBase) == 0)
            {
                spec.TargetAllUserBase = false;
                ((List<ISearchCriteria>)spec.TargetingCriteria).RemoveAll(
                    tc => tc.NodeType == SearchNodeType.AllUserBase);
            }
            var targetingTreeFacade = new TargetingTreeFacade();
            var criteria = targetingTreeFacade.GetTargetingCriteria(tNodes);
            spec.TargetingCriteria = criteria;
        }

        private void SaveUserTargetingInfo(IList<UserNode> uNodes, TargetingSpecification spec, int providerId, int operatorId)
        {
            if (uNodes == null)
                return;

            if (spec.TargetingCriteria == null)
                spec.TargetingCriteria = new List<ISearchCriteria>();

            var userIds = uNodes.Select(u => u.UserId).ToList();

            if (userIds != null && userIds.Any())
            {
                var srchArgs = new UserSearchArgs(false, true, false)
                {
                    ProviderId = providerId,
                    AttributeNames = new List<string>() { "Login_Id" },
                    ProviderCriteria = UserSearchHelper.GetProviderCriteria(providerId),
                    OperatorCriteria = UserSearchHelper.GetOperatorUserBaseCriteria(operatorId, providerId),
                };

                srchArgs.Paging.UsersPerPage = Int32.MaxValue;
                var statusAttributeId = _userFacade.GetStatusAttributeId();
                var statusValueIds = _userFacade.GetStatusValueIds(new[] { AttributeCommonNames.ValidEnabledUsers });
                var statusCriteria = UserSearchHelper.GetUserStatusCriteria(statusAttributeId, statusValueIds);
                var userCriteria = UserSearchHelper.GetIndividualUserIdCriteria(userIds);
                srchArgs.TargetCriteria = userCriteria & statusCriteria;
                var sUser = _userFacade.SearchUsersByContext(srchArgs);

                if (uNodes != null && sUser != null)
                {
                    uNodes.Join(sUser.Users, usrNode => usrNode.UserId, sUsr => sUsr.Id,
                        (usrNode, sUsr) => new SearchCriteria
                        {
                            SearchCriteriaID = usrNode.UserId, // user ID
                            NodeType = SearchNodeType.User,
                            IsBlocked = usrNode.IsBlocked,
                            SearchValue = usrNode.Name
                        }).ForEach(usr => spec.TargetingCriteria.Add(usr));
                }
            }
        }

        private static void SaveQueryTargetingInfo(SearchCriteriaModel selectedQuery, TargetingSpecification spec)
        {
            if (selectedQuery == null || selectedQuery.selections == null)
                return;

            if (spec.TargetingCriteria == null)
                spec.TargetingCriteria = new List<ISearchCriteria>();

            var criteria = UserAdvanceSearchModel.ConvertSearchCriteriaModel(selectedQuery);
            spec.TargetingCriteria.Add(criteria);
        }

        private void SetAlertAttachments(AlertBase alertBase, PublishingModel model, int providerId, int operatorId = 0)
        {
          
			alertBase.AlertSpec.Content.Location = model.Content.LocationGeo;
			//if location is empty
	        if (model.Content == null || string.IsNullOrEmpty(alertBase.AlertSpec.Content.Location))
	        {
		        var attachment = alertBase.AlertSpec.Advanced.GetAttachments(AttachmentType.Spatial,
			        AttachmentSubType.Location).FirstOrDefault();
		        if (attachment != null)
		        {
			        alertBase.AlertSpec.Advanced.RemoveAttachments(attachment.AttachmentType,attachment.AttachmentId,attachment.AttachmentSubType);
		        }
		        return;
	        }
	        	
	        
			//clear old fips
			alertBase.AlertSpec.Content.Location = _mapFacade.RemoveFips(alertBase.AlertSpec.Content.Location);

            //add fips code to geojson when mass device is selected
            if (model.MassDevices.Count > 0)
            {
				var injectFips = model.MassDevices.Any(device => device.ExtractFIPS);
				if (injectFips)
				{
					alertBase.AlertSpec.Content.Location = _mapFacade.InsertIntersectedCountyFips(alertBase.AlertSpec.Content.Location);
				}
            }
			
			
	      
        }

        private static void SetTargetByAreaCriteria(AlertBase alertBase)
        {
            var areaAttachment = alertBase.AlertSpec.Advanced.GetAttachments().FirstOrDefault(a => a.AttachmentType.Equals(AttachmentType.Spatial) &&
                                                                                                   a.AttachmentSubType.Equals(AttachmentSubType.Location));
            if (areaAttachment == null) return;

            if (alertBase.AlertSpec.Targeting.TargetingCriteria == null)
                alertBase.AlertSpec.Targeting.TargetingCriteria = new List<ISearchCriteria>();

            alertBase.AlertSpec.Targeting.TargetingCriteria.Add(new SearchCriteria { NodeType = SearchNodeType.Geo, IsBlocked = false, SearchCriteriaID = areaAttachment.AttachmentId });
        }

        private static void SetTargetOrgByAreaCriteria(AlertBase alertBase)
        {
            var areaAttachment = alertBase.AlertSpec.Advanced.GetAttachments().FirstOrDefault(a => a.AttachmentType.Equals(AttachmentType.Spatial) &&
                                                                                                   a.AttachmentSubType.Equals(AttachmentSubType.Location));
            if (areaAttachment == null) return;

            if (alertBase.AlertSpec.Targeting.TargetingCriteria == null)
                alertBase.AlertSpec.Targeting.TargetingCriteria = new List<ISearchCriteria>();

            alertBase.AlertSpec.Targeting.TargetingCriteria.Add(new SearchCriteria { NodeType = SearchNodeType.OrgGeo, IsBlocked = false, SearchCriteriaID = areaAttachment.AttachmentId });
        }

        public string SaveAudio(string audioStream, string fileName)
        {
            var myByteArray = Convert.FromBase64String(audioStream);
            var stream = new MemoryStream();
            var writer = new StreamWriter(stream);
            writer.BaseStream.Write(myByteArray, 0, myByteArray.Length);
            writer.Flush();
            stream.Position = 0;

            var mediaId = MediaServiceWrapper.SaveMedia(stream, fileName, "wav", "audio/wav", "Alert Recorded Audio");
            return mediaId;
        }

        private static void SaveMassDeviceTargetingInfo(IList<Models.Publishing.Device> massDevices, TargetingSpecification spec)
        {
            if (spec.TargetingCriteria == null)
                spec.TargetingCriteria = new List<ISearchCriteria>();

            foreach (var device in massDevices)
            {
                foreach (var endPoint in device.EndPoints)
                {
                    spec.TargetingCriteria.Add(new SearchCriteria
                    {
                        SearchCriteriaID = endPoint.UserId, // user ID
                        NodeType = SearchNodeType.MassUser,
                        IsBlocked = false,
                        SearchValue = endPoint.UserName,
                    });
                }
            }

        }

        private string GetAlertExtensionTemplate(XElement element)
        {
            return element.Descendants("DeviceExtensions").First().Nodes().First().ToString();
        }

        private static void SaveOrganizationTargetingInfo(IList<TargetableOrganization> tNodes, TargetingSpecification spec)
        {
            if (tNodes == null)
                return;

            if (spec.TargetingCriteria == null)
                spec.TargetingCriteria = new List<ISearchCriteria>();

            foreach (var node in tNodes)
            {
                //if (node.Selected)
                spec.TargetingCriteria.Add(new SearchCriteria
                {
                    SearchCriteriaID = node.UserId, // user ID
                    NodeType = SearchNodeType.OrgUser,
                    IsBlocked = false,
                    SearchValue = node.GeoSelected.ToString() //node.Name,
                });
            }
        }

        public  void SetAccountabilityOfficers(IList<UserNode> uNodes, TargetingSpecification spec, int providerId, int operatorId)
        {

            if (spec.TargetingCriteria == null)
                spec.TargetingCriteria = new List<ISearchCriteria>();

            var userIds = uNodes.Select(u => u.UserId).ToList();
            var srchArgs = new UserSearchArgs(false, true, false)
            {
                ProviderId = providerId,
                AttributeNames = new List<string>() { "Login_Id" },
                ProviderCriteria = UserSearchHelper.GetProviderCriteria(providerId),
                OperatorCriteria = UserSearchHelper.GetOperatorUserBaseCriteria(operatorId, providerId),

            };
            srchArgs.Paging.UsersPerPage = Int32.MaxValue;
            var statusAttributeId = _userFacade.GetStatusAttributeId();
            var statusValueIds = _userFacade.GetStatusValueIds(new[] { AttributeCommonNames.ValidEnabledUsers });
            var statusCriteria = UserSearchHelper.GetUserStatusCriteria(statusAttributeId, statusValueIds);
            var userCriteria = UserSearchHelper.GetIndividualUserIdCriteria(userIds);
            srchArgs.TargetCriteria = userCriteria & statusCriteria;
            var sUser = _userFacade.SearchUsersByContext(srchArgs);


            if (uNodes != null && sUser != null)
            {
                uNodes.Join(sUser.Users, usrNode => usrNode.UserId, sUsr => sUsr.Id,
                    (usrNode, sUsr) => new SearchCriteria
                    {
                        SearchCriteriaID = usrNode.UserId, // user ID
                        NodeType = SearchNodeType.User,
                        IsBlocked = false,
                        SearchValue = usrNode.Name
                    }).ForEach(usr => spec.TargetingCriteria.Add(usr));
            }
        
}
        /// <summary>
        /// Assign scenario settings to alertbase object for save.
        /// </summary>
        /// <param name="model"></param>
        /// <param name="alertBase"></param>
        /// <param name="providerId"></param>
        /// <param name="operatorId"></param>
        public static void SetScenarioSectionSettings(PublishingModel model, AlertBase alertBase, int providerId, int operatorId = 0)
        {

            // Advanced Section Settings
            alertBase.PublishLayoutConfig.Advanced.Collapsed = model.ScenarioSettings.Advanced.Collapsed;
            alertBase.PublishLayoutConfig.Advanced.Readonly = model.ScenarioSettings.Advanced.Readonly;
            alertBase.PublishLayoutConfig.Advanced.Visible = model.ScenarioSettings.Advanced.Visible.Equals("Y");
            // Content Settings
            alertBase.PublishLayoutConfig.Content.Collapsed = model.ScenarioSettings.Content.Collapsed;
            alertBase.PublishLayoutConfig.Content.Readonly = model.ScenarioSettings.Content.Readonly;
            alertBase.PublishLayoutConfig.Content.Visible = model.ScenarioSettings.Content.Visible.Equals("Y");
            alertBase.PublishLayoutConfig.Content.DropboxEnabled = model.ScenarioSettings.Content.DropboxEnabled;
            alertBase.PublishLayoutConfig.Content.LocationEnabled = model.ScenarioSettings.Content.LocationEnabled;
            alertBase.PublishLayoutConfig.Content.LocationMandatoryEnabled = model.ScenarioSettings.Content.LocationMandatoryEnabled;
            alertBase.PublishLayoutConfig.Content.ResponseOptionEnabled = model.ScenarioSettings.Content.ResponseOptionEnabled;
            //Delivery Section Settings
            alertBase.PublishLayoutConfig.Delivery.Collapsed = model.ScenarioSettings.Delivery.Collapsed;
            alertBase.PublishLayoutConfig.Delivery.Readonly = model.ScenarioSettings.Delivery.Readonly;
            alertBase.PublishLayoutConfig.Delivery.Visible = model.ScenarioSettings.Delivery.Visible.Equals("Y");
            alertBase.PublishLayoutConfig.Delivery.EnableMassDevices = model.ScenarioSettings.Delivery.EnableMassDevices;
            alertBase.PublishLayoutConfig.Delivery.DisableAllDevices();
            if (model.ScenarioSettings.Delivery.EnabledDevices != null)
            {
                foreach (var devicesTypes in model.ScenarioSettings.Delivery.EnabledDevices.ToList())
                    alertBase.PublishLayoutConfig.Delivery.EnableDevice(devicesTypes, true);
            }
            //Targetting Section Settings
            alertBase.PublishLayoutConfig.Targeting.Collapsed = model.ScenarioSettings.Targeting.Collapsed;
            alertBase.PublishLayoutConfig.Targeting.Readonly = model.ScenarioSettings.Targeting.Readonly;
            alertBase.PublishLayoutConfig.Targeting.Visible = model.ScenarioSettings.Targeting.Visible.Equals("Y");
            alertBase.PublishLayoutConfig.Targeting.EnablePersonalDevices = model.ScenarioSettings.Targeting.EnablePersonalDevices;
            alertBase.PublishLayoutConfig.Targeting.FillCount = model.ScenarioSettings.Targeting.FillCount;

            alertBase.PublishLayoutConfig.Targeting.DisableAllTargeting();

            if (model.ScenarioSettings.Targeting.EnabledTargetingTypes != null)
            {

                foreach (var tarTypes in model.ScenarioSettings.Targeting.EnabledTargetingTypes)
                    alertBase.PublishLayoutConfig.Targeting.EnableTargeting(tarTypes, true);
            }
            //Organisation Section Settings
            alertBase.PublishLayoutConfig.Organization.Collapsed = model.ScenarioSettings.Organization.Collapsed;
            alertBase.PublishLayoutConfig.Organization.Readonly = model.ScenarioSettings.Organization.Readonly;
            alertBase.PublishLayoutConfig.Organization.Visible = model.ScenarioSettings.Organization.Visible.Equals("Y");
            alertBase.PublishLayoutConfig.Organization.TargetByAreaEnabled = model.ScenarioSettings.Organization.TargetByAreaEnabled;
            alertBase.PublishLayoutConfig.Organization.TargetByNameEnabled = model.ScenarioSettings.Organization.TargetByNameEnabled;

            //Accountability Workflow Settings
            alertBase.PublishLayoutConfig.AccountabilityWorkflow.IsAccountabilityMessagesCollapsed = model.ScenarioSettings.AccountabilityWorkflow.IsAccountabilityMessagesCollapsed;
            alertBase.PublishLayoutConfig.AccountabilityWorkflow.IsAccountabilityMessagesEnabled = !model.ScenarioSettings.AccountabilityWorkflow.IsAccountabilityMessagesReadonly;
            alertBase.PublishLayoutConfig.AccountabilityWorkflow.IsAccountabilityMessagesVisible = model.ScenarioSettings.AccountabilityWorkflow.IsAccountabilityMessagesVisible;
            alertBase.PublishLayoutConfig.AccountabilityWorkflow.IsContentSeverityVisible = model.ScenarioSettings.AccountabilityWorkflow.IsContentSeverityVisible;
            alertBase.PublishLayoutConfig.AccountabilityWorkflow.IsContentTypeVisible = model.ScenarioSettings.AccountabilityWorkflow.IsContentTypeVisible;

            alertBase.PublishLayoutConfig.AccountabilityOfficer = model.ScenarioSettings.AccountabilityOfficer;
        }

    }
}