﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AtHoc.Utilities;

namespace AtHoc.IWS.Web.Helpers
{
    public static class FormatUtility
    {
        /// <summary>
        /// Truncate text string extention method
        /// </summary>
        /// <param name="str"></param>
        /// <param name="max"></param>
        /// <param name="sub"></param>
        /// <returns></returns>
        public static string TruncateText(this string str, int max = 75, int sub = 75)
        {
            return str.Length > max ? string.Format("{0}...", str.Substring(0, sub)) : str;
        }

        /// <summary>
        /// Helper method for getting time span string
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <returns></returns>
        public static string GetTimeSpan(DateTime from, DateTime to)
        {
            try
            {
                TimeSpan dateDiff = (to - from);

                if (dateDiff.Days >= 1 || dateDiff.Days < -1)
                {
                    return string.Format("{0}d:{1:d2}h", dateDiff.Days, Math.Abs(dateDiff.Hours));
                }

                return string.Format("{0:d2}:{1:d2}:{2:d2}", dateDiff.Hours, Math.Abs(dateDiff.Minutes), Math.Abs(dateDiff.Seconds));
            }
            catch
            {
                return string.Empty;
            }
        }    
    }
}