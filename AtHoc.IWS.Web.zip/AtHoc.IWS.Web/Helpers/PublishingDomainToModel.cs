﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using AtHoc.Global.Resources.Interfaces;
using AtHoc.Infrastructure.Log;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel;
using AtHoc.IWS.Business.Domain.Event.Spec;
using AtHoc.IWS.Business.Domain.Events;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Settings.Impl;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Users.Impl;
using AtHoc.IWS.Business.Domain.Users.Impl.Search;
using AtHoc.IWS.Business.Domain.VirtualSystem;
using System.Net.Mime;
using System.Threading;
using System.Resources;
using AtHoc.Global.Resources;
using AtHoc.IWS.SSA.Business;
using AtHoc.IWS.SSA.Business.Facades;
using AtHoc.IWS.SSA.Dictionaries;
using AtHoc.IWS.Web.Models.Publishing;
using AtHoc.Publishing;
using AtHoc.Publishing.Configuration;
using AtHoc.Systems;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Devices;
using AtHoc.IWS.Business.Domain.Devices.Spec;
using Scenario = AtHoc.Publishing.Scenario;
using AtHoc.IWS.Business.Domain.Organization;
using AtHoc.IWS.Business.Domain.Targeting.Model;
using AtHoc.IWS.Business.Configurations;
using System.Xml.Linq;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Web.Models.SearchCriteria;
using AtHoc.IWS.Web.Models.UserManager;
using AtHoc.Infrastructure;
using AtHoc.Devices;
using System.Web;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.Publishing.Service;
using AtHoc.IWS.Business.Domain.Targeting;
using AtHoc.IWS.Business.Domain.Targeting.Spec;
using AtHoc.IWS.Business.Domain.VirtualSystem.Spec;
using AtHoc.IWS.Web.Converter.SearchCriteria;
using AtHoc.IWS.Business.Domain.Map;
using Device = AtHoc.Devices.Device;
using DeviceAddress = AtHoc.IWS.Web.Models.Publishing.DeviceAddress;
using AtHoc.IWS.Business.Adapter;
using AtHoc.IWS.Business.Domain.Entities.Accountability;
using AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel;
using PlaceHolderControlType = AtHoc.IWS.Business.Domain.Entities.PlaceHolderControlType;

namespace AtHoc.IWS.Web.Helpers
{
    public enum MassDevicePropertyEnums
    {
        HideDeviceUsers,
        AreaRequired,
        ExtractFips
    }

    public class PublishingDomainToModel : IPublishingDomainToModel
    {
        private readonly string _orgDeviceCommonName;

        private readonly IScenarioFacade _scenarioFacade;
        private readonly IEventFacade _eventFacade;
        private readonly IAlertFacade _alertFacade;
        private readonly ICustomAttributeFacade _customAttributeFacade;
        private readonly IDeviceFacade _deviceFacade;
        private readonly IVirtualSystemFacade _virtualSystemFacade;
        private readonly IProviderFacade _providerFacade;
        private readonly IOperatorDetailsFacade _operatorDetailsFacade;
        private readonly IMassDeviceTargetingFacade _massdevicetargettingFacade;
        private readonly ITargetingSettingsRepository _targetingSettingsRepository;
        private readonly ISearchCriteriaConverter _searchCriteriaConverter;
        private readonly IOrganizationFacade _organizationFacade;
        private readonly IGlobalEntityLocaleFacade _globalEntityLocaleFacade;

        private readonly ITargetingTreeFacade _targetingFacade;
        private readonly IMapFacade _mapFacade;
        private readonly ILogService _logService;
        private readonly IPlaceHolderFacade _placeHolderFacade;
        public PublishingDomainToModel(IScenarioFacade scenarioFacade, IEventFacade eventFacade, IAlertFacade alertFacade, ICustomAttributeFacade customAttributeFacade, IDeviceFacade deviceFacade,
            IVirtualSystemFacade virtualSystemFacade, IProviderFacade providerFacade, IOperatorDetailsFacade operatorDetailsFacade,
            IMassDeviceTargetingFacade massDeviceTargetingFacade, ITargetingSettingsRepository targetingSettingsRepository, ISearchCriteriaConverter searchCriteriaConverter,
            IOrganizationFacade organizationFacade, ITargetingTreeFacade targetingFacade, IMapFacade mapFacade, IPlaceHolderFacade placeholderFacade, IGlobalEntityLocaleFacade globalEntityLocaleFacade,ILogService logService)
        {
            _scenarioFacade = scenarioFacade;
            _eventFacade = eventFacade;
            _alertFacade = alertFacade;
            _customAttributeFacade = customAttributeFacade;
            _deviceFacade = deviceFacade;
            _virtualSystemFacade = virtualSystemFacade;
            _providerFacade = providerFacade;
            _operatorDetailsFacade = operatorDetailsFacade;
            _massdevicetargettingFacade = massDeviceTargetingFacade;
            _targetingSettingsRepository = targetingSettingsRepository;
            _orgDeviceCommonName = AtHocSystem.Local.ConnectDeviceCommonName;
            _searchCriteriaConverter = searchCriteriaConverter;
            _organizationFacade = organizationFacade;
            _targetingFacade = targetingFacade;
            _mapFacade = mapFacade;
            _placeHolderFacade = placeholderFacade;
            _globalEntityLocaleFacade = globalEntityLocaleFacade;
             _logService = logService;
        }


        public IList<KeyValueModel> GetEventCategories(Provider provider)
        {
            var eventCategories = _eventFacade.GetEventCategories(new EventCategorySpec { ProviderId = provider.Id }, provider.BaseLocale);
            var eventCategoryList = eventCategories as IList<EventCategory> ?? eventCategories.ToList();
            if (!eventCategoryList.Any())
            {
                _logService.Error(() => "No Event Categories found for the provider:" + provider.Id);
                return new List<KeyValueModel>();
            }

            var standardCategories = eventCategoryList.ToList().FindAll(eventCategory => eventCategory.EventCategoryType.Equals("Standard", StringComparison.InvariantCultureIgnoreCase));
            var eventCategoriesModeled = standardCategories.OrderBy(t => t.Name).Select(t => new KeyValueModel { Id = t.EventCategoryId, Name = t.Name, LogicalId = t.LogicalId }).ToList();

            //keep other as last type
            if (eventCategoriesModeled.Any() && eventCategoriesModeled.Any(t => t.LogicalId.Equals("Other", StringComparison.InvariantCultureIgnoreCase)))
            {
                var other = eventCategoriesModeled.FirstOrDefault(t => t.LogicalId.Equals("Other", StringComparison.InvariantCultureIgnoreCase));
                if (other != null)
                {
                    eventCategoriesModeled.Remove(other);
                    eventCategoriesModeled.Add(other);
                }
            }
            return eventCategoriesModeled.ToList();
        }

        /// <summary>
        /// Returns all Severities except Priority.Severe
        /// IWS-8368
        /// </summary>
        /// <returns></returns>
        public static IList<KeyValueModel> GetSeverities()
        {
            var severityList = from Priority p in Enum.GetValues(typeof(Priority))
                               where p != Priority.Severe
                               select new KeyValueModel() { Id = (int)p, Name = GetResourceString(p.GetDescription()) };
            return severityList.ToList<KeyValueModel>();
        }

        public IList<KeyValueModel> GetLocalizedSeverityList(string baseLocale)
        {

            return
                _globalEntityLocaleFacade.GetLocalizedEntity(SettingsHelper.Severities(), baseLocale)
                   .Select(
                        p =>
                            new KeyValueModel
                            {
                                Id = (int)(Priority)Enum.Parse(typeof(Priority), p.SeverityId),
                                Name = p.SeverityName
                            }).ToList();

        }

        public static string GetResourceString(string strDescription)
        {
            var resource = new System.Resources.ResourceManager(Constants.resourceAssembly, typeof(IWSResources).Assembly);
            return resource.GetString(strDescription, Thread.CurrentThread.CurrentUICulture);
        }

        private bool GetMassDeviceProperties(MassDevicePropertyEnums propertyEnums, string deviceCommonName)
        {
            string deviceCommonNameUpper = deviceCommonName.ToUpper();
            switch (propertyEnums)
            {
                case MassDevicePropertyEnums.HideDeviceUsers:
                    return (deviceCommonNameUpper == "UAP-IPAWS"
                            || deviceCommonNameUpper == "UAP-IPAWS-WEA"
                            || deviceCommonNameUpper == "UAP-IPAWS-NWEM"
                            || deviceCommonNameUpper == "UAP-IPAWS-EAS");
                case MassDevicePropertyEnums.AreaRequired:
                    return (deviceCommonNameUpper == "UAP-IPAWS-WEA"
                     || deviceCommonNameUpper == "UAP-IPAWS-NWEM"
                     || deviceCommonNameUpper == "UAP-IPAWS-EAS"
                     || deviceCommonNameUpper == "IIM-PUBLIC-FEED"
                     || deviceCommonNameUpper == "IIM-PUBLIC-FEED-V2");
                case MassDevicePropertyEnums.ExtractFips:
                    return (deviceCommonNameUpper == "UAP-IPAWS-WEA"
                            || deviceCommonNameUpper == "UAP-IPAWS-NWEM"
                            || deviceCommonNameUpper == "UAP-IPAWS-EAS"
                            || deviceCommonNameUpper == "UAP-IPAWS");
                default:
                    throw new InvalidEnumArgumentException();

            }

        }

        public PublishingModel GetPublishingModel(AlertBase entity, Provider provider, int operatorId, CustomAttributeLookup customAttributeLookup, string locale,
            bool isSystem = false, int parentId = 0, string recipientType = null, bool loadTargetingTree = false, bool loadTargetUser = true)
        {
            //getting all devices once so we don't have to repeat db calls
            var dm = new DeviceManager(provider.Id);
            var devices = dm.GetDevices(true, true);

            var model = GetPublishingModelBasicSettings(entity, provider, operatorId, parentId, recipientType, loadTargetingTree, locale);

            //model.Content = GetContents(entity, provider.Id, customAttributeLookup, locale);
            var content = Task.Factory.StartNew(() => GetContents(entity, provider, customAttributeLookup, locale));
            var presetGroupOption =
                Task.Factory.StartNew(
                    () => DeviceGroupPresetOptions(entity.AlertSpec.Delivery.CustomOption.RawExtensions, devices));
            //model.PresetDeviceGroupOptions = DeviceGroupPresetOptions(entity.AlertSpec.Delivery.CustomOption.RawExtensions, devices);
            var targetUsers = Task.Factory.StartNew(() => GetTargetUser(entity, provider, operatorId, locale, loadTargetUser));
            //model.TargetUsers = GetTargetUser(entity, provider.Id, operatorId, locale);
            var targetOrg =
                Task.Factory.StartNew(
                    () =>
                        (entity.AlertSpec.Targeting.TargetingCriteria != null)
                            ? GetTargetOrganizations(entity, provider.Id)
                            : null);
            Task.WaitAll(content, presetGroupOption, targetUsers, targetOrg);
            model.Content = content.Result;
            model.PresetDeviceGroupOptions = presetGroupOption.Result;
            model.TargetUsers = targetUsers.Result;
            model.TargetOrg = targetOrg.Result;
            if (entity.AlertSpec.Targeting.TargetingCriteria != null)
            {
                // targeted organizations
                model.TargetOrg = GetTargetOrganizations(entity, provider.Id);
            }

            // TO GET SELECTED MASSDEVICES BASED ON SCENARIO SETTINGS
            model.MassDevices = (from e in model.ScenarioSettings.MassDeviceList
                                 where model.ScenarioSettings.Delivery.EnabledDevices.Contains(e.DeviceId)
                                 select (new Models.Publishing.Device
                                 {
                                     DeviceId = e.DeviceId,
                                     DeviceName = e.DeviceName,
                                     GroupName = e.GroupName,
                                     GroupId = e.GroupId,
                                     Selected = entity.AlertSpec.Delivery.GetTargetedDevices().Contains(e.DeviceId),
                                     CommonName = e.CommonName,
                                     HideMassDeviceUsers = GetMassDeviceProperties(MassDevicePropertyEnums.HideDeviceUsers, e.CommonName),
                                     IsAreaRequired = GetMassDeviceProperties(MassDevicePropertyEnums.AreaRequired, e.CommonName),
                                     ExtractFIPS = GetMassDeviceProperties(MassDevicePropertyEnums.ExtractFips, e.CommonName),
                                     WarningText = e.WarningText
                                 })).ToList();


            GetMassDeviceTargetingInfo(provider.Id, model.MassDevices, entity);

            model.TestDeviceList = GetTestDeviceList(operatorId, model);


            //poplulating fill count spec...
            model.FillCount = entity.AlertSpec.FillCount;

            return model;
        }

        private PublishingModel GetPublishingModelBasicSettings(AlertBase entity, Provider provider, int operatorId,
            int parentId,
            string recipientType, bool loadTargetingTree, string locale)
        {
            if (entity is Scenario)
            {
                return GetScenarioModelSetting(entity, provider, parentId, locale);
            }
            else if (entity is Alert)
            {
                return GetAlertModelSettings(entity, provider, operatorId, recipientType, parentId, loadTargetingTree, locale);
            }
            else if ((entity is AccountabilityTemplate) || (entity is AccountabilityEvent))
            {
                // this is accoutability template or event....
                return GetAccountModelSetting(entity, provider, operatorId, parentId, locale);
            }
            return null;
        }

        private PublishingModel GetAlertModelSettings(AlertBase entity, Provider provider, int operatorId, string recipientType,
            int parentId, bool loadTargetingTree, string locale)
        {
            var model = new PublishingModel
            {
                IsReadyToPublish = entity.IsReadyForPublish,
                ParentId = parentId,
                ScenarioSection = new ScenarioSection()
            };
            var alertObj = (Alert)entity;
            model.Context = PublishingContext.Alert;
            model.EntityId = entity.AlertId;
            model.ScenarioSection.Name =
                (alertObj.Origin == null ||
                 string.IsNullOrWhiteSpace(alertObj.Origin.ScenarioName))
                    ? string.Empty
                    : alertObj.Origin.ScenarioName;
            model.AlertStatus = alertObj.Status.ToString();
            model.ScenarioSettings = GetScenarioSettings(alertObj.PublishLayoutConfig, provider.Id, locale, false);
            // Get Alert Schedule settings from domain  entity
            model.AlertScheduleSettings = GetAlertScheduleSettings(alertObj, provider, recipientType);
            model.CustomPlaceHolders = GetCustomPlaceHoldersByScenario(alertObj, operatorId);
            model.rbt = GetAlertCriteria(entity.AlertSpec.Targeting);
            model.IsTestAlertSupportOperator = GetOperatorStatus(provider.Id, operatorId);
            if (loadTargetingTree)
            {
                model.TargetingTree =
                    _targetingFacade.GetTargetingTreeNodes(new TargetingTreeSpec
                    {
                        ProviderId = provider.Id,
                        UserId = operatorId
                    }, ProviderAttributes);
            }

            if (alertObj.Origin != null && alertObj.Origin.Type == OriginType.ResultBased || model.rbt != null)
            {
                SetRbtProperties(model, model.EntityId);

            }
            return model;
        }


        /// <summary>
        ///  Returns list of localized custom attributes
        /// </summary>
        private CustomAttributeLookup ProviderAttributes
        {
            get
            {
                var customAttributes = RuntimeContext.CustomAttributesWithouMassDevices.Where(x => x.EntityId == "USER").ToArray();
                return new CustomAttributeLookup(customAttributes);
            }
        }

        private PublishingModel GetAccountModelSetting(AlertBase entity, Provider provider, int operatorId, int parentId, string locale)
        {
            // todo: need to review this section. we should have account context.
            var isAccountTemplate = entity is AccountabilityTemplate;
            var model = new PublishingModel
            {
                IsReadyToPublish = entity.IsReadyForPublish,
                ParentId = parentId,
                ScenarioSection = new ScenarioSection(),
                EntityId = isAccountTemplate ? ((AccountabilityTemplate)entity).TemplateId : 0
            };
            /*model.ScenarioSection.Name = scenario.Name;
            model.ScenarioSection.CommonName = scenario.CommonName;
            model.ScenarioSection.AvailableForQuickPublish = scenario.AvailableForQuickPublish;
            model.ScenarioSection.Description = scenario.Description;
            model.ScenarioSection.IsSystemScenario = _scenarioFacade.IsSystemScenario(scenario.CommonName);*/

            /*if (entity.AlertSpec.Category != null)
            {
                model.ScenarioSection.ChannelId = entity.AlertSpec.Category.Id;
            }*/

            /*model.ScenarioInfo = new ScenarioInfo
            {
                CreatedBy = entity.CreatedByName,
                CreatedOn = provider.SystemToVpsDateTimeFormated(entity.CreatedOnInSystemTimeZone),
                UpdatedBy = entity.UpdatedByName,
                UpdatedOn = provider.SystemToVpsDateTimeFormated(entity.UpdatedOnInSystemTimeZone)
            };*/

            model.ScenarioSettings = GetScenarioSettings(entity.PublishLayoutConfig, provider.Id, locale);
            model.ScenarioSettings.PersonalDeviceList =
                _deviceFacade.GetDevicesBySpec(new DeviceSpec
                {
                    ProviderId = provider.Id,
                    EnabledOnly = true,
                    IncludeDeviceGroup = true,
                    IsMassDevice = false
                }, locale)
                    .OrderBy(x => x.GroupId).Select(x => new Models.Publishing.Device
                    {
                        DeviceId = x.Id,
                        DeviceName = x.Name,
                        GroupName = x.DeviceGroup.Name,
                        GroupId = x.GroupId,
                        CommonName = x.CommonName,
                        Selected = model.ScenarioSettings.Delivery.EnabledDevices.Contains(x.Id)
                    }).ToList();

            if (model.ScenarioSettings.Targeting.Readonly) //if targeting section is R/O then load the targeting tree
            {
                model.TargetingTree =
                    _targetingFacade.GetTargetingTreeNodes(new TargetingTreeSpec
                    {
                        ProviderId = provider.Id,
                        UserId = operatorId
                    }, ProviderAttributes);
            }

            //model.ScenarioScheduleSettings = GetScenarioScheduleSettings(entity);
            return model;
        }


        private PublishingModel GetScenarioModelSetting(AlertBase entity, Provider provider, int parentId, string locale)
        {
            var scenario = entity as Scenario;
            var model = new PublishingModel
            {
                IsReadyToPublish = entity.IsReadyForPublish,
                ParentId = parentId,
                ScenarioSection = new ScenarioSection(),
                Context = PublishingContext.Scenario,
                EntityId = scenario.ScenarioId
            };
            model.ScenarioSection.Name = scenario.Name;
            model.ScenarioSection.CommonName = scenario.CommonName;
            model.ScenarioSection.AvailableForQuickPublish = scenario.AvailableForQuickPublish;
            model.ScenarioSection.Description = scenario.Description;
            model.ScenarioSection.IsSystemScenario = _scenarioFacade.IsSystemScenario(scenario.CommonName);

            if (entity.AlertSpec.Category != null)
            {
                model.ScenarioSection.ChannelId = entity.AlertSpec.Category.Id;
            }

            model.ScenarioInfo = new ScenarioInfo
            {
                CreatedBy = entity.CreatedByName,
                CreatedOn = provider.SystemToVpsDateTimeFormated(entity.CreatedOnInSystemTimeZone),
                UpdatedBy = entity.UpdatedByName,
                UpdatedOn = provider.SystemToVpsDateTimeFormated(entity.UpdatedOnInSystemTimeZone)
            };

            model.ScenarioSettings = GetScenarioSettings(scenario.PublishLayoutConfig, provider.Id, locale);
            model.ScenarioSettings.PersonalDeviceList =
                _deviceFacade.GetDevicesBySpec(new DeviceSpec
                {
                    ProviderId = provider.Id,
                    EnabledOnly = true,
                    IncludeDeviceGroup = true,
                    IsMassDevice = false
                }, locale)
                    .OrderBy(x => x.GroupId).Select(x => new Models.Publishing.Device
                    {
                        DeviceId = x.Id,
                        DeviceName = x.Name,
                        GroupName = x.DeviceGroup.Name,
                        GroupId = x.GroupId,
                        CommonName = x.CommonName,
                        Selected = model.ScenarioSettings.Delivery.EnabledDevices.Contains(x.Id)
                    }).ToList();
            model.ScenarioScheduleSettings = GetScenarioScheduleSettings(scenario);
            return model;
        }

        private static List<DeviceAddress> GetTestDeviceList(int operatorId, PublishingModel model)
        {
            var addresses = Devices.DeviceAddress.GetAddresses(operatorId);

            var testDeviceList =
                (addresses.Where(e => model.ScenarioSettings.Delivery.EnabledDevices.Contains(e.DeviceId))
                    .Select(a => new AtHoc.IWS.Web.Models.Publishing.DeviceAddress
                    {
                        UserId = a.UserId,
                        DeviceId = a.DeviceId,
                        Address = a.Address,
                        AddressId = a.AddressId
                    }).ToList());
            return testDeviceList;
        }

        private PublishingContent GetContents(AlertBase entity, Provider provider, CustomAttributeLookup customAttributeLookup, string locale)
        {
            var eventCategories = GetEventCategories(provider);
            KeyValueModel selectedEventCategory;
            var selectedEventCategoryId = GetEventCategoryId(entity, eventCategories, out selectedEventCategory);
            var content = new PublishingContent
            {
                SeverityId = (int)entity.AlertSpec.Priority,
                SeverityName = entity.AlertSpec.Priority.ToString(),
                Title = entity.AlertSpec.Content.Header,
                Body = entity.AlertSpec.Content.Body,
                TargetUrl = entity.AlertSpec.Content.Url,
                TypeId = selectedEventCategoryId ?? 0,
                Local = entity.Locale.LocaleCode,
                CategoryType = selectedEventCategory,
                Severities = GetLocalizedSeverityList(provider.BaseLocale),
            };

            var severity = content.Severities.FirstOrDefault(c => c.Id.Equals(content.SeverityId));
            if (severity != null)
            {
                content.SeverityName = severity.Name;
            }
            content.Types = eventCategories;
            //keep other as last type

            var other =
                content.Types.FirstOrDefault(t => t.LogicalId.Equals("Other", StringComparison.InvariantCultureIgnoreCase));
            if (other != null)
            {
                content.Types.Remove(other);
                content.Types.Add(other);
                if (content.TypeId == 0)
                {
                    content.TypeId = other.Id;
                }
            }

            var type = eventCategories.FirstOrDefault(t => t.Id == content.TypeId);
            content.TypeName = (type == null) ? string.Empty : type.Name;

            //Response option values
            content.ResponseOptionId = entity.AlertSpec.Content.ResponseOptionsAttributeID;
            content.ResponseOptions = (from r in entity.AlertSpec.Content.ResponseOptions
                                       select new AtHoc.IWS.Web.Models.Publishing.ResponseOption
                                       {
                                           ResponseText = r.Text,
                                           CallBridgeNumber = HttpUtility.HtmlDecode(r.CallNumber),
                                           PassCode = HttpUtility.HtmlDecode(r.Passcode),
                                           ConferenceUrl = r.ConferenceUrl
                                       }).ToList();

            content.ResponseOptionList = customAttributeLookup
                .Where(
                    a =>
                        a.IsStandard == "N" && a.IsSystemAttribute == "N" &&
                        (a.AttributeTypeId == CustomAttributeDataType.Checkbox ||
                         a.AttributeTypeId == CustomAttributeDataType.Picklist) && a.Values.HasValue())
                .OrderBy(a => a.AttributeName)
                .Select(
                    a =>
                        new KeyValueModel
                        {
                            Id = a.Id,
                            Name = a.AttributeName,
                            Values =
                                (!a.Values.HasValue()) ? new List<string>() : a.Values.Select(v => v.ValueName).ToList()
                        })
                .ToList();

            //Reset response option if changed for scenario and alert not live/ended
            if (content.ResponseOptionId > 0)
            {
                if ((entity is Scenario) ||
                    ((entity is Alert) &&
                     !(((Alert)entity).Status == AlertStatus.Live || ((Alert)entity).Status == AlertStatus.Ended))
                    || (entity is AccountabilityTemplate) || ((entity is AccountabilityEvent) && !(((AccountabilityEvent)entity).Status == AccountabilityEventStatus.Live || ((AccountabilityEvent)entity).Status == AccountabilityEventStatus.Ended))
                    )
                {
                    content.ResponseOptions.Clear();
                    var attributeOption =
                        content.ResponseOptionList.FirstOrDefault(r => r.Id == content.ResponseOptionId);
                    if (attributeOption != null)
                    {
                        content.ResponseOptions =
                            attributeOption.Values.Select(
                                r => new AtHoc.IWS.Web.Models.Publishing.ResponseOption { ResponseText = r }).ToList();
                    }
                }
            }

            var resourceManager = IWSResources.ResourceManager;
            content.ResponseOptionList.Insert(0,
                new KeyValueModel
                {
                    Id = 0,
                    Name = resourceManager.GetString("Publishing_CustomResponseOptions", CultureInfo.GetCultureInfo(locale)),
                    Values = new List<string>()
                });

            content.Languages = _alertFacade.GetSupportedLanguages(provider.Id)
                .Select(l =>
                    new LanguageModel()
                    {
                        Code = l.LocalCode,
                        Name = l.LanguageName,
                        DisplayCode = l.LocalCode.ToUpper()
                    }).ToList();

            //location GeoJson
            content.LocationGeo = GetLocationAsGeoJson(entity, provider.Id);
            return content;
        }

        private TargetUsers GetTargetUser(AlertBase entity, Provider provider, int operatorId, string locale, bool loadTargetUser = true)
        {
            var targetUsers = new TargetUsers { };

            List<Models.Publishing.Device> Devices = new List<Models.Publishing.Device>();
            var devicesVPS = _deviceFacade.GetDevicesBySpec(new DeviceSpec
                                {
                                    IsMassDevice = false,
                                    ProviderId = provider.Id,
                                    EnabledOnly = true,
                                    GetDeletedDevices = false,
                                    IncludeDeviceProvider = false
                                }, locale);

            foreach (int id in entity.AlertSpec.Delivery.GetTargetedDevices())
            {

                var device = devicesVPS.Where(a => a.Id == id).FirstOrDefault();
                if (device != null)
                {
                    Devices.Add(new Models.Publishing.Device
                    {
                        DeviceId = id,
                        DeviceName = device.Name,
                        HideInReadOnlyView = (device.CommonName == _orgDeviceCommonName),
                        WarningText = device.TargetingConfirmationText,
                        GroupId = device.GroupId
                    });
                }
            }


            /*
        var targetUsers = new TargetUsers
        {
            Devices = from id in entity.AlertSpec.Delivery.GetTargetedDevices()
                      let device = _deviceFacade.GetDeviceBySpec(new DeviceSpec() { DeviceId = id, IncludeDeviceGroup = true}, locale)
                      where (!device.IsMassDevice)
                      select new Models.Publishing.Device
                      {
                          DeviceId = id,
                          DeviceName = device.Name,
                          HideInReadOnlyView = (device.CommonName == _orgDeviceCommonName),
                          WarningText = device.TargetingConfirmationText,
                          GroupId = device.GroupId
                          //if device is org, need to be hidden in read only view
                      }
        };*/

            targetUsers.Devices = Devices;

            if (entity is Alert)
            {
                var alertObj = (Alert)entity;
                if (alertObj.Status == AlertStatus.Live || alertObj.Status == AlertStatus.Ended || alertObj.Status == AlertStatus.Publishing || alertObj.Status == AlertStatus.Scheduled)
                {
                    targetUsers.TargetedUserCountForLiveEndedAlert = alertObj.RecipientUsersCount;
                }
            }

            targetUsers.TargetingNodes = GetTargetingTreeNodes(entity.AlertSpec.Targeting, provider.Id, operatorId);

            if (entity.AlertSpec.Targeting.TargetingCriteria != null)
            {
                var criteriaModel = GetAdvancedQueryCriteria(entity.AlertSpec.Targeting, provider, operatorId);
                if (criteriaModel != null)
                {
                    targetUsers.TargetedCriteria = criteriaModel;
                }
            }

            //targeting settings
            targetUsers.TargetUsersByArea = entity.AlertSpec.Targeting.TargetUsersByArea;

            if (loadTargetUser)
                targetUsers.TargetedBlockedUsers = GetTargetedBlockedUserList(entity, provider.Id, operatorId);
            else
                targetUsers.TargetedBlockedUsers = null;

            return targetUsers;
        }

        private static int? GetEventCategoryId(AlertBase entity, IList<KeyValueModel> eventCategories, out KeyValueModel selectedEventCategory)
        {
            var selectedEventCategoryId = entity.AlertSpec.EventCategoryId;
            selectedEventCategory = (entity.AlertSpec.EventCategoryId.HasValue)
                ? eventCategories.Where(t => t.Id == entity.AlertSpec.EventCategoryId.Value)
                    .Select(t => new KeyValueModel { Id = t.Id, Name = t.Name, LogicalId = t.LogicalId })
                    .FirstOrDefault()
                : new KeyValueModel();
            if (selectedEventCategory != null && selectedEventCategory.Name == null && entity.AlertSpec.EventCategory != null)
            {
                selectedEventCategory =
                    eventCategories.Where(t => t.Name == entity.AlertSpec.EventCategory)
                        .Select(t => new KeyValueModel { Id = t.Id, Name = t.Name, LogicalId = t.LogicalId })
                        .FirstOrDefault();
                selectedEventCategoryId = selectedEventCategory != null ? selectedEventCategory.Id : 0;
            }
            return selectedEventCategoryId;
        }

        private static List<DeviceGroupPresetOptions> DeviceGroupPresetOptions(Dictionary<int, string> rawExtensions, List<Device> devices)
        {
            var presetOptions = new List<DeviceGroupPresetOptions>();

            foreach (var kvp in rawExtensions)
            {
                var deviceGroup = devices.FirstOrDefault(a => a.Group.Extension != null && a.Group.Extension.ID == kvp.Key);
                if (deviceGroup != null)
                {
                    //this is encoded twice for IWS-12457                
                    presetOptions.Add(new DeviceGroupPresetOptions
                    {
                        Id = kvp.Key,
                        selection = HttpUtility.HtmlEncode(HttpUtility.HtmlEncode(kvp.Value)),
                        GroupId = deviceGroup.Group.Id
                    });
                }
            }
            return presetOptions;
        }

        private IList<Node> GetTargetingTreeNodes(TargetingSpecification spec, int providerId, int operatorId)
        {
            var result = new List<Node>();
            //when populating group targeting filter out query criteria.
            if (spec.TargetingCriteria.HasValue())
            {
                var treeCriteria = spec.TargetingCriteria.Where(t => t.NodeType == SearchNodeType.AllUserBase
                    || t.NodeType == SearchNodeType.Attribute || t.NodeType == SearchNodeType.AttributeValue
                    || t.NodeType == SearchNodeType.DynamicList || t.NodeType == SearchNodeType.ListHrchy
                    || t.NodeType == SearchNodeType.ListHrchy || t.NodeType == SearchNodeType.OrgHrchy
                    || t.NodeType == SearchNodeType.StaticList).ToList();

                if (treeCriteria.HasValue())
                {
                    result.AddRange(treeCriteria.Select(criteria => new Node()
                    {
                        Id = criteria.SearchCriteriaID,
                        IsBlocked = criteria.IsBlocked.HasValue && criteria.IsBlocked.Value,
                        Type = GetNodeType(criteria.NodeType, criteria),
                        DlType = GetDlType(criteria.NodeType, criteria),
                        ParentId = ConvertHelper.TryParseInt(criteria.SearchValue),
                        Selected = true,
                    }));
                }
            }

            return result;
        }

        private DistributionListType? GetDlType(SearchNodeType searchNodeType, ISearchCriteria criteria)
        {
            DistributionListType? dlType = null;
            switch (searchNodeType)
            {
                case SearchNodeType.DynamicList:
                    dlType = DistributionListType.Dynamic;
                    break;
                case SearchNodeType.StaticList:
                    dlType = DistributionListType.Static;
                    break;
            }

            return dlType;
        }

        private NodeType GetNodeType(SearchNodeType searchNodeType, ISearchCriteria criteria)
        {
            var nodeType = NodeType.Dummy;
            switch (searchNodeType)
            {
                case SearchNodeType.AllUserBase:
                    nodeType = NodeType.AllUserBase;
                    break;
                case SearchNodeType.Attribute:
                    nodeType = NodeType.CustomAttribute;
                    break;
                case SearchNodeType.AttributeValue:
                    nodeType = NodeType.CustomAttributeValue;
                    break;
                case SearchNodeType.DynamicList:
                    nodeType = NodeType.DistributionList;
                    break;
                case SearchNodeType.StaticList:
                    nodeType = NodeType.DistributionList;
                    break;
                case SearchNodeType.OrgHrchy:
                    if (!criteria.SearchValue.IsNullOrEmpty() && criteria.SearchValue == "/")
                    {
                        nodeType = NodeType.Root;
                    }
                    else
                    {
                        nodeType = NodeType.Folder;
                    }
                    break;
                case SearchNodeType.ListHrchy:
                    if (!criteria.SearchValue.IsNullOrEmpty() && criteria.SearchValue == "/")
                    {
                        nodeType = NodeType.Root;
                    }
                    else
                    {
                        nodeType = NodeType.Folder;
                    }
                    break;
            }

            return nodeType;
        }

        public bool GetOperatorStatus(int providerId, int operatorId)
        {
            var userFacade = new UserFacade();
            var user = userFacade.GetUserBySpec(new UserSpec { UserId = operatorId, ProviderId = providerId });
            return user != null && user.ProviderId == providerId;
        }

        public bool GetCustomPlaceHoldersStatus(int sid, int providerId, int operatorId)
        {

            var phQueryManger = new PlaceHolderManager();
            var dtoList = phQueryManger.GetByScenarioId(providerId, operatorId, sid);

            if (dtoList != null && dtoList.PlaceHolders != null && dtoList.PlaceHolders.Any())
                dtoList.PlaceHolders = dtoList.PlaceHolders.Where(p => p != null);
            var customPhListStatus =
                PlaceHolderSort.ByOrder(dtoList)
                    .Where(p => p.DisplayType == Publishing.Entity.PlaceHolderType.Custom)
                    .ToList()
                    .Count;

            return customPhListStatus > 0;
        }

        public List<AtHoc.IWS.Web.Models.Publishing.PlaceHolder> GetCustomPlaceHoldersByScenario(Alert alert, int operatorId)
        {
            //Get placeholder list associated with the scenario
            //Filter to return custom placeholders            
            int sid = alert.Origin.ScenarioId;
            // refactor the code, don't use existing legacy calls from publishing dll
            var phQueryManger = new PlaceHolderManager();
            var dtoList = phQueryManger.GetByScenarioId(alert.ProviderId, operatorId, sid);

            if (dtoList != null && dtoList.PlaceHolders != null && dtoList.PlaceHolders.Any())
                dtoList.PlaceHolders = dtoList.PlaceHolders.Where(p => p != null).Distinct();

            var customPhList = _placeHolderFacade.GetCustomerPlaceHolders(dtoList, alert.ProviderId, operatorId).Select(x => new Models.Publishing.PlaceHolder
            {
                CommonName = x.CommonName,
                Name = x.Name ?? x.CommonName,
                ControlType = x.ControlType.ToString(),
                DisplayLines = x.DisplayLines,
                DisplayType = x.DisplayType.ToString(),
                Id = x.Id,
                MaximumLength = x.MaximumLength,
                MinimumLength = x.MinimumLength,
                Values = x.Values.ToList()
            }).ToList();
            foreach (var item in customPhList)
            {
                if (item.Values.HasValue() && item.Values.Count > 0)
                {
                    string iValue = item.Values[0].Value == null ? string.Empty : item.Values[0].Value.ToString();
                    switch (item.ControlType)
                    {
                        case "Date":
                            item.Values[0].Value = string.IsNullOrEmpty(iValue) ? string.Empty : DateTimeHelper.ConvertFromUTCTicksToDate(iValue, 0);
                            break;
                        case "DateTime":
                            item.Values[0].Value = string.IsNullOrEmpty(iValue) ? string.Empty : DateTimeHelper.ConvertFromUTCTicksToDateTime(iValue);
                            break;
                        case "Time":
                            item.Values[0].Value = string.IsNullOrEmpty(iValue) ? string.Empty : DateTimeHelper.ConvertFromUTCTicksToTime(iValue);
                            break;
                    }
                }
            }
            return customPhList;
        }


        private TargetOrg GetTargetOrganizations(AlertBase alertbase, int providerId)
        {
            var allOrgs = _organizationFacade.GetActiveOrganization(providerId).ToList();
            var activeOrgIds = allOrgs.Select(o => o.UserId).ToList();
            var targetedOrgdIds = alertbase.AlertSpec.Targeting.TargetingCriteria.Where(c => c.NodeType.Equals(SearchNodeType.OrgUser)).Select(c => c.SearchCriteriaID).ToList();
            var disconnectedOrgIds = targetedOrgdIds.Except(activeOrgIds).ToList();
            var targetOrg = new TargetOrg();

            //always show orgs on the UI...
            targetOrg.TargetedOrganizations = (from o in alertbase.AlertSpec.Targeting.TargetingCriteria
                                               where o.NodeType.Equals(SearchNodeType.OrgUser)
                                                       && !disconnectedOrgIds.Contains(o.SearchCriteriaID)
                                               select new TargetableOrganization
                                               {
                                                   UserId = o.SearchCriteriaID,
                                                   GeoSelected = ConvertHelper.TryParseBoolean(o.SearchValue)
                                               }).ToList();

            var userFacade = new UserFacade();
            foreach (var org in targetOrg.TargetedOrganizations)
            {
                var user = userFacade.GetUserBySpec(new UserSpec { UserId = org.UserId, ProviderId = alertbase.ProviderId });
                if (user != null)
                {
                    if (user.DisplayName.HasValue() && (!user.DisplayName.Equals("N/A")))
                        org.Name = user.DisplayName.Trim();
                    else if ((user.FirstName.HasValue()) || (user.LastName.HasValue()))
                        org.Name = (user.FirstName + " " + user.LastName).Trim();
                    else org.Name = user.UserName;
                }
            }

            //targeting settings
            targetOrg.TargetAllOrganizations = alertbase.AlertSpec.Targeting.TargetAllOrganizations;
            targetOrg.TargetOrganizationsByArea = alertbase.AlertSpec.Targeting.TargetOrganizationsByArea;

            return targetOrg;
        }

        private static List<UserNode> GetTargetedBlockedUserList(AlertBase alertbase, int providerId, int operatorId)
        {
            if (alertbase.AlertSpec.Targeting.TargetingCriteria == null || alertbase.AlertSpec.Targeting.TargetingCriteria.Count <= 0)
                return new List<UserNode>();

            var users =
                alertbase.AlertSpec.Targeting.TargetingCriteria.Where(t => t.NodeType.Equals(SearchNodeType.User)).AsQueryable();

            var userNodeList =
                (from e in users
                 select new UserNode
                 {
                     UserId = e.SearchCriteriaID,
                     Name = e.SearchValue,
                     IsBlocked = (bool)e.IsBlocked,
                 }).ToList();

            if (userNodeList.Count == 0)
                return userNodeList;

            var userIds = userNodeList.Select(u => u.UserId).ToList();
            // TODO: refactor later, quick search for now
            // populate user name

            var userFacade = new UserFacade();

            var srchArgs = new UserSearchArgs(false, true, false)
            {
                ProviderId = providerId,
                AttributeNames = new List<string>() { "Login_Id", "FirstName", "LastName", "DisplayName", "Status" },
                ProviderCriteria = UserSearchHelper.GetProviderCriteria(providerId),
                OperatorCriteria = UserSearchHelper.GetOperatorUserBaseCriteria(operatorId, providerId),
                Paging = new PagingParameters()
                {
                    UsersPerPage = int.MaxValue,
                    PageNo = 1,
                    SortColumn = "USER_ID",
                    IsAsc = true,
                }
            }; //SHOW OPERATOR IS SET TO FALSE IN V1, NEED TO MAKE SURE THAT ITS SAME HERE

            var statusAttributeId = userFacade.GetStatusAttributeId();
            var statusValueIds = userFacade.GetStatusValueIds(new[] { "VLD" });
            var statusCriteria = UserSearchHelper.GetUserStatusCriteria(statusAttributeId, statusValueIds);

            var userCriteria = UserSearchHelper.GetIndividualUserIdCriteria(userIds);
            srchArgs.TargetCriteria = userCriteria & statusCriteria;

            var sUser = userFacade.SearchUsersByContext(srchArgs);

            userNodeList.ForEach(u =>
            {
                var user = sUser.Users.Find(o => o.Id == u.UserId);
                if (user != null)
                {
                    if (user.DisplayName.HasValue() && (!user.DisplayName.Equals("N/A")))
                        u.Name = user.DisplayName.Trim();
                    else if ((user.FirstName.HasValue()) || (user.LastName.HasValue()))
                        u.Name = (user.FirstName + " " + user.LastName).Trim();
                    else u.Name = user.UserName;
                    if (user.UserAttributes != null && user.UserAttributes.Count > 0)
                    {
                        u.Status = UserStatusType.Active;
                    }
                }
                else
                {
                    u.Status = UserStatusType.Disabled;
                }

            });
            if (alertbase is Alert)
            {
                var alert = alertbase as Alert;
                if (alert.Status == AlertStatus.Live || alert.Status == AlertStatus.Ended)
                {
                    return userNodeList.AsQueryable().OrderByDescending(p => !p.IsBlocked).ThenBy(p => p.Name).ToList();
                }
            }

            return userNodeList.AsQueryable().Where(p => p.Status == UserStatusType.Active || p.Status == UserStatusType.Enabled).OrderByDescending(p => !p.IsBlocked).ThenBy(p => p.Name).ToList();
        }


        public  List<UserNode> GetAccountabilityOfficers(TargetingSpecification spec, int providerId, int operatorId)
        {
            if (spec.TargetingCriteria == null || spec.TargetingCriteria.Count <= 0)
                return new List<UserNode>();

            var users =
                spec.TargetingCriteria.Where(t => t.NodeType.Equals(SearchNodeType.User)).AsQueryable();

            var userNodeList =
                (from e in users
                 select new UserNode
                 {
                     UserId = e.SearchCriteriaID,
                     Name = e.SearchValue,
                 }).ToList();

            if (userNodeList.Count == 0)
                return userNodeList;

            var userIds = userNodeList.Select(u => u.UserId).ToList();
            // TODO: refactor later, quick search for now
            // populate user name

            var userFacade = new UserFacade();

            var srchArgs = new UserSearchArgs(false, true, false)
            {
                ProviderId = providerId,
                AttributeNames = new List<string>() { "Login_Id", "FirstName", "LastName", "DisplayName", "Status" },
                ProviderCriteria = UserSearchHelper.GetProviderCriteria(providerId),
                OperatorCriteria = UserSearchHelper.GetOperatorUserBaseCriteria(operatorId, providerId),
                Paging = new PagingParameters()
                {
                    UsersPerPage = int.MaxValue,
                    PageNo = 1,
                    SortColumn = "USER_ID",
                    IsAsc = true,
                }
            }; //SHOW OPERATOR IS SET TO FALSE IN V1, NEED TO MAKE SURE THAT ITS SAME HERE

            var statusAttributeId = userFacade.GetStatusAttributeId();
            var statusValueIds = userFacade.GetStatusValueIds(new[] { "VLD" });
            var statusCriteria = UserSearchHelper.GetUserStatusCriteria(statusAttributeId, statusValueIds);

            var userCriteria = UserSearchHelper.GetIndividualUserIdCriteria(userIds);
            var roleIds = new List<int> { (int)Business.Domain.Entities.Roles.EnterpriseAdmin, (int)Business.Domain.Entities.Roles.AccountabilityManager, (int)Business.Domain.Entities.Roles.AccountabilityOfficer };
            var roleCriteria = UserSearchHelper.GetUserRoleCriteria(roleIds);
            srchArgs.TargetCriteria = userCriteria & statusCriteria & roleCriteria;

            var sUser = userFacade.SearchUsersByContext(srchArgs);

            userNodeList.ForEach(u =>
            {
                var user = sUser.Users.Find(o => o.Id == u.UserId);
                if (user != null)
                {
                    if (user.DisplayName.HasValue() && (!user.DisplayName.Equals("N/A")))
                        u.Name = user.DisplayName.Trim();
                    else if ((user.FirstName.HasValue()) || (user.LastName.HasValue()))
                        u.Name = (user.FirstName + " " + user.LastName).Trim();
                    else u.Name = user.UserName;
                    if (user.UserAttributes != null && user.UserAttributes.Count > 0)
                    {
                        u.Status = UserStatusType.Active;
                    }
                }
                else
                {
                    u.Status = UserStatusType.Disabled;
                }

            });
            
            return userNodeList.AsQueryable().Where(p => p.Status == UserStatusType.Active || p.Status == UserStatusType.Enabled).OrderByDescending(p => !p.IsBlocked).ThenBy(p => p.Name).ToList();
        }

        /// <summary>
        /// /
        /// </summary>
        /// <param name="alert"></param>
        /// <param name="provider"></param>
        /// <param name="recipientType"></param>
        /// <returns></returns>
        private static AlertScheduleModel GetAlertScheduleSettings(Alert alert, Provider provider, string recipientType = null)
        {
            var schedulesettings = new AlertScheduleModel(provider);
            var startDateTimeHelper = new DateTimeHelper(provider.UtcToVpsTime(DateTime.UtcNow), provider);
            schedulesettings.ScheduleAlertpublishStartDateInput = startDateTimeHelper.TheDateTimeFormatted;
            schedulesettings.TimeFormat = (from TimeFormatEnum tformat in Enum.GetValues(typeof(TimeFormatEnum))
                                           select new MultiSelectListModel()
                                           {
                                               Value = tformat.ToString(),
                                               Text = tformat.Display() ?? tformat.ToString()
                                           }).ToList();
            if (!alert.IsNew)
            {
                schedulesettings.ScheduleDurationInput = alert.AlertSpec.LiveDuration.Value;
                schedulesettings.ScheduleDurationInputUnit = alert.AlertSpec.LiveDuration.Unit.ToString();
                schedulesettings.ScheduleAlertPublishStartModeSettime = alert.PublishAtCurrentTime ? AlertingStartTime.ASAP.ToString() : AlertingStartTime.SetTime.ToString();

                if ((alert.Status == AlertStatus.Live || alert.Status == AlertStatus.Ended) && (recipientType == null))
                {

                    var startdatetime = new DateTimeHelper(alert.StartTime, provider);
                    schedulesettings.ScheduleAlertpublishStartDateInput = startdatetime.TheDateTimeFormatted;

                    var enddatetime = new DateTimeHelper(alert.EndTime, provider);

                    //Commented,to assign End date in date and time format (#iws-20992) 
                    //if (alert.Status == AlertStatus.Ended)
                    //    schedulesettings.ScheduleAlertpublishEndDateInput = enddatetime.TheDateTimeFormatted;
                    //else
                    //{
                    //    schedulesettings.ScheduleAlertpublishEndDateInput = enddatetime.TheDateFormatted;
                    //}
                    schedulesettings.ScheduleAlertpublishEndDateInput = enddatetime.TheDateTimeFormatted;
                }

                else
                {
                    if (schedulesettings.ScheduleAlertPublishStartModeSettime.Equals(AlertingStartTime.SetTime.ToString()))
                    {
                        var startdatetime = new DateTimeHelper(alert.StartTime, provider);
                        schedulesettings.ScheduleAlertpublishStartDateInput = startdatetime.TheDateTimeFormatted;
                    }
                }
            }
            else
            {
                schedulesettings.ScheduleDurationInput = alert.AlertSpec.LiveDuration.Value;
                schedulesettings.ScheduleDurationInputUnit = alert.AlertSpec.LiveDuration.Unit.ToString();
                var scheduleHelper = new ScheduleHelper();

                var dataSchedule = scheduleHelper.GetScenarioSchedule(alert.Origin.ScenarioId, alert.ProviderId);
                if (dataSchedule != null)
                {
                    if (dataSchedule.ActivateRecurrence)
                    {
                        schedulesettings.ScheduleAlertpublishStartDateInput =
                            dataSchedule.RecurrenceStartDateTimeHelper.TheDateTimeFormatted;
                    }
                }
            }
            return schedulesettings;
        }

        private static ScheduleModel GetScenarioScheduleSettings(Scenario entity)
        {
            var schedulesettings = new ScheduleModel();
            var sschedule = new ScheduleHelper();
            var dataSchedule = sschedule.GetScenarioSchedule(entity.ScenarioId, entity.ProviderId);
            schedulesettings.TimeFormat = (from TimeFormatEnum tformat in Enum.GetValues(typeof(TimeFormatEnum))
                                           select new MultiSelectListModel()
                                           {
                                               Value = tformat.ToString(),
                                               Text = tformat.Display() ?? tformat.ToString()
                                           }).ToList();

            schedulesettings.TimePeriod = (from TimePeriodEnum tformat in Enum.GetValues(typeof(TimePeriodEnum))
                                           select new MultiSelectListModel()
                                           {
                                               Value = Convert.ToInt16(tformat).ToString(CultureInfo.InvariantCulture),
                                               Text = tformat.Display() ?? tformat.ToString()
                                           }).ToList();
            schedulesettings.DayNames = (from DayNamesEnum tformat in Enum.GetValues(typeof(DayNamesEnum))
                                         select new MultiSelectListModel()
                                         {
                                             Value = Convert.ToInt16(tformat).ToString(CultureInfo.InvariantCulture),
                                             Text = tformat.Display() ?? tformat.ToString()
                                         }).ToList();

            schedulesettings.NumberNames = (from NumberNamesEnum tformat in Enum.GetValues(typeof(NumberNamesEnum))
                                            select new MultiSelectListModel()
                                            {
                                                Value = Convert.ToInt16(tformat).ToString(CultureInfo.InvariantCulture),
                                                Text = tformat.Display() ?? tformat.ToString()
                                            }).ToList();

            schedulesettings.MonthNames = (from MonthNamesEnum tformat in Enum.GetValues(typeof(MonthNamesEnum))
                                           select new MultiSelectListModel()
                                           {
                                               Value = Convert.ToInt16(tformat).ToString(CultureInfo.InvariantCulture),
                                               Text = tformat.Display() ?? tformat.ToString()
                                           }).ToList();

            if (dataSchedule != null)
            {
                schedulesettings.ScheduleActivateRecurrenceCheck = dataSchedule.ActivateRecurrence;
                schedulesettings.ScheduleDurationInput = entity.AlertSpec.LiveDuration.Value;
                schedulesettings.ScheduleDurationUnitSelect = entity.AlertSpec.LiveDuration.Unit.ToString();

                schedulesettings.ScheduleRecurrenceRadio = ((int)dataSchedule.RecurrencePattern).ToString();

                if (schedulesettings.ScheduleRecurrenceRadio.Equals("32"))
                    schedulesettings.ScheduleRecurrenceRadio = "16";
                else if (schedulesettings.ScheduleRecurrenceRadio.Equals("128"))
                    schedulesettings.ScheduleRecurrenceRadio = "64";

                schedulesettings.recurrenceTime = dataSchedule.RecurrenceStartDateTimeHelper.TheTimeFormattedWithoutSeconds;
                //Daily
                schedulesettings.ScheduleRecurrenceDailyRadiogroup = ((int)dataSchedule.RecurrenceDailyMode).ToString();
                schedulesettings.ScheduleRecurrenceDailyFrequencyInput = dataSchedule.RecurrenceDailyFrequency;
                schedulesettings.ScheduleRecurrenceWeeklyFrequencyInput = dataSchedule.RecurrenceWeeklyFrequency;
                schedulesettings.ScheduleRecurrenceWeekly.Clear();
                if (dataSchedule.RecurrenceWeeklyMask > 0)
                {
                    for (var i = 0; i <= 6; i++)
                    {
                        var mask = Convert.ToInt16(Math.Pow(2, i));
                        if ((dataSchedule.RecurrenceWeeklyMask & mask) > 0)
                        {
                            schedulesettings.ScheduleRecurrenceWeekly.Add(mask.ToString(CultureInfo.InvariantCulture));
                        }
                    }
                }
                //Monthly
                schedulesettings.ScheduleRecurrenceMonthlyRadiogroup = ((int)dataSchedule.RecurrenceMonthlyMode).ToString();
                schedulesettings.ScheduleRecurrenceMonthlyFrequencyInput = dataSchedule.RecurrenceMonthlyFrequency;
                schedulesettings.ScheduleRecurrenceMonthlyAbsoluteDaySelect = dataSchedule.RecurrenceMonthlyAbsoluteDay;
                schedulesettings.ScheduleRecurrenceMonthlyRelativeDayofweekSelect = dataSchedule.RecurrenceMonthlyRelativeDayofWeek;
                schedulesettings.ScheduleRecurrenceMonthlyRelativeWeeknumSelect = dataSchedule.RecurrenceMonthlyRelativeWeekNum;
                //Yearly
                schedulesettings.ScheduleRecurrenceYearlyModeRadiogroup = ((int)dataSchedule.RecurrenceYearlyMode).ToString();
                schedulesettings.ScheduleRecurrenceYearlyAbsoluteMonthSelect = dataSchedule.RecurrenceYearlyAbsoluteMonth;
                schedulesettings.ScheduleRecurrenceYearlyAbsoluteDayInput = dataSchedule.RecurrenceYearlyAbsoluteDay;
                schedulesettings.ScheduleRecurrenceYearlyRelativeMonthSelect = dataSchedule.RecurrenceYearlyRelativeMonth;
                schedulesettings.ScheduleRecurrenceYearlyRelativeWeeknumSelect = dataSchedule.RecurrenceYearlyRelativeWeekNum;
                schedulesettings.ScheduleRecurrenceYearlyRelativeDayofweekSelect = dataSchedule.RecurrenceYearlyRelativeDayofWeek;
                //Recurrence Period
                schedulesettings.ScheduleRecurrenceStartDateInput = dataSchedule.RecurrenceStartDateTimeHelper.TheDateFormatted;
                schedulesettings.ScheduleRecurrenceEndCountInput = dataSchedule.RecurrenceEndCount;
                schedulesettings.ScheduleRecurrenceEndRadiogroup = ((int)dataSchedule.RecurrenceEnd).ToString();
                schedulesettings.ScheduleRecurrenceEnddateInput = dataSchedule.RecurrenceEndDateFormatted;
            }

            return schedulesettings;
        }

        /// <summary>
        /// Get scenario section settings from publishing layout configuration
        /// </summary>
        /// <param name="configId"></param>
        /// <returns></returns>
        public ScenarioSettings GetScenarioSettings(PublishLayoutConfiguration config, int providerId, string locale, bool isScenario = true)
        {
            var settings = new ScenarioSettings();
            var publishLayoutSettings = config;

            if (publishLayoutSettings.IsNew)
            {
                if (isScenario)
                {
                    publishLayoutSettings.Organization.TargetByAreaEnabled = true;
                    publishLayoutSettings.Organization.TargetByNameEnabled = true;
                    publishLayoutSettings.Targeting.FillCount = true;
                    if (!locale.Equals("en-US"))
                    {
                        publishLayoutSettings.Delivery.Visible = false;
                        publishLayoutSettings.Delivery.Collapsed = false;
                        publishLayoutSettings.Delivery.Readonly = false;
                    }
                }
                publishLayoutSettings.Targeting.EnablePersonalDevices = true;
                publishLayoutSettings.Delivery.EnableMassDevices = true;
            }

            settings.Id = publishLayoutSettings.Id;
            settings.Content.Collapsed = publishLayoutSettings.Content.Collapsed;
            settings.Content.DropboxEnabled = publishLayoutSettings.Content.DropboxEnabled;
            settings.Content.LocationEnabled = publishLayoutSettings.Content.LocationEnabled;
            settings.Content.LocationMandatoryEnabled = publishLayoutSettings.Content.LocationMandatoryEnabled;
            settings.Content.ResponseOptionEnabled = publishLayoutSettings.Content.ResponseOptionEnabled;
            settings.Content.Readonly = publishLayoutSettings.Content.Readonly;
            settings.Content.Visible = publishLayoutSettings.Content.Visible ? "Y" : "N";
            settings.Targeting.FillCount = publishLayoutSettings.Targeting.FillCount;
            settings.Targeting.Collapsed = publishLayoutSettings.Targeting.Collapsed;
            settings.Targeting.EnabledTargetingTypes = publishLayoutSettings.Targeting.EnabledTargetingTypes;
            settings.Targeting.Readonly = publishLayoutSettings.Targeting.Readonly;
            settings.Targeting.Visible = publishLayoutSettings.Targeting.Visible ? "Y" : "N"; ;
            settings.Targeting.EnablePersonalDevices = publishLayoutSettings.Targeting.EnablePersonalDevices;
            settings.Delivery.Collapsed = publishLayoutSettings.Delivery.Collapsed;
            settings.Delivery.EnabledDevices = publishLayoutSettings.Delivery.EnabledDevices;
            settings.Delivery.Readonly = publishLayoutSettings.Delivery.Readonly;
            settings.Delivery.Visible = publishLayoutSettings.Delivery.Visible ? "Y" : "N"; ;
            settings.Delivery.EnableMassDevices = publishLayoutSettings.Delivery.EnableMassDevices;
            settings.Organization.Collapsed = publishLayoutSettings.Organization.Collapsed;
            settings.Organization.TargetByAreaEnabled = publishLayoutSettings.Organization.TargetByAreaEnabled;
            settings.Organization.TargetByNameEnabled = publishLayoutSettings.Organization.TargetByNameEnabled;
            settings.Organization.Readonly = publishLayoutSettings.Organization.Readonly;
            settings.Organization.Visible = publishLayoutSettings.Organization.Visible ? "Y" : "N";
            settings.Advanced.Collapsed = publishLayoutSettings.Advanced.Collapsed;
            settings.Advanced.Readonly = publishLayoutSettings.Advanced.Readonly;
            settings.Advanced.Visible = publishLayoutSettings.Advanced.Visible ? "Y" : "N";

            settings.AccountabilityWorkflow.IsAccountabilityMessagesCollapsed = publishLayoutSettings.AccountabilityWorkflow.IsAccountabilityMessagesCollapsed;
            settings.AccountabilityWorkflow.IsAccountabilityMessagesReadonly = !publishLayoutSettings.AccountabilityWorkflow.IsAccountabilityMessagesEnabled;
            settings.AccountabilityWorkflow.IsAccountabilityMessagesVisible = publishLayoutSettings.AccountabilityWorkflow.IsAccountabilityMessagesVisible;
            settings.AccountabilityWorkflow.IsContentSeverityVisible = publishLayoutSettings.AccountabilityWorkflow.IsContentSeverityVisible;
            settings.AccountabilityWorkflow.IsContentTypeVisible = publishLayoutSettings.AccountabilityWorkflow.IsContentTypeVisible;

            settings.AccountabilityOfficer = publishLayoutSettings.AccountabilityOfficer;

            // to populate the mass device section with enabled device list
            settings.MassDeviceList =
                _deviceFacade.GetDevicesBySpec(new DeviceSpec
                {
                    ProviderId = providerId,
                    EnabledOnly = true,
                    IncludeDeviceGroup = true,
                    IsMassDevice = true,

                }, locale)
                    .Where(x => x.CommonName != _orgDeviceCommonName)
                    .OrderBy(x => x.DeviceGroup.Name)
                    .ThenByDescending(x => x.Name)
                    .Select(
                        x =>
                            new Models.Publishing.Device
                            {
                                DeviceId = x.Id,
                                DeviceName = x.Name,
                                GroupName = x.DeviceGroup.Name,
                                GroupId = x.GroupId,
                                Selected = settings.Delivery.EnabledDevices.Contains(x.Id),
                                CommonName = x.CommonName,
                                WarningText = x.TargetingConfirmationText
                            })
                    .ToList();


            return settings;
        }

        private static MapLayer GetLocationLayer(int attachmentId, int providerId)
        {
            var mapMgr = ManagerFactory.Instance.CreateMapManager();
            mapMgr.ProviderId = providerId;
            var alertLocationLayer = mapMgr.GetMapLayer(attachmentId,
                new MapFilterCriteria()
                {
                    ProviderId = providerId,
                    MapLayerType = MapLayerSourceType.Alert,
                    NonPeopleLayersOnly = false
                });
            return alertLocationLayer;
        }

        private static string GetLocationAsGeoJson(AlertBase alertBase, int providerId)
        {
            if (alertBase.AlertSpec.Advanced == null)
                return string.Empty;

            var attachments = alertBase.AlertSpec.Advanced.GetAttachments(AttachmentType.Spatial, AttachmentSubType.Location);
            if (attachments == null || attachments.ToList().Count < 1)
                return string.Empty;

            // geolocation
            // get GeoJson from map layer ID
            var alertLocationLayer = GetLocationLayer(attachments.ToList()[0].AttachmentId, providerId);
            return (alertLocationLayer != null) ? alertLocationLayer.GeoJson : string.Empty;
        }

        public void ExtractTargetAndDeviceInfoFromEntity(AlertBase ab, int providerId, int operatorId, IPublishingFacade publishingFacade, ref TargetedUserCriteria criteria)
        {
            //set device info
            criteria.SelectedDevices = ab.AlertSpec.Delivery.GetTargetedDevices();
            //set selected tree nodes info
            criteria.SelectedTreeNodes = (List<Node>)(GetTargetingTreeNodes(ab.AlertSpec.Targeting, providerId, operatorId));
        }

        public void SetRbtProperties(PublishingModel model, int entity)
        {
            // set other targeting to false
            if (model.TargetingTree != null)
                model.TargetingTree.Clear();

            if(model.TargetUsers != null && model.TargetUsers.TargetingNodes != null)
                model.TargetUsers.TargetingNodes.Clear();

            model.TargetUsers.TargetUsersByArea = false;
            model.TargetOrg.TargetAllOrganizations = false;
            model.TargetOrg.TargetOrganizationsByArea = false;
            model.ScenarioSettings.Targeting.Visible = "Y";
            model.ScenarioSettings.Delivery.Visible = "N";
            model.ScenarioSettings.Organization.Visible = "N";

            if (model.rbt!=null  && model.rbt.AccountabilityEventId > 0)
                model.ScenarioSettings.Advanced.Visible = "Y";

            model.ScenarioSettings.Targeting.EnabledTargetingTypes.Clear();
            model.AlertOrigin = OriginType.ResultBased;

            //model.AlertStatus = AlertStatus.Standby.ToString();
            model.EntityId = entity;
            model.TargetUsers.TargetedCriteria = null;
            if (model.TargetUsers.TargetedBlockedUsers != null)
                model.TargetUsers.TargetedBlockedUsers.Clear();

        }

        public PublisherSettings GetPublisherSettings(Provider provider)
        {
            //These flags should not be depended on provider type but should be fetched from vps settings
            // var featureMatrix = RuntimeContext.Provider.FeatureMatrix;
            // Changed for IWS-21927
            if (provider.FeatureMatrix == null)
                provider.FeatureMatrix = _providerFacade.GetFeatureMatrix(provider.Id);

            var featureMatrix = provider.FeatureMatrix;
            var settings = new PublisherSettings
            {
                IsGroupBlockSupported = featureMatrix.IsGroupBlockingSupported,
                IsAdvancedQuerySuuported = featureMatrix.IsAdvancedQuerySupported,
                IsIndividualUserTargetingSupported = featureMatrix.IsIndividualUserTargetingSupported,
                IsTargetByAreaSupported = featureMatrix.IsTargetByAreaSupported,
                IsDropboxSupported = featureMatrix.IsDropboxSupported,
                IsMassDeviceTargetSupported = featureMatrix.IsMassDeviceTargetSupported,
                IsCallbridgeOptionSupported = (featureMatrix.IsCallbridgeOptionSupported && _targetingSettingsRepository.GetCallBridgeSetting(provider.Id)),
                IsSchedulingSupported = featureMatrix.IsSchedulingSupported,
                IsTestAlertSupported = featureMatrix.IsTestAlertSupported,
                IsPrintAlertSupported = featureMatrix.IsPrintAlertSupported,
                IsDeviceOptionSupported = featureMatrix.IsDeviceOptionSupported,
                IsAlertTemplateSettingSupported = featureMatrix.IsAlertTemplateSettingSupported,
                IsPlaceholderSupported = featureMatrix.IsPlaceholderSupported,
                IsDeviceDeliveryOrderSupported = featureMatrix.IsDeviceDeliveryOrderSupported,
                IsChannelSupported = featureMatrix.IsChannelSupported,
                IndividualUserTargetSelectionLimit = 1000,
                IsLyncEnabled = isLyncDeviceEnabled(provider.Id, provider.BaseLocale),
                IsOrgHierarchySupported = featureMatrix.IsOrgHierarchySupported,
                IsRecordedAudioSupported = featureMatrix.IsRecordedAudioSupported,
                IsFillCountSupported = featureMatrix.IsFillCountSupported,
                EnableDeviceOptionCache = featureMatrix.EnableDeviceOptionCache
            };

            return settings;
        }

        private bool isLyncDeviceEnabled(int providerId, string locale)
        {
            DeviceSpec spec = new DeviceSpec();
            spec.CommonName = "imTextLync";
            spec.ProviderId = providerId;
            spec.IncludeDeviceProvider = true;
            var ld = _deviceFacade.GetDeviceBySpec(spec, RuntimeContext.Provider.BaseLocale);
            return ld != null && ld.DeviceProvider.IsEnabled == "Y";
        }

        public bool OrganizationEnabled(IOrganizationFacade organizationFacade, int providerId)
        {
            //ConnectivityStatus connectivityStatus = organizationFacade.GetConnectivityStatus(providerId);
            //if (connectivityStatus == ConnectivityStatus.NotConfigured ||
            //    connectivityStatus == ConnectivityStatus.DeviceNotConfigured ||
            //    connectivityStatus == ConnectivityStatus.NotListed)
            //{
            //    return false;
            //}

            return true;
        }
        public IList<MassDeviceTargetingEndPoint> GetEndPointFromDevice(int providerid, Models.Publishing.Device device)
        {
            IList<MassDeviceTargetingEndPoint> targettingEndpoints = new List<MassDeviceTargetingEndPoint>();
            var userListTargetingResult = _massdevicetargettingFacade.GetMassDeviceEndpoints(new MassDeviceTargetingSpec { ProviderId = providerid, DeviceId = device.DeviceId, DeviceCommonName = device.CommonName });
            device.ExtractFIPS = GetMassDeviceProperties(MassDevicePropertyEnums.ExtractFips, device.CommonName);
            device.HideMassDeviceUsers = GetMassDeviceProperties(MassDevicePropertyEnums.HideDeviceUsers,
                device.CommonName);
            device.IsAreaRequired = GetMassDeviceProperties(MassDevicePropertyEnums.AreaRequired, device.CommonName);

            if (userListTargetingResult == null || userListTargetingResult.Count == 0)
            {
                device.Enabled = false;
            }
            else
            {
                device.Enabled = true;
            }

            foreach (var user in userListTargetingResult)
            {
                var endPoint = new MassDeviceTargetingEndPoint();
                endPoint.UserId = user.UserId;
                endPoint.UserName = user.UserName;
                endPoint.IsSelected = false;
                endPoint.IsKeyUser = (user.GiantVoiceType != null) && user.GiantVoiceType.Equals("key", StringComparison.InvariantCultureIgnoreCase);
                if (device.HideMassDeviceUsers)
                {
                    if (userListTargetingResult.Count == 1)
                        endPoint.IsVisible = false;
                    else
                        endPoint.IsVisible = true;
                }
                targettingEndpoints.Add(endPoint);
            }
            return targettingEndpoints;
        }

        public IList<MassDeviceTargetingEndPoint> GetEndPointFromDevices(int providerid, Models.Publishing.DeviceEndPoints device)
        {
            IList<MassDeviceTargetingEndPoint> targettingEndpoints = new List<MassDeviceTargetingEndPoint>();
            var userListTargetingResult = _massdevicetargettingFacade.GetMassDeviceEndpoints(new MassDeviceTargetingSpec { ProviderId = providerid, DeviceId = device.DeviceId, DeviceCommonName = device.CommonName });


            device.ExtractFIPS = GetMassDeviceProperties(MassDevicePropertyEnums.ExtractFips, device.CommonName);
            device.HideMassDeviceUsers = GetMassDeviceProperties(MassDevicePropertyEnums.HideDeviceUsers,
                device.CommonName);
            device.IsAreaRequired = GetMassDeviceProperties(MassDevicePropertyEnums.AreaRequired, device.CommonName);
            if (userListTargetingResult == null || userListTargetingResult.Count == 0)
            {
                device.Enabled = false;
            }
            else
            {
                device.Enabled = true;
            }


            foreach (var user in userListTargetingResult)
            {
                var endPoint = new MassDeviceTargetingEndPoint();
                endPoint.UserId = user.UserId;
                endPoint.UserName = user.UserName;
                endPoint.IsSelected = false;
                endPoint.IsKeyUser = (user.GiantVoiceType != null) && user.GiantVoiceType.Equals("key", StringComparison.InvariantCultureIgnoreCase);
                if (device.HideMassDeviceUsers)
                {
                    if (userListTargetingResult.Count == 1)
                        endPoint.IsVisible = false;
                    else
                        endPoint.IsVisible = true;
                }
                targettingEndpoints.Add(endPoint);
            }
            return targettingEndpoints;
        }
        private void GetMassDeviceTargetingInfo(int providerid, IList<Models.Publishing.Device> devices, AlertBase alertbase)
        {

            if (alertbase.AlertSpec.Targeting.TargetingCriteria != null)
            {
                var targettedUsers = (from o in alertbase.AlertSpec.Targeting.TargetingCriteria
                                      where o.NodeType.Equals(SearchNodeType.MassUser)
                                      select o.SearchCriteriaID).ToList<int>();

                var selectedDevices = (from d in devices
                                       where d.Selected
                                       select d).ToList();

                foreach (var device in selectedDevices)
                {
                    var endPoints = GetEndPointFromDevice(providerid, device);
                    foreach (var endPoint in endPoints)
                    {
                        if (targettedUsers.Contains(endPoint.UserId))
                        {
                            if (endPoint.IsKeyUser)
                            {
                                endPoint.IsTargetable = true;
                                device.IsKeyUserTargetted = true;
                            }
                            endPoint.IsSelected = true;
                            device.EndPoints.Add(endPoint);
                            device.SelectedUsers.Add(endPoint.UserId);
                        }
                    }
                }
            }
        }

        private ResultBasedTargeting GetAlertCriteria(TargetingSpecification spec)
        {
            if (spec.TargetingCriteria == null || spec.TargetingCriteria.Where(t => t.NodeType.Equals(SearchNodeType.Query)).ToList().Count < 1)
                return null;

            var queryCriteria = spec.TargetingCriteria.FirstOrDefault(t => t.NodeType.Equals(SearchNodeType.Query));

            var rbt = new ResultBasedTargeting();
            if (queryCriteria != null)
            {
                // currently it holds fill count flag this can be removed once code refactoring done 
                if (queryCriteria.SearchCriteriaID > -1)
                    rbt.FillCountType = ((ResultBasedCriteriaOperator)queryCriteria.SearchCriteriaID).ToString();

                if (queryCriteria.SearchQueries != null && queryCriteria.SearchQueries.Any())
                {
                    var alertQuery = queryCriteria.SearchQueries.FirstOrDefault();
                    if (alertQuery.QueryType == SearchQueryType.Alert)
                    {
                        rbt.AlertId = alertQuery.QueryEntityID ?? 0;
                        rbt.EntityFilterId = alertQuery.AlertOperator.ToString();
                        rbt.AccountabilityEventId = 0;
                        int deviceId = 0;
                        // in case of RBT with Device Targeting
                        Int32.TryParse(queryCriteria.SearchValue, out deviceId);
                        if (deviceId > 0)
                        {
                            rbt.DeviceId = deviceId;
                            rbt.IncludeDevices = true;
                        }
                    }
                    // below condition will be executed in case of PA Event
                    else if (alertQuery.QueryType == SearchQueryType.PAEvent)
                    {
                        rbt.AccountabilityEventId = (alertQuery.QueryEntityID ?? 0);
                        rbt.AlertId = 0;
                        // Collection will be available in case of  MultipleResponse  option
                        if (alertQuery.SearchValueCollections != null &&
                            alertQuery.SearchValueCollections.Any())
                        {
                            var searchValueCollection = alertQuery.SearchValueCollections.FirstOrDefault();
                            if (searchValueCollection != null)
                                rbt.EntityFilterId = searchValueCollection.SearchValue;
                        }
                        else
                        {
                            // This condition will be executed in case of Targeted, NoResponse, AnyResponse
                            rbt.EntityFilterId = alertQuery.AccountabilityOperator.ToString();
                        }
                    }
                }
            }
            return string.IsNullOrEmpty(rbt.EntityFilterId) ? null : rbt;
        }

        public SearchCriteriaModel GetAdvancedQueryCriteria(TargetingSpecification spec, Provider provider)
        {
            return GetAdvancedQueryCriteria(spec, provider, RuntimeContext.OperatorId);
        }

        private SearchCriteriaModel GetAdvancedQueryCriteria(TargetingSpecification spec, Provider provider, int operatorId)
        {
            if (spec.TargetingCriteria == null || spec.TargetingCriteria.Where(t => t.NodeType.Equals(SearchNodeType.Query)).ToList().Count < 1)
                return null;

            var selections = new List<Selection>();
            var display = new List<Display>();
            var displayNoStyle = new List<string>();

            var queryCriteriaList = spec.TargetingCriteria.Where(t => t.NodeType.Equals(SearchNodeType.Query)).ToList();
            foreach (var queryCriteria in queryCriteriaList)
            {
                if (queryCriteria.SearchQueries != null)
                {
                    foreach (var searchQuery in queryCriteria.SearchQueries.ToList())
                    {
                        Selection newSelection = null;
                        switch (searchQuery.QueryType)
                        {
                            case SearchQueryType.Attribute:
                                //newSelection = GetAttributeSelection(searchQuery);
                                AddAttributeSelection(searchQuery, ref selections, ref display, ref displayNoStyle, provider);
                                break;
                            case SearchQueryType.Device:
                                AddDeviceSelection(searchQuery, ref selections, ref display, ref displayNoStyle, provider.BaseLocale);
                                //newSelection = GetDeviceSelection(searchQuery);
                                break;
                            case SearchQueryType.OperatorRole:
                                AddRoleSelection(searchQuery, provider.Id, ref selections, ref display, ref displayNoStyle, provider.BaseLocale);
                                break;
                            case SearchQueryType.VirtualSystem:
                                AddVpsSelection(searchQuery, provider.Id, operatorId, ref selections, ref display, ref displayNoStyle);
                                break;
                        }
                    }
                }
            }

            return new SearchCriteriaModel(display, selections, displayNoStyle);
        }

        private void AddRoleSelection(SearchQuery searchQuery, int providerId, ref List<Selection> selections, ref List<Display> display, ref List<string> displayNoStyle, string locale)
        {
            var providerRoles = _operatorDetailsFacade.GetOperatorRoles(new OperatorRoleSpec { ProviderId = providerId, BaseLocale = locale }).OrderBy(x => x.RoleName);

            if (providerRoles.ToList().Count < 1)
                return;

            var rm = IWSResources.ResourceManager;
            var condition = (int)searchQuery.Operator.GetValueOrDefault();
            var newSelection = new Selection(searchQuery.QueryEntityID.GetValueOrDefault(),
                CustomAttributeDataType.MultiPicklist, GroupType.ROLE, rm.GetString("DisplayName_OperatorRoles"),
                0, condition);

            var roleNames = new List<string>();

            foreach (var searchValue in searchQuery.SearchValueCollections.ToList())
            {
                var valueAsInt = 0;
                int.TryParse(searchValue.SearchValue, out valueAsInt);
                var role = providerRoles.FirstOrDefault(r => r.Id == valueAsInt);
                if (role != null)
                {
                    newSelection.CreateValue(valueAsInt, GroupType.ROLE, role.RoleName);
                    roleNames.Add(role.RoleName);
                }
            }

            //return newSelection;
            selections.Add(newSelection);
            string val = roleNames.Join(",");
            display.Add(new Display { DisplayText = _searchCriteriaConverter.getRoleDisplayText(new CriteriaParam { Operator = (int)searchQuery.Operator, Value = val }, newSelection, true) });
            displayNoStyle.Add(_searchCriteriaConverter.getRoleDisplayText(new CriteriaParam { Operator = (int)searchQuery.Operator, Value = val }, newSelection, false));

        }

        private void AddVpsSelection(SearchQuery searchQuery, int providerId, int operatorId, ref List<Selection> selections, ref List<Display> display, ref List<string> displayNoStyle)
        {
            var providerIds = _virtualSystemFacade.GetProviderIdsByOperatorContext(providerId, operatorId);

            IEnumerable<Provider> providersList = new List<Provider>();
            foreach (var pid in providerIds)
            {
                ((List<Provider>)providersList).Add(_virtualSystemFacade.GetProviderBySpec(new VirtualSystemSpec { Id = pid, IncludeExtendedParams = true }));
            }

            if (providersList.ToList().Count < 1)
                return;

            var rm = IWSResources.ResourceManager;
            var condition = (int)searchQuery.Operator.GetValueOrDefault();
            var newSelection = new Selection(searchQuery.QueryEntityID.GetValueOrDefault(),
                CustomAttributeDataType.MultiPicklist, GroupType.VPS, rm.GetString("DisplayName_Organizations"),
                0, condition);

            var vpsNames = new List<string>();

            foreach (var searchValue in searchQuery.SearchValueCollections.ToList())
            {
                var valueAsInt = 0;
                int.TryParse(searchValue.SearchValue, out valueAsInt);
                var vps = providersList.ToList().FirstOrDefault(r => r.Id == valueAsInt);
                if (vps != null)
                {
                    newSelection.CreateValue(valueAsInt, GroupType.VPS, vps.DisplayName);
                    vpsNames.Add(vps.DisplayName);
                }
            }

            selections.Add(newSelection);
            string val = vpsNames.Join(",");
            display.Add(new Display { DisplayText = _searchCriteriaConverter.getVPSDisplayText(new CriteriaParam { Operator = (int)searchQuery.Operator, Value = val }, newSelection, true) });
            displayNoStyle.Add(_searchCriteriaConverter.getVPSDisplayText(new CriteriaParam { Operator = (int)searchQuery.Operator, Value = val }, newSelection, false));

        }

        private Selection GetAttributeSelection(SearchQuery searchQuery)
        {
            var attributeList = _customAttributeFacade.GetCustomAttributesBySpec(new CustomAttributeSpec { Id = searchQuery.QueryEntityID });
            if (attributeList != null && attributeList.ToList().Count > 0)
            {
                var attribute = attributeList.ToList()[0];
                var condition = (int)searchQuery.Operator.GetValueOrDefault();
                var newSelection = new Selection(searchQuery.QueryEntityID.GetValueOrDefault(),
                    attribute.AttributeTypeId.GetValueOrDefault(), GroupType.ATTRIBUTE, attribute.AttributeName,
                    0, condition);

                foreach (var searchQueryValue in searchQuery.SearchValueCollections.ToList())
                {
                    switch (attribute.AttributeTypeId.GetValueOrDefault())
                    {
                        case CustomAttributeDataType.Picklist:
                        case CustomAttributeDataType.MultiPicklist:
                        case CustomAttributeDataType.Checkbox:
                            //  newSelection = AddSelectionValue(newSelection, searchQueryValue, searchQuery.QueryEntityID.GetValueOrDefault());
                            break;
                        default:
                            newSelection.CreateValue(0, GroupType.ATTRIBUTEVALUE, searchQueryValue.SearchValue);
                            break;
                    }
                }
                return newSelection;
            }
            return null;
        }

        private void AddAttributeSelection(SearchQuery searchQuery, ref List<Selection> selections, ref List<Display> display, ref List<string> displayNoStyle, Provider provider)
        {
            var attributeList = _customAttributeFacade.GetCustomAttributesBySpec(new CustomAttributeSpec { Id = searchQuery.QueryEntityID, IncludeValues = true, BaseLocale = provider.BaseLocale, ProviderId = provider.Id });
            if (attributeList != null && attributeList.ToList().Count > 0)
            {
                var attribute = attributeList.ToList()[0];
                var condition = (int)searchQuery.Operator.GetValueOrDefault();
                var newSelection = new Selection(searchQuery.QueryEntityID.GetValueOrDefault(),
                    attribute.AttributeTypeId.GetValueOrDefault(), GroupType.ATTRIBUTE, attribute.AttributeName,
                    0, condition, attribute.CommonName ?? "");

                foreach (var searchQueryValue in searchQuery.SearchValueCollections.ToList())
                {
                    switch (attribute.AttributeTypeId.GetValueOrDefault())
                    {
                        case CustomAttributeDataType.Picklist:
                        case CustomAttributeDataType.MultiPicklist:
                        case CustomAttributeDataType.Checkbox:
                            newSelection = AddSelectionValue(newSelection, searchQueryValue, searchQuery.QueryEntityID.GetValueOrDefault(), provider.BaseLocale);
                            break;
                        case CustomAttributeDataType.Path:
                            newSelection.CreateValue(searchQueryValue.ID, GroupType.ATTRIBUTEVALUE, searchQueryValue.SearchValue, searchQueryValue.SearchValue);
                            break;
                        default:
                            newSelection.CreateValue(0, GroupType.ATTRIBUTEVALUE, searchQueryValue.SearchValue);
                            break;

                    }

                }
                selections.Add(newSelection);

                string searchValue = searchQuery.SearchValueCollections.Select(x => x.SearchValue).Join(",");

                if (attribute.AttributeTypeId.GetValueOrDefault().Equals(CustomAttributeDataType.GeoLocation))
                {
                    display.Add(new Display { DisplayText = _searchCriteriaConverter.getDisplayText(new CriteriaParam { Operator = (int)searchQuery.Operator, Value = searchValue }, attribute, true, provider) });
                }
                else
                {

                    display.Add(new Display { DisplayText = _searchCriteriaConverter.getDisplayText(new CriteriaParam { Operator = (int)searchQuery.Operator, Value = searchValue }, attribute, true, provider) });
                }
                displayNoStyle.Add(_searchCriteriaConverter.getDisplayText(new CriteriaParam { Operator = (int)searchQuery.Operator, Value = searchValue }, attribute, false, provider));
            }
        }

        private Selection AddSelectionValue(Selection newSelection, SearchValueCollection searchQueryValue, int entityId, string locale)
        {
            var valueAsInt = 0;
            var isValueInt = int.TryParse(searchQueryValue.SearchValue, out valueAsInt);
            if (!isValueInt || valueAsInt > 0)
            {
                // this means the search value either an attribute value ID or an attribute value name
                var attributeValues = _customAttributeFacade.GetCustomAttributeValuesBySpec(new CustomAttributeValueSpec { AttributeId = entityId, BaseLocale = locale });
                if (attributeValues != null && attributeValues.ToList().Count > 0)
                {
                    var attributeValue = valueAsInt > 0
                        ? attributeValues.ToList().FirstOrDefault(v => v.ValueId == valueAsInt)
                        : attributeValues.ToList().FirstOrDefault(v => v.ValueName == searchQueryValue.SearchValue);
                    if (attributeValue != null)
                        newSelection.CreateValue(attributeValue.ValueId, GroupType.ATTRIBUTEVALUE, attributeValue.ValueName);
                }
                else
                {
                    newSelection.CreateValue(0, GroupType.ATTRIBUTEVALUE, searchQueryValue.SearchValue);
                }
            }
            else
            {
                newSelection.CreateValue(0, GroupType.ATTRIBUTEVALUE, searchQueryValue.SearchValue);
            }
            return newSelection;
        }

        private void AddDeviceSelection(SearchQuery searchQuery, ref List<Selection> selections, ref List<Display> display, ref List<string> displayNoStyle, string locale)
        {
            var device = _deviceFacade.GetDeviceBySpec(new DeviceSpec { DeviceId = searchQuery.QueryEntityID }, locale);
            if (device != null)
            {
                var condition = (int)searchQuery.Operator.GetValueOrDefault();
                var newSelection = new Selection(searchQuery.QueryEntityID.GetValueOrDefault(),
                    CustomAttributeDataType.String, GroupType.DEVICE, device.Name, 0, condition, device.CommonName);

                foreach (var searchQueryValue in searchQuery.SearchValueCollections.ToList())
                {
                    newSelection.CreateValue(0, GroupType.DEVICE, searchQueryValue.SearchValue, device.CommonName);
                }

                selections.Add(newSelection);
                string searchValue = searchQuery.SearchValueCollections.Select(x => x.SearchValue).Join(",");
                display.Add(new Display { DisplayText = _searchCriteriaConverter.getDeviceDisplayText(new CriteriaParam { Operator = (int)searchQuery.Operator, Value = searchValue }, device.Name, device.CommonName, true) });
                displayNoStyle.Add(_searchCriteriaConverter.getDeviceDisplayText(new CriteriaParam { Operator = (int)searchQuery.Operator, Value = searchValue }, device.Name, device.CommonName, false));

            }
        }

        public DataTable SetTargetBaseofRbt(ResultBasedTargeting rbt, int provideId)
        {
            var rbtCriteria = new ResultBasedTargetingCriteria { AlertId = rbt.AlertId, RecipientType = rbt.EntityFilterId };

            return _alertFacade.GetTargetUserBase(rbtCriteria);
        }

        #region "Group Targeting Load"
        public void PopulateGroupTargetingSelection(IList<Node> tree, IList<ISearchCriteria> tCriteria)
        {
            var selectedNodes = tCriteria != null
                ? (from tc in tCriteria
                   where tc.NodeType != SearchNodeType.Query//when populating group targeting filter out query criteria.
                   group tc by tc.SearchCriteriaID
                       into g
                       select g.FirstOrDefault()).ToDictionary(k => k.SearchCriteriaID)//remove dups just in case. every node has a unique ID
                : null;

            foreach (var n in tree)
            {
                SetNode(n, selectedNodes, n.Selected.GetValueOrDefault(), n.IsBlocked);
                SetSelected(n, selectedNodes);
            }
        }

        /// <summary>
        /// Recursively set selected property of the tree nodes
        /// </summary>
        /// <param name="node">A targeting tree node</param>
        /// <param name="sNodes">Selected nodes</param>
        private void SetSelected(Node node, Dictionary<int, ISearchCriteria> sNodes)
        {
            //since blocked state is a special case, 
            //we cannot use the checkbox state so we need to explicitly set blocked here for each child
            bool blockChild = node.IsBlocked;
            bool selectChild = node.Selected.GetValueOrDefault();
            if (node.HasChildren)
            {
                //Add a dummy node to all nodes that have at least one child.
                //Purpose is to have a UI behavoir where selecting all child will result in selecting the parent
                node.Children.Add(new Node() { Id = -1, Type = NodeType.Dummy });
                foreach (var n in node.Children)
                {
                    SetNode(n, sNodes, selectChild, blockChild);
                    SetSelected(n, sNodes);
                }
            }
        }

        private void SetNode(Node node, Dictionary<int, ISearchCriteria> sNodes, bool selectChild, bool blockChild)
        {
            if (sNodes == null)
                return;

            ISearchCriteria item = null;
            sNodes.TryGetValue(node.Id, out item);
            node.Selected = item != null || selectChild;
            node.IsBlocked = (item != null && item.IsBlocked.GetValueOrDefault()) || blockChild;
            if (node.IsBlocked)
                node.CommandText = "Unblock";
        }
        #endregion

        public PlaceholderModel ReplacePlaceholders(int providerId, int operatorId, PlaceholderModel model)
        {
            var result = new PlaceholderModel();

            //get system placeholders
            var systemPlaceholders = _placeHolderFacade.GetSystemPlaceHolders(model.systemPlaceholders, providerId, operatorId).ToList();
            //convert date time values
            SetDefaultDateTimeValues(systemPlaceholders);
            //update replacement model
            if (model.PlaceholderReplacementModels.HasValue())
            {
                result.PlaceholderReplacementModels =
                    (from mdl in model.PlaceholderReplacementModels.Where(t => t.Value != null)
                     let value = ReplacePlaceholderInText(mdl.Value, model.SelectedPlaceHolders, systemPlaceholders)
                     select new PlaceholderReplacementModel { FieldId = mdl.FieldId, Value = value, GroupId = mdl.GroupId, IsTextArea = mdl.IsTextArea, Label = mdl.Label, MinLength = mdl.MinLength, MaxLength = mdl.MaxLength }).ToList();
            }
            result.RecordingPreviewModels = model.RecordingPreviewModels;
            return result;
        }

        /// <summary>
        /// To Convert Date & Time values of placeholder
        /// </summary>
        /// <param name="phData"></param>
        private void SetDefaultDateTimeValues(IEnumerable<Business.Domain.Entities.PlaceHolder> phData)
        {
            //to convert date & time values
            foreach (var modelItem in phData.Where(x => x.IsStandard == "N" && !x.IsSystem && (x.ControlType == AtHoc.IWS.Business.Domain.Entities.PlaceHolderControlType.Date || x.ControlType == AtHoc.IWS.Business.Domain.Entities.PlaceHolderControlType.DateTime || x.ControlType == AtHoc.IWS.Business.Domain.Entities.PlaceHolderControlType.Time)))
            {
                var iValue = modelItem.DefaultValue == null ? string.Empty : modelItem.DefaultValue.ToString();
                switch (modelItem.ControlType)
                {
                    case PlaceHolderControlType.Date:
                        modelItem.DefaultValue = DateTimeHelper.ConvertFromUTCTicksToDate(iValue.ToString(CultureInfo.InvariantCulture));
                        if (modelItem.Values.HasValue() && modelItem.Values.Any())
                            modelItem.Values.ToList()[0].Value = modelItem.DefaultValue;
                        break;
                    case PlaceHolderControlType.DateTime:
                        modelItem.DefaultValue = DateTimeHelper.ConvertFromUTCTicksToDateTime(iValue.ToString(CultureInfo.InvariantCulture));
                        if (modelItem.Values.HasValue() && modelItem.Values.Any())
                            modelItem.Values.ToList()[0].Value = modelItem.DefaultValue;
                        break;
                    case PlaceHolderControlType.Time:
                        modelItem.DefaultValue = DateTimeHelper.ConvertFromUTCTicksToTime(iValue.ToString(CultureInfo.InvariantCulture));
                        if (modelItem.Values.HasValue() && modelItem.Values.Any())
                            modelItem.Values.ToList()[0].Value = modelItem.DefaultValue;
                        break;
                }
            }

        }

        private void SetPlaceholderModelFromRawDeviceOptions(List<DeviceGroupPresetOptions> optionPresets, ref PlaceholderModel pm, List<Devices.Device> providerDevices)
        {
            //in  r & p or publish scenario context, DeviceGroupOptionsRawXML array should not be empty 
            foreach (var deviceRawXML in optionPresets)
            {
                if (deviceRawXML == null)
                    continue;

                int groupId = deviceRawXML.GroupId;
                var group = providerDevices.FirstOrDefault(x => x.Group.Id == groupId);
                if (group != null)
                {
                    XElement opt = XElement.Parse(HttpUtility.HtmlDecode(HttpUtility.HtmlDecode(deviceRawXML.selection)));

                    XElement dataElem = opt.Element("data");

                    if (dataElem != null)
                    {
                        string previewStr = CustomOption.GetPreviewXML(group.Group.Extension, dataElem, RuntimeContext.Provider.BaseLocale);

                        if (!previewStr.IsNullOrEmpty())
                        {
                            XElement previewXML = XElement.Parse(previewStr);

                            fillPlaceholderReplacementModel(groupId, previewXML, ref pm);
                        }
                    }
                }
            }
        }
        public PlaceholderModel RetrieveCustomTexts(List<DeviceGroupPresetOptions> optionPresets)
        {
            //This is not related to placeholder but 
            PlaceholderModel pm = new PlaceholderModel();

            var dm = new DeviceManager(RuntimeContext.Provider.Id);
            var providerDevices = dm.GetDevices(true, false);
            SetPlaceholderModelFromRawDeviceOptions(optionPresets, ref pm, providerDevices);
            return pm;
        }

        public PlaceholderModel ConvertDeviceOptionToPlaceholderReplacementModel(PlaceholderModel model)
        {

            var dm = new DeviceManager(RuntimeContext.Provider.Id);
            var providerDevices = dm.GetDevices(true, false);

            //if coming from alert details (with device option UI loaded), DeviceGroupOption array should not be empty 
            foreach (var devicegroup in model.DeviceGroupOptions)
            {
                if (devicegroup == null)
                    continue;

                //IWS-31029: no need to replace placeholders if pre-recorded audio option is selected
                var audioOption = devicegroup.Options.FirstOrDefault(op => op.Name.Contains(".ContentSource"));
                if (audioOption != null && audioOption.Value == "Audio")
                    continue;

                int groupId = devicegroup.GroupId;
                var group = providerDevices.FirstOrDefault(x => x.Group.Id == groupId);
                if (group != null)
                {
                    string previewStr = "";

                    previewStr = CustomOption.GetPreviewXML(group.Group.Extension, devicegroup.Options.ToDictionary(g => g.Name, g => g.Value), RuntimeContext.Provider.BaseLocale);

                    if (!previewStr.IsNullOrEmpty())
                    {
                        XElement previewXML = XElement.Parse(previewStr);

                        fillPlaceholderReplacementModel(groupId, previewXML, ref model);
                    }
                }
            }
            //in  r & p or publish scenario context, DeviceGroupOptionsRawXML array should not be empty 
            SetPlaceholderModelFromRawDeviceOptions(model.DeviceGroupOptionsRawXML, ref model, providerDevices);


            return model;
        }

        private void fillPlaceholderReplacementModel(int groupId, XElement previewXML, ref PlaceholderModel model)
        {
            IEnumerable<XElement> items = previewXML.Descendants("Item");
            foreach (XElement item in items)
            {
                XAttribute itemType = item.Attribute("Type");

                //just in case Type is lower case
                if (itemType == null)
                {
                    itemType = item.Attribute("type");
                }

                if (itemType != null && itemType.Value.ToUpper() == "PREVIEW")
                {
                    var itemModel = new PlaceholderReplacementModel()
                    {
                        GroupId = groupId,
                        Label = (item.Attribute("Label") != null) ? (string)item.Attribute("Label") : "",
                        FieldId = (item.Attribute("FieldId") != null) ? (string)item.Attribute("FieldId") : "",
                        MinLength = (item.Attribute("MinLength") != null) ? (int)item.Attribute("MinLength") : 10,
                        MaxLength = (item.Attribute("MaxLength") != null) ? (int)item.Attribute("MaxLength") : 3000,
                        Value = item.Value,
                        IsTextArea = (item.Attribute("Label") == null) ? false : !((item.Attribute("Label").Value.ToUpper() == "SUBJECT"))
                    };
                    model.PlaceholderReplacementModels.Add(itemModel);
                }
                else if (itemType != null && itemType.Value.ToUpper() == "RECORDING")
                {
                    var itemModel = new RecordingPreviewModel()
                    {
                        GroupId = groupId,
                        Id = item.Element("AttachmentId").Value,
                        Name = item.Element("AttachmentName").Value,
                        Stream = item.Element("Stream").Value
                    };
                    model.RecordingPreviewModels.Add(itemModel);

                }
            }

        }

        private static string ReplacePlaceholderInText(string text, IEnumerable<Models.Publishing.PlaceHolder> selectedPlaceholder, IEnumerable<AtHoc.IWS.Business.Domain.Entities.PlaceHolder> systemPlaceHolders)
        {
            //Replace with placeholders from entity/selected
            if (text.Contains("[[") && text.Contains("]]"))
            {
                if (selectedPlaceholder != null)
                {
                    foreach (var placeholder in selectedPlaceholder)
                    {
                        var key = string.Format("[[{0}]]", placeholder.Name == null ? placeholder.CommonName : placeholder.Name);
                        if (!text.Contains(key)) continue;
                        text = text.Replace(key, placeholder.SelectedValue ?? string.Empty);

                    }
                }
            }

            //Replace with system placeholder
            if (text.Contains("[[") && text.Contains("]]"))
            {
                if (systemPlaceHolders != null)
                {
                    foreach (var placeholder in systemPlaceHolders)
                    {
                        var key = string.Format("[[{0}]]", placeholder.Name);
                        if (!text.Contains(key)) continue;
                        var defaultValue = placeholder.Values.FirstOrDefault(v => v.IsDefault);
                        text = text.Replace(key, defaultValue != null ? defaultValue.Value : string.Empty);
                    }
                }
            }

            return text;
        }

        public static List<PlaceholderReplacementModel> GetCustomContentPerDevice(AlertBase alert, DeviceManager dm, List<Devices.Device> devices)
        {
            var prmList = new List<PlaceholderReplacementModel>();

            DeliverySpecification deliverySpec = alert.AlertSpec.Delivery;

            var processedGroups = new List<AtHoc.Devices.DeviceGroup>();

            foreach (int deviceId in deliverySpec.GetTargetedDevices())
            {
                AtHoc.Devices.Device d = devices.FirstOrDefault(a => a.Id == deviceId);
                if (d == null) continue;
                AtHoc.Devices.DeviceGroup group = d.Group;

                if (processedGroups.Contains(d.Group) == false)
                {
                    if (d.Group.Extension != null)
                    {

                        if (alert.AlertSpec.Delivery.CustomOption.PreviewExtensions.ContainsKey(d.Group.Extension.ID))
                        {

                            XElement previewExt = XElement.Parse(deliverySpec.CustomOption.PreviewExtensions[d.Group.Extension.ID]);
                            IEnumerable<XElement> items = previewExt.Descendants("Item");

                            List<CustomContentPreviewModel> al = new List<CustomContentPreviewModel>();
                            //var definition = XElement.Parse(d.Group.Extension.Definition.OuterXml);

                            foreach (XElement item in items)
                            {
                                XAttribute itemType = item.Attribute("Type");
                                if (itemType != null && itemType.Value.ToUpper() == "PREVIEW")
                                {
                                    /*
                                    var itemModel = new PlaceholderReplacementModel()
                                    {
                                        Label = (item.Attribute("Label") != null) ? (string)item.Attribute("Label") : "",
                                        FieldId = (item.Attribute("FieldId") != null) ? (string)item.Attribute("FieldId") : "",
                                        MinLength = (item.Attribute("MinLength") != null) ? (int)item.Attribute("MinLength") : 10,
                                        MaxLength = (item.Attribute("MaxLength") != null) ? (int)item.Attribute("MaxLength") : 3000,
                                        Value = item.Value,
                                        IsTextArea = (item.Attribute("Label") == null) ? false : !(((string)item.Attribute("Label").Value.ToUpper() == "SUBJECT"))
                                    };
                                    if (!string.IsNullOrWhiteSpace(itemModel.FieldId))
                                        al.Add(itemModel);
                                    */
                                    var itemModel = new PlaceholderReplacementModel()
                                    {
                                        GroupId = d.Group.Id,
                                        Label = (item.Attribute("Label") != null) ? (string)item.Attribute("Label") : "",
                                        FieldId = (item.Attribute("FieldId") != null) ? (string)item.Attribute("FieldId") : "",
                                        MinLength = (item.Attribute("MinLength") != null) ? (int)item.Attribute("MinLength") : 10,
                                        MaxLength = (item.Attribute("MaxLength") != null) ? (int)item.Attribute("MaxLength") : 3000,
                                        Value = item.Value,
                                        IsTextArea = (item.Attribute("Label") == null) ? false : !(((string)item.Attribute("Label").Value.ToUpper() == "SUBJECT"))
                                    };
                                    prmList.Add(itemModel);

                                }
                            }

                        }
                    }
                }
            }

            return prmList;
        }
    }

    //TODO: This exception class should be moved to business layer and generated from there
    internal class DuplicateResponseOptionException : Exception
    {
    }

}