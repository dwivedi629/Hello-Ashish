﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using AtHoc.d911.Model.Organization;
using AtHoc.Infrastructure.Ioc;
using AtHoc.Infrastructure.Log;
using AtHoc.IWS.Business.Domain.Organization;
using AtHoc.IWS.Web.Models.Organization;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Data.SearchSpec;

namespace AtHoc.IWS.Web.Helpers
{
    
    public class SentInvitationParameters : BaseSearchSpec
    {
        public string SearchText { get; set; }
    }
    public class OrganizationHelper
    {


        public static ConnectModel GetSentInviationDataModel(SentInvitationParameters sentInvitationParameters)
        {
            try
            {
                var providerId = RuntimeContext.ProviderId;
                var orgFacade = ServiceLocator.Current.Resolve<IOrganizationFacade>();
                var status = orgFacade.GetConnectivityStatus(providerId);
                var connections = orgFacade.GetConnections(providerId,false,false,true);
                if (status != ConnectivityStatus.Connected)
                {
                    LogService.Current.Warn(() => string.Format("Organization is not connected. should not get here..."));
                    return null;
                }
                var selfOrganizationGuid = orgFacade.GetSelfOrganizationGuid(RuntimeContext.ProviderId);

                var externalInvitationById = GetFilteredExternalInvitation(selfOrganizationGuid, connections.ExternalInvitations,
                   sentInvitationParameters.SearchText);

                return new ConnectModel()
                {
                    ExternalInvitations = externalInvitationById.Values.OrderByDescending(o => o.UpdatedOn).ToList()
                };
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => string.Format("Failed to build connect model for Sent Invitations"));
                LogService.Current.Error(() => ex);        
            }
            return null;

        }

        
        public static ConnectModel GetOrganizationsDataModel(OrganizationSpec organizationSpec, bool existingConnection, bool includeNotifications, List<string> includeOrgIds = null)
        {
            try
            {
                var orgFacade = ServiceLocator.Current.Resolve<IOrganizationFacade>();
                var status = orgFacade.GetConnectivityStatus(RuntimeContext.ProviderId);
                if (status != ConnectivityStatus.Connected)
                {
                    LogService.Current.Warn(() => string.Format("Organization is not connected. should not get here..."));
                    return null;
                }

                var selfOrganizationGuid = orgFacade.GetSelfOrganizationGuid(RuntimeContext.ProviderId);
                var searchOrgById = orgFacade.GetOrganizations(RuntimeContext.ProviderId, organizationSpec);
                
                // todo: we take all organizations, knowing it is comming form the cache, optimize here.   
                var allOrgById = orgFacade.GetOrganizations(RuntimeContext.ProviderId, new OrganizationSpec());
                var connections = orgFacade.GetConnections(RuntimeContext.ProviderId);
                
                var agreementsByOrg = new Dictionary<string, AgreementModel>();
                
                var invitationsById = new Dictionary<int, InvitationModel>();
               

                var organizations = new Dictionary<string, OrganizationModel>();
                var gridOrgIds = new List<string>();
                var totalCount = 0;
                var filterPendingPresent = organizationSpec.Filter.HasValue &&
                                       organizationSpec.Filter.Value.Equals(FilterType.RequestPending);
                if (organizationSpec.Filter.HasValue)
                {
                    existingConnection = organizationSpec.Filter.Value == FilterType.Connected ;
                }
                // make sure that return orgId if it is visible
                if (includeOrgIds != null)
                {
                    includeOrgIds.ForEach(orgId =>
                    {
                        if (allOrgById.ContainsKey(orgId))
                        {
                            organizations[orgId] = new OrganizationModel(allOrgById[orgId]);
                        }
                    });
                }
                
                // all organizations (only to support grid and notifications)
                // all agreements (only to support grid and notifications)
                // all invitations (only to support grid and notifications)
                // notifications (list of agreement ids, list of invitation ids)
                // grid (list of orgIds)

                if (!existingConnection && !filterPendingPresent)
                {
                    if (searchOrgById.ContainsKey(selfOrganizationGuid))
                    {
                        searchOrgById.Remove(selfOrganizationGuid);
                    }
                    totalCount = searchOrgById.Count;
                    searchOrgById = GetPaginatedOrganization(organizationSpec, searchOrgById);
                    foreach (var orgInfo in searchOrgById.Values)
                    {
                        if (orgInfo.Guid == selfOrganizationGuid)
                        {
                            continue;
                        }
                        var orgModel = new OrganizationModel(orgInfo);
                        organizations[orgInfo.Guid] = orgModel;
                        gridOrgIds.Add(orgInfo.Guid);
                    }
               }                

                foreach (var agreement in connections.Agreements)
                {
                    if(!allOrgById.ContainsKey(agreement.OtherOrganizationGuid))                    
                    {
                        LogService.Current.Error(() => string.Format("Could not find organization id: {0}, for agreement: {1}. Skip", agreement.OtherOrganizationGuid, agreement.Id));
                        continue;
                    }
                    var orgInfo = allOrgById[agreement.OtherOrganizationGuid];

                    var orgModel = new OrganizationModel(orgInfo);
                    organizations[orgInfo.Guid] = orgModel;
                    var agreementMdel = new AgreementModel(agreement, orgInfo.Sector.Name);
                    agreementsByOrg[orgInfo.Guid] = agreementMdel;
                    if (existingConnection && !filterPendingPresent &&  searchOrgById.ContainsKey(orgInfo.Guid))
                    {     
                        // make sure this org is in.
                        gridOrgIds.Add(orgInfo.Guid); 
                    }
                }
                if (existingConnection && !filterPendingPresent)
                {
                    totalCount = gridOrgIds.Count;
                    gridOrgIds = GetPaginatedOrgIds(organizationSpec, gridOrgIds);
                    //sort the connected orgs grid
                    gridOrgIds = gridOrgIds.OrderBy(orgGuid => allOrgById[orgGuid].Name).ToList();
                }
                
                foreach (var invitation in connections.Invitations)
                {
                    var invitatioModel = new InvitationModel(selfOrganizationGuid, invitation);
                    if (!allOrgById.ContainsKey(invitatioModel.OtherOrgGuid))
                    {
                        LogService.Current.Error(() => string.Format("Could not find organization id: {0}, for invitation: {1}. Skip", invitatioModel.OtherOrgGuid, invitatioModel.Id));
                        continue;
                    }                    
                    var orgInfo = allOrgById[invitatioModel.OtherOrgGuid];
                    var orgModel = new OrganizationModel(orgInfo);
                    organizations[orgInfo.Guid] = orgModel;
                    invitationsById[invitation.Id] = invitatioModel;
                    if (filterPendingPresent && searchOrgById.ContainsKey(orgInfo.Guid) && invitatioModel.Status.Equals(OrganizationInvitationStatus.Pending))
                    {
                        gridOrgIds.Add(orgInfo.Guid);
                    }                   
                }
                if (filterPendingPresent)
                {
                    totalCount = gridOrgIds.Count;
                    gridOrgIds = GetPaginatedOrgIds(organizationSpec, gridOrgIds);
                    //sort the connected orgs grid
                    gridOrgIds = gridOrgIds.OrderBy(orgGuid => allOrgById[orgGuid].Name).ToList();
                }
               
                return new ConnectModel
                {
                    Agreements = agreementsByOrg.Values.ToList(),
                    GridOrganizationIds = gridOrgIds.ToList(),
                    GridTotalCount = totalCount,
                    Invitations = invitationsById.Values.ToList(),
                    Organizations = organizations.Values.ToList(),
                    ProviderDateFormat = RuntimeContext.Provider.GetDateFormat()
                };                                
            }
            catch (Exception ex)
            {                
                LogService.Current.Error(() => string.Format("Failed to build connect model"));
                LogService.Current.Error(() => ex);                
            }

            return null;
        }


        private static Dictionary<int, InvitationModel> GetFilteredExternalInvitation(string selfGuid,
            IEnumerable<OrganizationInvitationInfoModel> infoModelList, string searchText)
        {
            var invitations = new Dictionary<int, InvitationModel>();
            foreach (var externalInvite in infoModelList)
            {
                if (searchText != null)
                {
                    searchText = searchText.Trim();
                }
                var isFiltered = false;
                if (!string.IsNullOrEmpty(searchText))
                {
                    var email = externalInvite.InviteeEmail ?? "";
                    var orgName = externalInvite.OrganizationName ?? "";
                    if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(orgName))
                    {
                        isFiltered = true;
                    }
                    else if (!(email.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0 || orgName.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0))
                    {
                        isFiltered = true;
                    }
                }
                if (!isFiltered)
                {
                   var invitationModel = new InvitationModel(selfGuid, externalInvite);
                   invitations[externalInvite.Id] = invitationModel;
                }
            }
            return invitations;
        }


        /// <summary>
        /// Returns sorted organizations by name by default if Sort is not specified
        /// </summary>
        /// <param name="spec"></param>
        /// <param name="allOrgs"></param>
        /// <returns></returns>
        private static IDictionary<string, OrganizationInfo> GetPaginatedOrganization(OrganizationSpec spec, IDictionary<string,OrganizationInfo> allOrgs)
        {
            IDictionary<string, OrganizationInfo> result = new Dictionary<string, OrganizationInfo>();
            if (spec == null || allOrgs == null || allOrgs.Count == 0)
                return allOrgs;
            var total = allOrgs.Count;
            var skip = spec.PageSize*(spec.Page - 1);
            var canPage = skip < total;
            if (!canPage)
                return allOrgs;

            var typeforSortObject = new OrganizationInfo();
            var canSort = spec.Sort != null && spec.Sort.Count > 0 && typeforSortObject.GetType().GetProperties().Any(p => p.Name.Equals(spec.Sort[0].Field, StringComparison.InvariantCultureIgnoreCase));
            //Sort by spec.Sort if it is not null 
            //else sort Organizations by name
            var sortedOrg = canSort 
                ? allOrgs.OrderBy(dictItem => ((OrganizationInfo)dictItem.Value).GetType().GetProperty(spec.Sort[0].Field).GetValue(dictItem.Value)) 
                : allOrgs.OrderBy(dictItem => dictItem.Value.Name);
            result = sortedOrg.Skip(skip).Take(spec.PageSize).ToDictionary(x => x.Key, x => x.Value);
            return result;
        }

        private static List<string> GetPaginatedOrgIds(OrganizationSpec spec, List<string> orgIds)
        {
            if (spec == null || orgIds == null || orgIds.Count == 0)
                return orgIds;

            var total = orgIds.Count;
            var skip = spec.PageSize * (spec.Page - 1);
            var canPage = skip < total;
            if (!canPage)
                return orgIds;
            var result = orgIds.Skip(skip).Take(spec.PageSize).ToList();
            return result;
        }

        public static dynamic GetHomePageStatistcs()
        {
            dynamic response = new System.Dynamic.ExpandoObject();
            response.ExistingConnectionCount = 0;
            response.NotificationCount = 0;
        
            try
            {
                var orgFacade = ServiceLocator.Current.Resolve<IOrganizationFacade>();
                var connections = orgFacade.GetConnections(RuntimeContext.ProviderId);
                if (connections != null)
                {
                    response.ExistingConnectionCount = connections.Agreements.Count;
                    response.NotificationCount = connections.Messages.Count;
                    return response;
                }
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);   
            }
            return response;

        }              
    }
}