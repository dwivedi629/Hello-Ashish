﻿using System.IO;

using System.Web.UI;

using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Users.Impl;
using AtHoc.Global.Resources;

namespace AtHoc.IWS.Web.Helpers
{
	public static class PasswordSummaryHelper
	{
		public static string RenderSummary()
		{
			var securityPolicy = new UserFacade().GetGlobalSecurityPolicy(RuntimeContext.ProviderId);
			var stringWriter = new StringWriter();

			using (var htmlWriter = new HtmlTextWriter(stringWriter))
			{
                htmlWriter.Write(IWSResources.General_Password);

				if (securityPolicy.PasswordMinLength.HasValue)
                    htmlWriter.Write(IWSResources.General_Password_Characters.FormatWith(securityPolicy.PasswordMinLength.Value));

				if (AnyCharTypePolicyExists(securityPolicy))
				{
                    htmlWriter.Write(' ' + IWSResources.General_Password_Contains);
					htmlWriter.WriteBreak();
				}

				if (CharPolicyExists(securityPolicy.PasswordMinUCaseChars))

                    AppendCharPolicyLine(htmlWriter, (securityPolicy.PasswordMinUCaseChars == 1 || securityPolicy.PasswordMinUCaseChars == 0) ? IWSResources.OperatorPermissions_Uppercase_Character_Singular : IWSResources.OperatorPermissions_Uppercase_Character_Plural, securityPolicy.PasswordMinUCaseChars);

				if (CharPolicyExists(securityPolicy.PasswordMinLCaseChars))
                    AppendCharPolicyLine(htmlWriter, (securityPolicy.PasswordMinLCaseChars == 1 || securityPolicy.PasswordMinLCaseChars == 0) ? IWSResources.OperatorPermissions_Lowercase_Character_Singular : IWSResources.OperatorPermissions_Lowercase_Character_Plural, securityPolicy.PasswordMinLCaseChars);

				if (CharPolicyExists(securityPolicy.PasswordMinNumericChars))
                    AppendCharPolicyLine(htmlWriter, (securityPolicy.PasswordMinNumericChars == 1 || securityPolicy.PasswordMinNumericChars == 0) ? IWSResources.OperatorPermissions_Numeric_Character_Singular : IWSResources.OperatorPermissions_Numeric_Character_Plural, securityPolicy.PasswordMinNumericChars);

				if (CharPolicyExists(securityPolicy.PasswordMinSpecialChars))

                    AppendCharPolicyLine(htmlWriter, (securityPolicy.PasswordMinSpecialChars == 1 || securityPolicy.PasswordMinSpecialChars == 0) ? IWSResources.OperatorPermissions_Special_Character_Singular : IWSResources.OperatorPermissions_Special_Character_Plural, securityPolicy.PasswordMinSpecialChars);
			}

			return stringWriter.ToString();
		}

		private static void AppendCharPolicyLine(HtmlTextWriter htmlWriter, string message, int? parameter)
		{
			htmlWriter.Write(message.FormatWith(parameter, parameter.Value > 0 ? "s" : null));
			htmlWriter.WriteBreak();
		}

		private static bool AnyCharTypePolicyExists(GlobalSecurityPolicy securityPolicy)
		{
			return CharPolicyExists(securityPolicy.PasswordMinUCaseChars) || CharPolicyExists(securityPolicy.PasswordMinLCaseChars) ||
					CharPolicyExists(securityPolicy.PasswordMinNumericChars) || CharPolicyExists(securityPolicy.PasswordMinSpecialChars);
		}

		private static bool CharPolicyExists(int? parameter)
		{
			return parameter.HasValue && parameter.Value > 0;
		}
	}
}