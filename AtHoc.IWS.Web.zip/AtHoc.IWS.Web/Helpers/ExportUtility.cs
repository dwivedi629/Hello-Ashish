﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using AtHoc.Global.Resources;
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Web.Configurations;
using AtHoc.IWS.Web.Configurations.Constants;
using AtHoc.IWS.Web.Models.Export;
using AtHoc.IWS.Web.Models.Shared;
using AtHoc.Utilities;
using StringExtensions = AtHoc.Infrastructure.StringExtensions;

namespace AtHoc.IWS.Web.Helpers
{
    /// <summary>
    /// Export Utility class.
    /// </summary>
    public static class ExportUtility
    {
        /// <summary>
        /// TO set Pdf html data to be rendered.
        /// </summary>
        /// <returns>Pdf Html Data Model.</returns>
        private static string _rowString;
        private static string _columnString;
        private static string _headerString;
        private static Dictionary<string, object> _gridRow;
        private static ExportGridColumnConfig _gridHeader;
        private static bool _isCsv;
        private static bool _isFormatHeaderName;
        private static string _headerLocalizationKey;
        private static string _customColumnString;
        private static string _hrefString;

        public static PdfHtmlDataModel SetPdf(ExportModel exportModel,int gridColumnWidth = PdfConfig.GridColumnWidth,bool isSetPdfWrapper=true)
        {
            _rowString = "<div class=\"pdf-grid-row\">value</div>";
            _columnString = "<div class=\"pdf-grid-col\">value</div>";
            _customColumnString = "<div class=\"pdf-grid-col {0}\">value</div>";
            _headerString = "<div class=\"pdf-grid-header\">value</div>";
            _hrefString = "<a href = {0}>value</a>";
            _headerLocalizationKey = exportModel.GridHeaderLocalizationKey;
            _isCsv = false;
            if (gridColumnWidth != PdfConfig.GridColumnWidth)
            {
                _columnString = "<div style =\"width:" + gridColumnWidth + "px !important\" class=\"pdf-grid-col\">value</div>";
                _customColumnString = "<div style =\"width:" + gridColumnWidth + "px !important\" class=\"pdf-grid-col {0}\">value</div>";
            }
            var pdfHtmlDataModel = new PdfHtmlDataModel
           {
               Header = GetGridHeader(exportModel.GridHeaders),
               Rows = GetGridRows(exportModel.GridRows, exportModel.GridHeaders),
               PdfSpeConfiguration =
                   new PdfGridConfiguration(exportModel.GridHeaders.Count, isSetPdfWrapper) { PageTitle = exportModel.Title, SubHeadline = exportModel.SubHeadline },
               FileName = FileNameFormats.GetFormattedFileName(IWSResources.Alert_PDFExport, "pdf")
           };
            return pdfHtmlDataModel;
        }

        /// <summary>
        /// To set CSV data.
        /// </summary>
        /// <param name="exportModel">export model.</param>
        /// <param name="specialHeaderNote"></param>
        /// <param name="includeTableTitle">includeTableTitle</param>
        /// <param name="processWithDataTable">Conversion to CSV string will done using export model GridDataTable property which is a datatable</param>
        /// <returns>Csv data model.</returns>
        public static CsvDataModel SetCsv(ExportModel exportModel,string specialHeaderNote = null,bool includeTableTitle = false, bool processWithDataTable = false)
        {
            _rowString = "value";
            _columnString = "value,";
            _headerString = "value\r\n";
            _isCsv = true;
            _headerLocalizationKey = exportModel.GridHeaderLocalizationKey;


            var headerNote = new StringBuilder();
            if (!string.IsNullOrEmpty(specialHeaderNote))
            {
                var splHeader = _headerString.Replace("value", specialHeaderNote);
                headerNote.Append(splHeader);
            }
            if (includeTableTitle)
            {
                var secHeader = _headerString.Replace("value", exportModel.Title);
                headerNote.Append(secHeader);
            }

            var localizationRequired = exportModel.GridHeaders.Any(h => h.IsLocalizationRequired == true);
            var headerStyleRequired = exportModel.GridHeaders.Any(h => h.HeaderStyle.IsNotNullOrEmpty());
            var valueStyleRequired = exportModel.GridHeaders.Any(h => h.ValueStyle.IsNotNullOrEmpty());
            var formatvalueStyleRequired = exportModel.GridHeaders.Any(h => h.FormatValue.IsNotNullOrEmpty());

            string gridString;

            if (processWithDataTable && exportModel.GridDataTable != null && !localizationRequired && !headerStyleRequired && !valueStyleRequired && !formatvalueStyleRequired)
                gridString = GetGridString(exportModel.GridDataTable);
            else
            {
                string headerStr = GetGridHeader(exportModel.GridHeaders);
                gridString = headerNote +headerStr+ GetGridRows(exportModel.GridRows, exportModel.GridHeaders);
            }


            var csvDataModel = new CsvDataModel()
            {
                GridData = AtHocConfigService.Current.Windows1252Encoding.GetBytes(gridString),
                FileName = FileNameFormats.GetFormattedFileName(IWSResources.User_CSVExport, "csv")
            };
            return csvDataModel;
        }

        /// <summary>
        /// To get Pdf grid header Html.
        /// </summary>
        /// <param name="gridHeader">Grid header to be exported.</param>
        /// <returns>Pdf grid header html string.</returns>
        private static string GetGridHeader(List<ExportGridColumnConfig> gridHeader)
        {
            var stringBuilder = new StringBuilder();
            var columnBuilder = new StringBuilder();
            var columnString = _columnString;
            _isFormatHeaderName = true;
            foreach (var header in gridHeader)
            {
                _isFormatHeaderName = true;
                if (header.HeaderStyle != null)
                {
                    columnString = StringExtensions.FormatWith(_customColumnString, header.HeaderStyle);
                }
                if (header.FormatValue != null)
                {
                    columnBuilder = columnBuilder.Append(columnString.Replace("value", Regex.Replace(header.FormatValue, "\\{[^\\}]+\\}", ReplaceWithValue)));
                }
                else
                {
                    try
                    {
                        columnBuilder = columnBuilder.Append(columnString.Replace("value", GetFormattedValue(header.ColumnName)));
                    }
                    catch (Exception ex)
                    {
                        columnBuilder.Append(columnString.Replace("value", header.ColumnName));
                    }
                }

            }
            if (_isCsv)
                columnBuilder.Length -= 1;
            var headerString = _headerString.Replace("value", columnBuilder.ToString());
            stringBuilder.Append(headerString);
            return stringBuilder.ToString();

        }

        private static string GetGridString(DataTable tableToExport, bool includeGridHeader = true)
        {
            var sb = new StringBuilder();

            if (includeGridHeader)
            {
                var columnNames = tableToExport.Columns.Cast<DataColumn>().Select(column => column.ColumnName);
                sb.AppendLine(string.Join(",", columnNames));
            }

            foreach (DataRow row in tableToExport.Rows)
            {
                var fields = row.ItemArray.Select(field =>
                  string.Concat("\"", field.ToString().Replace("\"", "\"\""), "\""));
                sb.AppendLine(string.Join(",", fields));
            }
            return sb.ToString();
        }

        /// <summary>
        /// To get Pdf grid row html.
        /// </summary>
        /// <param name="gridRows">Grid rows to be exported.</param>
        /// <param name="gridHeader">Grid Header.</param>
        /// <returns>Pdf grid row html string.</returns>
        private static string GetGridRows(List<Dictionary<string, object>> gridRows, List<ExportGridColumnConfig> gridHeader)
        {
            _isFormatHeaderName = false;
            var stringBuilder = new StringBuilder();
            foreach (var row in gridRows)
            {
                var columnBuilder = new StringBuilder();

                foreach (var header in gridHeader)
                {
                    var columnString = _columnString;
                    _gridHeader = header;
                    if (header.ValueStyle != null)
                    {
                        columnString = StringExtensions.FormatWith(_customColumnString, header.ValueStyle);
                    }
                    if (header.FormatValue != null)
                    {
                        _gridRow = row;
                        columnBuilder = columnBuilder.Append(columnString.Replace("value", Regex.Replace(header.FormatValue, "\\{[^\\}]+\\}", ReplaceWithValue)));
                    }
                    else
                    {
                        var columnValue = row.ContainsKey(header.ColumnName)
                            ? GetFormattedValue(row[header.ColumnName])
                            : string.Empty;
                        columnBuilder = columnBuilder.Append(columnString.Replace("value", columnValue));
                    }

                }
                if (_isCsv)
                    columnBuilder.Length -= 1;
                stringBuilder.AppendLine(_rowString.Replace("value", columnBuilder.ToString()));

            }


            return stringBuilder.ToString();

        }

        /// <summary>
        /// To replace CsvEscape characters.
        /// </summary>
        /// <param name="value">column value.</param>
        /// <returns>value without  escape character.</returns>
        internal static string CsvEscape(string value)
        {
            bool hasQuotes = false;
            if (value.Contains("\""))
            {
                hasQuotes = true;
                value = value.Replace("\"", "\"\"");
            }
            if (value.Contains(",") || value.Contains("\n") || hasQuotes)
            {
                return string.Concat("\"", value, "\"");
            }
            return value;
        }

        /// <summary>
        /// To get the placeholder value.
        /// </summary>
        /// <param name="match">placeholder value to be matched.</param>
        /// <returns></returns>
        private static string ReplaceWithValue(Match match)
        {
            return GetFormattedValue(_isFormatHeaderName ? match.Value.Trim('{', '}') : _gridRow[match.Value.Trim('{', '}')]);
        }

        /// <summary>
        /// To format the column value.
        /// </summary>
        /// <param name="value">Column value to be formatted.</param>
        /// <returns></returns>
        private static string GetFormattedValue(object value)
        {
            if (value == null)
            {
                return "";
            }

            if (_isFormatHeaderName)//if value to be formatted is a header name
            {
                if (_headerLocalizationKey == null)
                {
                    return value.ToString();
                }
                try
                {
                    return IWSResources.ResourceManager.GetString(_headerLocalizationKey + value,
                              System.Threading.Thread.CurrentThread.CurrentUICulture);
                }
                catch (Exception e)
                {
                    return value.ToString();
                }
            }

            DateTime time;
            if (DateTime.TryParseExact(value.ToString(), RuntimeContext.Provider.GetDateTimeFormat(),
                  CultureInfo.InvariantCulture, DateTimeStyles.None, out time))
            {
                return value.ToString();
               // return value.ToString().Contains(" ") ? RuntimeContext.Provider.SystemToVpsDateTimeFormated(time) : RuntimeContext.Provider.SystemToVpsDateFormated(time);
            }


            if (!_gridHeader.IsLocalizationRequired)
            {
                if (_isCsv)
                    return CsvEscape(value.ToString());

                var urlTextIndex = value.ToString().IndexOf("#UrlText#", StringComparison.Ordinal);
                if (urlTextIndex <= 0)
                    return urlTextIndex == 0 ? string.Empty : WebUtility.HtmlEncode(value.ToString());
                var url = value.ToString().Substring(0, urlTextIndex);
                var urlText = value.ToString()
                    .Substring(urlTextIndex + "#UrlText#".Length,
                        value.ToString().Length - (urlTextIndex + "#UrlText#".Length));
                var hrefString = _hrefString.Replace("value", urlTextIndex == -1 ? url : urlText);
                return StringExtensions.FormatWith(hrefString, url);
            }
            {
                value = value.ToString().Replace(" ", "_");
                try
                {
                    return IWSResources.ResourceManager.GetString(_gridHeader.ValueLocalizationKey + value,
                        System.Threading.Thread.CurrentThread.CurrentUICulture);
                }
                catch (Exception e)
                {
                    return value.ToString();
                }
            }
        }
    }
}