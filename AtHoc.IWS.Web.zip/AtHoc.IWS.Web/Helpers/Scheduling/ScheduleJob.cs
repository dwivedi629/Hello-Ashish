﻿using System;
using System.Data;
using System.Data.SqlClient;
using AtHoc.IWS.Business.Context;
using AtHoc.Publishing;
using AtHoc.Systems;
using AtHoc.Data;
using AtHoc.Utilities;

namespace AtHoc.IWS.Web.Helpers.Scheduling
{
    public class ScheduleJob
    {

        #region Members
        private int _scheduleJobId = -1;
        private int _scheduleId;
        private int _referenceId;
        private string _referenceType = string.Empty;
        private string _actionItem = string.Empty;
        private string _payload = string.Empty;
        private ScheduleJobStatus _status;
        private int _pickupTime;
        private int _retryCount;
        private DateTime? _nextRunDate = null;
        private int _priority;
        private int? _currentRecurrenceCount;
        private ReferenceEntityStatus _referenceEntityStatus;
        private const string New = "NEW";
        private const string Active = "ACT";
        private const string Disabled = "DSB";
        private const string Expired = "EXP";
        #endregion

        #region Constrctor
        internal ScheduleJob()
        {
            _currentRecurrenceCount = 0;
            _actionItem = "PUBLISH";
            _status = ScheduleJobStatus.New;
            _priority = 6;
            _referenceEntityStatus = ReferenceEntityStatus.ACTIVE;

        }
        #endregion

        #region Properties
        internal int ScheduleJobId
        {
            get { return _scheduleJobId; }
            set { _scheduleJobId = value; }
        }
        internal int ScheduleId
        {
            get { return _scheduleId; }
            set { _scheduleId = value; }
        }
        public int ReferenceId
        {
            get { return _referenceId; }
            set { _referenceId = value; }
        }
        public string ReferenceType
        {
            get { return _referenceType; }
            set { _referenceType = value; }
        }
        internal string ActionItem
        {
            get { return _actionItem; }
            set { _actionItem = value; }
        }
        internal string Payload
        {
            get { return _payload; }
            set { _payload = value; }
        }
        internal ScheduleJobStatus Status
        {
            get { return _status; }
            set { _status = value; }
        }
        internal int PickupTime
        {
            get { return _pickupTime; }
            set { _pickupTime = value; }
        }
        internal int RetryCount
        {
            get { return _retryCount; }
            set { _retryCount = value; }
        }
        internal DateTime? NextRunDate
        {
            get { return _nextRunDate; }
            set { _nextRunDate = value; }
        }
        internal int Priority
        {
            get { return _priority; }
            set { _priority = value; }
        }

        internal ReferenceEntityStatus ReferenceEntityStatus
        {
            get { return _referenceEntityStatus; }
            set { _referenceEntityStatus = value; }
        }

        internal int? CurrentRecurrenceCount
        {
            get { return _currentRecurrenceCount; }
            set { _currentRecurrenceCount = value; }
        }

        #endregion

        #region Methods

        public void ResetRunInstanceCount()
        {//This method is called by UI to reset the Current Recurrence Count. 
            _currentRecurrenceCount = 0;
        }
        internal void Save()
        {
            int scheduleJobId;
            string sqlInsertScheduleJob;
            string sqlUpdate;
            string strScheduleJobSeq;
            int? inNextRunDate = null;
            DateTime? dNextRunDate;
            DateTime nextRunDate;
            //if new Schedule Job id will be -1

            if (ScheduleJobId == -1)
            {
                using (NgadDatabase ngad = new NgadDatabase())
                {
                    try
                    {
                        if (NextRunDate != null)
                        {
                            dNextRunDate = _nextRunDate;
                            nextRunDate = (DateTime)Convert.ChangeType(dNextRunDate, typeof(DateTime));
                            inNextRunDate = DateTimeExtensions.ToSeconds(nextRunDate);
                        }
                        else
                        {
                            inNextRunDate = null;
                        }
                        strScheduleJobSeq = "SCD_SCHEDULED_JOB";
                        scheduleJobId = AtHocSystem.Local.GetSequence(strScheduleJobSeq);
                        if (scheduleJobId == -1)
                        {
                            throw new Exception("Error in Schedule Job Get Sequence.");
                        }
                        Payload = CreatePayLoad(_referenceId);
                        sqlInsertScheduleJob = SqlInsertScheduleJob();
                        ngad.AddParameter("SCHEDULEJOB_ID", SqlDbType.Int, scheduleJobId);
                        ngad.AddParameter("SCHEDULE_ID", SqlDbType.Int, _scheduleId);
                        ngad.AddParameter("REFERENCE_TYPE", SqlDbType.NVarChar, _referenceType);
                        ngad.AddParameter("REFERENCE_ID", SqlDbType.Int, _referenceId);
                        ngad.AddParameter("REFERENCE_ENTITY_STATUS", SqlDbType.VarChar, GetEntityStatus(_referenceEntityStatus));

                        ngad.AddParameter("ACTION_ITEM", SqlDbType.VarChar, _actionItem);
                        ngad.AddParameter("PAYLOAD", SqlDbType.VarChar, _payload);
                        if (NextRunDate == null)
                        {
                            ngad.AddParameter("NEXT_RUN_DATE", SqlDbType.Int, DBNull.Value);
                        }
                        else
                        {
                            ngad.AddParameter("NEXT_RUN_DATE", SqlDbType.Int, inNextRunDate);
                        }
                        ngad.AddParameter("PRIORITY", SqlDbType.Int, _priority);
                        ngad.AddParameter("STATUS", SqlDbType.VarChar, GetJobStatus(_status));

                        if (CurrentRecurrenceCount == null)
                        {
                            ngad.AddParameter("CURRENT_RECURRENCE_COUNT", SqlDbType.Int, DBNull.Value);
                        }
                        else
                        {
                            ngad.AddParameter("CURRENT_RECURRENCE_COUNT", SqlDbType.Int, _currentRecurrenceCount);
                        }
                        ngad.ExecuteNonQuery(sqlInsertScheduleJob);

                    }
                    catch (Exception ex)
                    {
                    }
                }
            }
            else
            {
                using (NgadDatabase ngad = new NgadDatabase())
                {
                    try
                    {
                        if (NextRunDate != null)
                        {
                            dNextRunDate = NextRunDate;
                            nextRunDate = (DateTime)Convert.ChangeType(dNextRunDate, typeof(DateTime));
                            inNextRunDate = DateTimeExtensions.ToSeconds(nextRunDate);  //DateTimeConverter.DateTimeToSeconds(nextRunDate);
                        }
                        else
                        {
                            inNextRunDate = null;
                        }
                        Payload = CreatePayLoad(ReferenceId);
                        sqlUpdate = SqlUpdateScheduleJob();
                        ngad.AddParameter("SCHEDULEJOB_ID", SqlDbType.Int, _scheduleJobId);
                        ngad.AddParameter("SCHEDULE_ID", SqlDbType.Int, _scheduleId);
                        ngad.AddParameter("REFERENCE_TYPE", SqlDbType.VarChar, _referenceType);
                        ngad.AddParameter("REFERENCE_ID", SqlDbType.Int, _referenceId);
                        ngad.AddParameter("REFERENCE_ENTITY_STATUS", SqlDbType.VarChar, GetEntityStatus(_referenceEntityStatus));
                        ngad.AddParameter("ACTION_ITEM", SqlDbType.VarChar, _actionItem);
                        ngad.AddParameter("PAYLOAD", SqlDbType.VarChar, _payload);
                        if (NextRunDate == null)
                        {
                            ngad.AddParameter("NEXT_RUN_DATE", SqlDbType.Int, DBNull.Value);
                        }
                        else
                        {
                            ngad.AddParameter("NEXT_RUN_DATE", SqlDbType.Int, inNextRunDate);
                        }

                        ngad.AddParameter("PRIORITY", SqlDbType.Int, _priority);
                        ngad.AddParameter("STATUS", SqlDbType.VarChar, GetJobStatus(_status));
                        if (CurrentRecurrenceCount == null)
                        {
                            ngad.AddParameter("CURRENT_RECURRENCE_COUNT", SqlDbType.Int, DBNull.Value);
                        }
                        else
                        {
                            ngad.AddParameter("CURRENT_RECURRENCE_COUNT", SqlDbType.Int, _currentRecurrenceCount);
                        }
                        ngad.ExecuteNonQuery(sqlUpdate).ToString();
                    }
                    catch (Exception ex)
                    {
                    }
                }
            }
        }
        internal ScheduleJob Get(int scheduleId)
        {
            string sql = SqlSelectScheduleJob();
            var scheduleJob = new ScheduleJob();
            using (NgadDatabase ngad = new NgadDatabase())
            {
                ngad.AddParameter("SCHEDULE_ID", SqlDbType.NVarChar, scheduleId);
                DataTable scheduleJobDt;


                try
                {
                    scheduleJobDt = ngad.ExecuteDataTable(sql);
                    foreach (DataRow dr in scheduleJobDt.Rows)
                    {
                        scheduleJob._scheduleJobId = (int)dr["SCHEDULEJOB_ID"];
                        scheduleJob._scheduleId = (int)dr["SCHEDULE_ID"];
                        scheduleJob._referenceType = (string)dr["REFERENCE_TYPE"];
                        scheduleJob._referenceId = (int)dr["REFERENCE_ID"];
                        scheduleJob._referenceEntityStatus = GetEntityStatus((string)dr["REFERENCE_ENTITY_STATUS"]);
                        scheduleJob._actionItem = (string)dr["ACTION_ITEM"];
                        scheduleJob._payload = (string)dr["PAYLOAD"];
                        scheduleJob._priority = (int)dr["PRIORITY"];
                        scheduleJob._status = GetJobStatus((string)dr["STATUS"]);
                        if (!dr["NEXT_RUN_DATE"].Equals(DBNull.Value))
                        {
                            scheduleJob._nextRunDate = AtHoc.Utilities.DateTimeExtensions.ToDateTime((int)dr["NEXT_RUN_DATE"]);
                        }
                        else
                        {
                            scheduleJob._nextRunDate = null;
                        }

                        if (!dr["CURRENT_RECURRENCE_COUNT"].Equals(DBNull.Value))
                        {
                            scheduleJob._currentRecurrenceCount = (int)dr["CURRENT_RECURRENCE_COUNT"];
                        }
                        else
                        {
                            scheduleJob._currentRecurrenceCount = null;
                        }
                    }
                    return scheduleJob;
                }
                catch (Exception ex)
                {
                }
            }
            return scheduleJob;
        }
        internal string GetJobStatus(ScheduleJobStatus scheduleJobStatus)
        {
            if (scheduleJobStatus == ScheduleJobStatus.New)
            {
                return New;
            }
            else
            {
                return Expired;
            }
        }
        internal ScheduleJobStatus GetJobStatus(string status)
        {
            if (status.Equals(New))
            {
                return ScheduleJobStatus.New;
            }
            else
            {
                return ScheduleJobStatus.Expired;
            }
        }
        internal string GetEntityStatus(ReferenceEntityStatus scheduleStatus)
        {
            if (scheduleStatus == ReferenceEntityStatus.ACTIVE)
            {
                return Active;
            }
            else
            {
                return Disabled;
            }
        }
        internal ReferenceEntityStatus GetEntityStatus(string referenceEntityStatus)
        {
            if (referenceEntityStatus.Equals(Active))
            {
                return ReferenceEntityStatus.ACTIVE;
            }

            else
            {
                return ReferenceEntityStatus.DISABLED;
            }
        }

        #endregion

        #region SQL

        internal string SqlInsertScheduleJob()
        {
            string sqlInsertScheduleJob = @"Insert into SCD_SCHEDULED_JOB_TAB
                ( SCHEDULEJOB_ID, 
                SCHEDULE_ID,
                REFERENCE_TYPE,
                REFERENCE_ID,
                ACTION_ITEM,
                PAYLOAD,
                NEXT_RUN_DATE,
                PRIORITY,
                STATUS,
                REFERENCE_ENTITY_STATUS,
                CURRENT_RECURRENCE_COUNT ) 
                values 
                ( @SCHEDULEJOB_ID, 
                @SCHEDULE_ID,
                @REFERENCE_TYPE,
                @REFERENCE_ID,
                @ACTION_ITEM,
                @PAYLOAD,
                @NEXT_RUN_DATE,
                @PRIORITY,
                @STATUS, 
                @REFERENCE_ENTITY_STATUS,
                @CURRENT_RECURRENCE_COUNT )";
            return sqlInsertScheduleJob;

        }
        internal string SqlUpdateScheduleJob()
        {
            string sqlUpdateScheduleJob = @"
                update SCD_SCHEDULED_JOB_TAB set
                    SCHEDULE_ID = @SCHEDULE_ID,
                    REFERENCE_TYPE = @REFERENCE_TYPE,
                    REFERENCE_ID = @REFERENCE_Id,
                    ACTION_ITEM = @ACTION_ITEM,
                    PAYLOAD =  @PAYLOAD,
                    NEXT_RUN_DATE = @NEXT_RUN_DATE, 
                    PRIORITY = @PRIORITY, 
                    STATUS = @STATUS,
                    REFERENCE_ENTITY_STATUS = @REFERENCE_ENTITY_STATUS,
                    CURRENT_RECURRENCE_COUNT = @CURRENT_RECURRENCE_COUNT 
                Where 
                    SCHEDULEJOB_ID = @SCHEDULEJOB_ID";

            return sqlUpdateScheduleJob;

        }
        internal string SqlSelectScheduleJob()
        {
            string sqlSelectScheduleJob = @"
                select 
                    SCHEDULEJOB_ID,
                    SCHEDULE_ID,
                    REFERENCE_ID,
                    REFERENCE_TYPE,
                    REFERENCE_ENTITY_STATUS,
                    ACTION_ITEM,
                    PAYLOAD,
                    case when NEXT_RUN_DATE = 0 then null
	                    else
		                NEXT_RUN_DATE
                    end as NEXT_RUN_DATE,
                    PRIORITY,
                    STATUS,
                    CURRENT_RECURRENCE_COUNT
                From
                    SCD_SCHEDULED_JOB_TAB 
                Where
                    SCHEDULE_ID = @SCHEDULE_ID";
            return sqlSelectScheduleJob;

        }

        #endregion

        private string CreatePayLoad(int referenceId)
        {

            var payload = new AtHoc.SystemJobs.Payload(
                                    AtHoc.SystemJobs.SourceLocation.GAC,
                                    typeof(RecurringScenario).Assembly.FullName,
                                    "AtHoc.Publishing",
                                    "RecurringScenario",
                                    "Publish",
                                    AtHoc.SystemJobs.PayloadPlatform.DOTNET
                                    );
            payload.Parameters.Add(new AtHoc.SystemJobs.Parameter(AtHoc.SystemJobs.ParameterType.Long, referenceId.ToString()));
            return payload.ToString();
        }
    }
}
