﻿using System;
using System.Globalization;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Web.Models.Publishing;

namespace AtHoc.IWS.Web.Helpers.Scheduling
{
    public enum ScheduleStatus
    {
        ACTIVE = 1,         //ACT
        DISABLED = 2,       //DSB
        EXPIRED = 3         //EXP 
    }
    public enum Weekly
    {
        Sunday = 1,
        Monday = 2,
        Tuesday = 4,
        Wednesday = 8,
        Thursday = 16,
        Friday = 32,
        Saturday = 64,
    }
    public enum MonthlyWeekDayRelative
    {
        Sunday = 1,
        Monday = 2,
        Tuesday = 3,
        Wednesday = 4,
        Thursday = 5,
        Friday = 6,
        Saturday = 7,
        Day = 8,
        Weekday = 9,
        WeekendDay = 10

    }
    internal enum ScheduleJobStatus
    {
        New = 1,            //NEW
        Expired = 2         //EXP
    }
    public enum Monthly
    {
        January = 1,
        February = 2,
        March = 3,
        April = 4,
        May = 5,
        June = 6,
        July = 7,
        August = 8,
        September = 9,
        October = 10,
        November = 11,
        December = 12
    }
    public enum ReferenceEntityStatus
    {
        ACTIVE = 1,     //ACT
        DISABLED = 2,   //DSB
    }
    public enum FrequencyTypeDaily
    {
        EveryWeekday = 0,
        Everyday = 1,
        EveryNDay = 2

    }
    public enum FrequencyType
    {
        OneTime = 1,
        Daily = 4,
        Weekly = 8,
        MonthlyAbsolute = 16,
        MonthlyRelative = 32,
        YearlyAbsolute = 64,
        YearlyRelative = 128

    }

    public enum AlertingStartTime
    {
       ASAP,
        SetTime
    }

    public class DateTimeHelperObj
    {
        private DateTime _theDateTime;
        public DateTime TheDateTime
        {
            get
            {
                return _theDateTime;
            }
            set
            {
                _theDateTime = value;
                TheDate = value.Date;
                TheHour = value.Hour;
                TheMinute = value.Minute;

                if (TheHour == 0)
                {
                    TheHour = 12;
                    TheAmpm = "AM";
                }
                else if (TheHour < 12)
                {
                    TheAmpm = "AM";
                }
                else if (TheHour >= 12)
                {
                    TheAmpm = "PM";
                    if (TheHour > 12)
                    {
                        TheHour -= 12;
                    }
                }
            }
        }

        public DateTime TheDate { get; private set; }
        public int TheHour { get; private set; }
        public int TheMinute { get; private set; }
        public string TheAmpm { get; private set; }

        public string TheDateFormatted
        {
            get
            {

                var pc = RuntimeContext.Provider;

                return string.Format("{0:" + pc.GetDateFormat() + "}", TheDate);
            }

        }

        public string TheDateTimeFormatted
        {
            get
            {
                var pc = RuntimeContext.Provider;
                return string.Format("{0:" + pc.GetDateFormat() + "}", TheDateTime);
            }
        }

        public DateTimeHelperObj()
        {
            var pc = RuntimeContext.Provider;
            TheDateTime = pc.CurrentSystemTime();
        }
        public DateTimeHelperObj(DateTime val)
        {
            TheDateTime = val;
        }
    }
    public class ScenarioScheduleObj
    {
        #region properties

        public bool ActivateRecurrence { get; set; }

        public DateTimeHelperObj RecurrenceStartDateTimeHelper { get; set; }

        public FrequencyType RecurrencePattern { get; set; }

        public FrequencyTypeDaily RecurrenceDailyMode { get; set; }
        public int RecurrenceDailyFrequency { get; set; }

        public int RecurrenceWeeklyFrequency { get; set; }
        public int RecurrenceWeeklyMask { get; set; }

        public FrequencyType RecurrenceMonthlyMode { get; set; }
        public int RecurrenceMonthlyFrequency { get; set; }
        public int RecurrenceMonthlyAbsoluteDay { get; set; }
        public int RecurrenceMonthlyRelativeWeekNum { get; set; }
        public int RecurrenceMonthlyRelativeDayofWeek { get; set; }

        public FrequencyType RecurrenceYearlyMode { get; set; }
        public int RecurrenceYearlyAbsoluteMonth { get; set; }
        public int RecurrenceYearlyAbsoluteDay { get; set; }
        public int RecurrenceYearlyRelativeWeekNum { get; set; }
        public int RecurrenceYearlyRelativeDayofWeek { get; set; }
        public int RecurrenceYearlyRelativeMonth { get; set; }

        public DateTime? RecurrenceEndDate { get; set; }

        public string RecurrenceEndDateFormatted
        {
            get
            {
                var pc = RuntimeContext.Provider;
                return (RecurrenceEndDate == null) ? "" :
                    string.Format("{0:" + pc.GetDateFormat() + "}", RecurrenceEndDate);
            }
            private set { }
        }

        public enum RecurrenceEndEnum
        {
            NoEndDate = 1,
            EndAfterSetNumber = 2,
            EndByDate = 3
        }
        public RecurrenceEndEnum RecurrenceEnd { get; set; }
        public int RecurrenceEndCount { get; set; }

        #endregion

        #region constructors

        public ScenarioScheduleObj()
        {
            ActivateRecurrence = false;

            RecurrenceStartDateTimeHelper = new DateTimeHelperObj(DateTime.Today.AddHours(8));

            RecurrencePattern = FrequencyType.Daily;

            RecurrenceDailyMode = FrequencyTypeDaily.Everyday;
            RecurrenceDailyFrequency = 1;

            RecurrenceWeeklyFrequency = 1;
            RecurrenceWeeklyMask = 1;

            RecurrenceMonthlyMode = FrequencyType.MonthlyAbsolute;
            RecurrenceMonthlyFrequency = 1;
            RecurrenceMonthlyAbsoluteDay = 1;
            RecurrenceMonthlyRelativeWeekNum = 1;
            RecurrenceMonthlyRelativeDayofWeek = 1;

            RecurrenceYearlyMode = FrequencyType.YearlyAbsolute;
            RecurrenceYearlyAbsoluteMonth = 1;
            RecurrenceYearlyAbsoluteDay = 1;
            RecurrenceYearlyRelativeWeekNum = 1;
            RecurrenceYearlyRelativeDayofWeek = 1;
            RecurrenceYearlyRelativeMonth = 1;

            RecurrenceEndDate = DateTime.Today.AddMonths(1);

            RecurrenceEnd = RecurrenceEndEnum.NoEndDate;
            RecurrenceEndCount = 10;
        }



        #endregion

        public Schedule SerializeToBackend(Schedule ss)
        {
            ss.Status = (this.ActivateRecurrence) ? ScheduleStatus.ACTIVE : ScheduleStatus.DISABLED;
            ss.StartDate = this.RecurrenceStartDateTimeHelper.TheDateTime;

            ss.FrequencyType = this.RecurrencePattern;
            switch (this.RecurrencePattern)
            {
                case FrequencyType.Daily:
                    switch (this.RecurrenceDailyMode)
                    {
                        case FrequencyTypeDaily.Everyday:
                        case FrequencyTypeDaily.EveryWeekday:
                            ss.FrequencyInterval = (int)this.RecurrenceDailyMode;
                            break;
                        case FrequencyTypeDaily.EveryNDay:
                            ss.FrequencyInterval = this.RecurrenceDailyFrequency;
                            break;
                    }
                    break;
                case FrequencyType.Weekly:
                    ss.FrequencyRecurrenceFactor = this.RecurrenceWeeklyFrequency;
                    ss.FrequencyInterval = this.RecurrenceWeeklyMask;
                    break;
                case FrequencyType.MonthlyAbsolute:
                    ss.FrequencyRecurrenceFactor = this.RecurrenceMonthlyFrequency;
                    ss.FrequencyInterval = this.RecurrenceMonthlyAbsoluteDay;
                    break;
                case FrequencyType.MonthlyRelative:
                    ss.FrequencyRecurrenceFactor = RecurrenceMonthlyFrequency;
                    ss.FrequencyInterval = this.RecurrenceMonthlyRelativeDayofWeek;
                    ss.FrequencyRelativeInterval = this.RecurrenceMonthlyRelativeWeekNum;
                    break;
                case FrequencyType.YearlyAbsolute:
                    ss.FrequencySubMonthType = this.RecurrenceYearlyAbsoluteMonth;
                    ss.FrequencyInterval = this.RecurrenceYearlyAbsoluteDay;
                    break;
                case FrequencyType.YearlyRelative:
                    ss.FrequencySubMonthType = this.RecurrenceYearlyRelativeMonth;
                    ss.FrequencyInterval = this.RecurrenceYearlyRelativeDayofWeek;
                    ss.FrequencyRelativeInterval = this.RecurrenceYearlyRelativeWeekNum;
                    break;
            }

            switch (this.RecurrenceEnd)
            {
                case RecurrenceEndEnum.NoEndDate:
                    ss.ScheduleNeverEnds = true;
                    break;
                case RecurrenceEndEnum.EndAfterSetNumber:
                    ss.EndRecurrenceCount = this.RecurrenceEndCount;
                    break;
                case RecurrenceEndEnum.EndByDate:
                    ss.EndDate = this.RecurrenceEndDate;
                    break;
            }

            return ss;
        }

        public ScenarioScheduleObj SyncScheduleFromRequest(ScheduleModel s)
        {
            var schedule = new ScenarioScheduleObj { ActivateRecurrence = s.ScheduleActivateRecurrenceCheck };

            if (schedule.ActivateRecurrence)
            {
                // read start date, which includes start date, hour, and minute
                DateTime? dt = GetFormattedDateTime(s.ScheduleRecurrenceStartDateInput, s.ScheduleRecurrenceStartHourSelect, s.ScheduleRecurrenceStartMinuteSelect, s.ScheduleRecurrenceStartAmpmSelect);
                if (dt != null)
                {
                    schedule.RecurrenceStartDateTimeHelper = new DateTimeHelperObj((DateTime)dt);
                }

                // read recurrence pattern section
                schedule.RecurrencePattern = (FrequencyType)Enum.Parse(typeof(FrequencyType), s.ScheduleRecurrenceRadio);
                switch (schedule.RecurrencePattern)
                {
                    case FrequencyType.Daily:
                        {
                            schedule.RecurrenceDailyMode = (FrequencyTypeDaily)Enum.Parse(typeof(FrequencyTypeDaily), s.ScheduleRecurrenceDailyRadiogroup);
                            switch (schedule.RecurrenceDailyMode)
                            {
                                case FrequencyTypeDaily.Everyday:
                                    schedule.RecurrenceDailyFrequency = 1;
                                    break;
                                case FrequencyTypeDaily.EveryWeekday:
                                    break;
                                case FrequencyTypeDaily.EveryNDay:
                                    schedule.RecurrenceDailyFrequency = s.ScheduleRecurrenceDailyFrequencyInput;
                                    break;
                            }
                            break;
                        }
                    case FrequencyType.Weekly:
                        {
                            schedule.RecurrenceWeeklyFrequency = s.ScheduleRecurrenceWeeklyFrequencyInput;
                            schedule.RecurrenceWeeklyMask = 0;

                            if (s.ScheduleRecurrenceWeekly != null)
                            {
                                foreach (var  item in s.ScheduleRecurrenceWeekly)
                                {
                                    int mask = 1;
                                    int.TryParse(item, out mask);
                                    schedule.RecurrenceWeeklyMask += mask;
                                }
                            }
                            
                            break;
                        }
                    case FrequencyType.MonthlyAbsolute:
                        // UI will combine absolute and relative, need to check schedule_recurrence_monthly_radiogroup
                        schedule.RecurrencePattern = (FrequencyType)Enum.Parse(typeof(FrequencyType), s.ScheduleRecurrenceMonthlyRadiogroup);
                        schedule.RecurrenceMonthlyFrequency = s.ScheduleRecurrenceMonthlyFrequencyInput;
                        switch (schedule.RecurrencePattern)
                        {
                            case FrequencyType.MonthlyAbsolute:
                                schedule.RecurrenceMonthlyAbsoluteDay = s.ScheduleRecurrenceMonthlyAbsoluteDaySelect;
                                break;
                            case FrequencyType.MonthlyRelative:
                                schedule.RecurrenceMonthlyRelativeDayofWeek = s.ScheduleRecurrenceMonthlyRelativeDayofweekSelect;
                                schedule.RecurrenceMonthlyRelativeWeekNum = s.ScheduleRecurrenceMonthlyRelativeWeeknumSelect;
                                break;
                        }
                        break;
                    case FrequencyType.YearlyAbsolute:
                        // UI will combine absolute and relative, need to check schedule_recurrence_yearly_mode_radiogroup
                        schedule.RecurrencePattern = (FrequencyType)Enum.Parse(typeof(FrequencyType), s.ScheduleRecurrenceYearlyModeRadiogroup);
                        schedule.RecurrenceYearlyMode = schedule.RecurrencePattern;
                        switch (schedule.RecurrencePattern)
                        {
                            case FrequencyType.YearlyAbsolute:
                                schedule.RecurrenceYearlyAbsoluteMonth = s.ScheduleRecurrenceYearlyAbsoluteMonthSelect;
                                schedule.RecurrenceYearlyAbsoluteDay = s.ScheduleRecurrenceYearlyAbsoluteDayInput;
                                break;
                            case FrequencyType.YearlyRelative:
                                schedule.RecurrenceYearlyRelativeWeekNum = s.ScheduleRecurrenceYearlyRelativeWeeknumSelect;
                                schedule.RecurrenceYearlyRelativeDayofWeek = s.ScheduleRecurrenceYearlyRelativeDayofweekSelect;
                                schedule.RecurrenceYearlyRelativeMonth = s.ScheduleRecurrenceYearlyRelativeMonthSelect;
                                break;
                        }
                        break;
                } // end - read recurrence pattern section

                // read End Date
                schedule.RecurrenceEnd = (RecurrenceEndEnum)Enum.Parse(typeof(RecurrenceEndEnum), s.ScheduleRecurrenceEndRadiogroup);
                switch (schedule.RecurrenceEnd)
                {
                    case RecurrenceEndEnum.NoEndDate:
                        break;
                    case RecurrenceEndEnum.EndAfterSetNumber:
                        schedule.RecurrenceEndCount = s.ScheduleRecurrenceEndCountInput;
                        break;
                    case RecurrenceEndEnum.EndByDate:
                        var formDate = GetForm_Date(s.ScheduleRecurrenceEnddateInput);
                        if (formDate != null)
                            schedule.RecurrenceEndDate = formDate;
                        break;
                }
            }

            return schedule;
        }

        public void SerializeFromBackend( Schedule ss)
        {
            ActivateRecurrence = (ss.Status == ScheduleStatus.DISABLED ? false : true);

            RecurrenceStartDateTimeHelper = new DateTimeHelperObj(ss.StartDate);

            RecurrencePattern = ss.FrequencyType;

            switch (RecurrencePattern)
            {
                case FrequencyType.Daily:
                    switch (ss.FrequencyInterval)
                    {
                        case 0:
                            RecurrenceDailyMode = FrequencyTypeDaily.EveryWeekday;
                            break;
                        case 1:
                            RecurrenceDailyMode = FrequencyTypeDaily.Everyday;
                            RecurrenceDailyFrequency = 1;
                            break;
                        default:
                            RecurrenceDailyMode = FrequencyTypeDaily.EveryNDay;
                            RecurrenceDailyFrequency = ss.FrequencyInterval;
                            break;
                    }
                    break;
                case FrequencyType.Weekly:
                    RecurrenceWeeklyFrequency = ss.FrequencyRecurrenceFactor;
                    RecurrenceWeeklyMask = ss.FrequencyInterval;
                    break;
                case FrequencyType.MonthlyAbsolute:
                    RecurrenceMonthlyMode = RecurrencePattern;
                    RecurrenceMonthlyFrequency = ss.FrequencyRecurrenceFactor;
                    RecurrenceMonthlyAbsoluteDay = ss.FrequencyInterval;
                    break;
                case FrequencyType.MonthlyRelative:
                    RecurrenceMonthlyMode = RecurrencePattern;
                    RecurrenceMonthlyFrequency = ss.FrequencyRecurrenceFactor;
                    RecurrenceMonthlyRelativeDayofWeek = ss.FrequencyInterval;
                    RecurrenceMonthlyRelativeWeekNum = ss.FrequencyRelativeInterval;
                    break;
                case FrequencyType.YearlyAbsolute:
                    RecurrenceYearlyMode = RecurrencePattern;
                    RecurrenceYearlyAbsoluteMonth = ss.FrequencySubMonthType;
                    RecurrenceYearlyAbsoluteDay = ss.FrequencyInterval;
                    break;
                case FrequencyType.YearlyRelative:
                    RecurrenceYearlyMode = RecurrencePattern;
                    RecurrenceYearlyRelativeWeekNum = ss.FrequencyRelativeInterval;
                    RecurrenceYearlyRelativeDayofWeek = ss.FrequencyInterval;
                    RecurrenceYearlyRelativeMonth = ss.FrequencySubMonthType;
                    break;
            }

            if (ss.EndDate != null)
            {
                RecurrenceEndDate = ss.EndDate;
                RecurrenceEnd = RecurrenceEndEnum.EndByDate;
            }
            else
            {
                if (ss.EndRecurrenceCount == null)
                {
                    RecurrenceEnd = RecurrenceEndEnum.NoEndDate;
                }
                else
                {
                    RecurrenceEnd = RecurrenceEndEnum.EndAfterSetNumber;
                    RecurrenceEndCount = (int)ss.EndRecurrenceCount;
                }

            }
        }

        public static DateTime? GetForm_Date(string value)
        {

            if (!string.IsNullOrEmpty(value))
            {
                try
                {
                    string format = RuntimeContext.Provider.GetDateFormat();
                    return DateTime.ParseExact(value, format, CultureInfo.InvariantCulture);
                }
                catch (Exception)
                { }   // no need to handle exception, return null.  TODO: nice to add a log debug
            }
            return null;
        }

        public static DateTime? GetFormattedDateTime(string value, string hourInput, string minuteInput, string ampmInput)
        {

            DateTime? retVal = GetForm_Date(value);

            if (retVal != null)
            {
                var startHour = Convert.ToInt16(hourInput);
                int startMinute = Convert.ToInt16(minuteInput);

                if ("AM".Equals(ampmInput, StringComparison.OrdinalIgnoreCase) &&
                    (startHour == 12))
                {
                    startHour = 0;
                }
                else if ("PM".Equals(ampmInput, StringComparison.OrdinalIgnoreCase) &&
                         (startHour != 12))
                {
                    startHour += 12;
                }
                return ((DateTime)retVal).AddHours(startHour).AddMinutes(startMinute);
            }
            else
            {

                return null;
            }

        }


    }



}