﻿using System;
using System.Data;
using System.Data.SqlClient;
using AtHoc.IWS.Business.Context;
using AtHoc.Systems;
using AtHoc.Data;
using AtHoc.Utilities;
namespace AtHoc.IWS.Web.Helpers.Scheduling
{
    public class Schedule
    {
        #region Members
        private int _scheduleId = -1;
        private string _scheduleName = string.Empty;
        private FrequencyType _frequencyType;
        private int _frequencyInterval;
        private int _frequencySubMonthType;
        private int _frequencySubDayType;
        private int _frequencySubDayInterval;
        private int _frequencyRelativeInterval;
        private int _frequencyRecurrenceFactor;
        private int? _endRecurrenceCount;
        internal DateTime StartDateTime;
        private int? _endTime;
        private DateTime? _endDate;
        private ScheduleStatus _status;
        private bool _scdNeverEnds;
        private DateTime _createdOn;
        private int _createdBy;
        private DateTime _updatedOn;
        private int _updatedBy;
        private const string ACTIVE = "ACT";
        private const string DISABLED = "DSB";
        private const string EXPIRED = "EXP";
        private const string YES = "Y";
        private const string NO = "N";
        private ScheduleJob _scheduleJob;
        //private Systems.DateTimeConverter _dateTimeConverter;
        //private Duration _duration;
        #endregion

        #region Constrctor
        internal Schedule()
        {
            _frequencySubDayType = 1;
            _frequencySubDayInterval = 0;
            _frequencyRelativeInterval = 0;
            _frequencyRecurrenceFactor = 0;
            _scheduleJob = new ScheduleJob();
            //_dateTimeConverter = dtc;
        }

        #endregion

        # region Property
        internal int ScheduleId
        {
            get { return _scheduleId; }
            set { _scheduleId = value; }
        }

        internal bool IsNew
        {
            get { return _scheduleId == -1; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string ScheduleName
        {
            get { return _scheduleName; }
            set { _scheduleName = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public FrequencyType FrequencyType
        {
            get { return _frequencyType; }
            set { _frequencyType = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public int FrequencyInterval
        {
            get { return _frequencyInterval; }
            set { _frequencyInterval = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public int FrequencySubMonthType
        {
            get { return _frequencySubMonthType; }
            set { _frequencySubMonthType = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public int FrequencySubDayType
        {
            get { return _frequencySubDayType; }
            set { _frequencySubDayType = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public int FrequencySubDayInterval
        {
            get { return _frequencySubDayInterval; }
            set { _frequencySubDayInterval = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public int FrequencyRelativeInterval
        {
            get { return _frequencyRelativeInterval; }
            set { _frequencyRelativeInterval = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public int FrequencyRecurrenceFactor
        {
            get { return _frequencyRecurrenceFactor; }
            set { _frequencyRecurrenceFactor = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public int? EndRecurrenceCount
        {
            get { return _endRecurrenceCount; }
            set
            {
                _endRecurrenceCount = value;
                _scdNeverEnds = false;
                _endDate = null;

                if (_endRecurrenceCount != null && _scheduleJob.CurrentRecurrenceCount == null) //4115 - if end recurrent count is valid, and existing current recurrentcount is null, reset to 0
                {
                    _scheduleJob.CurrentRecurrenceCount = 0;
                }

            }
        }

        /// <summary>
        /// 
        /// </summary>
        public DateTime StartDate
        {
            get
            {
                return RuntimeContext.Provider.SystemToVpsTime(StartDateTime);
            }
            set
            {
                StartDateTime = RuntimeContext.Provider.VpsToSystemTime(value);
                StartDateTime = new DateTime(StartDateTime.Year, StartDateTime.Month, StartDateTime.Day, StartDateTime.Hour, StartDateTime.Minute, 0);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public int? EndTime
        {
            get { return _endTime; }
            set { _endTime = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public DateTime? EndDate
        {
            get
            {
                if (_endDate != null)
                {
                    return _endDate;
                }
                return null;
            }
            set
            {
                _endDate = value;
                _endRecurrenceCount = null;
                _scheduleJob.CurrentRecurrenceCount = null;
                _scdNeverEnds = false;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public bool ScheduleNeverEnds
        {
            get { return _scdNeverEnds; }
            set
            {
                _scdNeverEnds = value;
                _endDate = null;
                _endRecurrenceCount = null;
                _scheduleJob.CurrentRecurrenceCount = null;

            }
        }

        /// <summary>
        /// 
        /// </summary>
        public ScheduleStatus Status
        {
            get { return _status; }
            set { _status = value; }
        }

        private int _providerId;
        /// <summary>
        /// 
        /// </summary>
        public int ProviderId
        {
            get { return _providerId; }
            internal set { _providerId = value; }
        }


        /// <summary>
        /// 
        /// </summary>
        public DateTime CreatedOn
        {
            get { return _createdOn; }
            internal set { _createdOn = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public int CreatedBy
        {
            get { return _createdBy; }
            internal set { _createdBy = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public DateTime UpdatedOn
        {
            get { return _updatedOn; }
            internal set { _updatedOn = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public int UpdatedBy
        {
            get { return _updatedBy; }
            internal set { _updatedBy = value; }
        }


        #endregion

        #region Schedule Job section
        /// <summary>
        /// 
        /// </summary>
        public ScheduleJob ScheduleJob
        {
            get { return _scheduleJob; }
            set { _scheduleJob = value; }
        }
        #endregion

        #region methods
        internal void Save()
        {
            DateTime startDateTime;
            DateTime endDate;
            int? inEndDate;
            DateTime? dnEndDate;

            //if new Schedule id will be -1
            if (ScheduleId == -1)
            {
                using (var ngad = new NgadDatabase())
                {
                    try
                    {
                        if (IsScheduleExist(_scheduleJob.ReferenceId, _scheduleJob.ReferenceType))
                        {
                            throw new Exception("Scenario has already recurring schedule, please modify the existing recurring schedule." + _scheduleJob.ReferenceId + "::" + _scheduleJob.ReferenceType);
                        }
                        const string strScheduleSeq = "SCD_SCHEDULED";
                        var scheduleId = AtHocSystem.Local.GetSequence(strScheduleSeq);
                        ScheduleJob.ScheduleId = scheduleId;
                        if (scheduleId == -1)
                        {
                            throw new Exception("Error in Schedule Get Sequence.");
                        }
                        //startDateTime = new DateTime(StartDate.Year, StartDate.Month, StartDate.Day, StartTime.Hour, StartTime.Minute, 00);
                        startDateTime = StartDateTime;

                        if (EndDate != null)
                        {
                            dnEndDate = _endDate;
                            endDate = (DateTime)Convert.ChangeType(dnEndDate, typeof(DateTime));
                            inEndDate = DateTimeConverter.DateTimeToSeconds(endDate); // DateTimeConverter.DateTimeToSeconds(endDate);

                        }
                        else
                        {
                            inEndDate = null;
                        }
                        string sqlInsertSchedule = SqlInsertSchedule();
                        ngad.AddParameter("SCHEDULE_ID", SqlDbType.Int, scheduleId);
                        if (ScheduleName == null)
                        {
                            ngad.AddParameter("NAME", SqlDbType.VarChar, String.Empty);

                        }
                        else
                        {
                            ngad.AddParameter("NAME", SqlDbType.VarChar, _scheduleName);
                        }
                        ngad.AddParameter("FREQUENCY_TYPE", SqlDbType.Int, Convert.ToInt32(_frequencyType));
                        ngad.AddParameter("FREQUENCY_INTERVAL", SqlDbType.Int, _frequencyInterval);
                        ngad.AddParameter("FREQUENCY_SUBMONTH_TYPE", SqlDbType.Int, _frequencySubMonthType);
                        ngad.AddParameter("FREQUENCY_SUBDAY_TYPE", SqlDbType.Int, _frequencySubDayType);
                        ngad.AddParameter("FREQUENCY_SUBDAY_INTERVAL", SqlDbType.Int, _frequencySubDayInterval);
                        ngad.AddParameter("FREQUENCY_RELATIVE_INTERVAL", SqlDbType.Int, _frequencyRelativeInterval);
                        ngad.AddParameter("FREQUENCY_RECURRENCE_FACTOR", SqlDbType.Int, _frequencyRecurrenceFactor);
                        if (EndRecurrenceCount == null)
                        {
                            ngad.AddParameter("END_RECURRENCE_COUNT", SqlDbType.Int, DBNull.Value);
                        }
                        else
                        {
                            ngad.AddParameter("END_RECURRENCE_COUNT", SqlDbType.Int, _endRecurrenceCount);
                        }
                        ngad.AddParameter("SCD_NEVER_ENDS", SqlDbType.VarChar, _scdNeverEnds == false ? NO : YES);
                        ngad.AddParameter("STATUS", SqlDbType.VarChar, GetStatus(_status));
                        ngad.AddParameter("START_DATE", SqlDbType.Int, DateTimeExtensions.ToSeconds(startDateTime));
                        if (inEndDate == null)
                        {
                            ngad.AddParameter("END_DATE", SqlDbType.Int, DBNull.Value);
                        }
                        else
                        {
                            ngad.AddParameter("END_DATE", SqlDbType.Int, inEndDate);
                        }
                        if (EndTime == null)
                        {
                            ngad.AddParameter("END_TIME", SqlDbType.Int, DBNull.Value);
                        }
                        else
                        {
                            ngad.AddParameter("END_TIME", SqlDbType.Int, _endTime);
                        }
                        ngad.AddParameter("CREATED_ON", SqlDbType.Int, DateTimeExtensions.ToSeconds(_createdOn));

                        ngad.AddParameter("CREATED_BY", SqlDbType.Int, _createdBy);
                        ngad.AddParameter("UPDATED_ON", SqlDbType.Int, DateTimeExtensions.ToSeconds(_updatedOn));
                        ngad.AddParameter("UPDATED_BY", SqlDbType.Int, _updatedBy);
                        ngad.ExecuteNonQuery(sqlInsertSchedule);
                        _scheduleJob.Save();
                    }
                    catch (Exception ex)
                    {

                    }
                }
            }
            else
            {
                using (NgadDatabase ngad = new NgadDatabase())
                {
                    try
                    {
                        startDateTime = StartDateTime;
                        //startDateTime = new DateTime(_startDateTime.Year, _startDateTime.Month, _startDateTime.Day, _startDateTime.Hour, _startDateTime.Minute, 00);

                        if (EndDate != null)
                        {
                            dnEndDate = _endDate;
                            endDate = (DateTime)Convert.ChangeType(dnEndDate, typeof(DateTime));
                            inEndDate = endDate.ToSeconds();
                        }
                        else
                        {
                            inEndDate = null;
                        }

                        string sqlUpdate = SqlUpdateSchedule();
                        ngad.AddParameter("SCHEDULE_ID", SqlDbType.Int, _scheduleId);
                        if (ScheduleName == null)
                        {
                            ngad.AddParameter("NAME", SqlDbType.NVarChar, String.Empty);

                        }
                        else
                        {
                            ngad.AddParameter("NAME", SqlDbType.VarChar, _scheduleName);
                        }
                        ngad.AddParameter("FREQUENCY_TYPE", SqlDbType.Int, Convert.ToInt32(_frequencyType));
                        ngad.AddParameter("FREQUENCY_INTERVAL", SqlDbType.Int, _frequencyInterval);
                        ngad.AddParameter("FREQUENCY_SUBMONTH_TYPE", SqlDbType.Int, _frequencySubMonthType);
                        ngad.AddParameter("FREQUENCY_SUBDAY_TYPE", SqlDbType.Int, _frequencySubDayType);
                        ngad.AddParameter("FREQUENCY_SUBDAY_INTERVAL", SqlDbType.Int, _frequencySubDayInterval);
                        ngad.AddParameter("FREQUENCY_RELATIVE_INTERVAL", SqlDbType.Int, _frequencyRelativeInterval);
                        ngad.AddParameter("FREQUENCY_RECURRENCE_FACTOR", SqlDbType.Int, _frequencyRecurrenceFactor);
                        if (EndRecurrenceCount == null)
                        {
                            ngad.AddParameter("END_RECURRENCE_COUNT", SqlDbType.Int, DBNull.Value);
                        }
                        else
                        {
                            ngad.AddParameter("END_RECURRENCE_COUNT", SqlDbType.Int, _endRecurrenceCount);
                        }

                        if (_scdNeverEnds == false)
                        {
                            ngad.AddParameter("SCD_NEVER_ENDS", SqlDbType.VarChar, NO);
                        }
                        else
                        {
                            ngad.AddParameter("SCD_NEVER_ENDS", SqlDbType.VarChar, YES);
                        }
                        ngad.AddParameter("STATUS", SqlDbType.VarChar, GetStatus(_status));
                        ngad.AddParameter("START_DATE", SqlDbType.Int, DateTimeExtensions.ToSeconds(startDateTime));
                        if (EndTime == null)
                        {
                            ngad.AddParameter("END_TIME", SqlDbType.Int, DBNull.Value);
                        }
                        else
                        {
                            ngad.AddParameter("END_TIME", SqlDbType.Int, _endTime);
                        }
                        if (inEndDate == null)
                        {
                            ngad.AddParameter("END_DATE", SqlDbType.Int, DBNull.Value);
                        }
                        else
                        {
                            ngad.AddParameter("END_DATE", SqlDbType.Int, inEndDate);
                        }
                        ngad.AddParameter("UPDATED_ON", SqlDbType.Int, DateTimeExtensions.ToSeconds(_updatedOn));
                        ngad.AddParameter("UPDATED_BY", SqlDbType.Int, _updatedBy);
                        ngad.ExecuteNonQuery(sqlUpdate);
                        _scheduleJob.Save();
                    }
                    catch (Exception)
                    {

                    }
                }

            }
        }

        internal Schedule Get(int referenceId, string referenceName)
        {
            using (var ngad = new NgadDatabase())
            {
                ngad.AddParameter("REFERENCE_ID", SqlDbType.Int, referenceId);
                ngad.AddParameter("REFERENCE_NAME", SqlDbType.VarChar, referenceName);
                var schedule = new Schedule();

                try
                {

                    using (SqlDataReader reader = ngad.ExecuteReader(SqlSelectScheduleByJob))
                    {
                        if (!reader.HasRows)
                        {
                            return null;
                        }

                        while (reader.Read())
                        {
                            schedule._scheduleId = reader.GetValue<int>("SCHEDULE_ID");
                            schedule._scheduleName = reader.GetValue("Name", string.Empty);
                            schedule._providerId = reader.GetValue<int>("PROVIDER_ID");
                            schedule._frequencyType = (FrequencyType)reader.GetValue<int>("FREQUENCY_TYPE");
                            schedule._frequencyInterval = reader.GetValue<int>("FREQUENCY_INTERVAL");
                            schedule._frequencySubMonthType = reader.GetValue<int>("FREQUENCY_SUBMONTH_TYPE");
                            schedule._frequencySubDayType = reader.GetValue<int>("FREQUENCY_SUBDAY_TYPE");
                            schedule._frequencySubDayInterval = reader.GetValue<int>("FREQUENCY_SUBDAY_INTERVAL");
                            schedule._frequencyRelativeInterval = reader.GetValue<int>("FREQUENCY_RELATIVE_INTERVAL");
                            schedule._frequencyRecurrenceFactor = reader.GetValue<int>("FREQUENCY_RECURRENCE_FACTOR");
                            schedule._endRecurrenceCount = reader.GetValue<int?>("END_RECURRENCE_COUNT", null);
                            schedule.Status = GetStatus(reader.GetValue<string>("STATUS"));
                            schedule._scdNeverEnds = reader.GetValue<bool>("SCD_NEVER_ENDS");
                            schedule.StartDateTime = reader.GetValue<int>("START_DATE").ToDateTime();
                            schedule._endTime = reader.GetValue<int?>("END_TIME");
                            if (reader.GetValue<int?>("END_DATE") != null)
                                schedule._endDate = reader.GetValue<int>("END_DATE").ToDateTime();
                            else
                                schedule._endDate = null;
                            schedule._createdOn = reader.GetValue<int>("CREATED_ON").ToDateTime();
                            schedule._createdBy = reader.GetValue<int>("CREATED_BY");
                            schedule._updatedOn = reader.GetValue<int>("UPDATED_ON").ToDateTime();
                            schedule._updatedBy = reader.GetValue<int>("UPDATED_BY");
                            schedule._scheduleJob = schedule._scheduleJob.Get(schedule._scheduleId);
                        }
                    }
                    return schedule;
                }
                catch (Exception)
                {

                    return null;
                }
            }
        }

        internal void Delete(int referenceId, string referenceName)
        {
            string sql;

            using (var ngad = new NgadDatabase())
            {

                try
                {
                    sql = SqlDeleteSchedule("SelectScheduleJob");
                    ngad.AddParameter("REFERENCE_Id", SqlDbType.Int, referenceId);
                    ngad.AddParameter("REFERENCE_TYPE", SqlDbType.NVarChar, referenceName);
                    var dtDeleteSchedules = ngad.ExecuteDataTable(sql);
                    foreach (DataRow rowsp in dtDeleteSchedules.Rows)
                    {
                        int scheduleId = (int)rowsp["SCHEDULE_ID"];
                        sql = SqlDeleteSchedule("DeleteScheduleJob");
                        ngad.AddParameter("REFERENCE_Id", SqlDbType.Int, referenceId);
                        ngad.AddParameter("REFERENCE_TYPE", SqlDbType.NVarChar, referenceName);
                        ngad.ExecuteNonQuery(sql);

                        sql = SqlDeleteSchedule("DeleteSchedule");
                        ngad.AddParameter("SCHEDULE_ID", SqlDbType.Int, scheduleId);
                        ngad.ExecuteNonQuery(sql);
                    }
                }
                catch (Exception ex)
                {

                }
            }
        }
        #endregion

        #region SQL

        private string SqlInsertSchedule()
        {
            string sqlInsertSchedule = @"
                Insert into SCD_SCHEDULED_ADVANCED_TAB (
                    SCHEDULE_ID,
                    NAME,
                    FREQUENCY_TYPE,
                    FREQUENCY_INTERVAL,
                    FREQUENCY_SUBMONTH_TYPE,
                    FREQUENCY_SUBDAY_TYPE,
                    FREQUENCY_SUBDAY_INTERVAL,
                    FREQUENCY_RELATIVE_INTERVAL,
                    FREQUENCY_RECURRENCE_FACTOR, 
                    END_RECURRENCE_COUNT,
                    SCD_NEVER_ENDS, 
                    STATUS,
                    START_DATE,
                    END_TIME,
                    END_DATE,
                    CREATED_ON,
                    CREATED_BY,
                    UPDATED_ON,
                    UPDATED_BY)
                Values (
                    @SCHEDULE_ID,
                    @NAME,
                    @FREQUENCY_TYPE,
                    @FREQUENCY_INTERVAL,
                    @FREQUENCY_SUBMONTH_TYPE,
                    @FREQUENCY_SUBDAY_TYPE,
                    @FREQUENCY_SUBDAY_INTERVAL,
                    @FREQUENCY_RELATIVE_INTERVAL,
                    @FREQUENCY_RECURRENCE_FACTOR, 
                    @END_RECURRENCE_COUNT,
                    @SCD_NEVER_ENDS,
                    @STATUS,
                    @START_DATE,
                    @END_TIME,
                    @END_DATE,
                    @CREATED_ON,
                    @CREATED_BY,
                    @UPDATED_ON,
                    @UPDATED_BY)";
            return sqlInsertSchedule;
        }
        private string SqlUpdateSchedule()
        {
            const string sqlUpdateSchedule = @"
                update SCD_SCHEDULED_ADVANCED_TAB set 
                    NAME = @NAME,
                    FREQUENCY_TYPE =  @FREQUENCY_TYPE,
                    FREQUENCY_INTERVAL = @FREQUENCY_INTERVAL,
                    FREQUENCY_SUBMONTH_TYPE = @FREQUENCY_SUBMONTH_TYPE,
                    FREQUENCY_SUBDAY_TYPE = @FREQUENCY_SUBDAY_TYPE,
                    FREQUENCY_SUBDAY_INTERVAL = @FREQUENCY_SUBDAY_INTERVAL,
                    FREQUENCY_RELATIVE_INTERVAL = @FREQUENCY_RELATIVE_INTERVAL,
                    FREQUENCY_RECURRENCE_FACTOR = @FREQUENCY_RECURRENCE_FACTOR,  
                    END_RECURRENCE_COUNT = @END_RECURRENCE_COUNT,
                    SCD_NEVER_ENDS = @SCD_NEVER_ENDS,
                    STATUS = @STATUS,
                    START_DATE = @START_DATE,
                    END_TIME = @END_TIME,
                    END_DATE = @END_DATE,
                    UPDATED_ON = @UPDATED_ON,
                    UPDATED_BY = @UPDATED_BY
                where 
                    SCHEDULE_ID = @SCHEDULE_ID";
            return sqlUpdateSchedule;
        }

        private const string SqlSelectScheduleByJob = @"
            select 
                S.SCHEDULE_ID,
	            T.PROVIDER_ID,
                T.NAME,
                S.FREQUENCY_TYPE,
                S.FREQUENCY_INTERVAL,
                S.FREQUENCY_SUBMONTH_TYPE,
                S.FREQUENCY_SUBDAY_TYPE,
                S.FREQUENCY_SUBDAY_INTERVAL,
                S.FREQUENCY_RELATIVE_INTERVAL,
                S.FREQUENCY_RECURRENCE_FACTOR, 
                case When S.END_RECURRENCE_COUNT = 0 then null
                     else
                        S.END_RECURRENCE_COUNT
                end as END_RECURRENCE_COUNT,
                S.END_RECURRENCE_COUNT,
                S.SCD_NEVER_ENDS,
                S.STATUS,
                S.START_DATE,
                S.END_TIME,
                case when S.END_DATE = 0 then null
                    when S.END_DATE = 2082758400 then null
                    when S.END_DATE = 2082844800 then null
                    else
                        S.END_DATE
                end as END_DATE,
                S.CREATED_ON,
                S.CREATED_BY,
                S.UPDATED_ON,
                S.UPDATED_BY
            From
                SCD_SCHEDULED_ADVANCED_TAB S with (nolock) 
	            inner join SCD_SCHEDULED_JOB_TAB J with (nolock) 
		            on S.SCHEDULE_ID = J.SCHEDULE_ID
	            inner join ALT_SCENARIO_TAB T with (nolock)
		            on J.REFERENCE_TYPE = 'SCENARIO' and J.REFERENCE_ID = T.SCENARIO_ID
            Where 
                J.REFERENCE_ID = @REFERENCE_ID";
        /*
                        select 
                            SCHEDULE_ID,
                            NAME,
                            FREQUENCY_TYPE,
                            FREQUENCY_INTERVAL,
                            FREQUENCY_SUBMONTH_TYPE,
                            FREQUENCY_SUBDAY_TYPE,
                            FREQUENCY_SUBDAY_INTERVAL,
                            FREQUENCY_RELATIVE_INTERVAL,
                            FREQUENCY_RECURRENCE_FACTOR, 
                            case When END_RECURRENCE_COUNT = 0 then null
                                 else
                                    END_RECURRENCE_COUNT
                            end as END_RECURRENCE_COUNT,
                            END_RECURRENCE_COUNT,
                            SCD_NEVER_ENDS,
                            STATUS,
                            START_DATE,
                            END_TIME,
                            case when END_DATE = 0 then null
                                when END_DATE = 2082758400 then null
                                when END_DATE = 2082844800 then null
                                else
                                    END_DATE
                            end as END_DATE,
                            CREATED_ON,
                            CREATED_BY,
                            UPDATED_ON,
                            UPDATED_BY
                        From
                            SCD_SCHEDULED_ADVANCED_TAB
                        Where 
                            SCD_SCHEDULED_ADVANCED_TAB.SCHEDULE_ID = 
                            (SELECT 
                                SCD_SCHEDULED_JOB_TAB.SCHEDULE_ID 
                            FROM 
                                SCD_SCHEDULED_JOB_TAB
                            WHERE
                                REFERENCE_ID = @REFERENCE_ID AND
                                REFERENCE_TYPE = @REFERENCE_NAME)";
        */

        private string SqlDeleteSchedule(string queryType)
        {
            string scheduleId;
            if (queryType == "SelectScheduleJob")
            {
                scheduleId = @"
            select 
                SCHEDULE_ID 
            from 
                SCD_SCHEDULED_JOB_TAB  
            Where 
                REFERENCE_Id = @REFERENCE_Id AND 
                REFERENCE_TYPE = @REFERENCE_TYPE";
                return scheduleId;
            }
            if (queryType == "DeleteScheduleJob")
            {
                scheduleId = @"
            Delete From 
                SCD_SCHEDULED_JOB_TAB
            Where 
                REFERENCE_Id = @REFERENCE_Id AND
                REFERENCE_TYPE = @REFERENCE_TYPE";
                return scheduleId;
            }

            scheduleId = @"
            Delete From 
                SCD_SCHEDULED_ADVANCED_TAB
            Where 
                SCHEDULE_ID = @SCHEDULE_ID";
            return scheduleId;
        }
        #endregion

        #region private method
        private static bool IsScheduleExist(int referenceId, string referenceType)
        {
            const string sql = "Select COUNT(schedule_id) from SCD_SCHEDULED_JOB_TAB where REFERENCE_ID = @REFERENCE_ID AND REFERENCE_TYPE = @REFERENCE_TYPE";
            using (var ngdb = new NgadDatabase())
            {
                ngdb.AddParameter("REFERENCE_ID", SqlDbType.Int, referenceId);
                ngdb.AddParameter("REFERENCE_TYPE", SqlDbType.VarChar, referenceType);
                var recordExist = ngdb.ExecuteScalar(sql);
                return recordExist.Equals(1);
            }
        }

        private string GetStatus(ScheduleStatus scheduleStatus)
        {
            if (scheduleStatus == ScheduleStatus.ACTIVE)
            {
                return ACTIVE;
            }
            if (scheduleStatus == ScheduleStatus.DISABLED)
            {
                return DISABLED;
            }
            return EXPIRED;
        }

        private ScheduleStatus GetStatus(string status)
        {
            if (status.Equals(ACTIVE))
            {
                return ScheduleStatus.ACTIVE;
            }
            else if (status.Equals(DISABLED))
            {
                return ScheduleStatus.DISABLED;
            }
            else
            {
                return ScheduleStatus.EXPIRED;
            }
        }

        #endregion


    }
    
}
