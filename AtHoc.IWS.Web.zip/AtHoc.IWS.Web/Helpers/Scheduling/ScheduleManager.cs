﻿using System;
using System.Data;
using AtHoc.IWS.Business.Context;
using AtHoc.Publishing;
using AtHoc.Systems;
using AtHoc.Data;
using AtHoc.Utilities;
namespace AtHoc.IWS.Web.Helpers.Scheduling
{
    public class ScheduleManager
    {

        #region Member

        private DateTime _nextRunDate;
        private readonly int _providerId;
        private readonly int _operatorId;

        //private VirtualSystem vps;
        //private static Systems.DateTimeConverter _dateTimeConverter;

        #endregion

        #region Constrctor

        public ScheduleManager()
        {
            //_dateTimeConverter = new DateTimeConverter(AtHocSystem.Local.TimeZoneOffset, AtHocSystem.Local.TimeZoneOffset);
        }

        public ScheduleManager(int providerId, int operatorId)
        {
            _providerId = providerId;
            _operatorId = operatorId;
            //vps = VirtualSystemManager.GetVirtualSystem(providerId);
            //_dateTimeConverter = vps.DateTimeConverter;
        }

        #endregion

        #region Public Methods

        public Schedule CreateSchedule()
        {
            var schedule = new Schedule { ProviderId = _providerId };
            return schedule;
        }
        public  Schedule GetSchedule(int referenceId, string referenceName)
        {
            var schedule = new Schedule();
            try
            {
                schedule = schedule.Get(referenceId, referenceName);
                return schedule;
            }
            catch (Exception)
            {

                return null;
            }
        }
        public void SaveSchedule(Schedule schedule)
        {
            try
            {

                var sm = new ScenarioManager(_providerId, _operatorId);
                Scenario scenario = sm.GetScenario(schedule.ScheduleJob.ReferenceId);
                var provider = RuntimeContext.Provider;
                DateTime currentDateTime = provider.CurrentSystemTime();
                if (schedule.Status == ScheduleStatus.ACTIVE && scenario.Enabled)
                {
                    schedule.ScheduleJob.ReferenceEntityStatus = ReferenceEntityStatus.ACTIVE;
                    schedule.ScheduleJob.Status = ScheduleJobStatus.New;
                    currentDateTime = ScheduleCalculator.CreateDateTimeWithoutSeconds(currentDateTime);
                    if (schedule.FrequencyType != FrequencyType.OneTime)
                    {
                        DateTime calNextRunDate = schedule.StartDate;

                        do
                        {
                            _nextRunDate = ScheduleCalculator.NextRun(
                                calNextRunDate,
                                schedule.FrequencyType,
                                schedule.FrequencySubMonthType,
                                schedule.FrequencyInterval,
                                schedule.FrequencySubDayInterval,
                                schedule.FrequencyRelativeInterval,
                                schedule.FrequencyRecurrenceFactor,
                                schedule.StartDate,
                                provider.CurrentSystemTime());
                            calNextRunDate = _nextRunDate;
                        } while (_nextRunDate < currentDateTime);
                        schedule.ScheduleJob.NextRunDate = provider.VpsToSystemTime(_nextRunDate);

                    }
                    else
                    {
                        schedule.ScheduleJob.NextRunDate = schedule.StartDateTime;
                    }
                }
                else
                {
                    schedule.ScheduleJob.NextRunDate = null;
                    schedule.ScheduleJob.Status = ScheduleJobStatus.Expired;
                    schedule.ScheduleJob.ReferenceEntityStatus = ReferenceEntityStatus.DISABLED;
                }
                if (schedule.ScheduleJob.NextRunDate != null)
                {
                    if (schedule.EndDate != null)
                    {
                        if (ScheduleCalculator.CreateDateWithoutTime(_nextRunDate) > ScheduleCalculator.CreateDateWithoutTime((DateTime)Convert.ChangeType(schedule.EndDate, typeof(DateTime))))
                        {
                            schedule.ScheduleJob.NextRunDate = null;
                            schedule.ScheduleJob.Status = ScheduleJobStatus.Expired;
                        }
                    }
                    else if (schedule.EndRecurrenceCount != null)
                    {
                        if (schedule.ScheduleJob.CurrentRecurrenceCount + 1 > schedule.EndRecurrenceCount)
                        {
                            schedule.ScheduleJob.NextRunDate = null;
                            schedule.ScheduleJob.Status = ScheduleJobStatus.Expired;
                        }
                    }

                }


                DateTime currSysTime = AtHocSystem.Local.CurrentDateTime;
                if (schedule.IsNew)
                {
                    schedule.CreatedBy = _operatorId;
                    schedule.CreatedOn = currSysTime;
                }
                schedule.UpdatedBy = _operatorId;
                schedule.UpdatedOn = currSysTime;
                schedule.Save();
            }
            catch (Exception)
            {
            }

        }
        public void Delete(int referenceId, string referenceName)
        {
            try
            {
                var schedule = new Schedule();
                schedule.Delete(referenceId, referenceName);
            }
            catch (Exception ex)
            {
            }
        }
        public void ProcessSchedules()
        {
            //This method will check all the schedules due and insert into SCD_EVENT_TAB
            //so that AtHoc Processor can execute the jobs like : scenario or alert or report and etc.

            int runCount;
            DateTime currentDateTime;
            DateTime nextRunDate;
            DateTime calNextRunDate;
            DateTime endTime;
            string sqlScheduleProcess = "dbo.GET_SCHEDULED_JOBS_TO_PROCESS";

            using (var ngad = new NgadDatabase())
            {
                ngad.CommandType = CommandType.StoredProcedure;
                ngad.AddParameter("eventsCount", SqlDbType.Int, 5);
                ngad.AddParameter("timeOut", SqlDbType.Int, 300);

                try
                {
                    DataTable dtScheduleProcess = ngad.ExecuteDataTable(sqlScheduleProcess);
                    foreach (DataRow rowsp in dtScheduleProcess.Rows)
                    {
                        var reader = new DataRowReader(rowsp);
                        var schedule = GetSchedule((int)rowsp["REFERENCE_ID"], "SCENARIO");
                        //Schedule schedule = GetSchedule(10801, "SCENARIO");  // TMP
                        if (!schedule.Equals(null))
                        {
                            currentDateTime = RuntimeContext.Provider.CurrentSystemTime();
                            //InsertScdEventTab method will insert into SCD_EVENT_TAB reader, once SCD_EVENT_TAB has the schedule entry
                            //AtHoc Processor will execute the entity.
                            if (!schedule.EndTime.Equals(null))
                            {
                                endTime = (DateTime)Convert.ChangeType(schedule.ScheduleJob.NextRunDate, typeof(DateTime));
                                endTime = endTime.AddSeconds((double)schedule.EndTime);
                                if (currentDateTime < endTime)
                                {
                                    InsertScdEventTab(reader);
                                }
                            }
                            else
                            {
                                InsertScdEventTab(reader);
                            }
                            calNextRunDate = (DateTime)Convert.ChangeType(schedule.ScheduleJob.NextRunDate, typeof(DateTime));
                            calNextRunDate = RuntimeContext.Provider.SystemToVpsTime(calNextRunDate);
                            do
                            {
                                nextRunDate = ScheduleCalculator.NextRun(
                                    calNextRunDate,
                                    schedule.FrequencyType,
                                    schedule.FrequencySubMonthType,
                                    schedule.FrequencyInterval,
                                    schedule.FrequencySubDayInterval,
                                    schedule.FrequencyRelativeInterval,
                                    schedule.FrequencyRecurrenceFactor,
                                    schedule.StartDate,
                                    RuntimeContext.Provider.CurrentSystemTime());

                                calNextRunDate = nextRunDate;

                            } while (nextRunDate <= currentDateTime.AddMinutes(1)); //Rakesh: added one minute latency to avoid publishing of Multiple Alerts on same day.

                            nextRunDate = RuntimeContext.Provider.SystemToVpsTime(nextRunDate);

                            //if end Schedule NY = Y then schedule never expire no end date
                            if (schedule.ScheduleNeverEnds)
                            {
                                schedule.ScheduleJob.NextRunDate = nextRunDate;
                                schedule.ScheduleJob.Status = ScheduleJobStatus.New;
                                schedule.ScheduleJob.Save();
                            }
                            else
                            {
                                //Schedule end after end recurrence count reaches
                                if (schedule.EndRecurrenceCount != null)
                                {
                                    if (schedule.ScheduleJob.CurrentRecurrenceCount + 1 < schedule.EndRecurrenceCount)
                                    {
                                        runCount = 1;
                                        schedule.ScheduleJob.CurrentRecurrenceCount = schedule.ScheduleJob.CurrentRecurrenceCount + runCount;
                                        schedule.ScheduleJob.NextRunDate = nextRunDate;
                                        schedule.ScheduleJob.Status = ScheduleJobStatus.New;
                                        schedule.ScheduleJob.Save();
                                    }
                                    else
                                    {
                                        runCount = 1;
                                        schedule.ScheduleJob.CurrentRecurrenceCount = schedule.ScheduleJob.CurrentRecurrenceCount + runCount;
                                        schedule.ScheduleJob.NextRunDate = null;
                                        schedule.ScheduleJob.Status = ScheduleJobStatus.Expired;
                                    }
                                }
                                //schedule end after schedule end date.
                                else
                                {
                                    if (schedule.EndDate != null)
                                    {
                                        if (ScheduleCalculator.CreateDateWithoutTime(nextRunDate) < ScheduleCalculator.CreateDateWithoutTime((DateTime)Convert.ChangeType(schedule.EndDate, typeof(DateTime))))
                                        {
                                            schedule.ScheduleJob.NextRunDate = nextRunDate;
                                            schedule.ScheduleJob.Status = ScheduleJobStatus.New;
                                            schedule.ScheduleJob.Save();
                                        }
                                        else
                                        {
                                            schedule.ScheduleJob.NextRunDate = null;
                                            schedule.ScheduleJob.Status = ScheduleJobStatus.Expired;
                                        }
                                    }
                                }
                                //if job is expired, mark the schdule as expired
                                if (schedule.ScheduleJob.Status.Equals(ScheduleJobStatus.Expired))
                                {
                                    schedule.Status = ScheduleStatus.EXPIRED;
                                    schedule.Save();

                                }
                            }
                        }
                    }
                }
                catch (Exception)
                {
                }
            }
        }

        #endregion

        #region SCD EVENT TAB

        private static void InsertScdEventTab(IDataRecord record)
        {
            string sqlEventInsert = GetSQL();
            using (var ngadEventInsert = new NgadDatabase())
            {
                const string strJobId = "SCD_JOB";
                ngadEventInsert.AddParameter("JOB_ID", SqlDbType.Int, AtHocSystem.Local.GetSequence(strJobId));
                ngadEventInsert.AddParameter("RUN_ON", SqlDbType.Int, DateTimeExtensions.ToSeconds(AtHocSystem.Local.CurrentDateTime));
                ngadEventInsert.AddParameter("PRIORITY", SqlDbType.Int, record["PRIORITY"]);
                ngadEventInsert.AddParameter(
                    "PAYLOAD",
                    SqlDbType.VarChar,
                    GetPayload(record.GetValue<string>("PAYLOAD"),
                               DateTimeExtensions.ToDateTime(record.GetValue<int>("NEXT_RUN_DATE"))));
                ngadEventInsert.AddParameter("SCD_TYPE", SqlDbType.VarChar, "S");
                ngadEventInsert.AddParameter("SCHEDULE_ID", SqlDbType.Int, record["SCHEDULEJOB_ID"]); //We need a validation 
                try
                {
                    ngadEventInsert.ExecuteNonQuery(sqlEventInsert);
                }
                catch (Exception ex)
                {
                }
            }
        }

        private static string GetSQL()
        {
            const string sql = @"
            Insert Into SCD_EVENT_TAB(
                JOB_ID,
                RUN_ON,
                PRIORITY,
                PAYLOAD,
                SCD_TYPE,
                SCHEDULE_ID
                )
            Values
                (@JOB_ID,
                @RUN_ON,
                @PRIORITY,
                @PAYLOAD,
                @SCD_TYPE,
                @SCHEDULE_ID)";
            return sql;
        }

        /// <summary>
        /// Append original start date into payload
        /// </summary>
        /// <param name="payload"></param>
        /// <param name="scdStartDate"></param>
        /// <returns></returns>
        private static string GetPayload(string payload, DateTime scdStartDate)
        {
            return payload;

        }

        #endregion
    }
}
