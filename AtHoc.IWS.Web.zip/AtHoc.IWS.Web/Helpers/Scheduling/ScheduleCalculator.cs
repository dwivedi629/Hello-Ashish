﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
namespace AtHoc.IWS.Web.Helpers.Scheduling
{
    internal static class ScheduleCalculator
    {

        #region member variables
        private static Hashtable _monthlyTable = new Hashtable();
        private static Hashtable _WeeklyRelativeTable = new Hashtable();

        #endregion

        #region Calculate Next Run Date and Time
        /// <summary>
        /// This is the main method will calculate next run date for all scheduling types.
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="frequencyType"></param>
        /// <param name="frequencySubMonthType"></param>
        /// <param name="frequencyInterval"></param>
        /// <param name="frequencySubDayInterval"></param>
        /// <param name="frequencyRelativeInterval"></param>
        /// <param name="frequencyRecurrenceFactor"></param>
        /// <param name="originalStartDate"></param>
        /// <param name="currentTime">VPS current datetime passed in by caller</param>
        /// <returns></returns>
        internal static DateTime NextRun(
            DateTime startDate,
            FrequencyType frequencyType,
            int frequencySubMonthType,
            int frequencyInterval,
            int frequencySubDayInterval,
            int frequencyRelativeInterval,
            int frequencyRecurrenceFactor,
            DateTime originalStartDate,
            DateTime currentTime)
        {
            DateTime date;
            DateTime doriginalstartDate = CreateDateTimeWithoutSeconds(originalStartDate);
            DateTime tstartTime = CreateDateTimeWithoutSeconds(startDate);
            //DateTime currentTime = AtHocSystem.Local.CurrentDateTime;
            DateTime currentDate = CreateDateWithoutTime(currentTime);

            try
            {
                //One Time, frequencyType = 1 is not used at all.
                if (frequencyType == FrequencyType.OneTime)
                {
                    startDate = new DateTime(startDate.Year, startDate.Month, startDate.Day, tstartTime.Hour, tstartTime.Minute, 00);
                }
                //Daily
                else if (frequencyType == FrequencyType.Daily)
                {
                    startDate = Daily(frequencyInterval, startDate, currentTime);
                }
                // Weekly
                else if (frequencyType == FrequencyType.Weekly)
                {
                    //1 = Sunday,2 =  Monday,4 = Tuesday,8 =Wednesday,16 =Thursday,32=Friday,64 = Saturday
                    date = GetNextWeekDay(startDate, frequencyInterval, frequencyRecurrenceFactor, tstartTime, currentTime, doriginalstartDate);
                    date = new DateTime(date.Year, date.Month, date.Day, tstartTime.Hour, tstartTime.Minute, 00);
                    startDate = date;
                }
                //Monthly
                else if (frequencyType == FrequencyType.MonthlyAbsolute)
                {
                    //Day : 1..31
                    // frequencyRecurrenceFactor always > 0
                    // date = GetMonthly(dstartDate, frequencyInterval, frequencyRecurrenceFactor, tstartTime, currentDate, currentTime);
                    date = GetMonthly(startDate, frequencyInterval, frequencyRecurrenceFactor, tstartTime, currentDate, currentTime);
                    date = new DateTime(date.Year, date.Month, date.Day, tstartTime.Hour, tstartTime.Minute, 00);
                    startDate = date;


                }
                //Monthly Relative
                else if (frequencyType == FrequencyType.MonthlyRelative)
                {
                    //Day : 1 = Sunday,2 = Monday,3 = Tuesday,4 = Wednesday,5 = Thursday,6 = Friday
                    //Day : 7 = Saturday,8 = Day,9 = Weekday,10 = Weekend day
                    //Month Interval :First, Second, Third, Fourth and Last. 
                    //frequencyRecurrenceFactor always > 0
                    date = GetMonthlyRelative(startDate, frequencyRelativeInterval, frequencyInterval, frequencyRecurrenceFactor, tstartTime, currentDate, currentTime);
                    date = new DateTime(date.Year, date.Month, date.Day, tstartTime.Hour, tstartTime.Minute, 00);
                    startDate = date;
                }
                // Yearly
                else if (frequencyType == FrequencyType.YearlyAbsolute)
                {
                    //Months : Jan = 1, Feb 2, ... Dec =12.
                    // Days : 1,2 ... 31
                    date = GetYearly(startDate, frequencySubMonthType, frequencyInterval, tstartTime, currentDate, currentTime);
                    date = new DateTime(date.Year, date.Month, date.Day, tstartTime.Hour, tstartTime.Minute, 00);
                    startDate = date;
                }
                //Yearly Relative
                else if (frequencyType == FrequencyType.YearlyRelative)
                {
                    //Month Interval :First, Second, Third, Fourth and Last. 
                    //Day : 1 = Sunday,2 = Monday,3 = Tuesday,4 = Wednesday,5 = Thursday,6 = Friday
                    //Day : 7 = Saturday,8 = Day,9 = Weekday,10 = Weekend day
                    //Months: Jan = 1, Feb = 2...Dec = 12
                    date = GetYearlyRelative(startDate, frequencySubMonthType, tstartTime, currentDate, currentTime);
                    date = GetYearlyRelative(date, frequencyRelativeInterval, frequencyInterval, frequencyRecurrenceFactor, tstartTime, currentDate, currentTime);
                    date = new DateTime(date.Year, date.Month, date.Day, tstartTime.Hour, tstartTime.Minute, 00);
                    startDate = date;
                }
                return startDate;
            }
            catch (Exception)
            {

                return startDate;
            }

        }
        #endregion

        #region Daily
        private static DateTime Daily(int frequencyInterval, DateTime startDate, DateTime currentDate)
        {
            DateTime date;
            DateTime startTime = CreateDateTimeWithoutSeconds(startDate);
            //Daily Week Days
            //Monday, Tuesday,Wednesday,Thursday,Friday
            //Every Week Day frequency Interval = 0
            if (frequencyInterval == Convert.ToInt32(FrequencyTypeDaily.EveryWeekday))
            {
                if (StartDateGreaterThanCurrentDate(startDate, currentDate) && IsWeekDay(startDate))
                {
                    date = new DateTime(startDate.Year, startDate.Month, startDate.Day, startTime.Hour, startTime.Minute, 00);
                }
                else
                {
                    date = DailyNextWeekDay(startDate);
                    date = new DateTime(date.Year, date.Month, date.Day, startTime.Hour, startTime.Minute, 00);
                }
            }
            // Every Day frequency Interval = 1 
            else
            {
                if (StartDateGreaterThanCurrentDate(startDate, currentDate))
                {
                    date = new DateTime(startDate.Year, startDate.Month, startDate.Day, startTime.Hour, startTime.Minute, 00);
                }
                else
                {
                    date = DailyNextDay(startDate, frequencyInterval);
                    date = new DateTime(date.Year, date.Month, date.Day, startTime.Hour, startTime.Minute, 00);
                }
            }
            return date;
        }
        //Following DailyNextDay and DailyNextWeekDay methods is used by Daily schedule Type.
        //To calculate Daily next run date.
        private static DateTime DailyNextDay(DateTime date, int frequencyInterval)
        {
            DateTime d;
            d = date.AddDays(frequencyInterval);
            return d;
        }
        //To calculate Daily next week day .
        private static DateTime DailyNextWeekDay(DateTime date)
        {
            DateTime d = date;
            switch (date.DayOfWeek)
            {
                case DayOfWeek.Sunday:
                case DayOfWeek.Monday:
                case DayOfWeek.Tuesday:
                case DayOfWeek.Wednesday:
                case DayOfWeek.Thursday:
                    d = date.AddDays(1);
                    break;
                case DayOfWeek.Friday:
                    d = date.AddDays(3);
                    break;
                case DayOfWeek.Saturday:
                    d = date.AddDays(2);
                    break;
            }
            return d;
        }
        //To check whether it is a weekend.
        private static bool IsWeekDay(DateTime date)
        {
            return ((date.DayOfWeek != DayOfWeek.Saturday) && (date.DayOfWeek != DayOfWeek.Sunday));
        }
        private static bool StartDateGreaterThanCurrentDate(DateTime startDate, DateTime currentDate)
        {
            if (startDate > currentDate)
                return true;
            return false;
        }

        #endregion

        #region Weekly
        private static DateTime GetNextWeekDay(DateTime date, int frequencyInterval, int frequencyRecurrenceFactor, DateTime startTime, DateTime currentTime, DateTime originalStartDate)
        {
            int remainder;
            short days;
            TimeSpan day;
            DateTime activenextWeekDate;
            DateTime beginingWeekoforiginalStartDate;
            List<DayOfWeek> activeWeekDays;


            activeWeekDays = GetActiveWeekDays(frequencyInterval);

            if (frequencyRecurrenceFactor == 0)
            {
                frequencyRecurrenceFactor = 1;
            }
            //First day of original start date.
            beginingWeekoforiginalStartDate = originalStartDate.AddDays(-1 * Convert.ToInt16(originalStartDate.DayOfWeek));

            if (activeWeekDays.Contains(date.DayOfWeek) && startTime > currentTime)
            {
                activenextWeekDate = date;
            }
            else
            {
                do
                {
                    day = date.Subtract(originalStartDate);
                    days = (short)day.Days;
                    remainder = (days / 7);
                    remainder = remainder % frequencyRecurrenceFactor;
                    if (remainder == 0)
                    {
                        DateTime EndofWeek = date.AddDays(6 - Convert.ToInt16(date.DayOfWeek));
                        activenextWeekDate = date;
                        while (activenextWeekDate <= EndofWeek)
                        {
                            if (activenextWeekDate != EndofWeek)
                            {
                                activenextWeekDate = activenextWeekDate.AddDays(1);
                            }
                            else
                            {
                                if (activeWeekDays.Contains(activenextWeekDate.DayOfWeek))
                                    activenextWeekDate.AddDays(1);
                                break;
                            }

                            if (activeWeekDays.Contains(activenextWeekDate.DayOfWeek))
                                return activenextWeekDate;
                        }
                    }
                    day = date.Subtract(beginingWeekoforiginalStartDate);
                    days = (short)day.Days;
                    remainder = (days / 7);
                    remainder = remainder % frequencyRecurrenceFactor;
                    if (remainder == 0)
                    {
                        date = date.AddDays(7 * frequencyRecurrenceFactor);
                    }
                    activenextWeekDate = date.AddDays(-1 * Convert.ToInt16(date.DayOfWeek));
                }
                while (remainder != 0);

            }
            while (!activeWeekDays.Contains(activenextWeekDate.DayOfWeek))
                activenextWeekDate = activenextWeekDate.AddDays(1);
            return activenextWeekDate;
        }

        private static List<DayOfWeek> GetActiveWeekDays(int frequencyInterval)
        {
            List<DayOfWeek> list = new List<DayOfWeek>();

            if (IsWeekDyaActive(Weekly.Sunday, frequencyInterval))
                list.Add(DayOfWeek.Sunday);
            if (IsWeekDyaActive(Weekly.Monday, frequencyInterval))
                list.Add(DayOfWeek.Monday);
            if (IsWeekDyaActive(Weekly.Tuesday, frequencyInterval))
                list.Add(DayOfWeek.Tuesday);
            if (IsWeekDyaActive(Weekly.Wednesday, frequencyInterval))
                list.Add(DayOfWeek.Wednesday);
            if (IsWeekDyaActive(Weekly.Thursday, frequencyInterval))
                list.Add(DayOfWeek.Thursday);
            if (IsWeekDyaActive(Weekly.Friday, frequencyInterval))
                list.Add(DayOfWeek.Friday);
            if (IsWeekDyaActive(Weekly.Saturday, frequencyInterval))
                list.Add(DayOfWeek.Saturday);

            return list;
        }

        private static bool IsWeekDyaActive(Weekly day, int frequencyInterval)
        {
            int daycode = day.GetHashCode();
            return (daycode & frequencyInterval) > 0;
        }


        #endregion

        #region Monthly
        private static DateTime GetMonthly(DateTime startDate, int monthly, int frequencyRecurrenceFactor, DateTime startTime, DateTime currentDate, DateTime currentTime)
        {//Following GetMonthly and GetMonthlyRelative method is used by Monthly schedule Type.

            DateTime day;
            // DateTime monthlyDate = new DateTime(startDateTime.Year, startDateTime.Month, monthly, startDateTime.Hour, startDateTime.Minute, 00);
            if ((currentTime.Day == monthly && startDate.Month == currentTime.Month && currentTime.Day >= startDate.Day && startDate.Year >= currentTime.Year && (startDate.Hour > currentTime.Hour || (startDate.Hour >= currentTime.Hour && startDate.Minute > currentTime.Minute))))
            {
                day = new DateTime(startDate.Year, startDate.Month, monthly, startDate.Hour, startDate.Minute, 00);
            }
            else if (startDate > currentTime && startDate.Day == monthly)
            {
                day = startDate;
            }
            // else if (startDateTime.Day == currentDate && startTime > currentTime)
            else if (((int)monthly > currentDate.Day && startTime > currentTime) || (monthly > startDate.Day && startTime > currentTime) || (monthly > currentDate.Day && startDate.Month == currentTime.Month))
            {
                DateTime date = (new DateTime(startDate.Year, startDate.Month, 1)).AddDays(-1);
                DateTime lastday = (new DateTime(startDate.Year, startDate.Month, 1)).AddMonths(1).AddDays(-1);
                //day = date;
                int numberofDays = DateTime.DaysInMonth(startDate.Year, lastday.Month);
                if (monthly <= numberofDays)
                {
                    day = date.AddDays(monthly);
                }
                else
                {
                    date = lastday.AddMonths(frequencyRecurrenceFactor);
                    numberofDays = DateTime.DaysInMonth(startDate.Year, date.Month);
                    if (monthly <= numberofDays)
                    {
                        date = (new DateTime(date.Year, date.Month, 1)).AddDays(-1);
                        day = date.AddDays(monthly);
                    }
                    else
                    {
                        date = date.AddMonths(frequencyRecurrenceFactor);
                        date = (new DateTime(date.Year, date.Month, 1)).AddDays(-1);
                        day = date.AddDays(monthly);
                    }

                }
            }
            else
            {
                startDate = startDate.AddMonths(frequencyRecurrenceFactor);
                DateTime date = (new DateTime(startDate.Year, startDate.Month, 1)).AddDays(-1);
                DateTime lastday = (new DateTime(startDate.Year, startDate.Month, 1)).AddMonths(1).AddDays(-1);
                // day = date;
                int numberofDays = DateTime.DaysInMonth(startDate.Year, lastday.Month);
                if (monthly <= numberofDays)
                {
                    day = date.AddDays(monthly);
                }
                else
                {
                    date = date.AddMonths(frequencyRecurrenceFactor);
                    numberofDays = DateTime.DaysInMonth(startDate.Year, date.Month);
                    if (monthly <= numberofDays)
                    {
                        // date = (new DateTime(date.Year, date.Month, 1)).AddDays(-1);
                        day = date.AddDays(monthly);
                    }
                    else
                    {
                        date = date.AddMonths(frequencyRecurrenceFactor);
                        date = (new DateTime(date.Year, date.Month, 1)).AddDays(-1);
                        day = date.AddDays(monthly);
                    }

                }
            }
            return day;
        }
        #endregion

        #region Monthly Relative
        private static DateTime GetMonthlyRelative(DateTime startDate, int frequencyRelativeInterval, int frequencyInterval, int frequencyRecurrenceFactor, DateTime startTime, DateTime currentDate, DateTime currentTime)
        {
            AddWeekDay();
            int ifrequencyRelativeInterval = CalFrequencyRelativeInterval(frequencyRelativeInterval);
            string dayName = WeekDayRelative(frequencyInterval);
            if (dayName == null) throw new ArgumentNullException("dayName");
            DateTime date = (new DateTime(startDate.Year, startDate.Month, 1)).AddDays(-1);
            DateTime lastday = (new DateTime(startDate.Year, startDate.Month, 1)).AddMonths(1).AddDays(-1);
            DateTime day = date;


            if (frequencyInterval == 8)
            {
                if (ifrequencyRelativeInterval != 5)
                {
                    day = date.AddDays(ifrequencyRelativeInterval);
                }
                else
                {
                    day = lastday;
                }
            }
            else if (frequencyInterval == 9)
            {
                if (ifrequencyRelativeInterval != 5)
                {
                    int days = MonthlyNextWeekDay(date);
                    day = date.AddDays(days);
                    date = date.AddDays(days);
                    bool weekday = false;
                    day = date.AddDays(ifrequencyRelativeInterval);
                    while (!weekday)
                    {
                        if (IsWeekDay(day))
                        {
                            weekday = false;
                            break;
                        }
                        day = day.AddDays(1);
                    }
                }
                else
                {
                    day = lastday;
                    for (int i = lastday.Day; i >= 1; i--)
                    {
                        if (IsWeekDay(day))
                            break;
                        day = day.AddDays(-1);

                    }
                }
            }
            else if (frequencyInterval == 10) // Weekend day
            {
                day = GetRelativeWeekendDay(startDate, ifrequencyRelativeInterval);


            }
            else
            {
                day = GetRelativeDay(startDate, ifrequencyRelativeInterval, (DayOfWeek)(frequencyInterval - 1));

            }
            day = new DateTime(day.Year, day.Month, day.Day, startTime.Hour, startTime.Minute, 00);
            if (day < currentTime)
            {
                day = GetMonthlyRelative(day.AddMonths(frequencyRecurrenceFactor), frequencyRelativeInterval, frequencyInterval, frequencyRecurrenceFactor, startTime, currentDate, currentTime);
            }
            if (day < startTime)
            {
                day = GetMonthlyRelative(day.AddMonths(frequencyRecurrenceFactor), frequencyRelativeInterval, frequencyInterval, frequencyRecurrenceFactor, startTime, currentDate, currentTime);
            }
            return day;
        }
        #endregion

        #region Relative Calculation Utility
        private static int MonthlyNextWeekDay(DateTime date)
        {
            int days = 0;
            switch (date.DayOfWeek)
            {
                case DayOfWeek.Friday:
                    days = 2;
                    break;
                case DayOfWeek.Saturday:
                    days = 1;
                    break;
            }
            return days;
        }
        private static int CalFrequencyRelativeInterval(int frequencyRelativeInterval)
        {
            int fri = 0;
            if (frequencyRelativeInterval == 1)   // First ??
            { fri = 1; }
            else if (frequencyRelativeInterval == 2)  // Second ??
            { fri = 2; }
            else if (frequencyRelativeInterval == 4) // Third ??
            { fri = 3; }
            else if (frequencyRelativeInterval == 8) // Forth ??
            { fri = 4; }
            else if (frequencyRelativeInterval == 16) // Last ??
            { fri = 5; }
            return fri;
        }

        private static DateTime GetRelativeWeekendDay(DateTime date, int relativeNumber)
        {
            var weekendDays = GetWeekendDaysOfMonth(date);
            return (relativeNumber == 5) ? weekendDays.Last() : weekendDays[relativeNumber - 1];
        }

        private static List<DateTime> GetWeekendDaysOfMonth(DateTime date)
        {
            // Get the 1st day of month
            DateTime startDate = date.AddDays(1 - date.Day);

            List<DateTime> list = new List<DateTime>();
            for (int i = 0; i < DateTime.DaysInMonth(date.Year, date.Month); i++)
            {
                DateTime d = startDate.AddDays(i);
                if (d.DayOfWeek == DayOfWeek.Saturday || d.DayOfWeek == DayOfWeek.Sunday)
                    list.Add(d);
            }
            return list;
        }

        private static DateTime GetRelativeDay(DateTime date, int relativeNumber, DayOfWeek dayOfWeek)
        {
            List<DateTime> weekendDays = GetDaysOfMonth(date, dayOfWeek);
            if (relativeNumber == 5) // Last weekend day
                return weekendDays.Last();
            else
                return weekendDays[relativeNumber - 1];
        }

        private static List<DateTime> GetDaysOfMonth(DateTime date, DayOfWeek dayOfWeek)
        {
            // Get the 1st day of month
            DateTime startDate = date.AddDays(1 - date.Day);

            List<DateTime> list = new List<DateTime>();
            for (int i = 0; i < DateTime.DaysInMonth(date.Year, date.Month); i++)
            {
                DateTime d = startDate.AddDays(i);
                if (d.DayOfWeek == dayOfWeek)
                    list.Add(d);
            }
            return list;
        }

        //private static int GetGapToNextWeekEnd(DateTime date)
        //{
        //    int days = 0;
        //    switch (date.DayOfWeek)
        //    {
        //        case System.DayOfWeek.Sunday:
        //            days = 6;
        //            break;
        //        case System.DayOfWeek.Monday:
        //            days = 5;
        //            break;
        //        case System.DayOfWeek.Tuesday:
        //            days = 4;
        //            break;
        //        case System.DayOfWeek.Wednesday:
        //            days = 3;
        //            break;
        //        case System.DayOfWeek.Thursday:
        //            days = 2;
        //            break;
        //        case System.DayOfWeek.Friday:
        //            days = 1;
        //            break;
        //        case System.DayOfWeek.Saturday:
        //            days = 1;
        //            break;
        //    }
        //    return days;
        //}

        private static string WeekDayRelative(int frequencyInterval)
        {
            return _WeeklyRelativeTable[frequencyInterval].ToString();

        }

        #endregion

        #region Yearly
        private static DateTime GetYearly(DateTime date, int month, int days, DateTime startTime, DateTime currentDate, DateTime currentTime)
        {
            DateTime d = date;
            try
            {
                if (month < 1 || month > 12)
                {
                    throw new Exception("Month must be between 1 to 12.");
                }
                if (days < 1 || days > 31)
                {
                    throw new Exception("Day must be between 1 to 31.");
                }
                if (d.Year == currentTime.Year && month == (int)currentDate.Month && days == (int)currentDate.Day && startTime > currentTime)
                {
                }
                else if (days == 29 && month == 2)
                {
                    if (
                        ((d.Year == currentTime.Year && month == d.Month && days > d.Day) ||
                        (d.Year == currentTime.Year && month > d.Month) ||
                        (d.Year > currentTime.Year && month > d.Month) ||
                        (d.Year > currentTime.Year && month == d.Month && days > d.Day) ||
                        (d.Year > currentTime.Year && month == d.Month && days == d.Day)) && DateTime.IsLeapYear(d.Year))
                    {
                        d = new DateTime(d.Year, month, days);
                    }
                    else
                    {
                        do
                        {
                            d = d.AddYears(1);
                        }
                        while (!DateTime.IsLeapYear(d.Year));
                        d = new DateTime(d.Year, month, days);
                    }
                }
                else if (d.Year == startTime.Year && d.Month == startTime.Month && d.Day == startTime.Day && days >= startTime.Day && startTime > currentTime)
                {
                    d = new DateTime(d.Year, month, days);
                }
                else if (d.Year == currentTime.Year && month == d.Month && days > d.Day)
                {
                    d = new DateTime(d.Year, month, days);
                }
                else if (d.Year == currentTime.Year && month > d.Month)
                {
                    d = new DateTime(d.Year, month, days);
                }
                else if (d.Year > currentTime.Year && month > d.Month)
                {
                    d = new DateTime(d.Year, month, days);
                }
                else if (d.Year > currentTime.Year && month == d.Month && days > d.Day)
                {
                    d = new DateTime(d.Year, month, days);
                }
                else if (d.Year > currentTime.Year && month == d.Month && days == d.Day)
                {
                    d = new DateTime(d.Year, month, days);
                }
                else
                {

                    d = d.AddYears(1);
                    d = new DateTime(d.Year, month, days);
                }
            }
            catch (Exception ex)
            {

            }
            return d;
        }
        #endregion

        #region Yearly Relative
        private static DateTime GetYearlyRelative(DateTime date, int month, DateTime startTime, DateTime currentDate, DateTime currentTime)
        {
            DateTime d = date;
            DateTime m;
            try
            {
                if (month < 1 || month > 12)
                {
                    throw new Exception("Month must be between 1 to 12.");
                }
                if (month == (int)currentDate.Month && month == d.Month && startTime > currentTime)
                {
                }
                else if (month >= d.Month)
                {
                    d = new DateTime(d.Year, month, d.Day);
                }
                else
                {
                    AddMonths();
                    IDictionaryEnumerator enumerator = _monthlyTable.GetEnumerator();
                    while (enumerator.MoveNext())
                    {
                        if (enumerator.Key.Equals(month))
                        {
                            m = date.AddMonths(-1);
                            d = (new DateTime(date.Year, date.Month, 1)).AddDays(-0);
                            d = (new DateTime(d.Year, d.Month, 1)).AddMonths(-m.Month);
                            d = d.AddYears(1);
                            d = d.AddMonths(month - 1);
                            break;
                        }
                    }
                }
            }
            catch (Exception)
            {

            }
            return d;

        }
        private static DateTime GetYearlyRelative(DateTime startDate, int frequencyRelativeInterval, int frequencyInterval, int frequencyRecurrenceFactor, DateTime startTime, DateTime currentDate, DateTime currentTime)
        {
            int days;
            AddWeekDay();
            int ifrequencyRelativeInterval = CalFrequencyRelativeInterval(frequencyRelativeInterval);
            string dayName = WeekDayRelative(frequencyInterval);
            //int weekNo = 1;
            //int weenEndWeekNo = 0;
            DateTime date = (new DateTime(startDate.Year, startDate.Month, 1)).AddDays(-1);
            DateTime lastday = (new DateTime(startDate.Year, startDate.Month, 1)).AddMonths(1).AddDays(-1);
            DateTime day = date;


            if (frequencyInterval == 8)
            {
                if (ifrequencyRelativeInterval != 5)
                {
                    day = date.AddDays(ifrequencyRelativeInterval);
                }
                else
                {
                    day = lastday;
                }
            }
            else if (frequencyInterval == 9)
            {
                if (ifrequencyRelativeInterval != 5)
                {
                    days = MonthlyNextWeekDay(date);
                    day = date.AddDays(days);
                    date = date.AddDays(days);
                    bool weekday = false;
                    day = date.AddDays(ifrequencyRelativeInterval);
                    while (!weekday)
                    {
                        if (IsWeekDay(day))
                        {
                            weekday = false;
                            break;
                        }
                        day = day.AddDays(1);
                    }
                }
                else
                {
                    day = lastday;
                    for (int i = lastday.Day; i >= 1; i--)
                    {
                        if (IsWeekDay(day))
                            break;
                        day = day.AddDays(-1);

                    }
                }
            }
            else if (frequencyInterval == 10)
            {
                day = GetRelativeWeekendDay(startDate, ifrequencyRelativeInterval);

                //for (int i = 1; i <= lastday.Day; i++)
                //{
                //    if (weenEndWeekNo == ifrequencyRelativeInterval)
                //    {
                //        if (day > lastday)
                //        {
                //            days = GetGapToNextWeekEnd(date);
                //            day = date.AddDays(-days);
                //            date = date.AddDays(-days);

                //        }
                //        if (!IsWeekDay(day))
                //            break;
                //        day = day.AddDays(1);

                //    }
                //    else
                //    {
                //        weenEndWeekNo++;
                //        days = GetGapToNextWeekEnd(date);
                //        day = date.AddDays(days);
                //        date = date.AddDays(days);
                //    }
                //}
            }
            else
            {
                day = GetRelativeDay(startDate, ifrequencyRelativeInterval, (DayOfWeek)(frequencyInterval - 1));
                //for (int i = 1; i <= lastday.Day; i++)
                //{
                //    if (weekNo == ifrequencyRelativeInterval)
                //    {
                //        day = day.AddDays(1);
                //        if (day > lastday)
                //        {
                //            days = 7;
                //            day = date.AddDays(-days);
                //            date = date.AddDays(-days);

                //        }
                //        if (day.DayOfWeek.ToString() == dayName)
                //        {
                //            break;
                //        }
                //    }
                //    else
                //    {
                //        weekNo++;
                //        days = 7;
                //        day = date.AddDays(days);
                //        date = date.AddDays(days);
                //    }
                //}
            }
            day = new DateTime(day.Year, day.Month, day.Day, startTime.Hour, startTime.Minute, 00);
            if (day < currentTime)
            {
                day = GetYearlyRelative(day.AddYears(1), frequencyRelativeInterval, frequencyInterval, frequencyRecurrenceFactor, startTime, currentDate, currentTime);
            }
            if (day < startTime)
            {
                day = GetYearlyRelative(day.AddYears(1), frequencyRelativeInterval, frequencyInterval, frequencyRecurrenceFactor, startTime, currentDate, currentTime);
            }
            return day;
        }
        #endregion

        #region Private Utility Methods

        // Removed by refactoring. YS
        //private static void frequencyIntervalWeekly(int frequencyInterval)
        //{
        //    //To calculate frequency type weekly, frequency Intervals like: 1 = Sunday; 2 =  Monday; 
        //    //4 = Tuesday ;8 =Wednesday; 16 =Thursday; 32=Friday; 64 = Saturday

        //    if (frequencyInterval == 0)
        //    {
        //    }
        //    else if (frequencyInterval >= 64)
        //    {
        //        _weeklyTable.Add(64, DayOfWeek.Saturday);
        //        frequencyInterval = frequencyInterval - 64;
        //        frequencyIntervalWeekly(frequencyInterval);
        //    }
        //    else if (frequencyInterval >= 32)
        //    {
        //        _weeklyTable.Add(32, DayOfWeek.Friday);
        //        frequencyInterval = frequencyInterval - 32;
        //        frequencyIntervalWeekly(frequencyInterval);
        //    }
        //    else if (frequencyInterval >= 16)
        //    {
        //        _weeklyTable.Add(16, DayOfWeek.Thursday);
        //        frequencyInterval = frequencyInterval - 16;
        //        frequencyIntervalWeekly(frequencyInterval);
        //    }
        //    else if (frequencyInterval >= 8)
        //    {
        //        _weeklyTable.Add(8, DayOfWeek.Wednesday);
        //        frequencyInterval = frequencyInterval - 8;
        //        frequencyIntervalWeekly(frequencyInterval);

        //    }
        //    else if (frequencyInterval >= 4)
        //    {
        //        _weeklyTable.Add(4, DayOfWeek.Tuesday);
        //        frequencyInterval = frequencyInterval - 4;
        //        frequencyIntervalWeekly(frequencyInterval);

        //    }
        //    else if (frequencyInterval >= 2)
        //    {
        //        _weeklyTable.Add(2, DayOfWeek.Monday);
        //        frequencyInterval = frequencyInterval - 2;
        //        frequencyIntervalWeekly(frequencyInterval);
        //    }
        //    else if (frequencyInterval == 1)
        //    {
        //        _weeklyTable.Add(1, DayOfWeek.Sunday);
        //        frequencyInterval = frequencyInterval - 1;
        //        frequencyIntervalWeekly(frequencyInterval);
        //    }
        //}

        private static void AddMonths()
        {
            if (_monthlyTable.Count == 0)
            {
                _monthlyTable.Add(1, Monthly.January);
                _monthlyTable.Add(2, Monthly.February);
                _monthlyTable.Add(3, Monthly.March);
                _monthlyTable.Add(4, Monthly.April);
                _monthlyTable.Add(5, Monthly.May);
                _monthlyTable.Add(6, Monthly.June);
                _monthlyTable.Add(7, Monthly.July);
                _monthlyTable.Add(8, Monthly.August);
                _monthlyTable.Add(9, Monthly.September);
                _monthlyTable.Add(10, Monthly.October);
                _monthlyTable.Add(11, Monthly.November);
                _monthlyTable.Add(12, Monthly.December);
            }

        }
        private static void AddWeekDay()
        {
            if (_WeeklyRelativeTable.Count == 0)
            {
                _WeeklyRelativeTable.Add(1, MonthlyWeekDayRelative.Sunday);
                _WeeklyRelativeTable.Add(2, MonthlyWeekDayRelative.Monday);
                _WeeklyRelativeTable.Add(3, MonthlyWeekDayRelative.Tuesday);
                _WeeklyRelativeTable.Add(4, MonthlyWeekDayRelative.Wednesday);
                _WeeklyRelativeTable.Add(5, MonthlyWeekDayRelative.Thursday);
                _WeeklyRelativeTable.Add(6, MonthlyWeekDayRelative.Friday);
                _WeeklyRelativeTable.Add(7, MonthlyWeekDayRelative.Saturday);
                _WeeklyRelativeTable.Add(8, MonthlyWeekDayRelative.Day);
                _WeeklyRelativeTable.Add(9, MonthlyWeekDayRelative.Weekday);
                _WeeklyRelativeTable.Add(10, MonthlyWeekDayRelative.WeekendDay);
            }
        }

        #endregion

        #region internal Utility Methods
        internal static DateTime CreateDateTimeWithoutSeconds(DateTime date)
        {
            return new DateTime(date.Year, date.Month, date.Day, date.Hour, date.Minute, 0);
        }
        internal static DateTime CreateDateWithoutTime(DateTime date)
        {
            return new DateTime(date.Year, date.Month, date.Day, 0, 0, 0);
        }
        #endregion

    }
}