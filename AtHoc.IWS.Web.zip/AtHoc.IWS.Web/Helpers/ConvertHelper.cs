﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AtHoc.IWS.Web.Helpers
{
    public static class ConvertHelper
    {
        public static bool TryParseBoolean(string val)
        {
            bool ret;
            return bool.TryParse(val, out ret) ? ret : false;
        }

        public static int TryParseInt(string val)
        {
            int ret;
            return int.TryParse(val, out ret) ? ret : 0;
        }
    }
}