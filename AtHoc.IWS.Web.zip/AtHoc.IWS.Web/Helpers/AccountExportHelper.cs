﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using AtHoc.Global.Resources;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Web.Configurations;
using AtHoc.IWS.Web.Configurations.Constants;
using AtHoc.IWS.Web.Models.Accountability;
using AtHoc.IWS.Web.Models.Accoutability;
using AtHoc.IWS.Web.Models.Export;
using AtHoc.IWS.Web.Models.Publishing;
using AtHoc.IWS.Web.Models.Shared;
using AtHoc.IWS.Web.Models.UserManager;
using EO.Internal;

namespace AtHoc.IWS.Web.Helpers
{
    /// <summary>
    /// Account export helper.
    /// </summary>
    public static class AccountExportHelper
    {
        /// <summary>
        /// To get the account csv export data.
        /// </summary>
        /// <param name="exportSpec">export spec.</param>
        /// <param name="eventDetails">event details.</param>
        /// <param name="userDetails">users details.</param>
        /// <param name="hierReportBuilder">hierarchy details.</param>
        /// <returns>csv data byte array.</returns>
        public static byte[] GetAccountCsvExportData(AccountEventExportSpec exportSpec, EventModel eventDetails, DashboardModel dashboardModel, Dictionary<string, object> userDetails = null, EventOrganizationReportBuilder hierReportBuilder = null)
        {
            CsvDataModel summaryCsvData = null;
            CsvDataModel userCsvData = null;
            CsvDataModel hrchyCsvData = null;

            if (exportSpec.IncludeSummary)//get the summary section csv data .
            {
                var summaryExportModel = GenerateSummaryExportModel(dashboardModel);
                summaryCsvData = ExportUtility.SetCsv(summaryExportModel, exportSpec.ExportDescription, includeTableTitle: true);
            }
            if (exportSpec.IncludeHierarchy && hierReportBuilder!=null)//get the hierarchy section csv data.
            {
                var responseOptions = eventDetails.AlertBaseModel.Content.ResponseOptions;
                var orgHrchy = hierReportBuilder;
                var hrchyExportModel = GenerateOrgHrchyExportModel(orgHrchy, responseOptions,exportSpec.OrgHrchyHeaderTitle, true);
                hrchyCsvData = ExportUtility.SetCsv(hrchyExportModel, includeTableTitle: true);
            }
            if (exportSpec.IncludeUsers && userDetails!=null)//get the users section csv data.
            {
                var userExportModel = GenerateUsersExportModel(userDetails, true);
                userCsvData = ExportUtility.SetCsv(userExportModel, includeTableTitle: true);
           }
            
                var sectionSeprator = AtHocConfigService.Current.Windows1252Encoding.GetBytes("\r\n");//this is the line separator betn each section.
                var csvGridDataLength = sectionSeprator.Length + (summaryCsvData != null ? summaryCsvData.GridData.Length : 0) + (hrchyCsvData != null ? hrchyCsvData.GridData.Length + sectionSeprator.Length : 0) + (userCsvData != null ? userCsvData.GridData.Length+ sectionSeprator.Length : 0);//calculate the total csv data length.
                var csvGridData = new byte[csvGridDataLength];
                #region combine the all sections data .
                // (Buffer.BlockCOpy - Inmemory byte array copy)
                if (summaryCsvData != null)
                {
                    Buffer.BlockCopy(summaryCsvData.GridData, 0, csvGridData, 0, summaryCsvData.GridData.Length);
                }
                if (hrchyCsvData != null)
                {
                    if (summaryCsvData != null)
                    {
                        Buffer.BlockCopy(sectionSeprator, 0, csvGridData, summaryCsvData.GridData.Length, sectionSeprator.Length);
                        Buffer.BlockCopy(hrchyCsvData.GridData, 0, csvGridData, summaryCsvData.GridData.Length + sectionSeprator.Length, hrchyCsvData.GridData.Length);
                    }
                    else
                        Buffer.BlockCopy(hrchyCsvData.GridData, 0, csvGridData, 0, hrchyCsvData.GridData.Length);
                   
                }
                if (userCsvData == null) return csvGridData;
                if (summaryCsvData != null)
                {
                    int dstOffset = summaryCsvData.GridData.Length + sectionSeprator.Length + (hrchyCsvData != null ? (hrchyCsvData.GridData.Length ) : 0);
                    Buffer.BlockCopy(sectionSeprator, 0, csvGridData, dstOffset, sectionSeprator.Length);
                    Buffer.BlockCopy(userCsvData.GridData, 0, csvGridData, dstOffset + sectionSeprator.Length, userCsvData.GridData.Length);
                 }
                 else
                 {
                     if (hrchyCsvData != null)
                     {
                         Buffer.BlockCopy(sectionSeprator, 0, csvGridData, hrchyCsvData.GridData.Length, sectionSeprator.Length);
                         Buffer.BlockCopy(userCsvData.GridData, 0, csvGridData,hrchyCsvData.GridData.Length + sectionSeprator.Length , userCsvData.GridData.Length);
                     }
                         
                     else
                        Buffer.BlockCopy(userCsvData.GridData, 0, csvGridData,0, userCsvData.GridData.Length);
                 }
                #endregion
                return csvGridData;
        }

        /// <summary>
        /// TO get the account pdf export data.
        /// </summary>
        /// <param name="exportSpec">account export spec.</param>
        /// <param name="eventDetails">event details.</param>
        /// <param name="userDetails">user details.</param>
        /// <param name="hierReportBuilder">hierarchy details.</param>
        /// <returns>accound odf data.</returns>
        public static AccountPdfHtmlDataModel GetAccountPdfExportData(AccountEventExportSpec exportSpec, EventModel eventDetails, Dictionary<string, object> userDetails = null, EventOrganizationReportBuilder hierReportBuilder = null)
        {
            var accountPdfHtml = new AccountPdfHtmlDataModel { PdfSpeConfiguration = new PdfGridConfiguration(5) };//PdfGridConfiguration(5) is to set the fixed width for the PDF doc.
            var accountSectionDataModelList = new List<PdfHtmlDataModel>();

            if (exportSpec.IncludeHierarchy && hierReportBuilder!=null)//Include the hierarchy export data.
            {
                
                var responseOptions = eventDetails.AlertBaseModel.Content.ResponseOptions;
                var hrchyExportModel = GenerateOrgHrchyExportModel(hierReportBuilder, responseOptions,exportSpec.OrgHrchyHeaderTitle, false);
                var hrchyBreadcrum = exportSpec.OrgHrchyFilter!=null? IWSResources.PA_Event_Export_Current_Filter + exportSpec.OrgHrchyFilter:null;

                //calculate the column width dynamically on the basic of number of columns.
                var hrchyColumnWidth = CalculateColumnWidth(accountPdfHtml.PdfSpeConfiguration.PdfDocumentSize,
                responseOptions.Count() + 3);
                    var hrchyPdfHtml = ExportUtility.SetPdf(hrchyExportModel, hrchyColumnWidth - 20, false);//Get Pdf Html Data to be rendered.
                    hrchyPdfHtml.TableSubTitle = hrchyBreadcrum; //set the filter text.
                    accountSectionDataModelList.Add(hrchyPdfHtml);
                
            }
            if (exportSpec.IncludeUsers)//Include the users export data.
            {
                var userTableHeading = IWSResources.PA_Event_Export_Current_Filter + exportSpec.CurrentUserFilter;
                var userExportModel = GenerateUsersExportModel(userDetails, false);
                var usrColumnWidth = CalculateColumnWidth(accountPdfHtml.PdfSpeConfiguration.PdfDocumentSize,
                    userExportModel.GridHeaders.Count);
                var userPdfHtml = ExportUtility.SetPdf(userExportModel, usrColumnWidth - 20, false); //Get Pdf Html Data to be rendered.
                userPdfHtml.TableSubTitle = userTableHeading; //set the filtertext.
                accountSectionDataModelList.Add(userPdfHtml);
            }
            accountPdfHtml.AccountSectionsDataModels = accountSectionDataModelList;
            return accountPdfHtml;
        }

        /// <summary>
        /// To calculate the column width for dynamic number of columns.
        /// </summary>
        /// <param name="pdfDocumentSize">pdf document size.</param>
        /// <param name="columnCount">column count.</param>
        /// <returns></returns>
        private static int CalculateColumnWidth(float pdfDocumentSize,int columnCount )
        {
            return (int)
                        (((pdfDocumentSize * PdfConfig.DotPerInch)) /
                         (columnCount));
        }
        /// <summary>
        /// To generate the summary export model for CSV.
        /// </summary>
        /// <param name="eventDetails">event details.</param>
        /// <returns>export model.</returns>
        private static ExportModel GenerateSummaryExportModel(DashboardModel eventDetails)
        {
            var gridHeader = new List<ExportGridColumnConfig>
            {
                new ExportGridColumnConfig(IWSResources.PA_Event_Export_Total_Users_Column_Title),
                new ExportGridColumnConfig(IWSResources.PA_Event_Export_Status_Column_Title),
                new ExportGridColumnConfig(IWSResources.PA_Event_Export_No_Status_Column_Title),
                new ExportGridColumnConfig(IWSResources.PA_Event_Export_Status_By_User_Column_Title),
                new ExportGridColumnConfig(IWSResources.PA_Event_Export_No_Status_By_Opr_Column_Title)
            };
            gridHeader.AddRange(
                       eventDetails.RuntimeModel.Status.StatusByResponse.Select(
                           t => new ExportGridColumnConfig(t.Name)));

            var row = new Dictionary<string, object>();
            row.Add(IWSResources.PA_Event_Export_Total_Users_Column_Title, eventDetails.RuntimeModel.Status.TotalUsers);
            row.Add(IWSResources.PA_Event_Export_Status_Column_Title, eventDetails.RuntimeModel.Status.UsersWithStatus.Value);
            row.Add(IWSResources.PA_Event_Export_No_Status_Column_Title, eventDetails.RuntimeModel.Status.UsersWithoutStatus.Value);
            row.Add(IWSResources.PA_Event_Export_Status_By_User_Column_Title, eventDetails.RuntimeModel.Status.ResponsesByUser.Value);
            row.Add(IWSResources.PA_Event_Export_No_Status_By_Opr_Column_Title, eventDetails.RuntimeModel.Status.ResponsesByOperator.Value);
            foreach (var status in eventDetails.RuntimeModel.Status.StatusByResponse)
            {
                row.Add(status.Name, status.Value.Value);
            }
            var exportModel = new ExportModel
            {
                Title = IWSResources.PA_Event_Export_Template_Summary_Section_Title,
                GridRows = new List<Dictionary<string, object>> { row },
                GridHeaders = gridHeader,
                SubHeadline = ""
            };
            return exportModel;
        }
        /// <summary>
        /// To get the user export Model.
        /// </summary>
        /// <param name="userDetails">user details.</param>
        /// <param name="isCsv"></param>
        /// <returns>user export model.</returns>
        private static ExportModel GenerateUsersExportModel(Dictionary<string, object> userDetails, bool isCsv)
        {
            var columns = (List<CustomViewColumn>)userDetails["Columns"];
            var gridHeader = isCsv ? columns.Select(t => new ExportGridColumnConfig(t.DisplayName)).ToList() : columns.Select(t => new ExportGridColumnConfig(t.DisplayName) { HeaderStyle = "pdf-grid-bordered-header" }).ToList();

            var users = (SessionSearchResult)userDetails["Users"];
            var userList = users.Users;
            var exportGridRows = userList.Select(t => columns.ToDictionary<CustomViewColumn, string, object>(t1 => t1.DisplayName, t1 => t.UserAttributes.ContainsKey(t1.Key) ? t.UserAttributes[t1.Key] : t.UserDevice[t1.Key])).ToList();

            var exportModel = new ExportModel
            {
                Title = IWSResources.PA_Event_Export_Users_Section_Title,
                GridRows = exportGridRows,
                GridHeaders = gridHeader,
                SubHeadline = "(" + users.Users.Count.ToString(CultureInfo.InvariantCulture) + ")"

            };
            return exportModel;
        }

        /// <summary>
        /// To generate the Org Hierarchy Export Model.
        /// </summary>
        /// <param name="orgHrchyBuilder">Hierarchy Builder.</param>
        /// <param name="responseOptions">response options.</param>
        /// <param name="hierarchyColumnTitle">hierarchy column title</param>
        /// <param name="isCsv">isCsv export.</param>
        /// <returns>Hierarchy export model.</returns>
        private static ExportModel GenerateOrgHrchyExportModel(EventOrganizationReportBuilder orgHrchyBuilder, IList<ResponseOption> responseOptions,string hierarchyColumnTitle, bool isCsv)
        {

            var gridHeader = new List<ExportGridColumnConfig>();
            var gridRows = new List<Dictionary<string, object>>();
            if (isCsv)
            {
                //Grid Headers
                gridHeader.Add(new ExportGridColumnConfig(hierarchyColumnTitle));//Organization Hierarchy column.
                gridHeader.Add(new ExportGridColumnConfig(IWSResources.PA_Event_Export_Org_Hr_All_Column_Title));//All Column.
                gridHeader.Add(new ExportGridColumnConfig(IWSResources.PA_Event_Details_Analysis_NoResponse)//No Responses Column.
                );
                gridHeader.AddRange(
                    responseOptions.Select(
                        t => new ExportGridColumnConfig(t.ResponseText)));//To get the columns from response options.
            }
            else
            {
                //Grid Headers
                //HeaderStyle = "pdf-grid-bordered-header" - is to give border to column headers.
                gridHeader.Add(new ExportGridColumnConfig(hierarchyColumnTitle)
                {
                    HeaderStyle = "pdf-grid-bordered-header"
                });
                gridHeader.Add(new ExportGridColumnConfig(IWSResources.PA_Event_Export_Org_Hr_All_Column_Title)
                {
                    HeaderStyle = "pdf-grid-bordered-header"
                });
                gridHeader.Add(new ExportGridColumnConfig(IWSResources.PA_Event_Details_Analysis_NoResponse)
                {
                    HeaderStyle = "pdf-grid-bordered-header"
                });
                gridHeader.AddRange(
                    responseOptions.Select(
                        t => new ExportGridColumnConfig(t.ResponseText) { HeaderStyle = "pdf-grid-bordered-header" }));
            }
            //Grid Rows
            var rootDepth = orgHrchyBuilder.Entries.Min(x => x.Depth);
            var rootItems = orgHrchyBuilder.Entries.Where(x => x.Depth == rootDepth).ToList();
            var orderedList = orgHrchyBuilder.Entries.GroupBy(x => x.ParentId).ToList();
          
            foreach (var item in rootItems)
            {
                GetHierarchGridRows(item, orderedList, gridHeader, gridRows, responseOptions, rootDepth, isCsv);
            }
           
            var exportModel = new ExportModel
            {
                Title = IWSResources.PA_Event_Export_Org_Hrchy_Section_Title,
                GridRows = gridRows,
                GridHeaders = gridHeader,
                SubHeadline = IWSResources.PA_Event_Export_Org_Hrchy_Section_SubTitle

            };
            return exportModel;
        }
        /// <summary>
        /// To get the hierarchy grid rows.
        /// </summary>
        /// <param name="itemEntry"></param>
        /// <param name="orderedItemList">ordered list of hierarchy items.</param>
        /// <param name="gridHeader">grid headers.</param>
        /// <param name="gridRows">grid rows.</param>
        /// <param name="responseOptions">event responseoptions.</param>
        /// <param name="rootDepth">root item depth.</param>
        /// <param name="isCsv">isCSV report.</param>
        private static void GetHierarchGridRows(EventOrganizationReportEntry itemEntry, 
            IEnumerable<IGrouping<int, EventOrganizationReportEntry>> orderedItemList, List<ExportGridColumnConfig> gridHeader,List<Dictionary<string, object>> gridRows,IList<ResponseOption> responseOptions,int rootDepth, bool isCsv)
        {
            gridRows.Add(GenerateHierarchyRow(itemEntry, gridHeader, responseOptions, rootDepth, isCsv));
            if (itemEntry.HasChildren)
            {
                var enumerable = orderedItemList as IList<IGrouping<int, EventOrganizationReportEntry>> ?? orderedItemList.ToList();
                var eventOrganizationReportEntries = enumerable.FirstOrDefault(w=> w.Key == itemEntry.Id);
                if (eventOrganizationReportEntries != null)
                    foreach (var listItem in eventOrganizationReportEntries)
                    {
                        GetHierarchGridRows(listItem, enumerable, gridHeader, gridRows, responseOptions, rootDepth, isCsv);
                    }
            }
        }

        /// <summary>
        /// To get the Org Hierarchy export row.
        /// </summary>
        /// <param name="hEntry">hierarchy entry.</param>
        /// <param name="gridHeader">export grid header.</param>
        /// <param name="responseOptions">response options.</param>
        /// <param name="rootDepth">root org depth.</param>
        /// <param name="isCsv">isCsv.</param>
        /// <returns>export row for org hrchy.</returns>
        private static Dictionary<string, object> GenerateHierarchyRow(EventOrganizationReportEntry hEntry, IReadOnlyList<ExportGridColumnConfig> gridHeader,
            IList<ResponseOption> responseOptions, int rootDepth, bool isCsv)
        {
            var row = new Dictionary<string, object>();
            var responseKeys = (hEntry.ResponseValues).Keys;
            var orgName = hEntry.Name;
            if (hEntry.Depth == rootDepth + 1)
            {
                if (isCsv)
                    orgName = "      " + orgName;//to suffix the space for csv cell.
                else
                {
                    orgName = "\u00A0\u00A0" + orgName; //\u00A0 - unicode for non breakable whitespace
                }
            }

            if (hEntry.Depth == rootDepth + 2)
            {
                if (isCsv)
                    orgName = "            " + orgName;//to suffix the space for csv cell.
                else
                {
                    orgName = "\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0" + orgName; //\u00A0 - unicode for non breakable whitespace
                }
            }

            row.Add(gridHeader[0].ColumnName, orgName);
            var noResponse = 0;
            var responseCOntainsNoResponse = false;
            if (hEntry.ResponseValues.Keys.Contains("0"))
            {
                responseCOntainsNoResponse = true;
                noResponse = hEntry.ResponseValues["0"];
            }
            row.Add(gridHeader[1].ColumnName, hEntry.TotalCount);
            row.Add(gridHeader[2].ColumnName, noResponse);
            for (var i = 0; i < responseOptions.Count; i++)
            {
                if (responseCOntainsNoResponse)
                {
                    row.Add(responseOptions[i].ResponseText,
                   responseKeys.ToList().Contains((i + 1).ToString(CultureInfo.InvariantCulture))
                       ? hEntry.ResponseValues[(i + 1).ToString(CultureInfo.InvariantCulture)]
                       : 0);
                }
                else
                {
                    row.Add(responseOptions[i].ResponseText,
                    responseKeys.ToList().Contains((i + 1).ToString(CultureInfo.InvariantCulture))
                        ? hEntry.ResponseValues[(i + 1).ToString(CultureInfo.InvariantCulture)]
                        : 0);
                }
            }
            return row;
        }
    }
}