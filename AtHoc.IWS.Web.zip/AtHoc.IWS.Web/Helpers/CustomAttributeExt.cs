﻿using AtHoc.IWS.Business.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AtHoc.IWS.Web.Helpers
{
    public static class CustomAttributeExt
    {
        public static bool IsStatus(this CustomAttribute ca)
        {
            return ca.IsStandard == "N" 
                && ca.IsSystemAttribute == "N" 
                && ca.AttributeTypeId == CustomAttributeDataType.Picklist 
                && !string.IsNullOrEmpty(ca.SupportsHistoricalValues) 
                && (ca.SupportsHistoricalValues.ToLower() == "true" || ca.SupportsHistoricalValues.ToLower() == "y");
        }
    }
}