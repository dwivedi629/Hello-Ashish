﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using AtHoc.Global.Resources.Entities;
using AtHoc.Global.Resources.Implementations;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Serialization;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Data;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Users.Impl.Search;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.IWS.Business.Domain.Users;
using AtHoc.IWS.Business.Domain.Devices;
using AtHoc.IWS.Business.Domain.Devices.Spec;
using AtHoc.IWS.Map;
using AtHoc.IWS.Web.Configurations.Constants;
using AtHoc.Global.Resources;
using AtHoc.IWS.Web.Models.UserManager;
using AtHoc.Targeting;
using Criteria = AtHoc.IWS.Business.Data.Criteria;
using DistributionList = AtHoc.IWS.Business.Domain.Entities.DistributionList;
using Hierarchy = AtHoc.IWS.Business.Domain.Entities.Hierarchy;
using Provider = AtHoc.IWS.Business.Domain.Entities.Provider;

namespace AtHoc.IWS.Web.Helpers
{
    public interface IUserManagerHelper
    {
        void GetValidCustomViews(IList<CustomView> customViewList, IList<Device> devices, ref IEnumerable<CustomView> customFieldCustomViews, ref IEnumerable<CustomView> deviceCustomViews);
        List<string> GetCustomViewEntityNames(IEnumerable<CustomView> customViews, IEnumerable<Device> alldevices);
        CustomViewColumn CreateCustomViewColumnModel(Provider provider, CustomView customView, IEnumerable<Device> alldevices);

        IEnumerable<int> GetSelectedUserIds(UsersStatusCriteria model, ILookup<string, Device> devicesByName);
        List<UserSearchResultItem> GetSelectedUsernames(UsersStatusCriteria model, ILookup<string, Device> devicesByName);
        ICriteria CreateUserSearchCriterias(int[] userIds, int[] listItemIds, int[] hierarchyIds,
            int[] attributeValueIds, int[] attributeIds, string[] searchStrings, string queryCriteria,
            Provider provider, List<CustomAttribute> selectedAttributes, bool applyUserbase = true,
            int[] includeUserIds = null, int[] excludeUserIds = null, int distributionId = 0, bool? isMember = null, string staticQueryCriteria = null);

        ICriteria GetSelectedUserCriteria(UsersStatusCriteria criteria);

        void RefreshDevices(ref IEnumerable<Device> allDevices, ref ILookup<string, Device> devicesByCommonName, ref ILookup<string, Device> devicesByName, bool forceRefresh = false, int pid = -1);

        void RefreshCarrier(ref List<PagerCarrierEntity> pagerCarriers, bool forceRefresh = false);

        void RefreshAllRoles(ref IEnumerable<OperatorRole> operatorRoles, bool forceRefresh = false);

        void RefreshOperatorRoles(ref IEnumerable<OperatorRole> operatorRoles, int pid, bool forceRefresh = false);

        void RefreshOperatorAccessibleChannels(ref IEnumerable<AlertChannel> OperatorAccessibleChannels, bool forceRefresh = false, int pid = -1);

        void RefreshChannels(ref IEnumerable<AlertChannel> VPSChannels, bool forceRefresh = false, int pid = -1);

        void RefreshOperatorAccessibleDistributionLists(ref IEnumerable<DistributionList> operatorAccessibleDistributionLists, bool forceRefresh = false, int pid = -1);

        IEnumerable<UserItem> ConvertToUIModel(IEnumerable<UserItem> userItems);

        IEnumerable<UserSearchResultItem> ConvertToUIModel(IEnumerable<UserSearchResultItem> userItems);

        int GetUserBaseCount(int providerId, int operatorId, bool hideMassDevices = true, bool onlyEnabled = false);

        SectionAttribute BuildDisplayMobileAttribute(NotificationInfo notificationInfo);

        SectionAttribute BuildDisplayDesktopAttribute(NotificationInfo notificationInfo);

        bool HasAnyDistributionListInFolder(int distributionId);

        bool HasAnyDistributionListInFolder(DistributionList distributionList);

        Messages Verify_UserName_MappingId_Uniqueness(EndUserForSave updatedUser);

        UserCounts GetHomePageUserCounts(int providerId, int operatorId);

        List<string> InitializeAttributesToRetrieve(IEnumerable<CustomAttribute> defaultAttributes, IEnumerable<CustomView> customViews);

        List<string> InitializeDevicesToRetrieve(IEnumerable<CustomView> customViews, IEnumerable<Device> allDevices);

        IDictionary<int, List<int>> GetAttributeIdsByValueIds(IEnumerable<int> valueIds);

        IEnumerable<OperatorUserRole> GetOperatorRolesInSystem(int userId);

        string GetOperatorRolesFormattedText(int userId);

        UserSearchArgs ConvertToSearchArgs(UsersStatusCriteria model, bool includeCurrentProviderExclusively = false);

        Messages TranslateUsernameReturnCodesToMessages(IEnumerable<LoginIdUniquenessStatus> returnCodes, Messages messages);
        Dictionary<string, object> GetAttributeList(string attributeCsv, UserListType userListType);

        UserSearchArgs GetAdvancedCriteria(UserSearchArgs model, string queryCriteria, string staticQueryCriteria, int[] attributeValueIds, int[] attributeIds, int[] listItemIds);
    }

    public class UserCountModel
    {
        public int EnabledUsers { get; set; }

        public int OnlineUsers { get; set; }
    }

    public class UserManagerHelper : IUserManagerHelper
    {
        private readonly IUserFacade _userFacade;
        private readonly IOperatorFacade _operatorFacade;
        private readonly ICustomAttributeCache _customAttributeCache;
        private readonly IDeviceFacade _deviceFacade;
        private readonly IPagerCarrierFacade _pagerCarrierFacade;
        private readonly IOperatorDetailsFacade _operatorDetailsFacade;
        private readonly IPublishingFacade _publishingFacade;
        private readonly ICustomAttributeFacade _customAttributeFacade;
        const string ACTIVE_LABEL = "Active";
        const string IN_ACTIVE_LABEL = "Inactive";
        const string NOT_AVAILABLE_LABEL = "Not Available";
        const string AVAILABLE_LABEL = "Available";

        public UserManagerHelper(IUserFacade userFacade, IOperatorFacade operatorFacade,
            ICustomAttributeCache customAttributeCache, IDeviceFacade deviceFacade, IPagerCarrierFacade pagerCarrierFacade, IOperatorDetailsFacade operatorDetailsFacade, IPublishingFacade publishingFacade, ICustomAttributeFacade customAttributeFacade)
        {
            _userFacade = userFacade;
            _operatorFacade = operatorFacade;
            _customAttributeCache = customAttributeCache;
            _deviceFacade = deviceFacade;
            _pagerCarrierFacade = pagerCarrierFacade;
            _operatorDetailsFacade = operatorDetailsFacade;
            _publishingFacade = publishingFacade;
            _customAttributeFacade = customAttributeFacade;
        }

        /// <summary>
        /// This function returns list of custom view entity names
        /// </summary>
        /// <param name="customViews">List of custom views</param>
        /// <param name="alldevices">List of devices</param>
        /// <returns>List of custom view entity names</returns>
        public List<string> GetCustomViewEntityNames(IEnumerable<CustomView> customViews, IEnumerable<Device> alldevices)
        {
            ILookup<string, Device> devicesByCommonName = null;
            ILookup<string, Device> devicesByName = null;

            if (alldevices == null)
                RefreshDevices(ref alldevices, ref devicesByCommonName, ref devicesByName, true);

            var customViewList = customViews as IList<CustomView> ?? customViews.ToList();

            var customDefaultColumns = customViewList.Where(x => x.Columnid == CustomViewColumnType.CustomField && x.EntityId.HasValue);

            var userAttributeColumns = from reportColumn in customDefaultColumns
                                       join prvAttribute in ProviderAttributes on reportColumn.EntityId equals prvAttribute.Id
                                       select prvAttribute.AttributeName;

            //  var deviceCustomView = customViewList.Where(x => x.Columnid == CustomViewColumnType.Device && x.EntityId.HasValue).ToList();

            var deviceColumns = from reportColumn in customViewList
                                where reportColumn.Columnid == CustomViewColumnType.Device && reportColumn.EntityId.HasValue
                                join device in alldevices on reportColumn.EntityId equals device.Id
                                select device.Name;


            var isRoleColumnExists = customViewList.Any(x => x.Columnid.Equals(CustomViewColumnType.Role));


            var reportLayoutColumns = userAttributeColumns.Union(deviceColumns).ToList();

            if (isRoleColumnExists)
                reportLayoutColumns.Add(IWSResources.DisplayName_OperatorRoles);


            return reportLayoutColumns;
        }

        /// <summary>
        /// This function return valid custom view by referrinbg provider attributes/ devices
        /// </summary>
        /// <param name="customViewList">Custom view list</param>
        /// <param name="devices">list of devices</param>
        /// <param name="customFieldCustomViews">List of valid custom views</param>
        /// <param name="deviceCustomViews">List of valid device custom views</param>
        public void GetValidCustomViews(IList<CustomView> customViewList, IList<Device> devices, ref IEnumerable<CustomView> customFieldCustomViews, ref IEnumerable<CustomView> deviceCustomViews)
        {
            //Remove the customviews if they don't exists by referring the provider attributes also remove if they are deleted
            customFieldCustomViews = customViewList.Where(x => x.Columnid.Equals(CustomViewColumnType.CustomField) && x.EntityId.HasValue);
            customFieldCustomViews = from cf in customFieldCustomViews
                                     join ca in ProviderAttributes on cf.EntityId equals ca.Id
                                     where ca.Status != "DEL"
                                     select cf;

            //Remove the customviews if they don't exists by referring the devices also remove if they are deleted
            deviceCustomViews = customViewList.Where(x => x.Columnid.Equals(CustomViewColumnType.Device) && x.EntityId.HasValue);
            deviceCustomViews = from cf in deviceCustomViews
                                join device in devices on cf.EntityId equals device.Id
                                where device.Status != "DEL" && !device.IsMassDevice
                                select cf;

        }

        /// <summary>
        /// This method returns custom view column model for given custom view
        /// </summary>
        /// <param name="provider">Provider</param>
        /// <param name="customView">Custom view instance</param>
        /// <param name="allDevices">List of devices</param>
        /// <returns>Custom View Column</returns>
        public CustomViewColumn CreateCustomViewColumnModel(Provider provider, CustomView customView, IEnumerable<Device> allDevices)
        {
            if (customView.Columnid == CustomViewColumnType.Role)
                return new CustomViewColumn
                {
                    Id = 0,
                    DisplayName = IWSResources.DisplayName_OperatorRoles,
                    Key = CommonNames.OperatorRoles,
                    IsRequired = false,
                    IsSortable = true,
                    CustomViewColumnType = "CF",
                    DataType = null,
                    DataFormat = null,
                    ViewId = customView.ViewId
                };


            if (customView.Columnid == CustomViewColumnType.CustomField && customView.EntityId.HasValue)
            {
                var titleAttribute = ProviderAttributes.GetById((int)customView.EntityId);
                return new CustomViewColumn
                {
                    Id = titleAttribute.Id,
                    DisplayName = titleAttribute.AttributeName,
                    Key = titleAttribute.CommonName,
                    IsRequired = false,
                    IsSortable = titleAttribute.IsSearchable.ConvertTo<bool>(),
                    CustomViewColumnType = "CF",
                    DataType = titleAttribute.AttributeTypeId,
                    DataFormat = titleAttribute.GetDataFormat(provider),
                    ViewId = customView.ViewId
                };
            }

            allDevices = allDevices.Where(d => !d.IsMassDevice);
            if (customView.Columnid == CustomViewColumnType.Device && customView.EntityId.HasValue)
            {
                var device = allDevices.FirstOrDefault(d => d.Id == customView.EntityId);
                if (device != null)
                    return new CustomViewColumn
                    {
                        Id = device.Id,
                        DisplayName = device.Name,
                        Key = device.CommonName,
                        IsRequired = false,
                        IsSortable = true,
                        CustomViewColumnType = "Device",
                        DataType = CustomAttributeDataType.Device,
                        DataFormat = provider.GetDeviceFormat(),
                        ViewId = customView.ViewId
                    };
            }
            return null;
        }


        public ICriteria CreateUserSearchCriterias(int[] userIds, int[] listItemIds, int[] hierarchyIds,
            int[] attributeValueIds, int[] attributeIds, string[] searchStrings, string queryCriteria,
            Provider provider, List<CustomAttribute> selectedAttributes, bool applyUserbase = true,
            int[] includeUserIds = null, int[] excludeUserIds = null, int distributionId = 0, bool? isMember = null, string staticQueryCriteria = null)
        {
            var userSearchCriterias = GroupCriteria.Or();

            if (queryCriteria.IsNotNullOrEmpty())
            {
                var queryCriteriaList = JsonSerializerService.Deserialize<IEnumerable<Criterion>>(queryCriteria);
                userSearchCriterias.Add(AttrCriteria.DynamicList(queryCriteriaList));
            }

            var listItems = listItemIds.HasValue()
                ? _userFacade.GetListItemBySpec(new DistributionListSpec { ProviderId = provider.Id, Ids = listItemIds }).ToArray()
                : Enumerable.Empty<DistributionList>().ToArray();

            var hierarchies = hierarchyIds.HasValue()
                ? _userFacade.GetHierarchyBySpec(new HierarchySpec { ProviderId = provider.Id, Ids = hierarchyIds, BaseLocale = provider.BaseLocale }).ToArray()
                : Enumerable.Empty<Hierarchy>().ToArray();

            if (searchStrings.HasValue())
                userSearchCriterias.Add(searchStrings.Select(x => AttrCriteria.ContainsSimple(x)).ToArray());

            var hierarchyCriteriaIds = new List<int>();
            if (listItems.HasValue())
            {
                foreach (var item in listItems)
                {
                    switch (item.ListType)
                    {
                        case ListItemType.Dynamic:
                            if (item.Definition.IsNotNullOrEmpty())
                                userSearchCriterias.Add(AttrCriteria.DynamicList(ProviderAttributes, item.Definition));
                            break;
                        case ListItemType.Static:
                            userSearchCriterias.Add(AttrCriteria.StaticList(ProviderAttributes, item.Definition));
                            break;
                        case ListItemType.Tree:
                            if (IsFolderDistributionList(item))
                            {
                                if (item != null && item.HierarchyId.HasValue)
                                {
                                    ApplyDistributionListFolderCriteria(item.HierarchyId.Value, item.FullLineage, userSearchCriterias);
                                }
                            }
                            else
                            {
                                hierarchyCriteriaIds.Add(item.Id);
                            }
                            break;
                        case ListItemType.Ip:
                            throw new NotSupportedException("IP list type currently not supported");
                    }
                }
            }

            if (hierarchies.HasValue())
            {
                var distributionListRoot = hierarchies.Where(h => h.AvailableForLists == "Y").FirstOrDefault();
                if (distributionListRoot.HasValue())
                {
                    ApplyDistributionListFolderCriteria(distributionListRoot.Id, String.Empty, userSearchCriterias);
                }

                var roots = hierarchies.Where(h => h.AvailableForLists == "N");
                if (roots.HasValue())
                {
                    userSearchCriterias.Add(AttrCriteria.HierarchyRoot(roots.Select(h => h.Id).Join()));
                }
            }

            if (hierarchyCriteriaIds.HasValue())
                userSearchCriterias.Add(AttrCriteria.Hierarchy(hierarchyCriteriaIds.Join()));

            if (ValidateUserIdsForCriteria(userIds))
                userSearchCriterias.Add(AttrCriteria.ContainsUserIds(userIds));

            if (attributeValueIds.HasValue())
            {
                var customAttributesValues = ProviderAttributes
                    .Where(x => x.Values.HasValue())
                    .SelectMany(x => x.Values);

                foreach (var attributeValueId in attributeValueIds)
                {
                    var attId = customAttributesValues.SingleOrDefault(x => x.ValueId == attributeValueId);
                    if (attId == null) continue;
                    var criteriaString = "ATTRIBUTE-{0}!1!{1}".FormatWith(attId.AttributeId, attributeValueId);
                    userSearchCriterias.Add(AttrCriteria.DynamicList(ProviderAttributes, criteriaString));
                }
            }

            if (attributeIds != null && attributeIds.Any())
            {
                foreach (var attributeId in attributeIds)
                {
                    var attributeStr = "ATTRIBUTE-{0}!12!%".FormatWith(attributeId);
                    userSearchCriterias.Add(AttrCriteria.DynamicList(ProviderAttributes, attributeStr));
                }
            }

            if (staticQueryCriteria.IsNotNullOrEmpty())
            {
                var queryCriteriaList = JsonSerializerService.Deserialize<IEnumerable<Criterion>>(staticQueryCriteria);
                var staticCriteria = GroupCriteria.And();
                staticCriteria.Add(AttrCriteria.DynamicList(queryCriteriaList));
                if (userSearchCriterias.Any())
                    staticCriteria.Add(userSearchCriterias);
                userSearchCriterias = staticCriteria;
            }


            if (!applyUserbase)
                return ApplyIncludeAndExcludeUsers(provider, userSearchCriterias, includeUserIds, excludeUserIds, distributionId, isMember);

            var loggedInUser = _operatorFacade.GetUser(new SystemUserSpec { ProviderId = provider.Id, OperatorId = RuntimeContext.Operator.Id, HasUserBase = true });

            if (loggedInUser.IsUserBaseUnrestricted())
                return ApplyIncludeAndExcludeUsers(provider, userSearchCriterias, includeUserIds, excludeUserIds, distributionId, isMember);

            var userBaseCriteria = AttrCriteria.UserBase(
                ProviderAttributes,
                new OperatorUserBaseSpec
                {
                    OperatorId = RuntimeContext.OperatorId,
                    ProviderId = RuntimeContext.ProviderId
                });

            if (userBaseCriteria == null)
                return ApplyIncludeAndExcludeUsers(provider, userSearchCriterias, includeUserIds, excludeUserIds, distributionId, isMember);

            if (!userBaseCriteria.HasValue())
                return ApplyIncludeAndExcludeUsers(provider, userSearchCriterias, includeUserIds, excludeUserIds, distributionId, isMember);

            if (!userSearchCriterias.HasValue())
                return ApplyIncludeAndExcludeUsers(provider, userBaseCriteria, includeUserIds, excludeUserIds, distributionId, isMember);

            var userSearchCriteriasWithUserbase = GroupCriteria.And(
                    userSearchCriterias,
                    userBaseCriteria
                );

            return ApplyIncludeAndExcludeUsers(provider, userSearchCriteriasWithUserbase, includeUserIds, excludeUserIds, distributionId, isMember);
        }

        private bool IsFolderDistributionList(DistributionList item)
        {
            if (item == null)
                return false;

            var distributionListItem = _userFacade.GetListItemBySpec(new DistributionListSpec { ProviderId = RuntimeContext.ProviderId, Id = item.Id, IncludeHierarchy = true }).FirstOrDefault();

            if (distributionListItem != null && distributionListItem.Hierarchy.HasValue())
            {
                return distributionListItem.Hierarchy.AvailableForLists == "Y";
            }

            return false;
        }

        private void ApplyDistributionListFolderCriteria(int hierarchyId, string fullLineage, ICriteria userSearchCriterias)
        {
            if (fullLineage == null)
                return;

            var childDistributionListItems = _publishingFacade.GetChildrenNodes(new DistributionListSpec
            {
                ProviderId = RuntimeContext.ProviderId,
                IncludeLists = true,
                EqualLineage = fullLineage + "/",
                HierarchyId = hierarchyId,
                IncludeTranslatedDefinition = true,
                IncludeCustomAttribute = true,
                ExcludeDeleted = true

            });

            foreach (var dlItem in childDistributionListItems)
            {

                var distributionList =
                    _publishingFacade.GetDistributionList(new DistributionListSpec
                    {
                        Id = dlItem.Id,
                        ProviderId = RuntimeContext.ProviderId,
                        OperatorId = RuntimeContext.OperatorId
                    });

                if (distributionList == null) continue;

                switch (distributionList.ListType)
                {
                    case ListItemType.Dynamic:
                        if (distributionList.Definition.IsNotNullOrEmpty())
                            userSearchCriterias.Add(AttrCriteria.DynamicList(ProviderAttributes, distributionList.Definition));
                        break;
                    case ListItemType.Static:
                        userSearchCriterias.Add(AttrCriteria.StaticList(ProviderAttributes, distributionList.Definition));
                        break;
                    case ListItemType.Tree:
                        if (distributionList.HierarchyId.HasValue)
                            ApplyDistributionListFolderCriteria(distributionList.HierarchyId.Value, distributionList.FullLineage, userSearchCriterias);
                        break;
                }
            }
        }

        private bool ValidateUserIdsForCriteria(IEnumerable<int> userIds)
        {
            return userIds.HasValue() && !(userIds.Count() == 1 && userIds.First() == 0);
        }

        public ICriteria ApplyIncludeAndExcludeUsers(Provider provider, ICriteria criteriaToApply, int[] includeUserIds = null, int[] excludeUserIds = null, int? distributionId = null, bool? isMember = null)
        {
            var result = GroupCriteria.And();

            if (ValidateUserIdsForCriteria(includeUserIds))
                result.Add(AttrCriteria.ContainsUserIds(includeUserIds));

            if (excludeUserIds.HasValue())
                result.Add(AttrCriteria.NotContainsUserIds(excludeUserIds));

            if (criteriaToApply.HasValue())
                result.Add(criteriaToApply);

            if (distributionId.HasValue && distributionId.Value != 0)
            {
                var distributionList = _publishingFacade.GetDistributionList(new DistributionListSpec { Id = distributionId });
                if (distributionList != null)
                {
                    var criteriaParameterComparison = isMember.GetValueOrDefault() ? CriteriaParameterComparison.Exists : CriteriaParameterComparison.NotExists;
                    result.Add(
                        AttrCriteria.StaticList(
                            RuntimeContext.CustomAttributes, distributionList.Definition, criteriaParameterComparison: criteriaParameterComparison
                            )
                        );
                }
            }

            //IWS-4330:	Members for DL not created 
            if (distributionId.HasValue && isMember.HasValue && distributionId.Value == 0 && isMember.Value)
            {
                result.Add(AttrCriteria.ContainsUserIds(new[] { -1 }));
            }

            return result;
        }

        public ICriteria GetSelectedUserCriteria(UsersStatusCriteria criteria)
        {
            if (criteria == null) return null;

            if (criteria.CriteriaType == (int)ListCriteriaType.USER_LIST)
                criteria.SearchCriteria.includeUserIds = criteria.EntityIds.ToArray();

            if (criteria.CriteriaType == (int)ListCriteriaType.EXCEPTION_LIST)
                criteria.SearchCriteria.excludeUserIds = criteria.EntityIds.ToArray();

            var criterias = CreateUserSearchCriterias(
                criteria.SearchCriteria.userIds,
                criteria.SearchCriteria.listItemIds,
                criteria.SearchCriteria.hierarchyIds,
                criteria.SearchCriteria.attributeValueIds,
                criteria.SearchCriteria.attributeIds,
                criteria.SearchCriteria.searchStrings,
                criteria.SearchCriteria.queryCriteria,
                RuntimeContext.Provider,
                Enumerable.Empty<CustomAttribute>().ToList(),
                true,
                criteria.SearchCriteria.includeUserIds,
                criteria.SearchCriteria.excludeUserIds
            );

            return criterias;
        }

        public void RefreshDevices(ref IEnumerable<Device> allDevices, ref ILookup<string, Device> devicesByCommonName, ref ILookup<string, Device> devicesByName, bool forceRefresh = false, int pid = -1)
        {
            var providerId = RuntimeContext.Provider.Id;
            if (pid != -1)
                providerId = pid;

            var refresh = (allDevices == null || !allDevices.Any());
            if (!refresh && !forceRefresh) return;
            var providerDevices =
                _deviceFacade.GetDevicesBySpec(new DeviceSpec
                {
                    ProviderId = providerId,
                    IncludeDeviceProvider = true,
                    IncludeDeviceGroup = true,
                    EnabledOnly = true
                }, RuntimeContext.Provider.BaseLocale);
            allDevices = providerDevices;
            devicesByCommonName = providerDevices.ToLookup(x => x.CommonName, StringComparer.OrdinalIgnoreCase);
            devicesByName = providerDevices.ToLookup(x => x.Name, StringComparer.OrdinalIgnoreCase);
        }

        public void RefreshCarrier(ref List<PagerCarrierEntity> pagerCarriers, bool forceRefresh = false)
        {
            var refresh = (pagerCarriers == null);
            if (refresh || forceRefresh)
                pagerCarriers = _pagerCarrierFacade.GetAllPagerCarrierEntities().ToList();
        }

        public void RefreshOperatorRoles(ref IEnumerable<OperatorRole> operatorRoles, int pid, bool forceRefresh = false)
        {
            var provider = RuntimeContext.Provider;
            operatorRoles = _operatorDetailsFacade.GetOperatorRoles(new OperatorRoleSpec { ProviderId = pid, BaseLocale = provider.BaseLocale });
        }

        public void RefreshAllRoles(ref IEnumerable<OperatorRole> operatorRoles, bool forceRefresh = false)
        {
            operatorRoles = _operatorFacade.GetAllRoles();
        }

        public void RefreshOperatorAccessibleChannels(ref IEnumerable<AlertChannel> operatorAccessibleChannels, bool forceRefresh = false, int pid = -1)
        {
            var providerId = RuntimeContext.Provider.Id;
            if (pid != -1)
                providerId = pid;

            var currentUser = RuntimeContext.Operator;
            var refresh = !operatorAccessibleChannels.HasValue();
            if (!refresh && !forceRefresh) return;
            var accessibleChannels =
                _operatorDetailsFacade.GetOperatorAccessibleChannels(
                    new OperatorAccessibleChannelsSpec
                    {
                        OperatorId = currentUser.Id,
                        ProviderId = providerId
                    },
                    RuntimeContext.Provider.BaseLocale
                );

            operatorAccessibleChannels = accessibleChannels.GroupBy(a => a.Id).Select(grp => grp.First());
        }

        public void RefreshChannels(ref IEnumerable<AlertChannel> VPSChannels, bool forceRefresh = false, int pid = -1)
        {
            var providerId = RuntimeContext.Provider.Id;
            if (pid != -1)
                providerId = pid;

            var refresh = !VPSChannels.HasValue();

            if (!refresh && !forceRefresh) return;
            var channels = _operatorDetailsFacade.GetOperatorAccessibleChannels(
                    new OperatorAccessibleChannelsSpec { ProviderId = providerId }, RuntimeContext.Provider.BaseLocale
                );

            VPSChannels = channels.GroupBy(a => a.Id).Select(grp => grp.First());
        }

        public void RefreshOperatorAccessibleDistributionLists(ref IEnumerable<DistributionList> operatorAccessibleDistributionLists, bool forceRefresh = false, int pid = -1)
        {
            var providerId = RuntimeContext.Provider.Id;
            if (pid != -1)
                providerId = pid;

            var refresh = !operatorAccessibleDistributionLists.HasValue();
            if (!refresh && !forceRefresh) return;
            operatorAccessibleDistributionLists = _operatorDetailsFacade.GetOperatorDistributionLists(
                new DistributionListSpec
                {
                    ProviderId = providerId,
                    ExcludeDeleted = true,
                    DistributionListTypes = new[] { ListItemType.Static, ListItemType.Dynamic, ListItemType.Ip }
                }
            ).Where(dl => dl.IsSystem == "N");
        }

        public IEnumerable<int> GetSelectedUserIds(UsersStatusCriteria model, ILookup<string, Device> devicesByName)
        {
            if (model == null) return Enumerable.Empty<int>();
            if (model.CriteriaType == (int)ListCriteriaType.USER_LIST)
            {
                if (model.SearchCriteria == null)
                    model.SearchCriteria = new SearchCriteria();
                model.SearchCriteria.userIds = model.EntityIds.ToArray();
                var allUserIds = _userFacade.SearchUsersByContext(ConvertToSearchArgs(model)).Users.Select(x => x.Id);
                return allUserIds;

            }


            if (model.CriteriaType == (int)ListCriteriaType.EXCEPTION_LIST)
            {
                var allUserIds = _userFacade.SearchUsersByContext(ConvertToSearchArgs(model)).Users.Select(x => x.Id);
                return allUserIds.Except(model.EntityIds);
            }

            if (model.CriteriaType == (int)ListCriteriaType.ALL_USERS)
            {
                var allUserIds = _userFacade.SearchUsersByContext(ConvertToSearchArgs(model)).Users.Select(x => x.Id);
                return allUserIds;
            }

            return Enumerable.Empty<int>();
        }

        public List<UserSearchResultItem> GetSelectedUsernames(UsersStatusCriteria model, ILookup<string, Device> devicesByName)
        {
            if (model == null) return new List<UserSearchResultItem>();
           
         
            // USER LIST
            if (model.CriteriaType == (int)ListCriteriaType.USER_LIST)
            {
                if (model.SearchCriteria == null)
                    model.SearchCriteria = new SearchCriteria();
                model.SearchCriteria.userIds = model.EntityIds.ToArray();
                var searchArgs = ConvertToSearchArgs(model);
                searchArgs.AttributeNames.AddRange(new List<string>
                {
                    AttributeCommonNames.UserName,
                    AttributeCommonNames.PreventUserMove
                });
                var users = _userFacade.SearchUsersByContext(searchArgs).Users;
                return users;
            }
            // EXCEPTION LIST
            if (model.CriteriaType == (int)ListCriteriaType.EXCEPTION_LIST)
            {
                  var searchArgs = ConvertToSearchArgs(model);
                searchArgs.AttributeNames.AddRange(new List<string>
                {
                    AttributeCommonNames.UserName,
                    AttributeCommonNames.PreventUserMove
                });
                var users = _userFacade.SearchUsersByContext(searchArgs).Users.Where(x => !model.EntityIds.Contains(x.Id)).ToList();
                return users;
            }
            //ALL USERS
            if (model.CriteriaType == (int)ListCriteriaType.ALL_USERS)
            {  var searchArgs = ConvertToSearchArgs(model);
                searchArgs.AttributeNames.AddRange(new List<string>
                {
                    AttributeCommonNames.UserName,
                    AttributeCommonNames.PreventUserMove
                });
                var users = _userFacade.SearchUsersByContext(searchArgs).Users;
                return users;
            }

            return new List<UserSearchResultItem>();
        }


        public UserSearchArgs ConvertToSearchArgs(UsersStatusCriteria model, bool includeCurrentProviderExclusively = false)
        {
            //safe checks just in case
            if (model.SearchCriteria.userIds == null) model.SearchCriteria.userIds = Enumerable.Empty<int>().ToArray();
            if (model.SearchCriteria.attributeIds == null) model.SearchCriteria.attributeIds = Enumerable.Empty<int>().ToArray();
            if (model.SearchCriteria.attributeValueIds == null) model.SearchCriteria.attributeValueIds = Enumerable.Empty<int>().ToArray();
            if (model.SearchCriteria.includeUserIds == null) model.SearchCriteria.includeUserIds = Enumerable.Empty<int>().ToArray();
            if (model.SearchCriteria.hierarchyIds == null) model.SearchCriteria.hierarchyIds = Enumerable.Empty<int>().ToArray();
            if (model.SearchCriteria.listItemIds == null) model.SearchCriteria.hierarchyIds = Enumerable.Empty<int>().ToArray();
            if (model.SearchCriteria.excludeUserIds == null) model.SearchCriteria.excludeUserIds = Enumerable.Empty<int>().ToArray();
            if (model.SearchCriteria.searchStrings == null) model.SearchCriteria.searchStrings = Enumerable.Empty<string>().ToArray();


            ExpressionElement advancedCriteria = null;
            ExpressionElement groupCriteria = null;

            //To Process the status criteria, we will need status attribute Id from provider and Ids for each status values like 'DSB', 'VLD' etc
            // When passed to UserSearch the user status needs to be passed as 'ATTRIBUTE-<Id of status attribute>|Operator|list of value ids for statuses'
            var statusAttribute = ProviderAttributes.GetByCommonName(AttributeCommonNames.Status);
            var customAttributeValueCache = new CustomAttributeValueCache();
            var customAttributeValueDictionary = customAttributeValueCache.Get(RuntimeContext.ProviderId, RuntimeContext.Provider.BaseLocale);
            var statusValues = model.SearchCriteria.isEnabled ? "'VLD'" : "'VLD','DSB'";
            var statusIds = customAttributeValueDictionary.GetByCommonNames(statusValues.Replace("'", "")).Select(x => x.ValueId);

            //This block takes care of group criteria. When you select multi picklist attributes or checkbox attributes from groups search panel, if the root
            // attribute is selected, we get the attributeIds for those, if the value itself were selected then we get attributeValueIds. We need to
            // parse both of them and OR between them 

            foreach (var attributeId in model.SearchCriteria.attributeIds)
            {
                if (groupCriteria == null) groupCriteria = new AttributeCriteria(attributeId, CriteriaOperator.IsNotEmpty, 0);
                else groupCriteria = groupCriteria | new AttributeCriteria(attributeId, CriteriaOperator.IsNotEmpty, 0);
            }
            var attributesDictionary = GetAttributeIdsByValueIds(model.SearchCriteria.attributeValueIds ?? new int[] { });
            foreach (var attributeId in attributesDictionary.Keys)
            {
                if (groupCriteria == null) groupCriteria = new AttributeCriteria(attributeId, CriteriaOperator.Equals, attributesDictionary[attributeId].Join(","));
                else groupCriteria = groupCriteria | new AttributeCriteria(attributeId, CriteriaOperator.Equals, attributesDictionary[attributeId].Join(","));
            }

            //Process all values that possibly come from advanced search. In model, it is passed as queryCriteria which needs to be deserialized.
            var qryCriterion = JsonSerializerService.Deserialize<IEnumerable<Criterion>>(model.SearchCriteria.queryCriteria);

            if (qryCriterion != null)
            {
                foreach (var qryCriteria in qryCriterion)
                {
                    var criteria = new GenericCriteria(qryCriteria.entity.entityType, qryCriteria.entity.id,
                        qryCriteria.operand);

                    switch (qryCriteria.AttributeType)
                    {
                        case CustomAttributeDataType.Picklist:
                        case CustomAttributeDataType.MultiPicklist:
                        case CustomAttributeDataType.Checkbox:
                            criteria.Value = (qryCriteria.operand == 11 || qryCriteria.operand == 12)
                                ? "0"
                                : ((int[])qryCriteria.Value).Join(",");
                            break;
                        case CustomAttributeDataType.Number:
                        case CustomAttributeDataType.String:
                        case CustomAttributeDataType.Memo:
                        case CustomAttributeDataType.Date:
                        case CustomAttributeDataType.DateTime:
                        case CustomAttributeDataType.Path:
                            criteria.Value = ((string[])qryCriteria.Value).Join(",");
                            break;
                        case CustomAttributeDataType.GeoLocation:
                            var fc = new FeatureCollection(qryCriteria.value[0].text);
                            if (fc.Features != null && fc.Features.Count > 0)
                            {
                                var polyGons = (from f in fc.Features
                                                where
                                                    f.Geometry.Type == Map.Geometry.Type.Polygon ||
                                                    f.Geometry.Type == Map.Geometry.Type.MultiPolygon
                                                select f.Attributes["OBJECTID"].ToString()).ToList();
                                var finalString = string.Join("|", polyGons);
                                criteria = new AttributeCriteria(qryCriteria.entity.id, qryCriteria.operand, finalString);
                            }
                            break;
                        case CustomAttributeDataType.AttributeValue:
                        case CustomAttributeDataType.Device:
                        case CustomAttributeDataType.Entity:
                        case CustomAttributeDataType.Object:
                        case CustomAttributeDataType.Unknown:
                        default:
                            throw new Exception("Not Implemented");
                    }

                    if (advancedCriteria == null)
                    {
                        advancedCriteria = criteria;
                    }
                    else
                    {
                        advancedCriteria = advancedCriteria & criteria;
                    }
                }
            }

            if (includeCurrentProviderExclusively)
            {
                //var vpsCriteria = new GenericCriteria();
                var vpssCriteria = new VPSCriteria(0, CriteriaOperator.Equals, RuntimeContext.Provider.Id);

                if (advancedCriteria == null)
                    advancedCriteria = vpssCriteria;
                else
                    advancedCriteria = advancedCriteria & vpssCriteria;
            }

            //each of the other criterias passed in UserStatusSearchCriteria needs to be converted to ExpressionGroup so we could AND or OR them
            var quickSearchCriteria = UserSearchHelper.GetQuickSearchCriteria(RuntimeContext.ProviderId, RuntimeContext.Provider.BaseLocale, model.SearchCriteria.searchStrings);
            var listCriteria = UserSearchHelper.GetListCriteria(RuntimeContext.ProviderId, model.SearchCriteria.listItemIds, RuntimeContext.ProviderId, RuntimeContext.OperatorId);
            var hierarchyCriteria = UserSearchHelper.GetHierarchyCriteria(RuntimeContext.ProviderId, RuntimeContext.Provider.BaseLocale, model.SearchCriteria.hierarchyIds, RuntimeContext.ProviderId, RuntimeContext.OperatorId);
            var individualUserCriteria = UserSearchHelper.GetIndividualUserIdCriteria(model.SearchCriteria.userIds.ToList());
            var statusCriteria = UserSearchHelper.GetUserStatusCriteria(statusAttribute.Id, statusIds);
            var includeOperatorsCriteria = UserSearchHelper.GetUserOperatorCriteria(model.SearchCriteria.isOperator);


            var targetingCriteria = (listCriteria | hierarchyCriteria | groupCriteria) & statusCriteria & individualUserCriteria & quickSearchCriteria & advancedCriteria & includeOperatorsCriteria;

            //preprare the search model with all options and criteria and return it
            var srchArgs = new UserSearchArgs(false, true, false, 1, Int32.MaxValue, AttributeCommonNames.UserId, "ASC")
            {
                AttributeNames = new List<string> { AttributeCommonNames.UserId, AttributeCommonNames.FirstName },


                DeviceNames = Enumerable.Empty<string>().ToList(),
                ProviderId = RuntimeContext.ProviderId,
                ProviderCriteria = UserSearchHelper.GetProviderCriteria(RuntimeContext.ProviderId),
                OperatorCriteria = UserSearchHelper.GetOperatorUserBaseCriteria(RuntimeContext.OperatorId, RuntimeContext.ProviderId),
                TargetUsers = model.SearchCriteria.includeUserIds.ToList(),
                BlockUsers = model.SearchCriteria.excludeUserIds.ToList(),
                BlockCriteria = null,
                TargetCriteria = targetingCriteria,

            };



            return srchArgs;
        }

        public IEnumerable<UserItem> ConvertToUIModel(IEnumerable<UserItem> userItems)
        {
            var uiUserItems = new List<UserItem>();
            foreach (var item in userItems)
            {
                var updatedAttribute = new UserAttributes();
                foreach (var attribute in item.UserAttributes)
                {
                    var value = attribute.Value;
                    var providerAttr = ProviderAttributes.FirstOrDefault(a => a.CommonName == attribute.Key);
                    if (providerAttr != null)
                    {
                        if (providerAttr.AttributeTypeId.HasValue &&
                            (providerAttr.AttributeTypeId.Value == CustomAttributeDataType.Date ||
                             providerAttr.AttributeTypeId.Value == CustomAttributeDataType.DateTime))
                        {
                            DateTime date;
                            if ((attribute.Value != null) && DateTime.TryParse(attribute.Value.ToString(), out date))
                            {
                                date = Convert.ToDateTime(attribute.Value);
                                date = RuntimeContext.Provider.SystemToVpsTime(date.ToString(CultureInfo.InvariantCulture).ConvertTo<DateTime>());
                                value = date.ToString(CultureInfo.InvariantCulture);
                            }
                        }
                        else if (providerAttr.AttributeTypeId == CustomAttributeDataType.Path
                            && (providerAttr.IsMandatory == "Y") && (value != null)
                            && string.IsNullOrWhiteSpace(value.ToString()))
                        {
                            value = "/";
                        }

                        var valueNotExists = !(attribute.Value as string).HasValue();
                        if (attribute.Key == AttributeCommonNames.DisplayName && valueNotExists)
                            value = IWSResources.UserManager_UserList_EmptyDisplayNameSubstitute;

                        if (attribute.Key == AttributeCommonNames.CurrentlyOnline && valueNotExists)
                            value = IWSResources.User_Criteria_Builder_No;


                    }

                    updatedAttribute.Set(attribute.Key, value.ToString());
                }

                var updateDevices = new UserDevice();
                foreach (var device in item.UserDevice)
                    updateDevices.Set(device.Key, GetDeviceDisplayValue(device));

                uiUserItems.Add(new UserItem
                {
                    Id = item.Id,
                    FirstName = item.FirstName,
                    LastName = item.LastName,
                    DisplayName = item.DisplayName,
                    RuntimeStatus = item.RuntimeStatus,
                    UserDevice = updateDevices,
                    UserName = item.UserName,
                    UserAttributes = updatedAttribute,
                });
            }

            return uiUserItems;
        }

        public IEnumerable<UserSearchResultItem> ConvertToUIModel(IEnumerable<UserSearchResultItem> userItems)
        {
            GlobalEntityLocaleFacade globalEntityLocaleFacade = new GlobalEntityLocaleFacade(new GlobalEntityLocaleRepository());

            var uiUserItems = new List<UserSearchResultItem>();
            foreach (var item in userItems)
            {
                var updatedAttribute = new Dictionary<string, string>();
                foreach (var attribute in item.UserAttributes)
                {
                    var value = attribute.Value;
                    var providerAttr = ProviderAttributes.FirstOrDefault(a => a.CommonName == attribute.Key);
                    if (providerAttr != null)
                    {
                        if (providerAttr.AttributeTypeId.HasValue &&
                            (providerAttr.AttributeTypeId.Value == CustomAttributeDataType.Date ||
                             providerAttr.AttributeTypeId.Value == CustomAttributeDataType.DateTime))
                        {
                            DateTime date;
                            if ((attribute.Value != null) && DateTime.TryParse(attribute.Value, out date))
                            {
                                date = Convert.ToDateTime(attribute.Value);
                                if (providerAttr.AttributeTypeId.Value == CustomAttributeDataType.Date)
                                    value = RuntimeContext.Provider.SystemToVpsDateFormated(date);
                                else if (providerAttr.AttributeTypeId.Value == CustomAttributeDataType.DateTime)
                                    value = RuntimeContext.Provider.SystemToVpsDateTimeFormated(date);

                            }
                        }
                        //already taken care at DB
                        //else if (providerAttr.AttributeTypeId == CustomAttributeDataType.Path
                        //    && (providerAttr.IsMandatory == "Y") && (value != null)
                        //    && string.IsNullOrWhiteSpace(value.ToString()))
                        //{
                        //    value = "/";
                        //}

                        var valueNotExists = !attribute.Value.HasValue();
                        if (attribute.Key == AttributeCommonNames.DisplayName && valueNotExists)
                            value = IWSResources.UserManager_UserList_EmptyDisplayNameSubstitute;

                        if (attribute.Key == AttributeCommonNames.CurrentlyOnline && valueNotExists)
                            value = IWSResources.User_Criteria_Builder_No;

                        if (providerAttr.AttributeTypeId == CustomAttributeDataType.Checkbox)
                        {
                            if (!string.IsNullOrEmpty(value))
                            {
                                value = globalEntityLocaleFacade.GetLocalizedValue(value, BusinessEntity.CheckBox, "Name",
                                    RuntimeContext.Provider.BaseLocale);
                            }
                        }

                    }


                    if (attribute.Key == AttributeCommonNames.OperatorRoles && string.IsNullOrEmpty(value))
                        value = IWSResources.UserManager_UserList_Roles_None;

                    if (attribute.Key == AttributeCommonNames.RoleCountOtherOrgs)
                    {
                        if (!string.IsNullOrEmpty(value))
                        {
                            int roleCount;
                            if (Int32.TryParse(value, out roleCount))
                            {
                                value = roleCount > 0
                                    ? String.Format(IWSResources.UserManager_UserList_RolesInOtherOrganization, value)
                                    : " ";
                            }
                            else
                            {
                                value = "";
                            }
                        }
                        else
                        {
                            value = "";
                        }

                    }


                    updatedAttribute.Set(attribute.Key, value);
                }

                var updatedDeviceAttribute = new Dictionary<string, string>();
                var deviceAttrbuteValue = string.Empty;
                foreach (var deviceAttribute in item.UserDevice)
                {
                    if (!string.IsNullOrEmpty(deviceAttribute.Value))
                    {
                        deviceAttrbuteValue = deviceAttribute.Value;
                        deviceAttrbuteValue = deviceAttrbuteValue.Replace(ACTIVE_LABEL, IWSResources.Device_Active);
                        deviceAttrbuteValue = deviceAttrbuteValue.Replace(IN_ACTIVE_LABEL, IWSResources.Device_Inactive);
                        deviceAttrbuteValue = deviceAttrbuteValue.Replace(NOT_AVAILABLE_LABEL, IWSResources.Device_Not_Available);
                        deviceAttrbuteValue = deviceAttrbuteValue.Replace(AVAILABLE_LABEL, IWSResources.Device_Available);

                        updatedDeviceAttribute.Set(deviceAttribute.Key, deviceAttrbuteValue);
                    }
                }


                //already taken care at DB
                //var updateDevices = new UserDevice();
                //foreach (var device in item.UserDevice)
                //    updateDevic es.Set(device.Key, GetDeviceDisplayValue(device));

                uiUserItems.Add(new UserSearchResultItem
                {
                    Id = item.Id,
                    FirstName = item.FirstName,
                    LastName = item.LastName,
                    DisplayName = item.DisplayName,
                    UserDevice = updatedDeviceAttribute,
                    UserName = item.UserName,
                    UserAttributes = updatedAttribute
                });
            }

            return uiUserItems;
        }

        public static string GetDeviceDisplayValue(KeyValuePair<string, object> deviceValue)
        {
            if (deviceValue.Key.ToLower() == CommonNames.DesktopDevice.ToLower() ||
                deviceValue.Key.ToLower() == CommonNames.MobileNotifierDevice.ToLower())
            {
                {
                    return string.IsNullOrEmpty(deviceValue.Value.ToString())
                        ? IWSResources.Profile_Device_Display
                        : deviceValue.Value.ToString();
                }
            }
            return deviceValue.Value == null ? string.Empty : deviceValue.Value.ToString();
        }

        public SectionAttribute BuildDisplayDesktopAttribute(NotificationInfo notificationInfo)
        {
            var desktopApp = notificationInfo.DesktopAddress == "Not Available" ? IWSResources.Profile_Device_Display : notificationInfo.DesktopAddress;
            var desktopName = notificationInfo.DesktopName;
            if (!desktopName.IsNotNullOrEmpty()) return null;
            var sectionAttribute = new SectionAttribute("IsDesktop", String.Empty, true)
            {
                AttributeId = 11,
                Name = desktopName,
                Value = desktopApp,
                DisplayValue = desktopApp,
                CssClass = "row",
                AttributeType = CustomAttributeDataType.String,
                MetaData = String.Empty,
                AttributeMeta = new CustomAttribute
                {
                    AttributeName = desktopName,
                    CommonName = "IsDesktopApp",
                    EditLevel = 0,
                    AttributeTypeId = CustomAttributeDataType.String
                },
                UpdatedTimeStamp = DateTime.MinValue,
            };
            return sectionAttribute;
        }

        public bool HasAnyDistributionListInFolder(int distribtuionId)
        {
            var providerId = RuntimeContext.ProviderId;
            var operatorId = RuntimeContext.OperatorId;

            var distributionList = _publishingFacade.GetDistributionList(new DistributionListSpec
            {
                ProviderId = providerId,
                OperatorId = operatorId,
                IncludeLists = true,
                IncludeTranslatedDefinition = true,
                IncludeCustomAttribute = true,
                ExcludeDeleted = true,
                IncludeHierarchy = true,
                Id = distribtuionId
            });

            return distributionList != null && HasAnyDistributionListInFolder(distributionList);
        }

        public bool HasAnyDistributionListInFolder(DistributionList distributionList)
        {
            var result = false;

            var providerId = RuntimeContext.ProviderId;
            var operatorId = RuntimeContext.OperatorId;

            if (distributionList.Hierarchy != null && distributionList.Hierarchy.AvailableForLists != "Y")
                return true;

            var childDistributionListItems = _publishingFacade.GetChildrenNodes(new DistributionListSpec
            {
                ProviderId = providerId,
                OperatorId = operatorId,
                IncludeLists = true,
                EqualLineage = distributionList.FullLineage + "/",
                HierarchyId = distributionList.HierarchyId,
                IncludeTranslatedDefinition = true,
                IncludeCustomAttribute = true,
                IncludeHierarchy = true,
                ExcludeDeleted = true

            });

            if (childDistributionListItems.HasValue())
            {
                result = childDistributionListItems.Any(d => d.ListType == ListItemType.Dynamic || d.ListType == ListItemType.Static);
                if (result)
                    return true;

                var subFolders = childDistributionListItems.Where(d => d.ListType == ListItemType.Tree);

                if (subFolders.HasValue())
                {
                    foreach (var subFolder in subFolders)
                    {
                        result = HasAnyDistributionListInFolder(subFolder);

                        if (result)
                            return true;
                    }
                }
            }

            return false;
        }

        private UserSearchSpec CreateNewSpecStub()
        {
            return new UserSearchSpec
            {
                ProviderId = RuntimeContext.ProviderId,
            };
        }

        public Messages Verify_UserName_MappingId_Uniqueness(EndUserForSave updatedUser)
        {
            var messages = new Messages();
            var userNameAttribute = updatedUser.CustomAttributes.FirstOrDefault(c => c.CommonName == AttributeCommonNames.UserName);
            var mappingIdAttribute = updatedUser.CustomAttributes.FirstOrDefault(c => c.CommonName == AttributeCommonNames.MappingId);
            string usernameToTest = "";
            string mappingIdToTest = "";
            if (userNameAttribute != null && userNameAttribute.Value.IsNotNullOrEmpty()) usernameToTest = userNameAttribute.Value.Trim();
            if (mappingIdAttribute != null && mappingIdAttribute.Value.IsNotNullOrEmpty()) mappingIdToTest = mappingIdAttribute.Value.Trim();
            bool checkOperator = false;
            var userIdToPassForValidation = updatedUser.UserId > 0 ? updatedUser.UserId : 0;
            if (updatedUser.UserId > 0)
            {
                var operatorUser = _operatorDetailsFacade.GetOperatorUserBySpec(new OperatorUserSpec
                {
                    OperatorId = updatedUser.UserId
                });
                //if a user is already an operator, we need to make sure that operator name doesn't collide
                if (operatorUser != null) checkOperator = true;
            }

            var returnCodes = _userFacade.ValidateUsernameAndMappingId(usernameToTest, mappingIdToTest, updatedUser.ProviderId, userIdToPassForValidation, checkOperator).ToList();
            return TranslateUsernameReturnCodesToMessages(returnCodes, messages);
        }

        public Messages TranslateUsernameReturnCodesToMessages(IEnumerable<LoginIdUniquenessStatus> returnCodes, Messages messages)
        {
            if (!returnCodes.Any())
                return messages;

            if (returnCodes.Contains(LoginIdUniquenessStatus.UserUsernameIsDuplicate))
                messages.CreateErrorMessage(IWSResources.Username_IsDuplicate);
            if (returnCodes.Contains(LoginIdUniquenessStatus.OperatorUsernameIsDuplicate))
                messages.CreateErrorMessage(IWSResources.OperatorUsername_IsDuplicate);
            if (returnCodes.Contains(LoginIdUniquenessStatus.UserMappingIdIsDuplicate))
                messages.CreateErrorMessage(IWSResources.UserMappingId_IsDuplicate);
            if (returnCodes.Contains(LoginIdUniquenessStatus.OperatorMappingIdIsDuplicate))
                messages.CreateErrorMessage(IWSResources.OperatorMappingId_IsDuplicate);
            return messages;



        }


        public UserCounts GetHomePageUserCounts(int providerId, int operatorId)
        {
            var userCounts = _userFacade.GetUserCounts(providerId, operatorId);
            return userCounts;
        }

        public SectionAttribute BuildDisplayMobileAttribute(NotificationInfo notificationInfo)
        {
            var activeDecviceText = notificationInfo.MobileNotificationAddress == "Not Available" ? IWSResources.Profile_Device_Display : notificationInfo.MobileNotificationAddress;
            var mobileNotificationName = notificationInfo.MobileNotificationName;

            if (!mobileNotificationName.IsNotNullOrEmpty()) return null;
            var sectionAttribute = new SectionAttribute("AtHocMobileApp", String.Empty, true)
            {
                AttributeId = 12,
                Name = mobileNotificationName,
                Value = activeDecviceText,
                DisplayValue = activeDecviceText,
                CssClass = "row",
                AttributeType = CustomAttributeDataType.String,
                MetaData = String.Empty,
                AttributeMeta = new CustomAttribute
                {
                    AttributeName = mobileNotificationName,
                    CommonName = "AtHocMobileApp",
                    EditLevel = 0,
                    AttributeTypeId = CustomAttributeDataType.String
                },
                UpdatedTimeStamp = DateTime.MinValue,
            };
            return sectionAttribute;
        }

        public int GetUserBaseCount(int providerId, int operatorId, bool hideMassDevices = true, bool onlyEnabled = false)
        {
            var statusStringList = new List<string> { "VLD" };
            if (!onlyEnabled) statusStringList.Add("DSB");

            var userOperatorCriteria = UserSearchHelper.GetUserOperatorCriteria(false);

            var statusAttributeId = _userFacade.GetStatusAttributeId();
            var statusValueIds = _userFacade.GetStatusValueIds(statusStringList.ToArray());
            var statusCriteria = UserSearchHelper.GetUserStatusCriteria(statusAttributeId, statusValueIds);

            var srchArgs = new UserSearchArgs(true, true, !hideMassDevices)
            {
                ProviderId = providerId,
                ProviderCriteria = UserSearchHelper.GetProviderCriteria(providerId),
                OperatorCriteria =
                    UserSearchHelper.GetOperatorUserBaseCriteria(RuntimeContext.OperatorId, RuntimeContext.ProviderId),
                TargetCriteria = userOperatorCriteria & statusCriteria
            };

            return _userFacade.SearchUsersByContext(srchArgs).SearchResultCount;
        }

        public List<string> InitializeAttributesToRetrieve(IEnumerable<CustomAttribute> defaultAttributes, IEnumerable<CustomView> customViews)
        {
            IEnumerable<CustomView> customViewColumns = customViews as CustomView[] ?? customViews.ToArray();

            var customAttributeColumns = customViewColumns.Where(x => x.Columnid == CustomViewColumnType.CustomField && x.EntityId.HasValue);
            var customAttributesFromCustomViews = from ca in ProviderAttributes
                                                  join cv in customAttributeColumns on ca.Id equals cv.EntityId
                                                  select ca;

            var attributenames = defaultAttributes.Union(customAttributesFromCustomViews).Select(customAttribute => customAttribute.CommonName).ToList();


            var operatorRolesColumn = customViewColumns.SingleOrDefault(x => x.Columnid == CustomViewColumnType.Role);



            if (operatorRolesColumn != null)
            {
                attributenames.Add(CommonNames.OperatorRoles);
                attributenames.Add(AttributeCommonNames.RoleCountOtherOrgs);
            }



            return attributenames;
        }

        public List<string> InitializeDevicesToRetrieve(IEnumerable<CustomView> customViews, IEnumerable<Device> allDevices)
        {
            var deviceCommonNames = new List<string>();

            var deviceCustomViews = customViews.Where(x => x.Columnid == CustomViewColumnType.Device && x.EntityId.HasValue);

            var devices = from deviceCustomView in deviceCustomViews
                          join device in allDevices on deviceCustomView.EntityId equals device.Id
                          where !device.IsMassDevice
                          select device;

            if (devices.Any())
            {
                deviceCommonNames = devices.Select(x => x.CommonName).ToList();
            }

            return deviceCommonNames;
        }

        public IDictionary<int, List<int>> GetAttributeIdsByValueIds(IEnumerable<int> valueIds)
        {
            var attributesDictionary = new Dictionary<int, List<int>>();

            foreach (var attr in ProviderAttributes)
            {
                if (attr.AttributeTypeId == CustomAttributeDataType.Picklist ||
                    attr.AttributeTypeId == CustomAttributeDataType.MultiPicklist ||
                    attr.AttributeTypeId == CustomAttributeDataType.Checkbox)
                {
                    foreach (var value in attr.Values.Where(value => valueIds.Contains((value.ValueId))))
                    {
                        if (attributesDictionary.ContainsKey(attr.Id))
                            attributesDictionary[attr.Id].Add(value.ValueId);
                        else
                            attributesDictionary.Add(attr.Id, new List<int> { value.ValueId });
                    }
                }
            }
            return attributesDictionary;
        }

        public IEnumerable<OperatorUserRole> GetOperatorRolesInSystem(int userId)
        {
            var operatorRolesInSystem = _operatorFacade.GetRoles(new OperatorUserRoleSpec { UserId = userId });
            return operatorRolesInSystem;
        }

        public string GetOperatorRolesFormattedText(int userId)
        {
            var operatorRolesInSystem = GetOperatorRolesInSystem(userId);
            var orgCount = operatorRolesInSystem.Where(entry => int.Parse(entry.ProviderFilter) != RuntimeContext.ProviderId).Select(x => int.Parse(x.ProviderFilter)).Distinct().Count();
            return (orgCount > 0) ? IWSResources.OperatorPermissions_AccessToOtherOrgs.FormatWith(orgCount) : string.Empty;
        }

        private CustomAttributeLookup _providerAttributes = null;

        private CustomAttributeLookup ProviderAttributes
        {
            get
            {
                var customAttributes = _customAttributeCache.Get(RuntimeContext.Provider.Id, RuntimeContext.Provider.BaseLocale, false);
                return new CustomAttributeLookup(customAttributes);
            }
        }

        public UserSearchArgs GetAdvancedCriteria(UserSearchArgs srchArgs, string queryCriteria, string staticQueryCriteria, int[] attributeValueIds, int[] attributeIds, int[] listItemIds)
        {

            //queryCriteria =
            //  "[{\"entity\":{\"name\":\"Display Name\",\"dataType\":\"String\",\"dataTypeId\":2,\"commonName\":\"DISPLAYNAME\",\"entityType\":\"ATTRIBUTE\",\"id\":130,\"hierarchyId\":0},\"operand\":1,\"operandName\":\"equals\",\"value\":[{\"id\":-1,\"text\":\"gogula\",\"entityType\":\"ATTRIBUTE\"}]}]";
            //listItemIds = new int[] { 1717 };
            //Sample Data
            var customCriteriaList = new List<List<GenericCriteria>>();
            if (!string.IsNullOrEmpty(queryCriteria))
            {
                customCriteriaList.Add(InitializeAdvancedSearch(queryCriteria));
            }
            if (!string.IsNullOrEmpty(staticQueryCriteria))
            {
                customCriteriaList.Add(InitializeAdvancedSearch(staticQueryCriteria));
            }

            if (customCriteriaList.HasValue())
            {
                srchArgs.TargetCriteria = srchArgs.TargetCriteria & UserSearchHelper.GetCustomCriteria(customCriteriaList);
            }

            // GROUPS
            var includeGroupsCriteria = GetIncludeGroupsCriteria(attributeValueIds, attributeIds);
            if (includeGroupsCriteria != null)
            {
                srchArgs.TargetCriteria = srchArgs.TargetCriteria & includeGroupsCriteria;
            }

            return srchArgs;
        }
        private List<GenericCriteria> InitializeAdvancedSearch(string queryCriteria)
        {
            var qryCriterion = JsonSerializerService.Deserialize<IEnumerable<Criterion>>(queryCriteria);

            var advancedCriterion = new List<GenericCriteria>();

            if (qryCriterion != null)
            {
                foreach (var qryCriteria in qryCriterion)
                {
                    var criteria = new GenericCriteria(qryCriteria.entity.entityType, qryCriteria.entity.id, qryCriteria.operand);

                    switch (qryCriteria.AttributeType)
                    {
                        case CustomAttributeDataType.Picklist:
                        case CustomAttributeDataType.MultiPicklist:
                        case CustomAttributeDataType.Checkbox:
                            criteria.Value = (qryCriteria.operand == 11 || qryCriteria.operand == 12)
                                ? "0"
                                : ((int[])qryCriteria.Value).Join(",");
                            break;
                        case CustomAttributeDataType.Number:
                        case CustomAttributeDataType.String:
                        case CustomAttributeDataType.Memo:
                        case CustomAttributeDataType.Date:
                        case CustomAttributeDataType.DateTime:
                        case CustomAttributeDataType.Path:
                            criteria.Value = ((string[])qryCriteria.Value).Join(",");
                            break;
                        case CustomAttributeDataType.GeoLocation:
                            var fc = new FeatureCollection(qryCriteria.value[0].text);
                            if (fc.Features != null && fc.Features.Count > 0)
                            {
                                foreach (var f in fc.Features)
                                {
                                    if (f.Geometry.Type == Map.Geometry.Type.Polygon || f.Geometry.Type == Map.Geometry.Type.MultiPolygon)
                                    {
                                        criteria = new AttributeCriteria(qryCriteria.entity.id, qryCriteria.operand, f.Attributes["OBJECTID"].ToString());
                                    }
                                }
                            }
                            break;
                        case CustomAttributeDataType.AttributeValue:
                        case CustomAttributeDataType.Device:
                        case CustomAttributeDataType.Entity:
                        case CustomAttributeDataType.Object:
                        case CustomAttributeDataType.Unknown:
                        default:
                            throw new Exception("Not Implemented");
                    }

                    advancedCriterion.Add(criteria);
                }
            }

            return advancedCriterion;
        }

        private ExpressionElement GetIncludeGroupsCriteria(int[] attributeValueIds = null, int[] attributeIds = null)
        {
            ExpressionElement includeGroupsCriteria = null;
            foreach (var attributeId in attributeIds ?? new int[] { })
            {
                includeGroupsCriteria = includeGroupsCriteria & UserSearchHelper.GetGroupsCriteria(new[] { new List<GenericCriteria> { new AttributeCriteria(attributeId, CriteriaOperator.IsNotEmpty, 0) } });
                //includeGroupsCriteria = includeGroupsCriteria | UserSearchHelper.GetGroupsCriteria(new[] { new List<GenericCriteria> { new AttributeCriteria(attributeId, CriteriaOperator.IsNotEmpty, 0) } });
            }
            var attributesDictionary = GetAttributeIdsByValueIds(attributeValueIds ?? new int[] { });
            foreach (var attributeId in attributesDictionary.Keys)
            {
                includeGroupsCriteria = includeGroupsCriteria & UserSearchHelper.GetGroupsCriteria(new[] { new List<GenericCriteria> { new AttributeCriteria(attributeId, CriteriaOperator.Equals, attributesDictionary[attributeId].Join(",")) } });
                //includeGroupsCriteria = includeGroupsCriteria | UserSearchHelper.GetGroupsCriteria(new[] { new List<GenericCriteria> { new AttributeCriteria(attributeId, CriteriaOperator.Equals, attributesDictionary[attributeId].Join(",")) } });
            }
            return includeGroupsCriteria;
        }

        public List<CustomViewColumn> AccountabilityUserDefaultColumns()
        {
            //Default Columns of EventUserManage List
            var columns = new List<CustomViewColumn>()
            {
                new CustomViewColumn
                {
                    DisplayName =IWSResources.PAEvent_ColHeader_UserName,
                    Key = AttributeCommonNames.DisplayName,
                    IsRequired = true,
                    IsSortable = true,
                    CustomViewColumnType = "CF",
                    DataType = CustomAttributeDataType.String,
                    DataFormat = string.Empty,
                    ViewId = 0,
                    ColumnDisplayOrder=1,
                    IsDefault=true
                },
               
                    new CustomViewColumn
                    {
                        Id = 0,
                        DisplayName =IWSResources.PAEvent_ColHeader_Status,
                        Key = AttributeCommonNames.StatusId,
                        IsRequired = true,
                        IsSortable = true,
                        CustomViewColumnType = "CF",
                        DataType = null,
                        DataFormat = null,
                        ViewId = 0,
                        IsDefault=true,
                        ColumnDisplayOrder=2,
                    },
                     new CustomViewColumn
                    {
                        Id = 0,
                        DisplayName = IWSResources.PAEvent_ColHeader_Source,
                        Key = AttributeCommonNames.UpdatedFrom,
                        IsRequired = true,
                        IsSortable = true,
                        CustomViewColumnType = "CF",
                        DataType = null,
                        DataFormat = null,
                        ViewId = 0,
                        IsDefault=true,
                         ColumnDisplayOrder=3,
                    },
                    new CustomViewColumn
                    {
                        Id = 0,
                        DisplayName = IWSResources.PAEvent_ColHeader_TimeResponded,
                        Key = AttributeCommonNames.UpdatedOn,
                        IsRequired = true,
                        IsSortable = true,
                        CustomViewColumnType = "CF",
                        DataType = null,
                        DataFormat = null,
                        ViewId = 0,
                        IsDefault=true,
                         ColumnDisplayOrder=4,
                    }
                    ,
                    new CustomViewColumn
                    {
                        Id = 0,
                        DisplayName = IWSResources.PAEvent_ColHeader_Comments,
                        Key = AttributeCommonNames.Comments,
                        IsRequired = true,
                        IsSortable = true,
                        CustomViewColumnType = "CF",
                        DataType = null,
                        DataFormat = null,
                        ViewId = 0,
                        IsDefault=true,
                         ColumnDisplayOrder=5,
                    }

            };
            return columns;
        }

        public Dictionary<string, object> GetAttributeList(string attributeCsv, UserListType userListType)
        {
            // Get Custom Attribute List

            IEnumerable<Business.Domain.Entities.Device> allDevices = null;
            ILookup<string, Business.Domain.Entities.Device> devicesByCommonName = null;
            ILookup<string, Business.Domain.Entities.Device> devicesByName = null;
            IEnumerable<CustomAttribute> newAttributeCollection = null;
            IList<CustomViewColumn> columns = null;
            var deviceNames = new List<string>();
            var attributeNames = new List<string>(new[] { AttributeCommonNames.DisplayName });
            var providerId = RuntimeContext.ProviderId;
            var operatorId = RuntimeContext.OperatorId;
            var columnSortOrder = 0;
            switch (userListType)
            {
                case UserListType.AccountabilityList:
                    columns = AccountabilityUserDefaultColumns();
                    columnSortOrder = columns.Count;
                    break;
            }
            RefreshDevices(ref allDevices, ref devicesByCommonName, ref devicesByName, true);

            if (!string.IsNullOrEmpty(attributeCsv))
            {
                string[] columnNames = attributeCsv.Split(',').ToArray();
                newAttributeCollection = _customAttributeFacade.GetCustomAttributesBySpec(new CustomAttributeSpec
                {
                    IncludeValues = false,
                    ProviderId = providerId,
                    OperatorId = operatorId,
                    CommonNames = columnNames,
                }).ToList();
            }


            // Get Device Attriubte List
            if (!string.IsNullOrEmpty(attributeCsv))
            {
                var _alldevices = allDevices as Business.Domain.Entities.Device[] ?? allDevices.ToArray();

                foreach (var device in attributeCsv.Split(',').ToArray())
                {
                    var deviceObj = _alldevices.FirstOrDefault(i => i.CommonName == device);
                    if (deviceObj != null && !string.IsNullOrEmpty(deviceObj.CommonName))
                    {
                        deviceNames.Add(deviceObj.CommonName);
                        columns.Add(new CustomViewColumn
                        {
                            Id = deviceObj.Id,
                            DisplayName = deviceObj.Name,
                            Key = deviceObj.CommonName,
                            IsRequired = false,
                            IsSortable = true,
                            CustomViewColumnType = "Device",
                            DataType = CustomAttributeDataType.Device,
                            DataFormat = string.Empty,
                            ViewId = 0,
                            IsDefault = false
                        });
                    }
                }
            }

            if (newAttributeCollection != null)
            {
                foreach (var CFColumn in attributeCsv.Split(',').ToArray())
                {
                    if (!string.IsNullOrEmpty(CFColumn))
                    {
                        if (CFColumn == AttributeCommonNames.OperatorRoles
                           )
                        {
                            attributeNames.Add(CFColumn);
                            columns.Add(new CustomViewColumn
                            {
                                Id = 0,
                                DisplayName = IWSResources.DisplayName_OperatorRoles,
                                Key = CFColumn,
                                IsRequired = false,
                                IsSortable = true,
                                CustomViewColumnType = "CF",
                                DataType = CustomAttributeDataType.String,
                                DataFormat = string.Empty,
                                ViewId = 0,
                                IsDefault = false
                            });
                        }
                        else
                        {
                            var c = newAttributeCollection.FirstOrDefault(e => e.CommonName == CFColumn);
                            if (c != null && !string.IsNullOrEmpty(c.CommonName))
                            {
                                attributeNames.Add(c.CommonName);
                                columns.Add(new CustomViewColumn
                                {
                                    Id = c.Id,
                                    DisplayName = c.AttributeName,
                                    Key = c.CommonName,
                                    IsRequired = false,
                                    IsSortable = true,
                                    CustomViewColumnType = "CF",
                                    DataType = CustomAttributeDataType.String,
                                    DataFormat = string.Empty,
                                    ViewId = 0,
                                    IsDefault = false
                                });
                            }
                        }
                    }
                }
            }
            #region "Sort Header Columns as per User Input"

            if (!string.IsNullOrEmpty(attributeCsv))
                foreach (var x in attributeCsv.Split(',').ToList())
                {
                    if (!string.IsNullOrEmpty(x))
                    {
                        var itemToChange = columns.FirstOrDefault(d => d.Key == x);
                        if (itemToChange != null)
                            itemToChange.ColumnDisplayOrder = columnSortOrder++;
                    }
                }
            #endregion "Sort Header Columns as per User Input"

            return new Dictionary<string, object>
            {
                {"DeviceColumns", deviceNames},
                {"HeaderColumns", columns},
                {"AttributeColumns", attributeNames}
            };
        }

    }
}