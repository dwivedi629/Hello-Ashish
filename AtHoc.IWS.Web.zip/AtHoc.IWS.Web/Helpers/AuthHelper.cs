﻿using System;
using System.ComponentModel;
using System.Web;
using System.Web.Security;
using AtHoc.IWS.Business.Adapter;
using AtHoc.IWS.Business.Context;
using AtHoc.Operators;
using AtHoc.Systems;
using AtHoc.Diagnostics;
namespace AtHoc.IWS.Web.Helpers
{
   
    public static class AuthHelper
        {
            public static bool CreateAuthTicket(Operator opr, AuthType authType)
            {
                var authTicketUserData = new AuthTicketUserData();

                if (opr.PasswordNeverExpires == false)
                {
                    if (opr.ValidationResult == OperatorValidationResult.PasswordExpired)
                    {
                        authTicketUserData.HasPasswordExpired = true;
                    }
                }

                if (opr.ValidationResult == OperatorValidationResult.PasswordChangeRequired)
                {
                    authTicketUserData.IsPasswordChangeRequired = true;
                }

                var accessibleProviders = opr.GetAccessibleProviders();

                int? providerToLogOnTo = null;

                if (opr.LastAccessedProvider.HasValue && accessibleProviders.Contains(opr.LastAccessedProvider.Value))
                {
                    // there is a last accessed provider and operator still has access to it, log on to that provider
                    providerToLogOnTo = opr.LastAccessedProvider.Value;
                }
                else if (accessibleProviders.Count == 1)
                {
                    // there is only one accessible provider remaining for this operator on which the operator still has access, log on to that provider
                    providerToLogOnTo = accessibleProviders[0];
                }
                else if (accessibleProviders.Count > 1)
                {
                    // there are multiple providers he has access to, ask to choose context provider
                    providerToLogOnTo = null;

                    // if operator has access to multiple VPSes, but his password has expired, then we will log him into his default provider for password change
                    if (opr.ValidationResult == OperatorValidationResult.PasswordChangeRequired) providerToLogOnTo = opr.DefaultProvider;
                }
                else
                {
                    // EDGE CASE : log off the operator since all the above checks have failed and he doesnt have operator access to any VPS
                    LogOff();
                }

                authTicketUserData.ProviderId = providerToLogOnTo;
                authTicketUserData.DefaultProviderId = opr.DefaultProvider;
                authTicketUserData.UserId = opr.Id;
                authTicketUserData.AuthType = authType;

                var operatorSessionTimeoutInterval = ConfigurationSettingsAdapter.GetSessionTimeOutInterval(); ;

                var ticket = new FormsAuthenticationTicket(1, opr.LoginId, DateTime.Now, DateTime.Now.AddMinutes(operatorSessionTimeoutInterval), false, authTicketUserData.ToString());
                var cookieString = FormsAuthentication.Encrypt(ticket);
                var cookie = new HttpCookie(FormsAuthentication.FormsCookieName, cookieString)
                {
                    HttpOnly = true,
                    Path = FormsAuthentication.FormsCookiePath
                };

                HttpContext.Current.Response.Cookies.Add(cookie);

                return true;
            }

            public static AuthTicketUserData GetAuthTicketUserData()
            {
                var authenticationCookie = HttpContext.Current.Request.Cookies[FormsAuthentication.FormsCookieName];

                if (authenticationCookie != null)
                {
                    var authenticationTicket = FormsAuthentication.Decrypt(authenticationCookie.Value);
                    if (authenticationTicket != null && !authenticationTicket.Expired && authenticationTicket.UserData != String.Empty)
                    {
                        return new AuthTicketUserData(authenticationTicket.UserData);
                    }
                }

                return null;
            }

            static public void LogOff()
            {
                if (HttpContext.Current == null) return;

                var session = HttpContext.Current.Session;
                var cookies = HttpContext.Current.Response.Cookies;

                // Update Session Activity Time and Session Status in SESSION_TAB to OUT
                if (HttpContext.Current.User != null && HttpContext.Current.User.Identity.IsAuthenticated)
                {
                    var user = RuntimeContext.Operator;
                    var provider = RuntimeContext.Provider;

                    if (!string.IsNullOrEmpty(session.SessionID) && !session.IsNewSession && user != null && user.Id > 0)
                    {
                        MarkSessionStatusOut(user.Id, session.SessionID);
                        OperationAuditor.LogAction(user.Id, provider.Id, AuditedAction.LogoutSuccessful, AuditedEntity.LoginAttempt, user.DisplayName, 0, "", "");
                    }
                }

                //http://stackoverflow.com/questions/412300/formsauthentication-signout-does-not-log-the-user-out

                FormsAuthentication.SignOut();
                session.Clear();
                session.Abandon();

                //Explicity setting the authentication cookie value to blank and setting expiry date to 1 year before now
                //Not doing this is causing the cookie to not expire, hence application still thinks that user is authenticated.
                //Cookies.remove removes cookie from only server response, hence what is cached in browser is not removed. 

                var authCookie = new HttpCookie(FormsAuthentication.FormsCookieName, "")
                {
                    HttpOnly = true,
                    Expires = DateTime.Now.AddYears(-1),
                    Path = FormsAuthentication.FormsCookiePath
                };
                HttpContext.Current.Response.Cookies.Add(authCookie);

                /*   var appleCookie = new HttpCookie(AppleConnect.CookieName, "")
                   {
                       HttpOnly = true,
                       Domain = AppleConnect.CookieDomainName,
                       Expires = DateTime.Now.AddYears(-1)
                   }; 
                   HttpContext.Current.Response.Cookies.Add(appleCookie);
                   */
                cookies.Remove("ASP.NET_SessionId");
                cookies.Remove("RequestVerificationToken");
                cookies.Remove("__AntiForgeryToken");


                //Session ID cookie is not removed from the browser of the user using Cookies.Remove.
                //Adding a new session ID cookie with empty string value
                HttpContext.Current.Response.Cookies.Add(new HttpCookie("ASP.NET_SessionId", ""));
            }

            //Set status to OUT for abandoned session
            static public void MarkSessionStatusOut(int opratorId, string currentSessionId)
            {
                using (new MethodScope(opratorId, currentSessionId))
                {
                    //Mark session as OUT
                    if (currentSessionId != "")
                    {
                        EventLogger.WriteVerbose("In MarkSessionStatusOut");
                        //OperatorManager.LogOutSession(currentSessionId, opratorId, AtHoc.Context.HttpRuntimeContext.GetRuntimeContext().GetProviderContext().Id);
                        OperatorManager.EndSession(currentSessionId, SessionSubStatus.OUT_SELF);
                    }
                }
            }
         
        }
    
    public enum AuthType
    {
        Unknown,

        [Description("Manual")]
        Manual,

        [Description("Smart Card")]
        SmartCard,

        [Description("Windows Authentication")]
        WinAuth,

        [Description("SSO")]
        SSO,
    }
}