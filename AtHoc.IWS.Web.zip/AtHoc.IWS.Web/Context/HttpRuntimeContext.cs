﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.IWS.Business.Domain.VirtualSystem;
using AtHoc.IWS.Business.Domain.VirtualSystem.Spec;
using AtHoc.IWS.Web.Configurations.Constants;
using AtHoc.IWS.Web.Helpers;

namespace AtHoc.IWS.Web.Context
{
	public class HttpRuntimeContext : IRuntimeContext
	{
	    private readonly IVirtualSystemFacade _virtualSystemFacade;
		private readonly IOperatorDetailsFacade _operatorDetailsFacade;
		private readonly IUserFacade _userFacade;
        private readonly IProviderFacade _providerFacade;

        public const string ContextKeyProvider = "HttpRuntimeContext.Provider";
        public const string ContextKeyUser = "HttpRuntimeContext.User";

		public HttpRuntimeContext(IVirtualSystemFacade virtualSystemFacade, IOperatorDetailsFacade operatorDetailsFacade, IUserFacade userFacade, IProviderFacade providerFacade)
		{
			_virtualSystemFacade = virtualSystemFacade;
			_operatorDetailsFacade = operatorDetailsFacade;
			_userFacade = userFacade;
		    _providerFacade = providerFacade;
		}

		public Provider Provider
		{
			get
			{
			    var currentProvider = (Provider) HttpContext.Current.Session[ContextKeyProvider];

			    var userData = AuthHelper.GetAuthTicketUserData();

			    if (currentProvider == null || (currentProvider.Id != (userData.ProviderId ?? userData.DefaultProviderId)))
			    {
			        currentProvider = _virtualSystemFacade.GetProviderBySpec(new VirtualSystemSpec
			        {
			            Id = userData.ProviderId ?? userData.DefaultProviderId,
			            IncludeExtendedParams = true
			        });
			        currentProvider.BaseLocale = _providerFacade.GetProviderLocale(currentProvider.Id);

			        currentProvider.FeatureMatrix = _providerFacade.GetFeatureMatrix(currentProvider.Id);

			        HttpContext.Current.Session[ContextKeyProvider] = currentProvider;
			    }

			    return currentProvider;
			}
		}

	    [Obsolete("Use Operator object and userFacade.GetOperator method.")]
		public OperatorUser Operator
		{
			get
			{
			    var currentOperator = (OperatorUser) HttpContext.Current.Session[ContextKeyUser];

                var userData = AuthHelper.GetAuthTicketUserData();

			    if (currentOperator == null || currentOperator.Id != userData.UserId)
			    {
			        currentOperator = _operatorDetailsFacade.GetOperatorUserBySpec(new OperatorUserSpec {UserId = userData.UserId});

			        currentOperator.OperatorAccess = _operatorDetailsFacade.GetOperatorAccess(new OperatorAccessSpec
			        {
			            OperatorId = currentOperator.Id,
			            ProviderId = Provider.Id
			        });

                    var currentProvider = (Provider)HttpContext.Current.Session[ContextKeyProvider];

                    //Remove objectIds from operator access list based on Feature Matrix
			        if (currentProvider.FeatureMatrix.ObjectIdsToRemove != null)
			        {
			            var objectIdsToRemove = new HashSet<int>(currentProvider.FeatureMatrix.ObjectIdsToRemove);
			            currentOperator.OperatorAccess = currentOperator.OperatorAccess.ToList().Where(x => !objectIdsToRemove.Contains(x.ObjectId)).ToList(); 
			        }

			        var operatorVpsAccess = _operatorDetailsFacade.GetOperatorVpsAccess(new OperatorAccessSpec {OperatorId = currentOperator.Id});

			        currentOperator.HasMultipleVpsAccess = operatorVpsAccess.Many();

			        //see if this opr is a member of the team, so we know to display ssa menu/not
			        var endUserDetails = _userFacade.GetUserBySpec(new UserSpec
			        {
			            ProviderId = Provider.Id,
			            OperatorId = currentOperator.Id,
			            CustomFieldFormat = true,
			            UserId = currentOperator.Id,
			            GetUserAttributes = true
			        });

			        currentOperator.IsTeamMember = false;

			        if (endUserDetails != null)
			        {
			            currentOperator.ShortDisplayName = endUserDetails.GetShortDisplayName();
			            var ssaValue = endUserDetails.UserAttributes.FirstOrDefault(x => x.CommonName == CommonNames.SSATeam);

			            currentOperator.IsTeamMember = ssaValue != null;
			            if (currentOperator.IsTeamMember)
			            {
			                currentOperator.TeamId = Convert.ToInt32(ssaValue.Value);
			            }
			        }

			        HttpContext.Current.Session[ContextKeyUser] = currentOperator;
			    }

			    return currentOperator;
			}
		}

        public User LoggedOnUser
        {
            get { return null; }
        }
	    
        public OperatorUser RefreshedOperatorContext()
		{
			HttpContext.Current.Session[ContextKeyUser] = null;
			return Operator;
		}

        public Provider RefreshedProviderContext()
        {
            HttpContext.Current.Session[ContextKeyProvider] = null;
            return Provider;
        }

	    /// <summary>
	    /// This API should be called when an user logs out.
	    /// It clears out both UserContext and ProviderContext.
	    /// </summary>
	    public static void ClearContext()
	    {
            HttpContext.Current.Session[ContextKeyUser] = null;
            HttpContext.Current.Session[ContextKeyProvider] = null;
	    }
	}
}