﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using AtHoc.IWS.Business.Configurations;

namespace AtHoc.IWS.Web.Runtime
{
    public static class LegacyProxy
    {
        public static void TransferRequest(HttpRequest request)
        {
            System.Net.ServicePointManager.ServerCertificateValidationCallback +=
                delegate(object sender, System.Security.Cryptography.X509Certificates.X509Certificate certificate,
                        System.Security.Cryptography.X509Certificates.X509Chain chain,
                                                System.Net.Security.SslPolicyErrors sslPolicyErrors)
                        {
                            return true; // **** Always accept
                        };

            //long polling to file in legacy app to keep session alive
            Uri uri = new Uri(ConfigurationManager.GetURL() + "/client/blank_do_not_delete.png");
            HttpWebRequest requestFile = (HttpWebRequest)WebRequest.Create(uri);
            requestFile.CookieContainer = new CookieContainer();
            HttpCookieCollection oCookies = request.Cookies;
            for (int j = 0; j < oCookies.Count; j++)
            {
                HttpCookie oCookie = oCookies.Get(j);
                Cookie oC = new Cookie();
                // Convert between the System.Net.Cookie to a System.Web.HttpCookie...
                oC.Domain = requestFile.RequestUri.Host;
                oC.Expires = oCookie.Expires;
                oC.Name = oCookie.Name;
                oC.Path = oCookie.Path;
                oC.Secure = oCookie.Secure;
                oC.Value = oCookie.Value;
                requestFile.CookieContainer.Add(oC);
            }
            HttpWebResponse webResp = requestFile.GetResponse() as HttpWebResponse;
        }
    }
}