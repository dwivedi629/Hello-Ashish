﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Mvc;
using System.Web.SessionState;
using AtHoc.Diagnostics;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Resources;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Data.SearchSpec;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.Authorization;
using AtHoc.IWS.Business.Domain.Devices;
using AtHoc.IWS.Business.Domain.Events;
using AtHoc.IWS.Business.Domain.Map;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Business.Domain.Users.Impl.Search;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Business.Domain.Spec;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.IWS.Business.Domain.Organization;
using AtHoc.IWS.Business.Domain.VirtualSystem;
using AtHoc.IWS.Web.Filters;
using AtHoc.IWS.Web.Models.Accoutability;
using AtHoc.Publishing;
using AtHoc.IWS.Web.Helpers;
using EO.Internal;
using GeoJSON.Net;
using GeoJSON.Net.Feature;
using GeoJSON.Net.Geometry;
using GeoJSON.Net.MsSqlSpatial;
using Newtonsoft.Json;
using Controller = AtHoc.Infrastructure.Web.Mvc.Controller;
using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.Accountability;
using AtHoc.IWS.Business.Domain.Accountability.Specs;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.SSA.Business;
using AtHoc.IWS.SSA.Business.Facades;
using AtHoc.IWS.SSA.Dictionaries;
using Microsoft.Ajax.Utilities;
using Microsoft.SqlServer.Types;
using Point = GeoJSON.Net.Geometry.Point;
using Type = AtHoc.IWS.Map.Geometry.Type;
using AtHoc.IWS.Business.Domain.Users.Impl;
using AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel;
using System.Collections;

namespace AtHoc.IWS.Web.Controllers
{
    [SessionState(SessionStateBehavior.ReadOnly)]
    public class MapLayersController : Controller
    {
        private readonly IOrganizationFacade _organizationFacade;
        private readonly IEventFacade _eventFacade;
        private readonly ILogService _logService;
        private readonly IUserFacade _userFacade;
        private readonly IDeviceFacade _deviceFacade;
		private readonly IPublishingDomainToModel _publishingDomainToModel;
        private readonly IMapFacade _mapFacade;
        private readonly IAccountabilityFacade _accountabilityFacade;
        private readonly IAlertFacade _alertFacade;
        private readonly IVirtualSystemFacade _virtualSystemFacade;
        private readonly IAuthFacade _authFacade;
        private readonly IOperatorDetailsFacade _operatorDetailsFacade;

        public MapLayersController(IOrganizationFacade organizationFacade, IEventFacade eventFacade, ILogService logService, IUserFacade userFacade, IDeviceFacade deviceFacade, IPublishingDomainToModel publishingDomainToModel, IMapFacade mapFacade, IAccountabilityFacade accountabilityFacade, IAlertFacade alertFacade, IVirtualSystemFacade virtualSystemFacade, IAuthFacade authFacade, IOperatorDetailsFacade operatorDetailsFacade)
        {
            _organizationFacade = organizationFacade;
            _eventFacade = eventFacade;
            _logService = logService;
            _userFacade = userFacade;
            _deviceFacade = deviceFacade;
            _publishingDomainToModel = publishingDomainToModel;
            _mapFacade = mapFacade;
            _accountabilityFacade = accountabilityFacade;
            _alertFacade = alertFacade;
            _virtualSystemFacade = virtualSystemFacade;
            _authFacade = authFacade;
            _operatorDetailsFacade = operatorDetailsFacade;
        }
        //
        // GET: /MapLayers/
        public JsonResult GetOrganizations()
        {
            bool isVPSConnectedToPSS = _publishingDomainToModel.OrganizationEnabled(_organizationFacade, RuntimeContext.ProviderId);
            if (!isVPSConnectedToPSS)
            {
                return Json(new { geoJson = "{features: []}" });
            }
            var features = new List<Feature>();
            var orgsInfo = _organizationFacade.GetActiveOrganizationInformation(RuntimeContext.ProviderId);
            foreach (var org in orgsInfo)
            {
                if (string.IsNullOrEmpty(org.LastKnownLocation)) continue;
                var lonLat = org.LastKnownLocation.Substring(org.LastKnownLocation.IndexOf('(') + 1, org.LastKnownLocation.Length - org.LastKnownLocation.IndexOf('(') - 2).Split(' ');
                var geoObj = new Point(new GeographicPosition(Double.Parse(lonLat[1]), Double.Parse(lonLat[0])));

                var orgInfo = _organizationFacade.GetOrganizationById(RuntimeContext.ProviderId, org.DeviceAddress);
                if (orgInfo == null)
                {
                    return null;
                }
                var featureProperties = new Dictionary<string, object>
                {
                    {"name", org.DisplayName}, 
                    {"editable", "false"},
                    {"orgId", org.DeviceAddress},
                    {"id", org.DeviceAddress},
                    {"description", orgInfo.Description},
                    {"address", orgInfo.PhysicalAddress.AddressLine1 + " " + orgInfo.PhysicalAddress.AddressLine2 + " " + orgInfo.PhysicalAddress.City + " " + orgInfo.PhysicalAddress.State + " " + orgInfo.PhysicalAddress.Country + " " + orgInfo.PhysicalAddress.ZipCode},
                    {"url", orgInfo.Url},
                    {"contact", orgInfo.ContactInfo.FirstName + " " + orgInfo.ContactInfo.LastName},
                    {"phone", orgInfo.ContactInfo.PhoneNumber},
                    {"sector", orgInfo.Sector.Name}
                };
                var feature = new Feature(geoObj, featureProperties);
                features.Add(feature);
            }
			var fc = new FeatureCollection(features);
            return Json(fc);
        }

        [HttpGet]
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public JsonResult GetEvents(bool includeSubVps = false)
        {
            var spec = new AccountabilityEventSearchSpec()
            {
                ProviderId = RuntimeContext.ProviderId,
                Page = 1,
                PageSize = 1000,
                Status = new[] { AccountabilityEventStatus.Live.ToString() }
            };

            IDictionary<int, string> subVpsData = null;
            if (includeSubVps)
            {
                subVpsData = _accountabilityFacade.GetSubOrganizationsWithNames(RuntimeContext.ProviderId);
                spec.VpsIds = subVpsData.Keys.CsvParamString();
            }
            else
            {
                spec.VpsIds = spec.ProviderId.ToString();
            }

            var liveEventData = _accountabilityFacade.GetEventsForMap(spec).ToList();
            var features = new List<Feature>();
            foreach (var eventData in liveEventData)
            {
                if (!string.IsNullOrEmpty(eventData.GeoJson))
                {
                    var existingGeoJson = JsonConvert.DeserializeObject<FeatureCollection>(eventData.GeoJson);
                    var priorityText = Models.Event.EventModel.GetSeverityText(eventData.Priority);

                    foreach (var existingFeature in existingGeoJson.Features)
                    {
                        existingFeature.Properties.Clear();
                        existingFeature.Properties.Add("name", eventData.EventName);
                        existingFeature.Properties.Add("editable", false);
                        existingFeature.Properties.Add("id", eventData.EventId);
                        existingFeature.Properties.Add("createdOn", RuntimeContext.Provider.SystemToVpsDateTimeFormated(eventData.CreatedOn));
                        existingFeature.Properties.Add("updatedOn", RuntimeContext.Provider.SystemToVpsDateTimeFormated(eventData.UpdatedOn));
                        existingFeature.Properties.Add("endsOn", RuntimeContext.Provider.SystemToVpsDateTimeFormated(eventData.EndDate));
                        existingFeature.Properties.Add("eventStatus", eventData.Status);
                        existingFeature.Properties.Add("usersAffected", eventData.Affected);
                        existingFeature.Properties.Add("usersResponded", eventData.UsersResponded);
                        existingFeature.Properties.Add("usersNotResponded", eventData.UsersNotResponded);

                        existingFeature.Properties.Add("priority", priorityText.ToLower());
                        if (includeSubVps && subVpsData.Count > 0)
                        {
                            existingFeature.Properties.Add("layerType", "sub-vps-events");
                            existingFeature.Properties.Add("providerId", eventData.ProviderId.ToString());
                            existingFeature.Properties.Add("organizationName", subVpsData[eventData.ProviderId].ToString());
                        }
                        else
                        {
                            existingFeature.Properties.Add("layerType", "events");
                        }

                        IEnumerable<AlertResponse> eventResponses = null;
                        if (eventData.Responses != null)
                        {
                            eventResponses = from res in eventData.Responses
                                             select new AlertResponse
                                             {
                                                 Number =  res.ResponseCount.GetValueOrDefault(),
                                                 Response = res.ResponseText
                                             };
                        }

                        existingFeature.Properties.Add("responses", eventResponses);

                    }

                    features = features.Concat(existingGeoJson.Features).ToList();
                }
            }

            var fc = new FeatureCollection(features);
            return Json(fc);
        }

        public JsonResult GetOrganization(string orgId)
        {
            Guid orgGuid;
            if (!Guid.TryParse(orgId, out orgGuid)) return null;

            var orgInfo = _organizationFacade.GetOrganizationById(RuntimeContext.ProviderId, orgId);
            if (orgInfo == null)
            {
                return null;
            }
            var organisationProperties = new Dictionary<string, object>
            {
                {"description", orgInfo.Description},
                {"address", orgInfo.PhysicalAddress.AddressLine1 + " " + orgInfo.PhysicalAddress.AddressLine2 + " " + orgInfo.PhysicalAddress.City + " " + orgInfo.PhysicalAddress.State + " " + orgInfo.PhysicalAddress.Country + " " + orgInfo.PhysicalAddress.ZipCode},
                {"url", orgInfo.Url},
                {"contact", orgInfo.ContactInfo.FirstName + " " + orgInfo.ContactInfo.LastName},
                {"phone", orgInfo.ContactInfo.PhoneNumber},
                {"sector", orgInfo.Sector.Name}
            };
            return Json(organisationProperties);
        }

        [HttpGet]
        [IWSAuthorize(new[] { SystemObject.Alert }, new[] { ActionType.View })]
        public JsonResult GetAlerts(bool getEventAlert = false)
        {
            var alertSpec = new AlertSearchSpec
                   {
                       OperatorId = RuntimeContext.Operator.Id,
                       ProviderId = RuntimeContext.Provider.Id,
                       StatusFilter = new List<string> { "Live" }
                   };

            var alertsForMap = _alertFacade.GetAlertsForMap(alertSpec, getEventAlert);

            var features = new List<Feature>();
            foreach (var alert in alertsForMap)
            {
                if (alert != null && !string.IsNullOrEmpty(alert.GeoJson))
                {
                    var existingGeoJson = JsonConvert.DeserializeObject<FeatureCollection>(alert.GeoJson);
                    foreach (var existingFeature in existingGeoJson.Features)
                    {
                        existingFeature.Properties.Clear();
                        existingFeature.Properties.Add("name", alert.Title);
                        existingFeature.Properties.Add("editable", false);
                        existingFeature.Properties.Add("id", alert.Id);
                        existingFeature.Properties.Add("layerType", "live-alerts");
                        existingFeature.Properties.Add("createdOn", RuntimeContext.Provider.SystemToVpsDateTimeFormated(alert.StartTime));
                        existingFeature.Properties.Add("updatedOn", RuntimeContext.Provider.SystemToVpsDateTimeFormated(alert.Tracking.UpdatedOn));
                        existingFeature.Properties.Add("endsOn", RuntimeContext.Provider.SystemToVpsDateTimeFormated(alert.EndTime));
                        existingFeature.Properties.Add("alertStatus", alert.Status);
                        existingFeature.Properties.Add("usersAffected", alert.Tracking.Targeted);
                        existingFeature.Properties.Add("usersResponded", alert.Tracking.Responded);
                        existingFeature.Properties.Add("usersNotResponded", alert.Tracking.NoResponse);
                        existingFeature.Properties.Add("priority", alert.Severity.ToLower());
                        existingFeature.Properties.Add("responses", alert.Tracking.Response);
                    }

                    features = features.Concat(existingGeoJson.Features).ToList();
                }
            }

            var fc = new FeatureCollection(features);
            return Json(fc);
        }

		/// <summary>
		/// 
		/// </summary>
		/// <param name="x0"></param>
		/// <param name="centerY"></param>
		/// <param name="radius"></param>
		/// <returns></returns>
		private Tuple<double, double> GetRandomLatLongAroundCenter(double centerX, double centerY,double radius)
		{
			Random random = new Random();

			// Convert radius from meters to degrees
			double radiusInDegrees = radius / 111000f;

			double u = random.NextDouble();
			double v = random.NextDouble();
			double w = radiusInDegrees * Math.Sqrt(u);
			double t = 2 * Math.PI * v;
			double x = w * Math.Cos(t);
			double y = w * Math.Sin(t);
			
			double foundLongitude = x + centerX;
			double foundLatitude = y + centerY;
			return new Tuple<double, double>(foundLongitude, foundLatitude);
		}

		/// <summary>
		/// Test method to test clusters
		/// </summary>
		/// <returns></returns>
		[HttpGet]
		public ActionResult GetTestLatLong()
		{
			var features = new List<Feature>();

			var totalCount = 1000;
			var centerLat = 37.0;
			var centerLong = -122.0;
			var radius = 10000; //meters
			for (int i = 0; i < totalCount; i++)
			{
				var latLong = GetRandomLatLongAroundCenter(centerLat, centerLong, 10000);
				var longitude = latLong.Item1;
				var latitude = latLong.Item2;
				var featureProperties = new Dictionary<string, object>
						{
							{"id", i }
						};
				var geoObj = new Point(new GeographicPosition(latitude, longitude));
				var feature = new Feature(geoObj, featureProperties);
				features.Add(feature);
			}
			var fc = new FeatureCollection(features);
			return Json(fc);
		}


        [IWSAuthorize(new[] { SystemObject.Alert, SystemObject.EventManager }, new[] { ActionType.View })]
        public JsonResult GetLiveIncomingAlerts(EventSpec eventSpec)
        {
            //with eventSpec.IsEnded as false to get the live incoming alerts
            
            try
            {
                var features = new List<Feature>();
                eventSpec.ProviderId = RuntimeContext.ProviderId;
                eventSpec.CurrentDbUtc = RuntimeContext.Provider.VpsToUtcTime(RuntimeContext.Provider.CurrentSystemTimeToVps());
                eventSpec.FuncVpsToUtcTime = RuntimeContext.Provider.VpsToUtcTime;
                eventSpec.Operator = RuntimeContext.Operator;
                eventSpec.OperatorId = RuntimeContext.OperatorId;
                eventSpec.ViewType = EventViewType.Inbox;
                eventSpec.IsEnded = false; //Get only Live alerts
                eventSpec.IncludeTotalCount = false; //Do not call get total count query
                eventSpec.IsLiveAlertOnly = true;

                //Get EventData  - do not include Media attachment
                var eventData = _eventFacade.GetEventsBySpec(eventSpec, false); //false - not include media attachment
               // var eventsViewModel = Models.Event.EventModel.GenerateEventModels(_userFacade, eventData.Events.Data,eventData.EventCategories, eventData.MediaAttachments);
                var eventsViewModel = Models.Event.EventModel.GetLiveIncomingAlerts(_userFacade, eventData.Events.Data,eventData.EventCategories);
                
                
                foreach (var incomingAlert in eventsViewModel)
                {
                    var hasLatLong = false;
                    double latitude = incomingAlert.Latitude;
                    double longitude = incomingAlert.Longitude;
                    if (latitude > 0 || longitude > 0) //Check if either latitude or Longitude is avaialble
                    {
                        hasLatLong = true;
                    }
                    //Certain case only Long/Lat value is available, thus extract the GEO information from Lat/Long
                    if ( hasLatLong)
                    {
                        var geoObj = new Point(new GeographicPosition(latitude, longitude));
                        var featureProperties = new Dictionary<string, object>
                        {
                            {"  ", incomingAlert.Title }, 
                            {"id", incomingAlert.Id }, 
                            {"description", incomingAlert.Description}, 
                            {"editable", false }, 
                            {"layerType", "incoming-alert"},
                            {"symbol", "{type: 'esriPMS', url: '"+incomingAlert.AlertTypeIcon+"', width:24, height:24}"},
                            {"createdOn", incomingAlert.CreatedOn},
                            {"type", incomingAlert.AlertType},
                            {"sourceName", incomingAlert.SourceName},
                            {"priority", ((Priority)incomingAlert.Priority).ToString().ToLower()},
                            {"sourceType", incomingAlert.SourceType.ToLower()}
                        };
                        var feature = new Feature(geoObj, featureProperties);
                        features.Add(feature);
                    }

                    //In case, if Geo Json is aviable, then try to extract GeoJson - Merge with above set using Concat so set if either has geo information aviable - it should work as expected.
                    if (!string.IsNullOrEmpty( incomingAlert.GeoJson ))
                    {
                        var existingGeoJson = JsonConvert.DeserializeObject<FeatureCollection>(incomingAlert.GeoJson);
                        foreach (var existingFeature in existingGeoJson.Features)
                        {
                            existingFeature.Properties.Clear();
                            existingFeature.Properties.Add("name", incomingAlert.Title);
                            existingFeature.Properties.Add("id", incomingAlert.Id);
                            existingFeature.Properties.Add("layerType", "incoming-alerts");
                            existingFeature.Properties.Add("description", incomingAlert.Description);
                            existingFeature.Properties.Add("editable", false);
                            existingFeature.Properties.Add("createdOn", incomingAlert.CreatedOn);
                            existingFeature.Properties.Add("type", incomingAlert.AlertType);
                            existingFeature.Properties.Add("sourceName", incomingAlert.SourceName);
                            existingFeature.Properties.Add("priority", ((Priority)incomingAlert.Priority).ToString().ToLower());
                            existingFeature.Properties.Add("sourceType", incomingAlert.SourceType.ToLower());
                        }
                        features = features.Concat(existingGeoJson.Features).ToList();
                    }
                }
                
                var fc = new FeatureCollection(features);
                return Json(fc);
            }
            //Catch timed out exception
            catch (TimeoutException ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, LastUpdatedTime = RuntimeContext.Provider.CurrentSystemTimeToVpsTimeString(), Data = string.Empty, IsTimedOut = true });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                //Making sure timed out exception is not skipping in above statement.
                return Json(new { Success = false, LastUpdatedTime = RuntimeContext.Provider.CurrentSystemTimeToVpsTimeString(), Data = string.Empty, IsTimedOut = ex.Message.ToLower().Contains("operation has timed out") });
            }
        }



        private string TruncateDigits(Match m)
        {
            var digits = m.ToString();
            var truncated = digits.Substring(0, 7);
            if (digits.LastOrDefault() == ')')
            {
                truncated += ")";
                return truncated;
            }

            if (digits.IndexOf("))") >= 0)
            {
                truncated += "))";
            }
            else if (digits.IndexOf(')') >= 0)
            {
                truncated += ")";
            }

            if (digits.IndexOf(',') >= 0)
            {
                truncated += ", ";
            }
            else
            {
                truncated += " ";
            }
            return truncated;
        }


        [HttpGet]
        public ActionResult GetSelectableLayersMetadata()
        {
            try
            {
                var zoneLayers = _mapFacade.GetSelectableLayersMetadata(RuntimeContext.ProviderId);
                var layerIdNameCollection = from zoneLayer in zoneLayers
                    orderby zoneLayer.Name 
                    select new
                    {
                        LayerId = zoneLayer.Id,
                        LayerName = zoneLayer.Name,
                        zoneLayer.FillColor,
                        zoneLayer.IsDisplayOnly,
                        Visible = false,
                    };
                return Json(new {Success = true, Data = layerIdNameCollection.ToList()});
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Message = "There was error loading selectable layers" });
            }
        }

        [HttpGet]
        public ActionResult GetLayerDisplayPermissions()
        {
            var isEnterprise = (RuntimeContext.Provider.ProviderType() == VPSType.Enterprise);
            var hasSubVPS = false;
            if (isEnterprise)
            {
                hasSubVPS = _virtualSystemFacade.GetSubVirtualSystems(RuntimeContext.ProviderId).Any();
            }

            var operatorAccess = _operatorDetailsFacade.GetOperatorAccess(new OperatorAccessSpec
            {
                OperatorId = RuntimeContext.OperatorId,
                ProviderId = RuntimeContext.ProviderId
            });

            var canViewPAEvent = _authFacade.HasAccess(operatorAccess, SystemObject.AccountabilityEvent, ActionType.View) && RuntimeContext.Provider.FeatureMatrix.IsAccountabilitySupported;
            var canViewAlert = _authFacade.HasAccess(operatorAccess, SystemObject.AdvancedAlertManager, ActionType.View)
                    || _authFacade.HasAccess(operatorAccess, SystemObject.AlertPublisher, ActionType.View)
                    || _authFacade.HasAccess(operatorAccess, SystemObject.EnterpriseAdmin, ActionType.View)
                    || _authFacade.HasAccess(operatorAccess, SystemObject.Alert, ActionType.View);
            var canViewIncomingAlert = _authFacade.HasAccess(operatorAccess, SystemObject.EventManager, ActionType.View);
            
            ConnectivityStatus connectivityStatus = _organizationFacade.GetConnectivityStatus(RuntimeContext.ProviderId);

            var canViewOrg = !(connectivityStatus == ConnectivityStatus.NotConfigured ||
                connectivityStatus == ConnectivityStatus.DeviceNotConfigured ||
                connectivityStatus == ConnectivityStatus.NotListed) ;
            
            return Json(new
            {
                Success = true,
                isEnterprise = isEnterprise,
                viewSubVPSEventsLayer = hasSubVPS,
                viewPAEvent = canViewPAEvent,
                viewAlert = canViewAlert,
                viewIncomingAlert = canViewIncomingAlert,
                viewOrg = canViewOrg
            });
        }

        [HttpGet]
        public ActionResult GetDisplayOnlyLayersMetadata()
        {
            try
            {
                var zoneLayers = _mapFacade.GetDisplayOnlyLayersMetadata(RuntimeContext.ProviderId);
                var layerIdNameCollection = from zoneLayer in zoneLayers
                                            orderby zoneLayer.SortOrder ascending
                                            select
                                                new
                                                {
                                                    LayerId = zoneLayer.Id,
                                                    LayerName = zoneLayer.Name,
                                                    zoneLayer.FillColor,
                                                    zoneLayer.IsDisplayOnly,
                                                    Visible = false,
                                                    zoneLayer.SortOrder
                                                };
                                                
                    return Json(new {Success = true, Data= layerIdNameCollection.ToList()});
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Message = "There was error loading display only shape file metadata" });
            }
        }

	    [HttpPost]
		public ActionResult CreateIdForGraphic(string geoJson)
	    {
			try
		    {
			 	if (string.IsNullOrEmpty(geoJson))
				{
					throw new Exception("Empty geojson string");
				}
				var fc = new Map.FeatureCollection(geoJson);
			    if (fc.Features == null || fc.Features.Count == 0)
			    {
					throw new Exception();
			    }
				var idDict = new Dictionary<int,string>(fc.Features.Count);
				foreach (var feature in fc.Features)
			    {
					var wkt = feature.Geometry.Wkt;
					if (string.IsNullOrEmpty(wkt) || !feature.Attributes.ContainsKey("TEMPKEY"))
					{
						continue;
					}
				    var tempKey = Convert.ToInt32(feature.Attributes["TEMPKEY"]);
				    var spatialId = 0;
				    if (feature.Attributes.ContainsKey("OBJECTID"))
				    {
						spatialId = Convert.ToInt32(feature.Attributes["OBJECTID"]);
						_mapFacade.CreateShapeInSharedLayer(RuntimeContext.ProviderId, wkt, spatialId);
				    }
				    else
				    {
						spatialId = _mapFacade.CreateShapeInSharedLayer(RuntimeContext.ProviderId, wkt, 0);
				    }
					idDict.Add(tempKey,spatialId.ToString());
			    }
			 	return Json(new {Success = true, Data = idDict});
		    }
		    catch (Exception ex)
		    {
			    LogService.Current.Error(() => ex);
			    return Json(new {Success = false, Message = "Error filling graphic with Id"});
		    }
	    }

		
	    [HttpGet]
        public ActionResult GetShapeLayerDataById(int layerId)
        {
            try
            {
                if (layerId <= 0)
                {
                    return Json(new {Success= false, Message="Invalid Id"});
                }
               
                var shapeNotifications = _mapFacade.GetShapesByLayerId(RuntimeContext.ProviderId, layerId).OrderBy( s => s.Name);
                var features = new List<Feature>();
                var id = 1;
                foreach (var shape in shapeNotifications)
                {
                    if (shape == null || shape.Geometry == null)
                    {
                        continue;
                    }
                    var wkt = shape.Geometry.AsText();
                    if (string.IsNullOrEmpty(wkt))
                    {
                        continue;
                    }
                    var geometry = SqlGeometry.Parse(wkt);
                    IGeometryObject geoObj = MsSqlSpatialConvert.ToGeoJSONGeometry(geometry);
                    var featureProperties = new Dictionary<string, object> { { "NAME", shape.Name }, { "editable", "false" } };
					var model = new Feature(geoObj, featureProperties, shape.Id.ToString());
                    features.Add(model);
                }
                var fc = new FeatureCollection(features);
                return Json(new {Success = true, Data = fc});
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                //TODO: Message in resource
                return Json(new {Success = false, Message = "There was error loading Shape layer data for Id:{0}",layerId});
            }

        }

		
        public JsonResult GetPredefinedZones()
        {
            using (var context = new AtHocDbContext())
            {
                //var rx = new Regex(@"\..*?\s|\..*?\)");
                var zoneLayers = context.MapLayers.Where(x => x.ProviderId == RuntimeContext.ProviderId && x.IsPredefinedZone == "Y" && x.Status != "DEL").ToList();
                var features = new List<Feature>();
                foreach (var zoneLayer in zoneLayers)
                {
                    var zones = zoneLayer.ShapeNotifications.Where(z => z.Geometry.SpatialTypeName == "Polygon" || z.Geometry.SpatialTypeName == "MultiPolygon").ToList();
                    foreach (var zone in zones)
                    {
                        var wkt = zone.Geometry.AsText();
                        //var truncatedWkt = rx.Replace(wkt, new MatchEvaluator(TruncateDigits));
                        //var geometry = SqlGeometry.Parse(truncatedWkt);
                        var geometry = SqlGeometry.Parse(wkt);
                        IGeometryObject geoObj = MsSqlSpatialConvert.ToGeoJSONGeometry(geometry);
                        var featureProperties = new Dictionary<string, object> { { "NAME", zone.Name }, { "editable", "false" } };
                        var model = new Feature(geoObj, featureProperties);
                        features.Add(model);
                    }
                }
                var fc = new FeatureCollection(features);

                return Json(fc);
            }
        }

        public JsonResult GetCountyBoundary()
        {
            using (var context = new AtHocDbContext())
            {
                var boundaryLayers = context.MapLayers.Where(x => x.ProviderId == RuntimeContext.ProviderId && x.Name == "county").ToList();
                var features = new List<Feature>();
                foreach (var boundaryLayer in boundaryLayers)
                {
                    var boundaries = boundaryLayer.ShapeNotifications.Where(z => z.Geometry.SpatialTypeName == "Polygon" || z.Geometry.SpatialTypeName == "MultiPolygon").ToList();
                    foreach (var boundary in boundaries)
                    {
                        var wkt = boundary.Geometry.AsText();
                        //var truncatedWkt = rx.Replace(wkt, new MatchEvaluator(TruncateDigits));
                        //var geometry = SqlGeometry.Parse(truncatedWkt);
                        var geometry = SqlGeometry.Parse(wkt);
                        IGeometryObject geoObj = MsSqlSpatialConvert.ToGeoJSONGeometry(geometry);
                        var featureProperties = new Dictionary<string, object> { { "NAME", boundary.Name }, { "editable", "false" } };
                        var model = new Feature(geoObj, featureProperties);
                        features.Add(model);
                    }
                }
                var fc = new FeatureCollection(features);

                return Json(fc);
            }
        }

        private string GetUserDisplayName(int userId)
        {
            if (userId == 0)
                return string.Empty;
            var user = _userFacade.GetUserBySpec(new UserSpec
            {
                ProviderId = RuntimeContext.ProviderId,
                OperatorId = RuntimeContext.OperatorId,
                CustomFieldFormat = true,
                UserId = userId,
                GetUserAttributes = false
            });
            return user.GetDisplayName();
        }

        [HttpPost]
        public ActionResult GetUserCountByGeo(string geoJson, string targetRelationship = "inside")
        {
            try
            {
                if (string.IsNullOrWhiteSpace(geoJson))
                {
                    return Json(new {selectedUsers = 0});
                }
                var spatialRelation = targetRelationship == "inside"
                    ? CriteriaOperator.IsInsideArea
                    : CriteriaOperator.IsOutsideArea;

                var srchArgs = new UserSearchArgs(true, true, false)
                {
                    ProviderId = RuntimeContext.ProviderId,
                    ProviderCriteria = UserSearchHelper.GetProviderCriteria(RuntimeContext.ProviderId),
                    OperatorCriteria =
                        UserSearchHelper.GetOperatorUserBaseCriteria(RuntimeContext.OperatorId,
                            RuntimeContext.ProviderId),
                };

                srchArgs.Options.EnableSession = true;

                var statusAttributeId = _userFacade.GetStatusAttributeId();
                var statusValueIds = _userFacade.GetStatusValueIds(new[] {"VLD"});
                var statusCriteria = UserSearchHelper.GetUserStatusCriteria(statusAttributeId, statusValueIds);

				var fc = new Map.FeatureCollection(geoJson);
                var numOfPolygon = 0;
                //only user polygon or multipolygon to query
                if (fc.Features == null || fc.Features.Count == 0)
                {
                    return Json(new {selectedUsers = 0});
                }

                var geoCriteriaList = new List<GeoCriteria>();
                foreach (var f in fc.Features)
                {
                    if (f.Geometry.Type == Type.Polygon || f.Geometry.Type == Type.MultiPolygon)
                    {
                        numOfPolygon++;
				        geoCriteriaList.Add(new GeoCriteria(0, spatialRelation, f.Attributes["OBJECTID"].ToString()));
                    }
                }

                if (numOfPolygon == 0)
                {
                    return Json(new {selectedUsers = 0});
                }

                var geoCriteria = UserSearchHelper.GetIncludeGeographyCriteria(geoCriteriaList,
                    RuntimeContext.ProviderId);

                srchArgs.TargetCriteria = geoCriteria & statusCriteria;
                var users = _userFacade.SearchUsersByContext(srchArgs);

                return Json(new {selectedUsers = users.SearchResultCount});
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { selectedUsers = 0 });
            }
        }
    }
}