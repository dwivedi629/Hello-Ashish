﻿using System.Web.Mvc;

namespace AtHoc.IWS.Web.Controllers
{
    [AllowAnonymous]
	public class ErrorController : AtHoc.Infrastructure.Web.Mvc.Controller
    {
        public ActionResult ShowWarningMessage(string msg)
        {
            if (!string.IsNullOrEmpty(msg))
            {
                ViewData["ErrorMessage"] = msg;
            }
            else
            {
                ViewData["ErrorMessage"] = "An unknown error has occurred while processing your request.";
            }
            return View();
            
        }
    }
}
