﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web.Mvc;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Security;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Business.Domain.Publishing.Spec;
using AtHoc.IWS.Business.Domain.Users.Impl;
using AtHoc.IWS.Business.Domain.Users.Impl.Search;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.IWS.Map;
using AtHoc.IWS.Web.Filters;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Web.Models.DistributionLists;
using AtHoc.IWS.Web.Configurations.Constants;
using AtHoc.Global.Resources;
using AtHoc.IWS.Web.Converter.SearchCriteria;
using AtHoc.IWS.Web.Models.SearchCriteria;
using AtHoc.IWS.Web.Converter;
using AtHoc.IWS.Web.Models.UserManager;
using AtHoc.IWS.Web.Helpers;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;
using AtHoc.Infrastructure.Csv.CsvHelper;

namespace AtHoc.IWS.Web.Controllers
{
    [IWSAuthorize(new[] { SystemObject.DistributionLists }, new[] { ActionType.View })]
    public class DistributionListController : Infrastructure.Web.Mvc.Controller
    {
        #region Private Members

        private static IEnumerable<Device> _allDevices;
        private static ILookup<string, Device> _devicesByCommonName;
        private static ILookup<string, Device> _devicesByName;

        private readonly IPublishingFacade _publishingFacade;
        private readonly ICustomAttributeFacade _customAttributeFacade;
        private readonly IUserFacade _userFacade;
        private readonly IAtHocConfigurations _configurations;
        private readonly ISearchCriteriaConverter _searchCriteriaConverter;
        private readonly IIpListConverter _ipListConverter;
        private readonly IUserManagerHelper _userManagerHelper;

        private CustomAttributeLookup _providerAttributes;

        /// <summary>
        /// Returns list of localized custom attributes
        /// </summary>
        private CustomAttributeLookup ProviderAttributes
        {
            get
            {
                var locale = RuntimeContext.Provider.BaseLocale;
                var customAttributes = _providerAttributes ?? (_providerAttributes = RuntimeContext.CustomAttributesWithouMassDevices);
                return new CustomAttributeLookup(customAttributes);
            }
        }

        private enum ListCriteriaType
        {
            AllEntities = -1,
            SelectedEntities = 0,
            ExcludedEntities = 1
        }

        #endregion

        #region Public Members

        public class ListCriteria
        {
            public int CriteriaType { get; set; }
            public List<int> EntityIds { get; set; }
            public DistributionListCriteria SearchCriteria { get; set; }
        }

        #endregion

        #region Constructors

        public DistributionListController(IPublishingFacade publishingFacade, ICustomAttributeFacade customAttributeFacade, IUserFacade userFacade, IAtHocConfigurations configurations, ISearchCriteriaConverter searchCriteriaConverter, IIpListConverter ipListConverter, IUserManagerHelper userManagerHelper)
        {
            _publishingFacade = publishingFacade;
            _customAttributeFacade = customAttributeFacade;
            _userFacade = userFacade;
            _configurations = configurations;
            _searchCriteriaConverter = searchCriteriaConverter;
            _ipListConverter = ipListConverter;
            _userManagerHelper = userManagerHelper;
        }

        #endregion

        #region Get Distribution Lists

        public ActionResult Index()
        {
            //required for top bar highlight
            ViewBag.TopicToHighlight = MenuTopicsId.users;

            var prv = RuntimeContext.Provider;
            var opr = RuntimeContext.Operator;
            ViewBag.IsIpAlertingAllowed = AtHocConfigService.Current.IsIpAlertingAllowed;
            ViewBag.DateFormat = prv.GetDateFormat();
            ViewBag.DateTimeFormat = prv.GetDateTimeFormat();
            var vpsTimeZone = prv.GetVpsTimeZoneFromId();
            ViewBag.VPSTimeZone = vpsTimeZone;
            ViewBag.UtcOffsetInMinutes = vpsTimeZone.BaseUtcOffset.TotalMinutes;
            ViewBag.VPSOffsetFromSystemInMinutes = prv.VPSOffsetFromSystemInMinutes();
            ViewBag.SupportsDaylightSavingTime = vpsTimeZone.SupportsDaylightSavingTime;
            ViewBag.ShowRestrictedUserBaseWarning = _userFacade.HasRestrictedUserBase(RuntimeContext.OperatorId);
            return View();
        }

        [HttpPost]
        public ActionResult GetDistributionList(DistributionListCriteria criteriaSpec)
        {
            try
            {
                var provider = RuntimeContext.Provider;
                var currentUser = RuntimeContext.Operator;
                var distributionListItemSpec = new DistributionListItemSpec
                {
                    ProviderId = provider.Id,
                    UserId = currentUser.Id,
                    IsSystem = false,
                    Page = criteriaSpec.Page,
                    PageSize = UIConfig.GridPageSize,
                    OrderAsc = criteriaSpec.OrderAsc,
                    OrderBy = GetDistributionListItemMetaProperty(criteriaSpec.OrderBy),
                    SearchString = criteriaSpec.SearchString,
                    DistributionListTypes = GetDistributionListTypes(criteriaSpec.DistributionListTypes),
                };

                distributionListItemSpec = FilterNestedDistributionLists(criteriaSpec, distributionListItemSpec);

                var data = _publishingFacade.GetDistributionListItemsPage(distributionListItemSpec);
                return Json(new { Data = data, PageSize = UIConfig.GridPageSize });
            }
            catch (Exception)
            {
                return Json(new { Error = IWSResources.DistributionList_Error_Loading_DistributionList });
            }
        }

        [HttpPost]
        public ActionResult GetDistributionListById(int id)
        {
            var provider = RuntimeContext.Provider;
            var currentUser = RuntimeContext.Operator;

            var spec = new DistributionListSpec { Id = id, ProviderId = provider.Id, IncludeParentChildren = true, OperatorId = currentUser.Id };
            var distribution = _publishingFacade.GetDistributionLists(spec).FirstOrDefault();
            var ipList = new List<IpModel>();
            var nestedIds = new List<int>();
            SearchCriteriaModel dynamicCriteriaModel = null;
            var error = string.Empty;
            var totalUsersCount = 0;
            var showOverrideWarning = false;

            if (distribution != null)
            {
                var updatedBy =
                    _userFacade.GetUserBySpec(new UserSpec
                    {
                        UserId = distribution.UpdatedBy,
                        EnabledUsersOnly = false,
                    });

                var createdBy =
                   _userFacade.GetUserBySpec(new UserSpec
                   {
                       UserId = distribution.CreatedBy,
                       EnabledUsersOnly = false,
                   });

                var searchCriteria = new DistributionListCriteria
                {
                    DistributionListTypes = new[] { (int)ListItemType.Static },
                    IsInclude = false,
                    ListIds = nestedIds.ToArray()
                };

                var criteria = new ListCriteria
                {
                    CriteriaType = (int)ListCriteriaType.AllEntities,
                    EntityIds = null,
                    SearchCriteria = searchCriteria
                };

                var userCount = 0;
                var userBaseCount = 0;
                var ipListCsv = string.Empty;
                var userIds = new List<int>();

                if (distribution.ListType == ListItemType.Static)
                {
                    var userSearchResult = _publishingFacade.GetDistributionListUserSearchResult(RuntimeContext.CustomAttributes, spec, RuntimeContext.Provider.BaseLocale);
                    //Total users in static DL

                    userCount = userSearchResult.SearchResultCount;
                    userBaseCount = userSearchResult.UserBaseCount;

                    nestedIds = _publishingFacade.GetStaticListFirstLevelChildIds(new DistributionListSpec { Id = distribution.Id, OperatorId = RuntimeContext.Operator.Id, ProviderId = RuntimeContext.Provider.Id }).ToList();

                    totalUsersCount = nestedIds.Count > 0 ? _publishingFacade.GetDistributionListUserSearchResult(RuntimeContext.CustomAttributes, spec, RuntimeContext.Provider.BaseLocale, true).SearchResultCount:userCount;
                    
                    if (updatedBy != null)
                    {
                        showOverrideWarning = (updatedBy.Id != RuntimeContext.OperatorId) && ShowOverrideWarning(updatedBy.Id);
                    }
                }
                else if (distribution.ListType == ListItemType.Ip)
                {
                    //Load List of IPs 
                    try
                    {
                        if (!string.IsNullOrWhiteSpace(distribution.Definition))
                        {
                            ipList = _ipListConverter.GetIPModelsFromXML(distribution.Definition);
                            ipListCsv = _ipListConverter.GetCsvForIpList(ipList);
                        }
                    }
                    catch
                    {
                        error = "Error loading IP Addresses.";
                    }

                }
                else if (distribution.ListType == ListItemType.Dynamic)
                {
                    try
                    {
                        if (!string.IsNullOrWhiteSpace(distribution.Definition) && distribution.FromSubProvider != "Y")
                        {
                            var parser = new CriteriaListParser(RuntimeContext.CustomAttributes, distribution.Definition);
                            dynamicCriteriaModel = _searchCriteriaConverter.GetSearchCriteriaModel(parser.Parse());

                            var customCriteria = UserSearchHelper.GetCustomCriteria(GetCustomCriteriaFromDefinition(distribution.Definition));

                            var statusAttributeId = _userFacade.GetStatusAttributeId();
                            var statusValueIds = _userFacade.GetStatusValueIds(new[] { "VLD", "DSB" });
                            var statusCriteria = UserSearchHelper.GetUserStatusCriteria(statusAttributeId, statusValueIds);

                            var userSearchV2 = new UserSearchArgs(true, true, false)
                            {
                                ProviderId = RuntimeContext.ProviderId,
                                ProviderCriteria = UserSearchHelper.GetProviderCriteria(RuntimeContext.ProviderId),
                                OperatorCriteria = UserSearchHelper.GetOperatorUserBaseCriteria(RuntimeContext.OperatorId, RuntimeContext.ProviderId),
                                TargetCriteria = customCriteria & statusCriteria,
                            };

                            userCount = _userFacade.SearchUsersByContext(userSearchV2).SearchResultCount;
                        }
                    }
                    catch (Exception)
                    {
                        error = "Error loading Criteria, criteria values are invalid or not supported.";
                    }
                }

                var notNestedCount = GetNotNestedListIds(criteria, id, nestedIds);

                var data = new DistributionModel
                {
                    Id = distribution.Id,
                    Name = distribution.Name,
                    CommonName = distribution.CommonName,
                    Description = distribution.Description,
                    ListType = (int)distribution.ListType,
                    ListTypeDisplay = LocalizedListType(distribution.ListType),
                    Lineage = distribution.Lineage,
                    IsCascaded = (distribution.FromSubProvider == "Y"),
                    IsAvailableForMap = distribution.IsAvailableForMap,

                    UserCount = userCount,
                    TotalUsersCount = totalUsersCount,
                    UserBaseCount = userBaseCount,
                    Nested = nestedIds.ToArray(),
                    NotNestedCount = notNestedCount,
                    EditLevel = (int)distribution.EditLevel,
                    TemporaryStaticDLId = 0,

                    Users = userIds,

                    DynamicCriteria = dynamicCriteriaModel,

                    IPList = ipList,
                    IPAddressesCSV = ipListCsv,

                    UpdatedBy = updatedBy == null ? IWSResources.User_Unknown : updatedBy.GetDisplayName(),
                    CreatedBy = createdBy == null ? IWSResources.User_Unknown : createdBy.GetDisplayName(),
                    UpdatedOn = (distribution.UpdatedOn.HasValue) ? provider.GetVpsDateTimeFromSecondsFormated(distribution.UpdatedOn.Value) : string.Empty,
                    CreatedOn = (distribution.CreatedOn.HasValue) ? provider.GetVpsDateTimeFromSecondsFormated(distribution.CreatedOn.Value) : string.Empty,

                    ShowOverrideWarning = showOverrideWarning
                };
                return Json(new { Data = data, Success = true, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }) });
            }

            return Json(new { Error = IWSResources.DistributionList_Error_Loading_Distribution });
        }

        #endregion

        private string LocalizedListType(ListItemType enumType)
        {
            string displayType = string.Empty;
            switch (enumType)
            {
                case ListItemType.Dynamic:
                    displayType = IWSResources.DistributionList_Index_ListType_Dynamic;
                    break;
                case ListItemType.Static:
                    displayType = IWSResources.DistributionList_Index_ListType_Static;
                    break;
                case ListItemType.Ip:
                    //(distribution.ListType == ListItemType.Ip ? distribution.ListType.ToString().ToUpper() : distribution.ListType.ToString())
                    displayType = IWSResources.DistributionList_Index_ListType_IP.ToString().ToUpper();
                    break;
                case ListItemType.Tree:
                    displayType = IWSResources.DistributionList_Index_ListType_Tree;
                    break;
                //default:
                //    break;
            }
            return displayType;
        }

        #region Update Distribution List Members

        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.DistributionLists }, new[] { ActionType.Modify })]
        public JsonResult UpdateMemberForStaticList(int distributionId, int tempId, bool isAdd, UsersStatusCriteria model)
        {
            try
            {
                _userManagerHelper.RefreshDevices(ref _allDevices, ref _devicesByCommonName, ref _devicesByName, true);

                var srchArgsV2 = GetUserSrchArgsForDistributionListV2(distributionId, tempId, isAdd, model);

                var updateIds = new List<int>();
                if (model != null)
                {
                    if (model.CriteriaType == (int)Models.UserManager.ListCriteriaType.USER_LIST)
                    {
                        updateIds.AddRange(model.EntityIds);
                    }

                    if (model.CriteriaType == (int)Models.UserManager.ListCriteriaType.EXCEPTION_LIST)
                    {
                        var allUsersIds = _userFacade.SearchUsersByContext(srchArgsV2).Users.Select(u => u.Id);
                        updateIds.AddRange(allUsersIds.Except(model.EntityIds));
                    }

                    if (model.CriteriaType == (int)Models.UserManager.ListCriteriaType.ALL_USERS)
                    {
                        var allUsersIds = _userFacade.SearchUsersByContext(srchArgsV2).Users.Select(u => u.Id);
                        updateIds.AddRange(allUsersIds);
                    }
                }
                int count;
                var newId = UpdateTemporaryStaticDl(distributionId, tempId, updateIds.ToList(), isAdd, out count);
                return Json(new { Success = true, TemporaryStaticListId = newId, UserCount = count });
            }
            catch (Exception)
            {
                return Json(new { Success = false, Error = "Error adding/removing members to distribution list." });
            }

        }

        #endregion

        #region Update Distribution List Nesting

        /// <summary>
        /// Adds or removes nested static lists to the current list
        /// </summary>
        [HttpPost]
        public ActionResult GetDistributionListSelectionIds(ListCriteria criteria, int currentListId, List<int> nestedListsIds, bool isAddSelected)
        {
            try
            {
                var nestedLists = new List<int>();

                if (currentListId > 0)
                {
                    nestedLists.Add(currentListId);
                }

                nestedLists.AddRange(nestedListsIds);

                IEnumerable<int> listIds;

                if (isAddSelected)
                {
                    //API for listid's where the current list is the memberof
                    var currentDistributionListSpec = new DistributionListSpec
                    {
                        Id = currentListId,
                        OperatorId = RuntimeContext.Operator.Id,
                        ProviderId = RuntimeContext.Provider.Id
                    };

                    var excludeListIds = new List<int>();
                    var memberOfListIds = _publishingFacade.GetStaticListParentIds(currentDistributionListSpec, true);
                    excludeListIds.AddRange(memberOfListIds);

                    //var chieldMemberListIds = _publishingFacade.GetStaticListChildIds(currentDistributionListSpec, true);
                    //excludeListIds.AddRange(chieldMemberListIds);

                    nestedLists.AddRange(excludeListIds);

                    listIds = GetSelectedListIds(criteria);
                    listIds = listIds.Except(nestedLists);
                }
                else
                {
                    if (criteria.CriteriaType == (int)ListCriteriaType.SelectedEntities)
                        listIds = criteria.EntityIds;
                    else if (criteria.CriteriaType == (int)ListCriteriaType.ExcludedEntities)
                    {
                        listIds = GetSelectedListIds(criteria);
                    }
                    else
                        listIds = nestedListsIds;
                }

                return Json(new { Success = true, Data = listIds });
            }
            catch (Exception)
            {
                return Json(new { Success = false, Error = IWSResources.DistributionList_Error_Loading_DistributionList });
            }
        }

        #endregion

        #region Save Distribution Lists

        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.DistributionLists }, new[] { ActionType.Modify })]
        public ActionResult SaveDistributionList(DistributionModel data)
        {
            try
            {
                if (data.Name.IndexOfAny(Constants.InvalidDLCharacterSet.ToCharArray()) != -1)
                {
                    return Json(new
                    {
                        Success = false,
                        Messages = new Messages(new Message { Type = MessageType.Error, Value = IWSResources.DistributionList_Pattern_Message })
                    });
                }
                else
                {
                    var provider = RuntimeContext.Provider;

                    var distributionList = (data.Id != 0) ? _publishingFacade.GetDistributionList(new DistributionListSpec { Id = data.Id, OperatorId = RuntimeContext.Operator.Id, ProviderId = RuntimeContext.Provider.Id }) : new DistributionList();

                    //all the new distribution lists created should have this flag set otherwise, its inserting as null in DB
                    if (data.Id == 0)
                        distributionList.FromSubProvider = "N";
                    distributionList.ListType = (ListItemType)data.ListType;
                    distributionList.Name = data.Name;
                    distributionList.CommonName = data.CommonName;
                    distributionList.Description = data.Description;
                    distributionList.EditLevel = data.EditLevel;
                    distributionList.IsAvailableForMap = data.IsAvailableForMap;
                    distributionList.ProviderId = RuntimeContext.Provider.Id;

                    if (!data.Lineage.HasValue())
                        data.Lineage = "/";

                    distributionList.Lineage = data.Lineage;

                    var userIds = Enumerable.Empty<int>();
                    if (distributionList.ListType == ListItemType.Ip)
                    {
                        try
                        {
                            var ipList = _ipListConverter.GetIpListForCsv(data.IPAddressesCSV);
                            distributionList.Definition = _ipListConverter.GetXmlStringFromIPList(ipList);

                            var orgHierarchy = _userFacade.GetHierarchyBySpec(new HierarchySpec { ProviderId = provider.Id, HierarchyType = HierarchyType.LOC, AvailableForLists = true, BaseLocale = provider.BaseLocale }).First();
                            distributionList.HierarchyId = orgHierarchy.Id;
                        }
                        catch (InvalidIPAddress ipException)
                        {
                            return Json(new { Success = false, Messages = new Messages(new Message { Type = MessageType.Error, Value = ipException.Message }) });
                        }
                    }
                    else if (distributionList.ListType == ListItemType.Dynamic)
                    {
                        if (data.DynamicCriteria != null && data.DynamicCriteria.selections.HasValue())
                        {
                            var criteriaList = _searchCriteriaConverter.GetAttributeCriteriaPrameter(data.DynamicCriteria.selections);
                            distributionList.Definition = AttrCriteria.ToCriteriaString(criteriaList);
                        }
                        else
                            distributionList.Definition = string.Empty;

                        if (distributionList.FromSubProvider != "Y" && string.IsNullOrWhiteSpace(distributionList.Definition))
                        {
                            throw new ApplicationException(IWSResources.DistributionList_EmptyDynamicCondition_Error);
                        }
                    }
                    else if (distributionList.ListType == ListItemType.Static)
                        userIds = GetStaticListUsers(data.GetStaticListIdToSave());

                    if (distributionList.ListType != ListItemType.Ip)
                    {
                        var orgHierarchy = _userFacade.GetHierarchyBySpec(new HierarchySpec { ProviderId = provider.Id, HierarchyType = HierarchyType.ORG, AvailableForLists = true, BaseLocale = provider.BaseLocale }).First();
                        distributionList.HierarchyId = orgHierarchy.Id;
                    }

                    var result = _publishingFacade.SaveDistributionList(
                        new DistributionListSaveSpec
                        {
                            List = distributionList,
                            UserIds = userIds,
                            OperatorId = RuntimeContext.Operator.Id,
                            ChildListsIds = data.Nested,
                            UserId = RuntimeContext.Operator.Id,
                            ProviderId = RuntimeContext.Provider.Id,
                            BaseLocale = RuntimeContext.Provider.BaseLocale
                        }
                    );



                    if (data.TemporaryStaticDLId != 0 && result.IsValid)
                        DeleteTemporaryStaticDl(data.TemporaryStaticDLId);

                    if (result.IsValid)
                        return Json(new { Success = true, distributionList.Id });


                    return Json(new { Success = false, Messages = result.Messages.Where(m => m.Type == MessageType.Error).ToList() });
                }
            }
            catch (Exception ex)
            {
                return Json(new { Success = false, Messages = new Messages(new Message { Type = MessageType.Error, Value = ex.Message }) });
            }
        }

        #endregion

        #region Dynamic List Count
        public JsonResult GetDynamicDistributionUserCount(SearchCriteriaModel model)
        {
            try
            {
                var count = 0;

                if (model.selections != null)
                {
                    ExpressionElement customCriteria = null;
                    var srchArgsV2 = new UserSearchArgs(false, true, false, 1, 10, "LOGIN_ID", "ASC")
                    {
                        DeviceNames = null,
                        AttributeNames = new List<string> { "LOGIN_ID" },
                        ProviderId = RuntimeContext.ProviderId,
                        ProviderCriteria = UserSearchHelper.GetProviderCriteria(RuntimeContext.ProviderId),
                        OperatorCriteria = UserSearchHelper.GetOperatorUserBaseCriteria(RuntimeContext.OperatorId, RuntimeContext.ProviderId)
                    };

                    foreach (var selection in model.selections)
                    {
                        var criteria = new GenericCriteria(selection.entity.entityType, selection.entity.id, selection.operand);

                        switch (selection.entity.dataType)
                        {
                            case "Picklist":
                            case "MultiPicklist":
                            case "Checkbox":
                                criteria.Value = (selection.operand == 11 || selection.operand == 12)
                                    ? "0"
                                    : selection.value.Aggregate("", (current, value) => current + value.id + ",").TrimEnd(',');
                                break;
                            case "Number":
                            case "String":
                            case "Memo":
                            case "Date":
                            case "DateTime":
                                criteria.Value = selection.value.Aggregate("", (current, value) => current + value.text + ",").TrimEnd(',');
                                break;
                            case "Path":
                                criteria.Value = selection.value.Aggregate("", (current, value) => current + value.lineage + ",").TrimEnd(',');
                                break;
                            case "GeoLocation":
                                var fc = new FeatureCollection(selection.value[0].text);
                                if (fc.Features != null && fc.Features.Count > 0)
                                {
                                    foreach (var f in fc.Features)
                                    {
                                        if (f.Geometry.Type == Map.Geometry.Type.Polygon || f.Geometry.Type == Map.Geometry.Type.MultiPolygon)
                                        {
                                            criteria = new AttributeCriteria(selection.entity.id, selection.operand, f.Attributes["OBJECTID"].ToString());
                                        }
                                    }
                                }
                                break;
                            case "AttributeValue":
                            case "Device":
                            case "Entity":
                            case "Object":
                            case "Unknown":
                            default:
                                throw new Exception("Not Implemented");
                        }
                        customCriteria = customCriteria == null ? criteria : customCriteria & criteria;
                    }

                    var statusAttribute = ProviderAttributes.GetByCommonName(AttributeCommonNames.Status);
                    var customAttributeValueCache = new CustomAttributeValueCache();
                    var customAttributeValueDictionary = customAttributeValueCache.Get(RuntimeContext.ProviderId, RuntimeContext.Provider.BaseLocale);
                    var statusValues = customAttributeValueDictionary.GetByCommonNames("VLD,DSB").Select(x => x.ValueId);
                    var statusCriteria = UserSearchHelper.GetUserStatusCriteria(statusAttribute.Id, statusValues);

                    srchArgsV2.TargetCriteria = customCriteria & statusCriteria;
                    count = _userFacade.SearchUsersByContext(srchArgsV2).SearchResultCount;

                    return Json(new { Success = true, UserCount = count });
                }

                return Json(new { Success = true, UserCount = count });
            }
            catch (Exception)
            {
                return Json(new { Success = false, Messages = new Messages(new Message { Type = MessageType.Error, Value = "Error processing criteria." }) });
            }
        }

        //public JsonResult GetDynamicDistributionUserCountV2(SearchCriteriaModel model)
        //{
        //    try
        //    {
        //        var count = 0;

        //        if (model.selections != null)
        //        {
        //            ExpressionElement customCriteria = null;
        //            foreach (var selection in model.selections)
        //            {
        //                var criteria = new GenericCriteria(selection.entity.entityType, selection.entity.id, selection.operand, selection.value.Aggregate("", (current, value) => current + value.entityType == "HIERARCHY" ? value.lineage : (value.id == -1 ? value.text : value.id.ToString(CultureInfo.InvariantCulture)) + ","));
        //                customCriteria = customCriteria == null ? criteria : customCriteria | criteria;
        //            }

        //            return Json(new { Success = true, UserCount = count });
        //        }

        //        return Json(new { Success = true, UserCount = count });
        //    }
        //    catch (Exception)
        //    {
        //        return Json(new { Success = false, Messages = new Messages(new Message { Type = MessageType.Error, Value = "Error processing criteria." }) });
        //    }
        //}
        #endregion

        #region Delete Destribution Lists

        /// <summary>
        /// Before deleting a list, this method gets lists in which the selected list(s) is/are nested
        /// </summary>
        [HttpPost]
        public ActionResult GetDistributionListDependencies(ListCriteria criteria)
        {
            try
            {
                IList<int> listIds = GetSelectedListIds(criteria).ToArray();
                var result = _publishingFacade.GetDistributionListDependencyResult(new DistributionListDependencySpec { ListIds = listIds });

                var listWithDependencies = result.Dependencies.GroupBy(dependencyItem => dependencyItem.ListId)
                       .Select(item => item.First().ListId).ToList();

                var independentListIds = listIds.Except(listWithDependencies);

                return Json(new { result, independentListIds });
            }
            catch (Exception)
            {
                return Json(new { Error = "Unable to get the dependencies for the distribution lists" });
            }
        }

        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.DistributionLists }, new[] { ActionType.Modify })]
        public ActionResult DeleteDistributionLists(int[] ids)
        {
            try
            {
                //TODO have to handle the return message - pending
                _publishingFacade.DeleteDistributionList(new DistributionListSpec
                {
                    Ids = ids,
                    OperatorId = RuntimeContext.Operator.Id,
                    UserId = RuntimeContext.Operator.Id,
                    ProviderId = RuntimeContext.Provider.Id
                });
                return Json("success");
            }
            catch (Exception)
            {
                return Json(new { Error = IWSResources.DistributionList_Error_Deleting_DistributionList });
            }
        }

        #endregion

        #region Private Methods

        private DistributionListItemSpec FilterNestedDistributionLists(DistributionListCriteria criteriaSpec, DistributionListItemSpec distributionListItemSpec)
        {
            var provider = RuntimeContext.Provider;
            var currentUser = RuntimeContext.Operator;

            if (criteriaSpec.IsInclude)
                distributionListItemSpec.ListIds = criteriaSpec.ListIds;
            else
                distributionListItemSpec.ExcludeIds = criteriaSpec.ListIds;

            if (criteriaSpec.CurrentId != 0)
            {

                //TODO - check if the api is returning the excluded listid's where the underlying listid is a member of
                var currentDistributionListSpec = new DistributionListSpec
                {
                    ProviderId = provider.Id,
                    OperatorId = RuntimeContext.Operator.Id,
                    UserId = currentUser.Id,
                    Id = criteriaSpec.CurrentId
                };

                var excludeListIds = new List<int>();
                var memberOfListIds = _publishingFacade.GetStaticListParentIds(currentDistributionListSpec, true);
                excludeListIds.AddRange(memberOfListIds);

                //var chieldMemberListIds = _publishingFacade.GetStaticListChildIds(currentDistributionListSpec, true);
                //excludeListIds.AddRange(chieldMemberListIds);

                if (distributionListItemSpec.ExcludeIds.HasValue())
                    excludeListIds.AddRange(distributionListItemSpec.ExcludeIds.ToList());

                //Also have to avoid the underlying listId also
                excludeListIds.Add(criteriaSpec.CurrentId);

                if (!criteriaSpec.IsInclude)
                    distributionListItemSpec.ExcludeIds = excludeListIds;
            }

            return distributionListItemSpec;
        }

        private IEnumerable<ListItemType> GetDistributionListTypes(IEnumerable<int> listTypeIds)
        {
            var list = new List<ListItemType>();
            if (listTypeIds != null)
            {
                foreach (var listTypeId in listTypeIds)
                {
                    var listValue = (ListItemType)Enum.GetValues(typeof(ListItemType)).GetValue(listTypeId);
                    if (listValue != ListItemType.Ip || AtHocConfigService.Current.IsIpAlertingAllowed)
                    {
                        list.Add(listValue);
                    }
                }
            }
            return list;
        }

        private Infrastructure.Meta.MetaProperty GetDistributionListItemMetaProperty(string columnName)
        {
            switch (columnName)
            {
                case "name":
                    return DistributionListItem.Meta.Name;
                case "type":
                    return DistributionListItem.Meta.ListType;
                case "folder":
                    return DistributionListItem.Meta.Lineage;
                case "virtualSystem":
                    return DistributionListItem.Meta.ProviderName;
                default:
                    return null;
            }
        }

        private DistributionListItemSpec GetDistributionListSearchSpec(DistributionListCriteria criteria)
        {

            if (criteria != null)
            {
                DistributionListItemSpec distributionListItemSpec = new DistributionListItemSpec();
                var provider = RuntimeContext.Provider;
                var currentUser = RuntimeContext.Operator;

                distributionListItemSpec.ProviderId = provider.Id;
                distributionListItemSpec.UserId = currentUser.Id;
                distributionListItemSpec.IsSystem = false;
                distributionListItemSpec.SearchString = criteria.SearchString;
                distributionListItemSpec.DistributionListTypes = GetDistributionListTypes(criteria.DistributionListTypes);
                if (criteria.IsInclude)
                {
                    distributionListItemSpec.ListIds = criteria.ListIds;
                }
                else
                {
                    distributionListItemSpec.ExcludeIds = criteria.ListIds;
                }

                return distributionListItemSpec;
            }
            return null;

        }

        private IEnumerable<int> GetSelectedListIds(ListCriteria model)
        {
            if (model != null)
            {
                if (model.CriteriaType == (int)ListCriteriaType.SelectedEntities)
                {
                    return model.EntityIds;
                }

                if (model.CriteriaType == (int)ListCriteriaType.ExcludedEntities)
                {
                    var allUserIds = _publishingFacade.GetDistributionListIds(GetDistributionListSearchSpec(model.SearchCriteria));
                    return allUserIds.Except(model.EntityIds);
                }

                if (model.CriteriaType == (int)ListCriteriaType.AllEntities)
                {
                    var allUserIds = _publishingFacade.GetDistributionListIds(GetDistributionListSearchSpec(model.SearchCriteria));
                    return allUserIds;
                }
            }
            return Enumerable.Empty<int>();
        }

        private int GetNotNestedListIds(ListCriteria criteria, int id, IEnumerable<int> nestedIds)
        {
            try
            {
                var nestedLists = new List<int>();

                if (id > 0)
                {
                    nestedLists.Add(id);
                }

                nestedLists.AddRange(nestedIds);

                //API for listid's where the current list is the memberof
                var currentDistributionListSpec = new DistributionListSpec { Id = id, OperatorId = RuntimeContext.Operator.Id, ProviderId = RuntimeContext.Provider.Id };

                var excludeListIds = new List<int>();
                var memberOfListIds = _publishingFacade.GetStaticListParentIds(currentDistributionListSpec, true);
                excludeListIds.AddRange(memberOfListIds);

                //var chieldMemberListIds = _publishingFacade.GetStaticListChildIds(currentDistributionListSpec, true);
                //excludeListIds.AddRange(chieldMemberListIds);

                nestedLists.AddRange(excludeListIds);
                IEnumerable<int> listIds = GetSelectedListIds(criteria);
                listIds = listIds.Except(nestedLists);

                return listIds.Count();
            }
            catch (Exception)
            {
                return 0;
            }
        }

        private UserSearchArgs GetUserSrchArgsForDistributionListV2(int distributionId, int tempId, bool isAdd, UsersStatusCriteria model)
        {
            var srchArgs = new UserSearchArgs(false, true, false)
            {
                ProviderCriteria = UserSearchHelper.GetProviderCriteria(RuntimeContext.ProviderId),
                OperatorCriteria = UserSearchHelper.GetOperatorUserBaseCriteria(RuntimeContext.OperatorId, RuntimeContext.ProviderId),
                ProviderId = RuntimeContext.ProviderId,
                Paging = { PageNo = 1, IsAsc = true, SortColumn = "", UsersPerPage = int.MaxValue }
            };

            if (model.SearchCriteria.searchStrings != null)
            {
                srchArgs.TargetCriteria = UserSearchHelper.GetQuickSearchCriteria(RuntimeContext.ProviderId, RuntimeContext.Provider.BaseLocale, model.SearchCriteria.searchStrings);
            }

            var customCriteria = new List<GenericCriteria>();
            if (distributionId != 0)
            {
                var dl = _publishingFacade.GetDistributionList(new DistributionListSpec { Id = tempId != 0 ? tempId : distributionId });
                var attribtueCriteria = new AttributeCriteria(Int32.Parse(dl.Definition), CriteriaOperator.Equals, isAdd ? 0 : 1);
                customCriteria.Add(attribtueCriteria);
            }

            if (!string.IsNullOrEmpty(model.SearchCriteria.queryCriteria))
            {
                customCriteria.AddRange(UserManagerController.InitializeAdvancedSearch(model.SearchCriteria.queryCriteria)); // ADVANCED SEARCH CRITERIA (AND to DL criteria)
            }

            foreach (var attributeId in model.SearchCriteria.attributeIds ?? new int[] { }) customCriteria.Add(new AttributeCriteria(attributeId, CriteriaOperator.IsNotEmpty, 0));
            var attributesDictionary = _userManagerHelper.GetAttributeIdsByValueIds(model.SearchCriteria.attributeValueIds ?? new int[] { });
            foreach (var attributeId in attributesDictionary.Keys) customCriteria.Add(new AttributeCriteria(attributeId, CriteriaOperator.Equals, attributesDictionary[attributeId].Join(",")));

            // USERIDs INCLUDE OR EXCLUDE
            if (model.SearchCriteria.userIds != null) srchArgs.TargetUsers = model.SearchCriteria.userIds.ToList();
            if (model.SearchCriteria.includeUserIds != null) srchArgs.TargetUsers = model.SearchCriteria.includeUserIds.ToList();
            if (model.SearchCriteria.excludeUserIds != null) srchArgs.BlockUsers = model.SearchCriteria.excludeUserIds.ToList();

            var providerDetails = RuntimeContext.Provider;
            // HIERARCHIES TO INCLUDE (NODES : Organizational Hierarchy, Distribution Lists)
            if (model.SearchCriteria.hierarchyIds != null)
                srchArgs.TargetCriteria = UserSearchHelper.GetHierarchyCriteria(providerDetails.Id, providerDetails.BaseLocale,
                    model.SearchCriteria.hierarchyIds);

            // LISTS TO INCLUDE (Dynamic Lists, Static Lists, Tree)
            if (model.SearchCriteria.listItemIds != null)
                srchArgs.TargetCriteria = srchArgs.TargetCriteria |
                                            UserSearchHelper.GetListCriteria(RuntimeContext.ProviderId,
                                                model.SearchCriteria.listItemIds);

            if (model.SearchCriteria.isOperator)
            {
                srchArgs.TargetCriteria = srchArgs.TargetCriteria & UserSearchHelper.GetUserOperatorCriteria(model.SearchCriteria.isOperator);
            }

            var statusAttributeId = _userFacade.GetStatusAttributeId();
            var status = new List<string> { "VLD" };
            if (!model.SearchCriteria.isEnabled) status.Add("DSB");
            var statusValueIds = _userFacade.GetStatusValueIds(status.ToArray());
            var statusCriteria = UserSearchHelper.GetUserStatusCriteria(statusAttributeId, statusValueIds);

            srchArgs.TargetCriteria = srchArgs.TargetCriteria & UserSearchHelper.GetCustomCriteria(new[] { customCriteria }) & statusCriteria;

            return srchArgs;
        }

        private int UpdateTemporaryStaticDl(int distributionId, int tempId, List<int> updateUserIds, bool isAdd, out int count)
        {
            _userManagerHelper.RefreshDevices(ref _allDevices, ref _devicesByCommonName, ref _devicesByName, true);

            var provider = RuntimeContext.Provider;
            var currentUser = RuntimeContext.Operator;

            DistributionList distributionList;
            var userIds = new List<int>();

            if (!updateUserIds.HasValue())
            {
                updateUserIds = new List<int>();
            }

            if (tempId == 0)
            {
                distributionList = new DistributionList();

                if (distributionId != 0)
                {
                    var existingIds = GetStaticListUsers(distributionId);
                    userIds.AddRange(existingIds);
                }
            }
            else
            {
                var spec = new DistributionListSpec { Id = tempId, ProviderId = provider.Id, OperatorId = currentUser.Id };
                distributionList = _publishingFacade.GetDistributionList(new DistributionListSpec { Id = tempId, ProviderId = provider.Id, OperatorId = currentUser.Id });
                userIds = _publishingFacade.GetDistributionListUsersIds(RuntimeContext.CustomAttributes, spec, RuntimeContext.Provider.BaseLocale).ToList();
            }

            if (isAdd)
            {
                userIds.AddRange(updateUserIds);
            }
            else
            {
                foreach (var id in updateUserIds)
                    userIds.Remove(id);
            }


            userIds = userIds.Distinct().ToList();
            count = userIds.Count();

            distributionList.IsSystem = "Y";
            var orgHierarchy = _userFacade.GetHierarchyBySpec(new HierarchySpec { ProviderId = provider.Id, HierarchyType = HierarchyType.ORG, AvailableForLists = true, BaseLocale = provider.BaseLocale }).First();
            distributionList.HierarchyId = orgHierarchy.Id;
            distributionList.Name = "TEMP_STATIC_DL_" + RuntimeContext.Operator.Id + '_' + provider.SystemToVpsTime(new DateTime(DateTime.Now.Ticks, DateTimeKind.Unspecified));
            distributionList.CommonName = "TEMP_STATIC_DL_" + RuntimeContext.Operator.Id + '_' + provider.SystemToVpsTime(new DateTime(DateTime.Now.Ticks, DateTimeKind.Unspecified));
            distributionList.ListType = ListItemType.Static;
            distributionList.Lineage = "/";
            distributionList.ProviderId = provider.Id;


            _publishingFacade.SaveDistributionList(
                   new DistributionListSaveSpec
                   {
                       List = distributionList,
                       UserIds = userIds,
                       OperatorId = RuntimeContext.Operator.Id,
                       ChildListsIds = new List<int>(),
                       UserId = RuntimeContext.Operator.Id,
                       ProviderId = RuntimeContext.Provider.Id,
                       BaseLocale = RuntimeContext.Provider.BaseLocale
                   }
               );
            return distributionList.Id;
        }

        private void DeleteTemporaryStaticDl(int id)
        {
            try
            {
                var provider = RuntimeContext.Provider;
                var spec = new DistributionListSpec { Ids = new[] { id }, OperatorId = RuntimeContext.Operator.Id, ProviderId = provider.Id };
                _publishingFacade.DeleteDistributionList(spec, true);
            }
            catch (Exception)
            {
            }
        }

        private IEnumerable<int> GetStaticListUsers(int id)
        {
            if (id == 0) return Enumerable.Empty<int>();
            var spec = new DistributionListSpec { Id = id, ProviderId = RuntimeContext.ProviderId, OperatorId = RuntimeContext.OperatorId };
            return _publishingFacade.GetDistributionListUsersIds(RuntimeContext.CustomAttributes, spec, RuntimeContext.Provider.BaseLocale).ToArray();
        }

        public static IEnumerable<List<GenericCriteria>> GetCustomCriteriaFromDefinition(string definition)
        {
            var customCriterias = new List<List<GenericCriteria>>();

            var orLines = definition.Split(new[] { Environment.NewLine }, StringSplitOptions.None);

            foreach (var orLine in orLines)
            {
                var andLines = orLine.Split('^');

                var customCriteria = new List<GenericCriteria>();

                foreach (var andLine in andLines)
                {
                    var data = andLine.Split('!');

                    var type = data[0].Split('-')[0];
                    var id = Int32.Parse(data[0].Split('-')[1]);
                    var opr = Int32.Parse(data[1]);
                    var value = data[2];

                    customCriteria.Add(new GenericCriteria(type, id, opr, value));
                }

                customCriterias.Add(customCriteria);
            }

            return customCriterias;
        }

        private bool ShowOverrideWarning(int lastUpdatedById)
        {
            //need to check if logged in operator has restriction
            if (!_userFacade.HasRestrictedUserBase(RuntimeContext.OperatorId)) return false;

            //if yes, check if both have same userbase or not
            var isOperatorUserbaseSame = _userFacade.HasSameUserBase(lastUpdatedById, RuntimeContext.OperatorId);
            return !isOperatorUserbaseSame;
        }

        #endregion

        #region Import Users

        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.DistributionLists }, new[] { ActionType.Modify })]
        public JsonResult ImportUsers(FormCollection form)
        {
            int distibutionId = Convert.ToInt32(form["distributionId"]);
            int tempId = Convert.ToInt32(form["tempId"]);
            var currentOperator = RuntimeContext.Operator;

            var fileName = "DL_Import_User_" + currentOperator.Id + "_" + DateTime.Now.ToString("MM_dd_yyy_hh_mm_ss_fff");

            var directoryLocation = _configurations.FilesBasePath + Constants.ImportFileUploadPath;

            var savePath = directoryLocation + fileName;
            try
            {
                if (Request.Files.Count <= 0)
                {
                    return Json(new { Success = false, Error = IWSResources.DistributionList_Error_ImportUser_InvalidFileFormat }, "text/plain");
                }

                var file = Request.Files[0];
                var acceptedExtensions = new[] { ".csv" };
                if (!acceptedExtensions.Contains(Path.GetExtension(file.FileName)))
                {
                    return Json(new { Success = false, Error = IWSResources.DistributionList_Error_ImportUser_InvalidFile }, "text/plain");
                }

                file.SaveAs(savePath);
                #region Parse CSV
                var userList = new List<string>();
                var textReader = new StreamReader(new MemoryStream(System.IO.File.ReadAllBytes(savePath)), AtHocConfigService.Current.Windows1252Encoding);
                var reader = new CsvHelperCsvReader(new Infrastructure.Csv.CsvReaderSettings { HasHeaderRecord = false, Reader = textReader });
                while (reader.Read())
                {
                    if (!reader.CurrentRecord.Any() || reader.CurrentRecord.Count() != 1)
                        return Json(new { Success = false, Error = IWSResources.DistributionList_Error_ImportUser_InvalidFile }, "text/plain");

                    if (reader.CurrentRecord.Any())
                    {
                        userList.Add(reader.CurrentRecord.GetValue(0).ToString());
                    }
                }
                #endregion Parse CSV
                try
                {
                    return userList.Any() ? GetUsers(userList.ToArray(), distibutionId, tempId) : Json(new { Success = false, Error = IWSResources.DistributionList_Error_ImportUser_InvalidFileFormat }, "text/plain");
                }
                catch (Exception ex)
                {
                    return Json(new { Success = false, Error = ex.Message }, "text/plain");
                }
            }
            catch
            {
                return Json(new { Success = false, Error = IWSResources.DistributionList_Error_ImportUser_InvalidFileFormat }, "text/plain");
            }
            finally
            {
                if (System.IO.File.Exists(savePath))
                {
                    System.IO.File.Delete(savePath);
                }
            }

        }

        [HttpPost]
        public JsonResult GetUsers(string[] names, int distributionId, int tempId)
        {
            try
            {
                var provider = RuntimeContext.Provider;
                var currentUser = RuntimeContext.Operator;
                var hasHeader = false;

                if (names.HasValue())
                {
                    string header = names.FirstOrDefault();
                    var userNameAttribute = ProviderAttributes.GetByCommonName(CommonNames.UserName).AttributeName;

                    if (!string.IsNullOrWhiteSpace(header))
                    {
                        hasHeader = header.Equals(userNameAttribute, StringComparison.InvariantCultureIgnoreCase);
                    }
                    var totalUserTried = (hasHeader) ? names.Count() - 1 : names.Count();
                    var importedUsers = 0;
                    var strVpsDate = provider.CurrentSystemTimeToVpsTimeString();

                    if (hasHeader)
                    {
                        // remove header
                        names = names.Skip(1).ToArray();
                    }

                    var users = BatchImportUsers(names);
                    if (users.HasValue())
                    {
                        int count;
                        tempId = UpdateTemporaryStaticDl(distributionId, tempId, users.ToList(), true, out count);
                        importedUsers = users.Count();

                        if (importedUsers > totalUserTried)
                            totalUserTried = importedUsers;

                        return Json(new
                        {
                            Success = true,
                            TotalImportUsers = totalUserTried,
                            ImportedUsers = importedUsers,
                            UpdatedOn = strVpsDate,
                            TempId = tempId,
                            UserCount = count,
                            UpdatedBy = currentUser.DisplayName
                        }, "text/plain");
                    }

                    return Json(new
                    {
                        Success = true,
                        TotalImportUsers = totalUserTried,
                        ImportedUsers = importedUsers,
                        UpdatedOn = strVpsDate,
                        TempId = -1,
                        UserCount = -1,
                        UpdatedBy = currentUser.DisplayName
                    }, "text/plain");
                }
                return Json(new { Success = false, Error = IWSResources.DistributionList_Error_ImportUser_NoUsers }, "text/plain");
            }
            catch (Exception ex)
            {
                return Json(new { Success = false, Error = ex.Message }, "text/plain");
            }

        }

        private IEnumerable<int> BatchImportUsers(IEnumerable<string> names)
        {
            var userIdList = new List<int>();
            const int batchSize = 2000;
            var currentBatch = 0;

            var attrUsernameId = ProviderAttributes.GetByCommonName(AttributeCommonNames.UserName).Id;

            while ((currentBatch * batchSize) < names.Count())
            {
                var namesBatch = names.Skip(currentBatch * batchSize).Take(batchSize).ToList();
                currentBatch++;

                if (namesBatch.HasValue())
                {
                    var srchArgsV2 = new UserSearchArgs(false, true, false, 1, namesBatch.Count, "LOGIN_ID", "ASC")
                    {
                        DeviceNames = null,
                        AttributeNames = new List<string> { "LOGIN_ID" },
                        ProviderId = RuntimeContext.ProviderId,
                        ProviderCriteria = UserSearchHelper.GetProviderCriteria(RuntimeContext.ProviderId),
                        OperatorCriteria = UserSearchHelper.GetOperatorUserBaseCriteria(RuntimeContext.OperatorId, RuntimeContext.ProviderId)
                    };
                    var customAttributeCache = new CustomAttributeCache();
                    var customAttributeDictionary = customAttributeCache.Get(RuntimeContext.ProviderId, RuntimeContext.Provider.BaseLocale, true);
                    var statusAttribute = customAttributeDictionary.GetByCommonName(AttributeCommonNames.Status);
                    var customAttributeValueCache = new CustomAttributeValueCache();
                    var customAttributeValueDictionary = customAttributeValueCache.Get(RuntimeContext.ProviderId, RuntimeContext.Provider.BaseLocale);
                    var statusValues = customAttributeValueDictionary.GetByCommonNames("VLD,DSB").Select(x => x.ValueId);
                    var statusCriteria = UserSearchHelper.GetUserStatusCriteria(statusAttribute.Id, statusValues);

                    var idList = new List<int>();
                    var userNameList = new List<string>();

                    foreach (var name in namesBatch)
                    {
                        int id;
                        if (int.TryParse(name.Trim(), out id))
                        {
                            // UserID found
                            idList.Add(id);
                        }
                        else
                        {
                            // Username found
                            userNameList.Add(name);
                        }
                    }

                    if (userNameList.Any())
                        srchArgsV2.TargetCriteria = new AttributeCriteria(attrUsernameId, CriteriaOperator.Equals, userNameList.CsvParamString());

                    if (idList.Any())
                        srchArgsV2.TargetCriteria = srchArgsV2.TargetCriteria | new UserCriteria(0, CriteriaOperator.Equals, idList.CsvParamString());
                   
                    //Adding Status criteria 
                    srchArgsV2.TargetCriteria = srchArgsV2.TargetCriteria & statusCriteria;

                    var userIds = _userFacade.SearchUsersByContext(srchArgsV2).Users.Select(x => x.Id);

                    userIdList.AddRange(userIds);
                }
            }

            return userIdList.Distinct();
        }
        #endregion
    }
}
