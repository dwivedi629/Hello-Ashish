﻿using System;
using System.Globalization;
using System.Linq;
using System.Web.Mvc;
using AtHoc.Infrastructure.Extensions;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Resources;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Data.SearchSpec;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.SSA.Business.Facades;
using AtHoc.IWS.Web.Configurations.Constants;
using AtHoc.IWS.Web.Filters;
using AtHoc.IWS.Web.Models.Publishing;
using AtHoc.IWS.Business.Domain.PageLayout;
using AtHoc.IWS.Business.Domain.PageLayout.Spec;
using AtHoc.IWS.Web.Models.PageLayout;
using AtHoc.IWS.SSA.Business.Facades.Interfaces;
using System.Collections.Generic;
using AtHoc.Global.Resources;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;
using AtHoc.IWS.Web.Helpers;

namespace AtHoc.IWS.Web.Controllers
{
    [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.View })]
    public class UserAttributesController : Infrastructure.Web.Mvc.Controller
    {
        private readonly ICustomAttributeFacade _customAttributeFacade;
        private readonly IPageLayoutFacade _pageLayoutFacade;
        private readonly IIconManager _iconManager;
        private readonly IUserFacade _userFacade;
        private readonly AtHoc.IWS.Business.Domain.Settings.IHierarchyDefinitionFacade _hierarchyFacade;
        private readonly IProviderFacade _providerFacade;
        public UserAttributesController(ICustomAttributeFacade customAttributeFacade, IPageLayoutFacade pageLayoutFacade, IUserFacade userFacade, AtHoc.IWS.Business.Domain.Settings.IHierarchyDefinitionFacade hierarchyFacade,IProviderFacade providerFacade)
        {
            _customAttributeFacade = customAttributeFacade;
            _pageLayoutFacade = pageLayoutFacade;
            _iconManager = ManagerFactory.Instance.CreateIconManager();
            _userFacade = userFacade;
            _hierarchyFacade = hierarchyFacade;
            _providerFacade = providerFacade;
        }

        // GET: UserAttributes
        [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.Modify })]
        public ActionResult Index()
        {
            return View();
        }

        [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.Modify })]
        public ActionResult AttributeDetails()
        {
            return View();
        }

        /// <summary>
        /// It will redirect to New Attribute details page
        /// </summary>
        /// <param name="id">Attribute Type</param>
        /// <returns></returns>
        [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.Modify })]
        public ActionResult New(string id)
        {
            string attributeType;
            if (id.Contains(Constants.PA_Status))
            {
                attributeType = CustomAttributeDataType.Picklist.ToString();
                ViewBag.SupportsHistory = "Y";
            }
            else
                attributeType = id;

            var types = _customAttributeFacade.GetUserAttributeTypes();
            ViewBag.AttributeTypeId = types.ToList().SingleOrDefault(i => i.AttributeType == attributeType).AttributeTypeId;
            ViewBag.IsNew = true;
            ViewBag.AttributeType = attributeType;
            ViewBag.AttributeOrigin = RuntimeContext.Provider.ProviderName;
            ViewBag.ProviderId = RuntimeContext.ProviderId;
            ViewBag.LocaleCode = RuntimeContext.Provider.BaseLocale;
            FillTimeProperties();
            return View("AttributeDetails");
        }

        /// <summary>
        /// It will redirect to Edit Attribute details page
        /// </summary>
        /// <param name="id">Attribute Id</param>
        /// <returns></returns>        
        [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.Modify })]
        public ActionResult Edit(string id)
        {
            ViewBag.AttributeType = id; // id is AttributeId
            ViewBag.IsNew = false;
            FillTimeProperties();
            return View("AttributeDetails");
        }

        /// <summary>
        /// Fill DateTime properties
        /// </summary>
        private void FillTimeProperties()
        {
            var provider = RuntimeContext.Provider;

            var vpsTimeZOne = RuntimeContext.Provider.GetVpsTimeZoneFromId();
            ViewBag.DateFormat = provider.GetDateFormat();
            ViewBag.DateTimeFormat = provider.GetDateTimeFormat();
            ViewBag.VPSTimeZone = vpsTimeZOne;
            ViewBag.UtcOffsetInMinutes = vpsTimeZOne.BaseUtcOffset.TotalMinutes;
            ViewBag.VPSOffsetFromSystemInMinutes = provider.VPSOffsetFromSystemInMinutes();
            ViewBag.SupportsDaylightSavingTime = vpsTimeZOne.SupportsDaylightSavingTime;
            ViewBag.CurrentDateTime = provider.CurrentSystemTimeToVps().ToString(System.Globalization.CultureInfo.InvariantCulture);
            ViewBag.CurrentTime = DateTime.Now;
        }

        /// <summary>
        /// Get Attributes based on spec
        /// If providerId is zero then get all attributes
        /// If providerID is somthing value then get only corresponding attributes
        /// TODO: If providerId is somthing value and get all attributes other than this prodierid attributes
        /// </summary>
        /// <param name="attributeSearchSpec">UserAttributeSearchSpec object</param>
        /// <returns></returns>
        [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.Modify })]
        public ActionResult GetUserAttributeList(UserAttributeSearchSpec attributeSearchSpec)
        {
            try
            {
                attributeSearchSpec.ProviderId = RuntimeContext.ProviderId;
                attributeSearchSpec.OperatorId = RuntimeContext.OperatorId;
                attributeSearchSpec.Locale = RuntimeContext.Provider.BaseLocale;
                var excludeList = new List<string>() { AttributeCommonNames.MassCommunication };
                if (!RuntimeContext.Provider.FeatureMatrix.IsEnterpriseManagementSupported)
                excludeList.AddRange(new[] { CommonNames.Organizations, CommonNames.PreventUserMove });
                attributeSearchSpec.ExcludeCommonNames = excludeList;
                var attributeList = _customAttributeFacade.GetAttributesForList(attributeSearchSpec);
                var attributes = SettingsHelper.AttributeList().ToList();
                attributes.Add(new MultiSelectListModel { Text = IWSResources.UserAttributeManager_Status, Value = Constants.PA_Status });
                var attributeTotalCount = attributeList.Count;

                var data = attributeList.Data.Select(x => new
                {
                    x.Id,
                    x.AttributeName,
                    x.AttributeOrigin,
                    UpdatedOn =
                       RuntimeContext.Provider.GetVpsDateFromSeconds(x.UpdatedOn.HasValue
                           ? x.UpdatedOn.Value
                           : x.CreatedOn.HasValue ? x.CreatedOn.Value : 0),
                    x.AttributeTypeId,
                    x.SupportsHistoricalValues,
                    AttributeType = GetLocalizedString(x, attributes)
                });
                if (attributeSearchSpec.Sort[0].Field == "AttributeType" && !attributeSearchSpec.Locale.Equals("en-US"))
                {
                    if (attributeSearchSpec.Sort[0].Dir == "asc")
                        data = data.OrderBy(x => x.AttributeType);
                    else
                        data = data.OrderByDescending(x => x.AttributeType);
                }
                return Json(new
                {
                    Success = true,
                    TotalCount = attributeTotalCount,
                    Data = data,
                    Attributes = attributes.Where(e => e.Value != CustomAttributeDataType.Path.ToString() && e.Value != CustomAttributeDataType.Time.ToString()).OrderBy(e => e.Text)
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new
                {
                    Success = false,
                    Messages = IWSResources.UserAttributeManager_List_Message
                }, JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// Getting usesr attribute details based on attributeId
        /// </summary>
        /// <param name="userAttributeId">Attribute Id</param>
        /// <returns></returns>
        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.Modify })]
        public ActionResult GetUserAttributeDetails(int userAttributeId)
        {
            try
            {
                bool isDeletable, isStatusAttributeEditable = true, isEditable = false;
                CustomAttributeModel custAttributeModel;
                var userAttribute = IsUserAttributeDeletableOnCurrentContext(userAttributeId, out isDeletable);
                if (userAttribute != null)
                {
                    custAttributeModel = GetUserAttributeDetail(userAttribute);
                    // For enable and disable of common Name and Attribute Name
                    if (RuntimeContext.ProviderId == userAttribute.ProviderId)
                    {
                        isEditable = true;
                        if (custAttributeModel.AttributeTypeId == 6 && custAttributeModel.SupportsHistory != null && custAttributeModel.SupportsHistory.ToLower() == "y")
                        {
                            var spec = new CustomAttributeDeleteDependencySpec
                            {
                                ProviderId = RuntimeContext.ProviderId,
                                UserAttributeId = userAttributeId,
                                PageSize = 1000,
                                Page = 1
                            };
                            isStatusAttributeEditable = (!_customAttributeFacade.CheckDeleteDependencies(spec).Any(e => e.UsedIn.Equals("PA Event")));
                        }
                    }

                    if (custAttributeModel.AttributeTypeId == 8 && !string.IsNullOrEmpty(userAttribute.DefaultValue))
                    {
                        custAttributeModel.DefaultValue =
                            userAttribute.Values.FirstOrDefault(
                                x => x.ValueId.ToString() == custAttributeModel.DefaultValue).ValueName;
                    }

                    return Json(new
                    {
                        Success = true,
                        Data = custAttributeModel,
                        IsDeletable = isDeletable,
                        IsEditeable = isEditable,
                        IsStandardAttibuteEditeable = isStatusAttributeEditable
                    });
                }
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new
                {
                    Success = false,
                    Messages = IWSResources.UserAttributeManager_Attribute_Get_Message
                });
            }
            return null;
        }

        /// <summary>
        /// getiing the user attribute details
        /// </summary>
        /// <param name="userAttribute"></param>
        /// <returns></returns>
        private CustomAttributeModel GetUserAttributeDetail(CustomAttribute userAttribute)
        {
            CustomAttributeModel custAttributeModel = new CustomAttributeModel();
            custAttributeModel.ProviderId = userAttribute.ProviderId;
            custAttributeModel.LocaleCode = userAttribute.LocaleCode;
            if (userAttribute.UpdatedBy != null)
                custAttributeModel.UpdatedBy = GetUserName(userAttribute.UpdatedBy);

            custAttributeModel.CreatedBy = userAttribute.CreatedBy.HasValue ? GetUserName(userAttribute.CreatedBy) : "";

            custAttributeModel.UpdatedOn = RuntimeContext.Provider.SystemToVpsDateTimeFormated(DateTimeConverter.GetDateTimeFromSeconds(userAttribute.UpdatedOn));

            custAttributeModel.CreatedOn = RuntimeContext.Provider.SystemToVpsDateTimeFormated(DateTimeConverter.GetDateTimeFromSeconds(userAttribute.CreatedOn));

            //Date format conversion
            if (userAttribute.AttributeTypeId == CustomAttributeDataType.Date)
            {
                custAttributeModel.EarliestAllowedDate = string.IsNullOrEmpty(userAttribute.MinValue) ? string.Empty : RuntimeContext.Provider.SystemToVpsDateFormated(Convert.ToDateTime(userAttribute.MinValue));

                custAttributeModel.LatestAllowedDate = string.IsNullOrEmpty(userAttribute.MaxValue) ? string.Empty : RuntimeContext.Provider.SystemToVpsDateFormated(Convert.ToDateTime(userAttribute.MaxValue));

            }
            //DateTime format conversion
            else if (userAttribute.AttributeTypeId == CustomAttributeDataType.DateTime)
            {
                custAttributeModel.EarliestAllowedDate = string.IsNullOrEmpty(userAttribute.MinValue) ? string.Empty : RuntimeContext.Provider.SystemToVpsDateTimeFormated(Convert.ToDateTime(userAttribute.MinValue));

                custAttributeModel.LatestAllowedDate = string.IsNullOrEmpty(userAttribute.MaxValue) ? string.Empty : RuntimeContext.Provider.SystemToVpsDateTimeFormated(Convert.ToDateTime(userAttribute.MaxValue));
            }
            else if (userAttribute.AttributeTypeId == CustomAttributeDataType.String || userAttribute.AttributeTypeId == CustomAttributeDataType.Number)
            {
                if (!string.IsNullOrEmpty(userAttribute.MaxValue)) custAttributeModel.MaxValue = userAttribute.MaxValue;
                if (!string.IsNullOrEmpty(userAttribute.MinValue)) custAttributeModel.MinValue = userAttribute.MinValue;
            }

            custAttributeModel.AttributeOrigin = userAttribute.AttributeOrigin;
            if (userAttribute.AttributeTypeId.HasValue)
                custAttributeModel.AttributeTypeId = Convert.ToInt16(userAttribute.AttributeTypeId.Value);
            custAttributeModel.Id = userAttribute.Id;
            custAttributeModel.AttributeType = (_customAttributeFacade.IsStatusAttribute(userAttribute)) ? IWSResources.UserAttributeManager_Status : userAttribute.AttributeType;
            custAttributeModel.Name = userAttribute.AttributeName;
            custAttributeModel.CommonName = userAttribute.CommonName;
            custAttributeModel.OldCommonName = userAttribute.CommonName;
            custAttributeModel.HelpText = userAttribute.HelpText;
            if (userAttribute.EditLevel.HasValue)
                custAttributeModel.EditLevel = userAttribute.EditLevel.Value;
            custAttributeModel.ToolTip = userAttribute.Description;
            custAttributeModel.IsMandatory = userAttribute.IsMandatory;
            custAttributeModel.IconId = userAttribute.IconId;
            custAttributeModel.SupportsHistory = userAttribute.SupportsHistoricalValues;
            custAttributeModel.DefaultValue = userAttribute.DefaultValue;
            custAttributeModel.IsStandard = userAttribute.IsStandard;
            if (custAttributeModel.AttributeTypeId == (int)CustomAttributeDataType.MultiPicklist || custAttributeModel.AttributeTypeId == (int)CustomAttributeDataType.Picklist || custAttributeModel.AttributeTypeId == (int)CustomAttributeDataType.Checkbox)
            {
                var rpt = _customAttributeFacade.GetReportDetails(userAttribute.Id);
                if (rpt.Count != 0)
                {
                    custAttributeModel.ReportName = rpt["REPORT_NAME"];
                    custAttributeModel.Description = rpt["REPORT_DESCRIPTION"];
                }

                if (custAttributeModel.AttributeTypeId == (int)CustomAttributeDataType.MultiPicklist || custAttributeModel.AttributeTypeId == (int)CustomAttributeDataType.Picklist)
                {
                    if (userAttribute.Values != null && userAttribute.Values.Count() > 0)
                    {
                        System.Text.StringBuilder pListStr = new System.Text.StringBuilder();
                        userAttribute.Values.ToList().ForEach(i => pListStr.AppendFormat("{0}<->{1}<->{2},", i.ValueId, i.ValueName, i.CommonName));
                        custAttributeModel.PickListValuesCSV = pListStr.ToString();
                         
                    }
                    if (custAttributeModel.AttributeTypeId == (int)CustomAttributeDataType.Picklist &&
                        custAttributeModel.CommonName.ToUpper() == AttributeCommonNames.Organizations.ToUpper())
                    {
                        System.Text.StringBuilder pListStr = new System.Text.StringBuilder();
                        var entList = _providerFacade.GetEnterpriseProviderList(RuntimeContext.ProviderId);
                        entList.ToList().ForEach(i => pListStr.AppendFormat("{0}<->{1}<->{2},", i.Key, i.Value, i.Value));
                        custAttributeModel.PickListValuesCSV = pListStr.ToString();
                        //custAttributeModel.PickListValuesCSV = "1<->Organization1<->Organization1,2<->Organization2<->Organization2,3<->Organization3<->Organization3,";
                    }
                }
            }
            return custAttributeModel;
        }

        /// <summary>
        /// returning the attributetype based on the attribute and attribute static list
        /// </summary>
        /// <param name="attribute"></param>
        /// <param name="attributes"></param>
        /// <returns></returns>
        private string GetLocalizedString(CustomAttribute attribute, IEnumerable<MultiSelectListModel> attributes)
        {
            if (attribute.AttributeTypeId.ToString() == CustomAttributeDataType.Picklist.ToString() && attribute.SupportsHistoricalValues == "Y")
                return IWSResources.UserAttributeManager_Status;
            var attributeData = attributes.FirstOrDefault(e => e.Value == attribute.AttributeTypeId.ToString());
            if (attributeData != null)
                return attributeData.Text;
            return string.Empty;
        }

        /// <summary>
        /// returning the user name based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        private string GetUserName(int? id)
        {
            var userDetail = _userFacade.GetUserBySpec(new UserSpec { OperatorId = id, UserId = id });
            return userDetail != null ? userDetail.UserName : string.Empty;
        }

        /// <summary>
        /// Getting attribute details and check it is deletable or not
        /// </summary>
        /// <param name="userAttributeId">Attribute Id</param>
        /// <param name="isDeletable">Deletable</param>
        /// <returns></returns>
        [NonAction]
        private CustomAttribute IsUserAttributeDeletableOnCurrentContext(int userAttributeId, out bool isDeletable)
        {
            var userAttributeDetails =
                _customAttributeFacade.GetCustomAttributesBySpec(new CustomAttributeSpec { Id = userAttributeId, IncludeValues = true, OperatorId = RuntimeContext.OperatorId, ProviderId = RuntimeContext.ProviderId, BaseLocale = RuntimeContext.Provider.BaseLocale })
                    .ToList();
            isDeletable = false;
            if (userAttributeDetails.Any())
            {
                var userAttribute = userAttributeDetails.First();

                isDeletable = ((userAttribute.ProviderId == RuntimeContext.ProviderId)
                               && (userAttribute.IsSystemAttribute != "Y" && userAttribute.IsStandard != "Y")
                               && ((userAttribute.CommonName.ToLower() != CommonNames.SSATeam.ToLower()) &&
                                   (_customAttributeFacade.GetOrgHierarchyAttributeId(RuntimeContext.ProviderId) !=
                                    userAttribute.Id)));
                return userAttribute;
            }
            return null;
        }

        /// <summary>
        /// Getting attribute dependecny list
        /// </summary>
        /// <param name="spec">CustomAttributeDeleteDependencySpec</param>
        /// <returns></returns>
        [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.Modify })]
        public ActionResult GetUserAttributeDependencyList(CustomAttributeDeleteDependencySpec spec)
        {
            try
            {
                spec.ProviderId = RuntimeContext.ProviderId;
                spec.PageSize = 1000; //To fetch total dependency count.
                spec.Page = 1;
                var dependencyList = _customAttributeFacade.CheckDeleteDependencies(spec).ToList();
                int totalDependencyCount = dependencyList.Count();

                if (dependencyList.Any())
                {
                    LocalizeDependencyList(dependencyList);
                    return Json(new
                    {
                        Success = true,
                        Data = dependencyList,
                        TotalCount = totalDependencyCount,
                        PageCount = dependencyList.Count,
                    }, JsonRequestBehavior.AllowGet);
                }
                return Json(new
                {
                    Success = true
                });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new
                {
                    Success = false
                });
            }
        }
        private void LocalizeDependencyList(IEnumerable<CustomAttributeDeleteDependency> dependencyList)
        {
            try
            {
                dependencyList.ToList().ForEach(item =>
                {
                    item.UsedIn = SettingsHelper.GetPageDependencyLocalizeString(item.UsedIn);
                    item.UsedFor = SettingsHelper.GetSectionDependencyLocalizeString(item.UsedFor);
                });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
            }
        }

        public ActionResult GetUserAttributeValues(int userAttributeId)
        {
            var attributeValues = _customAttributeFacade.GetCustomAttributeValuesBySpec(new CustomAttributeValueSpec { AttributeId = userAttributeId, BaseLocale = RuntimeContext.Provider.BaseLocale });
            return Json(new
            {
                Success = true,
                Data = attributeValues
            });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="contentType"></param>
        /// <param name="base64"></param>
        /// <param name="fileName"></param>
        /// <returns></returns>
        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.Modify })]
        public ActionResult ExportDependencies(string contentType, string base64, string fileName)
        {
            var fileContents = Convert.FromBase64String(base64);
            return File(fileContents, contentType, fileName);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userAttributeId"></param>
        /// <param name="commonName"></param>
        /// <param name="userSectionName"></param>
        /// <param name="selfServiceSectionName"></param>
        /// <returns></returns>
        [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.Modify })]
        public ActionResult DeleteUserAttribute(int userAttributeId, string commonName, string userSectionName, string selfServiceSectionName)
        {
            var messages = new Messages();
            try
            {
                bool isDeletable;
                IsUserAttributeDeletableOnCurrentContext(userAttributeId, out isDeletable);
                if (isDeletable)
                {
                    var result = _customAttributeFacade.DeleteCustomAttribute(RuntimeContext.OperatorId, RuntimeContext.ProviderId, userAttributeId, commonName, userSectionName, selfServiceSectionName, CustomAttributeType.User.ToString(), RuntimeContext.Operator.FullName);
                    return Json(new { Success = result.Messages.NoErrors(), Messages = result.Messages });
                }
                messages.Add(new Message { Value = IWSResources.UserAttributeManager_Attribute_Delete_Failed_Message, Type = MessageType.Error, Sender = typeof(UserAttributesController) });
                return Json(new { Success = false, Messages = messages });
            }
            catch (Exception exec)
            {
                messages.Add(new Message { Value = exec.Message, Type = MessageType.Error, Sender = typeof(UserAttributesController) });
                LogService.Current.Error(() => exec);
                return Json(new { Success = false, Messages = messages });
            }
        }

        public ActionResult GetUserAttributeTypes()
        {
            var data = _customAttributeFacade.GetUserAttributeTypes();
            return Json(new
            {
                Success = true,
                Data = data
            });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userAttributeId"></param>
        /// <returns></returns>
        [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.Modify })]
        public ActionResult DeletePickListOption(int userAttributeId)
        {
            var messages = new Messages();
            try
            {
                var operatorId = RuntimeContext.OperatorId;
                var result = _customAttributeFacade.DeletePickListValues(userAttributeId, operatorId);
                return Json(new { Success = true, Messages = result });
            }
            catch (Exception exec)
            {
                messages.Add(new Message { Value = exec.Message, Type = MessageType.Error, Sender = typeof(UserAttributesController) });
                LogService.Current.Error(() => exec);
                return Json(new { Success = false, Messages = messages });
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="attributeId"></param>
        /// <param name="valueId"></param>
        /// <returns></returns>
        [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.Modify })]
        public ActionResult DeletePickListValue(int providerId, int attributeId, int valueId)
        {
            var messages = new Messages();
            try
            {
                var result = _customAttributeFacade.DeletePickListValue(RuntimeContext.Operator.FullName, providerId, attributeId, valueId, RuntimeContext.OperatorId);
                return Json(new { Success = true, Messages = result });
            }
            catch (Exception exec)
            {
                messages.Add(new Message { Value = exec.Message, Type = MessageType.Error, Sender = typeof(UserAttributesController) });
                LogService.Current.Error(() => exec);
                return Json(new { Success = false, Messages = messages });
            }
        }

        /// <summary>
        /// Get PageLayout sections and get the selected section
        /// </summary>
        /// <param name="commonName">common name</param>
        /// <returns></returns>
        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.Modify })]
        public ActionResult GetSections(string commonName, int providerId)
        {
            try
            {
                providerId = RuntimeContext.ProviderId; // ProviderId should be current providerId

                // Get all user sections
                var userLayout = _pageLayoutFacade.GetPageLayoutBySpec(new PageLayoutSpec { ProviderId = providerId, PageId = "NEWEUM" }).FirstOrDefault();
                var layoutXml = new LayoutXml();
                var allUserSections = layoutXml.GetAllSections(userLayout.LayoutXml, commonName);
                var userList = allUserSections.Where(x => x.Type.ToUpper().Equals("ATTRIBUTES") && !x.Method.ToUpper().Equals("COMPUTED")).Select(s => new { s.DisplayName, s.Name, s.IsSelected, s.IsParent, s.IsChild, s.Children });

                // Get all SelfService sections
                var ssLayout = _pageLayoutFacade.GetPageLayoutBySpec(new PageLayoutSpec { ProviderId = providerId, PageId = "OPERATORDETAILS" }).FirstOrDefault();
                var allSSSections = layoutXml.GetAllSections(ssLayout.LayoutXml, commonName);
                var ssList = allSSSections.Where(x => x.Type.ToUpper().Equals("ATTRIBUTES") && !x.Method.ToUpper().Equals("COMPUTED")).Select(s => new { s.DisplayName, s.Name, s.IsSelected, s.IsParent, s.IsChild, s.Children });

                return
                    Json(
                        new
                        {
                            UserList = userList,
                            SSList = ssList,
                            Success = true
                        }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { ErrorMessage = ex.Message, Success = false }, JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// Get all map icons 
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.Modify })]
        public ActionResult MapIconsBase()
        {
            try
            {
                var Categories = _iconManager.GetCategories();
                var Icons = _iconManager.GetIcons();

                var model = new List<object>();
                foreach (var name in Categories)
                {
                    var list = Icons.Where(i => i.Category == name).ToList();
                    model.Add(new { Name = name, List = list });
                }

                int iconId;
                if (int.TryParse(_iconManager.GetDefaultIconId(), out iconId))
                {
                    iconId = 0;
                }

                return
                       Json(
                           new
                           {
                               Data = model,
                               DefaultIconId = iconId,
                               Success = true
                           }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { ErrorMessage = ex.Message, Success = false }, JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// Save attribute details
        /// </summary>
        /// <param name="model">Attribute details</param>
        /// <returns></returns>tr
        [HttpPost]
        public ActionResult SaveAttribute(CustomAttributeModel model, List<AtHoc.IWS.Business.Domain.Settings.PdlListModel> pldlistsettings)
        {
            var validateResult = false;
            try
            {
                // Commented below line and assign current providerId at repository after checking the provider context.
                var providerId = RuntimeContext.ProviderId;
                var operatorId = RuntimeContext.OperatorId;
                
                if (model.Id > 0)
                {
                   if (model.AttributeTypeId>0)
                    {
                       validateResult = _customAttributeFacade.ValidateProviderAttributeId((int)model.ProviderId, model.Id,model.AttributeTypeId);
                    }

                    if (!validateResult)
                    {
                        TempData["IsUnAuthorizedAccess"] = true;
                        var messages = new Messages();
                        messages.Add(new Message
                        {

                            Type = MessageType.Error,
                            Value = IWSResources.UserAttributeManager_Authorized_Access_UserAttribute_Other_Organization,
                            Sender = "Save Attribute"
                        });
                        return Json(new { Success = true, Messages = messages, IsUnAuthorizedAccess = true });
                    }
                }


                #region " Populate Custom Attribute Model for Save"
                model.EntityId = "USER";
                model.LocaleCode = RuntimeContext.Provider.BaseLocale;
                model.IsSystem = "N";
                model.IsStandard = !string.IsNullOrWhiteSpace(model.IsStandard) ? model.IsStandard : "N";

                if (model.AttributeTypeId == (int)CustomAttributeDataType.GeoLocation)
                    model.SupportsHistory = string.IsNullOrEmpty(model.SupportsHistory) ? "N" : model.SupportsHistory;

                //if (model.AttributeTypeId == (int)CustomAttributeDataType.Checkbox)
                //    model.DefaultValue = model.DefaultValue == "True" ? "Yes" : "No";

                if (model.AttributeTypeId == (int)AttributeType.Picklist || model.AttributeTypeId == (int)AttributeType.MultiPicklist || model.AttributeTypeId == (int)AttributeType.Checkbox)
                    model.PicklistDelimiter = ",";

                if (model.AttributeTypeId == (int)AttributeType.Picklist)
                    model.SupportsHistory = string.IsNullOrEmpty(model.SupportsHistory) ? "N" : model.SupportsHistory;

                if (model.Description != null) model.Description = model.Description.Trim();
                //Convertingthe selected dates to Seconds.
                if (!string.IsNullOrWhiteSpace(model.EarliestAllowedDate))
                {
                    var dateEart = RuntimeContext.Provider.VpsToSystemTime(DateTime.ParseExact(model.EarliestAllowedDate, (model.AttributeTypeId == (int)AttributeType.DateTime ? RuntimeContext.Provider.GetDateTimeFormat() : RuntimeContext.Provider.GetDateFormat()), null));
                    if (dateEart != DateTime.MinValue)
                        model.MinValue = dateEart.ToString(CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrWhiteSpace(model.LatestAllowedDate))
                {
                    var dateLatest = RuntimeContext.Provider.VpsToSystemTime(
                        DateTime.ParseExact(model.LatestAllowedDate,
                            (model.AttributeTypeId == (int)AttributeType.DateTime
                                ? RuntimeContext.Provider.GetDateTimeFormat()
                                : RuntimeContext.Provider.GetDateFormat()), null));
                    if (dateLatest != DateTime.MaxValue)
                        model.MaxValue = dateLatest.ToString(CultureInfo.InvariantCulture);

                }
                model.UpdatedBy = operatorId.ToString();
                model.CreatedBy = operatorId.ToString();
                model.OperatorId = operatorId;
                model.Name = model.Name.Trim();
                model.CommonName = model.CommonName.Trim();
                #endregion " Populate Custom Attribute Model for Save"
                //path validations
                if (model.AttributeTypeId == (int)AttributeType.Path)
                {
                    var hierarchySpec = new AtHoc.IWS.Business.Domain.Settings.HierarchySpec
                    {
                        ProviderId = RuntimeContext.ProviderId,
                        OperatorId = RuntimeContext.OperatorId,
                        LocalCode = RuntimeContext.Provider.BaseLocale,
                        NodeList = pldlistsettings,
                        HierarchySearchType = HierarchySearchType.Organization ,
                    };

                    var rootNode = pldlistsettings.Find(m => m.ListId == 0 && m.Name != null);
                    if (rootNode != null && _hierarchyFacade.IsValidHierarchyName(rootNode.Name, Convert.ToInt32(rootNode.HierarchyId), RuntimeContext.ProviderId))
                    {

                        var error = IWSResources.AtHoc_HierarchyDefinition_ErrMsg_UniqueNameinVPS;
                        return Json(new { ErrorMessage = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }), Success = false }, JsonRequestBehavior.AllowGet);
                    }
                    //Save Hierarchy
                    var hierResult = _hierarchyFacade.SaveNode(hierarchySpec);
                    if (!hierResult)
                    {
                        var error = IWSResources.AtHoc_HierarchyDefinition_ErrMsg_Saving;
                        return Json(new{ErrorMessage =new Messages(new Message {Type = MessageType.Error, Value = error}),Success = false}, JsonRequestBehavior.AllowGet);
                    }
                } 

                var resultMessage = _customAttributeFacade.SaveCustomAttribute(model, providerId);
                var result = resultMessage.ToList();
                bool isEditable = false;
                bool isStatusAttributeEditable = true;

                if (result.Any(e => e.Type == MessageType.Success))
                {
                    //Edit Info Section Implementation 
                    string updatedOn = string.Empty;
                    string createdOn = string.Empty;
                    var userName = string.Empty;
                    var userNameUpdatedBy = string.Empty;
                    bool isDeletable = false;
                    int attributeId = 0;
                    #region "Get Saved User Attribute Details to populated in UI"
                    var userAttributeDetails =
                   _customAttributeFacade.GetCustomAttributesBySpec(new CustomAttributeSpec { CommonName = model.CommonName, OperatorId = operatorId, ProviderId = providerId, }).FirstOrDefault();
                    // get attribute details
                    if (userAttributeDetails != null)
                    {
                        if (providerId == userAttributeDetails.ProviderId)
                        {
                            isEditable = true;
                            if (userAttributeDetails.AttributeTypeId != null && ((int)userAttributeDetails.AttributeTypeId == 6 && userAttributeDetails.SupportsHistoricalValues.ToLower() == "y"))
                            {
                                var spec = new CustomAttributeDeleteDependencySpec
                                {
                                    ProviderId = RuntimeContext.ProviderId,
                                    UserAttributeId = userAttributeDetails.Id,
                                    PageSize = 1000,
                                    Page = 1
                                };
                                isStatusAttributeEditable = (!_customAttributeFacade.CheckDeleteDependencies(spec).Any(e => e.UsedIn.Equals("PA Event")));
                            }
                            else
                                isEditable = true;

                        }
                        updatedOn = RuntimeContext.Provider.SystemToVpsDateTimeFormated(DateTimeConverter.GetDateTimeFromSeconds(userAttributeDetails.UpdatedOn));
                        createdOn = RuntimeContext.Provider.SystemToVpsDateTimeFormated(DateTimeConverter.GetDateTimeFromSeconds(userAttributeDetails.CreatedOn));
                        attributeId = userAttributeDetails.Id;

                        userName = GetUserName(userAttributeDetails.CreatedBy.HasValue ? userAttributeDetails.CreatedBy : 0);
                        userNameUpdatedBy = GetUserName(userAttributeDetails.UpdatedBy.HasValue ? userAttributeDetails.UpdatedBy : 0);
                        isDeletable = ((userAttributeDetails.ProviderId == providerId)

                                 && (userAttributeDetails.IsSystemAttribute != "Y" && userAttributeDetails.IsStandard != "Y")
                                 && ((userAttributeDetails.CommonName.ToLower() != CommonNames.SSATeam.ToLower()) &&
                                     (_customAttributeFacade.GetOrgHierarchyAttributeId(providerId) !=
                                      userAttributeDetails.Id)));
                    }
                    #endregion "Get Saved User Attribute Details to populated in UI"
                    return Json(new { ErrorMessage = result, Success = true, UserName = userName, UpdatedBy = userNameUpdatedBy, CreatedOn = createdOn, UpdatedOn = updatedOn, AttributeID = attributeId, IsEditeable = isEditable, IsDeletable = isDeletable, IsStatusAttributeEditable = isStatusAttributeEditable }, JsonRequestBehavior.AllowGet);
                }
                return Json(new { ErrorMessage = result, Success = false }, JsonRequestBehavior.AllowGet);

            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                var messages = new Messages();
                messages.Add(new Message
                {
                    Type = MessageType.Error,
                    Sender = typeof(CustomAttribute),
                    Value = IWSResources.UserAttributeManager_Save_Failed_Message
                });
                return Json(new { ErrorMessage = messages, Success = false }, JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// Validating attribute details
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string ValidateAttribute(CustomAttributeModel model)
        {
            try
            {
                string message = string.Empty;
                int providerId = RuntimeContext.ProviderId;
                // Validate Attribute Name
                var id = _customAttributeFacade.ValidateAttributeName(providerId, model.Name);
                if (id != -1 && id != model.AttributeTypeId)
                {
                    return string.Format(IWSResources.UserAttributeManager_AttributeName_Unique_Message, model.Name);
                }

                // Validate Common Name
                id = _customAttributeFacade.ValidateCommonName(providerId, model.CommonName);
                if (id != -1 && id != model.AttributeTypeId)
                {
                    return string.Format(IWSResources.UserAttributeManager_CommonName_Unique_Message, model.CommonName);
                }
                return string.Empty;
            }
            catch (Exception ex)
            {
                return string.Empty;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userAttributeId"></param>
        /// <returns></returns>
        [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.Modify })]
        public ActionResult SetCustomAttributeDefaultValues(int userAttributeId, string attributeName = null)
        {
            try
            {
                var result = _customAttributeFacade.SetCustomAttributeDefaultValues(RuntimeContext.OperatorId, RuntimeContext.ProviderId, userAttributeId, attributeName);
                return Json(new { ErrorMessage = result, Success = true }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { ErrorMessage = ex.Message, Success = false }, JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userAttributeId"></param>
        /// <returns></returns>
        [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.Modify })]
        public ActionResult DeleteCustomAttributeDefaultValues(int userAttributeId, string attributeName = null)
        {
            try
            {
                var result = _customAttributeFacade.DeleteAttributeValues(RuntimeContext.OperatorId, RuntimeContext.ProviderId, userAttributeId, attributeName, CustomAttributeType.User.ToString());
                return Json(new { ErrorMessage = result, Success = true }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { ErrorMessage = ex.Message, Success = false }, JsonRequestBehavior.AllowGet);
            }
        }



        /// <summary>
        /// Getting attribute dependecny list
        /// </summary>
        /// <param name="spec">CustomAttributeDeleteDependencySpec</param>
        /// <returns></returns>
        [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.Modify })]
        public ActionResult CheckForHierarchyNodeDependency(CustomAttributeHierarchyDependencySpec spec)
        {
            try
            {
                var dependencydetails = _customAttributeFacade.CheckHierarchyDependencyList(spec);

                var dependencyList = (List<CustomAttributeDeleteDependency>)dependencydetails["DependencyList"];
                var listUserDependency = (List<CustomAttributeHierarchyDeleteList>)dependencydetails["listUserDependency"];
                var userCount = listUserDependency.Sum(x => x.Count);
                int totalDependencyCount = (Int32)dependencydetails["totalRecordsCount"];
                var OnlyUserRecords = (dependencyList.Any(x => x.UsedIn != "User Record") == false);
                if (dependencyList.Count > 0)
                    LocalizeDependencyList(dependencyList);

                return Json(new
                {
                    Success = true,
                    Data = dependencyList.Select(x => new
                    {
                        USED_IN = x.UsedIn,
                        USED_FOR = x.UsedFor,
                        OBJECT_ID = x.EntityId,
                        OBJECT_NAME = x.EntityName,
                        PROVIDER_ID = x.ProviderId,
                        PROVIDER_DISPLAYNAME = x.SourceProvider
                    }),
                    ListCount = listUserDependency,
                    //to verify whether list having only User records
                    OnlyUsers = OnlyUserRecords,
                    DependentUsersMessage = userCount > 0 ? string.Format(IWSResources.HierarchyNode_Dependency_Msg, userCount) : "",
                    TotalCount = totalDependencyCount,
                    PageCount = dependencyList.Count,
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new
                {
                    Success = false
                });
            }
        }


    }
}