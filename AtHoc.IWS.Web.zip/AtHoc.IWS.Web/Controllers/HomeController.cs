﻿using System.Globalization;
using System.Threading;
using AtHoc.Infrastructure.Encryption;
using AtHoc.Infrastructure.Log;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Data.SearchSpec;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.Authorization;
using AtHoc.IWS.Business.Domain.Authorization.Impl;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Events;
using AtHoc.IWS.Business.Domain.Media;
using AtHoc.IWS.Business.Domain.Organization;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Business.Domain.Reports;
using AtHoc.IWS.Business.Domain.Spec;
using AtHoc.IWS.Business.Domain.Systems;
using AtHoc.IWS.Business.Domain.VirtualSystem;
using AtHoc.IWS.Web.Helpers;
using AtHoc.IWS.Web.Models.Accountability;
using AtHoc.IWS.Web.Models.Home;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.SessionState;
using IWSResources = AtHoc.Global.Resources.IWSResources;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.IWS.Business.Domain.GlobalAlertExtension.Interfaces;
using AtHoc.IWS.Business.Domain.Accountability;
using AtHoc.IWS.Business.Domain.Accountability.Specs;
using AtHoc.Publishing;

namespace AtHoc.IWS.Web.Controllers
{
    /// <summary>
    /// Controller for IWS home page
    /// Single entry point is Index method, others are Json method provides required data to home page
    /// </summary>
    /// 
    
    [Authorize]
    [SessionState(SessionStateBehavior.ReadOnly)]
    public class HomeController : AtHoc.Infrastructure.Web.Mvc.Controller
    {
        private readonly IScenarioFacade _scenarioFacade;
        private readonly IAlertFacade _alertFacade;
        private readonly IUserManagerHelper _userManager;
        private readonly IHealthMonitorFacade _healthMonitorFacade;
        private readonly ILogService _logService;
        private readonly IAuthFacade _authFacade;
        private readonly IEventFacade _eventFacade;
        private readonly IMediaFacade _mediaFacade;
        private readonly ISystemReportsFacade _sysRptFacade;
        private readonly IOrganizationFacade _organizationFacade;
        private readonly IVirtualSystemFacade _virtualSystemFacade;
        private readonly IPublishingDomainToModel _publishingDomainToModel;
        private readonly IUserFacade _userFacade;
        private readonly IOperatorDetailsFacade _operatorDetailsFacade;
        private readonly IGlobalAlertExtensionFacade _globalAlertExtensionFacade;
        private readonly IAccountabilityFacade _acctFacade;

        public HomeController(IScenarioFacade scenarioFacade, IAlertFacade alertFacade, IUserManagerHelper userManager,
            IHealthMonitorFacade healthMonitorFacade, ILogService logService, IAuthFacade authFacade, IEventFacade eventFacade,
            IMediaFacade mediaFacade, ISystemReportsFacade reportFacade, IOrganizationFacade organizationFacade, IVirtualSystemFacade virtualSystemFacade
            , IPublishingDomainToModel publishingDomainToModel, IUserFacade userFacade, IOperatorDetailsFacade operatorDetailsFacade, IGlobalAlertExtensionFacade globalAlertExtensionFacade, IAccountabilityFacade acctFacade
            )
        {
            _scenarioFacade = scenarioFacade;
            _alertFacade = alertFacade;
            _userManager = userManager;
            _healthMonitorFacade = healthMonitorFacade;
            _logService = logService;
            _authFacade = authFacade;
            _eventFacade = eventFacade;
            _mediaFacade = mediaFacade;
            _sysRptFacade = reportFacade;
            _organizationFacade = organizationFacade;
            _virtualSystemFacade = virtualSystemFacade;
            _publishingDomainToModel = publishingDomainToModel;
            _userFacade = userFacade;
            _operatorDetailsFacade = operatorDetailsFacade;
            _globalAlertExtensionFacade = globalAlertExtensionFacade;
            _acctFacade = acctFacade;
        }

        /// <summary>
        /// Web entery point for home page
        /// </summary>
        /// <returns>Home page view</returns>
        /// 
       
        public ActionResult Index()
        {

            //Data is send using ViewBag and also update later using Json, this to avoid flickering on home page
            try
            {
                var provider = RuntimeContext.RefreshedProviderContext;
                SetVPSCulture(provider.BaseLocale);
                var user = RuntimeContext.RefreshedOperatorContext;

                var roles = user.OperatorAccess.GroupBy(x => x.RoleId).Select(y => y.First()).ToList();

                if (roles.Count() == 1 && roles.First().RoleId == (int)Roles.SystemAdmin) return Redirect("/client/setup/settings");

                var model = GetHomeModel(provider, user, false);

                ViewBag.IsAffiliate = (provider.ProviderType() == VPSType.Affiliate25 || provider.ProviderType() == VPSType.Affiliate25Template);
                ViewBag.Identifier = model.Identifier;
                ViewBag.ActiveUsers = model.ActiveUsers;
                ViewBag.OnlineUsers = model.OnlineUsers;
                ViewBag.HealthStatus = model.HealthStatus;
                ViewBag.VpsLogoGuid = model.VpsLogoGuid;
                ViewBag.UpdatedOn = model.UpdatedOn;
                ViewBag.DateFormat = provider.GetDateFormat();
                //Operator Permission
                ViewBag.HasAccessToAlerts = model.HasAccessToAlerts;
                ViewBag.HasAccessToScenarios = model.HasAccessToScenarios;
                ViewBag.HasAccessToEvents = model.HasAccessToEvents;
                ViewBag.HasAccessToPA = model.HasAccessToAccountability;
                ViewBag.CanStartAccountabilityEvent = model.CanStartAccountabilityEvent;
                ViewBag.CanConnectToOrg = model.CanConnectToOrg;
                ViewBag.CanManagerUsers = model.CanManagerUsers;
                ViewBag.CanPublishAlert = model.CanPublishAlert;

                //Operator Login
                ViewBag.LastLoginTime = model.LastLoginTime;
                ViewBag.LoginFailedAttempts = model.LoginFailedAttempts;
                ViewBag.PasswordUpdatedOn = model.PasswordUpdatedOn;

                //Organization count
                ViewBag.OrganizationCount = model.OrganizationCount;
                ViewBag.OrganizationInviteCount = model.OrganizationInviteCount;
                ViewBag.WebImageAlternateText = model.WebImageAlternateText;

                //Publisher settings
                var _publisherSettings = _publishingDomainToModel.GetPublisherSettings(provider);
                ViewBag.PublisherSettings = _publisherSettings;
                //this code can be removed after providing these settings in the provider context for legacy.
                setCookiesforLegacy(_publisherSettings);

                // Calling GlobalAlertExtension to intiate the cache load
                _globalAlertExtensionFacade.GetLocalizedGlobalAlertExtensionList(RuntimeContext.Provider.BaseLocale);

            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
            }

            return View();
        }

        public void SetVPSCulture(string baseLocale)
        {
            var httpCookie = Request.Cookies[Constants.IwsLanguageCookie];
            // Setting  the selected language to current thread
            if (httpCookie != null)
            {
                Response.Cookies.Remove(Constants.IwsLanguageCookie);
            }
                var languageCookie = new HttpCookie(Constants.IwsLanguageCookie, "")
                {
                    Value = CookieEncryption.Protect(baseLocale),
                };
                Response.Cookies.Add(languageCookie);

            //Setting the baselocale as UI Culture
            Thread.CurrentThread.CurrentUICulture = CultureInfo.CreateSpecificCulture(baseLocale);
        }

        public void setCookiesforLegacy(Models.Publishing.PublisherSettings _publisherSettings)
        {
            var httpCookie = Response.Cookies.Get("IsChannelSupported");
            if (httpCookie != null)
                Response.Cookies["IsChannelSupported"].Value = _publisherSettings.IsChannelSupported.ToString().ToLower();
            else
                Response.Cookies.Add(new HttpCookie("IsChannelSupported", _publisherSettings.IsChannelSupported.ToString().ToLower()));


            httpCookie = Response.Cookies.Get("IsOrgHierarchySupported");
            if (httpCookie != null)
                Response.Cookies["IsOrgHierarchySupported"].Value = RuntimeContext.Provider.FeatureMatrix.IsOrgHierarchySupported.ToString().ToLower();
            else
                Response.Cookies.Add(new HttpCookie("IsOrgHierarchySupported", RuntimeContext.Provider.FeatureMatrix.IsOrgHierarchySupported.ToString().ToLower()));
        }

        /// <summary>
        /// Get json data for header section of page
        /// </summary>
        /// <returns></returns>
        public JsonResult GetHeaderJson()
        {
            try
            {
                var provider = RuntimeContext.Provider;
                var user = RuntimeContext.Operator;

                if (provider == null || user == null)
                {
                    Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    Response.StatusDescription = "InvalidSession";
                    return Json(new { Success = false, Error = "InvalidSession" });
                }

                var vpsLogoGuid = (provider.ExtendedParams.DisplayLogoOnWebApp == "Y") ? provider.WebImageId : string.Empty;
                string welcomemsg = provider.ExtendedParams.WelcomeMessage == null ? string.Empty : provider.ExtendedParams.WelcomeMessage;
                var welcomeMessage = WebUtility.HtmlEncode(welcomemsg).Replace("\n", "<br/>");

                return Json(new { Success = true, Data = new { VpsLogoGuid = vpsLogoGuid, WelcomeMessage = welcomeMessage } });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);

                //returning HTTP status code in addition to the translated message from resource.
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                Response.StatusDescription = IWSResources.Home_DataLoad_Error_Header;
                return Json(new { Success = false });
            }
        }

        /// <summary>
        /// Get json data for page sections and counts
        /// </summary>
        /// <returns></returns>
        public JsonResult GetHomeJson()
        {
            try
            {
                var provider = RuntimeContext.Provider;
                var user = RuntimeContext.Operator;

                if (provider == null || user == null)
                {
                    Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    Response.StatusDescription = "InvalidSession";
                    return Json(new { Success = false, Error = "InvalidSession" });
                }

                var model = GetHomeModel(provider, user);

                return Json(new { Success = true, Data = model, Errors = model.Errors });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);

                //returning HTTP status code in addition to the translated message from resource.
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                Response.StatusDescription = IWSResources.Home_DataLoad_Error;
                return Json(new { Success = false });
            }
        }

        /// <summary>
        /// Helper method to load home model
        /// </summary>
        /// <returns>HomeModel</returns>
        private HomeModel GetHomeModel(Provider provider, OperatorUser user, bool fullLoad = true)
        {
            var model = new HomeModel();
            try
            {
                model.Identifier = string.Format("{0}-{1}", user.UserRandomId, provider.Id);
                model.IsAffiliate = (provider.ProviderType() == VPSType.Affiliate25 || provider.ProviderType() == VPSType.Affiliate25Template);

                try
                {
                    model.HealthStatus = _healthMonitorFacade.GetHealthStatus(provider.Id);
                }
                catch (Exception ex)
                {
                    _logService.Error(() => ex);
                    model.Errors.Add(IWSResources.Home_Error_HealthInformation);
                }

                if (fullLoad)
                {
                    /*
                     * Call through API to get user conut
                     * This commented logic considers UserBase restriction for count
                     * But for performance reason we decided to use second method with single SP
                     * If the requirement for UserBase restriction comes back either uncomment following or refactor SP to consider UserBase
                     * 
                    var userCounts = _userManager.GetUserCounts(provider.Id, user.Id);
                    model.ActiveUsers = userCounts.EnabledUsers;
                    model.OnlineUsers = userCounts.OnlineUsers;

                    var counts = _sysRptFacade.GetDeviceCoverageSummary();
                    model.MobileUsers = counts.MobileAppUserCount;
                    model.NoDeviceUsers = counts.NoDeviceUserCount;
                    */

                    try
                    {
                        var userCounts = _userManager.GetHomePageUserCounts(provider.Id, RuntimeContext.OperatorId);
                        model.ActiveUsers = userCounts.TotalEnabledUsers.Value;
                        model.OnlineUsers = userCounts.CurrentOnlineUsers.Value;
                        model.MobileUsers = userCounts.MpnEnabledUsers.Value;
                        model.NoDeviceUsers = userCounts.EnabledUsersWithNoDevice.Value;
                    }
                    catch (Exception ex)
                    {
                        _logService.Error(() => ex);
                        model.Errors.Add(IWSResources.Home_Error_UserCount);
                    }
                }

                model.VpsLogoGuid = (provider.ExtendedParams.DisplayLogoOnWebApp == "Y") ? provider.WebImageId : string.Empty;
                string welcomemsg = provider.ExtendedParams.WelcomeMessage == null ? string.Empty : provider.ExtendedParams.WelcomeMessage;
                model.WelcomeMessage = WebUtility.HtmlEncode(welcomemsg).Replace("\n", "<br/>");
                model.UpdatedOn = provider.CurrentSystemTimeToVpsTimeString();
                model.WebImageAlternateText = provider.ExtendedParams.WebImageAlternateText;

                // Start Changed for IWS-21927
                var operatorAccess = _operatorDetailsFacade.GetOperatorAccess(new OperatorAccessSpec
                {
                    OperatorId = RuntimeContext.OperatorId,
                    ProviderId = RuntimeContext.ProviderId
                });

                // Roles in  Advanced Alert Manager, Alert Publisher, Enterprise admin, Virtual System Admin, Report Manager, Standby alert creator
                model.HasAccessToAlerts =  _authFacade.HasAccess(operatorAccess, SystemObject.AdvancedAlertManager, ActionType.View)
                    ||  _authFacade.HasAccess(operatorAccess, SystemObject.AlertPublisher, ActionType.View)
                    ||  _authFacade.HasAccess(operatorAccess, SystemObject.EnterpriseAdmin, ActionType.View)
                    ||  _authFacade.HasAccess(operatorAccess, SystemObject.VirtualSystemAdministrator, ActionType.View)
                    ||  _authFacade.HasAccess(operatorAccess, SystemObject.Alert, ActionType.View);

                model.HasAccessToScenarios =  _authFacade.HasAccess(operatorAccess, SystemObject.ScenarioManager, ActionType.View)
                    ||  _authFacade.HasAccess(operatorAccess, SystemObject.ScenarioPublisher, ActionType.View)
                    ||  _authFacade.HasAccess(operatorAccess, SystemObject.AdvancedAlertManager, ActionType.View)
                    ||  _authFacade.HasAccess(operatorAccess, SystemObject.AlertPublisher, ActionType.View)
                    ||  _authFacade.HasAccess(operatorAccess, SystemObject.EnterpriseAdmin, ActionType.View)
                    ||  _authFacade.HasAccess(operatorAccess, SystemObject.VirtualSystemAdministrator, ActionType.View);

                model.HasAccessToEvents = _authFacade.HasAccess(operatorAccess, SystemObject.EventManager, ActionType.View);
                //since 86R3, anybody can see the data.
                //model.HasAccessToEvents = true;

                model.CanStartAccountabilityEvent = _authFacade.HasAccess(operatorAccess, SystemObject.AccountabilityEvent, ActionType.Modify) && RuntimeContext.Provider.FeatureMatrix.IsAccountabilitySupported;

                model.HasAccessToAccountability = _authFacade.HasAccess(operatorAccess, SystemObject.AccountabilityEvent, ActionType.View) && RuntimeContext.Provider.FeatureMatrix.IsAccountabilitySupported;

                model.CanPublishAlert =  _authFacade.HasAccess(operatorAccess, SystemObject.ScenarioManager, ActionType.View)
                    ||  _authFacade.HasAccess(operatorAccess, SystemObject.ScenarioPublisher, ActionType.View)
                    ||  _authFacade.HasAccess(operatorAccess, SystemObject.AdvancedAlertManager, ActionType.View)
                    ||  _authFacade.HasAccess(operatorAccess, SystemObject.AlertPublisher, ActionType.View)
                    ||  _authFacade.HasAccess(operatorAccess, SystemObject.EnterpriseAdmin, ActionType.View)
                    ||  _authFacade.HasAccess(operatorAccess, SystemObject.VirtualSystemAdministrator, ActionType.View);

                model.CanManagerUsers =  _authFacade.HasAccess(operatorAccess, SystemObject.AdvancedAlertManager, ActionType.View)
                    ||  _authFacade.HasAccess(operatorAccess, SystemObject.EndUsers, ActionType.View)
                    ||  _authFacade.HasAccess(operatorAccess, SystemObject.EnterpriseAdmin, ActionType.View)
                    ||  _authFacade.HasAccess(operatorAccess, SystemObject.VirtualSystemAdministrator, ActionType.View);

                model.CanConnectToOrg =  _authFacade.HasAccess(operatorAccess, SystemObject.Organization, ActionType.View);
                   

                // End Changed for IWS-21927

                if (fullLoad)
                {
                    try
                    {
                        model.LastLoginTime = user.LastLoginTime.HasValue && user.LastLoginTime != 0
                            ? provider.GetVpsDateTimeFromSecondsFormated(user.LastLoginTime.Value)
                            : string.Empty;
                        model.LoginFailedAttempts = user.LastFailedAttempts;
                        model.PasswordUpdatedOn = user.PasswordUpdatedOn.HasValue
                            ? provider.GetVpsDateTimeFromSecondsFormated(user.PasswordUpdatedOn.Value)
                            : string.Empty;
                    }
                    catch (Exception ex)
                    {
                        _logService.Error(() => ex);
                        model.Errors.Add(IWSResources.Home_Error_LastLogin);
                    }


                    //Organization counts
                    model.IsOrganizationConnected = false;
                    model.OrganizationCount = 0;
                    model.OrganizationInviteCount = 0;

                    try
                    {
                        if (model.CanConnectToOrg)
                        {
                            var status = _organizationFacade.GetConnectivityStatus(provider.Id);
                            model.IsOrganizationConnected = (status == ConnectivityStatus.Connected);
                            if (model.IsOrganizationConnected)
                            {
                                var orgStat = OrganizationHelper.GetHomePageStatistcs();
                                var inboxStat = InboxHelper.GetConnnectRequestCount();
                                model.OrganizationCount = orgStat.ExistingConnectionCount;
                                model.OrganizationInviteCount = inboxStat.RequestCount;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        _logService.Error(() => ex);
                        model.Errors.Add(IWSResources.Home_Error_OrganizationCount);
                    }
                }
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                model.Errors.Add(IWSResources.Home_Error_CountGeneric);
            }

            return model;
        }

        public JsonResult GetHealthInfo()
        {
            try
            {
                var provider = RuntimeContext.Provider;
                var user = RuntimeContext.Operator;

                if (provider == null || user == null)
                {
                    Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    Response.StatusDescription = "InvalidSession";
                    return Json(new { Success = false, Error = "InvalidSession" });
                }

                var data = _healthMonitorFacade.GetHealthStatus(provider.Id);

                return Json(data);
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                //returning HTTP status code in addition to the translated message from resource.
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                Response.StatusDescription = IWSResources.Home_DataLoad_Error_HealthInfo;
                return Json(new { Success = false });
            }
        }

        [HttpPost]
        public JsonResult GetMapLayerCount(List<int> ids, bool isEvent)
        {
            if (ids == null || !ids.Any())
                return Json(new { count = 0 });

            var count = _alertFacade.GetMapAlertCount(ids, isEvent);
            return Json(new { count = count });
        }

        /// <summary>
        /// Fetch Json data for live alerts
        /// </summary>
        /// <returns>Live alerts - Json</returns>
        public JsonResult GetLiveAlerts()
        {
            try
            {
                var provider = RuntimeContext.Provider;
                var user = RuntimeContext.Operator;

                if (provider == null || user == null)
                {
                    Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    Response.StatusDescription = "InvalidSession";
                    return Json(new { Success = false, Error = "InvalidSession" });
                }

                var alertSpec =
                    new AlertSearchSpec
                    {
                        OperatorId = user.Id,
                        ProviderId = provider.Id,
                        StatusFilter = new List<string> { "Live" }
                    };

                var alerts = _alertFacade.GetAlerts(alertSpec);

                var currentVpsTime = provider.CurrentSystemTimeToVps();

                var data = alerts.GetList().Select(a =>
                    new
                    {
                        AlertId = a.Id,
                        AlertTitle = a.Title.TruncateText(),
                        PublishedTime = a.StartTime,
                        PublishedTimeString = RuntimeContext.Provider.SystemToVpsDateTimeFormated(a.StartTime),
                        Remaining = FormatUtility.GetTimeSpan(currentVpsTime, RuntimeContext.Provider.SystemToVpsTime(a.EndTime)),
                        Targeted = a.Tracking.Targeted,
                        Sent = a.Tracking.Sent,
                        Responded = Math.Max(a.Tracking.Responded, a.Tracking.Acknowledged),
                        Body = a.Body.TruncateText(),
                        Responses = a.Tracking.Response
                    });

                return Json(data);
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);

                //returning HTTP status code in addition to the translated message from resource.
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                Response.StatusDescription = IWSResources.Home_DataLoad_Error_Alerts;
                return Json(new { Success = false });
            }

        }

        /// <summary>
        /// Fetch Json data for quick publish 
        /// </summary>
        /// <returns>Quick publish scenario - Json</returns>
        public JsonResult GetQuickPublish()
        {
            try
            {
                var provider = RuntimeContext.Provider;
                var user = RuntimeContext.Operator;

                if (provider == null || user == null)
                {
                    Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    Response.StatusDescription = "InvalidSession";
                    return Json(new { Success = false, Error = "InvalidSession" });
                }

                var scenarioSpec = new ScenarioSearchSpec { QuickOnly = true, ExcludeSystemScenarios = true };

                var scenarios = _scenarioFacade.GetScenarios(provider.Id, user.Id, scenarioSpec);

                var data = scenarios.Select(s =>
                    new
                    {
                        s.ScenarioId,
                        Name = s.Name.TruncateText(),
                        ChannelName = s.ChannelName.TruncateText(),
                        s.IsReadyForPublish,
                        PublishedOn = s.PublishedOn,
                        PublishedOnString = (s.PublishedOn == DateTime.MinValue) ? string.Empty : RuntimeContext.Provider.SystemToVpsDateTimeFormated(s.PublishedOn),
                        Description = s.Description.TruncateText(200),
                        AlertTitle = s.AlertTitle.TruncateText(),
                        AlertBody = s.AlertBody.TruncateText()
                    });

                return Json(data);
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);

                //returning HTTP status code in addition to the translated message from resource.
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                Response.StatusDescription = IWSResources.Home_DataLoad_Error_QuickPublish;
                return Json(new { Success = false });
            }
        }

        /// <summary>
        /// Get Json data for recent events (latest 10 events)
        /// </summary>
        /// <returns></returns>
        public JsonResult GetEvents()
        {
            try
            {
                var provider = RuntimeContext.Provider;
                var user = RuntimeContext.Operator;

                if (provider == null || user == null)
                {
                    Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    Response.StatusDescription = "InvalidSession";
                    return Json(new { Success = false, Error = "InvalidSession" });
                }

                //Build Event Spec for Events
                var eventSpec = new EventSpec { Page = 1, PageSize = 10, OrderBy = "CreatedOn", OrderAsc = false, ProviderId = RuntimeContext.ProviderId};
                eventSpec.CurrentDbUtc = RuntimeContext.Provider.VpsToUtcTime(RuntimeContext.Provider.CurrentSystemTimeToVps());
                eventSpec.FuncVpsToUtcTime = RuntimeContext.Provider.VpsToUtcTime;
                eventSpec.Operator = RuntimeContext.Operator;
                eventSpec.ViewType = EventViewType.Inbox;
                eventSpec.OperatorId = RuntimeContext.OperatorId;

                //Get Events (Event Media attachment does not require for Homepage, thus pass false. (Optional)
                var domainEvents = _eventFacade.GetEventsBySpec(eventSpec, false);

                var eventsViewModel = Models.Event.EventModel.GenerateEventModels(_userFacade, domainEvents.Events.Data, domainEvents.EventCategories);

                return Json(new { TotalCount = domainEvents.Events.Count, Data = eventsViewModel });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);

                //returning HTTP status code in addition to the translated message from resource.
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                Response.StatusDescription = IWSResources.Home_DataLoad_Error_Events;
                return Json(new { Success = false });
            }

        }

        /// <summary>
        /// Get Json data for online users in last 24 hours
        /// </summary>
        /// <returns></returns>
        public JsonResult GetOnlineUsersInLast24Hours()
        {
            try
            {
                var provider = RuntimeContext.Provider;
                var user = RuntimeContext.Operator;

                if (provider == null || user == null)
                {
                    Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    Response.StatusDescription = "InvalidSession";
                    return Json(new { Success = false, Error = "InvalidSession" });
                }

                var list = _sysRptFacade.GetSnapShotReportData(SnapShotReportType.OnlineUserCount, provider);
                return Json(new { data = list, max = list.Max(i => i.Value) });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);

                //returning HTTP status code in addition to the translated message from resource.
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                Response.StatusDescription = IWSResources.Home_DataLoad_Error_OnlineUsersChart;
                return Json(new { Success = false });
            }
        }

        /// <summary>
        /// Get Json data for messages sent in last 24 hours. 
        /// This is sent alerts as of now.
        /// </summary>
        /// <returns></returns>
        public JsonResult GetMessagesSentInLast24Hours()
        {
            try
            {
                var provider = RuntimeContext.Provider;
                var user = RuntimeContext.Operator;

                if (provider == null || user == null)
                {
                    Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    Response.StatusDescription = "InvalidSession";
                    return Json(new { Success = false, Error = "InvalidSession" });
                }

                var list = _sysRptFacade.GetSnapShotReportData(SnapShotReportType.MessagesSent, provider);
                return Json(new { data = list, total = list.Sum(i => i.Value) });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);

                //returning HTTP status code in addition to the translated message from resource.
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                Response.StatusDescription = IWSResources.Home_DataLoad_Error_MessageSentChart;
                return Json(new { Success = false });
            }
        }

        /// <summary>
        /// Action method to accept the affiliate terms and conditions
        /// </summary>
        /// <returns></returns>
        public JsonResult AcceptAffTerms(int providerId, int userId)
        {
            _virtualSystemFacade.AcceptAffiliateTermsConditions(providerId, userId);
            return Json(new { Success = true });

        }

        /// <summary>
        /// Action method to decline affiliate terms and conditions
        /// </summary>
        /// <returns></returns>

        public JsonResult DeclineAffTerms(int providerId, int userId)
        {
            _virtualSystemFacade.DeclineAffiliateTermsConditions(providerId, userId);
            return Json(new { Success = false });

        }

        /// <summary>
        /// Fetch Json data for live PA events
        /// </summary>
        /// <returns>Live events - Json</returns>
        public JsonResult GetLiveEvents()
        {
            try
            {
                var provider = RuntimeContext.Provider;
                var user = RuntimeContext.Operator;

                if (provider == null || user == null)
                {
                    Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    Response.StatusDescription = "InvalidSession";
                    return Json(new { Success = false, Error = "InvalidSession" });
                }

                var eventSpec =
                    new AccountabilityEventSearchSpec
                    {
                        VpsIds = string.Join(",",GetAllVpsIds()),
                        Status = new[] { AccountabilityEventStatus.Live.ToString() }
                    };

                var events = _acctFacade.GetAccountabilitySearchResult(eventSpec);

                var currentVpsTime = provider.CurrentSystemTimeToVps();

                var ret = from e in events.GetList()
                          select new LiveEventModel
                          {
                              EventId = e.EventId,
                              AlertBaseId = e.AlertBaseId,
                              Title = e.EventName,
                              Description = e.EventDescription,
                              TimeLeft = FormatUtility.GetTimeSpan(currentVpsTime, RuntimeContext.Provider.SystemToVpsTime(e.EndDate)),
                              Responses = (from r in e.Responses
                                           select new AlertResponse
                                           {
                                               Response = r.ResponseText,
                                               Number = r.ResponseCount.Value
                                           }).ToList(),
                              StartTime = e.StartedOn,
                        StartTimeDisplay = RuntimeContext.Provider.SystemToVpsDateTimeFormated(e.StartedOn),
                        Affected = e.Affected,
                        UsersResponded = e.UsersResponded,
                        UsersNotResponded = e.UsersNotResponded,
                    };

                return Json(ret);
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);

                //returning HTTP status code in addition to the translated message from resource.
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                Response.StatusDescription = IWSResources.Home_DataLoad_Error;
                return Json(new { Success = false });
            }

        }
        private List<int> GetAllVpsIds()
        {
            var organizations = _acctFacade.GetSubOrganizationsWithNames(RuntimeContext.ProviderId);
            var data = new List<int>();
            data.Add(RuntimeContext.ProviderId);
            data.AddRange(organizations.Select(org => org.Key));
            return data;
        }

    }


}