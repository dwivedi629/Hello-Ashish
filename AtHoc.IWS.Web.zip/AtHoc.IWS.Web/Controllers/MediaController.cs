﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using AtHoc.Infrastructure.Web;
using AtHoc.Infrastructure.Resources;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Web.Filters;
using AtHoc.Infrastructure.MediaWrapper;
using System.IO;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.Infrastructure.Log;

namespace AtHoc.IWS.Web.Controllers
{

	public class MediaController : AtHoc.Infrastructure.Web.Mvc.Controller
    {

        private readonly IAudioFileFacade _audioFileFacade;
        private readonly ILogService _logService;

        public MediaController(IAudioFileFacade audioFileFacade, ILogService logService)
        {
            _audioFileFacade = audioFileFacade;
            _logService = logService;
        }

        [OutputCache(VaryByParam = "id;download;mediaType;ts", Duration = Int32.MaxValue)]
        public ActionResult Get(string id)
        {
            string fileName = "";
            Stream imageStream = MediaServiceWrapper.GetMedia(id, out fileName);
            var contentType = GetContentType(fileName);
            if (imageStream != null)
            {
                return File(imageStream, contentType,fileName);
            }

            return new EmptyResult();
        }

	    private string GetContentType(string fileName)
	    {
	        var extension = Path.GetExtension(fileName);
            var contentType = string.Empty;
	        if (extension != null)
	        {
	            var extn = extension.Replace(".", "");
	            switch (extn)
	            {
	                case "jpg":
	                    contentType = string.Format("image/{0}", "jpeg");
	                    break;
	                default:
                        contentType = string.Format("image/{0}", extn);
	                    break;
	            }
	        }
	        return contentType;
	    }

        public ActionResult GetAudioByAudioId(int id)
        {

            byte[] content = null;
            try
            {
                content = _audioFileFacade.DownloadAudioFile(id);
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
            }
            
        
            Response.Headers.Add("Content-Range", "bytes 0-" +  (content.Length-1).ToString() +  "/" + content.Length.ToString());
            Response.Headers.Add("Content-Length", content.Length.ToString());
            Response.Headers.Add("Accept-Ranges", "bytes");
            //Response.AddHeader("Content-Disposition", string.Format("{0};filename={1}", "attachment","audio" + id.ToString() + ".wav"));

            return new FileContentResult(content, "audio/wav");

        }

    }
}
