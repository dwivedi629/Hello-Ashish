﻿using System.Data.Entity;
using System.IO;
using System.Web;
using System.Web.Script.Serialization;
using System.Xml.XPath;
using AtHoc.Infrastructure.Extensions;
using AtHoc.Infrastructure.Template;
using AtHoc.Infrastructure.Web.Mvc.ActionFilters;
using AtHoc.IWS.Business.Domain.Accountability;
using AtHoc.IWS.Business.Domain.Accountability.Specs;
using AtHoc.IWS.Business.Domain.CustomAttributes;
﻿using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
﻿using AtHoc.IWS.Business.Domain.Devices;
﻿using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Event.Spec;
using AtHoc.IWS.Business.Domain.Events;
﻿using AtHoc.IWS.Business.Domain.Map;
﻿using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Business.Domain.Reports;
using AtHoc.IWS.Business.Domain.Users.Impl;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.IWS.Web.Configurations.Constants;
using AtHoc.IWS.Web.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using AtHoc.Global.Resources;
using AtHoc.IWS.Business.Data.SearchSpec;
using AtHoc.IWS.Business.Context;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Security;
using AtHoc.IWS.Web.Models.Publishing;
using AtHoc.Data;
using AtHoc.IWS.Web.Models.Report;
using AtHoc.Publishing;
using AtHoc.IWS.Web.Helpers;
using AtHoc.IWS.Business.Domain.Authorization;
using System.Globalization;
using AtHoc.Systems;
using EO.Internal;
using EO.Pdf.Mvc;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Web.Models.UserManager;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;
using AtHoc.IWS.Business.Domain.Devices.Spec;
using AtHoc.Global.Resources.Interfaces;
using System.Web.SessionState;

namespace AtHoc.IWS.Web.Controllers
{
    [SessionState(SessionStateBehavior.ReadOnly)]
    public class AlertManagerController : Infrastructure.Web.Mvc.Controller
    {
        private readonly IAlertFacade _alertFacade;
        private readonly ILogService _logService;
        private readonly IEventFacade _eventFacade;
        private readonly IAuthFacade _authFacade;
        private readonly IPublishingDomainToModel _publishingDomainToModel;
        private readonly IUserFacade _userFacade;
        private readonly IPublishingFacade _pubFacade;
        private readonly IUserManagerHelper _userManagerHelper;
        private CustomAttributeLookup _providerAttributes;
        private readonly ICustomAttributeFacade _customAttributeFacade;
        private readonly IDeviceFacade _deviceFacade;
        private readonly IPublishingModelToDomain _publisherModelToDomain;
        private readonly IPlaceHolderFacade _placeholderFacade;
        private readonly IGlobalEntityLocaleFacade _globalEntityLocaleFacade;
        private readonly IOperatorDetailsFacade _operatorDetailsFacade;
        private readonly IAccountabilityFacade _accountabiltyFacade;
        private readonly ICustomAttributeCache _customAttributeCache;


        public AlertManagerController(IAlertFacade alertFacade, IAuthFacade authFacade, IPublishingDomainToModel publishingDomainToModel,
            ILogService logService, IEventFacade eventFacade, IUserFacade userFacade, IPublishingFacade pubFacade, IMapFacade mapFacade,
            UserManagerHelper userManagerHelper, ICustomAttributeFacade customAttributeFacade, IDeviceFacade deviceFacade,
            IPublishingModelToDomain publisherModelToDomain, IPlaceHolderFacade placeholderFacade, IGlobalEntityLocaleFacade globalEntityLocaleFacade,
            IOperatorDetailsFacade operatorDetailsFacade, IAccountabilityFacade accountabiltyFacade, ICustomAttributeCache customAttributeCache)
        {
            _alertFacade = alertFacade;
            _authFacade = authFacade;
            _publisherModelToDomain = publisherModelToDomain;
            _logService = logService;
            _eventFacade = eventFacade;
            _userFacade = userFacade;
            _pubFacade = pubFacade;
            _userManagerHelper = userManagerHelper;
            _customAttributeFacade = customAttributeFacade;
            _deviceFacade = deviceFacade;
            _publishingDomainToModel = publishingDomainToModel;
            _placeholderFacade = placeholderFacade;
            _globalEntityLocaleFacade = globalEntityLocaleFacade;
            _operatorDetailsFacade = operatorDetailsFacade;
            _accountabiltyFacade = accountabiltyFacade;
            _customAttributeCache = customAttributeCache;
        }

        // GET: Alert
        [IWSAuthorize(new[] { SystemObject.Alert }, new[] { ActionType.View })]
        [HttpPost]
        public ActionResult Index(string id = null, string nav = "", string source = "", InboxEvent inboxEvent = null, string recipientType = null, string horizontalFilterName = null, string statusFilter = null, int accEventId = 0)
        {
            if (!string.IsNullOrEmpty(statusFilter) && statusFilter.ToLower() != "scheduled")
            {
                throw new HttpException(400, "The URL is invalid. Please check for errors and try again.");
            }

            var provider = RuntimeContext.Provider;
            int alertId = 0;
            if (!string.IsNullOrEmpty(id) && !int.TryParse(id, out alertId))
            {
                throw new HttpException(400, "The URL is invalid. Please check for errors and try again.");
            }

            if (alertId < 0)
            {
                throw new HttpException(400, "The URL is invalid. Please check for errors and try again.");
            }

            // Changed for IWS-21927
            var operatorAccess = _operatorDetailsFacade.GetOperatorAccess(new OperatorAccessSpec
            {
                OperatorId = RuntimeContext.OperatorId,
                ProviderId = RuntimeContext.ProviderId
            });

            ViewBag.UserNameAttributeName = CustomAttributesHelper.GetProviderAttributes(_customAttributeCache, RuntimeContext.ProviderId, RuntimeContext.Provider.BaseLocale, true, true).GetByCommonName(CommonNames.UserName).AttributeName;

            ViewBag.TopicToHighlight = MenuTopicsId.alerting;
            ViewBag.PublisherSettings = _publishingDomainToModel.GetPublisherSettings(provider);
            ViewBag.PlaceHolderItems = new JavaScriptSerializer().Serialize(_placeholderFacade.GetPlaceHolderList(provider.Id, RuntimeContext.OperatorId).Where(i => i.IsSystem));

            var vpsTimeZOne = RuntimeContext.Provider.GetVpsTimeZoneFromId();
            ViewBag.DateFormat = provider.GetDateFormat();
            ViewBag.DateTimeFormat = provider.GetDateTimeFormat();
            ViewBag.VPSTimeZone = vpsTimeZOne;
            ViewBag.UtcOffsetInMinutes = vpsTimeZOne.BaseUtcOffset.TotalMinutes;
            ViewBag.VPSOffsetFromSystemInMinutes = provider.VPSOffsetFromSystemInMinutes();
            ViewBag.SupportsDaylightSavingTime = vpsTimeZOne.SupportsDaylightSavingTime;
            ViewBag.IsAlertPublisher = _authFacade.HasAccess(operatorAccess, SystemObject.Alert, ActionType.Modify); // Changed for IWS-21927
            ViewBag.IsAffiliate = (provider.ProviderType() == VPSType.Affiliate25 || provider.ProviderType() == VPSType.Affiliate25Template);
            if (source == "e")
            {
                if (inboxEvent != null)
                {
                    Priority severity;
                    if (Enum.TryParse(inboxEvent.Severity, true, out severity))
                    {
                        inboxEvent.SeverityId = (int)severity;
                    }
                    else
                        throw new HttpException(400, "Invalid Severity code");

                    var eventCategories = _eventFacade.GetEventCategories(RuntimeContext.Provider.Id);


                    //inboxEvent.EventCategoryId has been evaluted at detailview.js
                    var originalEventCategory = eventCategories.FirstOrDefault(ec => ec.EventCategoryId == inboxEvent.EventCategoryId);

                    var currentCategoryCommonName = eventCategories.FirstOrDefault(eventCategory => eventCategory.Name.Equals(inboxEvent.Type, StringComparison.InvariantCultureIgnoreCase));
                    string eventCommonName = string.Empty;
                    if (currentCategoryCommonName != null)
                    {
                        var logCommonName = currentCategoryCommonName.CommonName;
                        eventCommonName = currentCategoryCommonName.CommonName;
                        if (logCommonName == Business.Domain.Event.ObjectModel.EventCategoryConstant.CommonName.LogManual || logCommonName == Business.Domain.Event.ObjectModel.EventCategoryConstant.CommonName.LogAlert)
                            source = "l";//"l" represents that the event is comming form AL .
                    }

                    var eventCatOfOtherType = eventCategories.FirstOrDefault(ec => ec.CommonName == Business.Domain.Event.ObjectModel.EventCategoryConstant.CommonName.Other);

                    //We cannot directly use the inboxEvent.Type because while forwarding from Activity Log, the TYPE will be ALERT or LOG which not the real event (Original event category id)
                    if (originalEventCategory != null && originalEventCategory.CommonName!=null)
                    {

                        //For Manual Log forward - make sure the OTHER alert type should get forward.
                        if (eventCommonName == Business.Domain.Event.ObjectModel.EventCategoryConstant.CommonName.LogManual)
                        {
                            //It cannot be possible that OTHER type of eventcategory is missing from system. if it is not avaiable then metadata is missing for provider Id.
                            if (eventCatOfOtherType == null)
                            {
                                throw new NullReferenceException(string.Format("Unable to find EventCategory for provider id ={0} and CommonName ='OTHER')", RuntimeContext.ProviderId));

                            }
                            inboxEvent.Type = eventCatOfOtherType.Name;
                            inboxEvent.TypeId = eventCatOfOtherType.EventCategoryId;
                            inboxEvent.EventCategoryId = eventCatOfOtherType.EventCategoryId; //TODO:Need to remove duplicate assignment.
                        }
                        else
                        {
                            inboxEvent.Type = originalEventCategory.Name;
                            inboxEvent.TypeId = originalEventCategory.EventCategoryId;
                            inboxEvent.EventCategoryId = originalEventCategory.EventCategoryId;
                        }
                    }
                    else
                    {


                        //It cannot be possible that OTHER type of eventcategory is missing from system. if it is not avaiable then metadata is missing for provider Id.
                        if (eventCatOfOtherType == null)
                        {
                            throw new NullReferenceException(string.Format("Unable to find EventCategory for provider id ={0} and CommonName ='OTHER')", RuntimeContext.ProviderId));

                        }
                        inboxEvent.Type = eventCatOfOtherType.Name;
                        inboxEvent.TypeId = eventCatOfOtherType.EventCategoryId;
                        inboxEvent.EventCategoryId = eventCatOfOtherType.EventCategoryId; //TODO:Need to remove duplicate assignment.
                    }

                }

                inboxEvent.Title = XxeValidation.GetHtmlEncode(inboxEvent.Title);
                inboxEvent.Description = XxeValidation.GetHtmlEncode(inboxEvent.Description);
                inboxEvent.Url = XxeValidation.GetUrlEncode(inboxEvent.Url);
                ViewBag.Event = inboxEvent;
            }

            ViewBag.HasModifyAccess = _authFacade.HasAccess(operatorAccess, SystemObject.Alert, ActionType.Modify);
            ViewBag.HasPublishAccess = _authFacade.HasAccess(operatorAccess, SystemObject.Alert, ActionType.Publish);

            ViewBag.DateFormat = provider.GetDateFormat();
            ViewBag.CurrentDateTime = provider.CurrentSystemTimeToVps().ToString(CultureInfo.InvariantCulture);
            ViewBag.OperatorName = RuntimeContext.Operator.DisplayName;
            //Deeplink support for alerts, also allow only one character for action for security
            if (!string.IsNullOrWhiteSpace(nav) && nav.Length == 1)
            {
                nav = nav.ToLower();
                switch (nav)
                {
                    case "c":
                        ViewBag.Action = "create";
                        break;
                    case "v":
                        ViewBag.Action = "view";
                        break;
                    case "r":
                        ViewBag.Action = "rbt";
                        break;
                    default:
                        throw new HttpException(400, "The URL is invalid. Please check for errors and try again.");
                }
                ViewBag.Id = alertId;
            }

            //Navigation source to re-route
            if (!string.IsNullOrWhiteSpace(source) && source.Length == 1)
            {
                source = source.ToLower();
                switch (source)
                {
                    case "p":
                        ViewBag.Source = "publisher";
                        break;
                    case "h":
                        ViewBag.Source = "home";
                        break;
                    case "e":
                        ViewBag.Source = "event";
                        break;
                    case "r":
                        ViewBag.Source = "rbt";
                        break;
                    case "l":
                        ViewBag.Source = "log";
                        break;
                    default:
                        throw new HttpException(400, "The URL is invalid. Please check for errors and try again.");
                }
            }


            if (recipientType != null)
            {
                var rbt = getRBTCriteria(recipientType, alertId, horizontalFilterName, provider.Id);
                rbt.AccountabilityEventId = accEventId;
                ViewBag.ResultBasedTargeting = rbt;
                ViewBag.Source = "rbt";
            }


            return View();
        }


        /// <summary>
        /// Returns the alert tracking report view.
        /// </summary>
        /// <param name="id">alert Id</param>
        /// <returns>alert tracking report view</returns>
        [IWSAuthorize(new[] { SystemObject.Alert }, new[] { ActionType.View })]
        public ActionResult ReportView(int? id)
        {
            ViewBag.isValidId = true;
            ViewBag.ErrorMessage = string.Empty;

            if (id != null)
            {
                var provider = RuntimeContext.RefreshedProviderContext;
                var _publisherSettings = _publishingDomainToModel.GetPublisherSettings(provider);
                ViewBag.PublisherSettings = _publisherSettings;
                var vpsTimeZOne = RuntimeContext.Provider.GetVpsTimeZoneFromId();
                ViewBag.DateFormat = provider.GetDateFormat();
                ViewBag.DateTimeFormat = provider.GetDateTimeFormat();
                ViewBag.VPSTimeZone = vpsTimeZOne;
                ViewBag.UtcOffsetInMinutes = vpsTimeZOne.BaseUtcOffset.TotalMinutes;
                ViewBag.VPSOffsetFromSystemInMinutes = provider.VPSOffsetFromSystemInMinutes();
                ViewBag.SupportsDaylightSavingTime = vpsTimeZOne.SupportsDaylightSavingTime;
                ViewBag.IsAlertPublisher = _authFacade.HasAccess(RuntimeContext.Operator, RuntimeContext.Provider.Id, SystemObject.Alert, ActionType.Modify);
                ViewBag.IsAffiliate = (provider.ProviderType() == VPSType.Affiliate25 || provider.ProviderType() == VPSType.Affiliate25Template);
                ViewBag.DateFormat = provider.GetDateFormat();
                ViewBag.CurrentDateTime = provider.CurrentSystemTimeToVps().ToString(CultureInfo.InvariantCulture);
            }
            else
            {
                ViewBag.isValidId = false;
                ViewBag.ErrorMessage = IWSResources.Alert_Error_LoadingAlertDetail;
                ViewBag.ErrorTitle = IWSResources.AtHoc_CommonErrMsg_Title_Error;
            }

            return View();
        }

        /// <summary>
        /// Returns the alert tracking summary data.
        /// </summary>
        /// <param name="id">alert Id</param>
        /// <returns></returns>
        [IWSAuthorize(new[] { SystemObject.Alert }, new[] { ActionType.View })]
        public JsonResult GetAlertTrackingSummaryData(int id, ReportType type = ReportType.Summary, Dimension dim = Dimension.USER)
        {
            var result = _alertFacade.GetAlertTrackingSummary(id, type, dim);
            var currentVpsTime = RuntimeContext.Provider.CurrentSystemTimeToVps();
            var remainingTime = FormatUtility.GetTimeSpan(currentVpsTime, RuntimeContext.Provider.SystemToVpsTime(result.RemainingTime));
            var alertEndAt = RuntimeContext.Provider.SystemToVpsDateTimeFormated(result.RemainingTime);
            List<ReportItem> ret = new List<ReportItem>();
            AlertTrackingSummary header = null;
            if (result.Summary != null)
            {
                //assuming first result set is the summary data
                //consisting of only one row
                header = result.Summary.FirstOrDefault();
                if (header != null)
                {
                    //todo: localize Category field...
                    ret.Add(new ReportItem { Category = IWSResources.Alert_Report_Targeted, RecipientType = "Targeted", Value = header.Tgt ?? 0, NormalizedValue = header.Tgt ?? 0 });
                    ret.Add(new ReportItem { Category = IWSResources.Alert_Report_Sent, RecipientType = "Sent", Value = header.Sent ?? 0, NormalizedValue = header.Sent ?? 0 });
                    ret.Add(new ReportItem { Category = IWSResources.Alert_Report_NotSent, RecipientType = "NotSent", Value = header.Not_Sent ?? 0, NormalizedValue = header.Not_Sent ?? 0 });
                    ret.Add(new ReportItem { Category = IWSResources.Alert_Response_Responded, RecipientType = "Ack", Value = header.Ack ?? 0, NormalizedValue = header.Ack ?? 0 });
                }
            }

            if (header != null && header.Any_Fill_Count == "Y") //adding 'any' fillcount special case
            {
                ret.Add(new ReportItem
                {
                    ID = 0,
                    FillCount =
                        new FillCountItem
                        {
                            FillCount = header.Fill_Count ?? 0,
                            AboveFillCount = header.Above_Fill_Count ?? 0,
                            IsAnyFillCount = true
                        }
                });
            }

            var responses = from r in result.Responses
                            select new ReportItem
                            {
                                ID = r.Response_Id,
                                Category = r.Response_Text,
                                Value = r.Count,
                                FillCount = (header != null && header.Any_Fill_Count != "Y") && r.Is_Fill_Count == "Y"
                                    ? new FillCountItem { FillCount = header.Fill_Count ?? 0, AboveFillCount = header.Above_Fill_Count ?? 0 }
                                    : null
                            };

            ret.AddRange(responses);

            if (header != null) //add 'no response' at the end...
            {
                ret.Add(new ReportItem { Category = IWSResources.Alert_Response_NoResponse, RecipientType = "NoResponse", Value = header.No_Response ?? 0, NormalizedValue = header.No_Response ?? 0 });
            }
            AlertStatus _status = (AlertStatus)Enum.Parse(typeof(AlertStatus), result.Status, true);
            var convertedStatus = convertStatus(_status);
            var currentDateTime = RuntimeContext.Provider.CurrentSystemTimeToVpsTimeString();

            var restrictedUser = RuntimeContext.Operator.IsRestricted;

            return Json(new[] { new
            {
                status = result.Status, statusLocalized = convertedStatus, items = ret, remainingTime, alertEndAt, currentVpsDateTime = currentDateTime, restrictedUser
            } });
        }
        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.Alert, SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View, ActionType.View })]
        public JsonResult GetAlertUserListData(int page = 1, int pageSize = 10, string sortBy = "Username", string sortOrder = "ASC", int userCountType = 0, int sessionId = 0, string attributeCSV = null, int totalCount = 0, string attributeSearchValue = "", string deviceIds = "", string displayColumnDeviceIds = "", string attributeIds = "", int fillCountAttributeId = 0)
        {
            //string attributeIds = "";
            var columns = new List<CustomViewColumn>();
            IEnumerable<Business.Domain.Entities.Device> allDevices = null;
            ILookup<string, Business.Domain.Entities.Device> devicesByCommonName = null;
            ILookup<string, Business.Domain.Entities.Device> devicesByName = null;
            _userManagerHelper.RefreshDevices(ref allDevices, ref devicesByCommonName, ref devicesByName, true);


            var provider = RuntimeContext.Provider;
            var customViews =
               _customAttributeFacade.GetCustomViewsBySpec(new CustomViewSpec
                {
                    ProviderId = provider.Id,
                    CustomViewType = (CustomViewType)Enum.Parse(typeof(CustomViewType), "UserReport"),
                    IsPlaceholder = false,
                    CustomViewColumnTypes = new[] { CustomViewColumnType.CustomField, CustomViewColumnType.Device, CustomViewColumnType.OrgName, CustomViewColumnType.Role },
                    DefaultOnly = true
                });

            var enumerable = customViews as IList<CustomView> ?? customViews.ToList();
            var customDefaultColumns = enumerable.Where(x => x.Columnid == CustomViewColumnType.CustomField && x.EntityId.HasValue && ProviderAttributes.GetById((int)x.EntityId) != null).Select(x => ProviderAttributes.GetById((int)x.EntityId).AttributeName).ToList();
            var deviceDefaultcolumns = enumerable.Where(x => x.Columnid == CustomViewColumnType.Device).ToList();

            var customattributes = ProviderAttributes.Where(x => customDefaultColumns.Contains(x.AttributeName)).Select(x => x.CommonName);
            var escalateAttribute = ProviderAttributes.GetById(fillCountAttributeId);
            int sortByAttributeId;
            int.TryParse(sortBy, out sortByAttributeId);
            if (sortByAttributeId > 0)
                sortBy = escalateAttribute.CommonName;

            if (customDefaultColumns.HasValue())
                attributeCSV = attributeCSV + String.Join(",", customattributes.ToArray());
            else
                attributeCSV = AttributeCommonNames.UserName + (attributeCSV != "" ? ("," + attributeCSV) : "");

            if (enumerable.Count(x => x.Columnid.Equals(CustomViewColumnType.OrgName)) > 0)
                attributeCSV = attributeCSV + "," + AttributeCommonNames.Organizations;

            if (enumerable.Count(x => x.Columnid == CustomViewColumnType.Role) > 0)
                attributeCSV = attributeCSV + "," + AttributeCommonNames.OperatorRoles;

            //if operator role is requested, automatically request one more column to get the count of roles in other organizations
            if (attributeCSV.Contains(AttributeCommonNames.OperatorRoles))
                attributeCSV = attributeCSV + "," + AttributeCommonNames.RoleCountOtherOrgs;

            if (escalateAttribute != null && !attributeCSV.Contains(escalateAttribute.CommonName))
                attributeCSV = attributeCSV + "," + escalateAttribute.CommonName;

            var argsSession = new UserSearchSession(false, true, true, page, pageSize, sortBy, sortOrder)
            {
                SessionId = sessionId,

                AttributeNames = attributeCSV.Trim(',').Split(',').ToList(),
            };
            argsSession.Options.GetCountsOnly = false;
            argsSession.Options.GetMassDevices = false;
            argsSession.Options.GetUsers = true;
            if (userCountType == -1) // All Users
            {
                argsSession.TargetAllUserBase = true;
            }
            if (displayColumnDeviceIds.HasValue() || deviceDefaultcolumns.HasValue())
                argsSession.DeviceNames = new List<string>();

            var _alldevices = allDevices as Business.Domain.Entities.Device[] ?? allDevices.ToArray();
            if (!string.IsNullOrEmpty(displayColumnDeviceIds))
            {
                IEnumerable<int> displayDevices = Array.ConvertAll(displayColumnDeviceIds.Trim(',').Split(char.Parse(",")),
                         s => int.Parse(s));

                foreach (var device in displayDevices)
                {
                    var deviceObj = _alldevices.FirstOrDefault(i => i.Id == device);
                    if (deviceObj != null && !string.IsNullOrEmpty(deviceObj.CommonName))
                        argsSession.DeviceNames.Add(deviceObj.CommonName);
                }
            }

            if (deviceDefaultcolumns.HasValue())
            {
                foreach (var device in deviceDefaultcolumns)
                {
                    var deviceObj = _alldevices.FirstOrDefault(i => i.Id == device.EntityId);
                    if (deviceObj != null && !string.IsNullOrEmpty(deviceObj.CommonName))
                        argsSession.DeviceNames.Add(deviceObj.CommonName);
                }


            }

            // pass device ids here that have been selected by the user
            if (deviceIds.Length > 0)
            {
                IEnumerable<int> devices = Array.ConvertAll(deviceIds.Trim(',').Split(char.Parse(",")),
                    s => int.Parse(s));

                if (userCountType == 0) // Non Reachable Users
                {
                    foreach (var device in devices)
                    {
                        if (argsSession.TargetCriteria == null)
                        {
                            argsSession.TargetCriteria = new DeviceCriteria(device, CriteriaOperator.IsEmpty, 0);
                        }
                        else
                        {
                            argsSession.TargetCriteria = argsSession.TargetCriteria & new DeviceCriteria(device, CriteriaOperator.IsEmpty, 0);
                        }
                    }
                }
                else if (userCountType == 1) // Reachable Users
                {
                    foreach (var device in devices)
                    {
                        if (argsSession.TargetCriteria == null)
                        {
                            argsSession.TargetCriteria = new DeviceCriteria(device, CriteriaOperator.IsNotEmpty, 0);
                        }
                        else
                        {
                            argsSession.TargetCriteria = argsSession.TargetCriteria | new DeviceCriteria(device, CriteriaOperator.IsNotEmpty, 0);
                        }
                    }
                }
            }
            //else
            //{
            //    argsSession.DeviceNames.Clear();
            //}

            if (!string.IsNullOrEmpty(attributeSearchValue.Trim()))
            {
                IEnumerable<int> attributes = Array.ConvertAll(attributeIds.Trim(',').Split(char.Parse(",")),
                   s => int.Parse(s));
                ExpressionElement searchCriteria = null;

                foreach (var attr in attributes)
                {
                    if (searchCriteria == null)
                        searchCriteria = new AttributeCriteria(attr, CriteriaOperator.Contains, attributeSearchValue.Trim());
                    else
                        searchCriteria = searchCriteria | new AttributeCriteria(attr, CriteriaOperator.Contains, attributeSearchValue.Trim());
                }
                if (argsSession.TargetCriteria != null)
                {
                    argsSession.TargetCriteria = argsSession.TargetCriteria & searchCriteria;
                }
                else
                {
                    argsSession.TargetCriteria = searchCriteria;
                }
            }

            var usersSession = _userFacade.SearchUsersBySession(argsSession);
            foreach (System.Data.DataColumn c in usersSession.UsersDataTable.Columns)
            {
                var commonName = c.ColumnName.ToUpper().Equals("USERNAME") ? AttributeCommonNames.UserName : c.ColumnName;
                CustomAttribute attribute = ProviderAttributes.GetByCommonName(commonName);
                if (attribute != null)
                {
                    columns.Add(new CustomViewColumn
                                     {
                                         Id = attribute.Id,
                                         DisplayName = attribute.AttributeName,
                                         Key = attribute.CommonName,
                                         IsRequired = true,
                                         IsSortable = true,
                                         CustomViewColumnType = "CF",
                                         DataType = CustomAttributeDataType.String,
                                         DataFormat = string.Empty,
                                         ViewId = 0
                                     });
                }
                else if (commonName == AttributeCommonNames.OperatorRoles)
                    columns.Add(new CustomViewColumn
                    {
                        Id = 0,
                        DisplayName = IWSResources.DisplayName_OperatorRoles,
                        Key = AttributeCommonNames.OperatorRoles,
                        IsRequired = false,
                        IsSortable = true,
                        CustomViewColumnType = "CF",
                        DataType = null,
                        DataFormat = null,
                        ViewId = 0
                    });
                else if (commonName == AttributeCommonNames.Organizations)
                    columns.Add(new CustomViewColumn
                    {
                        Id = 0,
                        DisplayName = IWSResources.DisplayName_Organizations,
                        Key = AttributeCommonNames.Organizations,
                        IsRequired = false,
                        IsSortable = true,
                        CustomViewColumnType = "CF",
                        DataType = null,
                        DataFormat = null,
                        ViewId = 0
                    });
                else
                {
                    var device = devicesByCommonName[c.ColumnName].FirstOrDefault();
                    if (device != null)
                    {
                        columns.Add(new CustomViewColumn
                        {
                            Id = device.Id,
                            DisplayName = device.Name,
                            Key = device.CommonName,
                            IsRequired = false,
                            IsSortable = true,
                            CustomViewColumnType = "Device",
                            DataType = CustomAttributeDataType.Device,
                            //DataFormat = provider.GetDeviceFormat(),
                            //ViewId = customView.ViewId
                        });
                    }
                }

            }

            // var reportLayoutColumns = enumerable.Select(t => t.Title).ToList();
            var reportLayoutColumns = _userManagerHelper.GetCustomViewEntityNames(enumerable, _alldevices.Where(d => !d.IsMassDevice));

            if (reportLayoutColumns.Count == 0)
                reportLayoutColumns.Add("Username");

            if (escalateAttribute != null && !reportLayoutColumns.Contains(escalateAttribute.AttributeName))
                reportLayoutColumns.Add(escalateAttribute.AttributeName);

            return Json(new
            {
                Success = true,
                ReportRows = _userManagerHelper.ConvertToUIModel(usersSession.Users),
                ReportsColumns = columns,
                TotalCounts = usersSession.SearchResultCount,
                ReportLayoutColumns = reportLayoutColumns
            });
        }

        private ResultBasedTargeting getRBTCriteria(string recipientType, int id, string horizontalFilterName, int providerId)
        {
            var fillCountType = string.Empty;
            switch (recipientType.ToLower())
            {
                case "targeted":
                    recipientType = AlertCriteriaOperator.TARGETED.ToString();
                    break;
                case "ack":
                    recipientType = AlertCriteriaOperator.RESPONDED.ToString();
                    break;
                case "sent":
                    recipientType = AlertCriteriaOperator.SENT.ToString();
                    break;
                case "noresponse":
                    recipientType = AlertCriteriaOperator.NORESPONSE.ToString();
                    break;
                case "notsent":
                    recipientType = AlertCriteriaOperator.NOTSENT.ToString();
                    break;

            }

            if (recipientType.Contains("res"))
            {
                var resIndex = Convert.ToInt32(recipientType.Substring(3));
                recipientType = recipientType.Contains("res0") ? AlertCriteriaOperator.ANYRESPONSE.ToString() : ((AlertCriteriaOperator)Enum.Parse(typeof(AlertCriteriaOperator), string.Format("RESPONSE{0}", resIndex))).ToString();
            }

            if (recipientType.Contains("RF") || recipientType.Contains("RA"))
            {
                fillCountType = recipientType.Contains("RF") ? ResultBasedCriteriaOperator.FILLCOUNT.ToString() : ResultBasedCriteriaOperator.ABOVEFILLCOUNT.ToString();
                if (recipientType.Contains("RF0") || recipientType.Contains("RA0"))
                    recipientType = AlertCriteriaOperator.ANYRESPONSE.ToString();
                else
                {
                    var resIndex = Convert.ToInt32(recipientType.Substring(2));
                    recipientType = ((AlertCriteriaOperator)Enum.Parse(typeof(AlertCriteriaOperator), "RESPONSE" + resIndex)).ToString();
                }

            }


            var deviceList =
                _deviceFacade.GetDevicesBySpec(new DeviceSpec
                {
                    ProviderId = providerId,
                    EnabledOnly = true,
                    IncludeDeviceGroup = true,
                    IsMassDevice = false
                }, RuntimeContext.Provider.BaseLocale).Where((p => p.Name == horizontalFilterName)).FirstOrDefault();


            return new ResultBasedTargeting
             {
                 AlertId = id,
                 EntityFilterId = recipientType,
                 HorizontalFilterName = horizontalFilterName,
                 DeviceId = deviceList != null && deviceList.Count > 0 ? deviceList.Id : 0,
                 FillCountType = fillCountType,
             };
        }

        /// <summary>
        ///  Returns list of localized custom attributes
        /// </summary>
        private CustomAttributeLookup ProviderAttributes
        {
            get
            {
                var locale = RuntimeContext.Provider.BaseLocale;
                var customAttributes = _providerAttributes ?? (_providerAttributes = RuntimeContext.CustomAttributesWithouMassDevices);
                return new CustomAttributeLookup(customAttributes);
            }
        }


        private string getLocalizedName(string fieldId, string fieldName)
        {
            if (fieldId.StartsWith("R"))
            {
                return fieldName;
            }
            else
            {
                switch (fieldName.ToLower())
                {
                    case "ack":
                        return IWSResources.Alert_Response_Responded;
                    case "targeted":
                        return IWSResources.Alert_Response_Targeted;
                    case "sent":
                        return IWSResources.Alert_Response_Sent;
                    case "noresponse":
                        return IWSResources.Alert_Response_NoResponse;
                    case "email - work":
                        return IWSResources.Alert_Report_EmailWork;
                    case "pager (numeric)":
                        return IWSResources.Alert_Report_Pager;
                    case "phone - work":
                        return IWSResources.Alert_Report_PhoneWork;
                    case "text messaging":
                        return IWSResources.Alert_Report_Text;
                    default:
                        return fieldName;
                }
            }
        }

        [IWSAuthorize(new[] { SystemObject.Alert }, new[] { ActionType.View })]
        public JsonResult GetAlerts(AlertSearchSpec spec, bool getChannels)
        {
            try
            {
                var dateRangeSet = false;
                DateTime fromDate = DateTime.MinValue;
                DateTime toDate = DateTime.MaxValue;
                var providerId = RuntimeContext.ProviderId;
                var operatorId = RuntimeContext.OperatorId;
                spec.ProviderId = providerId;
                spec.OperatorId = operatorId;

                try //wrap in try/catch to check if any invalid datetime has been passed
                {
                    if (spec.FromDateString != null)
                    {
                        fromDate = Convert.ToDateTime(spec.FromDateString);
                        var fromDateSys = RuntimeContext.Provider.VpsToSystemTime(fromDate);
                        spec.FromDate = fromDateSys.Date;//set from date in system time because search sproc searches in system time
                        dateRangeSet = true;
                    }

                    if (spec.ToDateString != null)
                    {
                        toDate = Convert.ToDateTime(spec.ToDateString);
                        toDate = toDate.AddDays(1).AddSeconds(-1);//toDate should be up to 11:59:59PM                        
                        var toDateSys = RuntimeContext.Provider.VpsToSystemTime(toDate);
                        spec.ToDate = toDateSys.Date;//set to date in system time because search sproc searches in system time
                        dateRangeSet = true;
                    }
                }
                catch (Exception ex)
                {
                    _logService.Error(() => ex);
                }

                if (dateRangeSet) //6855: if date criteria is set, filter out 'Standby' alerts.
                {
                    spec.StatusFilter.Remove("Standby");
                    //iws-14952 if date criteria is set, filter out 'Draft' (previously it is Standby) alerts.
                    spec.StatusFilter.Remove("Draft");
                }

                if (spec.StatusFilter != null && spec.StatusFilter.Count > 0)
                {
                    var indexOfDraft = spec.StatusFilter.FindIndex(s => s.Equals("Draft", StringComparison.InvariantCultureIgnoreCase));
                    if (indexOfDraft >= 0)
                    {
                        spec.StatusFilter.RemoveAt(indexOfDraft);
                        spec.StatusFilter.Add("Standby");
                    }
                }

                var alertList = _alertFacade.GetAlerts(spec);
                var alertListData = alertList == null ? null : convertAlertForView(alertList, fromDate, toDate);
                return alertList == null || alertListData == null
                    ? Json(new { Success = false, Messages = IWSResources.Alert_List_Error_NotFound })
                    : Json(new
                    {
                        Success = true,
                        TotalCount = alertList.TotalCount(),
                        Data = alertListData
                    });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Alert_List_Error_Generic });
            }
        }

        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.Alert }, new[] { ActionType.View })]
        public JsonResult GetAlertDetail(int id, bool? loadTargetingTree, bool? loadTargetUser)
        {
            try
            {
                var alert = _alertFacade.GetAlert(id, RuntimeContext.ProviderId, RuntimeContext.OperatorId);

                return alert == null ? Json(new { Success = false, Messages = IWSResources.Scenario_Error_NotFound }) :
                    Json(new
                    {
                        Success = true,
                        Data = _publishingDomainToModel.GetPublishingModel(alert, RuntimeContext.Provider,
                            RuntimeContext.OperatorId, RuntimeContext.CustomAttributesWithouMassDevices, RuntimeContext.Provider.BaseLocale,
                            parentId: id, loadTargetingTree: loadTargetingTree ?? false, loadTargetUser: loadTargetUser ?? true)
                    });


            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Alert_Error_LoadingAlertDetail });
            }
        }

        [IWSAuthorize(new[] { SystemObject.Alert }, new[] { ActionType.View })]
        public JsonResult DuplicateAlert(int id)
        {
            try
            {
                var alert = _alertFacade.DuplicateAlert(id, RuntimeContext.ProviderId, RuntimeContext.OperatorId);

                return alert == null ? Json(new { Success = false, Messages = IWSResources.Scenario_Error_NotFound }) : Json(new
                {
                    Success = true,
                    Data = _publishingDomainToModel.GetPublishingModel(alert, RuntimeContext.Provider,
                        RuntimeContext.OperatorId, RuntimeContext.CustomAttributesWithouMassDevices, RuntimeContext.Provider.BaseLocale)
                });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Alert_Error_DuplicateAlert });
            }
        }

        /// <summary>
        /// Id is scenarioId
        /// </summary>
        /// <param name="id"></param>
        /// <param name="loadTargetingTree"></param>
        /// <returns></returns>
        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.Alert }, new[] { ActionType.View })]
        public JsonResult CreateAlertFromScenario(int id, bool? loadTargetingTree)
        {
            try
            {
                var alert = _alertFacade.CreateAlertFromScenario(RuntimeContext.ProviderId, RuntimeContext.OperatorId, id);

                return alert == null ? Json(new { Success = false, Messages = IWSResources.Scenario_Error_NotFound }) : Json(new
                {
                    Success = true,
                    Data = _publishingDomainToModel.GetPublishingModel(alert, RuntimeContext.Provider,
                        RuntimeContext.OperatorId,
                        CustomAttributesHelper.GetProviderAttributes(_customAttributeCache, RuntimeContext.ProviderId, RuntimeContext.Provider.BaseLocale, true, true),
                        RuntimeContext.Provider.BaseLocale, parentId: id,
                        loadTargetingTree: loadTargetingTree ?? false)
                });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Alert_Error_CreateAlert });
            }
        }

        [IWSAuthorize(new[] { SystemObject.Alert }, new[] { ActionType.View })]
        public JsonResult StandbyAlert(PublishingModel model)
        {
            try
            {
                var providerId = RuntimeContext.ProviderId;
                var operatorId = RuntimeContext.OperatorId;
                if (model.AlertOrigin == OriginType.ResultBased && model.rbt != null && model.rbt.AccountabilityEventId > 0)
                    model.ParentId = 0;

                var alert = _publisherModelToDomain.GetAlert(model, providerId, RuntimeContext.Operator, AtHocSystem.Local.ConnectDeviceCommonName, model.ParentId);
                _alertFacade.StandbyAlert(providerId, operatorId, alert);

                //had to re-retrieve the scenairo otherwise updatedby/etc is not refreshed
                var newAlert = _alertFacade.GetAlert(alert.AlertId, providerId, operatorId);

                return
                    Json(
                        new
                        {
                            Success = true,
                            Data = _publishingDomainToModel.GetPublishingModel(newAlert, RuntimeContext.Provider, operatorId,
                            RuntimeContext.CustomAttributesWithouMassDevices, RuntimeContext.Provider.BaseLocale)

                        });
            }
            catch (DuplicateResponseOptionException)
            {
                return Json(new { Success = false, Messages = IWSResources.Publishing_DuplicateResponseOption_Error });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Alert_Error_StandbyAlert });
            }
        }

        [IWSAuthorize(new[] { SystemObject.Alert }, new[] { ActionType.View })]
        public JsonResult SaveAlert(PublishingModel model)
        {
            try
            {
                var providerId = RuntimeContext.ProviderId;
                var operatorId = RuntimeContext.OperatorId;

                var alert = _publisherModelToDomain.GetAlert(model, providerId, RuntimeContext.Operator, AtHocSystem.Local.ConnectDeviceCommonName);
                _alertFacade.SaveAlert(providerId, operatorId, alert);

                //had to re-retrieve the scenairo otherwise updatedby/etc is not refreshed
                var newAlert = _alertFacade.GetAlert(alert.AlertId, providerId, operatorId);

                return
                    Json(
                        new
                        {
                            Success = true,
                            Data = _publishingDomainToModel.GetPublishingModel(newAlert, RuntimeContext.Provider, operatorId,
                            RuntimeContext.CustomAttributesWithouMassDevices, RuntimeContext.Provider.BaseLocale)
                        });
            }
            catch (DuplicateResponseOptionException)
            {
                return Json(new { Success = false, Messages = IWSResources.Publishing_DuplicateResponseOption_Error });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Alert_Error_SavingAlert });
            }
        }

        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.Alert }, new[] { ActionType.View })]
        public JsonResult PublishAlert(PublishingModel model)
        {
            try
            {
                var providerId = RuntimeContext.ProviderId;
                var operatorId = RuntimeContext.OperatorId;
                Alert alert;

                if (model.Origin == PublishingOrigin.AlertManager)
                {
                    alert = _alertFacade.GetAlert(model.ParentId, providerId, operatorId);
                }
                else if (model.Origin == PublishingOrigin.ScenarioPublisher)
                {
                    alert = _alertFacade.CreateAlertFromScenario(providerId, operatorId, model.ParentId);
                }
                //For publishing
                else if (model.Origin == PublishingOrigin.AlertDetail)
                {
                    if (model.AlertOrigin == OriginType.ResultBased && model.rbt != null &&
                        model.rbt.AccountabilityEventId > 0)
                        model.ParentId = 0;

                    alert = _publisherModelToDomain.GetAlert(model, providerId, RuntimeContext.Operator, AtHocSystem.Local.ConnectDeviceCommonName, model.ParentId);
                }
                else
                {
                    alert = _publisherModelToDomain.GetAlert(model, providerId, RuntimeContext.Operator, AtHocSystem.Local.ConnectDeviceCommonName);
                }

                _alertFacade.PublishAlert(providerId, operatorId, alert);

                return
                    Json(
                        new
                        {
                            Success = true,
                            Data = new { EntityId = alert.AlertId, AlertStatus = alert.Status }
                        });
            }
            catch (DuplicateResponseOptionException)
            {
                return Json(new { Success = false, Messages = IWSResources.Publishing_DuplicateResponseOption_Error });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Alert_Error_PublishAlert });
            }
        }

        private string convertSeverity(string severity)
        {

            switch (severity)
            {
                case "Extreme":
                    return IWSResources.Event_Severity_Extreme;
                case "Severe":
                case "High":
                    return IWSResources.Event_Severity_High;
                case "Moderate":
                    return IWSResources.Event_Severity_Moderate;
                case "Minor":
                    return IWSResources.Event_Severity_Minor;
                case "Informational":
                    return IWSResources.Event_Severity_Informational;
                case "Unknown":
                    return IWSResources.Event_Severity_Unknown;
                default:
                    return severity;
            }
        }

        private string convertStatus(AlertStatus status)
        {
            switch (status)
            {
                case AlertStatus.Deleted:
                    return IWSResources.Alert_Status_Deleted;
                case AlertStatus.Ended:
                    return IWSResources.Alert_Status_Ended;
                case AlertStatus.Ending:
                    return IWSResources.Alert_Status_Ending;
                case AlertStatus.Live:
                    return IWSResources.Alert_Status_Live;
                case AlertStatus.Publishing:
                    return IWSResources.Alert_Status_Publishing;
                case AlertStatus.Scheduled:
                    return IWSResources.Alert_Status_Scheduled;
                case AlertStatus.Standby:
                    return IWSResources.Alert_Status_Standby;
                case AlertStatus.Updating:
                    return IWSResources.Alert_Status_Updating;
                default:
                    return "";
            }
        }

        /// <summary>
        /// Returns event category name from given event_category_id
        /// </summary>
        /// <param name="eventCategories"></param>
        /// <param name="categoryId"></param>
        /// <returns></returns>
        private string GetEventName(IEnumerable<EventCategory> eventCategories, int categoryId)
        {
            string resultEventName = string.Empty;
            var matchingCategory = eventCategories.FirstOrDefault(s => s.EventCategoryId.Equals(categoryId));
            if (matchingCategory != null)
            {
                resultEventName = matchingCategory.Name;
            }
            return resultEventName;
        }

        /// <summary>
        /// Convert dto to UI model
        /// </summary>
        /// <param name="rawAlerts"></param>
        /// <param name="fromDate">VPS from date</param>
        /// <param name="toDate">VPS to date</param>
        /// <returns></returns>
        private IEnumerable<AlertViewModel> convertAlertForView(IPaged<DtoAlert> rawAlerts, DateTime fromDate, DateTime toDate)
        {
            var currentVpsTime = RuntimeContext.Provider.CurrentSystemTimeToVps();
            var eventCategories = _eventFacade.GetEventCategories(RuntimeContext.ProviderId);
            var standardCategories = eventCategories.FindAll(eventCategory => eventCategory.EventCategoryType.Equals("Standard", StringComparison.InvariantCultureIgnoreCase));

            // Changed for IWS-21927
            var operatorAccess = _operatorDetailsFacade.GetOperatorAccess(new OperatorAccessSpec
            {
                OperatorId = RuntimeContext.OperatorId,
                ProviderId = RuntimeContext.ProviderId
            });

            var alerts = rawAlerts.GetList().Select(s =>
                new AlertViewModel
                {
                    AlertId = s.Id,
                    Title = s.Title.TruncateText(),
                    StatusLabel = convertStatus(s.Status),
                    Status = s.Status.ToString(),
                    StartTime = RuntimeContext.Provider.SystemToVpsTime(s.StartTime),
                    StartTimeDisplayString = (s.Status.Equals(AlertStatus.Standby)) ? IWSResources.Alert_List_Not_Yet_Published : RuntimeContext.Provider.SystemToVpsDateTimeFormated(s.StartTime),
                    Publisher = Server.HtmlEncode(s.Publisher),
                    Targeted = s.Tracking.Targeted,
                    Sent = s.Tracking.Sent,
                    Responded = Math.Max(s.Tracking.Responded, s.Tracking.Acknowledged),
                    ErrorExists = s.Tracking.HasError,
                    CanEdit = ((s.Status.Equals(AlertStatus.Standby) ||
                                (s.Status.Equals(AlertStatus.Live) && (RuntimeContext.Provider.ProviderType() != VPSType.Affiliate25 || RuntimeContext.Provider.ProviderType() == VPSType.Affiliate25Template)) ||
                                s.Status.Equals(AlertStatus.Scheduled))
                                &&
                                !s.OriginType.Equals(OriginType.SystemAlert)
                                &&
                                (_authFacade.HasAccess(operatorAccess, SystemObject.Alert, ActionType.Publish) || s.Status.Equals(AlertStatus.Standby))),
                    CanDuplicate = (!s.OriginType.Equals(OriginType.SystemAlert)), //cannot duplicate system alert
                    CanPublish = (s.Status.Equals(AlertStatus.Standby) && _authFacade.HasAccess(operatorAccess, SystemObject.Alert, ActionType.Publish) && (s.IsReadyForPublish.ToUpper().Equals("Y"))),
                    CanDelete = (s.Status.Equals(AlertStatus.Scheduled) || s.Status.Equals(AlertStatus.Standby)) && (!s.OriginType.Equals(OriginType.SystemAlert) || s.ProviderId.Equals(RuntimeContext.ProviderId)) && _authFacade.HasAccess(operatorAccess, SystemObject.Alert, ActionType.Publish),
                    CanEnd = s.Status.Equals(AlertStatus.Live) && (!s.OriginType.Equals(OriginType.SystemAlert) || s.ProviderId.Equals(RuntimeContext.ProviderId)) && _authFacade.HasAccess(operatorAccess, SystemObject.Alert, ActionType.Publish),
                    Body = s.Body.TruncateText(),
                    Responses = s.Tracking.Response,
                    TimeRemaining = FormatUtility.GetTimeSpan(currentVpsTime, RuntimeContext.Provider.SystemToVpsTime(s.EndTime)),
                    Severity = s.Severity,
                    SeverityLabel = convertSeverity(s.Severity),
                    Event = GetEventName(standardCategories, s.EventCategoryId),
                    EventLabel = GetEventName(standardCategories, s.EventCategoryId)
                });

            return alerts.Where(a => a.StartTime >= fromDate && a.StartTime < toDate);//correct the window here...
        }


        [HttpPost]
        public JsonResult CanModify(int[] ids)
        {
            try
            {
                var unmodifiableAlerts = new List<int>();
                var canModify = _alertFacade.CanModifyPerUserbase(RuntimeContext.OperatorId, RuntimeContext.ProviderId, ids, ref unmodifiableAlerts);
                return Json(new { Success = true, CanModify = canModify, UnmodifiableAlerts = unmodifiableAlerts });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Alert_List_Error_Generic });
            }
        }

        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.Alert }, new[] { ActionType.Modify })]
        public JsonResult Delete(int[] ids)
        {
            try
            {
                return Json(new { Success = _alertFacade.Delete(RuntimeContext.OperatorId, RuntimeContext.ProviderId, ids) });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Alert_Error_DeleteAlert });
            }
        }

        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.Alert }, new[] { ActionType.Modify })]
        public JsonResult End(int[] ids)
        {
            try
            {
                return Json(new { Success = _alertFacade.End(RuntimeContext.OperatorId, RuntimeContext.ProviderId, ids) });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Alert_Error_EndAlert });
            }
        }

        [IWSAuthorize(new[] { SystemObject.Alert }, new[] { ActionType.View })]
        public JsonResult GetOperatorsWhoPublishedAlert()
        {
            try
            {
                var providerId = RuntimeContext.ProviderId;
                var operatorList = _alertFacade.GetPublisherByProviderId(providerId);
                return Json(new { Success = true, Messages = operatorList.OrderBy(o => o) });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Alert_List_Error_Generic });
            }
        }


        [IWSAuthorize(new[] { SystemObject.Alert }, new[] { ActionType.View })]
        public JsonResult GetSeverityList()
        {
            try
            {

                var data = _globalEntityLocaleFacade.GetLocalizedEntity(SettingsHelper.Severities(), RuntimeContext.Provider.BaseLocale)
                                   .Select(
                                        p =>
                                            new KeyValueModel
                                            {
                                                Id = (int)(Priority)Enum.Parse(typeof(Priority), p.SeverityId),
                                                Name = p.SeverityName
                                            }).ToList();
                return Json(data);
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Alert_List_Error_Generic });
            }
        }

        [IWSAuthorize(new[] { SystemObject.Alert }, new[] { ActionType.View })]
        public JsonResult GetEventTypeList()
        {
            try
            {
                var result = _publishingDomainToModel.GetEventCategories(RuntimeContext.Provider);
                return Json(result);
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Alert_List_Error_Generic });
            }
        }



        [IWSAuthorize(new[] { SystemObject.Alert }, new[] { ActionType.Modify })]
        public ActionResult GenerateAlertPdfResult(int alertId)
        {
            var providerId = RuntimeContext.ProviderId;
            var operatorId = RuntimeContext.OperatorId;

            try
            {
                var alert = _alertFacade.GetAlert(alertId, providerId, operatorId);

                return alert == null
                    ? Json(new { Success = false, Messages = IWSResources.Scenario_Error_NotFound })
                    : Json(new
                    {
                        Success = true,
                        Data = _publishingDomainToModel.GetPublishingModel(alert, RuntimeContext.Provider,
                            operatorId, RuntimeContext.CustomAttributesWithouMassDevices,
                            RuntimeContext.Provider.BaseLocale, parentId: alertId)
                    });

            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Alert_Error_CreateAlert });
            }

        }

        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.Alert }, new[] { ActionType.Modify })]
        public JsonResult CreateAlertFromRbt(int id, string recipientType = null, int deviceId = 0, string fillCount = null, int accEventId = 0)
        {
            var providerId = RuntimeContext.ProviderId;
            var operatorId = RuntimeContext.OperatorId;

            try
            {
                var alert = _alertFacade.GetAlert(id, providerId, operatorId);

                var data = _publishingDomainToModel.GetPublishingModel(alert, RuntimeContext.Provider, operatorId, RuntimeContext.CustomAttributesWithouMassDevices,
                    RuntimeContext.Provider.BaseLocale, false, alert.Origin.ScenarioId, recipientType);
                // Get Accountability Event Id in case of RBT which is created from Event RBT
                if (accEventId == 0 && alert.AlertSpec.Targeting != null && alert.AlertSpec.Targeting.TargetingCriteria != null)
                {
                    var queryCriteria =
                        alert.AlertSpec.Targeting.TargetingCriteria.FirstOrDefault(
                            t => t.NodeType.Equals(SearchNodeType.Query) || t.NodeType.Equals(SearchNodeType.EbtQuery));
                    if (queryCriteria != null && (queryCriteria.SearchQueries != null && queryCriteria.SearchQueries.Any()))
                    {
                        var alertQuery = queryCriteria.SearchQueries.FirstOrDefault();
                        if (alertQuery != null && alertQuery.QueryType == SearchQueryType.PAEvent)
                        {
                            accEventId = (alertQuery.QueryEntityID ?? 0);
                        }
                    }
                }
                data.rbt = new ResultBasedTargeting { AlertId = id, EntityFilterId = recipientType, DeviceId = deviceId, IncludeDevices = false, FillCountType = fillCount, AccountabilityEventId = accEventId };
                _publishingDomainToModel.SetRbtProperties(data, 0);
                if (accEventId > 0)
                {
                    var acctSpec = new AccountabilityEventSpec();
                    acctSpec.ProviderId = providerId;
                    acctSpec.OperatorId = operatorId;
                    acctSpec.EventIds = new List<int> { accEventId };
                    acctSpec.IncludeReminderAlertDetails = false;
                    acctSpec.IsLoadBaseDetails = true;
                    acctSpec.BaseLocale = RuntimeContext.Provider.BaseLocale;
                    var acctEvent = _accountabiltyFacade.GetEvent(acctSpec);
                    data.Content.Title = acctEvent.AlertSpec.Content.Header;
                    data.Content.Body = acctEvent.AlertSpec.Content.Body;
                }
                return alert == null ? Json(new { Success = false, Messages = IWSResources.Scenario_Error_NotFound }) : Json(new { Success = true, Data = data });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Alert_Error_CreateAlert });
            }

        }

        [HttpPost]
        [RenderAsPDF(AutoConvert = false)]
        [FileDownloadCookie]
        [IWSAuthorize(new[] { SystemObject.Alert }, new[] { ActionType.View })]
        [ValidateInput(false)]
        public ActionResult GenerateAlertPDF(FormCollection form)
        {
            // Deserializing the json string

            var jsJson = new JavaScriptSerializer();
            jsJson.MaxJsonLength = Int32.MaxValue;
            var objPublishingModel = jsJson.Deserialize<PublishingModel>(form["feed"]);
            // Put Pie chart data
            ViewBag.PieChartData = form["pieChartData"].Replace("inner-bucket height300", "");
            // Put location image to show on pdf
            ViewBag.LocationData = form["locationData"];
            // Take target summary
            ViewBag.TargetingSummary = (form["targetingSummary"] != "" ? form["targetingSummary"] : null);
            List<DeviceGroupOptions> cloneDeviceOptions;
            List<DeviceGroupOptions> cloneMassDeviceOptions;
            try
            {
                // To show local timezone
                ViewBag.TimeZone = RuntimeContext.Provider.GetVpsTimeZoneFromId().DisplayName;
                ViewBag.ExportDateTime = RuntimeContext.Provider.CurrentSystemTimeToVpsTimeString();
                ViewBag.InformationBanner = RuntimeContext.Provider.ExtendedParams.InformationBanner;
                // To show Content section
                ViewBag.Content = objPublishingModel.Content;

                //Add selected language
                ViewBag.SelecctedLanguage = objPublishingModel.Content.Languages.SingleOrDefault(x => x.Code == objPublishingModel.Content.Local).Name;
                // Check if ResponseOPtion having Text or not
                ViewBag.IsReponseTextEmpty = objPublishingModel.Content.ResponseOptions != null ? objPublishingModel.Content.ResponseOptions.Any(a => a.ResponseText != string.Empty) : false;
                // To show target section
                ViewBag.TargetOrg = objPublishingModel.TargetOrg;
                // This is to show Mass device section on pdf
                ViewBag.DeviceList = objPublishingModel.MassDevices.Where(x => x.Selected).ToList();
                // To show Scheduling section
                if (objPublishingModel.AlertScheduleSettings != null)
                {
                    var alertScheduleSettings = objPublishingModel.AlertScheduleSettings;
                    var scheduleDurationInputUnit = alertScheduleSettings.ScheduleDurationInputUnit;
                    if (scheduleDurationInputUnit != null)
                    { 
                        alertScheduleSettings.ScheduleDurationInputUnit =
                            SettingsHelper.GetResourceString(string.Format("TimeFormat_{0}s", scheduleDurationInputUnit));
                    }
                    ViewBag.AlertScheduleSettings = alertScheduleSettings;
                }
                ViewBag.VirtualSystemName = (new VirtualSystems.VirtualSystemService()).GetProviderNameById(RuntimeContext.ProviderId);

                ViewBag.FillCountInfo = form["fillCountInfo"];

                ViewBag.PrintedBy = string.Empty;
                // This is to show target users
                ViewBag.TargetUsers = objPublishingModel.TargetUsers;
                ViewBag.TotalUsers = (form["TotalUsers"] != "" ? form["TotalUsers"] : "0");
                ViewBag.AudioFileName = (form["audioFileName"] != "" ? form["audioFileName"] : "");
                cloneDeviceOptions = new JavaScriptSerializer().Deserialize<List<DeviceGroupOptions>>(form["PersonalDevicesList"]);
                cloneMassDeviceOptions = new JavaScriptSerializer().Deserialize<List<DeviceGroupOptions>>(form["MassDevicesList"]);

                // This code is to show custom message for personal device
                ViewBag.DeviceOptionCustomText = cloneDeviceOptions != null ? cloneDeviceOptions.Where(x => x.Options.Count > 0).ToList() : null;


                // This code is to show custom message for Mass device
                ViewBag.MassDeviceOptionCustomText = cloneMassDeviceOptions != null ? cloneMassDeviceOptions.ToList() : null;

                // Below section is to show Number of counts for each section               
                if (objPublishingModel.TargetUsers.TargetingNodes != null && objPublishingModel.TargetUsers.TargetingNodes.Count() > 0)
                {
                    ViewBag.NumofTargetedNodes = objPublishingModel.TargetUsers.TargetingNodes.Where(x => x.IsBlocked == false).ToList().Count();
                    ViewBag.NumofBlockedNodes = objPublishingModel.TargetUsers.TargetingNodes.Where(x => x.IsBlocked).ToList().Count();
                }
                if (objPublishingModel.TargetUsers.TargetedBlockedUsers != null && objPublishingModel.TargetUsers.TargetedBlockedUsers.Count() > 0)
                {
                    ViewBag.NumofTargetedUsers = objPublishingModel.TargetUsers.TargetedBlockedUsers.Where(x => x.IsBlocked == false).ToList().Count();
                    ViewBag.NumofBlockedUsers = objPublishingModel.TargetUsers.TargetedBlockedUsers.Where(x => x.IsBlocked).ToList().Count();
                }
                if (objPublishingModel.TargetUsers.TargetedCriteria != null && objPublishingModel.TargetUsers.TargetedCriteria.selections != null
                    && objPublishingModel.TargetUsers.TargetedCriteria.selections.Count > 0)
                {
                    ViewBag.AdvancedQueryCount = objPublishingModel.TargetUsers.TargetedCriteria.selections.Count;
                }

                if (objPublishingModel.TargetUsers != null && objPublishingModel.TargetUsers.TargetUsersByArea
                    && objPublishingModel.Content != null && !string.IsNullOrWhiteSpace(objPublishingModel.Content.LocationGeo))
                {
                    var locationObj = (new JavaScriptSerializer()).Deserialize<Dictionary<string, object>>(objPublishingModel.Content.LocationGeo);
                    if (locationObj != null && locationObj.Count > 0)
                    {

                        ViewBag.TargetedAreas = locationObj.Where(a => a.Key == "features").Count();
                    }
                }

                ViewBag.Devices = objPublishingModel.DeviceList;

                // This is to show user specfic information
                var user = (new UserFacade()).GetUserBySpec(new UserSpec { UserId = RuntimeContext.OperatorId, ProviderId = RuntimeContext.ProviderId });
                if (user != null)
                {
                    if (user.DisplayName.HasValue() && (!user.DisplayName.Equals("N/A")))
                        ViewBag.PrintedBy = user.DisplayName.Trim();
                    else if ((user.FirstName.HasValue()) || (user.LastName.HasValue()))
                        ViewBag.PrintedBy = (user.FirstName + " " + user.LastName).Trim();
                    else ViewBag.PrintedBy = user.UserName;
                }


                try
                {
                    // Render the pdf
                    MVCToPDF.ResultFileName = FileNameFormats.GetFormattedFileName(IWSResources.Alert_PDFExport, "pdf");
                    MVCToPDF.RenderAsPDF();
                }
                catch
                {

                }
                return View("~/Views/Shared/Publishing/_PrintAlertDetails.cshtml");
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Alert_Error_LoadingAlertDetail });
            }
        }
        [HttpPost]
        public JsonResult TestAlert(PublishingModel model)
        {
            try
            {
                var providerId = RuntimeContext.ProviderId;
                var operatorId = RuntimeContext.OperatorId;
                model.AlertOrigin = OriginType.Test;
                model.rbt = null;
                // for test alert operator should be targeted to verify the alert message.
                model.TargetUsers.TargetedBlockedUsers = new List<Business.Domain.Targeting.Model.UserNode>();
                model.TargetUsers.TargetedBlockedUsers.Add(new Business.Domain.Targeting.Model.UserNode() { UserId = operatorId, IsBlocked = false });
                var alert = _publisherModelToDomain.GetAlert(model, providerId, RuntimeContext.Operator, AtHocSystem.Local.ConnectDeviceCommonName);
                alert.Origin.Type = OriginType.Test;
                _alertFacade.SaveAlert(providerId, operatorId, alert);
                return
                     Json(
                         new
                         {
                             Success = true,
                             Messages = IWSResources.Alert_Test_Success,
                         });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Alert_Test_Failure });
            }
        }
    }
}