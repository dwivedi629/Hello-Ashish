﻿using System;
using System.Globalization;
using System.Linq;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using AtHoc.Infrastructure.Log;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Web.Filters;
using AtHoc.IWS.Web.Helpers;
using AtHoc.IWS.Web.Models.Publishing;
using AtHoc.Global.Resources;
using AtHoc.IWS.Business.Data.SearchSpec;
using AtHoc.IWS.Business.Domain;
using System.Net;
using AtHoc.IWS.Business.Domain.Devices;
using AtHoc.IWS.Business.Domain.Organization;
using AtHoc.IWS.Business.Domain.Authorization;
using AtHoc.Scheduling;
using AtHoc.Publishing.Service;
using System.Globalization;
using AtHoc.Systems;
using AtHoc.IWS.Web.Configurations.Constants;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using System.Web.SessionState;

namespace AtHoc.IWS.Web.Controllers
{
    /// <summary>
    /// Controller for Scenario 
    /// </summary>
    [SessionState(SessionStateBehavior.ReadOnly)]
    public class ScenarioManagerController : AtHoc.Infrastructure.Web.Mvc.Controller
    {
        private readonly IScenarioFacade _scenarioFacade;
        private readonly ILogService _logService;
        private readonly IOperatorDetailsFacade _operatorDetailsFacade;
        private readonly IPublishingDomainToModel _publishingDomainToModel;
        private readonly IPublishingFacade _pubFacade;
        private readonly IPublishingModelToDomain _publisherModelToDomain;
        private readonly IPlaceHolderFacade _placeholderFacade;

        public ScenarioManagerController(IScenarioFacade scenarioFacade, ILogService logService, IOperatorDetailsFacade operatorDetailsFacade,
            IPublishingDomainToModel publishingDomainToModel, IDeviceFacade deviceFacade,
            IOrganizationFacade organizationFacade, IAuthFacade authFacade, IPublishingFacade pubFacade, IPublishingModelToDomain publisherModelToDomain, IPlaceHolderFacade placeholderFacade)
        {
            _scenarioFacade = scenarioFacade;
            _logService = logService;
            _operatorDetailsFacade = operatorDetailsFacade;
            _publishingDomainToModel = publishingDomainToModel;
            _pubFacade = pubFacade;
            _publisherModelToDomain = publisherModelToDomain;
            _placeholderFacade = placeholderFacade;
        }

        /// <summary>
        /// SPA entery point for Scenario Manager
        /// </summary>
        /// <returns></returns>
        [IWSAuthorize(new[] { SystemObject.ScenarioManager, SystemObject.AdvancedAlertManager, SystemObject.AlertPublisher, SystemObject.EnterpriseAdmin },
            new[] { ActionType.View, ActionType.View, ActionType.View, ActionType.View })]
        public ActionResult Index()
        {
            var provider = RuntimeContext.Provider;

            var vpsTimeZOne = RuntimeContext.Provider.GetVpsTimeZoneFromId();
            ViewBag.DateFormat = provider.GetDateFormat();
            ViewBag.DateTimeFormat = provider.GetDateTimeFormat();
            ViewBag.VPSTimeZone = vpsTimeZOne;
            ViewBag.UtcOffsetInMinutes = vpsTimeZOne.BaseUtcOffset.TotalMinutes;
            ViewBag.VPSOffsetFromSystemInMinutes = provider.VPSOffsetFromSystemInMinutes();
            ViewBag.SupportsDaylightSavingTime = vpsTimeZOne.SupportsDaylightSavingTime;
            ViewBag.IsAffiliate = (provider.ProviderType() == VPSType.Affiliate25 || provider.ProviderType() == VPSType.Affiliate25Template);
            ViewBag.OperatorName = RuntimeContext.Operator.DisplayName;
            ViewBag.TopicToHighlight = MenuTopicsId.alerting;
            ViewBag.PublisherSettings = _publishingDomainToModel.GetPublisherSettings(provider);
            ViewBag.PlaceHolderItems = new JavaScriptSerializer().Serialize(_placeholderFacade.GetPlaceHolderList(provider.Id, RuntimeContext.OperatorId));
            ViewBag.CurrentDateTime = provider.CurrentSystemTimeToVps().ToString(CultureInfo.InvariantCulture);
            ViewBag.UserNameAttributeName = RuntimeContext.CustomAttributesWithouMassDevices.GetByCommonName(CommonNames.UserName).AttributeName;
            return View();
        }

        /// <summary>
        /// View for the scenario publisher
        /// </summary>
        /// <returns></returns>
        [IWSAuthorize(new[] { SystemObject.ScenarioManager, SystemObject.ScenarioPublisher, SystemObject.AdvancedAlertManager, SystemObject.AlertPublisher, SystemObject.EnterpriseAdmin },
            new[] { ActionType.View, ActionType.View, ActionType.View, ActionType.View, ActionType.View })]
        public ActionResult ScenarioPublisher()
        {
            ViewBag.TopicToHighlight = MenuTopicsId.alerting;
            var provider = RuntimeContext.Provider;
            ViewBag.DateFormat = provider.GetDateFormat();
            ViewBag.PublisherSettings = _publishingDomainToModel.GetPublisherSettings(provider);

            return View();
        }

        /// <summary>
        /// Get the list of alert channels that the current operator has access to.
        /// </summary>
        /// <returns>Json result with list of alert channels</returns>
        [IWSAuthorize(new[] { SystemObject.ScenarioManager, SystemObject.ScenarioPublisher, SystemObject.AdvancedAlertManager, SystemObject.AlertPublisher, SystemObject.EnterpriseAdmin, SystemObject.Alert },
            new[] { ActionType.View, ActionType.View, ActionType.View, ActionType.View, ActionType.View, ActionType.View })]
        public ActionResult GetOperatorAccessibleChannels()
        {
            try
            {
                if ((Session["channelList"] == null) || ((Session["UpdateFolderData"] != null) && ((bool)Session["UpdateFolderData"])))
                {
                    var providerId = RuntimeContext.ProviderId;
                    var operatorId = RuntimeContext.OperatorId;

                    var channels = _operatorDetailsFacade.GetOperatorAccessibleChannels(
                        new OperatorAccessibleChannelsSpec { ProviderId = providerId, OperatorId = operatorId },
                        RuntimeContext.Provider.BaseLocale
                        );
                    //for some reason the legacy DA code is returning duplicate channelIds
                    //as a workaround, we group the result by channelId here.
                    var ret = (from c in channels
                               where c.Status != "DSB"
                               orderby c.Name
                               group c by c.Id into g
                               select g.First()).ToList();

                    Session["channelList"] = ret;
                    Session["UpdateFolderData"] = false;
                }

                var channelList = Session["channelList"];
                return Json(channelList);
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                //returning HTTP status code in addition to the exception message.
                return new HttpStatusCodeResult(HttpStatusCode.InternalServerError, ex.Message);
            }

        }

        /// <summary>
        /// Get senario using search spec
        /// </summary>
        /// <param name="spec">Search parameters</param>
        /// <param name="getChannels">Flag indicating if get channels or not</param>
        /// <returns>Json result with list of scenarios</returns>
        [IWSAuthorize(new[] { SystemObject.ScenarioManager, SystemObject.ScenarioPublisher, SystemObject.AdvancedAlertManager, SystemObject.AlertPublisher, SystemObject.EnterpriseAdmin },
            new[] { ActionType.View, ActionType.View, ActionType.View, ActionType.View, ActionType.View })]
        public ActionResult GetScenarios(ScenarioSearchSpec spec)
        {
            try
            {
                var providerId = RuntimeContext.ProviderId;
                var operatorId = RuntimeContext.OperatorId;
                var scenarioList = _scenarioFacade.GetScenarios(providerId, operatorId, spec);

                var data = scenarioList.Select(s =>
                                new Scenario
                                {
                                    ScenarioId = s.ScenarioId,
                                    Name = s.Name.TruncateText(),
                                    ChannelName = s.ChannelName.TruncateText() == "System Default" ? IWSResources.Channel_SystemDefault : s.ChannelName.TruncateText(),
                                    PublishedOn = s.PublishedOn,
                                    PublishedOnString = RuntimeContext.Provider.SystemToVpsDateTimeFormated(s.PublishedOn),
                                    DateTimeFormat = RuntimeContext.Provider.GetDateTimeFormat(),
                                    NextRecurrence = s.NextRecurrence,
                                    NextRecurrenceString = (s.IsRecurringScenario) ? RuntimeContext.Provider.SystemToVpsDateTimeFormated(s.NextRecurrence) : string.Empty,
                                    UpdatedBy = s.UpdatedBy,
                                    IsQuickPublish = s.IsQuickPublish,
                                    IsReadyForPublish = s.IsReadyForPublish,
                                    IsDefaultforNewAlert = s.IsDefaultforNewAlert,
                                    IsDefaultforNewScenario = s.IsDefaultforNewScenario,
                                    IsSystem = _scenarioFacade.IsSystemScenario(s.CommonName),
                                    IsRecurringScenario = s.IsRecurringScenario,
                                    Description = s.Description.TruncateText(200),
                                    AlertTitle = s.AlertTitle.TruncateText(),
                                    AlertBody = s.AlertBody.TruncateText()
                                });

                data = spec.ExcludeSystemScenarios ? data.Where(s => !s.IsSystem) : data;

                return Json(data);
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                //returning HTTP status code in addition to the exception message.
                return new HttpStatusCodeResult(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        /// <summary>
        /// Get scenario detail by id
        /// </summary>
        /// <param name="id">Id of scenario</param>
        /// <returns></returns>
        [IWSAuthorize(new[] { SystemObject.ScenarioManager, SystemObject.ScenarioPublisher, SystemObject.AdvancedAlertManager, SystemObject.AlertPublisher, SystemObject.EnterpriseAdmin },
            new[] { ActionType.View, ActionType.View, ActionType.View, ActionType.View, ActionType.View })]
        public JsonResult GetScenarioDetail(int id)
        {
            try
            {
                var operatorId = RuntimeContext.OperatorId;
                var scenario = _scenarioFacade.GetScenario(id, RuntimeContext.ProviderId, operatorId);

                return scenario == null
                    ? Json(new { Success = false, Messages = IWSResources.Scenario_Error_NotFound })
                    : Json(new
                    {
                        Success = true,
                        Data =
                            _publishingDomainToModel.GetPublishingModel(scenario, RuntimeContext.Provider, operatorId,
                                RuntimeContext.CustomAttributesWithouMassDevices, RuntimeContext.Provider.BaseLocale)
                    });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Scenario_Error_LoadingScenarioDetail });
            }

        }

        /// <summary>
        /// Create scenario 
        /// </summary>
        /// <returns></returns>
        public JsonResult CreateScenario()
        {
            try
            {
                var providerId = RuntimeContext.ProviderId;
                var operatorId = RuntimeContext.OperatorId;
                var scenario = _scenarioFacade.CreateScenario(providerId, operatorId);

                return scenario == null ? Json(new { Success = false, Messages = IWSResources.Scenario_Error_NotFound }) : Json(new
                {
                    Success = true,
                    Data = _publishingDomainToModel.GetPublishingModel(scenario, RuntimeContext.Provider, operatorId,
                        RuntimeContext.CustomAttributesWithouMassDevices, RuntimeContext.Provider.BaseLocale)
                });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Scenario_Error_CreateScenario });
            }

        }

        /// <summary>
        /// Duplicate scenario 
        /// </summary>
        /// <returns></returns>
        public JsonResult DuplicateScenario(int id)
        {
            try
            {
                var providerId = RuntimeContext.ProviderId;
                var operatorId = RuntimeContext.OperatorId;
                var scenario = _scenarioFacade.DuplicateScenario(id, providerId, operatorId);

                if (scenario != null)
                {
                    scenario.Name = string.Format("{0} {1}",scenario.Name ,IWSResources.Scenario_DuplicateText);
                    scenario.ScenarioId = id;
                }
                var data = _publishingDomainToModel.GetPublishingModel(scenario, RuntimeContext.Provider, operatorId,
                    RuntimeContext.CustomAttributesWithouMassDevices, RuntimeContext.Provider.BaseLocale);
                data.EntityId = 0;

                return scenario == null ? Json(new { Success = false, Messages = IWSResources.Scenario_Error_NotFound }) : Json(new
                {
                    Success = true,
                    Data = data
                });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Scenario_Error_DuplicateScenario });
            }

        }

        /// <summary>
        /// Save scenario
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [IWSAuthorize(new[] { SystemObject.ScenarioManager, SystemObject.ScenarioPublisher, SystemObject.AdvancedAlertManager, SystemObject.AlertPublisher, SystemObject.EnterpriseAdmin },
            new[] { ActionType.View, ActionType.View, ActionType.View, ActionType.View, ActionType.View })]
        [HttpPost]
        public JsonResult SaveScenario(PublishingModel model)
        {
            try
            {
                var providerId = RuntimeContext.ProviderId;
                var operatorId = RuntimeContext.OperatorId;

                var scenario = _publisherModelToDomain.GetScenario(model, providerId, operatorId, AtHocSystem.Local.ConnectDeviceCommonName);

                var sschedule = new ScheduleHelper();
                // set UI scenario schedule settings to  domain model
                Schedule dataSchedule = (model.ScenarioScheduleSettings == null) ? null : sschedule.SetScenarioSchedule(scenario, operatorId, model.ScenarioScheduleSettings);
                _scenarioFacade.SaveScenario(providerId, operatorId, scenario);

                if (dataSchedule != null)
                {
                    dataSchedule.ScheduleJob.ReferenceType = "SCENARIO";
                    dataSchedule.ScheduleJob.ReferenceId = scenario.ScenarioId;
                    var scManager = new ScheduleManager(providerId, operatorId);
                    scManager.SaveSchedule(dataSchedule);
                }


                //had to re-retrieve the scenairo otherwise updatedby/etc is not refreshed
                var newScenario = _scenarioFacade.GetScenario(scenario.ScenarioId, providerId, operatorId);

                var alertPlaceHolderManager = new AlertPlaceHolderManager();
                alertPlaceHolderManager.AssociatePlaceHoldersToScenario(RuntimeContext.Provider.Id, scenario.ScenarioId, model.AllPlaceHolderIds);


                return
                    Json(
                        new
                        {
                            Success = true,
                            Data = _publishingDomainToModel.GetPublishingModel(newScenario, RuntimeContext.Provider, operatorId,
                            RuntimeContext.CustomAttributesWithouMassDevices, RuntimeContext.Provider.BaseLocale)
                        });
            }
            catch (DuplicateResponseOptionException ex)
            {
                return Json(new { Success = false, Messages = IWSResources.Publishing_DuplicateResponseOption_Error });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Scenario_Error_SavingScenarioDetail });
            }
        }

        /// <summary>
        /// Delete scearios by Ids
        /// </summary>
        /// <param name="ids">ids of scenario</param>
        /// <returns></returns>
        [IWSAuthorize(new[] { SystemObject.ScenarioManager }, new[] { ActionType.Modify })]
        public JsonResult DeleteScenario(int[] ids)
        {
            try
            {
                var providerId = RuntimeContext.ProviderId;
                var operatorId = RuntimeContext.OperatorId;
                _scenarioFacade.DeleteScenarios(providerId, operatorId, ids);
                return Json(new { Success = true, Messages = IWSResources.Scenario_Error_NotFound });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Scenario_Error_DeleteScenario });
            }
        }
    }
}
