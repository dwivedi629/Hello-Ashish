﻿using System.Configuration;
using System.Web.SessionState;
using AtHoc.d911;
using AtHoc.d911.Model.Organization;
using AtHoc.Global.Resources;
using AtHoc.Global.Resources.Interfaces;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Web.Mvc.ActionFilters;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.Authorization;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel;
using AtHoc.IWS.Business.Domain.Event.Impl;
using AtHoc.IWS.Business.Domain.Event.Spec;
using AtHoc.IWS.Business.Domain.Events;
using AtHoc.IWS.Business.Domain.Organization;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Business.Domain.Spec;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.IWS.Web.Context;
using AtHoc.IWS.Web.Filters;
using AtHoc.IWS.Web.Helpers;
using AtHoc.IWS.Web.Models.Event;
using AtHoc.IWS.Web.Models.Export;
using AtHoc.Publishing;
using AtHoc.Targeting;
using EO.Internal;
using EO.Pdf.Mvc;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AtHoc.Infrastructure;
using Microsoft.Practices.ObjectBuilder2;
using Newtonsoft.Json;
using Controller = AtHoc.Infrastructure.Web.Mvc.Controller;
using AtHoc.IWS.Web.Models.Publishing;
using AtHoc.IWS.Business.Domain.Publishing.Impl;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;
using AtHoc.IWS.Web.Models.UserManager;
using AtHoc.IWS.Business.Domain.Accountability;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.IWS.Business.Domain.Users.Impl.Search;
using System.Net;

namespace AtHoc.IWS.Web.Controllers
{


    [SessionState(SessionStateBehavior.ReadOnly)]
    public class EventManagerController : Controller
    {
        # region  Global variable Declaration
        private readonly IEventFacade _eventFacade;
        private readonly IUserFacade _userFacade;
        private readonly IPublishingFacade _publishingFacade;
        private readonly IOrganizationFacade _organizationFacade;
        private readonly ILogService _logService;
        private readonly IAuthFacade _authFacade;
        private readonly IGlobalEntityLocaleFacade _globalEntityLocaleFacade;
        private readonly IOperatorDetailsFacade _operatorDetailsFacade;
        private readonly IUserManagerHelper _userManagerHelper;
        private readonly IAccountabilityFacade _accountabilityFacade;
        private readonly ICustomAttributeFacade _customAttributeFacade;

        private const string SourceType = "USER";
        private const string ResponseType = "response";


        #endregion

        #region Constructor
        public EventManagerController(IAuthFacade authFacade, IEventFacade eventFacade, IUserFacade userFacade, IPublishingFacade publishingFacade,
            IOrganizationFacade organizationFacade, ILogService logService, IGlobalEntityLocaleFacade globalEntityLocaleFacade, IOperatorDetailsFacade operatorDetailsFacade, IUserManagerHelper userManagerHelper, IAccountabilityFacade accountabilityFacade, ICustomAttributeFacade customAttributeFacade)
        {
            ViewBag.CustomKendo = false;
            _eventFacade = eventFacade;
            _userFacade = userFacade;
            _publishingFacade = publishingFacade;
            _organizationFacade = organizationFacade;
            _logService = logService;
            _authFacade = authFacade;
            _globalEntityLocaleFacade = globalEntityLocaleFacade;
            _operatorDetailsFacade = operatorDetailsFacade;
            _userManagerHelper = userManagerHelper;
            _accountabilityFacade = accountabilityFacade;
            _customAttributeFacade = customAttributeFacade;
        }

        #endregion


        /// <summary>
        /// Index action of Event Controller
        /// </summary>
        /// <returns></returns>

        [IWSAuthorize(new[] { SystemObject.EventManager }, new[] { ActionType.View })]
        public ActionResult Index()
        {


            object tempId, logEventCategoryId;
            EventViewType viewType = EventViewType.Inbox;
            object eventCategoryId;
            object filterByEventType;
            object filterByReviewedNo;

            // Changed for IWS-21927
            var operatorAccess = _operatorDetailsFacade.GetOperatorAccess(new OperatorAccessSpec
            {
                OperatorId = RuntimeContext.OperatorId,
                ProviderId = RuntimeContext.ProviderId
            });

            ViewBag.EventId = TempData.TryGetValue("EventId", out tempId) ? tempId : 0;

            //Below flag is used if you want to filter the inbox by EventType; also you need to pass EventCategoryId for EventTYpe filter.
            ViewBag.eventCategoryId = TempData.TryGetValue("EventCategoryId", out eventCategoryId) ? eventCategoryId : 0;
            ViewBag.FilterByEventType = TempData.TryGetValue("FilterByEventType", out filterByEventType) ? filterByEventType : false;

            //Below flag is used if inbox needs to filter by Reviewed = No;
            ViewBag.FilterbyReviewedNo = TempData.TryGetValue("FilterByReviewedNo", out filterByReviewedNo) ? filterByReviewedNo : false;

            object viewTypeObj;
            if (TempData.TryGetValue("ViewType", out viewTypeObj))
            {
                viewType = (EventViewType)viewTypeObj;
            }
            ViewBag.ViewType = viewType;

            ViewBag.logEventCategoryId = TempData.TryGetValue("LogEventCategoryId", out logEventCategoryId) ? logEventCategoryId : 0;

            //required for top bar highlight 
            ViewBag.TopicToHighlight = MenuTopicsId.alerting;
            ViewBag.ProviderId = RuntimeContext.ProviderId;
            ViewBag.Title = (viewType == EventViewType.Log ? IWSResources.Athoc_Title_ActivityLog : IWSResources.Athoc_Title_Inbox);

            //Get the value from web config. This key is for debugging purpose. For testing performance on Inbox without signal-r, then "SubscribeToSignalR" needs to set as false; 
            var subscribeToSignalR = ConfigurationManager.AppSettings.Get("SubscribeToSignalR");
            if (string.IsNullOrEmpty(subscribeToSignalR))
            {
                _logService.Warn(() => string.Format("Unable to find 'SubscribeToSignalR' key in web.config. Missing this key will set signalR subscription enable as default. The default value for SubscribeToSignalR key is true. If you want to disable signal-R for Inbox, then must add [<add key=\"SubscribeToSignalR\" value=\"false\" />] to web.config ;otherwise ignore this warning"));
                //If no key found then, default to true; Enable signal r
                ViewBag.SubscribeToSignalR = true;
            }
            else
            {
                bool result;

                if (!bool.TryParse(subscribeToSignalR, out result))
                {
                    _logService.Warn(
                        () => string.Format("Unable to parse 'SubscribeToSignalR' value as boolean in web.config."));
                    result = true;
                }

                ViewBag.SubscribeToSignalR = result;
            }


            ViewBag.CurrentDateTime = RuntimeContext.Provider.CurrentSystemTimeToVps().ToString(CultureInfo.InvariantCulture);
            //determine the current operator's permission for Activity Log , in order to show different UI components accordingly.
            ViewBag.IsPermitPublish = _authFacade.HasAccess(operatorAccess, SystemObject.EventPublisher, ActionType.Publish);//permission for Forward / Reply
            if (viewType == EventViewType.Log)
            {
                ViewBag.IsPermitView = _authFacade.HasAccess(operatorAccess, SystemObject.ActivityLog, ActionType.View);//permission to View AL
                ViewBag.IsPermitModify = _authFacade.HasAccess(operatorAccess, SystemObject.ActivityLog, ActionType.Modify);//permission to Modify AL
                ViewBag.IsPermitAcceptDecline = false;
                ViewBag.IsPermitReview = false;

            }
            if (viewType == EventViewType.Inbox)
            {
                ViewBag.IsPermitReview = _authFacade.HasAccess(operatorAccess, SystemObject.EventManager, ActionType.Modify);//permission for Review 
                ViewBag.IsPermitModify = _authFacade.HasAccess(operatorAccess, SystemObject.EventManager, ActionType.Modify);// permission for create/ update
                ViewBag.IsPermitAcceptDecline = _authFacade.HasAccess(operatorAccess, SystemObject.Organization, ActionType.Modify);//permission for Accept/Decline 

            }
            var provider = RuntimeContext.Provider;
            var vpsTimeZOne = provider.GetVpsTimeZoneFromId();
            ViewBag.DateFormat = provider.GetDateFormat();
            ViewBag.DateTimeFormat = provider.GetDateTimeFormat();
            ViewBag.VPSTimeZone = vpsTimeZOne;
            ViewBag.UtcOffsetInMinutes = vpsTimeZOne.BaseUtcOffset.TotalMinutes;
            ViewBag.VPSOffsetFromSystemInMinutes = provider.VPSOffsetFromSystemInMinutes();
            ViewBag.SupportsDaylightSavingTime = vpsTimeZOne.SupportsDaylightSavingTime;
            //Maximum number of records can be exported.
            ViewBag.exportLimit = 1000;
            return View("Index");
        }

        [IWSAuthorize(new[] { SystemObject.EventManager }, new[] { ActionType.View })]
        public ActionResult Inbox(int? eid)
        {
            var providerId = RuntimeContext.ProviderId;
            int eventCategoryId = 0;
            var eventCategory = _eventFacade.GetEventCategories(new EventCategorySpec
            {
                ProviderId = providerId,
                CommonName = Business.Domain.Event.ObjectModel.EventCategoryConstant.CommonName.Invite
            }, RuntimeContext.Provider.BaseLocale);
            var invitecategory = eventCategory.SingleOrDefault();
            if (invitecategory != null)
            {
                eventCategoryId = invitecategory.EventCategoryId;

            }
            //Below flag is used if inbox needs to filter by EventType; also you need to pass EventCategoryId for EventTYpe filter.
            TempData.Add("FilterByEventType", true);
            TempData.Add("EventCategoryId", eventCategoryId);

            //Below flag is used if inbox needs to filter by Reviewed = No;
            TempData.Add("FilterByReviewedNo", true);

            return RedirectToAction("Index", eid ?? 0);
        }

        [IWSAuthorize(new[] { SystemObject.ActivityLog }, new[] { ActionType.View })]
        public ActionResult ActivityLog()
        {
            if (!RuntimeContext.Provider.FeatureMatrix.IsActivityLogSupported)
            {
                ViewBag.NotSupportedMessage = IWSResources.Event_Activity_Log_Support_Message;
                return View("_NotSupported");
            }
            TempData.Add("ViewType", EventViewType.Log);
            var eventCategory = _eventFacade.GetEventCategories(new EventCategorySpec
            {
                ProviderId = RuntimeContext.ProviderId,
                CommonName = Business.Domain.Event.ObjectModel.EventCategoryConstant.CommonName.LogManual
            }, RuntimeContext.Provider.BaseLocale);
            var logEventCategory = eventCategory.SingleOrDefault();
            if (logEventCategory != null)
            {
                TempData.Add("LogEventCategoryId", logEventCategory.EventCategoryId);
            }
            return Index();
        }

        [IWSAuthorize(new[] { SystemObject.EventManager, SystemObject.ActivityLog }, new[] { ActionType.View, ActionType.View })]
        public JsonResult GetSeverityList()
        {
            try
            {
                var data = GetLocalizedSeverityList();
                return Json(data);
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Alert_List_Error_Generic });
            }
        }

        private List<KeyValueModel> GetLocalizedSeverityList()
        {
            return _globalEntityLocaleFacade.GetLocalizedEntity(SettingsHelper.Severities(), RuntimeContext.Provider.BaseLocale)
                                .Select(
                                     p =>
                                         new KeyValueModel
                                         {
                                             Id = (int)(Priority)Enum.Parse(typeof(Priority), p.SeverityId),
                                             Name = p.SeverityName
                                         }).ToList();
        }

        [IWSAuthorize(new[] { SystemObject.ActivityLog }, new[] { ActionType.Modify })]
        [ValidateInput(false)]
        public ActionResult CreateEvent(EventModel eventModel)
        {
            try
            {
                var eventObj = new Event()
                {
                    //EventType = /*eventModel.EventCategoryType*/"Report",
                    CreatedBy = RuntimeContext.OperatorId,
                    //EventCategoryId = eventModel.EventCategoryType
                    UserId = RuntimeContext.OperatorId,
                    MsgTitle = eventModel.Title,
                    MsgBody = eventModel.Body,
                    VisibilityLevel = eventModel.VisibilityLevel,
                    EventCategoryId = int.Parse(eventModel.EventCategoryType),
                    Priority = eventModel.Priority,
                    IncidentId = 0,
                    SourceName = RuntimeContext.Operator.DisplayName,
                    EventType = "Log"
                    //Priority = Severity.Unk
                };

                // set the additional attributes
                var attributes = new Dictionary<OrganizationEventCustomAttrIds, string>();
                attributes.Add(OrganizationEventCustomAttrIds.Url, eventModel.AlertUrl);
                eventObj.SetCustomData(attributes);

                int eventId = _eventFacade.CreateEvent(eventObj);
                if (eventId <= 0)
                {
                    return Json(new { Success = false });
                }

                return GetEventById(new EventSpec() { EventId = new List<int> { eventId } });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false });
            }
        }

        [IWSAuthorize(new[] { SystemObject.ActivityLog }, new[] { ActionType.Modify })]
        [ValidateInput(false)]
        public ActionResult UpdateEvent(EventModel eventModel)
        {
            try
            {
                Business.Domain.Entities.Event eventObj = new Business.Domain.Entities.Event()
                {
                    EventId = eventModel.Id,
                    MsgTitle = eventModel.Title,
                    MsgBody = eventModel.Body,
                    Priority = eventModel.Priority
                };

                // set the additional attributes
                Dictionary<OrganizationEventCustomAttrIds, string> attributes = new Dictionary<OrganizationEventCustomAttrIds, string>();
                attributes.Add(OrganizationEventCustomAttrIds.Url, eventModel.AlertUrl);
                eventObj.SetCustomData(attributes);

                bool ret = _eventFacade.UpdateEvent(eventObj);
                if (!ret)
                {
                    return Json(new { Success = false });
                }

                return GetEventById(new EventSpec() { EventId = new List<int> { eventModel.Id } });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false });
            }
        }

        /// <summary>
        /// Get Events by Event Spec
        /// </summary>
        /// <param name="eventSpec">EventSpec</param>
        /// <returns>JSON result</returns>
        [IWSAuthorize(new[] { SystemObject.EventManager, SystemObject.ActivityLog }, new[] { ActionType.View, ActionType.View })]
        public ActionResult GetEvents(EventSpec eventSpec)
        {
            try
            {
                //make sure to include total count
                eventSpec.IncludeTotalCount = true;
                var eventsViewModel = GetEvents(eventSpec, true);
                return Json(new { TotalCount = eventsViewModel.TotalEvent, LastUpdatedTime = RuntimeContext.Provider.CurrentSystemTimeToVpsTimeString(), Data = eventsViewModel.Events });
            }
            //Catch timed out exception
            catch (TimeoutException ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, LastUpdatedTime = RuntimeContext.Provider.CurrentSystemTimeToVpsTimeString(), Data = string.Empty, IsTimedOut = true });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                //Making sure timed out exception is not skipping in above statement.
                return Json(new { Success = false, LastUpdatedTime = RuntimeContext.Provider.CurrentSystemTimeToVpsTimeString(), Data = string.Empty, IsTimedOut = ex.Message.ToLower().Contains("operation has timed out") });
            }

        }

        [IWSAuthorize(new[] { SystemObject.EventManager, SystemObject.ActivityLog }, new[] { ActionType.View, ActionType.View })]
        public ActionResult GetEventById(EventSpec eventSpec)
        {
            try
            {
                eventSpec.IncludeTotalCount = false; //Do not call get total count query.

                //Get EventData including Media attachment
                var eventData = _eventFacade.GetEventById(eventSpec.EventId[0], true);

                if (eventData.Event.ProviderId != RuntimeContext.ProviderId)
                {
                    _logService.Error(() => "Unauthorized Operation.");
                    return Json(new { Success = false, LastUpdatedTime = DateTime.Now, Data = IWSResources.Athoc_Warning_UnauthrizedOperation, IsTimedOut = false });
                }

                IDictionary<int, EventCategory> categories = new Dictionary<int, EventCategory>();
                categories.Add(eventData.Event.EventCategory.EventCategoryId, eventData.Event.EventCategory);
                var eventsViewModels = Models.Event.EventModel.GenerateEventModels(_userFacade, new List<Business.Domain.Entities.Event>() { eventData.Event }, categories, eventData.MediaAttachments, _authFacade);


                //var eventsViewModel = Models.Event.EventModel.GenerateEventModel(eventData.Event, eventData.Event.EventCategory, eventData.MediaAttachments, _authFacade);
                /*eventsViewModel.ReviewedByDisplayName = GetUserDisplayName(eventsViewModel.ReviewedBy.GetValueOrDefault());
                if (eventsViewModel.RespondedBy.HasValue)
                    eventsViewModel.RespondedByDisplayName = GetUserDisplayName(eventsViewModel.RespondedBy.GetValueOrDefault());*/
                return Json(new { Success = true, LastUpdatedTime = RuntimeContext.Provider.CurrentSystemTimeToVpsTimeString(), Data = eventsViewModels[0] });
            }
            //Catch timed out exception
            catch (TimeoutException ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, LastUpdatedTime = DateTime.Now, Data = string.Empty, IsTimedOut = true });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                //Making sure timed out exception is not skipping in above statement.
                return Json(new { Success = false, LastUpdatedTime = DateTime.Now, Data = string.Empty, IsTimedOut = ex.Message.ToLower().Contains("operation has timed out") });
            }
        }

        /// <summary>
        /// Get User Details by User Id
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        [IWSAuthorize(new[] { SystemObject.EventManager, SystemObject.ActivityLog }, new[] { ActionType.View, ActionType.View })]
        public JsonResult GetUserDetails(int userId = 0)
        {
            if (userId == 0)
                return Json(new { Success = false, ErrorMessage = "USER_ID EMPTY" });

            //Get User from User Facade.
            var user = _userFacade.GetUserBySpec(new UserSpec
            {
                ProviderId = RuntimeContext.ProviderId,
                OperatorId = RuntimeContext.OperatorId,
                CustomFieldFormat = true,
                UserId = userId,
                GetUserAttributes = true
            });
            return Json(new { Success = true, ErrorMessage = string.Empty, Data = user });
        }
        /// <summary>
        /// Get Event Categories
        /// </summary>
        /// <returns>JSON of Event Categoreis collection.</returns>

        [IWSAuthorize(new[] { SystemObject.EventManager, SystemObject.ActivityLog }, new[] { ActionType.View, ActionType.View })]
        public JsonResult GetEventCategories(EventViewType viewType = EventViewType.All)
        {
            //1. Get Event Category Type from Facade
            //2. Get Event Category client model which is grouped by Category Type.
            var evtCategories = _eventFacade.GetEventCategories(RuntimeContext.ProviderId, viewType);
            var groups = EventModel.GenerateEventCategoryModel(evtCategories);

            //Return Json Response.
            return Json(new { EventCategories = groups });
        }

        [IWSAuthorize(new[] { SystemObject.EventManager, SystemObject.ActivityLog }, new[] { ActionType.View, ActionType.View })]
        public JsonResult GetDistributionLists()
        {
            var distibutionListSpec = new DistributionListSpec { ProviderId = RuntimeContext.ProviderId, IsSystem = false, ExcludeDeleted = true, OperatorId = RuntimeContext.OperatorId, IncludeHierarchy = false };
            var distributionLists =
                _publishingFacade.GetDistributionLists(distibutionListSpec).Where(x => x.IsAvailableForMap == "Y" && x.ListType != ListItemType.Tree);

            return Json(new { DistributionLists = distributionLists });
        }

        [IWSAuthorize(new[] { SystemObject.EventManager, SystemObject.ActivityLog }, new[] { ActionType.View, ActionType.View })]
        public JsonResult GetOrganizations()
        {
            try
            {
                var organizations = _organizationFacade.GetOrganizations(RuntimeContext.ProviderId,
                    new OrganizationSpec());
                return Json(new { Organizations = organizations });
            }
            catch (Exception err)
            {
                return Json(new { Organizations = new String[0] });
            }
        }

        [IWSAuthorize(new[] { SystemObject.EventManager, SystemObject.ActivityLog }, new[] { ActionType.View, ActionType.View })]
        public JsonResult GetOrganizationLists()
        {
            try
            {
                //this code copied from Itzik's code in mapcontroller
                TargetingManager tm = new TargetingManager(RuntimeContext.ProviderId);
                var table = tm.GetMassUserInfoForDevice("UAP-IAC", 0); //todo, define as const somewhere
                SortedDictionary<int, string> orgs = new SortedDictionary<int, string>();
                foreach (DataRow row in table.Rows)
                {
                    int orgId = int.Parse(row["USER_ID"].ToString());
                    orgs.Add(orgId, row["DISPLAYNAME"].ToString());
                }
                orgs.OrderBy(kv => kv.Value);

                return Json(new { organizationList = orgs });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { organizationList = string.Empty });
            }

        }

        [IWSAuthorize(new[] { SystemObject.EventManager, SystemObject.ActivityLog }, new[] { ActionType.View, ActionType.View })]
        public JsonResult GetOrganization(string orgId)
        {
            //for athoc Inc org, it's a sample organization, which doesn't exist on PSS side
            if (orgId == "00000000-0000-0000-0000-000000000001")
            {
                var athocOrg = new OrganizationInfo
                {
                    ContactInfo =
                        new OrganizationContactInfo
                        {
                            FirstName = "AtHoc",
                            LastName = "Support",
                            PhoneNumber = "support@athoc.com"
                        },
                    Description = "AtHoc is the pioneer and recognized leader in network-centric, interactive crisis communication. We serve the security, life safety and business continuity missions of commercial enterprises and government agencies worldwide. (AtHoc does not accept alerts through this profile. Contact AtHoc Support if you need assistance.)",
                    Guid = "00000000-0000-0000-0000-000000000001",
                    Location = "POINT (-122.327304 37.538207)",
                    LogoVersion = "4",
                    Name = "AtHoc Inc.",
                    OrganizationSector = new OrganizationSectorInfo
                    {
                        Id = 13,
                        Name = "Commercial",
                        Description = "Commercial"
                    },
                    PhysicalAddress = new OrganizationAddress
                    {
                        AddressLine1 = "2988 Campus Dr.",
                        AddressLine2 = "",
                        City = "San Mateo",
                        ZipCode = "94404",
                        State = "CA",
                        Country = "USA"
                    },
                    //Type = OrganizationType.Commercial,
                    Url = "http://www.athoc.com"
                };

                return Json(new { Organization = athocOrg, Type = athocOrg.OrganizationSector.Name });
            }

            var organization = _organizationFacade.GetOrganizationById(RuntimeContext.ProviderId, orgId);
            return Json(new { Organization = organization, Type = organization.Sector.ToString() });
        }

        [IWSAuthorize(new[] { SystemObject.EventPublisher }, new[] { ActionType.Modify })]
        [HttpPost]
        public JsonResult UpdateReplyStatus(string replyMsg, int eventId, string responseOptionId, string messageContext = "")
        {
            //First, call _organizationFacade.SetMessageStatus();
            //if IS_RESPONDED is already "Y", don't do anything. And return a json {msg: "has already been responded"}
            //for description tab
            //0. create a new row to description table with the eventId
            //1. add replyMsg to description tab in event database
            //2. record sourceid (user_id) and sourcetype (always "USER" for this case) in the description table
            //3. created_on and updated_on is the current database time (getUTCDate())
            //4. type is "reply"
            //for event tab
            //1. IS_RESPONDED is "Y"
            //2. updated_on should be getutcdate();


            //Call API and make sure the API return boolean success, then do create entry in Event_Description Database.
            bool apiResponse;
            if (responseOptionId == "-1")
            {
                apiResponse = _organizationFacade.SetMessageStatus(RuntimeContext.ProviderId, messageContext,
                    MessageDeliveryStatus.Ack, responseOptionId, null, null);
            }
            else
            {
                apiResponse = _organizationFacade.SetMessageStatus(RuntimeContext.ProviderId, messageContext,
                    MessageDeliveryStatus.Response, responseOptionId, HttpUtility.HtmlDecode(replyMsg), null);
            }
            if (apiResponse)
            {

                var eventDescription = new EventDescription
                {
                    EventId = eventId,
                    Description = HttpUtility.HtmlDecode(replyMsg),
                    SourceId = RuntimeContext.Operator.Id,
                    //Source Type should be always "USER" while responding to event
                    SourceType = SourceType,

                    //Type should be "response",this entry to goes to event_description db, where in it will be used to identity the event response entry.
                    Type = ResponseType
                };
                EventResponse eventResponse;
                string outMessage = string.Empty;
                var respondedOn = new DateTime();
                var result = _eventFacade.CreateEventDescription(eventDescription, out eventResponse, out respondedOn);

                if (!result)
                {
                    outMessage = IWSResources.Event_Unable_To_Respond_Via_Database;
                    //Return false, when response operation is failed.
                    return Json(new { IsSuccess = false, RespondedByDisplayName = RuntimeContext.Operator.DisplayName, RespondedBy = RuntimeContext.Operator.Id, RespondedOn = RuntimeContext.Provider.UtcToVpsTime(respondedOn), Message = outMessage });
                }
                //Set the message for view based on the operation status
                switch (eventResponse)
                {
                    case EventResponse.AlreadyResponded:
                        outMessage = IWSResources.Event_Already_Responded;
                        break;
                    case EventResponse.Successfull:
                        outMessage = IWSResources.Event_Responded_Successful;
                        break;
                    case EventResponse.EventEnded:
                        outMessage = IWSResources.Event_Already_Ended;
                        break;
                    default:
                        outMessage = IWSResources.Event_Responded_Successful;
                        break;
                }
                //Response success
                return Json(new { IsSuccess = true, RespondedByDisplayName = RuntimeContext.Operator.DisplayName, RespondedBy = RuntimeContext.Operator.Id, RespondedOn = RuntimeContext.Provider.UtcToVpsTime(respondedOn), Message = outMessage });
            }
            //if API is failed
            return Json(new { IsSuccess = false, RespondedByDisplayName = string.Empty, RespondedBy = string.Empty, RespondedOn = RuntimeContext.Provider.CurrentSystemTimeToVps(), Message = IWSResources.Event_Unable_To_Respond_Via_API });

        }

        /// <summary>
        /// Get the Response Options for event.
        /// </summary>
        /// <param name="eventId"></param>
        /// <returns></returns>
        public JsonResult GetResponseOptions(int eventId)
        {
            try
            {
                //Get XML data for Event
                var evt = _eventFacade.GetEventById(eventId);
                if (evt == null || evt.Event == null)
                {
                    return Json(new { ResponseOptions = string.Empty, DeliveryContext = string.Empty, Success = false, ErrorMessage = "Event not found" });
                }

                var additionalInfo = evt.Event.GetCustomData();

                //Get Availble response options for Events
                var obj = EventModel.GetResponseOption(additionalInfo);

                //Get Message Context (aka delivery context
                var deliveryContext = EventModel.GetDeliveryContext(additionalInfo);

                return Json(new { ResponseOptions = obj, DeliveryContext = deliveryContext, Success = true });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { ResponseOptions = string.Empty, DeliveryContext = string.Empty, Success = false });
            }

        }


        /// <summary>
        /// Update Event Review Status
        /// </summary>
        /// <param name="eventSpec"></param>
        /// <returns></returns>
        [IWSAuthorize(new[] { SystemObject.EventReviewer }, new[] { ActionType.Modify })]
        [HttpPost]
        public ActionResult UpdateEventReviewStatus(EventSpec eventSpec)
        {
            try
            {
                eventSpec.ProviderId = RuntimeContext.ProviderId;
                eventSpec.Operator = RuntimeContext.Operator;
                eventSpec.OperatorId = RuntimeContext.OperatorId;

                bool canUpdateReviewStatus = false;
                if(eventSpec.EventId != null && eventSpec.EventId.Count > 0)
                {
                    //fix for ISEC-445
                    var e = _eventFacade.GetEventById(eventSpec.EventId.FirstOrDefault());
                    canUpdateReviewStatus = e.Event.ProviderId == eventSpec.ProviderId;
                }

                if (!canUpdateReviewStatus) //return 500 when security error occurs
                {
                    _logService.Error(() => IWSResources.Athoc_Warning_UnauthrizedOperation);
                    Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    Response.StatusDescription = IWSResources.Event_Error_Updating_ReviewedBy;
                    return Json(new { Success = false, SuccessMessage = "", ErrorMessage = IWSResources.Event_Error_Updating_ReviewedBy });
                }

                var result = _eventFacade.UpdateReviewStatus(eventSpec);
                if (result)
                {
                    return Json(new { Success = true, SuccessMessage = "", Action = (eventSpec.Reviewed.Value ? "Reviewed" : "UnReviewed") });
                }
                else
                {
                    return Json(new { Success = false, SuccessMessage = "", ErrorMessage = IWSResources.Event_Error_Updating_ReviewedBy });
                }
            }
            catch (Exception ex)
            { 
                _logService.Error(() => ex);
                return Json(new { Success = false, ErrorMessage = IWSResources.Event_Error_Updating_ReviewedBy });
            }
        }

        /// <summary>
        /// Perform Accept/Decline action
        /// </summary>
        /// <param name="invitationId">invitationId (AtHoc Connect OrganizationInvitationId)</param>
        /// <param name="alertId">EventId - Event Table</param>
        /// <param name="action">1 = Accept, 2 = Cancel, 3 = Decline</param>
        /// <param name="sourceOrgGuid">Source Org Guid for this event request</param>
        /// <returns>JSON Result</returns>
        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.Organization }, new[] { ActionType.Modify })]
        public ActionResult SetConnectAction(int invitationId, int alertId, int action, string sourceOrgGuid = "")
        {
            bool result = false;
            try
            {
                //Parse Agreement Action from Enum.
                var agreementAction = (InvitationAction)action;

                //For Backward Compatibility - This is the case, when InvitationId is not available for old events. (Before 88 release)
                if (invitationId == 0)
                {
                    var selfInvitations = _organizationFacade.GetConnections(RuntimeContext.ProviderId, includeAgreement: false, includeInvitation: true, includeExternalInvitation: false);
                    var currentInvitation = selfInvitations.Invitations.FirstOrDefault(a => a.InviterOrganizationGuid == sourceOrgGuid && a.Status == OrganizationInvitationStatus.Pending);
                    if (currentInvitation == null)
                    {
                        _logService.Error(() => "InvitationId cannot be empty.");
                        return Json(new { Success = false, ErrorMessage = "Error while Setting Connect Action." });
                    }
                    invitationId = currentInvitation.Id;

                }

                //Call AtHoc Connect UpdateInvitation API.
                var response = _organizationFacade.UpdateInvitation(RuntimeContext.ProviderId, invitationId,
                    agreementAction);

                //If API execution succeed, then set flag at IWS -> Event Table. Such that, no more action should be performed.
                if (response.IsSuccess)
                {
                    var actionPerformed = ActionPerformed.ConnectRequestActionRequired;

                    if (agreementAction == InvitationAction.Accept)
                    {
                        actionPerformed = ActionPerformed.Accepted;
                    }
                    else if (agreementAction == InvitationAction.Decline)
                    {
                        actionPerformed = ActionPerformed.Declined;
                    }

                    //Once accepted, no more action required, thus set this event IS_CONNECT_ACTION_REQUIRED flag = 'N'
                    result = _eventFacade.SetConnectActionFlag(alertId, RuntimeContext.ProviderId, RuntimeContext.OperatorId, actionPerformed, sourceOrgGuid);

                }
                else
                {
                    if (response.ErrorId == ConnectErrorCodes.InvitationAlreadyAccepted.Description() ||
                        response.ErrorId == ConnectErrorCodes.InvitationAlreadyDeclined.Description()
                        || response.ErrorId == ConnectErrorCodes.InvitationAlreadyCancelled.Description())
                    {
                        result = _eventFacade.SetConnectActionFlag(alertId, RuntimeContext.ProviderId, RuntimeContext.OperatorId, ActionPerformed.ActionNotRequired, sourceOrgGuid);
                    }
                    return Json(new { Success = false, Message = GetErrorDescription(response.ErrorId), ErrorCode = response.ErrorId });
                }
                return Json(new { Success = result, Message = "" });

            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Message = "Error while Setting Connect Action.", ErrorCode = "NotDefined" });
            }
        }

        private string GetErrorDescription(string errorCode)
        {
            string description = "Undefined Error";
            if (ConnectErrorCodes.InvitationAlreadyAccepted.Description() == errorCode)
            {
                description = IWSResources.Organization_Invitation_Already_Accepted;
            }
            else if (ConnectErrorCodes.InvitationAlreadyDeclined.Description() == errorCode)
            {
                description = IWSResources.Organization_Invitation_Already_Declined;
            }
            else if (ConnectErrorCodes.InvitationAlreadyCancelled.Description() == errorCode)
            {
                description = IWSResources.Organization_Invitation_Already_Cancelled;
            }
            return description;
        }

        /// <summary>
        /// Get Event Manager Related Resource Content
        /// </summary>
        /// <returns></returns>

        [OutputCache(Duration = 0, VaryByParam = "none")]
        public JsonResult GetResource()
        {
            const string resourcePatternForInbox = "PA_|Event_|Inbox_|Map_ZoomToFit|Publishing_|Unsaved_Data_Text|AtHoc_|Action_|KO_|Bread|General_|IUTAllUsers_|IUTAllUser_|PAEvent_|^AtHoc_User_Search|^User_Criteria_Builder_|^User_Group_Selector_|WAMRule_|DurationFormat_";
            var inboxResourceSet = IWSResources.ResourceManager.GetResourceSetByPattern(resourcePatternForInbox);
            return Json(new { Resources = inboxResourceSet });

        }

        /// <summary>
        /// Export Events to Pdf. 
        /// </summary>
        /// <param name="eventSpec">EventSpec.</param>
        /// <param name="filterStructure">Export filter text.</param>
        /// <returns>Export PDF View</returns>
        [HttpPost]
        [FileDownloadCookie]
        [RenderAsPDF(AutoConvert = false)]
        [IWSAuthorize(new[] { SystemObject.ActivityLog }, new[] { ActionType.View })]
        public ActionResult ExportToPdf(EventSpec eventSpec, string filterStructure)
        {

            eventSpec.ViewType = EventViewType.Log;
            var eventViewModel = GetEvents(eventSpec, false);
            var exportModel = GetExportModel(eventViewModel.Events.ToList(), false);
            exportModel.SubHeadline = GenerateFilterText(filterStructure);
            var pdfHtml = ExportUtility.SetPdf(exportModel);//Get Pdf Html Data to be rendered.
            try
            {
                MVCToPDF.ResultFileName = pdfHtml.FileName;
                MVCToPDF.RenderAsPDF();
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
            }
            return View("_ExportToPdf", pdfHtml);
        }

        /// <summary>
        /// Export Events to Csv.
        /// </summary>
        /// <param name="eventSpec">EventSpec.</param>
        /// <returns>Csv File Result.</returns>
        [HttpPost]
        [FileDownloadCookie]
        [IWSAuthorize(new[] { SystemObject.ActivityLog }, new[] { ActionType.View })]
        public FileResult ExportToCsv(EventSpec eventSpec)
        {
            eventSpec.ViewType = EventViewType.Log;
            var evenList = GetEvents(eventSpec, false);
            var exportModel = GetExportModel(evenList.Events.ToList(), true);
            var csvData = ExportUtility.SetCsv(exportModel);
            return File(csvData.GridData, "text/csv", csvData.FileName);
        }

        /// <summary>
        /// To get events count by spec.
        /// </summary>
        /// <param name="eventSpec">Event spec.</param>
        /// <returns>Events count.</returns>
        public int GetEventCount(EventSpec eventSpec)
        {
            if (eventSpec.OrderBy == "Priority")
            {
                eventSpec.OrderAsc = !eventSpec.OrderAsc;
            }
            eventSpec.ViewType = EventViewType.Log;
            eventSpec.ProviderId = RuntimeContext.ProviderId;
            eventSpec.CurrentDbUtc =
                RuntimeContext.Provider.VpsToUtcTime(RuntimeContext.Provider.CurrentSystemTimeToVps());
            eventSpec.FuncVpsToUtcTime = RuntimeContext.Provider.VpsToUtcTime;
            eventSpec.Operator = RuntimeContext.Operator;
            eventSpec.OperatorId = RuntimeContext.OperatorId;
            eventSpec.ViewType = EventViewType.Log;
            return _eventFacade.GetEventCountBySpec(eventSpec);
        }
        /// <summary>
        /// To get the event count for all possible date range.
        /// </summary>
        /// <param name="eventSpec">EventSpec.</param>
        /// <returns>Json of event range with event count.</returns>
        public ActionResult GetEventCountForAllTimeRange(EventSpec eventSpec)
        {
            Dictionary<string, int> eventCounts = new Dictionary<string, int>();
            DateTime today = RuntimeContext.Provider.CurrentSystemTimeToVps();
            eventSpec.DateRangeTo = today;
            eventSpec.DateRangeFrom = today.AddDays(-1);
            eventCounts.Add("last24", GetEventCount(eventSpec));
            eventSpec.DateRangeFrom = today.AddDays(-7);
            eventCounts.Add("lastweek", GetEventCount(eventSpec));
            eventSpec.DateRangeFrom = today.AddMonths(-1);
            eventCounts.Add("lastmonth", GetEventCount(eventSpec));
            eventSpec.DateRangeTo = null;
            eventSpec.DateRangeFrom = null;
            eventCounts.Add("all", GetEventCount(eventSpec));
            return Json(eventCounts);
        }
        /// <summary>
        /// To get ExportModel.
        /// </summary>
        /// <param name="eventModelList">Event Model List.</param>
        /// <param name="isCsv">Is export file type Csv.</param>
        /// <returns>Export Model.</returns>
        private static ExportModel GetExportModel(List<EventModel> eventModelList, bool isCsv)
        {
            var gridHeader = new List<ExportGridColumnConfig>();
            if (!isCsv)
            {
                gridHeader.Add(new ExportGridColumnConfig("EventTimeAndType")
                {
                    FormatValue =
                        "{EventTime}<p>{Type}</p>",
                    HeaderStyle = "time-type-col",
                    ValueStyle = "time-type-col time-type-vlaue",
                    IsLocalizationRequired = false
                });
                gridHeader.Add(new ExportGridColumnConfig("TitleAndBodyAndUrl")
                {
                    FormatValue =
                        "{Title}<p>{Body}</p><p>{Url}<p>",
                    HeaderStyle = "pdf-grid-large-col",
                    ValueStyle = "pdf-grid-bold-col pdf-grid-large-col title-message-col"
                });
                gridHeader.Add(new ExportGridColumnConfig("Severity")
                {
                    IsLocalizationRequired = true,
                    ValueLocalizationKey = "Event_Severity_",
                    HeaderStyle = "pdf-grid-small-col",
                    ValueStyle = "pdf-grid-small-col"
                });
                gridHeader.Add(new ExportGridColumnConfig("Source")
                {
                    HeaderStyle = "pdf-grid-small-col",
                    ValueStyle = "pdf-grid-small-col"
                });

            }
            else
            {
                gridHeader.Add(new ExportGridColumnConfig("EventTime"));
                gridHeader.Add(new ExportGridColumnConfig("Type") { IsLocalizationRequired = false });
                gridHeader.Add(new ExportGridColumnConfig("Title"));
                gridHeader.Add(new ExportGridColumnConfig("Body"));
                gridHeader.Add(new ExportGridColumnConfig("Severity") { IsLocalizationRequired = true, ValueLocalizationKey = "Event_Severity_" });
                gridHeader.Add(new ExportGridColumnConfig("Source"));
            }
            var exportList = eventModelList.Select(eventModel => new Dictionary<string, object>
            {
                {"EventTime", eventModel.CreatedOn},
                {"Type", eventModel.EventCategoryName},
                {"Title", eventModel.Title},
                {"Body", eventModel.Body},
                {
                    "Severity",
                    Enum.Parse(typeof (AtHoc.IWS.Business.Domain.Events.Severity), eventModel.Priority.ToString())
                },
                {"Source", eventModel.SourceName},
                {"Url", eventModel.AlertUrl+"#UrlText#"+IWSResources.Inbox_DetailView_MoreInfo}

            }).ToList();

            var exportModel = new ExportModel
            {
                Title = IWSResources.ActivityLog_Title,
                GridHeaderLocalizationKey = "Event_Export_",
                GridRows = exportList,
                GridHeaders = gridHeader

            };
            return exportModel;
        }

        /// <summary>
        /// Get Inbox View Model
        /// </summary>
        /// <param name="eventSpec">Event Spec.</param>
        /// <param name="includeMediaAttachment">parameter to include Media Attachment.</param>
        /// <returns>Inbox View Model</returns>
        /// 
        /// 
         [HttpGet]
        private InboxViewModel GetEvents(EventSpec eventSpec, bool includeMediaAttachment)
        {
            //for severity sorting, descending means high severity is on top
            if (eventSpec.OrderBy == "Priority")
            {
                eventSpec.OrderAsc = !eventSpec.OrderAsc;
            }
            eventSpec.ProviderId = RuntimeContext.ProviderId;
            eventSpec.CurrentDbUtc =
                RuntimeContext.Provider.VpsToUtcTime(RuntimeContext.Provider.CurrentSystemTimeToVps());

            if (eventSpec.DateRangeFrom.HasValue)
            {
                var tempFrom = DateTime.SpecifyKind(eventSpec.DateRangeFrom.Value, DateTimeKind.Unspecified);
                eventSpec.DateRangeFrom = RuntimeContext.Provider.SystemToVpsTime(tempFrom);
            }
            if (eventSpec.DateRangeTo.HasValue)
            {
                var tempTo = DateTime.SpecifyKind(eventSpec.DateRangeTo.Value, DateTimeKind.Unspecified);
                eventSpec.DateRangeTo = RuntimeContext.Provider.SystemToVpsTime(tempTo);
            }
            eventSpec.FuncVpsToUtcTime = RuntimeContext.Provider.VpsToUtcTime;
            eventSpec.Operator = RuntimeContext.Operator;
            eventSpec.OperatorId = RuntimeContext.OperatorId;

            //Get EventData including Media attachment
            var eventData = _eventFacade.GetEventsBySpec(eventSpec, includeMediaAttachments: includeMediaAttachment);
            var inboxViewModel = new InboxViewModel();
            inboxViewModel.TotalEvent = eventData.Events.Count;
            inboxViewModel.Events = Models.Event.EventModel.GenerateEventModels(_userFacade, eventData.Events.Data, eventData.EventCategories, eventData.MediaAttachments, _authFacade);
            return inboxViewModel;
        }

        private string GenerateFilterText(string filterStructure)
        {
            var jsonSerializerSettings = new JsonSerializerSettings { DateTimeZoneHandling = DateTimeZoneHandling.Local, DateFormatHandling = DateFormatHandling.MicrosoftDateFormat };

            dynamic jsonObject = JsonConvert.DeserializeObject(filterStructure, jsonSerializerSettings);
            var filterText = string.Empty;
            for (int i = 0; i < jsonObject.Count; i++)
            {
                filterText = filterText + " " + jsonObject[i].fieldText + " ";
                for (int j = 0; j < jsonObject[i].fieldValue.Count; j++)
                {
                    if (jsonObject[i].field == "dateRange")
                    {
                        DateTime time;
                        DateTime.TryParse(jsonObject[i].fieldValue[j].ToString(), out time);
                        filterText = filterText + RuntimeContext.Provider.SystemToVpsDateTimeFormated(time) + " ";
                        if (j != jsonObject[i].fieldValue.Count - 1)
                            filterText = filterText + "-" + " ";
                    }
                    else
                    {
                        filterText = filterText + "" + jsonObject[i].fieldValue[j] + " ";
                        if (j != jsonObject[i].fieldValue.Count - 1)
                            filterText = filterText + " " + IWSResources.Event_Export_Or_Text + " ";

                    }

                    //else
                    //{
                    //    if (jsonObject[i].field == "dateRange")
                    //        filterText = filterText + jsonObject[i].fieldValue[j].ToString("MM/dd/yyyy HH:mm") + " " + "-" + " ";
                    //    else
                    //        filterText = filterText + "" + jsonObject[i].fieldValue[j] + " " + IWSResources.Event_Export_Or_Text + " ";
                    //}

                }
                filterText = filterText + ", ";

            }
            if (filterText.IsNotNullOrEmpty())
                return IWSResources.Event_Export_Filter_Text + ": " + filterText.TrimEnd(',', ' ');
            return IWSResources.Event_Export_Filter_Text + ": " + IWSResources.Event_Export_Empty_Filter_Text;
        }


    }
}