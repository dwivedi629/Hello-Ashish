﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.Entity.Core;
using System.Globalization;
using System.Configuration;
using System.Linq;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using AtHoc.d911.Permission;
using AtHoc.Diagnostics;
using AtHoc.Global.Resources;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Encryption;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Web.Mvc.ActionFilters;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Data.SearchSpec;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.Accountability;
using AtHoc.IWS.Business.Domain.Accountability.Specs;
using AtHoc.IWS.Business.Domain.Authorization;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel;
using AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel;
using AtHoc.IWS.Business.Domain.Organization;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Business.Domain.Users.Impl;
using AtHoc.IWS.Business.Domain.Users.Impl.Search;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.IWS.Web.Areas.Settings;
using AtHoc.IWS.Web.Configurations.Constants;
using AtHoc.IWS.Web.Filters;
using AtHoc.IWS.Web.Helpers;
using AtHoc.IWS.Web.Models.Accountability;
using AtHoc.IWS.Web.Models.Accoutability;
using AtHoc.IWS.Web.Models.Publishing;
using AtHoc.IWS.Web.Models.Shared;
using AtHoc.IWS.Web.Models.UserManager;
using AtHoc.Publishing;
using AtHoc.Systems;
using AtHoc.Utilities;
using EO.Internal;
using EO.Pdf;
using EO.Pdf.Mvc;
using Newtonsoft.Json;
using Scenario = AtHoc.IWS.Business.Domain.Entities.Scenario;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Web.Context;
using ResponseOption = AtHoc.IWS.Web.Models.Publishing.ResponseOption;
using AtHoc.Global.Resources.Interfaces;
using ActionType = AtHoc.IWS.Business.Domain.Entities.ActionType;
using System.Web.SessionState;
using AtHoc.IWS.Business.Domain.Settings;
namespace AtHoc.IWS.Web.Controllers
{
    [SessionState(SessionStateBehavior.ReadOnly)] //This will unblock asynchronous process.
    public class AccountController : Controller
    {

        private readonly IScenarioFacade _scenarioFacade;
        private readonly ILogService _logService;
        private readonly IPublishingDomainToModel _publishingDomainToModel;
        private readonly IPublishingModelToDomain _publishingModelToDomain;
        private readonly IAccountabilityFacade _accountabiltyFacade;
        private readonly IAlertFacade _alertFacade;
        private readonly IPublishingFacade _publishingFacade;
        private readonly IPlaceHolderFacade _placeholderFacade;
        private readonly IOperatorDetailsFacade _operatorDetailsFacade;
        private readonly IUserFacade _userFacade;
        private readonly ICustomAttributeFacade _customAttributeFacade;
        private readonly IAccountabilityFacade _accountabilityFacade;
        private readonly IUserManagerHelper _userManagerHelper;
        private readonly IAuthFacade _authFacade;
        private readonly IGlobalEntityLocaleFacade _globalEntityLocaleFacade;
        private readonly IProviderFacade _providerFacade;
        private readonly IOrganizationFacade _organizationFacade;

        public AccountController(IAccountabilityFacade accountabiltyFacade, IUserManagerHelper userManagerHelper, IAccountabilityFacade accountabilityFacade, IUserFacade userFacade, ICustomAttributeFacade customAttributeFacade, IScenarioFacade scenarioFacade, ILogService logService, IPlaceHolderFacade placeholderFacade, IPublishingDomainToModel publishingDomainToModel, IPublishingModelToDomain publishingModelToDomain, IAlertFacade alertFacade, IPublishingFacade publishingFacade, IOperatorDetailsFacade operatorDetailsFacade, IAuthFacade authFacade, IGlobalEntityLocaleFacade globalEntityLocaleFacade,IProviderFacade providerFacade, IOrganizationFacade organizationFacade)
        {
            _accountabiltyFacade = accountabiltyFacade;
            _scenarioFacade = scenarioFacade;
            _logService = logService;
            _publishingDomainToModel = publishingDomainToModel;
            _publishingModelToDomain = publishingModelToDomain;
            _alertFacade = alertFacade;
            _publishingFacade = publishingFacade;
            _placeholderFacade = placeholderFacade;
            _operatorDetailsFacade = operatorDetailsFacade;
            _accountabilityFacade = accountabilityFacade;
            _userFacade = userFacade;
            _customAttributeFacade = customAttributeFacade;
            _userManagerHelper = userManagerHelper;
            _authFacade = authFacade;
            _globalEntityLocaleFacade = globalEntityLocaleFacade;
            _providerFacade = providerFacade;
            _organizationFacade = organizationFacade;
        }

        #region Templates
        /// <summary>
        /// To get the template list view.
        /// </summary>
        /// <returns>template list view.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public ActionResult Index()
        {
            if (!RuntimeContext.Provider.FeatureMatrix.IsAccountabilitySupported)
            {
                ViewBag.NotSupportedMessage = IWSResources.Account_Accountability_Support_Message;
                return View("_NotSupported");
            }
            ViewBag.TopicToHighlight = MenuTopicsId.accountability;
            return Templates();
        }

        /// <summary>
        /// To get the template list view.
        /// </summary>
        /// <returns>template list view.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public ActionResult Templates()
        {
            if (!RuntimeContext.Provider.FeatureMatrix.IsAccountabilitySupported)
            {
                ViewBag.NotSupportedMessage = IWSResources.Account_Accountability_Support_Message;
                return View("_NotSupported");
            }

            ViewBag.TopicToHighlight = MenuTopicsId.accountability;

            SetBasicPageData();
            ViewBag.PA = true;
            ViewBag.PlaceHolderItems = new JavaScriptSerializer().Serialize(_placeholderFacade.GetPlaceHolderList(RuntimeContext.Provider.Id, RuntimeContext.OperatorId));
            SetPublisherPageData();


            return View("Templates");
        }
        /// <summary>
        /// To get the template list.
        /// </summary>
        /// <param name="spec">template specification.</param>
        /// <returns>Json containnig the template list.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public JsonResult GetTemplates(AccountabilityTemplateSpec spec)
        {
            try
            {
                var providerId = RuntimeContext.Provider.Id;
                var operatorId = RuntimeContext.OperatorId;
                spec.ProviderId = providerId;
                spec.FuncVpsToUtcTime = RuntimeContext.Provider.VpsToUtcTime;
                var templates = _accountabiltyFacade.GetTemplates(operatorId, spec, false);
                if (templates == null)
                {
                    _logService.Error(() => IWSResources.PA_Template_Load_Failed_Message);
                    return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
                }

                var models = new List<TemplateModel>();
                templates.ToList().ForEach(template => models.Add(TemplateModel.FromTemplate(template, false)));


                return Json(new { Success = true, Items = models, TotalCount = models.Count });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
            }
        }
        /// <summary>
        /// To get the template details.
        /// </summary>
        /// <param name="id">template Id.</param>
        /// <returns>Json containnig the template details.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public JsonResult GetTemplate(int id = 0)
        {
            try
            {
                var provider = RuntimeContext.Provider;
                var providerId = provider.Id;

                var operatorId = RuntimeContext.OperatorId;
                var template = _accountabiltyFacade.GetTemplate(providerId, operatorId, id);
                // default values for new template

                if (template == null)
                {
                    return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
                }

                TemplateModel tm = TemplateModel.FromTemplate(template, true);
                var eventPlaceholders = _placeholderFacade.GetEventPlaceholders(provider.BaseLocale).ToList();

                tm.ProcessSectionModel.EventPlaceholderList = eventPlaceholders;
                tm.OfficerSectionModel.EventPlaceholderList = eventPlaceholders;
                if (id == 0) //IF new template then hide Type
                {

                    tm.AlertBaseModel.ScenarioSettings.AccountabilityWorkflow.IsContentTypeVisible = false;
                }
                return Json(new { Success = true, Messages = "", Data = tm });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
            }
        }

        /// <summary>
        /// To get the event from template.
        /// </summary>
        /// <param name="id">templateId.</param>
        /// <returns>Json containing the template Model.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public JsonResult GetEventFromTemplate(int id)
        {
            try
            {
                var provider = RuntimeContext.Provider;
                var providerId = provider.Id;

                var operatorId = RuntimeContext.OperatorId;
                //todo return an Event object and not Tempalte
                var template = _accountabiltyFacade.GetTemplate(providerId, operatorId, id);
                var tm = TemplateModel.FromTemplate(template, true);
                tm.AlertBaseModel.Context = PublishingContext.AccountEvent;
                var ph = _placeholderFacade.GetEventPlaceholders(provider.BaseLocale).ToList();
                tm.ProcessSectionModel.EventPlaceholderList = ph;
                tm.OfficerSectionModel.EventPlaceholderList = ph;
                return Json(new { Success = true, Messages = IWSResources.PA_Template_Error_Message, Data = tm });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
            }
        }

        /// <summary>
        /// To duplicate the template.
        /// </summary>
        /// <param name="id">templateId.</param>
        /// <returns>Json containing templateModel.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public JsonResult DuplicateTemplate(int id)
        {
            try
            {
                var providerId = RuntimeContext.Provider.Id;
                var operatorId = RuntimeContext.OperatorId;
                var template = _accountabiltyFacade.DuplicateTemplate(providerId, operatorId, id);
                template.Name = string.Format("{0} {1}", template.Name, IWSResources.Scenario_DuplicateText);
                TemplateModel tm = TemplateModel.FromTemplate(template, true);
                var ph = _placeholderFacade.GetEventPlaceholders(template.Locale.LocaleCode).ToList();
                tm.ProcessSectionModel.EventPlaceholderList = ph;
                tm.OfficerSectionModel.EventPlaceholderList = ph;
                return Json(new { Success = true, Messages = IWSResources.PA_Template_Error_Message, Data = tm });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
            }
        }

        /// <summary>
        /// To save the template.
        /// </summary>
        /// <param name="template">templateModel.</param>
        /// <returns>Json containnig the success status and sucees message.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.Modify, ActionType.Modify })]
        [HttpPost]
        public JsonResult SaveTemplate(TemplateModel template)
        {
            try
            {
                var operatorId = RuntimeContext.OperatorId;
                var providerId = RuntimeContext.ProviderId;
                var at = template.ToTemplate(_publishingModelToDomain);
                _publishingModelToDomain.SetAlertSpec(template.AlertBaseModel, at, providerId, AtHocSystem.Local.ConnectDeviceCommonName, operatorId);

                int templateId;
                if (at.TemplateId > 0)
                {
                    templateId = at.TemplateId;
                    var ret = _accountabiltyFacade.UpdateTemplate(operatorId, at);
                    if (!ret)
                    {
                        _logService.Error(() => IWSResources.PA_Template_Update_Failed_Message);
                        return Json(new { Success = false, Messages = IWSResources.PA_Template_Update_Failed_Message });
                    }
                }
                else
                {
                    templateId = _accountabiltyFacade.CreateTemplate(operatorId, at);
                    if (templateId <= 0)
                    {
                        _logService.Error(() => IWSResources.PA_Template_Create_Failed_Message);
                        return Json(new { Success = false, Messages = IWSResources.PA_Template_Create_Failed_Message });
                    }
                }

                return Json(new { Success = true, Data = templateId });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
            }
        }

        /// <summary>
        /// to remove templates.
        /// </summary>
        /// <param name="ids">templateIds.</param>
        /// <returns>Json containing the success status and message.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.Modify, ActionType.Modify })]
        [HttpPost]
        public JsonResult RemoveTemplate(List<int> ids)
        {
            try
            {
                var providerId = RuntimeContext.Provider.Id;
                var operatorId = RuntimeContext.OperatorId;
                bool ret = _accountabiltyFacade.DeleteTemplates(providerId, operatorId, ids);
                if (!ret)
                {
                    _logService.Error(() => IWSResources.PA_Template_Remove_Failed_Message);
                    return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
                }
                return Json(new { Success = true, Data = ids });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
            }
        }

        /// <summary>
        /// To remove events.
        /// </summary>
        /// <param name="ids">event Ids.</param>
        /// <returns>Json containing success statsus nad success message.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.Modify, ActionType.Modify })]
        [HttpPost]
        public JsonResult RemoveEvent(List<int> ids)
        {
            try
            {
                var providerId = RuntimeContext.Provider.Id;
                var operatorId = RuntimeContext.OperatorId;
                bool ret = _accountabiltyFacade.DeleteEvents(providerId, operatorId, ids);
                if (!ret)
                {
                    _logService.Error(() => IWSResources.PA_Event_Remove_Failed_Message);
                    return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
                }
                return Json(new { Success = true, Data = ids });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
            }
        }

        #endregion

        #region Events

        /// <summary>
        /// To get the event details view.
        /// </summary>
        /// <param name="id">eventId.</param>
        /// <param name="providerId">providerId.</param>
        /// <param name="showNewDialog">showNewDialog flag.</param>
        /// <param name="tab">defalut tab to be selected</param>
        /// <returns>Event view.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public ActionResult Events(int id = 0, int providerId = 0, bool showNewDialog = false, string tab = "", DashboardConfigurationModel configurationModel = null)
        {
            var isSoftRedirect = TempData["isSoftRedirect"] != null && (bool)TempData["isSoftRedirect"];//isSoftRedirect : indicates if the internal redirect (used when Deeplink to the users tab in the specific event in the specific VPS)
            if (!isSoftRedirect && providerId != 0 && providerId != RuntimeContext.ProviderId && id > 0)
            {
                TempData["isSoftRedirect"] = true;
                var redirectUrl = "/athoc-iws/account/Events?id=" + id + "&providerId=" + providerId + "&tab=" + tab;
                var controller = DependencyResolver.Current.GetService<ChangeOrganizationController>();
                controller.ControllerContext = new ControllerContext(Request.RequestContext, controller);
                return controller.SetOrganization(providerId, redirectUrl);
            }
            if (!RuntimeContext.Provider.FeatureMatrix.IsAccountabilitySupported)
            {
                ViewBag.NotSupportedMessage = IWSResources.Account_Accountability_Support_Message;
                return View("_NotSupported");
            }

            var provider = RuntimeContext.Provider;
            ViewBag.TopicToHighlight = MenuTopicsId.accountability;
            SetBasicPageData();
            ViewBag.PA = true;
            ViewBag.PlaceHolderItems = new JavaScriptSerializer().Serialize(_placeholderFacade.GetPlaceHolderList(provider.Id, RuntimeContext.OperatorId).Where(i => i.IsSystem));
            ViewBag.ProviderType = RuntimeContext.Provider.ProviderType();
            ViewBag.ShowNewDialog = showNewDialog;
            ViewBag.selectedTab = tab;
            var operatorAccess = _operatorDetailsFacade.GetOperatorAccess(new OperatorAccessSpec
            {
                OperatorId = RuntimeContext.OperatorId,
                ProviderId = RuntimeContext.ProviderId
            });
            ViewBag.IsPAManagerRole = _authFacade.HasAccess(operatorAccess, SystemObject.AccountabilityEvent, ActionType.Modify);
            ViewBag.HasAccessToAccountability = _authFacade.HasAccess(operatorAccess, SystemObject.AccountabilityEvent, ActionType.View) && RuntimeContext.Provider.FeatureMatrix.IsAccountabilitySupported;
            ViewBag.CanViewAlert = _authFacade.HasAccess(operatorAccess, SystemObject.Alert, ActionType.View);
            //if (id > 0)
            //{
            //    providerId = _accountabilityFacade.GetEventProviderId(RuntimeContext.ProviderId, id);
            //    if (providerId == 0) { providerId = RuntimeContext.ProviderId; }
            //}
            if (id > 0 && _accountabilityFacade.CheckEventValidity(id, RuntimeContext.ProviderId, RuntimeContext.OperatorId, RuntimeContext.Provider.BaseLocale))
            //if (id > 0 && _accountabilityFacade.CheckEventValidity(id, providerId, RuntimeContext.OperatorId, RuntimeContext.Provider.BaseLocale))
            {
                ViewBag.PlaceHolderItems = new JavaScriptSerializer().Serialize(_placeholderFacade.GetPlaceHolderList(provider.Id, RuntimeContext.OperatorId).Where(i => i.IsSystem));
                SetPublisherPageData();
                ViewBag.EventId = new JavaScriptSerializer().Serialize(id);
                ViewBag.ConfigurationModel = new DashboardConfigurationModel()
                {
                    Ids = new List<int>() { id },
                    Type = "Event"
                };
                ViewBag.ProviderId = providerId;
                ViewBag.IsValidEvent = "true";
                return View("EventDetails");
            }
            /*else if (configurationModel != null && configurationModel.Ids != null && configurationModel.Ids.Count > 0)
            {
                ViewBag.PlaceHolderItems = new JavaScriptSerializer().Serialize(_placeholderFacade.GetPlaceHolderList(RuntimeContext.ProviderId, RuntimeContext.OperatorId).Where(i => i.IsSystem));
                ViewBag.IsSingleEventMode = false;
                SetPublisherPageData();
                configurationModel.Type = "Report";
                configurationModel.Tabs[TabId.Activity].Visible = false;
                configurationModel.Tabs[TabId.Setting].Visible = false;
                configurationModel.Tabs[TabId.Dashboard].Settings.Add("showOvertimeReport", "false");
                ViewBag.ConfigurationModel = configurationModel;

                return View("EventDetails");
            }*/
            ViewBag.IsValidEvent = "false";
            return View("Events");
        }

        /// <summary>
        /// To get the new Event View.
        /// </summary>
        /// <returns>Event View.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.Modify })]
        public ActionResult NewEvent()
        {
            return Events(showNewDialog: true);
        }

        /// <summary>
        /// Open Live Event Map.
        /// </summary>
        /// <returns>Live Map View.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent, SystemObject.Alert }, new[] { ActionType.View, ActionType.View, ActionType.View })]
        public ActionResult EventsLiveMap(string layerNames = "", bool allLayersEnabled = true)
        {
            var layerList = layerNames.Split(',');

            var enableMapLayers = new Dictionary<string, bool>();
            enableMapLayers.Add("AcctEventLayer", true);
            enableMapLayers.Add("SubVPSAcctEventLayer", true);
            enableMapLayers.Add("AlertLayer", true);
            enableMapLayers.Add("IncomingAlertLayer", true);
            enableMapLayers.Add("EventAlertLayer", true);
            
            if (layerList != null && layerList.Length > 0)
            {
                foreach (string layer in layerList)
                {
                    if (enableMapLayers.ContainsKey(layer))
                    {
                        enableMapLayers[layer] = !allLayersEnabled;
                    }
                }
            }

            ViewBag.enabledMapLayers = JsonConvert.SerializeObject(enableMapLayers);

            var provider = RuntimeContext.Provider;
            ViewBag.TopicToHighlight = MenuTopicsId.accountability;
            var vpsTimeZOne = RuntimeContext.Provider.GetVpsTimeZoneFromId();
            ViewBag.DateFormat = provider.GetDateFormat();
            ViewBag.DateTimeFormat = provider.GetDateTimeFormat();
            ViewBag.VPSTimeZone = vpsTimeZOne;
            ViewBag.UtcOffsetInMinutes = vpsTimeZOne.BaseUtcOffset.TotalMinutes;
            ViewBag.VPSOffsetFromSystemInMinutes = provider.VPSOffsetFromSystemInMinutes();
            ViewBag.SupportsDaylightSavingTime = vpsTimeZOne.SupportsDaylightSavingTime;
            ViewBag.OperatorName = RuntimeContext.Operator.DisplayName;
            ViewBag.CurrentDateTime = provider.CurrentSystemTimeToVps().ToString(CultureInfo.InvariantCulture);
            ViewBag.ProviderType = RuntimeContext.Provider.ProviderType();
            ViewBag.ProviderId = RuntimeContext.ProviderId;

            return View("EventsLiveMap");
        }

        [HttpPost]
        public JsonResult GetLatestTimeStamp()
        {
            var provider = RuntimeContext.Provider;
            var dateFormat = provider.GetDateFormat();
            var dateTimeFormat = provider.GetDateTimeFormat();
            var currentDateTime = provider.CurrentSystemTimeToVps().ToString(CultureInfo.InvariantCulture);
            var vpsTimeZone = RuntimeContext.Provider.GetVpsTimeZoneFromId();
            var VPSOffsetFromSystemInMinutes = provider.VPSOffsetFromSystemInMinutes();

            var tempDateTime = provider.SystemToVpsTime(DateTime.SpecifyKind(provider.CurrentSystemTimeToVps(), DateTimeKind.Unspecified));
            var dstDelta = DaylightSavingTimeDelta.CalculateDstDelta(provider.GetVpsTimeZoneFromId(), tempDateTime);

            return Json(new { currentDateTime = currentDateTime, dateFormat = dateFormat, dateTimeFormat = dateTimeFormat, vpsTimeZone = vpsTimeZone, VPSOffsetFromSystemInMinutes = VPSOffsetFromSystemInMinutes, dstDelta = dstDelta });
            
        }

        /// <summary>
        /// To get the events.
        /// </summary>
        /// <param name="spec">event specification.</param>
        /// <returns>Json containnig list of events.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public JsonResult GetEvents(AccountabilityEventSearchSpec spec)
        {
            var providerId = RuntimeContext.ProviderId;
            var operatorId = RuntimeContext.OperatorId;
            int eventFrom;
            try
            {
                var eventPublishRole = _authFacade.HasAccess(operatorId, providerId, SystemObject.AccountabilityEvent, ActionType.Publish);
                var alertPublishRole = _authFacade.HasAccess(operatorId, providerId, SystemObject.Alert, ActionType.Publish);

                int.TryParse(spec.VpsId, out eventFrom);
                switch (spec.QuickFilterValue)
                {
                    case -1: // All organizations                       
                        spec.VpsIds = eventFrom > 0 ? eventFrom.ToString() : providerId.ToString();
                        spec.IncludeSubVps = eventFrom > 0 ? false : true;
                        break;
                    case 0: // Current Organization
                        spec.IncludeSubVps = false; //Exclude the events from SUB VPS                       
                        spec.VpsIds = eventFrom > 0 ? (providerId == eventFrom ? eventFrom.ToString() : "0") : providerId.ToString();
                        break;
                    case 1: // Other All Sub Organizations
                        spec.IncludeSubVps = false;
                        spec.VpsIds = eventFrom > 0 ? (providerId != eventFrom ? eventFrom.ToString() : "0") : _accountabilityFacade.GetSubOrganizationsWithNames(RuntimeContext.ProviderId).Keys.CsvParamString();
                        break;
                }

                if (!string.IsNullOrEmpty(spec.StartDate))
                {
                    DateTime fromDate;
                    if (!DateTime.TryParse(spec.StartDate, out fromDate))
                    {
                        var formatException = string.Format("Invalid format for Start Date ={0}", spec.StartDate);
                        return Json(new { Success = false, Messages = formatException });
                    }
                    var fromDateSys = RuntimeContext.Provider.VpsToSystemTime(fromDate);
                    spec.StartDate = fromDateSys.ToString();//set from date in system time because search sproc searches in system time 
                }

                if (!string.IsNullOrEmpty(spec.EndDate))
                {
                    DateTime toDate;
                    if (!DateTime.TryParse(spec.EndDate, out toDate))
                    {
                        var formatException = string.Format("Invalid format for End Date ={0}", spec.EndDate);
                        return Json(new { Success = false, Messages = formatException });
                    }
                    toDate = toDate.AddDays(1).AddSeconds(-1);//toDate should be up to 11:59:59PM                        
                    var toDateSys = RuntimeContext.Provider.VpsToSystemTime(toDate);
                    spec.EndDate = toDateSys.ToString();//set to date in system time because search sproc searches in system time 
                }


                var events = _accountabiltyFacade.GetAccountabilitySearchResult(spec);

                if (events == null)
                {
                    _logService.Error(() => IWSResources.PA_Event_Get_Failed_Message);
                    return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
                }

                var models = new List<AccountabilityEventSearchResultModel>();
                var eventModelSpec = new EventModelSpec();
                eventModelSpec.ProviderId = providerId;
                eventModelSpec.OperatorId = operatorId;
                eventModelSpec.ProviderBaseLocale = RuntimeContext.Provider.BaseLocale;
                eventModelSpec.HasAlertPublisherRole = alertPublishRole;
                eventModelSpec.HasEventPublisherRole = eventPublishRole;
                eventModelSpec.CurrentSystemDateTime = RuntimeContext.Provider.CurrentSystemTime();

                events.GetList().ToList().ForEach(eventItem => models.Add(AccountabilityEventSearchResultModel.FromSearchResult(eventItem, eventModelSpec)));
                return Json(new { Success = true, Items = models, TotalCount = events.TotalCount() });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
            }
        }

        /// <summary>
        /// To get the event details.
        /// </summary>
        /// <param name="id">eventId.</param>
        /// <param name="providerId"></param>
        /// <returns>Json containnig event details.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public JsonResult GetEvent(int id, int providerId = 0)
        {
            try
            {
                var eventModel = GetEventModel(id);
                if (eventModel != null)
                    return Json(new JsonResponseModel(true, eventModel), JsonRequestBehavior.AllowGet);
                var ex = new ObjectNotFoundException("Accountablity Event not found");
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.PA_Event_Get_Failed_Message });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.PA_Event_Get_Failed_Message });
            }
        }

        /// <summary>
        /// To get the event details.
        /// </summary>
        /// <param name="configurationModel">configurationModel.</param>
        /// <returns>Json containnig event details.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        [HttpPost]
        public JsonResult GetEventsReport(DashboardConfigurationModel configurationModel)
        {
            try
            {
                var model = GetDashboardModel(configurationModel);
                return Json(new JsonResponseModel(true, model), JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.PA_Event_Get_Failed_Message });
            }
        }

        private DashboardModel GetDashboardModel(DashboardConfigurationModel configurationModel)
        {
            var providerId = RuntimeContext.Provider.Id;
            var operatorId = RuntimeContext.OperatorId;

            var accessCollection = RuntimeContext.Operator.OperatorAccess;
            var opeatorAccess = accessCollection as OperatorAccess[] ?? accessCollection.ToArray();
            var alertPublishRole = _authFacade.HasAccess(opeatorAccess, SystemObject.Alert, ActionType.Publish);
            var eventPublishRole = _authFacade.HasAccess(opeatorAccess, SystemObject.AccountabilityEvent, ActionType.Publish);
            var eventModelSpec = new EventModelSpec
            {
                OperatorId = operatorId,
                ProviderId = providerId,
                ProviderBaseLocale = RuntimeContext.Provider.BaseLocale,
                CurrentSystemDateTime = RuntimeContext.Provider.CurrentSystemTime(),
                HasAlertPublisherRole = alertPublishRole,
                HasEventPublisherRole = eventPublishRole
            };

            var eventIds = new List<int> { configurationModel.Ids[0] };

            var model = new DashboardModel()
            {
                Ids = eventIds,
                Type = configurationModel.Type,
                Name = configurationModel.Name,
                Description = configurationModel.Description,
            };

            if (configurationModel.SessionId == 0 || !_userFacade.IsUserSearchSessionValid(configurationModel.SessionId))
            {
                var providerContext = new ProviderContext()
                {
                    ProviderId = eventModelSpec.ProviderId,
                    BaseLocale = eventModelSpec.ProviderBaseLocale
                };

                var operatorContext = new AtHoc.IWS.Business.Context.OperatorContext()
                {
                    OperatorId = eventModelSpec.OperatorId
                };

                model.SessionId = _accountabilityFacade.GetUserSessionId(providerContext, operatorContext,eventIds.ToArray());
            }
            else
            {
                model.SessionId = configurationModel.SessionId;
            }
            
            if (configurationModel.Type == "Event")
            {
                model.RuntimeModel = GetEventRuntimeModel(model, eventIds, eventModelSpec);
            }

            return model;
        }
        private EventRuntimeModel GetEventRuntimeModel(DashboardModel dashboardModel, List<int> eventIds, EventModelSpec modelSpec)
        {
            var eventRuntimeModel = new EventRuntimeModel
            {
                Status = EventModel.GetStatusModel(eventIds, modelSpec, dashboardModel.SessionId),
                Activity = new ActivityModel(),
                Overtime = new StatusOverTimeModel()
            };
            
            bool isFirst = true;
            foreach (var eventId in eventIds)
            {
                var acctSpec = new AccountabilityEventSpec
                {
                    ProviderId = modelSpec.ProviderId,
                    OperatorId = modelSpec.OperatorId,
                    EventIds = new List<int> { eventId },
                    IncludeReminderAlertDetails = true,
                    IsLoadBaseDetails = true,
                    BaseLocale = RuntimeContext.Provider.BaseLocale
                };

                var acctEvent = _accountabiltyFacade.GetEvent(acctSpec);

                dashboardModel.DashboardItems.Add(new DashboardItemModel()
                {
                    Name = acctEvent.Name,
                    //EndDate = RuntimeContext.Provider.SystemToVpsTime(acctEvent.EndDate).ToString(RuntimeContext.Provider.GetDateTimeFormat()),
                    //EndDateUtc = eventModel.EndDateUtc,
                    //EndedBy = acctEvent.EndedBy,
                    StartedOn = RuntimeContext.Provider.SystemToVpsTime(acctEvent.StartDate).ToString(RuntimeContext.Provider.GetDateTimeFormat()),
                    StartDateUtc = acctEvent.StartDate.ToUniversalTime(),
                    //StartDate = acctEvent.StartedOn,
                    StartedBy = acctEvent.StartedBy,
                    StartedByName = acctEvent.StartedByName,
                    Id = acctEvent.EventId,
                    Status = acctEvent.Status.ToString()
                });

                if (isFirst)
                {
                    var eventModel = EventModel.FromEvent(acctEvent, true, true, modelSpec);
                    eventRuntimeModel.EventModel = eventModel;
                    eventModel.IsAlertPublisher = modelSpec.HasAlertPublisherRole;
                    eventModel.IsEventPublisher = modelSpec.HasEventPublisherRole;
                    var ph = _placeholderFacade.GetEventPlaceholders(RuntimeContext.Provider.BaseLocale).ToList();
                    eventModel.ProcessSectionModel.EventPlaceholderList = ph;
                    eventModel.OfficerSectionModel.EventPlaceholderList = ph;
                    eventModel.IsCurrentVps = acctEvent.ProviderId == modelSpec.ProviderId;
                    if (!eventModel.IsCurrentVps)
                    {
                        var subNames = GetSubOrganizationData();
                        eventModel.ProviderName = subNames.FirstOrDefault(o => o.Id == acctEvent.ProviderId).Name;
                    }
                    dashboardModel.ResponseOptions = eventModel.AlertBaseModel.Content.ResponseOptions;
                    isFirst = false;
                }

                var overtimeModel = EventModel.GetStatusOverModel(acctEvent, eventRuntimeModel.Status, modelSpec);
                eventRuntimeModel.Overtime.StatusOverTime.AddRange(overtimeModel.StatusOverTime);
                var activityModel = EventModel.GetActivityModel(acctEvent, modelSpec);
                eventRuntimeModel.Activity.SentAlerts.AddRange(activityModel.SentAlerts);
                eventRuntimeModel.Activity.PendingAlerts.AddRange(activityModel.PendingAlerts);
                eventRuntimeModel.Activity.SentAlertCountForUser = activityModel.SentAlertCountForUser;
            }

            return eventRuntimeModel;
        }

        /// <summary>
        /// To get event details.
        /// </summary>
        /// <param name="id">event Id</param>        
        /// <returns>Event Model.</returns>
        private EventModel GetEventModel(int id)
        {
            try
            {
                var provider = RuntimeContext.Provider;
                var operatorId = RuntimeContext.OperatorId;
                var providerId = RuntimeContext.ProviderId;

                var accessCollection = RuntimeContext.Operator.OperatorAccess;
                var opeatorAccess = accessCollection as OperatorAccess[] ?? accessCollection.ToArray();
                var eventPublishRole = _authFacade.HasAccess(opeatorAccess, SystemObject.AccountabilityEvent, ActionType.Publish);
                var alertPublishRole = _authFacade.HasAccess(opeatorAccess, SystemObject.Alert, ActionType.Publish);
                var eventModelSpec = new EventModelSpec();
                eventModelSpec.ProviderBaseLocale = RuntimeContext.Provider.BaseLocale;
                eventModelSpec.ProviderId = providerId;
                eventModelSpec.OperatorId = operatorId;
                eventModelSpec.HasAlertPublisherRole = alertPublishRole;
                eventModelSpec.HasEventPublisherRole = eventPublishRole;
                eventModelSpec.CurrentSystemDateTime = RuntimeContext.Provider.CurrentSystemTime();
                // This feature is moved to 92 release so commenting it for now, IWS-26999 implementation
                //if (id > 0)
                //{
                //    providerId = _accountabilityFacade.GetEventProviderId(providerId, id);
                //    if (providerId == 0)
                //    {
                //        providerId = providerId;
                //    }
                //}



                var acctSpec = new AccountabilityEventSpec
                {
                    ProviderId = providerId,
                    OperatorId = operatorId,
                    EventIds = new List<int> { id },
                    IncludeReminderAlertDetails = true,
                    IsLoadBaseDetails = true,
                    BaseLocale = RuntimeContext.Provider.BaseLocale
                };


                var acctEvent = _accountabiltyFacade.GetEvent(acctSpec);
                if (acctEvent == null)
                {
                    var ex = new ObjectNotFoundException("Accountablity Event not found");
                    LogService.Current.Error(() => ex);
                    return null;
                }
                EventModel eventModel = EventModel.FromEvent(acctEvent, true, true, eventModelSpec);
                eventModel.IsAlertPublisher = alertPublishRole;
                eventModel.IsEventPublisher = eventPublishRole;
                var ph = _placeholderFacade.GetEventPlaceholders(provider.BaseLocale).ToList();
                eventModel.ProcessSectionModel.EventPlaceholderList = ph;
                eventModel.OfficerSectionModel.EventPlaceholderList = ph;
                eventModel.IsCurrentVps = acctEvent.ProviderId == providerId;
                if (!eventModel.IsCurrentVps)
                {
                    var subNames = GetSubOrganizationData();
                    eventModel.ProviderName = subNames.FirstOrDefault(o => o.Id == acctEvent.ProviderId).Name;
                }
                return eventModel;
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return null;
            }
        }
        /// <summary>
        /// To get the eventRuntime.
        /// </summary>
        /// <param name="id">eventId.</param>
        /// <returns>Json containnig event runtime.</returns>
        public JsonResult GetEventRuntime(int id)
        {
            try
            {
                var providerId = RuntimeContext.Provider.Id;
                var operatorId = RuntimeContext.OperatorId;
                var alertPublishRole = _authFacade.HasAccess(operatorId, providerId, SystemObject.Alert, ActionType.Publish);
                var eventModelSpec = new EventModelSpec
                {
                    ProviderId = providerId,
                    OperatorId = operatorId,
                    CurrentSystemDateTime = RuntimeContext.Provider.CurrentSystemTime(),
                    HasAlertPublisherRole = alertPublishRole,
                    ProviderBaseLocale = RuntimeContext.Provider.BaseLocale
                };

                //todo: move to backend
                var acctSpec = new AccountabilityEventSpec
                {
                    ProviderId = providerId,
                    OperatorId = operatorId,
                    EventIds = new List<int>() { id },
                    IncludeReminderAlertDetails = true,
                    BaseLocale = RuntimeContext.Provider.BaseLocale
                };
                var eventObj = _accountabiltyFacade.GetEvent(acctSpec);
                var runtimeModel = EventModel.GetRuntimeModel(eventObj, eventModelSpec);

                return Json(new JsonResponseModel(true, runtimeModel));
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
            }
        }

        /// <summary>
        /// To start the event .
        /// </summary>
        /// <param name="id">eventId.</param>
        /// <returns>event view.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.Modify })]
        public ActionResult StartEvent(int id)
        {
            var provider = RuntimeContext.Provider;
            ViewBag.FromTemplateId = id;
            SetBasicPageData();
            ViewBag.PA = true;
            ViewBag.PlaceHolderItems = new JavaScriptSerializer().Serialize(_placeholderFacade.GetPlaceHolderList(provider.Id, RuntimeContext.OperatorId).Where(i => i.IsSystem));
            SetPublisherPageData();
            return View();
        }

        /// <summary>
        /// To end events.
        /// </summary>
        /// <param name="ids">EventIds.</param>
        /// <returns>Json contannig the sucess status and eventIds.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.Modify })]
        [HttpPost]
        public ActionResult EndEvents(List<int> ids)
        {
            if (ids == null || ids.Count == 0)
            {
                _logService.Error(() => IWSResources.PA_Event_Wrong_ArgumentIds_Message);
                return Json(new JsonResponseModel(false, IWSResources.PA_Event_End_Failed_Message));
            }
            var providerId = RuntimeContext.ProviderId;
            var operatorId = RuntimeContext.OperatorId;
            var success = _accountabiltyFacade.EndEvents(providerId, operatorId, ids);
            if (!success)
            {
                _logService.Error(() => IWSResources.PA_Event_End_Failed_Message);
                return Json(new JsonResponseModel(false, IWSResources.PA_Event_End_Failed_Message));
            }

            return Json(new JsonResponseModel(true, ids));
        }


        /// <summary>
        /// To start the event Now.
        /// </summary>
        /// <param name="eventModel">event template Object.</param>
        /// <returns>Json containnig success status and message.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        [HttpPost]
        public JsonResult StartEventNow(TemplateModel eventModel)
        {
            try
            {

                EventLogger.WriteInformation(string.Format("PUBLISH-EVENT-CHECKPOINT-{0} on Time - {1}", 1, DateTime.Now));
                var providerId = RuntimeContext.Provider.Id;
                var operatorId = RuntimeContext.OperatorId;

                IProviderContext prvContext = new ProviderContext();
                prvContext.BaseLocale = RuntimeContext.Provider.BaseLocale;
                prvContext.ProviderId = providerId;


                //Build Accountability Template including AlertBase from input eventModel.
                var acctTemplate = eventModel.ToTemplate(_publishingModelToDomain);
                acctTemplate.ProviderId = providerId;

                _publishingModelToDomain.SetAlertSpec(eventModel.AlertBaseModel, acctTemplate, providerId, AtHocSystem.Local.ConnectDeviceCommonName, operatorId);
                acctTemplate.AlertSpec.Category = Category.GetCategory(eventModel.AlertBaseModel.ScenarioSection.ChannelId);
                acctTemplate.TemplateId = eventModel.Id;
                acctTemplate.AlertSpec.LiveDuration = eventModel.ProcessSectionModel.LiveDuration.ToDuration();

                EventLogger.WriteInformation(string.Format("PUBLISH-EVENT-CHECKPOINT-{0} on Time - {1}", 2, DateTime.Now));
                var ret = _accountabiltyFacade.CreateEvent(operatorId, prvContext, acctTemplate);
                if (ret <= 0)
                {
                    _logService.Error(() => "Failed to Start Accountability Event");
                    return Json(new { Success = false, Messages = IWSResources.PA_Event_Start_Failed_Message });
                }

                return Json(new { Success = true, Data = ret, providerId = providerId });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.PA_Event_Start_Failed_Message });
            }
        }



        /// <summary>
        /// To get the event alerts.
        /// </summary>
        /// <param name="id">eventId.</param>
        /// <returns>Json containnig event alerts list.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public JsonResult GetEventAlerts(List<int> ids)
        {
            var providerId = RuntimeContext.ProviderId;
            var operatorId = RuntimeContext.OperatorId;
            var acctSpec = new AccountabilityEventSpec
            {
                ProviderId = providerId,
                OperatorId = operatorId,
                EventIds = ids,
                IncludeReminderAlertDetails = true,
                IsLoadBaseDetails = false,
                BaseLocale = RuntimeContext.Provider.BaseLocale
            };

            var eventObj = _accountabiltyFacade.GetEvent(acctSpec);

            if (eventObj == null)
            {
                _logService.Error(() => "Failed to Get EventAlerts");
                return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
            }

            var alertPublishRole = _authFacade.HasAccess(RuntimeContext.RefreshedOperatorContext.OperatorAccess, SystemObject.Alert, ActionType.Publish);

            var eventModelSpec = new EventModelSpec();
            eventModelSpec.ProviderBaseLocale = RuntimeContext.Provider.BaseLocale;
            eventModelSpec.ProviderId = providerId;
            eventModelSpec.OperatorId = operatorId;
            eventModelSpec.HasAlertPublisherRole = alertPublishRole;
            eventModelSpec.CurrentSystemDateTime = RuntimeContext.Provider.CurrentSystemTime();

            ActivityModel model = EventModel.GetActivityModel(eventObj, eventModelSpec);

            return Json(new JsonResponseModel(true, model));
        }

        /// <summary>
        /// To get the Organization Heirarchy Breakdown.
        /// </summary>
        /// <param name="id">eventId.</param>
        /// <param name="sessionId">sessionid.</param>
        /// <param name="hierarchyId">hierarchyId.</param>
        /// <returns>Event Org Hierarchy report Json.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public JsonResult GetHeirarchyBreakdown(int id, int sessionId = 0, int hierarchyId = 0)
        {

            var orgReport = EventHierarchyBreakdown(new List<int> { id }, sessionId, hierarchyId);
            return Json(new JsonResponseModel(true, orgReport));
        }

        /// <summary>
        /// Get accountability search results.
        /// </summary>
        /// <param name="spec">Search specs.</param>
        /// <returns>Search results.</returns>
        //[IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        //public JsonResult GetAccountabilitySearchResult(AccountabilitySearchSpec spec)
        //{
        //    var searchResult = _accountabilityFacade.GetAccountabilitySearchResult(spec);
        //    return Json(new JsonResponseModel(true, searchResult));
        //}

        private EventOrganizationReportBuilder EventHierarchyBreakdown(List<int> ids, int sessionId = 0, int hierarchyId = 0)
        {
            List<EventOrganizationReport> eventOrganizationReport;
            var data = new List<EventOrganizationReportEntry>();
            List<EventOrganizationHierarchy> eventOrganizationHierarchy;
            var hierarchyBreadcrumbNodes = new List<EventOrganizationHierarchyEntry>();
            var operatorId = RuntimeContext.OperatorId;
            var isEnterprise = RuntimeContext.Provider.ProviderType() == VPSType.Enterprise;

            var spec = new EventStatusByOrgSpec()
            {
                EventIds = ids,
                ProviderId = RuntimeContext.ProviderId,
                OperatorId = operatorId,
                BaseLocale = RuntimeContext.Provider.BaseLocale,
                SessionId = sessionId,
                HierarchyId = hierarchyId
            };

            _accountabilityFacade.GetEventStatusByOrg(spec, isEnterprise, out eventOrganizationReport, out eventOrganizationHierarchy);

            eventOrganizationReport.ForEach(entry =>
                data.Add(EventOrganizationReportEntry.FromEventOrganizationReport(entry)));

            eventOrganizationHierarchy.ForEach(entry =>
                hierarchyBreadcrumbNodes.Add(EventOrganizationHierarchyEntry.FromEventOrganizationHierarchy(entry)));

            var orgReport = new EventOrganizationReportBuilder()
            {
                SessionId = spec.SessionId,
                Entries = data,
                Hierarchy = hierarchyBreadcrumbNodes
            };
            return orgReport;
        }
        [NonAction]
        private Dictionary<string, object> GetEventUsers(int userSessionId ,int page = 1, int pageSize = 25, string sortBy = "DisplayName", string sortOrder = "ASC", string attributeCSV = null, string[] searchStrings = null,
            string searchFlow = null, int[] eventIds = null, int responseType = -1, int[] hierarchyIds = null, int[] listItemIds = null, string queryCriteria = null, string staticQueryCriteria = null, int[] attributeValueIds = null,
            int[] attributeIds = null, int nproviderId = 0)
        {
            var providerId = nproviderId == 0 ? RuntimeContext.ProviderId : nproviderId;
            var locale = RuntimeContext.Provider.BaseLocale;
            var paDefaultColumnsList = new List<string>
            {
                AttributeCommonNames.StatusId,
                AttributeCommonNames.UpdatedFrom,
                AttributeCommonNames.UpdatedOn,
                AttributeCommonNames.Comments
            };

            
            // Construct Event Criteria for getting the user list
            #region "Event Criteria"

            EventBasedCriteria eventBasedCriteria = null;
            var statusAttributeList = _accountabilityFacade.GetEventStatusAttributeList(eventIds[0], providerId).ToList();
            if (statusAttributeList.Count == 0)
                statusAttributeList.Add(new AccountabilityEventStatusAttribute
                {
                    AttributeId = 0,
                    CommonName = "",
                    SortOrder = 0,
                    ValueId = 0,
                    ValueName = IWSResources.PAEvent_NoStatus
                });
            switch (responseType)
            {
                case -1:
                   // eventBasedCriteria = new EventBasedCriteria(eventIds, EventCriteriaOperator.TARGETED);
                    break;
                case 0:
                    eventBasedCriteria = new EventBasedCriteria(eventIds, EventCriteriaOperator.NORESPONSE);
                    break;
                default:
                    var responseTypes = new List<string>();
                    if (responseType != -2)
                        responseTypes.Add("RESPONSE" + responseType);
                    else
                        responseTypes = statusAttributeList.Select(e => "RESPONSE" + e.SortOrder).ToList();
                    eventBasedCriteria = new EventBasedCriteria(eventIds, EventCriteriaOperator.MULTIPLERESPONSE,
                     responseTypes);
                    break;
            }

            #endregion "Event Criteria"

            // Get User List based on Event and Search Criteria  honoring the user selected columns
            #region "Search Criteria"
            //To get user status and status updated on fields in search result
            //var userFacade = new UserFacade();
            //var statusAttributeId = userFacade.GetStatusAttributeId();
           // var statusValueIds = userFacade.GetStatusValueIds(new[] { AttributeCommonNames.ValidEnabledUsers });
            //var statusCriteria = UserSearchHelper.GetUserStatusCriteria(statusAttributeId, statusValueIds);

            var srchArgs = new UserSearchSession(false, true, false)
            {
                ProviderId = providerId,
                Paging =
                {
                    PageNo = page,
                    UsersPerPage = pageSize,
                    SortColumn = paDefaultColumnsList.Contains(sortBy) ? "PAEVENT:" + sortBy : sortBy,
                    IsAsc = !sortOrder.Equals("DESC", StringComparison.CurrentCultureIgnoreCase)
                },

                TargetCriteria = eventBasedCriteria,
                EventAttributeNames =
                new List<string>(new[]
                    {
                    AttributeCommonNames.EventId, AttributeCommonNames.StatusId, AttributeCommonNames.UpdatedOn,
                    AttributeCommonNames.CreatedOn, AttributeCommonNames.UpdatedFrom, AttributeCommonNames.Comments
                }),
                EventId = eventIds[0],// TODO: fix that
                Options = { GetUsers = true }

            };
            if (searchStrings != null)
            {
                srchArgs.TargetCriteria = srchArgs.TargetCriteria &
                                          UserSearchHelper.GetQuickSearchCriteria(providerId,
                                              RuntimeContext.Provider.BaseLocale, searchStrings);
            }
            // HIERARCHIES TO INCLUDE (NODES : Organizational Hierarchy, Distribution Lists)
            if (hierarchyIds != null)
            {
                srchArgs.TargetCriteria = srchArgs.TargetCriteria &
                                          UserSearchHelper.GetHierarchyCriteria(providerId, locale,
                                             hierarchyIds);
            }

            srchArgs = (UserSearchSession)_userManagerHelper.GetAdvancedCriteria(srchArgs, queryCriteria, staticQueryCriteria, attributeValueIds, attributeIds, listItemIds);

            // LISTS TO INCLUDE (Dynamic Lists, Static Lists, Tree)
            if (listItemIds != null)
            {
                //if (!string.IsNullOrEmpty(queryCriteria) || !string.IsNullOrEmpty(staticQueryCriteria) || searchStrings != null)
                //{
                    srchArgs.TargetCriteria = srchArgs.TargetCriteria & UserSearchHelper.GetListCriteria(providerId, listItemIds);
                //}
                //else
                //{
                //    if (hierarchyIds != null || attributeValueIds != null || attributeIds != null)
                //        srchArgs.TargetCriteria = srchArgs.TargetCriteria | UserSearchHelper.GetListCriteria(providerId, listItemIds);
                //    else
                //        srchArgs.TargetCriteria = srchArgs.TargetCriteria & UserSearchHelper.GetListCriteria(providerId, listItemIds);
                //}

            }

            // Get Attribute List
            var userColumns = _userManagerHelper.GetAttributeList(attributeCSV, UserListType.AccountabilityList);
            var columns = (List<CustomViewColumn>)userColumns["HeaderColumns"];
            srchArgs.DeviceNames = (List<string>)userColumns["DeviceColumns"];
            srchArgs.AttributeNames = (List<string>)userColumns["AttributeColumns"];


            #endregion "Search Criteria"

            // Mapping status and operator values since DB does not return values
            #region "Update Accountability Status and Operator Source"
            //var users = _userFacade.SearchUsersByContext(srchArgs);
            //var srchArgsForSession = new UserSearchSession(false,true,false);
            srchArgs.SessionId = userSessionId;
            var users = _userFacade.SearchUsersBySession(srchArgs);

            // Map Status and Operator
            users.Users.ForEach(eventAttr =>
            {

                if (eventAttr.UserAttributes[AttributeCommonNames.UpdatedFrom].ToUpper() != "OPERATOR")
                    eventAttr.UserAttributes[AttributeCommonNames.UpdatedFrom] = IWSResources.PAEvent_SelfOperator;
                else
                    eventAttr.UserAttributes[AttributeCommonNames.UpdatedFrom] = IWSResources.PAEvent_Operator;

                if (eventAttr.UserAttributes[AttributeCommonNames.StatusId] != "0")
                    eventAttr.UserAttributes[AttributeCommonNames.StatusId] =
                        statusAttributeList.Where(
                            e => e.SortOrder == Convert.ToInt32(eventAttr.UserAttributes[AttributeCommonNames.StatusId]))
                            .Select(e => e.ValueName)
                            .FirstOrDefault();
                else
                {
                    eventAttr.UserAttributes[AttributeCommonNames.StatusId] = string.Empty;
                    eventAttr.UserAttributes[AttributeCommonNames.UpdatedFrom] = string.Empty;
                }

                eventAttr.UserAttributes[AttributeCommonNames.UpdatedOn] =
                    string.IsNullOrEmpty(eventAttr.UserAttributes[AttributeCommonNames.UpdatedOn])
                        ? string.Empty
                        : RuntimeContext.Provider.SystemToVpsDateTimeFormated(
                            Convert.ToDateTime(eventAttr.UserAttributes[AttributeCommonNames.UpdatedOn]));
            });
            #endregion "Update Accountability Status with Operator Source"

            var userDetails = new Dictionary<string, object>
            {
                {"Columns", columns},
                {"Users", users},
                {"ResponseTypes", statusAttributeList}
            };
            return userDetails;
        }

        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public JsonResult GetUserByEvent(int page = 1, int pageSize = 25, string sortBy = "LOGIN_ID",
            string sortOrder = "ASC", // DONE
          string attributeCSV = null,
          string[] searchStrings = null,
          string searchFlow = null,
          int[] eventIds = null,
          int responseType = -1,
            int[] hierarchyIds = null,
             int[] listItemIds = null,
             string queryCriteria = null,
            string staticQueryCriteria = null,
            int[] attributeValueIds = null,
            int[] attributeIds = null,
            int providerId = 0,
            int userSearchSessionId=0
          )
        {
            var accountabilityEventId = 0;
            if (eventIds == null || eventIds.Length < 1)
            {
                var err = new Exception("EventIds cannot be null or empty, while searching for Affected User list");
                EventLogger.WriteError(err);
                return null;
            }
            else
            {
                accountabilityEventId = eventIds[0];
            }
            var operatorContext = new AtHoc.IWS.Business.Context.OperatorContext
            {
                OperatorId = RuntimeContext.OperatorId,
                ProviderId= RuntimeContext.ProviderId
            };

            var providerContext = new ProviderContext();
            providerContext.ProviderId = providerId == 0 ? RuntimeContext.ProviderId : providerId;
            providerContext.BaseLocale = RuntimeContext.Provider.BaseLocale;

            if (userSearchSessionId == 0 || !_userFacade.IsUserSearchSessionValid(userSearchSessionId) || providerId != 0) // in case of sub vps filter - the session id is not valid - so make sure to generate session id for respective sub vps. This is extra overhead in case the SUB VPS user list has to pull in.
            {
                var includeSubVps = providerId == 0;
                userSearchSessionId = _accountabilityFacade.GetUserSessionId(providerContext, operatorContext, eventIds, includeSubVps);
            }


            var userDetails = GetEventUsers(userSearchSessionId, page, pageSize, sortBy, sortOrder, attributeCSV, searchStrings, searchFlow, eventIds, responseType, hierarchyIds, listItemIds, queryCriteria, staticQueryCriteria, attributeValueIds, attributeIds, providerId);
            var columns = (List<CustomViewColumn>)userDetails["Columns"];
            var users = (SessionSearchResult)userDetails["Users"];

            var statusAttributeList = (List<AccountabilityEventStatusAttribute>)userDetails["ResponseTypes"];
            var result =
                Json(
                    new
                    {
                        Columns = columns.OrderBy(e => e.ColumnDisplayOrder).ToList(),
                        Rows = users.Users,
                        TotalCounts = users.SearchResultCount,
                        ResponseTypes = statusAttributeList,
                        UserSearchSessionId = (providerId == 0?userSearchSessionId:0) // for SUB VPS - we should not retain session id. Here session id was generated for SUB VPS and this session id is not valid for enter prise vps.
                    });

            return result;
        }

        /// <summary>
        /// To update the events users status .
        /// </summary>
        /// <param name="userStatusList">user status list.</param>
        /// <returns>Json containing the success status and Message.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        [HttpPost]
        public JsonResult UpdateEventUsersStatus(UserStatusUpdateSpec userStatusList)
        {
            try
            {
                userStatusList.UpdatedFrom = "Operator";

                userStatusList.OperatorId = RuntimeContext.OperatorId;
                userStatusList.UpdatedBy = RuntimeContext.OperatorId;
                if (userStatusList.EventId <= 0)
                    throw new Exception("EventId Cannot be zero");
                var success = _accountabiltyFacade.UpdateUsersStatus(userStatusList, RuntimeContext.ProviderId,
                    RuntimeContext.Provider.BaseLocale);
                return Json(new JsonResponseModel(true, success));
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
            }
        }

        /// <summary>
        /// To get event user status attributes.
        /// </summary>
        /// <param name="id">eventId</param>
        /// <returns>status attribute list.</returns>
        public JsonResult GetEventUserStatus(int id)
        {
            var statusAttribute = _accountabiltyFacade.GetEventStatusAttributeList(id, RuntimeContext.ProviderId);
            return Json(new { Success = true, Data = JsonConvert.SerializeObject(statusAttribute) });
        }

        #endregion

        #region Export

        /// <summary>
        /// To export the event details.
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [FileDownloadCookie]
        [RenderAsPDF(AutoConvert = false)]
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public ActionResult ExportEventDetails(AccountEventExportSpec exportSpec)
        {
            var orgHrchyOptions = exportSpec.OrgHrchyOptions;
            var provider = RuntimeContext.Provider;
            #region setup veiwbags
            var vpsTimeZOne = provider.GetVpsTimeZoneFromId();
            ViewBag.UtcOffsetInMinutes = vpsTimeZOne.BaseUtcOffset.TotalMinutes;
            ViewBag.VPSOffsetFromSystemInMinutes = provider.VPSOffsetFromSystemInMinutes();
            ViewBag.Description = exportSpec.ExportDescription;
            var vpscontactPhone = provider.ContactPhone ?? provider.ContactPhone2;
            ViewBag.GeneratedBy = provider.ProviderName + (!string.IsNullOrEmpty(vpscontactPhone) ? " | " + vpscontactPhone : "");
            ViewBag.GeneratedOn = provider.CurrentSystemTimeToVpsTimeString();
            ViewBag.VpsLogoId = provider.WebImageId;

            var dashboardConfigurationModel = new DashboardConfigurationModel
            {
                Ids = new List<int> { exportSpec.EventId },
                Type = "Event",
                Name = "",
                Description = exportSpec.ExportDescription,
                //StatusAttributeId= self.dashboardConfig.StatusAttributeId
            };

            var dashboardModel = GetDashboardModel(dashboardConfigurationModel);
            var eventRuntimeModel = dashboardModel.RuntimeModel as EventRuntimeModel;
            var eventDetails = eventRuntimeModel.EventModel;

            //var eventDetails = GetEventModel(exportSpec.EventId);
            ViewBag.EventDetails = Json(new JsonResponseModel(true, dashboardModel), JsonRequestBehavior.AllowGet);
            ViewBag.includeSummary = exportSpec.IncludeSummary;
            #endregion
            var isCsv = exportSpec.DownloadFormat == "csv";
            Dictionary<string, object> usersDetails = null;
            EventOrganizationReportBuilder orgHrchy = null;
            AccountPdfHtmlDataModel accountPdfData = null;
            if (exportSpec.IncludeHierarchy)//Include Hierarchy.
            {
                var evnetIdforHrchy = orgHrchyOptions["id"];
                var orgHrchyId = 0;
                var sessionId = 0;
                if (orgHrchyOptions.ContainsKey("hierarchyId"))
                    orgHrchyId = orgHrchyOptions["hierarchyId"];
                 if (orgHrchyOptions.ContainsKey("sessionId"))
                     sessionId = orgHrchyOptions["sessionId"];
                orgHrchy = EventHierarchyBreakdown(ids: new List<int> { evnetIdforHrchy },sessionId:sessionId, hierarchyId: orgHrchyId);
            }
            if (exportSpec.IncludeUsers)//Include Users.
            {
                var uniqueAttributeCsv = "";
                if (exportSpec.UserAttriubuteCsv != null)
                {
                    var uniques = exportSpec.UserAttriubuteCsv.Split(',').Distinct().ToList();
                    uniqueAttributeCsv = string.Join(",", uniques.ToArray());
                }
                var pageSize = 0;
                if (!isCsv)
                    pageSize = 1000;//if not CSV export then display only 1000 user entries.

                var operatorContext = new AtHoc.IWS.Business.Context.OperatorContext
                {
                    OperatorId = RuntimeContext.OperatorId
                };

                var providerContext = new ProviderContext();
                providerContext.ProviderId = RuntimeContext.ProviderId;
                providerContext.BaseLocale = RuntimeContext.Provider.BaseLocale;

                var userSessionId = _accountabilityFacade.GetUserSessionId(providerContext, operatorContext, new[] {exportSpec.EventId});
                usersDetails = GetEventUsers(userSessionId,eventIds: new[] { exportSpec.EventId }, searchStrings: exportSpec.UserSearchOptions,
                   responseType: exportSpec.UserResponseType, pageSize: pageSize, attributeCSV: uniqueAttributeCsv, sortBy: exportSpec.SortUsersBy,
                   sortOrder: exportSpec.UserSortingOrder, queryCriteria: exportSpec.UsrrQueryCriteria, hierarchyIds: exportSpec.UserhierarchyIds, listItemIds: exportSpec.UserlistItemIds, attributeIds: exportSpec.UserattributeIds, nproviderId: exportSpec.ProviderId);
            }
            try
            {
                if (isCsv)
                {
                    //download the CSV .
                    var csvGridData = AccountExportHelper.GetAccountCsvExportData(exportSpec, eventDetails, dashboardModel, usersDetails, orgHrchy);//Get the CSV data.
                    var csvData = new CsvDataModel() { GridData = csvGridData };
                    var fileName = FileNameFormats.GetFormattedFileName(eventDetails.Name, "csv");
                    return File(csvData.GridData, "text/csv", fileName);
                }
                //download the PDF.
                accountPdfData = AccountExportHelper.GetAccountPdfExportData(exportSpec, eventDetails, usersDetails, orgHrchy);//Get the PDF data.
                var eventName = eventDetails.Name.Length > 10 ? eventDetails.Name.Substring(0, 10) : eventDetails.Name;//PDF file name should contain initial 10 characters of the eventName.
                MVCToPDF.ResultFileName = FileNameFormats.GetFormattedFileName(eventName, "pdf");
                
                MVCToPDF.RenderAsPDF((sender, args) =>
                {
                    HtmlToPdf.Options.Cookies.Add(new System.Net.Cookie(Constants.IwsLanguageCookie, CookieEncryption.Protect(provider.BaseLocale)));
                    HtmlToPdf.Options.MinLoadWaitTime = 4000; //put 4 sec delay before converting from html to pdf

                }, null);
                //Make a log entry
                AtHoc.Operators.OperationAuditor.LogAction(RuntimeContext.OperatorId, RuntimeContext.ProviderId, "ACE06", "ACE", eventDetails.Name, exportSpec.EventId, "", "");
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
            }
            return View("Export", accountPdfData);
        }


        #endregion

        /// <summary>
        /// To get the scenarios.
        /// </summary>
        /// <returns>Json containing scenario list.</returns>
        /*public JsonResult GetScenarios()
        {
            try
            {
                var providerId = RuntimeContext.ProviderId;
                var operatorId = RuntimeContext.OperatorId;
                var spec = new ScenarioSearchSpec();
                var scenarioList = _scenarioFacade.GetScenarios(providerId, operatorId, spec);
                var data = scenarioList.Select(s =>
                    new Scenario
                                {
                                    ScenarioId = s.ScenarioId,
                                    Name = s.Name.TruncateText(),
                                    ChannelName = s.ChannelName.TruncateText(),
                                    PublishedOn = s.PublishedOn,
                                    PublishedOnString = RuntimeContext.Provider.SystemToVpsDateTimeFormated(s.PublishedOn),
                                    DateTimeFormat = RuntimeContext.Provider.GetDateTimeFormat(),
                                    NextRecurrence = s.NextRecurrence,
                                    NextRecurrenceString = (s.IsRecurringScenario) ? RuntimeContext.Provider.SystemToVpsDateTimeFormated(s.NextRecurrence) : string.Empty,
                                    UpdatedBy = s.UpdatedBy,
                                    IsQuickPublish = s.IsQuickPublish,
                                    IsReadyForPublish = s.IsReadyForPublish,
                                    IsDefaultforNewAlert = s.IsDefaultforNewAlert,
                                    IsDefaultforNewScenario = s.IsDefaultforNewScenario,
                                    IsSystem = _scenarioFacade.IsSystemScenario(s.CommonName),
                                    IsRecurringScenario = s.IsRecurringScenario,
                                    Description = s.Description.TruncateText(),
                                    AlertTitle = s.AlertTitle.TruncateText(),
                                    AlertBody = s.AlertBody.TruncateText()
                                });

                data = data.Where(s => !s.IsSystem && s.IsReadyForPublish).OrderBy(s => s.Name);
                return Json(new { Success = true, Data = data });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                //returning HTTP status code in addition to the exception message.
                return Json(new { Success = false, Message = ex.Message });
                //return new HttpStatusCodeResult(HttpStatusCode.InternalServerError, ex.Message);
            }
        }*/

        /// <summary>
        /// to get the PA specific resources.
        /// </summary>
        /// <returns>Json containing respurces.</returns>
        [OutputCache(Duration = 0, VaryByParam = "none")]
        public JsonResult GetResource()
        {
            const string resourcePatternForPa = "PAEvent_|Account_|PA_";
            var paResourceSet = IWSResources.ResourceManager.GetResourceSetByPattern(resourcePatternForPa);
            return Json(new { Resources = paResourceSet }, JsonRequestBehavior.AllowGet);
        }

        private void SetBasicPageData()
        {
            var provider = RuntimeContext.Provider;
            var vpsTimeZOne = RuntimeContext.Provider.GetVpsTimeZoneFromId();
            ViewBag.DateFormat = provider.GetDateFormat();
            ViewBag.DateTimeFormat = provider.GetDateTimeFormat();
            ViewBag.VPSTimeZone = vpsTimeZOne;
            ViewBag.UtcOffsetInMinutes = vpsTimeZOne.BaseUtcOffset.TotalMinutes;
            ViewBag.VPSOffsetFromSystemInMinutes = provider.VPSOffsetFromSystemInMinutes();
            ViewBag.SupportsDaylightSavingTime = vpsTimeZOne.SupportsDaylightSavingTime;
            ViewBag.OperatorName = RuntimeContext.Operator.DisplayName;
            ViewBag.CurrentDateTime = provider.CurrentSystemTimeToVps().ToString(CultureInfo.InvariantCulture);
        }

        private void SetPublisherPageData()
        {
            var provider = RuntimeContext.RefreshedProviderContext;
            var user = RuntimeContext.RefreshedOperatorContext;
            ViewBag.IsAffiliate = (provider.ProviderType() == VPSType.Affiliate25 || provider.ProviderType() == VPSType.Affiliate25Template);
            ViewBag.DateFormat = provider.GetDateFormat();
            //Publisher settings
            var publisherSettings = _publishingDomainToModel.GetPublisherSettings(provider);
            ViewBag.PublisherSettings = publisherSettings;
        }

        /// <summary>
        /// To replace the AcctMessagePlaceholders for Preview.
        /// </summary>
        /// <param name="model">accountabilityMessagePlaceholderModel with placeholders.</param>
        /// <returns>accountabilityMessagePlaceholderModel with replaced placeholder values.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityEvent, SystemObject.AccountabilityTemplate }, new[] { ActionType.View })]
        public JsonResult ReplaceAccountabilityMessagePlaceholdersForPreview(AccountabilityMessagePlaceholderModel model)
        {
            try
            {
                var resultModel = new AccountabilityMessagePlaceholderModel();

                var sysPlaceholders = new SystemPlaceholders();
                //get system placeholders
                var systemPlaceholders = _placeholderFacade.GetSystemPlaceHolders(sysPlaceholders, RuntimeContext.Provider.Id, RuntimeContext.OperatorId);

                var eventPlaceholders = _placeholderFacade.GetEventPlaceholders(RuntimeContext.Provider.BaseLocale);
                var accountabilityStartDatePlaceHolderDisplayName =
                    eventPlaceholders.Single(
                        e => e.EventPlaceholderId == AccountabilityEventPlaceHolders.AccountabilityStartTime.ToString())
                        .EventPlaceholderDisplayName;

                var vpsDateTimeString =
                    RuntimeContext.Provider.CurrentSystemTimeToVps().ToString(RuntimeContext.Provider.GetTimeFormat());

                if (model.PlaceholderReplacementModels.HasValue())
                {
                    resultModel.PlaceholderReplacementModels =
                        (from mdl in model.PlaceholderReplacementModels.Where(t => t.Value != null)
                         let value = _accountabilityFacade.ReplacePlaceHoldersForPreviewMessage(mdl.Value, systemPlaceholders, accountabilityStartDatePlaceHolderDisplayName, vpsDateTimeString)
                         select new PlaceholderReplacementModel { FieldId = mdl.FieldId, Value = value, GroupId = mdl.GroupId, IsTextArea = mdl.IsTextArea, Label = mdl.Label, MinLength = mdl.MinLength, MaxLength = mdl.MaxLength }).ToList();
                }

                return Json(new { Model = resultModel, Success = true });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Alert_Placeholder_ReplaceErrorMsg });
            }
        }

        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public ActionResult GetEventContentPreview()
        {
            return PartialView("Publishing/_ContentDetail");
        }

        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public ActionResult GetReviewAndStartDialog()
        {
            ViewBag.PA = true;
            var provider = RuntimeContext.RefreshedProviderContext;
            var publisherSettings = _publishingDomainToModel.GetPublisherSettings(provider);
            ViewBag.PublisherSettings = publisherSettings;
            return PartialView("_ReviewAndStartDialog");
        }


        #region Event Advanced Search
        private object GetAccountabilityEventStatus()
        {
            var excludeStatus = new List<AccountabilityEventStatus> { AccountabilityEventStatus.Deleted, AccountabilityEventStatus.Publishing };

            var resource = new System.Resources.ResourceManager(Constants.resourceAssembly, typeof(IWSResources).Assembly);

            var accountabilityStatus = (from AccountabilityEventStatus status in Enum.GetValues(typeof(AccountabilityEventStatus))
                                        where !excludeStatus.Contains(status)
                                        select new
            {
                Id = status.ToString(),
                Name = resource.GetString(status.GetDescription(), System.Threading.Thread.CurrentThread.CurrentUICulture) ?? status.ToString()
            }).ToList();
            return accountabilityStatus;


        }
        private IEnumerable<KeyValueModel> GetAccountabilityStatusAttributes(string providerId)
        {
            var statusAttributes = new List<KeyValueModel>();
            var customAttributes = _accountabilityFacade.GetStatusAttibutes(RuntimeContext.ProviderId,
            RuntimeContext.Provider.BaseLocale);

            if (string.IsNullOrEmpty(providerId))
            {

                statusAttributes.AddRange(customAttributes.SelectMany(x => x.Item2).Where(attribute => attribute != null).Select(attribute =>
                    new { attribute.AttributeName, attribute.Id }).Distinct().Select(a => new KeyValueModel() { Name = a.AttributeName, Id = a.Id }));

            }
            else
            {
                //filter based on providerId
                var tupleProviderPublishers = customAttributes.FirstOrDefault(x => Convert.ToString(x.Item1) == providerId);
                if (tupleProviderPublishers != null)
                {
                    statusAttributes.AddRange(tupleProviderPublishers.Item2.Where(attribute => attribute != null).Select(attribute =>
                    new KeyValueModel() { Name = attribute.AttributeName, Id = attribute.Id }));
                }
            }
            return statusAttributes;
        }

        private object GetOperatorsWhoPublishedAccountabilityEvent(string providerId)
        {
            var publishers = new List<KeyValueModel>();
            var operatorList = _accountabilityFacade.GetAccountabilityEventPublishers(RuntimeContext.ProviderId);

            if (string.IsNullOrEmpty(providerId))
            {
                publishers.AddRange(operatorList.SelectMany(x => x.Item2).Distinct().OrderBy(x => x.Value).Select(x => new KeyValueModel { Name = x.Value, Id = x.Key }));
            }
            else
            {
                //filter based on providerId
                var tupleProviderPublishers = operatorList.FirstOrDefault(x => Convert.ToString(x.Item1) == providerId);
                if (tupleProviderPublishers != null)
                {
                    publishers.AddRange(tupleProviderPublishers.Item2.OrderBy(x => x.Value).Select(x => new KeyValueModel { Name = x.Value, Id = x.Key }));
                }
            }
            return publishers;
        }

        private IEnumerable<KeyValueModel> GetSeverityList()
        {
            var data = _globalEntityLocaleFacade.GetLocalizedEntity(SettingsHelper.Severities(), RuntimeContext.Provider.BaseLocale)
                               .Select(
                                    p =>
                                        new KeyValueModel
            {
                Id = (int)(Priority)Enum.Parse(typeof(Priority), p.SeverityId),
                Name = p.SeverityName
            }).ToList();
            return data;

        }

        private IEnumerable<KeyValueModel> GetSubOrganizationData()
        {

            var organizations = _accountabilityFacade.GetSubOrganizationsWithNames(RuntimeContext.ProviderId);
            var data = new List<KeyValueModel>();
            data.Add(new KeyValueModel() { Id = RuntimeContext.ProviderId, Name = RuntimeContext.Provider.ProviderName });
            data.AddRange(organizations.Select(org => new KeyValueModel() { Id = org.Key, Name = org.Value }));


            return data;
        }

        [IWSAuthorize(new[] { SystemObject.AccountabilityEvent }, new[] { ActionType.View })]
        public JsonResult PopulateAdvancedSearchFilters(string providerId, string[] filterIds)
        {
            var data = new ArrayList();
            try
            {
                foreach (var filterId in filterIds)
                {
                    if (filterId == "Status")
                    {
                        data.Add(new { FilterId = filterId, Data = GetAccountabilityEventStatus() });
                    }
                    else if (filterId == "StatusAttribute")
                    {
                        data.Add(new { FilterId = filterId, Data = GetAccountabilityStatusAttributes(providerId) });
                    }
                    else if (filterId == "Publisher")
                    {
                        data.Add(new { FilterId = filterId, Data = GetOperatorsWhoPublishedAccountabilityEvent(providerId) });
                    }
                    else if (filterId == "Severity")
                    {
                        data.Add(new { FilterId = filterId, Data = GetSeverityList() });
                    }
                    else if (filterId == "Organization")
                    {
                        data.Add(new { FilterId = filterId, Data = GetSubOrganizationData() });
                    }
                }

                return Json(new { Success = true, Data = data });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Alert_List_Error_Generic });
            }
        }

        #endregion

        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        [HttpPost]
        public JsonResult ChangeEventEndDate(AccountabilityEventEndDate param)
        {
            try
            {
                var dt = ScheduleHelper.GetForm_DateTime(param.NewDate);
                if (dt != null)
                {

                    DateTime endTimeInSys = RuntimeContext.Provider.VpsToSystemTime(dt.Value);//End Date is stored in system time
                    _accountabilityFacade.ChangeEventEndDate(param.EventId, endTimeInSys, RuntimeContext.ProviderId, RuntimeContext.OperatorId);
                    return Json(new { Success = true });
                }

                return Json(new { Success = false });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false });
            }
        }

        #region Instrumentation/Load Purpose Web Api

        public JsonResult TestPublishEvent(int templateId, int providerId, int eventcount = 1)
        {
            List<int> resultEventIds = new List<int>();
            try
            {
                var EnableApiToLoadGeneration = System.Configuration.ConfigurationManager.AppSettings.Get("EnableApiToLoadGeneration");
                bool isEnableApiToLoadGeneration = false;
                if (string.IsNullOrEmpty(EnableApiToLoadGeneration)
                    || !bool.TryParse(EnableApiToLoadGeneration, out isEnableApiToLoadGeneration) || !isEnableApiToLoadGeneration)
                {
                    var message = "Make sure Web.Config key 'EnableApiToLoadGeneration' is set to true for test purpose.";
                    var tempmessage = JsonConvert.SerializeObject(message);
                    return Json(new JsonResponseModel(false, tempmessage), JsonRequestBehavior.AllowGet);
                }
                // var provider = RuntimeContext.Provider;
                //var providerId = provider.Id;

                var operatorId = 1; ;
                //todo return an Event object and not Tempalte
                var template = _accountabiltyFacade.GetTemplate(providerId, operatorId, templateId);

                IList<ISearchCriteria> tempCriteria = new List<ISearchCriteria>();
                tempCriteria = template.AlertSpec.Targeting.TargetingCriteria;
                var eventModel = TemplateModel.FromTemplate(template, true);
                eventModel.AlertBaseModel.Context = PublishingContext.AccountEvent;
                var ph = _placeholderFacade.GetEventPlaceholders("en-US").ToList();
                eventModel.ProcessSectionModel.EventPlaceholderList = ph;
                eventModel.OfficerSectionModel.EventPlaceholderList = ph;

                IProviderContext prvContext = new ProviderContext();
                prvContext.BaseLocale = "en-US";
                prvContext.ProviderId = providerId;


                //Build Accountability Template including AlertBase from input eventModel.
                var acctTemplate = eventModel.ToTemplate(_publishingModelToDomain);
                acctTemplate.ProviderId = providerId;

                _publishingModelToDomain.SetAlertSpec(eventModel.AlertBaseModel, acctTemplate, providerId, AtHocSystem.Local.ConnectDeviceCommonName, operatorId);
                acctTemplate.AlertSpec.Category = Category.GetCategory(eventModel.AlertBaseModel.ScenarioSection.ChannelId);
                acctTemplate.TemplateId = eventModel.Id;
                acctTemplate.AlertSpec.LiveDuration = eventModel.ProcessSectionModel.LiveDuration.ToDuration();
                acctTemplate.AlertSpec.Targeting.TargetingCriteria = tempCriteria;

                for (int i = 0; i < eventcount; i++)
                {
                    var ret = _accountabiltyFacade.CreateEvent(operatorId, prvContext, acctTemplate);
                    resultEventIds.Add(ret);
                }




            }
            catch (Exception ex)
            {

            }
            var serializedData = JsonConvert.SerializeObject(resultEventIds);
            return Json(new JsonResponseModel(true, serializedData), JsonRequestBehavior.AllowGet);
        }

        public ViewResult TestPublishTemplates()
        {


            List<SelectListItem> items = new List<SelectListItem>();
            var providerList = _providerFacade.GetProviderList(1).Where(e => e.PROVIDER_ID > 100);
            foreach (var item in providerList)
            {
                items.Add(new SelectListItem { Text = item.PROVIDER_NAME, Value = item.PROVIDER_ID.ToString() });
            }

            return View(items);
        }

        public JsonResult TestAccountTemplates(int providerId)
        {
            var accttemplate = _accountabiltyFacade.GetTemplates(1, new AccountabilityTemplateSpec { ProviderId = providerId }, false);
            Dictionary<int, string> templates = new Dictionary<int, string>();
            foreach (var t in accttemplate)
            {
                templates.Add(t.TemplateId, t.Name);

            }
            var serializedData = JsonConvert.SerializeObject(accttemplate);
            return Json(new JsonResponseModel(true, serializedData), JsonRequestBehavior.AllowGet);


        }

        public JsonResult TestGetProviderList()
        {

            var accttemplate = _accountabiltyFacade.GetTemplates(1, new AccountabilityTemplateSpec { CommonName = "INCIDENT-PREVENTION" }, false);
            var dictByProvider = accttemplate.ToDictionary(e => e.ProviderId);
            List<Object> items = new List<Object>();
            var providerList = _providerFacade.GetProviderList(1).Where(e => e.PROVIDER_ID > 100);
            foreach (var item in providerList)
            {

                if (dictByProvider.ContainsKey(item.PROVIDER_ID))
                {
                    var temp = dictByProvider[item.PROVIDER_ID];
                    items.Add(new { ProviderId = item.PROVIDER_ID, ProviderName = item.PROVIDER_NAME, TemplateId = temp.TemplateId, TemplateName = temp.Name });
                }


            }
            var serializedData = JsonConvert.SerializeObject(items);
            return Json(new JsonResponseModel(true, items), JsonRequestBehavior.AllowGet);
        }
        #endregion

    }
}