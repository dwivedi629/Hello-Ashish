﻿using AtHoc.d911.Model.Organization;
using AtHoc.Global.Resources;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Web;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Organization;
using AtHoc.IWS.Web.Filters;
using AtHoc.IWS.Web.Helpers;
using AtHoc.IWS.Web.Models.Organization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI;


namespace AtHoc.IWS.Web.Controllers
{
    [IWSAuthorize(new[] { SystemObject.Organization }, new[] { ActionType.View })]
	public class OrganizationController : Infrastructure.Web.Mvc.Controller
    {
        private readonly IOrganizationFacade _organizationFacade;

        public OrganizationController(IOrganizationFacade organizationFacade)
        {
            _organizationFacade = organizationFacade;
        }
        public ActionResult Index(bool isExistingConnections = true, bool openNotificationsOnStartup = false, string showOrganizationIdOnStartup = null)
        {
            try
            {
                ViewBag.TopicToHighlight = MenuTopicsId.organizations; 

               
                ConnectivityStatus connectivityStatus = _organizationFacade.GetConnectivityStatus(RuntimeContext.ProviderId);
                if (connectivityStatus == ConnectivityStatus.NotConfigured)
                {
                    ViewBag.ConnectivityMessage = IWSResources.Organization_NotConfigured_ErrorMsg;
                    return View("_NotConnectedMessage");
                }
                if (connectivityStatus == ConnectivityStatus.DeviceNotConfigured)
                {
                    ViewBag.ConnectivityMessage = IWSResources.Organization_DeviceNotConfigured_ErrorMsg;
                    return View("_NotConnectedMessage");
                }
                if (connectivityStatus == ConnectivityStatus.NotListed)
                {
                    ViewBag.ConnectivityMessage = IWSResources.Organization_NotListed_ErrorMsg;
                    return View("_NotConnectedMessage");
                }

                var selfOrgGuid = _organizationFacade.GetSelfOrganizationGuid(RuntimeContext.ProviderId);

                //Some time IWS cache and PSS are not syched,
                if (selfOrgGuid == null)
                {
                    ViewBag.ConnectivityMessage = IWSResources.Organization_NotListed_ErrorMsg;
                    return View("_NotConnectedMessage");
                }
                var orgTypes = _organizationFacade.GetOrganizationSectors(RuntimeContext.ProviderId);
                var sortedOrgTypes = orgTypes.OrderBy(item => item.Name);
                                                
                ViewBag.Title = isExistingConnections ? IWSResources.NavBar_Organization_New_Connection : IWSResources.NavBar_Organization_Manager;
                ViewBag.SelfOrgGuid = selfOrgGuid;
                ViewBag.OrganizationTypes = sortedOrgTypes;
                ViewBag.IsExistingConnectionView = isExistingConnections;
                ViewBag.OpenNotificationsOnStartup = openNotificationsOnStartup;
                ViewBag.ShowOrganizationIdOnStartup = showOrganizationIdOnStartup;
                return View("Index");
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
            }
            //If error then only execution pointer will reach to this point, and then redirect to Error Page.
            return RedirectToAction("ShowWarningMessage", "Error");
        }
        
        public ActionResult Connections()
        {
            return Index();
        }

        public ActionResult Invitations()
        {
            return Index(true, true);
        }

        public ActionResult Directory()
        {
            return Index(false);
        }

        [IWSAuthorize(new[] { SystemObject.Organization }, new[] { ActionType.View })]
        public ActionResult GetOrganizations(OrganizatioSearchParameters organizatioSearchParameters)
        {
            try
            {
                List<string> additionalOrgIds = new List<string>();
                if (organizatioSearchParameters.LastVisibleOrganizationId != null)
                {
                    additionalOrgIds.Add(organizatioSearchParameters.LastVisibleOrganizationId);
                }
                var model = OrganizationHelper.GetOrganizationsDataModel(organizatioSearchParameters, organizatioSearchParameters.IsExistingConnectionView, true, additionalOrgIds);
                return Json(model);
            }
            catch (Exception ex)
            {
                LogService.Current.Error(()=>ex);
                return Json(new { Success = false, Message = IWSResources.Organization_LoadOrganization_ErrorMsg });
            }
        }


        [IWSAuthorize(new[] { SystemObject.Organization }, new[] { ActionType.View })]
        public ActionResult GetSentInvitation(SentInvitationParameters sendInvitationParameters)
        {
            try
            {
                var model = OrganizationHelper.GetSentInviationDataModel(sendInvitationParameters);
                return Json(model);
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Message = IWSResources.Organization_SentInvitation_LoadInviation_ErrorMsg });
            }
        }
       


         [IWSAuthorize(new[] { SystemObject.Organization }, new[] { ActionType.View })]
        public ActionResult GetOrganizationTypes()
        {
            try
            {
                
                var orgTypes = _organizationFacade.GetOrganizationSectors(RuntimeContext.ProviderId);
                var sortedOrgTypes = orgTypes.OrderBy(item => item.Name);
                return Json(new { OrganizationTypes = sortedOrgTypes });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Message = IWSResources.Organization_GetVisibilityTypes_Error_Message });
            }
        }

         [IWSAuthorize(new[] { SystemObject.Organization }, new[] { ActionType.View })]
        public ActionResult GetOrganizationVisibility()
        {
            try
            {
                
                var orgVisibility = _organizationFacade.GetOrganizationVisibility(RuntimeContext.ProviderId);
                return Json(new { OrganizationVisibility = orgVisibility });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Message = IWSResources.Organization_GetVisibility_Error_Message });
            }
        }
        
        [IWSAuthorize(new[] { SystemObject.Organization }, new[] { ActionType.Modify })]
        public ActionResult SetOrganizationVisibility(bool isVisibleToAll, List<int> organizationTypeIds )
        {
            try
            {
                bool result = _organizationFacade.SetOrganizationVisibility(RuntimeContext.ProviderId, isVisibleToAll, organizationTypeIds);
                return Json(new { Success = result});
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Message = IWSResources.Organization_SetVisibility_Error_Message });
            }
        }

        [IWSAuthorize(new[] { SystemObject.Organization }, new[] { ActionType.View })]
        public ActionResult GetOrganizationDetail(string id)
        {
            try
            {
                
                var org = _organizationFacade.GetOrganizationById(RuntimeContext.ProviderId, id);                                
                if (org == null)
                {
                    LogService.Current.Error(() => string.Format("failed to load organization by id : {0}", id));
                    return Json(new { Success = false, Message = IWSResources.Organization_LoadOrganization_ErrorMsg });                
                }

                var res = new
                {
                    Success = true,
                    Data = new OrganizationModel(org)
                };
                
                return Json(res);
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Message = IWSResources.Organization_LoadOrganization_ErrorMsg });                
            }                       
        }

        [IWSAuthorize(new[] {SystemObject.Organization}, new[] {ActionType.Modify})]
        public ActionResult Invite(string otherOrganizationId, bool send, bool receive, string message)
        {

            try
            {
               
                var direction = send && receive ? AgreementDirection.Both : (send ? AgreementDirection.Send : AgreementDirection.Receive);
                var orgAgreementId = _organizationFacade.Invite(RuntimeContext.ProviderId, otherOrganizationId, direction, message);
                return Json(new { Success = true, agreementId = orgAgreementId });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Message = IWSResources.Organization_UpdateAgreement_ErrorMsg });                
            }
        }
       
        [IWSAuthorize(new[] { SystemObject.Organization }, new[] { ActionType.Modify })]
        public ActionResult UpdateInvitation(int id, int action)
        {
            try
            {
                var agreementAction = (InvitationAction)action;
                
                var res = _organizationFacade.UpdateInvitation(RuntimeContext.ProviderId, id, agreementAction);
                bool ret = res.IsSuccess;
                if (!ret)
                {
                    LogService.Current.Error(() => "Failed to update invitation");
                    return Json(new { Success = false, Message = "Failed to update invitation" });
                }                                              
                return Json(new { Success = true });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Message = IWSResources.Organization_UpdateAgreement_ErrorMsg });
            }
        }

        [IWSAuthorize(new[] { SystemObject.Organization }, new[] { ActionType.Modify })]        
        public ActionResult CancelAgreement(int id)
        {
            try
            {                
               
                bool ret = _organizationFacade.CancelAgreement(RuntimeContext.ProviderId, id);
                if (!ret)
                {
                    LogService.Current.Error(() => "Failed to cancel agreement");
                    return Json(new { Success = false, Message = "Failed to cancel agreement" });
                }
                return Json(new { Success = true });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Message = IWSResources.Organization_UpdateAgreement_ErrorMsg });
            }
        }

        [IWSAuthorize(new[] { SystemObject.Organization }, new[] { ActionType.Modify })]
        public ActionResult MarkMessageAsRead(List<int> ids)
        {
            try
            {                
               
                _organizationFacade.MarkMessageAsRead(RuntimeContext.ProviderId, ids);
                return Json(new { Success = true });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Message = IWSResources.Organization_UpdateAgreement_ErrorMsg });                
            }
        }        

        [IWSAuthorize(new[] {SystemObject.Organization}, new[] {ActionType.View})]
        [OutputCache(Duration = 7 * 24 * 3600 /*week*/, VaryByParam = "id;version", Location = OutputCacheLocation.Client)]
        public ActionResult Logo(string id, string version = "")
        {
            if (id == "00000000-0000-0000-0000-000000000001")
            {
                return Redirect(Url.Cdn("images/athoc.png"));
            }
            
            Response.Cache.SetExpires(DateTime.UtcNow + TimeSpan.FromDays(7));
            Response.Cache.SetCacheability(HttpCacheability.Public); 
            Response.Cache.SetProxyMaxAge(TimeSpan.FromDays(7));
            OrganizationLogo logo = _organizationFacade.GetOrganizationLogo(RuntimeContext.ProviderId, id);
            if (logo == null || logo.Logo == null)
            {                                
                return Redirect(Url.Cdn("images/default-org-60.png"));                
            }
                                   
            return File(logo.Logo, "image/png");
        }

        [IWSAuthorize(new[] { SystemObject.Organization }, new[] { ActionType.Modify })]
        public ActionResult InviteNewOrganization(InviteNewOrganizationParams inviteForm)
        {
            try
            {
               

                inviteForm.InviterName = RuntimeContext.Operator.DisplayName;
                if (!string.IsNullOrEmpty(inviteForm.CustomMessage))
                {
                    inviteForm.CustomMessage = inviteForm.CustomMessage.Trim();
                }
                inviteForm.Locale = RuntimeContext.Provider.BaseLocale;
                Response<bool> result = _organizationFacade.InviteNewOrganization(RuntimeContext.ProviderId, inviteForm);
                if (!result.IsSuccess)
                {
                    LogService.Current.Error(() => string.Format("Failed to invite Organization {0}", inviteForm.InviteeOrganizationName));
                    return Json(new {Success = false, Message = result.ErrorId});
                }
                return Json(new { Success = true});
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Message = IWSResources.Organization_Invite_Org_Error });
            }
        }

        public ActionResult Test()
        {
            
            _organizationFacade.ExecuteJob();
            return Json(new {Success = true});
        }

        public class OrganizatioSearchParameters : OrganizationSpec
        {            
            //public bool Filtered { get; set; }
            public bool IsExistingConnectionView { get; set; }
            public string LastVisibleOrganizationId { get; set; }
        }

    }
}
