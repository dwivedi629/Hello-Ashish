﻿using AtHoc.Infrastructure.Encryption;
using AtHoc.IWS.Business.Domain.Devices;
using AtHoc.IWS.Business.Domain.Devices.Spec;
using AtHoc.IWS.Business.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AtHoc.Devices;
using AtHoc.IWS.Business.Context;
using System.Xml.Linq;
using System.Web.UI.WebControls;
using System.Xml.Xsl;
using System.Xml;
using System.IO;
using System.Xml.XPath;
using System.Reflection;
using System.Collections;
using AtHoc.IWS.Business.Domain.GlobalAlertExtension.Impl;
using AtHoc.IWS.Web.Helpers;
using AtHoc.Systems;
using System.Web.UI;
using AtHoc.IWS.Web.Models.Shared;
using AtHoc.IWS.Web.Models.Publishing;
using AtHoc.IWS.Business.Domain.GlobalAlertExtension;
using AtHoc.IWS.Business.Domain.GlobalAlertExtension.Interfaces;
using System.Web.SessionState;
using System.Xml.Serialization;

namespace AtHoc.IWS.Web.Controllers
{
    [SessionState(SessionStateBehavior.ReadOnly)]
    public class SharedController : Controller
    {
        private readonly IDeviceFacade _deviceFacade;
        private readonly IDeviceGroupFacade _deviceGroupFacade;
        private readonly IGlobalAlertExtensionFacade _globalAlertExtensionFacade;
        private readonly IDeviceOptionCache _deviceOptionCache;

        public SharedController(IDeviceFacade deviceFacade, IDeviceGroupFacade deviceGroupFacade, IGlobalAlertExtensionFacade globalAlertExtensionFacade, IDeviceOptionCache deviceOptionCache)
        {
            _deviceFacade = deviceFacade;
            _deviceGroupFacade = deviceGroupFacade;
            _globalAlertExtensionFacade = globalAlertExtensionFacade;
            _deviceOptionCache = deviceOptionCache;
        }

        // GET: Shared
        public ActionResult DisplayDeviceOptions(List<AtHoc.IWS.Web.Models.Publishing.Device> devices, List<DeviceGroupPresetOptions> presetOptions = null, String type = "")
        {
            //If device option cache is enabled get it from cache
            var EnableDeviceOptionCache = RuntimeContext.Provider.FeatureMatrix.EnableDeviceOptionCache;

            // Get the AlertExtension data from the cache based on locale
            var locale = RuntimeContext.Provider.BaseLocale;
            var localeAlertExtensions = _globalAlertExtensionFacade.GetLocalizedGlobalAlertExtensionList(locale);

            var dm = new DeviceManager(RuntimeContext.Provider.Id);
            var providerDevices = dm.GetDevices(true, false);

            var deviceGroup = new List<DeviceGroupModel>();

            if (devices == null || devices.Count < 1)
                return Json(new { DeviceOptions = deviceGroup });

            foreach (var dg in devices.GroupBy(d => d.GroupId))
            {
                bool selected = false;

                foreach (var device in dg)
                {
                    if (device.Selected)
                    {
                        selected = true;
                        break;
                    }

                }

                var groupId = dg.First().GroupId;
                if (groupId != null)
                {
                    var group = new DeviceGroupModel
                    {
                        Id = groupId.Value,
                        Name = dg.First().GroupName,
                        Selected = selected,
                        DeviceOptionLoaded = selected
                    };

                    //retrueve html
                    if (selected)
                    {
                        var devMT = providerDevices.First(a => a.Group.Id == @group.Id); //dm.GetDevice(group.DeviceId);

                        //Assigned locale based alert extension template to group extension for further processing.
                        var alertExtension = localeAlertExtensions.Where(x => x.ID == devMT.Group.ExtensionID).FirstOrDefault();

                        devMT.Group.Extension = alertExtension;

                        if (alertExtension != null && alertExtension.Definition != null)
                        {
                            var deviceOptionHtml = string.Empty;
                            if (EnableDeviceOptionCache)
                            {
                                deviceOptionHtml = _deviceOptionCache.Get(RuntimeContext.ProviderId, group.Id, locale);
                            }

                            if (string.IsNullOrWhiteSpace(deviceOptionHtml))
                            {
                                var definition = XElement.Parse(devMT.Group.Extension.Definition.OuterXml);

                                if (presetOptions != null && !EnableDeviceOptionCache)
                                {
                                    XElement rawData = null;
                                    // retrieve raw data, if it exists //
                                    if (presetOptions.Count(s => s.Id == devMT.Group.Extension.ID) != 0)
                                    {
                                        //Decoded twice for IWS-12457
                                        rawData = XElement.Parse(HttpUtility.HtmlDecode(HttpUtility.HtmlDecode(presetOptions.First(s => s.Id == devMT.Group.Extension.ID).selection)));
                                    }
                                    if (rawData != null)
                                    {
                                        definition.Add(rawData);
                                    }
                                }

                                deviceOptionHtml = getXSLTResult(definition, devMT, type);

                                if (EnableDeviceOptionCache)
                                {
                                    _deviceOptionCache.Set(RuntimeContext.ProviderId, group.Id, locale, deviceOptionHtml);
                                }
                            }

                            @group.HasExtension = true;
                            @group.HTML = deviceOptionHtml;
                            @group.ElementList = devMT.Group.Extension.FormElementNameList;
                        }
                    }
                    else
                    {
                        @group.HasExtension = false;
                    }
                    //optionList.Add(new DeviceOptionModel { HTML = result, Name = dev.Group.Name, Selected = true, Id = dev.Group.Id, ElementList = dev.Group.Extension.FormElementNameList });
                    deviceGroup.Add(@group);
                }
            }

            var presetSelectionList = new List<DeviceOptionPreset>();
            if (EnableDeviceOptionCache && presetOptions != null)
            {
                foreach (var presetOption in presetOptions)
                {
                    try
                    {
                        if (!string.IsNullOrWhiteSpace(presetOption.selection))
                        {
                            var xmlString = HttpUtility.HtmlDecode(HttpUtility.HtmlDecode(presetOption.selection));
                            using (var sr = new StringReader(xmlString))
                            {
                                var serializer = new XmlSerializer(typeof(DeviceOptionPreset));
                                var deviceOptionPreset = (DeviceOptionPreset)serializer.Deserialize(sr);
                                deviceOptionPreset.Id = presetOption.Id;
                                deviceOptionPreset.GroupId = presetOption.GroupId;
                                presetSelectionList.Add(deviceOptionPreset);
                            }
                        }
                    }
                    catch { }
                }
            }

            return Json(new { DeviceOptions = deviceGroup, DeviceOptionPreset = presetSelectionList });
        }

        public ActionResult GetMoreDeviceGroupOptions(List<int> deviceGroupIds, String type = "")
        {
            var EnableDeviceOptionCache = RuntimeContext.Provider.FeatureMatrix.EnableDeviceOptionCache;

            // Get the AlertExtension data from the cache based on locale
            var locale = RuntimeContext.Provider.BaseLocale;
            var localeAlertExtensions = _globalAlertExtensionFacade.GetLocalizedGlobalAlertExtensionList(locale);

            var dm = new DeviceManager(RuntimeContext.Provider.Id);
            var providerDevices = dm.GetDevices(true, false);

            List<DeviceGroupModel> deviceGroup = new List<DeviceGroupModel>();

            foreach (int deviceGroupId in deviceGroupIds)
            {

                AtHoc.Devices.Device devMT = providerDevices.Where(a => a.Group.Id == deviceGroupId).First(); //dm.GetDevice(group.DeviceId);

                var group = new DeviceGroupModel
                {
                    Id = deviceGroupId,
                    Selected = true,
                    HTML = "",
                    Name = devMT.Group.Name
                };

                //Assigned locale based alert extension template to group extension for further processing.
                var alertExtension = localeAlertExtensions.Where(x => x.ID == devMT.Group.ExtensionID).FirstOrDefault();
                devMT.Group.Extension = alertExtension;

                if (alertExtension != null && alertExtension.Definition != null)
                {
                    var deviceOptionHtml = string.Empty;
                    if(EnableDeviceOptionCache)
                    {
                        deviceOptionHtml = _deviceOptionCache.Get(RuntimeContext.ProviderId, group.Id, locale);
                    }

                    if (string.IsNullOrWhiteSpace(deviceOptionHtml))
                    {
                        var definition = XElement.Parse(devMT.Group.Extension.Definition.OuterXml);
                        deviceOptionHtml = getXSLTResult(definition, devMT, type);

                        if(EnableDeviceOptionCache)
                        {
                            _deviceOptionCache.Set(RuntimeContext.ProviderId, group.Id, locale, deviceOptionHtml);
                        }
                    }

                    group.HasExtension = true;
                    group.ElementList = devMT.Group.Extension.FormElementNameList;
                    group.HTML = deviceOptionHtml;
                    group.DeviceOptionLoaded = true;
                }
                else
                {
                    group.HasExtension = false;
                }
                deviceGroup.Add(group);
            }
            return Json(new { deviceGroupOptions = deviceGroup });
        }

        public string getXSLTResult(XElement definition, AtHoc.Devices.Device dev, string type)
        {
            string result = "";
            using (Xml UEX = new Xml())
            {
                UEX.DocumentContent = definition.ToString();
                //UEX.TransformSource = @"C:\CustomUIDefinitionMod.xslt";// _DeviceGroup.Extension.TransformPath;
                UEX.Transform = dev.Group.Extension.Transform;
                UEX.TransformArgumentList = new System.Xml.Xsl.XsltArgumentList();
                UEX.TransformArgumentList.AddExtensionObject("athoc-alert-extension", new CustomOptionsExtension(dev.Group.Id));
                UEX.TransformArgumentList.AddParam("ExtensionCommonName", "", dev.Group.Extension.CommonName);
                UEX.TransformArgumentList.AddParam("DeviceGroupID", "", dev.Group.Id.ToString());
                UEX.TransformArgumentList.AddParam("DeviceGroupName", "", dev.Group.Name);
                UEX.TransformArgumentList.AddParam("VirtualSystem", "", RuntimeContext.Provider.Id);
                UEX.TransformArgumentList.AddParam("DeviceType", "", type);

                var cookie = Request.Cookies[Business.Configurations.Constants.IwsLanguageCookie];
                if (cookie != null)
                {
                    var locale = CookieEncryption.UnProtect(cookie.Value);
                    UEX.TransformArgumentList.AddParam("Locale", "", locale);
                }
                //UserExperiencePanel.Controls.Add(UEX);

                StringWriter stringWriter = new StringWriter();
                using (HtmlTextWriter writer = new HtmlTextWriter(stringWriter))
                {
                    UEX.RenderControl(writer);
                }
                result = stringWriter.ToString();

            }
            return result;
        }
    }
}