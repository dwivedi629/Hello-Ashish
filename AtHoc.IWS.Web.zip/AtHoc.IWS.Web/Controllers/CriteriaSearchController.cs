﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Serialization;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.Devices;
using AtHoc.IWS.Business.Domain.Devices.Spec;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Users;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.IWS.Business.Domain.VirtualSystem.Spec;
using AtHoc.IWS.Web.Filters;
using AtHoc.IWS.Web.Helpers;
using AtHoc.IWS.Web.Models.UserManager;
using AtHoc.Global.Resources;
using EO.Internal;
using Controller = AtHoc.Infrastructure.Web.Mvc.Controller;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.IWS.Business.Domain.VirtualSystem;
using AtHoc.IWS.Business;
using System.Globalization;
using AtHoc.IWS.Business.Domain.RuleModel;
using AtHoc.IWS.Business.Domain.RuleModel.Impl;
using AtHoc.IWS.Web.Configurations.Constants;
using AtHoc.Global.Resources.Entities;
using AtHoc.Global.Resources.Implementations;
using System.Web.SessionState;
using AtHoc.IWS.Business.Domain.Targeting.Model;
using AtHoc.IWS.Business.Domain.Targeting;
using AtHoc.IWS.Business.Domain.Targeting.Spec;
using HierarchySpec = AtHoc.IWS.Business.Domain.Users.Spec.HierarchySpec;

namespace AtHoc.IWS.Web.Controllers
{
    [SessionState(SessionStateBehavior.ReadOnly)]
    [IWSAuthorize(new SystemObject[] { SystemObject.EndUsers, SystemObject.DistributionLists, SystemObject.Alert, SystemObject.AccountabilityEvent, SystemObject.AccountabilityTemplate }, new ActionType[] { ActionType.View, ActionType.View, ActionType.View, ActionType.View, ActionType.View })]
    public partial class CriteriaSearchController : Controller
    {
        private readonly ICustomAttributeCache _customAttributeCache;
        private readonly IUserFacade _userFacade;
        private readonly ICustomAttributeFacade customAttributeFacade;
        private readonly IDeviceFacade deviceFacade;
        private readonly IOperatorFacade operatorFacade;
        private readonly IPublishingFacade publishingFacade;
        private readonly IOperatorDetailsFacade _operatorDetailsFacade;
        private IVirtualSystemFacade _virtualSystemFacade;
        private IRuleFacade _ruleFacade;
        private readonly AtHoc.IWS.Business.Domain.Settings.IHierarchyDefinitionFacade _hierarchyFacade;
        private readonly ITargetingTreeFacade _targetingTreeFacade;
        private readonly IProviderFacade _providerFacade;


        public CriteriaSearchController(ICustomAttributeCache customAttributeCache,
                                    IUserFacade userFacade,
                                    ICustomAttributeFacade customAttributeFacade,
                                    IDeviceFacade deviceFacade,
                                    IOperatorFacade operatorFacade,
                                    IPublishingFacade publishingFacade,
                                    IOperatorDetailsFacade operatorDetailsFacade,
                                    IVirtualSystemFacade virtualSystemFacade,
                                    IRuleFacade ruleFacade,
                                    AtHoc.IWS.Business.Domain.Settings.IHierarchyDefinitionFacade hierarchyFacade, 
                                    ITargetingTreeFacade targetingTreeFacade,
            IProviderFacade providerFacade
            )
        {
            this._customAttributeCache = customAttributeCache;
            this._userFacade = userFacade;
            this.customAttributeFacade = customAttributeFacade;
            this.deviceFacade = deviceFacade;
            this.operatorFacade = operatorFacade;
            this.publishingFacade = publishingFacade;
            this._operatorDetailsFacade = operatorDetailsFacade;
            this._virtualSystemFacade = virtualSystemFacade;
            _ruleFacade = ruleFacade;
            _hierarchyFacade = hierarchyFacade; 
            _targetingTreeFacade = targetingTreeFacade;
            _providerFacade = providerFacade;
        }

        [HttpPost]
        public ActionResult GetGroupSearchNodes(string preselectedItems,
                                                int parentId = -1,
                                                bool selected = false,
                                                int rootId = 0,
                                                string groupType = "LISTITEM",
                                                string status = "",
                                                string preselections = "[]",
                                                bool multiselect = false,
                                                bool includeLists = true,
                                                bool removeEmptyFolder = false,
                                                bool hideMassDevices = false)
        {
            var preselectedNodesToReturn = new List<PreselectedGroupNode>(); //if not is preselected, but is not on the popupon upon launching (because preselected node is not at the root level in this case), return complete object to the front end so it can be added to the selections array and pills can be made

            var currentNodes = (parentId.Equals(-1))
                ? GetGroupSelectorRootNodes(ref preselectedNodesToReturn, hideMassDevices, preselections)
                : GetGroupSelectorChildrenNodes(parentId, rootId, EnumUtils<GroupType>.Parse(groupType), status, preselections, multiselect, includeLists, removeEmptyFolder, hideMassDevices);

            return Json(new { Nodes = currentNodes, PreselectedSelectionsToAdd = preselectedNodesToReturn });
        }

        private IEnumerable<GroupSearchNode> GetGroupSelectorRootNodes(ref List<PreselectedGroupNode> preselectedNodesToReturn, bool hideMassDevices, string preselections = "[]")
        {
            var provider = RuntimeContext.Provider;

            var showORGHierarchy = false;
            var orgHierarchy =
                _userFacade.GetHierarchyBySpec(new HierarchySpec { ProviderId = provider.Id, AvailableForLists = false, BaseLocale = provider.BaseLocale }).Select(
                    x =>
                        new GroupSearchNode
                        {
                            Name = x.Name,
                            IsCheckbox = true,
                            ShowCheckbox = true,
                            HasChildren = true,
                            Id = x.Id,
                            Status = CheckboxStatus.NO.ToString(),
                            CurrentGroupType = GroupType.HIERARCHY.ToString(),
                            RootId = x.Id,
                            Lineage = x.PathDelimiter
                        }).ToList();

            //see if org hierarchy is configured to show from vps setup
            var providerAttributes = CustomAttributesHelper.GetProviderAttributes(_customAttributeCache, RuntimeContext.ProviderId,RuntimeContext.Provider.BaseLocale, hideMassDevices);
            var customAttributeForOrgHierarchy = providerAttributes.Where(x => orgHierarchy.Count > 0 && x.HierarchyId == orgHierarchy.FirstOrDefault().Id &&
                x.Targeting != null);

            if (customAttributeForOrgHierarchy.Count() != 0)
            {
                showORGHierarchy = true;
                orgHierarchy.FirstOrDefault().DisplayOrder = (int)customAttributeForOrgHierarchy.FirstOrDefault().Targeting.DisplayOrder;
            }

            var showDLHierarchy = false;
            var dlListTargetingInfo = customAttributeFacade.GetCustomAttributeTargetingBySpec(new CustomAttributeTargetingSpec { ProviderId = provider.Id, TargetingEntityType = TargetingEntityType.DistributionList });
            var dlHierarchy = Enumerable.Empty<GroupSearchNode>();
            if (dlListTargetingInfo.Count() != 0)
            {

                dlHierarchy =
                    _userFacade.GetHierarchyBySpec(new HierarchySpec
                    {
                        ProviderId = provider.Id,
                        AvailableForLists = true,
                        HierarchyType = HierarchyType.ORG,
                        BaseLocale = provider.BaseLocale
                    }).Select(
                        x =>
                            new GroupSearchNode
                            {
                                Name = x.Name,
                                IsCheckbox = true,
                                ShowCheckbox = true,
                                HasChildren = true,
                                Id = x.Id,
                                Status = CheckboxStatus.NO.ToString(),
                                CurrentGroupType = GroupType.HIERARCHY.ToString(),
                                RootId = x.Id,
                                Lineage = x.PathDelimiter,
                                DisplayOrder = -1
                            });


                //check to see any distribution list exists on the vps
                var dlOnVPS = publishingFacade.GetDistributionLists(new DistributionListSpec { ProviderId = provider.Id });
                if (dlOnVPS.Count() != 0) //if there is no dl on the vps don't show dl hierarchy 
                {
                    var systemUser = operatorFacade.GetUser(new SystemUserSpec { ProviderId = provider.Id, OperatorId = RuntimeContext.Operator.Id });

                    if (systemUser.IsTargetableAccessListUnrestricted() || systemUser.IsManagableAccessListUnrestricted())
                    {
                        showDLHierarchy = true;
                    }
                    else if (systemUser.GetTargetableAccessList().Count() != 0 || systemUser.GetManagableAccessList().Count() != 0)
                    {
                        showDLHierarchy = true;

                    }
                }

            }

            var targetableCustomAttributes =
                providerAttributes.Where(x => x.Targeting != null && x.AttributeTypeId != CustomAttributeDataType.Path).OrderBy(x => x.Targeting.DisplayOrder).Select(
                    x =>
                        new GroupSearchNode
                        {
                            Name = x.AttributeName,
                            IsCheckbox = (x.AttributeTypeId.Equals(CustomAttributeDataType.Checkbox)) ? false : true,
                            ShowCheckbox = (x.AttributeTypeId.Equals(CustomAttributeDataType.Checkbox)) ? false : true,
                            HasChildren = (x.Values.Count() != 0),
                            Id = x.Id,
                            Status = CheckboxStatus.NO.ToString(),
                            CurrentGroupType = GroupType.ATTRIBUTE.ToString(),
                            RootId = x.Id,
                            Lineage = "",
                            DisplayOrder = (int)x.Targeting.DisplayOrder
                        });


            //need to refactor this after talking w alex b
            var resultNodes = (showDLHierarchy) ? dlHierarchy.Union(targetableCustomAttributes).Union((showORGHierarchy) ? orgHierarchy : Enumerable.Empty<GroupSearchNode>()) : targetableCustomAttributes.Union((showORGHierarchy) ? orgHierarchy : Enumerable.Empty<GroupSearchNode>());
            List<GroupSearchNode> nodesToReturn = resultNodes.ToList();

            preselectedNodesToReturn = applyPreselection(preselections, ref nodesToReturn, true);

            return nodesToReturn.OrderBy(x => x.DisplayOrder);
        }

        private IEnumerable<GroupSearchNode> GetGroupSelectorChildrenNodes(
            int parentId,
            int rootId,
            GroupType groupType,
            string status,
            string preselections = "[]",
            bool multiselect = false,
            bool includeLists = true,
            bool removeEmptyFolder = false,
            bool hideMassDevices = true)
        {
            bool isCheckbox = (multiselect) ? true : false;

            var provider = RuntimeContext.Provider;
            CheckboxStatus cbStatus = CheckboxStatus.NO;
            if (!status.IsNullOrEmpty())
            {

                CheckboxStatus checkboxStatus = EnumUtils<CheckboxStatus>.Parse(status);
                switch (checkboxStatus)
                {
                    case CheckboxStatus.EXP:
                        cbStatus = CheckboxStatus.IMP;
                        break;
                    case CheckboxStatus.IMP:
                        cbStatus = CheckboxStatus.IMP;
                        break;
                }

            }

            if (groupType.Equals(GroupType.HIERARCHY) || groupType.Equals(GroupType.HIERARCHYITEM))
            {
                var thisHierarchy = _userFacade.GetHierarchyBySpec(
                        new HierarchySpec
                        {
                            ProviderId = provider.Id,
                            Ids = new[] { rootId },
                            BaseLocale = provider.BaseLocale
                        }
                    ).FirstOrDefault();
                var delimiterForThisHchy = thisHierarchy.PathDelimiter;
                bool isDLHchy = (thisHierarchy.AvailableForLists == "Y");

                var lineage = delimiterForThisHchy;
                if (groupType.Equals(GroupType.HIERARCHYITEM))
                {
                    var currentNodeInfo =
                        _userFacade.GetListItemBySpec(new DistributionListSpec { ProviderId = provider.Id, Ids = new[] { parentId } });
                    lineage = currentNodeInfo.FirstOrDefault().Lineage + currentNodeInfo.FirstOrDefault().Name + delimiterForThisHchy;
                }

                //Get all children of the node. 
                //var hierarchyChildren =
                //    _userFacade.GetListItemBySpec(new DistributionListSpec
                //    {
                //        ProviderId = provider.Id,
                //        EqualLineage = lineage,
                //        HierarchyId = rootId,
                //        IncludeLists = includeLists
                //    }).Select(
                //        x =>
                //            new GroupSearchNode
                //            {
                //                Name = x.Name,
                //                IsCheckbox = isCheckbox,
                //                ShowCheckbox = true,
                //                HasChildren =
                //                    _userFacade.GetListItemBySpec(new DistributionListSpec
                //                    {
                //                        ProviderId = provider.Id,
                //                        EqualLineage = x.Lineage + x.Name + delimiterForThisHchy,
                //                        IncludeLists = includeLists
                //                    }).Any(),
                //                Id = x.Id,
                //                ParentId = parentId,
                //                ParentGroupType = groupType.ToString(),
                //                Status = cbStatus.ToString(),
                //                CurrentGroupType = ((x.ListType.Equals(ListItemType.Tree)) ? GroupType.HIERARCHYITEM : GroupType.LISTITEM).ToString(),
                //                RootId = (x.HierarchyId) ?? 0,
                //                Lineage = x.Lineage
                //            });


                var hierarchyChildren =
                    publishingFacade.GetChildrenNodes(new DistributionListSpec
                    {
                        ProviderId = provider.Id,
                        EqualLineage = lineage,
                        HierarchyId = rootId,
                        IncludeLists = includeLists
                    }).Select(
                        x =>
                            new GroupSearchNode
                            {
                                Name = x.Name,
                                IsCheckbox = isCheckbox,
                                ShowCheckbox = true,
                                HasChildren = (x.ChildrenCount != 0),
                                Id = x.Id,
                                ParentId = parentId,
                                ParentGroupType = groupType.ToString(),
                                Status = cbStatus.ToString(),
                                CurrentGroupType = ((x.ListType.Equals(ListItemType.Tree)) ? GroupType.HIERARCHYITEM : GroupType.LISTITEM).ToString(),
                                RootId = (x.HierarchyId) ?? 0,
                                DescendantLists = x.DescendantLists,
                                Lineage = x.Lineage
                            });


                List<GroupSearchNode> hierarchyChildrenToReturn = hierarchyChildren.ToList();
                if (isDLHchy && removeEmptyFolder)
                {
                    //first remove nodes that doesn't have children and doesn't have descendant nodes. . 
                    hierarchyChildrenToReturn = hierarchyChildrenToReturn.Where(x => !x.CurrentGroupType.Equals(GroupType.HIERARCHYITEM.ToString()) || x.DescendantLists != null).ToList(); //if this is not a folder, display. If it is a folder, but has some descendant list, keep it. 

                    // var  bleh = hierarchyChildrenToReturn.Where(x => !x.CurrentGroupType.Equals(GroupType.HIERARCHYITEM) || x.DescendantLists != null); //if this is not a folder, display. If it is a folder, but has some descendant list, keep it. 

                    var systemUser = operatorFacade.GetUser(new SystemUserSpec { ProviderId = provider.Id, OperatorId = RuntimeContext.Operator.Id });

                    if (!systemUser.IsTargetableAccessListUnrestricted() && !systemUser.IsManagableAccessListUnrestricted()) //if operator has unrestricted userbase for either, then no need to check for permission - operator can see node he or she has either publishing OR management access to. 
                    {
                        var manageList = systemUser.GetManagableAccessList().Select(x => x.EntityId); //strip permission list to list of Ids so compare is easy
                        var targetList = systemUser.GetTargetableAccessList().Select(x => x.EntityId);

                        List<GroupSearchNode> newNodes = new List<GroupSearchNode>();

                        foreach (GroupSearchNode hchyChildren in hierarchyChildrenToReturn)
                        {
                            bool hasAccess = true;

                            if (hchyChildren.CurrentGroupType.Equals(GroupType.HIERARCHYITEM.ToString())) //no need to check permission if node is a list. 
                            {
                                hasAccess = false;

                                var listIds = hchyChildren.DescendantLists;
                                var dLists = listIds.Split<int>();


                                foreach (int listId in dLists) //see if operator has access to any of the list that is descendant of this node. 
                                {
                                    if (manageList.Contains(listId) || targetList.Contains(listId))
                                    {
                                        hasAccess = true;
                                    }
                                }

                            }
                            else if (hchyChildren.CurrentGroupType.Equals(GroupType.LISTITEM.ToString()))
                            {
                                if (manageList.Contains(hchyChildren.Id) || targetList.Contains(hchyChildren.Id))
                                {
                                    hasAccess = true;
                                }
                                else
                                {
                                    hasAccess = false;
                                }


                            }
                            if (hasAccess)
                            {
                                newNodes.Add(hchyChildren);
                            }

                        }
                        hierarchyChildrenToReturn = newNodes;

                    }
                }

                applyPreselection(preselections, ref hierarchyChildrenToReturn);
                return hierarchyChildrenToReturn.OrderBy(x => x.Name);

            }

            if (groupType.Equals(GroupType.ATTRIBUTE))
            {
                var providerAttributes = CustomAttributesHelper.GetProviderAttributes(_customAttributeCache, RuntimeContext.ProviderId, RuntimeContext.Provider.BaseLocale, hideMassDevices);
                var customAttributeValues = providerAttributes.Where(x => x.Id == parentId).SelectMany(x => x.Values);

                GlobalEntityLocaleFacade globalEntityLocaleFacade = new GlobalEntityLocaleFacade(new GlobalEntityLocaleRepository());

                var attributeValues =
                    customAttributeValues.Select(
                        x =>
                            new GroupSearchNode
                            {
                                Name = (x.CustomAttribute.AttributeTypeId.Equals(CustomAttributeDataType.Checkbox)) ? globalEntityLocaleFacade.GetLocalizedValue(x.ValueName, BusinessEntity.CheckBox, "Name", RuntimeContext.Provider.BaseLocale) : x.ValueName,
                                ShowCheckbox = true,
                                IsCheckbox = (x.CustomAttribute.AttributeTypeId.Equals(CustomAttributeDataType.Checkbox)) ? false : true,
                                HasChildren = false,
                                Id = x.ValueId,
                                Status = cbStatus.ToString(),
                                CurrentGroupType = GroupType.ATTRIBUTEVALUE.ToString(),
                                RootId = x.CustomAttribute.Id,
                                ParentId = parentId,
                                ParentGroupType = groupType.ToString(),
                                Lineage = ""
                            });

                var attributeValuesToReturn = attributeValues.ToList();
                applyPreselection(preselections, ref attributeValuesToReturn);
                return attributeValuesToReturn;
            }

            return Enumerable.Empty<GroupSearchNode>();
        }

        public ActionResult GetHierarchyRoot(string preselections = "[]", bool selectRootByDefault = false, bool multiselect = true, HierarchyContext hchyContext = HierarchyContext.OrgHierarchy, bool applyPreselectionViaLineage = false, bool showErrorOnInvalidHierarchy = false)
        {
            var provider = RuntimeContext.Provider;
            string pathDelimiter = "/";

            var preselectedNodesToReturn = new List<PreselectedGroupNode>(); //if not is preselected, but is not on the popupon upon launching (because preselected node is not at the root level in this case), return complete object to the front end so it can be added to the selections array and pills can be made

            var preselectedList = JsonSerializerService.Deserialize<IEnumerable<CriterionValue>>(preselections);

            var availableForLists = (!hchyContext.Equals(HierarchyContext.OrgHierarchy));

            var hierarchyType = (hchyContext.Equals(HierarchyContext.Location)) ? HierarchyType.LOC : HierarchyType.ORG;

            var orgHierarchy =
                _userFacade.GetHierarchyBySpec(new HierarchySpec { ProviderId = provider.Id, HierarchyType = hierarchyType, AvailableForLists = availableForLists, BaseLocale = provider.BaseLocale });
            var hierarchyToReturn = new List<GroupSearchNode>();

            IEnumerable<CriterionValue> preselectedValues = preselectedList as IList<CriterionValue> ?? preselectedList.ToList();

            foreach (Hierarchy node in orgHierarchy)
            {
                pathDelimiter = node.PathDelimiter;

                var status = (selectRootByDefault) ? CheckboxStatus.EXP : CheckboxStatus.NO;

                foreach (CriterionValue preselectedValue in preselectedValues) //in this call (only called for folder selection for operator userbase and ddl), only lineage is given
                {
                    if (applyPreselectionViaLineage) //for user hierarchy selection and dl folder selection, only info I have is lineage. Must find corresponding entry in db via lineage only. 
                    {
                        if (preselectedValue.lineage.Equals(node.PathDelimiter)) //root node 
                        {
                            status = CheckboxStatus.EXP;
                            preselectedNodesToReturn.Add(createPreselectedGroupNode(node.Id, GroupType.HIERARCHY, node.Name, node.PathDelimiter, node.Id));
                        }
                        else
                        {
                            //find all folders under this hiearchy
                            foreach (DistributionList dl in _userFacade.GetListItemBySpec(new DistributionListSpec { ProviderId = provider.Id, IncludeLists = false, HierarchyId = node.Id }))
                            {
                                if (String.Concat(dl.FullLineage, pathDelimiter).Equals(preselectedValue.lineage))
                                {
                                    status = CheckboxStatus.PRT;
                                    preselectedNodesToReturn.Add(createPreselectedGroupNode(dl.Id, GroupType.HIERARCHYITEM, dl.Name, dl.Lineage, (int)dl.HierarchyId));
                                }
                            }

                        }
                    }
                    else
                    {
                        GroupType entityType = EnumUtils<GroupType>.Parse(preselectedValue.entityType);

                        if (entityType.Equals(GroupType.HIERARCHY) && preselectedValue.id == node.Id)
                        {
                            status = CheckboxStatus.EXP;
                            preselectedNodesToReturn.Add(createPreselectedGroupNode(node.Id, GroupType.HIERARCHY, node.Name, node.PathDelimiter, node.Id));
                        }
                        else if (entityType.Equals(GroupType.HIERARCHYITEM))
                        {
                            var subNode =
                                _userFacade.GetListItemBySpec(new DistributionListSpec { ProviderId = provider.Id, Ids = new[] { preselectedValue.id }, HierarchyId = node.Id });
                            if (subNode.Count() != 0) //preselected item belong to this hierarchy - root not should show as partially selected
                            {
                                status = CheckboxStatus.PRT;
                                DistributionList thisNode = subNode.FirstOrDefault();
                                preselectedNodesToReturn.Add(createPreselectedGroupNode(thisNode.Id, GroupType.HIERARCHYITEM, thisNode.Name, thisNode.Lineage, (int)thisNode.HierarchyId));
                            }

                        }
                    }
                }

                bool isCheckbox = (multiselect) ? true : false;

                hierarchyToReturn.Add(new GroupSearchNode
                {
                    Name = node.Name,
                    IsCheckbox = isCheckbox,
                    HasChildren = true,
                    Id = node.Id,
                    CurrentGroupType = GroupType.HIERARCHY.ToString(),
                    RootId = node.Id,
                    Lineage = node.PathDelimiter,
                    Status = status.ToString(),
                    ShowCheckbox = true
                });

            }

            bool preselectionWithInvalidHierarchyPath = false;

            if (applyPreselectionViaLineage
                && preselectedValues.Count() == 1
                && preselectedNodesToReturn.Count == 0
                && multiselect == false
                && hchyContext == HierarchyContext.OrgHierarchy
                && showErrorOnInvalidHierarchy
                )
            {
                preselectedNodesToReturn.Add(createPreselectedGroupNode(hierarchyToReturn[0].Id,
                    GroupType.HIERARCHY,
                    hierarchyToReturn[0].Name,
                    hierarchyToReturn[0].Lineage,
                    hierarchyToReturn[0].Id));

                preselectionWithInvalidHierarchyPath = true;
            }

            return Json(new { Nodes = hierarchyToReturn, PreselectedSelectionsToAdd = preselectedNodesToReturn, PathDelimiter = pathDelimiter, preselectionWithInvalidHierarchyPath });
        }


        [HttpPost]
        public ActionResult GetCustomAttributesForQuery(string entityId, string preselections = "[]", bool hideMassDevices = true, bool hideGeolocation = true, bool readFromCache = false)
        {
            if ("ALERT".Equals(entityId, StringComparison.InvariantCultureIgnoreCase))
            {
                return GetCustomAttributesForQueryForAlert(preselections);
            }
            else
            {
                return GetCustomAttributesForQueryForUser(preselections, hideMassDevices, hideGeolocation, readFromCache);
            }
        }

        private ActionResult GetCustomAttributesForQueryForUser(string preselections = "[]", bool hideMassDevices = true, bool hideGeolocation = true, bool readFromCache = false)
        {
            var provider = RuntimeContext.Provider;
            var rm = IWSResources.ResourceManager;
            var entities = new List<Object>();

            if (RuntimeContext.Provider.FeatureMatrix.IsOrgHierarchySupported)
            {
                var orgHierarchy = new
                {
                    name = rm.GetString("User_Criteria_Builder_Org_Hierarchy"),
                    items = _userFacade.GetHierarchyBySpec(
                        new HierarchySpec
                        {
                            ProviderId = provider.Id,
                            AvailableForLists = false,
                            IncludeCustomAttribute = true,
                            BaseLocale = provider.BaseLocale
                        }).Select(
                        x =>
                            new CustomAttributeForQuery
                            {
                                name = x.CustomAttribute.AttributeName,
                                dataType = CustomAttributeDataType.Path.ToString(),
                                dataTypeId = (int)CustomAttributeDataType.Path,
                                id = x.CustomAttribute.Id,
                                entityType = GroupType.ATTRIBUTE.ToString(),
                                commonName = x.CommonName,
                                hierarchyId = x.Id,
                                pathDelimiter = x.PathDelimiter
                            })
                };
                entities.Add(orgHierarchy);
            }

            if (!hideGeolocation)
            {
                var geoEntities = new
                {
                    name = rm.GetString("User_Criteria_Builder_GeoLocation"),
                    items = CustomAttributesHelper.GetProviderAttributes(_customAttributeCache, RuntimeContext.ProviderId,RuntimeContext.Provider.BaseLocale, hideMassDevices,readFromCache)
                        .Where(x =>
                            x.IsSearchable == "Y" && x.EntityId == "USER" &&
                            x.AttributeTypeId == CustomAttributeDataType.GeoLocation)
                        .Select(x =>
                            new CustomAttributeForQuery
                            {
                                name = x.AttributeName,
                                dataType = x.AttributeTypeId.ToString(),
                                dataTypeId = (int)x.AttributeTypeId,
                                id = x.Id,
                                entityType = GroupType.ATTRIBUTE.ToString(),
                                commonName = x.CommonName,
                                values =
                                    (x.Values == null)
                                        ? Enumerable.Empty<CustomAttributeValueForQuery>()
                                        : x.Values.Select(
                                            y =>
                                                new CustomAttributeValueForQuery
                                                {
                                                    name = y.ValueName,
                                                    id = y.ValueId,
                                                    commonName = y.CommonName
                                                })
                            }
                        ).OrderBy(x => x.name)
                };
                entities.Add(geoEntities);
            }

            var providerAttributes = CustomAttributesHelper.GetProviderAttributes(_customAttributeCache, RuntimeContext.ProviderId, RuntimeContext.Provider.BaseLocale, hideMassDevices, readFromCache)
                .Where(
                    x =>
                        x.IsSearchable == "Y" && x.EntityId == "USER" &&
                        x.AttributeTypeId != CustomAttributeDataType.Path &&
                        x.AttributeTypeId != CustomAttributeDataType.Memo &&
                        x.AttributeTypeId != CustomAttributeDataType.GeoLocation && (x.CommonName != ((!RuntimeContext.Provider.FeatureMatrix.IsEnterpriseManagementSupported) ? CommonNames.Organizations : null)) && (x.CommonName != ((!RuntimeContext.Provider.FeatureMatrix.IsEnterpriseManagementSupported) ? CommonNames.PreventUserMove : null)))
                .Select(
                x => (String.Equals(x.CommonName, CommonNames.Organizations, StringComparison.CurrentCultureIgnoreCase))?new CustomAttributeForQuery
                {
                    name = rm.GetString("DisplayName_Organizations"),
                    dataType = CustomAttributeDataType.MultiPicklist.ToString(),
                    dataTypeId = (int)CustomAttributeDataType.MultiPicklist,
                    id = 0,
                    entityType = GroupType.VPS.ToString(),
                    commonName = CommonNames.Organizations,
                    values =
                       
                        _providerFacade.GetEnterpriseProviderList(RuntimeContext.ProviderId).Select(z => new CustomAttributeValueForQuery
                        {
                            name = z.Value,
                            id = z.Key,
                            commonName = CommonNames.Organizations
                        }) 
                }:
                        new CustomAttributeForQuery
                        {
                            name = x.AttributeName,
                            dataType = x.AttributeTypeId.ToString(),
                            dataTypeId = (int)x.AttributeTypeId,
                            id = x.Id,
                            entityType = GroupType.ATTRIBUTE.ToString(),
                            commonName = x.CommonName,
                            values =
                                (x.Values == null)?Enumerable.Empty<CustomAttributeValueForQuery>() : x.Values.Select(
                                        y =>
                                            new CustomAttributeValueForQuery
                                            {
                                                name = y.ValueName,
                                                id = y.ValueId,
                                                commonName = y.CommonName
                                            })
                        }
                ).OrderBy(x => x.name);

            /*VPS based query*/
           
         
            var customAttributes = new
            {
                name = rm.GetString("User_Criteria_Builder_Attribute"),
                items =  providerAttributes
            };
            entities.Add(customAttributes);

            /*role based query dev - CAUTION there is a hardcode (approved by Rakesh)*/

            var providerRoles = _operatorDetailsFacade.GetOperatorRoles(new OperatorRoleSpec { ProviderId = provider.Id, BaseLocale = provider.BaseLocale }).OrderBy(x => x.RoleName);
            var roleValuesList = providerRoles.Select(role => new CustomAttributeValueForQuery { name = role.RoleName, id = role.Id, commonName = role.RoleName }).ToList();

            var roleList = new List<CustomAttributeForQuery>();
            roleList.Add(new CustomAttributeForQuery
                    {
                        name = rm.GetString("DisplayName_OperatorRoles"),
                        dataType = CustomAttributeDataType.MultiPicklist.ToString(),
                        dataTypeId = (int)CustomAttributeDataType.MultiPicklist,
                        id = 0,
                        entityType = GroupType.ROLE.ToString(),
                        commonName = CommonNames.OperatorRoles,
                        values = roleValuesList
                    }
                );

            var roles = new
            {
                name = rm.GetString("User_Criteria_Builder_OperatorAttribute"),
                items = roleList
            };
            entities.Add(roles);
            /*end role based query dev - CAUTION there is a hardcode (approved by Rakesh)*/

            var devices = new
            {
                name = rm.GetString("User_Criteria_Builder_Device"),
                items = deviceFacade.GetDevicesBySpec(new DeviceSpec { ProviderId = provider.Id, IsMassDevice = false, EnabledOnly = true }, RuntimeContext.Provider.BaseLocale).Select(
                x =>
                    new CustomAttributeForQuery
                    {
                        name = x.Name,
                        dataType = CustomAttributeDataType.String.ToString(),
                        dataTypeId = (int)CustomAttributeDataType.String,
                        id = x.Id,
                        entityType = GroupType.DEVICE.ToString(),
                        commonName = x.CommonName,
                    }).OrderBy(x => x.name)
            };
            entities.Add(devices);

            var preselectedList = JsonSerializerService.Deserialize<IEnumerable<String>>(preselections);

            List<OperandCollection> operandsInfo = new List<OperandCollection>();
            String currentDataTime = "";
            foreach (string dataTypeValue in preselectedList)
            {
                CustomAttributeDataType datatype = EnumUtils<CustomAttributeDataType>.Parse(dataTypeValue);
                int dataTypeId = (int)datatype;
                operandsInfo.Add(new OperandCollection
                {
                    name = datatype.ToString(),
                    operands = getOperands(datatype.ToString(), dataTypeId, datatype.Equals(CustomAttributeDataType.Date) || datatype.Equals(CustomAttributeDataType.DateTime))
                });

                if (datatype.Equals(CustomAttributeDataType.Date) || datatype.Equals(CustomAttributeDataType.DateTime))
                {
                    currentDataTime = provider.CurrentSystemTimeToVps().ToString(CultureInfo.InvariantCulture);
                }
            }

            return Json(new
            {
                availableEntities = entities.ToArray(),
                operandsArray = operandsInfo,
                currentDateTime = currentDataTime,
                relativeDateValueIndicaterString = QueryBuilderConstants.RelativeDateValueIndicaterString,
                relativeDateValueSerializeTemplate = QueryBuilderConstants.RelativeDateValueSerializeTemplate
            });
        }

        private ActionResult GetCustomAttributesForQueryForAlert(string preselections = "[]")
        {
            var provider = RuntimeContext.Provider;
            var rm = IWSResources.ResourceManager;
            var entities = new List<Object>();

            var ruleAttributes = _ruleFacade.GetRuleAttributeLookup()
                .Select(
                    x =>
                        new CustomAttributeForQuery
                        {
                            name = x.AttributeName,
                            dataType = x.AttributeTypeId.ToString(),
                            dataTypeId = (int)x.AttributeTypeId,
                            id = x.Id,
                            entityType = GroupType.ATTRIBUTE.ToString(),
                            commonName = x.CommonName,
                            useCommonNameValue = x.CommonName.Equals("ALERT-SOURCE-ORGANIZATION", StringComparison.InvariantCultureIgnoreCase),
                            values =
                                (x.Values == null)
                                    ? Enumerable.Empty<CustomAttributeValueForQuery>()
                                    : x.Values.Select(
                                        y =>
                                            new CustomAttributeValueForQuery
                                            {
                                                name = y.ValueName,
                                                id = y.ValueId,
                                                commonName = y.CommonName
                                            }).OrderBy(y => y.id)
                        }
                ).OrderBy(x => x.name);

            var customAttributes = new
            {
                name = rm.GetString("User_Criteria_Builder_Attribute"),
                items = ruleAttributes.OrderBy(attribute => attribute.name)
            };
            entities.Add(customAttributes);

            var preselectedList = JsonSerializerService.Deserialize<IEnumerable<String>>(preselections);

            List<OperandCollection> operandsInfo = new List<OperandCollection>();
            String currentDataTime = "";
            foreach (string dataTypeValue in preselectedList)
            {
                CustomAttributeDataType datatype = EnumUtils<CustomAttributeDataType>.Parse(dataTypeValue);
                int dataTypeId = (int)datatype;
                operandsInfo.Add(new OperandCollection
                {
                    name = datatype.ToString(),
                    operands = getOperands(datatype.ToString(), dataTypeId, datatype.Equals(CustomAttributeDataType.Date) || datatype.Equals(CustomAttributeDataType.DateTime), showEmptyNotEmptyFilter: false)
                });

                if (datatype.Equals(CustomAttributeDataType.Date) || datatype.Equals(CustomAttributeDataType.DateTime))
                {
                    currentDataTime = provider.CurrentSystemTimeToVps().ToString(CultureInfo.InvariantCulture);
                }
            }

            return Json(new
            {
                availableEntities = entities.ToArray(),
                operandsArray = operandsInfo,
                currentDateTime = currentDataTime,
                relativeDateValueIndicaterString = QueryBuilderConstants.RelativeDateValueIndicaterString,
                relativeDateValueSerializeTemplate = QueryBuilderConstants.RelativeDateValueSerializeTemplate
            });
        }

        [HttpPost]
        public ActionResult GetOperandsForQuery(string dataType = "", bool showEmptyNotEmptyFilter = true)
        {
            var provider = RuntimeContext.Provider;
            var rm = IWSResources.ResourceManager;

            CustomAttributeDataType datatypeEnum = EnumUtils<CustomAttributeDataType>.Parse(dataType);

            int dataTypeId = (int)datatypeEnum;

            String currentDataTime = "";
            bool isDateOrDateTime = false;

            if (datatypeEnum.Equals(CustomAttributeDataType.Date) || datatypeEnum.Equals(CustomAttributeDataType.DateTime))
            {
                currentDataTime = provider.CurrentSystemTimeToVps().ToString(CultureInfo.InvariantCulture);
                isDateOrDateTime = true;
            }

            var operands = getOperands(dataType, dataTypeId, isDateOrDateTime, showEmptyNotEmptyFilter);

            return Json(new { QueryNodes = operands, currentDateTime = currentDataTime });
        }

        private IEnumerable<Operand> getOperands(string dataType, int dataTypeId, bool isDateOrDateTime, bool showEmptyNotEmptyFilter = true)
        {


            var rm = IWSResources.ResourceManager;
            if (!showEmptyNotEmptyFilter)
            {
                string[] emptyFilterStrings = { "Is_Empty", "Is_Not_Empty" };
                return
                customAttributeFacade.ReturnOperatorsForDataType((int)dataTypeId).Where(a => !emptyFilterStrings.Contains(a.CommonName)).Select(
                    x =>
                        new Operand
                        {
                            id = x.Id,
                            name =
                                (rm.GetString(String.Concat("User_Criteria_Builder_Operator_", x.CommonName, "_", dataType)) == null)
                                    ? rm.GetString(String.Concat("User_Criteria_Builder_Operator_", x.CommonName))
                                    : rm.GetString(String.Concat("User_Criteria_Builder_Operator_", x.CommonName, "_", dataType)),
                            isValueRequired = x.IsValueRequired,
                            displayTextTemplate =
                                (rm.GetString(String.Concat("User_Criteria_Builder_Operator_", x.CommonName, "_", dataType, "_Display")) == null)
                                    ? rm.GetString(String.Concat("User_Criteria_Builder_Operator_", x.CommonName, "_Display"))
                                    : rm.GetString(String.Concat("User_Criteria_Builder_Operator_", x.CommonName, "_", dataType, "_Display")),
                            relativeDateTimeDisplayText = getRelativeDisplayTexts(isDateOrDateTime, x.CommonName, dataType),
                            showAdvancedValueSelector = x.ShowAdvancedValueSelector

                        });
            }

            return
                customAttributeFacade.ReturnOperatorsForDataType((int)dataTypeId).Select(
                    x =>
                        new Operand
                        {
                            id = x.Id,
                            name =
                                (rm.GetString(String.Concat("User_Criteria_Builder_Operator_", x.CommonName, "_", dataType)) == null)
                                    ? rm.GetString(String.Concat("User_Criteria_Builder_Operator_", x.CommonName))
                                    : rm.GetString(String.Concat("User_Criteria_Builder_Operator_", x.CommonName, "_", dataType)),
                            isValueRequired = x.IsValueRequired,
                            displayTextTemplate =
                                (rm.GetString(String.Concat("User_Criteria_Builder_Operator_", x.CommonName, "_", dataType, "_Display")) == null)
                                    ? rm.GetString(String.Concat("User_Criteria_Builder_Operator_", x.CommonName, "_Display"))
                                    : rm.GetString(String.Concat("User_Criteria_Builder_Operator_", x.CommonName, "_", dataType, "_Display")),
                            relativeDateTimeDisplayText = getRelativeDisplayTexts(isDateOrDateTime, x.CommonName, dataType),
                            showAdvancedValueSelector = x.ShowAdvancedValueSelector

                        });


        }

        private RelativeDateTimeOperandDisplay getRelativeDisplayTexts(bool isDateOrDateTime, string operatorCommonName, string dataTypeString)
        {
            var rm = IWSResources.ResourceManager;

            if (!isDateOrDateTime)
            {
                return new RelativeDateTimeOperandDisplay();
            }
            else
            {

                //"User_Criteria_Builder_Operator_{0}_{1}_{2}_Display_Short";
                return new RelativeDateTimeOperandDisplay
                {
                    pastShortSingular = rm.GetString(QueryBuilderConstants.DisplayResourceLookupFormatShort.FormatWith(operatorCommonName, dataTypeString, QueryBuilderConstants.PastXDaysSingularResourceKey)),
                    pastShortPlural = rm.GetString(QueryBuilderConstants.DisplayResourceLookupFormatShort.FormatWith(operatorCommonName, dataTypeString, QueryBuilderConstants.PastXDaysPluralResourceKey)),
                    pastLong = rm.GetString(QueryBuilderConstants.DisplayResourceLookupFormatLong.FormatWith(operatorCommonName, dataTypeString, QueryBuilderConstants.PastXDaysSingularResourceKey)),
                    nowShort = rm.GetString(QueryBuilderConstants.DisplayResourceLookupFormatShort.FormatWith(operatorCommonName, dataTypeString, QueryBuilderConstants.NowResourceKey)),
                    nowLong = rm.GetString(QueryBuilderConstants.DisplayResourceLookupFormatLong.FormatWith(operatorCommonName, dataTypeString, QueryBuilderConstants.NowResourceKey)),
                    nextShortSingular = rm.GetString(QueryBuilderConstants.DisplayResourceLookupFormatShort.FormatWith(operatorCommonName, dataTypeString, QueryBuilderConstants.NextXDaysSingularResourceKey)),
                    nextShortPlural = rm.GetString(QueryBuilderConstants.DisplayResourceLookupFormatShort.FormatWith(operatorCommonName, dataTypeString, QueryBuilderConstants.NextXDaysPluralResourceKey)),
                    nextLong = rm.GetString(QueryBuilderConstants.DisplayResourceLookupFormatLong.FormatWith(operatorCommonName, dataTypeString, QueryBuilderConstants.NextXDaysSingularResourceKey)),
                    absoluteDateShort = rm.GetString(QueryBuilderConstants.DisplayResourceLookupFormatShort.FormatWith(operatorCommonName, dataTypeString, QueryBuilderConstants.AbsoluteDateResourceKey)),
                    absoluteDateLong = rm.GetString(QueryBuilderConstants.DisplayResourceLookupFormatLong.FormatWith(operatorCommonName, dataTypeString, QueryBuilderConstants.AbsoluteDateResourceKey))
                };

            }

        }

        //takes a list of group search nodes, and apply preselection if required (if the node status needs to be explicitly/implicitly selected etc)
        private List<PreselectedGroupNode> applyPreselection(string preselections, ref List<GroupSearchNode> nodesToReturn, bool getPreselectedNodes = false, bool hideMassDevices = true)
        {
            //apply preselection
            List<PreselectedGroupNode> listToReturn = new List<PreselectedGroupNode>();

            IEnumerable<CriterionValue> preselectedList = JsonSerializerService.Deserialize<IEnumerable<CriterionValue>>(preselections);
            foreach (CriterionValue preselectedValue in preselectedList)
            {
                GroupType entityType = EnumUtils<GroupType>.Parse(preselectedValue.entityType);

                switch (entityType)
                {
                    case GroupType.HIERARCHY:
                    case GroupType.ATTRIBUTE:
                        var nodeToModify = nodesToReturn.Where(x => x.CurrentGroupType == entityType.ToString() && x.Id == preselectedValue.id);
                        if (nodeToModify.HasValue())
                        {
                            var thisNode = nodeToModify.FirstOrDefault();
                            thisNode.Status = CheckboxStatus.EXP.ToString();
                            if (getPreselectedNodes)
                            {
                                listToReturn.Add(createPreselectedGroupNode(preselectedValue.id, entityType, thisNode.Name, thisNode.Lineage, thisNode.RootId));
                            }
                        }
                        break;
                    case GroupType.HIERARCHYITEM:
                    case GroupType.LISTITEM:

                        //if hierarchy root is shown, see if it needs to shown as partially selected
                        foreach (GroupSearchNode hchyRootNode in nodesToReturn.Where(x => x.CurrentGroupType == GroupType.HIERARCHY.ToString()))
                        {
                            var subNode =
                                _userFacade.GetListItemBySpec(new DistributionListSpec { Ids = new[] { preselectedValue.id }, HierarchyId = hchyRootNode.Id });
                            if (subNode.Count() != 0) //preselected item belong to this hierarchy - root node should show as partially selected
                            {
                                DistributionList node = subNode.FirstOrDefault();
                                hchyRootNode.Status = CheckboxStatus.PRT.ToString();
                                if (getPreselectedNodes)
                                {
                                    listToReturn.Add(createPreselectedGroupNode(node.Id, entityType, node.Name, node.Lineage, (int)node.HierarchyId));
                                }

                            }
                        }

                        //if hierarchy item is shown, see if it needs to be implicitly or explicitly selected.
                        foreach (GroupSearchNode hchyItemNode in nodesToReturn.Where(x => x.CurrentGroupType == GroupType.HIERARCHYITEM.ToString() || x.CurrentGroupType == GroupType.LISTITEM.ToString()))
                        {
                            if (preselectedValue.id.Equals(hchyItemNode.Id))
                            {
                                hchyItemNode.Status = CheckboxStatus.EXP.ToString();
                                if (getPreselectedNodes)
                                {
                                    listToReturn.Add(createPreselectedGroupNode(hchyItemNode.Id, entityType, hchyItemNode.Name, hchyItemNode.Lineage, hchyItemNode.RootId));
                                }

                            }
                            else
                            {
                                if (!preselectedValue.lineage.Equals(hchyItemNode.Lineage) && preselectedValue.lineage.StartsWith(hchyItemNode.Lineage + hchyItemNode.Name))
                                {
                                    var subNode =
                                        _userFacade.GetListItemBySpec(new DistributionListSpec { Ids = new[] { preselectedValue.id } });
                                    if (subNode.HasValue()) //preselected item belong to this hierarchy - root not should show as partially selected
                                    {
                                        DistributionList firstSubNode = subNode.First();
                                        if (firstSubNode.HierarchyId == hchyItemNode.RootId) //double check to make sure they are of same hierarchy, just in case both dl and org hchy has same hchy structure, unlikely but.. 
                                        {
                                            hchyItemNode.Status = CheckboxStatus.PRT.ToString();
                                            if (getPreselectedNodes)
                                            {
                                                listToReturn.Add(createPreselectedGroupNode(preselectedValue.id, entityType, subNode.FirstOrDefault().Name, preselectedValue.lineage, (int)subNode.FirstOrDefault().HierarchyId));
                                            }
                                        }
                                    }
                                }

                            }
                        }
                        break;
                    case GroupType.ATTRIBUTEVALUE:
                        var providerAttributes = CustomAttributesHelper.GetProviderAttributes(_customAttributeCache,
                            RuntimeContext.ProviderId, RuntimeContext.Provider.BaseLocale, hideMassDevices);
                        //if attribute level is shown, see if it needs to shown as partially selected
                        foreach (GroupSearchNode attributeNode in nodesToReturn.Where(x => x.CurrentGroupType == GroupType.ATTRIBUTE.ToString()))
                        {
                            //ask alexb about this
                            foreach (CustomAttributeValue caValue in providerAttributes.Where(x => x.Id == attributeNode.Id).SelectMany(x => x.Values))
                            {
                                if (caValue.ValueId.Equals(preselectedValue.id))
                                {
                                    attributeNode.Status = CheckboxStatus.PRT.ToString();

                                    if (getPreselectedNodes)
                                    {

                                        string nodeDisplay = IWSResources.User_Group_Selector_Attribute_Is_Value.Replace("{customAttributeName}", attributeNode.Name);
                                        nodeDisplay = nodeDisplay.Replace("{value}", caValue.ValueName);

                                        listToReturn.Add(createPreselectedGroupNode(caValue.ValueId, entityType, nodeDisplay, "", caValue.AttributeId));
                                    }
                                }

                            }
                        }

                        //if attribute value level is shown see if it needs to be explicitly selected
                        var customAttributeValueNode = nodesToReturn.Where(x => x.CurrentGroupType == entityType.ToString() && x.Id == preselectedValue.id);
                        if (customAttributeValueNode.HasValue())
                        {
                            GroupSearchNode thisNode = customAttributeValueNode.FirstOrDefault();
                            thisNode.Status = CheckboxStatus.EXP.ToString();
                            if (getPreselectedNodes)
                            {
                                listToReturn.Add(createPreselectedGroupNode(thisNode.Id, entityType, thisNode.Name, "", thisNode.Id));
                            }

                        }

                        break;
                }


            }
            return listToReturn;
        }

        private PreselectedGroupNode createPreselectedGroupNode(int id, GroupType type, string display, string lineage, int rootId)
        {
            return new PreselectedGroupNode
            {
                value = id,
                type = type.ToString(),
                display = display,
                lineage = lineage,
                rootId = rootId
            };
        }


        public JsonResult GetHierarchyGroup(int hierarchytype)
        {
            var hierarchySearchType = hierarchytype == 0 ? HierarchySearchType.Organization : (hierarchytype == 1 ? HierarchySearchType.DistributionList : HierarchySearchType.TargetingGroupList);
            var list = new List<object>();
            try
            {

                switch (hierarchytype)
                {
                    case 0:
                    case 1:
                        {
                            var hierarchySpec = new AtHoc.IWS.Business.Domain.Settings.HierarchySpec
                            {
                                ProviderId = RuntimeContext.ProviderId,
                                OperatorId = RuntimeContext.OperatorId,
                                LocalCode = RuntimeContext.Provider.BaseLocale,
                                HierarchySearchType = hierarchySearchType
                            };
                            var data = _hierarchyFacade.GetHierarchy(hierarchySpec);
                            list.Add(ConvertHierarchytoTargetingTree(data, hierarchySearchType));
                        }
                        break;
                    default:
                        {
                            var targetingTree =
                            _targetingTreeFacade.GetHierarchyGroupList(new TargetingTreeSpec
                            {
                                ProviderId = RuntimeContext.ProviderId,
                                UserId = RuntimeContext.OperatorId
                            }, ProviderAttributes);
                            list.AddRange(targetingTree);
                        }
                        break;
                }
                var result = Json(new
                {
                    Success = true,
                    Data = list,
                });
                result.RecursionLimit = 1024;
                result.MaxJsonLength = 8388608;
                return result;
            }
            catch (Exception ex)
            { 
                return Json(new { Success = false, HasErrors = true, Messages = IWSResources.AtHoc_HierarchyDefinition_ErrMsg_Retriving });
            }
        }

        private static CustomAttributeLookup ProviderAttributes
        {
            get
            {
                var customAttributes = RuntimeContext.CustomAttributesWithouMassDevices.Where(x => x.EntityId == "USER").ToArray();
                return new CustomAttributeLookup(customAttributes);
            }
        }

        private Node ConvertHierarchytoTargetingTree(AtHoc.IWS.Business.Domain.Settings.PdlListModel rootNode, HierarchySearchType hierarchySearchType)
        {
            var treeNode = new Node
            {
                Id = rootNode.HierarchyId ?? rootNode.ListId,
                ParentId = rootNode.ParentListId ?? 0,
                Name = rootNode.Name,
                CommonName = rootNode.CommonName,
                Lineage = rootNode.Lineage == null ? "/" : rootNode.Lineage,
                Type = NodeType.Folder,
                SubType = hierarchySearchType == HierarchySearchType.Organization ? NodeSubType.Organization : NodeSubType.DistributionList,
                SortOrder = rootNode.SortOrder ?? 0,
                Children = GetChildNodes(rootNode, hierarchySearchType),
                AttributeTypeId = 9,
                AttributeId = rootNode.HierarchyId ?? 0,
            };
            return treeNode;
        }

        private List<Node> GetChildNodes(AtHoc.IWS.Business.Domain.Settings.PdlListModel treeNode, HierarchySearchType hierarchySearchType)
        {
            List<Node> childList = new List<Node>();
            if (treeNode.HasChildren)
            {
                foreach (var itemNode in treeNode.Children)
                {
                    childList.Add(new Node
                    {
                        Id = itemNode.ListId,
                        ParentId = itemNode.ParentListId ?? 0,
                        Name = itemNode.Name,
                        CommonName = itemNode.CommonName,
                        Lineage = itemNode.Lineage == null ? "/" : itemNode.Lineage,
                        Type = NodeType.Folder,
                        SubType = hierarchySearchType == HierarchySearchType.Organization ? NodeSubType.Organization : NodeSubType.DistributionList,
                        SortOrder = itemNode.SortOrder ?? 0,
                        Children = GetChildNodes(itemNode, hierarchySearchType),
                        AttributeTypeId = 9,
                        AttributeId = itemNode.HierarchyId ?? 0,
                    });
                }
            }
            return childList;
        }
    }
}