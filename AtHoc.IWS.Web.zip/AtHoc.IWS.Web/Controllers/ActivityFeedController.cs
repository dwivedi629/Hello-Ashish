﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Configuration;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using AtHoc.Business.Extensions;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Data;
using AtHoc.Infrastructure.Meta;
using AtHoc.Infrastructure.Web.Mvc.ActionFilters;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.Devices;
using AtHoc.IWS.Business.Domain.Devices.Spec;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.IWS.Web.Configurations;
using AtHoc.IWS.Web.Configurations.Constants;
using AtHoc.IWS.Web.Filters;
using AtHoc.IWS.Web.Models.UserManager;
using AtHoc.Global.Resources;
using EO.Pdf;
using EO.Pdf.Mvc;
using Newtonsoft.Json;
using Controller = AtHoc.Infrastructure.Web.Mvc.Controller;
using AtHoc.IWS.Web.Helpers;
using AtHoc.Publishing;

namespace AtHoc.IWS.Web.Controllers
{
    [IWSAuthorize(new SystemObject[] { SystemObject.EndUsers }, new ActionType[] { ActionType.View })]
    public partial class ActivityFeedController : Controller
    {
        private readonly IActivityFeedFacade _activityFeedFacade;
        private readonly IDeviceFacade _deviceFacade;

        private Provider _provider
        {
            get { return RuntimeContext.Provider; }
        }

        private IEnumerable<Device> _devices;
        private IUserFacade _userFacade;

        private IEnumerable<Device> devices
        {
            get
            {
                return _devices ?? (_devices = _deviceFacade.GetDevicesBySpec(new DeviceSpec
                {
                    ProviderId = RuntimeContext.Provider.Id,
                    IncludeDeviceProvider = true,
                    IncludeDeviceGroup = true,
                    EnabledOnly = true
                }, RuntimeContext.Provider.BaseLocale).ToList());
            }
        }

        private string convertDeliveryStatus(string status)
        {
            var lStatus = string.Empty;
            switch (status)
            {
                case "Error":
                    lStatus = IWSResources.ActivityFeed_AlertStatus_Error;
                    break;
                case "Received":
                    lStatus = IWSResources.ActivityFeed_AlertStatus_Received;
                    break;
                case "Responded":
                    lStatus = IWSResources.ActivityFeed_AlertStatus_Responded;
                    break;
                case "Sent":
                    lStatus = IWSResources.ActivityFeed_AlertStatus_Sent;
                    break;
                case "Not Sent":
                    lStatus = IWSResources.ActivityFeed_AlertStatus_NotSent;
                    break;
            }
            return lStatus;
        }
        public string convertAlertStatus(string status)
        {
            switch ((AlertStatus)Enum.Parse(typeof(AlertStatus), status))
            {
                case AlertStatus.Deleted:
                    return IWSResources.Alert_Status_Deleted;
                case AlertStatus.Ended:
                    return IWSResources.Alert_Status_Ended;
                case AlertStatus.Ending:
                    return IWSResources.Alert_Status_Ending;
                case AlertStatus.Live:
                    return IWSResources.Alert_Status_Live;
                case AlertStatus.Publishing:
                    return IWSResources.Alert_Status_Publishing;
                case AlertStatus.Scheduled:
                    return IWSResources.Alert_Status_Scheduled;
                case AlertStatus.Standby:
                    return IWSResources.Alert_Status_Standby;
                case AlertStatus.Updating:
                    return IWSResources.Alert_Status_Updating;
                default:
                    return "";
            }
        }
        private string GetDeliveryStatusText(AlertDeliveryStatus? deliveryStatus)
        {
            if (!deliveryStatus.HasValue) return String.Empty;


            if (Enum.IsDefined(typeof(AlertDeliveryStatus), deliveryStatus.Value))
            {
                return EnumUtils<AlertDeliveryStatus>.GetDescriptionByValue(deliveryStatus.Value);
            }
            return String.Empty;

        }


        private string getDeviceAddress(string deviceAddress = "", string deviceCommonName = "")
        {
            //This code is added in 87CP1 to show device address for Mobile App as "Push Notification"
            //WIthout this change, it will actually show long numeric device address. IWS-15047

            if (String.Compare(deviceCommonName, CommonNames.MobileNotifierDevice, StringComparison.OrdinalIgnoreCase) == 0)
            {
                deviceAddress = IWSResources.ActivityFeed_PushNotification;
            }
            return deviceAddress;
        }


        public ActivityFeedController(IActivityFeedFacade activityFeedFacade, IDeviceFacade deviceFacade, IUserFacade userFacade)
        {
            this._activityFeedFacade = activityFeedFacade;
            this._deviceFacade = deviceFacade;
            _userFacade = userFacade;
        }

        //public JsonResult GetActivityFeed(int userId)
        [HttpPost]

        public ActionResult GetActivityFeed(GetActivityFeedParam getActivityFeedParam)
        {

            MetaProperty orderBy = ActivityFeed.Meta.EventTime;
            switch (getActivityFeedParam.sortBy)
            {
                case "eventTime":
                    orderBy = ActivityFeed.Meta.EventTime;
                    break;
                case "eventType":
                    orderBy = ActivityFeed.Meta.EventType;
                    break;
                case "title":
                    orderBy = ActivityFeed.Meta.Title;
                    break;
                case "status":
                    orderBy = ActivityFeed.Meta.Status;
                    break;
                case "publisher":
                    orderBy = ActivityFeed.Meta.Publisher;
                    break;
                case "delivery":
                    orderBy = ActivityFeed.Meta.DeliveryState;
                    break;
            }

            var eventType = (getActivityFeedParam.alertId.HasValue &&
                                          getActivityFeedParam.alertId.Value > 0) ? ActivityFeedType.AlertResponse : ActivityFeedType.Alert;

            var minEventTime = getActivityFeedParam.dateFrom.HasValue ? _provider.VpsToSystemTime(new DateTime(getActivityFeedParam.dateFrom.Value.Date.Ticks, DateTimeKind.Unspecified)) : (DateTime?)null;
            var maxEventTime = getActivityFeedParam.dateTo.HasValue ? _provider.VpsToSystemTime(new DateTime(getActivityFeedParam.dateTo.Value.Date.AddDays(1).Ticks, DateTimeKind.Unspecified)) : (DateTime?)null;

            var activityFeedSpec = new ActivityFeedSpec
            {

                UserId = getActivityFeedParam.userId,
                Page = getActivityFeedParam.page,
                PageSize = getActivityFeedParam.pageSize,
                OrderBy = orderBy,
                OrderAsc = (getActivityFeedParam.sortOrder == "ASC"),
                SearchString = getActivityFeedParam.searchTerm,
                MinEventTime = minEventTime,
                MaxEventTime = maxEventTime,
                AlertId = getActivityFeedParam.alertId,
                EventType = eventType,
                ProviderId = RuntimeContext.Provider.Id
            };

            var actvityFeedWithPageCount = _activityFeedFacade.GetActivityFeedItemsPage(activityFeedSpec);

            var retActivityFeed = actvityFeedWithPageCount.Data.Select(af => new
            {
                af.Body,
                af.DeliveryStatus,
                DeviceAddress = getDeviceAddress(af.DeviceAddress, af.DeviceCommonName),
                af.DeviceCommonName,
                af.EventId,
                DisplayEventDate = _provider.SystemToVpsDateFormated(af.EventTime),
                DisplayEventTime = _provider.SystemToVpsTimeFormated(af.EventTime),
                af.EventType,
                af.NoResponse,
                af.Publisher,
                af.RespondedText,
                DisplayRespondedDate = _provider.SystemToVpsDateFormated(af.ResponseDate),
                DisplayRespondedTime = _provider.SystemToVpsTimeFormated(af.ResponseDate),
                af.Sent,
                af.Status,
                af.Title,
                af.UserId,
                RuntimeContext.Provider.ProviderName,
                af.DeviceName,
                af.IsFirstResponded,
                ListDeliveryStatusValue = GetDeliveryStatusText(af.DeliveryStatus),
                DetailDeliveryStatus = GetDeliveryStatusText(af.DeliveryStatus),
                af.DeliveryState,
            });

            return Json(new { activityFeed = retActivityFeed, totalRecordCount = actvityFeedWithPageCount.Count, pageSize = 25 });
        }

        [HttpPost]
        [RenderAsPDF(AutoConvert = false)]
        [FileDownloadCookie]
        public ActionResult ListToPdf(FormCollection form)
        {
            var getActivityFeedParam = new JavaScriptSerializer().Deserialize<GetActivityFeedParam>(form["feed"]);

            MetaProperty orderBy = ActivityFeed.Meta.EventTime;
            switch (getActivityFeedParam.sortBy)
            {
                case "eventTime":
                    orderBy = ActivityFeed.Meta.EventTime;
                    break;
                case "eventType":
                    orderBy = ActivityFeed.Meta.EventType;
                    break;
                case "title":
                    orderBy = ActivityFeed.Meta.Title;
                    break;
                case "status":
                    orderBy = ActivityFeed.Meta.Status;
                    break;
                case "publisher":
                    orderBy = ActivityFeed.Meta.Publisher;
                    break;
                case "delivery":
                    orderBy = ActivityFeed.Meta.DeliveryState;
                    break;
            }

            var eventType = (getActivityFeedParam.alertId.HasValue &&
                                          getActivityFeedParam.alertId.Value > 0) ? ActivityFeedType.AlertResponse : ActivityFeedType.Alert;

            var minEventTime = getActivityFeedParam.dateFrom.HasValue ? _provider.VpsToSystemTime(new DateTime(getActivityFeedParam.dateFrom.Value.Date.Ticks, DateTimeKind.Unspecified)) : (DateTime?)null;
            var maxEventTime = getActivityFeedParam.dateTo.HasValue ? _provider.VpsToSystemTime(new DateTime(getActivityFeedParam.dateTo.Value.Date.AddDays(1).Ticks, DateTimeKind.Unspecified)) : (DateTime?)null;

            var activityFeedSpec = new ActivityFeedSpec
            {

                UserId = getActivityFeedParam.userId,
                Page = getActivityFeedParam.page,
                PageSize = getActivityFeedParam.pageSize,
                OrderBy = orderBy,
                OrderAsc = (getActivityFeedParam.sortOrder == "ASC"),
                SearchString = getActivityFeedParam.searchTerm,
                MinEventTime = minEventTime,
                MaxEventTime = maxEventTime,
                AlertId = getActivityFeedParam.alertId,
                EventType = eventType,
                ProviderId = RuntimeContext.Provider.Id
            };

            var actvityFeedWithPageCount = _activityFeedFacade.GetActivityFeedItemsPage(activityFeedSpec);

            var retActivityFeed = actvityFeedWithPageCount.Data.Select(af => new ActivityFeedDisplayViewModel
            {
                Body = af.Body,
                DeliveryStatus = af.DeliveryStatus,
                ListDeliveryStatusValue = GetDeliveryStatusText(af.DeliveryStatus),
                DeviceAddress = getDeviceAddress(af.DeviceAddress, af.DeviceCommonName),
                DeviceCommonName = af.DeviceCommonName,
                EventId = af.EventId,
                DisplayEventDate = _provider.SystemToVpsDateFormated(af.EventTime),
                DisplayEventTime = _provider.SystemToVpsTimeFormated(af.EventTime),
                EventType = af.EventType,
                NoResponse = af.NoResponse,
                Publisher = af.Publisher,
                RespondedText = af.RespondedText,
                Sent = af.Sent,
                Status = af.Status,
                Title = af.Title,
                UserId = af.UserId,
                ProviderName = RuntimeContext.Provider.ProviderName,
                DeviceName = af.DeviceName,
                IsFirstResponded = af.IsFirstResponded,
                DetailDeliveryStatus = convertDeliveryStatus(GetDeliveryStatusText(af.DeliveryStatus)),
                DeliveryState = af.DeliveryState,
                DisplayRespondedDate = _provider.SystemToVpsDateFormated(af.ResponseDate),
                DisplayRespondedTime = _provider.SystemToVpsTimeFormated(af.ResponseDate),
                LocalizedStatus = convertAlertStatus(af.Status),
                LocalizedDeliveryStatus = convertDeliveryStatus(GetDeliveryStatusText(af.DeliveryStatus))
            });


            ViewBag.Data = retActivityFeed;
            ViewBag.CountOfRecords = actvityFeedWithPageCount.Count;

            var pdfSpec = new PdfGridConfiguration(4);

            var builder = new StringBuilder();
            builder.AppendFormat(IWSResources.ActivityFeed_CountOfActivities, actvityFeedWithPageCount.Count);

            if (activityFeedSpec.MinEventTime.HasValue && activityFeedSpec.MaxEventTime.HasValue)
            {
                builder.Append(" ");
                builder.AppendFormat(IWSResources.ActivityFeed_DateBetween, activityFeedSpec.MinEventTime.GetValueOrDefault().ToVpsDateString(), activityFeedSpec.MaxEventTime.Value.AddDays(-1).ToVpsDateString());
            }
            else
            {
                if (activityFeedSpec.MinEventTime.HasValue)
                {
                    builder.Append(" ");
                    builder.AppendFormat(IWSResources.ActivityFeed_DateFrom, activityFeedSpec.MinEventTime.GetValueOrDefault().ToVpsDateString());
                }

                if (activityFeedSpec.MaxEventTime.HasValue)
                {
                    builder.Append(" ");
                    builder.AppendFormat(IWSResources.ActivityFeed_DateBefore, activityFeedSpec.MaxEventTime.Value.AddDays(-1).ToVpsDateString());
                }
            }

            if (activityFeedSpec.SearchString.IsNotNullOrEmpty())
            {
                builder.Append(" ");
                builder.AppendFormat(IWSResources.ActivityFeed_MatchingTerm, activityFeedSpec.SearchString);
            }

            var user = _userFacade.GetUserBySpec(new UserSpec { UserId = activityFeedSpec.UserId });
            pdfSpec.PageTitle = IWSResources.ActivityFeed_ExportPDF_PageTitle + ": " + user.GetDisplayName();

            ViewBag.PdfSpec = pdfSpec;
            ViewBag.TimeZone = RuntimeContext.Provider.GetVpsTimeZoneFromId().DisplayName;
            ViewBag.SearchCriteria = builder.ToString();
            try
            {
                MVCToPDF.ResultFileName = FileNameFormats.GetFormattedFileName("Activities", "pdf");
                MVCToPDF.RenderAsPDF();
            }
            catch (HttpException ex)
            {

            }
            return View("~/Views/UserManager/_ActivityFeedListPdf.cshtml");
        }


        [HttpPost]
        public ActionResult GetActivityResponse(int alertId, int userId)
        {

            var activityFeedSpec = new ActivityFeedSpec
            {
                EventType = ActivityFeedType.AlertResponse,
                AlertId = alertId,
                ProviderId = RuntimeContext.Provider.Id,
                UserId = userId,
            };

            var activityFeeds = _activityFeedFacade.GetActivityFeedsBySpec(activityFeedSpec);
            var retActivityFeed = activityFeeds.OrderByDescending(af => af.ResponseDate).Select(af => new
            {
                af.Body,
                af.DeliveryStatus,
                ListDeliveryStatusValue = GetDeliveryStatusText(af.DeliveryStatus),
                DeviceAddress = getDeviceAddress(af.DeviceAddress, af.DeviceCommonName),
                af.DeviceCommonName,
                af.EventId,
                DisplayEventDate = _provider.SystemToVpsDateFormated(af.EventTime),
                DisplayEventTime = _provider.SystemToVpsTimeFormated(af.EventTime),
                af.EventType,
                af.NoResponse,
                af.Publisher,
                af.RespondedText,
                DisplayRespondedDate = _provider.SystemToVpsDateFormated(af.ResponseDate),
                DisplayRespondedTime = _provider.SystemToVpsTimeFormated(af.ResponseDate),
                af.Sent,
                af.Status,
                af.Title,
                af.UserId,
                RuntimeContext.Provider.ProviderName,
                af.DeviceName,
                af.IsFirstResponded,
                DetailDeliveryStatus = GetDeliveryStatusText(af.DeliveryStatus),
                af.DeliveryState,
            });
            return Json(retActivityFeed);
        }

        [HttpPost]
        [RenderAsPDF(AutoConvert = false)]
        [FileDownloadCookie]

        public ActionResult DetailsToPdf(int alertId, int userId)
        {
            var activityFeedSpec = new ActivityFeedSpec
            {
                EventType = ActivityFeedType.AlertResponse,
                AlertId = alertId,
				ProviderId = RuntimeContext.Provider.Id,
                UserId = userId
            };

            var feed = _activityFeedFacade.GetActivityFeedBySpec(
				new ActivityFeedSpec
				{
					ProviderId = RuntimeContext.Provider.Id,
					AlertId = alertId,
					EventType = ActivityFeedType.Alert,
					UserId = userId
				});

            if(feed != null && feed.Body != null)
                feed.Body = Regex.Replace(feed.Body, @"[\n]+", "<br />");

            var activityFeeds = _activityFeedFacade.GetActivityFeedsBySpec(activityFeedSpec);

           var retActivityFeed = activityFeeds.Select(af => new ActivityFeedDisplayViewModel
            {

                Body = af.Body,
                DeliveryStatus = af.DeliveryStatus,
                ListDeliveryStatusValue = GetDeliveryStatusText(af.DeliveryStatus),
                DeviceAddress = getDeviceAddress(af.DeviceAddress,af.DeviceCommonName),
                DeviceCommonName = af.DeviceCommonName,
                EventId = af.EventId,
                DisplayEventDate = _provider.SystemToVpsDateFormated(af.EventTime),
                DisplayEventTime = _provider.SystemToVpsTimeFormated(af.EventTime),
                EventType = af.EventType,
                NoResponse = af.NoResponse,
                Publisher = af.Publisher,
                RespondedText = af.RespondedText,
                Sent = af.Sent,
                Status = af.Status,
                Title = af.Title,
                UserId = af.UserId,
                ProviderName = RuntimeContext.Provider.ProviderName,
                DeviceName = af.DeviceName,
                IsFirstResponded = af.IsFirstResponded,
                DetailDeliveryStatus = GetDeliveryStatusText(af.DeliveryStatus),
                DeliveryState = af.DeliveryState,
                   LocalizedDeliveryStatus= convertDeliveryStatus(GetDeliveryStatusText(af.DeliveryStatus)),
                DisplayRespondedDate = _provider.SystemToVpsDateFormated(af.ResponseDate),
                DisplayRespondedTime = _provider.SystemToVpsTimeFormated(af.ResponseDate)
            });

            var firstOne = feed;
            var pdfSpec = new PdfGridConfiguration(4);
            var user = _userFacade.GetUserBySpec(new UserSpec { UserId = userId });
            pdfSpec.PageTitle = IWSResources.ActivityFeed_List_ActivityDetailsFor + " " + user.GetDisplayName();
            ViewBag.PdfSpec = pdfSpec;
            if (retActivityFeed.HasValue())
            {
                ViewBag.Data = retActivityFeed;
                var firstResponse = retActivityFeed.SingleOrDefault(x => x.IsFirstResponded == 1);
                ViewBag.FirstResponse = firstResponse;
            }
            else
            {
                ViewBag.Data = null;
                ViewBag.FirstResponse = null;
            }
            
            ViewBag.ProviderName = RuntimeContext.Provider.ProviderName;
            ViewBag.ActivityDetail = firstOne;
            ViewBag.DisplayEventDateTime = _provider.SystemToVpsDateFormated(firstOne.EventTime) + " " + _provider.SystemToVpsTimeFormated(firstOne.EventTime);
            ViewBag.TimeZone = RuntimeContext.Provider.GetVpsTimeZoneFromId().DisplayName;

            MVCToPDF.ResultFileName = FileNameFormats.GetFormattedFileName("Activity-Details", "pdf");
            MVCToPDF.RenderAsPDF();
            return View("~/Views/UserManager/_ActivityFeedDetailsPdf.cshtml");

        }

        public ActionResult GetAlertResponseOptions(int alertId)
        {
            return Json("");
        }

        // [HttpPost]
        public ActionResult SaveAlertResponseToDB(int alertId, int userId, string responseText)
        {
            return Json("");
        }


        public class GetActivityFeedParam
        {
            public GetActivityFeedParam()
            {
                page = 1;
                pageSize = 25;
                sortBy = "eventTime";
                sortOrder = "DESC";
            }

            public int? alertId { get; set; }
            public int userId { get; set; }
            public int page { get; set; }
            public int pageSize { get; set; }
            public string sortBy { get; set; }
            public string sortOrder { get; set; }
            public string searchTerm { get; set; }
            public DateTime? dateFrom { get; set; }
            public DateTime? dateTo { get; set; }

        }

    }
}