﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AtHoc.Infrastructure.Log;
using AtHoc.IWS.Business.Domain.Authorization;
using AtHoc.IWS.Business.Domain.Events;
using AtHoc.IWS.Business.Domain.Media;
using AtHoc.IWS.Business.Domain.Organization;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Business.Domain.Reports;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Systems;
using AtHoc.IWS.Business.Domain.VirtualSystem;
using AtHoc.IWS.Web.Helpers;

namespace AtHoc.IWS.Web.Controllers
{



    public class LanguageController : Controller
    {
        private readonly ILanguageFacade _languageFacade;
        private readonly ILogService _logService;

        public LanguageController(ILanguageFacade languageFacade, ILogService logService)
        {
            _languageFacade = languageFacade;
            _logService = logService;

        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            return View();
        }
        /// <summary>
        /// /
        /// </summary>
        /// <returns></returns>
        public JsonResult GetLanguages()
        {
            try
            {
                if (Session["LangList"] == null)
                {
                    var cultureLanguages = _languageFacade.GetLanguages();
                    var language = cultureLanguages.OrderBy(t => t.LanguageName).Select(t => new { Code = t.LocalCode, Name = t.LanguageName, }).ToList();
                    Session["LangList"] = language;
                }
                var languages = Session["LangList"];

                return Json(new
                {
                    Success = true,
                    Data = languages,
                });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new
                {
                    Success = false,
                    Data = "",
                });
            }
        }

    }
}