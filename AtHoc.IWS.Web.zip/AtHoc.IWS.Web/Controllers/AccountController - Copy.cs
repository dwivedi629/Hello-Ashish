﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.Entity.Core;
using System.Globalization;
using System.Linq;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using AtHoc.Global.Resources;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Encryption;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Web.Mvc.ActionFilters;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Data.SearchSpec;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.Accountability;
using AtHoc.IWS.Business.Domain.Accountability.Specs;
using AtHoc.IWS.Business.Domain.Authorization;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Entities.Accountability.DatabaseModel;
using AtHoc.IWS.Business.Domain.Entities.Accountability.ObjectModel;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Business.Domain.Users.Impl;
using AtHoc.IWS.Business.Domain.Users.Impl.Search;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.IWS.Web.Areas.Settings;
using AtHoc.IWS.Web.Areas.Settings.Controllers;
using AtHoc.IWS.Web.Configurations.Constants;
using AtHoc.IWS.Web.Filters;
using AtHoc.IWS.Web.Helpers;
using AtHoc.IWS.Web.Models.Accountability;
using AtHoc.IWS.Web.Models.Accoutability;
using AtHoc.IWS.Web.Models.Publishing;
using AtHoc.IWS.Web.Models.Shared;
using AtHoc.IWS.Web.Models.UserManager;
using AtHoc.Publishing;
using AtHoc.Systems;
using EO.Pdf;
using EO.Pdf.Mvc;
using Newtonsoft.Json;
using Scenario = AtHoc.IWS.Business.Domain.Entities.Scenario;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.Global.Resources.Interfaces;
using ActionType = AtHoc.IWS.Business.Domain.Entities.ActionType;
using System.Web.SessionState;

namespace AtHoc.IWS.Web.Controllers
{
    [SessionState(SessionStateBehavior.ReadOnly)] //This will unblock asynchronous process.
    public class AccountController : Controller
    {

        private readonly IScenarioFacade _scenarioFacade;
        private readonly ILogService _logService;
        private readonly IPublishingDomainToModel _publishingDomainToModel;
        private readonly IPublishingModelToDomain _publishingModelToDomain;
        private readonly IAccountabilityFacade _accountabiltyFacade;
        private readonly IAlertFacade _alertFacade;
        private readonly IPublishingFacade _publishingFacade;
        private readonly IPlaceHolderFacade _placeholderFacade;
        private readonly IOperatorDetailsFacade _operatorDetailsFacade;
        private readonly IUserFacade _userFacade;
        private readonly ICustomAttributeFacade _customAttributeFacade;
        private readonly IAccountabilityFacade _accountabilityFacade;
        private readonly IUserManagerHelper _userManagerHelper;
        private readonly IAuthFacade _authFacade;
        private readonly IGlobalEntityLocaleFacade _globalEntityLocaleFacade;

        public AccountController(IAccountabilityFacade accountabiltyFacade, IUserManagerHelper userManagerHelper, IAccountabilityFacade accountabilityFacade, IUserFacade userFacade, ICustomAttributeFacade customAttributeFacade, IScenarioFacade scenarioFacade, ILogService logService, IPlaceHolderFacade placeholderFacade, IPublishingDomainToModel publishingDomainToModel, IPublishingModelToDomain publishingModelToDomain, IAlertFacade alertFacade, IPublishingFacade publishingFacade, IOperatorDetailsFacade operatorDetailsFacade, IAuthFacade authFacade, IGlobalEntityLocaleFacade globalEntityLocaleFacade)
        {
            _accountabiltyFacade = accountabiltyFacade;
            _scenarioFacade = scenarioFacade;
            _logService = logService;
            _publishingDomainToModel = publishingDomainToModel;
            _publishingModelToDomain = publishingModelToDomain;
            _alertFacade = alertFacade;
            _publishingFacade = publishingFacade;
            _placeholderFacade = placeholderFacade;
            _operatorDetailsFacade = operatorDetailsFacade;
            _accountabilityFacade = accountabilityFacade;
            _userFacade = userFacade;
            _customAttributeFacade = customAttributeFacade;
            _userManagerHelper = userManagerHelper;
            _authFacade = authFacade;
            _globalEntityLocaleFacade = globalEntityLocaleFacade;
        }

        #region Templates
        /// <summary>
        /// To get the template list view.
        /// </summary>
        /// <returns>template list view.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public ActionResult Index()
        {
            if (!RuntimeContext.Provider.FeatureMatrix.IsAccountabilitySupported)
            {
                ViewBag.NotSupportedMessage = IWSResources.Account_Accountability_Support_Message;
                return View("_NotSupported");
            }
            ViewBag.TopicToHighlight = MenuTopicsId.accountability;
            return Templates();
        }

        /// <summary>
        /// To get the template list view.
        /// </summary>
        /// <returns>template list view.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public ActionResult Templates()
        {
            if (!RuntimeContext.Provider.FeatureMatrix.IsAccountabilitySupported)
            {
                ViewBag.NotSupportedMessage = IWSResources.Account_Accountability_Support_Message;
                return View("_NotSupported");
            }



            ViewBag.TopicToHighlight = MenuTopicsId.accountability;
            var provider = RuntimeContext.Provider;

            var vpsTimeZOne = RuntimeContext.Provider.GetVpsTimeZoneFromId();
            ViewBag.DateFormat = provider.GetDateFormat();
            ViewBag.DateTimeFormat = provider.GetDateTimeFormat();
            ViewBag.VPSTimeZone = vpsTimeZOne;
            ViewBag.UtcOffsetInMinutes = vpsTimeZOne.BaseUtcOffset.TotalMinutes;
            ViewBag.VPSOffsetFromSystemInMinutes = provider.VPSOffsetFromSystemInMinutes();
            ViewBag.SupportsDaylightSavingTime = vpsTimeZOne.SupportsDaylightSavingTime;
            ViewBag.OperatorName = RuntimeContext.Operator.DisplayName;
            ViewBag.CurrentDateTime = provider.CurrentSystemTimeToVps().ToString(CultureInfo.InvariantCulture);
            ViewBag.PA = true;
            ViewBag.PlaceHolderItems = new JavaScriptSerializer().Serialize(_placeholderFacade.GetPlaceHolderList(provider.Id, RuntimeContext.OperatorId).Where(i => i.IsSystem));

            SetDataForPublisher();

            return View("Templates");
        }
        /// <summary>
        /// To get the template list.
        /// </summary>
        /// <param name="spec">template specification.</param>
        /// <returns>Json containnig the template list.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public JsonResult GetTemplates(AccountabilityTemplateSpec spec)
        {
            try
            {
                var providerId = RuntimeContext.Provider.Id;
                var operatorId = RuntimeContext.OperatorId;
                spec.ProviderId = providerId;
                var templates = _accountabiltyFacade.GetTemplates(operatorId, spec, false);
                if (templates == null)
                {
                    _logService.Error(() => IWSResources.PA_Template_Load_Failed_Message);
                    return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
                }

                var models = new List<TemplateModel>();
                templates.ToList().ForEach(template => models.Add(TemplateModel.FromTemplate(template, false)));


                return Json(new { Success = true, Items = models, TotalCount = models.Count });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
            }
        }
        /// <summary>
        /// To get the template details.
        /// </summary>
        /// <param name="id">template Id.</param>
        /// <returns>Json containnig the template details.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public JsonResult GetTemplate(int id = 0)
        {
            try
            {
                var provider = RuntimeContext.Provider;
                var providerId = provider.Id;

                var operatorId = RuntimeContext.OperatorId;
                var template = _accountabiltyFacade.GetTemplate(providerId, operatorId, id);
                TemplateModel tm = TemplateModel.FromTemplate(template, true);
                if (id == 0) //setting defaults for a new template
                {
                    var defaultType = tm.AlertBaseModel.Content.Types.FirstOrDefault(kv => kv.LogicalId == "Safety");
                    if (defaultType != null)
                        tm.AlertBaseModel.Content.TypeId = defaultType.Id;

                    tm.AlertBaseModel.Content.SeverityId = (int)Priority.Informational;
                    tm.AlertBaseModel.ScenarioSettings.AccountabilityWorkflow.IsAccountabilityMessagesVisible = true;
                    tm.AlertBaseModel.ScenarioSettings.AccountabilityWorkflow.IsAccountabilityMessagesReadonly = false;
                    tm.AlertBaseModel.ScenarioSettings.AccountabilityWorkflow.IsContentSeverityVisible = true;
                    tm.AlertBaseModel.ScenarioSettings.AccountabilityWorkflow.IsContentTypeVisible = true;
                    tm.AlertBaseModel.ScenarioSettings.Content.DropboxEnabled = false;

                    // IWS - 26241 - Setting Body to empty
                    tm.AlertBaseModel.Content.Body = string.Empty;
                }
                var ph = _placeholderFacade.GetEventPlaceholders(provider.BaseLocale).ToList();
                tm.ProcessSectionModel.EventPlaceholderList = ph;
                tm.OfficerSectionModel.EventPlaceholderList = ph;
                return Json(new { Success = true, Messages = IWSResources.PA_Template_Error_Message, Data = tm });


            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
            }
        }

        /// <summary>
        /// To get the event from template.
        /// </summary>
        /// <param name="id">templateId.</param>
        /// <returns>Json containing the template Model.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public JsonResult GetEventFromTemplate(int id)
        {
            try
            {
                var provider = RuntimeContext.Provider;
                var providerId = provider.Id;

                var operatorId = RuntimeContext.OperatorId;
                //todo return an Event object and not Tempalte
                var template = _accountabiltyFacade.GetTemplate(providerId, operatorId, id);
                var tm = TemplateModel.FromTemplate(template, true);
                tm.AlertBaseModel.Context = PublishingContext.AccountEvent;
                var ph = _placeholderFacade.GetEventPlaceholders(provider.BaseLocale).ToList();
                tm.ProcessSectionModel.EventPlaceholderList = ph;
                tm.OfficerSectionModel.EventPlaceholderList = ph;
                return Json(new { Success = true, Messages = IWSResources.PA_Template_Error_Message, Data = tm });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
            }
        }

        /// <summary>
        /// To duplicate the template.
        /// </summary>
        /// <param name="id">templateId.</param>
        /// <returns>Json containing templateModel.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public JsonResult DuplicateTemplate(int id)
        {
            try
            {
                var providerId = RuntimeContext.Provider.Id;
                var operatorId = RuntimeContext.OperatorId;
                var template = _accountabiltyFacade.DuplicateTemplate(providerId, operatorId, id);
                template.Name = string.Format("{0} {1}", template.Name, IWSResources.Scenario_DuplicateText);
                TemplateModel tm = TemplateModel.FromTemplate(template, true);
                var ph = _placeholderFacade.GetEventPlaceholders(template.Locale.LocaleCode).ToList();
                tm.ProcessSectionModel.EventPlaceholderList = ph;
                tm.OfficerSectionModel.EventPlaceholderList = ph;
                return Json(new { Success = true, Messages = IWSResources.PA_Template_Error_Message, Data = tm });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
            }
        }

        /// <summary>
        /// To save the template.
        /// </summary>
        /// <param name="template">templateModel.</param>
        /// <returns>Json containnig the success status and sucees message.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.Modify, ActionType.Modify })]
        [HttpPost]
        public JsonResult SaveTemplate(TemplateModel template)
        {
            try
            {
                var operatorId = RuntimeContext.OperatorId;
                var at = template.ToTemplate(_publishingModelToDomain);
                int templateId;
                if (at.TemplateId > 0)
                {
                    templateId = at.TemplateId;
                    var ret = _accountabiltyFacade.UpdateTemplate(operatorId, at);
                    if (!ret)
                    {
                        _logService.Error(() => IWSResources.PA_Template_Update_Failed_Message);
                        return Json(new { Success = false, Messages = IWSResources.PA_Template_Update_Failed_Message });
                    }
                }
                else
                {
                    templateId = _accountabiltyFacade.CreateTemplate(operatorId, at);
                    if (templateId <= 0)
                    {
                        _logService.Error(() => IWSResources.PA_Template_Create_Failed_Message);
                        return Json(new { Success = false, Messages = IWSResources.PA_Template_Create_Failed_Message });
                    }
                }

                return Json(new { Success = true, Data = templateId });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
            }
        }

        /// <summary>
        /// to remove templates.
        /// </summary>
        /// <param name="ids">templateIds.</param>
        /// <returns>Json containing the success status and message.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.Modify, ActionType.Modify })]
        [HttpPost]
        public JsonResult RemoveTemplate(List<int> ids)
        {
            try
            {
                var providerId = RuntimeContext.Provider.Id;
                var operatorId = RuntimeContext.OperatorId;
                bool ret = _accountabiltyFacade.DeleteTemplates(providerId, operatorId, ids);
                if (!ret)
                {
                    _logService.Error(() => IWSResources.PA_Template_Remove_Failed_Message);
                    return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
                }
                return Json(new { Success = true, Data = ids });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
            }
        }

        /// <summary>
        /// To remove events.
        /// </summary>
        /// <param name="ids">event Ids.</param>
        /// <returns>Json containing success statsus nad success message.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.Modify, ActionType.Modify })]
        [HttpPost]
        public JsonResult RemoveEvent(List<int> ids)
        {
            try
            {
                var providerId = RuntimeContext.Provider.Id;
                var operatorId = RuntimeContext.OperatorId;
                bool ret = _accountabiltyFacade.DeleteEvents(providerId, operatorId, ids);
                if (!ret)
                {
                    _logService.Error(() => IWSResources.PA_Event_Remove_Failed_Message);
                    return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
                }
                return Json(new { Success = true, Data = ids });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
            }
        }

        #endregion

        #region Events

        /// <summary>
        /// To get the event details view.
        /// </summary>
        /// <param name="id">eventId.</param>
        /// <param name="providerId">providerId.</param>
        /// <param name="showNewDialog">showNewDialog flag.</param>
        /// <param name="tab">defalut tab to be selected</param>
        /// <returns>Event view.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public ActionResult Events(int id = 0, int providerId = 0, bool showNewDialog = false, string tab = "")
        {
            var isSoftRedirect = TempData["isSoftRedirect"] != null && (bool)TempData["isSoftRedirect"];//isSoftRedirect : indicates if the internal redirect (used when Deeplink to the users tab in the specific event in the specific VPS)
            if (!isSoftRedirect && providerId != 0 && providerId != RuntimeContext.ProviderId && id > 0)
            {
                TempData["isSoftRedirect"] = true;
                var redirectUrl = "/athoc-iws/account/Events?id=" + id + "&providerId=" + providerId + "&tab=" + tab;
                var controller = DependencyResolver.Current.GetService<ChangeOrganizationController>();
                controller.ControllerContext = new ControllerContext(Request.RequestContext, controller);
                return controller.SetOrganization(providerId, redirectUrl);
            }
            if (!RuntimeContext.Provider.FeatureMatrix.IsAccountabilitySupported)
            {
                ViewBag.NotSupportedMessage = IWSResources.Account_Accountability_Support_Message;
                return View("_NotSupported");
            }

            var provider = RuntimeContext.Provider;
            ViewBag.TopicToHighlight = MenuTopicsId.accountability;
            var vpsTimeZOne = RuntimeContext.Provider.GetVpsTimeZoneFromId();
            ViewBag.DateFormat = provider.GetDateFormat();
            ViewBag.DateTimeFormat = provider.GetDateTimeFormat();
            ViewBag.VPSTimeZone = vpsTimeZOne;
            ViewBag.UtcOffsetInMinutes = vpsTimeZOne.BaseUtcOffset.TotalMinutes;
            ViewBag.VPSOffsetFromSystemInMinutes = provider.VPSOffsetFromSystemInMinutes();
            ViewBag.SupportsDaylightSavingTime = vpsTimeZOne.SupportsDaylightSavingTime;
            ViewBag.OperatorName = RuntimeContext.Operator.DisplayName;
            ViewBag.CurrentDateTime = provider.CurrentSystemTimeToVps().ToString(CultureInfo.InvariantCulture);
            ViewBag.PA = true;
            ViewBag.PlaceHolderItems = new JavaScriptSerializer().Serialize(_placeholderFacade.GetPlaceHolderList(provider.Id, RuntimeContext.OperatorId).Where(i => i.IsSystem));
            ViewBag.ProviderType = RuntimeContext.Provider.ProviderType();
            ViewBag.ShowNewDialog = showNewDialog;
            ViewBag.selectedTab = tab;
            var operatorAccess = _operatorDetailsFacade.GetOperatorAccess(new OperatorAccessSpec
            {
                OperatorId = RuntimeContext.OperatorId,
                ProviderId = RuntimeContext.ProviderId
            });
            ViewBag.IsPAManagerRole = _authFacade.HasAccess(operatorAccess, SystemObject.AccountabilityEvent, ActionType.Modify);
            ViewBag.CanViewAlert = _authFacade.HasAccess(operatorAccess, SystemObject.Alert, ActionType.View);

            if (id > 0 && _accountabilityFacade.CheckEventValidity(id, RuntimeContext.ProviderId, RuntimeContext.OperatorId, RuntimeContext.Provider.BaseLocale))
            {
                SetDataForPublisher();
                ViewBag.EventId = new JavaScriptSerializer().Serialize(id);
                ViewBag.IsValidEvent = "true";
                return View("EventDetails");
            }

            ViewBag.IsValidEvent = "false";
            return View("Events");
        }

        /// <summary>
        /// To get the new Event View.
        /// </summary>
        /// <returns>Event View.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.Modify })]
        public ActionResult NewEvent()
        {
            return Events(showNewDialog: true);
        }


        /// <summary>
        /// To get the events.
        /// </summary>
        /// <param name="spec">event specification.</param>
        /// <returns>Json containnig list of events.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public JsonResult GetEvents(AccountabilityEventSearchSpec spec)
        {
            try
            {
                var operatorAccess = _operatorDetailsFacade.GetOperatorAccess(new OperatorAccessSpec
                {
                    OperatorId = RuntimeContext.OperatorId,
                    ProviderId = RuntimeContext.ProviderId
                });

                var accessCollection = operatorAccess as OperatorAccess[] ?? operatorAccess.ToArray();

                var eventPublishRole = _authFacade.HasAccess(accessCollection, SystemObject.AccountabilityEvent, ActionType.Publish);
                var alertPublishRole = _authFacade.HasAccess(accessCollection, SystemObject.Alert, ActionType.Publish);

                var providerId = RuntimeContext.Provider.Id;
                var operatorId = RuntimeContext.OperatorId;
                //Uncomment below lines when Enterprise with Sub VPS events are enabled for listing
                if (spec.VpsId == 0)
                {
                    spec.VpsId = RuntimeContext.ProviderId;
                    spec.IncludeSubVps = true;
                }
                //spec.VpsId = RuntimeContext.ProviderId;
                //spec.IncludeSubVps = false;

                try //wrap in try/catch to check if any invalid datetime has been passed
                {
                    if (!String.IsNullOrEmpty(spec.StartDate))
                    {
                        var fromDate = Convert.ToDateTime(spec.StartDate);
                        var fromDateSys = RuntimeContext.Provider.VpsToSystemTime(fromDate);
                        spec.StartDate = fromDateSys.ToString();//set from date in system time because search sproc searches in system time                    
                    }

                    if (!String.IsNullOrEmpty(spec.EndDate))
                    {
                        var toDate = Convert.ToDateTime(spec.EndDate);
                        toDate = toDate.AddDays(1).AddSeconds(-1);//toDate should be up to 11:59:59PM                        
                        var toDateSys = RuntimeContext.Provider.VpsToSystemTime(toDate);
                        spec.EndDate = toDateSys.ToString();//set to date in system time because search sproc searches in system time                   
                    }
                }
                catch (Exception ex)
                {
                    _logService.Error(() => ex);
                }

                var events = _accountabiltyFacade.GetAccountabilitySearchResult(spec);

                if (events == null)
                {
                    _logService.Error(() => IWSResources.PA_Event_Get_Failed_Message);
                    return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
                }

                var models = new List<AccountabilityEventSearchResultModel>();
                events.GetList().ToList().ForEach(eventItem => models.Add(AccountabilityEventSearchResultModel.FromSearchResult(eventItem)));
                //TODO: Do not need avoid in foreach
                models.ForEach(e =>
                {
                    e.IsAlertPublisher = alertPublishRole;
                    e.IsEventPublisher = eventPublishRole;
                });

                return Json(new { Success = true, Items = models, TotalCount = events.TotalCount() });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
            }
        }

        /// <summary>
        /// To get the event details.
        /// </summary>
        /// <param name="id">eventId.</param>
        /// <returns>Json containnig event details.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public JsonResult GetEvent(int id, int providerId = 0)
        {
            try
            {
                var eventModel = GetEventModel(id, providerId);
                if (eventModel != null)
                    return Json(new JsonResponseModel(true, eventModel), JsonRequestBehavior.AllowGet);
                var ex = new ObjectNotFoundException("Accountablity Event not found");
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.PA_Event_Get_Failed_Message });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.PA_Event_Get_Failed_Message });
            }
        }

        /// <summary>
        /// To get event details.
        /// </summary>
        /// <param name="id">event Id</param>
        /// <returns>Event Model.</returns>
        private EventModel GetEventModel(int id, int providerId)
        {
            try
            {
                var accessCollection = RuntimeContext.Operator.OperatorAccess;
                var opeatorAccess = accessCollection as OperatorAccess[] ?? accessCollection.ToArray();
                var eventPublishRole = _authFacade.HasAccess(opeatorAccess, SystemObject.AccountabilityEvent, ActionType.Publish);
                var alertPublishRole = _authFacade.HasAccess(opeatorAccess, SystemObject.Alert, ActionType.Publish);
                // This feature is moved to 92 release so commenting it for now, IWS-26999 implementation
                if (id > 0)
                {
                    providerId = _accountabilityFacade.GetEventProviderId(RuntimeContext.ProviderId, id);
                    if (providerId == 0) { providerId = RuntimeContext.ProviderId; }
                }

                providerId = RuntimeContext.ProviderId;
                var provider = RuntimeContext.Provider;
                var operatorId = RuntimeContext.OperatorId;

                var acctSpec = new AccountabilityEventSpec();

                acctSpec.ProviderId = providerId;
                acctSpec.OperatorId = operatorId;
                acctSpec.EventId = id;
                acctSpec.IncludeReminderAlertDetails = true;
                acctSpec.IsLoadBaseDetails = true;


                var acctEvent = _accountabiltyFacade.GetEvent(acctSpec);
                if (acctEvent == null)
                {
                    var ex = new ObjectNotFoundException("Accountablity Event not found");
                    LogService.Current.Error(() => ex);
                    return null;
                }
                EventModel eventModel = EventModel.FromEvent(acctEvent, true, true);
                eventModel.IsAlertPublisher = alertPublishRole;
                eventModel.IsEventPublisher = eventPublishRole;
                var ph = _placeholderFacade.GetEventPlaceholders(provider.BaseLocale).ToList();
                eventModel.ProcessSectionModel.EventPlaceholderList = ph;
                eventModel.OfficerSectionModel.EventPlaceholderList = ph;
                eventModel.IsCurrentVps = acctEvent.ProviderId == RuntimeContext.ProviderId;
                if (eventModel.RuntimeModel != null && eventModel.RuntimeModel.Activity != null && eventModel.RuntimeModel.Activity.SentAlerts != null)
                {
                    eventModel.RuntimeModel.Activity.SentAlerts.ForEach(e => e.IsAlertPublisher = alertPublishRole);
                }

                return eventModel;
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return null;
            }
        }
        /// <summary>
        /// To get the eventRuntime.
        /// </summary>
        /// <param name="id">eventId.</param>
        /// <returns>Json containnig event runtime.</returns>
        public JsonResult GetEventRuntime(int id)
        {
            try
            {
                var providerId = RuntimeContext.Provider.Id;
                var operatorId = RuntimeContext.OperatorId;

                var operatorAccess = _operatorDetailsFacade.GetOperatorAccess(new OperatorAccessSpec
                {
                    OperatorId = RuntimeContext.OperatorId,
                    ProviderId = RuntimeContext.ProviderId
                });
                var accessCollection = operatorAccess as OperatorAccess[] ?? operatorAccess.ToArray();
                var alertPublishRole = _authFacade.HasAccess(accessCollection, SystemObject.Alert, ActionType.Publish);

                //todo: move to backend
                var acctSpec = new AccountabilityEventSpec
                {
                    ProviderId = providerId,
                    OperatorId = operatorId,
                    EventId = id,
                    IncludeReminderAlertDetails = true
                };
                var eventObj = _accountabiltyFacade.GetEvent(acctSpec);
                var runtimeModel = EventModel.GetRuntimeModel(eventObj);

                if (runtimeModel != null && runtimeModel.Activity != null && runtimeModel.Activity.SentAlerts != null)
                {
                    runtimeModel.Activity.SentAlerts.ForEach(e => e.IsAlertPublisher = alertPublishRole);
                }

                return Json(new JsonResponseModel(true, runtimeModel));
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
            }
        }

        /// <summary>
        /// To start the event .
        /// </summary>
        /// <param name="id">eventId.</param>
        /// <returns>event view.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.Modify })]
        public ActionResult StartEvent(int id)
        {
            var provider = RuntimeContext.Provider;
            ViewBag.FromTemplateId = id;

            var vpsTimeZOne = RuntimeContext.Provider.GetVpsTimeZoneFromId();
            ViewBag.DateFormat = provider.GetDateFormat();
            ViewBag.DateTimeFormat = provider.GetDateTimeFormat();
            ViewBag.VPSTimeZone = vpsTimeZOne;
            ViewBag.UtcOffsetInMinutes = vpsTimeZOne.BaseUtcOffset.TotalMinutes;
            ViewBag.VPSOffsetFromSystemInMinutes = provider.VPSOffsetFromSystemInMinutes();
            ViewBag.SupportsDaylightSavingTime = vpsTimeZOne.SupportsDaylightSavingTime;
            ViewBag.OperatorName = RuntimeContext.Operator.DisplayName;
            ViewBag.CurrentDateTime = provider.CurrentSystemTimeToVps().ToString(CultureInfo.InvariantCulture);
            ViewBag.PA = true;
            ViewBag.PlaceHolderItems = new JavaScriptSerializer().Serialize(_placeholderFacade.GetPlaceHolderList(provider.Id, RuntimeContext.OperatorId).Where(i => i.IsSystem));

            SetDataForPublisher();

            return View();
        }

        /// <summary>
        /// To end events.
        /// </summary>
        /// <param name="ids">EventIds.</param>
        /// <returns>Json contannig the sucess status and eventIds.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.Modify })]
        [HttpPost]
        public ActionResult EndEvents(List<int> ids)
        {
            if (ids == null || ids.Count == 0)
            {
                _logService.Error(() => IWSResources.PA_Event_Wrong_ArgumentIds_Message);
                return Json(new JsonResponseModel(false, IWSResources.PA_Event_End_Failed_Message));
            }
            var providerId = RuntimeContext.ProviderId;
            var operatorId = RuntimeContext.OperatorId;
            //todo, for now it is just ending the event            
            var success = _accountabiltyFacade.EndEvents(providerId, operatorId, ids);
            if (!success)
            {
                _logService.Error(() => IWSResources.PA_Event_End_Failed_Message);
                return Json(new JsonResponseModel(false, IWSResources.PA_Event_End_Failed_Message));
            }

            return Json(new JsonResponseModel(true, ids));
        }

        // todo: refactor names;)
        /// <summary>
        /// To start the event Now.
        /// </summary>
        /// <param name="template">event template Object.</param>
        /// <returns>Json containnig success status and message.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        [HttpPost]
        public JsonResult StartEventNow(TemplateModel template)
        {
            try
            {
                var providerId = RuntimeContext.Provider.Id;
                var operatorId = RuntimeContext.OperatorId;
                AccountabilityTemplate at = template.ToTemplate(_publishingModelToDomain);
                at.ProviderId = providerId;

                _publishingModelToDomain.SetAlertSpec(template.AlertBaseModel, at, providerId, AtHocSystem.Local.ConnectDeviceCommonName, operatorId);
                // todo: review. a hack. need to set the channel id in order to save theh base template
                at.AlertSpec.Category = Category.GetCategory(template.AlertBaseModel.ScenarioSection.ChannelId);
                at.TemplateId = template.Id;
                at.AlertSpec.LiveDuration = template.ProcessSectionModel.LiveDuration.ToDuration();

                var ret = _accountabiltyFacade.CreateEvent(operatorId, providerId, at);
                if (ret <= 0)
                {
                    _logService.Error(() => IWSResources.PA_Event_Start_Failed_Message);
                    return Json(new { Success = false, Messages = IWSResources.PA_Event_Start_Failed_Message });
                }

                return Json(new { Success = true, Data = ret, providerId = providerId });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.PA_Event_Start_Failed_Message });
            }
        }

        /// <summary>
        /// To get the event alerts.
        /// </summary>
        /// <param name="id">eventId.</param>
        /// <returns>Json containnig event alerts list.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public JsonResult GetEventAlerts(int id)
        {
            var providerId = RuntimeContext.ProviderId;
            var operatorId = RuntimeContext.OperatorId;
            var acctSpec = new AccountabilityEventSpec();
            acctSpec.ProviderId = providerId;
            acctSpec.OperatorId = operatorId;
            acctSpec.EventId = id;
            acctSpec.IncludeReminderAlertDetails = true;
            acctSpec.IsLoadBaseDetails = false;

            var eventObj = _accountabiltyFacade.GetEvent(acctSpec);

            if (eventObj == null)
            {
                _logService.Error(() => "Failed to Get EventAlerts");
                return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
            }

            var alertPublishRole = _authFacade.HasAccess(RuntimeContext.RefreshedOperatorContext.OperatorAccess, SystemObject.Alert, ActionType.Publish);

            ActivityModel model = EventModel.GetActivityModel(eventObj);
            if (model != null && model.SentAlerts != null)
            {
                model.SentAlerts.ForEach(e => e.IsAlertPublisher = alertPublishRole);
            }
            return Json(new JsonResponseModel(true, model));
        }

        /// <summary>
        /// To get the Organization Heirarchy Breakdown.
        /// </summary>
        /// <param name="id">eventId.</param>
        /// <param name="sessionId">sessionid.</param>
        /// <param name="hierarchyId">hierarchyId.</param>
        /// <returns>Event Org Hierarchy report Json.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public JsonResult GetHeirarchyBreakdown(int id, int sessionId = 0, int hierarchyId = 0)
        {

            var orgReport = EventHierarchyBreakdown(id, sessionId, hierarchyId);
            return Json(new JsonResponseModel(true, orgReport));
        }

        /// <summary>
        /// Get accountability search results.
        /// </summary>
        /// <param name="spec">Search specs.</param>
        /// <returns>Search results.</returns>
        //[IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        //public JsonResult GetAccountabilitySearchResult(AccountabilitySearchSpec spec)
        //{
        //    var searchResult = _accountabilityFacade.GetAccountabilitySearchResult(spec);
        //    return Json(new JsonResponseModel(true, searchResult));
        //}

        private EventOrganizationReportBuilder EventHierarchyBreakdown(int id, int sessionId = 0, int hierarchyId = 0)
        {
            List<EventOrganizationReport> eventOrganizationReport;
            var data = new List<EventOrganizationReportEntry>();
            List<EventOrganizationHierarchy> eventOrganizationHierarchy;
            var hierarchyBreadcrumbNodes = new List<EventOrganizationHierarchyEntry>();
            var operatorId = RuntimeContext.OperatorId;
            var isEnterprise = RuntimeContext.Provider.ProviderType() == VPSType.Enterprise;

            var spec = new EventStatusByOrgSpec()
            {
                EventId = id,
                ProviderId = RuntimeContext.ProviderId,
                OperatorId = operatorId,
                BaseLocale = RuntimeContext.Provider.BaseLocale,
                SessionId = sessionId,
                HierarchyId = hierarchyId
            };

            _accountabilityFacade.GetEventStatusByOrg(spec, isEnterprise, out eventOrganizationReport, out eventOrganizationHierarchy);

            eventOrganizationReport.ForEach(entry =>
                data.Add(EventOrganizationReportEntry.FromEventOrganizationReport(entry)));

            eventOrganizationHierarchy.ForEach(entry =>
                hierarchyBreadcrumbNodes.Add(EventOrganizationHierarchyEntry.FromEventOrganizationHierarchy(entry)));

            var orgReport = new EventOrganizationReportBuilder()
            {
                Entries = data,
                Hierarchy = hierarchyBreadcrumbNodes
            };
            return orgReport;
        }
        [NonAction]
        private Dictionary<string, object> GetEventUsers(int page = 1, int pageSize = 25,
            string sortBy = "DisplayName", string sortOrder = "ASC", // DONE
          string attributeCSV = null,
          string[] searchStrings = null,
          string searchFlow = null,
          int eventId = 0,
          int responseType = -1,
            int[] hierarchyIds = null,
            int[] listItemIds = null,
            string queryCriteria = null,
            string staticQueryCriteria = null,
            int[] attributeValueIds = null,
            int[] attributeIds = null,
            int nproviderId = 0,
            int sessionId = 0
           )
        {
            var providerId = nproviderId == 0 ? RuntimeContext.ProviderId : nproviderId;
            var locale = RuntimeContext.Provider.BaseLocale;
            var paDefaultColumnsList = new List<string>
            {
                AttributeCommonNames.StatusId,
                AttributeCommonNames.UpdatedFrom,
                AttributeCommonNames.UpdatedOn,
                AttributeCommonNames.Comments
            };

            // Construct Event Criteria for getting the user list
            #region "Event Criteria"
            EventBasedCriteria eventBasedCriteria;
            var statusAttributeList = _accountabilityFacade.GetEventStatusAttributeList(eventId, providerId).ToList();
            if (statusAttributeList.Count == 0)
                statusAttributeList.Add(new AccountabilityEventStatusAttribute
                {
                    AttributeId = 0,
                    CommonName = "",
                    SortOrder = 0,
                    ValueId = 0,
                    ValueName = IWSResources.PAEvent_NoStatus
                });
            switch (responseType)
            {
                case -1:
                    eventBasedCriteria = new EventBasedCriteria(new[] { eventId }, EventCriteriaOperator.TARGETED);
                    break;
                case 0:
                    eventBasedCriteria = new EventBasedCriteria(new[] { eventId }, EventCriteriaOperator.NORESPONSE);
                    break;
                default:
                    var responseTypes = new List<string>();
                    if (responseType != -2)
                        responseTypes.Add("RESPONSE" + responseType);
                    else
                        responseTypes = statusAttributeList.Select(e => "RESPONSE" + e.SortOrder).ToList();
                    eventBasedCriteria = new EventBasedCriteria(new[] { eventId }, EventCriteriaOperator.MULTIPLERESPONSE,
                     responseTypes);
                    break;
            }

            #endregion "Event Criteria"

            // Get User List based on Event and Search Criteria  honoring the user selected columns
            #region "Search Criteria"
            //To get user status and status updated on fields in search result
            var userFacade = new UserFacade();
            var statusAttributeId = userFacade.GetStatusAttributeId();
            var statusValueIds = userFacade.GetStatusValueIds(new[] { AttributeCommonNames.ValidEnabledUsers });
            var statusCriteria = UserSearchHelper.GetUserStatusCriteria(statusAttributeId, statusValueIds);

            var srchArgs = new UserSearchArgs(false, true, false)
            {
                ProviderId = providerId,
                ProviderCriteria = UserSearchHelper.GetProviderCriteria(providerId, nproviderId == 0),
                OperatorCriteria =
                    UserSearchHelper.GetOperatorUserBaseCriteria(RuntimeContext.OperatorId, RuntimeContext.ProviderId),
                Paging =
            {
                PageNo = page,
                UsersPerPage = pageSize,
                SortColumn = paDefaultColumnsList.Contains(sortBy) ? "PAEVENT:" + sortBy : sortBy,
                IsAsc = !sortOrder.Equals("DESC", StringComparison.CurrentCultureIgnoreCase)
            },
                TargetCriteria = eventBasedCriteria & statusCriteria,
                EventAttributeNames =
                new List<string>(new[]
                    {
                    AttributeCommonNames.EventId, AttributeCommonNames.StatusId, AttributeCommonNames.UpdatedOn,
                    AttributeCommonNames.CreatedOn, AttributeCommonNames.UpdatedFrom, AttributeCommonNames.Comments
                }),
                EventId = eventId,
                Options = { GetUsers = true }

            };
            if (searchStrings != null)
            {
                srchArgs.TargetCriteria = srchArgs.TargetCriteria &
                                          UserSearchHelper.GetQuickSearchCriteria(providerId,
                                              RuntimeContext.Provider.BaseLocale, searchStrings);
            }
            // HIERARCHIES TO INCLUDE (NODES : Organizational Hierarchy, Distribution Lists)
            if (hierarchyIds != null)
            {
                srchArgs.TargetCriteria = srchArgs.TargetCriteria &
                                          UserSearchHelper.GetHierarchyCriteria(providerId, locale,
                                             hierarchyIds);
            }

            srchArgs = _userManagerHelper.GetAdvancedCriteria(srchArgs, queryCriteria, staticQueryCriteria, attributeValueIds, attributeIds, listItemIds);

            // LISTS TO INCLUDE (Dynamic Lists, Static Lists, Tree)
            if (listItemIds != null)
            {
                if (!string.IsNullOrEmpty(queryCriteria) || !string.IsNullOrEmpty(staticQueryCriteria) || searchStrings != null)
                {
                    srchArgs.TargetCriteria = srchArgs.TargetCriteria & UserSearchHelper.GetListCriteria(providerId, listItemIds);
                }
                else
                {
                    if (hierarchyIds != null || attributeValueIds != null || attributeIds != null)
                        srchArgs.TargetCriteria = srchArgs.TargetCriteria | UserSearchHelper.GetListCriteria(providerId, listItemIds);
                    else
                        srchArgs.TargetCriteria = srchArgs.TargetCriteria & UserSearchHelper.GetListCriteria(providerId, listItemIds);
                }

            }

            // Get Attribute List
            var userColumns = _userManagerHelper.GetAttributeList(attributeCSV, UserListType.AccountabilityList);
            var columns = (List<CustomViewColumn>)userColumns["HeaderColumns"];
            srchArgs.DeviceNames = (List<string>)userColumns["DeviceColumns"];
            srchArgs.AttributeNames = (List<string>)userColumns["AttributeColumns"];


            #endregion "Search Criteria"

            // Mapping status and operator values since DB does not return values
            #region "Update Accountability Status and Operator Source"

            ContextSearchResult user = null;
            var isRestricted = _userFacade.HasRestrictedUserBase(RuntimeContext.OperatorId);
            if (isRestricted && sessionId == 0)
            {
                srchArgs.Options.EnableSession = true;
                srchArgs.Options.GetUsers = true;
                srchArgs.Options.GetCountsOnly = true;
                srchArgs.Options.ReuseSessionDuration = 600;
                user = _userFacade.SearchUsersByContext(srchArgs);
                sessionId = user.SessionId;
            }

            if (sessionId > 0 && user == null)
            {
                var argsSession = new UserSearchSession(false, true, false, srchArgs.Paging.PageNo,
                    srchArgs.Paging.UsersPerPage, srchArgs.Paging.SortColumn, sortOrder)
                {
                    SessionId = sessionId,
                    DeviceNames = srchArgs.DeviceNames,
                    AttributeNames = srchArgs.AttributeNames,
                    TargetCriteria = srchArgs.TargetCriteria,
                };
                var sessionUser = _userFacade.SearchUsersBySession(argsSession);
                user = new ContextSearchResult()
                {
                    Users = sessionUser.Users,
                    SearchResultCount = sessionUser.SearchResultCount,
                    EnabledUserBaseCount = sessionUser.EnabledUserCount,
                    MaxEnabledUserCount = sessionUser.MaxEnabledUserCount,
                    UsersDataTable = sessionUser.UsersDataTable
                };
            }
            else
                user = _userFacade.SearchUsersByContext(srchArgs);
            // Map Status and Operator
            user.Users.ForEach(eventAttr =>
            {

                if (eventAttr.UserAttributes[AttributeCommonNames.UpdatedFrom].ToUpper() != "OPERATOR")
                    eventAttr.UserAttributes[AttributeCommonNames.UpdatedFrom] = IWSResources.PAEvent_SelfOperator;
                else
                    eventAttr.UserAttributes[AttributeCommonNames.UpdatedFrom] = IWSResources.PAEvent_Operator;

                if (eventAttr.UserAttributes[AttributeCommonNames.StatusId] != "0")
                    eventAttr.UserAttributes[AttributeCommonNames.StatusId] =
                        statusAttributeList.Where(
                            e => e.SortOrder == Convert.ToInt32(eventAttr.UserAttributes[AttributeCommonNames.StatusId]))
                            .Select(e => e.ValueName)
                            .FirstOrDefault();
                else
                {
                    eventAttr.UserAttributes[AttributeCommonNames.StatusId] = string.Empty;
                    eventAttr.UserAttributes[AttributeCommonNames.UpdatedFrom] = string.Empty;
                }

                eventAttr.UserAttributes[AttributeCommonNames.UpdatedOn] =
                    string.IsNullOrEmpty(eventAttr.UserAttributes[AttributeCommonNames.UpdatedOn])
                        ? string.Empty
                        : RuntimeContext.Provider.SystemToVpsDateTimeFormated(
                            Convert.ToDateTime(eventAttr.UserAttributes[AttributeCommonNames.UpdatedOn]));
            });
            #endregion "Update Accountability Status with Operator Source"

            var userDetails = new Dictionary<string, object>
            {
                {"Columns", columns},
                {"Users", user},
                {"ResponseTypes", statusAttributeList},
                {"SessionId",sessionId}
            };
            return userDetails;
        }

        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public JsonResult GetUserByEvent(int page = 1, int pageSize = 25, string sortBy = "LOGIN_ID",
            string sortOrder = "ASC", // DONE
          string attributeCSV = null,
          string[] searchStrings = null,
          string searchFlow = null,
          int eventId = 0,
          int responseType = -1,
            int[] hierarchyIds = null,
             int[] listItemIds = null,
             string queryCriteria = null,
            string staticQueryCriteria = null,
            int[] attributeValueIds = null,
            int[] attributeIds = null,
            int providerId = 0,
             int sessionId = 0
          )
        {

            var userDetails = GetEventUsers(page, pageSize, sortBy, sortOrder, attributeCSV, searchStrings, searchFlow, eventId, responseType, hierarchyIds, listItemIds, queryCriteria, staticQueryCriteria, attributeValueIds, attributeIds, providerId, sessionId);
            var columns = (List<CustomViewColumn>)userDetails["Columns"];
            var users = (ContextSearchResult)userDetails["Users"];
            var statusAttributeList = (List<AccountabilityEventStatusAttribute>)userDetails["ResponseTypes"];
            var result =
                Json(
                    new
                    {
                        Columns = columns.OrderBy(e => e.ColumnDisplayOrder).ToList(),
                        Rows = users.Users,
                        TotalCounts = users.SearchResultCount,
                        ResponseTypes = statusAttributeList,
                        SessionId = userDetails["SessionId"]
                    });

            return result;
        }

        /// <summary>
        /// To update the events users status .
        /// </summary>
        /// <param name="userStatusList">user status list.</param>
        /// <returns>Json containing the success status and Message.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        [HttpPost]
        public JsonResult UpdateEventUsersStatus(UserStatusUpdateSpec userStatusList)
        {
            try
            {
                userStatusList.UpdatedFrom = "Operator";

                userStatusList.OperatorId = RuntimeContext.OperatorId;
                userStatusList.UpdatedBy = RuntimeContext.OperatorId;
                var success = _accountabiltyFacade.UpdateUsersStatus(userStatusList, RuntimeContext.ProviderId,
                    RuntimeContext.Provider.BaseLocale);
                return Json(new JsonResponseModel(true, success));
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.PA_Template_Error_Message });
            }
        }

        /// <summary>
        /// To get event user status attributes.
        /// </summary>
        /// <param name="id">eventId</param>
        /// <returns>status attribute list.</returns>
        public JsonResult GetEventUserStatus(int id)
        {
            var statusAttribute = _accountabiltyFacade.GetEventStatusAttributeList(id, RuntimeContext.ProviderId);
            return Json(new { Success = true, Data = JsonConvert.SerializeObject(statusAttribute) });
        }

        #endregion

        #region Export

        /// <summary>
        /// To export the event details.
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [FileDownloadCookie]
        [RenderAsPDF(AutoConvert = false)]
        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public ActionResult ExportEventDetails(AccountEventExportSpec exportSpec)
        {
            var orgHrchyOptions = exportSpec.OrgHrchyOptions;
            var provider = RuntimeContext.Provider;
            #region setup veiwbags
            var vpsTimeZOne = provider.GetVpsTimeZoneFromId();
            ViewBag.UtcOffsetInMinutes = vpsTimeZOne.BaseUtcOffset.TotalMinutes;
            ViewBag.VPSOffsetFromSystemInMinutes = provider.VPSOffsetFromSystemInMinutes();
            ViewBag.Description = exportSpec.ExportDescription;
            var vpscontactPhone = provider.ContactPhone ?? provider.ContactPhone2;
            ViewBag.GeneratedBy = provider.ProviderName + (!string.IsNullOrEmpty(vpscontactPhone) ? " | " + vpscontactPhone : "");
            ViewBag.GeneratedOn = provider.CurrentSystemTimeToVpsTimeString();
            ViewBag.VpsLogoId = provider.WebImageId;
            var eventDetails = GetEventModel(exportSpec.EventId, provider.Id);
            ViewBag.EventDetails = Json(new JsonResponseModel(true, eventDetails), JsonRequestBehavior.AllowGet);
            ViewBag.includeSummary = exportSpec.IncludeSummary;
            #endregion
            var isCsv = exportSpec.DownloadFormat == "csv";
            Dictionary<string, object> usersDetails = null;
            EventOrganizationReportBuilder orgHrchy = null;
            AccountPdfHtmlDataModel accountPdfData = null;
            if (exportSpec.IncludeHierarchy)//Include Hierarchy.
            {
                var evnetIdforHrchy = orgHrchyOptions["id"];
                var orgHrchyId = 0;
                if (orgHrchyOptions.Count == 2)
                    orgHrchyId = orgHrchyOptions["hierarchyId"];
                orgHrchy = EventHierarchyBreakdown(id: evnetIdforHrchy, hierarchyId: orgHrchyId);
            }
            if (exportSpec.IncludeUsers)//Include Users.
            {
                var uniqueAttributeCsv = "";
                if (isCsv && exportSpec.UserAttriubuteCsv != null)
                {
                    var uniques = exportSpec.UserAttriubuteCsv.Split(',').Distinct().ToList();
                    uniqueAttributeCsv = string.Join(",", uniques.ToArray());
                }
                var pageSize = 0;
                if (!isCsv)
                    pageSize = 1000;//if not CSV export then display only 1000 user entries.
                usersDetails = GetEventUsers(eventId: exportSpec.EventId, searchStrings: exportSpec.UserSearchOptions,
                   responseType: exportSpec.UserResponseType, pageSize: pageSize, attributeCSV: uniqueAttributeCsv, sortBy: exportSpec.SortUsersBy,
                   sortOrder: exportSpec.UserSortingOrder, queryCriteria: exportSpec.UsrrQueryCriteria, hierarchyIds: exportSpec.UserhierarchyIds, listItemIds: exportSpec.UserlistItemIds, attributeIds: exportSpec.UserattributeIds, nproviderId: exportSpec.ProviderId);
            }
            try
            {
                if (isCsv)
                {
                    //download the CSV .
                    var csvGridData = AccountExportHelper.GetAccountCsvExportData(exportSpec, eventDetails, usersDetails, orgHrchy);//Get the CSV data.
                    var csvData = new CsvDataModel() { GridData = csvGridData };
                    var fileName = FileNameFormats.GetFormattedFileName(eventDetails.Name, "csv");
                    return File(csvData.GridData, "text/csv", fileName);
                }
                //download the PDF.
                accountPdfData = AccountExportHelper.GetAccountPdfExportData(exportSpec, eventDetails, usersDetails, orgHrchy);//Get the PDF data.
                var eventName = eventDetails.Name.Length > 10 ? eventDetails.Name.Substring(0, 10) : eventDetails.Name;//PDF file name should contain initial 10 characters of the eventName.
                MVCToPDF.ResultFileName = FileNameFormats.GetFormattedFileName(eventName, "pdf");
                MVCToPDF.RenderAsPDF((sender, args) =>
                {
                    HtmlToPdf.Options.Cookies.Add(new System.Net.Cookie(Constants.IwsLanguageCookie, CookieEncryption.Protect(provider.BaseLocale)));

                }, null);
                //Make a log entry
                AtHoc.Operators.OperationAuditor.LogAction(RuntimeContext.OperatorId, RuntimeContext.ProviderId, "ACE06", "ACE", eventDetails.Name, exportSpec.EventId, "", "");
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
            }
            return View("Export", accountPdfData);
        }


        #endregion

        /// <summary>
        /// To get the scenarios.
        /// </summary>
        /// <returns>Json containing scenario list.</returns>
        public JsonResult GetScenarios()
        {
            try
            {
                var providerId = RuntimeContext.ProviderId;
                var operatorId = RuntimeContext.OperatorId;
                var spec = new ScenarioSearchSpec();
                var scenarioList = _scenarioFacade.GetScenarios(providerId, operatorId, spec);
                var data = scenarioList.Select(s =>
                    new Scenario
                                {
                                    ScenarioId = s.ScenarioId,
                                    Name = s.Name.TruncateText(),
                                    ChannelName = s.ChannelName.TruncateText(),
                                    PublishedOn = s.PublishedOn,
                                    PublishedOnString = RuntimeContext.Provider.SystemToVpsDateTimeFormated(s.PublishedOn),
                                    DateTimeFormat = RuntimeContext.Provider.GetDateTimeFormat(),
                                    NextRecurrence = s.NextRecurrence,
                                    NextRecurrenceString = (s.IsRecurringScenario) ? RuntimeContext.Provider.SystemToVpsDateTimeFormated(s.NextRecurrence) : string.Empty,
                                    UpdatedBy = s.UpdatedBy,
                                    IsQuickPublish = s.IsQuickPublish,
                                    IsReadyForPublish = s.IsReadyForPublish,
                                    IsDefaultforNewAlert = s.IsDefaultforNewAlert,
                                    IsDefaultforNewScenario = s.IsDefaultforNewScenario,
                                    IsSystem = _scenarioFacade.IsSystemScenario(s.CommonName),
                                    IsRecurringScenario = s.IsRecurringScenario,
                                    Description = s.Description.TruncateText(),
                                    AlertTitle = s.AlertTitle.TruncateText(),
                                    AlertBody = s.AlertBody.TruncateText()
                                });

                data = data.Where(s => !s.IsSystem && s.IsReadyForPublish).OrderBy(s => s.Name);
                return Json(new { Success = true, Data = data });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                //returning HTTP status code in addition to the exception message.
                return Json(new { Success = false, Message = ex.Message });
                //return new HttpStatusCodeResult(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        /// <summary>
        /// to get the PA specific resources.
        /// </summary>
        /// <returns>Json containing respurces.</returns>
        [OutputCache(Duration = 0, VaryByParam = "none")]
        public JsonResult GetResource()
        {
            const string resourcePatternForPa = "PAEvent_|Account_|PA_";
            var paResourceSet = IWSResources.ResourceManager.GetResourceSetByPattern(resourcePatternForPa);
            return Json(new { Resources = paResourceSet }, JsonRequestBehavior.AllowGet);
        }

        private void SetDataForPublisher()
        {
            var provider = RuntimeContext.RefreshedProviderContext;
            var user = RuntimeContext.RefreshedOperatorContext;
            ViewBag.IsAffiliate = (provider.ProviderType() == VPSType.Affiliate25 || provider.ProviderType() == VPSType.Affiliate25Template);
            ViewBag.DateFormat = provider.GetDateFormat();
            //Publisher settings
            var publisherSettings = _publishingDomainToModel.GetPublisherSettings(provider);
            ViewBag.PublisherSettings = publisherSettings;
        }

        /// <summary>
        /// To replace the AcctMessagePlaceholders for Preview.
        /// </summary>
        /// <param name="model">accountabilityMessagePlaceholderModel with placeholders.</param>
        /// <returns>accountabilityMessagePlaceholderModel with replaced placeholder values.</returns>
        [IWSAuthorize(new[] { SystemObject.AccountabilityEvent, SystemObject.AccountabilityTemplate }, new[] { ActionType.View })]
        public JsonResult ReplaceAccountabilityMessagePlaceholdersForPreview(AccountabilityMessagePlaceholderModel model)
        {
            try
            {
                var resultModel = new AccountabilityMessagePlaceholderModel();

                var sysPlaceholders = new SystemPlaceholders();
                //get system placeholders
                var systemPlaceholders = _placeholderFacade.GetSystemPlaceHolders(sysPlaceholders, RuntimeContext.Provider.Id, RuntimeContext.OperatorId);

                var eventPlaceholders = _placeholderFacade.GetEventPlaceholders(RuntimeContext.Provider.BaseLocale);
                var accountabilityStartDatePlaceHolderDisplayName =
                    eventPlaceholders.Single(
                        e => e.EventPlaceholderId == AccountabilityEventPlaceHolders.AccountabilityStartTime.ToString())
                        .EventPlaceholderDisplayName;

                var vpsDateTimeString =
                    RuntimeContext.Provider.CurrentSystemTimeToVps().ToString(RuntimeContext.Provider.GetTimeFormat());

                if (model.PlaceholderReplacementModels.HasValue())
                {
                    resultModel.PlaceholderReplacementModels =
                        (from mdl in model.PlaceholderReplacementModels.Where(t => t.Value != null)
                         let value = _accountabilityFacade.ReplacePlaceHoldersForPreviewMessage(mdl.Value, systemPlaceholders, accountabilityStartDatePlaceHolderDisplayName, vpsDateTimeString)
                         select new PlaceholderReplacementModel { FieldId = mdl.FieldId, Value = value, GroupId = mdl.GroupId, IsTextArea = mdl.IsTextArea, Label = mdl.Label, MinLength = mdl.MinLength, MaxLength = mdl.MaxLength }).ToList();
                }

                return Json(new { Model = resultModel, Success = true });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Alert_Placeholder_ReplaceErrorMsg });
            }
        }

        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public ActionResult GetEventContentPreview()
        {
            return PartialView("Publishing/_ContentDetail");
        }

        [IWSAuthorize(new[] { SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public ActionResult GetReviewAndStartDialog()
        {
            ViewBag.PA = true;
            var provider = RuntimeContext.RefreshedProviderContext;
            var publisherSettings = _publishingDomainToModel.GetPublisherSettings(provider);
            ViewBag.PublisherSettings = publisherSettings;
            return PartialView("_ReviewAndStartDialog");
        }


        #region Event Advanced Search
        private object GetAccountabilityEventStatus()
        {
            var excludeStatus = new List<AccountabilityEventStatus> { AccountabilityEventStatus.Deleted, AccountabilityEventStatus.Publishing };

            var resource = new System.Resources.ResourceManager(Constants.resourceAssembly, typeof(IWSResources).Assembly);

            var accountabilityStatus = (from AccountabilityEventStatus status in Enum.GetValues(typeof(AccountabilityEventStatus))
                                        where !excludeStatus.Contains(status)
                                        select new
                                        {
                                            Id = status.ToString(),
                                            Name = resource.GetString(status.GetDescription(), System.Threading.Thread.CurrentThread.CurrentUICulture) ?? status.ToString()
                                        }).ToList();
            return accountabilityStatus;


        }
        private IEnumerable<KeyValueModel> GetAccountabilityStatusAttributes(string providerId)
        {
            var statusAttributes = new List<KeyValueModel>();
            var customAttributes = _accountabilityFacade.GetStatusAttibutes(RuntimeContext.ProviderId,
            RuntimeContext.Provider.BaseLocale);

            if (string.IsNullOrEmpty(providerId))
            {
                statusAttributes.AddRange(customAttributes.SelectMany(x => x.Item2).Distinct().Where(attribute => attribute != null).Select(attribute =>
                    new KeyValueModel() { Name = attribute.AttributeName, Id = attribute.Id }));
            }
            else
            {
                //filter based on providerId
                var tupleProviderPublishers = customAttributes.FirstOrDefault(x => Convert.ToString(x.Item1) == providerId);
                if (tupleProviderPublishers != null)
                {
                    statusAttributes.AddRange(tupleProviderPublishers.Item2.Where(attribute => attribute != null).Select(attribute =>
                    new KeyValueModel() { Name = attribute.AttributeName, Id = attribute.Id }));
                }
            }
            return statusAttributes;
        }

        private object GetOperatorsWhoPublishedAccountabilityEvent(string providerId)
        {
            var publishers = new List<KeyValueModel>();
            var operatorList = _accountabilityFacade.GetAccountabilityEventPublishers(RuntimeContext.ProviderId);

            if (string.IsNullOrEmpty(providerId))
            {
                publishers.AddRange(operatorList.SelectMany(x => x.Item2).Distinct().OrderBy(x => x.Value).Select(x => new KeyValueModel { Name = x.Value, Id = x.Key }));
            }
            else
            {
                //filter based on providerId
                var tupleProviderPublishers = operatorList.FirstOrDefault(x => Convert.ToString(x.Item1) == providerId);
                if (tupleProviderPublishers != null)
                {
                    publishers.AddRange(tupleProviderPublishers.Item2.OrderBy(x => x.Value).Select(x => new KeyValueModel { Name = x.Value, Id = x.Key }));
                }
            }
            return publishers;
        }

        private IEnumerable<KeyValueModel> GetSeverityList()
        {
            var data = _globalEntityLocaleFacade.GetLocalizedEntity(SettingsHelper.Severities(), RuntimeContext.Provider.BaseLocale)
                               .Select(
                                    p =>
                                        new KeyValueModel
                                        {
                                            Id = (int)(Priority)Enum.Parse(typeof(Priority), p.SeverityId),
                                            Name = p.SeverityName
                                        }).ToList();
            return data;

        }

        private IEnumerable<KeyValueModel> GetSubOrganizationData()
        {

            var organizations = _accountabilityFacade.GetSubOrganizationsWithNames(RuntimeContext.ProviderId);
            var data = new List<KeyValueModel>();
            data.Add(new KeyValueModel() { Id = RuntimeContext.ProviderId, Name = RuntimeContext.Provider.ProviderName });
            data.AddRange(organizations.Select(org => new KeyValueModel() { Id = org.Key, Name = org.Value }));


            return data;
        }

        [IWSAuthorize(new[] { SystemObject.AccountabilityEvent }, new[] { ActionType.View })]
        public JsonResult PopulateAdvancedSearchFilters(string providerId, string[] filterIds)
        {
            var data = new ArrayList();
            try
            {
                foreach (var filterId in filterIds)
                {
                    if (filterId == "Status")
                    {
                        data.Add(new { FilterId = filterId, Data = GetAccountabilityEventStatus() });
                    }
                    else if (filterId == "StatusAttribute")
                    {
                        data.Add(new { FilterId = filterId, Data = GetAccountabilityStatusAttributes(providerId) });
                    }
                    else if (filterId == "Publisher")
                    {
                        data.Add(new { FilterId = filterId, Data = GetOperatorsWhoPublishedAccountabilityEvent(providerId) });
                    }
                    else if (filterId == "Severity")
                    {
                        data.Add(new { FilterId = filterId, Data = GetSeverityList() });
                    }
                    else if (filterId == "Organization")
                    {
                        data.Add(new { FilterId = filterId, Data = GetSubOrganizationData() });
                    }
                }

                return Json(new { Success = true, Data = data });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Alert_List_Error_Generic });
            }
        }

        #endregion
    }
}