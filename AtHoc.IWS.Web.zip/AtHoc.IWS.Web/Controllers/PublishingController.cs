﻿using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Security;
using AtHoc.Infrastructure.Log;
using AtHoc.Global.Resources;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;
using AtHoc.IWS.Business.Domain.Devices;
using AtHoc.IWS.Business.Domain.Devices.Spec;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Targeting.Spec;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Business.Domain.Targeting;
using AtHoc.IWS.Map;
using AtHoc.IWS.Web.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Web.Models.Publishing;
using AtHoc.IWS.Business.Domain.Reports;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Organization;
using AtHoc.IWS.Web.Filters;
using AtHoc.IWS.Web.Models.SearchCriteria;
using AtHoc.IWS.Business.Domain.Users.Impl.Search;
using AtHoc.Infrastructure.MediaWrapper;
using AtHoc.MediaServices;
using EnumerableExtensions = AtHoc.Infrastructure.Extensions.EnumerableExtensions;
using System.IO;
using System.Web.Script.Serialization;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using System.Web.SessionState;


namespace AtHoc.IWS.Web.Controllers
{
    [SessionState(SessionStateBehavior.ReadOnly)]
    public class PublishingController : Controller
    {
        private readonly IDeviceFacade _deviceFacade;
        private readonly IPublishingDomainToModel _publishingDomainToModel;
        private readonly ITargetingTreeFacade _targetingFacade;
        private readonly IUserFacade _userFacade;
        private readonly IUserReportsFacade _userReportsFacade;
        private readonly IOrganizationFacade _organizationFacade;
        private readonly IPublishingFacade _publishingFacade;
        private readonly ILogService _logService;
        private readonly IPublishingModelToDomain _publisherModelToDomain;
        private readonly ICustomAttributeCache _customAttributeCache;

        public PublishingController(IDeviceFacade deviceFacade,
                            IPublishingDomainToModel publishingDomainToModel,
                            ITargetingTreeFacade targetingFacade,
                            IUserFacade userFacade,
                            IUserReportsFacade userReportFacade,
                            IOrganizationFacade organizationFacade,
                            IPublishingFacade publishingFacade,
                            ILogService logService,
                            IPublishingModelToDomain publisherModelToDomain, ICustomAttributeCache customAttributeCache)
        {
            _deviceFacade = deviceFacade;
            _publishingDomainToModel = publishingDomainToModel;
            _targetingFacade = targetingFacade;
            _userFacade = userFacade;
            _userReportsFacade = userReportFacade;
            _organizationFacade = organizationFacade;
            _publishingFacade = publishingFacade;
            _logService = logService;
            _publisherModelToDomain = publisherModelToDomain;
            _customAttributeCache = customAttributeCache;
        }

        /// <summary>
        /// A combined call to get targeting and device list data
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.Alert, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public ActionResult GetTargetingAndDeviceData(PublishingContext context, int id = -1, string recipientType = null, int deviceId = 0)
        {
            int providerId = RuntimeContext.ProviderId;
            int operatorId = RuntimeContext.OperatorId;
            var alertBaseObj = _publisherModelToDomain.GetAlertBase(context, id, providerId, operatorId);

            var deviceList = _deviceFacade.GetDevicesBySpec(new DeviceSpec { ProviderId = providerId, EnabledOnly = true, IncludeDeviceGroup = true, IsMassDevice = false }, RuntimeContext.Provider.BaseLocale)
                                .Where(x => alertBaseObj.PublishLayoutConfig.Delivery.EnabledDevices.Contains(x.Id)).OrderBy(x => x.GroupId).ThenBy(x => x.GroupSortOrder)
                .Select(device => new Models.Publishing.Device
                {
                    DeviceName = device.Name,
                    DeviceId = device.Id,
                    Selected = deviceId > 0 ? deviceId == device.Id : ((alertBaseObj != null) ? alertBaseObj.AlertSpec.Delivery.IsDeviceTargeted(device.Id) : false),
                    GroupId = device.DeviceGroup.Id,
                    GroupName = device.DeviceGroup.Name,
                    GroupCommonName = device.DeviceGroup.CommonName,
                    WarningText = device.TargetingConfirmationText,
                    Reach = 0,
                    IsPhone = (device.DeviceGroup.CommonName.ToLower().Equals("phone")),
                    Enabled = true

                }).ToList();

            var allPhonesCount = deviceList.Where(d => d.GroupCommonName.ToLower().Equals("phone")).Count();


            var phoneDevices = deviceList.Where(d => d.Selected && d.GroupCommonName.ToLower().Equals("phone")).ToList();
            if (EnumerableExtensions.HasValue(phoneDevices))
            {
                foreach (var device in phoneDevices)
                {
                    try
                    {
                        device.DeliveryOrder = (alertBaseObj != null)
                            ? alertBaseObj.AlertSpec.Delivery.GetTargetedDeviceOrder(device.DeviceId)
                            : 0;
                    }
                    catch (Exception)
                    {
                    } //try getting delivery order
                }
            }

            var deviceGroups = GetDeviceGroupsFromDevice(deviceList);

            var targetingNodes = _targetingFacade.GetTargetingTreeNodes(new TargetingTreeSpec { ProviderId = providerId, UserId = operatorId }, ProviderAttributes);

            //TODO: Localized targetingNodes

            if (string.IsNullOrEmpty(recipientType))
            {
                _publishingDomainToModel.PopulateGroupTargetingSelection(targetingNodes,
                    alertBaseObj.AlertSpec.Targeting.TargetingCriteria);
            }
            else
            {

                targetingNodes.Clear();

            }
            return Json(new { TargetingTree = targetingNodes, Devices = deviceList, DeviceGroups = deviceGroups, PhoneCount = allPhonesCount }, JsonRequestBehavior.AllowGet);


        }

        /// <summary>
        ///  Returns list of localized custom attributes
        /// </summary>
        private CustomAttributeLookup ProviderAttributes
        {
            get
            {
                var customAttributes = CustomAttributesHelper.GetProviderAttributes(_customAttributeCache, RuntimeContext.ProviderId, RuntimeContext.Provider.BaseLocale, true, true).Where(x => x.EntityId == "USER").ToArray();
                return new CustomAttributeLookup(customAttributes);
            }
        }
        
        private IList<Models.Publishing.DeviceGroup> GetDeviceGroupsFromDevice(IList<Models.Publishing.Device> devices)
        {
            var group = string.Empty;
            var deviceGroups = new List<Models.Publishing.DeviceGroup>();
            foreach (var device in devices)
            {
                if (group != device.GroupName && device.GroupId.HasValue)
                {
                    device.GroupChange = true;
                    group = device.GroupName;
                    deviceGroups.Add(new Models.Publishing.DeviceGroup { GroupId = device.GroupId.Value, GroupName = device.GroupName });
                }
            }
            return deviceGroups;
        }
        /// <summary>
        /// Returns GeoCriteria from the given geojson
        /// </summary>
        /// <param name="geojson">The geojson string</param>
        /// <returns>List of Geojson criteria</returns>
        private IEnumerable<GeoCriteria> GetGeoCriterias(string geojson)
        {
            IList<GeoCriteria> geoCriterias = new List<GeoCriteria>();
            //var geojson1 =
            //    "{\"type\":\"FeatureCollection\",\"features\":[{\"type\":\"Feature\",\"geometry\":{\"coordinates\":[-122.32736206054688,37.53844451904297]},\"properties\":{\"name\":\"I have an emergency\",\"description\":\"\",\"editable\":false,\"isInbound\":true,\"symbol\":{\"type\":\"esriPMS\",\"url\":\"http://platformdev.athocdevo.com/client/map/iconimage/41\",\"width\":24,\"height\":24}}}]}";
            var fc = new FeatureCollection(geojson);
            //var wktList = LocationConverter.GetLocationAsWkt(geojson);
            if (fc.Features != null && fc.Features.Count > 0)
            {
                foreach (var f in fc.Features)
                {
                    if (f.Geometry.Type == Map.Geometry.Type.Polygon || f.Geometry.Type == Map.Geometry.Type.MultiPolygon)
                    {
                        geoCriterias.Add(new GeoCriteria(0, CriteriaOperator.IsInsideArea, f.Attributes["OBJECTID"].ToString()));
                    }
                }
            }
            return geoCriterias;
        }
        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.Alert, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public ActionResult RefreshContactInfo(TargetedUserCriteria criteria)
        {
            if (criteria.EntityId != 0)
            { //RETRIEV TARGETING INFO BASED ON ID
                criteria.ResetCriteria(); //reset any old targeted info that might have been submitted; in this context we want to retrieve targeted info from entity.
                var alertbase = _publisherModelToDomain.GetAlertBase(criteria.PublishingContext, criteria.EntityId,
                 RuntimeContext.ProviderId, RuntimeContext.OperatorId);
                _publishingDomainToModel.ExtractTargetAndDeviceInfoFromEntity(alertbase, RuntimeContext.ProviderId, RuntimeContext.OperatorId, _publishingFacade, ref criteria);
            }

            var srchArgsV2 = new UserSearchArgs(true, true, false)
            {
                ProviderId = RuntimeContext.ProviderId,
                ProviderCriteria = UserSearchHelper.GetProviderCriteria(RuntimeContext.ProviderId),
                OperatorCriteria = UserSearchHelper.GetOperatorUserBaseCriteria(RuntimeContext.OperatorId, RuntimeContext.ProviderId),
                TargetAllUserBase = criteria.rbtCriteria == null && criteria.IsAllUserBaseSelected,
                Options = { GetCountsOnly = true, EnableSession = true, ReuseSessionDuration = 300 }
            };

            var providerDetails = RuntimeContext.Provider;
            var providerId = RuntimeContext.ProviderId;
            var operatorId = RuntimeContext.OperatorId;

            var includeListsCriteriaTask =
                Task.Factory.StartNew(
                    () =>
                        UserSearchHelper.GetListCriteria(providerId, criteria.TargetedListIds,
                            accessType: AccessType.Target, ctxProviderId: providerId, ctxOperatorId: operatorId, operatorId: operatorId));

            var blockedListsCriteriaTask =
                Task.Factory.StartNew(
                    () =>
                        UserSearchHelper.GetListCriteria(providerId, criteria.BlockedListIds,
                            accessType: AccessType.Target, ctxProviderId: providerId, ctxOperatorId: operatorId, operatorId: operatorId));


            var individualUserIdCriteriaTask =
                Task.Factory.StartNew(() => UserSearchHelper.GetIndividualUserIdCriteria(criteria.TargetedUsers));

            var includeGeoCriteriaTask =
                Task.Factory.StartNew(
                    () =>
                        !string.IsNullOrEmpty(criteria.TargetedArea)
                            ? UserSearchHelper.GetIncludeGeographyCriteria(
                                GetGeoCriterias(criteria.TargetedArea) as List<GeoCriteria>, providerId)
                            : null);

            var blockedGroupsCriteriaTask = Task.Factory.StartNew(() =>
                UserSearchHelper.GetExcludeGroupsCriteria(criteria.BlockedAttributes.ToList())
                );

            var includeHierarchiesCriteriaTask = Task.Factory.StartNew(() =>
                UserSearchHelper.GetHierarchyCriteria(providerDetails.Id, providerDetails.BaseLocale,
                    criteria.TargetedHierarchyIds, providerId, operatorId, AccessType.Target));

            var blockHierarchiesCriteriaTask =
                Task.Factory.StartNew(
                    () =>
                        UserSearchHelper.GetHierarchyCriteria(providerDetails.Id, providerDetails.BaseLocale,
                            criteria.BlockedHierarchyIds, providerId, operatorId, AccessType.Target));

            Task.WaitAll(includeListsCriteriaTask, blockedListsCriteriaTask, individualUserIdCriteriaTask, includeGeoCriteriaTask, blockedGroupsCriteriaTask,
                includeHierarchiesCriteriaTask, blockHierarchiesCriteriaTask);


            var includeListsCriteria = includeListsCriteriaTask.Result;
            var blockedListsCriteria = blockedListsCriteriaTask.Result;
            var individualUserIdCriteria = individualUserIdCriteriaTask.Result;
            var includeGeoCriteria = includeGeoCriteriaTask.Result;
            var blockedGroupsCriteria = blockedGroupsCriteriaTask.Result;
            var includeHierarchiesCriteria = includeHierarchiesCriteriaTask.Result;
            var blockHierarchiesCriteria = blockHierarchiesCriteriaTask.Result;

            srchArgsV2.TargetUsers = criteria.TargetedUsers;

            srchArgsV2.BlockUsers = criteria.BlockedUsers;

            //ExpressionElement includeGeoCriteria = null;
            //if (!string.IsNullOrEmpty(criteria.TargetedArea))
            //{
            //    includeGeoCriteria = UserSearchHelper.GetIncludeGeographyCriteria(GetGeoCriterias(criteria.TargetedArea) as List<GeoCriteria>, RuntimeContext.ProviderId);
            //}

            var targetedAttributesList = new List<GenericCriteria>();
            ExpressionElement includeGroupsCriteria = null;
            // GROUPS Searchable Attributes TO INCLUDE
            foreach (var attr in criteria.TargetedAttributes)
            {
                targetedAttributesList.Add(attr);
                includeGroupsCriteria = includeGroupsCriteria | UserSearchHelper.GetGroupsCriteria(new[] { new List<GenericCriteria> { attr } });
            }


            // Advanced query criteria
            ExpressionElement customCriteria = null;
            if (criteria.TargetedCriteria != null)
            {
                var advancedSearch = InitializeAdvancedSearch(criteria.TargetedCriteria);
                if (advancedSearch.HasValue())
                {
                    customCriteria = UserSearchHelper.GetCustomCriteria(new[] { advancedSearch });
                }
            }
            else
            {
                if (criteria.rbtCriteria != null)
                {
                    if (criteria.rbtCriteria.EntityFilterId != null)
                    {
                        //RBT Criteria
                        var rbtCriterion = new List<GenericCriteria>();
                        if (string.IsNullOrEmpty(criteria.rbtCriteria.FillCountType))
                        {

                            if (criteria.rbtCriteria.AccountabilityEventId > 0)
                            {
                                customCriteria = new EventBasedCriteria(new[] { criteria.rbtCriteria.AccountabilityEventId },
                                    EventCriteriaOperator.MULTIPLERESPONSE,
                             new List<string>() { criteria.rbtCriteria.EntityFilterId.ToUpper() });
                            }
                            else
                            {
                                var rbtcriteria = new AlertCriteria
                                {
                                    Id = criteria.rbtCriteria.AlertId,
                                    Operator =
                                        (AlertCriteriaOperator)
                                            Enum.Parse(typeof(AlertCriteriaOperator),
                                                criteria.rbtCriteria.EntityFilterId.ToUpper()),
                                    Value = criteria.rbtCriteria.DeviceId > 0
                                        ? new List<int> { criteria.rbtCriteria.DeviceId }
                                        : new List<int>()
                                };
                                rbtCriterion.Add(rbtcriteria);
                                customCriteria = UserSearchHelper.GetCustomCriteria(new[] { rbtCriterion });
                            }
                        }
                        else
                        {
                            var rbtcriteria = new ResultBasedCriteria
                            {
                                Id = criteria.rbtCriteria.AlertId,
                                Operator =
                                    (AlertCriteriaOperator)
                                        Enum.Parse(typeof(AlertCriteriaOperator),
                                            criteria.rbtCriteria.EntityFilterId.ToUpper()),
                                ResultBasedOperator =
                                    (ResultBasedCriteriaOperator)
                                        Enum.Parse(typeof(ResultBasedCriteriaOperator),
                                            criteria.rbtCriteria.FillCountType.ToUpper()),
                                Value = criteria.rbtCriteria.DeviceId > 0
                                    ? new List<int> { criteria.rbtCriteria.DeviceId }
                                    : new List<int>()
                            };
                            rbtCriterion.Add(rbtcriteria);
                            customCriteria = UserSearchHelper.GetCustomCriteria(new[] { rbtCriterion });
                        }

                    }
                }
            }

            var statusAttributeId = _userFacade.GetStatusAttributeId();
            var statusValueIds = _userFacade.GetStatusValueIds(new[] { "VLD" });
            var statusCriteria = UserSearchHelper.GetUserStatusCriteria(statusAttributeId, statusValueIds);

            DeviceContactInformation deviceInfo;
            var userNodeList = new List<int>();

            if (srchArgsV2.TargetAllUserBase == false && includeListsCriteria == null &&
                includeHierarchiesCriteria == null && includeGroupsCriteria == null && customCriteria == null &&
                includeGeoCriteria == null && individualUserIdCriteria == null)
            {
                deviceInfo = _userReportsFacade.GetContactInfo(RuntimeContext.ProviderId, 0, criteria.SelectedDevices, 0);
                return Json(new { TotalCount = 0, ContactInfo = deviceInfo, SessionId = 0, IUT = userNodeList }, JsonRequestBehavior.AllowGet);
            }
            if (srchArgsV2.TargetAllUserBase)
            {
                srchArgsV2.TargetCriteria = statusCriteria;
            }
            else
            {
                if (individualUserIdCriteria != null && (includeListsCriteria == null && includeHierarchiesCriteria == null && includeGroupsCriteria == null && customCriteria == null && includeGeoCriteria == null))
                {
                    srchArgsV2.TargetCriteria = individualUserIdCriteria & statusCriteria;
                }
                else
                {
                    srchArgsV2.TargetCriteria = (includeListsCriteria | includeHierarchiesCriteria | includeGroupsCriteria | customCriteria | includeGeoCriteria) & statusCriteria;
                }
            }

            srchArgsV2.BlockCriteria = blockedListsCriteria | blockHierarchiesCriteria | blockedGroupsCriteria;

            var users = _userFacade.SearchUsersByContext(srchArgsV2);

            if (users.SearchResultCount == 0) //don't bother getting contact info
            {
                deviceInfo = new DeviceContactInformation();
            }
            else
            {
                deviceInfo = _userReportsFacade.GetContactInfo(RuntimeContext.ProviderId, users.SessionId, criteria.SelectedDevices, users.SearchResultCount);
            }

            return Json(new { TotalCount = users.SearchResultCount, ContactInfo = deviceInfo, SessionId = users.SessionId, IUT = userNodeList }, JsonRequestBehavior.AllowGet);
        }

        private List<GenericCriteria> InitializeAdvancedSearch(SearchCriteriaModel searchCriteria)
        {

            var advancedCriterion = new List<GenericCriteria>();

            if (searchCriteria != null && searchCriteria.selections != null && searchCriteria.selections.Count > 0)
            {
                foreach (var qryCriteria in searchCriteria.selections)
                {

                    var criteria = new GenericCriteria(qryCriteria.entity.entityType, qryCriteria.entity.id, qryCriteria.operand);
                    var addToSearch = true;

                    switch (qryCriteria.entity.dataType)
                    {
                        case "Picklist":
                        case "MultiPicklist":
                        case "Checkbox":
                            criteria.Value = (qryCriteria.operand == 11 || qryCriteria.operand == 12)
                                ? "0"
                                : string.Join(",", qryCriteria.value.Select(v => v.id));
                            break;
                        case "Path":
                            criteria.Value = string.Join(",", qryCriteria.value.Select(v => v.lineage));
                            break;
                        case "GeoLocation":
                            var fc = new FeatureCollection(qryCriteria.value[0].text);
                            if (fc.Features != null && fc.Features.Count > 0)
                            {
                                var polyGons = (from f in fc.Features where f.Geometry.Type == Map.Geometry.Type.Polygon || f.Geometry.Type == Map.Geometry.Type.MultiPolygon select f.Attributes["OBJECTID"].ToString()).ToList();
                                var finalString = string.Join("|", polyGons);
                                criteria = new AttributeCriteria(qryCriteria.entity.id, qryCriteria.operand, finalString);
                            }
                            else
                            {
                                addToSearch = false;
                            }
                            break;
                        case "Number":
                        case "String":
                        case "Memo":
                        case "Date":
                        case "DateTime":
                        case "AttributeValue":
                        case "Device":
                        case "Entity":
                        case "Object":
                        case "Unknown":
                        default:
                            criteria.Value = string.Join(",", qryCriteria.value.Select(v => v.text));
                            break;
                    }

                    if (addToSearch)
                    {
                        advancedCriterion.Add(criteria);
                    }


                }
            }

            return advancedCriterion;
        }
        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.Alert }, new[] { ActionType.View })]
        public ActionResult GetTargetableOrganizations(bool getVPSConnectedStatus = false)
        {
            bool isVPSConnectedToPSS = (getVPSConnectedStatus) ? _publishingDomainToModel.OrganizationEnabled(_organizationFacade, RuntimeContext.ProviderId) : false;

            return Json(new
            {
                Organizations = _organizationFacade.GetActiveOrganization(RuntimeContext.ProviderId).OrderBy(x => x.Name),
                //GetActiveOrganization(RuntimeContext.ProviderId, RuntimeContext.OperatorId, _userFacade, _deviceFacade), 
                ShowOrgs = isVPSConnectedToPSS
            },
                JsonRequestBehavior.AllowGet);
        }

        [IWSAuthorize(new[] { SystemObject.Alert, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public ActionResult ReplacePlaceholders(PlaceholderModel model)
        {
            try
            {
                var providerId = RuntimeContext.ProviderId;
                var operatorId = RuntimeContext.OperatorId;
                var operatorName = string.IsNullOrWhiteSpace(RuntimeContext.Operator.DisplayName)
                   ? (!string.IsNullOrWhiteSpace(RuntimeContext.Operator.FirstName) || !string.IsNullOrWhiteSpace(RuntimeContext.Operator.LastName)
                       ? RuntimeContext.Operator.FirstName + " " + RuntimeContext.Operator.LastName
                       : RuntimeContext.Operator.Username)
                   : RuntimeContext.Operator.DisplayName;
                //convert device option to PlaceholderReplacementModel
                model = _publishingDomainToModel.ConvertDeviceOptionToPlaceholderReplacementModel(model);
                model.systemPlaceholders = new SystemPlaceholders
                {
                    OrganizationName = RuntimeContext.Provider.ProviderName,
                    OrganizationId = RuntimeContext.Provider.Id.ToString(),
                    OperatorFullName = string.IsNullOrEmpty(RuntimeContext.Operator.FullName)
                ? operatorName
                : RuntimeContext.Operator.FullName,
                    PublishDate = RuntimeContext.Provider.CurrentSystemTimeToVps().ToString(RuntimeContext.Provider.GetDateFormat()),
                    PublishTime = RuntimeContext.Provider.CurrentSystemTimeToVps().ToString(RuntimeContext.Provider.GetTimeFormat()),
                    TimeZone = SettingsHelper.GetLocalizedTimeZone(RuntimeContext.Provider.GetVpsTimeZoneFromId().Id),
                    SystemName = AtHoc.Systems.AtHocSystem.Local.Name,
                };

                var replacedModel = _publishingDomainToModel.ReplacePlaceholders(providerId, operatorId, model);
                return Json(new { Model = replacedModel, Success = true });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Alert_Placeholder_ReplaceErrorMsg.ToString() });
            }
        }


        [IWSAuthorize(new[] { SystemObject.Alert }, new[] { ActionType.View })]
        public ActionResult RetrieveCustomText(List<DeviceGroupPresetOptions> optionPresets)
        {
            try
            {
                //convert device option to PlaceholderModel - Placeholder is not required here, but we already use this class for other context (custom text in r&p) we will just reuse it for now.  
                PlaceholderModel model = _publishingDomainToModel.RetrieveCustomTexts(optionPresets);
                return Json(new { Model = model, Success = true });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = "Error occured during placeholder replacement." });
            }
        }

        [IWSAuthorize(new[] { SystemObject.Alert }, new[] { ActionType.View })]
        public ActionResult GetScenarioPlaceholdersStatus(int id)
        {
            try
            {
                int providerId = RuntimeContext.ProviderId;
                int operatorId = RuntimeContext.OperatorId;
                var placeholderStatus = _publishingDomainToModel.GetCustomPlaceHoldersStatus(id, providerId, operatorId);
                return Json(new { Status = placeholderStatus, Success = true });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = "Error occured during placeholder replacement." });
            }
        }

        [IWSAuthorize(new[] { SystemObject.Alert }, new[] { ActionType.View })]
        public ActionResult GetDeviceEndPoint(List<Models.Publishing.DeviceEndPoints> devices)
        {
            try
            {
                if (devices != null)
                {
                    foreach (var device in devices)
                    {
                        var endPoints = _publishingDomainToModel.GetEndPointFromDevices(RuntimeContext.ProviderId, device);
                        device.EndPoints = endPoints != null && endPoints.Count > 0 ? endPoints.OrderBy(a => a.UserName).ToList() : endPoints;
                    }
                    return Json(devices, JsonRequestBehavior.AllowGet);
                }
                return Json(new { Success = false, Message = "Devices are invalid" });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = "Error occured while retrieving device endpoints" });
            }

        }
        [HttpGet]
        [IWSAuthorize(new[] { SystemObject.Alert }, new[] { ActionType.View })]
        public ActionResult GetUsersCountFromAlert(int alertId)
        {
            try
            {
                var providerId = RuntimeContext.ProviderId;
                var customAttributeCache = new CustomAttributeCache();
                var customAttributeDictionary = customAttributeCache.Get(providerId, RuntimeContext.Provider.BaseLocale, true);
                var statusAttribute = customAttributeDictionary.GetByCommonName(AttributeCommonNames.Status);
                var customAttributeValueCache = new CustomAttributeValueCache();
                var customAttributeValueDictionary = customAttributeValueCache.Get(providerId, RuntimeContext.Provider.BaseLocale);
                var statusValues = customAttributeValueDictionary.GetByCommonNames("VLD,DSB,DEL").Select(x => x.ValueId);

                var srchArgs = new UserSearchArgs(true, true, false)
                {
                    ProviderId = providerId,
                    ChannelId = 0,
                    Options = new QueryOptions
                    {
                        EnableSession = true,
                        GetCountsOnly = true,
                        GetMassDevices = false,
                        GetUsers = true,
                    },
                    TargetCriteria = new AlertCriteria(alertId, AlertCriteriaOperator.SUMMARY, new List<int>()) & UserSearchHelper.GetUserStatusCriteria(statusAttribute.Id, statusValues),
                    ProviderCriteria = UserSearchHelper.GetProviderCriteria(providerId),
                    OperatorCriteria = UserSearchHelper.GetOperatorUserBaseCriteria(RuntimeContext.OperatorId, RuntimeContext.ProviderId)
                };

                var users = _userFacade.SearchUsersByContext(srchArgs);
                return Json(new { Success = true, TotalCount = users.SearchResultCount, SessionId = users.SessionId }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Message = "Error getting user count." }, JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// Play an audio file
        /// </summary>
        /// <param name="audioId">AudioId to be downloaded</param>
        /// <param name="audioName">Audio Name</param>
        /// <returns>File content </returns>
        public ActionResult PlayAudioFile(string audioId, bool isChanged, bool isIE)
        {
            byte[] content = null;
            string audioName = "";
            try
            {

                if (!string.IsNullOrEmpty(audioId) && !isChanged)
                {


                    Stream imageStream = MediaServiceWrapper.GetMedia(audioId, out audioName);

                    using (var memoryStream = new MemoryStream())
                    {
                        imageStream.CopyTo(memoryStream);
                        content = memoryStream.ToArray();
                    }
                    if (isIE)
                        TempData["audioData"] = content;


                }
                else
                {
                    if (isIE)
                    {
                        content = (byte[])TempData["audioData"];
                        TempData.Keep("audioData");
                    }

                }

            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
            }
            return (isIE) ? (ActionResult)File(content, System.Net.Mime.MediaTypeNames.Application.Octet) : (Json(new { Success = true, audioData = Convert.ToBase64String(content) }));
        }
        /// <summary>
        /// To Download an Audio File
        /// </summary>
        /// <param name="audioId"></param>
        /// <param name="audioData"></param>
        /// <param name="audioName"></param>
        /// <returns></returns>

        [HttpPost]
        public ActionResult DownloadAudioFile(string audioId, string audioData, string audioName)
        {
            byte[] content = null;
            try
            {
                if (string.IsNullOrEmpty(audioData))
                {

                    MediaService svc = MediaService.Instance;
                    var audioFileObject = svc.GetMedia(new Guid(audioId));
                    content = audioFileObject.MediaContent.GetContentBytes(); // convert back to Base64 string 
                }
                else
                {

                    content = Convert.FromBase64String(audioData);
                }
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
            }
            return File(content, System.Net.Mime.MediaTypeNames.Application.Octet, audioName);
        }
        /// <summary>
        /// To Get Audio File Data
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public JsonResult GetAudioFileData(bool isIE = false)
        {
            var audioFile = new AudioFileSettingsModel();
            try
            {
                var uploadFile = Request.Files[0];

                if (uploadFile != null && (uploadFile.ContentLength > 0) && !string.IsNullOrEmpty(uploadFile.FileName))
                {
                    if (FileMimeTypeValidation.ValidateMimeType(uploadFile.InputStream, FileType.Audio))
                    {
                        audioFile.AudioName = uploadFile.FileName;
                        uploadFile.InputStream.Position = 0;
                        audioFile.AudioCommonName = Regex.Replace(uploadFile.FileName, @"\s+", "-");
                        var fileBytes = new byte[uploadFile.ContentLength];
                        uploadFile.InputStream.Read(fileBytes, 0, Convert.ToInt32(uploadFile.ContentLength));
                        audioFile.AudioBlob = fileBytes;
                        if (isIE)
                            TempData["audioData"] = fileBytes;
                    }
                    else
                    {
                        return Json(new { HasErrors = IWSResources.Settings_AudioFile_InvalidAudioFile, Success = false });
                    }
                }

            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, audioData = "", fileSize = 0 });
            }

            return Json(new { audioData = Convert.ToBase64String(audioFile.AudioBlob), Success = true, fileSize = Math.Round((double)audioFile.AudioBlob.Length / (1024 * 1024), 2) }, "text/plain");
        }

        protected override JsonResult Json(object data, string contentType, System.Text.Encoding contentEncoding, JsonRequestBehavior behavior)
        {
            return new JsonResult
            {
                Data = data,
                //ContentType = !Request.AcceptTypes.Contains("application/json") ? "text/html" : contentType,
                ContentType = contentType,
                ContentEncoding = contentEncoding,
                JsonRequestBehavior = behavior,
                MaxJsonLength = Int32.MaxValue
            };
        }

    }
}