﻿using System;
using System.Linq;
using System.Web.Mvc;
using AtHoc.Business.Extensions;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Resources;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Data.SearchSpec;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.SSA.Business.Facades;
using AtHoc.IWS.Web.Configurations.Constants;
using AtHoc.IWS.Web.Filters;
using EO.Pdf.Internal;
using AtHoc.IWS.Business.Domain.PageLayout;
using AtHoc.IWS.Business.Domain.PageLayout.Spec;
using AtHoc.IWS.Web.Models.PageLayout;
using AtHoc.IWS.SSA.Business.Facades.Interfaces;
using System.Collections.Generic;
using AtHoc.IWS.SSA.Business;
using AtHoc.Global.Resources;
using AtHoc.IWS.Business;

namespace AtHoc.IWS.Web.Controllers
{
    [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.View })]
    public class UserAttributesController : Infrastructure.Web.Mvc.Controller
    {
        private readonly ICustomAttributeFacade _customAttributeFacade;
        private readonly IPageLayoutFacade _pageLayoutFacade;
        private readonly IIconManager _iconManager;
        public UserAttributesController(ICustomAttributeFacade customAttributeFacade, IPageLayoutFacade pageLayoutFacade)
        {
            _customAttributeFacade = customAttributeFacade;
            _pageLayoutFacade = pageLayoutFacade;
            _iconManager = ManagerFactory.Instance.CreateIconManager();

        }

        // GET: UserAttributes
        [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.Modify })]
        public ActionResult Index()
        {
            return View();
        }

        [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.Modify })]
        public ActionResult AttributeDetails()
        {
            return View();
        }

        /// <summary>
        /// It will redirect to New Attribute details page
        /// </summary>
        /// <param name="id">Attribute Type</param>
        /// <returns></returns>
        [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.Modify })]
        public ActionResult New(string id)
        {
            ViewBag.AttributeType = id;
            var types = _customAttributeFacade.GetUserAttributeTypes();
            ViewBag.AttributeTypeId = types.ToList().SingleOrDefault(i => i.AttributeType == id).AttributeTypeId;
            ViewBag.IsNew = true;
            FillTimeProperties();
            return View("AttributeDetails");
        }

        /// <summary>
        /// It will redirect to Edit Attribute details page
        /// </summary>
        /// <param name="id">Attribute Id</param>
        /// <returns></returns>        
        [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.Modify })]
        public ActionResult Edit(string id)
        {
            ViewBag.AttributeType = id;
            ViewBag.IsNew = false;
            FillTimeProperties();
            return View("AttributeDetails");
        }

        /// <summary>
        /// Fill DateTime properties
        /// </summary>
        private void FillTimeProperties()
        {
            var provider = RuntimeContext.Provider;

            var vpsTimeZOne = RuntimeContext.Provider.GetVpsTimeZoneFromId();
            ViewBag.DateFormat = provider.GetDateFormat();
            ViewBag.DateTimeFormat = provider.GetDateTimeFormat();
            ViewBag.VPSTimeZone = vpsTimeZOne;
            ViewBag.UtcOffsetInMinutes = vpsTimeZOne.BaseUtcOffset.TotalMinutes;
            ViewBag.VPSOffsetFromSystemInMinutes = provider.VPSOffsetFromSystemInMinutes();
            ViewBag.SupportsDaylightSavingTime = vpsTimeZOne.SupportsDaylightSavingTime;
            ViewBag.CurrentDateTime = provider.CurrentSystemTimeToVps().ToString(System.Globalization.CultureInfo.InvariantCulture);
            ViewBag.CurrentTime = DateTime.Now;
        }

        /// <summary>
        /// Get Attributes based on spec
        /// If providerId is zero then get all attributes
        /// If providerID is somthing value then get only corresponding attributes
        /// TODO: If providerId is somthing value and get all attributes other than this prodierid attributes
        /// </summary>
        /// <param name="attributeSearchSpec">UserAttributeSearchSpec object</param>
        /// <returns></returns>
        [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.Modify })]
        public ActionResult GetUserAttributeList(UserAttributeSearchSpec attributeSearchSpec)
        {
            if (!attributeSearchSpec.AllAttributesOnly)
                attributeSearchSpec.ProviderId = RuntimeContext.ProviderId;
            else
                attributeSearchSpec.ProviderId = 0;

            attributeSearchSpec.OperatorId = RuntimeContext.OperatorId;

            var dataFromDb = _customAttributeFacade.GetAttributesForList(attributeSearchSpec);

            var data = dataFromDb.Data.Select(x => new
            {
                x.Id,
                x.AttributeName,
                x.AttributeOrigin,
                UpdatedOn =
                    RuntimeContext.Provider.GetVpsDateTimeFromSeconds(x.UpdatedOn.HasValue
                        ? x.UpdatedOn.Value
                        : x.CreatedOn.HasValue ? x.CreatedOn.Value : 0).ToVpsDateString(),
                x.AttributeType
            });

            return Json(new
            {
                Success = true,
                TotalCount = dataFromDb.Count,
                Data = data,
            }, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Getting usesr attribute details based on attributeId
        /// </summary>
        /// <param name="userAttributeId">Attribute Id</param>
        /// <returns></returns>
        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.Modify })]
        public ActionResult GetUserAttributeDetails(int userAttributeId)
        {
            //just call findbyId - details
            //isDeletable(currentcontextproviderID) returns boolean (run through the business rules)

            bool isDeletable; DateTime earliestAllowedDate; DateTime latestAllowedDate;
            var userAttribute = IsUserAttributeDeletableOnCurrentContext(userAttributeId, out isDeletable);
            if (!string.IsNullOrEmpty(userAttribute.MinValue))
                earliestAllowedDate = DateTimeConverter.GetDateTimeFromSeconds(Convert.ToInt32(userAttribute.MinValue));
            if (!string.IsNullOrEmpty(userAttribute.MaxValue))
                latestAllowedDate = DateTimeConverter.GetDateTimeFromSeconds(Convert.ToInt32(userAttribute.MaxValue));

            if (userAttribute != null)
                return Json(new
                {
                    Success = true,
                    Data = userAttribute,
                    IsDeletable = isDeletable
                });
            return null;
        }

        /// <summary>
        /// Getting attribute details and check it is deletable or not
        /// </summary>
        /// <param name="userAttributeId">Attribute Id</param>
        /// <param name="isDeletable">Deletable</param>
        /// <returns></returns>
        [NonAction]
        private CustomAttribute IsUserAttributeDeletableOnCurrentContext(int userAttributeId, out bool isDeletable)
        {
            var userAttributeDetails =
                _customAttributeFacade.GetCustomAttributesBySpec(new CustomAttributeSpec { Id = userAttributeId })
                    .ToList();
            isDeletable = false;
            if (userAttributeDetails.Any())
            {
                var userAttribute = userAttributeDetails.First();

                isDeletable = ((userAttribute.ProviderId == RuntimeContext.ProviderId)
                               && (userAttribute.IsSystemAttribute != "Y" && userAttribute.IsStandard != "Y")
                               && ((userAttribute.CommonName.ToLower() != CommonNames.SSATeam.ToLower()) &&
                                   (_customAttributeFacade.GetOrgHierarchyAttributeId(RuntimeContext.ProviderId) !=
                                    userAttribute.Id)));
                return userAttribute;
            }
            return null;
        }

        /// <summary>
        /// Getting attribute dependecny list
        /// </summary>
        /// <param name="spec">CustomAttributeDeleteDependencySpec</param>
        /// <returns></returns>
        [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.Modify })]
        public ActionResult GetUserAttributeDependencyList(CustomAttributeDeleteDependencySpec spec)
        {
            spec.ProviderId = RuntimeContext.ProviderId;

            var dependencyList = _customAttributeFacade.CheckDeleteDependencies(spec).ToList();

            if (dependencyList.Any())
            {
                return Json(new
                {
                    Success = true,
                    Data = dependencyList,
                    TotalCount = 10000,
                }, JsonRequestBehavior.AllowGet);
            }
            return Json(new
            {
                Success = true
            });
        }

        public ActionResult GetUserAttributeValues(int userAttributeId)
        {
            var attributeValues = _customAttributeFacade.GetCustomAttributeValuesBySpec(new CustomAttributeValueSpec { AttributeId = userAttributeId });
            return Json(new
            {
                Success = true,
                Data = attributeValues
            });
        }


        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.Modify })]
        public ActionResult ExportDependencies(string contentType, string base64, string fileName)
        {
            var fileContents = Convert.FromBase64String(base64);
            return File(fileContents, contentType, fileName);
        }


        [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.Modify })]
        public ActionResult DeleteUserAttribute(int userAttributeId)
        {
            //userAttributeId = 128;
            var messages = new Messages();
            try
            {
                bool isDeletable;
                var userAttribute = IsUserAttributeDeletableOnCurrentContext(userAttributeId, out isDeletable);
                if (isDeletable)
                {
                    var result = _customAttributeFacade.DeleteCustomAttribute(userAttributeId, RuntimeContext.ProviderId);
                    return Json(new { Success = result.Messages.NoErrors(), result.Messages });
                }
                messages.Add(new Message { Value = "This user attribute cannot be deleted", Type = MessageType.Error, Sender = typeof(UserAttributesController) });
                return Json(new { Success = false, Messages = messages });
            }
            catch (Exception exec)
            {
                messages.Add(new Message { Value = exec.Message, Type = MessageType.Error, Sender = typeof(UserAttributesController) });
                LogService.Current.Error(() => exec);
                return Json(new { Success = false, Messages = messages });
            }
        }

        public ActionResult GetUserAttributeTypes()
        {
            var data = _customAttributeFacade.GetUserAttributeTypes();
            return Json(new
            {
                Success = true,
                Data = data
            });
        }

        [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.Modify })]
        public ActionResult DeletePickListOption(int userAttributeId)
        {
            var messages = new Messages();
            try
            {
                throw new Exception("Not Implemented");
            }
            catch (Exception exec)
            {
                messages.Add(new Message { Value = exec.Message, Type = MessageType.Error, Sender = typeof(UserAttributesController) });
                LogService.Current.Error(() => exec);
                return Json(new { Success = false, Messages = messages });
            }
        }

        /// <summary>
        /// Get PageLayout sections and get the selected section
        /// </summary>
        /// <param name="commonName">common name</param>
        /// <returns></returns>
        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.Modify })]
        public ActionResult GetSections(string commonName)
        {
            try
            {
                var provider = RuntimeContext.Provider;
                List<object> list = new List<object>();

                // Get all user sections
                var userLayout = _pageLayoutFacade.GetPageLayoutBySpec(new PageLayoutSpec { ProviderId = provider.Id, PageId = "NEWEUM" }).FirstOrDefault();
                var layoutXml = new LayoutXml();
                var allUserSections = layoutXml.GetAllSections(userLayout.LayoutXml, commonName);
                var userList = allUserSections.Select(s => new { s.DisplayName, s.Name, s.IsSelected, s.IsParent, s.IsChild, s.Children });

                // Get all SelfService sections
                var ssLayout = _pageLayoutFacade.GetPageLayoutBySpec(new PageLayoutSpec { ProviderId = provider.Id, PageId = "OPERATORDETAILS" }).FirstOrDefault();
                var allSSSections = layoutXml.GetAllSections(ssLayout.LayoutXml, commonName);
                var ssList = allSSSections.Select(s => new { s.DisplayName, s.Name, s.IsSelected, s.IsParent, s.IsChild, s.Children });

                return
                    Json(
                        new
                        {
                            UserList = userList,
                            SSList = ssList,
                            Success = true
                        }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { ErrorMessage = ex.Message, Success = false }, JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// Get all map icons 
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.Modify })]
        public ActionResult MapIconsBase()
        {
            try
            {
                var Categories = _iconManager.GetCategories();
                var Icons = _iconManager.GetIcons();

                var model = new List<object>();
                foreach (var name in Categories)
                {
                    var list = Icons.Where(i => i.Category == name).ToList();
                    model.Add(new { Name = name, List = list });
                }

                int iconId;
                if (int.TryParse(_iconManager.GetDefaultIconId(), out iconId))
                {
                    iconId = 0;
                }

                return
                       Json(
                           new
                           {
                               Data = model,
                               DefaultIconId = iconId,
                               Success = true
                           }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { ErrorMessage = ex.Message, Success = false }, JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// Save attribute details
        /// </summary>
        /// <param name="model">Attribute details</param>
        /// <returns></returns>
        public ActionResult SaveAttribute(CustomAttributeModel model)
        {
            try
            {
                string message = string.Empty;
                message = ValidateAttribute(model);
                //model = InitializeData(model);
                model.ProviderId = RuntimeContext.ProviderId;
                model.LocaleCode = RuntimeContext.Provider.BaseLocale;

                if (message != string.Empty)
                {
                    return Json(new { ErrorMessage = message, Success = false }, JsonRequestBehavior.AllowGet);
                }
                //Convertingthe selected dates to Seconds.
                if (model.EarliestAllowedDate.HasValue && model.EarliestAllowedDate != DateTime.MinValue)
                {
                    model.MinValue = DateTimeConverter.GetSecondsFromDateTime(model.EarliestAllowedDate.Value);
                }
                if (model.LatestAllowedDate.HasValue && model.LatestAllowedDate != DateTime.MaxValue)
                {
                    model.MaxValue = DateTimeConverter.GetSecondsFromDateTime(model.LatestAllowedDate.Value);
                }

                var resultMessage = _customAttributeFacade.SaveCustomAttribute(model);
                var result = resultMessage.FirstOrDefault();

                /* To Do : below line of code is for Retrieve functionality test 
                and it should be removed after UI integration.
                 */
                var attributeValues = _customAttributeFacade.GetCustomAttributesBySpec(new CustomAttributeSpec { CommonName = model.CommonName });
                if (result.Type == MessageType.Success)
                {
                    return Json(new { ErrorMessage = result.Value, Success = true }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(new { ErrorMessage = result.Value, Success = false }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json(new { ErrorMessage = ex.Message, Success = false }, JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// Validating attribute details
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string ValidateAttribute(CustomAttributeModel model)
        {
            try
            {
                string message = string.Empty;
                int providerId = RuntimeContext.ProviderId;
                // Validate Attribute Name
                var id = _customAttributeFacade.ValidateAttributeName(providerId, model.Name);
                if (id != -1 && id != model.AttributeTypeId)
                {
                    return string.Format(IWSResources.UserAttributeManager_AttributeName_Unique_Message, model.Name);
                }

                // Validate Common Name
                id = _customAttributeFacade.ValidateCommonName(providerId, model.CommonName);
                if (id != -1 && id != model.AttributeTypeId)
                {
                    return string.Format(IWSResources.UserAttributeManager_CommonName_Unique_Message, model.CommonName);
                }
                return string.Empty;
            }
            catch (Exception ex)
            {
                return string.Empty;
            }
        }

        /*ToDo : 
          This Action is written to do unit testing and should be removed after UI integration.
       */
        [IWSAuthorize(new[] { SystemObject.CustomAttributes }, new[] { ActionType.Modify })]
        public CustomAttributeModel InitializeData(CustomAttributeModel model)
        {
            switch (model.AttributeTypeId)
            {
                case 1: // Number
                    model = new CustomAttributeModel();
                    model.Name = "NumberTest" + DateTime.Now.ToString();
                    model.CommonName = "CNumberTest" + DateTime.Now.ToString();
                    model.AttributeTypeId = 1;
                    model.MinValue = null;
                    model.MaxValue = null;
                    model.EditLevel = 2;
                    model.PickListValuesCSV = "";
                    model.ToolTip = "NumberTest";
                    model.HelpText = "NumberTest";
                    model.Mandatory = "N";
                    model.IsEncrypted = "N";
                    model.SearchAllowed = "Y";
                    model.DisplayDropdown = "N";
                    model.DefaultValue = "";
                    model.PicklistDelimiter = "";
                    model.IsStandard = "Y";
                    model.ReportName = "";
                    model.Description = "";
                    model.IsSystem = "";
                    model.SupportsHistory = "";
                    model.IconId = 1;
                    model.EntityId = "USER";
                    model.LocaleCode = "en-US";
                    break;
                case 2: // String 
                    model = new CustomAttributeModel();
                    model.Name = "StringTest" + DateTime.Now.ToString();
                    model.CommonName = "CStringTest" + DateTime.Now.ToString();
                    model.AttributeTypeId = 2;
                    model.MinValue = null;
                    model.MaxValue = null;
                    model.EditLevel = 2;
                    model.PickListValuesCSV = "";
                    model.ToolTip = "StringTest";
                    model.HelpText = "StringTest";
                    model.Mandatory = "";
                    model.IsEncrypted = "";
                    model.SearchAllowed = "";
                    model.DisplayDropdown = "";
                    model.DefaultValue = "";
                    model.PicklistDelimiter = "";
                    model.IsStandard = "";
                    model.ReportName = "";
                    model.Description = "";
                    model.IsSystem = "N";
                    model.SupportsHistory = "";
                    model.IconId = 1;
                    model.EntityId = "USER";
                    model.LocaleCode = "en-US";
                    break;
                case 3: // Memo
                    model = new CustomAttributeModel();
                    model.Name = "MemoTest" + DateTime.Now.ToString();
                    model.CommonName = "CMemoTest" + DateTime.Now.ToString();
                    model.AttributeTypeId = 3;
                    model.MinValue = null;
                    model.MaxValue = null;
                    model.EditLevel = 2;
                    model.PickListValuesCSV = "";
                    model.ToolTip = "MemoTest";
                    model.HelpText = "MemoTest";
                    model.Mandatory = "";
                    model.IsEncrypted = "";
                    model.SearchAllowed = "";
                    model.DisplayDropdown = "";
                    model.DefaultValue = "";
                    model.PicklistDelimiter = ",";
                    model.IsStandard = "";
                    model.ReportName = "";
                    model.Description = "";
                    model.IsSystem = "N";
                    model.SupportsHistory = "";
                    model.IconId = 1;
                    model.EntityId = "USER";
                    model.LocaleCode = "en-US";
                    break;
                case 4: // Date
                    model = new CustomAttributeModel();
                    model.Name = "DateTest" + DateTime.Now.ToString();
                    model.CommonName = "CDateTest" + DateTime.Now.ToString();
                    model.AttributeTypeId = 4;
                    model.MinValue = null;
                    model.MaxValue = null;
                    model.EditLevel = 2;
                    model.PickListValuesCSV = "";
                    model.ToolTip = "DateTest";
                    model.HelpText = "DateTest";
                    model.Mandatory = "";
                    model.IsEncrypted = "";
                    model.SearchAllowed = "";
                    model.DisplayDropdown = "";
                    model.DefaultValue = "";
                    model.PicklistDelimiter = ",";
                    model.IsStandard = "";
                    model.ReportName = "";
                    model.Description = "";
                    model.IsSystem = "N";
                    model.SupportsHistory = "";
                    model.IconId = 1;
                    model.EntityId = "USER";
                    model.LocaleCode = "en-US";
                    break;
                case 5: // DateTime
                    model = new CustomAttributeModel();

                    model.Name = "DateTimeTest" + DateTime.Now.ToString();
                    model.CommonName = "CDateTimeTest" + DateTime.Now.ToString();
                    model.AttributeTypeId = 5;
                    model.MinValue = null;
                    model.MaxValue = null;
                    model.EditLevel = 2;
                    model.PickListValuesCSV = "";
                    model.ToolTip = "DateTimeTest";
                    model.HelpText = "DateTimeTest";
                    model.Mandatory = "";
                    model.IsEncrypted = "";
                    model.SearchAllowed = "";
                    model.DisplayDropdown = "";
                    model.DefaultValue = "";
                    model.PicklistDelimiter = ",";
                    model.IsStandard = "";
                    model.ReportName = "";
                    model.Description = "";
                    model.IsSystem = "N";
                    model.SupportsHistory = "";
                    model.IconId = 1;
                    model.EntityId = "USER";
                    model.LocaleCode = "en-US";
                    break;
                case 6: // Picklist
                    model = new CustomAttributeModel();

                    model.Name = "PicklistTest" + DateTime.Now.ToString();
                    model.CommonName = "CPicklistTest" + DateTime.Now.ToString();
                    model.AttributeTypeId = 6;
                    model.MinValue = null;
                    model.MaxValue = null;
                    model.EditLevel = 2;
                    model.PickListValuesCSV = "SL1,SL2,SL3";
                    model.ToolTip = "PicklistTest";
                    model.HelpText = "PicklistTest";
                    model.Mandatory = "";
                    model.IsEncrypted = "";
                    model.SearchAllowed = "";
                    model.DisplayDropdown = "";
                    model.DefaultValue = "";
                    model.PicklistDelimiter = ",";
                    model.IsStandard = "";
                    model.ReportName = "";
                    model.Description = "";
                    model.IsSystem = "N";
                    model.SupportsHistory = "";
                    model.IconId = 1;
                    model.EntityId = "USER";
                    model.LocaleCode = "en-US";
                    break;
                case 7: // Multi-Picklist
                    model = new CustomAttributeModel();

                    model.Name = "Multi-PicklistTest" + DateTime.Now.ToString();
                    model.CommonName = "CMulti-PicklistTest" + DateTime.Now.ToString();
                    model.AttributeTypeId = 7;
                    model.MinValue = null;
                    model.MaxValue = null;
                    model.EditLevel = 2;
                    model.PickListValuesCSV = "ML1,ML2,ML3";
                    model.ToolTip = "Multi-PicklistTest";
                    model.HelpText = "Multi-PicklistTest";
                    model.Mandatory = "";
                    model.IsEncrypted = "";
                    model.SearchAllowed = "";
                    model.DisplayDropdown = "";
                    model.DefaultValue = "";
                    model.PicklistDelimiter = ",";
                    model.IsStandard = "";
                    model.ReportName = "";
                    model.Description = "";
                    model.IsSystem = "N";
                    model.SupportsHistory = "";
                    model.IconId = 1;
                    model.EntityId = "USER";
                    model.LocaleCode = "en-US";
                    break;
                case 8: // Checkbox
                    model = new CustomAttributeModel();

                    model.Name = "CheckboxTest" + DateTime.Now.ToString();
                    model.CommonName = "CCheckboxTest" + DateTime.Now.ToString();
                    model.AttributeTypeId = 8;
                    model.MinValue = null;
                    model.MaxValue = null;
                    model.EditLevel = 2;
                    model.PickListValuesCSV = "";
                    model.ToolTip = "CheckboxTest";
                    model.HelpText = "CheckboxTest";
                    model.Mandatory = "";
                    model.IsEncrypted = "";
                    model.SearchAllowed = "";
                    model.DisplayDropdown = "";
                    model.DefaultValue = "";
                    model.PicklistDelimiter = ",";
                    model.IsStandard = "";
                    model.ReportName = "";
                    model.Description = "";
                    model.IsSystem = "N";
                    model.SupportsHistory = "";
                    model.IconId = 1;
                    model.EntityId = "USER";
                    model.LocaleCode = "en-US";
                    break;
                case 9: // Path
                    model = new CustomAttributeModel();
                    model.Name = "PathTest" + DateTime.Now.ToString();
                    model.CommonName = "CPathTest" + DateTime.Now.ToString();
                    model.AttributeTypeId = 9;
                    model.MinValue = null;
                    model.MaxValue = null;
                    model.EditLevel = 2;
                    model.PickListValuesCSV = "";
                    model.ToolTip = "PathTest";
                    model.HelpText = "PathTest";
                    model.Mandatory = "";
                    model.IsEncrypted = "";
                    model.SearchAllowed = "";
                    model.DisplayDropdown = "";
                    model.DefaultValue = "";
                    model.PicklistDelimiter = ",";
                    model.IsStandard = "";
                    model.ReportName = "";
                    model.Description = "";
                    model.IsSystem = "N";
                    model.SupportsHistory = "";
                    model.IconId = 1;
                    model.EntityId = "USER";
                    model.LocaleCode = "en-US";
                    break;
                case 10: // Geography
                    model = new CustomAttributeModel();
                    model.Name = "GeographyTest" + DateTime.Now.ToString();
                    model.CommonName = "CGeographyTest" + DateTime.Now.ToString();
                    model.AttributeTypeId = 10;
                    model.MinValue = null;
                    model.MaxValue = null;
                    model.EditLevel = 2;
                    model.PickListValuesCSV = "";
                    model.ToolTip = "GeographyTest";
                    model.HelpText = "GeographyTest";
                    model.Mandatory = "";
                    model.IsEncrypted = "";
                    model.SearchAllowed = "";
                    model.DisplayDropdown = "";
                    model.DefaultValue = "";
                    model.PicklistDelimiter = ",";
                    model.IsStandard = "";
                    model.ReportName = "";
                    model.Description = "";
                    model.IsSystem = "N";
                    model.SupportsHistory = "";
                    model.IconId = 1;
                    model.EntityId = "USER";
                    model.LocaleCode = "en-US";
                    break;
                case 11: // Time
                    model = new CustomAttributeModel();
                    model.Name = "TimeTest" + DateTime.Now.ToString();
                    model.CommonName = "CTimeTest" + DateTime.Now.ToString();
                    model.AttributeTypeId = 11;
                    model.MinValue = null;
                    model.MaxValue = null;
                    model.EditLevel = 2;
                    model.PickListValuesCSV = "";
                    model.ToolTip = "TimeTest";
                    model.HelpText = "TimeTest";
                    model.Mandatory = "";
                    model.IsEncrypted = "";
                    model.SearchAllowed = "";
                    model.DisplayDropdown = "";
                    model.DefaultValue = "";
                    model.PicklistDelimiter = ",";
                    model.IsStandard = "";
                    model.ReportName = "";
                    model.Description = "";
                    model.IsSystem = "N";
                    model.SupportsHistory = "";
                    model.IconId = 1;
                    model.EntityId = "USER";
                    model.LocaleCode = "en-US";
                    break;
            }
            return model;
        }

    }
}