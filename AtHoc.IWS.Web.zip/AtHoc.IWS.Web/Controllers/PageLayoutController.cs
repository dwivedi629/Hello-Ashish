﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web.WebPages.Deployment;
using System.Xml;
using System.Web;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Web.Mvc.ActionFilters;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.IWS.Business.Domain.Devices;
using AtHoc.IWS.Business.Domain.Devices.Spec;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.PageLayout;
using AtHoc.IWS.Business.Domain.PageLayout.Spec;
using AtHoc.IWS.Web.Configurations.Constants;
using AtHoc.IWS.Web.Filters;
using AtHoc.IWS.Web.Helpers;
using AtHoc.IWS.Web.Models.PageLayout;
using AtHoc.Global.Resources;
using AtHoc.Infrastructure.Security;
using Controller = AtHoc.Infrastructure.Web.Mvc.Controller;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;

namespace AtHoc.IWS.Web.Controllers
{
    [IWSAuthorize(new SystemObject[] { SystemObject.EndUsers, SystemObject.DistributionLists, SystemObject.VirtualSystemConfiguration }, new ActionType[] { ActionType.View, ActionType.View, ActionType.View })]
    public class PageLayoutController : Controller
    {
        private readonly IPageLayoutFacade pageLayoutFacade;

        private readonly ICustomAttributeFacade customAttributeFacade;

        private readonly ICustomAttributeCache customAttributeCache;

        private readonly IDeviceFacade deviceFacade;

        private static IEnumerable<Device> allDevices;

        private static ILookup<string, Device> devicesByCommonName;

        private static ILookup<string, Device> devicesByName;

        private readonly IUserManagerHelper _userManagerHelper;

        public PageLayoutController(IPageLayoutFacade pageLayoutFacade, ICustomAttributeFacade customAttributeFacade,
                                    ICustomAttributeCache customAttributeCache, IDeviceFacade deviceFacade, IUserManagerHelper userManagerHelper)
        {
            this.pageLayoutFacade = pageLayoutFacade;
            this.customAttributeCache = customAttributeCache;
            this.customAttributeFacade = customAttributeFacade;
            this.deviceFacade = deviceFacade;
            _userManagerHelper = userManagerHelper;
        }

        public ActionResult Index()
        {
            var provider = RuntimeContext.Provider;
            var layout =
                pageLayoutFacade.GetPageLayoutBySpec(new PageLayoutSpec { ProviderId = provider.Id, PageId = "NEWEUM" })
                                .FirstOrDefault();

            var xml = new XmlDocument();
            if (layout != null)
            {
                xml.LoadXml(layout.LayoutXml);
            }
            else
            {
                //load default xml
                //var path = Server.MapPath("~/App_Data/neweum_defaultpagelayout.xml");
                //xml.Load(path);
                throw new Exception(IWSResources.PageLayout_User_Layout_IsNotAvailable);
            }
            return View("Index", "", FormatXml(xml));
        }


        public ActionResult OperatorLayout()
        {
            var provider = RuntimeContext.Provider;
            var layout =
                pageLayoutFacade.GetPageLayoutBySpec(new PageLayoutSpec { ProviderId = provider.Id, PageId = "OPERATORDETAILS" })
                                .FirstOrDefault();

            var xml = new XmlDocument();
            if (layout != null)
            {
                xml.LoadXml(layout.LayoutXml);
            }
            else
            {
                throw new Exception(IWSResources.PageLayout_Operator_Layout_IsNotAvailable);
            }
            return View("OperatorPageLayout", "", FormatXml(xml));
        }

        [HttpGet]
        public ActionResult ListPageLayout(string viewType)
        {
            //Reset Provider as it is still old for IWS-4216	
            HttpContext.Session["CurrentProvider"] = null;

            var provider = RuntimeContext.Provider;

            var customViews =
                customAttributeFacade.GetCustomViewsBySpec(new CustomViewSpec
                {
                    ProviderId = provider.Id,
                    CustomViewType = (CustomViewType)Enum.Parse(typeof(CustomViewType), viewType),
                    IsPlaceholder = false,
                    CustomViewColumnTypes = new[] { CustomViewColumnType.CustomField, CustomViewColumnType.Device },
                    DefaultOnly = true
                });

            //ToDo: hardcoded default columns, need to check with PM/QA
            var defaultColumns = new List<string>();

            if ((CustomViewType)Enum.Parse(typeof(CustomViewType), viewType) == CustomViewType.UserManagerV2)
                defaultColumns.AddRange(new[] { RuntimeContext.CustomAttributes.GetByCommonName(CommonNames.FirstName).AttributeName,
                    RuntimeContext.CustomAttributes.GetByCommonName(CommonNames.LastName).AttributeName });

            //var existingColumns = customViews.Select(s => s.Title).ToList();
            var existingColumns = _userManagerHelper.GetCustomViewEntityNames(customViews, allDevices);
            var xmlColumns = new StringBuilder();

            defaultColumns.ForEach(s => xmlColumns.Append("<Column>{0}</Column>".FormatWith(s)));

            existingColumns.ForEach(s =>
            {
                if (!defaultColumns.Contains(s))
                {
                    xmlColumns.Append("<Column>{0}</Column>".FormatWith(HttpUtility.HtmlEncode(s)));
                }
            });

            var xml = new XmlDocument();
            xml.LoadXml("<EndUserList>{0}</EndUserList>".FormatWith(xmlColumns.ToString()));
            ViewBag.ViewType = viewType;

            if (viewType.ToLower() == CustomViewType.UserManagerV2.ToString().ToLower())
                ViewBag.LayoutTitle = IWSResources.GeneralSettings_Users_Grid_View_Title;
            else if (viewType.ToLower() == CustomViewType.UserReport.ToString().ToLower())
                ViewBag.LayoutTitle = IWSResources.GeneralSettings_Report_Columns_Title;

            return View("ListPageLayout", "", FormatXml(xml));
        }


        [HttpPost]
        public JsonResult UpdateListPageLayout(string viewType, LayoutAttributes attributes)
        {
            var messages = new Messages();
            var provider = RuntimeContext.Provider;

            CustomAttributeLookup customAttributes = null;
            if (viewType == Enum.GetName(typeof(CustomViewType), CustomViewType.UserReport))
            {
                RefreshDevices(true, true);
                customAttributes = customAttributeCache.Get(provider.Id, RuntimeContext.Provider.BaseLocale, false);
            }
            else
            {
                RefreshDevices();
                customAttributes = customAttributeCache.Get(provider.Id, RuntimeContext.Provider.BaseLocale);
            }

            if (attributes == null || !attributes.Attributes.Any())
            {
                messages.Add(new Message
                {
                    Value = "Please select attributes.",
                    Sender = "UpdateListPageLayout",
                    Type = MessageType.Error
                });
            }
            try
            {
                var updatedColumns =
                    attributes.Attributes.Select(s => new { s.AttributeName, s.AttributeType, s.Id, IsUpdated = true });
                //var customAttributes = customAttributeCache.Get(provider.Id);
                var customViews =
                    customAttributeFacade.GetCustomViewsBySpec(new CustomViewSpec
                    {
                        ProviderId = provider.Id,
                        CustomViewType = (CustomViewType)Enum.Parse(typeof(CustomViewType), viewType),
                        IsPlaceholder = false,
                        CustomViewColumnTypes = new[] { CustomViewColumnType.CustomField, CustomViewColumnType.Device, CustomViewColumnType.OrgName, CustomViewColumnType.Role },
                        DefaultOnly = true,
                    });
                var existingColumns = customViews.Select(s => s.ViewId).ToList();


                var removedCols = new List<int>();
                foreach (var commonName in existingColumns)
                {
                    if (!removedCols.Contains(commonName))
                    {
                        removedCols.Add(commonName);
                    }
                }
                if (removedCols.Any())
                {
                    var spec = new CustomViewSpec { ViewIds = removedCols };
                    customAttributeFacade.RemoveCustomView(spec);
                }

                foreach (var commonName in updatedColumns)
                {
                    var customView = new CustomView
                    {
                        ProviderId = provider.Id,
                        ViewType = (CustomViewType)Enum.Parse(typeof(CustomViewType), viewType)
                    };

                    if (commonName.AttributeType.ToLowerInvariant() != "device")
                    {
                        var attr = customAttributes.GetByAttributeName(commonName.AttributeName);
                        if (attr != null)
                        {
                            customView.Columnid = CustomViewColumnType.CustomField;
                            customView.EntityId = attr.Id;
                        }
                        else if (commonName.AttributeName == IWSResources.DisplayName_Organizations)
                            customView.Columnid = CustomViewColumnType.OrgName;
                        else if (commonName.AttributeName == IWSResources.DisplayName_OperatorRoles)
                            customView.Columnid = CustomViewColumnType.Role;
                    }
                    else
                    {
                        var attr = devicesByName[commonName.AttributeName].FirstOrDefault();
                        if (attr != null)
                        {
                            customView.Columnid = CustomViewColumnType.Device;
                            customView.EntityId = attr.Id;
                        }
                    }
                    customView.OperatorId = null;
                    customAttributeFacade.SaveCustomView(customView);
                }
            }
            catch (Exception e)
            {
                messages.Add(new Message
                {
                    Value = "Save failed. " + e.Message,
                    Sender = "UpdateListPageLayout",
                    Type = MessageType.Error
                });
            }
            return Json(new { Success = messages.NoErrors(), Messages = messages });
        }


        [NonAction]
        private string FormatXml(XmlNode xmlNode)
        {
            var bob = new StringBuilder();
            using (var stringWriter = new StringWriter(bob))
            {
                using (var xmlTextWriter = new XmlTextWriter(stringWriter))
                {
                    xmlTextWriter.Formatting = Formatting.Indented;
                    xmlNode.WriteTo(xmlTextWriter);
                }
            }

            return bob.ToString();
        }

        [HttpGet]
        public JsonResult GetSectionNames(string attributeName, string pageId = null)
        {

            try
            {
                var provider = RuntimeContext.Provider;
                var layout =
                    pageLayoutFacade.GetPageLayoutBySpec(new PageLayoutSpec { ProviderId = provider.Id, PageId = pageId })
                                    .FirstOrDefault();

                var layoutXml = new LayoutXml();
                var allSections = layoutXml.GetAllSections(layout.LayoutXml, attributeName);
                return
                    Json(
                        new
                        {
                            Sections = allSections.Select(s => new { s.DisplayName, s.Name, s.IsSelected, s.IsParent, s.IsChild }),
                            Success = true
                        }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { ErrorMessage = ex.Message, Success = false }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
        public JsonResult UpdateSection(string attributeName, string sectionName, string selfServiceSectionName)
        {
            var messages = new Messages();
            try
            {
                var provider = RuntimeContext.Provider;
                var layout = pageLayoutFacade.GetPageLayoutBySpec(new PageLayoutSpec { ProviderId = provider.Id, PageId = "NEWEUM" }).FirstOrDefault();
                var xmldoc = XmlValidation.ValidateXml(layout.LayoutXml);
                var existingCommonNames = pageLayoutFacade.GetAttributeCommonNames(xmldoc);
                var custromAttributes = RuntimeContext.CustomAttributes;
                var updatedXML = layout.LayoutXml;
                foreach (var commonName in existingCommonNames)
                {
                    if (custromAttributes.All(c => c.CommonName != commonName))
                        updatedXML = pageLayoutFacade.DeleteAttributeFromLayout(commonName, sectionName, updatedXML);
                }
                updatedXML = pageLayoutFacade.UpdatePageLayoutByAttributeName(attributeName, sectionName, updatedXML);
                try
                {
                    var saveMessages = pageLayoutFacade.SavePageLayout(provider.Id, "USER", "NEWEUM", "End User Manager", updatedXML,
                        "ATTRIBUTE");
                    messages.Add(saveMessages);
                }
                catch (Exception ex)
                {
                    messages.Add(new Message { Value = ex.Message, Sender = "UpdatePageLayout", Type = MessageType.Error });
                }


                //For Self Service Layout
                var selfServiceLayout =
                    pageLayoutFacade.GetPageLayoutBySpec(
                        new PageLayoutSpec { ProviderId = provider.Id, PageId = "OPERATORDETAILS" }).FirstOrDefault();
                var sslLayoutdoc = XmlValidation.ValidateXml(selfServiceLayout.LayoutXml);
                var existingCommonNamesSelfService = pageLayoutFacade.GetAttributeCommonNames(sslLayoutdoc);
                var updatedXMLSelfService = selfServiceLayout.LayoutXml;

                foreach (var commonName in existingCommonNamesSelfService)
                {
                    if (custromAttributes.All(c => c.CommonName != commonName))
                        updatedXMLSelfService = pageLayoutFacade.DeleteAttributeFromLayout(commonName, selfServiceSectionName,
                            updatedXMLSelfService);
                }

                updatedXMLSelfService = pageLayoutFacade.UpdatePageLayoutByAttributeName(attributeName, selfServiceSectionName, updatedXMLSelfService);

                try
                {
                    var saveSelfServiceMessages = pageLayoutFacade.SavePageLayout(provider.Id, "USER", "OPERATORDETAILS",
                        "Operator Details", updatedXMLSelfService, "ATTRIBUTE");
                    messages.Add(saveSelfServiceMessages);
                }
                catch (Exception ex)
                {
                    messages.Add(new Message() { Value = ex.Message, Sender = "UpdatePageLayout", Type = MessageType.Error });

                }
                return Json(new { Messages = messages, Success = true });
            }
            catch (Exception ex)
            {
                return Json(new { ErrorMessage = ex.Message, Success = false });
            }
        }

        [HttpPost]
        public JsonResult DeleteAttributeFromLayout(string attributeName, string sectionName, string selfServiceSectionName)
        {
            var messages = new Messages();
            try
            {
                var provider = RuntimeContext.Provider;
                var layout =
                    pageLayoutFacade.GetPageLayoutBySpec(new PageLayoutSpec { ProviderId = provider.Id, PageId = "NEWEUM" })
                                    .FirstOrDefault();
                var updatedXML = pageLayoutFacade.DeleteAttributeFromLayout(attributeName, sectionName, layout.LayoutXml);
                try
                {
                    var saveMessages = pageLayoutFacade.SavePageLayout(provider.Id, "USER", "NEWEUM", "End User Manager", updatedXML,
                        "ATTRIBUTE");
                    messages.Add(saveMessages);
                }
                catch (Exception ex)
                {
                    messages.Add(new Message { Value = ex.Message, Sender = "UpdatePageLayout", Type = MessageType.Error });
                }

                var layoutSelfService =
                    pageLayoutFacade.GetPageLayoutBySpec(new PageLayoutSpec()
                    {
                        ProviderId = provider.Id,
                        PageId = "OPERATORDETAILS"
                    }).FirstOrDefault();

                var updatedSelfServiceXml = pageLayoutFacade.DeleteAttributeFromLayout(attributeName, selfServiceSectionName,
                    layoutSelfService.LayoutXml);

                try
                {
                    var saveMessages = pageLayoutFacade.SavePageLayout(provider.Id, "USER", "OPERATORDETAILS", "Operator Details",
                        updatedSelfServiceXml, "ATTRIBUTE");
                    messages.Add(saveMessages);
                }
                catch (Exception ex)
                {
                    messages.Add(new Message { Value = ex.Message, Sender = "UpdatePageLayout", Type = MessageType.Error });

                }
                return Json(new { Messages = messages, Success = true });
            }
            catch (Exception ex)
            {
                return Json(new { ErrorMessage = ex.Message, Success = false });
            }
        }

        [HttpPost]
        [PostXml]
        public JsonResult UpdatePageLayout(string xml)
        {

            var messages = new Messages();
            var provider = RuntimeContext.Provider;

            var invalidXmlMessage = new Message
            {
                Value = IWSResources.PageLayout_XmlIsNotValid,
                Sender = "UpdatePageLayout",
                Type = MessageType.Error
            };

            if (xml.IsNullOrEmpty())
            {
                messages.Add(invalidXmlMessage);
                Response.StatusCode = 400;
                return Json(new { Success = messages.NoErrors(), Messages = messages });
            }

            try
            {
                var xmldoc = XmlValidation.ValidateXml(xml);
                if (!XmlValidation.IsDocType(xmldoc))
                {
                    var proceed = XmlValidation.ValidateXmlRoot(xmldoc, "page", "id", "NEWEUM");
                    RefreshDevices(true);
                    if (proceed)
                    {

                        var attrbuteCommonNames = pageLayoutFacade.GetAttributeCommonNames(xmldoc, true);
                        var deviceCommonNames = pageLayoutFacade.GetDeviceCommonNames(xmldoc);
                        var allCommonNames = attrbuteCommonNames.Concat(deviceCommonNames).ToList();
                        var allEnabledDevices =
                            allDevices.Where(
                                d =>
                                    d.DeviceProvider.IsEnabled == "Y" && d.DeviceGroup.CommonName != "MPN" &&
                                    d.GroupId != 1 && d.GroupId != 2 && !d.IsMassDevice
                                ).Select(d => d.CommonName);

                        var noDuplicates =
                            allCommonNames.GroupBy(x => x).Where(x => x.Count() > 1 && x.Key.IsNotNullOrEmpty()).Select(
                                x => new { CommonName = x.Key, Count = x.Count() });
                        if (!noDuplicates.Any())
                        {
                            var missingDevices = allEnabledDevices.Except(deviceCommonNames).ToList();
                            if (missingDevices != null && missingDevices.Any())
                            {
                                var msg = missingDevices.Count() > 1
                                    ? IWSResources.PageLayout_EnableDevices_Missing
                                    : IWSResources.PageLayout_EnableDevice_Missing;
                                messages.Add(new Message
                                {
                                    Value = msg.FormatWith(missingDevices.Join(", ")),
                                    Type = MessageType.Error,
                                    Sender = "UpdatePageLayout"
                                });
                            }

                            var customAttributes = customAttributeCache.Get(provider.Id,
                                RuntimeContext.Provider.BaseLocale);
                            foreach (var commonName in attrbuteCommonNames)
                            {
                                if (commonName.Contains("Error:"))
                                {
                                    var sectionName = commonName.Replace("Error:", "");
                                    messages.Add(new Message
                                    {
                                        Value = IWSResources.PageLayout_FieldsTag_IsMissing.FormatWith(sectionName),
                                        Type = MessageType.Error,
                                        Sender = "UpdatePageLayout"
                                    });
                                }
                                if (commonName.IsNullOrEmpty())
                                {
                                    messages.Add(new Message
                                    {
                                        Value = IWSResources.PageLayout_InvalidAttributeName_NotBeBlank,
                                        Type = MessageType.Error,
                                        Sender = "UpdatePageLayout"
                                    });
                                }
                                if (
                                    customAttributes.Where(x => x.CommonName != (!RuntimeContext.Provider.FeatureMatrix.IsEnterpriseManagementSupported ? AttributeCommonNames.Organizations : null) && x.CommonName != (!RuntimeContext.Provider.FeatureMatrix.IsEnterpriseManagementSupported ? AttributeCommonNames.PreventUserMove : null)).All(
                                        c =>
                                            !String.Equals(c.CommonName, commonName,
                                                StringComparison.InvariantCultureIgnoreCase)))
                                {
                                    if (!commonName.Contains("Error:"))
                                    {
                                        messages.Add(new Message
                                        {
                                            Value =
                                                IWSResources.PageLayout_Invalid_Attribute_Name.FormatWith(commonName),
                                            Type = MessageType.Error,
                                            Sender = "UpdatePageLayout"
                                        });
                                    }
                                }
                            }

                            foreach (var commonName in deviceCommonNames)
                            {
                                if (!devicesByCommonName.Contains(commonName))
                                {
                                    messages.Add(new Message
                                    {
                                        Value = IWSResources.PageLayout_Invalid_Device_Name.FormatWith(commonName),
                                        Type = MessageType.Error,
                                        Sender = "UpdatePageLayout"
                                    });
                                }
                            }
                        }
                        else
                        {
                            messages.Add(new Message
                            {
                                Value =
                                    IWSResources.PageLayout_Duplicate_Found.FormatWith(
                                        noDuplicates.Select(x => x.CommonName).Join(", ")),
                                Type = MessageType.Error,
                                Sender = "UpdatePageLayout"
                            });
                        }

                    }
                    else
                    {
                        messages.Add(invalidXmlMessage);
                        Response.StatusCode = 400; //If XML is invalid, change status code to Bad Request
                    }
                }
                else
                {
                    messages.Add(invalidXmlMessage);
                    Response.StatusCode = 400; //If XML is invalid, change status code to Bad Request
                }

                if (messages.NoErrors())
                {

                    var saveMessages = pageLayoutFacade.SavePageLayout(provider.Id, "USER", "NEWEUM", "End User Manager", xml,
                        "ATTRIBUTE");
                    messages.Add(saveMessages);

                }
            }
            catch (XmlException)
            {
                messages.Add(invalidXmlMessage);
                Response.StatusCode = 400;
            }
            catch (Exception ex)
            {
                messages.Add(new Message { Value = ex.Message, Sender = "UpdatePageLayout", Type = MessageType.Error });

            }


            return Json(new { Success = messages.NoErrors(), Messages = messages });
        }

        [HttpPost]
        [PostXml]
        public JsonResult UpdateOperatorPageLayout(string xml)
        {
            var messages = new Messages();
            var provider = RuntimeContext.Provider;

            var invalidXmlMessage = new Message
            {
                Value = IWSResources.PageLayout_Operator_XmlIsNotValid,
                Sender = "UpdateOperatorPageLayout",
                Type = MessageType.Error
            };
            if (xml.IsNullOrEmpty())
            {
                messages.Add(invalidXmlMessage);
                return Json(new { Success = messages.NoErrors(), Messages = messages });
            }

            try
            {
                var xmldoc = XmlValidation.ValidateXml(xml);
                if (!XmlValidation.IsDocType(xmldoc))
                {
                    var proceed = XmlValidation.ValidateXmlRoot(xmldoc, "page", "id", "OPERATORDETAILS");
                    RefreshDevices(true);
                    if (proceed)
                    {
                        var attrbuteCommonNames = pageLayoutFacade.GetAttributeCommonNames(xmldoc, true);
                        var deviceCommonNames = pageLayoutFacade.GetDeviceCommonNames(xmldoc);
                        var allCommonNames = attrbuteCommonNames.Concat(deviceCommonNames).ToList();
                        var allEnabledDevices =
                            allDevices.Where(
                                d =>
                                    d.DeviceProvider.IsEnabled == "Y" && d.DeviceGroup.CommonName != "MPN" &&
                                    d.GroupId != 1 && d.GroupId != 2 && !d.IsMassDevice
                                ).Select(d => d.CommonName);


                        var noDuplicates =
                            allCommonNames.GroupBy(x => x).Where(x => x.Count() > 1 && x.Key.IsNotNullOrEmpty()).Select(
                                x => new {CommonName = x.Key, Count = x.Count()});
                        if (!noDuplicates.Any())
                        {
                            var missingDevices = allEnabledDevices.Except(deviceCommonNames).ToList();
                            if (missingDevices != null && missingDevices.Any())
                            {
                                var msg = missingDevices.Count() > 1
                                    ? IWSResources.PageLayout_EnableDevices_Missing
                                    : IWSResources.PageLayout_EnableDevice_Missing;
                                messages.Add(new Message
                                {
                                    Value = msg.FormatWith(missingDevices.Join(", ")),
                                    Type = MessageType.Error,
                                    Sender = "UpdateOperatorPageLayout"
                                });
                            }

                            var customAttributes = customAttributeCache.Get(provider.Id,
                                RuntimeContext.Provider.BaseLocale);
                            foreach (var commonName in attrbuteCommonNames)
                            {
                                if (commonName.Contains("Error:"))
                                {
                                    var sectionName = commonName.Replace("Error:", "");
                                    messages.Add(new Message
                                    {
                                        Value = IWSResources.PageLayout_FieldsTag_IsMissing.FormatWith(sectionName),
                                        Type = MessageType.Error,
                                        Sender = "UpdatePageLayout"
                                    });
                                }

                                if (commonName.IsNullOrEmpty())
                                {
                                    messages.Add(new Message
                                    {
                                        Value = IWSResources.PageLayout_InvalidAttributeName_NotBeBlank,
                                        Type = MessageType.Error,
                                        Sender = "UpdateOperatorPageLayout"
                                    });
                                }
                                /*if (customAttributes.Any(c => (((int)c.AttributeTypeId == 6) && (c.SupportsHistoricalValues != null && c.SupportsHistoricalValues.ToLower().Equals("y")) && String.Equals(c.CommonName, commonName, StringComparison.InvariantCultureIgnoreCase))))
                            {
                                if (!commonName.Contains("Error:"))
                                {
                                    messages.Add(new Message
                                    {
                                        Value = IWSResources.PageLayout_StatusAttribute_Message.FormatWith(commonName),
                                        Type = MessageType.Error,
                                        Sender = "UpdatePageLayout"
                                    });
                                }
                            }*/

                                if (customAttributes.Where(x => x.CommonName != (!RuntimeContext.Provider.FeatureMatrix.IsEnterpriseManagementSupported ? AttributeCommonNames.Organizations : null) && x.CommonName != (!RuntimeContext.Provider.FeatureMatrix.IsEnterpriseManagementSupported ? AttributeCommonNames.PreventUserMove : null)).All(c => !String.Equals(c.CommonName, commonName)))
                                {
                                    if (!commonName.Contains("Error:"))
                                    {
                                        messages.Add(new Message
                                        {
                                            Value =
                                                IWSResources.PageLayout_Invalid_Attribute_Name.FormatWith(commonName),
                                            Type = MessageType.Error,
                                            Sender = "UpdatePageLayout"
                                        });
                                    }
                                }
                            }

                            foreach (var commonName in deviceCommonNames)
                            {
                                if (!devicesByCommonName.Contains(commonName))
                                {
                                    messages.Add(new Message
                                    {
                                        Value = IWSResources.PageLayout_Invalid_Device_Name.FormatWith(commonName),
                                        Type = MessageType.Error,
                                        Sender = "UpdateOperatorPageLayout"
                                    });
                                }
                            }
                        }
                        else
                        {
                            messages.Add(new Message
                            {
                                Value =
                                    IWSResources.PageLayout_Duplicate_Found.FormatWith(
                                        noDuplicates.Select(x => x.CommonName).Join(", ")),
                                Type = MessageType.Error,
                                Sender = "UpdateOperatorPageLayout"
                            });
                        }

                    }
                    else
                    {
                        messages.Add(invalidXmlMessage);
                        Response.StatusCode = 400; //If XML is invalid, change status code to Bad Request
                    }
                }
                else
                {
                    messages.Add(invalidXmlMessage);
                    Response.StatusCode = 400; //If XML is invalid, change status code to Bad Request
                }
                if (messages.NoErrors())
                {

                    var saveMessages = pageLayoutFacade.SavePageLayout(provider.Id, "USER", "OPERATORDETAILS",
                        "Operator Details", xml,
                        "ATTRIBUTE");
                    messages.Add(saveMessages);

                }
            }
            catch (XmlException)
            {
                messages.Add(invalidXmlMessage);
                Response.StatusCode = 400;
            }
            catch (Exception ex)
            {
                messages.Add(new Message
                {
                    Value = ex.Message,
                    Sender = "UpdateOperatorPageLayout",
                    Type = MessageType.Error
                });
            }

            return Json(new { Success = messages.NoErrors(), Messages = messages });
        }
        [HttpGet]
        public JsonResult GetCustomViews(string viewType)
        {
            if (string.IsNullOrEmpty(viewType))
                return null;

            var provider = RuntimeContext.Provider;
            CustomAttributeLookup customAttributes = null;

            if (viewType == Enum.GetName(typeof(CustomViewType), CustomViewType.UserReport)
                || viewType == Enum.GetName(typeof(CustomViewType), CustomViewType.UserManagerV2))
            {
                RefreshDevices();
                customAttributes = RuntimeContext.CustomAttributesWithouMassDevices;
            }
            else
            {
                RefreshDevices(true, true);
                customAttributes = RuntimeContext.CustomAttributes;
            }

            var customViews =
                customAttributeFacade.GetCustomViewsBySpec(new CustomViewSpec
                {
                    ProviderId = provider.Id,
                    CustomViewType = (CustomViewType)Enum.Parse(typeof(CustomViewType), viewType),
                    IsPlaceholder = false,
                    CustomViewColumnTypes = new[] { CustomViewColumnType.CustomField, CustomViewColumnType.Device, CustomViewColumnType.OrgName, CustomViewColumnType.Role },
                    DefaultOnly = true
                });

            var customViewList = customViews as IList<CustomView> ?? customViews.ToList();

            //Remove the customviews if they don't exists by referring the provider attributes also remove if they are deleted
            var customFieldCustomViews = customViewList.Where(x => x.Columnid.Equals(CustomViewColumnType.CustomField));
            customFieldCustomViews = from cf in customFieldCustomViews
                                     join ca in customAttributes on cf.EntityId equals ca.Id
                                     where ca.Status != "DEL"
                                     select cf;

            //Remove the customviews if they don't exists by referring the devices also remove if they are deleted
            var deviceCustomViews = customViewList.Where(x => x.Columnid.Equals(CustomViewColumnType.Device));
            deviceCustomViews = from cf in deviceCustomViews
                                join device in allDevices on cf.EntityId equals device.Id
                                where device.Status != "DEL" && cf.Columnid.Equals(CustomViewColumnType.Device)
                                select cf;

            var customAttributeList = customAttributes
                .Where(
                    x =>
                        (viewType == Enum.GetName(typeof(CustomViewType), CustomViewType.UserManagerV2) && x.CommonName.Equals(CommonNames.DisplayName) == false && x.CommonName.Equals(CommonNames.UserName) == false && x.Status != "DEL" &&
                        x.IsSearchable == "Y" && x.EntityId == "USER" &&
                        x.AttributeTypeId != CustomAttributeDataType.GeoLocation)
                        ||
                        (viewType != Enum.GetName(typeof(CustomViewType), CustomViewType.UserManagerV2) && x.Status != "DEL" &&
                        x.IsSearchable == "Y" && x.EntityId == "USER" &&
                        x.AttributeTypeId != CustomAttributeDataType.GeoLocation))
                //Exclude already selected attributes from the 'available columns' list
                        .Except((from item in customAttributes from cf in customFieldCustomViews where item.Id == cf.EntityId select item).ToList());


            if (!RuntimeContext.Provider.FeatureMatrix.IsEnterpriseManagementSupported)
                customAttributeList = customAttributeList.Where(x => x.CommonName != AttributeCommonNames.Organizations && x.CommonName != AttributeCommonNames.PreventUserMove);

            var available = customAttributeList.Select(
                    x =>
                        new ColumnListLayoutItem
                        {
                            ViewId = 0,
                            Id = x.Id,
                            Name = x.AttributeName,
                            DisplayName = x.AttributeName,
                            CustomViewColumnType = "CF"
                        });


            available = available
                .Union(
                allDevices
                //Exclude already selected devices from the 'available columns' list
                    .Where(d => deviceCustomViews.Any(y => y.EntityId.Equals(d.Id)) == false)
                        .Select(
                            x =>
                                new ColumnListLayoutItem
                                {
                                    ViewId = 0,
                                    Id = x.Id,
                                    Name = x.Name,
                                    DisplayName = "{0} (Device)".FormatWith(x.Name),
                                    CustomViewColumnType = "Device"
                                })).OrderBy(x => x.DisplayName);


            if (RuntimeContext.Provider.FeatureMatrix.IsEnterpriseManagementSupported
                && customViewList.Any(y => y.Columnid.Equals(CustomViewColumnType.OrgName)) == false)
            {
                available = available.Concat(new[] {new ColumnListLayoutItem
                {
                    ViewId = 0,
		            Id = 0,
		            Name = IWSResources.DisplayName_Organizations,
		            DisplayName = IWSResources.DisplayName_Organizations,
		            CustomViewColumnType = "CF"
                }}).OrderBy(x => x.Name);
            }

            if (customViewList.Any(y => y.Columnid.Equals(CustomViewColumnType.Role)) == false)
            {
                available = available.Concat(new[] {new ColumnListLayoutItem
                {
                    ViewId = 0,
		            Id = 0,
		            Name = IWSResources.DisplayName_OperatorRoles,
		            DisplayName = IWSResources.DisplayName_OperatorRoles,
		            CustomViewColumnType = "CF"
                }}).OrderBy(x => x.Name);
            }

            var cvList = customFieldCustomViews.Union(deviceCustomViews)
                .Union(
                    customViewList.Where(
                        x => x.Columnid.Equals(CustomViewColumnType.Role) || x.Columnid.Equals(CustomViewColumnType.OrgName)));

            var existing = (from cvListItem in cvList
                            let entityName = GetCustomViewEntityName(cvListItem)
                            select new ColumnListLayoutItem
                            {
                                ViewId = cvListItem.ViewId,
                                Id = cvListItem.ViewId,
                                Name = entityName,
                                DisplayName = cvListItem.Columnid == CustomViewColumnType.Device ? "{0} (Device)".FormatWith(entityName) : entityName,
                                //categorized in CF even for organization and roles because they should be sorted just like user attributes (grouped under user attributes),
                                //then devices are sorted and grouped under user attributes
                                CustomViewColumnType = ((cvListItem.Columnid == CustomViewColumnType.CustomField) || (cvListItem.Columnid == CustomViewColumnType.OrgName) || (cvListItem.Columnid == CustomViewColumnType.Role) ? "CF" : "Device")
                            }).ToList();

            return Json(new
            {
                Available = available,
                Existing = existing

            });
        }

        /// <summary>
        /// This function returns name of the cutom view entity
        /// </summary>
        /// <param name="customView">Custom view</param>
        /// <returns>name of the cutom view entity</returns>
        [NonAction]
        private string GetCustomViewEntityName(CustomView customView)
        {
            if (customView.Columnid == CustomViewColumnType.Device)
            {
                var device = allDevices.FirstOrDefault(d => d.Id == customView.EntityId);
                if (device != null)
                    return device.Name;
            }
            else if (customView.Columnid == CustomViewColumnType.CustomField)
            {
                if (customView.EntityId.HasValue)
                {
                    var attribute = RuntimeContext.CustomAttributes.GetById((int)customView.EntityId);
                    if (attribute != null)
                        return attribute.AttributeName;
                }
            }
            else if (customView.Columnid == CustomViewColumnType.OrgName)
                return IWSResources.DisplayName_Organizations;
            else if (customView.Columnid == CustomViewColumnType.Role)
                return IWSResources.DisplayName_OperatorRoles;

            return string.Empty;
        }

        [NonAction]
        private void RefreshDevices(bool forceRefresh = true, bool includeMassDevices = false)
        {
            var provider = RuntimeContext.Provider;

            var refresh = (allDevices == null || !allDevices.Any());
            if (refresh || forceRefresh)
            {
                var deviceSpec = new DeviceSpec
                {
                    ProviderId = provider.Id,
                    IncludeDeviceProvider = true,
                    IncludeDeviceGroup = true,
                    EnabledOnly = true
                };

                if (!includeMassDevices)
                    deviceSpec.IsMassDevice = false;

                var providerDevices = deviceFacade.GetDevicesBySpec(deviceSpec, RuntimeContext.Provider.BaseLocale);
                var deviceList = providerDevices as IList<Device> ?? providerDevices.ToList();
                allDevices = deviceList;
                devicesByCommonName = deviceList.ToLookup(x => x.CommonName, StringComparer.OrdinalIgnoreCase);
                devicesByName = deviceList.ToLookup(x => x.Name, StringComparer.OrdinalIgnoreCase);
            }
        }
    }
    public class ColumnListLayoutItem
    {
        public int ViewId { get; set; }
        public int Id { get; set; }
        public string Name { get; set; }
        public string DisplayName { get; set; }
        public string CustomViewColumnType { get; set; }
    }
}