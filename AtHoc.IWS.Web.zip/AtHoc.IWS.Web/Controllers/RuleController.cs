﻿using System.Text.RegularExpressions;
using System.Web;
using System.Web.Caching;
using System.Web.UI;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Ioc;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Web;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Web.Filters;
using AtHoc.IWS.Web.Helpers;
using AtHoc.IWS.Web.Models.Rule;
using AtHoc.Global.Resources;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.Entity.Spatial;
using System.Linq;
using System.Web.Mvc;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Business.Data.SearchSpec;
using AtHoc.IWS.Business.Domain.Organization;
using AtHoc.IWS.Business.Domain.RuleModel;
using AtHoc.IWS.Business.Domain.RuleModel.Spec;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Web.Models.SearchCriteria;
using AtHoc.Publishing;
using AtHoc.Utilities;
using AtHoc.IWS.Web.Models.Publishing;
using AtHoc.Global.Resources.Interfaces;
using Rule = AtHoc.IWS.Web.Models.Rule.Rule;
using RuleTypes = AtHoc.IWS.Business.Domain.Entities.Rule.Enum.RuleTypes;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Settings.Model;

namespace AtHoc.IWS.Web.Controllers
{
    public class RuleController : AtHoc.Infrastructure.Web.Mvc.Controller
    {

        private readonly IScenarioFacade _scenarioFacade;
        private readonly ILogService _logService;
        private readonly IPublishingDomainToModel _publishingDomainToModel;
        private readonly IPublishingFacade _pubFacade;
        private readonly IRuleFacade _ruleFacade;
        private readonly IGlobalEntityLocaleFacade _globalEntityLocaleFacade;
        private readonly IWeatherModuleFacade _wmFacade;
        public RuleController(IRuleFacade ruleFacade, IScenarioFacade scenarioFacade, ILogService logService, IPublishingDomainToModel publishingDomainToModel, IPublishingFacade pubFacade, IGlobalEntityLocaleFacade globalEntityLocaleFacade, IWeatherModuleFacade weatherModule)
        {
            _scenarioFacade = scenarioFacade;
            _logService = logService;
            _publishingDomainToModel = publishingDomainToModel;
            _pubFacade = pubFacade;
            _ruleFacade = ruleFacade;
            _globalEntityLocaleFacade = globalEntityLocaleFacade;
            _wmFacade = weatherModule;
        }

        //
        // GET: /EventRule/
        [IWSAuthorize(new[] { SystemObject.InboundAlertRules }, new[] { ActionType.View })]
        public ActionResult Index()
        {
            /*
                        var orgFacade = ServiceLocator.Current.Resolve<IOrganizationFacade>();
                        ConnectivityStatus connectivityStatus = orgFacade.GetConnectivityStatus(RuntimeContext.ProviderId);
                        if (connectivityStatus == ConnectivityStatus.NotConfigured)
                        {
                            ViewBag.ConnectivityMessage = IWSResources.Organization_NotConfigured_ErrorMsg;
                            return View("_NotConnectedMessage");
                        }
                        if (connectivityStatus == ConnectivityStatus.DeviceNotConfigured)
                        {
                            ViewBag.ConnectivityMessage = IWSResources.Organization_DeviceNotConfigured_ErrorMsg;
                            return View("_NotConnectedMessage");
                        }
                        if (connectivityStatus == ConnectivityStatus.NotListed)
                        {
                            ViewBag.ConnectivityMessage = IWSResources.Organization_NotListed_ErrorMsg;
                            return View("_NotConnectedMessage");
                        }

                        var selfOrgGuid = orgFacade.GetSelfOrganizationGuid(RuntimeContext.ProviderId);

                        //Some time IWS cache and PSS are not syched,
                        if (selfOrgGuid == null)
                        {
                            ViewBag.ConnectivityMessage = IWSResources.Organization_NotListed_ErrorMsg;
                            return View("_NotConnectedMessage");
                        }
            */
            var provider = RuntimeContext.Provider;
            var vpsTimeZOne = RuntimeContext.Provider.GetVpsTimeZoneFromId();
            ViewBag.DateFormat = provider.GetDateFormat();
            ViewBag.DateTimeFormat = provider.GetDateTimeFormat();
            ViewBag.VPSTimeZone = vpsTimeZOne;
            ViewBag.UtcOffsetInMinutes = vpsTimeZOne.BaseUtcOffset.TotalMinutes;
            ViewBag.VPSOffsetFromSystemInMinutes = provider.VPSOffsetFromSystemInMinutes();
            ViewBag.SupportsDaylightSavingTime = vpsTimeZOne.SupportsDaylightSavingTime;
            ViewBag.EnableWeather = RuntimeContext.Provider.FeatureMatrix.IsWAMSupported ? "true" : "false";            
            return View();
        }
        [IWSAuthorize(new[] { SystemObject.InboundAlertRules }, new[] { ActionType.View })]
        public ActionResult GetRules()
        {
            try
            {
                var model = RulesModel.GetModel(_ruleFacade, _scenarioFacade,RuleTypes.INCOMING_ALERT_RULE.ToString());
                if (model == null)
                {
                    return Json(new { Success = false, Messages = IWSResources.EventRule_Manager_Error_General });
                }
                return Json(model);
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.EventRule_Manager_Error_General });
            }
        }

        [IWSAuthorize(new[] { SystemObject.InboundAlertRules }, new[] { ActionType.View })]
        public JsonResult GetAllZipGeoCode(string stateCode, string zipCode, int page = 0, int pageSize = 25, string orderBy = "CountyName", bool orderAsc = true)
        {
            var error = string.Empty;          
            try
            {
                if (!string.IsNullOrEmpty(stateCode) && stateCode.Length != 2)
                {
                    return Json(new
                    {
                        Success = false,
                        Data = "Error",
                        TotalCount = 0
                    });
                }

                var data = _wmFacade.GetAllZipGeoCodeList(stateCode, zipCode, page, pageSize, orderBy, (orderAsc) ? "ASC" : "DESC");
                return Json(new { Data = data.GeoCodeList, TotalCount = data.GeoCodeCount, Success = true });              
            }
            catch (Exception ex)
            {
                //   _logService.Error(() => ex);
                return Json(new { Success = false, Error ="Error State or zip code." }, "text/plain");
            }
        }



        [IWSAuthorize(new[] { SystemObject.InboundAlertRules }, new[] { ActionType.View })]
        public JsonResult GetAllStates()
        {
            try
            {
                var data = _wmFacade.GetAllStateList();
                return
                    Json(
                        new
                        {
                            Data = data.Select(s => new {value = s.StateCode, text = s.StateName}).ToList(),
                            Success = true
                        });
            }
            catch (Exception ex)
            {
                //   _logService.Error(() => ex);
                return Json(new { Success = false, Error = IWSResources.SystemSettings_InvalidSave }, "text/plain");
            }
        }


        [IWSAuthorize(new[] { SystemObject.InboundAlertRules }, new[] { ActionType.View })]
        public ActionResult LoadSearchCriteria(int ruleId)
        {
            try
            {
                if (ruleId == 0)
                {
                    return Json(new { Success = true, SearchCriteriaModel = "" });
                }

                var r = _ruleFacade.Get(ruleId, true);
                SearchEntity searchEntity = r.Criteria;
                if (searchEntity == null || searchEntity.SearchCriterias.Count == 0)
                {
                    return Json(new { Success = true, SearchCriteriaModel = "" });
                }

                SearchCriteriaModel searchCriteriaModel = GetSearchCriteraModel(searchEntity);

                var model = new { Success = true, SearchCriteriaModel = searchCriteriaModel };
                return Json(model);
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.EventRule_Manager_Error_General });
            }
        }

        [IWSAuthorize(new[] { SystemObject.InboundAlertRules }, new[] { ActionType.View })]
        public ActionResult Save(Rule rule)
        {
            try
            {

                Business.Domain.RuleModel.Rule r = rule.ToBusinessRule();
                SearchEntity searchCriteria = null;
                if (rule.SearchCriteriaInput != null)
                {

                    // set the organization value to be useCommonNameValue
                    // this is a hack for now to support dynamic values. in the future we should add it to the model and _publishingHelper.GetAdvancedQueryCriteria should add it.
                    if (rule.SearchCriteriaInput.selections != null)
                    {
                        foreach (Selection selection in rule.SearchCriteriaInput.selections)
                        {
                            if (selection.entity.commonName.Equals("ALERT-SOURCE-ORGANIZATION", StringComparison.InvariantCultureIgnoreCase))
                            {
                                selection.useCommonNameValue = true;
                            }
                        }

                        searchCriteria = new SearchEntity()
                        {
                            SearchCriterias = new List<SearchCriteria>() { UserAdvanceSearchModel.ConvertSearchCriteriaModel(rule.SearchCriteriaInput) }
                        };
                    }
                }
                // save here                
                int id = 0;
                if (r.Id > 0)
                {
                    bool ret = _ruleFacade.Update(r, searchCriteria);
                    if (ret)
                    {
                        id = r.Id;
                    }
                }
                else
                {
                    id = _ruleFacade.Save(r, searchCriteria);
                }

                if (id <= 0)
                {
                    return Json(new { Success = false, Messages = IWSResources.EventRule_Manager_Error_Save });
                }

                return Json(new { Success = true, Id = id });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.EventRule_Manager_Error_General });
            }
        }

        [IWSAuthorize(new[] { SystemObject.InboundAlertRules }, new[] { ActionType.View })]
        public ActionResult Delete(List<int> ids)
        {
            try
            {

                bool ret = _ruleFacade.Delete(ids);
                if (ret)
                {
                    return Json(new { Success = true });
                }

                return Json(new { Success = false, Messages = IWSResources.EventRule_Manager_Error_Delete });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.EventRule_Manager_Error_General });
            }
        }

        [IWSAuthorize(new[] { SystemObject.InboundAlertRules }, new[] { ActionType.View })]
        public ActionResult Reorder(List<RuleOrder> orderedRules)
        {
            try
            {
                bool ret = _ruleFacade.ReOrder(orderedRules);
                if (ret)
                {
                    return Json(new { Success = true });
                }

                return Json(new { Success = false, Messages = IWSResources.EventRule_Manager_Error_Reorder });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.EventRule_Manager_Error_General });
            }
        }



        [IWSAuthorize(new[] { SystemObject.InboundAlertRules }, new[] { ActionType.View })]
        public ActionResult GetWeather()
        {

           
           
            try
            {
                var model = RulesModel.GetModel(_ruleFacade, _scenarioFacade,RuleTypes.INCOMING_FEED_RULE.ToString());

                model.Rules.ForEach(s => s.isEnable = s.isEnable == "Yes" ? IWSResources.General_YesButton : IWSResources.General_NoButton);
                if (model == null)
                {
                    return Json(new { Success = false, Messages = IWSResources.EventRule_Manager_Error_General });
                }
                
                return Json(new { Success = true, response = model.Rules,TotalCount=model.Rules.Count });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.EventRule_Manager_Error_General });
            }
        }

       //
        // GET: /EventRule/
        [IWSAuthorize(new[] { SystemObject.InboundAlertRules }, new[] { ActionType.View })]
        public ActionResult RuleDetail(int ruleId=0)
        {

            ViewBag.RuleId = ruleId;
            ViewBag.IsWAMSupported = RuntimeContext.Provider.FeatureMatrix.IsWAMSupported;
            return View();
        }
        [IWSAuthorize(new[] { SystemObject.InboundAlertRules }, new[] { ActionType.View })]
       
        public JsonResult PopulateDataSource(string providerId, string[] filterIds,int ruleId)
        {
            var data = new ArrayList();
            try
            {
                var ruleAttributes = _ruleFacade.GetRuleAttributeLookup("WAM").Where(a => a.EntityId=="WAM")
                 .Select(
                     x =>
                         new AtHoc.IWS.Web.Models.UserManager.CustomAttributeForQuery
                         {
                             name = x.AttributeName,
                             dataType = x.AttributeTypeId.ToString(),
                             dataTypeId = (int)x.AttributeTypeId,
                             id = x.Id,
                             entityType = AtHoc.IWS.Web.Models.UserManager.GroupType.ATTRIBUTE.ToString(),
                             commonName = x.CommonName,
                             values =
                                 (x.Values == null)
                                     ? Enumerable.Empty<AtHoc.IWS.Web.Models.UserManager.CustomAttributeValueForQuery>()
                                     : x.Values.Select(
                                         y =>
                                             new AtHoc.IWS.Web.Models.UserManager.CustomAttributeValueForQuery
                                             {
                                                 name = y.ValueName,
                                                 id = y.ValueId,
                                                 commonName = y.CommonName
                                             })
                         }
                 ).OrderBy(x => x.name);

                var model = RulesModel.GetModel(_ruleFacade, _scenarioFacade,RuleTypes.INCOMING_FEED_RULE.ToString());
                var ruleList = model.Rules;
                data.Add(new { Data = ruleAttributes });
                data.Add(new { FilterId = "SCENARIOS", Data = model.WamAlertScenarios });

                var r = _ruleFacade.Get(ruleId, true, RuleTypes.INCOMING_FEED_RULE.ToString());
                SearchCriteriaModel searchCriteriaModel = null;

                if (r != null && r.Criteria!=null)
                    searchCriteriaModel = GetSearchCriteraModel(r.Criteria);

                return Json(new { Success = true, Data = data, RuleList = ruleList, CriteriaModel = searchCriteriaModel });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Alert_List_Error_Generic });
            }
        }

        private SearchCriteriaModel GetSearchCriteraModel(SearchEntity searchEntity)
        {
            TargetingSpecification ts = new TargetingSpecification();
            ts.TargetingCriteria = searchEntity.SearchCriterias.ToList<ISearchCriteria>();
            SearchCriteriaModel searchCriteriaModel = _publishingDomainToModel.GetAdvancedQueryCriteria(ts, RuntimeContext.Provider);

            // set the organization value to be useCommonNameValue
            // this is a hack for now to support dynamic values. in the future we should add it to the model and _publishingHelper.GetAdvancedQueryCriteria should add it.
            foreach (Selection selection in searchCriteriaModel.selections)
            {
                //if (selection.entity.commonName.Equals("ALERT-SOURCE-ORGANIZATION", StringComparison.InvariantCultureIgnoreCase))
                if (selection.entity.commonName.Equals("ALERT-SOURCE-ORGANIZATION", StringComparison.InvariantCultureIgnoreCase))
                {
                    selection.useCommonNameValue = true;
                    foreach (var value in selection.value)
                    {
                        value.commonName = value.text;
                    }
                }
            }
            return searchCriteriaModel;
        }

        [IWSAuthorize(new[] { SystemObject.InboundAlertRules }, new[] { ActionType.View })]
        public ActionResult DeleteWeather(List<int> ids)
        {
            try
            {

                bool ret = _ruleFacade.DeleteWeather(ids);
                if (ret)
                {
                    return Json(new { Success = true });
                }

                return Json(new { Success = false, Messages = IWSResources.EventRule_Manager_Error_Delete });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.EventRule_Manager_Error_General });
            }
        }
    }
}