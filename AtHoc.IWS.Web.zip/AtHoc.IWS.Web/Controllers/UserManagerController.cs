﻿using System.Collections;
using AtHoc.Diagnostics;
using AtHoc.Global.Resources.Interfaces;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Security;
using AtHoc.Infrastructure.Serialization;
using AtHoc.Infrastructure.Web.Mvc.ActionFilters;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.Audit;
using AtHoc.IWS.Business.Domain.Authorization;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.IWS.Business.Domain.Devices;
using AtHoc.IWS.Business.Domain.Devices.Spec;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.PageLayout;
using AtHoc.IWS.Business.Domain.PageLayout.Spec;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Users.Impl.Search;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Business.Domain.Users.Search.UserImport;
using AtHoc.IWS.Business.Domain.Users;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.IWS.Business.Domain.VirtualSystem;
using AtHoc.IWS.Business.Domain.VirtualSystem.Spec;
using AtHoc.IWS.Interfaces.Services;
using AtHoc.IWS.Map;
using AtHoc.IWS.Web.Configurations;
using AtHoc.IWS.Web.Configurations.Constants;
using AtHoc.IWS.Web.Context;
using AtHoc.IWS.Web.Converter.SearchCriteria;
using AtHoc.IWS.Web.Filters;
using AtHoc.IWS.Web.Helpers;
using AtHoc.IWS.Web.Models.UserManager;
using AtHoc.Global.Resources;
using AtHoc.Operators;
using AtHoc.Security;
using AtHoc.Systems;
using AtHoc.VirtualSystems;
using EO.Pdf;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using AttributeCriteria = AtHoc.IWS.Business.Domain.Users.Search.AttributeCriteria;
using Controller = AtHoc.Infrastructure.Web.Mvc.Controller;
using Formatting = AtHoc.Infrastructure.Serialization.Formatting;
using JsonResult = System.Web.Mvc.JsonResult;
using AtHoc.IWS.Web.Models.Export;
using PhoneNumbers;
using AlertChannel = AtHoc.IWS.Business.Domain.Entities.AlertChannel;
using DistributionList = AtHoc.IWS.Business.Domain.Entities.DistributionList;
using Hierarchy = AtHoc.IWS.Business.Domain.Entities.Hierarchy;
using AtHoc.Global.Resources.Entities;
using AtHoc.Global.Resources.Implementations;
using AtHoc.Global.Resources;
using System.Text.RegularExpressions;
using EO.Pdf.Mvc;
using AtHoc.Utilities;
using AtHoc.Infrastructure.Security;
using ActionType = AtHoc.IWS.Business.Domain.Entities.ActionType;
using DateTimeConverter = AtHoc.IWS.Business.DateTimeConverter;
using Microsoft.Practices.Unity;
using System.Data.SqlClient;
using AtHoc.IWS.Interfaces.Business.Users;
using AtHoc.IWS.Users.Business;
using AtHoc.IWS.Interfaces.Services.Users;
using AtHoc.IWS.Users.Services;
using AtHoc.IWS.Users.DataAccess;
using AtHoc.IWS.Interfaces.DataAccess.Users;
using AtHoc.IWS.Interfaces.DataAccess.Global;
using AtHoc.IWS.Global.DataAccess;
using AtHoc.IWS.Interfaces.DataAccess.Orgs;
using AtHoc.IWS.Orgs.DataAccess;
using System.Data;
using CsvHelper;
using AtHoc.IWS.Interfaces.DataAccess.Attributes;
using AtHoc.IWS.Attributes.DataAccess;
using AtHoc.IWS.Models.UserSync;
using Microsoft.SqlServer.Types;
using System.Data.SqlTypes;
using Newtonsoft.Json;
using System.Diagnostics;
using HierarchySpec = AtHoc.IWS.Business.Domain.Users.Spec.HierarchySpec;


namespace AtHoc.IWS.Web.Controllers
{

    public class UserManagerController : Controller
    {
        private static List<PagerCarrierEntity> _pagerCarriers;
        private static IEnumerable<Device> _allDevices;
        private static ILookup<string, Device> _devicesByCommonName;
        private static ILookup<string, Device> _devicesByName;
        private static IEnumerable<OperatorRole> _operatorRoles;
        private static IEnumerable<OperatorRole> _allRoles;
        private IEnumerable<AlertChannel> _operatorAccessibleChannels;
        private IEnumerable<AlertChannel> _vpsChannels;
        private IEnumerable<DistributionList> _operatorAccessibleDistributionLists;
        private readonly IAtHocConfigurations _configurations;
        private readonly IUserFacade _userFacade;
        private readonly IUserExportImportFacade _userExportImportFacade;
        private readonly IVirtualSystemFacade _virtualSystemFacade;
        private readonly ICustomAttributeFacade _customAttributeFacade;
        private readonly IPageLayoutFacade _pageLayoutFacade;
        private readonly IDeviceFacade _deviceFacade;
        private readonly IOperatorDetailsFacade _operatorDetailsFacade;
        private readonly IOperatorFacade _operatorFacade;
        private readonly IOperatorAuditFacade _operatorAuditFacade;
        private readonly ISearchCriteriaConverter _userBaseConverterService;
        private readonly IUserManagerHelper _userManagerHelper;
        private readonly IPublishingFacade _publishingFacade;
        private readonly IAuthFacade _authFacade;
        private readonly IProviderFacade _providerFacade;
        private readonly IGlobalEntityLocaleFacade _globalEntityLocaleFacade;

        const string ACTIVE_LABEL = "Active";
        const string IN_ACTIVE_LABEL = "Inactive";
        const string NOT_AVAILABLE_LABEL = "Not Available";
        const string AVAILABLE_LABEL = "Available";

        /// <summary>
        /// Variable to represent PhoneNumberUtil instance.
        /// </summary>
        private static PhoneNumbers.PhoneNumberUtil _phoneNumberUtilInstance;

        /// <summary>
        /// Property to get the instance of PhoneNumberUtil.
        /// </summary>
        private static PhoneNumbers.PhoneNumberUtil PhoneNumberUtilInstance
        {
            get
            {
                _phoneNumberUtilInstance = _phoneNumberUtilInstance ?? PhoneNumbers.PhoneNumberUtil.GetInstance();
                return _phoneNumberUtilInstance;
            }
        }

        public UserManagerController(IAtHocConfigurations configurations,
                                    IUserFacade userFacade, IVirtualSystemFacade virtualSystemFacade, ICustomAttributeFacade customAttributeFacade,
                                    IPageLayoutFacade pageLayoutFacade, IDeviceFacade deviceFacade,
                                    IOperatorDetailsFacade operatorDetailsFacade, IOperatorFacade operatorFacade, IOperatorAuditFacade operatorAuditFacade,
                                    IUserExportImportFacade userExportImportFacade,
                                    ISearchCriteriaConverter userBaseConverterService, IUserManagerHelper userManagerHelper, IPublishingFacade publishingFacade,
                                    IAuthFacade authFacade, IProviderFacade providerFacade, IGlobalEntityLocaleFacade globalEntityLocaleFacade)
        {
            _configurations = configurations;
            _userFacade = userFacade;
            _virtualSystemFacade = virtualSystemFacade;
            _customAttributeFacade = customAttributeFacade;
            _pageLayoutFacade = pageLayoutFacade;
            _deviceFacade = deviceFacade;
            _operatorDetailsFacade = operatorDetailsFacade;
            _operatorFacade = operatorFacade;
            _operatorAuditFacade = operatorAuditFacade;
            _userExportImportFacade = userExportImportFacade;
            _userBaseConverterService = userBaseConverterService;
            _userManagerHelper = userManagerHelper;
            _publishingFacade = publishingFacade;
            _authFacade = authFacade;
            _providerFacade = providerFacade;
            _globalEntityLocaleFacade = globalEntityLocaleFacade;
        }

        #region "End User Details"
        [IWSAuthorize(new[] { SystemObject.EndUsers }, new[] { ActionType.View })]
        [HttpGet]
        public JsonResult GetUserDetails(int userId, bool loadEmptyAttributes = false)
        {
            var provider = RuntimeContext.Provider;
            var currentUser = RuntimeContext.Operator;
            var endUserDetails =
                _userFacade.GetUserBySpec(new UserSpec
                {
                    ProviderId = provider.Id,
                    OperatorId = currentUser.Id,
                    CustomFieldFormat = true,
                    UserId = userId,
                    GetUserAttributes = true
                });
            return Json(new { UserDetails = endUserDetails, }, JsonRequestBehavior.AllowGet);
        }

        [IWSAuthorize(new[] { SystemObject.EndUsers }, new[] { ActionType.View })]
        [HttpGet]
        public JsonResult GetEndUserDetails(int userId, bool loadEmptyAttributes = false)
        {
            _userManagerHelper.RefreshCarrier(ref _pagerCarriers);

            var provider = RuntimeContext.Provider;
            var currentUser = RuntimeContext.Operator;
            var message = new Message();

            if (userId > 0 && (!_userFacade.CheckUsersInOperatorBase(new List<int> { userId }, RuntimeContext.ProviderId, RuntimeContext.OperatorId)))
            {
                TimeZoneInfo vpsTimeZone = provider.GetVpsTimeZoneFromId();
                string dtFormat = provider.GetDateTimeFormat();
                TempData["IsCrossTenantAccess"] = true;
                var errorMessage = new Message()
                {
                    Type = MessageType.Error,
                    Value = IWSResources.User_Security,
                    Sender = "EndUser Save"
                };
                return
                    Json(
                        new
                        {
                            Success = false,
                            Messages = errorMessage,
                            UserId = userId,
                            UserStatus = "",
                            Rows = "",
                            EndUserFullName = "",
                            OrgHirarchy = "",
                            DateFormat = provider.GetDateFormat(),
                            DateTimeFormat = dtFormat,
                            VPSTimeZone = vpsTimeZone,
                            UtcOffsetInMinutes = vpsTimeZone.BaseUtcOffset.TotalMinutes,
                            PagerCarrier = "",
                            MaxEnabledUserCount = 0,
                            ShowGrantOperatorPermissionsBtn = false,
                            IsUnAuthorizedAccess = true
                        },
                        JsonRequestBehavior.AllowGet);
            }

            var layout = _pageLayoutFacade.GetPageLayoutBySpec(
                new PageLayoutSpec { ProviderId = provider.Id, PageId = "NEWEUM" }
            ).FirstOrDefault();

            if (layout != null)
            {
                //Todo: move to cache
                _userManagerHelper.RefreshDevices(ref _allDevices, ref _devicesByCommonName, ref _devicesByName, true);

                var endUserDetails = userId == -1 ? new User { UserAttributes = new List<UserAttribute>() } :
                    _userFacade.GetUserBySpec(new UserSpec
                    {
                        ProviderId = provider.Id,
                        OperatorId = currentUser.Id,
                        CustomFieldFormat = true,
                        UserId = userId,
                        GetUserAttributes = true
                    });
                if (endUserDetails != null)
                {
                    string endUserFullName;
                    string orgH;
                    IEnumerable<PageLayoutRow> allRowsFromXml;
                    TimeZoneInfo vpsTimeZone = provider.GetVpsTimeZoneFromId();
                    string dtFormat = provider.GetDateTimeFormat();
                    string userStatus;
                    var devices = endUserDetails.UserDevice.ToList();

                    //Getting the localized custom attributes based on locale
                    endUserDetails.UserAttributes = LocalizedCustomAttributeValues(endUserDetails, ProviderAttributes);

                    var ssAuthOption = _virtualSystemFacade.UserPasswordRequired(provider.Id);
                    _handleUserDetails(userId, loadEmptyAttributes, provider, currentUser, layout, endUserDetails, ssAuthOption, out endUserFullName, out orgH, out allRowsFromXml, out userStatus);
                    var passwordSection = allRowsFromXml
                  .SelectMany(c => c.Columns)
                  .SelectMany(b => b.Buckets)
                  .SelectMany(s => s.Sections)
                  .SelectMany(k => k.Attributes)
                  .FirstOrDefault(
                      x => x.CommonName == CommonNames.UserPassword
                      );
                    if (passwordSection != null)
                    {
                        passwordSection.Value = passwordSection.DisplayValue;
                    }
                    //As password is not more mandatory for Manual SS Auth based on TODO
                    bool isPasswordRequired = false;
                    if (ssAuthOption)
                    {
                        var roles = _userManagerHelper.GetOperatorRolesInSystem(userId);
                        if (roles.Any())
                            isPasswordRequired = true;
                    }

                    var pagerCarriersRequiredInJsonPayload = _allDevices.Where(x => x.GroupId == 6).ToList().Any(device => layout.LayoutXml.Contains(device.CommonName));


                    return
                        Json(
                            new
                            {
                                UserId = userId,
                                UserStatus = userStatus,
                                Rows = allRowsFromXml,
                                EndUserFullName = endUserFullName,
                                OrgHirarchy = orgH,
                                DateFormat = provider.GetDateFormat(),
                                DateTimeFormat = dtFormat,
                                VPSTimeZone = vpsTimeZone,
                                UtcOffsetInMinutes = vpsTimeZone.BaseUtcOffset.TotalMinutes,
                                PagerCarrier = pagerCarriersRequiredInJsonPayload ? _pagerCarriers.Select(p => new { CarrierId = p.Carrierid, CarrierName = p.Carriername }) : null,
                                MaxEnabledUserCount = _virtualSystemFacade.GetMaxEnabledUsersCap(provider.Id),
                                ShowGrantOperatorPermissionsBtn = endUserDetails.ProviderId == provider.Id,
                                IsUnAuthorizedAccess = false,
                                IsPasswordRequired = isPasswordRequired
                            },
                            JsonRequestBehavior.AllowGet);
                }
            }


            return Json(new { Rows = message, EndUserFullName = "", IsUnAuthorizedAccess = false }, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Localized custom attribute values by reading the data from cache based on locale
        /// </summary>
        /// <param name="endUser">User object.</param>
        /// <param name="providerAttributes">CustomAttributeLookup object</param>
        /// <returns>Returns localized IEnumerable<UserAttribute></returns>
        private IEnumerable<UserAttribute> LocalizedCustomAttributeValues(User endUser, CustomAttributeLookup providerAttributes)
        {
            if (providerAttributes.Count() == 0) return endUser.UserAttributes;

            var customUserAttributes = providerAttributes.Where(y => y.Values != null).Select(z => z.Values);

            var userAttributes = new List<UserAttribute>();
            userAttributes.AddRange(endUser.UserAttributes);

            GlobalEntityLocaleFacade globalEntityLocaleFacade = new GlobalEntityLocaleFacade(new GlobalEntityLocaleRepository());

            foreach (var userAttribute in userAttributes)
            {
                if (userAttribute.AttributeTypeId == (int)CustomAttributeDataType.Picklist || userAttribute.AttributeTypeId == (int)CustomAttributeDataType.MultiPicklist)
                {
                    var attributeValue = !string.IsNullOrEmpty(userAttribute.Value) ? Convert.ToInt32(userAttribute.Value) : -1;
                    if (attributeValue >= 0)
                    {
                        var localizedAttributeValues = customUserAttributes.Select(z => z.Where(y => y.AttributeId == userAttribute.Id
                            && y.ValueId == attributeValue).FirstOrDefault());

                        if (localizedAttributeValues != null)
                        {
                            var localizedAttributeValue = localizedAttributeValues.Where(x => x != null).FirstOrDefault();
                            if (localizedAttributeValue != null)
                            {
                                userAttribute.DisplayValue = localizedAttributeValue.ValueName;
                            }
                        }
                    }
                }

                //Code to localize Checkbox and available not available options
                if (userAttribute.AttributeTypeId == (int)CustomAttributeDataType.Checkbox)
                {
                    var value = userAttribute.DisplayValue;
                    if (!string.IsNullOrEmpty(value))
                    {
                        userAttribute.DisplayValue = globalEntityLocaleFacade.GetLocalizedValue(value, BusinessEntity.CheckBox,
                            "Name",
                            RuntimeContext.Provider.BaseLocale);
                    }
                }
            }
            return userAttributes;
        }

        [NonAction]
        private void _handleUserDetails(int userId, bool loadEmptyAttributes, Provider provider, OperatorUser currentUser, PageLayout layout, User endUserDetails, bool userPasswordRequired, out string endUserFullName, out string orgH, out IEnumerable<PageLayoutRow> allRowsFromXml, out string userStatus)
        {
            endUserFullName = endUserDetails.GetDisplayName();
            orgH = string.Empty;
            var orgHirarchy =
                _userFacade.GetHierarchyBySpec(new HierarchySpec
                {
                    ProviderId = provider.Id,
                    AvailableForLists = false,
                    HierarchyType = HierarchyType.ORG,
                    BaseLocale = provider.BaseLocale
                }).FirstOrDefault();
            if (orgHirarchy != null)
            {
                orgH = orgHirarchy.Name + "|";
                var orgHirarchyVal = endUserDetails.UserAttributes.FirstOrDefault(a => a.CommonName == orgHirarchy.CommonName);
                if (orgHirarchyVal != null)
                {
                    orgH += orgHirarchyVal.DisplayValue;
                }
            }

            EndUserDetails eumModel;



            if (RuntimeContext.ProviderId != provider.Id)
            {
                eumModel = new EndUserDetails(endUserDetails, RuntimeContext.Provider, layout.LayoutXml.ToXmlDocument());
                var providerAttrs =
                    new CustomAttributeLookup(_customAttributeFacade.GetCustomAttributesBySpec(new CustomAttributeSpec
                    {
                        ProviderId = RuntimeContext.ProviderId,
                        IncludeValues = true,
                        IncludeTargeting = true,
                        BaseLocale = RuntimeContext.Provider.BaseLocale
                    }).Where(x => x.EntityId == "USER"));
                allRowsFromXml = eumModel.LoadPageLayoutRows(userId, providerAttrs, _allDevices, loadEmptyAttributes,
                    userPasswordRequired);
            }
            else
            {
                eumModel = new EndUserDetails(endUserDetails, provider, layout.LayoutXml.ToXmlDocument());
                allRowsFromXml = eumModel.LoadPageLayoutRows(userId, ProviderAttributes, _allDevices, loadEmptyAttributes,
                    userPasswordRequired);

            }

            var userStausAttribute = endUserDetails.UserAttributes.FirstOrDefault(u => u.CommonName == CommonNames.Status);
            //userStatus = userStausAttribute != null ? userStausAttribute.DisplayValue : "";
            //As DisplayValues will be in localized language we can't use the string comparision any more using displayvalues but we can compare the status values with common name as they never change
            //In this case the possible values will be VLD, DSB and DEL
            //IWS-23442 -> On Edit user page, For Enable user also option Enable is shown from More actions
            userStatus = (userStausAttribute != null) ? RuntimeContext.CustomAttributeValues.GetById(int.Parse(userStausAttribute.Value)).CommonName : string.Empty;

            var mobileAndDesktopNotifierSection = allRowsFromXml
                    .SelectMany(c => c.Columns)
                    .SelectMany(b => b.Buckets)
                    .SelectMany(s => s.Sections)
                    .FirstOrDefault(
                        k => k.Id.IsNotNullOrEmpty() && k.Id.ToLowerInvariant() == SectionLayoutConfig.MobileAndDesktopNotifier
                        );

            var mobileNotifierSection = allRowsFromXml
                   .SelectMany(c => c.Columns)
                   .SelectMany(b => b.Buckets)
                   .SelectMany(s => s.Sections)
                   .FirstOrDefault(
                       k => k.Id.IsNotNullOrEmpty() && k.Id.ToLowerInvariant() == SectionLayoutConfig.MobileNotifier
                       );

            var devices = _deviceFacade.GetDevicesBySpec(new DeviceSpec { CommonNames = new List<string> { CommonNames.DesktopDevice, CommonNames.MobileNotifierDevice }, EnabledOnly = true, ProviderId = provider.Id }, RuntimeContext.Provider.BaseLocale);

            var notificationInfo = _deviceFacade.GetNotificationInfo(userId, RuntimeContext.Provider.BaseLocale);

            var desktopDeviceAttribute = devices.FirstOrDefault(c => c.CommonName == CommonNames.DesktopDevice);
            var mobileNotifierAttribute = devices.FirstOrDefault(c => c.CommonName == CommonNames.MobileNotifierDevice);

            if (mobileAndDesktopNotifierSection != null)
            {
                if (desktopDeviceAttribute != null)
                {
                    var displayDesktopAttribute = _userManagerHelper.BuildDisplayDesktopAttribute(notificationInfo);
                    if (displayDesktopAttribute != null)
                        mobileAndDesktopNotifierSection.AddAttribute(displayDesktopAttribute);
                }

                if (mobileNotifierAttribute != null)
                {
                    var displayMobileAttribute = _userManagerHelper.BuildDisplayMobileAttribute(notificationInfo);
                    if (displayMobileAttribute != null)
                        mobileAndDesktopNotifierSection.AddAttribute(displayMobileAttribute);
                }
            }
            else if (mobileNotifierSection != null)
            {
                if (mobileNotifierAttribute != null)
                {
                    var displayMobileAttribute = _userManagerHelper.BuildDisplayMobileAttribute(notificationInfo);
                    if (displayMobileAttribute != null)
                        mobileNotifierSection.AddAttribute(displayMobileAttribute);
                }

            }

            var membershipsAndAssociations = allRowsFromXml
                .SelectMany(c => c.Columns)
                .SelectMany(b => b.Buckets)
                .SelectMany(s => s.Sections)
                .FirstOrDefault(
                    k => k.Id.IsNotNullOrEmpty() && k.Id.ToLowerInvariant() == SectionLayoutConfig.MembershipsAndAssociations
                );

            if (membershipsAndAssociations != null)
            {
                membershipsAndAssociations.Attributes.RemoveAll(s => s.AttributeId > 0);
                var staticDestributionList = _userFacade.GetStaticDistributionLists(
                    new DistributionListSpec
                    {
                        ProviderId = provider.Id,
                        UserId = userId,
                        ExcludeDeleted = true,
                        OrderBy = DistributionList.Meta.Name,
                        IsSystem = false
                    }
                ).ToArray();

                var staticDestributionListValue = staticDestributionList.Select(l => l.Definition).ToArray().Join(",");
                var staticDestributionListDisplayValue = staticDestributionList.Select(l => l.Name).Join(", ");
                var attributeValues = new List<CustomAttributeValue>();

                var providerStaticDestributionList = _userFacade.GetStaticDistributionLists(
                    new DistributionListSpec
                    {
                        ProviderId = provider.Id,
                        ExcludeDeleted = true,
                        IsCascaded = false,
                        IsSystem = false
                    });

                var userSpec = SystemUserSpec.CreateHasAccessList();
                userSpec.OperatorId = currentUser.Id;
                userSpec.ProviderId = provider.Id;
                var currentOperator = _operatorFacade.GetUser(userSpec);
                if (currentOperator != null &&
                    !currentOperator.EntityAccessList.Any(
                        d =>
                            d.AccessType == SectionLayoutConfig.MemebershipAccessType &&
                            d.EntityType == SectionLayoutConfig.MemebershipEntityType && d.EntityId == -1))
                {
                    foreach (var lstItem in providerStaticDestributionList)
                    {
                        if (
                            currentOperator.IsManagableAccessListUnrestricted() ||
                            currentOperator.EntityAccessList.Any(
                                d =>
                                    d.AccessType == SectionLayoutConfig.MemebershipAccessType &&
                                    d.EntityType == SectionLayoutConfig.MemebershipEntityType && d.EntityId == lstItem.Id))
                        {
                            attributeValues.Add(new CustomAttributeValue
                            {
                                CommonName = lstItem.CommonName,
                                ValueName = lstItem.Name,
                                ValueId = int.Parse(lstItem.Definition),
                                IsReadOnly = false
                            });
                        }
                        else
                        {
                            attributeValues.Add(new CustomAttributeValue
                            {
                                CommonName = lstItem.CommonName,
                                ValueName = lstItem.Name,
                                ValueId = int.Parse(lstItem.Definition),
                                IsReadOnly = true
                            });
                        }
                    }
                }
                else
                {
                    attributeValues.AddRange(
                        providerStaticDestributionList.Select(
                            s =>
                                new CustomAttributeValue
                                {
                                    CommonName = s.CommonName,
                                    ValueName = s.Name,
                                    ValueId = int.Parse(s.Definition),
                                    IsReadOnly = false
                                }));
                }
                membershipsAndAssociations.AddAttribute(
                    new CustomAttribute
                    {
                        Values = attributeValues.OrderBy(v => v.ValueName),
                        AttributeName = IWSResources.AttributeName_StaticDistributionList,
                        CommonName = "StaticDistributionList",
                        EditLevel = 2,
                        AttributeTypeId = CustomAttributeDataType.MultiPicklist
                    }, "StaticDistributionList", 11,
                    IWSResources.AttributeName_StaticDistributionList, staticDestributionListValue, staticDestributionListDisplayValue);
            }
        }

        [IWSAuthorize(new[] { SystemObject.EndUsers }, new[] { ActionType.Modify })]
        [HttpPost]
        public JsonResult SaveEndUserDetails(string updatedUser)
        {
            var currentUser = RuntimeContext.Operator;
            var provider = RuntimeContext.Provider;
            int userId = 0;
            int userProviderId = RuntimeContext.ProviderId;
            DataTable payload;
            var messages = new Messages();
            bool result;
            List<int> staticDls = null;

            try
            {
                payload = JsonConvert.DeserializeObject<DataTable>(updatedUser);


                if (payload != null && payload.Rows.Count == 0)
                {
                    messages.Add(new Message { Type = MessageType.Error, Value = IWSResources.UserManager_Invalid_Request, Sender = "EndUser Save" });
                    result = false;
                    return Json(new { Success = result, Messages = messages });
                }

                if (payload != null && payload.Columns.Contains("StaticDistributionList") && payload.Rows.Count > 0)
                {
                    var staticDl = payload.Rows[0]["StaticDistributionList"].ToString();
                    if (staticDl == string.Empty)
                    {
                        staticDls = new List<int>();
                    }
                    else if (staticDl != "-1")
                    {
                        staticDls = staticDl.Split(',').Select(x => Convert.ToInt32(x)).ToList();
                    }
                    payload.Columns.Remove("StaticDistributionList");
                }

                //Check Operator has permissions
                if (currentUser == null || (!currentUser.HasPermission(SystemObject.EndUsers, ActionType.Modify)))
                {
                    messages.Add(new Message { Type = MessageType.Error, Value = "Do not have permission", Sender = "EndUser Save" });
                    result = false;
                    return Json(new { Success = result, Messages = messages });
                }

                userId = payload != null ? Convert.ToInt32(payload.Rows[0][AtHoc.IWS.Business.Configurations.Constants.UserId]) : 0;
                if (userId > 0)
                {
                    if (!_userFacade.CheckUsersInOperatorBase(new List<int> { userId }, RuntimeContext.ProviderId,
                            RuntimeContext.OperatorId))
                    {
                        TempData["IsCrossTenantAccess"] = true;
                        messages.Add(new Message
                        {
                            Type = MessageType.Error,
                            Value = IWSResources.User_Security,
                            Sender = "EndUser Save"
                        });
                        result = false;
                        return Json(new { Success = result, Messages = messages, IsUnAuthorizedAccess = true });
                    }
                }
                if (payload != null && payload.Columns.Contains(AtHoc.IWS.Business.Configurations.Constants.UserId))
                {
                    payload.Columns.Remove(AtHoc.IWS.Business.Configurations.Constants.UserId);
                }
                ModelConversionForAPI(payload);

                payload.Columns.Add(AtHoc.IWS.Business.Configurations.Constants.UserId, typeof(int));
                payload.Rows[0][AtHoc.IWS.Business.Configurations.Constants.UserId] = userId;

                var userSyncService = ResolveAPIDependecies().Resolve<IUserSyncService>();

                var resultDataTable = userSyncService.SyncByUserId(RuntimeContext.ProviderId, RuntimeContext.Provider.BaseLocale, payload, staticDls, currentUser.Id);
                
                if (resultDataTable.Errors.Count == 0 && resultDataTable.Value.Rows[0][":SyncStatus"].ToString() == "Ok")
                {
                    result = true;
                    bool isUnAuthorizedAccess = false;
                    if (userId > 0)
                    {
                        if (RuntimeContext.Operator.Id == userId)
                            RuntimeContext.RefreshOperatorContext();


                        if (payload.Columns.Cast<DataColumn>().Any(x => x.ColumnName == AttributeCommonNames.Status) &&
                            payload.Rows[0][AttributeCommonNames.Status].ToString() ==
                            AttributeCommonNames.StatusAttributeValue)
                        {
                            var updatedUserStatusId = 0;
                            var statusCommonName = payload.Rows[0][AttributeCommonNames.Status].ToString();
                            updatedUserStatusId = _userFacade.GetStatusValueIds(new[] { statusCommonName }).FirstOrDefault();


                            var deleteStatusId = _userFacade.GetStatusValueIds(new[] { AttributeCommonNames.StatusAttributeValue }).FirstOrDefault();
                            isUnAuthorizedAccess = updatedUserStatusId == deleteStatusId;
                        }
                    }
                    var auditSpec = new AuditSpec
                    {
                        Action = userId > 0 ? ServiceAction.UserUpdated : ServiceAction.UserCreated,
                        ObjectName = resultDataTable.Value.Rows[0][AtHoc.IWS.Business.Configurations.Constants.UserNameColumnCommonName].ToString(),
                        ObjectType = EntityType.EndUsers,
                        OperatorId = RuntimeContext.Operator.Id,
                        ProviderId = provider.Id
                    };
                    _operatorAuditFacade.LogAction(auditSpec);

                    //  return Json(new { Success = result, Messages = messages, UserId = Convert.ToInt32(resultDataTable.Value.Rows[0]["USER_ID"]), IsUnAuthorizedAccess = false });

                    return Json(new { Success = result, Messages = messages, UserId = userId > 0 ? userId : Convert.ToInt32(resultDataTable.Value.Rows[0]["USER_ID"]), IsUnAuthorizedAccess = isUnAuthorizedAccess });
                }
                else
                {
                    result = false;
                    List<string> errorMessages = new List<string>();
                    errorMessages.AddRange(resultDataTable.Errors);
                    if (resultDataTable.Errors.Count == 0)
                    {
                        errorMessages = resultDataTable.Value.Rows[0][":SyncDetails"].ToString().TrimEnd(',').Split(',').ToList();
                    }
                    foreach (string error in errorMessages)
                    {
                        messages.Add(new Message { Type = MessageType.Error, Value = error, Sender = "EndUser Save" });
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);

                messages.Add(new Message { Type = MessageType.Error, Value = IWSResources.UserManager_UserSave_Error, Sender = "EndUser Save" });
                return Json(new { Success = false, Messages = messages, UserId = -1, IsUnAuthorizedAccess = false });
            }

            return Json(new { Success = result, Messages = messages, UserId = -1, IsUnAuthorizedAccess = false });
        }


        private void ModelConversionForAPI(DataTable payload)
        {
            foreach (var dataColumn in payload.Columns.Cast<DataColumn>().Where(x => !x.ColumnName.ToUpper().Contains(AtHoc.IWS.Business.Configurations.Constants.DevicePrefix + AtHoc.IWS.Business.Configurations.Constants.CVS_COLUMN_SEPARATOR)))
            {
                if (ProviderAttributes.GetByCommonName(dataColumn.ColumnName) != null)
                {
                    if (ProviderAttributes.GetByCommonName(dataColumn.ColumnName).AttributeTypeId == CustomAttributeDataType.GeoLocation)
                    {
                        string[] delimiter = new string[] { "::" };
                        string geoValue = payload.Rows[0].Field<string>(dataColumn.ColumnName);

                        if (geoValue != string.Empty)
                        {
                            string geoAddressValue = geoValue.Split(delimiter, StringSplitOptions.None)[1];
                            payload.Rows[0][dataColumn.ColumnName] = geoValue.Split(delimiter, StringSplitOptions.None)[0];
                            dataColumn.ExtendedProperties[AtHoc.IWS.Business.Configurations.Constants.XPropGeoStringValue] = geoAddressValue;
                        }
                    }
                    else if (ProviderAttributes.GetByCommonName(dataColumn.ColumnName).AttributeTypeId == CustomAttributeDataType.DateTime ||
                        ProviderAttributes.GetByCommonName(dataColumn.ColumnName).AttributeTypeId == CustomAttributeDataType.Date)
                    {
                        var fieldValue = payload.Rows[0].Field<string>(dataColumn.ColumnName).Replace("\"", "");

                        if (fieldValue != string.Empty)
                        {
                            DateTime inputValue = new DateTime();
                            DateTime.TryParse(fieldValue, null, DateTimeStyles.RoundtripKind, out inputValue);
                            payload.Rows[0][dataColumn.ColumnName] = inputValue.ToString(ProviderAttributes.GetByCommonName(dataColumn.ColumnName).AttributeTypeId == CustomAttributeDataType.DateTime ?
                                RuntimeContext.Provider.GetDateTimeFormat() : RuntimeContext.Provider.GetDateFormat());
                        }
                        else
                        {
                            payload.Rows[0][dataColumn.ColumnName] = fieldValue;
                        }
                    }
                }
            }

        }

        #endregion

        #region "Operator Permissions"
        public ActionResult OperatorIndex()
        {
            return View();
        }

        [HttpPost]
        public JsonResult UpdatePassword(int operatorId, string currentPassword, string newPassword, bool isMyDetail = false)
        {
            var provider = RuntimeContext.Provider;
            var result = _operatorFacade.UpdateUserPassword(new UserPasswordUpdateSpec
            {
                OldPassword = currentPassword,
                NewPassword = newPassword,
                UserId = operatorId
            });
            if (result.IsValid && isMyDetail)
            {
                RuntimeContext.RefreshOperatorContext();
            }
            return Json(new { Success = result.IsValid, result.Messages, LastUpdated = provider.GetVpsDateTimeFromSecondsFormated(Convert.ToInt32(result.Messages.Sender)) });
        }

        [HttpGet]
        public JsonResult GetOperatorDetails(bool loadEmptyAttributes = false)
        {
            var provider = RuntimeContext.Provider;
            var associatedUserProvider = provider;
            var currentUser = RuntimeContext.Operator;

            //User Attribute Localization code
            GlobalEntityLocaleFacade globalEntityLocaleFacade = new GlobalEntityLocaleFacade(new GlobalEntityLocaleRepository());

            if (currentUser != null)
            {
                //see if this opr has user detail on this vps
                var endUserDetailsForVPS = _userFacade.GetUserBySpec(new UserSpec
                {
                    OperatorId = currentUser.Id,
                    CustomFieldFormat = true,
                    UserId = currentUser.Id,
                    GetUserAttributes = true
                });

                //User Attribute Localization code
                var userAttributeList = new List<UserAttribute>();
                foreach (var userAttribute in endUserDetailsForVPS.UserAttributes)
                {
                    var providerAttr = ProviderAttributes.FirstOrDefault(a => a.CommonName == userAttribute.CommonName);
                    if (providerAttr != null)
                    {
                        if (providerAttr.AttributeTypeId == CustomAttributeDataType.Checkbox)
                        {
                            if (!string.IsNullOrEmpty(userAttribute.DisplayValue))
                            {
                                userAttribute.DisplayValue =
                                    globalEntityLocaleFacade.GetLocalizedValue(userAttribute.DisplayValue,
                                        BusinessEntity.CheckBox, "Name", RuntimeContext.Provider.BaseLocale);

                                userAttributeList.Add(userAttribute);
                            }
                        }
                        else
                        {
                            userAttributeList.Add(userAttribute);
                        }
                    }
                }

                endUserDetailsForVPS.UserAttributes = userAttributeList;

                int userProviderId = (int)endUserDetailsForVPS.ProviderId;
                // Changed for IWS-21927
                // Since it is static variable, we are checking if it is null, then call the RefreshAllRoles.
                if (_allRoles == null)
                    _userManagerHelper.RefreshAllRoles(ref _allRoles);

                if (userProviderId == provider.Id)
                {
                    _userManagerHelper.RefreshDevices(ref _allDevices, ref _devicesByCommonName, ref _devicesByName, true);
                    _userManagerHelper.RefreshOperatorRoles(ref _operatorRoles, provider.Id);
                    if (Session["userChannelList"] == null)
                    {
                        _userManagerHelper.RefreshOperatorAccessibleChannels(ref _operatorAccessibleChannels, true);
                        Session["userChannelList"] = _operatorAccessibleChannels;
                    }
                    else
                        _operatorAccessibleChannels = Session["userChannelList"] as IEnumerable<AlertChannel>;

                    if (Session["vpsChannels"] == null)
                    {
                        _userManagerHelper.RefreshChannels(ref _vpsChannels, true);
                        Session["vpsChannels"] = _vpsChannels;
                    }
                    else
                        _vpsChannels = Session["vpsChannels"] as IEnumerable<AlertChannel>;

                    _userManagerHelper.RefreshOperatorAccessibleDistributionLists(ref _operatorAccessibleDistributionLists, true);
                }
                else
                {
                    associatedUserProvider = _virtualSystemFacade.GetProviderBySpec(new VirtualSystemSpec
                    {
                        Id = userProviderId,
                        IncludeExtendedParams = true
                    });

                    _userManagerHelper.RefreshDevices(ref _allDevices, ref _devicesByCommonName, ref _devicesByName, true, associatedUserProvider.Id);
                    _userManagerHelper.RefreshOperatorRoles(ref _operatorRoles, provider.Id);
                    if (Session["userwithProviderChannelList"] == null)
                    {
                        _userManagerHelper.RefreshOperatorAccessibleChannels(ref _operatorAccessibleChannels, true, provider.Id);
                        Session["userwithProviderChannelList"] = _operatorAccessibleChannels;
                    }
                    else
                        _operatorAccessibleChannels = Session["userwithProviderChannelList"] as IEnumerable<AlertChannel>;

                    if (Session["vpsChannelswithProvider"] == null)
                    {
                        _userManagerHelper.RefreshChannels(ref _vpsChannels, true, provider.Id);
                        Session["vpsChannelswithProvider"] = _vpsChannels;
                    }
                    else
                        _vpsChannels = Session["vpsChannelswithProvider"] as IEnumerable<AlertChannel>;

                    _userManagerHelper.RefreshOperatorAccessibleDistributionLists(ref _operatorAccessibleDistributionLists, true, provider.Id);
                }

                var layout = _pageLayoutFacade.GetPageLayoutBySpec(new PageLayoutSpec { ProviderId = RuntimeContext.ProviderId, PageId = "OPERATORDETAILS" }).FirstOrDefault();
                if (layout != null)
                {
                    var endUserDetails =
                        _userFacade.GetUserBySpec(new UserSpec
                        {
                            ProviderId = associatedUserProvider.Id,
                            OperatorId = currentUser.Id,
                            CustomFieldFormat = true,
                            UserId = currentUser.Id,
                            GetUserAttributes = true
                        });

                    //User Attribute Localization code
                    var usrAttributeList = new List<UserAttribute>();
                    foreach (var userAttribute in endUserDetails.UserAttributes)
                    {
                        var providerAttr = ProviderAttributes.FirstOrDefault(a => a.CommonName == userAttribute.CommonName);
                        if (providerAttr != null)
                        {
                            if (providerAttr.AttributeTypeId == CustomAttributeDataType.Checkbox)
                            {
                                if (!string.IsNullOrEmpty(userAttribute.DisplayValue))
                                {
                                    userAttribute.DisplayValue =
                                        globalEntityLocaleFacade.GetLocalizedValue(userAttribute.DisplayValue,
                                            BusinessEntity.CheckBox, "Name", RuntimeContext.Provider.BaseLocale);

                                    usrAttributeList.Add(userAttribute);
                                }
                            }
                            else
                            {
                                usrAttributeList.Add(userAttribute);
                            }
                        }
                    }

                    endUserDetails.UserAttributes = usrAttributeList;

                    string endUserFullName;
                    string orgH;
                    IEnumerable<PageLayoutRow> allRowsFromXml;
                    string userStatus;

                    TimeZoneInfo vpsTimeZone = provider.GetVpsTimeZoneFromId();
                    string dtFormat = provider.GetDateTimeFormat();
                    _handleUserDetails(currentUser.Id, loadEmptyAttributes, associatedUserProvider, currentUser, layout, endUserDetails, false, out endUserFullName, out orgH, out allRowsFromXml, out userStatus);

                    var systemUser = _operatorFacade.GetUser(new SystemUserSpec { ProviderId = provider.Id, OperatorId = currentUser.Id });
                    var operatorUserBase = _operatorDetailsFacade.GetOperatorUserBase(new OperatorUserBaseSpec { OperatorId = currentUser.Id, ProviderId = provider.Id }).ToList();
                    var operatorAccessSpec = new OperatorAccessSpec { OperatorId = currentUser.Id, ProviderId = provider.Id };
                    var operatorAccess = _operatorDetailsFacade.GetOperatorAccess(operatorAccessSpec);

                    var auditEvents = _operatorAuditFacade.GetFailedLoginAttempts(
                    new AuditSpec(currentUser.Id, RuntimeContext.Provider.Id) { ActionDateTime = currentUser.LastLoginTime }
                ).ToList();

                    var operatorpermissions = new OperatorPermissionsViewModel(currentUser.Id, systemUser,
                        _operatorRoles,
                        _allRoles,
                        _operatorAccessibleChannels,
                        _operatorAccessibleDistributionLists,
                        operatorAccess, auditEvents,
                        operatorUserBase, userStatus, systemUser.OperatorUser.MappingId, endUserDetails.UserName, _vpsChannels);

                    operatorpermissions.Permissions.RolesDescription = _userManagerHelper.GetOperatorRolesFormattedText(currentUser.Id);

                    //get operator password
                    GenerateOperatorPasswordView(provider, currentUser, operatorpermissions);

                    return
                    Json(new
                    {
                        Success = true,
                        UserId = currentUser.Id,
                        UserStatus = userStatus,
                        EndUserFullName = endUserFullName,
                        OrgHirarchy = orgH,
                        UserDetails = allRowsFromXml,
                        Permissions = operatorpermissions.Permissions,
                        OperatorUserBaseDisplayView = _userBaseConverterService.GetSearchCriteriaModel(operatorUserBase),
                        DateFormat = provider.GetDateFormat(),
                        DateTimeFormat = dtFormat,
                        VPSTimeZone = vpsTimeZone,
                        UtcOffsetInMinutes = vpsTimeZone.BaseUtcOffset.TotalMinutes
                    }, JsonRequestBehavior.AllowGet);
                }
            }
            return Json(new { Success = false, UserDetails = new { }, Permissions = new { }, OperatorUserBaseDisplayView = new { } }, JsonRequestBehavior.AllowGet);
        }


        [IWSAuthorize(new[] { SystemObject.EndUsers }, new[] { ActionType.View })]
        [HttpGet]
        public JsonResult GetEndUserOperatorPermissions(int userId, bool isNewOperator = false)
        {
            var provider = RuntimeContext.Provider;

            if (userId > 0 && (!_userFacade.CheckUsersInOperatorBase(new List<int> { userId }, RuntimeContext.ProviderId, RuntimeContext.OperatorId)))
            {
                TempData["IsCrossTenantAccess"] = true;
                return Json(new
                {
                    ModifyOperatorAllowed = false,
                    OperatorUserBaseDisplayView = new { },
                    IsUnAuthorizedAccess = true
                }, JsonRequestBehavior.AllowGet);

            }

            _userManagerHelper.RefreshOperatorRoles(ref _operatorRoles, provider.Id);

            // Changed for IWS-21927
            // Since it is static variable, we are checking if it is null, then call the RefreshAllRoles.
            if (_allRoles == null)
                _userManagerHelper.RefreshAllRoles(ref _allRoles);


            //Added this code for IWS-24491
            //if the user account is locked and if the organization reset lock timeout has passed or is 0, then unlock the user account
            var opr = AtHoc.Operators.OperatorManager.GetOperator(userId);
            if (opr != null)
            {
                var organizationSecurityPolicy = new VirtualSystemService().GetOrganizationSecurityPolicy(provider.Id);

                if (opr.CurrentFailedAttempts >= organizationSecurityPolicy.LoginLockoutAttempts)
                {
                    if (organizationSecurityPolicy.LoginLockoutMinutes <= 0 ||
                        opr.LastFailedAttemptTime.ToDateTime()
                            .AddMinutes(organizationSecurityPolicy.LoginLockoutMinutes) <
                        AtHocSystem.Local.CurrentDateTime)
                    {
                        OperationAuditor.LogAction(opr.LoginId, AuditedAction.LoginFailedAccountLocked, AuditedEntity.LoginAttempt, opr.LoginId, 0, "", "");
                        AtHoc.Operators.OperatorManager.UpdateUserAccessStatus(opr.Id, AtHoc.Operators.OperatorManager.AccessUnlocked, 0, 0, 0);
                        //Updated below details in case we resued the opr variable again in future.
                        opr.ValidationResult = OperatorValidationResult.AccessValid;
                        opr.Status = OperatorStatus.Active;
                        opr.CurrentFailedAttempts = 0;
                        opr.LastFailedAttempts = 0;
                    }
                }
            }

            if (Session["userChannelList"] == null)
            {
                _userManagerHelper.RefreshOperatorAccessibleChannels(ref _operatorAccessibleChannels, true);
                Session["userChannelList"] = _operatorAccessibleChannels;
            }
            else
                _operatorAccessibleChannels = Session["userChannelList"] as IEnumerable<AlertChannel>;

            if (Session["vpsChannels"] == null)
            {
                _userManagerHelper.RefreshChannels(ref _vpsChannels, true);
                Session["vpsChannels"] = _vpsChannels;
            }
            else
                _vpsChannels = Session["vpsChannels"] as IEnumerable<AlertChannel>;

            _userManagerHelper.RefreshOperatorAccessibleDistributionLists(ref _operatorAccessibleDistributionLists, true);

            var endUserDetails =
                _userFacade.GetUserBySpec(new UserSpec
                {
                    ProviderId = provider.Id,
                    UserId = userId,
                    GetUserAttributes = true
                });

            var userStausAttribute = endUserDetails.UserAttributes.FirstOrDefault(u => u.CommonName == AttributeCommonNames.Status);
            //var userStatus = userStausAttribute != null ? userStausAttribute.DisplayValue : "";
            //As DisplayValues will be in localized language we can't use the string comparision any more using displayvalues but we can compare the status values with common name as they never change
            //In this case the possible values will be VLD, DSB and DEL
            //IWS-23442 -> On Edit user page, For Enable user also option Enable is shown from More actions
            var userStatus = (userStausAttribute != null) ? RuntimeContext.CustomAttributeValues.GetById(int.Parse(userStausAttribute.Value)).CommonName : string.Empty;

            OperatorUser opUser;
            opUser = _operatorDetailsFacade.GetOperatorUserBySpec(new OperatorUserSpec
            {
                //ProviderId = provider.Id,
                UserId = userId,
                IncludeUserBase = false,
                ExcludeDeleted = true
            });

            if (opUser != null)
            {
                var systemUser =
                    _operatorFacade.GetUser(new SystemUserSpec { ProviderId = provider.Id, OperatorId = opUser.Id });
                var operatorUserBase =
                    _operatorDetailsFacade.GetOperatorUserBase(new OperatorUserBaseSpec
                    {
                        OperatorId = opUser.Id,
                        ProviderId = provider.Id
                    }).ToList();
                var operatorAccessSpec = new OperatorAccessSpec { OperatorId = opUser.Id, ProviderId = provider.Id };
                var operatorAccess = _operatorDetailsFacade.GetOperatorAccess(operatorAccessSpec);


                var auditEvents = _operatorAuditFacade.GetFailedLoginAttempts(
                    new AuditSpec(opUser.Id, RuntimeContext.Provider.Id) { ActionDateTime = opUser.LastLoginTime }
                    ).ToList();

                var operatorpermissions = new OperatorPermissionsViewModel(userId,
                    systemUser,
                    _operatorRoles,
                    _allRoles,
                    _operatorAccessibleChannels,
                    _operatorAccessibleDistributionLists,
                    operatorAccess,
                    auditEvents,
                    operatorUserBase,
                    userStatus,
                    systemUser.OperatorUser.MappingId,
                    endUserDetails.UserName,
                    _vpsChannels,
                    isNewOperator);

                operatorpermissions.Permissions.RolesDescription =
                    _userManagerHelper.GetOperatorRolesFormattedText(opUser.Id);

                //get operator password
                GenerateOperatorPasswordView(provider, opUser, operatorpermissions);

                return
                    Json(new
                    {
                        ModifyOperatorAllowed =
                            RuntimeContext.Operator.HasPermission(SystemObject.GrantOperators, ActionType.Modify),
                        operatorpermissions.Permissions,
                        OperatorUserBaseDisplayView = _userBaseConverterService.GetSearchCriteriaModel(operatorUserBase),
                        IsUnAuthorizedAccess = false
                    }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var mappingIdUserAttribute =
                    endUserDetails.UserAttributes.FirstOrDefault(x => x.CommonName == AttributeCommonNames.MappingId);

                var operatorpermissions = new OperatorPermissionsViewModel(userId,
                    _operatorRoles,
                    _allRoles,
                    _operatorAccessibleChannels,
                    _operatorAccessibleDistributionLists,
                    userStatus,
                    (mappingIdUserAttribute != null) ? mappingIdUserAttribute.Value : string.Empty,
                    endUserDetails.UserName,
                    _vpsChannels);

                GenerateOperatorPasswordView(provider, endUserDetails, operatorpermissions);

                return
                    Json(new
                    {
                        ModifyOperatorAllowed =
                            RuntimeContext.Operator.HasPermission(SystemObject.GrantOperators, ActionType.Modify),
                        operatorpermissions.Permissions,
                        OperatorUserBaseDisplayView = new { },
                        IsUnAuthorizedAccess = false
                    }, JsonRequestBehavior.AllowGet);
            }

        }

        [NonAction]
        private static void GenerateOperatorPasswordView(Provider provider, OperatorUser opUser, OperatorPermissionsViewModel operatorpermissions)
        {
            if (opUser != null)
            {
                if (opUser.Password.IsNotNullOrEmpty())
                {
                    operatorpermissions.Permissions.OperatorPassword.Password = "*********";
                }
                if (opUser.ExpirationDate.HasValue)
                {
                    operatorpermissions.Permissions.OperatorPassword.ExpirationDate = provider.GetVpsDateTimeFromSeconds(opUser.ExpirationDate.Value);
                }
                if (opUser.PasswordUpdatedOn.HasValue)
                {
                    operatorpermissions.Permissions.OperatorPassword.PasswordUpdatedOn = provider.GetSystemDateTimeFromSeconds(opUser.PasswordUpdatedOn.Value).ToString(CultureInfo.InvariantCulture);
                }
                operatorpermissions.Permissions.OperatorPassword.NextLoginChangePw = opUser.NextLoginChangePw;
                operatorpermissions.Permissions.OperatorPassword.PasswordNeverExpires = opUser.PasswordNeverExpires;
            }
        }

        private static void GenerateOperatorPasswordView(Provider provider, User user,
            OperatorPermissionsViewModel operatorpermissions)
        {
            var userPassword = user.UserAttributes.SingleOrDefault(x => x.CommonName == AttributeCommonNames.Password);
            var passwordUpdatedOn = user.UserAttributes.SingleOrDefault(x => x.CommonName == AttributeCommonNames.PasswordUpdatedOn);

            if (userPassword != null && userPassword.HasValue())
                operatorpermissions.Permissions.OperatorPassword.Password = "*********";
            if (passwordUpdatedOn != null && passwordUpdatedOn.HasValue())
            {
                var passwordTime = 0;
                if (int.TryParse(passwordUpdatedOn.Value, out passwordTime))
                {
                    operatorpermissions.Permissions.OperatorPassword.PasswordUpdatedOn =
                        provider.GetSystemDateTimeFromSeconds(passwordTime)
                            .ToString(CultureInfo.InvariantCulture);
                }
            }
        }

        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.Operators, SystemObject.GrantOperators },
            new[] { ActionType.Modify, ActionType.Modify })]
        public JsonResult SaveEndUserOperatorPermissions(
            EndUserOperatorPermissionsForSave updatedUserOperatorPermissions)
        {
            var messages = new Messages();
            string existingUserMappingId = string.Empty;

            var provider = RuntimeContext.Provider;

            _userManagerHelper.RefreshOperatorRoles(ref _operatorRoles, provider.Id);
            if (Session["userChannelList"] == null)
            {
                _userManagerHelper.RefreshOperatorAccessibleChannels(ref _operatorAccessibleChannels, true);
                Session["userChannelList"] = _operatorAccessibleChannels;
            }
            else
                _operatorAccessibleChannels = Session["userChannelList"] as IEnumerable<AlertChannel>;

            _userManagerHelper.RefreshOperatorAccessibleDistributionLists(ref _operatorAccessibleDistributionLists, true);

            try
            {

                OperatorUser opUser = null;
                var endUserDetails = _userFacade.GetUserBySpec(new UserSpec
                {
                    ProviderId = provider.Id,
                    UserId = updatedUserOperatorPermissions.UserId,
                    GetUserAttributes = true
                });

                var returnCodes = _userFacade.ValidateUsernameAndMappingId(endUserDetails.UserName, updatedUserOperatorPermissions.MappingId, RuntimeContext.ProviderId, updatedUserOperatorPermissions.UserId, true).ToList();
                messages = _userManagerHelper.TranslateUsernameReturnCodesToMessages(returnCodes, messages);
                if (messages.Any()) return Json(new { Success = false, Messages = messages, });

                SystemUser systemUser = null;

                var existingOperator = _operatorFacade.GetUser(new SystemUserSpec
                {
                    ProviderId = provider.Id,
                    OperatorId = updatedUserOperatorPermissions.UserId,
                    //OperatorId = updatedUserOperatorPermissions.OperatorId
                });

                //if (updatedUserOperatorPermissions.OperatorId > 0)
                if (existingOperator.OperatorUser != null)
                {

                    systemUser = existingOperator;

                    //TODO have to remove once the tables are merged
                    if (systemUser.User == null)
                    {
                        systemUser.User = endUserDetails;
                    }

                    systemUser.OperatorUser.Id = endUserDetails.Id;
                    systemUser.OperatorUser.FirstName = endUserDetails.FirstName;
                    systemUser.OperatorUser.LastName = endUserDetails.LastName;

                    try
                    {
                        UpdateOperatorPassword(updatedUserOperatorPermissions, systemUser.OperatorUser);
                    }
                    catch (InvalidDataException de)
                    {
                        messages.Add(new Message
                        {
                            Type = MessageType.Error,
                            Sender = "End User Operator Permissions Save",
                            Value = de.Message
                        });
                        return Json(new { Success = false, Messages = messages, IsUnAuthorizedAccess = false });
                    }
                }
                else
                {
                    opUser = new OperatorUser
                    {
                        Id = endUserDetails.Id,
                        Username = endUserDetails.UserName,
                        FirstName = endUserDetails.FirstName,
                        LastName = endUserDetails.LastName,
                    };
                    try
                    {
                        var existingPasswordForUser =
                            endUserDetails.UserAttributes.SingleOrDefault(
                                x => x.CommonName == AttributeCommonNames.Password);
                        if ((existingPasswordForUser != null && existingPasswordForUser.Value.IsNotNullOrEmpty()) &&
                            (updatedUserOperatorPermissions.OperatorPassword != null &&
                             updatedUserOperatorPermissions.OperatorPassword.NewPassword.IsNullOrEmpty()))
                            opUser.Password = existingPasswordForUser.Value;

                        UpdateOperatorPassword(updatedUserOperatorPermissions, opUser);
                    }
                    catch (InvalidDataException de)
                    {
                        messages.Add(new Message
                        {
                            Type = MessageType.Error,
                            Sender = "Save Permission",
                            Value = de.Message
                        });
                        return Json(new { Success = false, Messages = messages, IsUnAuthorizedAccess = false });
                    }
                }

                if (systemUser == null)
                {
                    systemUser = new SystemUser { User = endUserDetails, OperatorUser = opUser };
                }

                var selectedOperatorRoles = new List<OperatorUserRole>();

                foreach (var selectedRole in updatedUserOperatorPermissions.EndUserOperatorRoles)
                {
                    var r =
                        _operatorRoles.FirstOrDefault(
                            role =>
                                String.Equals(role.RoleName, selectedRole.RoleName,
                                    StringComparison.CurrentCultureIgnoreCase));
                    selectedOperatorRoles.Add(new OperatorUserRole { RoleId = r.Id });
                }

                var selectedOperatorChannels = new List<OperatorChannel>();
                if (updatedUserOperatorPermissions.EndUserOperatorChannels != null &&
                    updatedUserOperatorPermissions.EndUserOperatorChannels.Any())
                {
                    foreach (var channel in updatedUserOperatorPermissions.EndUserOperatorChannels)
                    {
                        var uc = new OperatorChannel { ChannelId = channel.Id };
                        selectedOperatorChannels.Add(uc);
                    }
                }

                systemUser.Roles = selectedOperatorRoles;
                systemUser.Channels = selectedOperatorChannels;
                systemUser.EntityAccessList = updatedUserOperatorPermissions.EntityAccessList;

                systemUser.UnrestrictUserBase();
                if (updatedUserOperatorPermissions.OperatorUserBase != null &&
                    updatedUserOperatorPermissions.OperatorUserBase.HasValue())
                {
                    systemUser.UserBase =
                        _userBaseConverterService.GetOperatorUserBase(updatedUserOperatorPermissions.OperatorUserBase);
                }

                var _userSaveSpec = new UserSaveSpec
                {
                    OperatorId = RuntimeContext.Operator.Id,
                    SystemUser = systemUser,
                    UserName = endUserDetails.UserName,
                    AssignPermissionsToProvider = RuntimeContext.ProviderId
                };

                var result = _operatorFacade.SaveUser(_userSaveSpec);
                messages.Add(result.Messages);

                //IWS-4271
                //On changing the password, set the OperatorUser status from locked(LCK) to active(ACT) which will enable the operator and login.

                if (updatedUserOperatorPermissions.OperatorPassword != null
                    && updatedUserOperatorPermissions.OperatorPassword.NewPassword.IsNotNullOrEmpty()
                    && messages.NoErrors())
                {
                    if (systemUser.OperatorUser != null && !string.IsNullOrEmpty(systemUser.OperatorUser.AccessLocked) &&
                        systemUser.OperatorUser.AccessLocked.ToUpper() == "YES")
                        UnlockOperatorPermissions(systemUser.UserId);
                }


                if (updatedUserOperatorPermissions.UserId == RuntimeContext.OperatorId)
                {
                    // IWS-21927, When Operator Permission is changed, it need to be picked from database.
                    var hasAccessToUserManager = _authFacade.HasAccess(RuntimeContext.OperatorId, RuntimeContext.ProviderId, SystemObject.EndUsers, ActionType.View);
                    if (!hasAccessToUserManager)
                    {
                        var redirectionMessage = new Message
                        {
                            Type = MessageType.Warning,
                            Value = "Access denied",
                            Sender = "Controller"
                        };
                        messages.Add(redirectionMessage);
                        return Json(new { Success = messages.NoErrors(), Messages = messages, });
                    }
                }

                return Json(new { Success = messages.NoErrors(), Messages = messages, });
            }
            catch (Exception exec)
            {
                messages.Add(new Message { Value = "Unknown Error", Type = MessageType.Error });
                LogService.Current.Error(() => exec);
                return Json(new { Success = false, Messages = messages });
            }
        }

        private static void UpdateOperatorPassword(EndUserOperatorPermissionsForSave updatedUserOperatorPermissions, OperatorUser operatorUser)
        {
            if (updatedUserOperatorPermissions.OperatorPassword != null)
            {
                if (operatorUser.Password.IsNullOrEmpty() &&
                    updatedUserOperatorPermissions.OperatorPassword.NewPassword.IsNullOrEmpty())
                    throw new InvalidDataException(IWSResources.OperatorPermissions_RequiredPassword);

                operatorUser.Password = updatedUserOperatorPermissions.OperatorPassword.NewPassword;

                if (updatedUserOperatorPermissions.OperatorPassword.NextLoginChangePw == "True" ||
                    updatedUserOperatorPermissions.OperatorPassword.NextLoginChangePw == "Yes")
                    operatorUser.NextLoginChangePw = "Yes";
                else
                    operatorUser.NextLoginChangePw = "No";


                if (updatedUserOperatorPermissions.OperatorPassword.PasswordNeverExpires == "True" ||
                    updatedUserOperatorPermissions.OperatorPassword.PasswordNeverExpires == "Yes")
                    operatorUser.PasswordNeverExpires = "Yes";
                else
                    operatorUser.PasswordNeverExpires = "No";

                if (updatedUserOperatorPermissions.OperatorPassword.ExpirationDate.HasValue &&
                        updatedUserOperatorPermissions.OperatorPassword.ExpirationDate != DateTime.MinValue)
                {
                    operatorUser.ExpirationDate = DateTimeConverter.GetSecondsFromDateTime(
                        updatedUserOperatorPermissions.OperatorPassword.ExpirationDate.Value);
                }
                else
                    operatorUser.ExpirationDate = null;
            }
        }

        [HttpGet]
        public JsonResult UnlockOperatorPermissions(int userId)
        {
            var messages = new Messages();

            OperatorUser operatorUser = _operatorDetailsFacade.GetOperatorUserBySpec(new OperatorUserSpec
            {
                UserId = userId,
            });

            try
            {
                messages = _operatorFacade.UnLockOperator(
                    new OperatorUserSpec
                    {
                        ProviderId = operatorUser.DefaultLoginProvider,
                        UserId = userId,
                        ExcludeDeleted = true
                    }
                );

                return Json(new { Success = messages.NoErrors(), Messages = messages });
            }
            catch (Exception exec)
            {
                messages.Add(new Message { Value = "Unknown Error", Type = MessageType.Error });
                LogService.Current.Error(() => exec);
                return Json(new { Success = false, Messages = messages });
            }
        }

        [HttpGet]
        public JsonResult RevokeEndUserOperatorPermissions(int operatorId)
        {
            var result = _operatorFacade.RevokePermissions(new SystemUserSpec(RuntimeContext.ProviderId, operatorId));
            return Json(new { CurrentOperatorRevoked = operatorId == RuntimeContext.OperatorId, Success = result.IsValid, result.Messages });
        }

        #endregion

        [IWSAuthorize(new[] { SystemObject.EndUsers }, new[] { ActionType.View })]
        public ActionResult Index()
        {
            var provider = RuntimeContext.Provider;
            var operatorObj = RuntimeContext.Operator;

            //required for top bar highlight 
            ViewBag.TopicToHighlight = MenuTopicsId.users;
            ViewBag.SendAlertAllowed = operatorObj.HasPermission(SystemObject.Alert, ActionType.Publish);
            ViewBag.ViewReportsAllowed = operatorObj.HasPermission(SystemObject.Report, ActionType.Publish);

            ViewBag.ViewEndUserAllowed = operatorObj.HasPermission(SystemObject.EndUsers, ActionType.View);
            ViewBag.ModifyEndUserAllowed = operatorObj.HasPermission(SystemObject.EndUsers, ActionType.Modify);

            ViewBag.ModifyOperatorAllowed = operatorObj.HasPermission(SystemObject.GrantOperators, ActionType.Modify);
            ViewBag.ChannelManagementAllowed = operatorObj.HasPermission(SystemObject.AlertChannelManager, ActionType.Publish);
            ViewBag.IsOrgHierarchySupported = provider.FeatureMatrix.IsOrgHierarchySupported;
            //For phone default iso country code.
            ViewBag.ProviderIsoCountryCode = provider.ExtendedParams.IsoCountryCode;

            var maxEnabledUsersCap = _virtualSystemFacade.GetMaxEnabledUsersCap(provider.Id);
            if (maxEnabledUsersCap > 0)
            {
                ViewBag.MaxEnabledCapSet = true;
            }

            if (_providerFacade.IsEnterpriseWithSubs(provider.Id) && RuntimeContext.Provider.FeatureMatrix.IsUserUniqueAcrossEnterprise && RuntimeContext.Provider.FeatureMatrix.IsEnterpriseManagementSupported)
            {
                ViewBag.UserMoveEnable = true;
            }
            var vpsTimeZOne = provider.GetVpsTimeZoneFromId();
            var vpsView = new VPSModel
            {
                DateFormat = provider.GetDateFormat(),
                DateTimeFormat = provider.GetDateTimeFormat(),
                VPSTimeZone = vpsTimeZOne,
                UtcOffsetInMinutes = vpsTimeZOne.BaseUtcOffset.TotalMinutes,
                VPSOffsetFromSystemInMinutes = provider.VPSOffsetFromSystemInMinutes(),
                SupportsDaylightSavingTime = vpsTimeZOne.SupportsDaylightSavingTime
            };
            return View(vpsView);
        }

        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.EndUsers, SystemObject.DistributionLists, SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View, ActionType.View, ActionType.View })]
        public ActionResult GetCustomViews()
        {
            var provider = RuntimeContext.Provider;
            var customViews =
                _customAttributeFacade.GetUserCustomViewsBySpec(new CustomViewSpec
                {
                    ProviderId = provider.Id,
                    OperatorId = RuntimeContext.Operator.Id,
                    CustomViewType = CustomViewType.UserManagerV2,
                    IsPlaceholder = false,
                    CustomViewColumnTypes = new[] { CustomViewColumnType.CustomField, CustomViewColumnType.Device, CustomViewColumnType.OrgName, CustomViewColumnType.Role }
                });

            _userManagerHelper.RefreshDevices(ref _allDevices, ref _devicesByCommonName, ref _devicesByName, true);

            var allDevicesList = _allDevices as IList<Device> ?? _allDevices.ToList();
            allDevicesList = allDevicesList.Where(d => !d.IsMassDevice).ToList();

            IEnumerable<Hierarchy> allHierarchies = _userFacade.GetHierarchyBySpec(new HierarchySpec
            {
                ProviderId = provider.Id,
                AvailableForLists = false,
                HierarchyType = HierarchyType.ORG,
                Status = UserStatusType.Active,
                IncludeCustomAttribute = true,
                BaseLocale = provider.BaseLocale
            });

            var customViewList = customViews as IList<CustomView> ?? customViews.ToList();


            IEnumerable<CustomView> customFieldCustomViews = null;
            IEnumerable<CustomView> deviceCustomViews = null;

            _userManagerHelper.GetValidCustomViews(customViewList, allDevicesList, ref customFieldCustomViews, ref deviceCustomViews);

            var listOfCustomViewColumns = new List<CustomViewColumn>();
            var attributes =
                ProviderAttributes.Where(
                x => x.CommonName.Equals(AttributeCommonNames.DisplayName) == false &&
                     x.CommonName.Equals(AttributeCommonNames.UserName) == false &&
                     x.Status != "DEL" && x.IsSearchable == "Y" && x.EntityId == "USER" &&
                     x.AttributeTypeId != CustomAttributeDataType.GeoLocation &&
                     x.AttributeTypeId != CustomAttributeDataType.Path && (x.CommonName != (!RuntimeContext.Provider.FeatureMatrix.IsEnterpriseManagementSupported ? AttributeCommonNames.Organizations : null))
                     && (x.CommonName != (!RuntimeContext.Provider.FeatureMatrix.IsEnterpriseManagementSupported ? AttributeCommonNames.PreventUserMove : null))
                ).GroupBy(d => d.Id, (key, group) => group.First())
               .Where(x => customFieldCustomViews.Any(y => y.EntityId.Equals(x.Id)) == false)
                .Select
                (
                    x => new CustomViewColumn
                    {
                        Id = x.Id,
                        DisplayName = x.AttributeName,
                        CustomViewColumnType = "CF",
                        ViewId = 0,
                        IsHierarchy = false,
                        Key = x.CommonName
                    }).OrderBy(d => d.DisplayName);

            var devices = allDevicesList
                .Where(d => deviceCustomViews.Any(y => y.EntityId.Equals(d.Id)) == false)
                        .Select(
                                x => new CustomViewColumn
                                {
                                    Id = x.Id,
                                    DisplayName = "{0}".FormatWith(x.Name),
                                    CustomViewColumnType = "Device",
                                    ViewId = 0,
                                    IsHierarchy = false,
                                    Key = x.CommonName
                                }).OrderBy(d => d.DisplayName);



            if (attributes.HasValue())
                listOfCustomViewColumns.AddRange(attributes);
            if (devices.HasValue())
                listOfCustomViewColumns.AddRange(devices);

            if (RuntimeContext.Provider.FeatureMatrix.IsOrgHierarchySupported)
            {
                var hierarchies = allHierarchies.Where(d => customFieldCustomViews.Any(y => y.EntityId.Equals(d.CustomAttribute.Id)) == false)
                    .Select
                    (
                        x => new CustomViewColumn
                        {
                            Id = x.CustomAttribute.Id,
                            DisplayName = x.CustomAttribute.AttributeName,
                            CustomViewColumnType = "CF",
                            ViewId = 0,
                            IsHierarchy = true,
                            Key = x.CommonName
                        }
                    ).OrderBy(d => d.DisplayName);

                if (hierarchies.HasValue())
                    listOfCustomViewColumns.AddRange(hierarchies);
            }

            IEnumerable<CustomViewColumn> roleCustomViewColumn = new[] {new CustomViewColumn
            {

                Id = 0,
                DisplayName = IWSResources.DisplayName_OperatorRoles,
                CustomViewColumnType = "CF",
                ViewId = 0,
                IsHierarchy = false,
                IsSortable = true,
                Key = CommonNames.OperatorRoles
            }};

            if (customViewList.Any(y => y.Columnid.Equals(CustomViewColumnType.Role)) == false)
                listOfCustomViewColumns.AddRange(roleCustomViewColumn);

            return Json(listOfCustomViewColumns);
        }

        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.Alert, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View })]
        public ActionResult GetReportCustomViews(string viewType)
        {
            var provider = RuntimeContext.Provider;
            var customViews =
                _customAttributeFacade.GetUserCustomViewsBySpec(new CustomViewSpec
                {
                    ProviderId = provider.Id,
                    OperatorId = RuntimeContext.Operator.Id,
                    CustomViewType = (CustomViewType)Enum.Parse(typeof(CustomViewType), viewType),
                    IsPlaceholder = false,
                    CustomViewColumnTypes = new[] { CustomViewColumnType.CustomField, CustomViewColumnType.Device, CustomViewColumnType.OrgName, CustomViewColumnType.Role }

                });

            _userManagerHelper.RefreshDevices(ref _allDevices, ref _devicesByCommonName, ref _devicesByName, true);

            var allDevicesList = _allDevices as IList<Device> ?? _allDevices.ToList();
            allDevicesList = allDevicesList.Where(d => !d.IsMassDevice).ToList();

            IEnumerable<Hierarchy> allHierarchies = _userFacade.GetHierarchyBySpec(new HierarchySpec { ProviderId = provider.Id, AvailableForLists = false, HierarchyType = HierarchyType.ORG, Status = UserStatusType.Active, IncludeCustomAttribute = true, BaseLocale = provider.BaseLocale });

            var customViewList = customViews as IList<CustomView> ?? customViews.ToList();

            IEnumerable<CustomView> customFieldCustomViews = null;
            IEnumerable<CustomView> deviceCustomViews = null;

            _userManagerHelper.GetValidCustomViews(customViewList, allDevicesList, ref customFieldCustomViews, ref deviceCustomViews);

            var listOfCustomViewColumns = new List<CustomViewColumn>();
            var attributes =
                ProviderAttributes.Where(
                x => x.Status != "DEL" && x.IsSearchable == "Y" && x.EntityId == "USER" &&
                     x.AttributeTypeId != CustomAttributeDataType.GeoLocation &&
                     x.AttributeTypeId != CustomAttributeDataType.Path && (x.CommonName != (!RuntimeContext.Provider.FeatureMatrix.IsEnterpriseManagementSupported ? AttributeCommonNames.Organizations : null))
                     && (x.CommonName != (!RuntimeContext.Provider.FeatureMatrix.IsEnterpriseManagementSupported ? AttributeCommonNames.PreventUserMove : null))
                ).GroupBy(d => d.Id, (key, group) => group.First())
               .Where(x => customFieldCustomViews.Any(y => y.EntityId == x.Id) == false)
                .Select
                (
                    x => new CustomViewColumn
                    {
                        Id = x.Id,
                        Key = x.CommonName,
                        DisplayName = x.AttributeName,
                        CustomViewColumnType = "CF",
                        ViewId = 0,
                        IsHierarchy = false
                    }).OrderBy(d => d.DisplayName);

            var devices = allDevicesList.Where(
                            d => deviceCustomViews.Any(y => y.EntityId == d.Id) == false
                                 && !d.IsMassDevice)
                        .Select(
                                x => new CustomViewColumn
                                {
                                    Id = x.Id,
                                    Key = x.CommonName,
                                    DisplayName = "{0} (Device)".FormatWith(x.Name),
                                    CustomViewColumnType = "Device",
                                    ViewId = 0,
                                    IsHierarchy = false
                                }).OrderBy(d => d.DisplayName);

            var hierarchies = allHierarchies.Where(
                d => customFieldCustomViews.Any(y => y.EntityId == d.CustomAttribute.Id) == false
                ).Select
                (
                    x => new CustomViewColumn
                    {
                        Id = x.CustomAttribute.Id,
                        Key = x.CommonName,
                        DisplayName = x.Name,
                        CustomViewColumnType = "CF",
                        ViewId = 0,
                        IsHierarchy = true
                    }
                ).OrderBy(d => d.DisplayName);

            IEnumerable<CustomViewColumn> roleCustomViewColumn = new[] {new CustomViewColumn
            {

                Id = 0,
                DisplayName = IWSResources.DisplayName_OperatorRoles,
                CustomViewColumnType = "CF",
                ViewId = 0,
                IsHierarchy = false,
                IsSortable = true,
                Key = CommonNames.OperatorRoles
            }};



            if (attributes.HasValue())
                listOfCustomViewColumns.AddRange(attributes);
            if (devices.HasValue())
                listOfCustomViewColumns.AddRange(devices);
            if (hierarchies.HasValue())
                listOfCustomViewColumns.AddRange(hierarchies);

            listOfCustomViewColumns.AddRange(roleCustomViewColumn);


            return Json(listOfCustomViewColumns);


        }

        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.EndUsers, SystemObject.DistributionLists, SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View, ActionType.View, ActionType.View })]
        public ActionResult SaveCustomView(int viewId, int id, string action, string type, string commonName = "")
        {
            var placholderCommonName = string.Empty;

            var customViewColumnType = (type.ToLowerInvariant() != "device")
                ? CustomViewColumnType.CustomField
                : CustomViewColumnType.Device;

            switch (commonName)
            {
                case CommonNames.OperatorRoles:
                    placholderCommonName = CommonNames.OperatorRoles;
                    customViewColumnType = CustomViewColumnType.Role;
                    break;
            }

            _userManagerHelper.RefreshDevices(ref _allDevices, ref _devicesByCommonName, ref _devicesByName, true);
            var messages = _customAttributeFacade.SaveCustomView(
                new SaveCustomViewSpec
                {
                    Id = id,
                    SequenceNo = null,
                    ViewId = viewId,
                    Action = action,
                    ColumnType = customViewColumnType,
                    AllDevices = _allDevices,
                    ViewType = CustomViewType.UserManagerV2,
                    ProviderAttributes = ProviderAttributes,
                    ProviderId = RuntimeContext.Provider.Id,
                    OperatorId = RuntimeContext.Operator.Id,
                    //if the commonName is 'OPERATOR-ROLES'
                    //For now we are sending ColumnKeyName which is optional to differentiate 'OPERATOR-ROLES' at the facade as its neither a device nor CustomField
                    ColumnKeyName = placholderCommonName
                });
            return Json(new Result<bool>(messages.NoErrors(), messages));
        }

        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.EndUsers, SystemObject.DistributionLists, SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View, ActionType.View, ActionType.View })]
        public ActionResult ResetToDefaultView()
        {
            var messages = new Messages();

            _customAttributeFacade.RemoveCustomView(new CustomViewSpec
            {
                ProviderId = RuntimeContext.Provider.Id,
                OperatorId = RuntimeContext.Operator.Id,
                CustomViewType = CustomViewType.UserManagerV2,
                IsPlaceholder = false,
            });

            return Json(new Result<bool>(messages.NoErrors(), messages));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="page"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortBy"></param>
        /// <param name="sortOrder"></param>
        /// <param name="userIds">where UserID IN (userids)</param>
        /// <param name="listItemIds">Dynamic and/or Static Distribution List IDs</param>
        /// <param name="hierarchyIds">##</param>
        /// <param name="attributeValueIds">where Attribute Value ID in (ATTRIBUTEID!OPR!VALUEID) probably for PickList</param>
        /// <param name="attributeIds">Where ATTRIBUTE is not EMPTY</param>
        /// <param name="searchStrings"></param>
        /// <param name="isEnabled"></param>
        /// <param name="isOperator"></param>
        /// <param name="queryCriteria"></param>
        /// <param name="includeUserIds"></param>
        /// <param name="excludeUserIds"></param>
        /// <param name="distributionId"></param>
        /// <param name="isMember"></param>
        /// <param name="staticQueryCriteria"></param>
        /// <param name="hideMassDevices"></param>
        /// <param name="searchFlow"></param>
        /// <returns></returns>
        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.EndUsers, SystemObject.DistributionLists, SystemObject.Alert, SystemObject.AccountabilityTemplate, SystemObject.AccountabilityEvent }, new[] { ActionType.View, ActionType.View, ActionType.View, ActionType.View, ActionType.View })]
        public ActionResult GetUsers(int page = 1, int pageSize = 25, string sortBy = AttributeCommonNames.DisplayName, string sortOrder = "ASC", // DONE
            int[] userIds = null,
            int[] listItemIds = null,
            int[] hierarchyIds = null,
            int[] attributeValueIds = null, int[] attributeIds = null,
            string[] searchStrings = null,
            bool? isEnabled = true, bool? isOperator = false,
            string queryCriteria = null,
            int[] includeUserIds = null, int[] excludeUserIds = null,
            int distributionId = 0,
            bool? isMember = null,
            string staticQueryCriteria = null, // NOT USED AS ALREADY TAKEN CARE BY RUNTIME CONTEXT OPERATOR_ID
            bool hideMassDevices = true,
            string searchFlow = null,
            bool isRoleBasedUsers = false)
        {
            _userManagerHelper.RefreshDevices(ref _allDevices, ref _devicesByCommonName, ref _devicesByName, true);

            var provider = RuntimeContext.Provider;

            #region Get Attributes

            var customViews =
                  _customAttributeFacade.GetUserCustomViewsBySpec(new CustomViewSpec
                  {
                      ProviderId = provider.Id,
                      OperatorId = RuntimeContext.OperatorId,
                      CustomViewType = CustomViewType.UserManagerV2,
                      IsPlaceholder = false,

                      CustomViewColumnTypes = new[]
                    {
                        CustomViewColumnType.CustomField,
                        CustomViewColumnType.Device,
                        CustomViewColumnType.OrgName,
                        CustomViewColumnType.Role
                    }
                  });

            IEnumerable<CustomView> customFieldCustomViews = null;
            IEnumerable<CustomView> deviceCustomViews = null;

            var customViewList = customViews as IList<CustomView> ?? customViews.ToList();
            var deviceList = _allDevices as IList<Device> ?? _allDevices.ToList();
            _userManagerHelper.GetValidCustomViews(customViewList.ToList(), deviceList.Where(d => !d.IsMassDevice).ToList(), ref customFieldCustomViews, ref deviceCustomViews);

            var validCustomViews = customViewList.Where(
                x => (x.Columnid == CustomViewColumnType.Role || x.Columnid == CustomViewColumnType.OrgName))
                .Union(customFieldCustomViews)
                .Union(deviceCustomViews);

            var defaultAttributes = new List<CustomAttribute>(
                ProviderAttributes.GetByCommonNames(
                        new[]
                        {
                            AttributeCommonNames.UserName,
                            AttributeCommonNames.FirstName,
                            AttributeCommonNames.DisplayName,
                            AttributeCommonNames.LastName
                        }
                    )
                );

            var columns = new[]
            {
                new CustomViewColumn
                {
                    DisplayName = (ProviderAttributes.Any())? ProviderAttributes.GetByCommonName(CommonNames.DisplayName).AttributeName: IWSResources.IUTTBUserList_Name,
                    Key = AttributeCommonNames.DisplayName,
                    IsRequired = true,
                    IsSortable = true,
                    CustomViewColumnType = "CF",
                    DataType = CustomAttributeDataType.String,
                    DataFormat = string.Empty,
                    ViewId = 0
                }
             }.Union(validCustomViews.Select(customView => _userManagerHelper.CreateCustomViewColumnModel(provider, customView, _allDevices)));

            columns = columns.Where(x => x != null);

            var secondaryColumns = new[]
            {
                new CustomViewColumn
                {
                    DisplayName = (ProviderAttributes.Any())? ProviderAttributes.GetByCommonName(CommonNames.UserName).AttributeName: IWSResources.Register_Username,
                    Key = AttributeCommonNames.UserName,
                    IsSortable = true,
                    CustomViewColumnType = "CF",
                    DataType = CustomAttributeDataType.String,
                    DataFormat = string.Empty,
                    ViewId = 0
                }
            };
            #endregion

            // INITIALIZE SEARCH ARGUMENT

            var srchArgsV2 = new UserSearchArgs(false, true, !hideMassDevices)
            {
                ProviderId = RuntimeContext.ProviderId,
                ProviderCriteria = UserSearchHelper.GetProviderCriteria(provider.Id),
                OperatorCriteria = UserSearchHelper.GetOperatorUserBaseCriteria(RuntimeContext.OperatorId, RuntimeContext.ProviderId),
                AttributeNames = _userManagerHelper.InitializeAttributesToRetrieve(defaultAttributes, customViewList),
                DeviceNames = _userManagerHelper.InitializeDevicesToRetrieve(customViewList, deviceList.Where(d => !d.IsMassDevice).ToList()),
                Paging = { PageNo = page, UsersPerPage = pageSize, SortColumn = sortBy, IsAsc = !sortOrder.Equals("DESC", StringComparison.CurrentCultureIgnoreCase) }
            };

            // STATIC DISTRIBUTION LIST FLOW
            if (searchFlow == SearchFlow.FromDistributionListManagerStatic.ToString())
            {
                if (distributionId != 0)
                {
                    // new modified and existing list

                    var dl = _publishingFacade.GetDistributionList(new DistributionListSpec() { Id = distributionId });
                    var customCriteria = new List<GenericCriteria>
                     {
                         new AttributeCriteria(Int32.Parse(dl.Definition), CriteriaOperator.Equals,
                             (bool) isMember ? 1 : 0)
                     };

                    if (searchStrings != null)
                    {
                        srchArgsV2.TargetCriteria = UserSearchHelper.GetQuickSearchCriteria(provider.Id, RuntimeContext.Provider.BaseLocale, searchStrings);
                    }
                    // QUICK SEARCH TEXT (POST DL SCOPE SEARCH)
                    if (!string.IsNullOrEmpty(queryCriteria))
                    {
                        customCriteria.AddRange(InitializeAdvancedSearch(queryCriteria));
                    }

                    // ADVANCED SEARCH CRITERIA (AND to DL criteria)
                    srchArgsV2.TargetCriteria = srchArgsV2.TargetCriteria & UserSearchHelper.GetCustomCriteria(new[] { customCriteria });

                    // GROUPS Searchable Attributes TO INCLUDE
                    var includeGroupsCriteria = GetIncludeGroupsCriteria(attributeValueIds, attributeIds);
                    if (includeGroupsCriteria != null)
                    {
                        srchArgsV2.TargetCriteria = srchArgsV2.TargetCriteria & includeGroupsCriteria;
                    }
                }
                else if (distributionId == 0 && (bool)isMember)
                {
                    //new static and List Members
                    return Json(
                        new
                        {
                            Columns = columns,
                            SecondaryColumns = secondaryColumns,
                            Rows = new List<UserSearchResultItem>(),
                            TotalCounts = 0,
                            TotalEnabledUsers = 0,
                            UserBaseCount = 0,
                            MaxEnabledUserCount = _userManagerHelper.GetHomePageUserCounts(RuntimeContext.Provider.Id, RuntimeContext.OperatorId).MaxEnabledUsers
                        });
                }
                else if (distributionId == 0 && !(bool)isMember)
                {
                    //new static and Non-Members, need to get all users

                    if (searchStrings != null)
                    {
                        srchArgsV2.TargetCriteria = UserSearchHelper.GetQuickSearchCriteria(provider.Id, RuntimeContext.Provider.BaseLocale, searchStrings);
                    }

                    if (!string.IsNullOrEmpty(queryCriteria))
                    {
                        srchArgsV2.TargetCriteria = srchArgsV2.TargetCriteria & UserSearchHelper.GetCustomCriteria(new[] { InitializeAdvancedSearch(queryCriteria) });
                    }

                    // GROUPS
                    var includeGroupsCriteria = GetIncludeGroupsCriteria(attributeValueIds, attributeIds);
                    if (includeGroupsCriteria != null)
                    {
                        srchArgsV2.TargetCriteria = srchArgsV2.TargetCriteria & includeGroupsCriteria;
                    }
                }
                else
                { throw new ApplicationException("Unknown case enountered for User Search Static List Flow"); }
            }
            // DYNAMIC DISTRIBUTION LIST FLOW
            else if (searchFlow == SearchFlow.FromDistributionListManagerDynamic.ToString())
            {
                if (distributionId == 0 && !string.IsNullOrEmpty(staticQueryCriteria))
                {
                    if (searchStrings != null)
                    {
                        srchArgsV2.TargetCriteria = UserSearchHelper.GetQuickSearchCriteria(provider.Id, RuntimeContext.Provider.BaseLocale, searchStrings);
                    }

                    srchArgsV2.TargetCriteria = srchArgsV2.TargetCriteria & UserSearchHelper.GetCustomCriteria(new[] { InitializeAdvancedSearch(staticQueryCriteria) });

                    // GROUPS
                    var includeGroupsCriteria = GetIncludeGroupsCriteria(attributeValueIds, attributeIds);
                    if (includeGroupsCriteria != null)
                    {
                        srchArgsV2.TargetCriteria = srchArgsV2.TargetCriteria & includeGroupsCriteria;
                    }
                }
            }
            // USER MANAGER FLOW
            else if (searchFlow == SearchFlow.FromUserManager.ToString())
            {
                if (searchStrings != null)
                {
                    srchArgsV2.TargetCriteria = UserSearchHelper.GetQuickSearchCriteria(provider.Id, RuntimeContext.Provider.BaseLocale, searchStrings);
                }

                var customCriteriaList = new List<List<GenericCriteria>>();
                if (!string.IsNullOrEmpty(queryCriteria))
                {
                    customCriteriaList.Add(InitializeAdvancedSearch(queryCriteria));
                }
                if (!string.IsNullOrEmpty(staticQueryCriteria))
                {
                    customCriteriaList.Add(InitializeAdvancedSearch(staticQueryCriteria));
                }

                if (customCriteriaList.HasValue())
                {
                    srchArgsV2.TargetCriteria = srchArgsV2.TargetCriteria & UserSearchHelper.GetCustomCriteria(customCriteriaList);
                }

                // GROUPS
                var includeGroupsCriteria = GetIncludeGroupsCriteria(attributeValueIds, attributeIds);
                if (includeGroupsCriteria != null)
                {
                    srchArgsV2.TargetCriteria = srchArgsV2.TargetCriteria & includeGroupsCriteria;
                }
            }
            else
            { throw new ApplicationException("Unknown case enountered for User Search Flow"); }

            var userIdsToInculde = new List<int>();
            // USERIDs INCLUDE OR EXCLUDE
            if (userIds != null)
            {
                userIdsToInculde.AddRange(userIds);
            }
            if (includeUserIds != null)
            {
                userIdsToInculde.AddRange(includeUserIds);
            }

            if (userIdsToInculde.HasValue())
            {
                srchArgsV2.TargetUsers = userIdsToInculde.ToList();
            }

            if (excludeUserIds != null)
            {
                srchArgsV2.BlockUsers = excludeUserIds.ToList();
            }

            // HIERARCHIES TO INCLUDE (NODES : Organizational Hierarchy, Distribution Lists)
            if (hierarchyIds != null)
            {
                srchArgsV2.TargetCriteria = srchArgsV2.TargetCriteria & UserSearchHelper.GetHierarchyCriteria(provider.Id, provider.BaseLocale, hierarchyIds);
                /*if (!string.IsNullOrEmpty(queryCriteria) || !string.IsNullOrEmpty(staticQueryCriteria) || searchStrings != null)
                {
                    srchArgsV2.TargetCriteria = srchArgsV2.TargetCriteria & UserSearchHelper.GetHierarchyCriteria(provider.Id, provider.BaseLocale, hierarchyIds);
                }
                else
                {
                    srchArgsV2.TargetCriteria = srchArgsV2.TargetCriteria | UserSearchHelper.GetHierarchyCriteria(provider.Id, provider.BaseLocale, hierarchyIds);
                }*/
            }

            // LISTS TO INCLUDE (Dynamic Lists, Static Lists, Tree)
            if (listItemIds != null)
            {
                srchArgsV2.TargetCriteria = srchArgsV2.TargetCriteria & UserSearchHelper.GetListCriteria(provider.Id, listItemIds);
                /*if (!string.IsNullOrEmpty(queryCriteria) || !string.IsNullOrEmpty(staticQueryCriteria) || searchStrings != null)
                {
                    srchArgsV2.TargetCriteria = srchArgsV2.TargetCriteria & UserSearchHelper.GetListCriteria(provider.Id, listItemIds);
                }
                else
                {
                    srchArgsV2.TargetCriteria = srchArgsV2.TargetCriteria | UserSearchHelper.GetListCriteria(provider.Id, listItemIds);
                }*/
            }

            // SHOULD WE INCLUDE ALL USER BASE
            srchArgsV2.TargetAllUserBase = srchArgsV2.TargetCriteria == null &&
                                           srchArgsV2.TargetUsers == null &&
                                           srchArgsV2.BlockCriteria == null &&
                                           srchArgsV2.BlockUsers == null;

            var status = new List<string> { "VLD" };
            if ((bool)!isEnabled) status.Add("DSB");
            var statusValueIds = _userFacade.GetStatusValueIds(status.ToArray());
            var statusAttributeId = _userFacade.GetStatusAttributeId();

            var statusCriteria = UserSearchHelper.GetUserStatusCriteria(statusAttributeId, statusValueIds);
            srchArgsV2.TargetCriteria = srchArgsV2.TargetCriteria & statusCriteria;

            if ((bool)isOperator)
            {
                srchArgsV2.TargetCriteria = srchArgsV2.TargetCriteria & UserSearchHelper.GetUserOperatorCriteria((bool)isOperator);
            }
            if ((bool)isRoleBasedUsers)
            {
                var roleIds = new List<int> { (int)Business.Domain.Entities.Roles.EnterpriseAdmin, (int)Business.Domain.Entities.Roles.AccountabilityManager, (int)Business.Domain.Entities.Roles.AccountabilityOfficer };
                srchArgsV2.TargetCriteria = srchArgsV2.TargetCriteria & UserSearchHelper.GetUserRoleCriteria(roleIds);
            }
            // GET USERS
            var users = _userFacade.SearchUsersByContext(srchArgsV2);
            //Format phone numbers of respective user into International Format.
            foreach (var user in users.Users)
            {
                user.UserDevice = SetFormattedPhoneNumbers(user.UserDevice);
                //Localized the DeviceList
                user.UserDevice = LocalizedDeviceList(user.UserDevice);
            }

            // RETURN RESULT
            var result =
                Json(
                    new
                    {
                        Columns = columns.OrderBy(x => x.ViewId),
                        SecondaryColumns = secondaryColumns,
                        Rows = _userManagerHelper.ConvertToUIModel(users.Users),
                        TotalCounts = users.SearchResultCount,
                        TotalEnabledUsers = users.EnabledUserBaseCount,
                        UserBaseCount = users.UserBaseCount,
                        MaxEnabledUserCount = _virtualSystemFacade.GetMaxEnabledUsersCap(provider.Id)
                    });

            return result;
        }

        /// <summary>
        /// Localized device list values
        /// </summary>
        /// <param name="userDeviceList">List of devices.</param>
        /// <returns>Device list with localized values.</returns>
        private static IDictionary<string, string> LocalizedDeviceList(IDictionary<string, string> userDeviceList)
        {
            var userDeviceDictionary = new Dictionary<string, string>();
            foreach (var deviceNumber in userDeviceList)
            {
                userDeviceDictionary.Add(deviceNumber.Key, LocalizedDeviceValue(deviceNumber.Value));
            }
            return userDeviceDictionary;
        }

        /// <summary>
        /// Method to set phone numbers into International format.
        /// </summary>
        /// <param name="userDeviceList">Dictionary of Devices</param> 
        /// <returns>IDictionary<string, string> Returns Dictionary of parsed phone numbers.</returns> 
        private static IDictionary<string, string> SetFormattedPhoneNumbers(IDictionary<string, string> userDeviceList)
        {
            var userDeviceDictionary = new Dictionary<string, string>();
            string[] extArray = { "ext." };
            char[] extSeparator = { 'x' };

            if (userDeviceList.Any())
            {
                foreach (var deviceNumber in userDeviceList)
                {
                    var possibleNumber = deviceNumber.Value.Split(extSeparator).FirstOrDefault();
                    if (!string.IsNullOrEmpty(possibleNumber) && PhoneNumberUtilInstance.IsPossibleNumber(possibleNumber, string.Empty))
                    {
                        var parsedPhoneNumber = PhoneNumberUtilInstance.Parse(deviceNumber.Value, string.Empty);
                        if (parsedPhoneNumber != null)
                        {
                            if (!userDeviceDictionary.ContainsKey(deviceNumber.Key))
                            {
                                var formatedPhoneNumber = PhoneNumberUtilInstance.Format(parsedPhoneNumber, PhoneNumberFormat.INTERNATIONAL);
                                if (parsedPhoneNumber.HasExtension)
                                    userDeviceDictionary.Add(deviceNumber.Key, formatedPhoneNumber.Split(extArray, StringSplitOptions.RemoveEmptyEntries).Join("x"));
                                else
                                    userDeviceDictionary.Add(deviceNumber.Key, formatedPhoneNumber);
                            }
                        }
                    }
                    else
                        userDeviceDictionary.Add(deviceNumber.Key, deviceNumber.Value);
                }
            }
            return userDeviceDictionary;
        }

        /// <summary>
        /// Localized the device value based on resource file.
        /// </summary>
        /// <param name="value">Value to be localized.</param>
        /// <returns>Returns localized value.</returns>
        public static string LocalizedDeviceValue(string value)
        {
            var resolvedValue = value;
            switch (value)
            {
                case ACTIVE_LABEL:
                    resolvedValue = IWSResources.Device_Active;
                    break;
                case IN_ACTIVE_LABEL:
                    resolvedValue = IWSResources.Device_Inactive;
                    break;
                case NOT_AVAILABLE_LABEL:
                    resolvedValue = IWSResources.Device_Not_Available;
                    break;
            }
            return resolvedValue;
        }

        private ExpressionElement GetIncludeGroupsCriteria(int[] attributeValueIds = null, int[] attributeIds = null)
        {
            ExpressionElement includeGroupsCriteria = null;
            foreach (var attributeId in attributeIds ?? new int[] { })
            {
                includeGroupsCriteria = includeGroupsCriteria & UserSearchHelper.GetGroupsCriteria(new[] { new List<GenericCriteria> { new AttributeCriteria(attributeId, CriteriaOperator.IsNotEmpty, 0) } });
                //includeGroupsCriteria = includeGroupsCriteria | UserSearchHelper.GetGroupsCriteria(new[] { new List<GenericCriteria> { new AttributeCriteria(attributeId, CriteriaOperator.IsNotEmpty, 0) } });
            }
            var attributesDictionary = _userManagerHelper.GetAttributeIdsByValueIds(attributeValueIds ?? new int[] { });
            foreach (var attributeId in attributesDictionary.Keys)
            {
                includeGroupsCriteria = includeGroupsCriteria & UserSearchHelper.GetGroupsCriteria(new[] { new List<GenericCriteria> { new AttributeCriteria(attributeId, CriteriaOperator.Equals, attributesDictionary[attributeId].Join(",")) } });
                //includeGroupsCriteria = includeGroupsCriteria | UserSearchHelper.GetGroupsCriteria(new[] { new List<GenericCriteria> { new AttributeCriteria(attributeId, CriteriaOperator.Equals, attributesDictionary[attributeId].Join(",")) } });
            }
            //for Orgnizations type attributes add VPSCriteria type criteria to filter the user list
            if (attributeValueIds != null && attributesDictionary.Count < attributeValueIds.ToList().Count)
            {
                var deltaValueIds = from attrValue in attributeValueIds
                                    where !(attributesDictionary.Any(x => x.Value.Contains(attrValue)))
                                    select attrValue;
                var orgValueIds = _providerFacade.GetEnterpriseProviderList(RuntimeContext.ProviderId).Select(v => v.Key).Where(y => deltaValueIds.Contains(y)).ToList();
                if (orgValueIds != null && orgValueIds.Count > 0)
                    includeGroupsCriteria = includeGroupsCriteria & new VPSCriteria(0, CriteriaOperator.Equals, orgValueIds.Join(","));
            }

            return includeGroupsCriteria;
        }

        public static List<GenericCriteria> InitializeAdvancedSearch(string queryCriteria)
        {
            var qryCriterion = JsonSerializerService.Deserialize<IEnumerable<Criterion>>(queryCriteria);

            var advancedCriterion = new List<GenericCriteria>();

            if (qryCriterion != null)
            {
                foreach (var qryCriteria in qryCriterion)
                {
                    var criteria = new GenericCriteria(qryCriteria.entity.entityType, qryCriteria.entity.id, qryCriteria.operand);

                    switch (qryCriteria.AttributeType)
                    {
                        case CustomAttributeDataType.Picklist:
                        case CustomAttributeDataType.MultiPicklist:
                        case CustomAttributeDataType.Checkbox:
                            criteria.Value = (qryCriteria.operand == 11 || qryCriteria.operand == 12)
                                ? "0"
                                : ((int[])qryCriteria.Value).Join(",");
                            break;
                        case CustomAttributeDataType.Number:
                        case CustomAttributeDataType.String:
                        case CustomAttributeDataType.Memo:
                        case CustomAttributeDataType.Date:
                        case CustomAttributeDataType.DateTime:
                        case CustomAttributeDataType.Path:
                            criteria.Value = ((string[])qryCriteria.Value).Join(",");
                            break;
                        case CustomAttributeDataType.GeoLocation:
                            var fc = new FeatureCollection(qryCriteria.value[0].text);
                            if (fc.Features != null && fc.Features.Count > 0)
                            {
                                foreach (var f in fc.Features)
                                {
                                    if (f.Geometry.Type == Map.Geometry.Type.Polygon || f.Geometry.Type == Map.Geometry.Type.MultiPolygon)
                                    {
                                        criteria = new AttributeCriteria(qryCriteria.entity.id, qryCriteria.operand, f.Attributes["OBJECTID"].ToString());
                                    }
                                }
                            }
                            break;
                        case CustomAttributeDataType.AttributeValue:
                        case CustomAttributeDataType.Device:
                        case CustomAttributeDataType.Entity:
                        case CustomAttributeDataType.Object:
                        case CustomAttributeDataType.Unknown:
                        default:
                            throw new Exception("Not Implemented");
                    }

                    advancedCriterion.Add(criteria);
                }
            }

            return advancedCriterion;
        }


        [IWSAuthorize(new[] { SystemObject.EndUsers }, new[] { ActionType.View })]
        public ActionResult DistList()
        {
            var provider = RuntimeContext.Provider;
            var listItems = _userFacade.GetListItemBySpec(new DistributionListSpec
            {
                IncludeTranslatedDefinition = true,
                ProviderId = provider.Id,
                HierarchyIds = new[] { 1144 },
                DistributionListTypes = new[] { ListItemType.Static, ListItemType.Dynamic },
                Status = UserStatusType.Active
            });

            var html = new StringBuilder();
            foreach (var item in listItems)
            {
                html.Append(item.Id).Append(", ");
                html.Append(item.Name).Append(", ");
                html.Append(item.HierarchyId).Append(", ");
                html.Append(item.Status).Append(", ");
                html.Append(item.ListType).Append("<br />");
            }
            return Content(html.ToString());
        }

        [IWSAuthorize(new[] { SystemObject.EndUsers }, new[] { ActionType.View })]
        public ActionResult HierTree()
        {
            var provider = RuntimeContext.Provider;
            var listItems = _userFacade.GetListItemBySpec(new DistributionListSpec
            {
                ProviderId = provider.Id,
                DistributionListTypes = new[] { ListItemType.Tree },
                Status = UserStatusType.Active,
                IncludeParentChildren = true,
                IncludeHierarchy = true
            });

            var html = new StringBuilder();
            foreach (var item in listItems)
            {
                PrintTreeNode(html, "", item);
            }

            html.Append("<pre>{0}</pre>".FormatWith(JsonSerializerService.Current.Serialize(listItems,
                    settings: new SerializerSettings { Formatting = Formatting.Indented })));

            return Content(html.ToString());
        }

        [NonAction]
        private void PrintTreeNode(StringBuilder html, string indent, DistributionList listItem)
        {
            html.Append("{0}Name: {1} (parent: {2})(HierarchyId: {3})<br />".FormatWith(indent, listItem.Name,
                listItem.ParentList == null ? "None" : listItem.ParentList.Name, listItem.HierarchyId));
            indent += "----->";
            if (listItem.Children != null)
            {
                foreach (var item in listItem.Children.OrderBy(x => x.Name))
                {
                    PrintTreeNode(html, indent, item);
                }
            }
        }

        #region UnKnown Public Methods. Need to Remove them in 91

        [IWSAuthorize(new[] { SystemObject.EndUsers }, new[] { ActionType.View })]
        public ActionResult EndUsers()
        {
            throw new NotSupportedException("The method is deprecated and will be removed in 91");
            //Deprecated perhaps
            var provider = RuntimeContext.Provider;
            var currentUser = RuntimeContext.Operator;

            var html = new StringBuilder();

            var endUsers = _userFacade.GetUsersBySpec(new UserSpec
            {
                ProviderId = provider.Id,
                OperatorId = currentUser.Id,
                GetRegularUsers = true,
                GetNonPersonalDevices = true,
                SelectedAttributes = ProviderAttributes.GetByCommonNames("LOGIN_ID FIRSTNAME LASTNAME USAFRICOM")
            });

            if (endUsers != null)
            {
                foreach (var user in endUsers)
                {
                    html.Append("UserID = ").Append(user.Id).Append("<br />");
                    foreach (var pair in user)
                    {
                        html.Append("------------>");
                        var value = (pair.Value is List<string>) ? (pair.Value as List<string>).Join() : pair.Value;

                        html.Append(pair.Key).Append(" = ").Append(value);
                        html.Append("(").Append(pair.Value.GetType()).Append(")");
                        html.Append("<br />");
                    }
                }

                html.Append("JSON Data<br /><br />");
                var serialized = JsonSerializerService.Current.Serialize(endUsers,
                    settings: new SerializerSettings { Formatting = Formatting.Indented });
                html.Append("<pre>").Append(serialized).Append("</pre>");
            }
            else
            {
                html.Append("No end users found");
            }

            return Content(html.ToString());
        }

        [IWSAuthorize(new[] { SystemObject.EndUsers }, new[] { ActionType.View })]
        public ActionResult CustomAttributes()
        {
            throw new NotSupportedException("This method is no longer supported in 91 and will be removed");
            var html = new StringBuilder();

            foreach (var item in ProviderAttributes)
            {
                html.Append(item.AttributeName);
                html.Append("(").Append(item.CommonName).Append(")");
                html.Append("(").Append(item.AttributeTypeId).Append(")");
                html.Append("<br />");
                if (item.Values != null)
                {
                    foreach (var value in item.Values)
                        html.Append("------------>").Append(value.ValueName).Append("<br />");
                }

                if (item.Targeting != null)
                {
                    html.Append("----TARGETING---->").Append(item.Targeting.TargetingType).Append("<br />");
                }
            }

            return Content(html.ToString());
        }

        #endregion

        [IWSAuthorize(new[] { SystemObject.EndUsers }, new[] { ActionType.View })]
        public ActionResult GetPointFromAddress(string address)
        {
            const string key = "Au1W2UTppQzyntvpMpRrNODG0bF6l1rBca6AI3toH6MqxVkjKgecZoxPdokOO9Hj";
            var geocodeRequest = new Uri(string.Format("http://dev.virtualearth.net/REST/v1/Locations?q={0}&key={1}", address.Replace("#", ""), key));
            using (var webClient = new WebClient())
            {
                var json = webClient.DownloadString(geocodeRequest);
                var root = JObject.Parse(json);
                return Json(new { Result = root }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.EndUsers }, new[] { ActionType.Modify })]
        public ActionResult DeleteUsers(UsersStatusCriteria deleteUsersCriteria)
        {
            try
            {
                var provider = RuntimeContext.Provider;
                var currentUser = RuntimeContext.Operator;
                var userIds = _userManagerHelper.GetSelectedUserIds(deleteUsersCriteria, _devicesByName);
                var userSpec = new UserSpec { ProviderId = provider.Id, UserIds = userIds, UpdatedByOperatorId = currentUser.Id };
                _userFacade.DeleteUser(userSpec);

                var currentOperatorDeleted = false;
                if (userIds.HasValue())
                {
                    currentOperatorDeleted = userIds.Contains(currentUser.Id);
                }

                return Json(new { Data = deleteUsersCriteria.EntityIds, CurrentOperatorDeleted = currentOperatorDeleted });
            }
            catch (Exception exce)
            {
                return null;
            }
        }

        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.EndUsers }, new[] { ActionType.Modify })]
        public ActionResult DisableUsers(UsersStatusCriteria disableUsersCriteria)
        {
            try
            {
                var provider = RuntimeContext.Provider;
                var currentUser = RuntimeContext.Operator;

                var userIds = _userManagerHelper.GetSelectedUserIds(disableUsersCriteria, _devicesByName);
                var userSpec = new UserSpec { ProviderId = provider.Id, UserIds = userIds, UpdatedByOperatorId = currentUser.Id };
                _userFacade.DisableUser(userSpec);

                var currentOperatorDisabled = false;
                if (userIds.HasValue())
                {
                    currentOperatorDisabled = userIds.Contains(currentUser.Id);
                }
                return Json(new { Data = disableUsersCriteria, CurrentOperatorDisabled = currentOperatorDisabled });
            }
            catch (Exception exec)
            {
                return null;
            }
        }

        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.EndUsers }, new[] { ActionType.View })]
        public ActionResult GetUsersForCriteria(UsersStatusCriteria criteria)
        {
            try
            {
                var userIds = _userManagerHelper.GetSelectedUserIds(criteria, _devicesByName);
                return Json(userIds);
            }
            catch (Exception)
            {
                return null;
            }
        }

        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.EndUsers }, new[] { ActionType.Modify })]
        public ActionResult EnableUsers(UsersStatusCriteria enableUsersCriteria)
        {
            try
            {
                var provider = RuntimeContext.Provider;
                var userIds = _userManagerHelper.GetSelectedUserIds(enableUsersCriteria, _devicesByName);
                var userSpec = new UserSpec { ProviderId = provider.Id, UserIds = userIds, UpdatedByOperatorId = RuntimeContext.Operator.Id };
                _userFacade.EnableUser(userSpec);
                return Json(enableUsersCriteria);
            }
            catch (Exception)
            {
                return null;
            }
        }

        #region ExportImportControllers

        [RenderAsPDF(AutoConvert = false)]
        [FileDownloadCookie]
        public ActionResult PdfView()
        {
            var records = 0;
            var format = "pdf";
            if (Request.QueryString["records"].IsNotNullOrEmpty())
            {
                records = Int32.Parse(Request.QueryString["records"]);
            }

            if (Request.QueryString["format"].IsNotNullOrEmpty())
            {
                format = Request.QueryString["format"];
            }
            var pdfSpec = new PdfGridConfiguration(8);
            pdfSpec.PageTitle = IWSResources.UserManager_Export_View_Export_PDF_PageTitle;
            ViewBag.PdfSpec = pdfSpec;
            ViewBag.records = records;

            try
            {
                if (format == "pdf")
                {
                    MVCToPDF.ResultFileName = FileNameFormats.GetFormattedFileName(IWSResources.Alert_PDFExport, "pdf");
                    MVCToPDF.RenderAsPDF();
                }
            }
            catch (HttpException)
            {

            }

            return View("PdfView");
        }

        [HttpPost]
        [FileDownloadCookie]
        [RenderAsPDF(AutoConvert = false)]
        [IWSAuthorize(new[] { SystemObject.ImportExportUsers }, new[] { ActionType.View })]
        public ActionResult ExportToCsv(FormCollection form)
        {
            var provider = RuntimeContext.Provider;
            var attributes = form["customAttributes"];
            var devices = form["devices"];
            var exportTo = form["exportTo"];
            var staticLists = form["staticLists"];
            var distributionLists = form["distributionListsId"];
            ExportFormat exportFormat;
            Enum.TryParse(exportTo, out exportFormat);

            var deserialized = new JavaScriptSerializer().Deserialize<UsersStatusCriteria>(form["searchCriteria"]);

            // Instead of using static _allDevices collection fetching fresh list of provider devices as static collection is causing problem in some cases when devices are exported
            var providerDevices =
                _deviceFacade.GetDevicesBySpec(new DeviceSpec
                {
                    ProviderId = provider.Id,
                    IncludeDeviceProvider = true,
                    IncludeDeviceGroup = true,
                    EnabledOnly = true
                }, RuntimeContext.Provider.BaseLocale);

            var devicesId = devices.Split<int>().ToList();
            var attributesId = attributes.Split<int>().ToList();
            var staticListsId = staticLists.Split<int>().ToList();
            var distributionListsId = distributionLists.Split<int>().ToList();

            IEnumerable<string> attributeNames = ProviderAttributes.GetByIds(attributesId).Where(x => x != null && (x.CommonName != (!RuntimeContext.Provider.FeatureMatrix.IsEnterpriseManagementSupported ? AttributeCommonNames.Organizations : null)) && (x.CommonName != (!RuntimeContext.Provider.FeatureMatrix.IsEnterpriseManagementSupported ? AttributeCommonNames.PreventUserMove : null))).Select(y => y.CommonName);


            // var attributesList = attributes.ToList();
            // if (customViewList.Any(y => y.Columnid.Equals(CustomViewColumnType.OrgName)) == false)
            // {
            var enumerable = attributeNames as IList<string> ?? attributeNames.ToList();

            //      attributes = attributes.Concat(new[] { organizationCustomViewColumn }).OrderBy(x => x.DisplayName);
            //  }
            if (deserialized.CriteriaType == (int)ListCriteriaType.USER_LIST)
                deserialized.SearchCriteria.userIds = deserialized.EntityIds.ToArray();

            // If criteria type is exception list then entity ids contains ids of users which should not export
            if (deserialized.CriteriaType == (int)ListCriteriaType.EXCEPTION_LIST)
                deserialized.SearchCriteria.excludeUserIds = deserialized.EntityIds.ToArray();

            var fileName = FileNameFormats.GetFormattedFileName(IWSResources.User_CSVExport, "csv");

            var searchCriteria = _userManagerHelper.ConvertToSearchArgs(deserialized, false);
            searchCriteria.AttributeNames = enumerable.ToList();
            searchCriteria.DeviceNames =
                providerDevices.Where(x => devicesId.Contains(x.Id)).Select(y => y.CommonName).ToList();
            searchCriteria.ProviderCriteria = UserSearchHelper.GetProviderCriteria(provider.Id);
            var specExport = new UserExportSpec()
            {
                SearchCriteria = searchCriteria,
                AttributesId = attributesId,
                DevicesId = devicesId,
                DistributionListsId = distributionListsId,
                OperatorId = RuntimeContext.Operator.Id,
                ProviderId = provider.Id,
                StaticListsId = staticListsId
            };
            ContextSearchResult userContextSearchResult = _userFacade.GetUserExportSearchResult(specExport);

            var orderDescriptor = _userFacade.GetUserExportDescriptorList(specExport, ProviderAttributes, providerDevices.ToList());


            //var exportModel = GetExportModelForUsers(userContextSearchResult.Users, orderDescriptor.ToList());

            var exportModel = GetExportModelForUsers(userContextSearchResult.UsersDataTable, orderDescriptor.ToList());

            if (ExportFormat.Csv == exportFormat)
            {
                var csvData = ExportUtility.SetCsv(exportModel, null, false, true);
                return File(csvData.GridData, "text/csv", csvData.FileName);
            }
            //Converting the DataTable to Dictionary for ExportToPdf and passing the GridRows property
            exportModel = AddGridRowsForPDFFormatting(exportModel);
            var pdfHtml = ExportUtility.SetPdf(exportModel);

            var countOfColumns = attributesId.Count;
            if (countOfColumns < 4)
            {
                countOfColumns = 4;
            }

            var pdfSpec = new PdfGridConfiguration(countOfColumns)
            {
                PageTitle = IWSResources.UserManager_Export_View_Export_PDF_PageTitle
            };


            ViewBag.Header = pdfHtml.Header;
            ViewBag.Body = pdfHtml.Rows;
            ViewBag.PdfSpec = pdfSpec;

            try
            {
                MVCToPDF.ResultFileName = FileNameFormats.GetFormattedFileName(IWSResources.Alert_PDFExport, "pdf");
                MVCToPDF.RenderAsPDF();
            }
            catch (HttpException)
            {

            }

            return View("_ExportToPdfUsers", pdfHtml);
        }

        private ExportModel AddGridRowsForPDFFormatting(ExportModel exportModel)
        {
            DataTable dt = exportModel.GridDataTable;

            List<Dictionary<string, object>> exportList = dt.AsEnumerable().Select(
                 row => dt.Columns.Cast<DataColumn>().ToDictionary(
                     column => column.ColumnName, // Key
                     column => row[column] as object // Value
                     )
                 ).ToList();

            exportModel.GridRows = exportList.ToList();

            return exportModel;
        }

        private ExportModel GetExportModelForUsers(DataTable usersDataTable, IEnumerable<UserExportDescriptor> orderDescriptor)
        {
            var globalEntityLocaleFacade = new GlobalEntityLocaleFacade(new GlobalEntityLocaleRepository());
            var orderDescriptorArray = orderDescriptor.ToArray();
            var gridHeader = orderDescriptorArray.Select(descriptor => new ExportGridColumnConfig(descriptor.Name)).ToList();
            var providercontext = RuntimeContext.Provider;

            var deviceColumns = orderDescriptorArray.Where(x => x.EntityType == CsvExportType.Device).ToArray();

            DataTable dtCloned = usersDataTable.Clone();
            foreach (DataColumn col in dtCloned.Columns)
            {
                col.DataType = typeof(string);
                // this line is added to address IWS-32217 issue 
                if ((col.ColumnName == CommonNames.MobileNotifierDevice || col.ColumnName == CommonNames.DesktopDevice) && !RuntimeContext.Provider.BaseLocale.Equals("en-US"))
                    col.MaxLength = col.MaxLength*2;

            }
            foreach (DataRow row in usersDataTable.Rows)
            {
                dtCloned.ImportRow(row);
            }

            //Datatable column names are commonnames but only for 'username' attribute, the commonname is coming as 'USERNAME' as mentioned in the AttributeResultSetNames.UserName enum
            dtCloned.Columns[AttributeResultSetNames.UserName].ColumnName = CommonNames.UserName;
            dtCloned.Columns.Remove("user_id");

            var yesLocale = globalEntityLocaleFacade.GetLocalizedValue("Yes", BusinessEntity.CheckBox, "Name", RuntimeContext.Provider.BaseLocale);
            var noLocale = globalEntityLocaleFacade.GetLocalizedValue("No", BusinessEntity.CheckBox, "Name", RuntimeContext.Provider.BaseLocale);
            //Process Data
            foreach (DataColumn col in dtCloned.Columns)
            {
                var providerAttr = ProviderAttributes.FirstOrDefault(a => a.CommonName == col.ColumnName);
                var deviceColumn = deviceColumns.FirstOrDefault(a => a.CommonName == col.ColumnName);
                if (providerAttr == null && deviceColumn == null) continue;

                //Continue if the column type doesn't fall into switch cases datatypes
                if (providerAttr != null && (providerAttr.AttributeTypeId != CustomAttributeDataType.Checkbox
                                             && providerAttr.AttributeTypeId != CustomAttributeDataType.Date
                                             && providerAttr.AttributeTypeId != CustomAttributeDataType.DateTime
                                             && providerAttr.AttributeTypeId != CustomAttributeDataType.GeoLocation))
                    continue;


               
                //make dtcloned columns as not readonly as we need to format the data in the datatable
                col.ReadOnly = false;

                DataColumn dataColumn = col;
                var rowsToUpdate = dtCloned.AsEnumerable()
                    .Where(r => !string.IsNullOrEmpty(r.Field<string>(dataColumn)));

                if (providerAttr != null)
                {
                    switch (providerAttr.AttributeTypeId)
                    {
                        case CustomAttributeDataType.Checkbox:
                            rowsToUpdate.ToList().ForEach(r => r.SetField(col.ColumnName, r.Field<string>(col.ColumnName) != null && r.Field<string>(col.ColumnName).Equals("Yes") ? yesLocale : string.Empty));
                            break;
                        case CustomAttributeDataType.Date:
                            rowsToUpdate.ToList().ForEach(r => r.SetField(col.ColumnName, providercontext.SystemToVpsDateFormated(Convert.ToDateTime(r.Field<string>(col.ColumnName)))));
                            break;
                        case CustomAttributeDataType.DateTime:
                            rowsToUpdate.ToList().ForEach(r => r.SetField(col.ColumnName, providercontext.SystemToVpsDateTimeFormated(Convert.ToDateTime(r.Field<string>(col.ColumnName)))));
                            break;
                    }
                }
                else
                {
                    if (deviceColumn.CommonName == CommonNames.MobileNotifierDevice ||
                        deviceColumn.CommonName == CommonNames.DesktopDevice)
                    {

                        rowsToUpdate.ToList().ForEach(r => r.SetField(col.ColumnName,
                            r.Field<string>(col.ColumnName) == ACTIVE_LABEL
                                ? IWSResources.Device_Active
                                : r.Field<string>(col.ColumnName) == IN_ACTIVE_LABEL
                                    ? IWSResources.Device_Inactive
                                    : r.Field<string>(col.ColumnName) == NOT_AVAILABLE_LABEL
                                        ? IWSResources.Device_Not_Available
                                        : r.Field<string>(col.ColumnName) == AVAILABLE_LABEL
                                            ? IWSResources.Device_Available
                                            : r.Field<string>(col.ColumnName)));
                    }
                }
            }

            //Change DataTable column names from common_name to display_name
            foreach (DataColumn col in dtCloned.Columns)
            {
                foreach (var orderdesc in orderDescriptorArray)
                {
                    if (col.ColumnName == orderdesc.CommonName)
                    {
                        col.ColumnName = orderdesc.Name;
                        break;
                    }
                }
            }

            //set order w.r.t order descriptor
            for (int i = 0; i < orderDescriptorArray.Length; i++)
            {
                dtCloned.Columns[orderDescriptorArray[i].Name].SetOrdinal(i);
            }

            var exportModel = new ExportModel()
            {
                Title = IWSResources.Event_Export_Inbox_PageTitle,
                GridDataTable = dtCloned,
                GridHeaders = gridHeader
            };
            return exportModel;
        }

        /// <summary>
        /// Returns export model for users
        /// </summary>
        /// <param name="userSearchResultItemList">User serach result</param>
        /// <param name="orderDescriptor">Orderdescriptor for exported columns</param>
        /// <returns>Export model</returns>
        private ExportModel GetExportModelForUsers(List<UserSearchResultItem> userSearchResultItemList, List<UserExportDescriptor> orderDescriptor)
        {
            var gridHeader = new List<ExportGridColumnConfig>();
            var exportList = new List<Dictionary<string, object>>();
            GlobalEntityLocaleFacade globalEntityLocaleFacade = new GlobalEntityLocaleFacade(new GlobalEntityLocaleRepository());

            foreach (var descriptor in orderDescriptor)
            {
                gridHeader.Add(
                              new ExportGridColumnConfig(descriptor.Name)
                             );
            }

            foreach (var userSearchResultItem in userSearchResultItemList)
            {
                Dictionary<string, object> exportItem = new Dictionary<string, object>();
                foreach (var gridHeaderItem in gridHeader)
                {
                    var orderDescriptorItem = orderDescriptor.FirstOrDefault(x => x.Name.Equals(gridHeaderItem.ColumnName));
                    foreach (var userAttribute in userSearchResultItem.UserAttributes.Where(userAttribute => orderDescriptorItem != null && orderDescriptorItem.CommonName.Equals(userAttribute.Key)))
                    {
                        var providerAttr = ProviderAttributes.FirstOrDefault(a => a.CommonName == userAttribute.Key);
                        if (providerAttr != null)
                        {
                            if (providerAttr.AttributeTypeId == CustomAttributeDataType.Checkbox)
                            {
                                if (!string.IsNullOrEmpty(userAttribute.Value))
                                {
                                    exportItem.Add(gridHeaderItem.ColumnName, globalEntityLocaleFacade.GetLocalizedValue(userAttribute.Value,
                                        BusinessEntity.CheckBox, "Name", RuntimeContext.Provider.BaseLocale));
                                }
                            }
                            else
                            {

                                if (!string.IsNullOrEmpty(userAttribute.Value))
                                {
                                    var usrAttributeValue = userAttribute.Value;
                                    switch (providerAttr.AttributeTypeId)
                                    {
                                        case CustomAttributeDataType.Date:
                                            usrAttributeValue = RuntimeContext.Provider.SystemToVpsDateFormated(
                                            Convert.ToDateTime(userAttribute.Value));
                                            break;
                                        case CustomAttributeDataType.DateTime:
                                            usrAttributeValue = RuntimeContext.Provider.SystemToVpsDateTimeFormated(
                                            Convert.ToDateTime(userAttribute.Value));
                                            break;
                                        case CustomAttributeDataType.GeoLocation:
                                            var geo_value = SqlGeography.STGeomFromText(new SqlChars(usrAttributeValue), 4326);
                                            usrAttributeValue = geo_value.Lat.ToString() + "," +
                                                                      geo_value.Long.ToString();
                                            break;
                                    }

                                    exportItem.Add(gridHeaderItem.ColumnName, usrAttributeValue);
                                }
                                else
                                    exportItem.Add(gridHeaderItem.ColumnName,
                                       string.Empty);

                            }

                        }

                    }

                    var deviceAttrbuteValue = string.Empty;

                    foreach (var deviceAttribute in userSearchResultItem.UserDevice.Where(device => orderDescriptorItem != null && orderDescriptorItem.CommonName.Equals(device.Key)))
                    {
                        if (!string.IsNullOrEmpty(deviceAttribute.Value))
                        {
                            deviceAttrbuteValue = deviceAttribute.Value;
                            deviceAttrbuteValue = deviceAttrbuteValue.Replace(ACTIVE_LABEL, IWSResources.Device_Active);
                            deviceAttrbuteValue = deviceAttrbuteValue.Replace(IN_ACTIVE_LABEL, IWSResources.Device_Inactive);
                            deviceAttrbuteValue = deviceAttrbuteValue.Replace(NOT_AVAILABLE_LABEL, IWSResources.Device_Not_Available);
                            deviceAttrbuteValue = deviceAttrbuteValue.Replace(AVAILABLE_LABEL, IWSResources.Device_Available);

                            exportItem.Add(gridHeaderItem.ColumnName, deviceAttrbuteValue);
                        }
                        else
                        {
                            exportItem.Add(gridHeaderItem.ColumnName, deviceAttribute.Value);
                        }


                    }
                }
                exportList.Add(exportItem);
            }

            var exportModel = new ExportModel()
            {
                Title = IWSResources.Event_Export_Inbox_PageTitle,
                GridRows = exportList.ToList(),
                GridHeaders = gridHeader

            };
            return exportModel;
        }

        //Will Refactor this code to possibly use the device list and custom attributes from cache.
        //Further refactoring to separate layer might be done later.
        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.ImportExportUsers }, new[] { ActionType.View })]
        public JsonResult FileUpload(SingleFileModel model)
        {
            var errors = new List<string>();
            var provider = RuntimeContext.Provider;
            var currentOperator = RuntimeContext.Operator;
            var importedById = currentOperator.Id;
            var columnCount = 0;
            var isResultValid = true;
            var validColumns = Enumerable.Empty<string>();
            var columnsNotMatch = Enumerable.Empty<string>();
            var columnsNotPermisson = Enumerable.Empty<string>();
            var defaultColumn = String.Empty;
            var fileErrors = new List<string>();
            var directoryLocation = _configurations.FilesBasePath + AtHoc.IWS.Business.Configurations.Constants.ImportFileUploadPath;
            if (!Directory.Exists(directoryLocation))
            {
                isResultValid = false;
                errors.Add(IWSResources.Error_UserManager_Import_DirectoryDoesNotExist);
            }

            var randomDirectory = Guid.NewGuid().ToString("N");
            while (Directory.Exists(directoryLocation + randomDirectory))
            {
                randomDirectory = Guid.NewGuid().ToString("N");
            }
            directoryLocation = directoryLocation + randomDirectory;
            Directory.CreateDirectory(directoryLocation);

            if (isResultValid)
            {

                if (!ModelState.IsValid)
                {
                    fileErrors.AddRange(ModelState["File"].Errors.Select(error => error.ErrorMessage));
                    errors.AddRange(ModelState["File"].Errors.Select(error => error.ErrorMessage));
                    isResultValid = false;
                }
                else
                {
                    var savePath = directoryLocation + "\\ORIGINAL_" + Path.GetFileName(model.File.FileName);
                    model.File.SaveAs(savePath);
                    var spec = new UserCsvImportSpec
                    {
                        ProviderId = provider.Id,
                        FileName = savePath,
                        ImportedById = importedById,
                        GetColumns = true,
                        Locale = provider.BaseLocale
                        //GetUserCount = true
                    };
                    var fileParseActionResult = _userExportImportFacade.GetUserCsvFileParseResult(spec);
                    if (fileParseActionResult.IsValid)
                    {
                        var fileParseResult = fileParseActionResult.Value;
                        var columnResult = fileParseResult.ColumnResult;
                        columnCount = fileParseResult.CountResult.Count;
                        if (columnCount <= 0)
                        {
                            isResultValid = false;
                            errors.Add(IWSResources.Error_UserManager_Import_FileHasNoUsers);
                        }

                        validColumns = columnResult.Columns.Except(columnResult.ColumnsNotMatch);
                        validColumns = validColumns.Except(columnResult.ColumnsNotHavePermissions);

                        var username = ProviderAttributes.GetByCommonName(AttributeCommonNames.UserName);

                        defaultColumn = validColumns.Contains(username.AttributeName, StringComparer.OrdinalIgnoreCase)
                            ? username.AttributeName
                            : "";

                        if (defaultColumn == "")
                        {
                            isResultValid = false;
                            errors.Add(IWSResources.Error_UserManager_Import_FileHasNoUsername);
                        }

                        columnsNotMatch = columnResult.ColumnsNotMatch;
                        columnsNotPermisson = columnResult.ColumnsNotHavePermissions;
                    }
                    else
                    {
                        isResultValid = false;
                        errors.Add(IWSResources.Error_UserManager_Import_FileParseError);
                        fileErrors.AddRange(fileParseActionResult.Messages.Select(x => x.Value));

                    }


                }
            }

            var data = new
            {
                files = new[] { new { name = Path.GetFileName(model.File.FileName), size = model.File.ContentLength, directory = randomDirectory, error = fileErrors } },
                validColumns,
                columnsNotMatch,
                defaultColumn,
                columnsNotPermission = columnsNotPermisson,
                numberOfUsers = columnCount,
                isResultValid,
                errors,
            };

            return (Json(data, "text/plain"));

        }



        //Will Refactor this code to possibly use the device list and custom attributes from cache.
        //Further refactoring to separate layer might be done later.
        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.ImportExportUsers }, new[] { ActionType.View })]
        public JsonResult APIFileUpload(SingleFileModel model)
        {
            var errors = new List<string>();
            var provider = RuntimeContext.Provider;
            var currentOperator = RuntimeContext.Operator;
            var importedById = currentOperator.Id;
            var columnCount = 0;
            var isResultValid = true;
            var validColumns = Enumerable.Empty<string>();
            var columnsNotMatch = Enumerable.Empty<string>();
            var columnsNotPermisson = Enumerable.Empty<string>();
            var defaultColumn = String.Empty;
            var fileErrors = new List<string>();
            var directoryLocation = _configurations.FilesBasePath + AtHoc.IWS.Business.Configurations.Constants.ImportFileUploadPath;
            if (!Directory.Exists(directoryLocation))
            {
                isResultValid = false;
                errors.Add(IWSResources.Error_UserManager_Import_DirectoryDoesNotExist);
            }

            var randomDirectory = Guid.NewGuid().ToString("N");
            while (Directory.Exists(directoryLocation + randomDirectory))
            {
                randomDirectory = Guid.NewGuid().ToString("N");
            }
            directoryLocation = directoryLocation + randomDirectory;
            Directory.CreateDirectory(directoryLocation);


            if (isResultValid)
            {

                if (!ModelState.IsValid)
                {
                    fileErrors.AddRange(ModelState["File"].Errors.Select(error => error.ErrorMessage));
                    errors.AddRange(ModelState["File"].Errors.Select(error => error.ErrorMessage));
                    isResultValid = false;
                }
                else
                {
                    var savePath = directoryLocation + "\\ORIGINAL_" + Path.GetFileName(model.File.FileName);
                    model.File.SaveAs(savePath);
                    var spec = new UserCsvImportSpec
                    {
                        ProviderId = provider.Id,
                        FileName = savePath,
                        ImportedById = importedById,
                        GetColumns = true,
                        Locale = provider.BaseLocale
                        //GetUserCount = true
                    };
                    var fileParseActionResult = _userExportImportFacade.GetUserCsvFileParseResult(spec);
                    if (fileParseActionResult.IsValid)
                    {
                        var fileParseResult = fileParseActionResult.Value;
                        var columnResult = fileParseResult.ColumnResult;
                        columnCount = fileParseResult.CountResult.Count;
                        if (columnCount <= 0)
                        {
                            isResultValid = false;
                            errors.Add(IWSResources.Error_UserManager_Import_FileHasNoUsers);
                        }

                        validColumns = columnResult.Columns.Except(columnResult.ColumnsNotMatch);
                        validColumns = validColumns.Except(columnResult.ColumnsNotHavePermissions);

                        var username = ProviderAttributes.GetByCommonName(AttributeCommonNames.UserName);

                        defaultColumn = validColumns.Contains(username.AttributeName, StringComparer.OrdinalIgnoreCase)
                            ? username.AttributeName
                            : "";

                        if (defaultColumn == "")
                        {
                            isResultValid = false;
                            errors.Add(IWSResources.Error_UserManager_Import_FileHasNoUsername);
                        }

                        columnsNotMatch = columnResult.ColumnsNotMatch;
                        columnsNotPermisson = columnResult.ColumnsNotHavePermissions;

                        //Add 'Organization' attribute to not found list untill IsEnterpriseManagementSupported and IsUserUniqueAcrossEnterprise are true for a given Organization
                        if (ProviderAttributes.Any(x => x.CommonName == CommonNames.Organizations))
                        {
                            var organizationAttribute = ProviderAttributes.First(x => x.CommonName == CommonNames.Organizations);
                            if (validColumns.Contains(organizationAttribute.AttributeName))
                            {
                                if (!provider.FeatureMatrix.IsEnterpriseManagementSupported || !provider.FeatureMatrix.IsUserUniqueAcrossEnterprise)
                                {
                                    columnsNotMatch = columnsNotMatch.Concat(new string[] { organizationAttribute.AttributeName });
                                }
                            }
                        }
                    }
                    else
                    {
                        isResultValid = false;
                        errors.Add(IWSResources.Error_UserManager_Import_FileParseError);
                        fileErrors.AddRange(fileParseActionResult.Messages.Select(x => x.Value));
                    }
                }
            }

            var data = new
            {
                files = new[] { new { name = Path.GetFileName(model.File.FileName), size = model.File.ContentLength, directory = randomDirectory, error = fileErrors } },
                validColumns,
                columnsNotMatch,
                defaultColumn,
                columnsNotPermission = columnsNotPermisson,
                numberOfUsers = columnCount,
                isResultValid,
                errors,
            };

            return (Json(data, "text/plain"));

        }


        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.ImportExportUsers }, new[] { ActionType.View })]
        public JsonResult StartImport(List<string> selectedColumns, string fileName, string directory)
        {
            var baseUploadDirectory = _configurations.FilesBasePath + AtHoc.IWS.Business.Configurations.Constants.ImportFileUploadPath;
            var fullPath = baseUploadDirectory + directory + "\\" + "ORIGINAL_" + fileName;


            var isResultValid = true;
            var messages = new List<string>();

            var statusResult = _userExportImportFacade.GetUserImportStatus(new UserImportStatusSpec
            {
                ProviderId = RuntimeContext.Provider.Id
            });

            if (statusResult != null)
            {

                if (statusResult.Status == UserImportStatusType.InProgress ||
                    statusResult.Status == UserImportStatusType.New)
                {
                    isResultValid = false;
                    messages.Add("Import is already in progress");
                }
            }

            if (isResultValid)
            {
                var result = _userExportImportFacade.StartImport(new UserImportDataSpec
                {
                    ProviderId = RuntimeContext.Provider.Id,
                    SelectedColumns = selectedColumns,
                    FileName = fullPath,
                    UserId = RuntimeContext.Operator.Id,
                    OperatorId = RuntimeContext.Operator.Id,
                    TimeOut = 5400      // set timeout to 1.5 hours
                });

                if (!result.IsValid)
                {
                    isResultValid = false;
                    messages.Add("Unable to start the import process right now. Please try again later.");
                }
            }

            var response = new
            {
                isResultValid,
                messages
            };

            return Json(response);
        }

        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.ImportExportUsers }, new[] { ActionType.View })]
        public JsonResult APIStartImport(List<string> selectedColumns, string fileName, string directory)
        {
            var messages = new List<string>();
            if (selectedColumns == null || selectedColumns.Count == 0 || string.IsNullOrEmpty(fileName) || string.IsNullOrEmpty(directory))
            {
                messages.Add(IWSResources.UserManager_Import_Error);
                var isResultValid = false;
                var apiResponse = new { isResultValid, messages };
                return Json(apiResponse);
            }
            var UserImportAPIFlag = string.IsNullOrEmpty(System.Configuration.ConfigurationManager.AppSettings["UserImportAPIFlag"]) ? true : Convert.ToBoolean(System.Configuration.ConfigurationManager.AppSettings["UserImportAPIFlag"]);
            if (UserImportAPIFlag)
            {

                try
                {
                    var provider = RuntimeContext.Provider;
                    var auditSpec = new AuditSpec
                    {
                        Action = ServiceAction.UserImport,
                        ObjectName = provider.ProviderName,
                        ObjectType = EntityType.EndUsers,
                        OperatorId = RuntimeContext.Operator.Id,
                        ProviderId = provider.Id
                    };
                    _operatorAuditFacade.LogAction(auditSpec);
                    var baseUploadDirectory = _configurations.FilesBasePath + AtHoc.IWS.Business.Configurations.Constants.ImportFileUploadPath;
                    var selectedCsvFileData = GetCsvSelectedColumnsDataAsDataTable(baseUploadDirectory + directory, "ORIGINAL_" + fileName, selectedColumns.ToArray());
                    SaveDataTableAsCsvFile(baseUploadDirectory + directory, fileName, selectedCsvFileData);
                    var csvData = new StreamReader(baseUploadDirectory + directory + "\\" + fileName).ReadToEnd();
                    var userSyncService = ResolveAPIDependecies().Resolve<IUserSyncService>();
                    var jobId = userSyncService.CreateAndScheduleUserImportJob(provider.Id, provider.BaseLocale, fileName, csvData.ToString(), RuntimeContext.Operator.Id);
                    var isResultValid = jobId > 0;
                    var apiResponse = new { isResultValid, messages };
                    return Json(apiResponse);
                }
                catch (Exception ex)
                {
                    LogService.Current.Error(() => ex);
                    messages.Add(IWSResources.UserManager_Import_Error);
                    var isResultValid = false;
                    var apiResponse = new { isResultValid, messages };
                    return Json(apiResponse);
                }

            }
            else
            {
                return StartImport(selectedColumns, fileName, directory);
            }
        }

        private DataTable GetCsvSelectedColumnsDataAsDataTable(string directoryLocation, string fileName, string[] selectedColumns)
        {
            var dt = new DataTable();
            IEnumerable<string> columnsToRemove = null;

            using (var sr = new StreamReader(directoryLocation + "\\" + fileName, Encoding.GetEncoding(1252)))
            using (var csv = new CsvReader(sr))
            {
                csv.Configuration.IsHeaderCaseSensitive = false;
                csv.Configuration.Encoding = Encoding.GetEncoding(1252);
                while (csv.Read())
                {
                    if (dt.Columns.Count == 0)
                    {
                        foreach (var header in csv.FieldHeaders)
                        {
                            dt.Columns.Add(header);
                        }

                        columnsToRemove = csv.FieldHeaders.Except(selectedColumns);
                    }

                    dt.Rows.Add(csv.CurrentRecord);
                }
            }

            if (columnsToRemove != null && columnsToRemove.Count() > 0)
            {
                foreach (var column in columnsToRemove)
                {
                    dt.Columns.Remove(column);
                }
            }

            return dt;
        }

        private void SaveDataTableAsCsvFile(string directoryLocation, string fileName, DataTable csvData)
        {
            using (var writer = System.IO.File.CreateText(directoryLocation + "\\" + fileName))
            using (var csv = new CsvWriter(writer))
            {
                csv.Configuration.IsHeaderCaseSensitive = false;
                csv.Configuration.Encoding = Encoding.GetEncoding(1252);
                foreach (DataColumn column in csvData.Columns)
                {
                    csv.WriteField(column.ColumnName);
                }

                csv.NextRecord();

                foreach (DataRow row in csvData.Rows)
                {
                    for (var i = 0; i < csvData.Columns.Count; i++)
                    {
                        csv.WriteField(row[i]);
                    }

                    csv.NextRecord();
                }
            }
        }

        [IWSAuthorize(new[] { SystemObject.ImportExportUsers }, new[] { ActionType.View })]
        public FileResult DownloadImportLog()
        {
            var bytes = _userExportImportFacade.GetImportLog(new UserImportDataSpec { ProviderId = RuntimeContext.Provider.Id });
            if (bytes == null)
            {
                bytes = new byte[0];
            }
            //var fileName = FileNameFormats.WithTimeStamp.FormatWith(RuntimeContext.Operator.Username, dateTimeStamp,"-Import-Log", "csv");
            var fileName = FileNameFormats.GetFormattedFileName("Import-Log", "csv");
            return File(bytes, "text/csv", fileName);
        }

        [IWSAuthorize(new[] { SystemObject.ImportExportUsers }, new[] { ActionType.View })]
        public FileResult APIDownloadImportLog()
        {
            var UserImportAPIFlag = string.IsNullOrEmpty(System.Configuration.ConfigurationManager.AppSettings["UserImportAPIFlag"]) ? true : Convert.ToBoolean(System.Configuration.ConfigurationManager.AppSettings["UserImportAPIFlag"]);
            if (UserImportAPIFlag)
            {

                var userSyncService = ResolveAPIDependecies().Resolve<IUserSyncService>();
                var userImportJob = userSyncService.GetUserImportLog(RuntimeContext.Provider.Id);
                var bytes = AtHocConfigService.Current.Windows1252Encoding.GetBytes(userImportJob.UploadFileData.ToString());
                if (bytes == null)
                {
                    bytes = new byte[0];
                }
                return File(bytes, "text/csv", FileNameFormats.GetFormattedFileName("Import-Log", "csv"));
            }
            else
            {
                return DownloadImportLog();
            }
        }



        [IWSAuthorize(new[] { SystemObject.ImportExportUsers }, new[] { ActionType.View })]
        public FileResult ImportTemplate()
        {
            var templateBytes = _userExportImportFacade.GetImportTemplate(new UserImportDataSpec
            {
                ProviderId = RuntimeContext.Provider.Id,
                UserId = RuntimeContext.Operator.Id,
                BaseLocale = RuntimeContext.Provider.BaseLocale
            }, _deviceFacade);

            //var fileName = FileNameFormats.Simple.FormatWith("Template-User-Import-File", "csv");
            var fileName = FileNameFormats.GetFormattedFileName("Import Template", "csv");
            return File(templateBytes, "text/csv", fileName);


        }

        [IWSAuthorize(new[] { SystemObject.ImportExportUsers }, new[] { ActionType.View })]
        public JsonResult GetImportStatus()
        {
            var isStatusAvailable = true;
            var userSyncService = ResolveAPIDependecies().Resolve<IUserSyncService>();
            UserImportJob JobStatus = userSyncService.GetUserImportStatus(RuntimeContext.Provider.Id);

            var importStatus = new ImportStatusViewModel();
            if (JobStatus == null)
            {
                isStatusAvailable = false;
            }
            else
            {
                UserImportStatus obj = new UserImportStatus()
                {
                    ProviderId = JobStatus.ProviderId,
                    Status = (UserImportStatusType)JobStatus.Status,
                    LastUpdateTime = (DateTime)JobStatus.LastUpdateTime,
                    TotalRecords = JobStatus.TotalRecords,
                    ProcessedRecords = JobStatus.ProcessedRecords,
                    SuccessRecords = JobStatus.SuccessRecords,
                    FailedRecords = JobStatus.FailedRecords,
                    PartialRecords = JobStatus.PartialRecords,
                    StartTime = JobStatus.StartTime == null ? default(DateTime) : Convert.ToDateTime(JobStatus.StartTime),
                    EndTime = JobStatus.EndTime == null ? default(DateTime) : Convert.ToDateTime(JobStatus.EndTime)
                };

                var operatorName = _userExportImportFacade.GetImportStartUserName(
                     new UserImportDataSpec { ProviderId = RuntimeContext.Provider.Id }
                     );
                importStatus.AddData(obj, (operatorName == string.Empty) ? IWSResources.User_Unknown : operatorName);
            }
            return Json(new { isStatusAvailable, importStatus });



        }

        [IWSAuthorize(new[] { SystemObject.ImportExportUsers }, new[] { ActionType.View })]
        public JsonResult APIGetImportStatus()
        {
            var UserImportAPIFlag = string.IsNullOrEmpty(System.Configuration.ConfigurationManager.AppSettings["UserImportAPIFlag"]) ? true : Convert.ToBoolean(System.Configuration.ConfigurationManager.AppSettings["UserImportAPIFlag"]);
            if (UserImportAPIFlag)
            {
                var isStatusAvailable = true;
                var userSyncService = ResolveAPIDependecies().Resolve<IUserSyncService>();
                UserImportJob JobStatus = userSyncService.GetUserImportStatus(RuntimeContext.Provider.Id);

                var importStatus = new ImportStatusViewModel();
                if (JobStatus == null)
                {
                    isStatusAvailable = false;
                }
                else
                {
                    if (!(JobStatus.Status == UserImportJob.JobStatus.ERR || JobStatus.Status == UserImportJob.JobStatus.ABT))
                    {
                        // check if import jobs have not been updated given the VPS import timeout interval                      
                        var timeoutInterval = userSyncService.GetOrgUserImportTimeout(RuntimeContext.Provider.Id);
                        if (JobStatus.CurrentDBTime > JobStatus.LastUpdateTime.AddMinutes(timeoutInterval))
                        {
                            var timeoutImportResult = userSyncService.UserImportTimeout(JobStatus.JobId);
                            if (timeoutImportResult)
                            {
                                // refresh the import status
                                JobStatus = userSyncService.GetUserImportStatus(RuntimeContext.Provider.Id);
                            }
                        }

                    }
                    if (JobStatus.Status == UserImportJob.JobStatus.ABT)
                    {
                        // if ABT status is greater than 5 minutes, flag status as "Done" to enable import functionality
                        if (JobStatus.CurrentDBTime > JobStatus.LastUpdateTime.AddMinutes(5))
                        {
                            JobStatus.Status = UserImportJob.JobStatus.Don;
                        }
                    }

                    UserImportStatus obj = new UserImportStatus()
                    {
                        ProviderId = JobStatus.ProviderId,
                        Status = (UserImportStatusType)JobStatus.Status,
                        LastUpdateTime = (DateTime)JobStatus.LastUpdateTime,
                        TotalRecords = JobStatus.TotalRecords,
                        ProcessedRecords = JobStatus.ProcessedRecords,
                        SuccessRecords = JobStatus.SuccessRecords,
                        FailedRecords = JobStatus.FailedRecords,
                        PartialRecords = JobStatus.PartialRecords,
                        StartTime = JobStatus.StartTime == null ? default(DateTime) : Convert.ToDateTime(JobStatus.StartTime),
                        EndTime = JobStatus.EndTime == null ? default(DateTime) : Convert.ToDateTime(JobStatus.EndTime)
                    };


                    var operatorName = _userExportImportFacade.GetImportStartUserName(
                         new UserImportDataSpec { ProviderId = RuntimeContext.Provider.Id }
                         );
                    importStatus.AddData(obj, (operatorName == string.Empty) ? IWSResources.User_Unknown : operatorName);
                }
                return Json(new { isStatusAvailable, importStatus });
            }
            else
            {
                return GetImportStatus();
            }


        }



        [IWSAuthorize(new[] { SystemObject.ImportExportUsers }, new[] { ActionType.View })]
        public JsonResult CancelImport()
        {
            var userSyncService = ResolveAPIDependecies().Resolve<IUserSyncService>();
            UserImportJob JobStatus = userSyncService.GetUserImportStatus(RuntimeContext.Provider.Id);

            if (JobStatus != null && (JobStatus.Status == UserImportJob.JobStatus.INP))
            {
                //this will update the status to abort
                var UserImportAbort = userSyncService.AbortUserImport(RuntimeContext.Provider.Id, RuntimeContext.Operator.Id);
                var result = new AtHoc.IWS.Business.Service.ServiceResult<bool>();
                if (!UserImportAbort)
                {
                    result.Messages.Add(new Message()
                    {
                        Type = MessageType.Error,
                        Value = ""
                    });
                }

                if (result.IsValid)
                {
                    var auditSpec = new AuditSpec
                    {
                        Action = ServiceAction.UserCancelImport,
                        ObjectName = RuntimeContext.Provider.ProviderName,
                        ObjectType = EntityType.EndUsers,
                        OperatorId = RuntimeContext.Operator.Id,
                        ProviderId = RuntimeContext.Provider.Id
                    };
                    _operatorAuditFacade.LogAction(auditSpec);

                    return Json(result);
                }
                return Json(result);
            }//if status is already done or error 
            else if (JobStatus != null && (JobStatus.Status == UserImportJob.JobStatus.Don || JobStatus.Status == UserImportJob.JobStatus.ERR))
            {
                var result = new AtHoc.IWS.Business.Service.ServiceResult<bool>();
                return Json(result);
            }
            var dummyResult = new { IsValid = false };
            return Json(dummyResult);
        }

        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.ImportExportUsers }, new[] { ActionType.View })]
        public JsonResult GetDataForExportView(string searchCriteria, bool resetToDefault)
        {
            var currentUser = RuntimeContext.Operator;
            Provider provider = RuntimeContext.Provider;
            var viewModel = new ExportViewModel();

            //Compose Distribution List.Only Static Ones
            IEnumerable<DistributionList> staticDistributionList = _operatorDetailsFacade.GetOperatorDistributionLists(
                new DistributionListSpec
                {
                    ProviderId = provider.Id,
                    OperatorId = currentUser.Id,
                    DistributionListTypes = new[] { ListItemType.Static },
                    IsSystem = false,
                    OrderBy = DistributionList.Meta.Name,
                    Status = UserStatusType.Active,
                    AccessType = AccessType.Manage,
                    ExcludeDeleted = true,
                    IsCascaded = false
                });
            IEnumerable<CustomAttribute> allCustomAttributes = RuntimeContext.CustomAttributesWithouMassDevices;

            if (allCustomAttributes.Any())
                allCustomAttributes = allCustomAttributes.Where(x => x.EntityId == "USER" && (x.CommonName != (!RuntimeContext.Provider.FeatureMatrix.IsEnterpriseManagementSupported ? AttributeCommonNames.Organizations : null)) && (x.CommonName != (!RuntimeContext.Provider.FeatureMatrix.IsEnterpriseManagementSupported ? AttributeCommonNames.PreventUserMove : null)));

            foreach (var distributionList in staticDistributionList)
            {
                var distributionListItems = allCustomAttributes.Where(x => x.Id == Convert.ToInt32(distributionList.Definition)).ToList();
                var distributionListItem = distributionListItems.Any() ? distributionListItems.First() : null;
                if (distributionListItem != null)
                {
                    if (distributionList.IsSystem == "N")
                    {
                        var item = new ExportViewModelItem
                        {
                            Id = Convert.ToInt32(distributionList.Id),
                            CustomAttributeId = distributionListItem.Id,
                            DisplayName = distributionList.Name,
                            EntityType = "DL",
                            IsRemovable = true
                        };

                        viewModel.Available.Add(item);
                    }
                }
            }

            var attributes = allCustomAttributes.Where(
                d =>
                    d.EntityId == "USER" && d.IsSearchable == "Y" && d.AttributeTypeId != CustomAttributeDataType.Memo &&
                    d.AttributeTypeId != CustomAttributeDataType.Path)
                .Select(x => new ExportViewModelItem
                {
                    Id = x.Id,
                    CustomAttributeId = x.Id,
                    DisplayName = x.AttributeName,
                    EntityType = "CF",
                    CommonName = x.CommonName,
                    IsRemovable = true

                }).ToList();


            viewModel.Available.AddRange(attributes.OrderBy(x => x.DisplayName));

            if (RuntimeContext.Provider.FeatureMatrix.IsOrgHierarchySupported)
            {
                IEnumerable<Hierarchy> hierarchies =
                    _userFacade.GetHierarchyBySpec(new HierarchySpec
                    {
                        ProviderId = provider.Id,
                        AvailableForLists = false,
                        HierarchyType = HierarchyType.ORG,
                        Status = UserStatusType.Active,
                        BaseLocale = provider.BaseLocale
                    });

                foreach (Hierarchy h in hierarchies)
                {
                    var heirarchyList = allCustomAttributes.Where(x => x.HierarchyId == h.Id).ToList();
                    var heirarchyItem = heirarchyList.Any() ? heirarchyList.First() : null;
                    if (heirarchyItem != null)
                    {
                        var item = new ExportViewModelItem
                        {
                            Id = h.Id,
                            CommonName = h.CommonName,
                            CustomAttributeId = heirarchyItem.Id,
                            DisplayName = heirarchyItem.AttributeName,
                            EntityType = "ORG",
                            IsRemovable = true
                        };
                        viewModel.Available.Add(item);
                    }
                }
            }

            IEnumerable<Device> devices =
                _deviceFacade.GetDevicesBySpec(new DeviceSpec
                {
                    IsMassDevice = false,
                    ProviderId = provider.Id,
                    EnabledOnly = true,
                    OrderBy = Device.Meta.Name
                }, RuntimeContext.Provider.BaseLocale);

            foreach (var device in devices)
            {
                var item = new ExportViewModelItem
                {
                    Id = device.Id,
                    CustomAttributeId = device.Id,
                    DisplayName = device.Name,
                    CommonName = device.CommonName,
                    EntityType = "Device",
                    IsRemovable = true
                };
                viewModel.Available.Add(item);
            }

            if (resetToDefault)
            {
                IEnumerable<CustomView> customViews = _customAttributeFacade.GetUserCustomViewsBySpec(
                    new CustomViewSpec
                    {
                        ProviderId = provider.Id,
                        OperatorId = RuntimeContext.Operator.Id,
                        IsPlaceholder = false,
                        IncludeCustomAttribute = false,
                        CustomViewColumnTypes = new[] { CustomViewColumnType.CustomField, CustomViewColumnType.Device, CustomViewColumnType.OrgName },
                        CustomViewType = CustomViewType.UserManagerV2
                    });
                IEnumerable<ExportViewModelItem> standardItems = allCustomAttributes.Where(
                    x =>
                        String.Compare(x.CommonName, AttributeCommonNames.UserName, StringComparison.OrdinalIgnoreCase) ==
                        0)
                    .Select(y => new ExportViewModelItem
                    {
                        Id = y.Id,
                        CustomAttributeId = y.Id,
                        DisplayName = y.AttributeName,
                        EntityType = "CF",
                        CommonName = y.CommonName,
                        IsRemovable = false
                    });
                viewModel.Existing.AddRange(standardItems);





                foreach (var field in customViews)
                {
                    if (field.Columnid == CustomViewColumnType.CustomField)
                    {
                        viewModel.Existing.Add(
                            allCustomAttributes
                                 .Where(y => y.Id == field.EntityId && y.AttributeTypeId != CustomAttributeDataType.Memo)
                                .Select(p => new ExportViewModelItem
                                {
                                    Id = p.Id,
                                    CustomAttributeId = p.Id,
                                    DisplayName = p.AttributeName,
                                    EntityType = "CF",
                                    CommonName = p.CommonName,
                                    IsRemovable = true

                                }
                                ).SingleOrDefault());
                    }

                    if (field.Columnid == CustomViewColumnType.Device)
                    {
                        viewModel.Existing.Add(
                            devices
                                .Where(y => y.Id == field.EntityId)
                                .Select(p => new ExportViewModelItem
                                {
                                    Id = p.Id,
                                    CustomAttributeId = p.Id,
                                    DisplayName = p.Name,
                                    EntityType = "Device",
                                    CommonName = p.CommonName,
                                    IsRemovable = true

                                }
                                ).SingleOrDefault());

                    }
                }
            }

            int userCount = GetOrganizationUserCount(searchCriteria, true);

            return (Json(new { viewModel, userCount }));
        }

        #region Export users flow should always contain organization filter to show only current vps users count (87 CP1 Fix only, will support export of all users across the enterprise in next release)

        private int GetOrganizationUserCount(string searchCriteria, bool includeSubVps = false)
        {
            var usersStatusCriteria = new JavaScriptSerializer().Deserialize<UsersStatusCriteria>(searchCriteria);

            UserSearchArgs srchArgs = _userManagerHelper.ConvertToSearchArgs(usersStatusCriteria, false);
            srchArgs.Options.GetCountsOnly = true;
            // Overiding the existing provider criteria since export users should only target current provider
            srchArgs.ProviderCriteria = UserSearchHelper.GetProviderCriteria(RuntimeContext.ProviderId, includeSubVps);

            if (usersStatusCriteria.CriteriaType == (int)ListCriteriaType.USER_LIST)
            {
                var userCriteria = UserSearchHelper.GetIndividualUserIdCriteria(usersStatusCriteria.EntityIds);
                srchArgs.TargetCriteria = userCriteria;
            }

            if (usersStatusCriteria.CriteriaType == (int)ListCriteriaType.EXCEPTION_LIST)
            {
                var userCriteria = UserSearchHelper.GetIndividualUserIdCriteria(usersStatusCriteria.EntityIds);
                srchArgs.BlockCriteria = userCriteria;
            }

            var users = _userFacade.SearchUsersByContext(srchArgs);
            return users.SearchResultCount;
        }



        #endregion


        #endregion

        [HttpPost]
        public ActionResult PasswordValidate(int userid, string password)
        {
            return Json(
                _operatorFacade.ValidateUserPassword(
                    new ValidatePasswordSpec(userid, password))
            );
        }

        [HttpPost]
        public ActionResult PasswordMatch(int userid, string password)
        {
            return Json(
                _operatorFacade.PasswordMatch(
                    new ValidatePasswordSpec(userid, password))
                );
        }

        [HttpPost]
        public JsonResult ValidatePassword(string password)
        {
            return Json(UserHelper.VerifyPasswordComplexity(password, RuntimeContext.ProviderId));
        }

        private CustomAttributeLookup _providerAttributes;

        /// <summary>
        ///  Returns list of localized custom attributes
        /// </summary>
        private CustomAttributeLookup ProviderAttributes
        {
            get
            {
                var customAttributes = RuntimeContext.CustomAttributesWithouMassDevices.Where(x => x.EntityId == "USER").ToArray();
                return new CustomAttributeLookup(customAttributes);
            }
        }

        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.Alert }, new[] { ActionType.View })]
        public ActionResult SaveReportCustomView(int viewId, int id, string action, string type, string commonName = "")
        {
            var placholderCommonName = string.Empty;

            var customViewColumnType = (type.ToLowerInvariant() != "device")
                ? CustomViewColumnType.CustomField
                : CustomViewColumnType.Device;

            switch (commonName)
            {
                case CommonNames.OperatorRoles:
                    placholderCommonName = CommonNames.OperatorRoles;
                    customViewColumnType = CustomViewColumnType.Role;
                    break;
                case CommonNames.Organizations:
                    placholderCommonName = CommonNames.Organizations;
                    customViewColumnType = CustomViewColumnType.OrgName;
                    break;
            }

            _userManagerHelper.RefreshDevices(ref _allDevices, ref _devicesByCommonName, ref _devicesByName, true);
            var messages = _customAttributeFacade.SaveCustomView(
                new SaveCustomViewSpec
                {
                    Id = id,
                    SequenceNo = null,
                    ViewId = viewId,
                    Action = action,
                    ColumnType = customViewColumnType,
                    AllDevices = _allDevices,
                    ViewType = CustomViewType.UserReport,
                    ProviderAttributes = ProviderAttributes,
                    ProviderId = RuntimeContext.Provider.Id,
                    OperatorId = RuntimeContext.Operator.Id,
                    //if the commonName is 'OPERATOR-ROLES'
                    //For now we are sending ColumnKeyName which is optional to differentiate 'OPERATOR-ROLES' at the facade as its neither a device nor CustomField
                    ColumnKeyName = placholderCommonName
                });
            return Json(new Result<bool>(messages.NoErrors(), messages));
        }

        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.Alert }, new[] { ActionType.View })]
        public ActionResult ResetToReportDefaultView(string viewType)
        {
            var messages = new Messages();

            _customAttributeFacade.RemoveCustomView(new CustomViewSpec
            {
                ProviderId = RuntimeContext.Provider.Id,
                OperatorId = RuntimeContext.Operator.Id,
                CustomViewType = (CustomViewType)Enum.Parse(typeof(CustomViewType), viewType),
                IsPlaceholder = false,
            });

            return Json(new Result<bool>(messages.NoErrors(), messages));
        }

        private UnityContainer ResolveAPIDependecies()
        {
            UnityContainer container = new UnityContainer();
            //Configure the container (register)
            container.RegisterInstance<IDbConnection>(new SqlConnection(_configurations.NgaddataConnStr), new ContainerControlledLifetimeManager());
            //Business layer resolver
            container.RegisterType<IUserSyncManager, UserSyncManager>();
            //Service layer resolver
            container.RegisterType<IUserSyncService, UserSyncService>();
            //Data access layer resolver
            container.RegisterType<IGlobalRepository, GlobalRepository>();
            container.RegisterType<IOrgRepository, OrgRepository>();
            container.RegisterType<AtHoc.IWS.Interfaces.DataAccess.Users.IUserRepository, UserRepository>();
            container.RegisterType<AtHoc.IWS.Interfaces.DataAccess.Users.IUserSyncRepository, UserSyncRepository>();
            container.RegisterType<AtHoc.IWS.Interfaces.DataAccess.Users.IUserSearchRepository, UserSearchRepository>();
            container.RegisterType<IAttributeRepository, AttributeRepository>();
            container.RegisterType<AtHoc.IWS.Interfaces.DataAccess.Devices.IDeviceRepository, DeviceRepository>();
            container.RegisterType<IUserRolesRepository, UserRolesRepository>();
            return container;
        }


        [HttpGet]
        public ActionResult GetUserMoveDetails(string moveUsersCriteria)
        {
            var provider = RuntimeContext.Provider;
            var providerDictionary = _providerFacade.GetEnterpriseProviderList(provider.Id);
            var providerList = providerDictionary.Select(v => new SelectListItem { Text = v.Value, Value = v.Key.ToString() })
                    .ToList();
            return Json(new { providerList = providerList, userCount = GetPreventUserMoveCount(moveUsersCriteria, true) }, JsonRequestBehavior.AllowGet);

        }

        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.EndUsers }, new[] { ActionType.Modify })]
        public ActionResult MoveUsers(UsersStatusCriteria moveUsersCriteria, string OrgName, bool unLockUsers, bool lockUsers)
        {
            var messages = new Messages();
            var allUserNames = new List<string>();
            try
            {

                var isCurrentOperatorMoved = false;
                var users =
                    _userManagerHelper.GetSelectedUsernames(moveUsersCriteria, _devicesByName).Select(
                                         p =>
                                             new
                                             {
                                                 PreventUserMove = p.UserAttributes.Where(y => y.Key == AttributeCommonNames.PreventUserMove).Select(z => z.Value).FirstOrDefault(),
                                                 Username = p.UserName
                                             }).ToList();


                if (users.HasValue())
                    isCurrentOperatorMoved = users.Any(x => x.Username == RuntimeContext.Operator.Username);

                var localizedYes = _globalEntityLocaleFacade.GetLocalizedValue("Yes", BusinessEntity.CheckBox, "Name", RuntimeContext.Provider.BaseLocale);

                // Unprevent users from move
                if (unLockUsers && users.Any())
                {
                    var userNames = users.Where(x => string.Equals(x.PreventUserMove.ToLower(), localizedYes, StringComparison.CurrentCultureIgnoreCase)).Select(x => x.Username).ToList();
                    if (userNames.Any())
                    {
                        var resultDataTable = PreventUsersMove(userNames, false);
                        allUserNames =
                            resultDataTable.Value.AsEnumerable()
                                .Where(w => ((string)w[":SyncStatus"]).ToUpper() == "OK")
                                .Select(x => x["LOGIN_ID"].ToString())
                                .ToList();

                    }
                    allUserNames.AddRange(users.Where(x => !string.Equals(x.PreventUserMove.ToLower(), localizedYes, StringComparison.CurrentCultureIgnoreCase)).Select(x => x.Username).ToList());
                }
                else
                {
                    allUserNames = users.Where(x => !string.Equals(x.PreventUserMove.ToLower(), localizedYes, StringComparison.CurrentCultureIgnoreCase)).Select(x => x.Username).ToList();
                }



                if (allUserNames.Any())
                    messages = PerformUsersMove(allUserNames, RuntimeContext.Provider.Id, RuntimeContext.Operator.Id, OrgName, RuntimeContext.Provider.BaseLocale);
                // Prevent users from move
                if (lockUsers && allUserNames.Any())
                {
                    var resultDataTable = PreventUsersMove(allUserNames, true);

                    var errorMessages = new List<string>();
                    errorMessages.AddRange(resultDataTable.Errors);
                    if (resultDataTable.Errors.Count > 0)
                    {
                        errorMessages = resultDataTable.Value.Rows[0][":SyncDetails"].ToString().TrimEnd(',').Split(',').ToList();

                        foreach (string error in errorMessages)
                        {
                            messages.Add(new Message { Type = MessageType.Error, Value = error, Sender = typeof(UserManagerController) });
                        }
                    }
                }

                return Json(new { Sucess = true, Messages = messages, IsCurrentOperatorMoved = isCurrentOperatorMoved });
            }
            catch (Exception ex)
            {
                var auditSpec = new AuditSpec(RuntimeContext.Operator.Id, RuntimeContext.Provider.Id)
                {
                    Action = ServiceAction.UserMovingFailed,
                    ObjectName = string.Format(IWSResources.UserManage_UsersMove_Failed, string.Empty, OrgName),
                    ObjectType = EntityType.EndUsers
                };
                _userFacade.LogMoveAction(auditSpec);
                messages.Add(new Message { Value = ex.Message, Type = MessageType.Error, Sender = typeof(UserManagerController) });
                return Json(new { Sucess = false, IsCurrentOperatorMoved = false, Messages = messages, });
            }
        }

        private ServiceResult<DataTable> PreventUsersMove(IEnumerable<string> userNames, bool lockUser)
        {
            var userSyncService = ResolveAPIDependecies().Resolve<IUserSyncService>();
            var dtMoveUsers = new DataTable();
            dtMoveUsers.Columns.Add("LOGIN_ID", typeof(string));
            dtMoveUsers.Columns.Add(AttributeCommonNames.PreventUserMove, typeof(string));

            var dtResult = userNames.Select(
               p =>
               {
                   var newRow = dtMoveUsers.NewRow();
                   newRow["LOGIN_ID"] = p;
                   newRow[AttributeCommonNames.PreventUserMove] = lockUser ? "YES" : "";
                   return newRow;
               }).CopyToDataTable();

            // This call has be changed when UserAPI has ready with this method
            var resultDataTable = userSyncService.SyncByCommonNames(RuntimeContext.ProviderId, RuntimeContext.Provider.BaseLocale, true, dtResult);
            return resultDataTable;
        }


        private Messages PerformUsersMove(IEnumerable<string> userNames, int providerId, int operatorId, string orgName, string baseLocale)
        {
            var messages = new Messages();
            var userSyncService = ResolveAPIDependecies().Resolve<IUserSyncService>();
            var dtMoveUsers = new DataTable();
            dtMoveUsers.Columns.Add("LOGIN_ID", typeof(string));
            dtMoveUsers.Columns.Add("ORGANIZATIONS", typeof(string));

            var dtResult = userNames.Select(
               p =>
               {
                   var newRow = dtMoveUsers.NewRow();
                   newRow["LOGIN_ID"] = p;
                   newRow["ORGANIZATIONS"] = orgName;
                   return newRow;
               }).CopyToDataTable();


            // This call has be changed when UserAPI has ready with this method
            var resultDataTable = userSyncService.SyncByCommonNames(providerId, baseLocale, true, dtResult);

            var userMovedCount = resultDataTable.Value.AsEnumerable().Count(w => ((string)w[":SyncStatus"]).ToUpper() == "OK");

            if (userMovedCount > 0)
            {
                var auditSpec = new AuditSpec(operatorId, providerId)
                {
                    Action = ServiceAction.EndUsersMoved,
                    ObjectType = EntityType.EndUsers,
                    ObjectName = string.Format(IWSResources.UserManage_UsersMove_Success, userMovedCount, orgName)
                };
                _userFacade.LogMoveAction(auditSpec);

            }

            var userMovedFailedCount = resultDataTable.Value.AsEnumerable().Count(w => ((string)w[":SyncStatus"]).ToUpper() == "ERROR");
            if (userMovedFailedCount > 0)
            {
                var auditSpec = new AuditSpec(operatorId, providerId)
                {
                    Action = ServiceAction.UserMovingFailed,
                    ObjectType = EntityType.EndUsers,
                    ObjectName = string.Format(IWSResources.UserManage_UsersMove_Failed, userMovedFailedCount, orgName)
                };
                _userFacade.LogMoveAction(auditSpec);
                messages.Add(new Message { Type = MessageType.Error, Value = string.Format(IWSResources.UserManage_UsersMove_Failed, userMovedFailedCount, orgName), Sender = typeof(UserManagerController) });
            }

            var errorMessages = new List<string>();
            errorMessages.AddRange(resultDataTable.Errors);
            if (resultDataTable.Errors.Count > 0)
            {
                errorMessages = resultDataTable.Value.Rows[0][":SyncDetails"].ToString().TrimEnd(',').Split(',').ToList();

                foreach (string error in errorMessages)
                {
                    messages.Add(new Message { Type = MessageType.Error, Value = error, Sender = typeof(UserManagerController) });
                }
            }
            return messages;
        }

        private int GetPreventUserMoveCount(string searchCriteria, bool includeSubVps = false)
        {
            var usersStatusCriteria = new JavaScriptSerializer().Deserialize<UsersStatusCriteria>(searchCriteria);

            var preventUserMove = ProviderAttributes.GetByCommonName(AttributeCommonNames.PreventUserMove);
            var preventUserMoveValueId = preventUserMove.Values.Where(x => x.CommonName.ToUpper() == "YES").Select(y => y.ValueId).FirstOrDefault();

            UserSearchArgs srchArgs = _userManagerHelper.ConvertToSearchArgs(usersStatusCriteria, false);
            srchArgs.Options.GetCountsOnly = true;
            if (usersStatusCriteria.CriteriaType == (int)ListCriteriaType.USER_LIST)
            {
                var userCriteria = UserSearchHelper.GetIndividualUserIdCriteria(usersStatusCriteria.EntityIds);
                srchArgs.TargetCriteria = userCriteria;
            }

            if (usersStatusCriteria.CriteriaType == (int)ListCriteriaType.EXCEPTION_LIST)
            {
                var userCriteria = UserSearchHelper.GetIndividualUserIdCriteria(usersStatusCriteria.EntityIds);
                srchArgs.BlockCriteria = userCriteria;
            }

            srchArgs.TargetCriteria = srchArgs.TargetCriteria & UserSearchHelper.GetCustomCriteria(new[] { new List<GenericCriteria> { new AttributeCriteria(preventUserMove.Id, CriteriaOperator.Equals, preventUserMoveValueId) } });

            var users = _userFacade.SearchUsersByContext(srchArgs);
            return users.SearchResultCount;
        }
    }
}