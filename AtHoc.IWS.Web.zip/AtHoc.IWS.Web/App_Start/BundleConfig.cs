﻿using System;
using System.Configuration;
using System.Web.Optimization;

namespace AtHoc.IWS.Web
{
    public class BundleConfig
    {

        public static void RegisterBundles(BundleCollection bundles)
        {

            #region "Script Bundle Files Declaration"

            var cndUrl = "../athoc-cdn";
            //var cndUrl = ConfigService.Current.CdnBaseUrl;
            var athocScripts = new[]
            {
                "~/" + cndUrl + "/Scripts/Athoc/athoc.xbrowser.js", 
                "~/Scripts/athoc.iws.layout.common.min.js",
                "~/" + cndUrl + "/Scripts/Athoc/athoc.global.js", 
                "~/" + cndUrl + "/Scripts/lib/athoc.iws.utilities.js"
            };

            var usermanagerScripts = new[]
        { 
            "~/" + cndUrl + "/Scripts/app/ajaxGlobal.js",
            "~/" + cndUrl + "/Scripts/lib-vendor/perfect-scrollbar-0.4.3.with-mousewheel.min.js",
            "~/" + cndUrl + "/Scripts/lib/ajax-loader.js",
            "~/" + cndUrl + "/Scripts/lib/list-grid.js",
            "~/" + cndUrl + "/Scripts/lib/grid-selectall.js",
            "~/" + cndUrl + "/Scripts/lib/usersearch.js",
            "~/" + cndUrl + "/Scripts/lib/groupselector.js", 
            "~/" + cndUrl + "/Scripts/lib/grouptreeselector.js",
            "~/" + cndUrl + "/Scripts/lib/querybuilder.js",
            "~/" + cndUrl + "/Scripts/app/athoc.iws.queryBuilderExtensions.js",
            "~/" + cndUrl + "/Scripts/app/viewmodels/athoc.iws.querycriteria.js",
            "~/" + cndUrl + "/Scripts/app/viewmodels/athoc.iws.userlist.js",
            "~/" + cndUrl + "/Scripts/app/viewmodels/athoc.iws.userdetails.js",
            "~/" + cndUrl + "/Scripts/app/viewmodels/athoc.iws.operator.js",
            "~/" + cndUrl + "/Scripts/app/viewmodels/athoc.iws.relativedatepicker.js",
            "~/" + cndUrl + "/Scripts/lib/entity-selector-popup.js",
            "~/" + cndUrl + "/Scripts/lib/knockout-grid.js",
            "~/" + cndUrl + "/Scripts/lib-vendor/OpenLayers/OpenLayers.js",
            "~/" + cndUrl + "/Scripts/lib/progress-indicator.js",
            "~/" + cndUrl + "/Scripts/app/pageassemblers/athoc.iws.activityfeed.js",
            "~/" + cndUrl + "/Scripts/app/services/dataservice.js",
            "~/" + cndUrl + "/Scripts/app/services/dataservice.user.js",
            "~/" + cndUrl + "/Scripts/app/viewmodels/athoc.iws.userexport.js",
            "~/" + cndUrl + "/Scripts/app/viewmodels/athoc.iws.userimport.js",
            "~/" + cndUrl + "/Scripts/app/viewmodels/athoc.iws.activityfeedmodel.js",
            "~/" + cndUrl + "/Scripts/app/services/dataservice.activityfeed.js"
        };

            var distributionListScripts = new[]
        {
            "~/" + cndUrl + "/Scripts/app/ajaxGlobal.js",
            "~/" + cndUrl + "/Scripts/lib-vendor/jquery.iframe-transport.js",
            "~/" + cndUrl + "/Scripts/app/services/dataservice.js",
            "~/" + cndUrl + "/Scripts/app/services/dataservice.user.js",
            "~/" + cndUrl + "/Scripts/app/pageassemblers/athoc.iws.activityfeed.js",
            "~/" + cndUrl + "/Scripts/lib/list-grid.js",
            "~/" + cndUrl + "/Scripts/lib/usersearch.js",
            "~/" + cndUrl + "/Scripts/lib/groupselector.js",
            "~/" + cndUrl + "/Scripts/lib/grouptreeselector.js",
            "~/" + cndUrl + "/Scripts/lib/grid-selectall.js",
            "~/" + cndUrl + "/Scripts/lib/ko-grid-selectall.js",
            "~/" + cndUrl + "/Scripts/lib/ajax-loader.js",
            "~/" + cndUrl + "/Scripts/lib/querybuilder.js", 
            "~/" + cndUrl + "/Scripts/app/athoc.iws.queryBuilderExtensions.js",
            "~/" + cndUrl + "/Scripts/app/viewmodels/athoc.iws.querycriteria.js",
            "~/" + cndUrl + "/Scripts/app/viewmodels/athoc.iws.relativedatepicker.js",
            "~/" + cndUrl + "/Scripts/lib/entity-selector-popup.js",
            "~/" + cndUrl + "/Scripts/lib/knockout-grid.js",
            "~/" + cndUrl + "/Scripts/lib-vendor/jquery.fileupload.js",
            "~/" + cndUrl + "/Scripts/lib-vendor/jquery.simulate.js",
            "~/" + cndUrl + "/Scripts/app/pageassemblers/athoc.iws.distributionlist.js",
            "~/" + cndUrl + "/Scripts/app/pageassemblers/athoc.iws.distributionlist.list.js",
            "~/" + cndUrl + "/Scripts/app/pageassemblers/athoc.iws.distributionlist.detail.js",
            "~/" + cndUrl + "/Scripts/app/viewmodels/athoc.iws.userlist.js"
        };
            var settingsScripts = new[]
            {
              
               "~/Scripts/settings/athoc.iws.audiofilemanager.js",
             
               "~/Scripts/settings/athoc.iws.deliverytemplate.js",
               "~/Scripts/settings/athoc.iws.disabledeleteendusers.js",
               "~/Scripts/settings/athoc.iws.channelmanager.js",
               "~/Scripts/settings/athoc.iws.generalsettings.js",
               "~/Scripts/settings/athoc.iws.hierarchydefinition.js",
               "~/Scripts/settings/athoc.iws.integrationmanager.js",
               "~/Scripts/settings/athoc.iws.operatorAuditTrail.js",
               "~/Scripts/settings/athoc.iws.organizationManager.js",
               "~/Scripts/settings/athoc.iws.organizationsettings.js",
               "~/Scripts/settings/athoc.iws.rule.js",
               "~/Scripts/settings/athoc.iws.securitypolicy.js",
               "~/Scripts/settings/athoc.iws.subaccountmanager.js",
               "~/Scripts/settings/athoc.iws.systemsettings.js",
               "~/Scripts/settings/athoc.iws.TargetingSettings.js",
               "~/Scripts/settings/athoc.iws.weatherModule.js",
               "~/Scripts/settings/jquery.jeditable.js",
               "~/Scripts/Settings/FileSaver.js"
              };

            var fileUploadScripts = new[]
            {
                    "~/" + cndUrl + "/Scripts/lib-vendor/jquery.filedownload.js",
                    "~/" + cndUrl + "/Scripts/lib-vendor/jquery.iframe-transport.js",
                    "~/" + cndUrl + "/Scripts/lib-vendor/jquery.fileupload.js",
                    "~/" + cndUrl + "/Scripts/lib-vendor/jquery.simulate.js"
            };

            var koScripts = new[]
            {
                "~/" + cndUrl + "/Scripts/lib-vendor/knockout-3.3.0.js",
                "~/" + cndUrl + "/Scripts/lib-vendor/knockout.validation.js",
                "~/" + cndUrl + "/Scripts/lib-vendor/knockout.mapping.js"
            };
            var jqueryScripts = new[]
            {
                "~/" + cndUrl + "/Scripts/lib-vendor/jquery-1.10.2.js",
                "~/" + cndUrl + "/Scripts/lib-vendor/jquery-ui-1.10.3.custom.min.js",
                "~/" + cndUrl + "/Scripts/lib-vendor/jquery.blockUI.js",
                "~/" + cndUrl + "/Scripts/lib-vendor/jquery.slimscroll.js",
                "~/" + cndUrl + "/Scripts/lib-vendor/jquery.tagsinput.js",
                "~/" + cndUrl + "/Scripts/lib-vendor/jquery.placeholder.js"
            };
            // Not in Use
            var bootstrap = new[]
            {
                "~/" + cndUrl + "/Scripts/lib-vendor/underscore.js",
                "~/" + cndUrl + "/Scripts/lib-vendor/bootstrap.js",
                 "~/" + cndUrl + "/Scripts/lib/bootstrap-select-athoc.js",
                "~/" + cndUrl + "/Scripts/lib/knockout-selectpicker.js",
                "~/" + cndUrl + "/Scripts/lib-vendor/bootstrap-multiselect.js",
                "~/" + cndUrl + "/Scripts/lib-vendor/bootstrap-datetimepicker.js",
                "~/" + cndUrl + "/Scripts/app/jsbootstrap.min.js"
            };
            var dojoScripts = new[]
               {"~/" + cndUrl + "/Scripts/app/dojoConfig.js",
                    "~/" + cndUrl + "/Scripts/lib-vendor/esri/javascript/init.js"};

            var publishingScripts = new[]
            {       
                "~/Scripts/Publishing/athoc.iws.scenario.publisher.js",
                "~/Scripts/Publishing/athoc.iws.publishing.js",
                    "~/Scripts/Publishing/athoc.iws.publishing.detail.js",
                    "~/Scripts/Publishing/athoc.iws.publishing.scenario.js",
                    "~/Scripts/Publishing/athoc.iws.publishing.content.js",
                    "~/Scripts/Publishing/athoc.iws.publishing.iut.js",
                    "~/Scripts/Publishing/athoc.iws.publishing.fillcount.js",
                    "~/Scripts/Publishing/athoc.iws.publishing.targetOrg.js",
                    "~/Scripts/Publishing/athoc.iws.publishing.targetUsers.js",
                    "~/Scripts/Publishing/athoc.iws.publishing.targetGroup.js",
                    "~/Scripts/Publishing/athoc.iws.publishing.view.js",
                    "~/Scripts/Publishing/athoc.iws.publishing.deviceOptions.js",
                    "~/Scripts/Publishing/athoc.iws.publishing.massDevices.js",
                    "~/Scripts/Publishing/athoc.iws.alert.reviewandpublish.js",
                    "~/Scripts/Publishing/athoc.iws.alert.schedule.js",
                    "~/Scripts/Publishing/athoc.iws.publishing.geo.js",
                    "~/Scripts/Publishing/athoc.iws.alert.report.js"
            };
            var layoutScripts = new[]
            {
               "~/" + cndUrl + "/Scripts/lib-vendor/jquery-1.10.2.js",
               "~/" + cndUrl + "/Scripts/lib-vendor/jquery-ui-1.10.3.js",
               "~/" + cndUrl + "/Scripts/lib-vendor/underscore.js",
               "~/" + cndUrl + "/Scripts/lib-vendor/knockout-3.3.0.js",
               "~/" + cndUrl + "/Scripts/lib-vendor/knockout.validation.js",
               "~/" + cndUrl + "/Scripts/lib-vendor/knockout.mapping.js",
               "~/" + cndUrl + "/Scripts/lib-vendor/jquery.slimscroll.js",
               "~/" + cndUrl + "/Scripts/lib-vendor/jquery.tagsinput.js",
               "~/" + cndUrl + "/Scripts/lib-vendor/jquery.placeholder.js",
               "~/" + cndUrl + "/Scripts/lib/application.js",
               "~/" + cndUrl + "/Scripts/lib-vendor/jquery.blockUI.js",
               "~/" + cndUrl + "/Scripts/lib-vendor/moment.js",
               "~/" + cndUrl + "/Scripts/lib-vendor/numeral.min.js",
               "~/" + cndUrl + "/Scripts/lib/shared-layout.js",
               "~/" + cndUrl + "/Scripts/lib/format-data.js",
               "~/" + cndUrl + "/Scripts/lib/bootstrap-select-athoc.js",
               "~/" + cndUrl + "/Scripts/lib/knockout-selectpicker.js",
               "~/" + cndUrl + "/Scripts/app/athoc.iws.constants.js",
               "~/" + cndUrl + "/Scripts/app/athoc.iws.utils.browser.js",
               "~/" + cndUrl + "/Scripts/lib/helper.js",
               "~/" + cndUrl + "/Scripts/lib-vendor/bootstrap-multiselect.js",
               "~/" + cndUrl + "/Scripts/lib-vendor/bootstrap-datetimepicker.js",
               "~/" + cndUrl + "/Scripts/lib-vendor/bootstrap.js",
               "~/" + cndUrl + "/Scripts/lib/TimeOut.js"
               
            };

            var kendoScripts = new[]
            {
                "~/" + cndUrl + "/Scripts/lib-vendor/kendo/jquery.min.js",
                "~/" + cndUrl + "/Scripts/lib-vendor/kendo/kendo.all.min.js",
                "~/" + cndUrl + "/Scripts/lib-vendor/kendo/cultures/kendo.culture.ar.min.js",
                "~/" + cndUrl + "/Scripts/lib/athoc.kendoGrid.utils.min.js"
            };

            var commonScripts = new[]
            {
                "~/" + cndUrl + "/Scripts/lib/ajax-loader.js",
                "~/" + cndUrl + "/Scripts/lib/ExtensionToolbox.js",
                "~/" + cndUrl + "/Scripts/lib-vendor/bootstrap-multiselect.js",
                "~/" + cndUrl + "/Scripts/app/services/dataservice.js",
                "~/" + cndUrl + "/Scripts/lib/querybuilder.js",
                "~/" + cndUrl + "/Scripts/app/viewmodels/athoc.iws.querycriteria.js",
                "~/" + cndUrl + "/Scripts/app/athoc.iws.queryBuilderExtensions.js",
                "~/" + cndUrl + "/Scripts/lib/entity-selector-popup.js",
                "~/" + cndUrl + "/Scripts/lib/groupselector.js",
                "~/" + cndUrl + "/Scripts/lib/grouptreeselector.js",
            };

            var alertListScripts = new[]
            {
               
                "~/Scripts/Publishing/athoc.iws.publishing.geo.js",
                "~/Scripts/Publishing/athoc.iws.alert.js",
                "~/Scripts/Publishing/athoc.iws.alert.list.js",
                "~/Scripts/Publishing/athoc.iws.alert.detail.js",
                "~/Scripts/Publishing/athoc.iws.alert.schedule.js",
                "~/Scripts/Publishing/athoc.iws.alert.test.js",
                "~/Scripts/Publishing/athoc.iws.alert.print.js"
            };

            // Not in Use
            var kendoAlertScripts = new[]
            {
                "~/" + cndUrl + "/Scripts/lib-vendor/kendo/kendo.alertlist-custom.min.js",
                "~/" + cndUrl + "/Scripts/lib/athoc.kendoGrid.utils.min.js",
                "~/" + cndUrl + "/Scripts/lib-vendor/kendo/kendo.panelbar.min.js"
            };
            var scenarioScripts = new[]
            {  "~/Scripts/Publishing/athoc.iws.scenario.js",
                "~/Scripts/Publishing/athoc.iws.scenario.list.js",
                "~/Scripts/Publishing/athoc.iws.scenario.detail.js",
                "~/Scripts/Publishing/athoc.iws.scenario.settings.js",
                "~/Scripts/Publishing/athoc.iws.scenario.schedule.js"
            };
            var placeholderScripts = new[]
            {
                "~/Scripts/Settings/athoc.iws.Placeholder.js",
                "~/Scripts/Settings/athoc.iws.Placeholder.Details.js",
                "~/Scripts/Settings/athoc.iws.Placeholder.list.js"
            };

            var userattributeScripts = new[]
            {
                "~/Scripts/UserAttributes/athoc.iws.userattribute.js",
                "~/Scripts/UserAttributes/athoc.iws.userattribute.list.js",
                "~/Scripts/UserAttributes/athoc.iws.userattribute.details.js",
                "~/Scripts/settings/jquery.jeditable.js"
            };

            #endregion "Script Bundle Files Declaration"

            #region "Style Bundle File Declaration"

            var customStyles = new[]
        {
            "~/" + cndUrl + "/Content/css/publishing-custom.css",
            "~/" + cndUrl + "/Content/css/print-custom.css",
            "~/" + cndUrl + "/Content/css/location-map.css",
            "~/" + cndUrl + "/Content/css/forms.css",
            "~/" + cndUrl + "/Content/css/intlTelInput.min.css"
        };

            var layoutStyles = new[]
        {
            "~/" + cndUrl + "/Content/css/global.css",
            "~/" + cndUrl + "/Content/css/tables.css",
            "~/" + cndUrl + "/Content/css/flags.css",
            "~/" + cndUrl + "/Content/css/msg.css",
            "~/" + cndUrl + "/Content/css/badges.css",
            "~/" + cndUrl + "/Content/css/advanced.css",
            "~/" + cndUrl + "/Content/css/forms.css",
        };



            var mapStyles = new[]
        {
            "~/" + cndUrl + "/Content/css/location-map.css",
           "~/" + cndUrl + "/Content/css/publishermap.css"
        };
            var publishingStyles = new[]
        {
           "~/" + cndUrl + "/Content/css/alertscenarios.css",
           
        };

            var homeStyles = new[]
        {
            "~/" + cndUrl + "/Content/css/homepage-body.css",
            "~/" + cndUrl + "/Content/css/athoc.iws.home.css"
        };

            var kendoStyles = new[]
        {
            "~/" + cndUrl + "/Content/css-vendor/kendo.dataviz.default.min.css",
            "~/" + cndUrl + "/Content/css-vendor/kendo.dataviz.min.css",
            "~/" + cndUrl + "/Content/css-vendor/kendo.dataviz.uniform.min.css",
            "~/" + cndUrl + "/Content/css-vendor/kendo.default.min.css",
            "~/" + cndUrl + "/Content/css-vendor/kendo.common.min.css",
            "~/" + cndUrl + "/Content/css-vendor/kendo.rtl.min.css",
             "~/" + cndUrl + "/Content/css-vendor/kendo.uniform.min.css",
           
            
        };



            var bootStrapStyles = new[]
        {
            "~/" + cndUrl + "/Scripts/lib-vendor/OpenLayers/theme/default/style.css",
            "~/" + cndUrl + "/Content/css-vendor/bootstrap.css",
            "~/" + cndUrl + "/Content/css-vendor/bootstrap-datetimepicker.min.css",
            "~/" + cndUrl + "/Content/css-vendor/bootstrap-multiselect.css",
            "~/" + cndUrl + "/Content/css-vendor/bootstrap-select.css"
        };

            #endregion "Style Bundle File Declaration"

            #region "Script Bundle "
            bundles.UseCdn = true;

            //   var cdnUrl = ConfigService.Current.CdnBaseUrl;
            /* ================================================================
                  1) Require JS Scripts [Bundle name : require-scripts-bundle]
               ================================================================ */

            bundles.Add(new ScriptBundle("~/bundles/requirejs")
                .Include("~/" + cndUrl + "/scripts/lib-vendor/require-2.1.14.js")
                );
            bundles.Add(new ScriptBundle("~/bundles/requirejs_config")
                .Include("~/" + cndUrl + "/scripts/app/requireJsConfig.js"));

            /* ==========================================================================================================================
                  2) LayoutScripts it contains all common scripts including athoc customized scripts  [Bundle name : layout-scripts-bundle]
               =========================================================================================================================== */

            bundles.Add(new ScriptBundle("~/bundles/layout-scripts-bundle")
             .Include(jqueryScripts)
                .Include(fileUploadScripts)
                .Include(layoutScripts)

                );

            /*  =============================================================================
                  3) KendoScripts Kendo controls scripts  [Bundle name : kendo-scripts-bundle] -Not in Use
                ============================================================================== */


            bundles.Add(new ScriptBundle("~/bundles/kendo-scripts-bundle")
                .Include(kendoScripts)
                );

            /*  ====================================================================
                 4) AtHoc customized scripts [Bundle name : athoc-scripts-bundle]
                ===================================================================== */

            bundles.Add(new ScriptBundle("~/bundles/athoc-scripts-bundle")
                .Include(commonScripts)
                );

            /*  =====================================================================
                5) Alert  bundle scripts  [Bundle name : alert-script-bundle]
                ====================================================================== */


            var alertScriptBundle = new ScriptBundle("~/bundles/alert-script-bundle")
                .Include(commonScripts)
                //.Include(fileUploadScripts)
                .Include(alertListScripts);
            bundles.Add(alertScriptBundle);


            /* ============================================================================
                6) Alert publishing bundle scripts [Bundle name : alert-pub-script-bundle]
               ============================================================================= */

            var alertPublishingScriptBundle = new ScriptBundle("~/bundles/alert-pub-script-bundle")
                .Include(dojoScripts)
                .Include(
                    "~/Scripts/Publishing/athoc.iws.scenario.js",
                    "~/Scripts/Publishing/athoc.iws.alert.placeholder.js",
                    "~/Scripts/Publishing/athoc.iws.scenario.settings.js"
                )
                .Include(publishingScripts);
            bundles.Add(alertPublishingScriptBundle);


            /*========================================================================
                  6) publishing-script-bundle [Bundle name : publishing-script-bundle]
              =========================================================================*/

            var publishingScriptBundle = new ScriptBundle("~/bundles/publishing-script-bundle")
                .Include(publishingScripts);
            bundles.Add(publishingScriptBundle);

            /* =========================================================================
                  7) home page bundle scripts  [Bundle name : home-script-bundle]
               ========================================================================= */

            var homeScriptBundle = new ScriptBundle("~/bundles/home-script-bundle")
             //.Include(fileUploadScripts)
                .Include(dojoScripts)
               .Include
                (
                    "~/Scripts/Home/athoc.iws.home.js"
                )
                .Include(publishingScripts);

            bundles.Add(homeScriptBundle);


            /* =====================================================================
                  8) scenario list bundle scripts  [Bundle name : scenario-script-bundle]
              ======================================================================= */
            var scenarioScriptBundle = new ScriptBundle("~/bundles/scenario-script-bundle")
                //.Include(fileUploadScripts)
                .Include(dojoScripts)
                .Include(scenarioScripts)
                .Include(publishingScripts);

            bundles.Add(scenarioScriptBundle);


            /* ==========================================================================
                  9) placeholder-script-bundle [Bundle name : placeholder-script-bundle]
               ==========================================================================*/

            var placeholderScriptBundle = new ScriptBundle("~/bundles/placeholder-script-bundle")
             .Include("~/" + cndUrl + "/Scripts/lib-vendor/kendo/jszip.min.js")
                .Include("~/" + cndUrl + "/Scripts/lib/ajax-loader.js")
                .Include
                (
                    placeholderScripts
                );

            bundles.Add(placeholderScriptBundle);


            /*===================================================================================
                  10) user attribute bundle scripts  [Bundle name : user-attribute-script-bundle]
              =================================================================================== */

            var userAttributeScriptBundle = new ScriptBundle("~/bundles/user-attribute-script-bundle")
                .Include("~/" + cndUrl + "/Scripts/lib-vendor/kendo/jszip.min.js")
                .Include("~/" + cndUrl + "/Scripts/lib/ajax-loader.js")
                .Include(userattributeScripts);

            bundles.Add(userAttributeScriptBundle);

            /*===================================================================================
                  11) settings bundle scripts  [Bundle name : settings-script-bundle]
              =================================================================================== */

            var settingsScriptBundle = new ScriptBundle("~/bundles/settings-script-bundle")
                .Include("~/" + cndUrl + "/scripts/lib-vendor/libphonenumber/intlTelInput.min.js")
                .Include("~/" + cndUrl + "/Scripts/lib-vendor/kendo/jszip.min.js")
                .Include(settingsScripts);

            bundles.Add(settingsScriptBundle);

            /*===================================================================================
                12) user manager bundle scripts  [Bundle name : usermanager-script-bundle]
            =================================================================================== */

            var usermanagerScriptBundle = new ScriptBundle("~/bundles/usermanager-script-bundle")
                .Include("~/" + cndUrl + "/scripts/lib-vendor/libphonenumber/intlTelInput.min.js")
                //.Include(fileUploadScripts)
                .Include(dojoScripts)
                .Include(usermanagerScripts);

            bundles.Add(usermanagerScriptBundle);

            /*===================================================================================
              13)distribution list bundle scripts  [Bundle name : distribution-script-bundle]
          =================================================================================== */

            var distributionScriptBundle = new ScriptBundle("~/bundles/distribution-script-bundle")
             //.Include(fileUploadScripts)
                 .Include(dojoScripts)
                 .Include("~/Scripts/app/viewmodels/athoc.iws.userlist.js")
                .Include(distributionListScripts);
            bundles.Add(distributionScriptBundle);

            var kendoAlertScriptBundle = new ScriptBundle("~/bundles/kendoAlert-script-bundle")
                .Include(kendoAlertScripts);
            bundles.Add(kendoAlertScriptBundle);

            var changeOrganizationScriptBundle = new ScriptBundle("~/bundles/changeOrganization-script-bundle")
                .Include("~/Scripts/settings/athoc.iws.changeOrganization.js")
                .Include("~/Scripts/settings/changeorganization-picker.js");

            bundles.Add(changeOrganizationScriptBundle);

            /*===================================================================================
              14)scenarioPublisher list bundle scripts  [Bundle name : scenario-publisher-script-bundle]
          =================================================================================== */
            var scenarioPublisherScriptBundle = new ScriptBundle("~/bundles/scenario-publisher-script-bundle")
                     .Include("~/" + cndUrl + "/Scripts/lib/ajax-loader.js")
                     .Include("~/" + cndUrl + "/Scripts/app/dojoConfig.js")
                     .Include("~/" + cndUrl + "/Scripts/lib-vendor/esri/javascript/init.js")
                     .Include("~/" + cndUrl + "/Scripts/jquery.filedownload.js")                     
                     .Include("~/" + cndUrl + "/Scripts/app/services/dataservice.js")
                     .Include("~/" + cndUrl + "/Scripts/lib/ExtensionToolbox.js")

                .Include(publishingScripts);

            bundles.Add(scenarioPublisherScriptBundle);

            #endregion "Script Bundles"

            #region"Style Bundles"

            bundles.Add(new StyleBundle("~/bundles/kendo-style-bundle")
               .Include(kendoStyles)
               );
            bundles.Add(new StyleBundle("~/bundles/bootstrap-style-bundle")
            .Include(bootStrapStyles)
            );
            bundles.Add(new StyleBundle("~/bundles/layout-style-bundle")
           .Include(layoutStyles)
           );

            bundles.Add(new StyleBundle("~/bundles/alert-style-bundle")
              .Include(customStyles)
              .Include(publishingStyles)
              );

            bundles.Add(new StyleBundle("~/bundles/home-style-bundle")
               .Include(homeStyles)
               );

            bundles.Add(new StyleBundle("~/bundles/settings-style-bundle")
             .Include("~/" + cndUrl + "/Content/css/kendo-custom.css")
              .Include("~/" + cndUrl + "/Content/css/intlTelInput.min.css")
               .Include("~/" + cndUrl + "/Content/css/publishing-custom.css")
               .Include("~/" + cndUrl + "/Content/css/settings-custom.css")
               );

            bundles.Add(new StyleBundle("~/bundles/users-style-bundle")
             .Include(customStyles)
             .Include(mapStyles)
             );


            #endregion "Style Bundles"

            var enableOptimizations = string.IsNullOrEmpty(ConfigurationManager.AppSettings["EnableOptimizations"]) ||
                                      Convert.ToBoolean(ConfigurationManager.AppSettings["EnableOptimizations"]);
            BundleTable.EnableOptimizations = enableOptimizations;
        }
    }

}

