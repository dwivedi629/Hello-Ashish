﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Security.AccessControl;
using System.Timers;
using System.Web;
using System.Timers;
using AtHoc.Infrastructure.Log;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Web.SignalR;
using AtHoc.IWS.Business.Domain.Notification;
using AtHoc.Systems;
using EO.Pdf;
using Microsoft.AspNet.SignalR;

namespace AtHoc.IWS.Web
{
    public class DatabaseNotification
    {
        private static int? _lastKnownLocationAttId = null;
        private static DateTime? _lastPullTime = null;
        private static bool _processing = false;
        private static bool logExecutionTime = false;
        public static void StartMonitor()
        {
            double pollInterval;
            string updateInterval = string.Empty;
            try
            {
                updateInterval = AtHocSystem.Local.Configuration.GetValue("CHECK-UPDATE-INTERVAL");
                if (!Double.TryParse(updateInterval, out pollInterval))
                {
                    //if unable to parse, then set to 10 sec and log the error.
                    pollInterval = 10;
                    LogService.Current.Warn(() => "Missing/Invalid value in Global Config table for key => CHECK-UPDATE-INTERVAL. Continuing with default polling value = 10 sec");
                }
            }
            catch (Exception ex)
            {
                pollInterval = 10;
                LogService.Current.Error(() => "Missing value in Global Config table for key => CHECK-UPDATE-INTERVAL. Continuing with default polling value = 10 sec. " + ex.Message);
            }

            //Times takes input as milli seconds. thus * 1000
            var timer = new System.Timers.Timer(pollInterval * 1000);
            timer.Elapsed += OnTimedEvent;
            timer.Enabled = true;
        }

        private static void OnTimedEvent(Object source, ElapsedEventArgs e)
        {
            try
            {

                //#if (!DEBUG)
                //Checking if previous database call has returned.
                if (!_processing)
                {
                    //Set flag = true - Let the response come from Database
                    _processing = true;

                    INotificationRepository notificationRepository = new NotificationRepository();
                    DateTime executionStartTime = DateTime.Now;
                    //At first call, lastpulltime will be null.
                    //At database side, if lastputtime is null then query returns the data based on DB Server current UTC time.
                    //Also it returns the datetime to hold the last pull time. Since the variable is static, it will hold the recent date returned by stored procedure.
                    var notifications = notificationRepository.GetSignalRNotifications(ref _lastPullTime);
                    if (logExecutionTime)
                    {
                        LogService.Current.Warn(
                            () =>
                                string.Format(
                                    "SignalR Notification: Database is taking more time than the actual polling interval time. (Stored Procedure: SNR_GET_NOTIFICATION_UPDATES. It took {0} millisecond to execute.",
                                    (DateTime.Now - executionStartTime).TotalMilliseconds));
                        
                        //reset flag
                        logExecutionTime = false;
                    }


                    foreach (var notification in notifications)
                    {
                        HubInvoker.InvokeSingalR(notification.ProviderId, notification.ContentId);
                    }

                    //Database has responsed successfully -  reset the flag - allow next request to go for database call

                }
                else
                {
                    //set flag
                    logExecutionTime = true;
                    LogService.Current.Warn(
                        () =>
                            "SignalR Notification: Database is taking more time than the actual polling interval time. (Stored Procedure: SNR_GET_NOTIFICATION_UPDATES");
                }
                // #endif
            }
            catch (Exception ex)
            {
                //Even if error occur - timer should continue looking for notification.
                LogService.Current.Error(() => string.Format("Error in SignalR Notification : {0}", ex.Message));
            }
            finally
            {
                _processing = false;
            }
        }
    }
}