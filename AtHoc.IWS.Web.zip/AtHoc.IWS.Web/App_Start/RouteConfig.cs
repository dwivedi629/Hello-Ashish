﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace AtHoc.IWS.Web
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");
            //routes.MapMvcAttributeRoutes();
            routes.MapRoute(
                name:"Inbox",
                url:"Inbox/{eid}",
                defaults: new { controller = "EventManager", action = "Inbox" ,eid=UrlParameter.Optional}
            );

            //required for problem with mp4 playback in ssl, has to attach extension to the url
            /*routes.MapRoute(
                "MP4",                                              // Route name
                "media/get/{id}.mp4",                           // URL with parameters
                new { controller = "media", action = "get", id = "" }  // Parameter defaults
            );*/
            routes.MapRoute(
               "wav",                                              // Route name
               "media/GetAudioByAudioId/{id}.wav",                           // URL with parameters
               new { controller = "media", action = "GetAudioByAudioId" }  // Parameter defaults
           );
           
            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}