﻿using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Settings.SqlQueries;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web.UI.WebControls;
using System.Xml;
using System.Xml.Linq;


namespace AtHoc.IWS.Business.Domain.Settings.Impl
{
    public class WeatherModuleRepository : IWeatherModuleRepository
    {
        #region Private Vairables/Properties

        private string _configurationPath = string.Empty;
        private int _providerId { get; set; }
        private int _operatorId { get; set; }
        private AgentSettingsList AgentInfo {get;set;}
        private XmlDocument ConfigXML { get; set; }
        private System.Xml.XmlNamespaceManager manager;
        private System.Xml.XmlElement provider;
        private System.Xml.XmlElement channel;

        private const string XML_NAMESPACE = "AtHoc";
        private const string XML_NAMESPACE_URI = "http://www.athoc.com";

        #endregion

        #region Public Methods 

        /// <summary>
        /// This method will get all alerts based on channel id
        /// </summary>
        /// <param name="channelId"></param>
        /// <returns>List of alerts</returns>
        public WeatherModuleSettings GetAlertingPreferenceInfo(WeatherModuleCriteria objCriteria)
        {           

            WeatherModuleSettings objAlertPref = new WeatherModuleSettings();

            Xml eventRules = new Xml();
            XmlDocument rulesDoc = new XmlDocument();
            this.LoadConfiguration(objCriteria);
            XmlElement ruleList = (XmlElement)channel.SelectSingleNode("AtHoc:RuleList", manager);

            #region Channel Enable/Disable
            XmlAttribute disabled = channel.Attributes["AtHoc:Disabled"];
            if (disabled != null && disabled.Value.ToLower() == "true")
            {
                objAlertPref.ChannelDisable = true;
            }

            #endregion

            #region Customized binding
            rulesDoc.AppendChild(rulesDoc.ImportNode(ruleList, true));
            objAlertPref.PersonalizedEventList = new List<WMEvents>();

            XmlNodeList nodes = rulesDoc.DocumentElement.SelectNodes("AtHoc:PersonalEventRule", manager);
            foreach (XmlNode item in nodes)
            {
                WMEvents pEvent = new WMEvents();
                XmlNode objNode = item.SelectSingleNode("AtHoc:Label", manager);
                pEvent.EventName = objNode.InnerText;
                XmlNodeList objNodes = item.SelectNodes("AtHoc:ConditionList/AtHoc:Condition", manager);
                for (int i = 1; i < objNodes.Count; i++)
                {
                    XmlNodeList objValues;
                    objNode = objNodes[i].SelectSingleNode("AtHoc:Nodes/AtHoc:Node", manager);
                    if ((objNode != null) && (!string.IsNullOrWhiteSpace(objNode.InnerText)))
                    {
                        switch (objNode.InnerText.ToLower())
                        {
                            case WeatherConstants.URGENCY:
                                objValues = objNodes[i].SelectNodes("AtHoc:Values/AtHoc:Value", manager);
                                foreach (XmlNode item1 in objValues)
                                {
                                    pEvent.UrgencyValues = item1.InnerText + "," + pEvent.UrgencyValues;
                                }

                                pEvent.UrgencyValues = pEvent.UrgencyValues.TrimEnd(',');
                                break;

                            case WeatherConstants.SEVERITY:
                                objValues = objNodes[i].SelectNodes("AtHoc:Values/AtHoc:Value", manager);
                                foreach (XmlNode item1 in objValues)
                                {
                                    pEvent.SeverityValues = item1.InnerText + "," + pEvent.SeverityValues;
                                }

                                pEvent.SeverityValues = pEvent.SeverityValues.TrimEnd(',');
                                break;

                            case WeatherConstants.CERTAINTY:
                                objValues = objNodes[i].SelectNodes("AtHoc:Values/AtHoc:Value", manager);
                                foreach (XmlNode item1 in objValues)
                                {
                                    pEvent.CertaintyValues = item1.InnerText + "," + pEvent.CertaintyValues;
                                }

                                pEvent.CertaintyValues = pEvent.CertaintyValues.TrimEnd(',');
                                break;
                        }
                        pEvent.Keywords =(objNodes[0].LastChild).InnerText;
                    }
                }

                objAlertPref.PersonalizedEventList.Add(pEvent);
            }
            #endregion

            #region folder Alerts

            using (var repository = new AtHocDbContext())
            {
                // Get all alerts based on channel Id
                objAlertPref.ListFolderAlerts = repository.Database.SqlQuery<FolderAlert>(WeatherModuleQueryTemplate.GetChannelAlertList(objCriteria.FolderId, objCriteria.ProviderId)).ToList<FolderAlert>();
            }

            #endregion

            #region States data

            List<GeoCodes> objStates = new List<GeoCodes>();
            // bind the state list //
            XmlNodeList states = ConfigXML.SelectNodes("/AtHoc:AgentConfiguration/AtHoc:StateList/AtHoc:State[AtHoc:Path[. = /AtHoc:AgentConfiguration/AtHoc:ProviderList/AtHoc:Provider[@AtHoc:ID[. = '" + objCriteria.ProviderId + "']]/AtHoc:URLList[@Type[. = 'Selected']]/AtHoc:URL/AtHoc:Path]]", manager);
            for (int i = 0; i < states.Count; i++)
            {
                GeoCodes state = new GeoCodes();
                state.StateName = states[i].Attributes["Name"].Value;
                state.StateCode = states[i].Attributes["Abbreviation"].Value;
                objStates.Add(state);
            }
            objAlertPref.StatesList = objStates;
            #endregion

            #region Events binding

            List<WMEvents> onEvents = new List<WMEvents>();

            XmlNodeList rules = ConfigXML.SelectNodes("/AtHoc:AgentConfiguration/AtHoc:RuleList/AtHoc:EventRule", manager);

            for (int i = 0; i < rules.Count; i++)
            {
                WMEvents objEvent = new WMEvents();
                XmlElement rule = (XmlElement)rules[i];
                XmlElement label = (XmlElement)rule.SelectSingleNode("AtHoc:Label", manager);
                objEvent.EventName = label.InnerText;

                XmlElement selected = (XmlElement)ruleList.SelectSingleNode("AtHoc:EventRule[AtHoc:Label[. = '" + label.InnerText + "']]", manager);
                if (selected != null)
                {
                    objEvent.isSelected = true;
                }
                onEvents.Add(objEvent);
            }

            objAlertPref.EventList = onEvents;

            #endregion

            #region Location Binding
            // locations //
            XmlElement locationListNode = (XmlElement)channel.SelectSingleNode("AtHoc:LocationList", manager);
            XmlNodeList locations = locationListNode.SelectNodes("AtHoc:Location", manager);
            XmlElement location;
            XmlElement code;
            ArrayList locationList = new ArrayList();
            for (int i = 0; i < locations.Count; i++)
            {
                location = (XmlElement)locations[i];
                code = (XmlElement)location.SelectSingleNode("AtHoc:Geocode", manager);
                if (code.InnerText.Length > 0)
                {
                    locationList.Add(code.InnerText.Trim());
                }
            }
            Boolean overrideFipsErrors = false;
            Boolean.TryParse(locationListNode.GetAttribute("AtHoc:OverrideFipsErrors"), out overrideFipsErrors);
            objAlertPref.PublishForBadCondition = overrideFipsErrors;
            objAlertPref.PublishForBadConditionText = locationListNode.GetAttribute("AtHoc:OverrideFipsErrorsScenario");
            objAlertPref.LocationGeoCodes = this.JoinStringArrayList(locationList);

            #endregion

            #region Targetting binding

             WMTargetOption tgtOption = new WMTargetOption();
             XmlElement targeting = null;
            //Targetting Agent Info
             targeting = (XmlElement)provider.SelectSingleNode("AtHoc:Targeting", manager);
             
             string agentInfo = (targeting == null) ? "ALL" : targeting.GetAttribute("Type").ToUpper();

             tgtOption.isMatchedWeatherEventLocation=agentInfo=="ALL"?false:true;

            // targeting //
            targeting = (XmlElement)channel.SelectSingleNode("AtHoc:Targeting", manager);
            string targetingImplementation = (targeting == null) ? "ALL" : targeting.GetAttribute("AtHoc:Implementation").ToUpper();

           
            switch (targetingImplementation)
            {
                case WeatherConstants.TARGETING_IMPLEMENTATION_GROUP:
                    tgtOption.isGroupNameChecked = true;
                    // fill in the list of groups //
                    XmlNodeList groups = targeting.SelectNodes("AtHoc:Collection/AtHoc:Item", manager);
                    for (int i = 0; i < groups.Count; i++)
                    {
                        XmlElement group = (XmlElement)groups[i];
                        if (i > 0)
                        {
                            tgtOption.GroupNames += ", ";
                        }
                        tgtOption.GroupNames += group.InnerText;
                    }
                    break;

                case WeatherConstants.TARGETING_IMPLEMENTATION_SCENARIO:
                    XmlElement seletedAlert = (XmlElement)targeting.SelectSingleNode("AtHoc:Collection/AtHoc:Item", manager);
                    if (seletedAlert != null)
                    {
                        tgtOption.isFolderAlertChecked = true;
                        tgtOption.SelectedAlertId = seletedAlert.InnerText;
                    }
                    break;

                case WeatherConstants.TARGETING_IMPLEMENTATION_LOCATION:
                    tgtOption.UserBasedOnLocation = tgtOption.isMatchedWeatherEventLocation ? true : false;
                    break;
                default:
                    tgtOption.AllSubscribeUser = true;
                    break;
            }

            objAlertPref.TargetOptions = tgtOption;

            #endregion

            return objAlertPref;
        }


        /// <summary>
        /// This method will get all geocodes based on channel id
        /// </summary>
        /// <param name="objCriteria"></param>
        /// <returns></returns>
        public List<GeoCodes> GetAllGeoCodeList(WeatherModuleCriteria objCriteria)
        {
            List<GeoCodes> geocodes = new List<GeoCodes>();
            using (var repository = new AtHocDbContext())
            {
                //checking if any channels dependent on alert
                geocodes = repository.Database.SqlQuery<GeoCodes>(WeatherModuleQueryTemplate.GetGeoCodes(objCriteria.StateCode, objCriteria.ZipCode)).
                        ToList<GeoCodes>();
                return geocodes;
            }

        }


        /// <summary>
        /// This method will Save Weather Modified informations
        /// </summary>
        /// <param name="weatherData"></param>
        public void SaveWeatherInformations(WeatherModuleSettings weatherData)
        {
            //Load basic configuration first, then do update
            this.LoadConfiguration(weatherData.BasicCriteria);
            XmlDocument addPEventRules = null;
            XmlElement rootElement = null;
            XmlNode newlyRootNode = null;
            bool isAttrExist = false;
            XmlAttribute attr = null;

            #region Channel Enable/Disable

            if (channel.Attributes.Count > 0 && this.isAttributeAvailable(channel.Attributes, "Disabled"))
            {
                channel.Attributes["AtHoc:Disabled"].InnerText = weatherData.ChannelDisable.ToString();
            }
            else
            {
                attr = ConfigXML.CreateAttribute(XML_NAMESPACE, "Disabled", XML_NAMESPACE_URI);
                attr.InnerText = weatherData.ChannelDisable.ToString();
                channel.Attributes.Append(attr);
            }
            #endregion

            #region //Update Personalized EventList
            XmlElement ruleList = (XmlElement)channel.SelectSingleNode("AtHoc:RuleList", manager);
            XmlNodeList deletePEventRules = ruleList.SelectNodes("AtHoc:PersonalEventRule", manager);

            foreach (XmlNode item in deletePEventRules)
            {
                ruleList.RemoveChild(item);
            }

            foreach (WMEvents item in weatherData.PersonalizedEventList)
            {
                newlyRootNode = ConfigXML.CreateElement(XML_NAMESPACE, WeatherConstants.PERSONAL_EVENT_RULE, XML_NAMESPACE_URI);
                addPEventRules = this.ConvertStringToXml(TemplateTypes.PersonalizedTemplate);

                #region Adding personalized Items
                addPEventRules.SelectSingleNode("AtHoc:PersonalEventRule/AtHoc:Label", manager).InnerText = item.EventName;
                addPEventRules.SelectSingleNode("AtHoc:PersonalEventRule/AtHoc:ConditionList/AtHoc:Condition/AtHoc:Values/AtHoc:Value", manager).InnerText = item.Keywords;

                rootElement = !string.IsNullOrWhiteSpace(item.CertaintyValues) ?
                      this.CreateChildNodes(addPEventRules, item.CertaintyValues, WeatherConstants.CERTAINTY) : null;
                if (rootElement != null)
                    addPEventRules.SelectSingleNode("AtHoc:PersonalEventRule/AtHoc:ConditionList", manager).AppendChild((XmlNode)rootElement);

                rootElement = !string.IsNullOrWhiteSpace(item.SeverityValues) ?
                      this.CreateChildNodes(addPEventRules, item.SeverityValues, WeatherConstants.SEVERITY) : null;
                if (rootElement != null)
                    addPEventRules.SelectSingleNode("AtHoc:PersonalEventRule/AtHoc:ConditionList", manager).AppendChild((XmlNode)rootElement);

                rootElement = !string.IsNullOrWhiteSpace(item.UrgencyValues) ?
                      this.CreateChildNodes(addPEventRules, item.UrgencyValues, WeatherConstants.URGENCY) : null;
                if (rootElement != null)
                    addPEventRules.SelectSingleNode("AtHoc:PersonalEventRule/AtHoc:ConditionList", manager).AppendChild((XmlNode)rootElement);
                #endregion

                newlyRootNode.InnerXml = addPEventRules.DocumentElement.InnerXml;
                ruleList.AppendChild(newlyRootNode);
            }




            #endregion

            #region Update Event list
            deletePEventRules = ruleList.SelectNodes("AtHoc:EventRule", manager);
            foreach (XmlNode item in deletePEventRules)
            {
                ruleList.RemoveChild(item);
            }


            addPEventRules = this.ConvertStringToXml(TemplateTypes.EventRuleTemplate);

            //Add new selected event rules
            foreach (var item in weatherData.EventList)
            {
                if (item.isSelected)
                {
                    newlyRootNode = ConfigXML.CreateElement(XML_NAMESPACE, WeatherConstants.EVENTRULE, XML_NAMESPACE_URI);
                    addPEventRules.SelectSingleNode("AtHoc:EventRule/AtHoc:Label", manager).InnerText = item.EventName;
                    addPEventRules.SelectSingleNode("AtHoc:EventRule/AtHoc:ConditionList/AtHoc:Condition/AtHoc:Values/AtHoc:Value", manager).InnerText = item.EventName.ToLower();
                    newlyRootNode.InnerXml = addPEventRules.DocumentElement.InnerXml;
                    ruleList.AppendChild(newlyRootNode);
                }

            }

            #endregion

            #region Update geocode

            channel.SelectSingleNode("AtHoc:LocationList", manager).RemoveAll();

            if (!string.IsNullOrWhiteSpace(weatherData.LocationGeoCodes))
            {
                string[] arrLocation = weatherData.LocationGeoCodes.Split(',');
                foreach (var item in arrLocation)
                {
                    XmlElement locationNode = ConfigXML.CreateElement(XML_NAMESPACE, "Location", XML_NAMESPACE_URI);
                    XmlElement geoCode = ConfigXML.CreateElement(XML_NAMESPACE, "Geocode", XML_NAMESPACE_URI);
                    geoCode.InnerText = item.Trim();
                    locationNode.AppendChild(geoCode);
                    channel.SelectSingleNode("AtHoc:LocationList", manager).AppendChild(locationNode);
                }
            }

            if (weatherData.PublishForBadCondition)
            {
                //Update bad weather flag
                isAttrExist = this.isAttributeAvailable(((XmlElement)channel.SelectSingleNode("AtHoc:LocationList", manager)).Attributes, "OverrideFipsErrors");

                if (isAttrExist)
                {
                    channel.SelectSingleNode("AtHoc:LocationList", manager).Attributes["AtHoc:OverrideFipsErrors"].InnerText = weatherData.PublishForBadCondition.ToString();
                }
                else
                {
                    attr = ConfigXML.CreateAttribute(XML_NAMESPACE, "OverrideFipsErrors", XML_NAMESPACE_URI);
                    attr.InnerText = weatherData.PublishForBadCondition.ToString();
                    ((XmlElement)channel.SelectSingleNode("AtHoc:LocationList", manager)).Attributes.Append(attr);
                }


                isAttrExist = this.isAttributeAvailable(((XmlElement)channel.SelectSingleNode("AtHoc:LocationList", manager)).Attributes, "OverrideFipsErrorsScenario");

                if (isAttrExist)
                {
                    channel.SelectSingleNode("AtHoc:LocationList", manager).Attributes["AtHoc:OverrideFipsErrorsScenario"].InnerText = weatherData.PublishForBadConditionText;
                }
                else
                {
                    attr = ConfigXML.CreateAttribute(XML_NAMESPACE, "OverrideFipsErrorsScenario", XML_NAMESPACE_URI);
                    attr.InnerText = weatherData.PublishForBadConditionText.ToString();
                    ((XmlElement)channel.SelectSingleNode("AtHoc:LocationList", manager)).Attributes.Append(attr);
                }
            }
            #endregion

            #region Update Target Section

            // targeting //
            channel.SelectSingleNode("AtHoc:Targeting", manager).RemoveAll();
            XmlElement collNode = null;
            XmlAttribute collAttr = null;
            XmlElement collItem = null;

            collNode = ConfigXML.CreateElement(XML_NAMESPACE, "Collection", XML_NAMESPACE_URI);
            collAttr = ConfigXML.CreateAttribute(XML_NAMESPACE, "Implementation", XML_NAMESPACE_URI);
            collAttr.InnerText = "ALL";
            collNode.Attributes.Append(collAttr);
            collAttr = ConfigXML.CreateAttribute(XML_NAMESPACE, "Implementation", XML_NAMESPACE_URI);
            collAttr.InnerText = "ALL";
            channel.SelectSingleNode("AtHoc:Targeting", manager).Attributes.Append(collAttr);

            if (weatherData.TargetOptions.UserBasedOnLocation)
            {
                channel.SelectSingleNode("AtHoc:Targeting", manager).Attributes["AtHoc:Implementation"].InnerText = "LOCATION";
                collItem = ConfigXML.CreateElement(XML_NAMESPACE, "Item", XML_NAMESPACE_URI);
                collItem.InnerText = weatherData.TargetOptions.UserBasedOnLocation.ToString();
                collNode.AppendChild(collItem);
                channel.SelectSingleNode("AtHoc:Targeting", manager).AppendChild(collNode);

            }
            else if ((weatherData.TargetOptions.isGroupNameChecked) && (!string.IsNullOrWhiteSpace(weatherData.TargetOptions.GroupNames)))
            {
                channel.SelectSingleNode("AtHoc:Targeting", manager).Attributes["AtHoc:Implementation"].InnerText = "GROUP";
                string[] arrGroups = weatherData.TargetOptions.GroupNames.Split(',');

                foreach (var item in arrGroups)
                {
                    collItem = ConfigXML.CreateElement(XML_NAMESPACE, "Item", XML_NAMESPACE_URI);
                    collItem.InnerText = item;
                    collNode.AppendChild(collItem);
                    channel.SelectSingleNode("AtHoc:Targeting", manager).AppendChild(collNode);
                }

            }
            else if ((weatherData.TargetOptions.isFolderAlertChecked) && (!string.IsNullOrWhiteSpace(weatherData.TargetOptions.SelectedAlertId)))
            {
                channel.SelectSingleNode("AtHoc:Targeting", manager).Attributes["AtHoc:Implementation"].InnerText = "SCENARIO";
                collItem = ConfigXML.CreateElement(XML_NAMESPACE, "Item", XML_NAMESPACE_URI);
                collItem.InnerText = weatherData.TargetOptions.SelectedAlertId;
                collNode.AppendChild(collItem);
                channel.SelectSingleNode("AtHoc:Targeting", manager).AppendChild(collNode);
            }
            else
            {
                //Default All
                channel.SelectSingleNode("AtHoc:Targeting", manager).AppendChild(collNode);
            }

            #endregion

            #region Final Update on database

            channel.SelectSingleNode("AtHoc:RuleList", manager).InnerXml = ruleList.InnerXml;

            ConfigXML.SelectSingleNode("AtHoc:AgentConfiguration/AtHoc:ProviderList/AtHoc:Provider[@AtHoc:ID[. = '" + weatherData.BasicCriteria.ProviderId + "']]/AtHoc:ChannelList/AtHoc:Channel[@AtHoc:ID[. = '" + weatherData.BasicCriteria.FolderId + "']]", manager).InnerXml = channel.InnerXml;

            using (var dbContext = new AtHocDbContext())
            {
                var ndeletedata = dbContext.AgentSettings.Where(p => p.agentId == weatherData.BasicCriteria.AgentId).ToList();
                foreach (AgentSettings item in ndeletedata)
                {
                    item.metastore = ConfigXML.OuterXml;
                    dbContext.Entry(item).State = System.Data.Entity.EntityState.Modified;
                }
                dbContext.SaveChanges();
            }


            #endregion
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Check for the available attributes
        /// </summary>
        /// <param name="attrColl"></param>
        /// <param name="strFindText"></param>
        /// <returns></returns>
        private bool isAttributeAvailable(XmlAttributeCollection attrColl, string strFindText)
        {
            int count = 0;
            foreach (XmlAttribute item in attrColl)
            {
                if (item.LocalName.ToLower() == strFindText.ToLower()) count++;
            }

            if (count == 0)
                return false;

            return true;
        }


        /// <summary>
        /// creating the child nodes
        /// </summary>
        /// <param name="xLocalDoc"></param>
        /// <param name="priorityValues"></param>
        /// <param name="headerText"></param>
        /// <returns></returns>
        private XmlElement CreateChildNodes(XmlDocument xLocalDoc, string priorityValues, string headerText)
        {
            XmlElement rootElement = xLocalDoc.CreateElement(XML_NAMESPACE, WeatherConstants.CONDITION, XML_NAMESPACE_URI);
            XmlAttribute attr = xLocalDoc.CreateAttribute(XML_NAMESPACE, WeatherConstants.TEST, XML_NAMESPACE_URI);
            attr.InnerText = WeatherConstants.ASSERT;
            rootElement.Attributes.Append(attr);

            #region //add Nodes
            XmlElement rootNodes = xLocalDoc.CreateElement(XML_NAMESPACE, "Nodes", XML_NAMESPACE_URI);
            XmlNode childNode = xLocalDoc.CreateNode(XmlNodeType.Element, XML_NAMESPACE, "Node", XML_NAMESPACE_URI);
            childNode.InnerText = headerText;
            rootNodes.AppendChild(childNode);

            childNode = xLocalDoc.CreateNode(XmlNodeType.Element, XML_NAMESPACE, "Node", XML_NAMESPACE_URI);
            childNode.InnerText = "cap:" + headerText;
            rootNodes.AppendChild(childNode);
            rootElement.AppendChild((XmlNode)rootNodes);
            #endregion

            #region //add Values Node
            rootNodes = xLocalDoc.CreateElement(XML_NAMESPACE, "Values", XML_NAMESPACE_URI);
            string[] arrValues = priorityValues.Split(',');
            for (int i = 0; i < arrValues.Count(); i++)
            {
                childNode = xLocalDoc.CreateNode(XmlNodeType.Element, XML_NAMESPACE, "Value", XML_NAMESPACE_URI);
                childNode.InnerText = arrValues[i];
                rootNodes.AppendChild(childNode);
            }

            rootElement.AppendChild((XmlNode)rootNodes);

            #endregion

            return rootElement;
        }


        /// <summary>
        /// operation on arrays to mae data
        /// </summary>
        /// <param name="list"></param>
        /// <returns></returns>
        private string JoinStringArrayList(ArrayList list)
        {
            string output = "";
            for (int i = 0; i < list.Count; i++)
            {
                if (i > 0)
                {
                    output += ", ";
                }
                output += list[i].ToString();
            }
            return output;
        }              


        /// <summary>
        /// Get Channels reference types
        /// </summary>
        private string GetChannelReferenceType
        {
            get
            {
                var queries = AgentInfo.channelpreferencesURL.Split('&');

                // Convert the array of strings into an object
                for (int i = 0, l = queries.Length; i < l; i++)
                {
                    var temp = queries[i].Split('=');
                    if ((temp[1].Equals(WeatherConstants.EVENT,StringComparison.OrdinalIgnoreCase)) || (temp[1].Equals(WeatherConstants.CONDITION,StringComparison.OrdinalIgnoreCase)))
                    {
                        return temp[1];
                    }

                }
                return WeatherConstants.EVENT; //Default
            }
        }


        /// <summary>
        /// Loading the Configuration to get agents metaxml
        /// </summary>
        /// <param name="objCriteria"></param>
        private void LoadConfiguration(WeatherModuleCriteria objCriteria)
        {
            this._providerId = objCriteria.ProviderId;
            this._operatorId = objCriteria.OperatorId;
            AgentInfo = this.AgentDetails(objCriteria.AgentId);

            if ((AgentInfo != null) && (!string.IsNullOrWhiteSpace(AgentInfo.metastore)))
            {
                this.LoadConfiguration(objCriteria.FolderId);
            }
        }


        /// <summary>
        /// overloaded method for Loading the Configuration to get agents metaxml
        /// </summary>
        /// <param name="folderId"></param>
        private void LoadConfiguration(int folderId)
        {

            switch (this.GetChannelReferenceType)
            {
                case WeatherConstants.EVENT:
                    _configurationPath = WeatherConstants.CONFIGPATH_EVENT;
                    break;
                default:
                    _configurationPath = WeatherConstants.CONFIGPATH_CONDITION;
                    break;
            }


            ConfigXML = new XmlDocument();
            ConfigXML.LoadXml(AgentInfo.metastore);
            manager = new XmlNamespaceManager(ConfigXML.NameTable);
            manager.AddNamespace("AtHoc", "http://www.athoc.com");

            // get the config node //
            XmlElement node = (XmlElement)ConfigXML.SelectSingleNode(_configurationPath, manager);
            ConfigXML.LoadXml(node.OuterXml);

            manager = new XmlNamespaceManager(ConfigXML.NameTable);
            manager.AddNamespace(XML_NAMESPACE, XML_NAMESPACE_URI);
            provider = (XmlElement)ConfigXML.SelectSingleNode("AtHoc:AgentConfiguration/AtHoc:ProviderList/AtHoc:Provider[@AtHoc:ID[. = '" + this._providerId + "']]", manager);
            if (provider != null)
                channel = (XmlElement)provider.SelectSingleNode("AtHoc:ChannelList/AtHoc:Channel[@AtHoc:ID[. = '" + folderId + "']]", manager);

            // if the channel entry doesn't exist, create one //
            if (channel == null)
            {
                var list = (XmlElement)provider.SelectSingleNode("AtHoc:ChannelList", manager);
                channel = (XmlElement)list.AppendChild(ConfigXML.ImportNode((XmlNode)CreateChannelEntry(folderId), true));
            }


        }


        /// <summary>
        /// creating  the channel entry
        /// </summary>
        /// <param name="folderId"></param>
        /// <returns></returns>
        private XmlElement CreateChannelEntry(int folderId)
        {
            // utilities //
            XmlDocument provider = new XmlDocument();
            XmlNamespaceManager manager = new XmlNamespaceManager(provider.NameTable);
            manager.AddNamespace(XML_NAMESPACE, XML_NAMESPACE_URI);

            // build the root node and fill it up //
            XmlElement root = provider.CreateElement(XML_NAMESPACE, WeatherConstants.CHANNEL, XML_NAMESPACE_URI);
            root.Attributes.Append(provider.CreateAttribute(XML_NAMESPACE, WeatherConstants.ID, XML_NAMESPACE_URI));
            root.Attributes["AtHoc:ID"].Value = folderId.ToString();
            XmlElement item;
            XmlElement child;

            item = (XmlElement)root.AppendChild((XmlNode)provider.CreateElement(XML_NAMESPACE, WeatherConstants.TARGETING, XML_NAMESPACE_URI));
            child = (XmlElement)item.AppendChild((XmlNode)provider.CreateElement(XML_NAMESPACE, WeatherConstants.COLLECTION, XML_NAMESPACE_URI));
            child.SetAttribute(WeatherConstants.IMPLEMENTATION, XML_NAMESPACE_URI, WeatherConstants.ALL);

            item = (XmlElement)root.AppendChild((XmlNode)provider.CreateElement(XML_NAMESPACE, WeatherConstants.LOCATION_LIST, XML_NAMESPACE_URI));
            item.SetAttribute(WeatherConstants.OVERRIDE_FIPS_ERRORS, XML_NAMESPACE_URI, false.ToString());
            item.SetAttribute(WeatherConstants.OVERRIDE_FIPS_ERRORS_SCENARIO, XML_NAMESPACE_URI, "");

            item = (XmlElement)root.AppendChild((XmlNode)provider.CreateElement(XML_NAMESPACE, WeatherConstants.TEMPORARY_RULE_LIST, XML_NAMESPACE_URI));

            item = (XmlElement)root.AppendChild((XmlNode)provider.CreateElement(XML_NAMESPACE, WeatherConstants.RULE_LIST, XML_NAMESPACE_URI));

            return root;
        }


        /// <summary>
        /// Getting the Agent details
        /// </summary>
        /// <param name="agentId"></param>
        /// <returns></returns>
        private AgentSettingsList AgentDetails(int agentId)
        {
            using (var repository = new AtHocDbContext())
            {
                return repository.AgentSettings.Where(x => x.agentId == agentId).Select(p => new AgentSettingsList
                {
                    agentId = p.agentId,
                    agentName = p.agentName,
                    agentcommonName = p.agentcommonName,
                    providerId = p.providerId,
                    channelpreferencesURL = p.channelpreferencesURL,
                    metastore = p.metastore,
                }).FirstOrDefault();
            }
        }


        /// <summary>
        /// Personnalized the rule list
        /// </summary>
        private string PersonalizedRulesTemplate
        {
            get
            {

                return "<AtHoc:PersonalEventRule><AtHoc:Label>test345</AtHoc:Label><AtHoc:ConditionList AtHoc:Test='ASSERT'>" + "<AtHoc:Condition AtHoc:Test='ASSERT'><AtHoc:Nodes><AtHoc:Node>headline</AtHoc:Node>" + 
                "<AtHoc:Node>description</AtHoc:Node>" + 
                "<AtHoc:Node>title</AtHoc:Node><AtHoc:Node>summary</AtHoc:Node>" + "<AtHoc:Node>cap:headline</AtHoc:Node>" +
                "<AtHoc:Node>cap:description</AtHoc:Node><AtHoc:Node>cap:title</AtHoc:Node>" +
                "<AtHoc:Node>cap:summary</AtHoc:Node></AtHoc:Nodes>" +
                "<AtHoc:Values><AtHoc:Value AtHoc:Test='CONTAINS'>Key-Test</AtHoc:Value>" +
                "</AtHoc:Values></AtHoc:Condition></AtHoc:ConditionList>" + "</AtHoc:PersonalEventRule>";
            }
        }


        /// <summary>
        /// Event Rules
        /// </summary>
        private string EventRulesTemplate
        {
            get
            {

                return "<AtHoc:EventRule><AtHoc:Label>test345</AtHoc:Label><AtHoc:ConditionList AtHoc:Test='ASSERT'>" + "<AtHoc:Condition AtHoc:Test='ASSERT'><AtHoc:Nodes><AtHoc:Node>headline</AtHoc:Node>" +
                "<AtHoc:Node>description</AtHoc:Node>" +
                "<AtHoc:Node>title</AtHoc:Node><AtHoc:Node>summary</AtHoc:Node>" + "<AtHoc:Node>cap:headline</AtHoc:Node>" +
                "<AtHoc:Node>cap:description</AtHoc:Node><AtHoc:Node>cap:title</AtHoc:Node>" +
                "<AtHoc:Node>cap:summary</AtHoc:Node></AtHoc:Nodes>" +
                "<AtHoc:Values><AtHoc:Value AtHoc:Test='CONTAINS'>Key-Test</AtHoc:Value>" +
                "</AtHoc:Values></AtHoc:Condition></AtHoc:ConditionList>" + "</AtHoc:EventRule>";
            }
        }

        /// <summary>
        /// String to XML Conversion
        /// </summary>
        /// <param name="types"></param>
        /// <returns></returns>
        private XmlDocument ConvertStringToXml(TemplateTypes types)
        {
            XmlDocument xmldoc = new XmlDocument();
            XmlReaderSettings settings = new XmlReaderSettings { NameTable = new NameTable() };
            XmlNamespaceManager manager = new XmlNamespaceManager(settings.NameTable);
            manager.AddNamespace(XML_NAMESPACE, XML_NAMESPACE_URI);
            XmlParserContext context = new XmlParserContext(null, manager, "", XmlSpace.Default);
            XmlReader reader = null;

            switch (types)
            {
                case TemplateTypes.PersonalizedTemplate:
                    reader = XmlReader.Create(new StringReader(this.PersonalizedRulesTemplate), settings, context);
                    xmldoc.Load(reader);
                    break;
                case TemplateTypes.EventRuleTemplate:
                    reader = XmlReader.Create(new StringReader(this.EventRulesTemplate), settings, context);
                    xmldoc.Load(reader);
                    break;
                default:
                    break;
            }

            return xmldoc;
        }

        #endregion

    }

    /// <summary>
    /// Enums
    /// </summary>
    enum TemplateTypes
    {
        PersonalizedTemplate,
        EventRuleTemplate,
    }
    /// <summary>
    /// Constants
    /// </summary>
    public  class WeatherConstants
    {
         public const string EVENT = "Event";
         public const string CONDITION = "Condition";
         public const string CONFIGPATH_EVENT = "//AtHoc:AgentConfiguration[@AtHoc:Mode[. = 'Event']]";
         public const string CONFIGPATH_CONDITION = "//AtHoc:AgentConfiguration[@AtHoc:Mode[. = 'Condition']]";
         public const string TEMPORARY_RULE_LIST = "TemporaryRuleList";
         public const string RULE_LIST = "RuleList";
         public const string LOCATION_LIST = "LocationList";
         public const string COLLECTION = "Collection";
         public const string TARGETING = "Targeting";
         public const string IMPLEMENTATION = "Implementation";
         public const string ALL = "ALL";
         public const string OVERRIDE_FIPS_ERRORS = "OverrideFipsErrors";
         public const string OVERRIDE_FIPS_ERRORS_SCENARIO = "OverrideFipsErrorsScenario";
         public const string ID ="ID";
         public const string CHANNEL = "Channel";
         public const string TEST = "Test";
         public const string ASSERT = "ASSERT";
         public const string EVENTRULE = "EventRule";
         public const string PERSONAL_EVENT_RULE="PersonalEventRule";
         public const string URGENCY = "urgency";
         public const string SEVERITY = "severity";
         public const string CERTAINTY = "certainty";
         
         public const string TARGETING_IMPLEMENTATION_GROUP = "GROUP";
         public const string TARGETING_IMPLEMENTATION_SCENARIO = "SCENARIO";
         public const string TARGETING_IMPLEMENTATION_LOCATION = "LOCATION";
    }

    
}