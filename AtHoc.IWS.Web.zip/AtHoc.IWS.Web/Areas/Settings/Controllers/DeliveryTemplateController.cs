﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Web.Mvc;
using AtHoc.Global.Resources.Entities;
using AtHoc.Global.Resources.Interfaces;
using AtHoc.Infrastructure.Security;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Resources;
using AtHoc.IWS.Business.Context;
using AtHoc.Global.Resources;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Web.Filters;
using AtHoc.MediaServices;
using AtHoc.IWS.Web.Helpers;
using AtHoc.IWS.Business.Domain.Settings.Impl;
using AtHoc.IWS.Business.Domain.Authorization;
using AtHoc.IWS.Business.Domain.Users;
using AtHoc.IWS.Web.Models.Publishing;

using AtHoc.Publishing;
using Constants = AtHoc.IWS.Business.Configurations.Constants;
using AtHoc.IWS.Business.Domain.Devices;

namespace AtHoc.IWS.Web.Areas.Settings.Controllers
{

    [IWSAuthorize(new[] { SystemObject.DeliveryTemplates }, new ActionType[] { ActionType.Modify })]
    public class DeliveryTemplateController : Controller
    {
        private readonly IDeliveryTemplateFacade _deliveryFacade;
        private readonly ILogService _logService;
        private readonly IAuthFacade _authFacade;
        private readonly IUserFacade _userFacade;
        private readonly IOperatorFacade _operatorFacade;
        private readonly ILanguageFacade _languageFacade;
        private readonly IGlobalEntityLocaleFacade _globalEntityLocaleFacade;
        private readonly IDeviceOptionCache _deviceOptionCache;
        public DeliveryTemplateController(IDeliveryTemplateFacade deliveryFacade, ILogService logService, IAuthFacade authFacade, IUserFacade userFacade, IOperatorFacade operatorFacade, ILanguageFacade languageFacade, IGlobalEntityLocaleFacade globalEntityLocaleFacade, IDeviceOptionCache deviceOptionCache)
        {
            _deliveryFacade = deliveryFacade;
            _logService = logService;
            _authFacade = authFacade;
            _userFacade = userFacade;
            _operatorFacade = operatorFacade;
            _languageFacade = languageFacade;
            _globalEntityLocaleFacade = globalEntityLocaleFacade;
            _deviceOptionCache = deviceOptionCache;
        }
        /// <summary>
        /// GET: /Settings/DeliveryTemplate/
        /// </summary>
        /// <returns></returns>     
        public ActionResult Index()
        {
            var provider = RuntimeContext.Provider;
            ViewBag.DateFormat = provider.GetDateFormat();
            ViewBag.DateTimeFormat = provider.GetDateTimeFormat();
            var vpsTimeZOne = provider.GetVpsTimeZoneFromId();
            ViewBag.VPSTimeZone = vpsTimeZOne;
            ViewBag.UtcOffsetInMinutes = vpsTimeZOne.BaseUtcOffset.TotalMinutes;
            ViewBag.VPSOffsetFromSystemInMinutes = provider.VPSOffsetFromSystemInMinutes();
            ViewBag.SupportsDaylightSavingTime = vpsTimeZOne.SupportsDaylightSavingTime;
            return View();
        }
        /// <summary>
        /// To get all delivery tempaltes as per search criteria
        /// </summary>
        /// <param name="criteriaSpec">DeliveryTemplateCriteria</param>
        /// <returns>Json result- List of all Delivery Template Objects</returns>
        /// 

        [HttpPost]
        public JsonResult GetDeliveryTemplates(DeliveryTemplateCriteria criteriaSpec)
        {
            try
            {
                var providerId = RuntimeContext.ProviderId;
                var operatorId = RuntimeContext.OperatorId;
                criteriaSpec.ProviderId = providerId;
                criteriaSpec.OperatorId = operatorId;

                var deliveryTemplateList = _deliveryFacade.GetDeliveryTemplates(criteriaSpec, RuntimeContext.Provider.BaseLocale).Select(p => new { p.Template_Id, p.Name, p.Device_Group_Name, p.Scope, p.IsChecked, p.Description, p.Device_Group_Id, p.IsOwner,p.Provider_Id,p.AlertStatus,p.Severity,p.Default_Severity,p.Locale_Code }).ToList();
                var deviceGroups = _deliveryFacade.GetDeviceGroups(RuntimeContext.Provider.BaseLocale);
                var deviceGroupsList = deviceGroups.Select(p => new { p.DeviceGroupId, p.DeviceGroupName }).Distinct().OrderBy(p => p.DeviceGroupName).ToList();
                var systemUser = _operatorFacade.GetUser(new SystemUserSpec { ProviderId = providerId, OperatorId = operatorId });
                var rEnterpriseAdmin = systemUser.Roles.Count(e => e.RoleId == (int)Roles.EnterpriseAdmin) > 0;
                var rSystemAdmin = systemUser.Roles.Count(e => e.RoleId == (int)Roles.SystemAdmin) > 0 ;
                var rVirtualSystemAdmin = systemUser.Roles.Count(e => e.RoleId == (int)Roles.Administrator) > 0 ;
                var localizedseverityData = _globalEntityLocaleFacade.GetLocalizedEntity(SettingsHelper.Severities(), RuntimeContext.Provider.BaseLocale);
                var languageList = _languageFacade.GetDeliveryEnabledLanguagesByHierarchy(providerId).ToList();
                return Json(new
                    {
                        Success = true,
                        TotalCount = deliveryTemplateList.ToList().Count,
                        Data = deliveryTemplateList,
                        DeviceGroups = deviceGroupsList,
                        languages = languageList,
                        IsEnterprises = rEnterpriseAdmin,
                        IsSysAdmin = rSystemAdmin,
                        IsVirtualSysAdmin = rVirtualSystemAdmin,
                        IsOperator = operatorId,
                        ContextProvider = providerId,
                        Serverity = localizedseverityData
                    });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Scenario_Error_LoadingScenarioDetail });
            }
        }
        /// <summary>
        /// To Save Delivery Template data along with customer image
        /// </summary>
        /// <param name="templateData"></param>
        /// <returns>JsonResult- returns true or false</returns>

        [HttpPost]
        [ValidateInput(false)]
        public JsonResult SaveTemplate(TemplateDetailsModel templateData)
        {
            var error = string.Empty;
            var result = false;
            var providerId = RuntimeContext.ProviderId;
            var currentUserId = RuntimeContext.OperatorId;
            var strErrorMessage = "";

            try
            {

                
                // Template name validation
                if (_deliveryFacade.IsValidTemplateName(templateData, ref strErrorMessage))
                {
                    error = strErrorMessage;
                    return Json(new { Success = false, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }), ReturnType = 1 });
                }
                // Common name validation
                if (_deliveryFacade.IsValidCommonName(templateData))
                {
                    error = IWSResources.DeliveryTemplate_Common_Name_AlreadyExists;
                    return Json(new { Success = false, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }), ReturnType = 2 });
                }

                // Xslt validation                
                if (!_deliveryFacade.IsValidXslt(templateData, templateData.templateDefinition))
                {
                    error = IWSResources.DeliveryTemplate_XSLT_Valid;
                    return Json(new { Success = false, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }), ReturnType = 3 });
                }
                // if common name is valid then proceed for save
                templateData.updatedBy = Convert.ToString(currentUserId);
                templateData.providerId = providerId;
                templateData.operatorId = currentUserId;

                if (templateData.imageData != null)
                {

                    byte[] myByteArray = Convert.FromBase64String(templateData.imageData);
                    MemoryStream mMediaData = new MemoryStream(myByteArray);
                    if (!FileMimeTypeValidation.ValidateMimeType(mMediaData, FileType.Image))
                    {
                        return
                            Json(
                                new
                                {
                                    Success = false,
                                    HasErrors = true,
                                    Messages= new Messages(new Message { Type = MessageType.Error, Value = IWSResources.MimeType_File_Exception })
                                });
                    }
                    else
                    {
                        mMediaData.Position = 0;
                        var wMediaInfo = new MediaInfo
                        {
                            Source = Constants.WebSource,
                            Description = "",
                            AllowWebAccess = true,
                            ContentType = templateData.imageType,
                            ContentLength = mMediaData.Length,
                            Extension = templateData.imageExtension,
                            Height = 0,
                            Width = 0,
                            Rotation = 0
                        };
                        // image is attached with request then execute below method or else proceed with else statement
                        result = _deliveryFacade.SaveTemplateWithImageData(mMediaData, wMediaInfo, templateData);
                    }
                }
                else
                {

                    result = _deliveryFacade.SaveDeliveryTemplateData(templateData);
                }

                _deviceOptionCache.Clear(providerId);
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = result, Error = IWSResources.SystemSettings_InvalidSave }, "text/plain");
            }

            return Json(new { Success = result, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }) });
        }

        /// <summary>
        /// To Save Notifier Template data along with customer image
        /// </summary>
        /// <param name="formData"></param>
        /// <returns>JsonResult- returns true or false</returns>



        /// <summary>
        /// To Delete Delivery Template data
        /// </summary>        
        /// <param name="templateIds">DeliveryTemplateModel</param>
        /// <returns>JsonResult- returns true or false</returns>
        [HttpPost]
        public JsonResult DeleteDeliveryTemplate(List<DeliveryTemplateModel> templateIds)
        {
            var blResult = false;
            try
            {
                var providerId = RuntimeContext.ProviderId;
                var operatorId = RuntimeContext.OperatorId;
                blResult = _deliveryFacade.DeleteDeliveryTemplate(templateIds, providerId, operatorId);

                _deviceOptionCache.Clear(providerId);
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = blResult, Error = IWSResources.SystemSettings_InvalidSave }, "text/plain");
            }

            return Json(new { Success = blResult });
        }
        /// <summary>
        ///  To get selected delivery template data 
        /// </summary>
        /// <param name="templateId"></param>
        /// <returns>JsonResult- Template data</returns>
        [HttpPost]
        public JsonResult GetDeliveryTemplateDetails(int templateId)
        {
            var error = string.Empty;
            var providerId = RuntimeContext.ProviderId;
            try
            {
                var data = _deliveryFacade.GetTemplateDetails(templateId, providerId,RuntimeContext.Provider.BaseLocale, false);
                // to get user name from User facade
                var userInfo = _userFacade.GetUserBySpec(new UserSpec { OperatorId = (!string.IsNullOrEmpty(data.createdBy)) ? Convert.ToInt32(data.createdBy) : 0, UserId = (!string.IsNullOrEmpty(data.createdBy)) ? Convert.ToInt32(data.createdBy) : 0, GetUserAttributes = false });
                if (userInfo != null)
                    data.createdBy = userInfo.UserName;
                if (!(string.IsNullOrEmpty(data.updatedBy)))
                {
                    var userInfoUpdated = _userFacade.GetUserBySpec(new UserSpec { OperatorId = (!string.IsNullOrEmpty(data.updatedBy)) ? Convert.ToInt32(data.updatedBy) : 0, UserId = (!string.IsNullOrEmpty(data.updatedBy)) ? Convert.ToInt32(data.updatedBy) : 0, GetUserAttributes = false });
                    if (userInfoUpdated != null)
                        data.updatedBy = userInfoUpdated.UserName;
                }
                else
                {
                    data.updatedBy = string.Empty;

                }
                // get dropdown list 
                var desktopFormatModel = SettingsHelper.GetDesktopFormatModel();
                desktopFormatModel.SeverityList = _globalEntityLocaleFacade.GetLocalizedEntity(SettingsHelper.Severities(), data.LocaleCode);
                var languageList = _languageFacade.GetDeliveryEnabledLanguages(providerId).ToList();
                return Json(new { Data = data, formatModel=desktopFormatModel, languages=languageList, Success = true, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }) });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Error = IWSResources.SystemSettings_InvalidSave }, "text/plain");
            }



        }
        /// <summary>
        /// To Duplicate Delivery Template data
        /// </summary>        
        /// <param name="templateIds">DeliveryTemplateModel</param>
        /// <returns>JsonResult- returns true or false</returns>
        [HttpPost]
        public JsonResult DuplicateDeliveryTemplate(List<DeliveryTemplateModel> templateIds)
        {
            var blResult = false;
            try
            {
                var providerId = RuntimeContext.ProviderId;
                var operatorId = RuntimeContext.OperatorId;
                var localeCode = RuntimeContext.Provider.BaseLocale;
                blResult = _deliveryFacade.DuplicateDeliveryTemplate(templateIds, providerId, operatorId, localeCode);

                _deviceOptionCache.Clear(providerId);
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = blResult, Error = IWSResources.SystemSettings_InvalidSave }, "text/plain");
            }

            return Json(new { Success = blResult });

        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="templateData"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult EmailTemplatePreview(TemplateDetailsModel templateData)
        {
            try
            {
                var preview = new GenerateDesktopPreview();
                //AtRendering related to standard
                var localizedeSeverity = _globalEntityLocaleFacade.GetLocalizedValue(templateData.Severity, BusinessEntity.Severity, "Name", templateData.LocaleCode);
                var returnHtml = preview.GenerateEmailReview(templateData.templateDefinition, string.Empty, RuntimeContext.Provider.DisplayName, localizedeSeverity, templateData.LocaleCode);
                var jsonResult = Json(new { Success = true, data = returnHtml }, JsonRequestBehavior.AllowGet);
                jsonResult.MaxJsonLength = int.MaxValue;
                return jsonResult;

            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Error = IWSResources.SystemSettings_InvalidSave }, "text/plain");
            }

        }
        /// <summary>
        /// To Render Desktop Delivery Template Preview data
        /// </summary>        
        /// <param name="templateData">NotifierTemplateModel</param>
        /// <returns>JsonResult- returns HTML</returns>
        [HttpPost]

        public JsonResult DesktopTemplatePreview(TemplateDetailsModel templateData)
        {
            try
            {
                var preview = new GenerateDesktopPreview();
                templateData.IsPreview = true;
                //AtRendering related to standard

               var localizedeSeverity = _globalEntityLocaleFacade.GetLocalizedValue(templateData.Severity, BusinessEntity.Severity, "Name", templateData.LocaleCode);
                if (templateData.imageData != null)
                    templateData.templateDefinition = _deliveryFacade.GetTemplateDefinition(templateData, RuntimeContext.ProviderId, templateData.imgOption == "SYSTEM" ? string.Empty : templateData.imageData);
                else
                    templateData.templateDefinition = _deliveryFacade.GetTemplateDefinition(templateData, RuntimeContext.ProviderId, string.Empty);

                var returnHtml = preview.GenerateDesktopReview(templateData.templateDefinition, string.Empty, RuntimeContext.Provider.ProviderName, localizedeSeverity, templateData.LocaleCode);
                
                var jsonResult = Json(new { Success = true, data = returnHtml }, JsonRequestBehavior.AllowGet);
                jsonResult.MaxJsonLength = int.MaxValue;
                return jsonResult;

            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Error = IWSResources.SystemSettings_InvalidSave }, "text/plain");
            }

        }

        /// <summary>
        /// To Create Template
        /// </summary>        
        /// <param name="templateData">CreateTemplate</param>
        /// <returns>JsonResult- returns true or false</returns>
        /// 
        /// 
        [HttpPost]
        [ValidateInput(false)]
        public JsonResult CreateTemplate(TemplateDetailsModel templateData)
        {
            string error = string.Empty;
            var result = false;
            try
            {
                var providerId = RuntimeContext.ProviderId;
                var operatorId = RuntimeContext.OperatorId;
                templateData.providerId = providerId;
                templateData.operatorId = operatorId;
                templateData.createdBy = Convert.ToString((operatorId));
                 var strErrorMessage = "";
                // Common name validation
                 if (_deliveryFacade.IsValidTemplateName(templateData, ref strErrorMessage))
                {
                    error = strErrorMessage;
                    return Json(new { Success = false, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }), ReturnType = 1 });
                }
                // Common name validation
                if (_deliveryFacade.IsValidCommonName(templateData))
                {
                    error = IWSResources.DeliveryTemplate_Common_Name_AlreadyExists;
                    return Json(new { Success = false, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }), ReturnType = 2 });
                }
                // Xslt validation
                if (!_deliveryFacade.IsValidXslt(templateData, templateData.templateDefinition))
                {
                    error = IWSResources.DeliveryTemplate_XSLT_Valid;
                    return Json(new { Success = false, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }), ReturnType = 3 });
                }

                if (templateData.imageData != null)
                {

                    byte[] myByteArray = Convert.FromBase64String(templateData.imageData);
                    MemoryStream mMediaData = new MemoryStream(myByteArray);
                    if (!FileMimeTypeValidation.ValidateMimeType(mMediaData, FileType.Image))
                    {
                        return
                            Json(
                                new
                                {
                                    Success = false,
                                    HasErrors = true,
                                    Messages = new Messages(new Message { Type = MessageType.Error, Value = IWSResources.MimeType_File_Exception })
                                });
                    }
                    else
                    {
                        mMediaData.Position = 0;
                        var wMediaInfo = new MediaInfo
                        {
                            Source = Constants.WebSource,
                            Description = "",
                            AllowWebAccess = true,
                            ContentType = templateData.imageType,
                            ContentLength = mMediaData.Length,
                            Extension = templateData.imageExtension,
                            Height = 0,
                            Width = 0,
                            Rotation = 0
                        };
                        // image is attached with request then execute below method or else proceed with else statement
                        result = _deliveryFacade.SaveTemplateWithImageData(mMediaData, wMediaInfo, templateData);
                    }
                }
                else
                {

                    result = _deliveryFacade.CreateDeliveryTemplate(templateData, providerId, operatorId);
                }

                _deviceOptionCache.Clear(providerId);
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = result, Error = IWSResources.SystemSettings_InvalidSave }, "text/plain");
            }

            return Json(new { Success = result, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }) });
        }

        /// <summary>
        /// To Create Template Style Sheet
        /// </summary>        
        /// <param name="deviceId">GetTemplateStyleSheet</param>
        /// <returns>JsonResult- returns true or false</returns>
        /// 
        ///
        [HttpPost]
        public JsonResult GetTemplateStyleSheet(int deviceId)
        {
            string error = string.Empty;
            TemplateDetailsModel data;
            var providerId = RuntimeContext.ProviderId;
            try
            {
                data = _deliveryFacade.GetTemplateStyleSheet(deviceId, providerId, RuntimeContext.Provider.BaseLocale);
                var desktopFormatModel = SettingsHelper.GetDesktopFormatModel();
                desktopFormatModel.SeverityList = _globalEntityLocaleFacade.GetLocalizedEntity(SettingsHelper.Severities(), RuntimeContext.Provider.BaseLocale);
                var languageList = _languageFacade.GetDeliveryEnabledLanguages(providerId).ToList();
                data.LocaleCode = RuntimeContext.Provider.BaseLocale;
                return Json(new { Data = data, formatModel = desktopFormatModel, languages=languageList, Success = true, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }) });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Error = IWSResources.SystemSettings_InvalidSave }, "text/plain");
            }

          

        }

        [HttpPost]
        public JsonResult GetTemplateStyleSheetByRegion(int deviceId,string locale)
        {
            string error = string.Empty;
            var providerId = RuntimeContext.ProviderId;
            try
            {
               var  data = _deliveryFacade.GetTemplateStyleSheet(deviceId, providerId, locale);
               return Json(new { Data = data, Success = true, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }) });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Error = IWSResources.SystemSettings_InvalidSave }, "text/plain");
            }
        }

        [HttpPost]
        public JsonResult GetImageString(FormCollection image)
        {
            byte[] imageBytes = null;
            var fileData = Request.Files[0];
            if (!FileMimeTypeValidation.ValidateMimeType(fileData.InputStream, FileType.Image))
            {
                return
                    Json(
                        new
                        {
                            data = "",
                            extension = "error",
                            HasErrors = true,
                            Messages =
                                new Messages(new Message
                                {
                                    Type = MessageType.Error,
                                    Value = IWSResources.MimeType_File_Exception
                                }),
                            type = "",
                            Success = false
                        }, "text/plain");
            }
            fileData.InputStream.Position = 0;
            System.IO.BinaryReader reader = new System.IO.BinaryReader(fileData.InputStream);
            imageBytes = reader.ReadBytes((int)fileData.ContentLength);
            var data = Convert.ToBase64String(imageBytes);
            var extension = fileData.FileName.Substring(fileData.FileName.LastIndexOf('.') + 1);

            return Json(new { data = data, extension = extension, type = fileData.ContentType, Success = true }, "text/plain");

        }

        [HttpGet]
        public JsonResult GetSeverityList()
        {

            var data = _globalEntityLocaleFacade.GetLocalizedEntity(SettingsHelper.Severities(), RuntimeContext.Provider.BaseLocale)
                                    .Select(
                                         p =>
                                             new KeyValueModel
                                             {
                                                 Id = (int)(Priority)Enum.Parse(typeof(Priority), p.SeverityId),
                                                 Name = p.SeverityName
                                             }).ToList();

            return Json(new { data = data, Success = true }, JsonRequestBehavior.AllowGet);

        }

    }
}