﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Web.Filters;
using AtHoc.Global.Resources;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.Infrastructure.Log;
using AtHoc.IWS.Business.Domain.Audit;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.Infrastructure;

namespace AtHoc.IWS.Web.Areas.Settings.Controllers
{
    public class OperatorAuditTrailController : Controller
    {
        private readonly IOperatorAuditFacade _operatorAuditFacade;

        private readonly ILogService _logService;

       
        public OperatorAuditTrailController(IOperatorAuditFacade operatorAuditFacade,ILogService logService)
        {
            _operatorAuditFacade = operatorAuditFacade;
            _logService = logService;
        }

        // GET: /Settings/OperatorAuditTrail/
        [IWSAuthorize(new[] { SystemObject.ReportsSystemLog }, new ActionType[] { ActionType.Modify })]
        public ActionResult Index()
        {
            var provider = RuntimeContext.Provider;

            var vpsTimeZOne = RuntimeContext.Provider.GetVpsTimeZoneFromId();
            ViewBag.DateFormat = provider.GetDateFormat();
            ViewBag.DateTimeFormat = provider.GetDateTimeFormat();
            ViewBag.VPSTimeZone = vpsTimeZOne;
            ViewBag.UtcOffsetInMinutes = vpsTimeZOne.BaseUtcOffset.TotalMinutes;
            ViewBag.VPSOffsetFromSystemInMinutes = provider.VPSOffsetFromSystemInMinutes();
            ViewBag.SupportsDaylightSavingTime = vpsTimeZOne.SupportsDaylightSavingTime;
            ViewBag.CurrentDateTime = provider.CurrentSystemTimeToVps().ToString(System.Globalization.CultureInfo.InvariantCulture);
            ViewBag.CurrentTime = DateTime.Now;
            ViewBag.Yesterday = provider.CurrentSystemTimeToVps().AddDays(-1).ToString(System.Globalization.CultureInfo.InvariantCulture);
            return View();
        }
        /// <summary>
        ///  Get enttities
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public JsonResult GetEntities()
        {
            try
            {
                var entities = _operatorAuditFacade.GetAuditEntities();
                return Json(new
                {
                    Success = true,
                    Data = entities
                },JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Message = ex.Message },JsonRequestBehavior.AllowGet);
            }
        }        
        /// <summary>
        /// Get Actions by EntityId
        /// </summary>
        /// <param name="entityId"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult GetActions(string entityId)
        {
            try
            {
                var actions = _operatorAuditFacade.GetAuditActionsByEntityId(entityId);

                return Json(new
                {
                    Success = true,
                    Data = actions
                },JsonRequestBehavior.AllowGet);
            }
            catch(Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success=false, Message=ex.Message },JsonRequestBehavior.AllowGet);            
            }
        }
        /// <summary>
        /// Get audit data, written as common function for download excel, printer friendly report and grid
        /// </summary>
        /// <param name="operatorName"></param>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <param name="entityId"></param>
        /// <param name="actionId"></param>
        /// <returns></returns>
        private List<OperatorAuditModel> GetAuditData(string operatorName, string fromDate, string toDate, string entityId, string actionId) 
        {
            var providerId = RuntimeContext.ProviderId;
            if (!string.IsNullOrEmpty(fromDate))
                fromDate = RuntimeContext.Provider.VpsToSystemTime(System.Convert.ToDateTime(fromDate)).ToString();

            if (!string.IsNullOrEmpty(toDate))
                toDate = RuntimeContext.Provider.VpsToSystemTime(System.Convert.ToDateTime(toDate)).ToString();

            var auditData = _operatorAuditFacade.GetOperatorAuditDetails(providerId, operatorName, fromDate, toDate, entityId, actionId);
            return auditData.ToList();
        }
        /// <summary>
        /// Get audit data for grid
        /// </summary>
        /// <param name="operatorName"></param>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <param name="entityId"></param>
        /// <param name="actionId"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult GetOperatorAuditDetails(string operatorName, string fromDate, string toDate, string entityId, string actionId)
        {
            try 
            {
                var result = new List<object>();
                var auditData = GetAuditData(operatorName, fromDate, toDate, entityId, actionId);
                auditData.ForEach(o => result.Add(new
                {
                    Action_TimeStamp_Display = RuntimeContext.Provider.SystemToVpsDateTimeFormated(o.Action_TimeStamp),
                    Action_TimeStamp = o.Action_TimeStamp,
                    provider_id = o.Provider_Id,
                    UserName = o.UserName,
                    UserId = o.User_Id,
                    Action_Name = o.Action_Name,
                    Entity_Name = o.Entity_Name,
                    Object_Name = o.Object_Name,
                    Object_Id = o.Object_Id,
                    Client_IP = o.Client_IP,
                    Source = o.Source,
                    Server_Name = o.Server_Name,
                    AdditionalInfo = o.Additional_Info,
                    entityId = o.Entity_Id,
                    FromEntity_Id = string.Empty,
                    FromEntity_Name = string.Empty,
                    FromObject_Id = string.Empty,
                    FromObject_Name = string.Empty
                }));
                 var jsonResult = Json(new
                {
                    Success = true,
                    Data = result,
                }, JsonRequestBehavior.AllowGet);

                jsonResult.MaxJsonLength = int.MaxValue;
                return jsonResult;


            }
            catch(Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Message = ex.Message }, JsonRequestBehavior.AllowGet);  
            }
        }
        public bool ValidateParameters(string fromDate, string toDate, string entityId, string actionId)
        {
            var flag = false;
            var blnActionId = true;
            DateTime parseFrmDate;
            DateTime parseToDate;
            var blnFrmDate = DateTime.TryParse(fromDate, out parseFrmDate);
            var blnToDate = DateTime.TryParse(toDate, out parseToDate);
            var objectEntity = _operatorAuditFacade.GetAuditActionsByEntityId(entityId).ToList();
            var blnEntityType = objectEntity.Any();

            if (blnEntityType)
            {
                var actionIds = actionId.Split(',').ToList();
                if (actionIds.Count > 0)
                    blnActionId = objectEntity.Count(e => actionIds.Contains(e.ActionId)) == actionIds.Count;
            }
            else
                blnEntityType = entityId.Equals("0");
            if (blnEntityType && blnActionId && blnFrmDate && blnToDate)
                flag = true;
            return flag;
        }
        /// <summary>
        /// Get data for printer friendly report
        /// </summary>
        /// <param name="operatorName"></param>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <param name="entityId"></param>
        /// <param name="actionId"></param>
        /// <param name="entityName"></param>
        /// <param name="actions"></param>
        /// <returns></returns>
        public ActionResult AuditPrintReport(string operatorName, string fromDate, string toDate, string entityId, string actionId,string entityName,string actions)
        {
            var auditData = GetAuditData(operatorName, fromDate, toDate, entityId, actionId);
            ViewBag.InformationBanner = RuntimeContext.Provider.ExtendedParams.InformationBanner;
            ViewBag.ProviderName = RuntimeContext.Provider.ProviderName;
            ViewBag.ProductName = IWSResources.Settings_Audit_ProductName;
            ViewBag.OperatorName = operatorName;
            ViewBag.FromDate = RuntimeContext.Provider.SystemToVpsTime(System.Convert.ToDateTime(fromDate)).ToString(RuntimeContext.Provider.GetDateFormat());
            ViewBag.ToDate = RuntimeContext.Provider.SystemToVpsTime(System.Convert.ToDateTime(toDate)).ToString(RuntimeContext.Provider.GetDateFormat());
            ViewBag.EntityName = entityName;
            ViewBag.Actions = actions.Trim(',');

            return View(auditData);
        }

	}
}