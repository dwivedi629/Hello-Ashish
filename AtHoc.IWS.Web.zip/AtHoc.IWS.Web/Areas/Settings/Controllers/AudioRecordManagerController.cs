﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Web.Mvc;
using AtHoc.Infrastructure.Log;
using AtHoc.Systems;
using Microsoft.VisualBasic.Devices;
using AtHoc.IWS.Business.Context;


namespace AtHoc.IWS.Web.Areas.Settings.Controllers
{
    public class AudioRecordManagerController : Controller
    {
        private readonly ILogService _logService;

        [DllImport("winmm.dll", EntryPoint = "mciSendStringA", CharSet = CharSet.Ansi, SetLastError = true, ExactSpelling = true)]
        private static extern int mciSendString(string lpstrCommand, string lpstrReturnString, int uReturnLength, int hwndCallback);

        public AudioRecordManagerController(ILogService logService)
        {
            _logService = logService;

        }
        public ActionResult Index()
        {
            ViewBag.ProviderId = RuntimeContext.ProviderId;
            return View();
        }


        public ActionResult RecordAudio(int alertId, int operatorId)
        {

            try
            {
                string uniqueName = alertId + "_" + operatorId;

                mciSendString("stop recsound", "", 0, 0);
                mciSendString("close recsound", "", 0, 0);
                mciSendString("open new Type waveaudio Alias recsound", "", 0, 0);
                mciSendString("record recsound", "", 0, 0);

                return Json(new
                {
                    Success = true,
                });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = ex.Message });
            }

        }


        public ActionResult StopAudio(int alertId, int operatorId)
        {
            try
            {
                string uniqueName = alertId + "_" + operatorId;

               // var fileName = string.Concat(AtHocSystem.Local.DirPathApplication, "\\wwwroot\\", "\\RecordedFiles\\" + uniqueName + ".wav");

                //var wavfilename = @"D:\RecordedFiles\1_11.wav";
                var wavfilename = @"C:\RecordedFiles\" + uniqueName + ".wav";
                wavfilename = wavfilename.Replace("/", "\\");
                mciSendString("stop recsound", "", 0, 0);
                var result = mciSendString("save recsound \"" + wavfilename + "\"", "", 0, 0);
                mciSendString("close recsound", "", 0, 0);
                byte[] data = System.IO.File.ReadAllBytes(wavfilename);
                string base64 = Convert.ToBase64String(data);
                return Json(new
                {
                    Success = true,
                    audioData = base64
                });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = ex.Message });
            }
        }

    }
}