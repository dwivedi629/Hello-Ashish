﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Web.Mvc;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Resources;
using AtHoc.IWS.Business;
using AtHoc.IWS.Business.Context;
using AtHoc.Global.Resources;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Web.Filters;
using AtHoc.MediaServices;
using AtHoc.IWS.Business.Domain.Settings.Impl;
using AtHoc.IWS.Business.Domain.Authorization;
using Microsoft.Owin.Security.Provider;
using AtHoc.IWS.Business.Domain.Users;


namespace AtHoc.IWS.Web.Areas.Settings.Controllers
{

    public class IntegrationManagerController : Controller
    {

        private readonly IAgentFacade _agentManagerFacade;
        private readonly ILogService _logService;
        private readonly IAuthFacade _authFacade;
        private readonly IUserFacade _userFacade;
        private readonly IOperatorFacade _operatorFacade;

        public IntegrationManagerController(IAgentFacade agentManagerFacade, ILogService logService, IAuthFacade authFacade, IUserFacade userFacade, IOperatorFacade operatorFacade)
        {
            _agentManagerFacade = agentManagerFacade;
            _logService = logService;
            _authFacade = authFacade;
            _userFacade = userFacade;
            _operatorFacade = operatorFacade;

        }

        [IWSAuthorize(new SystemObject[] { SystemObject.VirtualSystemAgents }, new ActionType[] { ActionType.Modify })]
        public ActionResult Index()
        {
            var provider = RuntimeContext.Provider; 
            ViewBag.DateFormat = provider.GetDateFormat();
            ViewBag.DateTimeFormat = provider.GetDateTimeFormat();
            return View();
        }

        /// <summary>
        /// To get all Agent Details as per search criteria
        /// </summary>
        /// <param name="criteriaSpec">AgentCriteria</param>
        /// <returns>Json result- List of all Agent Details Objects</returns>
        /// 

        [HttpPost]
        public JsonResult GetAgentDetails(AgentCriteria criteriaSpec)
        {
            try
            {
                var providerId = RuntimeContext.ProviderId;
                var operatorId = RuntimeContext.OperatorId;
                criteriaSpec.ProviderId = providerId;
                criteriaSpec.OperatorId = operatorId;

                var agentList = _agentManagerFacade.GetAgentDetails(
                    criteriaSpec, 
                    RuntimeContext.Provider.BaseLocale).Select(p => new { p.agentId, p.agentName, p.agentcommonName, p.agentType, p.engineId, p.engineLocationId, p.agentowner, p.providerId, p.IsChecked, p.IsOwner,p.channelpreferencesURL,p.metastore, agentUpdatedOn= RuntimeContext.Provider.SystemToVpsTime(DateTimeConverter.GetDateTimeFromSeconds(p.updatedOn))}).ToList();

                var systemUser = _operatorFacade.GetUser(new SystemUserSpec { ProviderId = providerId, OperatorId = operatorId });
                var rEnterpriseAdmin = systemUser.Roles.Where(e => e.RoleId == (int)Roles.EnterpriseAdmin).Count() > 0 ? true : false;
                var rSystemAdmin = systemUser.Roles.Where(e => e.RoleId == (int)Roles.SystemAdmin).Count() > 0 ? true : false;
                var rVirtualSystemAdmin = systemUser.Roles.Where(e => e.RoleId == (int)Roles.Administrator).Count() > 0 ? true : false;


                return Json(new
                {
                    Success = true,
                    TotalCount = agentList.ToList().Count,
                    Data = agentList,
                    IsEnterprises = rEnterpriseAdmin,
                    IsSysAdmin = rSystemAdmin,
                    IsVirtualSysAdmin = rVirtualSystemAdmin,
                    IsOperator = operatorId,
                    ContextProvider = providerId,
                });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Scenario_Error_LoadingScenarioDetail });
            }

        }
        /// <summary>
        ///  To get selected Agent Details data 
        /// </summary>
        /// <param name="templateId"></param>
        /// <returns>JsonResult- Agent Details data</returns>
        [HttpPost]
        public JsonResult GetAgentManagerDetails(int AgentId)
        {
            var error = string.Empty;
            var provider = RuntimeContext.Provider;
            var currentUser = RuntimeContext.Operator;
            try
            {
                var data = _agentManagerFacade.GetAgentManagerDetails(AgentId, RuntimeContext.Provider.BaseLocale);
                //set providerId, if its null
                if(data.providerId==null)
                    data.providerId = RuntimeContext.ProviderId; 
                // to get user name from User facade
                var userInfo = _userFacade.GetUserBySpec(new UserSpec { OperatorId = (data.createdBy > 0) ? Convert.ToInt32(data.createdBy) : 0, UserId = (data.createdBy > 0) ? Convert.ToInt32(data.createdBy) : 0, GetUserAttributes = false });
                if (userInfo != null)
                    data.CreatedByUsername = userInfo.UserName;
                if (data.updatedBy > 0)
                {
                    var userInfoUpdated = _userFacade.GetUserBySpec(new UserSpec { OperatorId = (data.updatedBy > 0) ? Convert.ToInt32(data.updatedBy) : 0, UserId = (data.updatedBy > 0) ? Convert.ToInt32(data.updatedBy) : 0, GetUserAttributes = false });
                    if (userInfoUpdated != null)
                        data.UpdatedByUsername = userInfoUpdated.UserName;
                }
                else
                    data.UpdatedByUsername = (data.updatedOn.HasValue) ? data.CreatedByUsername : string.Empty;

                

                data.UpdatedByDate = (data.updatedOn.HasValue) ? provider.GetVpsDateTimeFromSecondsFormated(data.updatedOn.Value) : string.Empty;
                data.CreatedByDate = (data.createdOn.HasValue) ? provider.GetVpsDateTimeFromSecondsFormated(data.createdOn.Value) : string.Empty;


                return Json(new { Data = data, Success = true, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }) });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Error = IWSResources.SystemSettings_InvalidSave }, "text/plain");
            }



        }
        /// <summary>
        /// To Delete Delivery Template data
        /// </summary>        
        /// <param name="templateIds">DeliveryTemplateModel</param>
        /// <returns>JsonResult- returns true or false</returns>
        [HttpPost]
        public JsonResult DeleteAgentManagerDetails(AgentCriteria criteriaSpec)
        {
            var blResult = false;
            try
            {
                var providerId = RuntimeContext.ProviderId;
                var operatorId = RuntimeContext.OperatorId;
                criteriaSpec.ProviderId = providerId;
                blResult = _agentManagerFacade.DeleteAgentManagerDetails(criteriaSpec, operatorId);
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = blResult, Error = IWSResources.SystemSettings_InvalidSave }, "text/plain");
            }

            return Json(new { Success = blResult });
        }

        /// <summary>
        /// This method will check the agent id is associated with any channels or not
        /// </summary>
        /// <returns>bool</returns>
        [HttpPost]
        public JsonResult IsAgentAssociated(string strAgentIds)
        {
            List<int> agentIds = null;
            if (!string.IsNullOrWhiteSpace(strAgentIds))
            {
                agentIds = strAgentIds.Split(',').Select(Int32.Parse).ToList();
                agentIds = _agentManagerFacade.IsAgentAssociated(agentIds);
            }

            return Json(new { Success = agentIds }, "text/plain");
        }

        [HttpPost]
        [ValidateInput(false)]
        public JsonResult SaveAgentDetails(AgentSettings AgentData)
        {
            var error = string.Empty;
            var result = false;
            var providerId = RuntimeContext.ProviderId;
            var currentUserId = RuntimeContext.OperatorId;
            try
            {

                /// Common name validation
                if (_agentManagerFacade.IsValidCommonName(providerId, AgentData.agentId, AgentData.agentcommonName))
                {
                    error = IWSResources.Settings_AgentManager_DuplicateAgentName;
                    return Json(new { Success = false, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }), ReturnType = 1 });
                }
                else
                {
                    if (AgentData.agentId == 0)
                    {
                        AgentData.createdBy = currentUserId;
                        AgentData.agentType = "AMC";
                        AgentData.engineId = "DEFAULT";
                        AgentData.engineLocationId = "SERVER";
                        AgentData.providerId = providerId;
                        AgentData.updatedBy = currentUserId;
                    }
                    else
                    {
                        AgentData.updatedBy = currentUserId;
                        AgentData.providerId = providerId;
                    }
                    AgentData.operatorId = currentUserId;
                    AgentData.agentName = AgentData.agentName.Trim();
                    result = _agentManagerFacade.SaveAgentData(AgentData);
                }

            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = result, Error = IWSResources.SystemSettings_InvalidSave }, "text/plain");
            }

            return Json(new { Success = result, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }) });
        }

    }
}