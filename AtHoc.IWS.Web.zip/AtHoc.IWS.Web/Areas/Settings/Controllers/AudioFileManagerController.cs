﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using AtHoc.Global.Resources.Interfaces;
using AtHoc.Infrastructure.Security;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Resources;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.SSA.Business.Facades;
using AtHoc.IWS.Web.Helpers;
using AtHoc.Global.Resources;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Settings.Model;


namespace AtHoc.IWS.Web.Areas.Settings.Controllers
{
    public class AudioFileManagerController : Controller
    {

        private readonly IAudioFileFacade _audioFileFacade;
        private readonly ILogService _logService;
        private readonly ILanguageFacade _languageFacade;
        private readonly IGlobalEntityLocaleFacade _globalEntityLocaleFacade;

        public AudioFileManagerController(IAudioFileFacade audioFileFacade, ILogService logService, ILanguageFacade languageFacade, IGlobalEntityLocaleFacade globalEntityLocaleFacade)
        {
            _audioFileFacade = audioFileFacade;
            _logService = logService;
            _languageFacade = languageFacade;
            _globalEntityLocaleFacade = globalEntityLocaleFacade;
        }

        //
        // GET: /Settings/AudioFileManager/
        public ActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// Get audio files 
        /// </summary>
        /// <param name="criteria">AudioSearchCriteria</param>
        /// <returns>List of audio files</returns>
        [HttpPost]
        public JsonResult GetAudioFiles(AudioSearchCriteria criteria)
        {

            var providerId = RuntimeContext.ProviderId;
            var currentUser = RuntimeContext.Operator;
            criteria.ProviderId = providerId;
            criteria.UserId = currentUser.Id;
            criteria.Locale = RuntimeContext.Provider.BaseLocale;
            var languageList = new List<Language>();
            var defaultSeverties = new List<AudioDefaultSeverities>();
            var localizedseverityData = new List<Web.Models.Publishing.SeverityModel>();
            var returnFlag = false;
            try
            {
                if (criteria.SearchString[0] != string.Empty)
                {
                    returnFlag = criteria.SearchString.Length > 0 &&
                                 ValidateName(String.Join(",", criteria.SearchString.ToArray()));
                }
                if(returnFlag)
                    criteria.SearchString =new string[]{};
                
                    var  audioFileList =
                        _audioFileFacade.GetAudioList(criteria)
                            .ToList()
                            .Select(
                                p =>
                                    new
                                    {
                                        AudioId = p.Audio_Id,
                                        AudioName = HttpUtility.HtmlEncode(p.Audio_Name),
                                        Description = p.Description,
                                        AudioType = p.Audio_Type,
                                        AudioCommonName = p.Audio_Common_Name,
                                        AudioScope = p.Audio_Scope,
                                        AudioOwner = p.Provider_Id != criteria.ProviderId,
                                        AudioSize = ((byte[]) p.Audio_Blob).Length/1024,
                                        Severity = p.Severity,
                                        DefaultSeverity = p.Default_Severity,
                                        Locale = p.Locale_Code,
                                        IsChecked = false,
                                        ActualDefaultSeverity = p.Actual_Default_Severity,
                                        providerId = p.Provider_Id
                                    });
                    languageList = _languageFacade.GetDeliveryEnabledLanguages(providerId).ToList();
                    defaultSeverties = _audioFileFacade.GetDefaultAudioSeverityData(providerId);
                    localizedseverityData = _globalEntityLocaleFacade.GetLocalizedEntity(SettingsHelper.Severities(),
                        RuntimeContext.Provider.BaseLocale);

                    return Json(new
                    {
                        Success = (!returnFlag),
                        TotalCount = audioFileList.ToList().Count,
                        Data = audioFileList,
                        SeverityList = localizedseverityData,
                        languages = languageList,
                        defaultSeverties = defaultSeverties.ToList(),
                        ContextProvider = providerId
                    });                
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = ex.Message });
            }
           
        }

        /// <summary>
        /// Saving audio file
        /// </summary>
        /// <param name="audioName">Audio Name</param>
        /// <param name="description">Audio Description</param>
        /// <param name="uploadFile">Uploaded wav file</param>
        /// <returns>status of save</returns>
        [HttpPost]
        public JsonResult SaveAudioFile(string audioName, string description, string severity, string defaultseverity, string locale)
        {
            string error = string.Empty;
            bool result = false;
            int audioId = 0;
            try
            {
                if (!ValidateName(audioName))
                {
                    var providerId = RuntimeContext.ProviderId;
                    var operatorId = RuntimeContext.OperatorId;
                    var uploadFile = Request.Files[0];
                    //System.Web.Script.Serialization.JavaScriptSerializer js = new System.Web.Script.Serialization.JavaScriptSerializer();
                    //var templateData = js.Deserialize<NotifierTemplateModel>(formData["templateData"]);

                    if (uploadFile != null && (uploadFile.ContentLength > 0) && !string.IsNullOrEmpty(uploadFile.FileName) && 
                        FileMimeTypeValidation.ValidateMimeType(uploadFile.InputStream, FileType.Audio))
                    {
                        uploadFile.InputStream.Position = 0;
                        AudioFileSettingsModel audioFile = new AudioFileSettingsModel();
                        audioFile.AudioName = audioName;
                        audioFile.AudioCommonName = System.Text.RegularExpressions.Regex.Replace(audioName, @"\s+", "-");
                        audioFile.Description = description;
                        audioFile.ProviderId = providerId;
                        audioFile.Severity = severity;

                        audioFile.DefaultSeverity = (defaultseverity == "true" ? "Y" : "N");
                        audioFile.Locale = locale;

                        byte[] fileBytes = new byte[uploadFile.ContentLength];
                        uploadFile.InputStream.Read(fileBytes, 0, Convert.ToInt32(uploadFile.ContentLength));
                        audioFile.AudioBlob = fileBytes;

                        if (!_audioFileFacade.IsAudioNameExists(audioFile))
                        {
                            audioId = _audioFileFacade.SaveAudioFileData(audioFile, operatorId);
                            result = true;
                        }
                        else
                            error = IWSResources.Settings_AudioFile_AlreadySave;
                    }
                    else
                    {
                        error = IWSResources.MimeType_File_Exception;
                        result = false;
                    }
                }
                else
                {
                    error = IWSResources.Settings_AudioFile_NamePattern;
                }
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                error = IWSResources.Settings_AudioFile_InvalidSave;
                return Json(new { Success = false, audioId = audioId, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }) }, "text/plain");
            }

            return Json(new { Success = result, AudioId = audioId, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }) }, "text/plain");

        }

        /// <summary>
        /// Validate the HTML special characters (/,:,*,?,",\,&lt;,&gt;) in string 
        /// </summary>
        /// <param name="inputString">Input string to Validate</param>
        /// <returns>return true if input string have HTML sepecial characters.</returns>
        private bool ValidateName(string inputString)
        {
           
            Regex regex = new Regex(@"^[^%^'^&^/^:^*^?^""^\^\^<^>^|]+$");
                Match match = regex.Match(inputString);
                return !match.Success;
        }

        /// <summary>
        /// Editing audio file
        /// </summary>
        /// <param name="audioFile">AudioFileSettingsModel</param>
        /// <returns>status of edit</returns>
        [HttpPost]
        public JsonResult EditAudioFiles(FormCollection formData)
        {
            bool blResult = false;
            string error = string.Empty;
            int sender = 0;
            // get dropdown list
            try
            {
                var js = new System.Web.Script.Serialization.JavaScriptSerializer();
                var audioFile = js.Deserialize<AudioFileSettingsModel>(formData["audioFile"]);
                var providerId = RuntimeContext.ProviderId;
                var operatorId = RuntimeContext.OperatorId;
                audioFile.ProviderId = providerId;

                if (!ValidateName(audioFile.AudioName))
                {
                    if (_audioFileFacade.IsAudioNameExists(audioFile))
                    {
                        error = IWSResources.Settings_AudioFile_AlreadySave;
                        sender = 1; // Audio File Name
                    }
                    else if (_audioFileFacade.IsAudioCommonNameExists(audioFile))
                    {
                        error = IWSResources.Settings_AudioFile_CommonNameSave;
                        sender = 2; // Common Name
                    }
                    else
                    {
                        var bflagSave = true;
                        if (Request.Files.Count > 0 && Request.Files[0] != null && Request.Files[0].ContentLength > 0)
                        {                            
                            var uploadFile = Request.Files[0];
                            if (FileMimeTypeValidation.ValidateMimeType(uploadFile.InputStream, FileType.Audio))
                            {
                                uploadFile.InputStream.Position = 0;
                                byte[] fileBytes = new byte[uploadFile.ContentLength];
                                uploadFile.InputStream.Read(fileBytes, 0, Convert.ToInt32(uploadFile.ContentLength));
                                audioFile.AudioBlob = fileBytes;    
                            }
                            else
                            {
                                error = IWSResources.MimeType_File_Exception;
                                bflagSave = false;
                            }                            
                        }
                        if (bflagSave)
                        {
                            blResult = _audioFileFacade.UpdateAudioFileData(audioFile, operatorId);
                        }
                            
                    }
                }
                else
                {
                    error = IWSResources.Settings_AudioFile_NamePattern;
                }

            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                error = IWSResources.Settings_AudioFile_InvalidUpdate;
                return Json(new {  Success = false, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }), Sender = sender }, "text/plain");
            }
            return Json(new { Success = blResult, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }), Sender = sender }, "text/plain");
        }

        /// <summary/>
        /// <summary>
        /// Editing audio data
        /// </summary>
        /// <param name="audioFile">AudioFileSettingsModel</param>
        /// <returns>status of edit</returns>
        [HttpPost]
        public JsonResult EditAudioData(AudioFileSettingsModel audioFile)
        {
            bool blResult = false;
            string error = string.Empty;
            int sender = 0;
            try
            {
                var providerId = RuntimeContext.ProviderId;
                var operatorId = RuntimeContext.OperatorId;
                audioFile.ProviderId = providerId;
                if (!ValidateName(audioFile.AudioName))
                {
                    if (_audioFileFacade.IsAudioNameExists(audioFile))
                    {
                        error = IWSResources.Settings_AudioFile_AlreadySave;
                        sender = 1; // Audio File Name
                    }
                    else if (_audioFileFacade.IsAudioCommonNameExists(audioFile))
                    {
                        error = IWSResources.Settings_AudioFile_CommonNameSave;
                        sender = 2; // Common Name
                    }
                    else
                    {
                        blResult = _audioFileFacade.UpdateAudioFileData(audioFile, operatorId);
                    }
                }
                else
                {
                    error = IWSResources.Settings_AudioFile_NamePattern;
                }

            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                error = IWSResources.Settings_AudioFile_InvalidUpdate;
                return Json(new {  Success = false, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }), Sender = sender }, "text/plain");
            }
            return Json(new {  Success = blResult, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }), Sender = sender }, "text/plain");
        }

        /// <summary>
        /// Deleting the audio files
        /// </summary>
        /// <param name="ids">List of audioids</param>
        /// <returns>Status of Delete</returns>
        [HttpPost]
        public JsonResult DeleteAudioFiles(int[] ids)
        {
            bool result = false;
            try
            {
                var providerId = RuntimeContext.ProviderId;
                var operatorId = RuntimeContext.OperatorId;
                result = _audioFileFacade.DeleteAudioFiles(ids, providerId, operatorId);
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Error = ex.Message }, "text/plain");
            }
            return Json(new { Success = result });
        }

        /// <summary>
        /// Download audio file
        /// </summary>
        /// <param name="audioId">AudioId to be downloaded</param>
        /// <param name="audioName">Audio Name</param>
        /// <returns>File content </returns>
        public FileContentResult DownloadAudioFile(int audioId, string audioName)
        {
            byte[] content = null;
            try
            {
                content = _audioFileFacade.DownloadAudioFile(audioId);
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
            }
            return File(content, System.Net.Mime.MediaTypeNames.Application.Octet, audioName);
        }
    }
}