﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using AtHoc.Infrastructure.Resources;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Business.Domain.Users.Impl;
using AtHoc.IWS.Business.Domain.Users.Impl.Search;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Map;
using AtHoc.IWS.Web.Filters;
using AtHoc.IWS.Web.Configurations.Constants;
using AtHoc.Global.Resources;
using AtHoc.IWS.Web.Converter.SearchCriteria;
using AtHoc.IWS.Web.Models.SearchCriteria;
using AtHoc.IWS.Web.Models.UserManager;
using AtHoc.IWS.Web.Helpers;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;
using AtHoc.IWS.Web.Areas.Settings.Models;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Data.SearchSpec;
using AtHoc.IWS.Business.AutoCleanupUsers;
using AtHoc.Targeting;

namespace AtHoc.IWS.Web.Areas.Settings.Controllers
{
    /// <summary>
    /// Disable/Delete End Users Implementation
    /// </summary>
    public class DisableDeleteEndUsersController : Controller
    {

        #region Private Properties/Valriables

        private readonly ICustomAttributeFacade _customAttributeFacade;
        private readonly IUserFacade _userFacade;
        private readonly IUserManagerHelper _userManagerHelper;
        private readonly IDisableDeleteEndUsersFacade _disableDeleteEndUsersFacade;
        private readonly IPublishingFacade _publishingFacade;
        private ISearchCriteriaConverter _searchCriteriaConverter;
        private CustomAttributeLookup ProviderAttributes
        {
            get
            {
                var customAttributes = RuntimeContext.CustomAttributesWithouMassDevices.Where(x => x.EntityId == "USER").ToArray();
                return new CustomAttributeLookup(customAttributes);
            }
        }

        #endregion

        #region Constructor

        /// <summary>
        /// Constructor Initialization 
        /// </summary>
        /// <param name="disableDeleteEndUsersFacade"></param>
        /// <param name="userFacade"></param>
        /// <param name="userManagerHelper"></param>
        /// <param name="customAttributeFacade"></param>
        /// <param name="publishingFacade"></param>
        /// <param name="searchCriteriaConverter"></param>
        public DisableDeleteEndUsersController(IDisableDeleteEndUsersFacade disableDeleteEndUsersFacade, IUserFacade userFacade, IUserManagerHelper userManagerHelper,
            ICustomAttributeFacade customAttributeFacade, IPublishingFacade publishingFacade, ISearchCriteriaConverter searchCriteriaConverter)
        {

            _userFacade = userFacade;
            _userManagerHelper = userManagerHelper;
            _disableDeleteEndUsersFacade = disableDeleteEndUsersFacade;
            _customAttributeFacade = customAttributeFacade;
            _publishingFacade = publishingFacade;
            _searchCriteriaConverter = searchCriteriaConverter;
        }

        #endregion

        #region Action Results/Methods

        /// <summary>
        /// GET: /Settings/DisableDeleteEndUsers/ 
        /// returned object required for building advance query criteria
        /// </summary>
        /// <returns></returns>
        [IWSAuthorize(new SystemObject[] { SystemObject.AutoDeleteUsers }, new ActionType[] { ActionType.Modify })]
        public ActionResult Index()
        {
            var provider = RuntimeContext.Provider;
            var vpsTimeZOne = RuntimeContext.Provider.GetVpsTimeZoneFromId();
            ViewBag.DateFormat = provider.GetDateFormat();
            ViewBag.DateTimeFormat = provider.GetDateTimeFormat();
            ViewBag.VPSTimeZone = vpsTimeZOne;
            ViewBag.UtcOffsetInMinutes = vpsTimeZOne.BaseUtcOffset.TotalMinutes;
            ViewBag.VPSOffsetFromSystemInMinutes = provider.VPSOffsetFromSystemInMinutes();
            ViewBag.SupportsDaylightSavingTime = vpsTimeZOne.SupportsDaylightSavingTime;
            return View();
        }

        /// <summary>
        /// getting the initial data to load
        /// </summary>
        /// <returns></returns>
        [IWSAuthorize(new SystemObject[] { SystemObject.AutoDeleteUsers }, new ActionType[] { ActionType.Modify })]
        public JsonResult GetDisableDeleteDetails()
        {
            try
            {
                return Json(new { Success = true, DisableInformation = GetDisableUserDetails(), DeleteInformation = GetDeleteUserDetails(), PurgeInformation = GetDisableDeletePurgeUserDetails() });
            }
            catch (Exception ex)
            {
                return Json(new { Success = false, Messages = (string.IsNullOrWhiteSpace(IWSResources.DisableDeleteEndUsers_InvalidGet)) ? null : new Messages(new Message { Type = MessageType.Error, Value = IWSResources.DisableDeleteEndUsers_InvalidGet }) }, "text/plain");
            }

        }

        /// <summary>
        /// getting the values for disable on load
        /// </summary>
        /// <returns></returns>
        public DisableDeleteEndUsersSpec GetDisableUserDetails()
        {
            //creating the spec for getting the distribution list
            var distribution = _publishingFacade.GetDistributionLists(new DistributionListSpec { CommonName = AttributeCommonNames.DisableDistListCommonName, ProviderId = RuntimeContext.Provider.Id, IncludeParentChildren = true, OperatorId = RuntimeContext.Operator.Id }).FirstOrDefault();

            SearchCriteriaModel dynamicCriteriaModel = null;
            if (distribution != null)
            {
                //converting the query criteria into strings and send to UI for view 
                if (!string.IsNullOrWhiteSpace(distribution.Definition))
                {
                    var parser = new CriteriaListParser(RuntimeContext.CustomAttributes, ExcludeDefaultCriteria(AutoCleanupType.DisableUsers, distribution.Definition));
                    var criteria = _searchCriteriaConverter.GetSearchCriteriaModel(parser.Parse());
                    this.setGeoValues(criteria.selections);
                    dynamicCriteriaModel = criteria;
                }


            }
            return new DisableDeleteEndUsersSpec
            {
                EndUsersDisableDeleteModel = _disableDeleteEndUsersFacade.GetDisableExecutionJobInfo(new AutoDisableDeleteSpec() { Provider = RuntimeContext.Provider, DisableDeleteMode = AutoDisableDeleteMode.Disable }),
                DisableDynamicCriteria = dynamicCriteriaModel,
                IsCheckedForDisable = distribution.Status == DistributionListStatusType.Active ? true : false

            };

        }
        private void setGeoValues(List<Selection> selections)
        {
            var strValue = string.Empty;
            foreach (var item in selections)
            {
                if (item.entity.dataType == AttributeCommonNames.GeoLocation)
                {
                    var lstValue = new List<Value>();

                    //strvalue = item.value.Aggregate("", (current, value) => current + value.lineage + ",").TrimEnd(',');
                    strValue = string.Join(",", item.value.Select(a => a.text));
                    lstValue.Add(new Value() { text = strValue, commonName = item.commonName, entityType = item.entity.entityType, id = item.entity.id, lineage = strValue });
                    item.value = lstValue;
                }
            }
        }


        private string GetGeoLocationCriteria(List<Selection> selections)
        {
            var criteria = new GenericCriteria();
            var customCriteria = string.Empty;
            var addforSearch = true;
            foreach (var selection in selections)
            {
                addforSearch = true;
                if (!string.IsNullOrWhiteSpace(selection.value[0].text))
                {
                    var fc = new FeatureCollection(selection.value[0].text);
                    if (fc.Features != null && fc.Features.Count > 0)
                    {
                        var polyGons = (from f in fc.Features where f.Geometry.Type == Map.Geometry.Type.Polygon || f.Geometry.Type == Map.Geometry.Type.MultiPolygon select f.Attributes["OBJECTID"].ToString()).ToList();
                        var finalString = string.Join("^", polyGons);
                        criteria = new AttributeCriteria(selection.entity.id, selection.operand, finalString);
                    }
                    else
                        addforSearch = false;
                }
                else
                    addforSearch = false;

                if (addforSearch)
                    customCriteria = string.IsNullOrWhiteSpace(customCriteria) ? criteria.ToString() : customCriteria + "^" + criteria.ToString();

            }

            return customCriteria;
        }
        /// <summary>
        /// Exclude the certain criteria before bind the attribute dropdown
        /// </summary>
        /// <param name="userCleanupType"></param>
        /// <param name="definition"></param>
        /// <returns></returns>
        private string ExcludeDefaultCriteria(AutoCleanupType userCleanupType, string definition)
        {
            var userFacade = new UserFacade();

            //Status Criteria
            var statusAttributeId = userFacade.GetStatusAttributeId();
            var statusValueIds = userCleanupType == AutoCleanupType.DisableUsers ? userFacade.GetStatusValueIds(new[] { AttributeCommonNames.ValidEnabledUsers }) :
                userFacade.GetStatusValueIds(new[] { AttributeCommonNames.ValidEnabledUsers, AttributeCommonNames.UserDisableStatus });
            var statusCriteria = UserSearchHelper.GetUserStatusCriteria(statusAttributeId, statusValueIds).ToString();

            //Do not Disable/Delete Criteria
            var autoDisableDeleteCommonName = (userCleanupType == AutoCleanupType.DisableUsers) ? AttributeCommonNames.Do_not_Auto_Disable_User : AttributeCommonNames.Do_not_Auto_Delete_User;
            var autoDisableDeleteProcess = new AutoDisabDeleteProcess();
            var autoDisableDeleteCriteria = autoDisableDeleteProcess.GetAutoDisableDeleteCriteria(RuntimeContext.ProviderId, autoDisableDeleteCommonName).ToString();

            //NPD "Mass Device" Criteria
            var autoDisableDeleteMassDeviceCriteria = autoDisableDeleteProcess.GetAutoDisableDeleteCriteria(RuntimeContext.ProviderId, AttributeCommonNames.MassCommunication).ToString();

            if (definition.Contains(statusCriteria))
                definition = definition.Replace("^" + statusCriteria, "").Replace(statusCriteria + "^", "");//Exclude Status Criteria

            if (definition.Contains(autoDisableDeleteCriteria))
                definition = definition.Replace("^" + autoDisableDeleteCriteria, "").Replace(autoDisableDeleteCriteria + "^", "");//Exclude Do not Disable/Delete Criteria

            if (definition.Contains(autoDisableDeleteMassDeviceCriteria))
                definition = definition.Replace("^" + autoDisableDeleteMassDeviceCriteria, "").Replace(autoDisableDeleteMassDeviceCriteria + "^", "");// Exclude NPD "Mass Device" Criteria

            return definition;
        }

        /// <summary>
        ///  Include the certain criteria before save 
        /// </summary>
        /// <param name="userCleanupType"></param>
        /// <param name="defination"></param>
        /// <returns></returns>
        private string IncludeDefaultCriteria(AutoCleanupType userCleanupType, string defination)
        {
            var userFacade = new UserFacade();

            //Status Criteria
            var statusAttributeId = userFacade.GetStatusAttributeId();
            var statusValueIds = userCleanupType == AutoCleanupType.DisableUsers ? userFacade.GetStatusValueIds(new[] { AttributeCommonNames.ValidEnabledUsers }) :
                userFacade.GetStatusValueIds(new[] { AttributeCommonNames.ValidEnabledUsers, AttributeCommonNames.UserDisableStatus });
            var statusCriteria = UserSearchHelper.GetUserStatusCriteria(statusAttributeId, statusValueIds).ToString();

            //Do not Disable/Delete Criteria
            var autoDisableDeleteCommonName = (userCleanupType == AutoCleanupType.DisableUsers) ? AttributeCommonNames.Do_not_Auto_Disable_User : AttributeCommonNames.Do_not_Auto_Delete_User;
            var autoDisableDeleteProcess = new AutoDisabDeleteProcess();
            var autoDisableDeleteCriteria = autoDisableDeleteProcess.GetAutoDisableDeleteCriteria(RuntimeContext.ProviderId, autoDisableDeleteCommonName).ToString();

            //NPD "Mass Device" Criteria
            var autoDisableDeleteMassDeviceCriteria = autoDisableDeleteProcess.GetAutoDisableDeleteCriteria(RuntimeContext.ProviderId, AttributeCommonNames.MassCommunication).ToString();

            defination += "^" + statusCriteria; //Include Status Criteria
            defination += "^" + autoDisableDeleteCriteria; //Include Do not Disable/Delete Criteria
            defination += "^" + autoDisableDeleteMassDeviceCriteria; //Include NPD "Mass Device" Criteria

            return defination;
        }

        /// <summary>
        /// getting the values for delete on load
        /// </summary>
        /// <returns></returns>
        public DisableDeleteEndUsersSpec GetDeleteUserDetails()
        {
            //creating the spec for getting the distribution list
            var distribution = _publishingFacade.GetDistributionLists(new DistributionListSpec { CommonName = AttributeCommonNames.DeleteDistListCommonName, ProviderId = RuntimeContext.Provider.Id, IncludeParentChildren = true, OperatorId = RuntimeContext.Operator.Id }).FirstOrDefault();

            SearchCriteriaModel dynamicCriteriaModel = null;
            if (distribution != null)
            {
                //converting the query criteria into strings and send to UI for view 
                if (!string.IsNullOrWhiteSpace(distribution.Definition))
                {
                    var parser = new CriteriaListParser(RuntimeContext.CustomAttributes, ExcludeDefaultCriteria(AutoCleanupType.DeleteUsers, distribution.Definition));
                    var criteria = _searchCriteriaConverter.GetSearchCriteriaModel(parser.Parse());
                    //verifying weather the certain atrribute is there whichh suppose not to be loaded
                    this.setGeoValues(criteria.selections);
                    dynamicCriteriaModel = criteria;
                }
            }
            return new DisableDeleteEndUsersSpec
            {
                EndUsersDisableDeleteModel = _disableDeleteEndUsersFacade.GetDeleteExecutionJobInfo(new AutoDisableDeleteSpec() { Provider = RuntimeContext.Provider, DisableDeleteMode = AutoDisableDeleteMode.Delete }),
                DeleteDynamicCriteria = dynamicCriteriaModel,
                IsCheckedForDelete = distribution.Status == DistributionListStatusType.Active ? true : false
            };

        }

        /// <summary>
        /// Getting purge details
        /// </summary>
        /// <returns></returns>
        public DisableDeleteEndUsersSpec GetDisableDeletePurgeUserDetails()
        {
            string purgeInterval = AtHoc.VirtualSystems.SystemConfiguration.GetValue(RuntimeContext.Provider.Id, AttributeCommonNames.PurgeUsers);
            return new DisableDeleteEndUsersSpec
            {
                PurgeUsersModel = new PurgeUserInformation()
                {
                    SelectedPurgeDuration = !string.IsNullOrWhiteSpace(purgeInterval) && Convert.ToInt32(purgeInterval) > 0 ? purgeInterval : "30",
                    IsUserPurgedRequest = !string.IsNullOrWhiteSpace(purgeInterval) && Convert.ToInt32(purgeInterval) != 0,
                    PurgeDurationList = SettingsHelper.PurgeDurationList()
                },
            };
        }

        /// <summary>
        /// Getting the users detail for the disable and delete and count operations
        /// </summary>
        /// <param name="model"></param>
        /// <param name="disableDeleteEndUsersSpec"></param>
        /// <returns></returns>
        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.AutoDeleteUsers }, new[] { ActionType.Modify })]
        public JsonResult GetEndUsersDetail(DisableDeleteEndUsersSpec disableDeleteEndUsersSpec)
        {
            try
            {
                string userName = string.Empty;
                ExpressionElement searchCriteriaElement = null;
                ExpressionElement customCriteria = null;
                var provider = RuntimeContext.Provider;

                #region Get Attributes

                var defaultAttributes = new List<string>() { 
                                                    AttributeCommonNames.UserId,
                                                    AttributeCommonNames.UserName, 
                                                    AttributeCommonNames.DisplayName,
                                                    AttributeCommonNames.FirstName,
                                                    AttributeCommonNames.LastName,
                                                    AttributeCommonNames.Status,
                                                    AttributeCommonNames.CreatedOn,
                                                    
                };
                var columns = new[]
                  {
                      new CustomViewColumn
                      {
                        DisplayName = (ProviderAttributes.Any())? ProviderAttributes.GetByCommonName(CommonNames.UserName).AttributeName: IWSResources.DisableDeleteEndUsers_Username,
                        Key = AttributeCommonNames.UserName,
                        IsSortable = true,
                        CustomViewColumnType = "CF",
                        DataType = CustomAttributeDataType.String,
                        DataFormat = string.Empty,
                        ViewId = 1
                       },
                       new CustomViewColumn
                       {
                        DisplayName =  (ProviderAttributes.Any())? ProviderAttributes.GetByCommonName(CommonNames.DisplayName).AttributeName: IWSResources.DisableDeleteEndUsers_DisplayName,
                        Key = AttributeCommonNames.DisplayName,
                        IsRequired = true,
                        IsSortable = true,
                        CustomViewColumnType = "CF",
                        DataType = CustomAttributeDataType.String,
                        DataFormat = string.Empty,
                        ViewId = 2
                     },
                     new CustomViewColumn
                     {
                        DisplayName = (ProviderAttributes.Any())? ProviderAttributes.GetByCommonName(CommonNames.CreatedOn).AttributeName: IWSResources.DisableDeleteEndUsers_CreatedOn,
                        Key = AttributeCommonNames.CreatedOn,
                        IsSortable = false,
                        CustomViewColumnType = "CF",
                        DataType = CustomAttributeDataType.DateTime,
                        DataFormat = string.Empty,
                        ViewId = 3
                    }
                  
               };


                #endregion

                #region Setting Search Criteria

                var srchArgsV2 = new UserSearchArgs(false, true, false)
                {
                    AttributeNames = defaultAttributes,
                    ProviderId = RuntimeContext.ProviderId,
                    ProviderCriteria = UserSearchHelper.GetProviderCriteria(RuntimeContext.ProviderId),
                    Paging = { PageNo = disableDeleteEndUsersSpec.SearchEndUsersCriteriaModel.page, UsersPerPage = disableDeleteEndUsersSpec.SearchEndUsersCriteriaModel.pageSize, SortColumn = disableDeleteEndUsersSpec.SearchEndUsersCriteriaModel.sortBy, IsAsc = !disableDeleteEndUsersSpec.SearchEndUsersCriteriaModel.sortOrder.Equals("DESC", StringComparison.CurrentCultureIgnoreCase) }
                };

                if (disableDeleteEndUsersSpec.SearchEndUsersCriteriaModel.searchModel != null && disableDeleteEndUsersSpec.SearchEndUsersCriteriaModel.searchModel.selections != null)
                {
                    foreach (var selection in disableDeleteEndUsersSpec.SearchEndUsersCriteriaModel.searchModel.selections)
                    {
                        var addToSearch = true;
                        var criteria = new GenericCriteria(selection.entity.entityType, selection.entity.id, selection.operand);

                        switch (selection.entity.dataType)
                        {
                            case "Picklist":
                            case "MultiPicklist":
                            case "Checkbox":
                                criteria.Value = (selection.operand == 11 || selection.operand == 12)
                                    ? "0"
                                    : selection.value.Aggregate("", (current, value) => current + value.id + ",").TrimEnd(',');
                                break;
                            case "Number":
                            case "String":
                            case "Memo":
                            case "Date":
                            case "DateTime":
                                criteria.Value = selection.value.Aggregate("", (current, value) => current + value.text + ",").TrimEnd(',');
                                break;
                            case "Path":
                                criteria.Value = selection.value.Aggregate("", (current, value) => current + value.lineage + ",").TrimEnd(',');
                                break;
                            case "GeoLocation":
                                if (!string.IsNullOrWhiteSpace(selection.value[0].text))
                                {
                                    var fc = new FeatureCollection(selection.value[0].text);
                                    if (fc.Features != null && fc.Features.Count > 0)
                                    {
                                        var polyGons = (from f in fc.Features where f.Geometry.Type == Map.Geometry.Type.Polygon || f.Geometry.Type == Map.Geometry.Type.MultiPolygon select f.Attributes["OBJECTID"].ToString()).ToList();
                                        var finalString = string.Join("|", polyGons);
                                        criteria = new AttributeCriteria(selection.entity.id, selection.operand, finalString);
                                    }
                                    else
                                        addToSearch = false;
                                }
                                else
                                    addToSearch = false;
                                break;
                            case "AttributeValue":
                            case "Device":
                            case "Entity":
                            case "Object":
                            case "Unknown":
                            default:
                                throw new Exception("Not Implemented");
                        }
                        if (addToSearch)
                            customCriteria = customCriteria == null ? criteria : customCriteria & criteria;
                    }
                }


                var customAttributeValueCache = new CustomAttributeValueCache();
                var customAttributeValueDictionary = customAttributeValueCache.Get(RuntimeContext.ProviderId, RuntimeContext.Provider.BaseLocale);

                //Building  criteria for disable only VLD user and for Delete both user has to be selected for search
                var statusAttribute = ProviderAttributes.GetByCommonName(AttributeCommonNames.Status);

                var statusValues = disableDeleteEndUsersSpec.SearchEndUsersCriteriaModel.isfromDisable ? customAttributeValueDictionary.GetByCommonNames(AttributeCommonNames.ValidEnabledUsers).Select(x => x.ValueId) :
                                    customAttributeValueDictionary.GetByCommonNames(string.Format("{0},{1}", AttributeCommonNames.ValidEnabledUsers, AttributeCommonNames.UserDisableStatus)).Select(x => x.ValueId);

                var statusCriteria = UserSearchHelper.GetUserStatusCriteria(statusAttribute.Id, statusValues);


                //Building  criteria for disable exclude Do_not_Auto_Disable_User checked with flag to true
                //Building  criteria for delete exclude Do_not_Auto_Delete_User checked with flag to true
                var DonotIncludeUserAttribute = disableDeleteEndUsersSpec.SearchEndUsersCriteriaModel.isfromDisable ? ProviderAttributes.GetByCommonName(AttributeCommonNames.Do_not_Auto_Disable_User) :
                                        ProviderAttributes.GetByCommonName(AttributeCommonNames.Do_not_Auto_Delete_User);

                var autoDisableDeleteStatus = disableDeleteEndUsersSpec.SearchEndUsersCriteriaModel.isfromDisable ? customAttributeValueDictionary.GetByCommonNames(AttributeCommonNames.NO, DonotIncludeUserAttribute.Id).Select(x => x.ValueId) :
                                    customAttributeValueDictionary.GetByCommonNames(AttributeCommonNames.NO, DonotIncludeUserAttribute.Id).Select(x => x.ValueId);

                var DonotIncludeUserCriteria = UserSearchHelper.GetUserStatusCriteria(DonotIncludeUserAttribute.Id, autoDisableDeleteStatus);


                //for search criteria need to be created and include
                if (disableDeleteEndUsersSpec.SearchEndUsersCriteriaModel.searchString != null)
                {
                    searchCriteriaElement = UserSearchHelper.GetQuickSearchCriteria(provider.Id, RuntimeContext.Provider.BaseLocale, disableDeleteEndUsersSpec.SearchEndUsersCriteriaModel.searchString);
                }

                //Final search criteria
                srchArgsV2.TargetCriteria = customCriteria & statusCriteria & DonotIncludeUserCriteria & searchCriteriaElement;

                #endregion
                var usersResult = _userFacade.SearchUsersByContext(srchArgsV2);

                if (usersResult != null && usersResult.SearchResultCount > 0)
                    userName = usersResult.Users.Count() == 1 ? usersResult.Users.FirstOrDefault().UserName : string.Empty;

                if (disableDeleteEndUsersSpec.SearchEndUsersCriteriaModel.showList)
                {
                    return Json(new
                    {
                        Columns = columns,
                        Rows = _userManagerHelper.ConvertToUIModel(usersResult.Users),
                        TotalCounts = usersResult.SearchResultCount,
                        Success = true,
                    });

                }
                else
                {
                    return Json(new
                    {
                        Success = true,
                        UserCount = usersResult.SearchResultCount,
                        UserName = userName
                    });
                }
            }
            catch (Exception ex)
            {
                return Json(new { Success = false, Messages = (string.IsNullOrWhiteSpace(IWSResources.DisableDeleteEndUsers_InvalidUserDetail)) ? null : new Messages(new Message { Type = MessageType.Error, Value = IWSResources.DisableDeleteEndUsers_InvalidUserDetail }) }, "text/plain");
            }
        }

        /// <summary>
        /// Save the disable/delete users info
        /// </summary>
        /// <param name="data"></param>
        /// <param name="DisableUsers"></param>
        /// <param name="DeleteUsers"></param>
        /// <param name="isFromDisable"></param>
        /// <param name="isFromDelete"></param>
        /// <param name="isForPurgerequest"></param>
        /// <param name="purgeInterval"></param>
        /// <returns></returns>
        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.AutoDeleteUsers }, new[] { ActionType.Modify })]
        public ActionResult SaveDisableDeleteEndUsers(DisableDeleteEndUsersSpec disableDeleteEndUsersSpec)
        {
            bool savedDisable = false;
            bool savedDelete = false;
            string message = string.Empty;
            try
            {
                if (SaveDisableUserData(disableDeleteEndUsersSpec))
                    savedDisable = true;

                if (SaveDeleteUserData(disableDeleteEndUsersSpec))
                    savedDelete = true;

                if (savedDelete && savedDisable)
                {
                    var autoDisableDeleteSpec = new AutoDisableDeleteSpec
                    {
                        ProviderId = RuntimeContext.ProviderId,
                        OperatorId = RuntimeContext.OperatorId,
                        Provider = RuntimeContext.Provider
                    };
                    _disableDeleteEndUsersFacade.UpdateOperatorAuditLog(ServiceAction.AutoDisableDeleteUpdated,
                        autoDisableDeleteSpec);
                }

                VirtualSystems.SystemConfiguration.SetValue(RuntimeContext.Provider.Id, AttributeCommonNames.PurgeUsers, disableDeleteEndUsersSpec.PurgeUsersModel.IsUserPurgedRequest ? disableDeleteEndUsersSpec.PurgeUsersModel.SelectedPurgeDuration : "0");

                return Json(new { Success = true });
            }
            catch (Exception ex)
            {
                if (!savedDisable)
                    message = IWSResources.DisableDeleteEndUsers_Disable_InvalidSave;
                else if (!savedDelete)
                    message = IWSResources.DisableDeleteEndUsers_Delete_InvalidSave;

                return Json(new
                {
                    Success = false,
                    Messages = (string.IsNullOrWhiteSpace(message)) ? null :
                        new Messages(new Message { Type = MessageType.Error, Value = IWSResources.DisableDeleteEndUsers_InvalidGet })
                }, "text/plain");
            }
        }

        /// <summary>
        /// Save Disable Info
        /// </summary>
        /// <param name="disableUserInformation"></param>
        /// <returns></returns>
        private bool SaveDisableUserData(DisableDeleteEndUsersSpec disableUserInformation)
        {
            var distributionList = _publishingFacade.GetDistributionList(new DistributionListSpec { CommonName = AttributeCommonNames.DisableDistListCommonName, OperatorId = RuntimeContext.Operator.Id, ProviderId = RuntimeContext.Provider.Id });

            //saving the query criteria selected from UI
            if (disableUserInformation.DisableDynamicCriteria != null)
            {
                var criteriaList = _searchCriteriaConverter.GetAttributeCriteriaPrameter(disableUserInformation.DisableDynamicCriteria.selections);

                distributionList.Definition = this.IncludeDefaultCriteria(AutoCleanupType.DisableUsers, AttrCriteria.ToCriteriaString(criteriaList));

            }
            else
                distributionList.Definition = string.Empty;


            distributionList.Status = disableUserInformation.IsCheckedForDisable ? DistributionListStatusType.Active : DistributionListStatusType.Disabled;

            //Final save for selected users setting for disable/delete
            var result = _publishingFacade.SaveDistributionList(
             new DistributionListSaveSpec
             {
                 List = distributionList,
                 OperatorId = RuntimeContext.Operator.Id,
                 UserId = RuntimeContext.Operator.Id,
                 ProviderId = RuntimeContext.Provider.Id
             }
         );
            return true;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="spec"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult SubmitToJob(DisableDeleteEndUsersSpec spec)
        {
            var providerId = RuntimeContext.ProviderId;
            var operatorId = RuntimeContext.OperatorId;
            var autoDisableDeleteProcess = new AutoDisabDeleteProcess();
            var criteria = string.Empty;
            var customCriteria = string.Empty;

            try
            {

                var autoDisableDeleteSpec = new AutoDisableDeleteSpec
                {
                    ProviderId = RuntimeContext.ProviderId,
                    OperatorId = RuntimeContext.OperatorId,
                    Provider = RuntimeContext.Provider
                };

                //saving the query criteria selected from UI
                if (spec.actionType == AutoCleanupType.DisableUsers)
                {
                    criteria = this.GetGeoLocationCriteria(spec.DisableDynamicCriteria.selections.Select(a => a).Where(a => a.entity.dataType == AttributeCommonNames.GeoLocation).ToList());

                    var criteriaList = _searchCriteriaConverter.GetAttributeCriteriaPrameter(spec.DisableDynamicCriteria.selections.Select(a => a).Where(a => a.entity.dataType != AttributeCommonNames.GeoLocation));

                    if (string.IsNullOrWhiteSpace(criteria) && criteriaList != null)
                        customCriteria = AttrCriteria.ToCriteriaString(criteriaList);
                    else if (!string.IsNullOrWhiteSpace(criteria) && criteriaList != null)
                        customCriteria = criteria + "^" + AttrCriteria.ToCriteriaString(criteriaList);
                    else if (!string.IsNullOrWhiteSpace(criteria) && criteriaList == null)
                        customCriteria= criteria;

                    autoDisableDeleteProcess.RunNow(providerId, AutoCleanupType.DisableUsers.ToString(), operatorId, customCriteria);
                    var result = _disableDeleteEndUsersFacade.GetDisableExecutionJobInfo(new AutoDisableDeleteSpec() { Provider = RuntimeContext.Provider, DisableDeleteMode = AutoDisableDeleteMode.Disable });
                    _disableDeleteEndUsersFacade.UpdateOperatorAuditLog(ServiceAction.AutoDisableJobAction,
                        autoDisableDeleteSpec);

                    return Json(new { Success = true, TargetDisableModel = result });
                }
                if (spec.actionType == AutoCleanupType.DeleteUsers)
                {
                    criteria = this.GetGeoLocationCriteria(spec.DeleteDynamicCriteria.selections.Select(a => a).Where(a => a.entity.dataType == AttributeCommonNames.GeoLocation).ToList());

                    var criteriaList = _searchCriteriaConverter.GetAttributeCriteriaPrameter(spec.DeleteDynamicCriteria.selections.Select(a => a).Where(a => a.entity.dataType != AttributeCommonNames.GeoLocation));

                    if (string.IsNullOrWhiteSpace(criteria) && criteriaList != null)
                        customCriteria = AttrCriteria.ToCriteriaString(criteriaList);
                    else if (!string.IsNullOrWhiteSpace(criteria) && criteriaList != null)
                        customCriteria = criteria + "^" + AttrCriteria.ToCriteriaString(criteriaList);
                    else if (!string.IsNullOrWhiteSpace(criteria) && criteriaList == null)
                        customCriteria = criteria;


                    autoDisableDeleteProcess.RunNow(providerId, AutoCleanupType.DeleteUsers.ToString(), operatorId, customCriteria);
                    var result = _disableDeleteEndUsersFacade.GetDeleteExecutionJobInfo(new AutoDisableDeleteSpec() { Provider = RuntimeContext.Provider, DisableDeleteMode = AutoDisableDeleteMode.Delete });
                    _disableDeleteEndUsersFacade.UpdateOperatorAuditLog(ServiceAction.AutoDeleteJobAction,
                       autoDisableDeleteSpec);
                    return Json(new { Success = true, TargetDeleteModel = result });
                }
                return Json(new { Success = false });
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    Success = false,
                    Messages = (string.IsNullOrWhiteSpace((spec.actionType == AutoCleanupType.DisableUsers) ? IWSResources.DisableDeleteEndUsers_Disable_User_Error : IWSResources.DisableDeleteEndUsers_Delete_User_Error)) ? null :
                    new Messages(new Message { Type = MessageType.Error, Value = (spec.actionType == AutoCleanupType.DisableUsers) ? IWSResources.DisableDeleteEndUsers_Disable_User_Error : IWSResources.DisableDeleteEndUsers_Delete_User_Error })
                }, "text/plain");
            }
        }

        /// <summary>
        /// Save the delete users info
        /// </summary>
        /// <param name="deleteUserInformation"></param>
        /// <returns></returns>
        private bool SaveDeleteUserData(DisableDeleteEndUsersSpec deleteUserInformation)
        {
            var distributionList = _publishingFacade.GetDistributionList(new DistributionListSpec { CommonName = AttributeCommonNames.DeleteDistListCommonName, OperatorId = RuntimeContext.Operator.Id, ProviderId = RuntimeContext.Provider.Id });
            //saving the query criteria selected from UI
            if (deleteUserInformation.DeleteDynamicCriteria != null)
            {
                var criteriaList = _searchCriteriaConverter.GetAttributeCriteriaPrameter(deleteUserInformation.DeleteDynamicCriteria.selections);
                distributionList.Definition = this.IncludeDefaultCriteria(AutoCleanupType.DeleteUsers, AttrCriteria.ToCriteriaString(criteriaList));
            }
            else
                distributionList.Definition = string.Empty;

            distributionList.Status = deleteUserInformation.IsCheckedForDelete ? DistributionListStatusType.Active : DistributionListStatusType.Disabled;

            //Final save for selected users setting for disable/delete
            var result = _publishingFacade.SaveDistributionList(
             new DistributionListSaveSpec
             {
                 List = distributionList,
                 OperatorId = RuntimeContext.Operator.Id,
                 UserId = RuntimeContext.Operator.Id,
                 ProviderId = RuntimeContext.Provider.Id
             }
         );
            return true;
        }

        /// <summary>
        /// creating disabled deleted excel file.
        /// </summary>
        /// <param name="AuditID"></param>
        /// <param name="typeString"></param>
        /// <returns></returns>
        [IWSAuthorize(new[] { SystemObject.AutoDeleteUsers }, new[] { ActionType.Modify })]
        public ActionResult DownloadDisableDeleteDetails(string auditID, string typeString)
        {
            try
            {
                int auditJobID;

                if (int.TryParse(auditID, out auditJobID))
                {
                    var auditData = _disableDeleteEndUsersFacade.GetAuditData(auditJobID);
                    Response.ContentType = "application/vnd.ms-excel";
                    Response.ContentEncoding = System.Text.Encoding.Default;
                    Response.AddHeader("Content-Disposition", string.Format("attachment; filename={0}.csv", typeString));
                    Response.Write(auditData.AdditionalInformation);
                }

                return new EmptyResult();
            }
            catch (Exception)
            {
                return Json(new
                {
                    Success = false,
                    Messages = (string.IsNullOrWhiteSpace(IWSResources.DisableDeleteEndUsers_DownLoadExcel_Error)) ? null :
                    new Messages(new Message { Type = MessageType.Error, Value = IWSResources.DisableDeleteEndUsers_DownLoadExcel_Error })
                }, "text/plain");
            }
        }


        /// <summary>
        /// checking the status of submitted job for Disable/Delete
        /// </summary>
        /// <param name="spec"></param>
        /// <returns></returns>
        [IWSAuthorize(new[] { SystemObject.AutoDeleteUsers }, new[] { ActionType.Modify })]
        [HttpPost]
        public ActionResult CheckRunNowStatus(DisableDeleteEndUsersSpec spec)
        {
            try
            {
                if (spec.actionType == AutoCleanupType.DisableUsers)
                {
                    var result = _disableDeleteEndUsersFacade.GetDisableExecutionJobInfo(new AutoDisableDeleteSpec() { Provider = RuntimeContext.Provider, DisableDeleteMode = AutoDisableDeleteMode.Disable });
                    return Json(new { Success = true, TargetDisableModel = result });
                }
                if (spec.actionType == AutoCleanupType.DeleteUsers)
                {
                    var result = _disableDeleteEndUsersFacade.GetDeleteExecutionJobInfo(new AutoDisableDeleteSpec() { Provider = RuntimeContext.Provider, DisableDeleteMode = AutoDisableDeleteMode.Delete });
                    return Json(new { Success = true, TargetDeleteModel = result });
                }
                return Json(new { Success = false });
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    Success = false,
                    Messages = (string.IsNullOrWhiteSpace((spec.actionType == AutoCleanupType.DisableUsers) ? IWSResources.DisableDeleteEndUsers_Disable_User_Error : IWSResources.DisableDeleteEndUsers_Delete_User_Error)) ? null :
                    new Messages(new Message { Type = MessageType.Error, Value = (spec.actionType == AutoCleanupType.DisableUsers) ? IWSResources.DisableDeleteEndUsers_Disable_User_Error : IWSResources.DisableDeleteEndUsers_Delete_User_Error })
                }, "text/plain");
            }
        }

        #endregion

    }
}