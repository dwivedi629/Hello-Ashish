﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using AtHoc.IWS.Web.Filters;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Resources;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.Global.Resources; 

namespace AtHoc.IWS.Web.Areas.Settings.Controllers
{
    public class HierarchyDefinitionController : Controller
    {

        private readonly ILogService _logService;
        private readonly IHierarchyDefinitionFacade _hierarchyFacade; 
        public HierarchyDefinitionController(IHierarchyDefinitionFacade hierarchyFacade, ILogService logService )
        {
            _hierarchyFacade = hierarchyFacade;
            _logService = logService; 
        }
        // GET: /Settings/IHierarchy/
        // Only authorized user can access this page
        // Only authorized user can access this page
        [IWSAuthorize(new SystemObject[] { SystemObject.HierarchyDefination }, new ActionType[] { ActionType.Modify })]
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [IWSAuthorize(new SystemObject[] { SystemObject.HierarchyDefination }, new ActionType[] { ActionType.Modify })]
        public ActionResult AddNode(PdlListSettings pdllistsettings, int hierarchytype)
        {
            try
            {

                var hierarchySpec = new HierarchySpec
                {
                    ProviderId = RuntimeContext.ProviderId,
                    OperatorId = RuntimeContext.OperatorId,
                    LocalCode = RuntimeContext.Provider.BaseLocale,
                    Node = pdllistsettings,
                    HierarchySearchType = (HierarchySearchType)hierarchytype,
                };
                var data = _hierarchyFacade.AddNode(hierarchySpec);
                return Json(new
                {
                    Success = true,
                    Data = data,
                });
            }

            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, HasErrors = true, Messages = IWSResources.AtHoc_HierarchyDefinition_ErrMsg_Adding });
            }

        }


        [HttpPost]
        public ActionResult SaveNode(List<PdlListModel> pldlistsettings, int hierarchyType)
        {
            var result = false;
            try
            {


                var hierarchySpec = new HierarchySpec
                {
                    ProviderId = RuntimeContext.ProviderId,
                    OperatorId = RuntimeContext.OperatorId,
                    LocalCode = RuntimeContext.Provider.BaseLocale,
                    NodeList = pldlistsettings,
                    HierarchySearchType = (HierarchySearchType)hierarchyType,
                };
                var rootNode = pldlistsettings.Find(m => m.ListId == 0 && m.Name != null);
                if (rootNode != null && _hierarchyFacade.IsValidHierarchyName(rootNode.Name, Convert.ToInt32(rootNode.HierarchyId), RuntimeContext.ProviderId))
                {

                    var error = IWSResources.AtHoc_HierarchyDefinition_ErrMsg_UniqueNameinVPS;
                    return Json(new { Success = false, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }), ReturnType = 1 });
                }
                else
                {
                    result = _hierarchyFacade.SaveNode(hierarchySpec);
                    var treedata = _hierarchyFacade.GetHierarchy(hierarchySpec);
                    var list = new List<PdlListModel> { treedata };
                    return Json(new
                    {
                        Success = result,
                        Data = list,
                    });
                }
            }

            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = result, HasErrors = true, Messages = IWSResources.AtHoc_HierarchyDefinition_ErrMsg_Saving });
            }

        }

        [HttpPost]
        public ActionResult DeleteNode(PdlListSettings pdllistsettings, int hierarchytype)
        {

            try
            {
                var hierarchySpec = new HierarchySpec
                {
                    ProviderId = RuntimeContext.ProviderId,
                    OperatorId = RuntimeContext.OperatorId,
                    LocalCode = RuntimeContext.Provider.BaseLocale,
                    Node = pdllistsettings,
                    HierarchySearchType = (HierarchySearchType)hierarchytype
                };
                var data = _hierarchyFacade.DeleteNode(hierarchySpec);
                return Json(new
                {
                    Success = true,
                    Data = data,
                });
            }

            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, HasErrors = true, Messages = IWSResources.AtHoc_HierarchyDefinition_ErrMsg_Deleting });
            }
        }

        [HttpPost]
        public JsonResult GetHierarchyDetails(int hierarchytype)
        {
            try
            {
                var hierarchySpec = new HierarchySpec
                {
                    ProviderId = RuntimeContext.ProviderId,
                    OperatorId = RuntimeContext.OperatorId,
                    LocalCode = RuntimeContext.Provider.BaseLocale,
                    HierarchySearchType = (HierarchySearchType)hierarchytype
                };
                var data = _hierarchyFacade.GetHierarchy(hierarchySpec);
                var list = new List<PdlListModel>();
                list.Add(data);

                var result = Json(new
                {
                    Success = true,
                    Data = list,
                });

                result.RecursionLimit = 1024;
                result.MaxJsonLength = 8388608;
                return result;
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, HasErrors = true, Messages = IWSResources.AtHoc_HierarchyDefinition_ErrMsg_Retriving });
            }

        }
         
    }
}