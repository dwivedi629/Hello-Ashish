﻿using System;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using AtHoc.Business.Extensions;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Resources;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Data.SearchSpec;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Web.Configurations.Constants;
using AtHoc.IWS.Web.Filters;
using System.Collections.Generic;
using AtHoc.Global.Resources;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business;
using AtHoc.IWS.Web.Helpers;
using AtHoc.IWS.Business.Configurations;
using System.IO;
using AtHoc.Infrastructure.Csv.CsvHelper;

namespace AtHoc.IWS.Web.Areas.Settings.Controllers
{
    [IWSAuthorize(new[] { SystemObject.VirtualSystemConfiguration }, new[] { ActionType.View })]
    public class PlaceholderController : Controller
    {
        private readonly ICustomAttributeFacade _customAttributeFacade;
        private readonly IUserFacade _userFacade;
        private readonly IAtHocConfigurations _configurations;
        public PlaceholderController(ICustomAttributeFacade customAttributeFacade, IUserFacade userFacade, IAtHocConfigurations configurations)
        {
            _customAttributeFacade = customAttributeFacade;
            _userFacade = userFacade;
            _configurations = configurations;
        }

        // GET: Placeholders
        [IWSAuthorize(new[] { SystemObject.VirtualSystemConfiguration }, new[] { ActionType.Modify })]
        public ActionResult Index()
        {
            return View();
        }

        [IWSAuthorize(new[] { SystemObject.VirtualSystemConfiguration }, new[] { ActionType.Modify })]
        public ActionResult PlaceholderDetails()
        {
            return View();
        }

        /// <summary>
        /// It will redirect to New Attribute details page
        /// </summary>
        /// <param name="id">Attribute Type</param>
        /// <returns></returns>
        [IWSAuthorize(new[] { SystemObject.VirtualSystemConfiguration }, new[] { ActionType.Modify })]
        public ActionResult New(string id)
        {
                if(!ValidateId(id))
                { 
                    throw new HttpException(400, "The URL is invalid.");
                }
                ViewBag.AttributeType = id;
                ViewBag.AttributeOrigin = RuntimeContext.Provider.ProviderName;
                ViewBag.ProviderId = RuntimeContext.ProviderId;
                ViewBag.LocaleCode = RuntimeContext.Provider.BaseLocale;
                var types = _customAttributeFacade.GetUserAttributeTypes();
                var userAttributeDataType = types.ToList().SingleOrDefault(i => i.AttributeType.ToLower()==id.ToLower());
                if (userAttributeDataType != null)
                    ViewBag.AttributeTypeId = userAttributeDataType.AttributeTypeId;
                ViewBag.IsNew = true;
                FillTimeProperties();
                return View("PlaceholderDetails");
            
        }

        private bool ValidateId(string id)
        {
            List<string> placeholderIds = new List<string>();
            placeholderIds.Add("Multi-Picklist");
            placeholderIds.Add("Picklist");
            placeholderIds.Add("String");
            placeholderIds.Add("Date");
            placeholderIds.Add("DateTime");
            placeholderIds.Add("Time");
            return placeholderIds.Any(s => s.Equals(id, StringComparison.OrdinalIgnoreCase));
        }
        /// <summary>
        /// It will redirect to Edit Attribute details page
        /// </summary>
        /// <param name="id">Attribute Id</param>
        /// <returns></returns>        
        [IWSAuthorize(new[] { SystemObject.VirtualSystemConfiguration }, new[] { ActionType.Modify })]
        public ActionResult Edit(string id)
        {
            ViewBag.AttributeType = id; // id is AttributeId
            ViewBag.IsNew = false;
            FillTimeProperties();
            return View("PlaceholderDetails");
        }

        /// <summary>
        /// Fill DateTime properties
        /// </summary>
        private void FillTimeProperties()
        {
            var provider = RuntimeContext.Provider;

            var vpsTimeZOne = RuntimeContext.Provider.GetVpsTimeZoneFromId();
            ViewBag.DateFormat = provider.GetDateFormat();
            ViewBag.DateTimeFormat = provider.GetDateTimeFormat();
            ViewBag.VPSTimeZone = vpsTimeZOne;
            ViewBag.UtcOffsetInMinutes = vpsTimeZOne.BaseUtcOffset.TotalMinutes;
            ViewBag.VPSOffsetFromSystemInMinutes = provider.VPSOffsetFromSystemInMinutes();
            ViewBag.SupportsDaylightSavingTime = vpsTimeZOne.SupportsDaylightSavingTime;
            ViewBag.CurrentDateTime = provider.CurrentSystemTimeToVps().ToString(CultureInfo.InvariantCulture);
            ViewBag.CurrentTime = DateTime.Now;
        }

        /// <summary>
        /// Get Attributes based on spec
        /// If providerId is zero then get all attributes
        /// If providerID is somthing value then get only corresponding attributes
        /// TODO: If providerId is somthing value and get all attributes other than this prodierid attributes
        /// </summary>
        /// <param name="attributeSearchSpec">UserAttributeSearchSpec object</param>
        /// <returns></returns>
        [IWSAuthorize(new[] { SystemObject.VirtualSystemConfiguration }, new[] { ActionType.Modify })]
        public ActionResult GetPlaceholderList(UserAttributeSearchSpec attributeSearchSpec)
        {
            try
            {

                attributeSearchSpec.ProviderId = RuntimeContext.ProviderId;
                attributeSearchSpec.OperatorId = RuntimeContext.OperatorId;
                attributeSearchSpec.EntityId = CustomAttributeType.Placeholder;
                attributeSearchSpec.Locale = RuntimeContext.Provider.BaseLocale;
                var placeholderList = _customAttributeFacade.GetAttributesForList(attributeSearchSpec);

                var placeholderData = placeholderList.Data.ToList();
                var systemInfo = new SystemPlaceholders
                {
                    OrganizationName = RuntimeContext.Provider.ProviderName,
                    OrganizationId = RuntimeContext.Provider.Id.ToString(CultureInfo.InvariantCulture),
                    OperatorFullName = GetOperatorName(),
                    PublishDate = RuntimeContext.Provider.CurrentSystemTimeToVps().ToString(RuntimeContext.Provider.GetDateFormat()),
                    PublishTime = RuntimeContext.Provider.CurrentSystemTimeToVps().ToString(RuntimeContext.Provider.GetTimeFormat()),
                    TimeZone = SettingsHelper.GetLocalizedTimeZone(RuntimeContext.Provider.GetVpsTimeZoneFromId().Id),

                };
                var sysPlaceholderList = systemInfo.GetSystemStaticPlaceholders();
                // var placeholderList = dataFromDb.Data.ToList().Where(p => p.ProviderId == 3 || p.ProviderId == attributeSearchSpec.ProviderId).ToList();
                foreach (var placeHolder in placeholderData)
                {
                    if (!sysPlaceholderList.ContainsKey(placeHolder.CommonName))
                        continue;
                    var value = sysPlaceholderList[placeHolder.CommonName];
                    placeHolder.DefaultValue = value;
                }
                var data = placeholderData.Select(x => new
                {
                    x.Id,
                    x.AttributeName,
                    x.AttributeOrigin,
                    UpdatedOn =
                        RuntimeContext.Provider.GetVpsDateFromSeconds(x.UpdatedOn.HasValue
                            ? x.UpdatedOn.Value
                            : x.CreatedOn.HasValue ? x.CreatedOn.Value : 0),
                    x.AttributeTypeId,
                    DefaultValue = string.Empty,
                    PlaceholderType = x.AttributeType
                });

                return Json(new
                {
                    Success = true,
                    TotalCount = placeholderList.Count,
                    Data = data,
                    Attributes = SettingsHelper.AttributeList().Where(e => e.Value != CustomAttributeDataType.Path.ToString())
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new
                {
                    Success = false,
                    Messages = IWSResources.UserAttributeManager_List_Message
                }, JsonRequestBehavior.AllowGet);
            }
        }



        /// <summary>
        /// Getting usesr attribute details based on attributeId
        /// </summary>
        /// <param name="placeholderId">Attribute Id</param>
        /// <returns></returns>
        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.VirtualSystemConfiguration }, new[] { ActionType.Modify })]
        public ActionResult GetPlaceholderDetails(int placeholderId)
        {
            try
            {
                bool isDeletable, isEditable = true;
                var userAttribute = IsPlaceholderDeletableOnCurrentContext(placeholderId, out isDeletable);
                if (userAttribute != null)
                {
                    CustomAttributeModel custAttributeModel = GetPlaceholderDetail(userAttribute);
                    custAttributeModel.DefaultText = custAttributeModel.DefaultValue;
                    if (userAttribute.IsStandard == "Y" || userAttribute.ProviderId == 3)
                    {
                        isEditable = false;
                    }

                    return Json(new
                    {
                        Success = true,
                        Data = custAttributeModel,
                        IsDeletable = isDeletable,
                        IsEditeable = isEditable
                    });
                }
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new
                {
                    Success = false,
                    Messages = IWSResources.UserAttributeManager_Attribute_Get_Message
                });
            }
            return null;
        }

        /// <summary>
        /// getiing the user attribute details
        /// </summary>
        /// <param name="placeholder"></param>
        /// <returns></returns>
        private CustomAttributeModel GetPlaceholderDetail(CustomAttribute placeholder)
        {
            var custAttributeModel = new CustomAttributeModel
            {
                ProviderId = placeholder.ProviderId,
                LocaleCode = placeholder.LocaleCode,
                UpdatedBy = GetUserName(placeholder.UpdatedBy.HasValue ? placeholder.UpdatedBy : placeholder.CreatedBy),
                CreatedBy = placeholder.CreatedBy.HasValue ? GetUserName(placeholder.CreatedBy) : "",
                UpdatedOn =
                    RuntimeContext.Provider.SystemToVpsDateTimeFormated(
                        DateTimeConverter.GetDateTimeFromSeconds(placeholder.UpdatedOn.HasValue
                            ? placeholder.UpdatedOn
                            : placeholder.CreatedOn)),
                CreatedOn =
                    RuntimeContext.Provider.SystemToVpsDateTimeFormated(
                        DateTimeConverter.GetDateTimeFromSeconds(placeholder.CreatedOn)),
                AttributeOrigin = placeholder.AttributeOrigin,
                AttributeTypeId = placeholder.AttributeTypeId != null ? Convert.ToInt16(placeholder.AttributeTypeId.Value) : 0,
                Id = placeholder.Id,
                AttributeType = placeholder.AttributeType,
                Name = placeholder.AttributeName,
                CommonName = placeholder.CommonName,
                OldCommonName = placeholder.CommonName,
                HelpText = placeholder.HelpText,
                EditLevel = placeholder.EditLevel != null ? placeholder.EditLevel.Value : 0,
                ToolTip = placeholder.Description,
                IsMandatory = "N",
                SupportsHistory = placeholder.SupportsHistoricalValues,
                IsStandard = placeholder.IsStandard,
                LinesToShow = placeholder.TextLineNumbers.ToString(),
                EntityId = CustomAttributeType.Placeholder.ToString()
            };

            switch ((CustomAttributeDataType)(custAttributeModel.AttributeTypeId))
            {
                case CustomAttributeDataType.String:
                    if (!string.IsNullOrEmpty(placeholder.MaxValue)) custAttributeModel.MaxValue = placeholder.MaxValue;
                    if (!string.IsNullOrEmpty(placeholder.MinValue)) custAttributeModel.MinValue = placeholder.MinValue;
                    custAttributeModel.DefaultValue = placeholder.DefaultValue;
                    custAttributeModel.DefaultText = placeholder.DefaultValue;
                    break;
                case CustomAttributeDataType.Checkbox:
                    custAttributeModel.DefaultValue = placeholder.DefaultValue;
                    break;
                case CustomAttributeDataType.Picklist:
                    custAttributeModel.DefaultValue = placeholder.DefaultValue;
                    if (placeholder.Values != null && placeholder.Values.Any())
                    {
                        var pListStr = new System.Text.StringBuilder();
                        placeholder.Values.ToList().ForEach(i => pListStr.AppendFormat("{0}<->{1}<->{2}<>", i.ValueId, i.ValueName, i.CommonName));
                        custAttributeModel.PickListValuesCSV = pListStr.ToString();
                        // custAttributeModel.PickListValues = placeholder.Values.Select(i => new PicklistValues { ValueId = i.ValueId, ValueName = i.ValueName, CommonName = i.CommonName, DefaultValue = (i.ValueId.ToString()==custAttributeModel.DefaultValue) }).ToList();
                    }
                    break;
                case CustomAttributeDataType.MultiPicklist:
                    custAttributeModel.DefaultValue = placeholder.DefaultValue;
                    if (placeholder.Values != null && placeholder.Values.Any())
                    {
                        var pListStr = new System.Text.StringBuilder();
                        placeholder.Values.ToList().ForEach(i => pListStr.AppendFormat("{0}<->{1}<->{2}<>", i.ValueId, i.ValueName, i.CommonName));
                        custAttributeModel.PickListValuesCSV = pListStr.ToString();
                    }
                    break;
                case CustomAttributeDataType.Date:
                    custAttributeModel.DefaultValue = string.IsNullOrEmpty(placeholder.DefaultValue) ? string.Empty : DateTimeHelper.ConvertFromUTCTicksToDate(placeholder.DefaultValue);
                    break;
                case CustomAttributeDataType.DateTime:
                    custAttributeModel.DefaultValue = string.IsNullOrEmpty(placeholder.DefaultValue) ? string.Empty : DateTimeHelper.ConvertFromUTCTicksToDateTime(placeholder.DefaultValue);
                    break;
                case CustomAttributeDataType.Time:
                    var time = string.IsNullOrEmpty(placeholder.DefaultValue)
                        ? string.Empty
                        : DateTimeHelper.ConvertFromUTCTicksToTime(placeholder.DefaultValue);
                    custAttributeModel.DefaultValue = time;
                    break;

            }



            if (placeholder.ProviderId == 3 && placeholder.IsStandard == "Y")
            {
                var systemInfo = new SystemPlaceholders
                {
                    OrganizationName = RuntimeContext.Provider.ProviderName,
                    OrganizationId = RuntimeContext.Provider.Id.ToString(CultureInfo.InvariantCulture),
                    OperatorFullName = GetOperatorName(),
                    PublishDate = RuntimeContext.Provider.CurrentSystemTimeToVps().ToString(RuntimeContext.Provider.GetDateFormat()),
                    PublishTime = RuntimeContext.Provider.CurrentSystemTimeToVps().ToString(RuntimeContext.Provider.GetTimeFormat()),
                    TimeZone = SettingsHelper.GetLocalizedTimeZone(RuntimeContext.Provider.GetVpsTimeZoneFromId().Id),

                };
                var sysPlaceholderList = systemInfo.GetSystemStaticPlaceholders();
                custAttributeModel.DefaultValue = sysPlaceholderList[placeholder.CommonName];
            }
            return custAttributeModel;
        }


        /// <summary>
        /// returning the user name based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        private string GetUserName(int? id)
        {
            var userDetail = _userFacade.GetUserBySpec(new UserSpec { OperatorId = id, UserId = id });
            return userDetail != null ? userDetail.UserName : string.Empty;
        }

        /// <summary>
        /// Getting attribute details and check it is deletable or not
        /// </summary>
        /// <param name="placeholderId">Attribute Id</param>
        /// <param name="isDeletable">Deletable</param>
        /// <returns></returns>
        [NonAction]
        private CustomAttribute IsPlaceholderDeletableOnCurrentContext(int placeholderId, out bool isDeletable)
        {
            var userAttributeDetails =
                _customAttributeFacade.GetCustomAttributesBySpec(new CustomAttributeSpec { Id = placeholderId, IncludeValues = true, OperatorId = RuntimeContext.OperatorId, ProviderId = RuntimeContext.ProviderId, BaseLocale = RuntimeContext.Provider.BaseLocale, EntityType = new List<CustomAttributeType> { CustomAttributeType.Placeholder } })
                    .ToList();
            isDeletable = false;
            if (userAttributeDetails.Any())
            {
                var userAttribute = userAttributeDetails.First();

                isDeletable = ((userAttribute.ProviderId == RuntimeContext.ProviderId)
                               && (userAttribute.IsSystemAttribute != "Y" && userAttribute.IsStandard != "Y"));
                return userAttribute;
            }
            return null;
        }

        /// <summary>
        /// Getting attribute dependecny list
        /// </summary>
        /// <param name="spec">CustomAttributeDeleteDependencySpec</param>
        /// <returns></returns>
        [IWSAuthorize(new[] { SystemObject.VirtualSystemConfiguration }, new[] { ActionType.Modify })]
        public ActionResult GetPlaceholderDependencyList(CustomAttributeDeleteDependencySpec spec)
        {
            try
            {
                spec.ProviderId = RuntimeContext.ProviderId;
                var dependencyList = _customAttributeFacade.CheckPlaceholderDeleteDependencies(spec).ToList();
                spec.PageSize = 1000; //To fetch total dependency count.
                spec.Page = 1;

                if (dependencyList.Any())
                {
                    LocalizeDependencyList(dependencyList);
                    return Json(new
                    {
                        Success = true,
                        Data = dependencyList,
                        TotalCount = dependencyList.Count,
                        PageCount = dependencyList.Count,
                    }, JsonRequestBehavior.AllowGet);
                }
                return Json(new
                {
                    Success = true
                });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                return Json(new
                {
                    Success = false
                });
            }
        }
        private void LocalizeDependencyList(IEnumerable<CustomAttributeDeleteDependency> dependencyList)
        {
            try
            {
                dependencyList.ToList().ForEach(item =>
                {
                    item.EntityName = SettingsHelper.GetPageDependencyLocalizeString(item.EntityName);
                });
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
            }
        }

        public ActionResult GetPlaceholderValues(int placeholderId)
        {
            var attributeValues = _customAttributeFacade.GetCustomAttributeValuesBySpec(new CustomAttributeValueSpec { AttributeId = placeholderId, BaseLocale = RuntimeContext.Provider.BaseLocale });
            return Json(new
            {
                Success = true,
                Data = attributeValues
            });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="contentType"></param>
        /// <param name="base64"></param>
        /// <param name="fileName"></param>
        /// <returns></returns>
        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.VirtualSystemConfiguration }, new[] { ActionType.Modify })]
        public ActionResult ExportDependencies(string contentType, string base64, string fileName)
        {
            var fileContents = Convert.FromBase64String(base64);
            return File(fileContents, contentType, fileName);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="placeholderId"></param>
        /// <param name="commonName"></param>
        /// <returns></returns>
        [IWSAuthorize(new[] { SystemObject.VirtualSystemConfiguration }, new[] { ActionType.Modify })]
        public ActionResult DeletePlaceHolder(int placeholderId, string commonName)
        {
            var messages = new Messages();
            try
            {
                bool isDeletable;
                IsPlaceholderDeletableOnCurrentContext(placeholderId, out isDeletable);
                if (isDeletable)
                {
                    var result = _customAttributeFacade.DeleteCustomAttribute(RuntimeContext.OperatorId, RuntimeContext.ProviderId, placeholderId, commonName, string.Empty, string.Empty, CustomAttributeType.Placeholder.ToString(), GetOperatorName());

                    return Json(new { Success = true, Messages = result }, JsonRequestBehavior.AllowGet);
                }
                messages.Add(new Message { Value = IWSResources.UserAttributeManager_Attribute_Delete_Failed_Message, Type = MessageType.Error });
                return Json(new { Success = false, Messages = messages });
            }
            catch (Exception exec)
            {
                messages.Add(new Message { Value = exec.Message, Type = MessageType.Error });
                LogService.Current.Error(() => exec);
                return Json(new { Success = false, Messages = messages });
            }
        }

        public ActionResult GetPlaceholderTypes()
        {
            var data = _customAttributeFacade.GetUserAttributeTypes();
            return Json(new
            {
                Success = true,
                Data = data
            });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="placeholderId"></param>
        /// <returns></returns>
        [IWSAuthorize(new[] { SystemObject.VirtualSystemConfiguration }, new[] { ActionType.Modify })]
        public ActionResult DeletePickListOption(int placeholderId)
        {
            var messages = new Messages();
            try
            {
                var operatorId = RuntimeContext.OperatorId;
                var result = _customAttributeFacade.DeletePickListValues(placeholderId, operatorId);
                return Json(new { Success = true, Messages = result });
            }
            catch (Exception exec)
            {
                messages.Add(new Message { Value = exec.Message, Type = MessageType.Error });
                LogService.Current.Error(() => exec);
                return Json(new { Success = false, Messages = messages });
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="attributeId"></param>
        /// <param name="valueId"></param>
        /// <returns></returns>
        [IWSAuthorize(new[] { SystemObject.VirtualSystemConfiguration }, new[] { ActionType.Modify })]
        public ActionResult DeletePickListValue(int providerId, int attributeId, int valueId)
        {
            var messages = new Messages();
            try
            {
                var operatorId = RuntimeContext.OperatorId;
                var result = _customAttributeFacade.DeletePickListValue(GetOperatorName(), providerId, attributeId, valueId, operatorId);
                return Json(new { Success = true, Messages = result });
            }
            catch (Exception exec)
            {
                messages.Add(new Message { Value = exec.Message, Type = MessageType.Error });
                LogService.Current.Error(() => exec);
                return Json(new { Success = false, Messages = messages });
            }
        }

        /// <summary>
        /// Save attribute details
        /// </summary>
        /// <param name="model">Attribute details</param>
        /// <returns></returns>tr
        [HttpPost]
        public ActionResult SavePlaceholder(CustomAttributeModel model)
        {

            var providerId = RuntimeContext.ProviderId;
            try
            {
                #region " Populate Custom Attribute Model for Save"
                model.Locale = RuntimeContext.Provider.BaseLocale;
                model.LocaleCode = RuntimeContext.Provider.BaseLocale;
                model.IsSystem = "N";
                model.IsStandard = "N";
                model.CommonName = model.Name;
                if (model.Description != null) model.Description = model.Description;
                model.UpdatedBy = RuntimeContext.OperatorId.ToString(CultureInfo.InvariantCulture);
                model.CreatedBy = RuntimeContext.OperatorId.ToString(CultureInfo.InvariantCulture);
                model.OperatorId = RuntimeContext.OperatorId;
                model.Locale = RuntimeContext.Provider.BaseLocale;
                switch ((CustomAttributeDataType)model.AttributeTypeId)
                {
                    case CustomAttributeDataType.String:
                        model.DefaultValue = model.DefaultText;
                        break;
                    case CustomAttributeDataType.Checkbox:
                        model.DefaultValue = model.DefaultValue == "True" ? "Yes" : "No";
                        model.PicklistDelimiter = "<>";
                        break;
                    case CustomAttributeDataType.Picklist:
                        model.PicklistDelimiter = "<>";
                        break;
                    case CustomAttributeDataType.MultiPicklist:
                        model.PicklistDelimiter = "<>";
                        break;
                    case CustomAttributeDataType.Date:
                        if (!string.IsNullOrWhiteSpace(model.DefaultValue))
                        {
                            DateTime dateEart = DateTime.ParseExact(model.DefaultValue, (model.AttributeTypeId == (int)CustomAttributeDataType.DateTime ?
                                RuntimeContext.Provider.GetDateTimeFormat() : RuntimeContext.Provider.GetDateFormat()), null);
                            if (dateEart != DateTime.MinValue)
                                model.DefaultValue = DateTimeHelper.ConvertToUTCDateTicks(model.DefaultValue, DateTimeHelper.GetDateFormat());
                        }
                        break;
                    case CustomAttributeDataType.DateTime:
                        if (!string.IsNullOrWhiteSpace(model.DefaultValue))
                        {
                            DateTime dateEart = DateTime.ParseExact(model.DefaultValue, (model.AttributeTypeId == (int)CustomAttributeDataType.DateTime ?
                                RuntimeContext.Provider.GetDateTimeFormat() : RuntimeContext.Provider.GetDateFormat()), null);
                            if (dateEart != DateTime.MinValue)
                                model.DefaultValue = DateTimeHelper.ConvertToUTCDateTicks(model.DefaultValue, DateTimeHelper.GetDateFormat() + " " + RuntimeContext.Provider.GetTimeFormat());
                        }
                        break;
                    case CustomAttributeDataType.Time:
                        if (!string.IsNullOrWhiteSpace(model.DefaultValue))
                        {
                            var date = "01/01/2001 " + model.DefaultValue;
                            DateTime dateEart = DateTime.ParseExact(date, "MM/dd/yyyy " + RuntimeContext.Provider.GetTimeFormat(), null);
                            if (dateEart != DateTime.MinValue)
                                model.DefaultValue = DateTimeHelper.ConvertToUTCTimeTicks(model.DefaultValue);
                        }
                        break;

                }
                #endregion " Populate Custom Attribute Model for Save"
                var resultMessage = _customAttributeFacade.SaveCustomAttribute(model, providerId);
                bool isEditable = true;

                if (!resultMessage.HasErrors())
                {
                    //Edit Info Section Implementation 
                    string updatedOn = string.Empty;
                    string createdOn = string.Empty;
                    int attributeId = 0;
                    var userName = string.Empty;
                    var userNameUpdatedBy = string.Empty;
                    var custAttributeModel = new CustomAttributeModel();
                    #region "Get Saved User Attribute Details to populated in UI"
                    var userAttributeDetails =
                   _customAttributeFacade.GetCustomAttributesBySpec(new CustomAttributeSpec { CommonName = model.CommonName, IncludeValues = true, OperatorId = RuntimeContext.OperatorId, ProviderId = RuntimeContext.Provider.Id, BaseLocale = RuntimeContext.Provider.BaseLocale, EntityType = new List<CustomAttributeType> { CustomAttributeType.Placeholder } }).FirstOrDefault();

                    if (userAttributeDetails != null)
                    {
                        custAttributeModel = GetPlaceholderDetail(userAttributeDetails);
                        if (userAttributeDetails.IsStandard == "Y" || userAttributeDetails.ProviderId == 3)
                        {
                            isEditable = false;
                        }
                        updatedOn = RuntimeContext.Provider.SystemToVpsDateTimeFormated(DateTimeConverter.GetDateTimeFromSeconds(userAttributeDetails.UpdatedOn));
                        createdOn = RuntimeContext.Provider.SystemToVpsDateTimeFormated(DateTimeConverter.GetDateTimeFromSeconds(userAttributeDetails.CreatedOn));
                        attributeId = userAttributeDetails.Id;
                        userName = GetUserName(userAttributeDetails.CreatedBy.HasValue ? userAttributeDetails.CreatedBy : 0);
                        userNameUpdatedBy = GetUserName(userAttributeDetails.UpdatedBy.HasValue ? userAttributeDetails.UpdatedBy : 0);
                    }
                    #endregion "Get Saved User Attribute Details to populated in UI"
                    return Json(new { ErrorMessage = resultMessage.ToList(), Success = true, UserName = userName, UpdatedBy = userNameUpdatedBy, CreatedOn = createdOn, UpdatedOn = updatedOn, AttributeID = attributeId, IsEditeable = isEditable, PlaceholderDetails = custAttributeModel }, JsonRequestBehavior.AllowGet);

                }
                return Json(new { ErrorMessage = resultMessage.ToList(), Success = false }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogService.Current.Error(() => ex);
                var messages = new Messages();
                messages.Add(new Message
                {
                    Type = MessageType.Error,
                    Value = IWSResources.UserAttributeManager_Save_Failed_Message
                });
                return Json(new { ErrorMessage = messages, Success = false }, JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="form"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult ImportValues(FormCollection form)
        {
            var currentOperator = RuntimeContext.Operator;


            var fileName = "Athoc-IWS_" + RuntimeContext.Provider.ProviderName + "_" + DateTime.Now.ToString("MM_dd_yyy_hh_mm_ss_fff");
            var directoryLocation = _configurations.FilesBasePath + Constants.ImportFileUploadPath;
            var savePath = directoryLocation + fileName;
            var isValidFile = true;
            var errorRecords = 0;

            try
            {
                //  return the call in case of file not found
                if (Request.Files.Count <= 0)
                    return Json(new { Success = false, Error = IWSResources.DistributionList_Error_ImportUser_InvalidFileFormat }, "text/plain");

                //  valid for file extension and return the call in case of invalid extension
                var acceptedExtensions = new[] { ".csv" };
                var file = Request.Files[0];
                if (file != null && !acceptedExtensions.Contains(Path.GetExtension(file.FileName)))
                {
                    return Json(new { Success = false, Error = IWSResources.DistributionList_Error_ImportUser_InvalidFile }, "text/plain");
                }

                #region Parse CSV
                file.SaveAs(savePath);
                var valueList = new List<string>();
                var textReader = new StreamReader(new MemoryStream(System.IO.File.ReadAllBytes(savePath)), AtHocConfigService.Current.Windows1252Encoding);
                var reader = new CsvHelperCsvReader(new Infrastructure.Csv.CsvReaderSettings { HasHeaderRecord = false, Reader = textReader });
                while (reader.Read())
                {
                    if (reader.CurrentRecord.Count() > 1)
                        return Json(new { Success = false, Error = IWSResources.DistributionList_Error_ImportUser_InvalidFileFormat }, "text/plain");

                    string value = reader.CurrentRecord.GetValue(0).ToString();
                    if (!string.IsNullOrEmpty(value))
                    {

                        if ((!(value.Contains("<") || value.Contains(">"))) && (!string.IsNullOrEmpty(value)) && (!valueList.Contains(value)))
                            valueList.Add(value);
                        else
                            errorRecords++;
                    }
                }

                #endregion Parse CSV

                // Mark valid file as false in case of empty file
                if (valueList.Count == 0)
                    isValidFile = false;
                return isValidFile ? Json(new { Success = true, data = valueList.ToArray(), errorrecords = errorRecords }) : Json(new { Success = false, Error = IWSResources.DistributionList_Error_ImportUser_InvalidFileFormat }, "text/plain");
            }
            catch
            {
                return Json(new { Success = false, Error = IWSResources.DistributionList_Error_ImportUser_InvalidFileFormat }, "text/plain");
            }
            finally
            {
                if (System.IO.File.Exists(savePath))
                {
                    System.IO.File.Delete(savePath);
                }
            }

        }

        private string GetMimeType(string fileName)
        {
            string mimeType = "application/unknown";
            string ext = System.IO.Path.GetExtension(fileName).ToLower();
            Microsoft.Win32.RegistryKey regKey = Microsoft.Win32.Registry.ClassesRoot.OpenSubKey(ext);
            if (regKey != null && regKey.GetValue("Content Type") != null)
                mimeType = regKey.GetValue("Content Type").ToString();
            return mimeType;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="contentType"></param>
        /// <param name="base64"></param>
        /// <param name="fileName"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult ExportPlaceholderValues(string contentType, string base64, string fileName)
        {
            var fileContents = Convert.FromBase64String(base64);
            return File(fileContents, contentType, fileName);
        }

        public string GetOperatorName()
        {
            var operatorName = string.IsNullOrWhiteSpace(RuntimeContext.Operator.DisplayName)
                  ? (!string.IsNullOrWhiteSpace(RuntimeContext.Operator.FirstName) || !string.IsNullOrWhiteSpace(RuntimeContext.Operator.LastName)
                      ? RuntimeContext.Operator.FirstName + " " + RuntimeContext.Operator.LastName
                      : RuntimeContext.Operator.Username)
                  : RuntimeContext.Operator.DisplayName;
            return string.IsNullOrEmpty(RuntimeContext.Operator.FullName)
                ? operatorName
                : RuntimeContext.Operator.FullName;
        }

    }
}