﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Helpers;
using System.Web.Mvc;
using System.Web.Security;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Web;
using AtHoc.Infrastructure.Resources;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Web.Helpers;
using AtHoc.Global.Resources;
using AtHoc.Data;
using AtHoc.IWS.Business.Data.SearchSpec;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Business.Domain.Settings.Model;

namespace AtHoc.IWS.Web.Areas.Settings.Controllers
{
    public class SubAccountManagerController : Controller
    {

        private readonly IProviderFacade _providerFacade;
        private readonly ILogService _logService;

        public SubAccountManagerController(IProviderFacade providerFacade, ILogService logService)
        {
            _providerFacade = providerFacade;
            _logService = logService;

        }

       
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            return View();
        }


        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public JsonResult GetSubAccountManagers()
        {
            try
            {
                var providerList = _providerFacade.GetProviderData();
                return  Json(new
                    {
                        Success = true,
                        TotalCount = providerList.ToList().Count,
                        Data = providerList
                    });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Messages = IWSResources.Scenario_Error_LoadingScenarioDetail });
            }

        }
	}
}