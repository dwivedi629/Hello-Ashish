﻿using System;
using System.Web.Mvc;
using AtHoc.IWS.Web.Context;
using AtHoc.Security;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Resources;
using AtHoc.IWS.Business.Context;
using AtHoc.Global.Resources;
using AtHoc.IWS.Web.Helpers;
using AtHoc.IWS.Web.Filters;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Authorization;
namespace AtHoc.IWS.Web.Areas.Settings.Controllers
{
    [IWSAuthorize(new[] { SystemObject.SystemServerSettings }, new[] { ActionType.Modify })]
    public class SystemController : Controller
    {
        private readonly ISystemFacade _systemFacade;
        private readonly ILogService _logService;
        private readonly IAuthFacade _authFacade;

        public SystemController(ISystemFacade systemFacade, ILogService logService, IAuthFacade authFacade)
        {
            _systemFacade = systemFacade;
            _logService = logService;
            _authFacade = authFacade;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>       
       
        public ActionResult Index()
        {
            var provider = RuntimeContext.Provider;
            ViewBag.DateFormat = provider.GetDateFormat();
            ViewBag.DateTimeFormat = provider.GetDateTimeFormat();
            var vpsTimeZOne = provider.GetVpsTimeZoneFromId();
            ViewBag.VPSTimeZone = vpsTimeZOne;
            return View();
        }

        /// <summary>
        /// To get System settings from database
        /// </summary>
        /// <returns> returns system settings in JSON format</returns>

        [HttpPost]
        public ActionResult GetSystemSettings()
        {
            var error = string.Empty;

            try
            {

                
               var   data = _systemFacade.GetSystemSettings();
                var provider = RuntimeContext.Provider;
                var providerId = RuntimeContext.ProviderId;
                var operatorId = RuntimeContext.OperatorId;
                var vpsTimeZOne = provider.GetVpsTimeZoneFromId();
                data.TimeZone = TimeZoneInfo.Local.DisplayName;
                //data.IsEnterpriseAdmin = _authFacade.HasAccess(operatorId, providerId, SystemObject.EnterpriseAdmin, ActionType.View);
                // Changed for IWS-21927
                data.IsSystemAdmin = _authFacade.HasAccess(RuntimeContext.Operator, providerId, SystemObject.SystemServerSettings, ActionType.Modify);

                // get dropdown list
                var SystemSettingsFormatModel = SettingsHelper.GetSystemSettingsFormatModel();
                return Json(new { Data = data, formatModel = SystemSettingsFormatModel, Success = true, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }) });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Error = IWSResources.SystemSettings_InvalidGet }, "text/plain");
            }

          
        }

        /// <summary>
        /// To save System settings in the database
        /// </summary>
        /// <returns></returns>

        [HttpPost]
        public ActionResult SaveSystemSettings(SystemSettingsModel systemSettingsModel)
        {
            var blResult = false;

            try
            {
                systemSettingsModel.operatorId = RuntimeContext.OperatorId;
                systemSettingsModel.providerId = RuntimeContext.ProviderId;
                blResult = _systemFacade.SaveSystemSettings(systemSettingsModel);
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = blResult, Error = IWSResources.SystemSettings_InvalidSave }, "text/plain");
            }

            return Json(new { Data = blResult, Success = true});

        }

        

       
    }
}