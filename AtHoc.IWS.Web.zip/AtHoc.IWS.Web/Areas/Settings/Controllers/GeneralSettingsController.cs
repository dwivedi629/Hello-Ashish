﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mime;
using System.Threading;
using System.Web;
using System.Web.Mvc;
using System.Xml;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Security;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Resources;
using AtHoc.IWS.Business.Adapter;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.Global.Resources;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.PageLayout;
using AtHoc.IWS.Business.Domain.PageLayout.Spec;
using AtHoc.IWS.Business.Domain.Authorization;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Users.Impl.Search;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Web.Filters;
using AtHoc.IWS.Business.Domain.Users;
using AtHoc.IWS.Business.Domain.Users.Spec;
using System.Text;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.IWS.Web.Helpers;
using AtHoc.IWS.Web.Models.Publishing;
using EO.Internal;
using EO.Pdf;
using AtHoc.IWS.Business.Domain.Settings.Spec;
using AtHoc.IWS.Business.Domain.Targeting.Model;


namespace AtHoc.IWS.Web.Areas.Settings.Controllers
{


    public class GeneralSettingsController : Controller
    {
        private readonly IGeneralSettingsFacade _generalFacade;
        private readonly ILogService _logService;
        private readonly IAuthFacade _authFacade;
        private readonly IOperatorFacade _operatorFacade;
        private readonly IPageLayoutFacade _pageLayoutFacade;
        private readonly ICustomAttributeFacade _customAttributeFacade;
        private readonly ILanguageFacade _languageFacade;
        private readonly ICustomAttributeCache customAttributeCache;       
        private readonly IUserFacade _userFacade;
        public GeneralSettingsController(IGeneralSettingsFacade generalFacade, ILogService logService, IAuthFacade authFacade, IOperatorFacade operatorFacade, IPageLayoutFacade pageLayoutFacade, ICustomAttributeFacade customAttributeFacade, ILanguageFacade languageFacade,IUserFacade userFacade)
        {
            _generalFacade = generalFacade;
            _logService = logService;
            _authFacade = authFacade;
            _operatorFacade = operatorFacade;
            _pageLayoutFacade = pageLayoutFacade;
            _customAttributeFacade = customAttributeFacade;
            _languageFacade = languageFacade;           
            _userFacade = userFacade;
        }

        // GET: /Settings/GeneralSettings/       
        [IWSAuthorize(new SystemObject[] { SystemObject.VirtualSystemConfiguration, SystemObject.GeneralSettings }, new ActionType[] { ActionType.Modify, ActionType.Modify })]
        public ActionResult Index()
        {
            var provider = RuntimeContext.Provider;
            ViewBag.IsAffiliate = (provider.ProviderType() == VPSType.Affiliate25 ||
                               provider.ProviderType() == VPSType.Affiliate25Template);



            return View();
        }


        /// <summary>
        /// Get the general setting based on providerId and timezones
        /// </summary>
        /// <returns>Generalsetting,TimeZones</returns>
        [HttpPost]
        public JsonResult GetGeneralSettings()
        {
            var error = string.Empty;
            try
            {
                var providerId = RuntimeContext.ProviderId;
                var operatorId = RuntimeContext.OperatorId;
                var data = _generalFacade.GetGeneralSettings(providerId);
         
                var systemUser = _operatorFacade.GetUser(new SystemUserSpec { ProviderId = providerId, OperatorId = operatorId });
                data.IsSystemAdmin = systemUser.Roles.Count(e => e.RoleId == (int)Roles.SystemAdmin) > 0;
                var languages = _languageFacade.GetOperatorEnabledLanguages().ToList();
                var timeZones = TimeZoneInfo.GetSystemTimeZones().Select(timeZoneInfo => new MultiSelectListModel { Value = timeZoneInfo.Id, Text = SettingsHelper.GetLocalizedTimeZone(timeZoneInfo.Id) }).ToList();
                return Json(new { Data = data, TimeZones = timeZones, langSupports = languages,ProviderLocale = RuntimeContext.Provider.BaseLocale, Success = true, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }) }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, HasErrors = !string.IsNullOrWhiteSpace(IWSResources.GeneralSettings_InvalidGet), Messages = (string.IsNullOrWhiteSpace(IWSResources.GeneralSettings_InvalidGet)) ? null : new Messages(new Message { Type = MessageType.Error, Value = IWSResources.GeneralSettings_InvalidGet }) }, "text/plain");
            }

        }

        
        [HttpPost]
        public JsonResult GetUniquenessUsersList(EnterpriseUniuenessDependencySpec spec)
        {
            var error = string.Empty;
            try
            {
                var providerId = spec.ProviderId = RuntimeContext.ProviderId;
                var operatorId = RuntimeContext.OperatorId;
                var uniquenessUserListData = _operatorFacade.GetUniquenessUsersList(spec);
                var enterpriseUserDependencyList = (List<EnterpriseUserUniquenessDependency>)uniquenessUserListData["UserUniquenessList"];
                int totalUsersCount = (Int32)uniquenessUserListData["totalRecordsCount"];
                return Json(new { Data = enterpriseUserDependencyList, TotalCount = totalUsersCount, PageCount = enterpriseUserDependencyList.Count, Success = true }, JsonRequestBehavior.AllowGet);
              
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, HasErrors = !string.IsNullOrWhiteSpace(IWSResources.GeneralSettings_InvalidGet), Messages = (string.IsNullOrWhiteSpace(IWSResources.GeneralSettings_InvalidGet)) ? null : new Messages(new Message { Type = MessageType.Error, Value = IWSResources.GeneralSettings_InvalidGet }) }, "text/plain");
            }

        }


        /// <summary>
        /// Checking org code is already existed or not
        /// </summary>
        /// <param name="orgCode">Org Code</param>
        /// <returns>JsonResult contains true/false</returns>
        [HttpPost]
        public JsonResult CheckOrganizationCode(string orgCode)
        {
            var result = false;
            var error = string.Empty;
            try
            {
                var providerId = RuntimeContext.ProviderId;
                result = _generalFacade.IsOrgCodeExists(providerId, orgCode);
                if (result)
                    error = IWSResources.GeneralSettingsOrgCode_Alredy_Existed;
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = result, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }) });

            }
            return Json(new { Success = result, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }) });
        }


        /// <summary>
        /// Saving the general settings
        /// </summary>
        /// <param name="generalSettings">General setting data</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult SaveGeneralSettings(GeneralSettings generalSettings)
        {
            string error = string.Empty;
            var result = false;
            var providerId = RuntimeContext.ProviderId;
            var currentUserId = RuntimeContext.OperatorId;
            try
            {
                generalSettings.ProviderId = providerId;
                if (_generalFacade.IsVirtualNameExists(generalSettings))
                {
                    error = IWSResources.GeneralSettings_Name_Alredy_Existed;
                }
                else
                {
                    if (!generalSettings.OrgCode.IsNullOrEmpty() && _generalFacade.IsOrgCodeExists(generalSettings.ProviderId, generalSettings.OrgCode))
                        error = IWSResources.GeneralSettings_OrgCode_Alredy_Existed;
                    else if (!string.IsNullOrEmpty(generalSettings.WebImageData) &&
                         !CheckValidImage(generalSettings.WebImageData))
                        error = IWSResources.MimeType_File_Exception;
                    else if (!string.IsNullOrEmpty(generalSettings.AlertImageData) &&
                                                 !CheckValidImage(generalSettings.AlertImageData))
                        error = IWSResources.MimeType_File_Exception;
                    else
                        result = _generalFacade.UpdateGeneralSettings(generalSettings, currentUserId);
                }

                var provider = RuntimeContext.RefreshedProviderContext;
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Error = IWSResources.GeneralSettings_InvalidSave }, "text/plain");
            }
            return Json(new { Success = result, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }) });
        }

        /// <summary>
        /// Convert image to string
        /// </summary>
        /// <returns>string content</returns>
        [HttpPost]
        public JsonResult GetImageString()
        {
            byte[] imageBytes = null;
            var fileData = Request.Files[0];
            if (!FileMimeTypeValidation.ValidateMimeType(fileData.InputStream, FileType.Image))
            {
                return Json(new { data = "", extension = "error", type = "", Success = false }, "text/plain");
            }
            fileData.InputStream.Position = 0;
            BinaryReader reader = new BinaryReader(fileData.InputStream);
            imageBytes = reader.ReadBytes((int)fileData.ContentLength);
            var data = Convert.ToBase64String(imageBytes);
            var extension = fileData.FileName.Substring(fileData.FileName.LastIndexOf('.') + 1);
            return Json(new { data = data, extension = extension, type = fileData.ContentType, Success = true }, "text/plain");
        }

        public ActionResult OperatorLayout(string PageId)
        {
            var provider = RuntimeContext.Provider;
            var error = string.Empty;
            var layout =
                _pageLayoutFacade.GetPageLayoutBySpec(new PageLayoutSpec { ProviderId = provider.Id, PageId = PageId })
                                .FirstOrDefault();

            var xml = new XmlDocument();
            if (layout != null)
            {
                xml.LoadXml(layout.LayoutXml);
            }
            else
            {
                error = IWSResources.GeneralSettings_ErrorMsg_OperatorLayout;
                return Json(new { Success = false, Error = error }, "text/plain");

            }

            return Json(new { Success = true, Data = FormatXml(xml), HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }) });

        }

        protected override JsonResult Json(object data, string contentType, System.Text.Encoding contentEncoding, JsonRequestBehavior behavior)
        {
            return new JsonResult
            {
                Data = data,
                //ContentType = !Request.AcceptTypes.Contains("application/json") ? "text/html" : contentType,
                ContentType = contentType,
                ContentEncoding = contentEncoding,
                JsonRequestBehavior = behavior,
                MaxJsonLength = Int32.MaxValue
            };
        }
   
        [NonAction]
        private string FormatXml(XmlNode xmlNode)
        {
            var bob = new StringBuilder();
            using (var stringWriter = new StringWriter(bob))
            {
                using (var xmlTextWriter = new XmlTextWriter(stringWriter))
                {
                    xmlTextWriter.Formatting = Formatting.Indented;
                    xmlNode.WriteTo(xmlTextWriter);
                }
            }

            return bob.ToString();
        }

        [NonAction]
        private bool CheckValidImage(string logoImageBase64String)
        {
            byte[] imageBytes = Convert.FromBase64String(logoImageBase64String);
            var logoImageStream = new MemoryStream(imageBytes);
            return FileMimeTypeValidation.ValidateMimeType(logoImageStream, FileType.Image);
        }

      
        public ActionResult ExportDuplicateUsers(string contentType, string base64, string fileName)
        {
            var fileContents = Convert.FromBase64String(base64);
            return File(fileContents, contentType, fileName);
        }
    }
    
}