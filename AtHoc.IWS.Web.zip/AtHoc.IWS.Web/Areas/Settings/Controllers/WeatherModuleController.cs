﻿using AtHoc.Infrastructure.Log;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.Authorization;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Users;
using AtHoc.IWS.Web.Filters;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Xsl;

namespace AtHoc.IWS.Web.Areas.Settings.Controllers
{
    public class WeatherModuleController : Controller
    {
        private readonly ILogService _logService;
        private readonly IAuthFacade _authFacade;
        private readonly IUserFacade _userFacade;
        private readonly IOperatorFacade _operatorFacade;
        private readonly IWeatherModuleFacade _wmFacade;
        public WeatherModuleController(ILogService logService, IAuthFacade authFacade, IUserFacade userFacade, IOperatorFacade operatorFacade, IWeatherModuleFacade weatherModule)
        {
            _wmFacade = weatherModule;
            _logService = logService;
            _authFacade = authFacade;
            _userFacade = userFacade;
            _operatorFacade = operatorFacade;
        }

        // Only authorized user can access this page
        [IWSAuthorize(new SystemObject[] { SystemObject.AlertChannelManager }, new ActionType[] { ActionType.Modify })]
        public ActionResult Index()
        {
            return View();
        }


        /// <summary>
        /// This method will search geocode based on stateid and zipcode
        /// </summary>
        /// <returns>Collection of geocodes</returns>
        [HttpPost]
        public JsonResult SearchGeoCode(WeatherModuleCriteria objCriteria)
        {
            try
            {
                //validation zipcode and statecode to prevent sql injection
                if (objCriteria.StateCode.Length != 2)
                {
                    return Json(new
                    {
                        Success = false,
                        Data = "Error",
                        TotalCount = 0
                    });
                }

                string _usZipRegEx = @"^\d{5}(?:[-\s]\d{4})?$";
                if (objCriteria.ZipCode != null && objCriteria.ZipCode.Length != 0 && !Regex.Match(objCriteria.ZipCode, _usZipRegEx).Success)
                {
                    return Json(new
                    {
                        Success = false,
                        Data = "Error",
                        TotalCount = 0
                    });
                }

                var geoCodes = _wmFacade.GetAllGeoCodeList(objCriteria);
                return Json(new
                {
                    Success = true,
                    Data = geoCodes,
                    TotalCount = geoCodes.Count
                });
            }
            catch (Exception ex)
            {

                _logService.Error(() => ex);
                return Json(new
                {
                    Success = false,
                    Data = "Error",
                    TotalCount = 0
                });
            }
        }

        

        /// <summary>
        /// Get all alert preference information
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public JsonResult GetAlertingPreferenceInfo(WeatherModuleCriteria objCriteria)
        {
            try
            {
                objCriteria.OperatorId = RuntimeContext.OperatorId;
                objCriteria.ProviderId = RuntimeContext.ProviderId;
                var result = _wmFacade.GetAlertingPreferenceInfo(objCriteria);

                return Json(new
                {
                    Success = true,
                    Data = result,
                });
            }
            catch (Exception ex)
            {

                _logService.Error(() => ex);
                return Json(new
                {
                    Success = false,
                    Data = "Error",
                });
            }
        }

        /// <summary>
        /// This method is used to save all weather related information 
        /// </summary>
        /// <param name="data"></param>
        /// <returns>bool</returns>
        [HttpPost]
        public JsonResult SaveWeatherInformations(WeatherModuleSettings data)
        {
            try
            {
                data.BasicCriteria.ProviderId = RuntimeContext.ProviderId;
                data.BasicCriteria.OperatorId = RuntimeContext.OperatorId;
                _wmFacade.SaveWeatherInformations(data);
                // Save enterprize , basic or sub enterprize data.
                return Json(new
                {
                    // Saving the information on database
                    Success = true
                });
            }
            catch (Exception ex)
            {

                _logService.Error(() => ex);
                return Json(new
                {
                    Success = false,
                    Error = ex.Message,
                });
            }
        }

        /// <summary>
        /// This method is used to save all weather related information 
        /// </summary>
        /// <param name="data"></param>
        /// <returns>bool</returns>
        [HttpPost]
        public JsonResult DisableWeather(WeatherModuleCriteria objCriteria)
        {
            try
            {


                // Save enterprize , basic or sub enterprize data.
                return Json(new
                {
                    // Saving the information on database
                    Success = true
                });
            }
            catch (Exception ex)
            {

                _logService.Error(() => ex);
                return Json(new
                {
                    Success = false,
                    Error = ex.Message,
                });
            }
        }
    }
}