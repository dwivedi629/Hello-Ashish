﻿using System;
using System.Data;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AtHoc.Publishing;
using AtHoc.IWS.Web.Helpers;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Resources;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Web.Resources;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Web.Filters;
using AtHoc.MediaServices;
using AtHoc.IWS.Business.Domain.Settings.Impl;
using AtHoc.IWS.Business.Domain.Authorization;
using Microsoft.Owin.Security.Provider;
using AtHoc.IWS.Business.Domain.Users;
using AtHoc.IWS.Web.Models.Publishing;
using System.Globalization;
using AtHoc.IWS.Business.Domain.Organization;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Serialization;
using AtHoc.Infrastructure.Web.Mvc.ActionFilters;
using AtHoc.IWS.Business;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.Audit;
using AtHoc.IWS.Business.Domain.Authorization;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.IWS.Business.Domain.Devices;
using AtHoc.IWS.Business.Domain.Devices.Spec;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.PageLayout;
using AtHoc.IWS.Business.Domain.PageLayout.Spec;
using AtHoc.IWS.Business.Domain.Publishing;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Business.Domain.Users.Search.UserImport;
using AtHoc.IWS.Business.Domain.Users;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.IWS.Business.Domain.VirtualSystem;
using AtHoc.IWS.Business.Domain.VirtualSystem.Spec;
using AtHoc.IWS.Web.Configurations;
using AtHoc.IWS.Web.Configurations.Constants;
using AtHoc.IWS.Web.Converter.SearchCriteria;
using AtHoc.IWS.Web.Filters;
using AtHoc.IWS.Web.Helpers;
using AtHoc.IWS.Web.Models.UserManager;
using AtHoc.IWS.Web.Resources;
using AtHoc.Security;
using EO.Pdf.Internal;
using EO.Pdf.Mvc;
using EO.Pdf.Mvc5;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using AttributeCriteria = AtHoc.IWS.Business.Domain.Users.Search.AttributeCriteria;
using Controller = AtHoc.Infrastructure.Web.Mvc.Controller;
using Formatting = AtHoc.Infrastructure.Serialization.Formatting;
using JsonResult = System.Web.Mvc.JsonResult;

namespace AtHoc.IWS.Web.Areas.Settings.Controllers
{
    public class TargetingUsersController : Controller
    {
        //
        // GET: /Settings/Tragetting/
        private readonly IAlertFacade _alertFacade;
        private readonly PublishingHelper _publishingHelper;
        private static List<PagerCarrierEntity> pagerCarriers;
        private static IEnumerable<AtHoc.IWS.Business.Domain.Entities.Device> allDevices;
        private static ILookup<string, AtHoc.IWS.Business.Domain.Entities.Device> devicesByCommonName;
        private static ILookup<string, AtHoc.IWS.Business.Domain.Entities.Device> devicesByName;
        private static IEnumerable<OperatorRole> OperatorRoles;
        private IEnumerable<AtHoc.IWS.Business.Domain.Entities.AlertChannel> OperatorAccessibleChannels;
        private IEnumerable<AtHoc.IWS.Business.Domain.Entities.AlertChannel> VPSChannels;
        private IEnumerable<DistributionList> OperatorAccessibleDistributionLists;
        private readonly IAtHocConfigurations configurations;
        private readonly IUserFacade _userFacade;
        private readonly IUserExportImportFacade _userExportImportFacade;
        private readonly IVirtualSystemFacade _virtualSystemFacade;
        private readonly ICustomAttributeFacade customAttributeFacade;
        private readonly IPageLayoutFacade pageLayoutFacade;
        private readonly IDeviceFacade deviceFacade;
        private readonly IOperatorDetailsFacade _operatorDetailsFacade;
        private readonly IOperatorFacade _operatorFacade;
        private readonly IOperatorAuditFacade _operatorAuditFacade;
        private readonly ISearchCriteriaConverter userBaseConverterService;
        private readonly IUserManagerHelper _userManagerHelper;
        private readonly IPublishingFacade _publishingFacade;
        private readonly IAuthFacade _authFacade;

        public TargetingUsersController(IAlertFacade alertFacade, IAuthFacade authFacade, PublishingHelper publishingHelper, IOrganizationFacade organizationFacade, ILogService logService, IAtHocConfigurations configurations,
                                    IUserFacade userFacade, IVirtualSystemFacade _virtualSystemFacade, ICustomAttributeFacade customAttributeFacade,
                                    IPageLayoutFacade pageLayoutFacade, IDeviceFacade deviceFacade,
                                    IOperatorDetailsFacade operatorDetailsFacade, IOperatorFacade operatorFacade, IOperatorAuditFacade operatorAuditFacade,
                                    IUserExportImportFacade userExportImportFacade,
                                    ISearchCriteriaConverter userBaseConverterService, IUserManagerHelper userManagerHelper, IPublishingFacade publishingFacade)
        {
            _alertFacade = alertFacade;
            _publishingHelper = publishingHelper;
            this.configurations = configurations;
            this._userFacade = userFacade;
            this._virtualSystemFacade = _virtualSystemFacade;
            this.customAttributeFacade = customAttributeFacade;
            this.pageLayoutFacade = pageLayoutFacade;
            this.deviceFacade = deviceFacade;
            this._operatorDetailsFacade = operatorDetailsFacade;
            this._operatorFacade = operatorFacade;
            this._operatorAuditFacade = operatorAuditFacade;
            this._userExportImportFacade = userExportImportFacade;
            this.userBaseConverterService = userBaseConverterService;
            this._userManagerHelper = userManagerHelper;
            this._publishingFacade = publishingFacade;
            this._authFacade = authFacade;
        }
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [IWSAuthorize(new[] { SystemObject.Alert }, new[] { ActionType.View })]
        public JsonResult GetTargetingUserList()
        {
            try
            {
                var providerId = RuntimeContext.ProviderId;
                var operatorId = RuntimeContext.OperatorId;

                var alert = _alertFacade.GetAlert(1026737, providerId, operatorId);

                var AlertData = _publishingHelper.GetPublishingModel(alert, providerId, operatorId);

             

                return Json(new
                {
                    Success = true,
                    Data = AlertData.TargetUsers.TargetedBlockedUsers,

                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {

                return Json(new { Success = false, Messages = "" });
            }

        }
        private CustomAttributeLookup _providerAttributes;
        private CustomAttributeLookup ProviderAttributes
        {
            get { return _providerAttributes ?? (_providerAttributes = RuntimeContext.CustomAttributesWithouMassDevices); }
        }
        [HttpPost]
        public ActionResult GetUsers(int page = 1, int pageSize = 25, string sortBy = "displayname", string sortOrder = "ASC", // DONE
            int[] userIds = null,
            int[] listItemIds = null,
            int[] hierarchyIds = null,
            int[] attributeValueIds = null, int[] attributeIds = null,
            string[] searchStrings = null,
            bool? isEnabled = true, bool? isOperator = false,
            string queryCriteria = null,
            int[] includeUserIds = null, int[] excludeUserIds = null,
            int distributionId = 0,
            bool? isMember = null,
            string staticQueryCriteria = null, // NOT USED AS ALREADY TAKEN CARE BY RUNTIME CONTEXT OPERATOR_ID
            bool hideMassDevices = true)
        {
            _userManagerHelper.RefreshDevices(ref allDevices, ref devicesByCommonName, ref devicesByName, true);

            var provider = RuntimeContext.Provider;

            #region Get Attributes

            var customViews =
                customAttributeFacade.GetUserCustomViewsBySpec(new CustomViewSpec
                {
                    ProviderId = provider.Id,
                    OperatorId = RuntimeContext.OperatorId,
                    CustomViewType = CustomViewType.UserManagerV2,
                    IsPlaceholder = false,
                    CustomViewColumnTypes = new[] { CustomViewColumnType.CustomField, CustomViewColumnType.Device },
                }).Where(x => ProviderAttributes.GetByAttributeName(x.Title) != null || x.Columnid == CustomViewColumnType.Device);

            var defaultAttributes = new List<CustomAttribute>(
                ProviderAttributes.GetByCommonNames(
                        new[]
						{
							AttributeCommonNames.UserName,
							AttributeCommonNames.FirstName,
							AttributeCommonNames.DisplayName,
							AttributeCommonNames.LastName
						}
                    )
                );

            #endregion

            // INITIALIZE SEARCH ARGUMENT
            var srchArgs = new UserSearchArgs(RuntimeContext.ProviderId, RuntimeContext.OperatorId, page, pageSize, sortBy, sortOrder, (bool)!isEnabled, (bool)isOperator, hideMassDevices)
            {
                // CUSTOM ATTRIBUTES AND DEVICES TO RETRIEVE
                AttributeNames = InitializeAttributesToRetrieve(defaultAttributes, customViews),
                DeviceNames = InitializeDevicesToRetrieve(customViews)
            };

            // STATIC DISTRIBUTION LIST FLOW
            if (distributionId != 0)
            {
                var dl = _publishingFacade.GetDistributionList(new DistributionListSpec() { Id = distributionId });
                var customCriteria = new List<GenericCriteria> { new AttributeCriteria(Int32.Parse(dl.Definition), CriteriaOperator.Equals, (bool)isMember ? 1 : 0) };
                if (searchStrings != null) srchArgs.Filters.QuickSearchCriteria.AddRange(searchStrings); // QUICK SEARCH TEXT (POST DL SCOPE SEARCH)
                if (!string.IsNullOrEmpty(queryCriteria)) customCriteria.AddRange(InitializeAdvancedSearch(queryCriteria)); // ADVANCED SEARCH CRITERIA (AND to DL criteria)

                // GROUPS Searchable Attributes TO INCLUDE
                foreach (var attributeId in attributeIds ?? new int[] { }) customCriteria.Add(new AttributeCriteria(attributeId, CriteriaOperator.IsNotEmpty, 0));
                var attributesDictionary = GetAttributeIdsByValueIds(attributeValueIds ?? new int[] { });
                foreach (var attributeId in attributesDictionary.Keys) customCriteria.Add(new AttributeCriteria(attributeId, CriteriaOperator.Equals, attributesDictionary[attributeId].Join(",")));

                srchArgs.Filters.CustomCriterias.Add(customCriteria);
            }
            // DYNAMIC DISTRIBUTION LIST FLOW
            else if (distributionId == 0 && staticQueryCriteria != null && staticQueryCriteria.Length != 0)
            {
                if (searchStrings != null) srchArgs.Filters.QuickSearchCriteria.AddRange(searchStrings); // QUICK SEARCH TEXT (POST DL SCOPE SEARCH)
                srchArgs.Filters.CustomCriterias.Add(InitializeAdvancedSearch(staticQueryCriteria)); // ADVANCED SEARCH CRITERIA (AND to DL criteria)

                // GROUPS Searchable Attributes TO INCLUDE
                foreach (var attributeId in attributeIds ?? new int[] { }) srchArgs.Filters.IncludeGroups.Add(new List<GenericCriteria> { new AttributeCriteria(attributeId, CriteriaOperator.IsNotEmpty, 0) });
                var attributesDictionary = GetAttributeIdsByValueIds(attributeValueIds ?? new int[] { });
                foreach (var attributeId in attributesDictionary.Keys) srchArgs.Filters.IncludeGroups.Add(new List<GenericCriteria> { new AttributeCriteria(attributeId, CriteriaOperator.Equals, attributesDictionary[attributeId].Join(",")) });
            }
            // USER MANAGER FLOW
            else
            {
                if (searchStrings != null) srchArgs.Filters.CustomCriterias.AddRange(InitializeQuickSearch(searchStrings, defaultAttributes)); // QUICK SEARCH TEXT (ROOT SCOPE SEARCH)
                if (!string.IsNullOrEmpty(queryCriteria)) srchArgs.Filters.CustomCriterias.Add(InitializeAdvancedSearch(queryCriteria)); // ADVANCED SEARCH CRITERIA

                // GROUPS Searchable Attributes TO INCLUDE
                foreach (var attributeId in attributeIds ?? new int[] { }) srchArgs.Filters.IncludeGroups.Add(new List<GenericCriteria> { new AttributeCriteria(attributeId, CriteriaOperator.IsNotEmpty, 0) });
                var attributesDictionary = GetAttributeIdsByValueIds(attributeValueIds ?? new int[] { });
                foreach (var attributeId in attributesDictionary.Keys) srchArgs.Filters.IncludeGroups.Add(new List<GenericCriteria> { new AttributeCriteria(attributeId, CriteriaOperator.Equals, attributesDictionary[attributeId].Join(",")) });
            }

            // USERIDs INCLUDE OR EXCLUDE
            if (userIds != null) srchArgs.Filters.IncludeUsers.AddRange(userIds);
            if (includeUserIds != null) srchArgs.Filters.IncludeUsers.AddRange(includeUserIds);
            if (excludeUserIds != null) srchArgs.Filters.ExcludeUsers.AddRange(excludeUserIds);

            // HIERARCHIES TO INCLUDE (NODES : Organizational Hierarchy, Distribution Lists)
            if (hierarchyIds != null) srchArgs.Filters.IncludeHierarchies.AddRange(hierarchyIds);

            // LISTS TO INCLUDE (Dynamic Lists, Static Lists, Tree)
            if (listItemIds != null) srchArgs.Filters.IncludeLists.AddRange(listItemIds);

            // SHOULD WE INCLUDE ALL USER BASE
            srchArgs.Filters.IncludeAllUserBase =
                srchArgs.Filters.IncludeGroups.Count == 0 &&
                srchArgs.Filters.IncludeHierarchies.Count == 0 &&
                srchArgs.Filters.IncludeLists.Count == 0 &&
                srchArgs.Filters.CustomCriterias.Count == 0 &&
                srchArgs.Filters.IncludeUsers.Count == 0 &&
                srchArgs.Filters.ExcludeGroups.Count == 0 &&
                srchArgs.Filters.ExcludeHierarchies.Count == 0 &&
                srchArgs.Filters.ExcludeLists.Count == 0;

            // GET USERS
            var users = (ContextSearchResult)_userFacade.SearchUsersV1ByArgs(srchArgs);
            // RETURN RESULT
            var result =
                Json(
                    new
                    {
                        Columns =
                            new[]
                            {
                                new CustomViewColumn
                                {
                                    DisplayName = "Display Name",
                                    Key = "DISPLAYNAME",
                                    IsRequired = true,
                                    IsSortable = true,
                                    CustomViewColumnType = "CF",
                                    DataType = CustomAttributeDataType.String,
                                    DataFormat = string.Empty,
                                    ViewId = 0
                                }
                            }.Union(
                                customViews.Where(
                                    x => x.Columnid == CustomViewColumnType.CustomField || x.Columnid == CustomViewColumnType.Device).Select(
                                        customView => CreateCustomViewColumnModel(provider, customView))),
                        SecondaryColumns =
                            new[]
                            {
                                new CustomViewColumn
                                {
                                    DisplayName = "Username",
                                    Key = AttributeCommonNames.UserName,
                                    IsSortable = true,
                                    CustomViewColumnType = "CF",
                                    DataType = CustomAttributeDataType.String,
                                    DataFormat = string.Empty,
                                    ViewId = 0
                                }
                            },
                        Rows = _userManagerHelper.ConvertToUIModel(users.Users),
                        TotalCounts = users.SearchResultCount,
                        TotalEnabledUsers = _userManagerHelper.GetHomePageUserCounts(RuntimeContext.Provider.Id,RuntimeContext.OperatorId).TotalEnabledUsers,
                        MaxEnabledUserCount = _userManagerHelper.GetHomePageUserCounts(RuntimeContext.Provider.Id,RuntimeContext.OperatorId).MaxEnabledUsers
                    });

            return result;
        }

        [HttpPost]
        public ActionResult GetCustomViews()
        {
            var provider = RuntimeContext.Provider;
            var customViews =
                customAttributeFacade.GetUserCustomViewsBySpec(new CustomViewSpec
                {
                    ProviderId = provider.Id,
                    OperatorId = RuntimeContext.Operator.Id,
                    CustomViewType = CustomViewType.UserManagerV2,
                    IsPlaceholder = false,
                    CustomViewColumnTypes = new[] { CustomViewColumnType.CustomField, CustomViewColumnType.Device },

                });

            _userManagerHelper.RefreshDevices(ref allDevices, ref devicesByCommonName, ref devicesByName, true);

            IEnumerable<Hierarchy> allHierarchies = _userFacade.GetHierarchyBySpec(new HierarchySpec { ProviderId = provider.Id, AvailableForLists = false, HierarchyType = HierarchyType.ORG, Status = UserStatusType.Active, IncludeCustomAttribute = true });

            var listOfCustomViewColumns = new List<CustomViewColumn>();
            var attributes =
                ProviderAttributes.Where(
                x => x.CommonName.Equals("DISPLAYNAME") == false &&
                     x.CommonName.Equals(AttributeCommonNames.UserName) == false &&
                     x.Status != "DEL" && x.IsSearchable == "Y" && x.EntityId == "USER" &&
                     x.AttributeTypeId != CustomAttributeDataType.GeoLocation &&
                     x.AttributeTypeId != CustomAttributeDataType.Path

                ).GroupBy(d => d.Id, (key, group) => group.First())
                .Where(x => customViews.Any(y => y.Title.Equals(x.AttributeName, StringComparison.OrdinalIgnoreCase)) == false)
                .Select
                (
                    x => new CustomViewColumn
                    {
                        Id = x.Id,
                        DisplayName = x.AttributeName,
                        CustomViewColumnType = "CF",
                        ViewId = 0,
                        IsHierarchy = false
                    }).OrderBy(d => d.DisplayName);

            var devices = allDevices.Where(
                            d => customViews.Any(y => y.Title.Equals(d.Name, StringComparison.OrdinalIgnoreCase)) == false
                                 && !d.IsMassDevice)
                        .Select(
                                x => new CustomViewColumn
                                {
                                    Id = x.Id,
                                    DisplayName = "{0} (Device)".FormatWith(x.Name),
                                    CustomViewColumnType = "Device",
                                    ViewId = 0,
                                    IsHierarchy = false
                                }).OrderBy(d => d.DisplayName);

            var hierarchies = allHierarchies.Where(
                d => customViews.Any(y => y.Title.Equals(d.Name, StringComparison.OrdinalIgnoreCase)) == false
                ).Select
                (
                    x => new CustomViewColumn
                    {
                        Id = x.CustomAttribute.Id,
                        DisplayName = x.Name,
                        CustomViewColumnType = "CF",
                        ViewId = 0,
                        IsHierarchy = true
                    }
                ).OrderBy(d => d.DisplayName);


            if (attributes.HasValue())
                listOfCustomViewColumns.AddRange(attributes);
            if (devices.HasValue())
                listOfCustomViewColumns.AddRange(devices);
            if (hierarchies.HasValue())
                listOfCustomViewColumns.AddRange(hierarchies);
            return Json(listOfCustomViewColumns);

        }

        [HttpPost]
        public ActionResult SaveCustomView(int viewId, int id, string action, string type, string commonName = "")
        {
            var provider = RuntimeContext.Provider;

            var customViewColumnType = (type.ToLowerInvariant() != "device")
                ? CustomViewColumnType.CustomField
                : CustomViewColumnType.Device;

            _userManagerHelper.RefreshDevices(ref allDevices, ref devicesByCommonName, ref devicesByName, true);
            var messages = customAttributeFacade.SaveCustomView(
                new SaveCustomViewSpec
                {
                    Id = id,
                    ViewId = viewId,
                    Action = action,
                    ColumnType = customViewColumnType,
                    AllDevices = allDevices,
                    ProviderAttributes = ProviderAttributes,
                    ProviderId = RuntimeContext.Provider.Id,
                    OperatorId = RuntimeContext.Operator.Id
                });
            return Json(new Result<bool>(messages.NoErrors(), messages));
        }

        private List<string> InitializeAttributesToRetrieve(IEnumerable<CustomAttribute> defaultAttributes, IEnumerable<CustomView> customViews)
        {
            var attributenames = new List<string>();

            foreach (
                var customAttribute in
                    defaultAttributes.Union(
                        customViews.Where(x => x.Columnid == CustomViewColumnType.CustomField)
                            .Select(x => ProviderAttributes.GetByAttributeName(x.Title))))
            {
                attributenames.Add(customAttribute.CommonName);
            }

            return attributenames;
        }

        private static List<string> InitializeDevicesToRetrieve(IEnumerable<CustomView> customViews)
        {
            var deviceNames = new List<string>();

            foreach (
                var device in
                    customViews.Where(x => x.Columnid == CustomViewColumnType.Device)
                        .Select(x => devicesByName[x.Title].FirstOrDefault()))
            {
                deviceNames.Add(device.CommonName);
            }

            return deviceNames;
        }


        private static List<GenericCriteria> InitializeAdvancedSearch(string queryCriteria)
        {
            var qryCriterion = JsonSerializerService.Deserialize<IEnumerable<Criterion>>(queryCriteria);

            var advancedCriterion = new List<GenericCriteria>();

            if (qryCriterion != null)
            {
                foreach (var qryCriteria in qryCriterion)
                {
                    var criteria = new GenericCriteria(qryCriteria.entity.entityType, qryCriteria.entity.id, qryCriteria.operand);

                    switch (qryCriteria.AttributeType)
                    {
                        case CustomAttributeDataType.Picklist:
                        case CustomAttributeDataType.MultiPicklist:
                        case CustomAttributeDataType.Checkbox:
                            criteria.Value = (qryCriteria.operand == 11 || qryCriteria.operand == 12)
                                ? "0"
                                : ((int[])qryCriteria.Value).Join(",");
                            break;
                        case CustomAttributeDataType.Number:
                        case CustomAttributeDataType.String:
                        case CustomAttributeDataType.Memo:
                        case CustomAttributeDataType.Date:
                        case CustomAttributeDataType.DateTime:
                        case CustomAttributeDataType.Path:
                            criteria.Value = ((string[])qryCriteria.Value).Join(",");
                            break;
                        case CustomAttributeDataType.GeoLocation:
                            break;
                        case CustomAttributeDataType.AttributeValue:
                        case CustomAttributeDataType.Device:
                        case CustomAttributeDataType.Entity:
                        case CustomAttributeDataType.Object:
                        case CustomAttributeDataType.Unknown:
                        default:
                            throw new Exception("Not Implemented");
                    }

                    advancedCriterion.Add(criteria);
                }
            }

            return advancedCriterion;
        }

        public IDictionary<int, List<int>> GetAttributeIdsByValueIds(IEnumerable<int> valueIds)
        {
            var attributesDictionary = new Dictionary<int, List<int>>();

            foreach (var attr in ProviderAttributes)
            {
                if (attr.AttributeTypeId == CustomAttributeDataType.Picklist ||
                    attr.AttributeTypeId == CustomAttributeDataType.MultiPicklist ||
                    attr.AttributeTypeId == CustomAttributeDataType.Checkbox)
                {
                    foreach (var value in attr.Values.Where(value => valueIds.Contains((value.ValueId))))
                    {
                        if (attributesDictionary.ContainsKey(attr.Id))
                            attributesDictionary[attr.Id].Add(value.ValueId);
                        else
                            attributesDictionary.Add(attr.Id, new List<int> { value.ValueId });
                    }
                }
            }
            return attributesDictionary;
        }

        private static IEnumerable<List<GenericCriteria>> InitializeQuickSearch(IEnumerable<string> searchStrings, List<CustomAttribute> defaultAttributes)
        {
            var quickSearchCriteria = new List<List<GenericCriteria>>();

            if (searchStrings != null)
            {
                foreach (var searchString in searchStrings)
                {
                    foreach (var defaultAttribute in defaultAttributes)
                    {
                        quickSearchCriteria.Add(new List<GenericCriteria>
                        {
                            new AttributeCriteria(defaultAttribute.Id, CriteriaOperator.Contains, searchString.Trim())
                        });
                    }
                }

            }

            return quickSearchCriteria;
        }
        private CustomViewColumn CreateCustomViewColumnModel(Provider provider, CustomView customView)
        {
            if (customView.Columnid == CustomViewColumnType.CustomField)
            {
                var titleAttribute = ProviderAttributes.GetByAttributeName(customView.Title);
                return new CustomViewColumn
                {
                    Id = titleAttribute.Id,
                    DisplayName = customView.Title,
                    Key = titleAttribute.CommonName,
                    IsRequired = false,
                    IsSortable = titleAttribute.IsSearchable.ConvertTo<bool>(),
                    CustomViewColumnType = "CF",
                    DataType = titleAttribute.AttributeTypeId,
                    DataFormat = titleAttribute.GetDataFormat(provider),
                    ViewId = customView.ViewId
                };
            }
            var device = devicesByName[customView.Title].FirstOrDefault();
            return new CustomViewColumn
            {
                Id = device.Id,
                DisplayName = customView.Title,
                Key = device.CommonName,
                IsRequired = false,
                IsSortable = true,
                CustomViewColumnType = "Device",
                DataType = CustomAttributeDataType.Device,
                DataFormat = provider.GetDeviceFormat(),
                ViewId = customView.ViewId
            };
        }
       

       
        public class TargettingUsers
        {

            public string UserId { get; set; }
            public string Name { get; set; }
            public string UserStatus { get; set; }
        }


        public List<TargettingUsers> GetTargettingUserList()
        {
            List<TargettingUsers> objTargettingUsers = new List<TargettingUsers>();

            objTargettingUsers.Add(new TargettingUsers() { UserId = "1", Name = "athocadmin", UserStatus = "Active" });


            objTargettingUsers.Add(new TargettingUsers() { UserId = "2080230", Name = "amanb", UserStatus = "Active" });
            objTargettingUsers.Add(new TargettingUsers() { UserId = "2080386", Name = "amanb_usr", UserStatus = "Active" });
            objTargettingUsers.Add(new TargettingUsers() { UserId = "2076016", Name = "anjali_ent", UserStatus = "Active" });
            objTargettingUsers.Add(new TargettingUsers() { UserId = "2076017", Name = "anjali_vpsadmin", UserStatus = "Active" });
            objTargettingUsers.Add(new TargettingUsers() { UserId = "2079534", Name = "anjali123", UserStatus = "Active" });

            objTargettingUsers.Add(new TargettingUsers() { UserId = "2076927", Name = "DistributionListmanager", UserStatus = "Active" });
            objTargettingUsers.Add(new TargettingUsers() { UserId = "2079395", Name = "eadmin007", UserStatus = "Active" });
            objTargettingUsers.Add(new TargettingUsers() { UserId = "2079419", Name = "entadmin", UserStatus = "Active" });
            objTargettingUsers.Add(new TargettingUsers() { UserId = "2074391", Name = "Enteropr", UserStatus = "Active" });
            objTargettingUsers.Add(new TargettingUsers() { UserId = "2079420", Name = "enterpriseadmin", UserStatus = "Active" });

            objTargettingUsers.Add(new TargettingUsers() { UserId = "2080434", Name = "entuser2", UserStatus = "Active" });
            objTargettingUsers.Add(new TargettingUsers() { UserId = "2076435", Name = "epei", UserStatus = "Active" });
            objTargettingUsers.Add(new TargettingUsers() { UserId = "2074118", Name = "fema113", UserStatus = "Active" });
            objTargettingUsers.Add(new TargettingUsers() { UserId = "2075750", Name = "GVoice", UserStatus = "Active" });
            objTargettingUsers.Add(new TargettingUsers() { UserId = "2076436", Name = "GVSiren", UserStatus = "Active" });

            objTargettingUsers.Add(new TargettingUsers() { UserId = "2077054", Name = "hasita_sysadmin", UserStatus = "Active" });
            objTargettingUsers.Add(new TargettingUsers() { UserId = "2079435", Name = "henil", UserStatus = "Active" });
            objTargettingUsers.Add(new TargettingUsers() { UserId = "2074118", Name = "fema113", UserStatus = "Active" });
            objTargettingUsers.Add(new TargettingUsers() { UserId = "2075750", Name = "GVoice", UserStatus = "Active" });
            objTargettingUsers.Add(new TargettingUsers() { UserId = "2076436", Name = "GVSiren", UserStatus = "Active" });

            objTargettingUsers.Add(new TargettingUsers() { UserId = "2075541", Name = "jgaddam", UserStatus = "Active" });
            objTargettingUsers.Add(new TargettingUsers() { UserId = "2080444", Name = "nagarajkv", UserStatus = "Active" });
            objTargettingUsers.Add(new TargettingUsers() { UserId = "2074048", Name = "ramk99", UserStatus = "Active" });


            return objTargettingUsers;

        }


    }
}