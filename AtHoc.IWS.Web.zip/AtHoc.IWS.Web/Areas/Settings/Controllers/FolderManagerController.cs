﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Web.Mvc;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Resources;
using AtHoc.IWS.Business.Context;
using AtHoc.Global.Resources;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Web.Filters;
using AtHoc.MediaServices;
using AtHoc.IWS.Business.Domain.Settings.Impl;
using AtHoc.IWS.Business.Domain.Authorization;
using EO.Pdf;
using Microsoft.Owin.Security.Provider;
using AtHoc.IWS.Business.Domain.Users;
using System.Text.RegularExpressions;
using System.Text;
using System.Web;

namespace AtHoc.IWS.Web.Areas.Settings.Controllers
{
    public class FolderManagerController : Controller
    {
        private readonly ILogService _logService;
        private readonly IAuthFacade _authFacade;
        private readonly IUserFacade _userFacade;
        private readonly IOperatorFacade _operatorFacade;
        private readonly IChannelManagerFacade _channelManager;

        public FolderManagerController(ILogService logService, IAuthFacade authFacade, IUserFacade userFacade, IOperatorFacade operatorFacade, IChannelManagerFacade channelManager)
        {
            _channelManager = channelManager;

            _logService = logService;
            _authFacade = authFacade;
            _userFacade = userFacade;
            _operatorFacade = operatorFacade;

        }
        /// <summary>
        /// GET: /Settings/DeliveryTemplate/
        /// </summary>
        /// <returns></returns>     
        public ActionResult Index()
        {
            var provider = RuntimeContext.Provider;
            ViewBag.DateFormat = provider.GetDateFormat();
            ViewBag.DateTimeFormat = provider.GetDateTimeFormat();
            return View();
        }

        /// <summary>
        /// This method is used to get all channels
        /// </summary>
        /// <param name="channelCriteria"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult GetChannelList(ChannelCriteria channelCriteria)
        {
            IEnumerable<ChannelSettingsList> noOfChannels = new List<ChannelSettingsList>();
            try
            {
                channelCriteria.ProviderId = RuntimeContext.ProviderId;
                channelCriteria.OperatorId = RuntimeContext.OperatorId;
                noOfChannels = _channelManager.GetChannelList(channelCriteria, RuntimeContext.Provider.BaseLocale);
                noOfChannels.ToList<ChannelSettingsList>().ForEach(a => { a.CreatedDate = RuntimeContext.Provider.SystemToVpsDateTimeFormated(Convert.ToDateTime(a.Created_On)); a.UpdatedDate = RuntimeContext.Provider.SystemToVpsDateTimeFormated(Convert.ToDateTime(a.Updated_On)); });

                return Json(new
                {
                    Success = true,
                    Data = noOfChannels,
                    TotalCount = noOfChannels.Count(),
                    ContextProvider = channelCriteria.ProviderId,
                });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new
                {
                    Success = false,
                    Data = noOfChannels,
                    TotalCount = noOfChannels.Count(),
                    ContextProvider = channelCriteria.ProviderId,
                    Messages = ex.Message
                });
            }
        }

        /// <summary>
        /// This method is used to get all details based on selected channel
        /// </summary>
        /// <param name="channelCriteria"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult GetChannelDetails(ChannelCriteria channelCriteria)
        {
            try
            {
                channelCriteria.OperatorId = RuntimeContext.OperatorId;

                var data = _channelManager.GetChannelDetails(channelCriteria, RuntimeContext.Provider.BaseLocale);


                var userInfo = _userFacade.GetUserBySpec(new UserSpec { OperatorId = (data.ChannelSettings.Created_By > 0) ? Convert.ToInt32(data.ChannelSettings.Created_By) : 0, UserId = (data.ChannelSettings.Created_By > 0) ? Convert.ToInt32(data.ChannelSettings.Created_By) : 0, GetUserAttributes = false });

                if (userInfo != null)
                    data.ChannelSettings.CreatedByUsername = userInfo.UserName;
                if (data.ChannelSettings.Updated_By > 0)
                {
                    var userInfoUpdated = _userFacade.GetUserBySpec(new UserSpec { OperatorId = (data.ChannelSettings.Updated_By > 0) ? Convert.ToInt32(data.ChannelSettings.Updated_By) : 0, UserId = (data.ChannelSettings.Updated_By > 0) ? Convert.ToInt32(data.ChannelSettings.Updated_By) : 0, GetUserAttributes = false });
                    if (userInfoUpdated != null)
                        data.ChannelSettings.UpdatedByUsername = userInfoUpdated.UserName;
                }
                else
                    data.ChannelSettings.UpdatedByUsername = (data.ChannelSettings.Updated_On != null) ? data.ChannelSettings.CreatedByUsername : string.Empty;


                data.ChannelSettings.UpdatedDate = RuntimeContext.Provider.SystemToVpsDateTimeFormated(data.ChannelSettings.Updated_On);
                data.ChannelSettings.CreatedDate = RuntimeContext.Provider.SystemToVpsDateTimeFormated(data.ChannelSettings.Created_On);


                var systemUser = _operatorFacade.GetUser(new SystemUserSpec { ProviderId = channelCriteria.ProviderId, OperatorId = channelCriteria.OperatorId });
                var rEnterpriseAdmin = systemUser.Roles.Where(e => e.RoleId == (int)Roles.EnterpriseAdmin).Count() > 0 ? true : false;
                var rSystemAdmin = systemUser.Roles.Where(e => e.RoleId == (int)Roles.SystemAdmin).Count() > 0 ? true : false;
                var rVirtualSystemAdmin = systemUser.Roles.Where(e => e.RoleId == (int)Roles.Administrator).Count() > 0 ? true : false;

                return Json(new
                {
                    Success = true,
                    Data = data,
                    IsEnterprises = rEnterpriseAdmin,
                    IsSysAdmin = rSystemAdmin,
                    IsVirtualSysAdmin = rVirtualSystemAdmin,
                });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Error = ex.Message });
            }
        }

        private bool ValidateName(string inputString)
        {
            string FolderNameSpecialCharacterRegex = @"^[^`^!^$^^^%^(^)^=^{^}^,^;^\^:^?^\""^<^>^|]+$";

            if (!Regex.IsMatch(inputString, FolderNameSpecialCharacterRegex, RegexOptions.IgnoreCase))
            {
                return true;
            }
            return false;
        }

        private List<Message> lengthValidation(ChannelSettingsModel channelSettingsModel)
        {
            var listErrorMessage = new List<Message>();
            if (channelSettingsModel.ChannelSettings.Name.Length < 3 || channelSettingsModel.ChannelSettings.Name.Length > 100)
            {
                listErrorMessage.Add(new Message { Type = MessageType.Error, Value = IWSResources.Settings_FolderManager_folderNamelimit });
            }

            if (channelSettingsModel.ChannelSettings.Description.Length > 200)
            {
                listErrorMessage.Add(new Message { Type = MessageType.Error, Value = IWSResources.Settings_FolderManager_folderDeslimit });
            }

            return listErrorMessage;
        }

        /// <summary>
        /// This method is used to save the channel data
        /// </summary>
        /// <param name="channelSettingsModel"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateInput(false)]
        public JsonResult SaveChannel(ChannelSettingsModel channelSettingsModel)
        {
            var error = string.Empty;
            var result = false;
            var provider = RuntimeContext.Provider;
            var currentUserId = RuntimeContext.OperatorId;
            List<Message> ValidationMsg;
            try
            {
                if (string.IsNullOrEmpty(channelSettingsModel.ChannelSettings.Description))
                {
                    channelSettingsModel.ChannelSettings.Description = string.Empty;
                }


                ValidationMsg = lengthValidation(channelSettingsModel);

                if (ValidationMsg.Count <= 0)
                {
                    if (!ValidateName(channelSettingsModel.ChannelSettings.Name))
                    {
                        channelSettingsModel.ChannelSettings.Provider_Id = provider.Id;
                        /// Common name validation
                        if (_channelManager.IsUniqueFolderName(channelSettingsModel.ChannelSettings.Provider_Id, channelSettingsModel.ChannelSettings.Channel_Id, channelSettingsModel.ChannelSettings.Name))
                        {
                            error = IWSResources.Settings_FolderManager_DuplicateFolderName;
                            return Json(new { Success = false, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }), ReturnType = 1 });
                        }
                        else
                        {
                            Session["UpdateFolderData"] = true;
                            Session["channelList"] = null;
                            Session["userChannelList"] = null;
                            Session["userwithProviderChannelList"] = null;
                            Session["vpsChannels"] = null;
                            Session["vpsChannelswithProvider"] = null;
                            return Json(new
                            {
                                Success = _channelManager.UpdateChannel(channelSettingsModel, RuntimeContext.OperatorId)
                            });
                        }
                    }

                    else
                    {
                        error = IWSResources.Settings_FolderManager_notAllowedInName + " \\ / : * ? ` ; \" < > | [ ]";
                        return Json(new { Success = false, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }), ReturnType = 1 });
                    }
                }
                else
                {
                    return Json(new
                    {
                        Success = false,
                        HasErrors = !string.IsNullOrWhiteSpace(ValidationMsg[0].Value),
                        Messages = (string.IsNullOrWhiteSpace(ValidationMsg[0].Value)) ? null :
                        new Messages(ValidationMsg.ToArray()),
                        ReturnType = 1
                    });

                }
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = result, Error = IWSResources.SystemSettings_InvalidSave }, "text/plain");
            }

        }

        /// <summary>
        /// This method is used to delete the channel
        /// </summary>
        /// <param name="channelCriteria"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult DeleteChannel(ChannelCriteria channelCriteria)
        {
            try
            {
                if (channelCriteria.ProviderId == null || channelCriteria.ProviderId == 0)
                    channelCriteria.ProviderId = RuntimeContext.ProviderId;
                if (channelCriteria.OperatorId == 0)
                    channelCriteria.OperatorId = RuntimeContext.OperatorId;

                Session["UpdateFolderData"] = true;
                Session["channelList"] = null;
                Session["userChannelList"] = null;
                Session["userwithProviderChannelList"] = null;
                Session["vpsChannels"] = null;
                Session["vpsChannelswithProvider"] = null;

                return Json(new
                {
                    Success = _channelManager.DeleteChannel(channelCriteria),
                });


            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Error = IWSResources.SystemSettings_InvalidSave }, "text/plain");
            }

        }

        /// <summary>
        /// This method is used to update the channel stauts
        /// </summary>
        /// <param name="channelCriteria"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult UpdateStatus(ChannelCriteria channelCriteria)
        {
            try
            {
                if (channelCriteria.ChannelIds.Any())
                {
                    channelCriteria.ProviderId = RuntimeContext.ProviderId;
                    channelCriteria.OperatorId = RuntimeContext.OperatorId;

                    return Json(new
                    {
                        Success = _channelManager.UpdateChannelStatus(channelCriteria),
                    });
                }
                else
                {
                    return Json(new
                    {
                        Success = false,
                        Error = IWSResources.Settings_FolderManager_FolderIdsNotFound
                    });

                }
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Error = IWSResources.SystemSettings_InvalidSave }, "text/plain");
            }

        }

        /// <summary>
        /// This method will check the agent id is associated with any channels or not
        /// </summary>
        /// <returns>list<int></returns>
        [HttpPost]
        public JsonResult IsAlertAssociated(string strChannelIds)
        {
            List<int> channelIds = new List<int>();
            try
            {
                if (!string.IsNullOrWhiteSpace(strChannelIds))
                {
                    channelIds = strChannelIds.Split(',').Select(Int32.Parse).ToList();
                    channelIds = _channelManager.IsAlertAssociated(channelIds);
                }
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
            }

            return Json(new { Data = channelIds }, "text/plain");
        }

        [HttpPost]
        public JsonResult GetDependencyList(int ChannelId)
        {
            var dependencyList = new List<ChannelDependencyList>();
            bool isSystemFolder = false;
            try
            {
                var providerId = RuntimeContext.ProviderId;
                if (ChannelId > 0)
                {
                    if (providerId == 3)
                    {
                        isSystemFolder = _channelManager.IsSystemFolder(ChannelId);
                    }
                    dependencyList = _channelManager.GetDependencyList(ChannelId);
                }
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
            }

            return Json(new { IsSystemFolder = isSystemFolder, Success = dependencyList != null, Data = dependencyList }, "text/plain");
        }

        [HttpPost]
        public JsonResult DeleteFolder(int intChannelId)
        {
            try
            {

                var ProviderId = RuntimeContext.ProviderId;
                var OperatorId = RuntimeContext.OperatorId;

                Session["UpdateFolderData"] = true;
                Session["channelList"] = null;
                Session["userChannelList"] = null;
                Session["userwithProviderChannelList"] = null;
                Session["vpsChannels"] = null;
                Session["vpsChannelswithProvider"] = null;

                return Json(new
                {
                    Success = _channelManager.DeleteFolder(intChannelId, ProviderId, OperatorId),
                });


            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Error = IWSResources.SystemSettings_InvalidSave }, "text/plain");
            }

        }
    }
}