﻿using System.Linq;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Web.Helpers;
using AtHoc.Operators;
using System.Web;
using AtHoc.IWS.Business.Configurations;

namespace AtHoc.IWS.Web.Areas.Settings
{
    public class ChangeOrganizationController : AtHoc.Infrastructure.Web.Mvc.Controller
    {
        // GET: ChangeOrganization

        private readonly IProviderFacade _providerFacade;

        public ChangeOrganizationController(IProviderFacade providerFacade)
        {
            _providerFacade = providerFacade;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            var userId = RuntimeContext.OperatorId;
            ViewBag.providerId = RuntimeContext.ProviderId;
            var providerList = _providerFacade.GetProviderList(userId)
                .Select(
                    p =>
                        new
                        {
                            Text = string.Format("{0} ({1})", p.PROVIDER_NAME, p.PROVIDER_ID),
                            Value = p.PROVIDER_ID
                        });

            ViewBag.providerList = new JavaScriptSerializer().Serialize(providerList);
            if(!providerList.Any())
              return Redirect( "/athoc-iws/");
            return View();
        }

        /// <summary>
        /// To set the organization.
        /// </summary>
        /// <param name="id">providerId</param>
        /// <param name="redirectUrl">redirect URL.</param>
        /// <returns></returns>
        public ActionResult SetOrganization(int id, string redirectUrl="")
        {
            var userId = RuntimeContext.OperatorId;
            var opr = OperatorManager.GetOperator(userId);
            var roles = opr.GetObjectRoles(id);
            var allowAccess = roles.Count > 0;
            if (allowAccess)
            {
                opr.LastAccessedProvider = id;
                opr.UpdateLastAccessedProvider(id);
                OperationAuditor.LogAction(opr.Id, id, "LOG00", "", opr.LoginId, opr.Id, "MS", "");
                // Successful Switch Audit Log Entry
                AuthHelper.CreateAuthTicket(opr, AuthHelper.GetAuthTicketUserData().AuthType);
                var walkMeLanguageCookie = new HttpCookie(Constants.WalkMeLanguageCookie, "true");               
                Response.Cookies.Add(walkMeLanguageCookie);
                Session["channelList"] = null;
                Session["userChannelList"] = null;
                Session["userwithProviderChannelList"] = null;
                Session["vpsChannels"] = null;
                Session["vpsChannelswithProvider"] = null;
                if (redirectUrl!="")
                {
                    return Redirect(redirectUrl);
                }
                return Redirect("/athoc-iws/");
            }

            return Redirect("/client/sys/access_error.asp");
        }

    }

    
}