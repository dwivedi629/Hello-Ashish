﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AtHoc.Infrastructure.Ioc;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Organization;
using AtHoc.Global.Resources;
using AtHoc.IWS.Web.Filters;
using AtHoc.IWS.Business.Domain.Entities;

namespace AtHoc.IWS.Web.Areas.Settings.Controllers
{
    public class OrganizationSettingsController : Controller
    {
        //
        // GET: /Settings/OrganizationSettings/
        [IWSAuthorize(new SystemObject[] { SystemObject.OrganizationSettings }, new ActionType[] { ActionType.View })]
        public ActionResult Index()
        {
            var orgFacade = ServiceLocator.Current.Resolve<IOrganizationFacade>();
            ConnectivityStatus connectivityStatus = orgFacade.GetConnectivityStatus(RuntimeContext.ProviderId);
            if (connectivityStatus == ConnectivityStatus.NotConfigured)
            {
                ViewBag.ConnectivityMessage = IWSResources.Organization_NotConfigured_ErrorMsg;
                return View("_NotConnectedMessage");
            }
            if (connectivityStatus == ConnectivityStatus.DeviceNotConfigured)
            {
                ViewBag.ConnectivityMessage = IWSResources.Organization_DeviceNotConfigured_ErrorMsg;
                return View("_NotConnectedMessage");
            }
            if (connectivityStatus == ConnectivityStatus.NotListed)
            {
                ViewBag.ConnectivityMessage = IWSResources.Organization_NotListed_ErrorMsg;
                return View("_NotConnectedMessage");
            }
            
            var orgGuid = orgFacade.GetSelfOrganizationGuid(RuntimeContext.ProviderId);
            ViewBag.orgGuid = orgGuid.ToString();
            return View();
        }
	}
}