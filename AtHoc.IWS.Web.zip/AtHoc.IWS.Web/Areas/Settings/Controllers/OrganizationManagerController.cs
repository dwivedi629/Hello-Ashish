﻿using AtHoc.Global.Resources;
using AtHoc.Infrastructure.Log;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.Authorization;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Users;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.Business.Extensions;
using AtHoc.IWS.Web.Filters;
using AtHoc.IWS.Web.Helpers;
using System;
using System.Linq;
using System.Web.Mvc;
using AtHoc.IWS.Web.Models.Publishing;
using AtHoc.Operators;
using ActionType = AtHoc.IWS.Business.Domain.Entities.ActionType;
using Roles = AtHoc.IWS.Business.Domain.Entities.Roles;

namespace AtHoc.IWS.Web.Areas.Settings.Controllers
{
    public class OrganizationManagerController : Controller
    {
        private readonly ILogService _logService;
        private readonly IAuthFacade _authFacade;
        private readonly IUserFacade _userFacade;
        private readonly IOperatorFacade _operatorFacade;
        private readonly IProviderFacade _orgProviderfacade;
        private readonly ILanguageFacade _languageFacade;
        private const string dateCompare = "2000-01-01";
        private const string aff25 = "AFF25";
        private const string basicAff = "Basic";

        public OrganizationManagerController(ILogService logService, IAuthFacade authFacade, IUserFacade userFacade, IOperatorFacade operatorFacade, IProviderFacade orgManager, ILanguageFacade languageFacade)
        {
            _orgProviderfacade = orgManager;

            _logService = logService;
            _authFacade = authFacade;
            _userFacade = userFacade;
            _operatorFacade = operatorFacade;
            _languageFacade = languageFacade;
        }

        // Only authorized user can access this page
        [IWSAuthorize(new SystemObject[] { SystemObject.SystemVirtualSystems }, new ActionType[] { ActionType.Modify })]
        public ActionResult Index()
        {
            var provider = RuntimeContext.Provider;
            ViewBag.DateFormat = provider.GetDateFormat();
            ViewBag.DateTimeFormat = provider.GetDateTimeFormat();
            if ((RuntimeContext.Provider.ProviderType() != AtHoc.IWS.Business.Domain.Entities.VPSType.System) && (RuntimeContext.Provider.ProviderType() != AtHoc.IWS.Business.Domain.Entities.VPSType.Enterprise) && (RuntimeContext.Provider.ProviderType() != AtHoc.IWS.Business.Domain.Entities.VPSType.EnterpriseTemplate))
            {
                throw new ApplicationException(IWSResources.Settings_Organization_NoAccessForUnAuthorizedUser);
            }
            return View();
        }

        /// <summary>
        /// This method will use for either New organizatio/sub-org/Basic adding or duplicating these
        /// // by using organization manager. 
        /// </summary>
        /// <param name="data"></param>
        /// <returns>json result</returns>
        [HttpPost]
        public JsonResult SaveOrganizationManager(OrgManagerSettings data)
        {
            try
            {
                var operatorId = RuntimeContext.OperatorId;
                var providerId = RuntimeContext.ProviderId;
                data.OperatorId = operatorId;
                data.LoggedInProviderId = providerId;

                //Check for the Valid Organization Name
                if (data.OrgName.IndexOfAny(Constants.InvalidOrgCharacterSet.ToCharArray()) != -1)
                {
                    return Json(new
                    {
                        Success = false,
                        isCharacterValidationError=true,
                        Error = IWSResources.Settings_Organization_SpecialCharatersAllowed,
                        
                    });
                }
                else if (
                    (!ValidateOperatorPermissions(operatorId,
                        providerId != Constants.SystemVps ? data.EnterpriseProviderId : providerId))
                    || (!ValidateProviderType(data.OrgType, RuntimeContext.Provider.ProviderType())))
                {
                    return Json(new
                    {
                        Success = false,
                        isUnAuthOrgAccess = true,
                        Error = IWSResources.OM_CrossTenant_Msg
                    });
                }
                // Save enterprize , basic or sub enterprize data.
                return Json(new
                {
                    // Saving the information on database
                    Success = _orgProviderfacade.SaveOrganizationManager(data),
                });

            }
            catch (Exception ex)
            {

                _logService.Error(() => ex);
                return Json(new
                {
                    Success = false,
                    Error = ex.Message,
                });
            }
        }



        /// <summary>
        /// This method is used to get all organization(s) based on provider Id
        /// </summary>
        /// <param name="providerId">provider id</param>
        /// <returns>List of organization name</returns>
        /// 
        [HttpPost]
        public JsonResult GetOrganizationList(OrgManagerSettings orgSettings)
        {


            var provider = RuntimeContext.Provider;
            bool isSysAdmin;
            try
            {
                orgSettings.ProviderId = provider.Id;
                //Get all organization based on logged in provider Id
                var operatorId = RuntimeContext.OperatorId;
                var systemUser = _operatorFacade.GetUser(new SystemUserSpec { ProviderId = orgSettings.ProviderId, OperatorId = operatorId });
                isSysAdmin = systemUser.Roles.Any(e => e.RoleId == (int)Roles.SystemAdmin);
                var languageSettings = _languageFacade.GetOperatorEnabledLanguages().ToList();
                var timeZones = TimeZoneInfo.GetSystemTimeZones().Select(timeZoneInfo => new MultiSelectListModel { Value = timeZoneInfo.Id, Text = SettingsHelper.GetLocalizedTimeZone(timeZoneInfo.Id) }).ToList();
                // get Organization Details based on Organization Id
                var provideInfo = _orgProviderfacade.GetOrganizationList(orgSettings.ProviderId, RuntimeContext.Provider.ProviderType(), orgSettings.SearchString).Select(p => new
                {
                    p.ProviderId,
                    p.ProviderName,
                    p.ProviderStatus,
                    ProvideType = GetLocalizedString(p.ProvideType),
                    CreatedDate = p.CreatedOn != null ? RuntimeContext.Provider.GetVpsDateTimeFromSeconds(int.Parse(p.CreatedOn.ToString())).ToVpsDateTimeString() :"",
                    p.DisplayName,
                    TimeZone = SettingsHelper.GetLocalizedTimeZone(TimeZoneInfo.GetSystemTimeZones().FirstOrDefault(timeZoneInfo => timeZoneInfo.ToString() == p.TimeZone).Id.Trim()),
                    p.HomeURL,
                    p.DefaultLocale,
                    LanguageName = languageSettings.Find(o => o.LocalCode == p.DefaultLocale).LanguageName
                }).Where(p => p.ProviderId != (isSysAdmin ? 0 : 3)).ToList();
                // get dropdown list
                return Json(new
                {
                    Success = true,
                    Data = provideInfo,
                    OrgTypes = SettingsHelper.GetOrgTypes(provider.ProviderType()),
                    languages = languageSettings,
                    TotalCount = provideInfo.Count(),
                    ProviderType = provider.ProviderType().ToString(),
                    ProviderTypeId = provider.Id,
                    ProviderLocale = provider.BaseLocale,
                    TimeZones = timeZones

                });
            }
            catch (Exception ex)
            {

                _logService.Error(() => ex);
                return Json(new
                {
                    Success = false,
                    Data = "",
                    TotalCount = 0,
                });
            }
        }

        public static string GetLocalizedString(string key)
        {
            return SettingsHelper.GetResourceString(key);
        }

        public bool ValidateOperatorPermissions(int operatorId, int providerId)
        {
            var op = OperatorManager.GetOperator(operatorId);
            if (op.HasPermission(providerId, (int)SystemObject.SystemVirtualSystems, Operators.ActionType.Modify))
                return true;
            return false;
        }
        public bool ValidateProviderType(string orgType, VPSType providerType)
        {
            return SettingsHelper.GetOrgTypes(providerType).Any(e => e.Value == orgType);
        }

        /// <summary>
        /// This method will use for duplicating organizatio/sub-org/Basic
        /// // by using organization manager. 
        /// </summary>
        /// <param name="data"></param>
        /// <returns>json result</returns>
        [HttpPost]
        public JsonResult DuplicateOrganization(OrgManagerSettings data)
        {
            try
            {
                var operatorId = RuntimeContext.OperatorId;
                var providerId = RuntimeContext.ProviderId;
                data.OperatorId = operatorId;
                data.LoggedInProviderId = providerId;
                data.IsDuplicate = true;

                //Check for the Valid Organization Name
                if (data.OrgName.IndexOfAny(Constants.InvalidOrgCharacterSet.ToCharArray()) != -1)
                {
                    return Json(new
                    {
                        Success = false,
                        isCharacterValidationError=true,
                        Error = IWSResources.Settings_Organization_SpecialCharatersAllowed,
                    });
                }
                else if ((_orgProviderfacade.GetProviderList(operatorId).Where(x => x.PROVIDER_ID == data.ProviderId).Count() == 0)
                    || (!ValidateOperatorPermissions(operatorId,
                        providerId != Constants.SystemVps ? data.EnterpriseProviderId : providerId)))
                {
                    return Json(new
                    {
                        Success = false,
                        isUnAuthOrgAccess = true,
                        Error = IWSResources.OM_CrossTenant_Msg
                    });
                }
                // Save enterprize , basic or sub enterprize data.
                return Json(new
                {
                    // Saving the information on database
                    Success = _orgProviderfacade.SaveOrganizationManager(data),
                });

            }
            catch (Exception ex)
            {

                _logService.Error(() => ex);
                return Json(new
                {
                    Success = false,
                    Error = ex.Message,
                });
            }
        }
    }
}