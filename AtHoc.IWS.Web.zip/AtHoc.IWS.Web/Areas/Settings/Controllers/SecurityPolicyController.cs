﻿using System;
using System.Linq;
using System.Web.Mvc;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Resources;
using AtHoc.Infrastructure.Web.Security;
using AtHoc.IWS.Business.Context;
using AtHoc.Global.Resources;
using AtHoc.IWS.Web.Filters;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Settings.Model;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Web.Filters;
using AtHoc.MediaServices;
using AtHoc.IWS.Business.Domain.Settings.Impl;
using AtHoc.IWS.Business.Domain.Authorization;
using Microsoft.Owin.Security.Provider;
using AtHoc.IWS.Business.Domain.Users;

namespace AtHoc.IWS.Web.Areas.Settings.Controllers
{
     [IWSAuthorize(new[] { SystemObject.SecurityPolicy }, new ActionType[] { ActionType.Modify })]
    public class SecurityPolicyController : Controller
    {
        private readonly ISecurityPolicyFacade _securitypolicyFacade;
        private readonly ILogService _logService;
        private readonly IAuthFacade _authFacade;
        private readonly IUserFacade _userFacade;
        private readonly IOperatorFacade _operatorFacade;
             public SecurityPolicyController(ISecurityPolicyFacade securitypolicyFacade, ILogService logService, IAuthFacade authFacade, IUserFacade userFacade, IOperatorFacade operatorFacade)
        {
            _securitypolicyFacade = securitypolicyFacade;
            _logService = logService;
            _authFacade = authFacade;
            _userFacade = userFacade;
            _operatorFacade = operatorFacade;

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [IWSAuthorize(new SystemObject[] { SystemObject.SecurityPolicy }, new ActionType[] { ActionType.Modify })]
        public ActionResult Index()
        {
            var provider = RuntimeContext.Provider;
            ViewBag.DateFormat = provider.GetDateFormat();
            ViewBag.DateTimeFormat = provider.GetDateTimeFormat();
            var vpsTimeZOne = provider.GetVpsTimeZoneFromId();
            ViewBag.VPSTimeZone = vpsTimeZOne;
            return View();
        }

        /// <summary>
        /// To get System settings from database
        /// </summary>
        /// <returns> returns system settings in JSON format</returns>

        [HttpPost]
        public ActionResult GetSecurityPolicy()
        {
            var error = string.Empty;
            var providerId = RuntimeContext.ProviderId;
            var operatorId = RuntimeContext.OperatorId;
           
            try
            {
                var data = _securitypolicyFacade.GetSecurityPolicySettings(providerId);

                var systemUser = _operatorFacade.GetUser(new SystemUserSpec { ProviderId = providerId, OperatorId = operatorId });
                data.IsEnterpriseAdmin = systemUser.Roles.Where(e => e.RoleId == (int)Roles.EnterpriseAdmin).Count() > 0 ? true : false;
                data.IsSystemAdmin = systemUser.Roles.Where(e => e.RoleId == (int)Roles.SystemAdmin).Count() > 0 ? true : false;

				// Changed for IWS-21927
                data.IsModifySecurityPolicyAllowed = _authFacade.HasAccess(RuntimeContext.Operator, providerId, SystemObject.SecurityPolicy, ActionType.Modify);

                return Json(new { Data = data, Success = true, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }) });
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, Error = IWSResources.SystemSettings_InvalidGet }, "text/plain");
            }

           
        }

        /// <summary>
        /// To Save Security Policy
        /// </summary>        
        /// <param name="securityPolicyModel">SaveSecurityPolicySettings</param>
        /// <returns>JsonResult- returns true or false</returns>
         [ValidateAntiForgeryTokenFilter]
        public ActionResult SaveSecurityPolicySettings(SecurityPolicyModel securityPolicyModel)
        {
            var blResult = false;
            var providerId = RuntimeContext.ProviderId;
            var operatorId = RuntimeContext.OperatorId;
            var provider = RuntimeContext.Provider.ProviderName;
            try
            {
                securityPolicyModel.OperatorId = operatorId;
                securityPolicyModel.ProviderId = providerId;
                securityPolicyModel.Provider = provider.ToString();
                blResult = _securitypolicyFacade.SaveSecurityPolicySettings(securityPolicyModel);
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = blResult, Error = IWSResources.SystemSettings_InvalidSave }, "text/plain");
            }

            return Json(new { Data = blResult, Success = true });

        }
        /// <summary>
        /// To copy Security Policy settings to other provider from parent VPS
        /// </summary>        
        /// <param name="securityPolicyModel">SaveSecInsertSecurityPolicySettingsurityPolicySettings</param>
        /// <returns>JsonResult- returns true or false</returns>
          [ValidateAntiForgeryTokenFilter]
        public ActionResult InsertSecurityPolicySettings(SecurityPolicyModel securityPolicyModel)
        {
            var blResult = false;
            var providerId = RuntimeContext.ProviderId;
            var operatorId = RuntimeContext.OperatorId;
            try
            {

                securityPolicyModel.OperatorId = operatorId;
                securityPolicyModel.ProviderId = providerId;
                blResult = _securitypolicyFacade.InsertSecurityPolicySettings(securityPolicyModel);
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = blResult, Error = IWSResources.SystemSettings_InvalidSave }, "text/plain");
            }

            return Json(new { Data = blResult, Success = true });

        }
        /// <summary>
        /// To delete Security Policy settings 
        /// </summary>        
        /// <param name="securityPolicyModel">DeleteSecurityPolicySettings</param>
        /// <returns>JsonResult- returns true or false</returns>
          [ValidateAntiForgeryTokenFilter]
        public ActionResult DeleteSecurityPolicySettings(SecurityPolicyModel securityPolicyModel)
        {
            var error = string.Empty;
            var blResult = false;
            var providerId = RuntimeContext.ProviderId;
            var operatorId = RuntimeContext.OperatorId;
            try
            {
                securityPolicyModel.ProviderId = providerId;
                securityPolicyModel.OperatorId = operatorId;

                blResult = _securitypolicyFacade.DeleteSecurityPolicySettings(securityPolicyModel);
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = blResult, Error = IWSResources.SystemSettings_InvalidGet }, "text/plain");
            }

            return Json(new { Data = blResult, Success = true, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }) });
        }
        [ValidateAntiForgeryTokenFilter]
        public ActionResult UpdateSecurityPolicySettings()
        {
            var error = string.Empty;
            var blResult = false;
            var providerId = RuntimeContext.ProviderId;
            var operatorId = RuntimeContext.OperatorId;
            try
            {
                blResult = _securitypolicyFacade.UpdateEnforcePassword(operatorId,providerId);
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = blResult, Error = IWSResources.SystemSettings_InvalidGet }, "text/plain");
            }

            return Json(new { Data = blResult, Success = true, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }) });
        }

    }
}