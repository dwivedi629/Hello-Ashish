﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using AtHoc.Infrastructure.Log;
using AtHoc.Infrastructure.Resources;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Business.Domain.Settings.Model;

namespace AtHoc.IWS.Web.Areas.Settings.Controllers
{
    //[IWSAuthorize(new SystemObject[] { SystemObject.GeneralSettings }, new ActionType[] { ActionType.Modify })]
    public class TargetingSettingsController : Controller
    {

        private readonly ITargetingSettingsFacade _targetingSettingsFacade;
        private readonly ILogService _logService;



        public TargetingSettingsController(ITargetingSettingsFacade targetingSettingsFacade, ILogService logService)
        {
            _targetingSettingsFacade = targetingSettingsFacade;
            _logService = logService;
        }

        //
        // GET: /Settings/TargetingSettings/
        public ActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// Get the Targeting setting based on providerId
        /// </summary>
        /// <returns>TargetingSettings</returns>
        [HttpPost]
        public JsonResult GetTargetingSettings()
        {
            var error = string.Empty;
          

            try
            {
                var providerId = RuntimeContext.ProviderId;
                var selectedAttr = new List<TargetingSettingsModel>();
                var availableAttr = _targetingSettingsFacade.GetTargetingSettings(providerId);
                if (availableAttr.Count>0)
                    selectedAttr = availableAttr.FindAll(a => a.IsSelected).OrderBy(a=>a.DisplayOrder).ToList();
                 var  bridgeFlag=_targetingSettingsFacade.GetCallBridgeSetting(providerId);
                 // AvailableAttr,SelectedAttr has been modified, the corresponding  JSON attributes has to be  modified in javascript
                return Json(new { AvailableAttr = availableAttr.OrderBy(a=>a.Name).ToList(), SelectedAttr = selectedAttr, bridgeValue = bridgeFlag, Success = true, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }) }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);
                return Json(new { Success = false, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }) }, "text/plain");
            }
       
        }

        /// <summary>
        ///  Saving targeting setting values
        /// </summary>
        /// <param name="data">List of TargetingSettingsModel</param>
        /// <param name="bridgeValue">Call bridge response value</param>
        /// <returns>List of TargetingSettingsModel and value of call bridge response</returns>
        [HttpPost]
        public JsonResult SaveTargetingSettings(List<TargetingSettingsModel> data,string bridgeValue )
        {
            var error = string.Empty;
            var result = false;
            try
            {
                var providerId = RuntimeContext.ProviderId;
                var operatorId = RuntimeContext.OperatorId;
                result = _targetingSettingsFacade.SaveTargetingSettings(data, providerId, Convert.ToBoolean(bridgeValue), operatorId);
            }
            catch (Exception ex)
            {
                _logService.Error(() => ex);

                // define standard error here show it in javascript
                return Json(new { Success = result, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }) }, "text/plain");    
            }

            return Json(new { Success = result, HasErrors = !string.IsNullOrWhiteSpace(error), Messages = (string.IsNullOrWhiteSpace(error)) ? null : new Messages(new Message { Type = MessageType.Error, Value = error }) }, JsonRequestBehavior.AllowGet);
 
        }
	}
}