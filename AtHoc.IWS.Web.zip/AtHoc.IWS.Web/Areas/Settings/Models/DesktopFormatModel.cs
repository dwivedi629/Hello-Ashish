﻿using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Threading;
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Configurations;
using AtHoc.IWS.Web.Models.Publishing;
using AtHoc.Systems;
using AtHoc.Global.Resources;
using System.Resources;

namespace AtHoc.IWS.Web.Areas.Settings.Models
{
    public class DesktopFormatModel
    {
        public IList<MultiSelectListModel> FontList { get; set; }
        public IList<MultiSelectListModel> FontTypeList { get; set; }
        public IList<MultiSelectListModel> ImagePositionList { get; set; }
        public IList<MultiSelectListModel> PopupPositionList { get; set; }
        public IList<MultiSelectListModel> DesktopTimeList { get; set; }
        public IList<MultiSelectListModel> DisplayStyleList { get; set; }
        public IList<MultiSelectListModel> ExitMotionStyleList { get; set; }
        public IList<MultiSelectListModel> EntranceMotionStyleList { get; set; }
        public List<SeverityModel> SeverityList { get; set; }
    }

    public class SystemSettingsFormatModel
    {
        public IList<MultiSelectListModel> StoreLocationList { get; set; }
        public IList<MultiSelectListModel> StoreNameList { get; set; }

    }
   
    public enum FontEnum
    {
        [Description("Font_Arial")]
        Arial,
        [Description("Font_Tahoma")]
        Tahoma,
        [Description("Font_Verdana")]
        Verdana,
        [Description("Font_TimesNewRoman")]
        Times_new_roman,
        [Description("Font_SansSerif")]
        Sans_serif,

    }
  
    public enum FontTypeEnum
    {
        [Description("Font_Regular")]
        Regular,
        [Description("Font_Italic")]
        Italic,
        [Description("Font_Bold")]
        Bold,
        [Description("Font_BoldItalic")]
        Bold_Italic,


    }
  

    public enum DisplayStyleEnum
    {
        [Description("Display_Style_Hide")]
        Hide=1,
        [Description("Display_Style_Show")]
        Show=0,
    }
 

    public enum ImagePositionEnum
    {
        [Description("Image_Position_Hide")]
        none,
        [Description("Image_Position_TopLeft")]
        TopLeft,
        [Description("Image_Position_TopRight")]
        TopRight,
        //[Description("Image_Position_BottomLeft")]
        //BottomLeft,
        //[Description("Image_Position_BottomRight")]
        //BottomRight,
    }
  

    public enum PopupPositionEnum
    {
        [Description("Popup_Position_BottomRight")]
        SYSTRAY,
        [Description("Popup_Position_TopLeft")]
        ABS,

    }
 
    public enum DesktopTimeEnum
    {
        [Description("Desktop_Time_Seconds")]
        SEC,
        [Description("Desktop_Time_Minutes")]
        MIN,
        [Description("Desktop_Time_Hours")]
        HRS,
        [Description("Desktop_Time_Days")]
        DAY,
    }
    public static class DesktopTimeEnumExtension
    {
        static readonly System.Resources.ResourceManager Resource = new
          System.Resources.ResourceManager(Constants.resourceAssembly, typeof(IWSResources).Assembly);

        public static string Display(this DesktopTimeEnum format)
        {
            return Resource.GetString(format.GetDescription(), Thread.CurrentThread.CurrentUICulture);
        }

    }


    public enum EntranceMotionStyleEnum
    {
        [Description("Entrance_Motion_FromRight")]
        RIGHT,
        [Description("Entrance_Motion_FromLeft")]
        LEFT,
    }
  

    public enum ExitMotionStyleEnum
    {
        [Description("Exit_Motion_FromRight")]
        RIGHT,
        [Description("Exit_Motion_FromLeft")]
        LEFT,
    }

    public enum StoreLocationEnum
    {
        [Description("StoreLocation_Current_User")]
        CURRENTUSER,
        [Description("StoreLocation_Local_Machine")]
        LOCALMACHINE,
    }

    public enum StoreNameEnum
    {
        [Description("StoreName_Othe_users")]
        AddressBook,
        [Description("StoreName_Third_party")]
        AuthRoot,
        [Description("StoreName_Intermediate_certificate")]
        CertificateAuthority,
        [Description("StoreName_Personal")]
        My,
        [Description("StoreName_Trustedroot")]
        Root,
        [Description("StoreName_TrustedPeople")]
        TrustedPeople,
        [Description("StoreName_TrustedPublisher")]

        TrustedPublisher,
    }

    public enum OrgTypeEnum
    {
        [Description("OrgType_SubOrganization")]
        SubEnterprise,
        [Description("OrgType_Enterprise")]
        Enterprise,
        [Description("OrgType_Basic")]
        Basic,
    }
   
}
