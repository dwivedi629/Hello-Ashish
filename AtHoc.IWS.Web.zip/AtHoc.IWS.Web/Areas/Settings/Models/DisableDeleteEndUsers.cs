﻿using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Web.Models.UserManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Web.Models.SearchCriteria;
using System.ComponentModel;

namespace AtHoc.IWS.Web.Areas.Settings.Models
{
    public class DisableDeleteEndUsers
    {


        public DisableDeleteEndUsers(string status, List<UserSearchResultItem> endUserDetails)
        {
            _enduserStatus = status;
            _endUserDetails = endUserDetails;
        }

        public DisableDeleteEndUsers()
        {
            // TODO: Complete member initialization
        }
        

        private string _enduserStatus = "";

        /// <summary>
        /// Get/Set User Status
        /// </summary>
        public string EnduserStatus
        {
            get { return _enduserStatus; }
            set { _enduserStatus = value; }
        }

        /// <summary>
        /// Get/Set purge duration 
        /// </summary>
        public string PurgeUsers { get; set; }

        private List<UserSearchResultItem> _endUserDetails = null;

        /// <summary>
        /// Get/Set EndUserDetails
        /// </summary>
        public List<UserSearchResultItem> EndUserDetails
        {
            get { return _endUserDetails; }
            set { _endUserDetails = value; }
        }

        /// <summary>
        /// Get/Set Status
        /// </summary>
        public UserStatusType Status { get; set; }

        /// <summary>
        /// Get/Set UserDataModel
        /// </summary>
        public DisableDeleteEndUsersModel EndUsersModel { get; set; }

        /// <summary>
        /// Get/Set User Search 
        /// </summary>
        public SearchCriteriaModel EndUsersSearchModel { get; set; }


        //Get/Set User for purge request
        public bool IsPurgeRequest { get; set; }

        /// <summary>
        /// Get/Set User for Purge Duration
        /// </summary>
        public int PurgeDuration { get; set; }

        /// <summary>
        /// Get/Set User for IsDisableUserChecked
        /// </summary>
        public bool IsDisableUserChecked { get; set; }

        /// <summary>
        /// Get/Set User for IsDeleteUserChecked
        /// </summary>
        public bool IsDeleteUserChecked { get; set; }
        
       
    }

    /// <summary>
    /// Purge Interval Enum
    /// </summary>
    public enum PurgeUserDurationEnum
    {
        [Description("PurgeUser_1_Month")]
        one_month=30,
        [Description("PurgeUser_3_Months")]
        three_months=90,
        [Description("PurgeUser_6_Months")]
        six_months=180,
        [Description("PurgeUser_1_Year")]
        one_year=365,
        [Description("PurgeUser_2_Years")]
        two_years=730,
        [Description("PurgeUser_5_Years")]
        five_years=1825,

    }

    /// <summary>
    /// Report Columns Enum
    /// </summary>
    public enum DisableDeleteReportColumnEnum
    {
        [Description("DisableDelete_Report_User_Id")]
        User_Id,
        [Description("DisableDelete_Report_User_Name")]
        Username,
        [Description("DisableDelete_Report_First_Name")]
        Firstname,
        [Description("DisableDelete_Report_Last_Name")]
        Lastname,
        [Description("DisableDelete_Report_Display_Name")]
        Displayname,
        [Description("DisableDelete_Report_Old_Status")]
        Old_Status,
        [Description("DisableDelete_Report_New_Status")]
        New_Status,
        [Description("DisableDelete_Report_Status_Change_Comments")]
        Status_Change_Comments,
        

    }
}