﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.Xml.XPath;
using System.Xml;
using System.Xml.Xsl;
using System.IO;

namespace AtHoc.IWS.Web.Areas.Settings.Models
{

    public sealed class EncodingSupportStringWriter : StringWriter
    {
        private Encoding encoding;
        public EncodingSupportStringWriter(Encoding expectedEncoding)
        {
            encoding = expectedEncoding == null ? Encoding.UTF8 : expectedEncoding;
        }
        public override Encoding Encoding { get { return encoding; } }
    }

    internal class TabIndexer
    {
        private int _Index;

        public TabIndexer()
        {
            ResetIndex();
        }

        public void ResetIndex()
        {
            _Index = 0;
        }

        public int NextIndex()
        {
            return ++_Index;
        }

        public int CurrentIndex()
        {
            return _Index;
        }
    }
}