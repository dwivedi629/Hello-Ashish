﻿using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Users.Search;
using AtHoc.IWS.Web.Models.UserManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AtHoc.IWS.Business.Domain.Settings;
using AtHoc.IWS.Web.Models.SearchCriteria;
using System.ComponentModel;
using AtHoc.IWS.Web.Models.Publishing;
using AtHoc.IWS.Business.Data.SearchSpec;
using AtHoc.Targeting;

namespace AtHoc.IWS.Web.Areas.Settings.Models
{
    public class DisableDeleteEndUsersSpec
    {
        /// <summary>
        /// Get/Set UserDataModel
        /// </summary>
        public DisableDeleteEndUsersModel EndUsersDisableDeleteModel { get; set; }

        /// <summary>
        /// Get/Set User for IsDisableUserChecked
        /// </summary>
        public bool IsCheckedForDisable { get; set; }

        public AutoCleanupType actionType { get; set; }

        public SearchCriteriaModel DisableDynamicCriteria { get; set; }

        public SearchCriteriaModel DeleteDynamicCriteria { get; set; }
        /// <summary>
        /// Get/Set Status
        /// </summary>
        public UserStatusType UserStatus { get; set; }


        /// <summary>
        /// Get/Set User for IsDeleteUserChecked
        /// </summary>
        public bool IsCheckedForDelete { get; set; }


        /// <summary>
        /// Get/Set UserDataModel
        /// </summary>
        public PurgeUserInformation PurgeUsersModel { get; set; }

        /// <summary>
        /// Get/Set UserDataModel
        /// </summary>
        public searchEndUsersCriteria SearchEndUsersCriteriaModel { get; set; }
    }

    /// <summary>
    /// Purge Interval Enum
    /// </summary>
    public enum PurgeUserDurationEnum
    {
        [Description("PurgeUser_1_Month")]
        one_month = 30,
        [Description("PurgeUser_3_Months")]
        three_months = 90,
        [Description("PurgeUser_6_Months")]
        six_months = 180,
        [Description("PurgeUser_1_Year")]
        one_year = 365,
        [Description("PurgeUser_2_Years")]
        two_years = 730,
        [Description("PurgeUser_5_Years")]
        five_years = 1825,

    }

    /// <summary>
    /// Report Columns Enum
    /// </summary>
    public enum DisableDeleteReportColumnEnum
    {
        [Description("DisableDelete_Report_User_Id")]
        User_Id,
        [Description("DisableDelete_Report_User_Name")]
        Username,
        [Description("DisableDelete_Report_First_Name")]
        Firstname,
        [Description("DisableDelete_Report_Last_Name")]
        Lastname,
        [Description("DisableDelete_Report_Display_Name")]
        Displayname,
        [Description("DisableDelete_Report_Old_Status")]
        Old_Status,
        [Description("DisableDelete_Report_New_Status")]
        New_Status,
        [Description("DisableDelete_Report_Status_Change_Comments")]
        Status_Change_Comments,


    }

    public enum DisableDeleteType
    {
        Disable = 0,
        Delete = 1
    }
    public class PurgeUserInformation
    {
        //Get/Set User for purge request
        public bool IsUserPurgedRequest { get; set; }
        public string SelectedPurgeDuration { get; set; }

        /// <summary>
        /// Get/Set purge duration 
        /// </summary>
        public string PurgeUsers { get; set; }


        public List<MultiSelectListModel> PurgeDurationList { get; set; }

    }

    public class searchEndUsersCriteria
    {
        private int _page = 1;
        public int page { get { return _page; } set { _page = value; } }

        private int _pageSize = 50;
        public int pageSize { get { return _pageSize; } set { _pageSize = value; } }

        private string _sortBy = "LOGIN_ID";
        public string sortBy { get { return _sortBy; } set { _sortBy = value; } }

        private string _sortOrder = "asc";
        public string sortOrder { get { return _sortOrder; } set { _sortOrder = value; } }
        public bool showList { get; set; }
        public bool isfromDisable { get; set; }
        private string[] _searchString = null;

        public string[] searchString
        {
            get { return _searchString; }
            set { _searchString = value; }
        }

        public SearchCriteriaModel searchModel { get; set; }
    }

}
