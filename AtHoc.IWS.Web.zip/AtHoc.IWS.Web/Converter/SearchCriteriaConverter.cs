﻿using AtHoc.IWS.Business.Database;
using AtHoc.IWS.Business.Domain.CustomAttributes;
using AtHoc.IWS.Business.Domain.CustomAttributes.Impl;
using AtHoc.IWS.Business.Domain.CustomAttributes.Spec;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Domain.Users.Search;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Domain.Users;
using AtHoc.IWS.Business.Domain.VirtualSystem;
using AtHoc.IWS.Business.Domain.VirtualSystem.Spec;
using AtHoc.Global.Resources;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Devices;
using AtHoc.IWS.Business.Domain.Devices.Spec;
using AtHoc.IWS.Web.Models.UserManager;
using AtHoc.IWS.Web.Models.SearchCriteria;
using AtHoc.IWS.Business.Domain;
using AtHoc.IWS.Business.Domain.Users.Spec;
using AtHoc.IWS.Business.Data;
using AtHoc.Infrastructure.Serialization;
using AtHoc.Infrastructure.Data;
using AtHoc.IWS.Web.Configurations.Constants;
using AtHoc.Global.Resources.Implementations;
using AtHoc.Global.Resources.Entities;

namespace AtHoc.IWS.Web.Converter.SearchCriteria
{
    public interface ISearchCriteriaConverter
    {
        SearchCriteriaModel GetSearchCriteriaModel(IEnumerable<OperatorUserBase> operatorUserBase);

		SearchCriteriaModel GetSearchCriteriaModel(IEnumerable<IAttributeCriteriaParameter> parameters);

        IEnumerable<OperatorUserBase> GetOperatorUserBase(IEnumerable<Selection> selections);

        IEnumerable<IAttributeCriteriaParameter> GetAttributeCriteriaPrameter(IEnumerable<Selection> selections);

        string getDisplayText(CriteriaParam param, CustomAttribute attribute, bool isDisplayFormat, Provider provider);
        string getDeviceDisplayText(CriteriaParam param, string deviceName, string deviceCommonName, bool isDisplayFormat);

        string getRoleDisplayText(CriteriaParam param, Selection selection, bool isDisplayFormat);

        string getVPSDisplayText(CriteriaParam param, Selection selection, bool isDisplayFormat);

    }

    public class SearchCriteriaConverter : ISearchCriteriaConverter
    {
        private readonly IDeviceFacade deviceFacade;
        private readonly ICustomAttributeCache customAttributeCache;
        private readonly ICustomAttributeFacade customAttributeFacade;
        private readonly IOperatorDetailsFacade operatorFacade;
        private readonly IVirtualSystemFacade virtualSystemFacade;
        private readonly IEnumerable<CustomAttributeQueryOperator> operands;

        private Provider provider;
        private int providerId;
        private IEnumerable<OperatorUserBase> operatorUserBase;

        public SearchCriteriaConverter(ICustomAttributeCache attributes, IDeviceFacade deviceFacade, ICustomAttributeFacade customAttributeFacade, IOperatorDetailsFacade operatorFacade, IVirtualSystemFacade virtualSystemFacade)
        {
            this.customAttributeCache = attributes;
            this.deviceFacade = deviceFacade;
            this.operatorFacade = operatorFacade;
            this.virtualSystemFacade = virtualSystemFacade;
            this.operands = customAttributeFacade.GetOperands();
        }

        public IEnumerable<OperatorUserBase> GetOperatorUserBase(IEnumerable<Selection> selections)
        {
            this.provider = RuntimeContext.Provider;
            this.providerId = this.provider.Id;
            var operatorUserBase = new List<OperatorUserBase>();
            foreach (var sel in selections)
            {
                var searchValues = getSearchValue(sel);
                operatorUserBase.Add(new OperatorUserBase { ProviderId = providerId, AttributeId = sel.entity.id, SearchCondition = sel.operand, SearchValues = searchValues, AttributeType = sel.entity.entityType });
            }
            return operatorUserBase;
        }

        public IEnumerable<IAttributeCriteriaParameter> GetAttributeCriteriaPrameter(IEnumerable<Selection> selections)
        {
            List<AttributeCriteriaParameter> attributeCriterias = null;

            if(selections != null && selections.Any())
            {
                attributeCriterias = selections.Select(s =>
                    new AttributeCriteriaParameter(getSearchValue(s), ConditionOperatorConvertor.Convert(s.operand))
                    {
						ObjectType = EnumUtils<CriteriaObjectType>.Parse(s.entity.entityType),
                        AttributeType = getAttributeTypeFromString(s.entity.dataType),
                        ObjectId = s.entity.id,
                        Value = getSearchValue(s),
                        Operator = ConditionOperatorConvertor.Convert(s.operand)
                    }).ToList();
            }

            return attributeCriterias;
        }

        private CustomAttributeDataType getAttributeTypeFromString(string type)
        {
            CustomAttributeDataType attributeType;
            if(!Enum.TryParse(type, out attributeType))
            {
                return CustomAttributeDataType.Unknown;
            }
            return attributeType;
        }

        public SearchCriteriaModel GetSearchCriteriaModel(IEnumerable<OperatorUserBase> operatorUserBase)
        {
            SearchCriteriaModel criteriaModel = null;
            if(operatorUserBase != null && operatorUserBase.Any())
            {
                return getSearchCriteriaModel( 
                    operatorUserBase.Select(p => 
                        new CriteriaParam
                        { 
                            Id = p.AttributeId, 
                            Type = p.AttributeType, 
                            Operator = p.SearchCondition.Value, 
                            Value = p.SearchValues
                        }), true);
            }

            return criteriaModel;
        }

		public SearchCriteriaModel GetSearchCriteriaModel(IEnumerable<IAttributeCriteriaParameter> parameters)
        {
            SearchCriteriaModel criteriaModel = null;
            if(parameters != null && parameters.Any())
            {
                criteriaModel = getSearchCriteriaModel(
                    parameters.Select(p => 
                        new CriteriaParam
                        { 
                            Id = p.ObjectId, 
                            Type = p.ObjectType.ToString(),
							Operator = ConditionOperatorConvertor.Convert(p.Operator), 
                            Value = p.Value.ToString() 
                        }),
						true);
            }

            return criteriaModel;
        }

        private string getSearchValue(Selection sel)
        {
            var returnValue = new List<string>();
            foreach (var val in sel.value)
            {
                CustomAttributeDataType attrType;
                if (Enum.TryParse(sel.entity.dataType, out attrType))
                {
                    switch (attrType)
                    {
                        case CustomAttributeDataType.Unknown:
                            break;
                        case CustomAttributeDataType.Number:
                        case CustomAttributeDataType.String:
                        case CustomAttributeDataType.Memo:
                        case CustomAttributeDataType.Date:
                        case CustomAttributeDataType.DateTime:
                        case CustomAttributeDataType.Device:
                                returnValue.Add(val.text);
                            break;
                        case CustomAttributeDataType.Picklist:
                        case CustomAttributeDataType.MultiPicklist:
                        case CustomAttributeDataType.Checkbox:
                            returnValue.Add(val.id.ToString());
                            break;
                        case CustomAttributeDataType.Path:
                            returnValue.Add(val.lineage);
                            break;
                        case CustomAttributeDataType.GeoLocation:
                            returnValue.Add(val.text);
                            break;
                        case CustomAttributeDataType.AttributeValue:
                            break;
                        case CustomAttributeDataType.Entity:
                            break;
                        case CustomAttributeDataType.Object:
                            break;
                        default:
                            break;
                    }
                }
            }
            return returnValue.Join();
        }

		private SearchCriteriaModel getSearchCriteriaModel(IEnumerable<CriteriaParam> parameters, bool isDisplayFormat)
        {
            this.provider = RuntimeContext.Provider;
            this.providerId = provider.Id;
            var display = new List<Display>();
            var selections = new List<Selection>();


            var attrs = customAttributeCache.Get(this.providerId, RuntimeContext.Provider.BaseLocale, false).ToList();
            var devices = deviceFacade.GetDevicesBySpec(new DeviceSpec
            {
                ProviderId = provider.Id,
                IncludeDeviceProvider = true,
                IncludeDeviceGroup = true,
                EnabledOnly = true
            },RuntimeContext.Provider.BaseLocale);

            //User Attribute Localization code
            GlobalEntityLocaleFacade globalEntityLocaleFacade = new GlobalEntityLocaleFacade(new GlobalEntityLocaleRepository());

            foreach (var param in parameters)
            {
                if (param.Type == "ATTRIBUTE")
                {
                    var attr = attrs.Where(c => c.Id == param.Id).FirstOrDefault();

                    var selection = new Selection();
                    selection.operand = (int)param.Operator;
                    selection.CreateEntity(commonName: attr.CommonName, dataType: attr.AttributeTypeId.Value, name: attr.AttributeName, id: attr.Id, hierarchyId: attr.HierarchyId);
                    if (attr.AttributeTypeId.Value == CustomAttributeDataType.Picklist || attr.AttributeTypeId.Value == CustomAttributeDataType.MultiPicklist)
                    {
                        var attrValues = attr.Values.Where(v => param.Value.Split<int>().Contains(v.ValueId));
                        foreach (var atrVal in attrValues)
                        {
                            selection.CreateValue(id: atrVal.ValueId, text: atrVal.ValueName);
                        } 
                    }
                    if (attr.AttributeTypeId.Value == CustomAttributeDataType.Checkbox)
                    {
                        var attrValues = attr.Values.Where(v => param.Value.Split<int>().Contains(v.ValueId));
                        foreach (var atrVal in attrValues)
                        {
                            var translatedValue = globalEntityLocaleFacade.GetLocalizedValue(atrVal.ValueName,
                                        BusinessEntity.CheckBox, "Name", RuntimeContext.Provider.BaseLocale);

                            selection.CreateValue(id: atrVal.ValueId, text: translatedValue);
                        }
                    }
                    else if (attr.AttributeTypeId.Value == CustomAttributeDataType.Path)
                    {
                        var sVals = param.Value.Split<string>();
                        foreach (var valItem in sVals)
                        {
                            selection.CreateValue(entityType: GroupType.ATTRIBUTE, id: attr.Id, text: valItem, lineage: valItem);
                        }
                    }
                    else
                    {
                        if (!string.IsNullOrWhiteSpace(param.Value) && param.Value.Contains(","))
                        {
                            var sVals = param.Value.Split<string>(",");
                            foreach (var valItem in sVals)
                            {
                                selection.CreateValue(entityType: GroupType.ATTRIBUTE, id: attr.Id, text: valItem, lineage: valItem);
                            }
                        }
                        else
                        {
                            selection.CreateValue(id: attr.Id, text: param.Value);
                        }
                    }

                    selections.Add(selection);
                    display.Add(new Display { DisplayText = getDisplayText(param, attr, isDisplayFormat, this.provider) });
                }
                if (param.Type == "DEVICE")
                {
                    var device = devices.Where(c => c.Id == param.Id).FirstOrDefault();
                    var selection = new Selection();
                    selection.operand = (int)param.Operator;
                    selection.CreateEntity(commonName: device.CommonName, entityType: GroupType.DEVICE, dataType: CustomAttributeDataType.String, name: device.Name, id: device.Id);

                    selection.CreateValue(device.Id, GroupType.DEVICE, param.Value);
                    selections.Add(selection);
                    display.Add(new Display { DisplayText = getDeviceDisplayText(param, device.Name, device.CommonName, isDisplayFormat) });
                }
                if (param.Type == "ROLE")
                {
                    var selection = new Selection {operand = param.Operator};
                    selection.CreateEntity(commonName: "ROLE", dataType: CustomAttributeDataType.MultiPicklist, name: IWSResources.DisplayName_OperatorRoles, id: 0, hierarchyId: null, entityType: GroupType.ROLE);

                    var providerRoles = operatorFacade.GetOperatorRoles(new OperatorRoleSpec() { ProviderId = RuntimeContext.Provider.Id,BaseLocale=RuntimeContext.Provider.BaseLocale });

                    var oprRoles = providerRoles.Where(v => param.Value.Split<int>().Contains(v.Id));
                    foreach (var oprRole in oprRoles)
                    {
                        selection.CreateValue(oprRole.Id, GroupType.ROLE, oprRole.RoleName);
                    }

                    selections.Add(selection);
                    display.Add(new Display { DisplayText = getRoleDisplayText(param, selection, isDisplayFormat) });
                }

                if (RuntimeContext.Provider.FeatureMatrix.IsEnterpriseManagementSupported)
                {
                    if (param.Type == "VPS")
                    {
                        var selection = new Selection { operand = param.Operator };
                        selection.CreateEntity(commonName: CommonNames.Organizations, dataType: CustomAttributeDataType.MultiPicklist, name: IWSResources.DisplayName_Organizations, id: 0, hierarchyId: null, entityType: GroupType.VPS);

                        var providerIds = param.Value.Split<int>();

                        IEnumerable<Provider> providersList = new List<Provider>();
                        foreach (var providerId in providerIds)
                        {
                            ((List<Provider>)providersList).Add(virtualSystemFacade.GetProviderBySpec(new VirtualSystemSpec { Id = providerId, IncludeExtendedParams = true }));
                        }

                        var providerAccessValuesList = providersList.Select(v => new CustomAttributeValueForQuery { name = v.ProviderName, id = v.Id, commonName = v.ProviderName })
                                .ToList();

                        foreach (var vps in providerAccessValuesList)
                        {
                            selection.CreateValue(vps.id, GroupType.VPS, vps.name);
                        }

                        selections.Add(selection);
                        display.Add(new Display { DisplayText = getVPSDisplayText(param, selection, isDisplayFormat) });
                    }
                }
            }

            return new SearchCriteriaModel(display, selections);
        }

        public string getDisplayText(CriteriaParam param, CustomAttribute attribute, bool isDisplayFormat, Provider provider)
        {
            var operand = operands.Where(s => s.Id == param.Operator).FirstOrDefault();
            var resourceKey = "User_Criteria_Builder_Operator_{0}_{1}_Display".FormatWith(operand.CommonName, attribute.AttributeTypeId.Value);
            if (IWSResources.ResourceManager.GetString(resourceKey).IsNullOrEmpty())
            {
                resourceKey = "User_Criteria_Builder_Operator_{0}_Display".FormatWith(operand.CommonName);
            }

            var attrValue = param.Value.ToString();
            //format datetime to VPS and convert to VPS Timezone
            if (attribute.AttributeTypeId.Value == CustomAttributeDataType.Date || attribute.AttributeTypeId.Value == CustomAttributeDataType.DateTime)
            {
                string value = param.Value;

                if (value.StartsWith(QueryBuilderConstants.RelativeDateValueIndicaterString)) //D:0 etc
                {
                    var number = Int32.Parse(value.Substring(QueryBuilderConstants.RelativeDateValueIndicaterString.Length));
                    if (number == 0) {
                        attrValue = IWSResources.ResourceManager.GetString(QueryBuilderConstants.DisplayResourceLookupFormatShort.FormatWith(operand.CommonName,attribute.AttributeTypeId.Value.ToString(),QueryBuilderConstants.NowResourceKey));
                    }
                    else if (number < 0) //past
                    {
                        int absValue = Math.Abs(number);
                        var singleOrPluralResourceKey = (absValue == 1) ? QueryBuilderConstants.PastXDaysSingularResourceKey : QueryBuilderConstants.PastXDaysPluralResourceKey;
                        attrValue = IWSResources.ResourceManager.GetString(QueryBuilderConstants.DisplayResourceLookupFormatShort.FormatWith(operand.CommonName, attribute.AttributeTypeId.Value.ToString(), singleOrPluralResourceKey)).FormatWith(absValue.ToString());
                    }
                    else if (number > 0) //next
                    {
                        var singleOrPluralResourceKey = (number == 1) ? QueryBuilderConstants.NextXDaysSingularResourceKey : QueryBuilderConstants.NextXDaysPluralResourceKey;
                        attrValue = IWSResources.ResourceManager.GetString(QueryBuilderConstants.DisplayResourceLookupFormatShort.FormatWith(operand.CommonName, attribute.AttributeTypeId.Value.ToString(), singleOrPluralResourceKey.FormatWith(number))).FormatWith(number);
                    }                                    
                } else {
                    attrValue = provider.SystemToVpsTime(param.Value.ToString().ConvertTo<DateTime>()).ToString();
                    if (attribute.AttributeTypeId.Value == CustomAttributeDataType.DateTime)
                    {
                        var strDate = param.Value;
                        if (!string.IsNullOrWhiteSpace(strDate))
                        {
                            if (strDate.Contains(","))
                            {
                                strDate = strDate.Split(',')[0].Trim();
                            }
                            attrValue = provider.SystemToVpsTime(strDate.ConvertTo<DateTime>()).ToString(provider.GetDateTimeFormat().Replace("TT", "tt"));
                        }
                    }
                    else
                    {
                        attrValue = provider.SystemToVpsTime(param.Value.ToString().ConvertTo<DateTime>()).ToString(provider.GetDateFormat());
                    }
                }
                if(isDisplayFormat)
                    attrValue = "<span class='bold'>" + attrValue + "</span>";
            }

            //User Attribute Localization code
            GlobalEntityLocaleFacade globalEntityLocaleFacade = new GlobalEntityLocaleFacade(new GlobalEntityLocaleRepository());
            
            //get the value from attr value table
            if (attribute.AttributeTypeId.Value == CustomAttributeDataType.Picklist || attribute.AttributeTypeId.Value == CustomAttributeDataType.MultiPicklist)
            {
                attrValue = attribute.Values.Where(v => param.Value.ToString().Split<int>().Contains(v.ValueId)).Select(s => s.ValueName).Join(", ");
                if (isDisplayFormat)
                {
                    attrValue =
                        attribute.Values.Where(v => param.Value.ToString().Split<int>().Contains(v.ValueId))
                            .Select(s => s.ValueName)
                            .Join("&quot;</span>&#160;" + IWSResources.AtHoc_User_Search_or +
                                  "&#160;<span class='bold'>&quot;");
                    attrValue = "<span class='bold'>&quot;" + attrValue + "&quot;</span>";
                }
            } 
            else if (attribute.AttributeTypeId.Value == CustomAttributeDataType.Checkbox)
            {
                attrValue = attribute.Values.Where(v => param.Value.ToString().Split<int>().Contains(v.ValueId)).Select(s => s.ValueName).Join(", ");
                attrValue = globalEntityLocaleFacade.GetLocalizedValue(attrValue, BusinessEntity.CheckBox, "Name", provider.BaseLocale);

                if (isDisplayFormat)
                {
                    attrValue =
                        attribute.Values.Where(v => param.Value.ToString().Split<int>().Contains(v.ValueId))
                            .Select(s => s.ValueName)
                            .Join("&quot;</span>&#160;" + IWSResources.AtHoc_User_Search_or +
                                  "&#160;<span class='bold'>&quot;");
                    attrValue = globalEntityLocaleFacade.GetLocalizedValue(attrValue, BusinessEntity.CheckBox, "Name", provider.BaseLocale);
                    attrValue = "<span class='bold'>&quot;" + attrValue + "&quot;</span>";
                }
            }
            else if (attribute.AttributeTypeId.Value == CustomAttributeDataType.Path && attrValue == "/")
            {
                attrValue = attribute.AttributeName;
            }
            else if (attribute.AttributeTypeId.Value == CustomAttributeDataType.Path)
            {
                //attrValue = attrValue.LastIndexOf("/");
                if (attrValue != null)
                {
                    var attrNodes = string.Empty;
                    var attrValues = attrValue.Split(new[] { "/," }, StringSplitOptions.None);
                    foreach (var attrVal in attrValues)
                    { 
                        attrNodes = attrNodes + attrVal.Replace("/", "") + "/,";
                    }
                    if (attrNodes.EndsWith("/,"))
                        attrValue = attrNodes.Remove(attrNodes.LastIndexOf("/,"));
                    else
                        attrValue = attrNodes;
                }
            } else if (attribute.AttributeTypeId.Value == CustomAttributeDataType.GeoLocation)
            { 
                try {
                    var locations = new AtHoc.IWS.Map.FeatureCollection(attrValue);
                    attrValue  = string.Format(IWSResources.User_Criteria_Builder_Locations,locations.Features.Count.ToString());
                
                } catch(Exception e)
                {
                    attrValue  = string.Format(IWSResources.User_Criteria_Builder_Locations,"0");
                }                               
            }

            var attributeName = attribute.AttributeName;

            if (isDisplayFormat)
            {
                attributeName = "<span class='bold'>" + attributeName + "</span>";
                if (!attrValue.StartsWith("<span class='bold'"))
                {
                    //attrValue = "<span class='bold'>&quot;" + attrValue + "&quot;</span>";
                    if (attribute.AttributeTypeId.Value == CustomAttributeDataType.Path)
                        attrValue = attrValue.Split(new string[] { "/," }, StringSplitOptions.None).Join("&quot;</span>&#160;" + IWSResources.AtHoc_User_Search_or + "&#160;<span class='bold'>&quot;");
                    else
                    attrValue = attrValue.Split(',').Join("&quot;</span>&#160;" + IWSResources.AtHoc_User_Search_or + "&#160;<span class='bold'>&quot;");
                    attrValue = "<span class='bold'>&quot;" + attrValue + "&quot;</span>";
                }
            }

            var resoucevalue = IWSResources.ResourceManager.GetString(resourceKey).Replace("{customAttributeName}", attributeName).Replace("{value}", attrValue);
            return resoucevalue;
        }

        public string getDeviceDisplayText(CriteriaParam param, string deviceName, string deviceCommonName, bool isDisplayFormat)
        {
            var operand = operands.Where(s => s.Id == param.Operator).FirstOrDefault();
            var resourceKey = "User_Criteria_Builder_Operator_{0}_{1}_Display".FormatWith(operand.CommonName, CustomAttributeDataType.String);
            if (IWSResources.ResourceManager.GetString(resourceKey).IsNullOrEmpty())
            {
                resourceKey = "User_Criteria_Builder_Operator_{0}_Display".FormatWith(operand.CommonName);
            }

            var attributeName = deviceName;
            var attributeValue = param.Value;

            if (isDisplayFormat)
            {
                attributeName = "<span class='bold'>" + attributeName + "</span>";

                if (deviceCommonName == CommonNames.DesktopDevice ||
                    deviceCommonName == CommonNames.MobileNotifierDevice)
                {
                    var tempattributeValue = attributeValue.Split(',').Select(val => val.Trim() == "Active" ? IWSResources.Device_Active : IWSResources.Device_Inactive).ToList(); 
                    attributeValue = "<span class='bold'>&quot;" +
                                     tempattributeValue.Join("&quot;</span>&#160;" + IWSResources.AtHoc_User_Search_or +
                                               "&#160;<span class='bold'>&quot;") + "&quot;</span>";
                }
                else
                    attributeValue = "<span class='bold'>&quot;" + attributeValue + "&quot;</span>";
            }

            var resoucevalue = IWSResources.ResourceManager.GetString(resourceKey).Replace("{customAttributeName}", attributeName).Replace("{value}", attributeValue);
            return resoucevalue;
        }

        public string getRoleDisplayText(CriteriaParam param, Selection selection, bool isDisplayFormat)
        {
            var operand = operands.Where(s => s.Id == param.Operator).FirstOrDefault();
            var resourceKey = "User_Criteria_Builder_Operator_{0}_{1}_Display".FormatWith(operand.CommonName, CustomAttributeDataType.String);
            if (IWSResources.ResourceManager.GetString(resourceKey).IsNullOrEmpty())
            {
                resourceKey = "User_Criteria_Builder_Operator_{0}_Display".FormatWith(operand.CommonName);
            }

            var attributeName = IWSResources.OperatorPermissions_Operator_Roles;
            var attributeValue = isDisplayFormat ? "" : param.Value;

            if (isDisplayFormat)
            {
                attributeName = "<span class='bold'>" + attributeName + "</span>";
                attributeValue = "<span class='bold'>&quot;" + selection.value.Select(s => s.text).Join("&quot;</span>&#160;" + IWSResources.AtHoc_User_Search_or + "&#160;<span class='bold'>&quot;") + "&quot;</span>";
            }

            var resoucevalue = IWSResources.ResourceManager.GetString(resourceKey).Replace("{customAttributeName}", attributeName).Replace("{value}", attributeValue);
            return resoucevalue;
        }

        public string getVPSDisplayText(CriteriaParam param, Selection selection, bool isDisplayFormat)
        {
            var operand = operands.Where(s => s.Id == param.Operator).FirstOrDefault();
            var resourceKey = "User_Criteria_Builder_Operator_{0}_{1}_Display".FormatWith(operand.CommonName, CustomAttributeDataType.String);
            if (IWSResources.ResourceManager.GetString(resourceKey).IsNullOrEmpty())
            {
                resourceKey = "User_Criteria_Builder_Operator_{0}_Display".FormatWith(operand.CommonName);
            }

            var attributeName = IWSResources.DisplayName_Organizations;
            var attributeValue = isDisplayFormat ? "" : param.Value;

            if (isDisplayFormat)
            {
                attributeName = "<span class='bold'>" + attributeName + "</span>";
                attributeValue = "<span class='bold'>&quot;" + selection.value.Select(s => s.text).Join("&quot;</span>&#160;" + IWSResources.AtHoc_User_Search_or + "&#160;<span class='bold'>&quot;") + "&quot;</span>";
            }

            var resoucevalue = IWSResources.ResourceManager.GetString(resourceKey).Replace("{customAttributeName}", attributeName).Replace("{value}", attributeValue);
            return resoucevalue;
        }


    }

    public class CriteriaParam
    {
        public string Type { get; set; }
        public int Id { get; set; }
        public int Operator { get; set; }
        public string Value { get; set; }
    }
}