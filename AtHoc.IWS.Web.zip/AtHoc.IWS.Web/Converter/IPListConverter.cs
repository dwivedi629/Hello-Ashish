﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;
using AtHoc.Global.Resources;
namespace AtHoc.IWS.Web.Converter
{
    public interface IIpListConverter
    {
        List<IpModel> GetIPModelsFromXML(string xmlString);
        string GetXmlStringFromIPList(IList<IpModel> ipList);
        IList<IpModel> GetIpListForCsv(string ipCsv);
        string GetCsvForIpList(IList<IpModel> ipList);
    }

    public class IpListConverter : IIpListConverter
    {
        public List<IpModel> GetIPModelsFromXML(string xmlString)
        {
            if (string.IsNullOrWhiteSpace(xmlString))
                return null;

            var doc = XDocument.Parse(xmlString);
            var ipList = (from node in doc.Descendants("address")
                      select new IpModel()
                      {
                          Type = node.Attribute("type").Value,
                          Address1 = node.Descendants("address1").First().Value,
                          Address2 = node.Descendants("address2").First().Value,
                      }).ToList();
            return ipList;
        }

        public string GetCsvForIpList(IList<IpModel> ipList)
        {
            var ipListCSV = string.Empty;
            if (ipList != null && ipList.Any())
            {
                foreach (var ip in ipList)
                {
                    if (!string.IsNullOrEmpty(ipListCSV))
                    {
                        ipListCSV += ", ";
                    }

                    if (string.Equals(ip.Type, IpModel.IP_TYPE_IP, StringComparison.CurrentCultureIgnoreCase))
                    {
                        ipListCSV += ip.Address1;
                    }
                    else if (string.Equals(ip.Type, IpModel.IP_TYPE_RANGE, StringComparison.CurrentCultureIgnoreCase))
                    {
                        ipListCSV += string.Format("{0} - {1}", ip.Address1, ip.Address2);
                    }
                    else if (string.Equals(ip.Type, IpModel.IP_TYPE_MASK, StringComparison.CurrentCultureIgnoreCase))
                    {
                        ipListCSV += string.Format("{0}:{1}", ip.Address1, ip.Address2);
                    }
                }
            }

            return ipListCSV;
        }

        public IList<IpModel>  GetIpListForCsv(string ipCsv)
        {
            if (string.IsNullOrWhiteSpace(ipCsv))
                return null;

            var ipListModel = new List<IpModel>();
            foreach(var ipStr in ipCsv.Split(','))
            {
                if(!string.IsNullOrWhiteSpace(ipStr))
                    ipListModel.Add(new IpModel(ipStr));
            }

            return ipListModel;
        }

        public string GetXmlStringFromIPList(IList<IpModel> ipList)
        {
            if (ipList == null || !ipList.Any())
                return string.Empty;

            var ipListModel = new IpListModel() { IpList = ipList.ToList() };

            var xmlSetting = new XmlWriterSettings()
            {
                OmitXmlDeclaration = true,
                Indent = true
            };
            using (var writer = new StringWriter())
            {
                using (var xmlWriter = XmlWriter.Create(writer, xmlSetting))
                {
                    var xmlNamespace = new XmlSerializerNamespaces();
                    xmlNamespace.Add(string.Empty, string.Empty);

                    var serializer = new XmlSerializer(typeof(IpListModel));
                    serializer.Serialize(xmlWriter, ipListModel, xmlNamespace);
                }
                return writer.ToString();
            }
        }
    }

    [XmlRoot("ipListDefinition")]
    public class IpListModel
    {
        public IpListModel() 
        { 
            IpList = new List<IpModel>(); 
        }

        [XmlElement("address")]
        public List<IpModel> IpList { get; set; }
    }

    public class IpModel
    {
        public const string IP_TYPE_IP = "IP";
        public const string IP_TYPE_MASK = "MASK";
        public const string IP_TYPE_RANGE = "RANGE";

        public IpModel()
        {

        }

        public IpModel(string ipStr)
        {
            if(ipStr.Contains("-"))
            {
                var ipArray = ipStr.Split('-');
                
                if (ipArray == null || ipArray.Count() != 2)
                    throw new InvalidIPAddress();

                ValidateIpString(ipArray[0].Trim());
                ValidateIpString(ipArray[1].Trim());

                IPAddress ipOne, ipTwo;
                if(!IPAddress.TryParse(ipArray[0].Trim(), out ipOne) || !IPAddress.TryParse(ipArray[1].Trim(), out ipTwo))
                    throw new InvalidIPAddress();

                Type = IP_TYPE_RANGE;
                Address1 = ipOne.ToString();
                Address2 = ipTwo.ToString();
                TranslatedAddress1 = Address1;
                TranslatedAddress2 = Address2;
            }
            else if(ipStr.Contains(":"))
            {
                var ipArray = ipStr.Split(':');

                if (ipArray == null || ipArray.Count() != 2)
                    throw new InvalidIPAddress();

                ValidateIpString(ipArray[0].Trim());
                ValidateIpString(ipArray[1].Trim());

                IPAddress ipOne, ipTwo, ipStart, ipEnd;
                if (!IPAddress.TryParse(ipArray[0].Trim(), out ipOne) || !IPAddress.TryParse(ipArray[1].Trim(), out ipTwo))
                    throw new InvalidIPAddress();

                Type = IP_TYPE_MASK;
                Address1 = ipOne.ToString();
                Address2 = ipTwo.ToString();

                try
                {
                    GetIPStartEnd(ipOne, ipTwo, out ipStart, out ipEnd);
                }
                catch
                {
                    throw new InvalidIPAddress();
                }

                TranslatedAddress1 = ipStart.ToString();
                TranslatedAddress2 = ipEnd.ToString();
            }
            else
            {
                IPAddress ipOne;
                if (!IPAddress.TryParse(ipStr.Trim(), out ipOne))
                    throw new InvalidIPAddress();

                ValidateIpString(ipStr.Trim());

                Type = IP_TYPE_IP;
                Address1 = ipOne.ToString();
                Address2 = string.Empty;
                TranslatedAddress1 = Address1;
                TranslatedAddress2 = Address1;
            }

        }

        private void ValidateIpString(string ip)
        {
            if (ip.Count(a => a == '.') != 3)
                throw new InvalidIPAddress();
        }

        private void GetIPStartEnd(IPAddress ip, IPAddress subnet, out IPAddress startIP, out IPAddress endIP)
        {
            // Convert the IP address to bytes.
            byte[] ipBytes = ip.GetAddressBytes();

            // BitConverter gives bytes in opposite order to GetAddressBytes().
            byte[] maskBytes = subnet.GetAddressBytes();

            byte[] startIPBytes = new byte[ipBytes.Length];
            byte[] endIPBytes = new byte[ipBytes.Length];

            // Calculate the bytes of the start and end IP addresses.
            for (int i = 0; i < ipBytes.Length; i++)
            {
                startIPBytes[i] = (byte)(ipBytes[i] & maskBytes[i]);
                endIPBytes[i] = (byte)(ipBytes[i] | ~maskBytes[i]);
            }

            // Convert the bytes to IP addresses.
            startIP = new IPAddress(startIPBytes);
            endIP = new IPAddress(endIPBytes);
        }

        [XmlAttribute("type")]
        public string Type { get; set; }
        
        [XmlElement("address1")]
        public string Address1 { get; set; }

        [XmlElement("address2")]
        public string Address2 { get; set; }

        [XmlElement("translatedAddress1")]
        public string TranslatedAddress1 { get; set; }

        [XmlElement("translatedAddress2")]
        public string TranslatedAddress2 { get; set; }

    }

    public class InvalidIPAddress : ApplicationException
    {
        public override string Message
        {
            get{ return IWSResources.DistributionList_Error_Invalid_IP_Address ; }
        }
    }
}