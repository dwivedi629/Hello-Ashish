﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Web.Configurations.Constants;
using EO.Pdf;
using AtHoc.IWS.Web.Helpers;

namespace AtHoc.IWS.Web.Configurations
{
    public class PdfGridConfiguration
    {
        private int _numberOfColumns;
        
        public string OperatorName { get; set; }
        public string ExportDateTime { get; set; }
        public string ExportTimeZone { get; set; }
        public string InformationBanner { get; set; }
        public string SubHeadline { get; set; }
        public string PageTitle { get; set; }

        public float PdfDocumentSize { get; set; }

        public string HtmlWrapperSize { get; set; }

        public PdfGridConfiguration(int numberOfColumns,bool isSetWrapper = true)
        {
            _numberOfColumns = numberOfColumns;
            if (!isSetWrapper) return;
            CalculateDimension();
            SetData();
            SetHtmlPdfOptions();
        }

        private void SetHtmlPdfOptions()
        {
            HtmlToPdf.Options.PageSize = new SizeF(PdfDocumentSize, PdfConfig.PageHeight);
            HtmlToPdf.Options.NoCache = true;
        }

        private void SetData()
        {
           OperatorName = RuntimeContext.Operator.DisplayName;
           ExportDateTime = RuntimeContext.Provider.CurrentSystemTimeToVpsTimeString();
           InformationBanner = RuntimeContext.Provider.ExtendedParams.InformationBanner;
           ExportTimeZone = RuntimeContext.Provider.GetVpsTimeZoneFromId().ToLocalizedString();
        } 

        private void CalculateDimension()
        {
            var size = ((_numberOfColumns) * PdfConfig.GridColumnWidth);
            float pdfSize = size / PdfConfig.DotPerInch;
            PdfDocumentSize = pdfSize > PdfConfig.MinPageWidth ? pdfSize : PdfConfig.MinPageWidth;
            HtmlWrapperSize = (size + 10) + "px";

        }

    }

    public static class TimeZoneInfoExtensions
    {
        public static string ToLocalizedString(this TimeZoneInfo timeZone)
        {
            return SettingsHelper.GetLocalizedTimeZone(timeZone.Id);
        }
    }
   
}