﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AtHoc.Infrastructure;
using AtHoc.IWS.Business.Context;
using AtHoc.IWS.Business.Domain.Entities;
using EO.Pdf;

namespace AtHoc.IWS.Web.Configurations.Constants
{
    public class SectionLayoutConfig
    {
        public const string MobileAndDesktopNotifier = "mobileanddesktopnotifier";
        public const string MobileNotifier = "mobilenotifier";
        public const string MembershipsAndAssociations = "membershipsandassociations";
        public const string MemebershipAccessType = "MGT";
        public const string MemebershipEntityType = "LST";
        public const string LoginAndLocation = "login";
        public const string Password = "password";

    }

    public static class CommonNames
    {
        public const string MappingId = "MAPPING_ID";
        public const string UserName = "LOGIN_ID";
        public const string UserPassword = "USR_PSWD";
        public const string UserRandomId = "USER_RANDOM_ID";
        public const string PasswordUpdatedOn = "PASSWORD_UPDATED_ON";
        public const string OperatorRoles = "OPERATOR-ROLES";
        public const string Organizations = "ORGANIZATIONS";

        public const string FirstName = "FIRSTNAME";
        public const string LastName = "LASTNAME";
        public const string DisplayName = "DISPLAYNAME";

        public const string Status = "STATUS";
        public const string CreatedOn = "CREATEDON";

        public const string OperatorUserName = "OPERATOR-USERNAME";
        public const string SSATeam = "SSA-TEAM";

        public const string DesktopDevice = "DesktopPopup";
        public const string MobileNotifierDevice = "mobileNotification";

        public const string Pin = "PIN";
        public const string PreventUserMove = "PREVENT-USER-MOVE";
    }

    public static class PermissionsDisplayNames
    {
        public const string OperatorRoles = "Operator Role";
    }

    public static class FileNameFormats
    {
        public const string Simple = "AtHoc-IWS-{0}.{1}";
        public const string WithTimeStamp = "AtHoc-IWS-{0}-{1}-{2}.{3}";

        public static string GetFormattedFileName(string fileQualifier, string fileExtension)
        {
            var format = "AtHoc-IWS_{0}_{1}_{2}.{3}";
            var vpsname = RuntimeContext.Provider.ProviderName;
            var dateTime = RuntimeContext.Provider.CurrentSystemTimeToVpsTimeString();
            return format.FormatWith(vpsname, fileQualifier, dateTime, fileExtension);
        }
    }

    public static class PdfConfig
    {
        public const int GridColumnWidth = 235;
        public const float DotPerInch = 96.0F;
        public const float PageHeight = 11.0F;
        public const float MinPageWidth = 8.5F;
    }

    public static class UIConfig
    {
        public const int GridPageSize = 25;
    }

    public static class QueryBuilderConstants
    {
        public const string NextXDaysSingularResourceKey = "NextSingular";
        public const string NextXDaysPluralResourceKey = "NextPlural";
        public const string PastXDaysSingularResourceKey = "PastSingular";
        public const string PastXDaysPluralResourceKey = "PastPlural";

        public const string NowResourceKey = "Now";
        public const string AbsoluteDateResourceKey = "AbsoluteDate";

        public const string RelativeDateValueIndicaterString = "D:";
        public const string RelativeDateValueSerializeTemplate = "D:{0}";

        //i.e. User_Criteria_Builder_Operator_Less_Than_Date_Next_Display_Short // 0 - operands text 1 - datatype 2- next, past, now or abs date
        public const string DisplayResourceLookupFormatShort =  "User_Criteria_Builder_Operator_{0}_{1}_{2}_Display_Short";
        public const string DisplayResourceLookupFormatLong =  "User_Criteria_Builder_Operator_{0}_{1}_{2}_Display_Long";
    }

}