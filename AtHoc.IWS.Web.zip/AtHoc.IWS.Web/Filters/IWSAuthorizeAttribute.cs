﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AtHoc.Diagnostics;
using AtHoc.IWS.Business.Domain.Authorization;
using AtHoc.IWS.Business.Domain.Entities;
using AtHoc.IWS.Business.Context;

namespace AtHoc.IWS.Web.Filters
{
    public class IWSAuthorizeAttribute : AuthorizeAttribute
    {
        public IAuthFacade AuthFacade { get; set; }
        public SystemObject[] SystemObject { get; set; }
        public ActionType[] ActionType { get; set; }

        public IWSAuthorizeAttribute(SystemObject[] systemObject, ActionType[] actionTypes)
        {
            SystemObject = systemObject;
            ActionType = actionTypes;
        }

        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            var currentUser = RuntimeContext.Operator;
            var providerId = RuntimeContext.ProviderId;

            if (SystemObject == null || ActionType == null || !SystemObject.Any() || !ActionType.Any()) return false;
            int count = Math.Min(SystemObject.Count(), ActionType.Count());
            for (var i = 0; i < count; i++)
            {
                var allow = false;
                allow = AuthFacade.HasAccess(currentUser, providerId, SystemObject[i], ActionType[i]);
                if (allow) return true;
            }
            if (httpContext != null && httpContext.Request != null)
            {
               var exceptionString =  string.Format("Access denied - Content Path = [{0}]",
                    httpContext.Request.CurrentExecutionFilePath);
                var exception = new UnauthorizedAccessException(exceptionString);
                EventLogger.WriteWarning("Unauthorized operation ",exception);
            }
            return false;
        }

        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
           
            var currentUser = RuntimeContext.Operator;

            if (currentUser != null)
            {
                filterContext.Result = new RedirectResult("/athoc-iws/");
            }
        }

    }
}