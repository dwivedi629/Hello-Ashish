﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Web;
using AtHoc.Infrastructure;
using AtHoc.Infrastructure.Validation;

namespace AtHoc.IWS.Web.Filters
{
    [AttributeUsage(AttributeTargets.Property,AllowMultiple = true)]
    public class ValidateFileAttribute: RuleValidationAttribute
    {
        public string AllowedExtensions { get; set; }
        public string AllowedExtensionMessage { get; set; } 
        public int AllowedSizeInMB { get; set; }
        public string AllowedSizeInMBMessage { get; set; }

        protected override ValidationResult IsValidImpl(object value, ValidationContext validationContext)
        {
            string[] memberNames = null;
            if (validationContext.MemberName.IsNotNullOrEmpty())
                memberNames = new string[] {validationContext.MemberName};

            var file = value as HttpPostedFileBase;

            if (file == null)
                return new ValidationResult("No Files were uploaded", memberNames);

            if (file.ContentLength/(1024 * 1024) > AllowedSizeInMB)
                return new ValidationResult("The file is too big",memberNames);

            var fileName = Path.GetFileName(file.FileName);

            if (!AllowedExtensions.Split().Contains(Path.GetExtension(fileName)))
                return new ValidationResult("Only File with these extension are allowed" + AllowedExtensions,memberNames);

            if (fileName.IndexOfAny(Path.GetInvalidFileNameChars()) != -1)
                return new ValidationResult("Invalid Characters detected in file",memberNames);

            return ValidationResult.Success;
        }
    }
}