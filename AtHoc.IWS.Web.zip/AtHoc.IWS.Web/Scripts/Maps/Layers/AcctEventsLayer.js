﻿define([
"dojo/_base/declare", "esri/layers/GraphicsLayer", "dojo/_base/lang", "esri/request", "dojo/Evented", "dojo/_base/array", "esri/layers/LabelLayer",
"esri/symbols/SimpleFillSymbol", "esri/symbols/SimpleLineSymbol",
"esri/symbols/SimpleMarkerSymbol", "esri/symbols/PictureMarkerSymbol", "esri/Color", "esri/renderers/SimpleRenderer", "maps/util", "dojo/_base/json",
"esri/InfoTemplate", "esri/geometry/Extent"
],
function (declare, GraphicsLayer, lang, request, Evented, array, LabelLayer,
    SimpleFillSymbol, SimpleLineSymbol,
    SimpleMarkerSymbol, PictureMarkerSymbol, Color, SimpleRenderer, util, dojoJson,
    InfoTemplate, Extent) {
    var AcctEventsLayer = declare("athoc.layer.AcctEventsLayer", [Evented], {
        name: "",
        visible: ko.observable(false),
        graphics: [],
        enabled: ko.observable(false),
        order: -1,
        constructor: function (options) {
            var self = this;
            this._abortInit = false;
            this.graphics = [];
            this.visible.subscribe(lang.hitch(this, "setVisibility"));
            this.i18n = options.i18n;
            this.options = options.layer;
            this.order = options.order;
            this.infoTemplate = new InfoTemplate();
            this.infoTemplate.setTitle("${name}");
            this.infoTemplate.setContent(
                '<div class="overflow-hidden pad-bot10 border-bot1">' +
                '<div class="map-pop-label">' +
                        '<div class="icon32 event-mgr-sprite-${priority} pa-sub-icon"></div>' +
                    '</div>' +
                    '<div class="pull-left width60per word-wrap">' +
                            '<div class="bold font-size12 color-light-grey">' + this.i18n.Map_Layer_Acct_Event_Entity + '</div>' +
                            '<div class="bold font-size14">${name}</div>' +
                            '<div class="k-secondary font-size11">' +
                                '<span class="bold">'+ this.i18n.Map_Layer_Ends_At_Text +'</span> ${endsOn}</div>' +
                        '</div>' +
                    '<div class="pull-right font-size10">' +
                         '<span class="pull-left">' + this.i18n.Map_Layer_Updated_Text + ' <br> ${updatedOn}</span>' +
                     '</div>' +
                 '</div>' +
                 '<div class="overflow-hidden border-bot1 pad-all-10">' +
                    '<div class="pull-left pad-all-10 pad-top0 mar-top10">' +
                '<span class="bold">${usersAffected}</span><br><span>' + this.i18n.Map_Acct_Events_Users_Affected  + '</span></div>' +
                    '<div class="pull-left width67per pad-all-10 border-left1">' +
                         '<div class="map-pop-label"><div class="chart"></div></div>' +
                        '<span class="bold">${usersResponded}</span><br><span>' + this.i18n.Map_Acct_Events_Users_Have_Status + '</span>' +
                        '<div class="user-response-tree-view wrap-all"></div>' +
                      '</div>' +
                '</div>' +
                '<a href="' + athoc.iws.account.urls.EventDetails + '?id=${eventId}" target="_blank" class="btn btn-large btn-block mar-left10 btn-primary pull-right mar-top10">' + this.i18n.Map_Acct_Events_Open_Event + '</a>'
            );
            this._esriMap = options.coreMap;
            this.selectedFeaturePoint = {
                eventPoint : '',
                selectedIndex: null,
                objectId: null,
                openPopup: false
            };
													  
            this._esriGraphicsLayer = new GraphicsLayer({ infoTemplate: this.infoTemplate, id: "AcctEventLayer" });
            this._esriMap.addLayer(this._esriGraphicsLayer, 2);
            
            this._esriMap.infoWindow.resize(400, 300);

            this._esriGraphicsLayer.on("mouse-over", function (e) {
                $(e.target).css("cursor", "pointer");

            });
            this._esriGraphicsLayer.on("mouse-out", function(e) {
                $(e.target).css("cursor", "default");
            });
            
            this._esriMap.infoWindow.on("selection-change", function (e) {
                if (e.target.selectedIndex > -1 && e.target.features[e.target.selectedIndex].attributes.layerType == "events") {
                    self.selectedFeaturePoint.selectedIndex = e.target.selectedIndex;
                    self.selectedFeaturePoint.objectId = e.target.features[e.target.selectedIndex].attributes.OBJECTID;
                    self.selectedFeaturePoint.openPopup = true;
                    self.initInfoWindowChart(e.target);
                } else {
                    self.selectedFeaturePoint.openPopup = false;
                    self.selectedFeaturePoint.objectId = null;
                }
            });

            this._esriMap.on('click', function (e) {
                self.selectedFeaturePoint.eventPoint = e.mapPoint;
            });

            this.url = "/athoc-iws/maplayers/GetEvents";

            if (options && options.url) {
                this.url = options.url;
            }
            self.getData();
        },

        getData: function () {
            var self = this;
            var geoJsonDeferred = request({
                url: this.url,
                handleAs: "json",
                preventCache: true
            });
				 
            geoJsonDeferred.then(function (response) {
                //console.log("Success: ", response);
                self.clear();
                self.init(response);
                self.refreshLayer();
            }, function (error) {
                //console.log("Error: ", error);
            });
				
        },
        //@TODO: move this to Layer Manager to have centralize control over all layers from one location
        refreshLayer: function () {
            var self = this;
            if (self.options.autoRefreshLayer) {
                setTimeout(function () {
                    //console.log("Refreshing Layer: " + self.options.LayerName + " .. " + Date.now());
                    self.getData();
                }, self.options.autoRefreshInterval ? self.options.autoRefreshInterval : 1 * 60 * 1000);
            }
        },

        init: function (geoJson) {
            var self = this;
            this.enabled(true);
            if (this._abortInit) {
                this.emit("layerLoaded", { graphics: null });
                return;
            }
            if (!geoJson || !geoJson.features || geoJson.features.length === 0) {
                this.emit("layerLoaded", { graphics: null });			   
                return;
            }
            var graphic, selectedGraphic,
                features = geoJson.features,
                symbol, graphicCount = [];
            
            array.forEach(features, function (item) {
                if (item.geometry.type.toLowerCase() === "point") {
                    //if (item.properties && item.properties.symbol) {
                    //symbol = new PictureMarkerSymbol(lang.isString(item.properties.symbol) ? dojoJson.fromJson(item.properties.symbol) : item.properties.symbol);
                    //} else {
                    //always use one symbol to represent the incoming alert point. If using image from database with ID, crossing server doesn't work
                    symbol = new PictureMarkerSymbol("/athoc-cdn/images/icon-alert-incoming.png", 32, 39);
                    symbol.setOffset(-3, 20);
                    //}
                }
                else if (item.geometry.type.toLowerCase() === "polygon") {
                    symbol = new SimpleFillSymbol(SimpleFillSymbol.STYLE_SOLID,
                        new SimpleLineSymbol(SimpleLineSymbol.STYLE_DASH,
                            Color.fromHex(self.options.BorderColor), 2), Color.fromString(self.options.FillColor));
                }
                graphic = util.convertGeoJsonFeatureToGraphic(item, { symbol: symbol });
                this._esriGraphicsLayer.add(graphic);
                if (this.selectedFeaturePoint.objectId == item.properties.OBJECTID) {
                    selectedGraphic = graphic;
                }
                if (graphicCount.indexOf(item.properties.eventId) == -1) {
                    graphicCount.push(item.properties.eventId);
                }
            }, this);
            this.graphics = this._esriGraphicsLayer.graphics;
            this.emit("layerLoaded", { graphics: this.graphics });
            this.enabled(true);
            this.setVisibility(true);
            this.options.count(graphicCount.length);
            if (this.selectedFeaturePoint.openPopup) {
                this._esriMap.infoWindow.hide();
                this._esriMap.onClick({
                    graphic: selectedGraphic,
                    mapPoint: this.selectedFeaturePoint.eventPoint,
                    screenPoint: this.selectedFeaturePoint.eventPoint
                });
            }

        },

        setVisibility: function (visibility) {
            if (!visibility) {
                this._esriMap.infoWindow.hide();
            }
            if (this._esriGraphicsLayer) {
                visibility ? this._esriGraphicsLayer.show() : this._esriGraphicsLayer.hide();
            }
        },

        clear: function () {
            //console.log("Clearing layer");
            this._esriGraphicsLayer.clear();
            this.graphics = [];
        },

        toGeoJson: function () {
            if (!this.graphics || this.graphics.length === 0) {
                return { type: "FeatureCollection", features: [] };
            }
            //for incoming alert point, it has to remember the symbol
            var features = [], feature;
            array.forEach(this.graphics, function (item) {
                feature = util.convertGraphicToGeoJsonFeature(item);
                if (feature.geometry.type.toLowerCase() === "point") {
                    if (!feature.properties) {
                        feature.properties = {};
                    }
                    feature.properties.symbol = item.symbol.toJson();
                }
            });
            var geoJson = { features: features };
            return geoJson;
        },

        restore: function (geoJson) {
            this._abortInit = true;
            this.clear();
            if (!geoJson || !geoJson.features || geoJson.features.length === 0) {
                //console.log("failed initializing country boundary layer");
                return;
            }
            var graphic, symbol;
            array.forEach(geoJson.features, function (item) {
                symbol = new SimpleMarkerSymbol();
                //symbol object in feature property is esri symbol json
                if (item.properties && item.properties.symbol) {
                    switch (item.properties.symbol.type) {
                    case "esriPMS":
                        symbol = new PictureMarkerSymbol(item.properties.symbol);
                        break;
                    }
                }
                graphic = util.convertGeoJsonFeatureToGraphic(item, { symbol: symbol });
                this._esriGraphicsLayer.add(graphic);
            }, this);
            this.graphics = this._esriGraphicsLayer.graphics;
            if (this.graphics.length > 0) {
                this.enabled(true);
                this.setVisibility(true);
            }
        },

        zoomToLayer: function () {
            if (this._esriGraphicsLayer && this._esriGraphicsLayer.Extent) {
                this._esriMap.setExtent(this._esriGraphicsLayer.Extent, true);
                return;
            }
            var extent = esri.graphicsExtent(this.graphics);
            if (extent.xmax - extent.xmin < 1000 && extent.ymax - extent.ymin < 1000) {
                extent.xmax += 5000;
                extent.xmin -= 5000;
                extent.ymax += 5000;
                extent.ymin -= 5000;
            }
            extent = extent.expand(4);
            this._esriMap.setExtent(extent, true);
            this._esriGraphicsLayer.Extent = extent;

        },

        initInfoWindowChart: function (target) {
            var self = this;
            if (target == null || target.selectedIndex < 0) return;
            var feature = target.features[target.selectedIndex];
            var attributes = feature.attributes;
            var status = attributes.eventResponses;
            var userResponses = [];

            for (var i = 0, len = status.StatusByResponse.length; i < len; i++) {
                userResponses.push({
                    "Name": status.StatusByResponse[i]['StatusAttribute']['ValueName'],
                    "Count": status.StatusByResponse[i]['Responses']
                });
            }
            userResponses.push({
                "Name": self.i18n.Map_Acct_Events_No_Status,
                "Count": attributes.usersNotResponded
            });

            var chartElement = $('.map-pop-label .chart');
            chartElement.kendoChart({
                chartArea: {
                    width: 50,
                    height: 50,
                    background: "",
                },
                theme: "flat",
                series: [
                    {
                        type: "donut",
                        startAngle: 270,
                        holeSize: 18,
                        data: [
                            {
                                category: self.i18n.Map_Acct_Events_Users_Have_Status,
                                value: attributes.usersResponded,
                                color: "#00cc03"
                            },
                            {
                                category: self.i18n.Map_Acct_Events_Users_Not_Have_Status,
                                value: attributes.usersNotResponded,
                                color: "#eeeeee"
                            }
                        ]
                    }
                ],
                legend: {
                    visible: false
                },
                tooltip: {
                    visible: true,
                    template: "#: category  #: #: value #"
                },
            });
            chartElement.append(
                $('<div>').addClass("inner-content").html(kendo.format("{0:n0}%", attributes.usersAffected > 0 ? (attributes.usersResponded / attributes.usersAffected) * 100 : 0)).css({ 'top': '35%' })
            );
            var ds = new kendo.data.HierarchicalDataSource({
                data: [
                  {
                      "Name": self.i18n.Map_Acct_Events_Status_Breakdown, "Count": "",
                      items: userResponses
                  }]
            });
            $('.user-response-tree-view').kendoTreeView({
                animation: false,
                dataSource: ds,
                template: kendo.template($("#treeview-template").html())
            });

        },

});
    return AcctEventsLayer;
});