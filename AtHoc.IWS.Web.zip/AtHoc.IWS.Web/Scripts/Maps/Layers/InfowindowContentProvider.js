﻿define([
    "dojo/_base/declare",
    "dojo/_base/array",
], function(declare, array) {
    var infoContent = declare("athoc.layer.infowindowcontent", [], {
        activeInfowindowPoint: {
            active: false,
            selectedIndex: null,
            objectId: null,
            layerType: null,
            eventPoint: '',
        },
        constructor: function (options) {
            var self = this;
            this._esriMap = options.coreMap;
            this.i18n = options.i18n;
            this._esriMap.infoWindow.on("selection-change", function (e) {
                var target = e.target;
                if (target.selectedIndex > -1) {
                    self._createInfoWindowChart(target);
                }
            });
        },

        getContent: function(options) {
            var self = this;

            this.options = options;
            this.graphic = this.options.graphic;
            this.graphicType = this.graphic.attributes.layerType;
            
            var graphic = this.graphic;
            var data = {
                i18n: self.i18n
            };

            var template = kendo.template($("#" + options.templateId).html());
            data.graphic = self._getGraphicAttributes(graphic);

            return template(data);
        },

        _getGraphicAttributes: function (graphic) {
            var self = this;
            var attributes = graphic.attributes;
            var isEvent = attributes.layerType && this.includes(attributes.layerType, 'event');
            var userResponses = [];

            if (isEvent) {
                
                attributes.i18n = {
                    entityName: attributes.organizationName ? this.i18n.Map_Layer_Sub_Vps_Acct_Event_Entity : this.i18n.Map_Layer_Acct_Event_Entity,
                    summeryBtnText: self.i18n.Map_Acct_Events_Open_Event,
                    userAffected: self.i18n.Map_Acct_Events_Users_Affected,
                    userHaveStatus: self.i18n.Map_Acct_Events_Users_Have_Status,
                    userHaveNoStatus: self.i18n.Map_Acct_Events_Users_Not_Have_Status,
                    UserResponseTreeviewText: self.i18n.Map_Acct_Events_Status_Breakdown,
                }
                attributes.priority += ' pa-sub-icon';
                attributes.summeryUrl = athoc.iws.account.urls.EventDetails;

            }

            if (attributes.layerType && this.includes(attributes.layerType, 'alert')) {
                
                attributes.i18n = {
                    entityName: self.i18n.Map_Layer_Alert_Entity,
                    summeryBtnText: self.i18n.Map_Alerts_Open_Alert,
                    userAffected: self.i18n.Map_Alerts_Users_Targeted,
                    userHaveStatus: self.i18n.Map_Alerts_Users_Responded,
                    userHaveNoStatus: self.i18n.Map_Alerts_Users_Not_Responded,
                    UserResponseTreeviewText: self.i18n.Map_Alerts_Response_Breakdown,
                }
                attributes.summeryUrl = athoc.iws.account.urls.AlertsDetail;
                attributes.usersNotResponded = attributes.usersAffected - attributes.usersResponded;
            }
            
            if (attributes.responses !== undefined) {
                if (attributes.responses == null) {
                    userResponses.push({
                        "Name": attributes.i18n.userHaveStatus,
                        "Count": attributes.usersResponded
                    });
                    userResponses.push({
                        "Name": attributes.i18n.userHaveNoStatus,
                        "Count": attributes.usersNotResponded
                    });
                } else {
                    for (var i = 0, len = attributes.responses.length; i < len; i++) {
                        userResponses.push({
                            "Name": attributes.responses[i]["Response"],
                            "Count": attributes.responses[i]['Number']
                        });
                    }
                    userResponses.push({
                        "Name": (isEvent ? self.i18n.Map_Acct_Events_No_Status : self.i18n.Map_Alerts_No_Status),
                        "Count": attributes.usersNotResponded
                    });
                }

                attributes.userResponses = userResponses;
            }
            return attributes;
        },

        _createInfoWindowChart: function (target) {
            var self = this;
            if (target == null || target.selectedIndex < 0) return;
            var feature = target.features[target.selectedIndex];
            var attributes = feature.attributes;
            var i18n = attributes.i18n;
            if (attributes.userResponses == undefined) { return; }
            var chartElement = $('.map-pop-label .chart');
            chartElement.kendoChart({
                chartArea: {
                    width: 50,
                    height: 50,
                    background: "",
                },
                theme: "flat",
                series: [
                    {
                        type: "donut",
                        startAngle: 270,
                        holeSize: 18,
                        data: [
                            {
                                category: i18n.userHaveStatus,
                                value: attributes.usersResponded,
                                color: "#00cc03"
                            },
                            {
                                category: i18n.userHaveNoStatus,
                                value: attributes.usersNotResponded,
                                color: "#eeeeee"
                            }
                        ]
                    }
                ],
                legend: {
                    visible: false
                },
                tooltip: {
                    visible: true,
                    template: "#: category  #: #: value #"
                },
            });
            chartElement.append(
                $('<div>').addClass("popup-inner-content").html(kendo.format("{0:n0}%", attributes.usersAffected > 0 ? (attributes.usersResponded / attributes.usersAffected) * 100 : 0)).css({ 'top': '35%' })
            );
            var ds = new kendo.data.HierarchicalDataSource({
                data: [
                  {
                      "Name": i18n.UserResponseTreeviewText, "Count": "",
                      items: attributes.userResponses
                  }]
            });

            $('.user-response-tree-view').kendoTreeView({
                animation: false,
                dataSource: ds,
                template: kendo.template($("#response-treeview-template").html())
            });

        },

        includes: function (container, value) {
            var returnValue = false;
            var pos = container.indexOf(value);
            if (pos >= 0) {
                returnValue = true;
            }
            return returnValue;
        }
        

    });

    return infoContent;
})