﻿define([
"dojo/_base/declare", "esri/layers/GraphicsLayer", "dojo/_base/lang", "esri/request", "dojo/Evented", "dojo/_base/array", "esri/layers/LabelLayer",
"esri/symbols/SimpleMarkerSymbol", "esri/symbols/PictureMarkerSymbol", "esri/Color", "esri/renderers/SimpleRenderer", "maps/util",
"dojo/dom-style", "esri/InfoTemplate"
],
function (declare, GraphicsLayer, lang, request, Evented, array, LabelLayer,
    SimpleMarkerSymbol, PictureMarkerSymbol, Color, SimpleRenderer, util,
    domStyle, InfoTemplate) {
    var OrgLayer = declare("athoc.layer.OrgLayer", [Evented], {
        name: "",
        visible: ko.observable(false),
        graphics: [],
        loaded: false,
        aborted: false,
        enabled: ko.observable(false),
        order: -1,
        constructor: function (options) {
            this.visible.subscribe(lang.hitch(this, "setVisibility"));
            this.options = options.layer;
            this.order = options.order;
            var infoTemplate = new InfoTemplate();
            infoTemplate.setTitle("${name}");
            var content = function (orgId) {
                var divId = 'organizationContainer' + orgId;
                var emptyContent = '<div id="' + divId + '"><img src="/athoc-cdn/images/ajax-loader.gif"/></div>';
                return emptyContent;
            };
            infoTemplate.setContent(content("${orgId}"));
            this._esriMap = options.coreMap;
            this._esriMap.infoWindow.resize(400, 300);
            this._esriGraphicsLayer = new GraphicsLayer({ infoTemplate: infoTemplate, id: "OrgLayer" });
            this._esriMap.addLayer(this._esriGraphicsLayer, 1);
            this._esriGraphicsLayer.on("mouse-over", function (e) {
                $(e.target).css("cursor", "pointer");

            });
            this._esriGraphicsLayer.on("mouse-out", function (e) {
                $(e.target).css("cursor", "default");
            });

            this.url = "/athoc-iws/maplayers/GetOrganizations";
            if (options && options.url) {
                this.url = options.url;
            }
            var geoJsonDeferred = request({
                url: this.url,
                handleAs: "json",
                preventCache: true
            });
            geoJsonDeferred.then(lang.hitch(this, "init"), function (err) {
                //console.log("failed initializing organization layer");
            });

            this._esriMap.infoWindow.on("selection-change", function (graphic) {
                if (graphic.target.selectedIndex > -1 && graphic.target.features[graphic.target.selectedIndex].attributes.orgId) {
                    var orgId = graphic.target.features[graphic.target.selectedIndex].attributes.orgId;
                    contentSetResponse(orgId);
                }
            });

            this._esriMap.infoWindow.on("click", function (graphic) {
                var orgId = graphic.graphic.attributes.orgId;
                contentSetResponse(orgId);
            });
            var contentSetResponse = function (orgId) {
                var divId = 'organizationContainer' + orgId;
                $.when($.ajax({
                    type: "GET",
                    cache:false,
                    url: "/athoc-iws/maplayers/GetOrganization?orgId=" + orgId,
                    dataType: "json"
                }).then(function (response) {
                    var responsedata = '<div id="findMeIfYouCan" class="width220 overflow-hidden">' +
                        '<span class="map-pop-label"><img class="infoWindowImg" src="/athoc-iws/Organization/Logo?id=' + orgId + '&version=1"></span>' +
                        '<span class="map-pop-value bold font-size14">' + response.description + '</span></div>' +
                        '<span class="mar-left50 width220 block overflow-hidden mar-top5 mar-bot5"><span class="map-pop-label">Sector: </span><span class="map-pop-value">' + response.sector + '</span></span>' +
                        '<span class="mar-left50 width220 block overflow-hidden mar-bot5"><span class="map-pop-label">Contact: </span><span class="map-pop-value">' + response.contact + '</span></span>' +
                        '<span class="mar-left50 width220 block overflow-hidden mar-bot5"><span class="map-pop-label">Phone: </span><span class="map-pop-value">' + response.phone + '</span></span>' +
                        '<span class="mar-left50 width220 block overflow-hidden mar-bot5"><span class="map-pop-label">Address: </span><span class="map-pop-value">' + response.address + '</span></span>' +
                        '<span class="mar-left50 width220 block overflow-hidden mar-bot5"><span class="map-pop-label">Website: </span><span class="map-pop-value"><a href=' + response.url + ' target="_blank">' + response.url + '</a></span></span>';

                    setTimeout(function () { $("#" + divId).html(responsedata); }, 500);

                }));
            };
        },

        init: function (geoJson) {
            this.enabled(true);
            if (!geoJson || !geoJson.features || geoJson.features.length === 0) {
                //console.log("failed initializing organization layer");
                this.aborted = true;
                this.emit("abort", {});
                return;
            }
            var graphic,
                features = geoJson.features,
                symbol = new PictureMarkerSymbol("/athoc-cdn/images/icon-org-pin.png", 33, 50);
            symbol.setOffset(0, 21);

            array.forEach(features, function (item) {
                graphic = util.convertGeoJsonFeatureToGraphic(item, { symbol: symbol });
                this._esriGraphicsLayer.add(graphic);
            }, this);
            this.graphics = this._esriGraphicsLayer.graphics;
            this.enabled(true);
            this.setVisibility(true);
            this.options.count(features.length);
            this.loaded = true;
            this.aborted = false;
            this.emit("load", {});
        },

        setVisibility: function (visibility) {
            if (!visibility) {
                this._esriMap.infoWindow.hide();
            }
            if (this._esriGraphicsLayer) {
                visibility ? this._esriGraphicsLayer.show() : this._esriGraphicsLayer.hide();
            }
        },

        zoomToLayer: function () {
            if (this._esriGraphicsLayer && this._esriGraphicsLayer.Extent) {
                this._esriMap.setExtent(this._esriGraphicsLayer.Extent.expand(4), true);
                return;
            }
        },
    });
    return OrgLayer;
});