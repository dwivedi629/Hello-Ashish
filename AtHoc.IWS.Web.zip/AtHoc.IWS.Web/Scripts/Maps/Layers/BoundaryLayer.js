﻿define([
"dojo/_base/declare", "esri/layers/GraphicsLayer", "dojo/_base/lang", "esri/request", "dojo/Evented", "dojo/_base/array", "esri/layers/LabelLayer",
"esri/symbols/SimpleFillSymbol", "esri/symbols/SimpleLineSymbol", "esri/Color", "esri/renderers/SimpleRenderer", "maps/util"
],
function (declare, GraphicsLayer, lang, request, Evented, array, LabelLayer,
    SimpleFillSymbol, SimpleLineSymbol, Color, SimpleRenderer, util) {
    var BoundaryLayer = declare("athoc.layer.BoundaryLayer", [Evented], {
        name: "County Boundary",
        visible: ko.observable(false),
        graphics: [],
        enabled: ko.observable(false),
        constructor: function (options) {
            this.visible.subscribe(lang.hitch(this, "setVisibility"));
            this.options = options;
            this._esriMap = options.coreMap;
            this._esriGraphicsLayer = new GraphicsLayer();
            this._esriMap.addLayer(this._esriGraphicsLayer, 1);

            this.url = "/athoc-iws/maplayers/GetCountyBoundary";
            if (options && options.url) {
                this.url = options.url;
            }
            var geoJsonDeferred = request({
                url: this.url,
                handleAs: "json"
            });
            geoJsonDeferred.then(lang.hitch(this, "init"), function (err) {
                console.log("failed initializing country boundary layer");
            });
        },

        init: function (geoJson) {
            if (!geoJson || !geoJson.features || geoJson.features.length === 0) {
                console.log("failed initializing country boundary layer");
                return;
            }
            var graphic, symbol = new SimpleFillSymbol(SimpleFillSymbol.STYLE_NULL,
  new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID,
  new Color("red"), 2), new Color([255, 255, 0, 0.25]));
            array.forEach(geoJson.features, function (item) {
                graphic = util.convertGeoJsonFeatureToGraphic(item, { symbol: symbol });
                this._esriGraphicsLayer.add(graphic);
            }, this);
            this.graphics = this._esriGraphicsLayer.graphics;
            if (this.graphics.length > 0) {
                this.enabled(true);
                this.visible(true);
            }
        },

        setVisibility: function () {
            this._esriGraphicsLayer.setVisibility(this.visible());
        }
    });
    return BoundaryLayer;
});