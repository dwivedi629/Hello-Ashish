﻿define([
"dojo/_base/declare", "esri/layers/GraphicsLayer", "dojo/_base/lang", "esri/request", "dojo/Evented", "dojo/_base/array", "esri/layers/LabelLayer", "esri/symbols/SimpleFillSymbol", "esri/symbols/SimpleLineSymbol",
"esri/symbols/SimpleMarkerSymbol", "esri/symbols/PictureMarkerSymbol", "esri/Color", "esri/renderers/SimpleRenderer", "maps/util", "dojo/_base/json", "esri/InfoTemplate", "esri/geometry/Extent"
],
function (declare, GraphicsLayer, lang, request, Evented, array,
    LabelLayer, SimpleFillSymbol, SimpleLineSymbol,
    SimpleMarkerSymbol, PictureMarkerSymbol, Color, SimpleRenderer,
    util, dojoJson, InfoTemplate, Extent) {
    var layer = declare("athoc.layer.baselayer", [Evented], {
        name: "",
        visible: ko.observable(false),
        graphics: [],
        enabled: ko.observable(false),
        order:  -1,
        constructor: function(options) {
            var self = this;
            this._esriMap = options.coreMap;
            this.i18n = options.i18n;
            this.order = options.order;

            this.options = options.layer || {};
            this._abortInit = false;
            this.graphics = [];
            this.timeLastUpdated = ko.observable();
            this.visible.subscribe(lang.hitch(this, "setVisibility"));

            if (options && options.layer.url) {
                this.url = options.layer.url;
            } else {
                console.log("No Layer URL Defined : " + this.options.id);
                return;
            }

            this.urlContent = options.layer.urlContent;
            
            var infoTemplate = new InfoTemplate();
            infoTemplate.setTitle("${name}");
            infoTemplate.setContent(function(graphic) {
                
                return options.infowindowProvider.getContent({
                    layerId: self.options.id,
                    templateId: self.options.templateId,
                    graphic: graphic
                });
                
            });

            this._esriGraphicsLayer = new GraphicsLayer({ infoTemplate: infoTemplate, id: this.options.id });
            this._esriMap.addLayer(this._esriGraphicsLayer, 2);

            this._esriGraphicsLayer.on("mouse-over", function(e) {
                $(e.target).css("cursor", "pointer");

            });
            this._esriGraphicsLayer.on("mouse-out", function(e) {
                $(e.target).css("cursor", "default");
            });
            this.selectedFeatures = null;
            this.selectedFeaturePoint = {
                eventPoint: '',
                selectedIndex: null,
                objectId: null,
                openPopup: false,
                layerType: null
            };

            this._esriMap.infoWindow.resize(400, 300);

            this._esriMap.infoWindow.on("selection-change", function (e) {
                var target = e.target;
                var features = target.features;
                if (target.selectedIndex > -1) {
                    self.selectedFeaturePoint = {
                        eventPoint: self.selectedFeaturePoint.eventPoint,
                        selectedIndex: target.selectedIndex,
                        objectId: features[target.selectedIndex].attributes.OBJECTID,
                        openPopup: true,
                        layerType: features[target.selectedIndex].attributes.layerType
                    };
                }
            });

            this._esriMap.infoWindow.on("hide", function (e) {
                self.selectedFeaturePoint = {
                    eventPoint: '',
                    selectedIndex: null,
                    openPopup: false,
                    layerType: null
                };
            });

            this._esriMap.on('click', function (e) {
                self.selectedFeaturePoint.eventPoint = e.mapPoint;
            });

        },

        init: function () {
            var self = this;
            var geoJsonDeferred = request({
                url: this.url,
                handleAs: "json",
                preventCache: true,
                content: self.urlContent
            });
            
            geoJsonDeferred.then(function (response) {
                //console.log("Success: ", response);
                self.clear();
                self.updatedOn = moment(new Date()).zone(-1 * $.vpsTimeZone.UtcOffsetInMinutes -$.vpsTimeZone.dstDelta).format($.getMomentDateTimeFormat(($.vpsDateTimeFormat)));
                self.dataToLayer(response);
                self.timeLastUpdated(self.updatedOn);
            }, function (error) {
                //console.log("Error: ", error);
            });
				
        },

        refresh: function () {
            this.init();
        },

        dataToLayer: function (geoJson) {
            var self = this;
            this.enabled(true);
            if (this._abortInit) {
                this.emit("layerLoaded", { graphics: null });
                return;
            }
            if (!geoJson || !geoJson.features || geoJson.features.length === 0) {
                this.emit("layerLoaded", { graphics: null });
                this.options.count(0);
                return;
            }
            var graphic, selectedGraphic,
                features = geoJson.features,
                symbol, graphicCount = [];
            
            array.forEach(features, function (item) {
                if (self.options.id == "OrgLayer") {
                    symbol = new PictureMarkerSymbol("/athoc-cdn/images/icon-org-pin.png", 33, 50);
                    symbol.setOffset(0, 21);
                }
                else if (item.geometry.type.toLowerCase() === "point") {
                    symbol = new PictureMarkerSymbol("/athoc-cdn/images/icon-alert-incoming.png", 32, 39);
                    symbol.setOffset(-3, 20);
                    var latlng = item.geometry.coordinates;
                    item.properties.latLng = latlng[1].toFixed(4) +" , "+ latlng[0].toFixed(4);
                }
                else if (item.geometry.type.toLowerCase() === "polygon") {
                    symbol = new SimpleFillSymbol(SimpleFillSymbol.STYLE_SOLID,
                        new SimpleLineSymbol(SimpleLineSymbol.STYLE_DASH,
                            Color.fromHex(self.options.BorderColor), 2), Color.fromString(self.options.FillColor));
                }
                item.properties.updatedOn = self.updatedOn;
                graphic = util.convertGeoJsonFeatureToGraphic(item, { symbol: symbol });
                self._esriGraphicsLayer.add(graphic);
                
                if (graphicCount.indexOf(item.properties.id) == -1) {
                    graphicCount.push(item.properties.id);
                }

                if (this.selectedFeaturePoint.objectId == item.properties.OBJECTID) {
                    selectedGraphic = graphic;
                }
                if (this.selectedFeatures) {
                    var selectedLayers = this.selectedFeatures._layer;

                    for (var i = 0; i < selectedLayers.graphics.length, i++;) {
                        var attr = selectedLayers.attributes;
                        if (attr.LayerType == item.properties.LayerType &&
                            attr.OBJECTID == item.properties.OBJECTID) {
                            this._esriMap.infoWindow.setFeatures([item]);
                        }
                    }
                }
            }, this);
            this.graphics = this._esriGraphicsLayer.graphics;
            this.emit("layerLoaded", { graphics: this.graphics });
            this.enabled(true);
            this.options.count(graphicCount.length);

            if (this.selectedFeaturePoint.openPopup && this.selectedFeaturePoint.eventPoint != "") {
                this._esriMap.emit("click", {
                    bubbles: true,
                    cancelable: true,
                    mapPoint: this.selectedFeaturePoint.eventPoint,
                    screenPoint: this._esriMap.toScreen(this.selectedFeaturePoint.eventPoint)
                });
            }
        },

        setVisibility: function (visibility) {
            if (!visibility) {
                this._esriMap.infoWindow.hide();
            }
            if (this._esriGraphicsLayer) {
                visibility ? this._esriGraphicsLayer.show() : this._esriGraphicsLayer.hide();
            }
        },

        clear: function () {
            //console.log("Clearing layer");
            this._esriGraphicsLayer.clear();
            this.graphics = [];
        },

        toGeoJson: function () {
            if (!this.graphics || this.graphics.length === 0) {
                return { type: "FeatureCollection", features: [] };
            }
            //for incoming alert point, it has to remember the symbol
            var features = [], feature;
            array.forEach(this.graphics, function (item) {
                feature = util.convertGraphicToGeoJsonFeature(item);
                if (feature.geometry.type.toLowerCase() === "point") {
                    if (!feature.properties) {
                        feature.properties = {};
                    }
                    feature.properties.symbol = item.symbol.toJson();
                }
            });
            var geoJson = { features: features };
            return geoJson;
        },

        restore: function (geoJson) {
            this._abortInit = true;
            this.clear();
            if (!geoJson || !geoJson.features || geoJson.features.length === 0) {
                //console.log("failed initializing country boundary layer");
                return;
            }
            var graphic, symbol;
            array.forEach(geoJson.features, function (item) {
                symbol = new SimpleMarkerSymbol();
                //symbol object in feature property is esri symbol json
                if (item.properties && item.properties.symbol) {
                    switch (item.properties.symbol.type) {
                        case "esriPMS":
                            symbol = new PictureMarkerSymbol(item.properties.symbol);
                            break;
                    }
                }
                graphic = util.convertGeoJsonFeatureToGraphic(item, { symbol: symbol });
                self._esriGraphicsLayer.add(graphic);
            }, this);
            this.graphics = this._esriGraphicsLayer.graphics;
            if (this.graphics.length > 0) {
                this.enabled(true);
                this.setVisibility(true);
            }
        },

        zoomToLayer: function () {
            if (this._esriGraphicsLayer && this._esriGraphicsLayer.Extent) {
                this._esriMap.setExtent(this._esriGraphicsLayer.Extent, true);
                return;
            }
            var extent = esri.graphicsExtent(this.graphics);
            if (extent.xmax - extent.xmin < 1000 && extent.ymax - extent.ymin < 1000) {
                extent.xmax += 5000;
                extent.xmin -= 5000;
                extent.ymax += 5000;
                extent.ymin -= 5000;
            }
            extent = extent.expand(4);
            this._esriMap.setExtent(extent, true);
            this._esriGraphicsLayer.Extent = extent;

        },

    });

    return layer;
});