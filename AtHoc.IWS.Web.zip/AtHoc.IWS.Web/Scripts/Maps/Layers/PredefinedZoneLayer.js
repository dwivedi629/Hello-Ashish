﻿define([
"dojo/_base/declare", "esri/layers/FeatureLayer", "dojo/_base/lang", "esri/request", "dojo/Evented", "dojo/_base/array", "esri/layers/LabelLayer",
"esri/symbols/SimpleFillSymbol", "esri/symbols/SimpleLineSymbol", "esri/symbols/TextSymbol", "esri/Color", "esri/renderers/SimpleRenderer", "maps/util", "dojo/_base/json",
"esri/symbols/Font", "esri/geometry/Extent"
],
function (declare, FeatureLayer, lang, request, Evented, array, LabelLayer,
    SimpleFillSymbol, SimpleLineSymbol, TextSymbol, Color, SimpleRenderer, util, dojoJson,
    Font,Extent) {
    var fc = {
        "layerDefinition": {
            "currentVersion": 10.21,
            "id": 3,
            "name": "states",
            "type": "Feature Layer",
            "description": "Predefined zones for geotargeting selection\n",
            "geometryType": "esriGeometryPolygon",
            "copyrightText": "",
            "parentLayer": null,
            "subLayers": [],
            "minScale": 0,
            "maxScale": 0,
            "drawingInfo": {
                "renderer": {
                    "type": "simple",
                    "symbol": {
                        "type": "esriSFS",
                        "style": "esriSFSSolid",
                        "color": [0, 0, 0, 0],
                        "outline": {
                            "type": "esriSLS",
                            "style": "esriSLSSolid",
                            "color": [0, 0, 0, 255],
                            "width": 2
                        }
                    },
                    "label": "",
                    "description": ""
                },
                "transparency": 0,
                "labelingInfo": null
            },
            "defaultVisibility": true,
            "extent": {
                "xmin": -178.21759836267427,
                "ymin": 18.9217863446641,
                "xmax": -66.96927103622932,
                "ymax": 71.40623536706858,
                "spatialReference": {
                    "wkid": 4269,
                    "latestWkid": 4269
                }
            },
            "hasAttachments": false,
            "htmlPopupType": "esriServerHTMLPopupTypeNone",
            "displayField": "NAME",
            "typeIdField": null,
            "fields": [{
                "name": "OBJECTID",
                "type": "esriFieldTypeOID",
                "alias": "OBJECTID",
                "domain": null
            }, {
                "name": "Shape",
                "type": "esriFieldTypeGeometry",
                "alias": "Shape",
                "domain": null
            }, {
                "name": "NAME",
                "type": "esriFieldTypeString",
                "alias": "NAME",
                "length": 25,
                "domain": null
            }],
            "relationships": [],
            "canModifyLayer": true,
            "canScaleSymbols": false,
            "hasLabels": false,
            "capabilities": "Data,Map,Query",
            "maxRecordCount": 1000,
            "supportsStatistics": true,
            "supportsAdvancedQueries": true,
            "supportedQueryFormats": "JSON, AMF",
            "ownershipBasedAccessControlForFeatures": {
                "allowOthersToQuery": true
            },
            "useStandardizedQueries": true
        },
        "featureSet": {
            "geometryType": "esriGeometryPolygon",
            "features": []
        }
    };
    var PredefindZoneLayer = declare("athoc.layer.PredefindZoneLayer", [Evented], {
        options: { map: null },
        name: "",
        visible: ko.observable(false),
        graphics: [],
        enabled: ko.observable(false),
        layerId: -1,
        fillColor: "#ff0000",
        constructor: function (options) {
            this.visible.subscribe(lang.hitch(this, "setVisibility"));
            this.options = options;
            this.coreMap = options.coreMap;
            this.layerId = options.layerId;
            this.isDisplay = options.isDisplay ?  true:false;
            this.abort = options.abort ? true : false;
            this.fillColor = options.fillColor;
            this._zoneFeatureLayer = new FeatureLayer(fc);
	        if (this.isDisplay) {
		        this._zoneFeatureLayer.id = "Layer_" + this.layerId + "_display";
	        } else {
		        this._zoneFeatureLayer.id = "Layer_" + this.layerId;
	        }
	        this.coreMap.addLayer(this._zoneFeatureLayer, options.order);
	        var labelColor = Color.fromHex("#000000");
	        var labelHaloColor = Color.fromHex("#ffffff");
			if (this.isDarkColor(this.fillColor)) {
				labelColor = Color.fromHex("#ffffff");
			    labelHaloColor = Color.fromHex("#000000");
			}
			if (this.isDisplay) {
				labelColor= Color.fromHex(this.fillColor);
			}
            var labelSymbol = new TextSymbol().setColor(labelColor);
			
            labelSymbol.font.setSize("9pt");
            labelSymbol.font.setFamily("Arial");
            labelSymbol.font.setWeight(Font.WEIGHT_BOLD);
            labelSymbol.setHaloColor(labelHaloColor);
            labelSymbol.setHaloSize(2);
            var labelRenderer = new SimpleRenderer(labelSymbol);

            this._labelLayer = new LabelLayer();
            if (this.isDisplay) {
	            this._labelLayer.id = "labels_" + this.layerId + "_display";
            } else {
            	this._labelLayer.id = "labels_" + this.layerId ;
            }
            this.coreMap.addLayer(this._labelLayer, options.order + 1);
            this.labelField = "NAME";
            this._labelLayer.addFeatureLayer(this._zoneFeatureLayer, labelRenderer, "{" + this.labelField + "}");

            $.AjaxLoader.setup({ useBlock: true, idToShow: null, elementToBlock: $('.mapHolder'), imageURL: '/athoc-cdn/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000 }).showLoader();
            this.showLoader();
            var featureCollectionDeferred = request({
                url: "/athoc-iws/maplayers/GetShapeLayerDataById",
                content: { layerId: this.layerId },
                handleAs: "text"
            });
            featureCollectionDeferred.then(lang.hitch(this, "init"), lang.hitch(this, function (error) {
                this.hideLoader();
                this.emit("layerLoaded", { graphics: null });
                AjaxUtility().dojoRequestHandler(error);
            }));

        },
        
        showLoader:function() {
            $.AjaxLoader.showLoader();

        },
		
        hideLoader:function() {
            $.AjaxLoader.hideLoader();
        },
		

        isDarkColor: function (color) {
        	//http://stackoverflow.com/questions/12043187/how-to-check-if-hex-color-is-too-black	
			var c = color.substring(1);      // strip #
			var rgb = parseInt(c, 16);   // convert rrggbb to decimal
			var r = (rgb >> 16) & 0xff;  // extract red
			var g = (rgb >> 8) & 0xff;  // extract green
			var b = (rgb >> 0) & 0xff;  // extract blue

			var luma = 0.2126 * r + 0.7152 * g + 0.0722 * b; // per ITU-R BT.709
			return luma < 60;

		},

        init: function (geoJsonStr) {
            try {
                var geoJson = dojoJson.fromJson(geoJsonStr);
                if (!geoJson.Success || !geoJson.Data) {
                    this.emit("layerLoaded", { graphics: null });
                    return;
                }
                geoJson = geoJson.Data;
                if (!geoJson || !geoJson.features || geoJson.features.length === 0) {
                    this.emit("layerLoaded", { graphics: null });
                    return;
                }

                this._zoneFeatureLayer.clear();
                var fillcolor = Color.fromHex(this.fillColor);
	            fillcolor.a = 0.5;
                var bordercolor = Color.fromHex("#000000");
	            var symbolStyle = SimpleFillSymbol.STYLE_SOLID;
                var lineSymbolStyle = SimpleLineSymbol.STYLE_SOLID;
                if (this.isDisplay) {
                	lineSymbolStyle = SimpleLineSymbol.STYLE_DASH;
                	symbolStyle = SimpleFillSymbol.STYLE_SOLID;
                	bordercolor = Color.fromHex(this.fillColor);
		            fillcolor.a = 0.2;
                }

                var graphic,
                    symbol = new SimpleFillSymbol(symbolStyle,
                        new SimpleLineSymbol(lineSymbolStyle,
                            bordercolor, 1), fillcolor);
                array.forEach(geoJson.features, function(item) {
                    graphic = util.convertGeoJsonFeatureToGraphic(item, { symbol: symbol });
                    this._zoneFeatureLayer.add(graphic);
                }, this);
                this.graphics = this._zoneFeatureLayer.graphics;
				

                //label layer
                if (!this.isDisplay) {
                    var zoneSelectEvent = this._zoneFeatureLayer.on("mouse-down", lang.hitch(this, "select"));
                    var labelSelectEvent = this._labelLayer.on("mouse-down", lang.hitch(this, "selectByPointOnMap"));
                    this.coreMap.on("pan-start", function() {
                        zoneSelectEvent.remove();
                        labelSelectEvent.remove();
                    });
                    this.coreMap.on("pan-end", lang.hitch(this, function() {
                        zoneSelectEvent = this._zoneFeatureLayer.on("mouse-down", lang.hitch(this, "select"));
                        labelSelectEvent = this._labelLayer.on("click", lang.hitch(this, "selectByPointOnMap"));
                    }));
                    this._zoneFeatureLayer.on("mouse-over", lang.hitch(this, "highlightLabel"));
                    this._zoneFeatureLayer.on("mouse-out", lang.hitch(this, "deHighlightLabel"));
                    this._labelLayer.on("mouse-over", lang.hitch(this, "highlightLabel"));
                    this._labelLayer.on("mouse-out", lang.hitch(this, "deHighlightLabel"));   
                }

                if (this.graphics.length > 0) {
                    this.enabled(true);
                    this.setVisibility(true);
                }
                if (this.count) {
                    this.count(this.graphics.length);
                }
                this.emit("layerLoaded", { graphics: this.graphics });
            } catch (error) {
                console.log(error);
            } finally {
                this.hideLoader();
            }
        },

        deHighlightLabel: function (e) {
            $(e.target).css("cursor", "default");
        },

        highlightLabel: function(e) {
            $(e.target).css("cursor", "pointer");
        },

        removeLayer:function() {
            this.coreMap.removeLayer(this._zoneFeatureLayer);
            this.coreMap.removeLayer(this._labelLayer);
        },

        zoomToLayer: function () {
            if (this._zoneFeatureLayer && this._zoneFeatureLayer.Extent) {
                this.coreMap.setExtent(this._zoneFeatureLayer.Extent, true);
                return;
            }
            var unionExtent = new Extent(0,0,0,0,"{wkid:102100}");
            if (this._zoneFeatureLayer && this._zoneFeatureLayer.graphics && this._zoneFeatureLayer.graphics.length > 0) {
                var count = 0;
                array.forEach(this._zoneFeatureLayer.graphics, function (item) {
                    var extent = item.geometry.getExtent();
                    if (count === 0) {
                        unionExtent = extent;
                    }
                    unionExtent.union(extent);
                    count++;
                });
                unionExtent = unionExtent.expand(4);
                this._zoneFeatureLayer.Extent = unionExtent;
                this.coreMap.setExtent(unionExtent, true);
            }
        },

        selectByPointOnMap:function(e) {
            e.stopPropagation();
            var graphics = this._zoneFeatureLayer.graphics;
            array.forEach(graphics, function(item) {
                if (item.geometry.contains(e.graphic.geometry)) {
                    this.emit("selectComplete", {
                        graphic: item,
                        name: e.graphic.symbol.text
                    });
                    return;
                }
            }, this);

        },

        select: function (e) {
            e.stopPropagation();
            this.emit("selectComplete", {
                graphic: e.graphic,
                name: e.graphic.symbol.text
            });
       },

        setVisibility: function (visibility) {
            if (this._labelLayer) {
                visibility ? this._labelLayer.show():this._labelLayer.hide();
            }
            if (this._zoneFeatureLayer) {
                visibility ? this._zoneFeatureLayer.show() : this._zoneFeatureLayer.hide();
            }
            
        },

        setLabelColor: function () {
            if (!this._labelLayer || !this._labelLayer.graphics || this._labelLayer.graphics.length === 0) {
                return;
            }
            var graphics = this._labelLayer.graphics;
            array.forEach(graphics, function(item) {
                var svgText = item.getShape();
                if (svgText) {
                    //svgText only available when it's within the map extent
                    svgText.setStroke({ color: "black", width: 1 });
                }
            });
        }
    });
    return PredefindZoneLayer;
});