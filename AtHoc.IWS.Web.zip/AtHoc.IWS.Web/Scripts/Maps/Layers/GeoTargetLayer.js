﻿//essentially, it's a graphiclayer
//properties:
//1. extent
//2. geometries as wkt
//3. 
//methods:
//1. target
//events
//1. add, it requests to get the number of selected users/orgs
//2. remove
//3. change
//4. emit targetComplete
//final notes: geotargetlayer should contain two graphicslayers, 1 is selected graphics from other layers, 2 is user added graphics. 
//so that it will solve the graphic order issue and bring convenience as manipulating the pills and editable graphics and different logic

define(
["dojo/_base/declare", "esri/layers/GraphicsLayer", "dojo/_base/lang", "esri/request", "dojo/Evented", "dojo/_base/array", "esri/toolbars/edit", "dojo/_base/event",
"dojo/query", "dojo/dom-style", "dojo/keys", "dojo/on", "esri/graphic", "esri/symbols/SimpleFillSymbol", "esri/symbols/SimpleLineSymbol", "esri/Color", "maps/util", "dojo/_base/json",
"dojo/Deferred", "esri/symbols/PictureMarkerSymbol", "esri/renderers/SimpleRenderer", "esri/layers/LabelLayer", "esri/symbols/TextSymbol", "esri/symbols/Font", "esri/layers/LabelClass", "esri/layers/FeatureLayer","esri/geometry/Polygon"],
    function (declare, GraphicsLayer, lang, request, Evented, array, Edit, event, query, domStyle, keys, on, Graphic, SimpleFillSymbol, SimpleLineSymbol, Color, util, dojoJson,
        Deferred, PictureMarkerSymbol, SimpleRenderer, LabelLayer, TextSymbol, Font, LabelClass,FeatureLayer) {
        var fc = {
            "layerDefinition": {
                "currentVersion": 10.21,
                "id": 3,
                "name": "states",
                "type": "Feature Layer",
                "description": "Predefined zones for geotargeting selection\n",
                "geometryType": "esriGeometryPolygon",
                "copyrightText": "",
                "parentLayer": null,
                "subLayers": [],
                "minScale": 0,
                "maxScale": 0,
                "drawingInfo": {
                    "renderer": {
                        "type": "simple",
                        "symbol": {
                            "type": "esriSFS",
                            "style": "esriSFSSolid",
                            "color": [0, 0, 0, 0],
                            "outline": {
                                "type": "esriSLS",
                                "style": "esriSLSSolid",
                                "color": [0, 0, 0, 255],
                                "width": 2
                            }
                        },
                        "label": "",
                        "description": ""
                    },
                    "transparency": 0,
                    "labelingInfo": null
                },
                "defaultVisibility": true,
                "extent": {
                    "xmin": -178.21759836267427,
                    "ymin": 18.9217863446641,
                    "xmax": -66.96927103622932,
                    "ymax": 71.40623536706858,
                    "spatialReference": {
                        "wkid": 4269,
                        "latestWkid": 4269
                    }
                },
                "hasAttachments": false,
                "htmlPopupType": "esriServerHTMLPopupTypeNone",
                "displayField": "NAME",
                "typeIdField": null,
                "fields": [{
                    "name": "OBJECTID",
                    "type": "esriFieldTypeOID",
                    "alias": "OBJECTID",
                    "domain": null
                }, {
                    "name": "Shape",
                    "type": "esriFieldTypeGeometry",
                    "alias": "Shape",
                    "domain": null
                }, {
                    "name": "NAME",
                    "type": "esriFieldTypeString",
                    "alias": "NAME",
                    "length": 25,
                    "domain": null
                }],
                "relationships": [],
                "canModifyLayer": true,
                "canScaleSymbols": false,
                "hasLabels": false,
                "capabilities": "Data,Map,Query",
                "maxRecordCount": 1000,
                "supportsStatistics": true,
                "supportsAdvancedQueries": true,
                "supportedQueryFormats": "JSON, AMF",
                "ownershipBasedAccessControlForFeatures": {
                    "allowOthersToQuery": true
                },
                "useStandardizedQueries": true
            },
            "featureSet": {
                "geometryType": "esriGeometryPolygon",
                "features": []
            }
        };
        var GeoTargetLayer = declare("athoc.layer.GeoTargetLayer", [Evented], {
            name: "Target Areas",
            visible: ko.observable(true),
            _dirty: false,
            options: { map: null },
            isTargeting: true,
            canTargetUser: true,
            canTargetOrg: true,
            removedFeatures: null,
            graphics: [],
            enabled: ko.observable(false),
            symbol: new SimpleFillSymbol(SimpleFillSymbol.STYLE_SOLID,
                                    new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID,
                                    Color.fromHex("#8564a6"), 2), new Color([224, 255, 255, 0.45])),
            constructor: function (options) {
                this.visible.subscribe(lang.hitch(this, "setVisibility"));
                if (!options) {
                    options = {};
                }
                this.options = options;
                this.isTargeting = options.isTargeting === false ? false : true;
                this.removedFeatures = [];
                this.predefinedZoneLayer = options.predefinedZoneLayer;
                this.orgsLayer = options.orgsLayer;
                this.graphics = [];
                this._esriMap = options.coreMap;

                this._editLayer = new GraphicsLayer({
                    id: "EditLayer"
                });
                this._noneEditLayer = new FeatureLayer(fc);
                this._noneEditLayer.id = "NonEditLayer";
                
                
                this._esriMap.addLayer(this._editLayer, 4);

                var labelColor = Color.fromHex("#ffffff");
                var labelSymbol = new TextSymbol().setColor(labelColor);
                labelSymbol.font.setSize("9pt");
                labelSymbol.font.setFamily("Arial");
                labelSymbol.font.setWeight(Font.WEIGHT_BOLD);
                this._labelLayer = new LabelLayer({ id: "NonEditLabel" });
                var json = {
                    "labelExpressionInfo": { "value": "{NAME}" }
                };
                var labelClass = new LabelClass(json);
                labelClass.symbol = labelSymbol;
                this._noneEditLayer.setLabelingInfo([labelClass]);
                this._esriMap.addLayer(this._noneEditLayer, 2);
                
                this.targetRelationship = "inside";
                this.edit = new Edit(this._esriMap);
                //whenever geometries got updated, invoke target mothod, and in turn, it will emit userTargetComplete and orgTargetComplete events
                //it should set dirty flag. If any of the events, such as vertex-move, rotate, graphic-move and so on, ever happened, then dirty is true,
                //then call target method
                this.edit.on("graphic-first-move", lang.hitch(this, function (e) {
                    this._updateGraphic(e.graphic);
                }));
                this.edit.on("rotate-first-move", lang.hitch(this, function (e) {
                    this._updateGraphic(e.graphic);
                }));
                this.edit.on("scale-first-move", lang.hitch(this, function (e) {
                    this._updateGraphic(e.graphic);
                }));
                this.edit.on("vertex-add", lang.hitch(this, function (e) {
                    this._updateGraphic(e.graphic);
                }));
                this.edit.on("vertex-delete", lang.hitch(this, function (e) {
                    this._updateGraphic(e.graphic);
                }));
                this.edit.on("vertex-first-move", lang.hitch(this, function (e) {
                    this._updateGraphic(e.graphic);
                }));

                this.edit.on("graphic-move-stop", lang.hitch(this, function (e) {
                    this._updateGraphic(e.graphic);
                }));

                this.edit.on("deactivate", lang.hitch(this, function () {
                    if (this._dirty) {
                        //this.target();
                    }
                    this._dirty = false;
                }));
                this.startListenEdit();

                //delete graphic when pressing delete button
                this.deleteKeyEvent = on.pausable(window, "keyup", lang.hitch(this, function (e) {
                    switch (e.keyCode) {
                        case keys.DELETE:
                            this.removeEditableGraphic(this.editingGraphic);
                            this.emit("graphicRemove", { graphic: this.editingGraphic });

                            this.editingGraphic = null;
                            this.endEdit();
                            break;
                    }
                }));
                //don't connect it initially. All about efficiency.
                this.deleteKeyEvent.pause();
                //listening alt key to decide if it's uniform scale
                on(window, "keydown", lang.hitch(this, function (e) {
                    switch (e.keyCode) {
                        case keys.SHIFT:
                            this._uniformScaling = true;
                            break;
                    }
                }));
                on(window, "keyup", lang.hitch(this, function (e) {
                    switch (e.keyCode) {
                        case keys.SHIFT:
                            this._uniformScaling = false;
                            break;
                    }
                }));
            },

            startListenEdit: function () {
                if (!this._editStartEvent) {
                    this._editStartEvent = this._editLayer.on("click", lang.hitch(this, function (evt) {
                        //event.stop prevents any other click event from bubbling up
                        event.stop(evt);
                        this.endEdit();
                        if (evt.graphic.attributes && evt.graphic.attributes.editable === false) {
                            return;
                        }
                        this.startEdit(evt.graphic);
                        this.editingGraphic = evt.graphic;
                    }));
                }
            },

            stopListenEdit: function () {
                if (this._editStartEvent && this._editStartEvent.remove) {
                    this._editStartEvent.remove();
                    this._editStartEvent = null;
                }
            },

            _updateGraphic: function (graphic) {
                if (!graphic.attributes) {
                    graphic.attributes = {};
                }
                if (graphic.attributes.status !== "add" && graphic.attributes.id != null && graphic.attributes.id != undefined) {
                    graphic.attributes.status = "update";
                }
                this._dirty = true;
	            graphic.attributes.updated = true;
	        },

            reducePolygon: function (feature) {
            	if (feature && feature.geometry) {
            		var bbox = feature.geometry.bbox();
		            if (feature.geometry.type === "MultiPolygon") {
			            for (var i = 0; i < feature.geometry.coordinates.length; i++) {
				            for (var j = 0; j < feature.geometry.coordinates[i].length; j++) {
					            feature.geometry.coordinates[i][j][0] = [bbox[0], bbox[1]];
					            feature.geometry.coordinates[i][j][1] = [bbox[2], bbox[1]];
					            feature.geometry.coordinates[i][j][2] = [bbox[2], bbox[3]];
					            feature.geometry.coordinates[i][j][3] = [bbox[0], bbox[3]];
					            feature.geometry.coordinates[i][j][4] = [bbox[0], bbox[1]];
					            feature.geometry.coordinates[i][j].splice(5);
				            }
			            }
		            } else {
			            feature.geometry.coordinates[0][0] = [bbox[0], bbox[1]];
			            feature.geometry.coordinates[0][1] = [bbox[2], bbox[1]];
			            feature.geometry.coordinates[0][2] = [bbox[2], bbox[3]];
			            feature.geometry.coordinates[0][3] = [bbox[0], bbox[3]];
			            feature.geometry.coordinates[0][4] = [bbox[0], bbox[1]];
			            feature.geometry.coordinates[0].splice(5);
		            }
	            }
            },


            target: function () {
                this.graphics.clear();
                this.graphics = this.graphics.concat(this._editLayer.graphics, this._noneEditLayer.graphics);
	            if (this.graphics.length > 0) {
                    this.enabled(true);
                    //this.visible(true);
                } else {
                    this.emit("targetAbort", { graphics: this.graphics, applyEnabled: false });
                    return;
                }

                //if not targeting, abort
                if (!this.isTargeting) {
                    this.emit("targetAbort", { graphics: this.graphics, applyEnabled: true });
                    return;
                }
	            var geoJsonObj = this.toGeoJson();
               
	           
				//delete geo geometry to reduce payload
	            array.forEach(geoJsonObj.features,lang.hitch(this, function (feature) {
	            	this.reducePolygon(feature);
	            }));

            	//reduce the size of the coordinate values by cutting off the string after 6 decimal digits
            	//for now, it's always polygon
                var geoJsonStr = dojoJson.toJson(geoJsonObj);
                if (geoJsonStr.length > 999999999999) {
                	//UTF-8 encoding, if it's larger than 200k, don't target
                	this.emit("targetAbort", { graphics: this.graphics, applyEnabled: false });
                	//pop a warning msg
                	return;
                }
                this.emit("targetStart", { graphics: this.graphics });
                this.emit("userTargetStart", {});
                this.emit("orgTargetStart", {});
                //query users
                if (this.canTargetUser) {
                    $.ajax({
                        type:"POST",
                        url: "/athoc-iws/maplayers/GetUserCountByGeo",
                        data: { geoJson: geoJsonStr, targetRelationship: this.targetRelationship },
                        dataType: "json"
                    }).then(lang.hitch(this, function (response) {
                        var numberOfUsers = this.graphics.length > 0 ? response.selectedUsers : 0;
                        this.emit("userTargetComplete", { selectedUsers: numberOfUsers });
                    }), function (jqxhr, textStatus, errorThrown) {
                        console.log("Querying users encountered issues...");
                        AjaxUtility().ajaxPostOptions.error(jqxhr, textStatus, errorThrown);
                    });
                }
                //query orgs client side, the commented code is query orgs on server
                //check if loaded, may or may not be necessary. If there is no use case, just reduce the complexity by remove the check.
                if (this.orgsLayer.aborted || !this.canTargetOrg) {
                    this.emit("orgTargetComplete", { selectedOrgs: 0, orgIds: [] });
                } else if (!this.orgsLayer) {
                    this.emit("orgTargetComplete", { selectedOrgs: 0, orgIds: [] });
                    var orgsLayerLoadHandler = this.orgsLayer.on("load", lang.hitch(this, "_targetOrgs"));
                    orgsLayerLoadHandler.remove();
                } else {
                    this._targetOrgs();
                }
             
            },

            setTargetRelationship: function (targetRelationship) {
                this.targetRelationship = targetRelationship;
            },

            targetOrgs: function () {
                if (!this.orgLayer) {
                    var orgLayerLoadHandler = this.orgLayer.on("load", function () {
                        orgLayerLoadHandler.remove();
                        this._targetOrgs();
                    });
                } else {
                    this._targetOrgs();
                }
            },

            getSelectedGraphics: function () {
            	var graphics = this._editLayer.graphics.concat(this._noneEditLayer.graphics);
	            return graphics;
            },

            _targetOrgs: function () {
                if (this.orgsLayer.graphics.length === 0) {
                    //this.emit("orgTargetComplete", { selectedOrgs: "Not available" });
                    this.emit("orgTargetComplete", { selectedOrgs: 0, orgIds: [] });
                }
                var numberOfOrgs = 0, selectedOrgsIdx = [], orgIds = [];
                array.forEach(this.graphics, function (targetGraphic) {
                    array.forEach(this.orgsLayer.graphics, function (orgGraphic, idx) {
                        //only polygon has contain function
                        if (selectedOrgsIdx.indexOf(idx) === -1 &&
                            targetGraphic.geometry &&
                            targetGraphic.geometry.contains && targetGraphic.geometry.contains(orgGraphic.geometry)) {
                            numberOfOrgs++;
                            selectedOrgsIdx.push(idx);
                            if (orgGraphic.attributes && orgGraphic.attributes.orgId) {
                                orgIds.push(orgGraphic.attributes.orgId);
                            }
                        }
                    });
                }, this);
                if (this.targetRelationship === "inside") {
                    this.emit("orgTargetComplete", { selectedOrgs: numberOfOrgs, orgIds: orgIds });
                    return;
                } else {
                    //todo: when outside case needed, generate the orgIds for it
                    this.emit("orgTargetComplete", { selectedOrgs: this.orgsLayer.graphics.length - numberOfOrgs });
                    return;
                }
            },

            startEdit: function (graphic) {
                this.isEditing = true;
                this.emit("editStart", { graphic: graphic });
                this.deleteKeyEvent.resume();
                this.edit.activate(Edit.EDIT_VERTICES | Edit.MOVE | Edit.ROTATE | Edit.SCALE, graphic, { uniformScaling: this._uniformScaling });
            },

            endEdit: function () {
                this.editingGraphic = null;
                this.isEditing = false;
                this.deleteKeyEvent.pause();
                if (this.edit && this.edit.deactivate) {
                    this.edit.deactivate();
                }
                this.emit("editEnd", null);
            },

			

            addEditableGraphic: function (graphic) {
                graphic.attributes.color = graphic.symbol.color;
                graphic.attributes.border = graphic.symbol.outline.color;
	           
                this._editLayer.add(graphic);
                this.emit("editableGraphicAdd", { graphic: graphic });
            },

            addNoneEditableGraphic: function (graphic) {
                this._noneEditLayer.add(graphic);
                this.emit("noneEditableGraphicAdd", { graphic: graphic });
            },

            isNoneEditableGraphicExist: function (id) {
                var graphicExist = $.grep(this._noneEditLayer.graphics, lang.hitch(this, function (graphic) {
                    return (graphic.attributes.id === id);
                }));
                if (graphicExist && graphicExist.length > 0) {
                    return graphicExist[0];
                }
                return null;
            },


            removeNoneEditableGraphic: function (id) {
                if (!id) return;
                var graphicExist = this.isNoneEditableGraphicExist(id);
                if (graphicExist) {
                    this._noneEditLayer.remove(graphicExist);
                    this.emit("noneEditableGraphicRemove", { id: id });
                }
            },

			getNonEditLayerGraphics:function() {
				return this._noneEditLayer.graphics;
			},

            removeEditableGraphic: function (graphic) {
                this._editLayer.remove(graphic);
            },

            clear: function () {
                this.clearEditLayer();
                this.clearNoneEditLayer();
                this.graphics = [];
                this.emit("clear", null);
            },

            clearInboundGraphics: function () {
                var nonEditableGraphics = this._noneEditLayer.graphics,
                    inboundGraphics = [];
                //have to loop to find all the inbound graphics, then loop again.
                //It will mess the item in the layer.graphics if removing it in the same loop
                array.forEach(nonEditableGraphics, function (item) {
                    if (item.attributes && item.attributes.isInbound) {
                        inboundGraphics.push(item);
                    }
                });
                array.forEach(inboundGraphics, function (item) {
                    this._noneEditLayer.remove(item);
                }, this);
            },

            clearEditLayer: function () {
                this._editLayer.clear();
            },

            clearNoneEditLayer: function () {
                this._noneEditLayer.clear();
            },

			
            getIdForHandDrawnPolygon: function (geojsonObj,callback) {
            	var geoJsonStr = dojoJson.toJson(geojsonObj);
            	$.ajax({
            		type: "POST",
            		url: "/athoc-iws/maplayers/CreateIdForGraphic",
            		data: { geoJson: geoJsonStr },
            		dataType: "json",
					async:false
            	}).then(lang.hitch(this, function (response) {
		            if (callback) {
				        callback(response.Data);
			        }
		        }), function (jqxhr, textStatus, errorThrown) {
            		console.log("Graphic spatialids didn't get filled");
            		AjaxUtility().ajaxPostOptions.error(jqxhr, textStatus, errorThrown);
            	});
            },
			
			
			populateSpatialId:function() {
				//custom graphics does not have ids, so populate them first
				var featuresDoesNotHaveIds = [];
				for (var i = 0; i < this._editLayer.graphics.length; i++) {
					var graphic = this._editLayer.graphics[i];
					graphic.attributes.TEMPKEY = i;
					if (!graphic.attributes.OBJECTID || graphic.attributes.updated) {
						var graphicGeoJson = util.convertToGeoJson([graphic]);
						featuresDoesNotHaveIds.push(graphicGeoJson.features[0]);
					}
				}

				if (featuresDoesNotHaveIds.length > 0) {
					var featureClass = { type: "FeatureCollection", features: featuresDoesNotHaveIds };
					this.getIdForHandDrawnPolygon(featureClass, lang.hitch(this, function(idDict) {
						if (!idDict) {
							console.log("Id generation failed for graphics ");
							return;
						}
						for (var key in idDict) {
							var graphicToBeUpdated = $.grep(this._editLayer.graphics, function (graphicElem) {
								return parseInt(key,10) === graphicElem.attributes.TEMPKEY;
							});
							if (graphicToBeUpdated) {
								graphicToBeUpdated[0].attributes.OBJECTID = idDict[key];
								delete graphicToBeUpdated[0].attributes.TEMPKEY;
							}
						}
		            	
					}));
				}
			},


            toGeoJson: function () {
            	this.graphics = [];
            	
                this.graphics = this.graphics.concat(this._editLayer.graphics, this._noneEditLayer.graphics);

                if (!this.graphics || this.graphics.length === 0) {
                    return { type: "FeatureCollection", features: [] };
                }

	            this.populateSpatialId();

	            var geoJson = util.convertToGeoJson(this.graphics);

	            //reduce the size of the coordinate values by cutting off the string after 6 decimal digits
                //for now, it's always polygon
                array.forEach(geoJson.features, function (feature) {
                    switch (feature.geometry.type.toLowerCase()) {
                        case "polygon":
                            array.forEach(feature.geometry.coordinates, function (coordinate) {
                                coordinate.reverse();
                                array.forEach(coordinate, function (values) {
                                    values[0] = parseInt(values[0] * 1000000) / 1000000;
                                    values[1] = parseInt(values[1] * 1000000) / 1000000;
                                });
                            });
                            break;
                        case "multipolygon":
                            array.forEach(feature.geometry.coordinates, function (coordinate) {
                                array.forEach(coordinate, function (values) {
                                    values.reverse();
                                    array.forEach(values, function (valuePair) {
                                        valuePair[0] = parseInt(valuePair[0] * 1000000) / 1000000;
                                        valuePair[1] = parseInt(valuePair[1] * 1000000) / 1000000;
                                    });
                                });
                            });
                            break;
                    }
                });
                if (!geoJson.features) {
                    geoJson.features = [];
                }
                return geoJson;
            },

            
            toJson: function () {
                var editableLayer = this._editLayer,
                    editableGraphics = [],
                    nonEditableLayer = this._noneEditLayer,
                    nonEditableGraphics = [];
                array.forEach(editableLayer.graphics, function (item) {
                    editableGraphics.push(item.toJson());
                });
                array.forEach(nonEditableLayer.graphics, function (item) {
                    nonEditableGraphics.push(item.toJson());
                });
                return {
                    editableGraphics: editableGraphics,
                    nonEditableGraphics: nonEditableGraphics
                };
            },

            restoreJson: function (json) {
                this.clear();
                var editableGraphic;
                array.forEach(json.editableGraphics, function (item) {
                    editableGraphic = new Graphic(item);
                    this.addEditableGraphic(editableGraphic);
                    this.graphics.push(editableGraphic);
                }, this);
                var noneEditableGraphic;
                array.forEach(json.nonEditableGraphics, function (item) {
                    noneEditableGraphic = new Graphic(item);
                    this.addNoneEditableGraphic(noneEditableGraphic);
                    this.graphics.push(noneEditableGraphic);
                }, this);
                if (this.graphics.length > 0) {
                    this.enabled(true);
                }
            },

            restore: function (geoJson) {
                //restore geojson
                this.clear();
                var graphic, symbol;
                //when calling restore, don't call target method because it' snot efficient.
               var inboundPolygonSymbol = new SimpleFillSymbol(SimpleFillSymbol.STYLE_SOLID,
                    new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID,
                        Color.fromHex("#FF0000"), 2), new Color([255, 0, 0, 0.3]));
                array.forEach(geoJson.features, function (item) {
                    /*//only use polygon or multipolygon
                    if (item.geometry.type.toLowerCase() !== "polygon" && item.geometry.type.toLowerCase() !== "multipolygon") {
                        return;
                    }*/
                    if (item.geometry.type.toLowerCase() === "point" && item.properties.symbol) {
                        //presumably, each item may have different icon.
                        symbol = new PictureMarkerSymbol(item.properties.symbol.url, 32, 32);
                        symbol.setOffset(item.properties.symbol.width / 4, item.properties.symbol.height * 3 / 8);
                        graphic = util.convertGeoJsonFeatureToGraphic(item, { symbol: symbol });
                    } else if (item.properties && item.properties.isInbound) {
                        graphic = util.convertGeoJsonFeatureToGraphic(item, { symbol: inboundPolygonSymbol });
                    } 
                    
                    if (item.properties && item.properties.status !== "add") {
                        graphic.attributes.status = "existing";
                    }
                    if (item.geometry.type.toLowerCase() !== "point") {
                    	var fillSymbol;
	                    if (!item.properties || item.properties.editable == undefined) {
		                    fillSymbol = new SimpleFillSymbol(SimpleFillSymbol.STYLE_SOLID,
			                    new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID,
				                    Color.fromHex("#00ffff"), 2), new Color([0, 255, 255, 0.45]));
		                    graphic = util.convertGeoJsonFeatureToGraphic(item, { symbol: fillSymbol });
		                    this.addEditableGraphic(graphic);

	                    } else {
		                    var notEditable ;		                    
							if (typeof item.properties.editable === 'string') {
								notEditable = item.properties.editable == "false";
							}else if (typeof item.properties.editable === 'boolean') {
								notEditable = !item.properties.editable;
							}
		                    
		                    if (!notEditable) {
			                    fillSymbol = new SimpleFillSymbol(SimpleFillSymbol.STYLE_SOLID,
				                    new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID,
					                    Color.fromHex("#00ffff"), 2), new Color([0, 255, 255, 0.45]));
			                    graphic = util.convertGeoJsonFeatureToGraphic(item, { symbol: fillSymbol });
			                    this.addEditableGraphic(graphic);
		                    } else {
			                    var borderColor, fillColor;
			                    if (!item.properties.color && !item.properties.border) {
				                    borderColor = Color.fromHex("#00ffff");
				                    fillColor = new Color([246, 178, 107, 0.5]);
			                    } else {
				                    borderColor = item.properties.border;
				                    fillColor = item.properties.color;
			                    }
			                    fillSymbol = new SimpleFillSymbol(SimpleFillSymbol.STYLE_SOLID,
				                    new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID,
					                    borderColor, 3), fillColor);

			                    graphic = util.convertGeoJsonFeatureToGraphic(item, { symbol: fillSymbol });
			                    this.addNoneEditableGraphic(graphic);
		                    }
	                    }
                    }
	                this.graphics.push(graphic);
                }, this);
                if (this.graphics.length > 0) {
                    this.enabled(true);
                }
           },

            setVisibility: function (e) {
                this._noneEditLayer.setVisibility(this.visible());
                this._editLayer.setVisibility(this.visible());
            },

            setTargetable: function (targetable) {
                this.isTargeting = targetable;
                this.emit("isTargetingChange", { isTargeting: targetable });
            },

            setUserTargetable: function (targetable) {
                this.canTargetUser = targetable;
                this.emit("canTargetUserChange", { canTarget: targetable });
            },

            setOrgTargetable: function (targetable) {
                this.canTargetOrg = targetable;
                this.emit("canTargetOrgChange", { canTarget: targetable });
            }
        });
        return GeoTargetLayer;
    }
);