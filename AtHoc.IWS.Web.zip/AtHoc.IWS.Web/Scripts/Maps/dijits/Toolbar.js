﻿define([
"dojo/_base/declare",
"dojo/dom-construct",
"dojo/on",
"dojo/query",
"dojo/_base/lang",
"dojo/_base/array",
"dijit/_WidgetBase",
"dijit/_TemplatedMixin",
"dojo/Evented",
"dojo/dom-style",
"dojo/dom-class",
"dojo/dom-attr",
"dojo/text!maps/dijits/toolbar/toolbarTemplate.html",
"maps/dijits/toolbar/ToolbarModel"
],
function (declare, domConstruct, on, query, lang, array, _WidgetBase, _TemplatedMixin, Evented, domStyle, domClass, domAttr, template, Model) {
    var Toolbar = declare("athoc.dijits.Toolbar", [_WidgetBase, _TemplatedMixin, Evented], {
        templateString: template,
        options: { tools: [] },
        model: null,
        constructor: function (options, srcRefNode) {
            this.options = options;
            this.tools = options.tools;
            this.model = new Model({
                tools: this.tools
            });
            this.domNode = srcRefNode;
        },

        startup: function () {
            ko.applyBindings(this.model, this.domNode);
            this.inherited(arguments);
            //hide all tools initially
            this.model.deactivateAll();

            var nodes = query(".btn-info", this.domNode.parentNode);
            array.forEach(nodes, function(item) {
                on(item, "click", lang.hitch(this, "toggle", item));
            }, this);
          
        },

        toggle: function (item, e) {
            var tool = item;
            //deactivate all other tools
            array.forEach(this.tools, function (item) {
                if ($(tool).hasClass(item.name)) {
                    $(item.domNode).toggle();
                } else {
                    domStyle.set(item.domNode, {
                        display: "none"
                    });
                    item.visible = false;
                    item.deactivate();
                }
            });
            return;
            
        },

        closeAllTools: function() {
            array.forEach(this.tools, function (item) {
                domStyle.set(item.domNode, {
                    display: "none"
                });
                item.visible = false;
                item.deactivate();
            });
        },

        destroy: function() {
            this.inherited(arguments);
        },

        add: function (tool) {

        },

        remove: function(tool) {
            
        }
    });
    return Toolbar;
});