﻿define(
["dojo/_base/declare", "dojo/_base/lang", "dijit/_WidgetBase", "dijit/_TemplatedMixin", "dojo/Evented", "dojo/text!maps/dijits/homeAndFit/homeAndFitTemplate.html"],
    function (declare, lang, _WidgetBase, _TemplatedMixin, Evented, template) {
        var HomeAndFit = declare("athoc.dijits.TargetResult", [_WidgetBase, _TemplatedMixin, Evented], {
            templateString: template,
            options: { map: null },
            map: null,
            i18n:{},
            constructor: function (options, srcRefNode) {
                this.options = options;
                this.map = options.map;
                this.domNode = srcRefNode;
                this.i18n = options.i18n;
            },

            startup: function () {
                $("#homeButton").attr("title", this.i18n.Map_HomeAndFit_DefaultArea);
                $("#fitButton").attr("title", this.i18n.Map_HomeAndFit_WorkingArea);
            },

            home: function () {
                this.map.zoomToHome();
            },

            fit: function() {
                this.map.zoomToFit();
            }
        });
        return HomeAndFit;
    }
);