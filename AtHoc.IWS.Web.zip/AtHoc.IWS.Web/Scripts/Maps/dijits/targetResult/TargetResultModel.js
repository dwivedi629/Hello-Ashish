﻿define(
["dojo/_base/declare", "dojo/_base/array"],
    function (declare, array) {
        var TargetResultModel = declare("athoc.dijits.targetResult.TargetResultModel", null, {
            selectedUsers: null,
            constructor: function (options) {
                if (!options) {
                    options = {};
                }
                var self = this;
                this.visible = ko.observable();
                this.selectedUsers = ko.observable();
                this.selectedOrgs = ko.observable();
                this.totalSelectedLocations = ko.observable();
                var isTargeting = options.isTargeting ? true : false;
                this.isTargeting = ko.observable(isTargeting);

                this.isTargetingUser = ko.observable(true);
                this.isTargetingOrg = ko.observable(true);
                this.targetRelationship = ko.observable();
                this.canTargetUser = ko.observable(true);
                this.canTargetOrg = ko.observable(true);
                this.i18n = ko.observableArray([]);
	            this.isDirty = ko.observable(false);
            }
        });
        return TargetResultModel;
    }
);