﻿define([
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/array",
"dijit/_WidgetBase",
"dijit/_TemplatedMixin",
"dojo/Evented",
"dojo/dom-style",
"dojo/text!maps/dijits/tools/toc/tocTemplate.html",
"maps/dijits/tools/toc/TocModel",
"maps/dijits/tools/_ToolBase"
],
function (declare, lang, array, _WidgetBase, _TemplatedMixin, Evented, domStyle, template, Model, _ToolBase) {
    var Toc = declare("athoc.dijits.tools.Toc", [_WidgetBase, _TemplatedMixin, Evented, _ToolBase], {
        templateString: template,
        name: "toc",
        title: "Layers",
        options: { map: null, visible: false },
        constructor: function (options, srcRefNode) {
            //common code for tool
            this.domNode = srcRefNode;
            this.options = options;
            this.visible = options.visible == undefined ? true : options.visible;
            this.layers = options.layers;
            this.model = new Model(this.layers);
            this.model.i18n = options.i18n;
            this._esriMap = options.map;
        },

        startup: function () {
            //common code for tool
            ko.applyBindings(this.model, this.domNode);
            this.inherited(arguments);
            if (!this.visible) {
                this.hide();
            }
        },

        removeLayer: function (layer) {
            //this.layers.remove?
            this.model.layers.remove(layer);
        },

        activate: function () {
        },

        deactivate: function () {
        },

        show: function () {
            domStyle.set(this.domNode, {
                display: "block"
            });
        },

        hide: function () {
            domStyle.set(this.domNode, {
                display: "none"
            });
        }
    });
    return Toc;
});