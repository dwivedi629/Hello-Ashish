﻿define(
["dojo/_base/declare", "dojo/_base/array"],
    function (declare, array) {
        var model = declare("athoc.dijits.targetResult.RefreshLayerModel", null, {
            selectedUsers: null,
            constructor: function (options) {
                if (!options) {
                    options = {};
                }
                var self = this;
                this.i18n = options.i18n;
                this.time = ko.observable();
            }
        });
        return model;
    }
);