﻿define([
    "dojo/aspect",
    "dojo/Evented",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/has", // feature detection
    "esri/kernel", // esri namespace
    "dijit/_WidgetBase",
    "dijit/a11yclick", // Custom press, release, and click synthetic events which trigger on a left mouse click, touch, or space/enter keyup.
    "dijit/_TemplatedMixin",
    "dojo/on",
    "dojo/Deferred",
    "dojo/dom-style",
    "dojo/dom-class",
    "dojo/query",
    "dojo/text!maps/dijits/tools/drawing/drawingTemplate.html",
    "maps/dijits/tools/drawing/DrawingModel",
    "maps/util",
    "esri/toolbars/draw",
    "esri/graphic",
    "esri/symbols/SimpleFillSymbol",
    "esri/symbols/SimpleLineSymbol",
    "esri/Color",
    "esri/geometry/geodesicUtils",
    "esri/units",
    "esri/geometry/webMercatorUtils",
    "esri/geometry/Polygon",
    "maps/dijits/tools/_ToolBase"
],
function (
    aspect,
    Evented,
    declare,
    lang,
    has, esriNS,
    _WidgetBase, a11yclick, _TemplatedMixin,
    on,
    Deferred,
    domStyle,
    domClass,
    query,
    template,
    Model,
    util,
    Draw,
    Graphic,
    SimpleFillSymbol,
    SimpleLineSymbol,
    Color,
    geodesicUtils,
    esriUnits,
    webMercatorUtils,
    Polygon,
    _ToolBase
) {
    var Drawing = declare("athoc.dijits.tools.Drawing", [_WidgetBase, _TemplatedMixin, Evented, _ToolBase], {
        templateString: template,
        name: "drawing",
        title: "Map Tools",
        options: { geoTargetLayer: null, map: null, visible: false },
        constructor: function (options, srcRefNode) {
            this.domNode = srcRefNode;
            this.options = options;
            this.visible = options.visible == undefined ? true : options.visible;
            this.geoTargetLayer = options.geoTargetLayer;
            this._esriMap = options.map;
            //this.info = options.info;
            this.geotargetMap = options.geotargetMap;
            this.model = new Model();
            this.model.i18n = options.i18n;
            this._draw = new Draw(this._esriMap, {
                showTooltips: true
            });
            this._draw.on("draw-complete", lang.hitch(this, "_drawCompleteHandler"));
            this.geoTargetLayer.on("editStart", lang.hitch(this, function(e) {
                this.editingGraphic = e.graphic;
                domClass.remove(this._deleteNode, "disabled");
                this.model.disableDelete(false);
                //calculate the show the area of the selected graphic
                this._calculateArea(this.editingGraphic.geometry);
            }));
            this.geoTargetLayer.on("editEnd", lang.hitch(this, function () {
                this.editingGraphic = null;
                domClass.add(this._deleteNode, "disabled");
                this.model.disableDelete(true);
                //two ways binding to the template
                this.geotargetMap.model.drawinfo(null);
            }));
            //listens to edit toolbar events to update the area
            this.geoTargetLayer.edit.on("graphic-first-move", lang.hitch(this, function (e) {
            	this.geotargetMap.model.drawinfo(null);
            }));
            this.geoTargetLayer.edit.on("rotate-first-move", lang.hitch(this, function (e) {
            	this.geotargetMap.model.drawinfo(null);
            }));
            this.geoTargetLayer.edit.on("scale-first-move", lang.hitch(this, function (e) {
            	this.geotargetMap.model.drawinfo(null);
            }));
            this.geoTargetLayer.edit.on("vertex-add", lang.hitch(this, function (e) {
                this._calculateArea(e.graphic.geometry);
            }));
            this.geoTargetLayer.edit.on("vertex-delete", lang.hitch(this, function (e) {
                this._calculateArea(e.graphic.geometry);
            }));
            this.geoTargetLayer.edit.on("vertex-move-start", lang.hitch(this, function (e) {
                this._startGeometryJson = e.graphic.geometry.toJson();
            }));
            this.geoTargetLayer.edit.on("vertex-move-stop", lang.hitch(this, function (e) {
                if (e.graphic.geometry.type == "polygon" && e.graphic.geometry.isSelfIntersecting(e.graphic.geometry)) {
                    e.graphic.setGeometry(new Polygon(this._startGeometryJson));
                    this.geoTargetLayer.endEdit();
                    this.geotargetMap.model.drawinfo(this.model.i18n.Map_Polygon_Message);
                } else {
                    this._calculateArea(e.graphic.geometry);
                }
            }));
            this.geoTargetLayer.edit.on("scale-stop", lang.hitch(this, function (e) {
                this._calculateArea(e.graphic.geometry);
            }));

            aspect.before(this._draw, "_onMouseDragHandler", lang.hitch(this, function (e) {
                if (this._draw._geometryType === Draw.CIRCLE) {
                    this._circleCenter = this._draw._points[0];
                    var circleEdgePoint = e.mapPoint;
                    var radius, unit = "feet";
                    if (this._circleCenter) {
                        radius = util.getDistance(this._circleCenter, circleEdgePoint) * 3.28084;//in feet
                        if (radius > 5000) {
                            radius /= 5280;
                            unit = "miles";
                        }
                        else if (radius > 1000) {
                            radius /= 3;
                            unit = "yards";
                        }
                        radius = Math.round(radius * 1000) / 1000;
                        this.geotargetMap.model.drawinfo(kendo.format(this.model.i18n.Map_Selected_Radius, radius, unit));
                    }
                }
            }));
        },

        startup: function() {
            this.inherited(arguments);
            if (!this.visible) {
                this.hide();
            } else {
                this.show();
            }
            ko.applyBindings(this.model, this.domNode);
        },

      
        activate: function (e) {
            this.deactivate();
            var toolDomNode = e.target;
            var toolName = toolDomNode.id.replace(" ", "_").toUpperCase();
            domClass.add(toolDomNode.parentNode, "selected");
            domClass.add(toolDomNode, "selected");
            //disable editing tool
            this.geoTargetLayer.stopListenEdit();
            //drawing dijit is inside another div, so it has to go two levels up to find the map holder
            $("#mapHolder_container", this.domNode.parentNode.parentNode).css("cursor", "crosshair");
            this._draw.activate(Draw[toolName]);
            //map mouse drag event doesn't work with IE10 and 11. use dojo aspect to target onmousedraghandler in esri.draw
            //if (this._drawMouseDownHandler) {
            //    this._drawMouseDownHandler.remove();
            //}
            //if (this._drawMouseDragHandler) {
            //    this._drawMouseDragHandler.remove();
            //}
            //if (toolName === "CIRCLE") {
            //    this._drawMouseDownHandler = this._esriMap.on("mouse-drag-start", lang.hitch(this, function(e) {
            //        this._circleCenter = e.mapPoint;
            //    }));
            //    this._drawMouseDragHandler = this._esriMap.on("mouse-drag", lang.hitch(this, function (e) {
            //        //var circleEdgePoint = e.mapPoint;
            //        //var radius, unit = "feet";
            //        //if (this._circleCenter) {
            //        //    radius = util.getDistance(this._circleCenter, circleEdgePoint) * 3.28084;//in feet
            //        //    if (radius > 5000) {
            //        //        radius /= 5280;
            //        //        unit = "miles";
            //        //    }
            //        //    else if (radius > 1000) {
            //        //        radius /= 3;
            //        //        unit = "yards";
            //        //    }
            //        //    radius = Math.round(radius * 1000) / 1000;
            //        //    this.info("The radius is " + radius + " " + unit);
            //        //}
            //    }));
            //}
        },

        deactivate: function () {
            //enable editing tool listening
            this.geoTargetLayer.startListenEdit();
            if (this._drawMouseDownHandler) {
                this._drawMouseDownHandler.remove();
            }
            if (this._drawMouseDragHandler) {
                this._drawMouseDragHandler.remove();
            }
            query(".btn", this.domNode).forEach(function(item) {
                domClass.remove(item, "selected");
            });
            $("#mapHolder_container", this.domNode.parentNode.parentNode).css("cursor", "default");
            
            //make it robust
            if (this._draw && this._draw.deactivate) {
	             this._draw.deactivate();
            }
        },

        deleteGraphic: function () {
            if (this.model.disableDelete()) {
                return;
            }
            if (this.editingGraphic.attributes && this.editingGraphic.attributes.id && this.editingGraphic.attributes.status !== "add") {
                //if id attribute exist, it implies it's from an existing alert
                this.geoTargetLayer.removedFeatures.push({
                    type: "Feature",
                    geometry: null,
                    properties: {
                        status: "remove",
                        id: this.editingGraphic.attributes.id
                    }
                });
            }
            this.geoTargetLayer.removeEditableGraphic(this.editingGraphic);
            this.geoTargetLayer.emit("graphicRemove", { graphic: this.editingGraphic });
            this.editingGraphic = null;
            this.geoTargetLayer.endEdit();
            
        },

        show: function() {
            domStyle.set(this.domNode, {
                display: "block"
            });
        },

        hide: function() {
            domStyle.set(this.domNode, {
                display: "none"
            });
        },

        _drawCompleteHandler: function (e) {
            this.deactivate();
            var symbol;
            switch(e.geometry.type) {
                case "polygon":
                    //sql server doesn't support self intersecting polygon
                    if (e.geometry.isSelfIntersecting(e.geometry)) {
                    	this.geotargetMap.info(this.model.i18n.Map_Polygon_Message);
                        return;
                    }
                    symbol = new SimpleFillSymbol(SimpleFillSymbol.STYLE_SOLID,
                                    new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID,
                                    Color.fromHex("#00ffff"), 2), new Color([0, 255, 255, 0.45]));
                    break;
                default:
                    //if it's not a polygon, don't do anything
                    return;
            }
            var graphic = new Graphic(e.geometry, symbol, {
                status: "add"
            });
            this.geoTargetLayer.addEditableGraphic(graphic);
            this._calculateArea(e.geometry);
        },
       

        _calculateArea: function (webMercatorGeometry) {
            var areaGeometry = webMercatorUtils.webMercatorToGeographic(webMercatorGeometry);
            var area = Math.abs(geodesicUtils.geodesicAreas([areaGeometry], esriUnits.SQUARE_MILES)[0]);
            var unit = "sq miles";
            //convert unit
            if (area < 1 / 6400) {
                //43560*640 = 27878400
                area *= 27878400;
                unit = "sq feet";
            }
            else if (area < 2) {
                area *= 640;
                unit = "acres";
            }
            //round values
            area = Math.round(area * 1000) / 1000;
            this.geotargetMap.model.drawinfo( kendo.format(this.model.i18n.Map_Selected_Area,area,unit));
        }
    });
    return Drawing;
});