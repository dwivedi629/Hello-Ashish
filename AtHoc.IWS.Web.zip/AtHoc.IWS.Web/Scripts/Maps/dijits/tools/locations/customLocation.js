﻿define(
["dojo/_base/declare",
    "dojo/_base/lang",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "dojo/Evented",
    "dojo/text!maps/dijits/tools/locations/customLocationTemplate.html",
    "maps/dijits/tools/Drawing",
    "dojo/query",
    "maps/layers/PredefinedZoneLayer",
    "esri/symbols/SimpleFillSymbol",
    "esri/symbols/SimpleLineSymbol",
     "esri/Color",
     "esri/graphic",
     "lib/helper"

],
    function (declare, lang, _WidgetBase, _TemplatedMixin, Evented, template, Drawing, query, PredefinedZoneLayer,
        SimpleFillSymbol, SimpleLineSymbol, Color, Graphic) {
    	var customLocation = declare("athoc.dijits.locations", [_WidgetBase, _TemplatedMixin, Evented], {
    		templateString: template,
    		options: { map: null },
    		map: null,
    		i18n: {},
    		constructor: function (options, srcRefNode) {
    			this.options = options;
    			this.map = options.map;
    			this.geotargetMap = options.geotargetMap;
    			this.geoTargetLayer = options.geoTargetLayer,
    			//this.viewMode = options.viewMode,
				    this.domNode = srcRefNode;
    			this.i18n = options.i18n;
    			var selectionText = this.i18n.Map_PredefinedLocation_DefaultSelection;
    			this.NoSelectedLayerMessage = this.i18n.Map_NoSelectionLayer_Message;
    			this.SelectableLayersArray = ko.observableArray([{ LayerId: -1, LayerName: selectionText }]);
    			this.SelectedLayer = ko.observable(-1);
    			this.ShapesArray = ko.observableArray([]);
    			this.SelectedGraphics = [];
    			this.SelectedFillColor = ko.observable("none");
    			this.geoTargetLayer.on("noneEditableGraphicRemove", lang.hitch(this, function (e) {
    				var graphicId = parseInt(e.id.substring(e.id.lastIndexOf("_") + 1));
    				var layerId = parseInt(e.id.substring(e.id.indexOf("_") + 1, e.id.lastIndexOf("_")));
    				var layerExist = $.grep(this.SelectableLayersArray(), function (e) {
    					return (e.LayerId === layerId);
    				});
    				if (layerExist && layerExist.length > 0) {
    					var layerToQuery = layerExist[0];
    					var shapesArray = layerToQuery.Shapes;
    					for (var i = 0; i < shapesArray.length; i++) {
    						if (shapesArray[i].Id === graphicId) {
    							shapesArray[i].Selected(false);
    							this.deselectShape(shapesArray[i].graphicObj);
    							break;
    						}
    					}
    				}
    			}));

    		},

    		startup: function () {
    			this.CustomLocationName = this.i18n.Map_CustomLocation;
    			this.PredefinedLocationName = this.i18n.Map_PredefinedLocation;
    			this.SelectedLayer.subscribe($.proxy(function (layerId) {
    				this.hideLayer(layerId);
    			}), this, "beforeChange");
    			this.SelectedLayer.subscribe($.proxy(function (layerId) {
    				this.loadLayer(layerId);
    			}), this);
    			ko.applyBindings(this, this.domNode);
    			$(this.domNode).find('.filter-option.pull-left.ellipsis').tooltip('disable');

    			var panelBar = $(".location-accord").kendoPanelBar().data("kendoPanelBar");
    			this.drawing = new Drawing({
    				geoTargetLayer: this.geoTargetLayer,
    				map: this.map,
    				visible: true,
    				i18n: this.i18n,
    				geotargetMap: this.geotargetMap
    			}, query(".drawingHolder", this.domNode)[0]);
    			this.drawing.title = this.i18n.Map_Map_Tools;
    			this.drawing.startup();

    			//this.init();

    		},

    		init: function () {
    			//load predefined location array 
    			$.ajax({
    				url: "/athoc-iws/maplayers/GetSelectableLayersMetadata",
    				cache: false,
    				success: $.proxy(function (response) {
    					this.callbackLayerMetadata(response);
    				}, this),
    				error: function (jqxhr, textStatus, errorThrown) {
    					AjaxUtility().ajaxPostOptions.error(jqxhr, textStatus, errorThrown);
    				}
    			});
    		},

    		removeAllLayers: function () {
    			$.each(this.SelectableLayersArray(), lang.hitch(this, function (index, layer) {
    				if (layer.LayerObj) {
    					layer.LayerObj.removeLayer();
    					layer.LayerObj = null;
    				}
    				if (layer.Shapes) {
    					layer.Shapes = [];
    				}

    			}));
    			this.ShapesArray.removeAll();
    			this.init();
    		},
    		hideLayer: function (layerId) {
    			if (!layerId || layerId === -1) {
    				return;
    			}
    			var layerExist = $.grep(this.SelectableLayersArray(), function (e) {
    				return (e.LayerId === layerId);
    			});
    			if (layerExist && layerExist.length > 0) {
    				var layerToQuery = layerExist[0];
    				if (layerToQuery.LayerObj) {
    					layerToQuery.LayerObj.setVisibility(false);
    				}
    			}
    		},
    		/*this heck is implemented in order to not obtruct selection layer*/
    		rearrangeInternalLabelLayer: function (currentLayerId) {
    			var internalLabelLayer = $("g").filter("#_internal_LabelLayer_layer")[0];
    			internalLabelLayer = $(internalLabelLayer).detach();
    			var nonEditLayer = $("g").filter("#NonEditLayer_layer")[0];
    			$(nonEditLayer).after(internalLabelLayer);
    		},

    		loadLayer: function (layerId) {
    			this.ShapesArray.removeAll();
    			if (!layerId || layerId === -1) {
    				$(".panelbar-predefined-location .legend").hide();
    				return;
    			}

    			var layerExist = $.grep(this.SelectableLayersArray(), function (e) {
    				return (e.LayerId === layerId);
    			});
    			if (layerExist && layerExist.length > 0) {
    				var layerToQuery = layerExist[0];
    				this.SelectedFillColor(layerToQuery.FillColor);
    				$(".legend").show();
    				if (layerToQuery.LayerObj) {
    					layerToQuery.LayerObj.setVisibility(true);
    					layerToQuery.LayerObj.zoomToLayer();
    					if (layerToQuery.Shapes) {
    						$.each(layerToQuery.Shapes, lang.hitch(this, function (index, shape) {
    							this.ShapesArray.push(shape);
    						}));
    					}
    				} else {

    					var indexOfLayer = this.map.graphicsLayerIds.indexOf("EditLayer");
    					var predefinedZoneLayer = new PredefinedZoneLayer({
    						coreMap: this.map,
    						layerId: layerToQuery.LayerId,
    						fillColor: layerToQuery.FillColor,
    						order: indexOfLayer,
    						isDisplay: false
    					});

    					predefinedZoneLayer.name = layerToQuery.LayerName;
    					layerToQuery.LayerObj = predefinedZoneLayer;

    					predefinedZoneLayer.on("layerLoaded", lang.hitch(this, function (e) {
    						if (!e.graphics) {
    							console.log("There was error loading shapes");
    							return;
    						}
    						layerToQuery.Shapes = [];
    						var id = 1;
    						$.each(e.graphics, lang.hitch(this, function (index, graphic) {
    							graphic.id = id;
    							var graphicObj = { Name: graphic.attributes["NAME"], Selected: ko.observable(false), Id: id++, graphicObj: graphic };
    							this.selectGraphicsFromGeotarget(graphicObj);
    							this.ShapesArray.push(graphicObj);
    							layerToQuery.Shapes.push(graphicObj);
    						}));
    						predefinedZoneLayer.zoomToLayer();
    						this.rearrangeInternalLabelLayer(layerId);
    					}));
    					predefinedZoneLayer.on("selectComplete", lang.hitch(this, function (graphicObj) {
    						if (this.geoTargetLayer.isEditing) {
    							this.geoTargetLayer.endEdit();
    						}
    						this.geotargetMap.model.drawinfo(null);
    						for (var i = 0; i < this.ShapesArray().length; i++) {
    							var item = this.ShapesArray()[i];
    							if (item.Id === graphicObj.graphic.id) {
    								item.Selected(!item.Selected());
    								if (item.Selected()) {
    									this.selectShape(graphicObj.graphic);
    								} else
    									this.deselectShape(graphicObj.graphic);
    								break;
    							}
    						}
    					}));
    				}
    			}
    		},

    		selectGraphicsFromGeotarget: function (inputGraphic) {
    			$.each(this.geoTargetLayer.getNonEditLayerGraphics(), lang.hitch(this, function (index, graphic) {
    				if (graphic.attributes.OBJECTID && inputGraphic.graphicObj.attributes.OBJECTID
							&& inputGraphic.graphicObj.attributes.OBJECTID === graphic.attributes.OBJECTID) {
    					inputGraphic.Selected(true);
    					this.selectShape(inputGraphic.graphicObj);
    				}
    			}));
    		},

    		shapeSelectionChanged: function (e, item) {
    			this.selectShapeById(e.Id, e.Selected);
    			return true;
    		},

    		selectShapeById: function (shapeid, selected) {
    			var layerExist = $.grep(this.SelectableLayersArray(), lang.hitch(this, function (e) {
    				return (this.SelectedLayer() !== -1 && e.LayerId === this.SelectedLayer());
    			}));
    			if (layerExist && layerExist.length > 0) {
    				var layerShapes = layerExist[0].LayerObj.graphics;
    				var shapeExist = $.grep(layerShapes, function (e) {
    					return (e.id === shapeid);
    				});
    				if (shapeExist && shapeExist.length > 0) {
    					var selectedShape = shapeExist[0];
    					if (selected()) {
    						this.selectShape(selectedShape);
    					} else {
    						this.deselectShape(selectedShape);
    					}
    				}
    			}
    		},

    		deselectShape: function (shape) {
    			if (!shape) return;
    			var dojoShape = shape.getDojoShape();
    			if (dojoShape) {
    				dojoShape.moveToBack();
    			}
    			shape.setSymbol(this.getDeselectionSymbol(shape.symbol.color));
    			var id = shape.getLayer().id + "_" + shape.id;
    			this.geoTargetLayer.removeNoneEditableGraphic(id);

    		},

    		selectShape: function (shape) {
    			if (!shape) return;
    			var dojoShape = shape.getShape();
    			if (dojoShape) {
    				dojoShape.moveToFront();
    			}
    			var selectedSymbol = this.getSelectionSymbol(shape.symbol.color);
    			shape.setSymbol(selectedSymbol);
    			var graphic = new Graphic(shape.toJson());
    			graphic.attributes.status = "add";
    			graphic.attributes.id = shape.getLayer().id + "_" + shape.id;
    			graphic.attributes.color = shape.symbol.color;
    			graphic.attributes.border = shape.symbol.outline.color;
    			var layerExist = $.grep(this.SelectableLayersArray(), lang.hitch(this, function (e) {
    				return (this.SelectedLayer() !== -1 && e.LayerId === this.SelectedLayer());
    			}));
    			if (layerExist && layerExist.length > 0) {
    				graphic.attributes["layername"] = layerExist[0].LayerName;
    			}
    			if (!this.geoTargetLayer.isNoneEditableGraphicExist(graphic.attributes.id))
    				this.geoTargetLayer.addNoneEditableGraphic(graphic);

    		},
    		setSelectionSymbol: function (featureLayer) {
    			if (!featureLayer) return;
    			featureLayer.setSelectionSymbol(symbol);
    		},

    		getSelectionSymbol: function (fillColor) {
    			var borderColor = Color.fromHex("#00ffff");
    			var symbol = new SimpleFillSymbol(SimpleFillSymbol.STYLE_SOLID,
				new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID, borderColor, 3), fillColor);
    			return symbol;
    		},

    		getDeselectionSymbol: function (fillColor) {
    			var borderColor = Color.fromHex("#000000");
    			var symbol = new SimpleFillSymbol(SimpleFillSymbol.STYLE_SOLID,
                new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID, borderColor, 1), fillColor);
    			return symbol;
    		},


    		callbackLayerMetadata: function (data) {
    			if (!data || !data.Success || !data.Data) {
    				console.log("Failed to get selectablelayermetadata");
    				return;
    			}
    			this.SelectableLayersArray.splice(1);
    			var count = data.Data.length;
    			for (var i = 0; i < count; i++) {
    				this.SelectableLayersArray.push(data.Data[i]);
    			}
    		},


    	});
    	return customLocation;
    }
);