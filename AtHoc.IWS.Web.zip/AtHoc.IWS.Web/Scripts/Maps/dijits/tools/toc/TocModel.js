﻿//each layer has
//1. name string
//2. setVisibility function
//3. visible ko.observable(bool)
//4. enabled ko.observable(bool)

define(
    ["dojo/_base/declare", "dojo/_base/array", "dojo/dom-style"],
    function(declare, array, domStyle) {
        var TocModel = declare("athoc.dijits.toc.TocModel", null, {
            i18n:{},
            constructor: function(layers) {
                this.layers = ko.observableArray(layers);
            }
        });
        return TocModel;
    });