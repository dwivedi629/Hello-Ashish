﻿define([
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/array",
"dojo/query",
"dojo/dom-construct",
"dijit/_WidgetBase",
"dijit/_TemplatedMixin",
"dojo/Evented",
"dojo/dom-style",
"dojo/text!maps/dijits/tools/basemap/basemapTemplate.html",
"esri/dijit/BasemapGallery",
"esri/dijit/Basemap",
"esri/dijit/BasemapLayer",
"maps/dijits/tools/_ToolBase"
],
function (declare, lang, array, query, domConstruct, _WidgetBase, _TemplatedMixin, Evented, domStyle, template, BasemapGallery, Basemap, BasemapLayer, _ToolBase) {
    var Basemap = declare("athoc.dijits.tools.Basemap", [_WidgetBase, _TemplatedMixin, Evented, _ToolBase], {
        templateString: template,
        name: "baseLayerHolder",
        title: "Base Map1",
        options: { map: null },
        i18n:{},
        constructor: function (options, srcRefNode) {
            //common code for tool
            this.domNode = srcRefNode;
            this.options = options;
            this.visible = options.visible == undefined ? true : options.visible;
            this._esriMap = options.map;
            this.i18n = options.i18n;
            this.culture = options.culture;
        },

        startup: function () {
            //common code for tool
            this.inherited(arguments);
            if (!this.visible) {
                this.hide();
            }
            //$("#baseLayer").text(this.i18n.Map_BaseMap);
            $('#baseLayer').append("<span title='"+ this.i18n.Map_BaseMap +"'></span>");
            var basemaps = [];
            var basemapRoad = new Basemap({
                layers: [new BasemapLayer({
                    type: "BingMapsRoad"
                })],
                //id: "bmRoad",
                title: this.i18n.Map_BaseMap_BingRoad,
                thumbnailUrl: "/athoc-cdn/Images/bing-map-tile-road.png"
            });
            basemaps.push(basemapRoad);
            var basemapAerial = new Basemap({
                layers: [new BasemapLayer({
                    type: "BingMapsAerial"
                })],
                //id: "bmAerial",
                title: this.i18n.Map_BaseMap_BingAerial,
                thumbnailUrl: "/athoc-cdn/Images/bing-map-tile-aerial.png"
            });
            basemaps.push(basemapAerial);

            var basemapGallery = new BasemapGallery({
                showArcGISBasemaps: true,
                map: this._esriMap,
                basemaps: basemaps,
                bingMapsKey: "Au1W2UTppQzyntvpMpRrNODG0bF6l1rBca6AI3toH6MqxVkjKgecZoxPdokOO9Hj",
                culture: this.culture,
            }, query(".esriBasemapHolder", this.domNode)[0]);
            basemapGallery.startup();
            basemapGallery.on("load", function() {
                //move those two bing maps basemap to the top
                var bingRoadDomNode = query("div[id^='galleryNode_athoc_dijits_tools_Basemap_']", this.domNode)[0];
                domConstruct.place(bingRoadDomNode, bingRoadDomNode.parentNode, 0);
                var bingAerialDomNode = query("div[id^='galleryNode_athoc_dijits_tools_Basemap_']", this.domNode)[1];
                domConstruct.place(bingAerialDomNode, bingAerialDomNode.parentNode, 1);
                var bingRoadBasemapId = basemapGallery.basemaps[basemapGallery.basemaps.length - 2].id;
                basemapGallery.select(bingRoadBasemapId);
            	//remove USGS National map JIRA:IWS-20441
                $("#galleryNode_basemap_0",this.domNode).remove();
            });
            basemapGallery.on("selection-change", lang.hitch(this, function() {
                var basemap = basemapGallery.getSelected();
                var basemapName;
                switch (basemap.title) {
                    case "Imagery":
                    case "Bing Aerial":
                        basemapName = "satellite";
                        break;
                    case "Imagery with Labels":
                        basemapName = "hybrid";
                        break;
                    case "Streets":
                        basemapName = "streets";
                        break;
                    case "Oceans":
                        basemapName = "oceans";
                        break;
                    case "Topographic":
                    case "USA Topo Maps":
                    case "Bing Road":
                        basemapName = "topo";
                        break;
                    case "Dark Gray Canvas":
                        basemapName = "dark-gray";
                        break;
                    case "Light Gray Canvas":
                        basemapName = "gray";
                        break;
                    case "National Geographic":
                    case "USGS National Map":
                        basemapName = "national-geographic";
                        break;
                    case "Terrain with Labels":
                        basemapName = "terrain";
                        break;
                    case "OpenStreetMap":
                        basemapName = "osm";
                        break;
                }
                this._esriMap.basemapName = basemapName;
                this.emit("selectionChange", { name: basemap.title });
            }));
        },

        activate: function () {
        },

        deactivate: function () {
        },

        show: function () {
            domStyle.set(this.domNode, {
                display: "block"
            });
        },

        hide: function () {
            domStyle.set(this.domNode, {
                display: "none"
            });
        }
    });
    return Basemap;
}
);