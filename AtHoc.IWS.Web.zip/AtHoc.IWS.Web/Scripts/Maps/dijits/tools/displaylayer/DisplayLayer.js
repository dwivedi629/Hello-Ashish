﻿define([
"dojo/_base/declare",
"esri/layers/FeatureLayer", 
"dojo/_base/lang", 
"esri/request", 
"dojo/Evented", 
"dojo/_base/array",
"esri/layers/LabelLayer",
"esri/symbols/SimpleFillSymbol",
"esri/symbols/SimpleLineSymbol",
"esri/symbols/TextSymbol",
"esri/Color", 
"esri/renderers/SimpleRenderer",
"esri/geometry/Extent",
"maps/util",
"dojo/_base/json",
"esri/symbols/Font",
"dojo/text!maps/dijits/tools/displaylayer/displayLayerTemplate.html",
"dijit/_WidgetBase",
"dijit/_TemplatedMixin",
"dojo/Evented",
"maps/dijits/tools/_ToolBase",
"dojo/dom-style" ,
"maps/layers/PredefinedZoneLayer",
"maps/layers/OrgLayer",
"maps/layers/IncomingAlertsLayer",
"maps/layers/AcctEventsLayer",
"maps/layers/AlertsLayer",
"maps/layers/_LayerBase",
"maps/layers/InfowindowContentProvider",
"lib/helper"
],
function (declare, FeatureLayer, lang, request, Evented, array, LabelLayer,
    SimpleFillSymbol, SimpleLineSymbol, TextSymbol, Color, SimpleRenderer, Extent, util, dojoJson,
    Font, template, _WidgetBase, _TemplatedMixin, Evented, _ToolBase, domStyle, PredefinedZoneLayer, OrgLayer, IncomingAlertsLayer, AcctEventsLayer, AlertsLayer, LayerBase, InfowindowContentProvider) {
    var fc = {
        "layerDefinition": {
            "currentVersion": 10.21,
            "id": 3,
            "name": "states",
            "type": "Feature Layer",
            "description": "Predefined zones for geotargeting selection\n",
            "geometryType": "esriGeometryPolygon",
            "copyrightText": "",
            "parentLayer": null,
            "subLayers": [],
            "minScale": 0,
            "maxScale": 0,
            "drawingInfo": {
                "renderer": {
                    "type": "simple",
                    "symbol": {
                        "type": "esriSFS",
                        "style": "esriSFSSolid",
                        "color": [0, 0, 0, 0],
                        "outline": {
                            "type": "esriSLS",
                            "style": "esriSLSSolid",
                            "color": [0, 0, 0, 255],
                            "width": 2
                        }
                    },
                    "label": "",
                    "description": ""
                },
                "transparency": 0,
                "labelingInfo": null
            },
            "defaultVisibility": true,
            "extent": {
                "xmin": -178.21759836267427,
                "ymin": 18.9217863446641,
                "xmax": -66.96927103622932,
                "ymax": 71.40623536706858,
                "spatialReference": {
                    "wkid": 4269,
                    "latestWkid": 4269
                }
            },
            "hasAttachments": false,
            "htmlPopupType": "esriServerHTMLPopupTypeNone",
            "displayField": "NAME",
            "typeIdField": null,
            "fields": [{
                "name": "OBJECTID",
                "type": "esriFieldTypeOID",
                "alias": "OBJECTID",
                "domain": null
            }, {
                "name": "Shape",
                "type": "esriFieldTypeGeometry",
                "alias": "Shape",
                "domain": null
            }, {
                "name": "NAME",
                "type": "esriFieldTypeString",
                "alias": "NAME",
                "length": 25,
                "domain": null
            }],
            "relationships": [],
            "canModifyLayer": true,
            "canScaleSymbols": false,
            "hasLabels": false,
            "capabilities": "Data,Map,Query",
            "maxRecordCount": 1000,
            "supportsStatistics": true,
            "supportsAdvancedQueries": true,
            "supportedQueryFormats": "JSON, AMF",
            "ownershipBasedAccessControlForFeatures": {
                "allowOthersToQuery": true
            },
            "useStandardizedQueries": true
        },
        "featureSet": {
            "geometryType": "esriGeometryPolygon",
            "features": []
        }
    };

    var DisplayLayer = declare("athoc.dijits.tools.DisplayLayer", [_WidgetBase, _TemplatedMixin, Evented, _ToolBase], {
        templateString: template,
        name: "displayLayerHolder",
        title: "Display Layers",
        options: { map: null },
        i18n: {},
        displayLayersArr: null,
        constructor: function(options, srcRefNode) {
            //common code for tool
            this.domNode = srcRefNode;
            this.options = options;
            //this.visible = options.visible == undefined ? true : options.visible;
            this._esriMap = options.map;
            this.i18n = options.i18n;
            this.culture = options.culture;
            this.displayLayersArr = ko.observableArray([]);
            this.updatedTime = ko.observable();
            this.viewMode = options.viewMode;
            this.showIncomingAlertsLayer = options.visibleLayers && options.visibleLayers.incomingAlertsLayer;
            this.showAlertsLayer = options.visibleLayers && options.visibleLayers.alertsLayer;
            this.showAcctEventLayer = options.visibleLayers && options.visibleLayers.acctEventLayer;
            this.showSubVPSAccEventsLayer = options.visibleLayers && options.visibleLayers.subVPSAccEventsLayer;
            this.showOrgLayer = options.visibleLayers && options.visibleLayers.orgLayer;

            this.enabledLayers = options.enabledLayers;
        },

        startup: function () {
            ko.applyBindings(this, this.domNode);
            //common code for tool
            this.inherited(arguments);
            if (!this.visible) {
                this.hide();
            }
            $('#displayLayer').append("<span title='" + this.i18n.Map_Layers + "'></span>");
            $(".layer-name").text(this.i18n.Map_LayerName);
            $(".show-in-map").text(this.i18n.Map_ShowInMap);
            this._init();
        },

        _init: function(data) {
           $.ajax({
                url: "/athoc-iws/maplayers/GetDisplayOnlyLayersMetadata",
                async: false,
                cache: false,
                success: $.proxy(function (response) {
                    this._callback(response);
                }, this),
                error: function (jqxhr, textStatus, errorThrown) {
                    AjaxUtility().ajaxPostOptions.error(jqxhr, textStatus, errorThrown);
                }
           });
        },

        _callback:function(data) {
            if (!data || !data.Success || !data.Data) {
                console.log("Failed to get displaylayermetadata");
                return;
            }
            var count = data.Data.length;
            this.displayLayersArr.removeAll();

            this.autoRefreshTimer = 0;
            this.infowindowProvider = InfowindowContentProvider({
                coreMap: this._esriMap,
                i18n: this.i18n,
            });
            
            $.ajax({
                url: "/athoc-iws/maplayers/GetLayerDisplayPermissions",
                async: false,
                cache: false,
                success: $.proxy(function (permissions) {
                    if (permissions.viewPAEvent) {
                        this.setAccEventsLayer(count + 1);
                        if (permissions.isEnterprise && permissions.viewSubVPSEventsLayer) {
                            this.setSubVPSAccEventsLayer(count + 1);
                        }
                    }
                    
                    if (permissions.viewAlert) {
                         this.setAlertsLayer(count + 2);
                    }
                    //this.setEventAlertsLayer(count + 2);
                    if (permissions.viewIncomingAlert) {
                        this.setIncomingAlertsLayer(count + 3);
                    }
                    if (permissions.viewOrg) {
                        this.setOrganizationLayer(count + 4);
                    }
                }, this)
            });
            
            for (var i = 0; i < count; i++) {
                var item = data.Data[i];
                item.SortOrder = count - i;
                item.enabled = true;
                item.Visible = ko.observable(false);
                item.count = ko.observable(0);
                var modifiedTransparency = new Color(item.FillColor);
	            modifiedTransparency.a = 0.3;
	            item.ComputedFillColor = modifiedTransparency.toCss(true);
                this.displayLayersArr.push(item);
            }

        },

        createLayer: function (order, options) {
            var self = this;
            var layerCount = 0;
            var layer = new LayerBase({
                coreMap: this._esriMap,
                order: order,
                layer: options,
                i18n: this.i18n,
                infowindowProvider: this.infowindowProvider
            });
            options.LayerObj = layer;
            options.LayerObj.layers = [];
            options.enabled = layer.enabled(options.enabled);
            options.count = ko.observable(0);
            options.Visible = ko.observable(options.Visible);
            this.displayLayersArr.push(options);
            layer.timeLastUpdated.subscribe(function (time) {
                self.updatedTime(time);
                $('.livemap-refresh-icon').removeClass('animate');
            });
            
            return layer;
        },
        
        setOrganizationLayer:function(order) {
            var layer = {
                id: "OrgLayer",
                LayerName: this.i18n.Map_Layer_Organizations,
                LayerId: -4,
                Visible: false,
                templateId:"infowindow-org-template",
                url: "/athoc-iws/maplayers/GetOrganizations"
            };
            this.orgLayer = this.createLayer(order, layer);
            this.orgLayer.setVisibility(layer.Visible());
        },

        setIncomingAlertsLayer:function(order) {
            var layer = {
                LayerName: this.i18n.Map_Layer_Incoming_Alerts,
                id: "IncomingAlertLayer",
                LayerId: -3,
                FillColor: "#FF0000",
                BorderColor: "#FF0000",
                templateId: "infowindow-incoming-alert-template",
                url: "/athoc-iws/maplayers/GetLiveIncomingAlerts"
            };
            layer.Visible = this.enabledLayers ? this.enabledLayers[layer.id] : true;
            this.incomingAlertsLayer = this.createLayer(order, layer);
            this.incomingAlertsLayer.setVisibility(layer.Visible());
        },

        setAlertsLayer: function (order) {
            var layer = {
                LayerName: this.i18n.Map_Layer_Alerts,
                id: "AlertLayer",
                LayerId: -2,
                FillColor: "rgba(255, 0, 0, 0.3)",
                BorderColor: "#FF0000",
                templateId:"infowindow-layer-template",
                url: "/athoc-iws/maplayers/GetAlerts"
            };
            layer.Visible = this.enabledLayers ? this.enabledLayers[layer.id]: true;
            this.alertsLayer = this.createLayer(order, layer);
            this.alertsLayer.setVisibility(layer.Visible());
        },

        setEventAlertsLayer: function (order) {
            var layer = {
                LayerName: this.i18n.Map_Layer_Event_Alerts,
                id: "EventAlertLayer",
                LayerId: -2,
                FillColor: "rgba(255, 0, 0, 0.3)",
                BorderColor: "#FF0000",
                templateId:"infowindow-layer-template",
                url: "/athoc-iws/maplayers/GetAlerts",
                isSubLayer: true,
                urlContent: {
                    getEventAlert: true
                }
            };
            layer.Visible = this.enabledLayers ? this.enabledLayers[layer.id] : true;
            this.eventAlertsLayer = this.createLayer(order, layer);
            this.eventAlertsLayer.setVisibility(layer.Visible());
            this.alertsLayer.layers.push(layer);
        },

        setAccEventsLayer: function (order) {
            var layer = {
                id: "AcctEventLayer",
                LayerName: this.i18n.Map_Layer_Acct_Events,
                LayerId: -1,
                FillColor: "rgba(251, 255, 0, 0.3)",
                BorderColor: "#FF0000",
                templateId: "infowindow-layer-template",
                url: "/athoc-iws/maplayers/GetEvents"
            };
            layer.Visible = this.enabledLayers ? this.enabledLayers[layer.id] : true;
            this.acctEventsLayer = this.createLayer(order, layer);
            this.acctEventsLayer.setVisibility(layer.Visible());
        },

        setSubVPSAccEventsLayer: function (order) {
            var self = this;
            var layer = {
                id: "SubVPSAcctEventLayer",
                LayerName: this.i18n.Map_Layer_Sub_Vps_Acct_Events,
                LayerId: -1,
                FillColor: "rgba(251, 255, 0, 0.3)",
                BorderColor: "#FF0000",
                //isSubLayer: true,
                templateId: "infowindow-layer-template",
                url: "/athoc-iws/maplayers/GetEvents",
                urlContent: {
                    includeSubVps: true
                }
            };
            layer.Visible = this.enabledLayers ? this.enabledLayers[layer.id] : true;
            this.subVPSAcctEventsLayer = this.createLayer(order, layer);
            this.subVPSAcctEventsLayer.setVisibility(layer.Visible());
            //this.acctEventsLayer.layers.push(layer);
        },

        hideAllLayers: function () {
            var count = this.displayLayersArr().length;
            for (var i = 0; i < count; i++) {
                var displayLayer = this.displayLayersArr()[i];
                if (displayLayer.Visible() && displayLayer.LayerName !== 'Organizations' ) {
                    if (displayLayer.LayerObj) {
                        displayLayer.LayerObj.setVisibility(false);
                    }
                    this.displayLayersArr()[i].Visible(false);
                }
            }
            //this._init();
        },

        refreshAllLayers: function () {
            var count = this.displayLayersArr().length;
            clearTimeout(this.autoRefreshTimer);
            for (var i = 0; i < count; i++) {
                var displayLayer = this.displayLayersArr()[i];
                if (displayLayer.LayerObj && typeof displayLayer.LayerObj.refresh == 'function') {
                    displayLayer.LayerObj.refresh();
                }
            }
            this.autoRefreshLayers();
        },

        autoRefreshLayers: function () {
            var self = this;
            var count = this.displayLayersArr().length;
            this.autoRefreshTimer = setTimeout(function () {
                for (var i = 0; i < count; i++) {
                    var displayLayer = self.displayLayersArr()[i];
                    if (displayLayer.LayerObj && typeof displayLayer.LayerObj.refresh == 'function') {
                        displayLayer.LayerObj.refresh();
                    }
                }
                self.autoRefreshLayers();
            }, 1 * 60 * 1000);
        },

        zoomToVisibleGraphics: function() {
            var count = this.displayLayersArr().length;
            var extent = null;
            for (var i = 0; i < count; i++) {
                var displayLayer = this.displayLayersArr()[i];
                if (displayLayer.Visible()) {
                    if (displayLayer.LayerObj.graphics.length > 0) {
                        var layerExtent = esri.graphicsExtent(displayLayer.LayerObj.graphics);
                        extent = extent == null ? new Extent(layerExtent) : extent.union(layerExtent);
                    }
                }
            }
            this._esriMap.setExtent(extent, true);
        },

        /*this heck is implemented in order to not obtruct selection layer*/
        _rearrangeInternalLabelLayer: function () {
            var internalLabelLayer = $("g").filter("#_internal_LabelLayer_layer")[0];
            internalLabelLayer = $(internalLabelLayer).detach();
            var nonEditLayer = $("g").filter("#NonEditLayer_layer")[0];
             $(nonEditLayer).after(internalLabelLayer);
        },

        layerVisibilityClicked :function(data) {
            //console.log(data);
            
            if (data.LayerObj) {
                var subLayers = data.LayerObj.layers;
                data.LayerObj.setVisibility(data.Visible());
                if (subLayers && subLayers.length > 0) {
                    for (var i = 0; i < subLayers.length; i++) {
                        subLayers[i].LayerObj.setVisibility(data.Visible());
                        subLayers[i].Visible(data.Visible());
                    }
                }
            } else {
                if (data.LayerId > 0) {
                    var predefinedZoneLayer = new PredefinedZoneLayer({
                        coreMap: this._esriMap,
                        layerId: data.LayerId,
                        fillColor: data.FillColor,
                        order: 0,
                        isDisplay:true
                    });
                    predefinedZoneLayer.name = data.LayerName;
                    predefinedZoneLayer.count = data.count;
                    data.LayerObj = predefinedZoneLayer;
                    predefinedZoneLayer.on("layerLoaded", lang.hitch(this, function (e) {
                        this._rearrangeInternalLabelLayer();
                    }));
                    
                }
            }
            
            return true;
        },

        zoomToLayerClicked: function (data) {
            if (data.LayerObj) {
                data.LayerObj.zoomToLayer();
            }
        },

       

        activate: function () {
        },

        deactivate: function () {
        },

        show: function () {
            domStyle.set(this.domNode, {
                display: "block"
            });
        },

        hide: function () {
            domStyle.set(this.domNode, {
                display: "none"
            });
        }
    });
    return DisplayLayer;
}
);