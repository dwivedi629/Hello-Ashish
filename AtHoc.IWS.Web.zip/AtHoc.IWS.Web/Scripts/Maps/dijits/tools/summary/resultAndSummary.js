﻿define(
["dojo/_base/declare",
    "dojo/_base/lang",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "dojo/Evented",
    "dojo/text!maps/dijits/tools/summary/resultAndSummaryTemplate.html",
    "dojo/query",
    "esri/Color",
    "maps/dijits/TargetResult"
],
    function (declare, lang, _WidgetBase, _TemplatedMixin, Evented, template, query, Color, TargetResult) {
    	var resultAndSummary = declare("athoc.dijits.summary", [_WidgetBase, _TemplatedMixin, Evented], {
    		templateString: template,
    		options: { map: null },
    		map: null,
    		i18n: {},
    		geoTargetLayer: null,
    		constructor: function (options, srcRefNode) {
    			this.options = options;
    			this.map = options.map;
    			this.geoTargetLayer = options.geoTargetLayer;
    			this.customGraphics = ko.observableArray();
    			this.predefinedGraphics = ko.observableArray();
    			var isTargeting = this.geoTargetLayer.isTargeting ;
    			this.isTargeting = ko.observable(isTargeting);
    			this.isTargetingUser = ko.observable(true);
    			this.isTargetingOrg = ko.observable(true);
    			this.targetRelationship = ko.observable();
    			this.canTargetUser = ko.observable(true);
    			this.canTargetOrg = ko.observable(true);
    			this.userCount = 0;
    			this.orgCount = 0;
    			this.isDirty = ko.observable(false);


    			//this.viewMode = options.viewMode,
    			this.domNode = srcRefNode;
    			this.i18n = options.i18n;

    			this.geoTargetLayer.on("isTargetingChange", lang.hitch(this, function (e) {
    				this.isTargeting(e.isTargeting);
    			}));
    			this.geoTargetLayer.on("canTargetUserChange", lang.hitch(this, function (e) {
    				this.canTargetUser(e.canTarget);
    			}));
    			this.geoTargetLayer.on("canTargetOrgChange", lang.hitch(this, function (e) {
    				this.canTargetOrg(e.canTarget);
    			}));

    			this.geoTargetLayer.on("editableGraphicAdd", lang.hitch(this, function (e) {
    				this.addCustomGraphic(e.graphic);
    			}));

    			this.geoTargetLayer.on("noneEditableGraphicAdd", lang.hitch(this, function (e) {
    				this.addPredefinedGraphic(e.graphic);
    			}));


    			this.geoTargetLayer.on("noneEditableGraphicRemove", lang.hitch(this, function (e) {
    				this.removePredefinedGraphic(e.id);
    			}));

    			//graphicRemove only happens when the editable layer removes a graphic since noneeditablelayer cannot remove graphic directly other than close the pill
    			this.geoTargetLayer.on("graphicRemove", lang.hitch(this, function (e) {
    				this.removeCustomGraphic(e.graphic);
    			}));


    			this.geoTargetLayer.on("clear", lang.hitch(this, function () {
    				this.customGraphics.removeAll();
    				this.predefinedGraphics.removeAll();
    			}));

    			this.geoTargetLayer.on("userTargetComplete", lang.hitch(this, function (e) {
    				this.userCount = e.selectedUsers;
    				this.isDirty(false);
    			}));
    			this.geoTargetLayer.on("orgTargetComplete", lang.hitch(this, function (e) {
    				this.orgCount = e.selectedOrgs;
    				this.isDirty(false);
    				
    			}));


    			this.geoTargetLayer.on("targetAbort", lang.hitch(this, function (e) {
    				if (!e.graphics || e.graphics.length === 0) {
    					this.userCount = 0;
    					this.orgCount = 0;
    				}
    				this.isDirty(false);
    			}));
    			this.geoTargetLayer.on("editEnd", lang.hitch(this, function (e) {
    				this.isDirty(true);
    			}));


    		},

    		_sortPredefinedGraphic: function () {
    			this.predefinedGraphics.sort(function (a, b) {
				    if (a.attributes.layername && b.attributes.layername) {
					    if (a.attributes.layername.toLowerCase() === b.attributes.layername.toLowerCase()) {
						    if (a.attributes.NAME.toLowerCase() > b.attributes.NAME.toLowerCase()) {
							    return 1;
						    } else if (a.attributes.NAME.toLowerCase() < b.attributes.NAME.toLowerCase()) {
							    return -1;
						    } else {
							    return 0;
						    }
					    } else if (a.attributes.layername.toLowerCase() < b.attributes.layername.toLowerCase())
						    return -1;
					    else
						    return 1;
				    } else {
					      if (a.attributes.NAME.toLowerCase() > b.attributes.NAME.toLowerCase()) {
							    return 1;
						    } else if(a.attributes.NAME.toLowerCase() < b.attributes.NAME.toLowerCase()) {
							    return -1;
							} else {
							    return 0;
							}
				    }
			    });
    		},

    		addPredefinedGraphic: function (graphic) {
    			this.isDirty(true);
    			var esriColor = new Color(graphic.symbol.color);
    			graphic.color = esriColor.toHex();
    			this.predefinedGraphics.push(graphic);
    			this._sortPredefinedGraphic();
    			this.updateSummaryHeader();
    		},

    		removePredefinedGraphic: function (id) {
    			this.isDirty(true);
    			this.predefinedGraphics.remove(function (item) {
    				return item.attributes.id === id;
    			});
    			this.updateSummaryHeader();
    		},

    		removeAllPredefinedGraphic: function () {
    			this.predefinedGraphics.removeAll();
    		},
    		removePredefinedGraphicClick: function (graphic) {
    			this.isDirty(true);
    			this.removePredefinedGraphic(graphic.attributes.id);
    			this.geoTargetLayer.removeNoneEditableGraphic(graphic.attributes.id);
    		},

    		addCustomGraphic: function (graphic) {
    			this.isDirty(true);
    			this.customGraphics.push(graphic);
    			this.updateSummaryHeader();
    		},

    		removeCustomGraphicLayer: function () {
    			this.isDirty(true);
    			this.customGraphics.removeAll();
    			this.geoTargetLayer.endEdit();
    			this.geoTargetLayer.clearEditLayer();
    			this.updateSummaryHeader();
    		},

    		removeCustomGraphic: function (graphic) {
    			this.isDirty(true);
    			this.customGraphics.remove(graphic);
    			//this.geoTargetLayer.removeEditableGraphic(graphic);
    			this.updateSummaryHeader();
    		},

    		updateSummaryHeader: function () {
    			if (this.targetResult) {
    				this.targetResult.setTotalSelectedLocations(this.predefinedGraphics().length + this.customGraphics().length);
    			}
    			this.SummaryWidgetHeaderSub(this._getSummaryHeader(this.predefinedGraphics().length, this.customGraphics().length));
    		},

    		updateTargetHeader: function () {
    		},

    		onCalculate: function (e, evt) {
    			evt.stopPropagation();
    			this.geoTargetLayer.target();
				//heck to call adjustsize of map to prevent drawing graphics offset
			    $(window).trigger('resize');
		    },

			
    		startup: function () {
    			this.SummaryWidgetHeader = this.i18n.Map_LocationSummary;
    			this.SummaryWidgetHeaderSub = ko.observable(this._getSummaryHeader(0, 0));
    			this.TargetByLocationWidgetHeader = this.i18n.Map_TargetByLocation;
			    
    			ko.applyBindings(this, this.domNode);


    			try {
    				var panelBar = $(".summary-accord").kendoPanelBar({
    				}).data("kendoPanelBar");
    				var li = $("#targetResult",this.domNode);
				    panelBar.expand(li);

			    } catch (error) {

    			}

    			//initialize TargetByLocations widget
    			//targetResult dijit
    			this.targetResult = new TargetResult({
    				geoTargetLayer: this.geoTargetLayer,
    				visible: true,
    				i18n: this.i18n,
    			}, query(".targetResultHolder", this.domNode)[0]);
    			this.targetResult.startup();

    			this.updateSummaryHeader();

    			this.isDirty.subscribe($.proxy(function (newValue) {
    				this.targetResult.model.isDirty(newValue);
    			}),this);
    		},

    		_getSummaryHeader: function (predefinedCount, customCount) {
    			return kendo.format(this.i18n.Map_LocationSummarySub, customCount, predefinedCount);
    		},

    		_getTargetHeader: function (userCount, orgCount) {
    			return kendo.format(this.i18n.Map_TargetByLocationSub, userCount, orgCount);
    		},

    		setIsTargetingUser: function (isTargetingUser) {
    			this.targetResult.model.isTargetingUser(isTargetingUser);
    		},

    		setIsTargetingOrg: function (isTargetingOrg) {
    			this.targetResult.model.isTargetingOrg(isTargetingOrg);
    		},

    		setIsTargetRelationship: function (targetRelationship) {
    			this.targetResult.setTargetRelationship(targetRelationship);
    		},

    		getIsTargetingOrg: function () {
    			return this.targetResult.model.isTargetingOrg();
    		},

    		getIsTargetingUser: function () {
    			return this.targetResult.model.isTargetingUser();

    		}


    	});
    	return resultAndSummary;
    }
);