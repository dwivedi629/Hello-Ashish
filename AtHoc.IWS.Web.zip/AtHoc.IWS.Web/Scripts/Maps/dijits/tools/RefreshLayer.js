﻿define([
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "dojo/Evented",
    "dojo/dom-style",
    "dojo/text!maps/dijits/tools/refreshLayer/template.html",
    "maps/dijits/tools/refreshLayer/model"],
    function (declare, lang, _WidgetBase, _TemplatedMixin, Evented, domStyle, template, Model) {
        var refreshLayer = declare("athoc.dijits.tools.RefreshLayer", [_WidgetBase, _TemplatedMixin, Evented], {
            templateString: template,
            options: { map: null },
            map: null,
            i18n: {},
            constructor: function (options, srcRefNode) {
                this.options = options;
                this.map = options.map;
                this.domNode = srcRefNode;
                this.i18n = options.i18n;
                this.culture = options.culture;
                this.model = new Model({
                    i18n: options.i18n
                });
            },

            startup: function () {
                this.inherited(arguments);
                ko.applyBindings(this.model, this.domNode);
                this.show();
            },

            refreshLayers: function () {
                $('.livemap-refresh-icon').addClass('animate');
                this.map.refreshAllLayers();
            },

            activate: function () {
            },

            deactivate: function () {
            },

            show: function () {
                domStyle.set(this.domNode, {
                    display: "block"
                });
            },

            hide: function () {
                domStyle.set(this.domNode, {
                    display: "none"
                });
            }

        });
        return refreshLayer;
    }
);