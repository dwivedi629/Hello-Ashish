﻿define(
["dojo/_base/declare", "dojo/_base/array"],
function (declare, array) {
    var DrawingModel = declare("athoc.dijits.tools.DrawingModel", null, {
        constructor: function () {
            //this.area = ko.observable();//area info moves to toolbar model
            this.disableDelete = ko.observable(true);
            this.i18n = ko.observableArray([]);

        }
    });
    return DrawingModel;
});