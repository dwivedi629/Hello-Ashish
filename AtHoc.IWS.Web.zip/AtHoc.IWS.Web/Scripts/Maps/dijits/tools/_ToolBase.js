﻿define(
["dojo/_base/declare",
"dojo/_base/lang"],
function(declare) {
    var _ToolBase = declare('athoc.dijits.tools._ToolBase', null, {
        setToolbar: function(toolbar) {
             this.toolbar = toolbar;
        }
    });

    return _ToolBase;
});