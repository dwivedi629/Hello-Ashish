﻿//when geotargetlayer gets update/add/remove, the result update accordingly
//constructor takes geotargetlayer and listens to the targetcomplete event

define(
["dojo/_base/declare", "dojo/_base/lang", "dijit/_WidgetBase", "dijit/_TemplatedMixin", "dojo/Evented", "dojo/text!maps/dijits/targetResult/TargetResultTemplate.html", "maps/dijits/targetResult/TargetResultModel"],
    function (declare, lang, _WidgetBase, _TemplatedMixin, Evented, template, Model) {
        var TargetResult = declare("athoc.dijits.TargetResult", [_WidgetBase, _TemplatedMixin, Evented], {
            templateString: template,
            options: { geoTargetLayer: null },
            geoTargetLayer: null,
            model: null,
            constructor: function (options, srcRefNode) {
                if (!options) {
                    options = {};
                }
                this.options = options;
                this.geoTargetLayer = options.geoTargetLayer;
                this.visible = options.visible ? true : false;
                var isTargeting = this.geoTargetLayer.isTargeting;
                this.model = new Model({ isTargeting: isTargeting });
                this.model.visible(this.visible);
                this.model.i18n = options.i18n;
               
                this.geoTargetLayer.on("isTargetingChange", lang.hitch(this, function (e) {
                    this.isTargeting = e.isTargeting;
                    this.model.isTargeting(e.isTargeting);
                }));
                this.geoTargetLayer.on("canTargetUserChange", lang.hitch(this, function (e) {
                    this.canTargetUser = e.canTarget;
                    this.model.canTargetUser(e.canTarget);
                }));
                this.geoTargetLayer.on("canTargetOrgChange", lang.hitch(this, function (e) {
                    this.canTargetOrg = e.canTarget;
                    this.model.canTargetOrg(e.canTarget);
                }));
                this.domNode = srcRefNode;
               
                //listen to the events
                //show spinner
                this.geoTargetLayer.on("userTargetStart", lang.hitch(this, function (e) {
                    this.model.selectedUsers("...");
                }));
                this.geoTargetLayer.on("orgTargetStart", lang.hitch(this, function (e) {
                    this.model.selectedOrgs("...");
                }));
                //update the result
                this.geoTargetLayer.on("userTargetComplete", lang.hitch(this, function(e) {
                    this.model.selectedUsers(e.selectedUsers);
                }));
                this.geoTargetLayer.on("orgTargetComplete", lang.hitch(this, function (e) {
                    this.model.selectedOrgs(e.selectedOrgs);
                }));

               

                //remove all pills and numbers
                this.geoTargetLayer.on("clear", lang.hitch(this, function () {
                    this.model.selectedUsers(0);
                    this.model.selectedOrgs(0);
                   
                }));

                this.geoTargetLayer.on("targetAbort", lang.hitch(this, function (e) {
                    if (!e.graphics || e.graphics.length === 0) {
                        this.model.selectedUsers(0);
                        this.model.selectedOrgs(0);
                    }
                }));
            },

            startup: function() {
                this.inherited(arguments);
                ko.applyBindings(this.model, this.domNode);
            },

            destoy: function() {
                this.inherited(arguments);
            },

            setTargetRelationship: function(targetRelationship) {
                this.model.targetRelationship(targetRelationship);
            },

            setTotalSelectedLocations:function(selectedLocationCount) {
                this.model.totalSelectedLocations(selectedLocationCount);
            }
           
        });
        return TargetResult;
    }
);