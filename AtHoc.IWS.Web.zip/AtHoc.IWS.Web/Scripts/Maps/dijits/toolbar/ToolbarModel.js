﻿//toolbar hosts tools
//tool item needs to implements properties:
//1. domNode
//2. name
//3. deactivate: could be empty function. function to stop the tool. e.g. drawing tool should be stopped once it's toggled off.

define(
["dojo/_base/declare", "dojo/_base/array", "dojo/dom-style"],
    function (declare, array, domStyle) {
        var ToolbarModel = declare("athoc.dijits.toolbar.ToolbarModel", null, {
            //tools: null,
            options: {tools: []},
            constructor: function (options) {
                this.tools = ko.observableArray();
                this.options = options;
                //this.tools = tools;
                array.forEach(options.tools, function (item) {
                    this.tools.push(item);
                }, this);
                this.info = ko.observable();
            },

            toggle: function (e) {
                var tool = e;
                var toolbar = tool.toolbar;
                //deactivate all other tools
                array.forEach(toolbar.tools, function (item) {
                    if (item != tool) {
                        domStyle.set(item.domNode, {
                            display: "none"
                        });
                        item.visible = false;
                        item.deactivate();
                    }
                });
                //deactivate
                if (tool.visible === true) {
                    tool.deactivate();
                    tool.visible = false;
                    domStyle.set(tool.domNode, {
                        display: "none"
                    });
                    return;
                }
                //activate
                if (tool.visible === false) {
                    tool.visible = true;
                    domStyle.set(tool.domNode, {
                        display: "block"
                    });
                    return;
                }
            },

            activate: function (tool) {
                //show this tool
                domStyle.set(tool.domNode, {
                    display: "block"
                });
            },

            deactivate: function (tool) {
                tool.deactivate();
                domStyle.set(tool.domNode, {
                    display: "none"
                });
            },

            deactivateAll: function () {
                array.forEach(this.tools, function (item) {
                    domStyle.set(item.domNode, {
                        display: "none"
                    });
                    item.deactivate();
                });
            }
        });
        return ToolbarModel;
    }
);