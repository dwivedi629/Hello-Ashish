﻿define([
    "dojo/_base/declare",
    "dojo/_base/lang",
    "maps/util",
    "dojo/_base/array",
    "esri/map",
    "esri/symbols/SimpleFillSymbol",
    "esri/symbols/SimpleLineSymbol",
    "esri/symbols/PictureMarkerSymbol",
    "esri/Color"
],
    function (declare, lang, util, array, Map,
        SimpleFillSymbol, SimpleLineSymbol, PictureMarkerSymbol, Color) {
        var MiniMap = declare("athoc.maps.MiniMap", null, {
            constructor: function (options, srcRefNode) {
                if (!options) {
                    options = {};
                }
                this.options = options;
                if (options.width && options.height) {
                    this.size = { width: options.width, height: options.height };
                } else {
                    this.size = { width: 447, height: 200 };
                }
                this._esriMap = new Map(srcRefNode, {
                    basemap: "streets",
                    nav: false,
                    slider: false
                });

                this._esriMap.isPan = false;
                this._esriMap.isPanArrows = false;
                this._esriMap.isClickRecenter = false;
                this._esriMap.isDoubleClickZoom = false;
                this._esriMap.isKeyboardNavigation = false;
                this._esriMap.isRubberBandZoom = false;
                this._esriMap.isScrollWheelZoom = false;
                this._esriMap.isZoomSlider = false;

                var container = $(this._esriMap.container);
                container.css("height", this.size.height);
                container.css("width", this.size.width);
                var mapDiv = container.children();
                mapDiv.css("height", this.size.height);
                mapDiv.css("width", this.size.width);

                this.geoJson = options.geoJson;
                if (this.geoJson) {
                    this.restore(geoJson);
                }
            },

            clear: function () {
                if (this._esriMap.graphics) {
                    this._esriMap.graphics.clear();
                }
            },

            restore: function (geoJson) {
                this.geoJson = geoJson;
                if (!this._esriMap.loaded) {
                    var mapLoadEventListener = this._esriMap.on("load", lang.hitch(this, function() {
                        this._restore(geoJson);
                        mapLoadEventListener.remove();
                    }));
                } else {
                    this._restore(geoJson);
                }
            },

            _restore: function (geoJson) {
                this.clear();
                try {
                    this._esriMap.resize(true);
                    this._esriMap.reposition();
                } catch (err) {

                }
                this.addGeoJsonLayer(geoJson);
                this.zoomToFit();
            },

            resize: function () {
                if (!this._esriMap.loaded) {
                    var mapLoadEventListener = this._esriMap.on("load", lang.hitch(this, function () {
                        this._esriMap.resize(true);
                        mapLoadEventListener.remove();
                    }));
                } else {
                    this._esriMap.resize(true);
                }
            },

            addGeoJsonLayer: function(geoJson) {
                this.geoJson = geoJson;
                if (!geoJson || !geoJson.features || geoJson.features.length === 0) {
                    return;
                }
                var graphic, symbol,
                    features = geoJson.features;
                array.forEach(features, function (item) {
                    switch (item.geometry.type.toLowerCase()) {
                        case "polygon":
                        case "multipolygon":
                            if (item.properties && item.properties.isInbound) {
                                symbol = new SimpleFillSymbol(SimpleFillSymbol.STYLE_SOLID,
                                    new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID,
                                        Color.fromHex("#FF0000"), 2), new Color([255, 0, 0, 0.3]));
                            } else {
                                symbol = new SimpleFillSymbol(SimpleFillSymbol.STYLE_SOLID,
                                    new SimpleLineSymbol(SimpleLineSymbol.STYLE_SOLID,
                                        Color.fromHex("#8564a6"), 2), new Color([133, 100, 166, 0.35]));
                            }
                            break;
                        case "point":
                            if (item.properties && item.properties.symbol && item.properties.symbol.url) {
                                symbol = new PictureMarkerSymbol(item.properties.symbol.url, 32, 32);
                                symbol.setOffset(item.properties.symbol.width / 4, item.properties.symbol.height*3/8);
                            } else {
                                symbol = new PictureMarkerSymbol("/athoc-cdn/images/GreenShinyPin.png", 32, 32);
                            }
                    }
                    graphic = util.convertGeoJsonFeatureToGraphic(item, {symbol: symbol});
                    this._esriMap.graphics.add(graphic);
                }, this);
                this.graphics = this._esriMap.graphics.graphics;
            },

            zoomToFit: function () {
                var graphics = this.graphics,
                    extent;
                if (graphics && graphics.length > 0) {
                    extent = esri.graphicsExtent(graphics);
                    extent.xmin -= extent.getWidth() / 2 || 5000;
                    extent.xmax += extent.getWidth() / 2 || 5000;
                    extent.ymin -= extent.getHeight() / 2 || 5000;
                    extent.ymax += extent.getHeight() / 2 || 5000;
                    this._esriMap.setExtent(extent);
                }
            },

            setBasemap: function (basemapName) {
                if (!this._esriMap.loaded) {
                    var mapLoadEventListener = this._esriMap.on("load", lang.hitch(this, function () {
                        this._esriMap.setBasemap(basemapName);
                        mapLoadEventListener.remove();
                    }));
                } else {
                    this._esriMap.setBasemap(basemapName);
                }
            }
        });

        return MiniMap;
    }
);