﻿define(["dojo/_base/declare", "dojo/_base/lang"],
function (declare, lang) {
    var GeoTargetMapModel = declare("athoc.maps.GeoTargetMapModel", null, {
        i18n:{},
        constructor: function() {
            this.applyEnabled = ko.observable(true);
            this.viewMode = ko.observable();
            this.drawinfo = ko.observable();
            this.info = ko.observable();
            this.isModal = ko.observable();
        }
    });
    return GeoTargetMapModel;
});