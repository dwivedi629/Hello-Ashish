﻿define([
"dojo/_base/lang",
"dojo/_base/array",
"maps/terraformerArcgisParser",
"esri/tasks/PrintTask",
"esri/tasks/PrintParameters",
"esri/tasks/PrintTemplate",
"esri/geometry/webMercatorUtils",
"esri/graphic",
"esri/symbols/SimpleFillSymbol",
"esri/symbols/SimpleMarkerSymbol",
"esri/geometry/geodesicUtils",
"esri/geometry/Polyline",
"esri/units"
],
function (lang, array, terraformerArcgisParser, PrintTask, PrintParameters, PrintTemplate, webMercatorUtils, Graphic,
    SimpleFillSymbol, SimpleMarkerSymbol, geodesicUtils, Polyline, units) {
    var generateStaticMap = function (map) {
        var printTask = new PrintTask(window.location.protocol + "//utility.arcgisonline.com/arcgis/rest/services/Utilities/PrintingTools/GPServer/Export%20Web%20Map%20Task");
            
        var printTemplate = new PrintTemplate();
        printTemplate.exportOptions = {
            width: 400,
            height: 200,
            dpi: 96
        };
        printTemplate.format = "JPG";
        printTemplate.layout = "MAP_ONLY";
        printTemplate.preserveScale = false;
        printTemplate.showAttribution = false;

        var printParams = new PrintParameters();
        printParams.map = map._esriMap;
        printParams.template = printTemplate;

        return printTask.execute(printParams);
    };

    var convertGraphicToGeoJsonFeature = function (graphic, options) {
        if (!options) {
            options = {};
        }
        if (options.isWebMercator !== false) {
            options.isWebMercator = true;
        }
        var symbol = options.symbol,
            wgsGeometry, graphicJson = graphic.toJson();
        if (options.isWebMercator) {
            wgsGeometry = webMercatorUtils.webMercatorToGeographic(graphic.geometry).toJson();
            graphicJson.geometry = wgsGeometry;
        }
        return terraformerArcgisParser.parse(graphicJson);
    };

    var convertToGeoJson = function (graphics, options) {
        var features = [];
        array.forEach(graphics, function (item) {
            features.push(convertGraphicToGeoJsonFeature(item, options));
        });

        var geoJson = {
            type: "FeatureCollection",
            features: features
        };
        
        return geoJson;
    };

    var convertGeoJsonFeatureToGraphic = function (feature, options) {
        if (!options) {
            options = {};
        }
        if (options.isWebMercator !== false) {
            options.isWebMercator = true;
        }
        var graphicJson = terraformerArcgisParser.convert(feature),
            graphic = new Graphic(graphicJson),
            symbol;

        if (options.isWebMercator) {
            graphic.setGeometry(webMercatorUtils.geographicToWebMercator(graphic.geometry));
        }

        if (options.symbol) {
            symbol = options.symbol;
        } else {
            switch (graphic.geometry.type) {
            case "polygon":
                symbol = new SimpleFillSymbol();
                break;
            case "point":
                symbol = new SimpleMarkerSymbol();
                break;
            }
        }
        graphic.setSymbol(symbol);
        
        return graphic;
    };

    var convertToGraphics = function (geoJson, options) {
        var features = geoJson.features;
        var graphics = [];
        array.forEach(features, function(item) {
            graphics.push(convertGeoJsonFeatureToGraphic(item, options));
        });
        
        return graphics;
    };

    var getDistance = function(ptA, ptB) {
        //assume it's web mercator, and only two points
        var polylineJson = {
            "paths": [[[ptA.x, ptA.y], [ptB.x, ptB.y]]],
            "spatialReference": { "wkid": 3857 }
        };

        var polyline = new Polyline(polylineJson);
        polyline = webMercatorUtils.webMercatorToGeographic(polyline);
        return geodesicUtils.geodesicLengths([polyline], units.METERS)[0];
    };

    var util = {
        generateStaticMap: generateStaticMap,
        convertToGeoJson: convertToGeoJson,
        convertToGraphics: convertToGraphics,
        convertGeoJsonFeatureToGraphic: convertGeoJsonFeatureToGraphic,
        convertGraphicToGeoJsonFeature: convertGraphicToGeoJsonFeature,
        getDistance: getDistance
    };
    return util;
});