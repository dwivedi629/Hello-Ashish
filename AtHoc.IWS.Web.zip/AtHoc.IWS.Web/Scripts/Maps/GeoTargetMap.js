﻿//each one of the maps in the system should have a specific map object
//the result is this would give the caller one line of code to create every thing
//for this geoTargetMap, the requirements are:
//1. geocoding
//2. drawing, editing
//3. print/export as a static image
//4. spatial query
//5. toc of layers

define([
    "dojo/Evented",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/has", // feature detection
    "esri/kernel", // esri namespace
    "dijit/_WidgetBase",
    "dijit/a11yclick", // Custom press, release, and click synthetic events which trigger on a left mouse click, touch, or space/enter keyup.
    "dijit/_TemplatedMixin",
    "dojo/on",
    "dojo/Deferred",
    "dojo/text!maps/geoTargetMap/GeoTargetMapTemplate.html",
    "maps/geoTargetMap/GeoTargetMapModel",
    //"dojo/i18n!application/nls/jsapi", // localization
    "dojo/dom-class",
    "dojo/dom-style",
    "dojo/query",
    "esri/map",
    "esri/dijit/Geocoder",
    "esri/dijit/Scalebar",
    "esri/request",
    "esri/geometry/Extent",
    "esri/dijit/BasemapToggle",
    "maps/layers/GeoTargetLayer",
    "maps/layers/PredefinedZoneLayer",
    "maps/layers/OrgLayer",
    "maps/layers/BoundaryLayer",
    "maps/layers/IncomingAlertsLayer",
    "maps/dijits/tools/Drawing",
    "maps/dijits/tools/Toc",
    "maps/dijits/tools/Basemap",
    "maps/dijits/tools/RefreshLayer",
    "maps/dijits/Toolbar",
    //"maps/dijits/TargetResult",
    "maps/dijits/HomeAndFit",
    "maps/util",
    "dojo/_base/array",
    "maps/dijits/tools/displaylayer/DisplayLayer",
    "maps/dijits/tools/locations/customLocation",
    "maps/dijits/tools/summary/resultAndSummary",
    "esri/geometry/Point",
	"esri/symbols/PictureMarkerSymbol",
	"esri/virtualearth/VETiledLayer",
    "esri/SpatialReference"
],
function (
    Evented,
    declare,
    lang,
    has, esriNS,
    _WidgetBase, a11yclick, _TemplatedMixin,
    on,
    Deferred,
    template, Model,
    domClass, domStyle,
    query,
    Map,
    Geocoder,
    Scalebar,
    request,
    Extent,
    BasemapToggle,
    GeoTargetLayer,
    PredefinedZoneLayer,
    OrgLayer,
    BoundaryLayer,
    IncomingAlertsLayer,
    Drawing,
    Toc,
    Basemap,
    RefreshLayers,
    Toolbar,
   // TargetResult,
    HomeAndFit,
    util,
    array,
    DisplayLayer,
    CustomLocation,
    ResultAndSummary,
    Point,
	PictureMarkerSymbol,
	veTileDLayer,
	spatialRef
) {
	var GeoTargetMap = declare("athoc.maps.GeoTargetMap", [_WidgetBase, _TemplatedMixin, Evented], {
		templateString: template,
		options: {},
		//properties
		homeExtent: null,
		geoTargetLayer: null,
		isTargeting: true,
		isTargetingUser: true,
		isTargetingOrg: true,
		constructor: function (options, srcRefNode) {
			if (!options)
			{
				options = {};
				options.isTargeting = true;
			}
			this.isTargeting = (options.isTargeting === false) ? false : true;
			this.viewMode = options.viewMode ? true : false;
			this.isModal = (options.isModal !== undefined) ? options.isModal : true;
			if (this.viewMode)
			{
				this.isTargeting = false;
			}
			//this.isTargeting = false;
			this.options = options;
			//regardless if srcRefNode is a string or domNode, this.domNode is always a domNode after startup. Dojo dijits convert it automatically
			this.domNode = srcRefNode;
			this.model = new Model();
			this.model.i18n = options.i18n;
			this.model.viewMode(this.viewMode);
			this.model.isModal(this.isModal);
		},

		startup: function () {
			this.inherited(arguments);
			ko.applyBindings(this.model, this.domNode);
			this.init();
			//deactivate editing when clicking anywhere on the map
			on(this.domNode, "click", lang.hitch(this, function (e) {
				this.model.drawinfo(null);
				if (this.geoTargetLayer && this.geoTargetLayer.isEditing) {
					this.geoTargetLayer.endEdit();
				}
				//hide the widgets only if button for displayLayer and baseLayer are not clicked
				if (!$.contains($(this.domNode).find(".display-layer-container")[0], e.target))
				{
					$(".content-display-layer").hide();
					$(".content-basemap").hide();
				}

			}));

			this._esriMap = new Map(query(".mapHolder", this.domNode)[0], {autoResize: false,
				showLabels : true,
				spatialReference: new spatialRef({wkid: 4326})
			});
			
			var  veTileLayer = new esri.virtualearth.VETiledLayer({
				bingMapsKey: 'Au1W2UTppQzyntvpMpRrNODG0bF6l1rBca6AI3toH6MqxVkjKgecZoxPdokOO9Hj',
			    mapStyle: esri.virtualearth.VETiledLayer.MAP_STYLE_ROAD,
			    culture: this.options.culture,
			});

			this._esriMap.addLayer(veTileLayer);

			//layers
			var predefinedZoneLayer = {};
			var orgLayer = {};

			//scalebar dijit
			var scalebar = new Scalebar({
				map: this._esriMap,
				scalebarUnit: "dual",
				attachTo: "scalebar_bottom-center"
			});

			var tools = [];

			//basemap tool
			var basemap = new Basemap({
				map: this._esriMap,
				visible: false,
				i18n: this.i18n,
				culture: this.options.culture,
			}, query(".basemapToggleHolder", this.domNode)[0]);
			basemap.startup();
			tools.push(basemap);

			this.displaylayer = new DisplayLayer({
				map: this._esriMap,
				visible: false,
				i18n: this.i18n,
				culture: this.options.culture,
				viewMode: this.viewMode,
				visibleLayers: this.options.visibleLayers,
                enabledLayers: this.options.enabledLayers
			}, query(".displayToggleHolder", this.domNode)[0]);
			this.displaylayer.startup();
			orgLayer = this.displaylayer.orgLayer;
			this.incomingAlertsLayer = this.displaylayer.incomingAlertsLayer;
			tools.push(this.displaylayer);
			this.displaylayer.updatedTime.subscribe(lang.hitch(this, "updatedRefreshLayers"));

			this.refreshLayers = new RefreshLayers({
			    map: this,
			    i18n: this.i18n,
			    culture: this.options.culture
			}, query(".refreshLayersHolder", this.domNode)[0]);
			this.refreshLayers.startup();
			this.refreshAllLayers();

		    //initialize geotarget layer
			this.geoTargetLayer = this._setUpGeoTargetLayer(predefinedZoneLayer, orgLayer);
			this.geoTargetLayer.name = this.i18n.Map_Layer_Target_Areas;

			//toolbar
			this.toolbar = new Toolbar({
				tools: tools
			}, query(".toolbarHolder", this.domNode)[0]);
			this.toolbar.startup();

			if (!this.viewMode)
			{

				//initialize customlocation widget
				this.customLocation = new CustomLocation({
					geoTargetLayer: this.geoTargetLayer,
					map: this._esriMap,
					visible: false,
					i18n: this.i18n,
					geotargetMap:this
				}, query(".location-holder", this.domNode)[0]);
				//set up the area and radius info dom
				this.customLocation.startup();
				//this.customLocation.setInfoModel(this.toolbar.model.info);

				//initialize summary widget
				this.resultAndSummary = new ResultAndSummary({
					geoTargetLayer: this.geoTargetLayer,
					map: this._esriMap,
					visible: false,
					i18n: this.i18n,
				}, query(".summary-holder", this.domNode)[0]);
				this.resultAndSummary.startup();

				this.resultAndSummary.customGraphics.subscribe($.proxy(function (newValue) {
					this.model.applyEnabled(newValue.length > 0 || this.resultAndSummary.predefinedGraphics().length > 0);
				}), this);
				this.resultAndSummary.predefinedGraphics.subscribe($.proxy(function (newValue) {
					this.model.applyEnabled(newValue.length > 0 || this.resultAndSummary.customGraphics().length > 0);
				}), this);

			} else
			{
				//hide the container widget
				$(".location-container").hide();
				$(".summary-container").hide();
			}

			//geocoder dijit
			this.geocoder = new Geocoder({
				autoNavigate: true, // do not zoom to best result
				highlightLocation: true,
				zoomScale: 10,
				maxLocations: 20, // increase number of results returned
				map: this._esriMap,
				autoComplete: true,
				arcgisGeocoder: {
					url: window.location.protocol + "//geocode.arcgis.com/arcgis/rest/services/World/GeocodeServer",
					name: "Esri World Geocoder",
					placeholder: this.i18n.Map_Search_Placeholder
				},
				symbol: new PictureMarkerSymbol("/athoc-cdn/scripts/lib-vendor/esri/javascript/esri/dijit/images/sdk_gps_location.png", 28, 28)
			}, query(".geocoderHolder", this.domNode)[0]);

			this.geocoder.startup();
			this.geocoder.focus();
			
			$(".simpleGeocoder .esriGeocoder input", this.domNode).keydown(function(e) {
				$(".esriGeocoderSearch.esriGeocoderIcon").css('display', 'none');
			});

			$(".simpleGeocoder .esriGeocoder input", this.domNode).keyup(lang.hitch(this,function (e) {
				this.geocoder._autoComplete();
				
			}));

			this.geocoder.on("find-results", lang.hitch(this, function (results) {
				$(".esriGeocoder .esriGeocoderReset.esriGeocoderIcon", this.domNode).attr('title', this.i18n.Map_Search_Clear_Tooltip);
				if (results.results.results.length == 0)
				{
					//this.toolbar.model.info("We could not find it");
					this.model.info(this.i18n.Map_Location_NotFound_Message);
				} else
				{
					this.model.info(null);
				}

			}));
			this.geocoder.on("clear", lang.hitch(this, function (results) {
				this.model.info(null);
				$(".esriGeocoderSearch.esriGeocoderIcon").css('display', 'block');
			}));
			this.geocoder.on("auto-complete", lang.hitch(this, function (results) {
				$(".esriGeocoder .esriGeocoderReset.esriGeocoderIcon", this.domNode).attr('title', this.i18n.Map_Search_Clear_Tooltip);
				this.model.info(null);
			}));

			$(".simpleGeocoder .esriGeocoder input", this.domNode).click(lang.hitch(this,function () {
				$(".esriGeocoder .esriGeocoderReset.esriGeocoderIcon", this.domNode).attr('title', this.i18n.Map_Search_Clear_Tooltip);
			}));

			this.geocoder.on("select", lang.hitch(this, function (results) {
				$(".esriGeocoder .esriGeocoderReset.esriGeocoderIcon", this.domNode).attr('title', this.i18n.Map_Search_Clear_Tooltip);
			}));

			this.geocoder.on("geocoder-select", lang.hitch(this, function (results) {
				$(".esriGeocoder .esriGeocoderReset.esriGeocoderIcon", this.domNode).attr('title', this.i18n.Map_Search_Clear_Tooltip);
			}));

			$(".simpleGeocoder .esriGeocoder input", this.domNode).focus(lang.hitch(this, function () {
				$(".esriGeocoder .esriGeocoderReset.esriGeocoderIcon", this.domNode).attr('title', this.i18n.Map_Search_Clear_Tooltip);
			}));

			//make the geocoder large
			$(".esriGeocoder", this.domNode).css("width", "300px");
			$(".esriGeocoderResults", this.domNode).css("width", "300px");
			$(".simpleGeocoder .esriGeocoder input", this.domNode).css("width", "260px");
			$(".esriGeocoder .esriGeocoderReset.esriGeocoderIcon", this.domNode).attr('title', this.i18n.Map_Search_Clear_Tooltip);
			this.geocoder.focus();

			//homeandfit dijit
			var homeAndFit = new HomeAndFit({
				map: this, i18n: this.i18n,
			}, query(".homeAndFitHolder", this.domNode)[0]);
			homeAndFit.startup();
			//responsive adjust the height
			$(window).resize(lang.hitch(this, function () {
				this.adjustSize(this.domNode);
			}));
			this.firstUse = false;
			$(this.domNode).on('shown.bs.modal', lang.hitch(this, function (e, ev) {
				if (this.firstUse) {
					if (this.viewMode) {
						this.zoomToIncomingAlerts();
					} else if (!this._firstShow) {
						this.zoomToFit();
					}
				}
				this.firstUse = true;
				
			}));

			this.swapEsriLogoAndContent();
		},

		destroy: function () {
			this.inherited(arguments);
		},

		_processGeoJson: function (geoJson) {
			this.geoTargetLayer.clear();
			var graphic;
			array.forEach(geoJson.features, function (item) {
				graphic = util.convertGeoJsonFeatureToGraphic(item);
				if (item.properties && item.properties.status !== "add")
				{
					graphic.attributes.status = "existing";
				}
				if (!item.properties || item.properties.editable || item.properties.editable == undefined)
				{
					this.geoTargetLayer.addEditableGraphic(graphic);
				} else
				{
					this.geoTargetLayer.addNoneEditableGraphic(graphic);
				}
			}, this);
		},

		swapEsriLogoAndContent:function() {
			var esriAttribution = $('.esriControlsBR', this.domNode);
			var attributionElement = $(esriAttribution).children().first();
			$(attributionElement).detach().appendTo(esriAttribution);
			//remove logo to disable hyperlink of esri website. Re-add the logo after loading map
			$(".logo-sm, .logo-med", esriAttribution).remove();
		},
		show: function (params) {
			if (params == null || (!params.isNewMap))
			{
				this.toolbar.closeAllTools();
			}

			
			$("body").css("overflow", "hidden");//disable the scrollbar on the main page, in order to make the infowindow and zoom action correct.
			if (params && params.targetRelationship)
			{
				this.targetRelationship = params.targetRelationship;
			} else
			{
				this.targetRelationship = "inside";
			}
			if (this.resultAndSummary)
			{
				this.resultAndSummary.setIsTargetingUser(this.isTargetingUser);
				this.resultAndSummary.setIsTargetingOrg(this.isTargetingOrg);
				this.resultAndSummary.setIsTargetRelationship(this.targetRelationship);
			}

			//Below line giving error when bigger map loaded on demand 
			//Todo: 22/03/2016 - need to check error and solve it
			//done for IWS-17793 ->IWS-17839

			var mapLoadedHandler = this._esriMap.on("load", $.proxy(function () {
				setTimeout($.proxy(function () {
					this.adjustSize(this.domNode);
					this._esriMap.resize(true);
					this.zoomToFit();
				}, this), 1000);
				var esriAttribution = $('.esriControlsBR', this.domNode);
				$("<div class='esri-logo-med'></div>").prependTo(esriAttribution);
				mapLoadedHandler.remove();
			}, this));


			var mapresizeHandler = this._esriMap.on("resize", $.proxy(function (obj) {
				if (obj.width === 0 || obj.height === 0)
				{
					this.adjustSize(this.domNode);
				}
				setTimeout($.proxy(function () {
					this.zoomToFit();
				}, this), 500);
				mapresizeHandler.remove();
			}, this));

			if (this.isModal) {
			    $(this.domNode).modal("show");
            }
			this.adjustSize(this.domNode);
			
			//this._esriMap.width = $(".mapHolder").width();
			//this._esriMap.height = $(".mapHolder").height();

			this.geoTaregetLayerJson = this.geoTargetLayer.toJson();
			//everytime map shows, it needs to query again to get the latest result
			this.geoTargetLayer.setTargetRelationship(this.targetRelationship);
			this.geoTargetLayer.target();
			this.toolbar.model.info(null);
		},

		zoomToFit: function () {
			var geoTargetGraphics = this.geoTargetLayer.getSelectedGraphics(),
                graphics,
                extent;
			if (this.viewMode && this.incomingAlertsLayer && this.incomingAlertsLayer.graphics && this.incomingAlertsLayer.graphics.length > 0) {
				this.zoomToIncomingAlerts();
				return;
			}
			if ((geoTargetGraphics && geoTargetGraphics.length > 0))
			{
				graphics = geoTargetGraphics;
				extent = esri.graphicsExtent(graphics);
				//it not always zoom out to the extent where convers all graphics due to the ratio of the map
				//if there is only one point in the graphics, it should add 100meters box
				//extent.xmin -= extent.getWidth() / 2 || 5000;
				//extent.xmax += extent.getWidth() / 2 || 5000;
				//extent.ymin -= extent.getHeight() / 2 || 5000;
				//extent.ymax += extent.getHeight() / 2 || 5000;
				extent = extent.expand(3);
				this._esriMap.setExtent(extent);
			} else
			{
                //Check if homeextent object is not null then only check for center
			    if (this.homeExtent && this.homeExtent.center)
				{
					this._esriMap.centerAndZoom(this.homeExtent.center, this.homeExtent.zoom);
				}
			}
		},

		zoomToIncomingAlerts: function () {
			var eventGraphics = this.incomingAlertsLayer.graphics;
			if (eventGraphics && eventGraphics.length > 0)
			{
				this.incomingAlertsLayer.zoomToLayer();
			} 
		},

		zoomToHome: function () {
			this._esriMap.centerAndZoom(this.homeExtent.center, this.homeExtent.zoom);
		},

		updatedRefreshLayers: function (time) {
	        this.refreshLayers.model.time(time);
		},

		refreshAllLayers: function () {
		    var self = this;
		    $.ajax({
		        type: "POST",
		        url: "/AtHoc-IWS/Account/GetLatestTimeStamp",
		        cache: false,
		        dataType: "json",
		        success: function (response) {
		            $.vpsDateFormat = response.dateFormat;
		            $.vpsDateTimeFormat = response.dateTimeFormat;

		            $.vpsTimeZone = {
		                CurrentVPSDate: new Date(response.currentDateTime),
		                Name: response.vpsTimeZone.DisplayName,
		                UtcOffsetInMinutes: response.vpsTimeZone.BaseUtcOffset.TotalMinutes,
		                VPSOffsetFromSystemInMinutes: response.VPSOffsetFromSystemInMinutes,
		                dstDelta: response.dstDelta
		            };
		            self.displaylayer.refreshAllLayers();
		        }
		    });
	    },

		adjustSize: function (domNode) {
			var pageFooterHeight = $("#pageFooter").height();
			var topMargin = 40;
			if (this.isModal) {

		        domStyle.set(domNode, {
                    "top": "25px",
		            "margin-top": "0px",
		            "margin-left": (40 - $(window).width()) / 2 + "px",
		            "width": $(window).width() - 40 + "px",
		            "height": $(window).height() - pageFooterHeight - topMargin + "px"
		        });
		        domStyle.set(query(".mapHolder", domNode)[0], {
		            width: $(window).width() - 40 + "px",
		            height: $(window).height() - pageFooterHeight - topMargin + "px"
		        });
		        if ($(".mapHolder").height()) {
		            domStyle.set(query(".modal-footer", domNode)[0], {
		                width: $(".mapHolder").width() - 28 + "px",
		                bottom: pageFooterHeight + 12 + "px",
		            });
		        }

			} else {

		        domStyle.set(domNode, {
                    "top": "0px",
		            "margin-top": "0px",
		            "width": $(window).width() + "px",
		            "height": $(window).height() + "px",
		            display: "block"
		        });
		        domStyle.set(query(".mapHolder", domNode)[0], {
		            width: $(window).width() + "px",
		            height: $(window).height() + "px"
		        });
		        
		    }

		    this._esriMap.resize();
		},

		_close: function () {
			//all the common stuff needs to clean up
			this.geocoder.clear();
			if (this.resultAndSummary)
			{
				this.isTargetingUser = this.resultAndSummary.getIsTargetingUser();
				this.isTargetingOrg = this.resultAndSummary.getIsTargetingOrg();
			}
			$("body").css("overflow", "auto");//set back the scrollbar
			//$('#' + this.id).modal('hide');
			this.emit("close", null);
		},

		close: function () {
			this._close();
			this.geoTargetLayer.endEdit();
			this.geoTargetLayer.target();
			if (this.customLocation && this.customLocation.drawing)
			{
				this.customLocation.drawing.deactivate();
			}
			this.zoomToFit();
		},

		removeTargetAreas: function () {
			this.geoTargetLayer.clear();
			if (this.resultAndSummary)
			{
				this.resultAndSummary.removeAllPredefinedGraphic();
				this.resultAndSummary.removeCustomGraphicLayer();
			}
			if (this.customLocation)
			{
				this.customLocation.removeAllLayers();
			}
			this.displaylayer.hideAllLayers();
		},

		cancel: function () {
		    this.geoTargetLayer.restoreJson(this.geoTaregetLayerJson);
		    this.geoTargetLayer.target();
			this._close();
		},

		init: function () {
			//init settings of the map. It will have config settings of layers in future
			var mapConfigDeferred = this._getMapConfig();
			mapConfigDeferred.then(lang.hitch(this, "_init"));
		},



		toGeoJson: function () {
			var geoJson = this.geoTargetLayer.toGeoJson();
			return geoJson;
		},

		setTargetable: function (targetable) {
			this.isTargeting = targetable;
			this.geoTargetLayer.setTargetable(targetable);
		},

		setUserTargetable: function (targetable) {
			this.canTargetUser = targetable;
			this.geoTargetLayer.setUserTargetable(targetable);
		},

		setOrgTargetable: function (targetable) {
			this.canTargetOrg = targetable;
			this.geoTargetLayer.setOrgTargetable(targetable);
		},

		removeLayer: function (layer) {
			//only implement remove incomingalerts layer for now
			if (layer.name = "Incoming Alerts")
			{
				if (this.incomingAlertsLayer && this.incomingAlertsLayer._esriGraphicsLayer && this._esriMap.graphicsLayerIds.indexOf(this.incomingAlertsLayer._esriGraphicsLayer.id) !== -1)
				{
					if (this._esriMap.loaded)
					{
						this._esriMap.removeLayer(this.incomingAlertsLayer._esriGraphicsLayer);
					} else
					{
						var mapLoadHandler = this._esriMap.on("load", lang.hitch(this, function () {
							mapLoadHandler.remove();
							this._esriMap.removeLayer(this.incomingAlertsLayer._esriGraphicsLayer);
						}));
					}
				}
				this.toc.removeLayer(this.incomingAlertsLayer);
			}
		},

		generateStaticMap: function () {
			return util.generateStaticMap(this);
		},

		_init: function (config) {
			//zoom to default
			var center = [config.DefaultLongitude, config.DefaultLatitude],
                zoom = config.DefaultZoomLevel;

			this.homeExtent = {
				center: center,
				zoom: zoom
			};

		},

		_setUpGeoTargetLayer: function (predefinedZoneLayer, orgsLayer) {
			var geoTargetLayer = new GeoTargetLayer({
				coreMap: this._esriMap,
				predefinedZoneLayer: predefinedZoneLayer,
				orgsLayer: orgsLayer,
				isTargeting: this.isTargeting
			});
			return geoTargetLayer;
		},

		_setUpPredefinedZoneLayer: function () {
			var predefinedZoneLayer = new PredefinedZoneLayer({
				coreMap: this._esriMap,
				abort: this.viewMode
			});
			return predefinedZoneLayer;
		},

		_getMapConfig: function () {
			return request({
				url: "/client/map/GetMapConfiguration",
				handleAs: "json"
			});
		},

		getBasemap: function () {
			return this._esriMap.basemapName;
		}
	});
	return GeoTargetMap;
});