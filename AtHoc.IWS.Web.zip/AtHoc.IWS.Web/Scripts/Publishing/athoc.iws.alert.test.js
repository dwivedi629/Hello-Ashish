﻿/* define javascript namespace for Test Alert  */
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.alert = athoc.iws.alert || {};
if (athoc.iws.alert) {
    athoc.iws.alert.test = function () {
        //
        var extraSpaceAddBlock = 55;
        return {
            //is model changed
            isChanged: false,
            IsRefered: false,
            tesDeviceList:[],
            testDevicesAddress: ko.observableArray(),
            //this method will be
            viewModel: {
                personalDeviceList: ko.observableArray(),
                
            },
            
            //called when new data will be available for this section for binding
            load: function () {             

                $("#btn_send_test_alert").click(function () {
                    athoc.iws.alert.detail.TestAlert();
                });

                $("#btn_test_alert").click(function () {
                    $("#TestAlert").show();
                    $('#alertMessagePanel').messagesPanel('reset');
                    $("#testbackshade").show();
                    athoc.iws.alert.test.resizeModalBasedOnScreen($("#TestAlert"));
                    var data = ko.mapping.toJS(athoc.iws.publishing.targetUsers.SelectedGroupedDevices().Devices);
                    

                   athoc.iws.alert.test.viewModel.personalDeviceList = ko.mapping.fromJS(athoc.iws.alert.test.formatTestDeviceList(data));
                   

                    if (athoc.iws.alert.test.viewModel.personalDeviceList().length > 0) {
                        $("#testpersonaldevicesdisplay").html("");
                        $("#testAlertMessage").css("display", "none");
                        $("#testpersonaldevicesdisplay").css("display", "");
                        ko.cleanNode($("#publishing-test-alert").get(0));
                        ko.applyBindings(athoc.iws.alert.test.viewModel, $("#testDevicesFlatList").get(0));
                    } else {
                        $("#testAlertMessage").css("display", "");
                        $("#testpersonaldevicesdisplay").css("display", "none");
                        $("#testpersonaldevicesdisplay").html("");
                    }
                    
                    athoc.iws.alert.test.enableSendAlert();

                });

                $("#btn_close_test_alert").click(function () {
                    $("#TestAlert").hide();
                    $("#testbackshade").hide();
                   
                });

                
            },
            bind: function(data) {
                athoc.iws.alert.test.testDevicesAddress(data);

            },

            enableTestAlertButton: function (flag) {

                if (flag)
                    $("#btn_test_alert").removeAttr("disabled");
                else
                    $("#btn_test_alert").attr("disabled",true);

            },

            getAddress: function (deviceId) {
                
                var filterData = ko.mapping.toJS(athoc.iws.alert.test.testDevicesAddress).filter(function (el) {
                    return el.DeviceId == deviceId;
                });

                return filterData.length > 0 ? filterData[0].Address : athoc.iws.publishing.resources.Publishing_Alert_TestAlert_Address_NotAvailable;
            },
            getModel: function (data) {
                var resultdata = [];
                var data = ko.mapping.toJS(athoc.iws.alert.test.viewModel.personalDeviceList);
                $(data).each(function (index) {
                    $(data[index].DeviceList).each(function (index2) {
                        if (data[index].DeviceList[index2].Selected)
                            resultdata.push(data[index].DeviceList[index2]);
                    });
                });

                return resultdata;
            },
            personalDeviceChanged: function (device) {
                athoc.iws.alert.test.enableSendAlert();
                return true;
            },

            enableSendAlert:function(){
                var self = this;
                var filterData = athoc.iws.alert.test.getModel();
                if (filterData != null && filterData.length>0)
                    $("#btn_send_test_alert").removeAttr("disabled");
                else
                    $("#btn_send_test_alert").attr("disabled", true);            
            },

            formatTestDeviceList: function (data) {
                var groupList = [];
                var deviceList = [];
                var list = 0;
                var groupId = 0;
                var groupName = "";
                var filterData = data;

                $(filterData).each(function (index) {
                    if (filterData[index].Selected) {
                        list++;
                        if (groupId != filterData[index].GroupId) {
                            groupId = filterData[index].GroupId;

                            if (deviceList.length > 0) {

                                groupList.push({ GroupName: groupName, DeviceList: deviceList });
                                deviceList = [];
                            }

                            filterData[index].Address = athoc.iws.alert.test.getAddress(filterData[index].DeviceId);
                            filterData[index].Enabled = true;
                            if (filterData[index].Address == athoc.iws.publishing.resources.Publishing_Alert_TestAlert_Address_NotAvailable || filterData[index].Address == "Inactive") {
                                filterData[index].Selected = false;
                                filterData[index].Enabled = false;
                            }


                            deviceList.push(filterData[index]);
                            if (filterData[index].Selected) {
                                athoc.iws.alert.test.tesDeviceList.push(filterData[index]);
                            }
                            groupName = filterData[index].GroupName;

                        } else {
                            if (filterData[index].Selected) {
                                athoc.iws.alert.test.tesDeviceList.push(filterData[index]);
                            }
                            filterData[index].Address = athoc.iws.alert.test.getAddress(filterData[index].DeviceId);
                            filterData[index].Enabled = true;
                            if (filterData[index].Address == athoc.iws.publishing.resources.Publishing_Alert_TestAlert_Address_NotAvailable || filterData[index].Address == "Inactive") {
                                filterData[index].Selected = false;
                                filterData[index].Enabled = false;
                            }
                            deviceList.push(filterData[index]);

                        }
                    }
                });
                if(list>0)
                groupList.push({ GroupName: groupName, DeviceList: deviceList });
                return groupList;

            },
            resizeModalBasedOnScreen: function (modal) {
            var extrSpace = 0;
            modal.find(".modal-body").css("max-height", 370);
            var windowHeight = $(window).height();

            if (windowHeight > 770) {
                modal.css("margin-top", 40 - (windowHeight / 2) + ((windowHeight - 770) / 2));
                modal.find(".modal-body").css("height", windowHeight - 340);
            } else {
                modal.css("margin-top", 40 - (windowHeight / 2));
                modal.find(".modal-body").css("height", windowHeight - 240);
            }

            if (modal.height() + 170 > windowHeight) {
                var newHeight = windowHeight - 170;
                modal.find(".modal-body").css("max-height", newHeight);
            }

        },
        };

    }();
}
