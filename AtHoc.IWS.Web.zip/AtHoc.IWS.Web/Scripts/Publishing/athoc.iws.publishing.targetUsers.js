﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};

if (athoc.iws.publishing) {
    athoc.iws.publishing.targetUsers = function () {
        return {
            Parameters: {},
            viewModelInstance: {},
            //Viewmodel for the Target section in readonly
            ReadonlyviewModel: {},
            SelectedGroupedDevices: function () {
                var selectedDevices = [];
                var lastGroup = '';
                if ((athoc.iws.publishing.source == null || athoc.iws.publishing.source == '') && (this.viewModelInstance.Devices!== undefined)) {
                    _.each(this.viewModelInstance.Devices(), function (item, index) {
                        if (item.Selected()) {
                            var groupChanged = false;
                            if (lastGroup != item.GroupName()) {
                                groupChanged = true;
                                lastGroup = item.GroupName();
                            }
                            var device = { DeviceId: item.DeviceId, DeviceName: item.DeviceName, GroupChange: groupChanged, GroupId: item.GroupId, GroupName: item.GroupName, HideInReadOnlyView: item.HideInReadOnlyView, Reach: item.Reach, Selected: true, CustomText: ko.observable(null) };
                            selectedDevices.push(device);
                        }
                    });
                } else {
                    if (athoc.iws.publishing.view !== undefined) {
                        _.each(athoc.iws.publishing.view.viewModel.personalDeviceList.Devices(), function (item, index) {
                            var groupChanged = false;
                            //if (lastGroup != item.GroupName) {
                            groupChanged = true;
                            lastGroup = item.GroupName;
                            var device = { DeviceId: item.DeviceId, DeviceName: item.DeviceName, GroupChange: groupChanged, GroupId: item.GroupId, GroupName: item.GroupName, HideInReadOnlyView: item.HideInReadOnlyView, Reach: item.Reach, Selected: true, CustomText: ko.observable(null) };
                            selectedDevices.push(device);
                            //}
                        });
                    }

                }

                return { Devices: selectedDevices };
            },

            SessionId: {},
            TreeIsSelected: false,
            PieDataSource: null,
            PieChartObject: null,
            //is section ready to publish
            isReadyToPublish: false,

            //is in error state
            isInErrorState: true,
            summaryDivTrmplate: "<div class=\"summary-row ellipsis\" title='{1}'>{0}</div>",
            DeviceGroupOptions: new Array(),
            presetDeviceOptions: new Array(),

            advancedQueryCriteria: null,
            treeIsLoaded: false,
            deviceOptionIsLoaded: false,
            clearingAllCriteria: false,

            setPresetDeviceOptions: function (presetDeviceGroupOptions) {
                this.presetDeviceOptions = presetDeviceGroupOptions;
            },
            bind: function (data, presetDeviceGroupOptions) {
                var self = this;
                self.advancedQueryCriteria = null;

                this.targetGroupInstance.LoadViewModel(data);

                /*
                var deliveryOrders = [1];
                if (data.MaxDelivery) {
                    for (var i = 2; i <= data.MaxDelivery; i++) {
                        deliveryOrders.push(i);
                    }
                }
                self.viewModelInstance.DeliveryOrderList = ko.observable(deliveryOrders);
                */

                if (typeof data.TargetedUserCountForLiveEndedAlert != "undefined") {
                    this.targetGroupInstance.ViewModel.set("TargetedUserCountForLiveEndedAlert", data.TargetedUserCountForLiveEndedAlert);
                }

                this.presetDeviceOptions = presetDeviceGroupOptions;
                //load query builder  

                /*$(this.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder({
                    options: this.Parameters.queryBuilderParameters
                });
                */

                var onShown = function (queryDivSelector) {
                    return function () {
                        self.viewModelInstance.numberQueryCriteria($(queryDivSelector).athocQueryBuilder("getCurrentSelections").selections.length);

                        //update contact pie chart
                        var tempCriteria = $(queryDivSelector).athocQueryBuilder("getCurrentSelections");
                        athoc.iws.publishing.detail.isQueryLoaded = true;

                        athoc.iws.publishing.targetUsers.updateContactInfo();
                        self.advancedQueryCriteria = tempCriteria;
                        if (athoc.iws.publishing.detail.viewModel.ScenarioSettings && athoc.iws.scenario) {                        
                            athoc.iws.scenario.settings.ApplysettingsOnFingerTabs(athoc.iws.publishing.detail.viewModel.ScenarioSettings.Targeting.EnabledTargetingTypes);
                        }

                        self.targetingChanged();
                    };
                }(this.Parameters.queryBuilderParameters.queryBuilderDiv);

                $(this.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder("setOnShownFunction", onShown);

                var onChanged = function (queryDivSelector) {
                    return function () {
                        self.viewModelInstance.numberQueryCriteria($(queryDivSelector).athocQueryBuilder("getCurrentSelections").selections.length);

                        //update contact pie chart
                        var tempCriteria = $(queryDivSelector).athocQueryBuilder("getCurrentSelections");

                        athoc.iws.publishing.detail.isQueryLoaded = true;
                        if (!self.isQueryCriteriaEqual(tempCriteria, self.advancedQueryCriteria) && !self.clearingAllCriteria) {
                            athoc.iws.publishing.scenario.isChanged = true;
                            athoc.iws.publishing.targetUsers.updateContactInfo();
                        }
                        self.advancedQueryCriteria = tempCriteria;

                        
                        athoc.iws.publishing.targetUsers.targetingChanged();
                    };
                }(this.Parameters.queryBuilderParameters.queryBuilderDiv);

                $(this.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder("setOnChangedFunction", onChanged);


                if (data.TargetedCriteria && data.TargetedCriteria.selections) {
                    $(this.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder("setPreselections", data.TargetedCriteria.selections);
                } else {
                    $(this.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder("setPreselections", null);
                }
                $(this.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder("show");
            },

            //helper function to compare query criteria
            isQueryCriteriaEqual: function (criteriaOne, criteriaTwo) {
                try {
                    return criteriaOne.display.join() == criteriaTwo.display.join();
                } catch (e) {
                    return true;
                }
            },

            getModel: function () {
                if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content != undefined && athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Targeting.Readonly && athoc.iws.publishing.targetUsers.isReadyToPublish && !$("#alert-user-edit").is(':visible')) {
                    var targetusersByArea = false;
                    if (athoc.iws.publishing.geo.viewModel.isGeoSelected() && athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetUsersByArea()) {
                        targetusersByArea = true;
                    }
                    return {
                        Devices: ko.mapping.toJS(athoc.iws.publishing.view.viewModel.personalDeviceList.Devices),
                        //TargetingNodes: ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetingNodes),
                        TargetingNodes: this.targetGroupInstance.ViewModel.get("SelectedNodes"),
                        TargetedCriteria: ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetedCriteria),
                        DeviceGroupOptions: this.DeviceGroupOptions, //IWS-14434: send device options in this case as well they are already set properly by client script
                        TargetedBlockedUsers: athoc.iws.publishing.view.viewModel.TargetedBlockerUsersList,
                        TargetUsersByArea: targetusersByArea
                    };

                }
                else {
                    //convert viewmodel to the format that will be set to server side with all of other sections. 
                    //this.TargetUsersViewModel.Devices([1034]);
                    var checkedDevices = ko.mapping.toJS(this.viewModelInstance.Devices()).filter(function (el) {
                        return el.Selected;
                    });
                    var targetusersByArea = false;
                    if (athoc.iws.publishing.geo.viewModel.isUsersTargeted() && athoc.iws.publishing.geo.geoJson != null) {
                        targetusersByArea = true;
                    }
                    else
                        athoc.iws.publishing.targetUsers.viewModelInstance.numberAreaCriteria(0);
                    var advanceCriteriaModel = null;
                    var advancedCriteriaSelected = (athoc.iws.publishing.settings.IsAdvancedQuerySuuported) && (this.viewModelInstance.numberQueryCriteria() > 0);
                    if (advancedCriteriaSelected) {
                        advanceCriteriaModel = $(this.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder("getCurrentSelections");
                    }
                    return {
                        Devices: checkedDevices,
                        TargetingNodes: this.targetGroupInstance.ViewModel.get("SelectedNodes"),
                        TargetedCriteria: advanceCriteriaModel,
                        DeviceGroupOptions: this.DeviceGroupOptions,
                        TargetedBlockedUsers: athoc.iws.publishing.iut.getModel(),
                        TargetUsersByArea: targetusersByArea
                    };
                }
            },

            refresh: function (entityId) {
                this.treeIsLoaded = false;
                this.deviceOptionIsLoaded = false;

                //refresh will re-initialize the view model as well as rebinding the controls
                //re-create view model
                this.targetGroupInstance.LoadViewModel();

                kendo.ui.progress($("#publishing-user-edit"), true);
                $(".alert-nav").attr("disabled", true);
                $(".severity-list").find("button").prop("disabled", true);


                athoc.iws.publishing.detail.checkStatusChange();

                //making a single ajax call to get targeting tree and device data
                var ajaxSuccessWrapper = function (context) {

                    $(".severity-list").find("button").prop("disabled", false);
                    $(".severity-list").find("button").focus();

                    return function (data) {
                        //kendo.ui.progress($("#divDevices, #divTgTree"), false); //must show now loading until device option is done loading, to meet desktop popup requirement
                        $("#treeview").show();

                        var deliveryOrders = [1];
                        if (data.PhoneCount) {
                            for (var i = 2; i <= data.PhoneCount; i++) {
                                deliveryOrders.push(i);
                            }
                        }
                        //self.viewModelInstance.DeliveryOrderList = ko.observable(deliveryOrders);
                        ko.mapping.fromJS(deliveryOrders, {}, context.viewModelInstance.DeliveryOrderList);


                        ko.mapping.fromJS(data.Devices, {}, context.viewModelInstance.Devices);
                        ko.mapping.fromJS(data.DeviceGroups, {}, context.viewModelInstance.DeviceGroups);

                        athoc.iws.publishing.targetUsers.targetGroupInstance.RefreshTreeView(data);

                        var onSave = function (selectedOptions) {
                            context.DeviceGroupOptions = selectedOptions;
                        }

                        var onLoadDone = function (selectedOptions) {
                            context.deviceOptionIsLoaded = true;
                            if (context.treeIsLoaded) { //must check to make sure both tree and device option  is loaded. 
                                $(".alert-nav").attr("disabled", false);
                            }
                            context.DeviceGroupOptions = selectedOptions;
                            kendo.ui.progress($("#publishing-user-edit"), false);

                            $(".alert-nav").attr("disabled", false);

                            
                            
                        }

                        athoc.iws.publishing.personalDeviceOptions.load(ko.mapping.toJS(context.viewModelInstance.Devices()), context.presetDeviceOptions, onSave, onLoadDone);                        
                        if (athoc.iws.publishing.detail.viewModel.ScenarioSettings && athoc.iws.scenario) {
                            athoc.iws.scenario.settings.ApplysettingsOnFingerTabs(athoc.iws.publishing.detail.viewModel.ScenarioSettings.Targeting.EnabledTargetingTypes);
                        }



                    }
                }(this);

                var targetingInfoSuccess = function (data) {
                    ajaxSuccessWrapper(data);
                    athoc.iws.publishing.detail.checkStatusChange(true);
                };

                var targetingInfoError = function (e) {
                    kendo.ui.progress($("#publishing-user-edit"), false);
                    var errorCallBack = function (returnedErrorObject) {
                        $('#listMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                    };
                }
                var param1;
                var param2;
                var param3;
                if (athoc.iws.alert == undefined) {
                    param1 = entityId;
                    param2 = "";
                    param3 = "";

                } else if (athoc.iws.alert.action == 'rbt') {
                    param1 = athoc.iws.publishing.rbt.AlertId;
                    param2 = "rbt";
                    param3 = athoc.iws.publishing.rbt.IncludeDevices == true ? 0 : athoc.iws.publishing.rbt.DeviceId;
                } else {
                    param1 = entityId;
                    param2 = "";
                    param3 = "";
                }

                var ajaxOptions = {
                    cache: false,
                    url: athoc.iws.publishing.urls.GetDeviceListUrl,
                    data: { context: this.Parameters.context, id: param1, recipientType: param2, deviceId: param3 },
                    type: "POST"
                };

                var ajaxOptions = $.extend({}, AjaxUtility(targetingInfoError, targetingInfoSuccess).ajaxPostOptions, ajaxOptions);
                $.ajax(ajaxOptions);
            },

            loadTargetUsersViewModel: function () {
                var targetVM = function (context) {
                    var self = this;
                    self.Devices = ko.observableArray();
                    self.DeviceGroups = ko.observableArray();

                    self.UsersCount = ko.observable(0);

                    self.ShowUsers = ko.observable(true);

                    self.ReachableUsers = ko.observable(0);
                    self.ReachableUsersPercentage = ko.observable(0);

                    self.UnReachableUsers = ko.observable(0);
                    self.UnReachableUsersPercentage = ko.observable(0);
                    self.numberQueryCriteria = ko.observable(0);
                    self.numberAreaCriteria = ko.observable(0);

                    self.numberOfDevices = ko.observable(0);

                    self.DeliveryOrderList = ko.observable([]);

                    self.AnyDeviceSelected = function () {
                        var checkedDevices = ko.mapping.toJS(self.Devices()).filter(function (el) {
                            return el.Selected;
                        });

                        return checkedDevices.length > 0;
                    };
                    self.toggleDeviceOptionLink = function () {
                        if (!self.AnyDeviceSelected()) {
                            $(context.Parameters.personalDeviceOptionsLink).toggleClass("link-disabled", true);
                            $("#personalDeviceOptionsLink").attr("disabled", true);
                        } else {
                            $(context.Parameters.personalDeviceOptionsLink).toggleClass("link-disabled", false);
                            $("#personalDeviceOptionsLink").attr("disabled", false);
                        }

                    };
                    self.deviceChanged = function (device) {
                        //IWS-32687 Reset first search on device selection
                        athoc.iws.publishing.detail.firstLoad = false;

                        kendo.ui.progress($("#publishing-user-edit"), true);

                        var checkedDevices = ko.mapping.toJS(context.viewModelInstance.Devices()).filter(function (el) {
                            return el.Selected;
                        });
                        $(".alert-nav").attr("disabled", true);
                        $(".severity-list").find("button").prop("disabled", true)

                        context.viewModelInstance.numberOfDevices(checkedDevices.length);

                        var onLoadDone = function (selectedOptions) {
                            kendo.ui.progress($("#publishing-user-edit"), false);
                            $(".alert-nav").attr("disabled", false);
                            $(".severity-list").find("button").prop("disabled", false);
                            context.DeviceGroupOptions = selectedOptions;
                        }

                        athoc.iws.publishing.personalDeviceOptions.loadOnlyNewDeviceGroups(checkedDevices, onLoadDone);
                        context.updateContactInfo();
                        context.targetingChanged();
                        self.toggleDeviceOptionLink();
                        athoc.iws.publishing.scenario.isChanged = true;
                        return true;
                    }

                    self.DisplayUserList = function () {
                        //alert("You have to pass sessionId to the user list  popup, which is " + context.SessionId + " For info on how to pass session Id and also get columns, pls talk to tarun.");
                        //to show readOnlyUserList
                        if (self.UsersCount() > 0) {
                            $("#readOnlyUserListTitle").html(athoc.iws.publishing.iut.resources.IUTReadOnly_AllUsers);
                            //Condition is added to ShowUsersList in readonly mode
                            athoc.iws.publishing.iut.ShowUsersList(athoc.iws.publishing.source == "readonly" ? athoc.iws.publishing.view.viewModel.data.SessionId : context.SessionId, -1, "", self.UsersCount());
                        }
                    }

                    self.GetReachableUserList = function () {
                        if (self.ReachableUsers() > 0) {
                            self.LaunchContactInfoUserList(1);
                        }
                    }

                    self.GetUnReachableUserList = function () {
                        if (self.UnReachableUsers() > 0) {
                            self.LaunchContactInfoUserList(0);
                        }
                    }

                    self.LaunchContactInfoUserList = function (covered) {
                        var checkedDevices = null;
                        if (athoc.iws.publishing.source == 'p' || athoc.iws.publishing.source == 'h') {
                            checkedDevices = ko.mapping.toJS(this.ReadonlyviewModel.Devices()).filter(function (el) {
                                return el.Selected;
                            }).map(function (item) { return item.DeviceId; });
                        }
                        else {
                            var checkedDevices = ko.mapping.toJS(self.Devices()).filter(function (el) {
                                return el.Selected;
                            }).map(function (item) { return item.DeviceId; });
                        }

                        var attributeIdCSV = checkedDevices.join(",");
                        //to show readOnlyUserList
                        if (covered == 1)
                            $("#readOnlyUserListTitle").html(athoc.iws.publishing.iut.resources.IUTReadOnly_Reachable_Users + "(" + self.ReachableUsers() + ")");
                        else
                            $("#readOnlyUserListTitle").html(athoc.iws.publishing.iut.resources.IUTReadOnly_UnReachable_Users + "(" + self.UnReachableUsers() + ")");
                        //Condition is added to display User list in readonly mode
                        var param = (athoc.iws.publishing.source == "p" || athoc.iws.publishing.source == "h") ? athoc.iws.publishing.view.viewModel.data.SessionId : context.SessionId;
                        athoc.iws.publishing.iut.ShowUsersList(param, covered, "", covered == 1 ? self.ReachableUsers() : self.UnReachableUsers());
                    }


                    self.showQuerySummary = function () {
                        if (self.numberQueryCriteria() > 0) {
                            $(context.Parameters.dialogTargetingSummary).find("#spanTitle").text(athoc.iws.publishing.iut.resources.Publishing_TargetUsers_Advanced_Query);
                            var summaryDiv = $(context.Parameters.dialogTargetingSummary).find(context.Parameters.targetingSummaryContentDiv);
                            summaryDiv.html("");
                            var selections = $(context.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder("getCurrentSelections");

                            var seletionTextArray = selections.display;

                            _.each(seletionTextArray, function (item, index) {
                                if (index != 0) {
                                    summaryDiv.append("<div class=\"summary-row summary-operator-row\">" + athoc.iws.publishing.resources.Publishing_TargetUsers_Advanced_Query_Summary_And + "</div>");
                                }

                                summaryDiv.append(context.summaryDivTrmplate.format(item, selections.displayNoStyle[index]));
                                index += 1;
                            });
                            $(context.Parameters.dialogTargetingSummary).modal("show");
                        }
                    };

                    //on number of map area clicked
                    self.showAreaSummary = function () {
                        if (self.numberAreaCriteria() > 0) {
                            //Show map with objects in model window
                            $("#dialogGeoTargetingSummary").modal("show");
                        }
                    };

                    //show selected devices list
                    self.showDeviceSummary = function () {
                        if (self.numberOfDevices() > 0) {
                            //show device summary
                            $("#personalDeviceSummaryDiv").html('');
                            ko.cleanNode($("#dialogPersonalDevicesSummary").get(0));
                            var groupedDevices = athoc.iws.publishing.targetUsers.SelectedGroupedDevices();
                            ko.applyBindings(groupedDevices, $("#dialogPersonalDevicesSummary").get(0));
                            $("#dialogPersonalDevicesSummary").modal("show");
                        }
                    };

                    self.numGroupsTargeted = ko.observable(0);
                    self.numGroupsBlocked = ko.observable(0);

                    self.showTargetedGroupSummary = function () {
                        if (self.numGroupsTargeted() > 0) {
                            $(context.Parameters.dialogTargetingSummary).find("#spanTitle").text(athoc.iws.publishing.iut.resources.Publishing_TargetUsers_ByGroups);
                            var summaryDiv = $(context.Parameters.dialogTargetingSummary).find(context.Parameters.targetingSummaryContentDiv);
                            var template = kendo.template($("#groupsummary-template").html());
                            var result = template(athoc.iws.publishing.targetUsers.targetGroupInstance.ViewModel.TargetedGroupsFormatted());
                            summaryDiv.html(result);
                            $(context.Parameters.dialogTargetingSummary).modal("show");
                        }
                    };

                    self.showBlockedGroupSummary = function () {
                        if (self.numGroupsBlocked() > 0) {
                            $(context.Parameters.dialogTargetingSummary).find("#spanTitle").text(athoc.iws.publishing.iut.resources.Publishing_TargetUsers_ByGroupsBlocked);
                            var summaryDiv = $(context.Parameters.dialogTargetingSummary).find(context.Parameters.targetingSummaryContentDiv);
                            var template = kendo.template($("#groupsummary-template").html());
                            var result = template(athoc.iws.publishing.targetUsers.targetGroupInstance.ViewModel.BlockedGroupsFormatted());
                            summaryDiv.html(result);
                            $(context.Parameters.dialogTargetingSummary).modal("show");
                        }
                    };

                    self.numTargetedUsers = ko.observable(0);

                    self.showTargetedUsersSummary = function () {
                        if (self.numTargetedUsers() > 0) {
                            athoc.iws.publishing.iut.showTargetedUsersSummary(false);
                            $("#targetedUsersSummary").find("h2").html(athoc.iws.publishing.iut.resources.Publishing_TargetUsers_ByUsers + '(' + self.numTargetedUsers() + ')');
                            $("#targetedUsersSummary").modal("show");
                        }
                    };
                    self.numBlockedUsers = ko.observable(0);

                    self.showBlockedUsersSummary = function () {
                        if (self.numBlockedUsers() > 0) {
                            athoc.iws.publishing.iut.showBlockedUsersSummary(false);
                            $("#blockedUsersSummary").find("h2").html(athoc.iws.publishing.iut.resources.Publishing_TargetUsers_ByUsersBlocked + '(' + self.numBlockedUsers() + ')');
                            $("#blockedUsersSummary").modal("show");
                        }
                    };
                };

                this.viewModelInstance = new targetVM(this);

                ko.cleanNode($("#devicesListDiv").get(0));

                ko.applyBindings(this.viewModelInstance, $("#devicesListDiv").get(0));
                ko.applyBindings(this.viewModelInstance, $("#targetUsersHeaderDiv").get(0));
                ko.applyBindings(this.viewModelInstance, $("#contactInfoSummary").get(0));
                ko.applyBindings(this.viewModelInstance, $("#targetUsersSummary").get(0));
            },

            init: function (parameters) {
                self = this;
                //init is called once when the page loads for the first time.
                //all controls are created here.
                this.Parameters = parameters;
                //this.createTargetingTree();
                this.targetGroupInstance = new athoc.iws.publishing.TargetGroup('#treeview');
                this.targetGroupInstance.TreeView.bind("check", function (e) {
                    athoc.iws.publishing.scenario.isChanged = true;
                    var targetedNodes = athoc.iws.publishing.targetUsers.targetGroupInstance.ViewModel.TargetedGroups();
                    var blockedNodes = athoc.iws.publishing.targetUsers.targetGroupInstance.ViewModel.BlockedGroups();
                    athoc.iws.publishing.targetUsers.viewModelInstance.numGroupsTargeted(targetedNodes.length);
                    athoc.iws.publishing.targetUsers.viewModelInstance.numGroupsBlocked(blockedNodes.length);
                    athoc.iws.publishing.targetUsers.treeSelectionChanged();
                });
                this.targetGroupInstance.TreeView.bind("dataBound", function (e) {
                    if (!e.node) {
                        var targetedNodes = athoc.iws.publishing.targetUsers.targetGroupInstance.ViewModel.TargetedGroups();
                        var blockedNodes = athoc.iws.publishing.targetUsers.targetGroupInstance.ViewModel.BlockedGroups();
                        athoc.iws.publishing.targetUsers.viewModelInstance.numGroupsTargeted(targetedNodes.length);
                        athoc.iws.publishing.targetUsers.viewModelInstance.numGroupsBlocked(blockedNodes.length);
                        athoc.iws.publishing.targetUsers.treeSelectionChanged();

                        self.treeIsLoaded = true;
                        if (self.deviceOptionIsLoaded) { //must check to make sure both tree and device option  is loaded. 
                            $(".alert-nav").attr("disabled", false);
                        }
                    }
                });

                this.loadTargetUsersViewModel();
                this.createPieChart();

                var self = this;

                $(this.Parameters.clearAllCriteriaLink).on("click", function () {
                    self.clearingAllCriteria = true;
                    $(self.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder("clearAll");
                    self.clearingAllCriteria = false;
                    athoc.iws.publishing.targetUsers.updateContactInfo();

                });

                $(this.Parameters.personalDeviceOptionsLink).on("click", function () {

                    if (self.viewModelInstance.AnyDeviceSelected()) {

                        $(self.Parameters.dialogDeviceOptions).modal("show");
                        athoc.iws.utilities.resizeModalBasedOnScreen($(self.Parameters.dialogDeviceOptions), 600, 770, 20, 170);
                    }
                });
            },

            load: function (entityId) {
                var self = this;

                //reset all of the parameters
                this.TreeIsSelected = false;
                this.DeviceIsSelected = false;
                this.viewModelInstance.UsersCount(0);
                this.viewModelInstance.Devices([]);
                athoc.iws.publishing.SetSectionStatus("#targetUsersStatus", "open");
                athoc.iws.publishing.targetUsers.isReadyToPublish = false;

                //load will be called when the detail view is visible again. 
                this.refresh(entityId);
            },

            createPieChart: function () {

                require(['publishing/athoc.iws.publishing.contactInfoPieChart'], function (ContactInfoPieChart) {
                    PieChartObject = new ContactInfoPieChart({
                        domPointer: "#contactInfo",
                        Publishing_Contact_Info_No_users_found: athoc.iws.publishing.resources.Publishing_Contact_Info_No_users_found,
                        Publishing_Contact_Info_Reachable_Tooltip: athoc.iws.publishing.resources.Publishing_Contact_Info_Reachable_Tooltip,
                        Publishing_Contact_Info_Not_Reachable_Tooltip: athoc.iws.publishing.resources.Publishing_Contact_Info_Not_Reachable_Tooltip,
                    });
                });

            },

            //Update contact chart
            updateContactInfo: function () {

                if (!athoc.iws.publishing.detail.isEverythingLoaded()) {
                    return;
                }

                var self = this;

                //turn on now loading
                self.viewModelInstance.ShowUsers(false);
                kendo.ui.progress($("#contactInfo"), true);
                //$.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $("#scenarioDetailsDiv"), imageURL: athoc.iws.scenario.urls.cdnUrl + '/Images/ajax-loader.gif', left: '50%' }).showLoader();

                var checkedDevices = ko.mapping.toJS(this.viewModelInstance.Devices()).filter(function (el) {
                    return el.Selected;
                });

                var devices = checkedDevices.map(function (item) { return item.DeviceId; });
                this.viewModelInstance.numberOfDevices(devices.length);

                var treeNodes = this.targetGroupInstance.ViewModel.SelectedNodes;

                var advancedCriteria = null;
                //if advanced targeting is enabled get criteria
                if ($(this.Parameters.queryBuilderParameters.queryBuilderDiv).length > 0) {
                    $(this.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder();
                    advancedCriteria = $(this.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder("getCurrentSelections");
                }

                var targetedArea = "";
                //send targeted area
                if (athoc.iws.publishing.geo.viewModel.isUsersTargeted() && athoc.iws.publishing.geo.geoJson != null) {
                    targetedArea = JSON.stringify(athoc.iws.publishing.geo.geoJson);
                }
                //send targeted users and blocked users
                var targetdUsers = athoc.iws.publishing.iut.getTargetedUsers();
                var blockedUsers = athoc.iws.publishing.iut.getBlockedUsers();

                //condition to checked whether readonly or not.
                if (athoc.iws.publishing.source != 'readonly') {
                    var userInfoSuccess = function (data) {

                        self.viewModelInstance.UsersCount(data.TotalCount);
                        self.viewModelInstance.ShowUsers(true);

                        self.SessionId = data.SessionId;

                        if (data.TotalCount == 0) {
                            self.resetReach();
                        } else {
                            _.each(data.ContactInfo.ContactInfo, function (item, index) {
                                var found = _.find(self.viewModelInstance.Devices(), function (itemVM) {
                                    return (itemVM.DeviceId() == item.DeviceId);
                                });

                                if (found) {
                                    found.Reach(item.Percentage);
                                }
                            });

                            //set up summary
                            self.viewModelInstance.ReachableUsers(data.ContactInfo.TotalCovered);
                            self.viewModelInstance.ReachableUsersPercentage(data.ContactInfo.TotalCoveredPercentage);

                            self.viewModelInstance.UnReachableUsers(data.ContactInfo.TotalNotCovered);
                            self.viewModelInstance.UnReachableUsersPercentage(data.ContactInfo.TotalNotCoveredPercentage);


                            //draw pie
                            var contactInfo = [{
                                "type": "covered",
                                "number": data.ContactInfo.TotalCovered,
                                "color": "#7CB500",
                                "customPercentage": data.ContactInfo.TotalCoveredPercentage
                            }, {
                                "type": "notcovered",
                                "number": data.ContactInfo.TotalNotCovered,
                                "color": "#AE004B",
                                "customPercentage": data.ContactInfo.TotalNotCoveredPercentage
                            }];
                            PieChartObject.update(contactInfo);

                        }
                        if (data.ContactInfo.TotalCovered > 0 || data.ContactInfo.TotalNotCovered > 0)
                            $("#contactInfo").css("cursor", "pointer");
                        else
                            $("#contactInfo").css("cursor", "default");
                        //$.AjaxLoader.hideLoader();
                        kendo.ui.progress($("#contactInfo"), false);


                        if (athoc.iws.publishing.contextName == "Alert") {
                            athoc.iws.scenario.settings.applyVisibleSettingsOnAlert();
                        }

                        if ($("#personalDeviceOptionsLink"))
                            if (athoc.iws.publishing.targetUsers.viewModelInstance.AnyDeviceSelected()) {
                                $("#personalDeviceOptionsLink").toggleClass("link-disabled", false);
                            } else {
                                $("#personalDeviceOptionsLink").toggleClass("link-disabled", true);
                            }
                        athoc.iws.publishing.targetUsers.targetingChanged();
                    };

                    var userInfoError = function (error) {
                        self.viewModelInstance.UsersCount(0);
                        self.viewModelInstance.ShowUsers(true);

                        //$.AjaxLoader.hideLoader();
                        kendo.ui.progress($("#contactInfo"), false);
                    };
                    athoc.iws.publishing.UpdateContactInfo(0, "", treeNodes, devices, userInfoSuccess, userInfoError, advancedCriteria, targetedArea, targetdUsers, blockedUsers, athoc.iws.publishing.rbt);
                }
            },

            resetReach: function () {
                _.each(this.viewModelInstance.Devices(), function (itemVM) {
                    itemVM.Reach(0);
                });

                this.viewModelInstance.ReachableUsers(0);
                this.viewModelInstance.ReachableUsersPercentage(0);

                this.viewModelInstance.UnReachableUsers(0);
                this.viewModelInstance.UnReachableUsersPercentage(0);

                //draw pie
                var contactInfo = [{
                    "type": "none",
                    "number": 100,
                    "color": "#ccc"
                }];

                PieChartObject.update(contactInfo);
                //$("#contactInfo").data("kendoChart").dataSource.data(contactInfo);

            },

            treeSelectionChanged: function () {

                this.TreeIsSelected = (this.targetGroupInstance.ViewModel.SelectedNodes.length != 0);

                this.targetingChanged();

                athoc.iws.publishing.detail.isTreeLoaded = true;

                if (this.TreeIsSelected) {
                    this.updateContactInfo();
                } else {
                    this.viewModelInstance.UsersCount(0);
                    this.updateContactInfo();
                }
            },

            targetingChanged: function () {
                //if advanced targeting is enabled get criteria
                // var advancedCriteriaSelected = (athoc.iws.publishing.settings.IsAdvancedQuerySuuported) && (this.viewModelInstance.numberQueryCriteria() > 0);
                var advancedCriteriaSelected = 0;
                if ((athoc.iws.publishing.contextName == "Alert" || athoc.iws.publishing.contextName == "AccountEvent")
                    && athoc.iws.scenario.settings.ReadonlyViewModel != null && athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Targeting.Readonly) {
                    advancedCriteriaSelected = (athoc.iws.publishing.settings.IsAdvancedQuerySuuported) && (athoc.iws.publishing.view.viewModel.QueryCriteriaCount() > 0);
                } else {
                    advancedCriteriaSelected = (athoc.iws.publishing.settings.IsAdvancedQuerySuuported) && (this.viewModelInstance.numberQueryCriteria() > 0);
                }

                //is target by area selected
                var targetByAreaSelected = (athoc.iws.publishing.settings.IsTargetByAreaSupported)
                    && (athoc.iws.publishing.geo.viewModel.isGeoSelected())
                    && (athoc.iws.publishing.geo.viewModel.isUsersTargeted());

                //is IUT selected
                var iutTargeted = (athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList().length > 0);

                //check if any of targeting is selected
                var anyTargetingSelected = (this.TreeIsSelected
                    || iutTargeted
                    || advancedCriteriaSelected
                    || targetByAreaSelected || (athoc.iws.publishing.rbt != null));

                var isAnyUserReachable = (athoc.iws.publishing.targetUsers.Parameters.context == "AccountEvent" ||
                    athoc.iws.publishing.targetUsers.Parameters.context == "AccountTemplate") || (athoc.iws.publishing.ReachableUserCount() > 0);

                if (anyTargetingSelected && this.viewModelInstance.AnyDeviceSelected() && isAnyUserReachable) {
                    athoc.iws.publishing.targetUsers.isReadyToPublish = true;
                    athoc.iws.publishing.targetUsers.isInErrorState = false;
                    athoc.iws.publishing.SetSectionStatus("#targetUsersStatus", "ready");
                } else if (anyTargetingSelected || this.viewModelInstance.AnyDeviceSelected()) {
                    athoc.iws.publishing.targetUsers.isReadyToPublish = false;
                    athoc.iws.publishing.targetUsers.isInErrorState = true;
                    athoc.iws.publishing.SetSectionStatus("#targetUsersStatus", "notReady");
                } else {
                    athoc.iws.publishing.targetUsers.isReadyToPublish = false;
                    athoc.iws.publishing.targetUsers.isInErrorState = false;
                    athoc.iws.publishing.SetSectionStatus("#targetUsersStatus", "open");

                }


                if (athoc.iws.publishing.contextName == "Scenario")
                    athoc.iws.scenario.schedule.isActiveRecurrenceEnabled();


            },

            resetTargetingInfo: function () {
                $("#treeview").hide();
                this.resetReach();
            },

            getTargetedUsersCount: function (cnt) {
                athoc.iws.publishing.targetUsers.viewModelInstance.numTargetedUsers(cnt);
            },

            getBlockedUsersCount: function (cnt) {
                athoc.iws.publishing.targetUsers.viewModelInstance.numBlockedUsers(cnt);
            },

            pieChartClick: function (e) {
                if (e.category == "covered") {
                    if (athoc.iws.publishing.source == 'p' || athoc.iws.publishing.source == 'h' || athoc.iws.publishing.source == 'a' || athoc.iws.publishing.source == 'readonly') {
                        athoc.iws.alert.reviewandpublish.GetReachableUserList(1);
                    }
                    else
                        athoc.iws.publishing.targetUsers.viewModelInstance.GetReachableUserList(1);
                }
                else if (e.category == "notcovered") {
                    if (athoc.iws.publishing.source == 'p' || athoc.iws.publishing.source == 'h' || athoc.iws.publishing.source == 'a' || athoc.iws.publishing.source == 'readonly') {
                        athoc.iws.alert.reviewandpublish.GetUnReachableUserList(0);
                    }
                    else
                        athoc.iws.publishing.targetUsers.viewModelInstance.GetUnReachableUserList(0);
                }
            },

            //bind contact data to target section in readonly
            applyReadonlySettingsOnTargetUsers: function (data, targetDiv) {

                var targetVM = function (context) {
                    var self = this;
                    //Contact info
                    self.targetedBlockerUsersList = data.TargetUsers.TargetedBlockedUsers;
                    self.ContactinfoTotalCoveredNumber = ko.observable(0);
                    self.ContactinfoTotalCoveredPercentage = ko.observable(0);
                    self.ContactinfoNotCoveredNumber = ko.observable(0);
                    self.ContactinfoNotCoveredPercentage = ko.observable(0);
                    self.TotalUsers = ko.observable(0);
                    if (athoc.iws.publishing.iut != undefined && athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList() == null && data.TargetUsers.TargetedBlockedUsers != null)
                        athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList(data.TargetUsers.TargetedBlockedUsers);
                    self.Devices = ko.observableArray();
                    self.TargetingTree = ko.observableArray();
                    self.groupedDevices = ko.observableArray();
                    self.numberQueryCriteria = ko.observable(0);
                    self.numberAreaCriteria = ko.observable(0);

                    self.numberOfDevices = ko.observable(0);
                    self.DeliveryOrderList = ko.observableArray();
                    self.numGroupsTargeted = ko.observable(0);
                    self.numGroupsBlocked = ko.observable(0);
                    self.numTargetedUsers = ko.observable(0);
                    self.numBlockedUsers = ko.observable(0);
                    self.targetedUsers = ko.observableArray();
                    self.getTargetedUsers = function () {
                        var targetdata = [];
                        _.each(data.TargetUsers.TargetedBlockedUsers, function (item, index) {
                            if (!item.IsBlocked) {
                                targetdata.push(item.UserId);
                            }

                        });
                        return targetdata;
                    };
                    self.targetedBlockedUsers = ko.observableArray();
                    self.getBlockedUsers = function () {
                        var targetdata = [];
                        _.each(data.TargetUsers.TargetedBlockedUsers, function (item, index) {
                            if (item.IsBlocked) {
                                targetdata.push(item.UserId);
                            }

                        });
                        return targetdata;
                    };

                    self.showQuerySummary = function () {
                        if (self.numberQueryCriteria() > 0) {
                            $("#dialogTargetingSummary").find("#spanTitle").text(athoc.iws.publishing.iut.resources.Publishing_TargetUsers_Advanced_Query);
                            var summaryDiv = $("#dialogTargetingSummary").find("#targetingSummaryContentDiv");
                            summaryDiv.html("");
                            var selections = $("#queryBuilderDiv").athocQueryBuilder("getCurrentSelections");

                            var seletionTextArray = selections.display;

                            _.each(seletionTextArray, function (item, index) {
                                if (index != 0) {
                                    summaryDiv.append("<div class=\"summary-row summary-operator-row\">" + athoc.iws.publishing.resources.Publishing_TargetUsers_Advanced_Query_Summary_And + "</div>");
                                }

                                summaryDiv.append(context.summaryDivTrmplate.format(item, selections.displayNoStyle[index]));
                                index += 1;
                            });
                            $("#dialogTargetingSummary").modal("show");
                        }
                    };

                    //on number of map area clicked
                    self.showAreaSummary = function () {
                        if (self.numberAreaCriteria() > 0) {
                            //Show map with objects in model window
                            $("#dialogGeoTargetingSummary").modal("show");
                        }
                    };

                    //show selected devices list
                    self.showDeviceSummary = function () {
                        if (self.numberOfDevices() > 0) {
                            //show device summary
                            $("#personalDeviceSummaryDiv").html('');
                            ko.cleanNode($("#dialogPersonalDevicesSummary").get(0));
                            var groupedDevices = athoc.iws.publishing.targetUsers.SelectedGroupedDevices();
                            ko.applyBindings(groupedDevices, $("#dialogPersonalDevicesSummary").get(0));
                            $("#dialogPersonalDevicesSummary").modal("show");
                        }
                    };

                    self.showTargetedGroupSummary = function () {
                        $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP").html('');
                        if (self.numGroupsTargeted() > 0) {
                            var result = "";
                            athoc.iws.alert.reviewandpublish.showModalonModal("#targetedUsersSummaryRP");
                            $("#targetedUsersSummaryRP").find("#spanTitleDetails").text(athoc.iws.publishing.iut.resources.Publishing_TargetUsers_ByGroups);
                            var summaryDiv = $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP");
                            var template = kendo.template($("#groupsummary-template-RP").html());
                            result = template(athoc.iws.alert.reviewandpublish.TargetedGroupsFormatted());
                            summaryDiv.html(result);
                        }
                    };

                    self.showBlockedGroupSummary = function () {
                        $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP").html('');
                        if (self.numGroupsBlocked() > 0) {
                            athoc.iws.alert.reviewandpublish.showModalonModal("#targetedUsersSummaryRP");
                            $("#targetedUsersSummaryRP").find("#spanTitleDetails").text(athoc.iws.publishing.iut.resources.Publishing_TargetUsers_ByGroupsBlocked);
                            var summaryDiv = $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP");
                            var template = kendo.template($("#groupsummary-template-RP").html());
                            var result = "";
                            result = template(athoc.iws.alert.reviewandpublish.BlockedGroupsFormatted());
                            summaryDiv.html(result);
                        }
                    };

                    self.showTargetedUsersSummary = function () {
                        $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP").html('');
                        if (self.numTargetedUsers() > 0) {
                            athoc.iws.alert.reviewandpublish.showModalonModal("#targetedUsersSummaryRP");
                            athoc.iws.alert.reviewandpublish.showTargetedUsersSummary();
                            $("#targetedUsersSummaryRP").find("#spanTitleDetails").text(athoc.iws.publishing.iut.resources.Publishing_TargetUsers_ByUsers + '(' + self.numTargetedUsers() + ')');
                        }
                    };

                    self.showBlockedUsersSummary = function () {
                        $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP").html('');
                        if (self.numBlockedUsers() > 0) {
                            athoc.iws.alert.reviewandpublish.showModalonModal("#targetedUsersSummaryRP");
                            athoc.iws.alert.reviewandpublish.showBlockedUsersSummary();
                            $("#targetedUsersSummaryRP").find("#spanTitleDetails").text(athoc.iws.publishing.iut.resources.Publishing_TargetUsers_ByUsersBlocked + '(' + self.numBlockedUsers() + ')');
                        }
                    };

                    self.SelectedGroupedDevices = function () {
                        var selectedDevices = [];
                        var lastGroup = '';
                        _.each(this.ReadonlyviewModel.Devices(), function (item, index) {
                            if (item.Selected()) {
                                var groupChanged = false;
                                if (lastGroup != item.GroupName()) {
                                    groupChanged = true;
                                    lastGroup = item.GroupName();
                                }
                                var device = { DeviceId: item.DeviceId, DeviceName: item.DeviceName, GroupChange: groupChanged, GroupId: item.GroupId, GroupName: item.GroupName, HideInReadOnlyView: item.HideInReadOnlyView, Reach: item.Reach, Selected: true };
                                selectedDevices.push(device);
                            }
                        });

                        return { Devices: selectedDevices };
                    };

                    self.GetReachableUserList = function () {
                        athoc.iws.alert.reviewandpublish.LaunchContactInfoUserList(1);
                    };

                    self.GetUnReachableUserList = function () {
                        athoc.iws.alert.reviewandpublish.LaunchContactInfoUserList(0);
                    };
                    self.DisplayUserList = function () {
                        $("#readOnlyUserListTitle").html(athoc.iws.publishing.iut.resources.IUTReadOnly_AllUsers);
                        athoc.iws.alert.reviewandpublish.ShowUsersList(athoc.iws.alert.reviewandpublish.SessionId, -1, "", athoc.iws.publishing.targetUsers.ReadonlyviewModel.TotalUsers());
                    };
                };

                this.ReadonlyviewModel = new targetVM(this);

                //do knockout binding using viewModel
                ko.cleanNode(targetDiv.find(".contact-info-section").get(0));
                ko.cleanNode(targetDiv.find(".contact-info-section").get(1));
                ko.cleanNode(targetDiv.find("#targetSummaryDetail").get(0));
                ko.cleanNode(targetDiv.find("#PersonalDeviceListDetail").get(0));

                ko.applyBindings(athoc.iws.publishing.targetUsers.ReadonlyviewModel, targetDiv.find(".contact-info-section").get(0));
                ko.applyBindings(athoc.iws.publishing.targetUsers.ReadonlyviewModel, targetDiv.find(".contact-info-section").get(1));
                ko.applyBindings(athoc.iws.publishing.targetUsers.ReadonlyviewModel, targetDiv.find("#targetSummaryDetail").get(0));


                ko.applyBindings(athoc.iws.publishing.targetUsers.ReadonlyviewModel, targetDiv.find("#targetSummaryDetail").get(0));
                //Skip ajax call : in Edit Mode
                //if (athoc.iws.publishing.source == "a" && (athoc.iws.scenario.settings != undefined && athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Targeting != undefined && !athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Targeting.Readonly)) {
                if (athoc.iws.publishing.source == "a" && (athoc.iws.publishing.source != "readonly")) {
                    ko.mapping.fromJS(data.TargetUsers.Devices, {}, this.ReadonlyviewModel.Devices);
                    ko.mapping.fromJS(data.TargetUsers.TargetingTree, {}, this.ReadonlyviewModel.TargetingTree);
                    athoc.iws.publishing.view.showContactInfo();
                }
                else {

                    //making a single ajax call to get targeting tree and device data
                    var ajaxSuccessWrapper = function (context) {
                        return function (data) {
                            ko.mapping.fromJS(data.Devices, {}, context.ReadonlyviewModel.Devices);
                            ko.mapping.fromJS(data.TargetingTree, {}, context.ReadonlyviewModel.TargetingTree);
                        }
                    }(this);

                    var targetingInfoSuccess = function (data) {
                        ajaxSuccessWrapper(data);

                        athoc.iws.publishing.view.showContactInfo();


                    };

                    var targetingInfoError = function (e) {
                        kendo.ui.progress($("#publishing-user-detail"), false);
                        var errorCallBack = function (returnedErrorObject) {
                            $('#listMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        };
                    }
                    //need to check context
                    var paramcontext = 'Scenario';

                    if (athoc.iws.alert.action == 'rbt') {
                        param1 = athoc.iws.alert.rbt.AlertId;
                        param2 = athoc.iws.alert.rbt.EntityFilterId;
                        paramcontext = 'Alert';

                    } else if (athoc.iws.alert.action == "v") {
                        param1 = athoc.iws.alert.id;
                        paramcontext = 'Alert';
                        param2 = "";
                    } else {
                        param1 = data.EntityId == 0 ? data.ParentId : data.EntityId;
                        param2 = "";
                    }

                    var ajaxOptions = {
                        cache: false,
                        url: athoc.iws.publishing.urls.GetDeviceListUrl,
                        data: { context: paramcontext, id: param1, recipientType: param2 },
                        type: "POST"
                    };

                    var ajaxOptions = $.extend({}, AjaxUtility(targetingInfoError, targetingInfoSuccess).ajaxPostOptions, ajaxOptions);
                    $.ajax(ajaxOptions);

                    //End
                }
            },

            refreshPersonalDevices: function (data) {
                /* var deletedItems = [];
                 _.each(athoc.iws.publishing.targetUsers.viewModelInstance.Devices(), function (item, index) {
                     var flag = _.find(data, function (device) {
                         return (device.DeviceId == item.DeviceId());
                     });
                     if (flag == null) {
                         deletedItems.push(item.DeviceId());
                     }
                 });
                 _.each(data, function (obj, index) {
                     var newDevice = _.find(athoc.iws.publishing.targetUsers.viewModelInstance.Devices(), function (device) {
                         return device.DeviceId() == obj.DeviceId;
                     });
                     if (newDevice == null) {
                         //obj.GroupChange = true;
                         obj.Selected = false;
                         athoc.iws.publishing.targetUsers.viewModelInstance.Devices.push(ko.mapping.fromJS(obj));
                     }
                 });
                 if (deletedItems.length > 0) {
                     athoc.iws.publishing.targetUsers.viewModelInstance.Devices.remove(function (i) {
                         return deletedItems.indexOf(i.DeviceId()) > -1;
                     });
                 }*/
                var selectedList = $.grep(athoc.iws.publishing.targetUsers.viewModelInstance.Devices(), function (d) {
                    return d.Selected() == true;
                });
                _.each(data, function (obj, index) {
                    var selected = _.find(selectedList, function (s) {
                        return s.DeviceId() == obj.DeviceId;
                    });
                    if (selected == null)
                        obj.Selected = false;
                });
                ko.mapping.fromJS(data, {}, athoc.iws.publishing.targetUsers.viewModelInstance.Devices);
                //athoc.iws.publishing.targetUsers.updateContactInfo();
                //athoc.iws.publishing.targetUsers.viewModelInstance.Devices().sort(function (l, r) { return [l.GroupId() < r.GroupId()] ? -1 : 1 })
                //ko.cleanNode($("#devicesListDiv").get(0));
                //ko.applyBindings(this.viewModelInstance, $("#devicesListDiv").get(0));


            },

            isThisDeviceGroupTargeted: function (groupid) {

                var checkedDevices = ko.mapping.toJS(this.viewModelInstance.Devices()).filter(function (el) {
                    return el.Selected;
                });

                for (i = 0; i < checkedDevices.length; i++) {
                    if (checkedDevices[i].GroupId == groupid) {
                        return true;
                    }
                }
                return false;
            }
        };
    }();
}

