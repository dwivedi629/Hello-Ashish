﻿/* define javascript namespace for Test Alert  */
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.alert = athoc.iws.alert || {};
if (athoc.iws.alert) {

    athoc.iws.alert.print = function () {
       
        return {
            //is model changed
            isChanged: false,
            IsRefered: false,
            alertId:0,
            //this method will be
            viewModel: {
             

            },

            //called when new data will be available for this section for binding
            load: function () {
                
                $("#btn_print_alert").click(function () {
                   athoc.iws.alert.print.redirectToPrintAlertDetailsUrl();
                });

            },
            bind: function (data) {
            },

            redirectToPrintAlertDetailsUrl: function () {
                try {
                    $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.modal-footer'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();
                    athoc.iws.alert.detail.downloadPdfFile(athoc.iws.publishing.urls.CreatePrintAlertUrl);

                } catch (e) {
                    console.log(e);
                }
                finally {
                    $.AjaxLoader.hideLoader();
                };
            },
        };

    }();
}
