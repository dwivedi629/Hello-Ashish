﻿/* define javascript namespace for fill count  */
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};
if (athoc.iws.publishing) {
    $.fn.setCursorPosition = function (pos) {
        this.each(function (index, elem) {
            if (elem.setSelectionRange) {
                elem.setSelectionRange(pos, pos);
            } else if (elem.createTextRange) {
                var range = elem.createTextRange();
                range.collapse(true);
                range.moveEnd('character', pos);
                range.moveStart('character', pos);
                range.select();
            }
        });
        return this;
    };
    athoc.iws.publishing.fillcount = function () {
        //
        return {
            //is model changed
            isChanged: false,
            responseChangedText: '',
            deleteResponseIndex: -1,
            confirmationDailogType: 0,
            isTUSectionReadonly: false,
            // fill count summary 
            fillCountSummary: ko.observable(),
            defaultFillCountSummary: {
                ResponseText: "",
                FillCount: 0,
                AttributeName: "",
                ControlDeliveryTypeText: "",
                WaitTimeTitle: "",
                WaitTime: "",
                ControlDeliveryType: 0,
            },
            defaultFillCount: {
                ResponseOptionId: -1,
                EntityId: 0,
                AnyResponseOption: true,
                FillCount: 1,
                EscalationAttributeId: 0,
                PhoneAttributeId: 0,
                WaitTime: 15,
                WaitTimeUnit: "Minutes",
                GroupByAscending: true,
                OrderByAscending: true,
                ControlledDeliveryType: 0,
                EnableControlledDelivery: false,
                EnableEscalation: false,
            },

            // viewmodel
            viewModel: {
                initialFocus: ko.observable(true),
                fillCountModel: ko.observable(),
                responseOptions: ko.observableArray(),
                escalationAttributes: ko.observableArray(),
                phonesequencingAttributes: ko.observableArray(),
                waitTimeUnits: ko.observableArray(),
                editFillCountModel: {},
            },
            //This method is used to resize the popup when window is resizing
            attachResizePopupWindowEvent: function () {
                var resizeFunction = function () {
                    if ($(window).height() > 1024)
                        athoc.iws.utilities.resizeModalBasedOnScreen($('#FillCount'), 600, 770, 20, 170);
                    else
                        athoc.iws.utilities.resizeModalBasedOnScreen($('#FillCount'), 560, 710, 15, 145);

                    athoc.iws.publishing.fillcount.fcDivScrollEventActions();

                }
                var updateLayout = _.debounce(resizeFunction, 500); // Maximum run of once per 500 milliseconds
                window.addEventListener("resize", updateLayout, false);
            },
            fcDivScrollEventActions: function () {
                if ($('#FillCount .modal-body').get(0).scrollHeight > $('#FillCount .modal-body').innerHeight())
                    $("#secondBucket").removeClass("mar-bot0");
                else
                    $("#secondBucket").addClass("mar-bot0");

            },
            //This is method when new data is loaded from publishing model
            load: function () {
                athoc.iws.publishing.fillcount.viewModel.waitTimeUnits.push({ text: athoc.iws.publishing.fillcount.resources.TimeFormat_Minutes, value: "Minutes" });
                athoc.iws.publishing.fillcount.viewModel.waitTimeUnits.push({ text: athoc.iws.publishing.fillcount.resources.TimeFormat_Hours, value: "Hours" });

                // Edit Link to show Fill Count UI
                $("#EditFillCount").click(function () {
                    $('#FillCount').modal('show');
                    athoc.iws.publishing.fillcount.attachResizePopupWindowEvent();
                    // athoc.iws.utilities.resizeModalBasedOnScreenwithCenter($('#FillCount'), 600, 770, (navigator.userAgent.toLocaleLowerCase().indexOf('mozilla') != -1 ? 25 : 40), 170, 720, 40, 770);
                    athoc.iws.publishing.fillcount.viewModel.editFillCountModel = ko.mapping.toJS(athoc.iws.publishing.fillcount.viewModel.fillCountModel);
                    athoc.iws.publishing.fillcount.showFillCount();
                });

                // Open Fill Count Popup
                $("#FillCountLink").click(function () {
                    if (!athoc.iws.publishing.fillcount.isResponsesAvailable()) {
                        /// TODO move text to resource file
                        athoc.iws.publishing.fillcount.showConfirmationDialog(3, $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_AtleastOneResponse));
                    } else {
                        $('#FillCount').modal('show');
                        athoc.iws.publishing.fillcount.attachResizePopupWindowEvent();
                        //athoc.iws.utilities.resizeModalBasedOnScreenwithCenter($('#FillCount'), 600, 770, (navigator.userAgent.toLocaleLowerCase().indexOf('mozilla') != -1 ? 25 : 40), 170, 720, 40, 770);
                        athoc.iws.publishing.fillcount.viewModel.editFillCountModel = ko.mapping.toJS(athoc.iws.publishing.fillcount.viewModel.fillCountModel);
                        athoc.iws.publishing.fillcount.showFillCount();

                    }
                });

                //Apply Fill Count on Target User Section
                $("#ApplyFillCount").click(function () {
                    if (!athoc.iws.publishing.fillcount.isValid()) {
                        $("#FillCountSummary").show();
                        $("#EditFillCountDetails").show();
                        $("#FillCountLink").hide();
                        $('#FillCount').modal('hide');
                        athoc.iws.publishing.fillcount.setFillCountSummary(null);
                        var targetDiv = $("#publishing-user-edit");
                        athoc.iws.publishing.fillcount.ShowFillCountSummary(athoc.iws.publishing.fillcount.fillCountSummary, targetDiv);

                        athoc.iws.publishing.fillcount.isChanged = true;
                    }
                });

                //Cancel Fill Count 
                $("#CancelFillCount").click(function () {
                    $('#FillCount').modal('hide');
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.ResponseOptionId);
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.AnyResponseOption(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.AnyResponseOption);
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.FillCount(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.FillCount);
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.ControlledDeliveryType);
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.EscalationAttributeId(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.EscalationAttributeId);
                    $('#escalationAttribute').selectpicker('refresh');

                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.WaitTime);
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTimeUnit(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.WaitTimeUnit);
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.GroupByAscending(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.GroupByAscending);
                    // athoc.iws.publishing.fillcount.viewModel.fillCountModel.PhoneAttributeId(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.PhoneAttributeId);
                    // $('#phoneAttribute').selectpicker('refresh');
                    // athoc.iws.publishing.fillcount.viewModel.fillCountModel.OrderByAscending(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.OrderByAscending);
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.EntityId(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.ControlledDeliveryType.EntityId);
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.EnableEscalation(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.EnableEscalation);
                });

                //Clear Fill Count
                $("#ClearFillCount").click(function () {
                    athoc.iws.publishing.fillcount.confirmationDailogType = 1;
                    /// TODO move text to resource file
                    athoc.iws.publishing.fillcount.showConfirmationDialog(1, athoc.iws.publishing.fillcount.resources.FillCount_Removemsg);
                });
            },

            // Modal resizing
            resizeModalBasedOnScreen: function (modal) {
                modal.find(".modal-body").css("max-height", 460);
                var windowHeight = $(window).height();

                if (windowHeight > 770) {
                    modal.css("margin-top", 60 - (windowHeight / 2) + ((windowHeight - 770) / 2));
                    modal.find(".modal-body").css("height", windowHeight - 340);
                } else {
                    modal.css("margin-top", 60 - (windowHeight / 2));
                    modal.find(".modal-body").css("height", windowHeight - 240);
                }

                if (modal.height() + 170 > windowHeight) {
                    var newHeight = windowHeight - 170;
                    modal.find(".modal-body").css("max-height", newHeight);

                }

            },

            // to show escalation breadcrum
            showEscalationBreadCrum: function (flag) {
                if (!flag) {
                    $("#showEscalationBreadCrumLess").show();
                    $("#showEscalationBreadCrumMore").hide();
                } else {
                    $("#showEscalationBreadCrumLess").hide();
                    $("#showEscalationBreadCrumMore").show();
                }
                athoc.iws.publishing.fillcount.fcDivScrollEventActions();
                return false;
            },

            EditFillcount: function () {

                $('#FillCount').modal('show');
                athoc.iws.publishing.fillcount.attachResizePopupWindowEvent();
                //athoc.iws.utilities.resizeModalBasedOnScreenwithCenter($('#FillCount'), 600, 770, (navigator.userAgent.toLocaleLowerCase().indexOf('mozilla') != -1 ? 25 : 40), 170, 720, 40, 770);
                athoc.iws.publishing.fillcount.viewModel.editFillCountModel = ko.mapping.toJS(athoc.iws.publishing.fillcount.viewModel.fillCountModel);
                athoc.iws.publishing.fillcount.showFillCount();
            },
            /// TODO : we can delete this method
            CancelDailog: function () {
                if (athoc.iws.publishing.fillcount.confirmationDailogType == 1 || athoc.iws.publishing.fillcount.confirmationDailogType == 0)
                    $("#dialogResponseDeleteConfirm").modal("hide");
                else if (athoc.iws.publishing.fillcount.confirmationDailogType == 2) {
                    athoc.iws.publishing.fillcount.fillCountSummary.ResponseText(athoc.iws.publishing.fillcount.responseChangedText);
                    athoc.iws.publishing.fillcount.responseChangedText = '';
                    $("#dialogResponseChangeConfirm").modal("hide");
                } else if (athoc.iws.publishing.fillcount.confirmationDailogType == 3) {
                    athoc.iws.publishing.content.viewModel.data.ResponseOptionId(athoc.iws.publishing.content.responseOptionPreviousId);
                    $('#responseList').selectpicker('refresh');
                    $("#dialogResponseDeleteConfirm").modal("hide");
                }
                athoc.iws.publishing.fillcount.confirmationDailogType = 0;
            },

            localizeTimeUnit: function (unit) {
                if ((unit.toLowerCase() == "hour") || (unit.toLowerCase() == "hours"))
                    return $.htmlDecode(athoc.iws.publishing.fillcount.resources.TimeFormat_Hours);
                if ((unit.toLowerCase() == "minute") || (unit.toLowerCase() == "minutes"))
                    return $.htmlDecode(athoc.iws.publishing.fillcount.resources.TimeFormat_Minutes);
            },

            // set Fill count summary data
            setFillCountSummary: function (existingSummary) {
                var self = athoc.iws.publishing.fillcount.fillCountSummary;
                if (existingSummary == null) {
                    self.ResponseText($("#fillCountResponses option:selected").text());
                    self.FillCount($("#fillcount").val() + ' ' + $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_Summary_ResponseText));



                    switch (athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType()) {
                        case 0:
                            self.ControlDeliveryType(0);
                            self.ControlDeliveryTypeText("");
                            self.AttributeName("");
                            self.WaitTimeTitle("");
                            self.WaitTime("");

                            break;
                        case 1:
                            self.ControlDeliveryType(1);
                            self.ControlDeliveryTypeText( $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_ControlledDelivery_Escalation));
                            self.AttributeName($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_EscalationBy) + ' ' + $("#escalationAttribute option:selected").text() + ' ' + (athoc.iws.publishing.fillcount.viewModel.fillCountModel.GroupByAscending() ? $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_ToptoBottom) : $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_BottomtoTop)));
                            self.WaitTimeTitle($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_Waittime));
                            self.WaitTime(athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime() + ' ' + athoc.iws.publishing.fillcount.localizeTimeUnit((athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime() > 1 ? athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTimeUnit().toLowerCase() : athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTimeUnit().toLowerCase().substring(0, athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTimeUnit().length - 1))));
                            break;
                        case 2:
                            self.ControlDeliveryType(2);
                            self.ControlDeliveryTypeText($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_ControlledDelivery_Escalation));
                            self.AttributeName($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_EscalationBy) + ' ' + $("#escalationAttribute option:selected").text() + ' ' + (athoc.iws.publishing.fillcount.viewModel.fillCountModel.GroupByAscending() ? $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_ToptoBottom) : $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_BottomtoTop)));
                            self.WaitTimeTitle($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_Waittime));
                            self.WaitTime(athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime() + ' ' + athoc.iws.publishing.fillcount.localizeTimeUnit((athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime() > 1 ? athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTimeUnit().toLowerCase() : athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTimeUnit().toLowerCase().substring(0, athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTimeUnit().length - 1))));
                            break;
                            /*    case 2:
                                    self.ControlDeliveryType(2);
                                    self.ControlDeliveryTypeText(athoc.iws.publishing.fillcount.resources.FillCount_ControlledDelivery_Sequencing);
                                    self.WaitTimeTitle("");
                                    self.WaitTime("");
                                    self.AttributeName(athoc.iws.publishing.fillcount.resources.FillCount_Sortby + ' ' + $("#phoneAttribute option:selected").text() + ' ' + (athoc.iws.publishing.fillcount.viewModel.fillCountModel.OrderByAscending() ? athoc.iws.publishing.fillcount.resources.FillCount_Asc : athoc.iws.publishing.fillcount.resources.FillCount_Desc));
                                    break;*/
                    }
                } else {
                    // set Default Fill Count Summary Model

                    self.ResponseText(athoc.iws.publishing.fillcount.getControlDeliveryAttributeValue(existingSummary.ResponseOptionId, 0));
                    self.FillCount(existingSummary.FillCount + ' ' + $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_Summary_ResponseText));
                    athoc.iws.publishing.fillcount.setNoneFillCountSummary(self);
                    var attributeName;
                    switch (existingSummary.ControlledDeliveryType) {
                        case 1:
                            attributeName = athoc.iws.publishing.fillcount.getControlDeliveryAttributeValue(existingSummary.EscalationAttributeId, 1);
                            if (attributeName != $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_SelectanAttribute)) {
                                self.ControlDeliveryType(1);
                                self.ControlDeliveryTypeText($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_ControlledDelivery_Escalation));
                                self.AttributeName($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_EscalationBy) + ' ' + attributeName + ' ' + (existingSummary.OrderByAscending == true ? $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_ToptoBottom) : $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_BottomtoTop)));
                                self.WaitTimeTitle($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_Waittime));
                                self.WaitTime(existingSummary.WaitTime + ' ' + athoc.iws.publishing.fillcount.localizeTimeUnit((existingSummary.WaitTime > 1 ? existingSummary.WaitTimeUnit.toLowerCase() : existingSummary.WaitTimeUnit.toLowerCase().substring(0, existingSummary.WaitTimeUnit.length - 1))));
                            }
                            break;
                        case 2:
                            attributeName = athoc.iws.publishing.fillcount.getControlDeliveryAttributeValue(existingSummary.EscalationAttributeId, 1);
                            if (attributeName != $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_SelectanAttribute)) {
                                self.ControlDeliveryType(2);
                                self.ControlDeliveryTypeText($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_ControlledDelivery_Escalation));
                                self.AttributeName($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_EscalationBy) + ' ' + attributeName + ' ' + (existingSummary.OrderByAscending == true ? $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_ToptoBottom) : $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_BottomtoTop)));
                                self.WaitTimeTitle($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_Waittime));
                                self.WaitTime(existingSummary.WaitTime + ' ' + athoc.iws.publishing.fillcount.localizeTimeUnit((existingSummary.WaitTime > 1 ? existingSummary.WaitTimeUnit.toLowerCase() : existingSummary.WaitTimeUnit.toLowerCase().substring(0, existingSummary.WaitTimeUnit.length - 1))));

                            }
                            break;
                            /*  case 2:
                                  attributeName = athoc.iws.publishing.fillcount.getControlDeliveryAttributeValue(existingSummary.PhoneAttributeId, 2);
                                  if (attributeName != athoc.iws.publishing.fillcount.resources.FillCount_SelectanAttribute) {
                                      self.ControlDeliveryType(2);
                                      self.ControlDeliveryTypeText(athoc.iws.publishing.fillcount.resources.FillCount_ControlledDelivery_Sequencing);
                                      self.AttributeName(athoc.iws.publishing.fillcount.resources.FillCount_Sortby + ' ' + athoc.iws.publishing.fillcount.getControlDeliveryAttributeValue(existingSummary.PhoneAttributeId, 2) + ' ' + (existingSummary.OrderByAscending == true ? athoc.iws.publishing.fillcount.resources.FillCount_Asc : athoc.iws.publishing.fillcount.resources.FillCount_Desc));
                                      self.WaitTimeTitle("");
                                      self.WaitTime("");
                                  }
                                  break;*/
                    }
                }
            },

            // reset fill count summary on selecting none of delivery control type
            setNoneFillCountSummary: function (objModel) {

                // set fillcount summary attributes to default before assigning the db values
                objModel.ControlDeliveryType(0);
                objModel.ControlDeliveryTypeText("");
                objModel.AttributeName("");
                objModel.WaitTimeTitle("");
                objModel.WaitTime("");


            },

            // Attribute value from ID
            getControlDeliveryAttributeValue: function (Id, srctype) {
                var data;
                var iResponses = -1;
                var self = athoc.iws.publishing.fillcount.viewModel;
                if (srctype == 0 && Id == 0)
                    /// TODO move text to resource file
                    return athoc.iws.publishing.fillcount.resources.FillCount_Any;
                switch (srctype) {
                    case 0:
                        data = ko.mapping.toJS(self.responseOptions);
                        break;
                    case 1:
                        data = ko.mapping.toJS(self.escalationAttributes);
                        break;
                    case 2:
                        data = ko.mapping.toJS(self.phonesequencingAttributes);
                        break;
                }

                var attributeData = _.find(data, function (item) {
                    iResponses++;
                    return (srctype == 0) ? iResponses == Id : Id === item.Id;

                });
                if (attributeData == undefined)
                    switch (srctype) {
                        case 0:
                            /// TODO move text to resource file
                            return athoc.iws.publishing.fillcount.resources.FillCount_SelectaResponseOption;
                        case 1:
                        case 2:
                            /// TODO move text to resource file
                            if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType != undefined) {
                                athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType(0);
                                athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime("15");
                                athoc.iws.publishing.fillcount.viewModel.fillCountModel.EscalationAttributeId(0);
                                athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTimeUnit("Minutes");
                                athoc.iws.publishing.fillcount.viewModel.fillCountModel.GroupByAscending(true);
                            }

                            return $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_SelectanAttribute);
                            /*case 2:
                                /// TODO move text to resource file
                                if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType != undefined) {
                                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType(0);
                                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.PhoneAttributeId(0);
                                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.OrderByAscending(true);
                                
                                return athoc.iws.publishing.fillcount.resources.FillCount_SelectanAttribute;
                                }*/
                    }

                return attributeData.Name;
            },

            // to fill summary section0
            ShowFillCountSummary: function (fillcountsummary, targetDiv) {
                ko.cleanNode(targetDiv.find("#FillCountDetails").get(0));
                ko.applyBindings(fillcountsummary, targetDiv.find("#FillCountDetails").get(0));
            },

            // to show fill count modal
            showFillCount: function () {


                var escalationDiv = $("#EscalationAttributeBreadCrum");
                if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType() == 0)
                    escalationDiv.hide();
                else
                    athoc.iws.publishing.fillcount.escalationBreadCrum(athoc.iws.publishing.fillcount.viewModel.fillCountModel.EscalationAttributeId());


                athoc.iws.publishing.fillcount.viewModel.responseOptions(athoc.iws.publishing.fillcount.fillResponses(ko.mapping.toJS(athoc.iws.publishing.content.viewModel.data.ResponseOptions || athoc.iws.publishing.view.viewModel.data.Content.ResponseOptions)));
                $("#responseOption").find(".bootstrap-select").remove();
                ko.cleanNode($("#responseOption").get(0));
                ko.applyBindings(athoc.iws.publishing.fillcount.viewModel, $("#responseOption").get(0));
                $("#fillCountResponses").selectpicker('refresh');
                $("#waitTimeDuration").selectpicker('refresh');

                //athoc.iws.publishing.fillcount.enableControlDeliveryAttributes(athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType());
                $('#FillCount').modal({
                    keyboard: true
                }).promise().done(function () {
                    setTimeout(function () {
                        $("#fillcount").trigger('focus').setCursorPosition($("#fillcount").val().length);
                        //    $('[data-id=fillCountResponses]').trigger('focus');
                    }, 1000);
                });

            },

            // to enable the control delivery attributes based on delivery control  type attribute selection
            enableControlDeliveryAttributes: function (newValue) {
                switch (newValue) {
                    case 0:
                        $("#ErrorMsg_EscalationAttributeId").css('display', "none");
                        $("#ErrorMsg_PhoneAttributeId").css('display', "none");
                        $("#EscalationAttributeBreadCrum").hide();
                        $('[data-id=escalationAttribute]').attr("disabled", "disabled");
                        $('[data-id=phoneAttribute]').attr("disabled", "disabled");
                        $('[data-id=waitTimeDuration]').attr("disabled", "disabled");
                        break;
                    case 1:
                        $("#ErrorMsg_PhoneAttributeId").css('display', "none");
                        $("#EscalationAttributeBreadCrum").show();
                        $('[data-id=escalationAttribute]').removeAttr("disabled");
                        $('[data-id=phoneAttribute]').attr("disabled", "disabled");
                        $('[data-id=waitTimeDuration]').removeAttr("disabled");
                        break;
                    case 2:
                        $("#ErrorMsg_EscalationAttributeId").css('display', "none");
                        $("#EscalationAttributeBreadCrum").hide();
                        $('[data-id=phoneAttribute]').removeAttr("disabled");
                        $('[data-id=escalationAttribute]').attr("disabled", "disabled");
                        $('[data-id=waitTimeDuration]').attr("disabled", "disabled");
                        break;

                }
            },

            // to generate escalation breadcrum based on escalation attribute selection
            escalationBreadCrum: function (Id) {

                var toData = ko.mapping.toJS(athoc.iws.publishing.fillcount.viewModel.escalationAttributes);
                var data = _.find(toData, function (toItem) {
                    return Id === toItem.Id;
                });
                var escalationDiv = $("#divEscalationAttributeBreadCrum");
                var template = kendo.template($("#fillCountEscalate-template").html());
                var lessdata = '';
                var moredata = '';
                var noitems = 0;
                var txtStyle = "font-size:11px; white-space:nowrap;display:none";
                data = data.Values;
                if (data == null || Id == 0) {
                    escalationDiv.hide();
                    return;
                } else
                    escalationDiv.show();
                if (!athoc.iws.publishing.fillcount.viewModel.fillCountModel.GroupByAscending())
                    data = data.reverse();

                for (var i = 0; i < data.length; i++) {                         
                    if ((lessdata == moredata) && this.fnCalcTextWidth("", txtStyle, ((lessdata + (lessdata != "" ? " > " : "") + data[i]) + " and more...")) < 385) { 
                        lessdata = lessdata + (lessdata != "" ? " > " : "") + data[i];
                        noitems++;
                    }
                    if (data.length > 1)
                        moredata = moredata + (moredata != "" ? " > " : "") + data[i];
                }
                if (lessdata == moredata)
                    moredata = "";
                noitems = ((data.length) - noitems);
                var data = { more: moredata, less: lessdata, items: noitems };
                var result = template(data);
                $("#escalationAttributeBreadCrum").html(result);
                
                if (moredata != "")
                    $("#morelinkfillcount").show();
                else
                    $("#morelinkfillcount").hide();
            },
            fnCalcTextWidth: function (Class,Style,text) {
                var tmpSpan = $('<span id="escalationAttributeBreadCrumTmp" ' + (Class != '' ? ' class="' + Class + '" ' : '') + '  ' + (Style != '' ? ' style="' + Style + '" ' : '') + ' >' + text + '</span>')
                      .appendTo($('body'));
                columnWidth = tmpSpan.width();
                tmpSpan.remove();
                return columnWidth;
            },
            // Subcribe Methods to capture changed state
            fillCountSubscribeMethods: function () {
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.EnableControlledDelivery.subscribe(function (newValue) {
                    if (!newValue)
                        athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType(1);
                    else
                        athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType(2);
                });
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.EnableEscalation.subscribe(function (newValue) {
                    ///IWS-15930
                    //athoc.iws.utilities.resizeModalBasedOnScreenwithCenter($('#FillCount'), 600, 770, (navigator.userAgent.toLocaleLowerCase().indexOf('mozilla') != -1 ? 25 : 40), 170, 720, 40, 770);
                    if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime() == "" || isNaN(athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime()))
                        athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime('15');
                    if (!newValue) {
                        athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType(0);
                    } else
                        athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType(athoc.iws.publishing.fillcount.viewModel.fillCountModel.EnableControlledDelivery() ? 2 : 1);
                    athoc.iws.publishing.fillcount.fcDivScrollEventActions();
                });

                athoc.iws.publishing.fillcount.viewModel.fillCountModel.FillCount.subscribe(function (newValue) {
                    ///IWS-15930
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.FillCount($.trim(newValue));
                });

                athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId.subscribe(function (newValue) {

                });

                athoc.iws.publishing.fillcount.viewModel.fillCountModel.GroupByAscending.subscribe(function (newValue) {
                    athoc.iws.publishing.iut.readOnlySortColumn = "";
                    athoc.iws.publishing.iut.readOnlySortOrder = "";
                    athoc.iws.publishing.fillcount.escalationBreadCrum(athoc.iws.publishing.fillcount.viewModel.fillCountModel.EscalationAttributeId());
                });



                athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime.subscribe(function (newValue) {
                    ///IWS-15930
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime($.trim(newValue));
                });

                athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTimeUnit.subscribe(function (newValue) {
                });

                athoc.iws.publishing.fillcount.viewModel.fillCountModel.EscalationAttributeId.subscribe(function (newValue) {

                    // if (athoc.iws.publishing.iut.readOnlySortColumn != null || athoc.iws.publishing.iut.readOnlySortColumn!=undefined)

                    athoc.iws.publishing.iut.readOnlySortColumn = "";
                    athoc.iws.publishing.iut.readOnlySortOrder = "";

                    athoc.iws.publishing.fillcount.escalationBreadCrum(newValue);


                });

                /*      athoc.iws.publishing.fillcount.viewModel.fillCountModel.PhoneAttributeId.subscribe(function (newValue) {
                          if (newValue == 0) {
                              $("#ErrorMsg_EscalationAttributeId").css('display', "none");
                              /// TODO move text to resource file
                              $("#ErrorMsg_PhoneAttributeId").html(athoc.iws.publishing.fillcount.resources.FillCount_FieldRequired);
                              $("#ErrorMsg_PhoneAttributeId").css('display', "inline-block");
                          }
                      });*/
            },

            // data from server side
            bind: function (data, isReadOnly) {

                athoc.iws.publishing.fillcount.isTUSectionReadonly = isReadOnly;

                //reset fill count model  based on fill count settings
                if (athoc.iws.publishing.fillcount.clearFillCountData(data.ScenarioSettings.Targeting.FillCount, data.FillCount))
                    return;

                // initilize data model
                athoc.iws.publishing.fillcount.initializeFillCountModel(data);
                // make sure to verify scenario setting before loading the data               

                if (!isReadOnly) {
                    athoc.iws.publishing.fillcount.enableFillCountSummary(data.ScenarioSettings.Targeting.FillCount);
                    $("#fillCountContent").find(".bootstrap-select").remove();
                    ko.cleanNode($("#fillCountContent").get(0));
                    ko.applyBindings(athoc.iws.publishing.fillcount.viewModel, $("#fillCountContent").get(0));
                    athoc.iws.publishing.fillcount.fillCountSubscribeMethods();
                    athoc.iws.publishing.fillcount.initiatePickers();
                } else {
                    athoc.iws.publishing.fillcount.readOnlyFillCountSummary(null, $("#publishing-user-detail"), false, data.ScenarioSettings.Targeting.FillCount);
                }
            },

            // to clear the fill count on removing  the fill count settings
            clearFillCountData: function (isFillCountEnabled, fillCountData) {
                if (!isFillCountEnabled && fillCountData != null && athoc.iws.publishing.fillcount.viewModel.fillCountModel.EntityId != undefined) {
                    var entityId = athoc.iws.publishing.fillcount.viewModel.fillCountModel.EntityId();
                    // default model values to fill count model
                    athoc.iws.publishing.fillcount.setDefaultFillCountModel();
                    return true;
                }
                return false;
            },

            // to enable or disable the fill count summary based on scenario settings and readonly mode
            enableFillCountSummary: function (isFillCountEnabled) {
                if (!isFillCountEnabled) {
                    $("#publishing-user-edit").find("#FillCountLink").hide();
                    $("#publishing-user-edit").find("#EditFillCountDetails").hide();
                    $("#publishing-user-edit").find("#FillCountSummary").hide();
                    return;
                }
                var showflag = athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId() > -1;
                // check if fill count data exists
                athoc.iws.publishing.fillcount.toggleFillCountSummary(showflag, $("#publishing-user-edit"));
            },

            // Show or Hide Fill Count Summary
            toggleFillCountSummary: function (ishowflag, targetDiv) {
                if (ishowflag) {
                    targetDiv.find("#FillCountSummary").show();
                    targetDiv.find("#EditFillCountDetails").show();
                    targetDiv.find("#FillCountLink").hide();
                    athoc.iws.publishing.fillcount.ShowFillCountSummary(athoc.iws.publishing.fillcount.fillCountSummary, targetDiv);
                } else {
                    targetDiv.find("#FillCountLink").show();
                    targetDiv.find("#EditFillCountDetails").hide();
                    targetDiv.find("#FillCountSummary").hide();
                }
            },

            // to show readOnly view of Fill Count Summary
            readOnlyFillCountSummary: function (data, targetDiv, isPublishing, isFillCountEnabled) {

                if (data == null || (athoc.iws.publishing.fillcount.clearFillCountData(isFillCountEnabled, data.FillCount)) || (!isFillCountEnabled)) return;
                targetDiv.find("#EditFillCountDetails").hide();
                targetDiv.find("#FillCountLink").hide();

                if (data != null)
                    athoc.iws.publishing.fillcount.initializeReadOnlyFillCountModel(data);
                var showflag = data == null ? athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId() > -1 : data.FillCount != null && data.FillCount.ResponseOptionId > -1;
                if (showflag) {
                    targetDiv.find("#FillCountDetails").show();
                    targetDiv.find("#FillCountSummary").show();
                    if (athoc.iws.publishing.fillcount.fillCountSummary != null)
                        athoc.iws.publishing.fillcount.ShowFillCountSummary(athoc.iws.publishing.fillcount.fillCountSummary, targetDiv);
                } else {
                    targetDiv.find("#FillCountDetails").hide();
                    targetDiv.find("#FillCountSummary").hide();
                }
            },
            //  // initialize view model for Scenario or Alert Edit
            initializeFillCountModel: function (data) {
                data.EscalationAttributes.unshift({ Id: 0, Name: $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_SelectanAttribute), Values: [] });
                athoc.iws.publishing.fillcount.viewModel.escalationAttributes = ko.mapping.fromJS(data.EscalationAttributes);
                //data.SequencingAttributes.unshift({ Id: 0, Name: "Select an Attribute", Values: [] });
                //athoc.iws.publishing.fillcount.viewModel.phonesequencingAttributes = ko.mapping.fromJS(data.SequencingAttributes);
                athoc.iws.publishing.fillcount.viewModel.responseOptions = ko.mapping.fromJS(athoc.iws.publishing.fillcount.fillResponses(data.Content.ResponseOptions));
                athoc.iws.publishing.fillcount.fillCountSummary = ko.mapping.fromJS(athoc.iws.publishing.fillcount.defaultFillCountSummary);
                athoc.iws.publishing.fillcount.viewModel.fillCountModel = ko.mapping.fromJS(athoc.iws.publishing.fillcount.setFillCountCustModel(data), athoc.iws.publishing.fillcount.getValidation());

                if (data.FillCount != null) {
                    /// TODO  Remove below attributes if they are not being used

                    data.FillCount.EscalationAttributeId = data.FillCount.ControlledDeliveryType != 0 ? data.FillCount.ControlledDeliveryAttributeId : 0;

                    //data.FillCount.PhoneAttributeId = data.FillCount.ControlledDeliveryType == 2 ? data.FillCount.ControlledDeliveryAttributeId : 0;
                    athoc.iws.publishing.fillcount.setFillCountSummary(data.FillCount, athoc.iws.publishing.fillcount.defaultFillCountSummary);
                }


            },

            // set Fill Count Cust Model for UI binding
            setFillCountCustModel: function (data) {
                var model = {};
                if (data.FillCount != null) {
                    model.ResponseOptionId = data.FillCount.ResponseOptionId;
                    model.AnyResponseOption = data.FillCount.AnyResponseOption;
                    model.FillCount = data.FillCount.FillCount;
                    model.ControlledDeliveryType = data.FillCount.ControlledDeliveryType;
                    // model.PhoneAttributeId = data.FillCount.ControlledDeliveryType == 2 ? data.FillCount.ControlledDeliveryAttributeId : 0;
                    // model.OrderByAscending = data.FillCount.ControlledDeliveryType == 2 ? data.FillCount.OrderByAscending : true;

                    var attributeName = athoc.iws.publishing.fillcount.getControlDeliveryAttributeValue(data.FillCount.ControlledDeliveryAttributeId, 1);
                    if (attributeName == $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_SelectanAttribute)) {
                        model.EscalationAttributeId = 0;
                        model.EnableEscalation = false;
                        model.ControlledDeliveryType = 0;
                        model.EnableControlledDelivery = data.FillCount.ControlledDeliveryType == 2 ? true : false;
                    } else {
                        model.EnableEscalation = data.FillCount.ControlledDeliveryType != 0 ? true : false;
                        model.EnableControlledDelivery = data.FillCount.ControlledDeliveryType == 2 ? true : false;
                        model.EscalationAttributeId = data.FillCount.ControlledDeliveryType != 0 ? data.FillCount.ControlledDeliveryAttributeId : 0;
                    }
                    model.WaitTime = data.FillCount.ControlledDeliveryAttributeId != 0 ? data.FillCount.WaitTime : athoc.iws.publishing.fillcount.defaultFillCount.WaitTime;
                    model.WaitTimeUnit = data.FillCount.ControlledDeliveryAttributeId != 0 ? data.FillCount.WaitTimeUnit : athoc.iws.publishing.fillcount.defaultFillCount.WaitTimeUnit;
                    model.GroupByAscending = data.FillCount.ControlledDeliveryAttributeId != 0 ? data.FillCount.OrderByAscending : true;
                    model.EntityId = data.FillCount.EntityId;
                }
                else
                    model = athoc.iws.publishing.fillcount.defaultFillCount;

                return model;
            },

            // initialize readonly fill Count model for Scenario or Alert or Publishing
            initializeReadOnlyFillCountModel: function (data) {
                athoc.iws.publishing.fillcount.viewModel.escalationAttributes = ko.mapping.fromJS(data.EscalationAttributes);
                //athoc.iws.publishing.fillcount.viewModel.phonesequencingAttributes = ko.mapping.fromJS(data.SequencingAttributes);
                athoc.iws.publishing.fillcount.viewModel.responseOptions = ko.mapping.fromJS(athoc.iws.publishing.fillcount.fillResponses(data.Content.ResponseOptions));
                athoc.iws.publishing.fillcount.fillCountSummary = ko.mapping.fromJS(athoc.iws.publishing.fillcount.defaultFillCountSummary);
                if (data.FillCount != null) {

                    data.FillCount.EscalationAttributeId = data.FillCount.ControlledDeliveryType != 0 ? data.FillCount.ControlledDeliveryAttributeId : 0;

                }
                if (data.FillCount != null && data.FillCount.ResponseOptionId > -1) {
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel = ko.mapping.fromJS(athoc.iws.publishing.fillcount.setFillCountCustModel(data));
                    athoc.iws.publishing.fillcount.setFillCountSummary(data.FillCount, athoc.iws.publishing.fillcount.defaultFillCountSummary);
                }
            },

            // fill Response Options from the content model
            fillResponses: function (responseList) {
                var i = 0;

                /// TODO move text to resource file
                var responseOptions = [{
                    Id: -1, Name: $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_SelectaResponseOption)
                }];
                if (responseList.length >= 1) {
                    _.each(responseList, function (item) {
                        i++;
                        if ($.trim(item.ResponseText) != "") {
                            responseOptions.push({ Id: i, Name: $.htmlDecode(item.ResponseText) });
                        }
                    });
                    responseOptions.push({ Id: 0, Name: $.htmlDecode( athoc.iws.publishing.fillcount.resources.FillCount_Any) });
                }

                return responseOptions;
            },

            // Refresh all select pickers , this is required when you enable and disable the dropdowns
            refreshPickers: function () {

                $("#fillCountResponses").selectpicker('refresh');
                $('#escalationAttribute').selectpicker('refresh');
                $('#waitTimeDuration').selectpicker('refresh');
                // $('#phoneAttribute').selectpicker('refresh');
            },

            // initiate all select pickers
            initiatePickers: function () {
                $("#fillCountResponses").selectpicker();
                $("#escalationAttribute").selectpicker();
                // $("#phoneAttribute").selectpicker();
                $("#waitTimeDuration").selectpicker();
            },

            // get model returns Fill Data Model  , same function works for new ,modify and delete
            getModel: function () {

                var data = ko.mapping.toJS(athoc.iws.publishing.fillcount.viewModel.fillCountModel);
                if (data == null || data == undefined || (data.ResponseOptionId == -1 && (data.EntityId == 0 || athoc.iws.publishing.entityId == 0)))
                    return null;
                // Re-calculate the responseId since some are empty.
                if (athoc.iws.publishing.content.viewModel.data.ResponseOptions != null || athoc.iws.publishing.view.viewModel.data.Content.ResponseOptions != null) {
                    var res = ko.mapping.toJS(athoc.iws.publishing.content.viewModel.data.ResponseOptions || athoc.iws.publishing.view.viewModel.data.Content.ResponseOptions);
                    var selectedRes = 0;
                    _.each(res, function (item, index) {
                        if (item.ResponseText != "")
                            selectedRes++;
                        if (data.ResponseOptionId == (index + 1)) {
                            data.ResponseOptionId = selectedRes;
                            return;
                        }
                    });
                }

                var fillcountdata = {
                    ID: 0,
                    ResponseOptionId: data.ResponseOptionId,
                    EntityId: data.EntityId,
                    AnyResponseOption: data.ResponseOptionId == 0 ? true : false,
                    FillCount: data.ResponseOptionId == -1 ? 0 : data.FillCount,
                    ControlledDeliveryAttributeId: data.ControlledDeliveryType != 0 ? data.EscalationAttributeId : 0,
                    WaitTime: data.ControlledDeliveryType != 0 ? data.WaitTime : 0,
                    WaitTimeUnit: data.ControlledDeliveryType != 0 ? data.WaitTimeUnit : null,
                    OrderByAscending: data.ControlledDeliveryType != 0 ? data.GroupByAscending : true,
                    ControlledDeliveryType: data.ControlledDeliveryType
                };
                return fillcountdata;
            },

            // return phone sequencing flag whether it is enabled or not
            isPhoneSequencingEnabled: function () {
                /* if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId() == -1)
                     return false;
                 var data = ko.mapping.toJS(athoc.iws.publishing.fillcount.viewModel.fillCountModel);
                 return data.ControlledDeliveryType == 2 ? true : false;*/
                return false;
            },
            // to verify whether
            isResponsesAvailable: function () {
                var data = athoc.iws.publishing.content.viewModel.data.ResponseOptions == undefined ? athoc.iws.publishing.view.viewModel.data.Content.ResponseOptions() : athoc.iws.publishing.content.viewModel.data.ResponseOptions();
                if (data.length >= 1) {
                    var flag = false;
                    _.each(data, function (item) {

                        if ($.trim(item.ResponseText()) != "") {
                            flag = true;
                            return;
                        }
                    });
                    return flag;
                }
                return false;
            },
            // Validation
            isValid: function () {
                if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId() < 0) {
                    /// TODO move text to resource file
                    $("#ErrorMsg_ResponseOptionId").html(athoc.iws.publishing.fillcount.resources.FillCount_FieldRequired);
                    $("#ErrorMsg_ResponseOptionId").css('display', "inline-block");
                }

                if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.EnableEscalation() && (athoc.iws.publishing.fillcount.viewModel.fillCountModel.EscalationAttributeId() == undefined || athoc.iws.publishing.fillcount.viewModel.fillCountModel.EscalationAttributeId() == 0)) {
                    /// TODO move text to resource file
                    $("#ErrorMsg_EscalationAttributeId").html(athoc.iws.publishing.fillcount.resources.FillCount_FieldRequired);
                    $("#ErrorMsg_EscalationAttributeId").css('display', "inline-block");
                }

                if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.EnableEscalation() && athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime() <= 0)
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime.valueHasMutated();

                athoc.iws.publishing.fillcount.fcDivScrollEventActions();

                //verify any error message is displayed
                var bValid = $("#FillCount").find(".warning-msg").is(':visible');
                return bValid;
            },
            // TODO : Bring entire show dailog logic here
            showConfirmationDialog: function (dialogType, itext) {
                itext = $.htmlDecode(itext);
                switch (dialogType) {

                    case 0:
                        //show dialog for delete response
                        $("#fillCountText").text(itext);
                        $("#btnResDeleteCancel").show();
                        $("#btnResDeleteConfirm").show();
                        $("#btnResDeleteConfirm").text(athoc.iws.publishing.fillcount.resources.Action_Button_Delete);
                        $("#btnInfo").hide();
                        $("#dialogResponseDeleteConfirm").modal("show");
                        break;
                    case 1:
                        // show dialog for clear
                        $("#fillCountText").text(itext);
                        $("#btnResDeleteCancel").show();
                        $("#btnResDeleteConfirm").show();
                        $("#btnResDeleteConfirm").text(athoc.iws.publishing.fillcount.resources.FillCount_Summary_ClearTitle);
                        $("#btnInfo").hide();
                        $("#dialogResponseDeleteConfirm").modal("show");
                        break;

                    case 2:
                        // show dialog for response change
                        $("#respnseChangeText").text(itext);
                        $("#dialogResponseChangeConfirm").modal("show");
                        break;
                    case 3:
                        //show  dialog for no response
                        $("#fillCountText").text(itext);
                        $("#btnResDeleteCancel").hide();
                        $("#btnResDeleteConfirm").hide();
                        $("#btnInfo").show();
                        $("#dialogResponseDeleteConfirm").modal('show');
                        break;
                    case -1:
                        if (athoc.iws.publishing.fillcount.confirmationDailogType == 1 || athoc.iws.publishing.fillcount.confirmationDailogType == 0 || athoc.iws.publishing.fillcount.confirmationDailogType == 3)
                            $("#dialogResponseDeleteConfirm").modal("hide");
                        else if (athoc.iws.publishing.fillcount.confirmationDailogType == 2) {
                            $("#dialogResponseChangeConfirm").modal("hide");
                        }
                        athoc.iws.publishing.fillcount.confirmationDailogType = 0;
                        break;

                }
            },

            // On response delete  this method is invoke
            setFillCountOnResponseDelete: function (index) {
                athoc.iws.publishing.fillcount.deleteResponseIndex = index;
                var responseCount = athoc.iws.publishing.content.viewModel.data.ResponseOptions().length;
                var data = ko.mapping.toJS(athoc.iws.publishing.fillcount.viewModel.fillCountModel);
                if (data.ResponseOptionId == 0 && responseCount == 1) {
                    /// TODO move text to resource file
                    athoc.iws.publishing.fillcount.showConfirmationDialog(0, athoc.iws.publishing.fillcount.resources.FillCount_DeleteAnymsg);
                    return false;
                } else if ((index + 1) == data.ResponseOptionId) {
                    /// TODO move text to resource file
                    athoc.iws.publishing.fillcount.showConfirmationDialog(0, athoc.iws.publishing.fillcount.resources.FillCount_Deletemsg);

                    return false;
                }

                if (data.ResponseOptionId > index)
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId(data.ResponseOptionId - 1);
                return true;
            },

            /// TODO move  fill count default settings to here
            setDefaultFillCountModel: function () {
                var entityId = athoc.iws.publishing.fillcount.viewModel.fillCountModel.EntityId();
                // default model values to fill count model
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId(athoc.iws.publishing.fillcount.defaultFillCount.ResponseOptionId);
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.AnyResponseOption(athoc.iws.publishing.fillcount.defaultFillCount.AnyResponseOption);
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.FillCount(athoc.iws.publishing.fillcount.defaultFillCount.FillCount);
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.EntityId(entityId);
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.EscalationAttributeId(athoc.iws.publishing.fillcount.defaultFillCount.EscalationAttributeId);
                $('#escalationAttribute').selectpicker('refresh');
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime(athoc.iws.publishing.fillcount.defaultFillCount.WaitTime);
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTimeUnit(athoc.iws.publishing.fillcount.defaultFillCount.WaitTimeUnit);
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.GroupByAscending(athoc.iws.publishing.fillcount.defaultFillCount.GroupByAscending);
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.EnableEscalation(athoc.iws.publishing.fillcount.defaultFillCount.EnableEscalation);
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.EnableControlledDelivery(athoc.iws.publishing.fillcount.defaultFillCount.EnableControlledDelivery);
                //athoc.iws.publishing.fillcount.viewModel.fillCountModel.PhoneAttributeId(athoc.iws.publishing.fillcount.defaultFillCount.PhoneAttributeId);
                //athoc.iws.publishing.fillcount.viewModel.fillCountModel.OrderByAscending(athoc.iws.publishing.fillcount.defaultFillCount.OrderByAscending);
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType(athoc.iws.publishing.fillcount.defaultFillCount.ControlledDeliveryType);
                athoc.iws.publishing.fillcount.isChanged = true;

                if (!athoc.iws.publishing.fillcount.isTUSectionReadonly) {
                    $("#publishing-user-edit").find("#FillCountLink").show();
                    $("#publishing-user-edit").find("#FillCountSummary").hide();
                } else {
                    $("#publishing-user-detail").find("#FillCountSummary").hide();
                }
            },

            // to set  fill count model to default in case of delete or clear function is invoked
            responseChangeAction: function () {
                var cdType = athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType();
                athoc.iws.publishing.fillcount.setDefaultFillCountModel();
                switch (cdType) {
                    case 1:
                        $('#escalationAttribute').selectpicker('refresh');
                        var escalationDiv = $("#EscalationAttributeBreadCrum");
                        escalationDiv.hide();
                        escalationDiv.html("");
                        break;
                    case 2:
                        $('#phoneAttribute').selectpicker('refresh');
                        break;
                }
                if (athoc.iws.publishing.fillcount.confirmationDailogType == 0)
                    athoc.iws.publishing.content.viewModel.deleteResponseOption(athoc.iws.publishing.fillcount.deleteResponseIndex);
                else if (athoc.iws.publishing.fillcount.confirmationDailogType == 3)
                    athoc.iws.publishing.content.responseOptionChanged();
                athoc.iws.publishing.fillcount.showConfirmationDialog(-1, "");
            },

            // On response change this method is invoked
            responseChange: function (index, chngText) {
                if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId != null && athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId() - 1 == index) {
                    /// TODO move text to resource file
                    athoc.iws.publishing.fillcount.confirmationDailogType = 2;
                    athoc.iws.publishing.fillcount.responseChangedText = chngText;
                    //athoc.iws.publishing.fillcount.fillCountSummary.ResponseText(chngText);
                    if (!athoc.iws.publishing.fillcount.isTUSectionReadonly)
                        athoc.iws.publishing.fillcount.ShowFillCountSummary(athoc.iws.publishing.fillcount.fillCountSummary, $("#publishing-user-edit"));
                    else
                        athoc.iws.publishing.fillcount.ShowFillCountSummary(athoc.iws.publishing.fillcount.fillCountSummary, $("#publishing-user-detail"));

                    if ($.trim(chngText) == "") {
                        athoc.iws.publishing.fillcount.showConfirmationDialog(3, athoc.iws.publishing.fillcount.resources.FillCount_ResponseConfirm_Msg);
                        athoc.iws.publishing.fillcount.responseChangeAction();
                    } else if (athoc.iws.publishing.fillcount.fillCountSummary.ResponseText() != $.trim(chngText))
                        athoc.iws.publishing.fillcount.showConfirmationDialog(2, athoc.iws.publishing.fillcount.resources.FillCount_ModResponsemsg);
                }
            },

            reponseTypeChange: function () {
                if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId != null && athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId() > -1) {
                    athoc.iws.publishing.fillcount.confirmationDailogType = 3;
                    athoc.iws.publishing.fillcount.showConfirmationDialog(1, athoc.iws.publishing.fillcount.resources.FillCount_ModResponseConf);
                }
            },

            // Fill Count UI validation
            getValidation: function () {
                athoc.iws.publishing.fillcount.fcDivScrollEventActions();
                var validationMapping = {
                    FillCount: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                required: {params:true, message:athoc.iws.publishing.fillcount.resources.FillCount_FieldRequired},
                                min: { params: 1, message: athoc.iws.scenario.resources.Scenario_Schedule_Err_NumberLessThanOne },
                                /// TODO move text to resource file
                                maxLength: { params: 7, message: athoc.iws.publishing.fillcount.resources.FillCount_ExceedMaxLength },
                                pattern: {
                                    message: athoc.iws.publishing.fillcount.resources.FillCount_OnlyNummsg,
                                    params: "^[0-9]+$"
                                }
                            });
                        }
                    },
                    WaitTime: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                /// TODO move text to resource file
                                maxLength: { params: 7, message: athoc.iws.publishing.fillcount.resources.FillCount_ExceedMaxLength },
                                min: { params: 1, message: athoc.iws.scenario.resources.Scenario_Schedule_Err_NumberLessThanOne },
                                required: { params: true, message: athoc.iws.publishing.fillcount.resources.FillCount_FieldRequired },
                                pattern: {
                                    /// TODO move text to resource file
                                    message: athoc.iws.publishing.fillcount.resources.FillCount_OnlyNummsg,
                                    params: "^[0-9]+$"
                                },
                            });
                        }
                    },
                };
                return validationMapping;
            },


        };

    }();
}
