﻿define([
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/array",
"dijit/_WidgetBase",
"dijit/_TemplatedMixin",
"dojo/Evented",
"dojo/dom-style",
"dojo/on",
"dojo/query",
"dojo/text!publishing/Placeholder/PlaceholderTemplate.html"
],
function (declare, lang, array, _WidgetBase, _TemplatedMixin, Evented, domStyle, on, query, template) {
    var Placeholder = declare("athoc.iws.publishing.placeholder", [_WidgetBase, _TemplatedMixin, Evented], {
        templateString: template,
        constructor: function (options, srcRefNode) {
            //common code for tool
            this.textField = options.textField;//this is the input textbox
            if (options) {
                this.options = options;
                this.visible = options.visible == undefined ? true : options.visible;
                this.showOnLeft = options.left == undefined ? false : options.left;
                this.isStatic = options.isStatic == undefined ? false : options.isStatic;
                this.isEventPlaceholder = options.isEventPlaceholder != null ? options.isEventPlaceholder : false;
            }
            var placeHolderTitle=(athoc.iws.scenario.resources.Scenario_Content_Select_Alert_Placeholder ? athoc.iws.scenario.resources.Scenario_Content_Select_Alert_Placeholder : athoc.iws.publishing.resources.Publishing_Content_Select_Alert_Placeholder);
            if (options.isPA && athoc.iws.publishing.resources.Account_SelectEventPlaceholder)
                placeHolderTitle = athoc.iws.publishing.resources.Account_SelectEventPlaceholder;
            //define viewmodel here...
            this.viewModel = kendo.observable(
                  {
                      Placeholders: options.items,
                      PlaceholderTitle: options.placeHolderTitle ? options.placeHolderTitle : placeHolderTitle,
                  });
        },

        startup: function () {
            //common code for tool
            //bind to viewmodel etc.
            //this.domNode is the domNode injected by dojo
            //this.placeholderBtn is the dom obj defined by data-dojo-attach-point="placeholderBtn"
            this.inherited(arguments);
            kendo.bind($(this.domNode), this.viewModel);
            var q = query(".text-select", this.domNode);
            var self = this;
            on(q, "click", function (e) {
                self.addPlaceHolder(e);
            });

            on(this.textField, "keydown, keyup, change", function(e) {
                self.adjustButton(e);
            });

            $("span.placeholder-add-wrap", this.domNode).toggleClass("static", this.isStatic);
            $("span.placeholder-add", this.domNode).toggleClass("position-right5", $(this.textField).width() < 350);
                        
            if (!this.isEventPlaceholder) {
                $("div.placeholder-add-panel", this.domNode).toggleClass("custom-option-placeholder-position", $(this.textField).width() < 350);
                $("div.placeholder-add-panel", this.domNode).toggleClass("position-right-neg538", $(this.textField).width() < 350);
            }
            $("div.placeholder-add-panel", this.domNode).toggleClass("left", this.showOnLeft);

            
        },

        adjustButton: function (e) {
            $(".placeholder-add", this.domNode).toggleClass("position-right20", this.textField.clientHeight < this.textField.scrollHeight);
        },

        showDropDown: function (e) {
            //show dropdown
            $(this.placeholderPanel).show();
            //only id attr selector appears to be working, not #...
            var q = kendo.format("div.placeholder-add-panel:not([id='{0}-addPanel']):visible", this.id);
            //hide other placeholders 
            $(q).hide();
            e.stopPropagation();
        },

        addPlaceHolder: function (e) {
            var phText = $(e.target).attr("dn");
            this.insertAtCaret(phText);
            $(this.textField).change();//need to manually fire change for the textbox.
        },

        insertAtCaret: function (text) {
            var txtarea = this.textField;
            var scrollPos = txtarea.scrollTop;
            var strPos = 0;
            var br = ((txtarea.selectionStart || txtarea.selectionStart == '0') ?
                "ff" : (document.selection ? "ie" : false));
            if (br == "ie") {
                txtarea.focus();
                var range = document.selection.createRange();
                range.moveStart('character', -txtarea.value.length);
                strPos = range.text.length;
            }
            else if (br == "ff") {
                if (AthocXBrowser.IsIE9() === true)
                    strPos = txtarea.value.length;
                else
                    strPos = txtarea.selectionStart;
            }

            var front = (txtarea.value).substring(0, strPos);
            var back = (txtarea.value).substring(strPos, txtarea.value.length);
            txtarea.value = front + text + back;
            strPos = strPos + text.length;
            if (br == "ie") {
                txtarea.focus();
                var range = document.selection.createRange();
                range.moveStart('character', -txtarea.value.length);
                range.moveStart('character', strPos);
                range.moveEnd('character', 0);
                range.select();
            }
            else if (br == "ff") {
                txtarea.selectionStart = strPos;
                txtarea.selectionEnd = strPos;
                txtarea.focus();
            }
            txtarea.scrollTop = scrollPos;
        }
    });

    return Placeholder;
});