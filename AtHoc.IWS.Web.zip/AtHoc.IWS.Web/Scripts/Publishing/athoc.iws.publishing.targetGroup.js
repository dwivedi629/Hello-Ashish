﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};

athoc.iws.publishing.TargetGroup = function (treeContainer) {
    var self = this;
    this.ViewModel = kendo.observable(
                  {
                      Devices: [],
                      SelectedNodes: [],
                      TargetedUserCountForLiveEndedAlert: "0",

                      TargetedGroups: function () {
                          var nodes = this.get("SelectedNodes");
                          return $.grep(nodes, function (i) {
                              return !i.IsBlocked;
                          });
                      },

                      TargetedGroupsFormatted: function () {
                          var tg = this.TargetedGroups();
                          return self._formatGroups(tg);
                      },

                      BlockedGroups: function () {
                          var nodes = this.get("SelectedNodes");
                          return $.grep(nodes, function (i) {
                              return i.IsBlocked;
                          });
                      },

                      BlockedGroupsFormatted: function () {
                          var bg = this.BlockedGroups();
                          return self._formatGroups(bg);
                      },

                      ExpandAll: function (e) {
                          self.TreeView.expand(".k-item");
                      },
                      CollapseAll: function (e) {
                          self.TreeView.collapse(".k-item:not(li:first)");
                      },
                      Visible: function () {
                          return this.get("Devices").length > 0 && this.get("SelectedNodes").length > 0;
                      },
                  });

    this._formatGroups = function (groups) {
        var x = {};
        var nodes = groups;// this.get("SelectedNodes");
        for (var i = 0; i < nodes.length; ++i) {
            var n = nodes[i];
            switch (n.Type) {
                case 0:
                case 1:
                case 3:
                    if (x[n.Name] == undefined)
                        x[n.Name] = [];
                    x[n.Name].push({ Type: n.Type, Item: athoc.iws.publishing.resources.Publishing_TargetUsers_All_Selected });
                    break;
                case 2:
                    if (x[n.ParentName] == undefined)
                        x[n.ParentName] = [];
                    x[n.ParentName].push({ Type: n.Type, Item: n.Name });
                    break;
                case 4:
                case 5:
                    if (x[n.RootName] == undefined) {
                        x[n.RootName] = [];
                    }
                    if (n.Type == 5) {
                        x[n.RootName].push({ Type: n.Type, Item: n.Name });
                    } else {
                        if (n.Lineage) {
                            x[n.RootName].push({ Type: n.Type, Item: kendo.format("{0}{1}/", n.Lineage, n.Name) });
                        } else {
                            x[n.RootName].push({ Type: n.Type, Item: kendo.format(n.Type == 4 ? "{0}" : "/{0}/", n.Name) }); //loading on review/publish
                        }
                    }
                    break;
            }
        }
        var ret = Object.keys(x).map(function (k) {
            return { Group: k, Items: x[k], Type: x[k][0] != undefined ? x[k][0].Type : -1 }
        });
        return ret;

    };

    this.LoadViewModel = function (data) {
        if (arguments.length > 0) {
            self.ViewModel.set("SelectedNodes", data.TargetingNodes);
            self.ViewModel.set("Devices", data.Devices);
        }
        kendo.bind($(".kTGBound"), self.ViewModel);
    };

    this.toggleBlock = function (a) {
        var item = $(a).closest("li");
        //if (item.hasClass("k-state-disabled"))
        //    return;

        var node = self.TreeView.dataItem(item);
        var val = !node.get("IsBlocked");
        self._toggleBlockStateForNode(item, val);
        if (node.hasChildren)
            self._toggleBlockChildren(node.Children, val);

        //need to wait till all block state is reset and then fire check
        var checkbox = item.find(":checkbox").first();
        checkbox.trigger("click");
    };

    this.showCheckBox = function (node) {
        var ret = true;
        if (node.Type == 3 && !node.HasChildren)//if a root has no chilren, don't show checkbox
        {
            node.Name += node.SubType == 0 ? athoc.iws.publishing.resources.Publishing_TargetUsers_EmptyHierarchy : athoc.iws.publishing.resources.Publishing_TargetUsers_EmptyFolder;
            node.Type = 6; //go ahead and hide the node, treat it as a dummy node. IWS-11867
            ret = false;
        }
        else if (!node.IsTargetable) {
            ret = false;
        }
        return ret;
    };

    this._selectionChanged = function (node) {
        var targetedNodes = [];
        var blockedNodes = [];
        //due to target and block being mixed in one tree and to accomadate all scenarios, 
        //we need to traverse the tree seperately for getting targeted and blocked nodes
        self._getTargetedNodes(node, self.TreeView.dataSource.view(), targetedNodes);
        self._getBlockedNodes(node, self.TreeView.dataSource.view(), blockedNodes);
        var selectedNodes = targetedNodes.concat(blockedNodes);
        self.ViewModel.set("SelectedNodes", selectedNodes);
    };

    //check to see if the given node is a child of the parent node
    this._checkIfChildExists = function (node, nodes) {
        var childFound;
        var found = [];
        for (var i = 0; i < nodes.length; i++) {
            if (nodes[i].Name == node.Name && nodes[i].Id == node.Id)
                found.push(nodes[i]);
            else if (nodes[i].hasChildren) {
                childFound = self._checkIfChildExists(node, nodes[i].Children);
                if (childFound.length > 0) {
                    //var treeNode = self.TreeView.findByUid(nodes[i].uid);
                    //var chk = treeNode.find('input:checkbox').first();
                    //var img = treeNode.find('div.targeting-sprite').first();
                    //var item = nodes[i];
                    //item.set("CommandText", "Block");
                    //item.set("IsBlocked", false);
                    //item.set("checked", false);
                    //img.hide();
                    //chk.show();
                    found = found.concat(childFound);
                }
            }
        }
        return found;
    };

    this._hideFakeNodes = function (nodes) {
        if (nodes) {
            for (var i = 0; i < nodes.length; i++) {
                var treeNode = self.TreeView.findByUid(nodes[i].uid);
                if (nodes[i].Type == 6) {
                    treeNode.hide();
                }
                if (nodes[i].hasChildren) {
                    self._hideFakeNodes(nodes[i].Children);
                }
            }
        }
    };

    //_getTargetedNodes gets the targeted nodes as well as setting the correct state of all nodes
    this._getTargetedNodes = function (node, nodes, targetedNodes, parent, root) {

        for (var i = 0; i < nodes.length; i++) {
            var treeNode = self.TreeView.findByUid(nodes[i].uid);
            var chk = treeNode.find('input:checkbox').first();
            var img = treeNode.find('div.targeting-sprite').first();
            //the below logic is to retain the block/unblock state for the parent nodes
            var found = node && nodes[i].hasChildren ? self._checkIfChildExists(node, nodes[i].Children) : [];
            if (nodes[i].IsBlocked && found.length > 0) {
                var item = nodes[i];
                item.set("CommandText", athoc.iws.scenario.resources.Publishing_TargetUsers_Block ? athoc.iws.scenario.resources.Publishing_TargetUsers_Block : athoc.iws.publishing.resources.Publishing_TargetUsers_Block);
                item.set("IsBlocked", false);//unblocking child should unblock parent
                //item.set("checked", false);
                img.hide();
                chk.show();
            }

            //Mohit: if any child is unchecked, also uncheck the fake node.
            if (node && parent && nodes[i].Type == 6 && !node.checked)
                nodes[i].set("checked", false);

            var r = !root && nodes[i].Type == 3 ? nodes[i] : root;
            //this is where we save the targeted nodes and we need to check to see if it's not blocked
            //otherwise, we need to keep traversing the tree to set the correct blocked state for each node
            if (nodes[i].checked && !nodes[i].IsBlocked && nodes[i].Type != 6 && nodes[i].IsTargetable) {
                var parentId = 0;
                var parentName = "";
                try {
                    parentId = parent.Id;
                    parentName = parent.Name;
                } catch (e) {

                }

                //creating a flat list here for save()
                targetedNodes.push({
                    Id: nodes[i].Id,
                    Name: nodes[i].Name,
                    Type: nodes[i].Type,
                    Lineage: nodes[i].Lineage,
                    ParentId: parentId,
                    ParentName: parentName,
                    SubType: nodes[i].SubType,
                    RootId: root != null ? root.Id : 0,
                    RootName: root != null ? root.Name : "",
                    DlType: nodes[i].DlType,
                    //IsBlocked: nodes[i].IsBlocked
                    //todo: add IsBlocked
                });
            }
            else if (nodes[i].hasChildren) {
                self._getTargetedNodes(node, nodes[i].children.view(), targetedNodes, nodes[i], r);
            }
        }
    };

    //_getBlockedNodes gets the blocked nodes only
    this._getBlockedNodes = function (node, nodes, blockedNodes, parent, root) {

        for (var i = 0; i < nodes.length; i++) {
            var r = !root && nodes[i].Type == 3 ? nodes[i] : root;
            //this is where we save the targeted nodes and we need to check to see if it's not blocked
            //otherwise, we need to keep traversing the tree to set the correct blocked state for each node
            if (nodes[i].IsBlocked && nodes[i].Type != 6) {
                var parentId = 0;
                var parentName = "";
                try {
                    parentId = parent.Id;
                    parentName = parent.Name;
                } catch (e) {

                }

                //creating a flat list here for save()
                blockedNodes.push({
                    Id: nodes[i].Id,
                    Name: nodes[i].Name,
                    Type: nodes[i].Type,
                    Lineage: nodes[i].Lineage,
                    ParentId: parentId,
                    ParentName: parentName,
                    SubType: nodes[i].SubType,
                    RootId: root != null ? root.Id : 0,
                    RootName: root != null ? root.Name : "",
                    DlType: nodes[i].DlType,
                    IsBlocked: nodes[i].IsBlocked
                    //todo: add IsBlocked
                });
            }
            else if (nodes[i].hasChildren) {
                self._getBlockedNodes(node, nodes[i].children.view(), blockedNodes, nodes[i], r);
            }
        }
    };

    this._initializeTreeView = function () {
        self.TreeView.updateIndeterminate();
        var lastElement = self.TreeView.wrapper.find("li:last");
        var node = self.TreeView.dataItem(lastElement);
        if (node != null && node.Type == 3)
            self.TreeView.expand(lastElement);
        self._setSort(self.TreeView.dataSource.view());
    };

    this._setSort = function (items) {
        for (var i = 0; i < items.length; i++) {

            // Only perform sorting on Distribution List Node
            if (items[i].SubType && items[i].SubType == 1) {
                if (items[i].hasChildren) {
                    items[i].children.sort({ field: "Name", dir: "asc", field: "SortOrder", dir: "asc" });
                    self._setSort(items[i].children.view());
                }
            }
        }
    };

    this._toggleBlockChildren = function (children, blocked) {
        for (var i = 0; i < children.length; i++) {
            var item = self.TreeView.findByUid(children[i].uid);
            //item.toggleClass('k-state-disabled', blocked);
            self._toggleBlockStateForNode(item, blocked);
            if (children[i].hasChildren) {
                self._toggleBlockChildren(children[i].Children, blocked);
            }
        }
    };

    this._toggleBlockStateForNode = function (treeNode, val) {
        var item = self.TreeView.dataItem(treeNode);
        item.set("CommandText", val ? (athoc.iws.scenario.resources.Publishing_TargetUsers_Unblock ? athoc.iws.scenario.resources.Publishing_TargetUsers_Unblock : athoc.iws.publishing.resources.Publishing_TargetUsers_Unblock) : (athoc.iws.scenario.resources.Publishing_TargetUsers_Block ? athoc.iws.scenario.resources.Publishing_TargetUsers_Block : athoc.iws.publishing.resources.Publishing_TargetUsers_Block));
        item.set("IsBlocked", val);
        item.set("checked", !val); //Mohit: block will check/uncheck nodes
        //todo: store blocked nodes...
        var chk = treeNode.find('input:checkbox').first();
        var img = treeNode.find('div.targeting-sprite').first();
        if (val) {
            chk.hide();
            img.show();
        } else {
            img.hide();
            chk.show();
        }
    };

    this.showBlockBtn = function (node) {
        var ret = athoc.iws.publishing.settings.IsGroupBlockSupported && node.Type > 0;
        if (ret && node.Type == 3 && !node.HasChildren) {
            ret = false;
        }
        return ret;
    };


    this.TreeView = $(treeContainer).kendoTreeView({
        autoBind: false,
        loadOnDemand: false,//setting this to false will cause the tree to load all child initially
        checkboxes: {
            checkChildren: true,
            template: "# if(athoc.iws.publishing.targetUsers.targetGroupInstance.showCheckBox(item)){# <div class='targeting-sprite blocked' #=item.IsBlocked ? '' : 'style=\"display:none\"' #></div><input type='checkbox' #=item.checked ? 'checked' : '' # #=item.IsBlocked ? 'style=\"display:none\"' : '' # /> #} #"
        },
        template: "<div class=\"tree-block\"># if(athoc.iws.publishing.targetUsers.targetGroupInstance.showBlockBtn(item)){# <a onclick=\"athoc.iws.publishing.targetUsers.targetGroupInstance.toggleBlock(this)\">#=item.IsBlocked? (athoc.iws.scenario.resources.Publishing_TargetUsers_Unblock ? athoc.iws.scenario.resources.Publishing_TargetUsers_Unblock : athoc.iws.publishing.resources.Publishing_TargetUsers_Unblock)  : (athoc.iws.scenario.resources.Publishing_TargetUsers_Block ? athoc.iws.scenario.resources.Publishing_TargetUsers_Block : athoc.iws.publishing.resources.Publishing_TargetUsers_Block)#</a>#} #</div><div class=\"ellipsis\" style=\"width:400px\" title=\"#=$.customizedHtmlEncoding(item.Name)# \">#=$.htmlEncode(item.Name)#</div>",
        check: function (e) {//check fires once when all the checked states have changed
            var item = self.TreeView.dataItem(e.node);
            self._selectionChanged(item);
        },
        dataBound: function (e) {
            if (!e.node) {//dataBound is fired for each node but not the last one
                self._initializeTreeView();
                self._hideFakeNodes(this.dataSource.view());
                self._selectionChanged();//walk through the tree and get the selection in case user press 'Save' right away w/o changing the tree selection
            }
            
        },
        dataTextField: "CommandText",
    }).data("kendoTreeView");

    this.RefreshTreeView = function (data) {
        self.TreeView.setDataSource(new kendo.data.HierarchicalDataSource({
            data: data.TargetingTree,
            schema: {
                model: {
                    children: "Children",//the child nodes property in the data model
                    fields: {
                        checked: {
                            from: "Selected", type: "boolean"
                        },
                    },
                },
            }
        }));
    };


}
