﻿define(["dojo/_base/declare"], function (declare) {
    var ContactInfoPieChart = declare("athoc.iws.publishing.contactPieChart", null, {
        //constructor
        constructor: function(parameters)
        {
            this.domPointer = parameters.domPointer;

            $(this.domPointer).kendoChart({
                autoBind: true,
                seriesDefaults: {
                    type: "pie",
                    labels: {
                        visible: false,
                    }
                },
                legend: {
                    visible: false
                },
                chartArea: {
                    background: "transparent",
                    height: 180,
                    width: 300
                },
                series: [
                    {
                        field: "number",
                        categoryField: "type",
                        padding: 0
                    }
                ],
                tooltip: {
                    visible: true,
                    template: "#if (category== \"none\"){#"
                        + parameters.Publishing_Contact_Info_No_users_found
                        + "#}else if (category== \"covered\"){# "
                        + parameters.Publishing_Contact_Info_Reachable_Tooltip.format("#=value#", "#=dataItem.customPercentage#")
                        + "#} else {#"
                        + parameters.Publishing_Contact_Info_Not_Reachable_Tooltip.format("#=value#", "#=dataItem.customPercentage#")
                        + "#}#"

                },
                seriesClick: function (e) {
                    athoc.iws.publishing.targetUsers.pieChartClick(e);
                    e.preventDefault();
                    
                }

            });
        },

        update: function(data) {
            $(this.domPointer).data("kendoChart").dataSource.data(data);
        }
    });
    return ContactInfoPieChart;
});