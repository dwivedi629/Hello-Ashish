﻿///#source 1 1 /Scripts/Publishing/athoc.iws.publishing.js
/* define javascript namespace for Scenario */
var athoc = athoc || {};
athoc.iws = athoc.iws || {};

if (athoc.iws) {
    athoc.iws.publishing = function () {
        
        return {
            //Required URLs these URLs should be loaded from inline page JavaScript
            urls: {},

            //Required resources these resources should be loaded from inline page JavaScript
            resources: {},

            //Publisher settings to show/hide features
            settings: {
                IsGroupBlockSupported: false,
                IsAdvancedQuerySuuported: false,
                IsIndividualUserTargetingSupported: false,
                IsTargetByAreaSupported: false,
                IsDropboxSupported: false,
                IsMassDeviceTargetSupported: false,
                IsCallbridgeOptionSupported: false,
                IsSchedulingSupported: false,
                IsTestAlertSupported: false,
                IsPrintAlertSupported: false,
                IsDeviceOptionSupported: false,
                IsAlertTemplateSettingSupported: false,
                IsPlaceholderSupported: false,
                IsDeviceDeliveryOrderSupported: false,
                IsChannelSupported: false,
                IndividualUserTargetSelectionLimit: 500,
            },

            SetSectionStatus: function (statusDivSelector, newStatus) {//newStatus: open/notReady/ready
                var className = "open";
                var tooltip = this.resources.Publishing_Section_Empty_Tooltip;

                switch (newStatus) {
                    case "open":
                        className = "open";
                        tooltip = this.resources.Publishing_Section_Empty_Tooltip;
                        break;
                    case "notReady":
                        className = "not-ready";
                        tooltip = this.resources.Publishing_Section_NotReady_Tooltip;
                        break;
                    case "ready":
                        className = "ready";
                        tooltip = this.resources.Publishing_Section_Ready_Tooltip;
                        break;
                }
                athoc.iws.publishing.detail.checkStatusChange();                
                this.onReadyChange(className == 'ready' ? true : false);
                $(statusDivSelector).removeClass("open").removeClass("not-ready").removeClass("ready").addClass(className).attr("title", tooltip);
            },

            //modified the method and passing targetedUsers, blockedUsers as parameters
            UpdateContactInfo: function (EntityId, Context, selectedTreeNodes, selectedDevices, successCallBack, errorCallBack, queryCriteria, targetedArea, targetedUsers, blockedUsers, rbtCriteria) {
                var self = this;
                var targetingCriteria = queryCriteria;
                if (rbtCriteria != null)
                    if (rbtCriteria.EntityFilterId != "")
                        targetingCriteria = null;

                //turn on now loading
                var criteriaToPass = {
                    SelectedTreeNodes: selectedTreeNodes,
                    SelectedDevices: selectedDevices,
                    EntityId: EntityId,
                    TargetedCriteria: targetingCriteria,
                    PublishingContext: Context,
                    TargetedArea: targetedArea,
                    TargetedUsers: targetedUsers,
                    BlockedUsers: blockedUsers,
                    RbtCriteria: rbtCriteria,
                }

                var contactAjaxOption =
                    {
                        url: athoc.iws.publishing.urls.RefreshContactInfoUrl,
                        contentType: 'application/json',
                        dataType: 'json',
                        type: 'POST',
                        data: JSON.stringify(criteriaToPass),
                        cache: false
                    };

                var userInfoSuccess = function (data) {
                    successCallBack(data);
                };

                var userInfoError = function (error) {
                    errorCallBack(error);
                };

                var ajaxOptions = $.extend({}, AjaxUtility(userInfoError, userInfoSuccess).ajaxPostOptions, contactAjaxOption);
                $.ajax(ajaxOptions);

            },
            getErrorTitleList: function () {
                var errorTitleStrings = new Array();
                //To fill the Message popup title strings from resource 
                errorTitleStrings.push(athoc.iws.publishing.resources.AtHoc_CommonErrMsg_Title_Information);
                errorTitleStrings.push(athoc.iws.publishing.resources.AtHoc_CommonErrMsg_Title_Warning);
                errorTitleStrings.push(athoc.iws.publishing.resources.AtHoc_CommonErrMsg_Title_Error);
                errorTitleStrings.push(athoc.iws.publishing.resources.AtHoc_CommonErrMsg_Title_Success);
                errorTitleStrings.push(athoc.iws.publishing.resources.AtHoc_CommonErrMsg_Title_Completed);
                return errorTitleStrings;
            },
            getPlaceholderList: function () {
                var patt = /\[\[(.+?)\]\]/g; ///\[\[(\w+\s?\w+)=?(.*?)\]\]/g;

                var nameArray = new Array();

                $(".needs-placeholder").each(function () {

                    //check to see if this item is in device options. 
                    //if so, need to check to make sure corresponding devicegroup/device is targeted. Otherwise, we should ignore this input/textbox.
                    if (typeof $(this).attr("device_group_id") != "undefined")
                        if (!athoc.iws.publishing.massdevices.IsThisDeviceGroupTargeted($(this).attr("device_group_id"))
                            && !athoc.iws.publishing.targetUsers.isThisDeviceGroupTargeted($(this).attr("device_group_id"))) {
                            return true;
                        }

                    var customTxt = $(this).val();
                    var matches = customTxt.match(patt);
                    if (matches != null) {
                        for (var i = 0; i < matches.length; i++) {
                            var m = matches[i].substr(2, matches[i].length - 4);
                            if (m.length > 0 && $.inArray(m, nameArray) == -1) {
                                nameArray.push({ Name: m, ControlId: $(this).attr('id') });
                            }
                        }
                    }
                });

                var idArray = new Array();
                for (var i = 0; i < nameArray.length; i++) {
                    var found = _.find(athoc.iws.publishing.placeHolderItems, function (item) {
                        if (nameArray[i].Name == item.Name)
                            return true;
                    });

                    if (found) {
                        if (idArray.indexOf(found.Id) == -1) {
                            idArray.push(found.Id)
                        }
                    }

                }
                return idArray;


            },
            onReadyChange: function (isReady) { },
        }
    }();
};
///#source 1 1 /Scripts/Publishing/athoc.iws.publishing.detail.js
/// <reference path="athoc.iws.alert.placeholder.js" />
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};

if (athoc.iws.publishing) {
    athoc.iws.publishing.detail = function () {
        return {
            parameters: null,
            entityId: 0,
            context: null,
            alertOrgin: null,
            rbtCriteria: null,
            targetByUserArea: false,
            isQueryLoaded: false,
            isIUTLoaded: false,
            isTreeLoaded: false,
            rbt: null,
            init: function (args) {
                this.parameters = args;
                athoc.iws.publishing.content.init();
            },
            //model to hold publishing model for alert/scenario
            //structure is same as AtHoc.IWS.Web.Models.Publishing.PublishingModel C# class
            viewModel: {},
            isEverythingLoaded: function () {
                return ((!athoc.iws.publishing.settings.IsAdvancedQuerySuuported || this.isQueryLoaded)
                    && (!athoc.iws.publishing.settings.IsIndividualUserTargetingSupported || this.isIUTLoaded)
                    && (this.isTreeLoaded));
                //|| (athoc.iws.publishing.rbt != undefined);
            },
            resetLoadedStatus: function () {
                this.isQueryLoaded = false;
                this.isIUTLoaded = false;
                this.isTreeLoaded = false;
            },
            //load publishing model for alert/scenario
            loadPublishingModel: function (loadUrl, isEdit,id,loadTargetUsers) {
                this.resetLoadedStatus();
                if (athoc.iws.scenario != undefined) {
                    athoc.iws.scenario.breadcrumbModel.updateTitle('', undefined, undefined, 'scenarioDetail');
                }
                if (athoc.iws.alert != undefined) {
                    athoc.iws.alert.breadcrumbModel.updateTitle('', undefined, undefined, 'alertDetail');
                }
                athoc.iws.publishing.detail.setChanged(false);

                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();

                var dlSuccess = function (data) {
                    $(".publishing-detail").show();

                    if (data.Success) {
                        athoc.iws.publishing.detail.bindModel(data, isEdit);
                        if (typeof loadTargetUsers != "undefined" && loadTargetUsers) {
                            athoc.iws.publishing.targetUsers.setPresetDeviceOptions(data.Data.PresetDeviceGroupOptions);                            
                        }
                        //target users should be loaded after the binding the viewmodel that is the reason it was moved to here, it must happen only in case of rbt, in other cases it will proceed as usual.
                        if ((athoc.iws.alert && athoc.iws.alert.action && athoc.iws.alert.action == 'rbt')||(typeof loadTargetUsers != "undefined" && loadTargetUsers))
                             athoc.iws.publishing.targetUsers.load(id);
                    } else {
                        $.AjaxLoader.hideLoader();
                        $('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: data.Messages }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                    }
                    $("#alertListBreadcrumbs .title-crumb:last").addClass("ellipsis width80");
                };

                var dlAjaxOption =
                {
                    type: "POST",
                    url: loadUrl,
                };

                var ajaxOptions = $.extend({}, AjaxUtility(null, dlSuccess).ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);
            },

            //bind publishing model to ui with knockout
            bindModel: function (data, isEdit) {
                athoc.iws.publishing.detail.bindFingerTabs();

                athoc.iws.publishing.detail.viewModel = data.Data;

                $.AjaxLoader.hideLoader();

                //remove old validation
                $(".warning").each(function () { $(this).parent().remove(); });

                athoc.iws.publishing.rbt = data.Data.rbt;
                athoc.iws.publishing.detail.bindReadonlyView(data.Data);
              
                athoc.iws.publishing.context = data.Data.Context;
                athoc.iws.publishing.contextName = data.Data.ContextName;
                athoc.iws.publishing.entityId = data.Data.EntityId;
               
                athoc.iws.publishing.targetByUserArea = data.Data.TargetUsers.TargetUsersByArea;

                //if scenario bind this section, Context 1 is for scenario
                if (data.Data.Context == 1) {
                    athoc.iws.publishing.scenario.bind(data.Data.ScenarioSection);
                    // to bind scenario settings 
                    athoc.iws.scenario.settings.bind(data.Data.ScenarioSettings);

                    
                    athoc.iws.publishing.content.bind(data.Data.Content, data.Data.Context);
                    athoc.iws.publishing.targetUsers.bind(data.Data.TargetUsers, data.Data.PresetDeviceGroupOptions);
                    athoc.iws.publishing.iut.bind(data.Data.TargetUsers.TargetedBlockedUsers);
                    //
                   // athoc.iws.publishing.targetOrg.load(data.Data.TargetOrg);
                    // to bind mass devices settings
                    athoc.iws.publishing.massdevices.bind(data.Data.MassDevices, data.Data.Context, data.Data.ScenarioSettings.Delivery.Readonly, data.Data.PresetDeviceGroupOptions);
                    // to bind scenario schedule settings 
                    athoc.iws.scenario.schedule.bind(data.Data.ScenarioScheduleSettings);  
                    
                } else {

                    //apply scenario settings on alert 
                    athoc.iws.scenario.settings.applySettingsOnAlert(data.Data.ScenarioSettings, data.Data);
                    //bind test alert device list with addresses
                    athoc.iws.alert.test.bind(data.Data.TestDeviceList);
                    // apply place holder settings
                    athoc.iws.alert.placeholder.bind(data.Data.CustomPlaceHolders);
                    athoc.iws.publishing.alertOrgin = data.Data.AlertOrigin;
                    // to bind  alert schedule settings
                    athoc.iws.alert.schedule.bind(data.Data.ScenarioSettings, data.Data.AlertScheduleSettings); 
                }
                // Commented: Redundant call.
                athoc.iws.publishing.targetOrg.load(data.Data.TargetOrg);

                //if scenario
                if (data.Data.Context == 1) {
                    athoc.iws.scenario.breadcrumbModel.updateTitle(data.Data.ScenarioSection.Name, undefined, undefined, 'scenarioDetail');

                    $("#scenario-name").focus();

                    //show info section
                    if (isEdit) {
                        $("#scenarioCreatedBy").text(data.Data.ScenarioInfo.CreatedBy).attr("title", data.Data.ScenarioInfo.CreatedBy);
                        $("#scenarioCreatedOn").text(data.Data.ScenarioInfo.CreatedOn).attr("title", data.Data.ScenarioInfo.CreatedOn);
                        $("#scenarioUpdatedBy").text(data.Data.ScenarioInfo.UpdatedBy).attr("title", data.Data.ScenarioInfo.UpdatedBy);
                        $("#scenarioUpdatedOn").text(data.Data.ScenarioInfo.UpdatedOn).attr("title", data.Data.ScenarioInfo.UpdatedOn);
                        $("#scenarioCommonName").text(data.Data.ScenarioSection.CommonName).attr("title", data.Data.ScenarioSection.CommonName);
                        $("#templateId").text(data.Data.EntityId).attr("title", data.Data.EntityId);
                        $("#scenarioInfoSection").show();
                    }
                } else {
                    // in case of alert
                    if ((athoc.iws.publishing.settings.IsTestAlertSupported) && (data.Data.AlertStatus.toUpperCase() != "LIVE" || data.Data.AlertStatus.toUpperCase() != "ENDED") && data.Data.IsTestAlertSupportOperator) {
                        $("#btn_test_alert").show();
                    } else {
                        $("#btn_test_alert").hide();
                    }
                    //IWS-14925 - show save button after loading
                    if ((data.Data.AlertStatus.toUpperCase() != "LIVE" || data.Data.AlertStatus.toUpperCase() != "ENDED") && !$("#btn_detail_standby").is(":visible")) {
                        $("#btn_detail_save").show();
                    }
                    
                    if (athoc.iws.alert.action == 'create') {
                        var titlePrefix = '';
                        $(".severity-list").find("button").focus();
                        if (athoc.iws.alert.id == 0) {
                            if (athoc.iws.alert.source != "event") {
                                titlePrefix = "<span class='title-crumb'>"+athoc.iws.publishing.resources.Publishing_NewAlert+"</span><span class='normal-narrow mar-left5 mar-right5'>"+athoc.iws.publishing.resources.Publishing_BasedOn+"</span>";
                                athoc.iws.alert.breadcrumbModel.updateTitle(data.Data.ScenarioSection.Name, undefined, undefined, 'alertCreate', titlePrefix);
                            }
                        } else {
                            titlePrefix = "<span>"+athoc.iws.publishing.resources.Publishing_PublishAlert+"</span><span class='normal-narrow mar-left5 mar-right5'>"+athoc.iws.publishing.resources.Publishing_BasedOn+"</span>";
                            athoc.iws.alert.breadcrumbModel.updateTitle(data.Data.ScenarioSection.Name, undefined, undefined, 'alertCreate', titlePrefix);
                        }
                    }
                    if (athoc.iws.alert.action == 'rbt') {
                        var titlePrefix = '';
                        $(".severity-list").find("button").focus();
                        titlePrefix = "<span>" + athoc.iws.publishing.resources.Publishing_NewAlert + "</span><span class='normal-narrow mar-left5 mar-right5'>" + athoc.iws.publishing.resources.Publishing_BasedOn + "</span>";
                        athoc.iws.alert.breadcrumbModel.updateTitle(data.Data.Content.Title, undefined, undefined, 'alertCreate', titlePrefix);
                    }
                    else {
                        if (athoc.iws.alert.action == 'view') {//enable end button
                            if (data.Data.AlertStatus == "Live") {
                                $("#btn_alert_end").show();
                                if(athoc.iws.publishing.settings.IsSchedulingSupported)
                                $("#btn_alert_save").show();
                            }
                        }

                        $(".severity-list").find("button").focus();
                        setTimeout(function () { $(".severity-list").find("button").focus(); }, 50);
                        athoc.iws.alert.breadcrumbModel.updateTitle(data.Data.Content.Title, undefined, undefined, 'alertDetail');
                    }
                }

                //commented to avoid multiple times collapse and expand when click
                // if($._data($("html").find('.section-title, .expand-arrow-open, .expand-arrow-closed')[0], "events")== undefined)
                //    athoc.iws.publishing.detail.bindBucketExpandCollapse($("html"));

                // apply finger tab settings on on Scenario and Alert
                athoc.iws.scenario.settings.ApplysettingsOnFingerTabs(data.Data.ScenarioSettings.Targeting.EnabledTargetingTypes);
                athoc.iws.scenario.settings.ApplyOrgsettingsOnFingerTabs(data.Data.ScenarioSettings.Organization);
                if (data.Data.Context == 1) {
                    athoc.iws.publishing.detail.bindBucketExpandCollapse($("html"));
                    // toggle schedule section 
                    athoc.iws.scenario.schedule.toggleScheduleSection();
                    // apply content settings such as dropbox , Location, response option  on Scenario
                    athoc.iws.scenario.settings.applyScenarioContentSettings(data.Data.ScenarioSettings.Content);
                } else {
                    // apply content settings such as dropbox , Location, response option  on Alert
                    athoc.iws.scenario.settings.applyAlertContentSettings(data.Data.ScenarioSettings.Content);

                    athoc.iws.scenario.settings.applyCollapseSettingsOnAlert();

                }
                
                athoc.iws.scenario.settings.isFillCountEnabled = data.Data.ScenarioSettings.Targeting.FillCount;
                //for Scenario always readonly=false
                //fill count summary can be readonly=true only when readonly is set scenario settings  and section is ready  
                athoc.iws.publishing.fillcount.bind(data.Data, data.Data.Context == 1 ? false: (data.Data.ScenarioSettings.Targeting.Readonly==true && athoc.iws.publishing.targetUsers.isReadyToPublish==true));

                //after loading the data reset the changed flag to not changed
                athoc.iws.publishing.detail.setChanged(false);
                $(document).scrollTop(0);
                //if the content panel is collapse initially, map doesn't have a chance to adjust ot the size of the container
                //only needs to do it once
                //for editing mode content
                var contentDom = $('#publishing-content-edit');
                var contentExpandHeaderDom = $('#bucketTitle', contentDom);
                var expandArrow = $('.expand-arrow-closed', contentExpandHeaderDom);
                if (expandArrow.css('display') == 'block') {
                    contentExpandHeaderDom.on('click', function () {
                        if (!athoc.iws.publishing.geo.miniMap && athoc.iws.publishing.geo.geoJson) {
                            require(["widget/Map"], function (WidgetMap) {
                                athoc.iws.publishing.geo.miniMap = new WidgetMap("miniMapHolder", {i18n: athoc.iws.publishing.mapResources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture });
                                athoc.iws.publishing.geo.bindAlertMiniMap(athoc.iws.publishing.geo.miniMap,athoc.iws.publishing.geo.geoJson);
                            });
                        }
                        /*
                        if (!athoc.iws.publishing.geo.miniMapResized) {
                            setTimeout(function () {
                                athoc.iws.publishing.geo.miniMapResized = true;
                                athoc.iws.publishing.geo.miniMap.resize();
                                athoc.iws.publishing.geo.miniMap.zoomToFit();
                            }, 500);
                        }*/
                    });
                }
                //for readonly content
                var readOnlyContentDom = $('#publishing-content-detail');
                var readOnlyContentExpandHeaderDom = $('#bucketTitle', readOnlyContentDom);
                var readOnlyExpandArrow = $('.expand-arrow-closed', readOnlyContentExpandHeaderDom);
                if (readOnlyExpandArrow.css('display') == 'block') {
                    readOnlyContentExpandHeaderDom.on('click', function () {
                        if (!athoc.iws.publishing.view.readOnlyMap && athoc.iws.publishing.view.geoJson) {
                            require(["widget/Map"], function (WidgetMap) {
                                var reviewMapHolder = readOnlyContentDom.find(".readOnlyMiniMapHolder");
                                athoc.iws.publishing.view.readOnlyMap = new WidgetMap(reviewMapHolder, { i18n: athoc.iws.publishing.mapResources,zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture });
                                athoc.iws.publishing.view.bindGeoAlertMiniMap(athoc.iws.publishing.view.readOnlyMap, athoc.iws.publishing.view.geoJson);
                            });
                        }
                        /*
                        if (!athoc.iws.publishing.view.readOnlyMapResized) {
                            setTimeout(function () {
                                athoc.iws.publishing.view.readOnlyMapResized = true;
                                if (athoc.iws.publishing.view.readOnlyMap) {
                                    athoc.iws.publishing.view.readOnlyMap.resize();
                                    athoc.iws.publishing.view.readOnlyMap.zoomToFit();
                                }
                                if (athoc.iws.publishing.view.readOnlyMapInRP) {
                                    athoc.iws.publishing.view.readOnlyMapInRP.resize();
                                    athoc.iws.publishing.view.readOnlyMapInRP.zoomToFit();
                                }
                            }, 500);
                        }*/
                    });
                }
            },

            //bind readonly view
            bindReadonlyView: function (data) {
                if ($("#alertView").length > 0) {
                    if (athoc.iws.publishing.view) {
                        athoc.iws.publishing.view.bind(data, $("#alertView"));
                    }
                }
            },

            //has any section got changed
            isChanged: function () {
                var changed = athoc.iws.publishing.content.isChanged || athoc.iws.publishing.scenario.isChanged || athoc.iws.publishing.massdevices.isChanged || athoc.iws.publishing.fillcount.isChanged;
                return changed;
            },

            //is ready to publish
            isReadyToPublish: function () {
                var isReady = false;
                //if alert is ready and either or targeting ready and no errors
                if (athoc.iws.publishing.contextName == "Scenario" ||  athoc.iws.publishing.contextName == "AccountTemplate")
                    isReady = athoc.iws.publishing.content.isReadyToPublish() &&
                       (athoc.iws.publishing.targetUsers.isReadyToPublish || athoc.iws.publishing.targetOrg.isReadyToPublish || athoc.iws.publishing.massdevices.isReadyToPublish) &&
                       (!athoc.iws.publishing.targetUsers.isInErrorState) && (!athoc.iws.publishing.massdevices.isInErrorState) && (!athoc.iws.scenario.schedule.isInErrorState);
                else
                    isReady = athoc.iws.publishing.content.isReadyToPublish() &&
                    (athoc.iws.publishing.targetUsers.isReadyToPublish || athoc.iws.publishing.targetOrg.isReadyToPublish || athoc.iws.publishing.massdevices.isReadyToPublish) &&
                    (!athoc.iws.publishing.targetUsers.isInErrorState) && (!athoc.iws.publishing.massdevices.isInErrorState) && (!athoc.iws.alert.schedule.isInErrorState)
                    && ((athoc.iws.alert.placeholder.placeholderModel && athoc.iws.alert.placeholder.placeholderModel.length > 0 ) ? athoc.iws.alert.placeholder.isValid() : true);

                return isReady;
            },

            //change status
            checkStatusChange: function (enablePublishReview) {
                if (athoc.iws.publishing.detail.isChanged()) {
                    $('#messagePanel').messagesPanel('reset');
                }
                //iws12104
                if (athoc.iws.publishing.detail.viewModel.AlertStatus != undefined && athoc.iws.publishing.detail.viewModel.AlertStatus == "Scheduled" && athoc.iws.publishing.entityId > 0)
                {
                    $("#btn_review_and_publish").hide();
                    if ($("#btn_detail_save").is(":visible")) {
                        $("#btn_detail_save").removeClass('btn-info');
                        $("#btn_detail_save").addClass('btn-primary');
                    }
                    else
                        if ($("#btn_detail_standby").is(":visible")) {
                            $("#btn_detail_save").removeClass('btn-info');
                            $("#btn_detail_standby").addClass('btn-primary');
                        }
                }
                else
                {
                    //IWS12606
                        if (athoc.iws.publishing.detail.viewModel.AlertStatus && athoc.iws.publishing.detail.viewModel.AlertStatus != "Live" && (enablePublishReview != undefined || enablePublishReview == false) )
                          $("#btn_review_and_publish").show();

                    if ($("#btn_detail_save").is(":visible")) {
                        $("#btn_detail_save").removeClass('btn-primary');
                        $("#btn_detail_save").addClass('btn-info'); // IWS12553
                    }
                    else
                        if ($("#btn_detail_standby").is(":visible"))
                            $("#btn_detail_standby").removeClass('btn-primary');
                }

                if ($("#btn_review_and_publish").is(":visible"))
                {
                    var reviewIcon = $("#btn_review_and_publish").find(".ready-indicator");

                    if (athoc.iws.publishing.detail.isReadyToPublish()) {
                        reviewIcon.removeClass('not-ready');
                        reviewIcon.addClass('ready');
                        $("#btn_review_and_publish_tooltip").hide();
                    } else
                    {
                        reviewIcon.removeClass('ready');
                        reviewIcon.addClass('not-ready');

                        var position = reviewIcon.offset();
                        var tooltip = $("#btn_review_and_publish_tooltip");
                        tooltip.css({ top: '30px', right: '5px', 'z-index': '0' });

                        if (!tooltip.parent().hasClass('header-bar')) {
                            tooltip.appendTo(".header-bar");
                        }

                        if ($("#btn_review_and_publish").is(":enabled"))
                            tooltip.show();
                        else {
                            //reviewIcon.removeClass('ready');
                            //reviewIcon.removeClass('not-ready');
                            tooltip.hide();
                        }
                    }
                }
                if (athoc.iws.publishing.detail.viewModel.Context == 1) {
                    athoc.iws.scenario.schedule.isActiveRecurrence(athoc.iws.publishing.detail.isReadyToPublish(), false,athoc.iws.publishing.detail.isChanged());
                }
            },

            //set changed
            setChanged: function (val) {
                athoc.iws.publishing.content.isChanged = val;
                athoc.iws.publishing.scenario.isChanged = val;
                athoc.iws.publishing.massdevices.isChanged = val;
                athoc.iws.publishing.fillcount.isChanged = val;
            },

            //bind bucket section header for collape/expand
            bindBucketExpandCollapse: function (targetDiv) {
                //bind the toggle event
                //iws-12353
                //added condition for basic vps bind the sections toggle event
                if (targetDiv.selector == "#dialogReviewAndPublish" || !athoc.iws.publishing.settings.IsSchedulingSupported) {
                    //bind bucket toggle 
                    targetDiv.find('.section-title, .expand-arrow-open, .expand-arrow-closed').unbind("click");
                    targetDiv.find('#bucketTitle').unbind("click");

                    targetDiv.find('.section-title, .expand-arrow-open, .expand-arrow-closed').click(function () {
                        $(this).parent().parent().find('.row').slideToggle(500);
                        $(this).parent().parent().find('.expand-arrow-open:not(.advanced-arrow-open)').toggle();
                        $(this).parent().parent().find('.expand-arrow-closed:not(.advanced-arrow-closed)').toggle();
                    });
                }
                ////show bucket expanded by default
                targetDiv.find(".bucket-toggle .row").show();
                targetDiv.find(".bucket-toggle .expand-arrow-open").show();
                targetDiv.find(".bucket-toggle .expand-arrow-closed").hide();

            },

            //bind finger tab
            bindFingerTabs: function () {
                /*START finger tabs*/
                $('.finger-tab.by-groups').click(function () {
                    $('.finger-tab.by-groups, .finger-tab.by-users, .finger-tab.by-query, .finger-tab.by-area, .finger-tab.personal-devices').removeClass('selected');
                    $('.finger-tab.by-groups').addClass('selected');
                    $('#targetContentGroups, #targetContentUsers, #targetContentQuery, #targetContentArea, #targetContentDevices').hide();
                    $('#targetContentGroups').show();
                });
                $('.finger-tab.by-users').click(function () {
                    $('.finger-tab.by-groups, .finger-tab.by-users, .finger-tab.by-query, .finger-tab.by-area, .finger-tab.personal-devices').removeClass('selected');
                    $('.finger-tab.by-users').addClass('selected');
                    $('#targetContentGroups, #targetContentUsers, #targetContentQuery, #targetContentArea, #targetContentDevices').hide();
                    $('#targetContentUsers').show();
                });
                $('.finger-tab.by-query').click(function () {
                    $('.finger-tab.by-groups, .finger-tab.by-users, .finger-tab.by-query, .finger-tab.by-area, .finger-tab.personal-devices').removeClass('selected');
                    $('.finger-tab.by-query').addClass('selected');
                    $('#targetContentGroups, #targetContentUsers, #targetContentQuery, #targetContentArea, #targetContentDevices').hide();
                    $('#targetContentQuery').show();
                });
                $('.finger-tab.by-area').click(function () {
                    $('.finger-tab.by-groups, .finger-tab.by-users, .finger-tab.by-query, .finger-tab.by-area, .finger-tab.personal-devices').removeClass('selected');
                    $('.finger-tab.by-area').addClass('selected');
                    $('#targetContentGroups, #targetContentUsers, #targetContentQuery, #targetContentArea, #targetContentDevices').hide();
                    $('#targetContentArea').show();
                });
                $('.finger-tab.personal-devices').click(function () {
                    $('.finger-tab.by-groups, .finger-tab.by-users, .finger-tab.by-query, .finger-tab.by-area, .finger-tab.personal-devices').removeClass('selected');
                    $('.finger-tab.personal-devices').addClass('selected');
                    $('#targetContentGroups, #targetContentUsers, #targetContentQuery, #targetContentArea, #targetContentDevices').hide();
                    $('#targetContentDevices').show();
                });
                $('.finger-tab.org-by-name').click(function () {
                    $('.finger-tab.org-by-area').removeClass('selected');
                    $('.finger-tab.org-by-name').addClass('selected');
                    $('#targetOrgByArea').hide();
                    $('#targetOrgByName').show();
                });
                $('.finger-tab.org-by-area').click(function () {
                    $('.finger-tab.org-by-name').removeClass('selected');
                    $('.finger-tab.org-by-area').addClass('selected');
                    $('#targetOrgByName').hide();
                    $('#targetOrgByArea').show();
                });
                /*END finger tabs*/
            },

        };
    }();
}
///#source 1 1 /Scripts/Publishing/athoc.iws.publishing.scenario.js
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};

if (athoc.iws.publishing) {
    athoc.iws.publishing.scenario = function() {
        return {
            viewModel: {
                data: ko.observable(),
                status: ko.observable('ready'),
                statusTooltip: ko.observable(athoc.iws.publishing.resources.Publishing_Section_Ready_Tooltip),
                Channels: ko.observable([]),
            },

            setChannels: function(channels) {
                var list = [];
                if (channels) {
                    $.each(channels, function (index, value) {
                        if (value.Id && value.Id > 0) {
                            list.push(value);
                        }
                    });
                }
                athoc.iws.publishing.scenario.viewModel.Channels(list);
            },

            //is model changed
            isChanged: false,

            //is ready for publish
            isReadyToPublish: function() {
                return (this.viewModel.status() == 'ready');
            },

            //this method will be called when new data will be available for this section for binding
            bind: function (data) {
                var model = athoc.iws.publishing.scenario.viewModel;
                var current = athoc.iws.publishing.scenario;

                $("#scenarioDetailsDiv").find(".bootstrap-select").remove();
                if ($("#channelList").length > 0) {
                    $("#channelList").html('');
                }

                model.data = ko.mapping.fromJS(data, athoc.iws.publishing.scenario.getValidation());
                

                //Binding
                if ($("#publishing-scenario-edit").length > 0) {
                    ko.cleanNode($("#publishing-scenario-edit").get(0));
                    ko.applyBindings(model, $("#publishing-scenario-edit").get(0));
                }
                

                if ($("#channelList").length > 0) {
                    $("#channelList").val(data.ChannelId).change();
                }

                //Change events binding
                current.isChanged = false;

                model.data.Name.subscribe(function(newValue) {
                    current.dataChanged();

                    var name = newValue;
                    if (name == "") {
                        name = "Untitled";
                    }

                    athoc.iws.scenario.breadcrumbModel.updateTitle(name, undefined, undefined, 'scenarioDetail');
                });
                model.data.CommonName.subscribe(function (newValue) { current.dataChanged(); });
                model.data.AvailableForQuickPublish.subscribe(function (newValue) { current.dataChanged(); });
                model.data.Description.subscribe(function (newValue) { current.dataChanged(); });

                current.checkReadyNotReady();

            },

            //this method will be called when data is required for updating
            getModel: function () {
                return ko.mapping.toJS(athoc.iws.publishing.scenario.viewModel.data);
            },

            //setup validation
            getValidation: function () {
                var validationMapping = {
                    Name: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                required: {
                                    params: true,
                                    message: athoc.iws.scenario.resources.Publishing_Validation_ScenarioName
                                },
                                maxLength: {
                                    params: 200,
                                    message: athoc.iws.scenario.resources.Publishing_Validation_ScenarioName
                                } 
                            });
                        }
                    },
                    Description: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                maxLength: {
                                    params: 200,
                                    message: athoc.iws.scenario.resources.Publishing_Validation_Description
                                }
                            });
                        }
                    },
                    CommonName: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                maxLength: {
                                    params: 200,
                                    message: athoc.iws.scenario.resources.Publishing_Validation_CommonName
                                }
                            });
                        }
                    },
                };

                return validationMapping;
            },

            //is model valid
            isValid: function () {
                var result = ko.validation.group(athoc.iws.publishing.scenario.viewModel.data, { deep: true });
                if (result().length > 0) {
                    result.showAllMessages(true);
                    $.AjaxLoader.hideLoader();
                    return false;
                }
                return true;
            },

            //triggered on data changed
            dataChanged: function () {
                var current = athoc.iws.publishing.scenario;
                current.isChanged = true;
                current.checkReadyNotReady();
            },

            //set ready not-ready
            checkReadyNotReady: function() {
                var current = athoc.iws.publishing.scenario;
                if (current.isValid()) {
                    current.viewModel.status('ready');
                    current.viewModel.statusTooltip(athoc.iws.scenario.resources.Publishing_Section_Ready_Tooltip);
                } else {
                    current.viewModel.status('not-ready');
                    current.viewModel.statusTooltip(athoc.iws.scenario.resources.Publishing_Section_NotReady_Tooltip);
                }
                athoc.iws.publishing.detail.checkStatusChange();
            },
        };
    }();
}
///#source 1 1 /Scripts/Publishing/athoc.iws.publishing.content.js
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};

if (athoc.iws.publishing) { 
    athoc.iws.publishing.content = function () {
        return {
            viewModel: {
                data: ko.observable(),
                ResponseName: ko.observable(''), // to display selected response in the readonly view.
                status: ko.observable('ready'),
                statusTooltip: ko.observable(athoc.iws.publishing.resources.Publishing_Section_Ready_Tooltip),
                titleLength: ko.observable(0),
                bodyLength: ko.observable(0),
                severityVisible: ko.observable(true),
                typeVisible: ko.observable(true),
                context: 0,
                responseChange: function (index, data) {
                    var isValid = false;
                    var chngText = "";
                    athoc.iws.publishing.content.dataChanged();
                    var options = athoc.iws.publishing.content.viewModel.data.ResponseOptions;
                    for (var i = 0; i < options().length; i++) {
                        isValid = options()[i].ResponseText.isValid();
                        if (i == index) chngText = options()[i].ResponseText();
                    }
                    if (isValid)
                        athoc.iws.publishing.fillcount.responseChange(index, chngText);

                    return isValid; 
                },

                bindContent: function (SeverityId, TypeId, ResponseOptionId) {
                    $("#publishing-content-edit").find("#severityList").val(SeverityId).change();
                    $("#publishing-content-edit").find("#typeList").val(TypeId).change();
                    $("#publishing-content-edit").find("#responseList").val(ResponseOptionId).change();
                },

                selectLanguage: function (data, event) {
                    var position = $(".btn-lang").offset();
                    var selLanguage = $("#lang-dropdown");
                    var correction = 0;


                    var top = 148;
                    if(athoc.iws.publishing.contextName == "AccountEvent")
                        top = 185;
                    else if (athoc.iws.publishing.contextName == "AccountTemplate")
                        top = 350;

                    var topPosition = position.top - (($("#CustomPlaceHolderDetails:visible").length > 0 ? $("#CustomPlaceHolderDetails").height() : 0) + top);

                    if ($("#messagePanel:visible").length > 0 && $("#messagePanel").height() > 20) {
                        correction += $("#messagePanel").height() + 20;
                        topPosition = topPosition - correction;
                    }

                    //if scenario
                    if (athoc.iws.publishing.content.viewModel.context == 1) {
                        correction += 125;
                        if ($("#publishing-scenario-edit").length > 0) {
                            var scenarioSection = $("#publishing-scenario-edit");
                            correction += scenarioSection.height();
                        }
                        topPosition = position.top - correction;
                    }

                    selLanguage.css({ top: topPosition + 'px', right: '-70px' });
                    selLanguage.toggle();
                    event.stopPropagation();
                },

                changeLanguage: function (data, event) {
                    var lang = $(event.target).attr('data-settings-value');
                    athoc.iws.publishing.content.viewModel.data.Local(lang);
                    var selLanguage = $("#lang-dropdown");
                    selLanguage.hide();
                },

                localDisplay: ko.observable('EN (US)'),
                localDisplayTooltip: ko.observable('English (United States)'),

                gotoTargetUrl: function (data, event) {
                    var url = athoc.iws.publishing.content.viewModel.data.TargetUrl;
                    if (!url.isValid() || url().trim().length == 0) {
                        return;
                    }

                    window.open(athoc.iws.publishing.content.viewModel.data.TargetUrl(), '_blank');
                },

                triggerClick: function (data, event) {
                    var keyCode = event.which || event.keyCode;
                    if (keyCode == 13) {
                        $(event.target).trigger("click");
                    }
                },

                addResponseOption: function () {
                    var model = athoc.iws.publishing.content.viewModel;
                    model.data.ResponseOptions.push(new athoc.iws.publishing.content.ResponseOptionItem({ ResponseText: '', CallBridgeNumber: '', ShowCallBridge: false, PassCode: '', ConferenceUrl: '' }));
                },

                removeResponseOption: function (index) {
                    if (!athoc.iws.scenario.settings.isFillCountEnabled)
                        athoc.iws.publishing.content.viewModel.deleteResponseOption(index);
                    else if (athoc.iws.scenario.settings.isFillCountEnabled && athoc.iws.publishing.fillcount.setFillCountOnResponseDelete(index))
                        athoc.iws.publishing.content.viewModel.deleteResponseOption(index);
                },

                deleteResponseOption: function (index) {
                    var model = athoc.iws.publishing.content.viewModel;
                    model.data.ResponseOptions.splice(index, 1);
                    if (model.data.ResponseOptionId() == 0 && model.data.ResponseOptions().length == 0) {
                        model.data.ResponseOptions.push(new athoc.iws.publishing.content.ResponseOptionItem({ ResponseText: '', CallBridgeNumber: '', ShowCallBridge: false, PassCode: '', ConferenceUrl: '' }));
                    }
                },

                //geo location
                isGeoSelected: ko.observable(false),

                geoImageUrl: ko.observable(''),

                addLocation: function () {
                    athoc.iws.publishing.geo.add();
                },

                editLocation: function () {
                    athoc.iws.publishing.geo.edit();
                },

                removeLocation: function () {
                    athoc.iws.publishing.geo.remove();
                },

                //Publishing event as alert
                inboxEvent: null,
            },
            responseOptionPreviousId: -1,
            getCharCount: function (str) {
                var result = 0;
                if (str !== undefined) {
                    for (var n = 0; n < str.length; n++) {
                        var charCode = str.charCodeAt();
                        if (typeof charCode === "number") {
                            if (charCode < 128)
                            { result = result + 1; }
                            else if (charCode < 2048)
                            { result = result + 2; }
                            else if (charCode < 65536)
                            { result = result + 3; }
                            else if (charCode < 2097152)
                            { result = result + 4; }
                            else if (charCode < 67108864)
                            { result = result + 5; }
                            else
                            { result = result + 6; }
                        }
                    }
                }
                return result;
            },

            lengthValidation: function (str, minChar, maxChar) {
                if (str.length < minChar[1] || str.length > minChar[2]) {
                    return false;
                }
                return true;
            },

            //Readonly view model
            ReadonlyViewModel:
                        {
                            data: ko.observable(),
                            alertTitle: ko.observable(''),
                            bodyWithLineBreak: ko.observable(''),
                            isGeoSelected: ko.observable(false),
                        },
            //is model changed
            isChanged: false,

            phBody: null,

            init: function () {
                if (athoc.iws.publishing.settings.IsPlaceholderSupported) {
                    //var list = context == 0 ? athoc.iws.publishing.placeHolderItems.filter(function (i) { return i.IsSystem; }) : athoc.iws.publishing.placeHolderItems;
                    require(["publishing/Placeholder/Placeholder"], function (Placeholder) {
                        var txt = $("#content-title")[0];
                        var options = { textField: txt, items: athoc.iws.publishing.placeHolderItems }
                        var ph = new Placeholder(options, $("#divTitlePlaceholder", txt.parentNode)[0]);
                        ph.startup();
                    });

                    require(["publishing/Placeholder/Placeholder"], function (Placeholder) {
                        var txt = $("#content-body")[0];
                        var options = { textField: txt, items: athoc.iws.publishing.placeHolderItems }
                        athoc.iws.publishing.content.phBody = new Placeholder(options, $("#divBodyPlaceholder", txt.parentNode)[0]);
                        athoc.iws.publishing.content.phBody.startup();
                    });
                    ko.bindingHandlers.addPlaceHolder = {
                        init: function (element) {
                            require(["publishing/Placeholder/Placeholder"], function (Placeholder) {
                                var txt = element;
                                var options = { textField: txt, items: athoc.iws.publishing.placeHolderItems, isStatic: true }
                                var ph = new Placeholder(options, $(".roPh", txt.parentNode)[0]);
                                ph.startup();
                            });
                        },
                        update: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
                            if (bindingContext.$parent.data.ResponseOptionId() > 0) {
                                $(element).nextAll("span:first").hide();
                            }
                            else
                                $(element).nextAll("span:first").show();
                        }
                    };
                }
            },

            //set the tooltip position for title and body input fields.
            _setTooltipPosition: function (inputField) {
                var position = $(inputField).offset();
                var tooltipId = inputField + "-tooltip-template";
                var tooltip = $(tooltipId);
                var tooltipHieght = 160;
                var noOfExtraLine = (tooltip.height() - 44) / 15;
                tooltipHieght = tooltipHieght + (15 * noOfExtraLine);
                var pa = athoc.iws.publishing.contextName == "AccountTemplate" || athoc.iws.publishing.contextName == "AccountEvent";
                if (pa || (navigator.userAgent.toLowerCase().indexOf("MSIE 9.0".toLowerCase()) > -1 && $("#scenarioDetailsDiv [id='publishing-scenario-edit']").length > 0)) {
                    var diff = athoc.iws.publishing.contextName == "AccountTemplate" ? 25 : 45;
                    tooltip.css({ top: position.top - diff - tooltipHieght + 'px', right: '230px' });
                } else {
                    tooltip.css({ top: position.top - tooltipHieght + 'px', right: '230px' });
                }
                setTimeout(function () { tooltip.show(); }, 50);

            },

            //this method will be called when new data will be available for this section for binding
            bind: function (data, context) {

                //IF alert is created from event - Forward Alert
                if (athoc.iws.publishing.content.viewModel.inboxEvent != null && athoc.iws.publishing.content.viewModel.inboxEvent.IsEvent) {
                    var event = athoc.iws.publishing.content.viewModel.inboxEvent;
                    //Decode Inbox Title and Body -
                    data.Title = $.htmlDecode(event.Title);
                    data.Body = $.htmlDecode(event.Body);
                    var targetUrl = '';

                    if (event.Link && event.Link != "null") {
                        targetUrl = event.Link;
                    }
                    data.TargetUrl = targetUrl;
                    data.TypeId = event.TypeId;
                    data.SeverityId = event.SeverityId;
                    data.Type = event.Type;
                    data.Severity = event.Severity;


                    //data.SeverityName = event.SeverityName;

                    if (event.Location == "{}")
                        data.LocationGeo = null;
                    else
                        data.LocationGeo = event.Location;
                }

                var current = athoc.iws.publishing.content;

                if ($("#dbChooser").length > 0) {
                    current.createDropBoxButton(data.TargetUrl);
                }

                current.viewModel.data = ko.mapping.fromJS(data, athoc.iws.publishing.content.getValidation());
                current.viewModel.context = context;
                var model = athoc.iws.publishing.content.viewModel.data;
                current.updateLocal();

                //Rebind response options so validation kicks-off
                current.viewModel.data.ResponseOptions.removeAll();
                $.each(data.ResponseOptions, function (index, value) {
                    current.viewModel.data.ResponseOptions.push(new athoc.iws.publishing.content.ResponseOptionItem({ ResponseText: value.ResponseText, CallBridgeNumber: $.htmlDecode(value.CallBridgeNumber), ShowCallBridge: $.htmlDecode(value.ShowCallBridge), PassCode: $.htmlDecode(value.PassCode), ConferenceUrl: value.ConferenceUrl }));
                });

                //remove previous dropdown

                $("#publishing-content-edit").find(".lang-list").html("");
                $("#publishing-content-edit").find(".response-list").html("");
                $("#publishing-content-edit").find(".severity-list").html("");
                $("#publishing-content-edit").find(".content-type").html("");


                /*save typeid,severityid and responseoption before ko.applybindings as 
                that is causing to reset the bindings 
                TODO:research why comboxbox bindings with ko is not working
                */
                var typeid = athoc.iws.publishing.content.viewModel.data.TypeId();
                var severityid = athoc.iws.publishing.content.viewModel.data.SeverityId();
                var responseOption = athoc.iws.publishing.content.viewModel.data.ResponseOptionId();

                if (athoc.iws.publishing.contextName == "AccountEvent" && athoc.iws.publishing.detail.viewModel) {
                    current.viewModel.severityVisible(athoc.iws.publishing.detail.viewModel.ScenarioSettings.AccountabilityWorkflow.IsContentSeverityVisible
                    );
                    current.viewModel.typeVisible(athoc.iws.publishing.detail.viewModel.ScenarioSettings.AccountabilityWorkflow.IsContentTypeVisible
                    );
                }

                //Binding
                ko.cleanNode($("#publishing-content-edit").get(0));
                ko.applyBindings(athoc.iws.publishing.content.viewModel, $("#publishing-content-edit").get(0));

                athoc.iws.publishing.content.viewModel.bindContent(severityid, typeid, responseOption);

                //for some reason bootstrap creates another control
                $("#publishing-content-edit").find(".bootstrap-select.response-list").eq(1).remove();
                $("#publishing-content-edit").find(".bootstrap-select.severity-list").eq(1).remove();
                $("#publishing-content-edit").find(".bootstrap-select.content-type").eq(1).remove();


                if (athoc.iws.publishing.contextName == "AccountEvent") {
                    $('#responseList').attr('disabled', true);
                    $('#responseList').selectpicker('refresh');
                }

                if (model.Title() == null) {
                    athoc.iws.publishing.content.viewModel.titleLength(0);
                } else {
                    //athoc.iws.publishing.content.viewModel.titleLength(athoc.iws.publishing.content.getCharCount(model.Title()));
                    athoc.iws.publishing.content.viewModel.titleLength(model.Title().length);
                }

                if (model.Body() == null) {
                    athoc.iws.publishing.content.viewModel.bodyLength(0);
                } else {
                    athoc.iws.publishing.content.viewModel.bodyLength(model.Body().length);
                }

                $("#content-title").focus(function () {
                    athoc.iws.publishing.content._setTooltipPosition("#content-title");
                });

                $("#content-body").focus(function () {
                    athoc.iws.publishing.content._setTooltipPosition("#content-body");
                });

                $(document).click(function () {
                    var selLanguage = $(".lang-filter");
                    selLanguage.hide();
                });

                $("#lang-dropdown").click(function (e) { e.stopPropagation(); });

                $("#content-title").on('change keyup paste', function () {
                    var vm = athoc.iws.publishing.content.viewModel;
                    vm.titleLength($(this).val().length);
                });

                //IE-10 Clear event
                $("#content-title").on("mouseup", function (e) {
                    var $input = $(this),
                        oldValue = $input.val();

                    if (oldValue == "") return;

                    setTimeout(function () {
                        var newValue = $input.val();

                        if (newValue == "") {
                            var vm = athoc.iws.publishing.content.viewModel;
                            vm.titleLength(0);
                        }
                    }, 1);
                });

                $("#content-body").on('change keyup paste', function () {
                    var vm = athoc.iws.publishing.content.viewModel;
                    vm.bodyLength($(this).val().length);
                });

                //IE-10 Clear event
                $("#content-body").on("mouseup", function (e) {
                    var $input = $(this),
                        oldValue = $input.val();

                    if (oldValue == "") return;

                    setTimeout(function () {
                        var newValue = $input.val();

                        if (newValue == "") {
                            var vm = athoc.iws.publishing.content.viewModel;
                            vm.bodyLength(0);
                        }
                    }, 1);
                });

                $("#content-title").focusout(function () {
                    var tooltip = $("#content-title-tooltip-template");
                    var position = $("#content-title").offset();
                    tooltip.css({ top: position.top - 200 + 'px', right: '230px' });
                    tooltip.hide();
                });

                $("#content-body").focusout(function () {
                    var tooltip = $("#content-body-tooltip-template");
                    tooltip.hide();
                });

                //Change events binding
                current.isChanged = false;

                model.Title.subscribe(function (newValue) {
                    current.dataChanged();
                    if (athoc.iws.alert != undefined) {
                        if (newValue == undefined || newValue.trim() == '') {
                            athoc.iws.alert.breadcrumbModel.updateTitle("Untitled", undefined, undefined, 'alertDetail');
                        } else {
                            athoc.iws.alert.breadcrumbModel.updateTitle(newValue, undefined, undefined, 'alertDetail');
                        }
                    }
                });
                model.Body.subscribe(function (newValue) { current.dataChanged(); });
                model.TargetUrl.subscribe(function (newValue) {

                    athoc.iws.publishing.content.createDropBoxButton(newValue);

                    current.dataChanged();

                    var prefix = 'http://';
                    var httpsPrefix = "https://";

                    newValue = newValue.trim();
                    model.TargetUrl(newValue);
                    var url = newValue.toLowerCase().trim();
                    if (url.length == 0 || url.substr(0, httpsPrefix.length).toLowerCase() == httpsPrefix)
                        return;

                    if (url.substr(0, prefix.length) !== prefix) {
                        newValue = prefix + newValue.trim();
                        model.TargetUrl(newValue);
                    } else if (newValue.indexOf(' ') >= 0) {
                        model.TargetUrl(newValue.trim());
                    }

                });
                model.Local.subscribe(function (newValue) {
                    current.dataChanged();
                    current.updateLocal();
                    athoc.iws.publishing.personalDeviceOptions.changeBasedOnLocale(newValue);
                });
                model.SeverityId.subscribe(function (newValue) {
                    current.dataChanged();
                    athoc.iws.publishing.personalDeviceOptions.changeBasedOnSeverity(newValue);
                });
                model.getSeverityNanmeFromId = function (severityId) {
                    var severityName = "";

                    var severities = athoc.iws.publishing.content.viewModel.data.Severities();

                    var found = $.grep(severities, function (severity) {
                        return severity.Id() == severityId;
                    });
                    if (found.length > 0)
                        severityName = found[0].Name();

                    return severityName;
                };
                model.SeverityName = ko.computed(function () {
                    var severityId = athoc.iws.publishing.content.viewModel.data.SeverityId();
                    return athoc.iws.publishing.content.viewModel.data.getSeverityNanmeFromId(severityId);
                    /*var severityName = "";

                    var severityId = athoc.iws.publishing.content.viewModel.data.SeverityId();
                    var severities = athoc.iws.publishing.content.viewModel.data.Severities();

                    var found = $.grep(severities, function (severity) {
                        return severity.Id() == severityId;
                    });
                    if (found.length > 0)
                        severityName = found[0].Name();

                    return severityName;
                    */
                });
                model.TypeId.subscribe(function (newValue) {

                    var found = _.find(model.Types(), function (item) {
                        return (item.Id() == newValue);
                    });

                    if (found) {
                        model.CategoryType = found;
                    }

                });
                model.TypeName = ko.computed(function () {
                    var typeId = athoc.iws.publishing.content.viewModel.data.TypeId();
                    var types = athoc.iws.publishing.content.viewModel.data.Types();
                    try {
                        var typeName = $.grep(types, function (type) {
                            return type.Id() == typeId;
                        })[0].Name();
                        return typeName;

                    } catch (e) {
                        return "";
                    }

                });

                model.ResponseOptionId.subscribe(function (previousValue) {
                    if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId() > -1) {
                        athoc.iws.publishing.content.responseOptionPreviousId = previousValue;
                        athoc.iws.publishing.fillcount.reponseTypeChange();
                    }

                }, this, "beforeChange");

                model.ResponseOptionId.subscribe(function (previousValue) {
                    if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId() == -1) {
                        current.responseOptionChanged();
                    }
                });

                if (model.ResponseOptionId() == 0 && model.ResponseOptions().length == 0) {
                    model.ResponseOptions.push(new athoc.iws.publishing.content.ResponseOptionItem({ ResponseText: '', CallBridgeNumber: '', ShowCallBridge: false, PassCode: '', ConferenceUrl: '' }));
                }
                model.ResponseOptions.subscribe(function (newValue) { current.dataChanged(); });

                //bind geo location
                athoc.iws.publishing.geo.bind(model.LocationGeo(), athoc.iws.publishing.targetByUserArea, true);

                current.checkReadyNotReady();

                if (athoc.iws.publishing.content.phBody)
                    athoc.iws.publishing.content.phBody.adjustButton();

                if (model.Languages().length == 1) {
                    $(".btn-lang").attr("disabled", "disabled");
                }

                $("#publishing-content-edit").find(".content-type button").focus();

            },

            createDropBoxButton: function (url) {
                var options = {
                    success: function (files) {
                        athoc.iws.publishing.content.viewModel.data.TargetUrl(files[0].link);
                    }
                };
                try { // If dropbox not selected for current VPS then it'll skip
                    var button = Dropbox.createChooseButton(options);
                    $("#dbChooser").empty().append(button);


                    if ($("#dbChooser").find('.dropbox-dropin-btn').length > 0)
                        $("#dbChooser").find('.dropbox-dropin-btn')[0].innerHTML = '<span class="dropin-btn-status"></span>' + athoc.iws.publishing.resources.Publishing_Content_ChooseFromDropbox;


                }
                catch (e) { }
            },

            //this method will be called when data is required for updating
            getModel: function () {
                if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content != undefined && athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.Readonly)
                    return ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.Content)

                //Load geo json as string for geo targeting
				// todo: this check is for PA case where we load only preview mode, and have no LocationGeo
				// todo: review with Nishith
                if(athoc.iws.publishing.content.viewModel.data.LocationGeo) {
                    athoc.iws.publishing.content.viewModel.data.LocationGeo(athoc.iws.publishing.geo.getModel());
                    return ko.mapping.toJS(athoc.iws.publishing.content.viewModel.data);    
                }                
            },


            //setup validation
            getValidation: function () {
                var validationMapping = {
                    Title: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                required: {
                                    params: true,
                                    message: athoc.iws.publishing.resources.Publishing_Validation_Title
                                },
                                validation: {
                                    validator: athoc.iws.publishing.content.lengthValidation,
                                    message: athoc.iws.publishing.resources.Publishing_Validation_Title,
                                    params: [this.value, 3, 100]
                                }
                            });
                        }
                    },
                    Body: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                validation: {
                                    validator: athoc.iws.publishing.content.lengthValidation,
                                    message: athoc.iws.publishing.resources.Publishing_Validation_Body,
                                    params: [this.value, 0, 2000]
                                }
                            });
                        }
                    },
                    //ResponseOptionId: {
                    //    create: function (options) {
                    //        return ko.observable(options.data).extend({
                    //            required: {
                    //                params: true,
                    //            }
                    //        });
                    //    }
                    //},
                    //TargetUrl: {
                    //    create: function (options) {
                    //        return ko.observable(options.data).extend({
                    //            validation: {
                    //                message: athoc.iws.publishing.resources.Publishing_Validation_TargetUrl,
                    //                validator: function (val) {
                    //                    if (val == undefined || val == '')
                    //                        return true;

                    //                    var isValid = true;
                    //                    var urlRegex = /(^|\s)((https?:\/\/)?[\w-]+(\.[\w-]+)+\.?(:\d+)?(\/^\S*)?)/i;
                    //                    var noSpaceRegex = /^[\S]*$/;
                    //                    isValid = val.match(urlRegex) && val.match(noSpaceRegex);
                    //                    return isValid;
                    //                },
                    //                params: [self],

                    //            },
                    //        });
                    //    }
                    //},
                    ResponseOptions: {
                        create: function (options) {
                            return new athoc.iws.publishing.content.ResponseOptionItem(options.data);
                        }
                    }
                };

                return validationMapping;
            },

            ResponseOptionItem: function (data) {
                var self = this;
                ko.mapping.fromJS(data, {}, self);
                self.ResponseText.extend({
                    maxLength: {
                        params: 64,
                        message: athoc.iws.publishing.resources.Publishing_Validation_ResponseOption
                    },
                    validation: {
                        validator: athoc.iws.publishing.content.DuplicateResponseOptionValidation,
                        message: athoc.iws.publishing.resources.Publishing_DuplicateResponseOption_ValidationMessage,
                        params: [athoc.iws.publishing.content.viewModel.data.ResponseOptions, self, 'ResponseText']
                    }
                });

                //self.CallBridgeNumber.extend({
                //    maxLength: {
                //        params: 64,
                //        message: athoc.iws.publishing.resources.Publishing_Validation_ResponseOption
                //    },
                //    //validation: {
                //    //    validator: athoc.iws.publishing.content.DuplicateResponseOptionValidation,
                //    //    message: athoc.iws.publishing.resources.Publishing_DuplicateResponseOption_ValidationMessage,
                //    //    params: [athoc.iws.publishing.content.viewModel.data.ResponseOptions, self, 'ResponseText']
                //    //}
                //});
            },

            DuplicateResponseOptionValidation: function (val, params) {

                var options = athoc.iws.publishing.content.viewModel.data.ResponseOptions;

                if (val == undefined || val == '' || options == undefined)
                    return true;

                //issue with grep switching to old way of looping
                //var numOccurences = $.grep(options(), function (elem) { return elem.Name() == val; }).length;

                var numOccurences = 0;
                for (var i = 0; i < options().length; i++) {
                    if (options()[i].ResponseText() == val)
                        numOccurences++;
                }

                return (numOccurences <= 1);

                //var isValid = true;
                //var responseOptions = athoc.iws.publishing.content.viewModel.data.ResponseOptions;
                //console.log(params);
                //console.log(responseOptions);

                //if (val == undefined || val == '' || responseOptions == undefined || responseOptions.length == 0)
                //    return isValid;

                //ko.utils.arrayFirst(params[0](), function (item) {
                //    if (val === item[params[2]]() && item !== params[1]) {
                //        isValid = false;
                //        return true;
                //    }
                //});
                //return isValid;
            },

            isLocationMandatory: function (forReadyStatus) {
                if (forReadyStatus) {
                    //TODO: Use following after implementing setting form PA
                    //if (athoc.iws.publishing.contextName == "Scenario" || athoc.iws.publishing.contextName == "AccountTemplate") {
                    if (athoc.iws.publishing.contextName == "Scenario") {
                        if (athoc.iws.scenario.settings.viewModel.scenariosettings.Content.LocationMandatoryEnabled
                            && athoc.iws.publishing.geo.viewModel.isGeoSelected() == false) {
                            $('#location-mandatory').css("display", "");
                            return false;
                        }
                    }

                    //TODO: Use following after implementing setting form PA
                    //if (athoc.iws.publishing.contextName == "Alert" || athoc.iws.publishing.contextName == "AccountEvent") {
                    if (athoc.iws.publishing.contextName == "Alert" ) {
                        if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.LocationMandatoryEnabled
                            && athoc.iws.publishing.geo.viewModel.isGeoSelected() == false) {
                            $('#location-mandatory').css("display", "");

                            return false;
                        }
                    }
                }
                else
                    //TODO: Use following after PA setting
                    //if (athoc.iws.publishing.contextName == "Alert" || athoc.iws.publishing.contextName == "AccountEvent") {
                    if (athoc.iws.publishing.contextName == "Alert") {
                            if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.LocationMandatoryEnabled
                            && athoc.iws.publishing.geo.viewModel.isGeoSelected() == false) {
                            $('#location-mandatory').css("display", "");

                            return false;
                        }
                    }
                //TODO: Use following after PA setting
                //if (athoc.iws.publishing.contextName == "Scenario" || athoc.iws.publishing.contextName == "AccountTemplate") {
                if (athoc.iws.publishing.contextName == "Scenario") {
                    if (athoc.iws.scenario.settings.viewModel.scenariosettings.Content.LocationMandatoryEnabled
                            && athoc.iws.publishing.geo.viewModel.isGeoSelected() == false) {
                            $('#location-mandatory').css("display", "");
                            return false;
                        }
                    }
                $('#location-mandatory').css("display", "none");
                return true;
            },

            //is model valid
            isValid: function () {
                var result = ko.validation.group(athoc.iws.publishing.content.viewModel.data, { deep: true });
                if (result().length > 0) {
                    result.showAllMessages(true);
                    $.AjaxLoader.hideLoader();
                    return false;
                }

                return true;
            },

            //is ready for publish
            isReadyToPublish: function () {
                return (this.viewModel.status() == 'ready');
            },


            //triggered on data changed
            dataChanged: function () {
                var current = athoc.iws.publishing.content;
                current.isChanged = true;
                current.checkReadyNotReady();
            },

            //set ready not-ready
            checkReadyNotReady: function () {
                var current = athoc.iws.publishing.content;
                if (current.isValid() && current.isLocationMandatory(true)) {
                    current.viewModel.status('ready');
                    current.viewModel.statusTooltip(athoc.iws.publishing.resources.Publishing_Section_Ready_Tooltip);
                } else {
                    current.viewModel.status('not-ready');
                    current.viewModel.statusTooltip(athoc.iws.publishing.resources.Publishing_Section_NotReady_Tooltip);
                }
                current.onReadyChange(current.viewModel.status() == 'ready' ? true : false);

                if (athoc.iws.publishing.contextName == "Alert" && athoc.iws.alert.test)
                    athoc.iws.alert.test.enableTestAlertButton(athoc.iws.publishing.content.isReadyToPublish());

                athoc.iws.publishing.detail.checkStatusChange();
            },

            //on response option change
            responseOptionChanged: function () {
                var current = athoc.iws.publishing.content;
                current.dataChanged();

                var model = current.viewModel;
                model.data.ResponseOptions.removeAll();

                var option = $.grep(model.data.ResponseOptionList(), function (e) { return e.Id() == model.data.ResponseOptionId(); });
                if (option.length == 1) {

                    $.each(option[0].Values(), function (index, value) {
                        model.data.ResponseOptions.push(new athoc.iws.publishing.content.ResponseOptionItem({ ResponseText: value, CallBridgeNumber: '', ShowCallBridge: false, PassCode: '', ConferenceUrl: '' }));
                    });
                }

                if (model.data.ResponseOptionId() == 0 && model.data.ResponseOptions().length == 0) {
                    model.data.ResponseOptions.push(new athoc.iws.publishing.content.ResponseOptionItem({ ResponseText: '', CallBridgeNumber: '', ShowCallBridge: false, PassCode: '', ConferenceUrl: '' }));
                }
            },

            //update local
            updateLocal: function () {
                var displayVal = '';
                var model = ko.mapping.toJS(athoc.iws.publishing.content.viewModel.data);
                for (var index = 0; index < model.Languages.length; index++) {
                    if (model.Languages[index].Code === athoc.iws.publishing.content.viewModel.data.Local()) {
                        displayVal = model.Languages[index].Name;
                        break;
                    };
                };
                athoc.iws.publishing.content.viewModel.localDisplay(displayVal);
                athoc.iws.publishing.content.viewModel.localDisplayTooltip(displayVal);

                //athoc.iws.publishing.content.updateLanguageTooltip();
                //if (displayVal == 'en-US') {
                //    displayVal = "EN (US)";
                //} else if (displayVal == 'ar-SA') {
                //    displayVal = "AR (SA)";
                //} else if (displayVal == 'fr-FR') {
                //    displayVal = "FR (FR)";
                //} else if (displayVal == 'ja-JP') {
                //    displayVal = "JA (JP)";
                //}

            },

            updateLanguageTooltip: function () {
                var displayVal = athoc.iws.publishing.content.viewModel.data.Local();
                if (displayVal == 'en-US') {
                    displayVal = "English (United States)";
                } else if (displayVal == 'ar-SA') {
                    displayVal = "Arabic (Saudi Arabia)";
                } else if (displayVal == 'fr-FR') {
                    displayVal = "French (France)";
                } else if (displayVal == 'ja-JP') {
                    displayVal = "Japanese (Japan)";
                }
                athoc.iws.publishing.content.viewModel.localDisplayTooltip(displayVal);
            },
            applyReadonlySettingsOnContent: function (data, targetDiv) {
                //var targetDiv = $("#alert-content-detail");
                if (data.Content != undefined && data.Content.ResponseOptions != undefined && data.Content.ResponseOptions.length > 0) {
                    var reponseOptions = [];
                    for (var i = 0; i < data.Content.ResponseOptions.length; i++) {
                        if (data.Content.ResponseOptions[i].ResponseText.trim() !== '') {
                            reponseOptions.push(data.Content.ResponseOptions[i]);
                        }
                    }
                    data.Content.ResponseOptions = reponseOptions;
                    var responseOptions = $.grep(data.Content.ResponseOptionList, function (e) { return e.Id == data.Content.ResponseOptionId; });
                    if (responseOptions && responseOptions.ResponseText)
                        athoc.iws.publishing.content.viewModel.ResponseName = responseOptions.ResponseText;
                }

                athoc.iws.publishing.content.ReadonlyViewModel.data = ko.mapping.fromJS(data);
                //adding linebreak for alert body
                try {
                    if (data.Content != undefined && data.Content.Body != undefined && data.Content.Body != null) {
                        athoc.iws.publishing.content.ReadonlyViewModel.bodyWithLineBreak($.htmlEncode(data.Content.Body.trim()).replace(/(?:\r\n|\r|\n)/g, '<br />'));
                    } else {
                        athoc.iws.publishing.content.ReadonlyViewModel.bodyWithLineBreak('');
                    }
                    athoc.iws.publishing.content.ReadonlyViewModel.alertTitle(data.Content.Title);
                }
                catch (e) { }
                //ko.cleanNode(targetDiv.get(0));
                // if (data.Content.LocationGeo != "" && data.Content.LocationGeo != undefined)
                //  athoc.iws.publishing.geo.readOnlyBind(data.Content.LocationGeo, true, true);

                //TODO: Readonly view of alert
                //ko.cleanNode(targetDiv.find(".content-section").get(0));
                //ko.applyBindings(athoc.iws.publishing.content.ReadonlyViewModel, targetDiv.find(".content-section").get(0));


            },

            onReadyChange: function (isReady) { },
        };
    }();
}
///#source 1 1 /Scripts/Publishing/athoc.iws.publishing.targetUsers.js
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};

if (athoc.iws.publishing) {
    athoc.iws.publishing.targetUsers = function () {
        return {
            Parameters: {},
            viewModelInstance: {},
            //Viewmodel for the Target section in readonly
            ReadonlyviewModel: {},
            SelectedGroupedDevices: function () {
                var selectedDevices = [];
                var lastGroup = '';
                if ((athoc.iws.publishing.source == null || athoc.iws.publishing.source == '') && (this.viewModelInstance.Devices!== undefined)) {
                    _.each(this.viewModelInstance.Devices(), function (item, index) {
                        if (item.Selected()) {
                            var groupChanged = false;
                            if (lastGroup != item.GroupName()) {
                                groupChanged = true;
                                lastGroup = item.GroupName();
                            }
                            var device = { DeviceId: item.DeviceId, DeviceName: item.DeviceName, GroupChange: groupChanged, GroupId: item.GroupId, GroupName: item.GroupName, HideInReadOnlyView: item.HideInReadOnlyView, Reach: item.Reach, Selected: true, CustomText: ko.observable(null) };
                            selectedDevices.push(device);
                        }
                    });
                } else {
                    if (athoc.iws.publishing.view !== undefined) {
                        _.each(athoc.iws.publishing.view.viewModel.personalDeviceList.Devices(), function (item, index) {
                            var groupChanged = false;
                            //if (lastGroup != item.GroupName) {
                            groupChanged = true;
                            lastGroup = item.GroupName;
                            var device = { DeviceId: item.DeviceId, DeviceName: item.DeviceName, GroupChange: groupChanged, GroupId: item.GroupId, GroupName: item.GroupName, HideInReadOnlyView: item.HideInReadOnlyView, Reach: item.Reach, Selected: true, CustomText: ko.observable(null) };
                            selectedDevices.push(device);
                            //}
                        });
                    }

                }

                return { Devices: selectedDevices };
            },

            SessionId: {},
            TreeIsSelected: false,
            PieDataSource: null,
            PieChartObject: null,
            //is section ready to publish
            isReadyToPublish: false,

            //is in error state
            isInErrorState: true,
            summaryDivTrmplate: "<div class=\"summary-row ellipsis\" title='{1}'>{0}</div>",
            DeviceGroupOptions: new Array(),
            presetDeviceOptions: new Array(),

            advancedQueryCriteria: null,
            treeIsLoaded: false,
            deviceOptionIsLoaded: false,
            clearingAllCriteria: false,

            setPresetDeviceOptions: function (presetDeviceGroupOptions) {
                this.presetDeviceOptions = presetDeviceGroupOptions;
            },
            bind: function (data, presetDeviceGroupOptions) {
                var self = this;
                self.advancedQueryCriteria = null;

                this.targetGroupInstance.LoadViewModel(data);

                /*
                var deliveryOrders = [1];
                if (data.MaxDelivery) {
                    for (var i = 2; i <= data.MaxDelivery; i++) {
                        deliveryOrders.push(i);
                    }
                }
                self.viewModelInstance.DeliveryOrderList = ko.observable(deliveryOrders);
                */

                if (typeof data.TargetedUserCountForLiveEndedAlert != "undefined") {
                    this.targetGroupInstance.ViewModel.set("TargetedUserCountForLiveEndedAlert", data.TargetedUserCountForLiveEndedAlert);
                }

                this.presetDeviceOptions = presetDeviceGroupOptions;
                //load query builder  

                /*$(this.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder({
                    options: this.Parameters.queryBuilderParameters
                });
                */

                var onShown = function (queryDivSelector) {
                    return function () {
                        self.viewModelInstance.numberQueryCriteria($(queryDivSelector).athocQueryBuilder("getCurrentSelections").selections.length);

                        //update contact pie chart
                        var tempCriteria = $(queryDivSelector).athocQueryBuilder("getCurrentSelections");
                        athoc.iws.publishing.detail.isQueryLoaded = true;

                        athoc.iws.publishing.targetUsers.updateContactInfo();
                        self.advancedQueryCriteria = tempCriteria;
                        if (athoc.iws.publishing.detail.viewModel.ScenarioSettings && athoc.iws.scenario) {                        
                            athoc.iws.scenario.settings.ApplysettingsOnFingerTabs(athoc.iws.publishing.detail.viewModel.ScenarioSettings.Targeting.EnabledTargetingTypes);
                        }

                        self.targetingChanged();
                    };
                }(this.Parameters.queryBuilderParameters.queryBuilderDiv);

                $(this.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder("setOnShownFunction", onShown);

                var onChanged = function (queryDivSelector) {
                    return function () {
                        self.viewModelInstance.numberQueryCriteria($(queryDivSelector).athocQueryBuilder("getCurrentSelections").selections.length);

                        //update contact pie chart
                        var tempCriteria = $(queryDivSelector).athocQueryBuilder("getCurrentSelections");

                        athoc.iws.publishing.detail.isQueryLoaded = true;
                        if (!self.isQueryCriteriaEqual(tempCriteria, self.advancedQueryCriteria) && !self.clearingAllCriteria) {

                            athoc.iws.publishing.targetUsers.updateContactInfo();
                        }
                        self.advancedQueryCriteria = tempCriteria;

                        athoc.iws.publishing.scenario.isChanged = true;
                        athoc.iws.publishing.targetUsers.targetingChanged();
                    };
                }(this.Parameters.queryBuilderParameters.queryBuilderDiv);

                $(this.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder("setOnChangedFunction", onChanged);


                if (data.TargetedCriteria && data.TargetedCriteria.selections) {
                    $(this.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder("setPreselections", data.TargetedCriteria.selections);
                } else {
                    $(this.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder("setPreselections", null);
                }
                $(this.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder("show");
            },

            //helper function to compare query criteria
            isQueryCriteriaEqual: function (criteriaOne, criteriaTwo) {
                try {
                    return criteriaOne.display.join() == criteriaTwo.display.join();
                } catch (e) {
                    return true;
                }
            },

            getModel: function () {
                if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content != undefined && athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Targeting.Readonly && athoc.iws.publishing.targetUsers.isReadyToPublish && !$("#alert-user-edit").is(':visible')) {
                    var targetusersByArea = false;
                    if (athoc.iws.publishing.geo.viewModel.isGeoSelected() && athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetUsersByArea()) {
                        targetusersByArea = true;
                    }
                    return {
                        Devices: ko.mapping.toJS(athoc.iws.publishing.view.viewModel.personalDeviceList.Devices),
                        TargetingNodes: ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetingNodes),
                        TargetedCriteria: ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetedCriteria),
                        DeviceGroupOptions: this.DeviceGroupOptions, //IWS-14434: send device options in this case as well they are already set properly by client script
                        TargetedBlockedUsers: athoc.iws.publishing.view.viewModel.TargetedBlockerUsersList,
                        TargetUsersByArea: targetusersByArea
                    };

                }
                else {
                    //convert viewmodel to the format that will be set to server side with all of other sections. 
                    //this.TargetUsersViewModel.Devices([1034]);
                    var checkedDevices = ko.mapping.toJS(this.viewModelInstance.Devices()).filter(function (el) {
                        return el.Selected;
                    });
                    var targetusersByArea = false;
                    if (athoc.iws.publishing.geo.viewModel.isUsersTargeted() && athoc.iws.publishing.geo.geoJson != null) {
                        targetusersByArea = true;
                    }
                    else
                        athoc.iws.publishing.targetUsers.viewModelInstance.numberAreaCriteria(0);
                    var advanceCriteriaModel = null;
                    var advancedCriteriaSelected = (athoc.iws.publishing.settings.IsAdvancedQuerySuuported) && (this.viewModelInstance.numberQueryCriteria() > 0);
                    if (advancedCriteriaSelected) {
                        advanceCriteriaModel = $(this.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder("getCurrentSelections");
                    }
                    return {
                        Devices: checkedDevices,
                        TargetingNodes: this.targetGroupInstance.ViewModel.get("SelectedNodes"),
                        TargetedCriteria: advanceCriteriaModel,
                        DeviceGroupOptions: this.DeviceGroupOptions,
                        TargetedBlockedUsers: athoc.iws.publishing.iut.getModel(),
                        TargetUsersByArea: targetusersByArea
                    };
                }
            },

            refresh: function (entityId) {
                this.treeIsLoaded = false;
                this.deviceOptionIsLoaded = false;

                //refresh will re-initialize the view model as well as rebinding the controls
                //re-create view model
                this.targetGroupInstance.LoadViewModel();

                kendo.ui.progress($("#publishing-user-edit"), true);
                $(".alert-nav").attr("disabled", true);
                $(".severity-list").find("button").prop("disabled", true);


                athoc.iws.publishing.detail.checkStatusChange();

                //making a single ajax call to get targeting tree and device data
                var ajaxSuccessWrapper = function (context) {

                    $(".severity-list").find("button").prop("disabled", false);
                    $(".severity-list").find("button").focus();

                    return function (data) {
                        //kendo.ui.progress($("#divDevices, #divTgTree"), false); //must show now loading until device option is done loading, to meet desktop popup requirement
                        $("#treeview").show();

                        var deliveryOrders = [1];
                        if (data.PhoneCount) {
                            for (var i = 2; i <= data.PhoneCount; i++) {
                                deliveryOrders.push(i);
                            }
                        }
                        //self.viewModelInstance.DeliveryOrderList = ko.observable(deliveryOrders);
                        ko.mapping.fromJS(deliveryOrders, {}, context.viewModelInstance.DeliveryOrderList);


                        ko.mapping.fromJS(data.Devices, {}, context.viewModelInstance.Devices);
                        ko.mapping.fromJS(data.DeviceGroups, {}, context.viewModelInstance.DeviceGroups);

                        athoc.iws.publishing.targetUsers.targetGroupInstance.RefreshTreeView(data);

                        var onSave = function (selectedOptions) {
                            context.DeviceGroupOptions = selectedOptions;
                        }

                        var onLoadDone = function (selectedOptions) {
                            context.deviceOptionIsLoaded = true;
                            if (context.treeIsLoaded) { //must check to make sure both tree and device option  is loaded. 
                                $(".alert-nav").attr("disabled", false);
                            }
                            context.DeviceGroupOptions = selectedOptions;
                            kendo.ui.progress($("#publishing-user-edit"), false);

                            $(".alert-nav").attr("disabled", false);

                            
                            
                        }

                        athoc.iws.publishing.personalDeviceOptions.load(ko.mapping.toJS(context.viewModelInstance.Devices()), context.presetDeviceOptions, onSave, onLoadDone);                        
                        if (athoc.iws.publishing.detail.viewModel.ScenarioSettings && athoc.iws.scenario) {
                            athoc.iws.scenario.settings.ApplysettingsOnFingerTabs(athoc.iws.publishing.detail.viewModel.ScenarioSettings.Targeting.EnabledTargetingTypes);
                        }



                    }
                }(this);

                var targetingInfoSuccess = function (data) {
                    ajaxSuccessWrapper(data);
                    athoc.iws.publishing.detail.checkStatusChange(true);
                };

                var targetingInfoError = function (e) {
                    kendo.ui.progress($("#publishing-user-edit"), false);
                    var errorCallBack = function (returnedErrorObject) {
                        $('#listMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                    };
                }
                var param1;
                var param2;
                var param3;
                if (athoc.iws.alert == undefined) {
                    param1 = entityId;
                    param2 = "";
                    param3 = "";

                } else if (athoc.iws.alert.action == 'rbt') {
                    param1 = athoc.iws.publishing.rbt.AlertId;
                    param2 = "rbt";
                    param3 = athoc.iws.publishing.rbt.IncludeDevices == true ? 0 : athoc.iws.publishing.rbt.DeviceId;
                } else {
                    param1 = entityId;
                    param2 = "";
                    param3 = "";
                }

                var ajaxOptions = {
                    cache: false,
                    url: athoc.iws.publishing.urls.GetDeviceListUrl,
                    data: { context: this.Parameters.context, id: param1, recipientType: param2, deviceId: param3 },
                    type: "POST"
                };

                var ajaxOptions = $.extend({}, AjaxUtility(targetingInfoError, targetingInfoSuccess).ajaxPostOptions, ajaxOptions);
                $.ajax(ajaxOptions);
            },

            loadTargetUsersViewModel: function () {
                var targetVM = function (context) {
                    var self = this;
                    self.Devices = ko.observableArray();
                    self.DeviceGroups = ko.observableArray();

                    self.UsersCount = ko.observable(0);

                    self.ShowUsers = ko.observable(true);

                    self.ReachableUsers = ko.observable(0);
                    self.ReachableUsersPercentage = ko.observable(0);

                    self.UnReachableUsers = ko.observable(0);
                    self.UnReachableUsersPercentage = ko.observable(0);
                    self.numberQueryCriteria = ko.observable(0);
                    self.numberAreaCriteria = ko.observable(0);

                    self.numberOfDevices = ko.observable(0);

                    self.DeliveryOrderList = ko.observable([]);

                    self.AnyDeviceSelected = function () {
                        var checkedDevices = ko.mapping.toJS(self.Devices()).filter(function (el) {
                            return el.Selected;
                        });

                        return checkedDevices.length > 0;
                    };
                    self.toggleDeviceOptionLink = function () {
                        if (!self.AnyDeviceSelected()) {
                            $(context.Parameters.personalDeviceOptionsLink).toggleClass("link-disabled", true);
                            $("#personalDeviceOptionsLink").attr("disabled", true);
                        } else {
                            $(context.Parameters.personalDeviceOptionsLink).toggleClass("link-disabled", false);
                            $("#personalDeviceOptionsLink").attr("disabled", false);
                        }

                    };
                    self.deviceChanged = function (device) {
                        kendo.ui.progress($("#publishing-user-edit"), true);

                        var checkedDevices = ko.mapping.toJS(context.viewModelInstance.Devices()).filter(function (el) {
                            return el.Selected;
                        });
                        $(".alert-nav").attr("disabled", true);
                        $(".severity-list").find("button").prop("disabled", true)

                        context.viewModelInstance.numberOfDevices(checkedDevices.length);

                        var onLoadDone = function (selectedOptions) {
                            kendo.ui.progress($("#publishing-user-edit"), false);
                            $(".alert-nav").attr("disabled", false);
                            $(".severity-list").find("button").prop("disabled", false);
                            context.DeviceGroupOptions = selectedOptions;
                        }

                        athoc.iws.publishing.personalDeviceOptions.loadOnlyNewDeviceGroups(checkedDevices, onLoadDone);
                        context.updateContactInfo();
                        context.targetingChanged();
                        self.toggleDeviceOptionLink();
                        athoc.iws.publishing.scenario.isChanged = true;
                        return true;
                    }

                    self.DisplayUserList = function () {
                        //alert("You have to pass sessionId to the user list  popup, which is " + context.SessionId + " For info on how to pass session Id and also get columns, pls talk to tarun.");
                        //to show readOnlyUserList
                        if (self.UsersCount() > 0) {
                            $("#readOnlyUserListTitle").html(athoc.iws.publishing.iut.resources.readOnlyUserCountTitle);
                            //Condition is added to ShowUsersList in readonly mode
                            athoc.iws.publishing.iut.ShowUsersList(athoc.iws.publishing.source == "readonly" ? athoc.iws.publishing.view.viewModel.data.SessionId : context.SessionId, -1, "", self.UsersCount());
                        }
                    }

                    self.GetReachableUserList = function () {
                        if (self.ReachableUsers() > 0) {
                            self.LaunchContactInfoUserList(1);
                        }
                    }

                    self.GetUnReachableUserList = function () {
                        if (self.UnReachableUsers() > 0) {
                            self.LaunchContactInfoUserList(0);
                        }
                    }

                    self.LaunchContactInfoUserList = function (covered) {
                        var checkedDevices = null;
                        if (athoc.iws.publishing.source == 'p' || athoc.iws.publishing.source == 'h') {
                            checkedDevices = ko.mapping.toJS(this.ReadonlyviewModel.Devices()).filter(function (el) {
                                return el.Selected;
                            }).map(function (item) { return item.DeviceId; });
                        }
                        else {
                            var checkedDevices = ko.mapping.toJS(self.Devices()).filter(function (el) {
                                return el.Selected;
                            }).map(function (item) { return item.DeviceId; });
                        }

                        var attributeIdCSV = checkedDevices.join(",");
                        //to show readOnlyUserList
                        if (covered == 1)
                            $("#readOnlyUserListTitle").html(athoc.iws.publishing.iut.resources.readOnlyReacheableCountTitle + "(" + self.ReachableUsers() + ")");
                        else
                            $("#readOnlyUserListTitle").html(athoc.iws.publishing.iut.resources.readOnlyNotReacheableCountTitle + "(" + self.UnReachableUsers() + ")");
                        //Condition is added to display User list in readonly mode
                        var param = (athoc.iws.publishing.source == "p" || athoc.iws.publishing.source == "h") ? athoc.iws.publishing.view.viewModel.data.SessionId : context.SessionId;
                        athoc.iws.publishing.iut.ShowUsersList(param, covered, "", covered == 1 ? self.ReachableUsers() : self.UnReachableUsers());
                    }


                    self.showQuerySummary = function () {
                        if (self.numberQueryCriteria() > 0) {
                            $(context.Parameters.dialogTargetingSummary).find("#spanTitle").text(athoc.iws.publishing.iut.resources.TargetUsers_Advanced_Query);
                            var summaryDiv = $(context.Parameters.dialogTargetingSummary).find(context.Parameters.targetingSummaryContentDiv);
                            summaryDiv.html("");
                            var selections = $(context.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder("getCurrentSelections");

                            var seletionTextArray = selections.display;

                            _.each(seletionTextArray, function (item, index) {
                                if (index != 0) {
                                    summaryDiv.append("<div class=\"summary-row summary-operator-row\">" + athoc.iws.publishing.resources.Publishing_TargetUsers_Advanced_Query_Summary_And + "</div>");
                                }

                                summaryDiv.append(context.summaryDivTrmplate.format(item, selections.displayNoStyle[index]));
                                index += 1;
                            });
                            $(context.Parameters.dialogTargetingSummary).modal("show");
                        }
                    };

                    //on number of map area clicked
                    self.showAreaSummary = function () {
                        if (self.numberAreaCriteria() > 0) {
                            //Show map with objects in model window
                            $("#dialogGeoTargetingSummary").modal("show");
                        }
                    };

                    //show selected devices list
                    self.showDeviceSummary = function () {
                        if (self.numberOfDevices() > 0) {
                            //show device summary
                            $("#personalDeviceSummaryDiv").html('');
                            ko.cleanNode($("#dialogPersonalDevicesSummary").get(0));
                            var groupedDevices = athoc.iws.publishing.targetUsers.SelectedGroupedDevices();
                            ko.applyBindings(groupedDevices, $("#dialogPersonalDevicesSummary").get(0));
                            $("#dialogPersonalDevicesSummary").modal("show");
                        }
                    };

                    self.numGroupsTargeted = ko.observable(0);
                    self.numGroupsBlocked = ko.observable(0);

                    self.showTargetedGroupSummary = function () {
                        if (self.numGroupsTargeted() > 0) {
                            $(context.Parameters.dialogTargetingSummary).find("#spanTitle").text(athoc.iws.publishing.iut.resources.ByGroups);
                            var summaryDiv = $(context.Parameters.dialogTargetingSummary).find(context.Parameters.targetingSummaryContentDiv);
                            var template = kendo.template($("#groupsummary-template").html());
                            var result = template(athoc.iws.publishing.targetUsers.targetGroupInstance.ViewModel.TargetedGroupsFormatted());
                            summaryDiv.html(result);
                            $(context.Parameters.dialogTargetingSummary).modal("show");
                        }
                    };

                    self.showBlockedGroupSummary = function () {
                        if (self.numGroupsBlocked() > 0) {
                            $(context.Parameters.dialogTargetingSummary).find("#spanTitle").text(athoc.iws.publishing.iut.resources.ByGroupsBlocked);
                            var summaryDiv = $(context.Parameters.dialogTargetingSummary).find(context.Parameters.targetingSummaryContentDiv);
                            var template = kendo.template($("#groupsummary-template").html());
                            var result = template(athoc.iws.publishing.targetUsers.targetGroupInstance.ViewModel.BlockedGroupsFormatted());
                            summaryDiv.html(result);
                            $(context.Parameters.dialogTargetingSummary).modal("show");
                        }
                    };

                    self.numTargetedUsers = ko.observable(0);

                    self.showTargetedUsersSummary = function () {
                        if (self.numTargetedUsers() > 0) {
                            athoc.iws.publishing.iut.showTargetedUsersSummary(false);
                            $("#targetedUsersSummary").find("h2").html(athoc.iws.publishing.iut.resources.ByUsers + '(' + self.numTargetedUsers() + ')');
                            $("#targetedUsersSummary").modal("show");
                        }
                    };
                    self.numBlockedUsers = ko.observable(0);

                    self.showBlockedUsersSummary = function () {
                        if (self.numBlockedUsers() > 0) {
                            athoc.iws.publishing.iut.showBlockedUsersSummary(false);
                            $("#blockedUsersSummary").find("h2").html(athoc.iws.publishing.iut.resources.ByUsersBlocked + '(' + self.numBlockedUsers() + ')');
                            $("#blockedUsersSummary").modal("show");
                        }
                    };
                };

                this.viewModelInstance = new targetVM(this);

                ko.cleanNode($("#devicesListDiv").get(0));

                ko.applyBindings(this.viewModelInstance, $("#devicesListDiv").get(0));
                ko.applyBindings(this.viewModelInstance, $("#targetUsersHeaderDiv").get(0));
                ko.applyBindings(this.viewModelInstance, $("#contactInfoSummary").get(0));
                ko.applyBindings(this.viewModelInstance, $("#targetUsersSummary").get(0));
            },

            init: function (parameters) {
                self = this;
                //init is called once when the page loads for the first time.
                //all controls are created here.
                this.Parameters = parameters;
                //this.createTargetingTree();
                this.targetGroupInstance = new athoc.iws.publishing.TargetGroup('#treeview');
                this.targetGroupInstance.TreeView.bind("check", function (e) {
                    athoc.iws.publishing.scenario.isChanged = true;
                    var targetedNodes = athoc.iws.publishing.targetUsers.targetGroupInstance.ViewModel.TargetedGroups();
                    var blockedNodes = athoc.iws.publishing.targetUsers.targetGroupInstance.ViewModel.BlockedGroups();
                    athoc.iws.publishing.targetUsers.viewModelInstance.numGroupsTargeted(targetedNodes.length);
                    athoc.iws.publishing.targetUsers.viewModelInstance.numGroupsBlocked(blockedNodes.length);
                    athoc.iws.publishing.targetUsers.treeSelectionChanged();
                });
                this.targetGroupInstance.TreeView.bind("dataBound", function (e) {
                    if (!e.node) {
                        var targetedNodes = athoc.iws.publishing.targetUsers.targetGroupInstance.ViewModel.TargetedGroups();
                        var blockedNodes = athoc.iws.publishing.targetUsers.targetGroupInstance.ViewModel.BlockedGroups();
                        athoc.iws.publishing.targetUsers.viewModelInstance.numGroupsTargeted(targetedNodes.length);
                        athoc.iws.publishing.targetUsers.viewModelInstance.numGroupsBlocked(blockedNodes.length);
                        athoc.iws.publishing.targetUsers.treeSelectionChanged();

                        self.treeIsLoaded = true;
                        if (self.deviceOptionIsLoaded) { //must check to make sure both tree and device option  is loaded. 
                            $(".alert-nav").attr("disabled", false);
                        }
                    }
                });

                this.loadTargetUsersViewModel();
                this.createPieChart();

                var self = this;

                $(this.Parameters.clearAllCriteriaLink).on("click", function () {
                    self.clearingAllCriteria = true;
                    $(self.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder("clearAll");
                    self.clearingAllCriteria = false;
                    athoc.iws.publishing.targetUsers.updateContactInfo();

                });

                $(this.Parameters.personalDeviceOptionsLink).on("click", function () {

                    if (self.viewModelInstance.AnyDeviceSelected()) {

                        $(self.Parameters.dialogDeviceOptions).modal("show");
                        athoc.iws.utilities.resizeModalBasedOnScreen($(self.Parameters.dialogDeviceOptions), 600, 770, 20, 170);
                    }
                });
            },

            load: function (entityId) {
                var self = this;

                //reset all of the parameters
                this.TreeIsSelected = false;
                this.DeviceIsSelected = false;
                this.viewModelInstance.UsersCount(0);
                this.viewModelInstance.Devices([]);
                athoc.iws.publishing.SetSectionStatus("#targetUsersStatus", "open");
                athoc.iws.publishing.targetUsers.isReadyToPublish = false;

                //load will be called when the detail view is visible again. 
                this.refresh(entityId);
            },

            createPieChart: function () {

                require(['publishing/athoc.iws.publishing.contactInfoPieChart'], function (ContactInfoPieChart) {
                    PieChartObject = new ContactInfoPieChart({
                        domPointer: "#contactInfo",
                        Publishing_Contact_Info_No_users_found: athoc.iws.publishing.resources.Publishing_Contact_Info_No_users_found,
                        Publishing_Contact_Info_Reachable_Tooltip: athoc.iws.publishing.resources.Publishing_Contact_Info_Reachable_Tooltip,
                        Publishing_Contact_Info_Not_Reachable_Tooltip: athoc.iws.publishing.resources.Publishing_Contact_Info_Not_Reachable_Tooltip,
                    });
                });

            },

            //Update contact chart
            updateContactInfo: function () {

                if (!athoc.iws.publishing.detail.isEverythingLoaded()) {
                    return;
                }

                var self = this;

                //turn on now loading
                self.viewModelInstance.ShowUsers(false);
                kendo.ui.progress($("#contactInfo"), true);
                //$.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $("#scenarioDetailsDiv"), imageURL: athoc.iws.scenario.urls.cdnUrl + '/Images/ajax-loader.gif', left: '50%' }).showLoader();

                var checkedDevices = ko.mapping.toJS(this.viewModelInstance.Devices()).filter(function (el) {
                    return el.Selected;
                });

                var devices = checkedDevices.map(function (item) { return item.DeviceId; });
                this.viewModelInstance.numberOfDevices(devices.length);

                var treeNodes = this.targetGroupInstance.ViewModel.SelectedNodes;

                var advancedCriteria = null;
                //if advanced targeting is enabled get criteria
                if ($(this.Parameters.queryBuilderParameters.queryBuilderDiv).length > 0) {
                    $(this.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder();
                    advancedCriteria = $(this.Parameters.queryBuilderParameters.queryBuilderDiv).athocQueryBuilder("getCurrentSelections");
                }

                var targetedArea = "";
                //send targeted area
                if (athoc.iws.publishing.geo.viewModel.isUsersTargeted() && athoc.iws.publishing.geo.geoJson != null) {
                    targetedArea = JSON.stringify(athoc.iws.publishing.geo.geoJson);
                }
                //send targeted users and blocked users
                var targetdUsers = athoc.iws.publishing.iut.getTargetedUsers();
                var blockedUsers = athoc.iws.publishing.iut.getBlockedUsers();

                //condition to checked whether readonly or not.
                if (athoc.iws.publishing.source != 'readonly') {
                    var userInfoSuccess = function (data) {

                        self.viewModelInstance.UsersCount(data.TotalCount);
                        self.viewModelInstance.ShowUsers(true);

                        self.SessionId = data.SessionId;

                        if (data.TotalCount == 0) {
                            self.resetReach();
                        } else {
                            _.each(data.ContactInfo.ContactInfo, function (item, index) {
                                var found = _.find(self.viewModelInstance.Devices(), function (itemVM) {
                                    return (itemVM.DeviceId() == item.DeviceId);
                                });

                                if (found) {
                                    found.Reach(item.Percentage);
                                }
                            });

                            //set up summary
                            self.viewModelInstance.ReachableUsers(data.ContactInfo.TotalCovered);
                            self.viewModelInstance.ReachableUsersPercentage(data.ContactInfo.TotalCoveredPercentage);

                            self.viewModelInstance.UnReachableUsers(data.ContactInfo.TotalNotCovered);
                            self.viewModelInstance.UnReachableUsersPercentage(data.ContactInfo.TotalNotCoveredPercentage);


                            //draw pie
                            var contactInfo = [{
                                "type": "covered",
                                "number": data.ContactInfo.TotalCovered,
                                "color": "#7CB500",
                                "customPercentage": data.ContactInfo.TotalCoveredPercentage
                            }, {
                                "type": "notcovered",
                                "number": data.ContactInfo.TotalNotCovered,
                                "color": "#AE004B",
                                "customPercentage": data.ContactInfo.TotalNotCoveredPercentage
                            }];
                            PieChartObject.update(contactInfo);

                        }
                        if (data.ContactInfo.TotalCovered > 0 || data.ContactInfo.TotalNotCovered > 0)
                            $("#contactInfo").css("cursor", "pointer");
                        else
                            $("#contactInfo").css("cursor", "default");
                        //$.AjaxLoader.hideLoader();
                        kendo.ui.progress($("#contactInfo"), false);


                        if (athoc.iws.publishing.contextName == "Alert") {
                            athoc.iws.scenario.settings.applyVisibleSettingsOnAlert();
                        }

                        if ($("#personalDeviceOptionsLink"))
                            if (athoc.iws.publishing.targetUsers.viewModelInstance.AnyDeviceSelected()) {
                                $("#personalDeviceOptionsLink").toggleClass("link-disabled", false);
                            } else {
                                $("#personalDeviceOptionsLink").toggleClass("link-disabled", true);
                            }

                    };

                    var userInfoError = function (error) {
                        self.viewModelInstance.UsersCount(0);
                        self.viewModelInstance.ShowUsers(true);

                        //$.AjaxLoader.hideLoader();
                        kendo.ui.progress($("#contactInfo"), false);
                    };
                    athoc.iws.publishing.UpdateContactInfo(0, "", treeNodes, devices, userInfoSuccess, userInfoError, advancedCriteria, targetedArea, targetdUsers, blockedUsers, athoc.iws.publishing.rbt);
                }
            },

            resetReach: function () {
                _.each(this.viewModelInstance.Devices(), function (itemVM) {
                    itemVM.Reach(0);
                });

                this.viewModelInstance.ReachableUsers(0);
                this.viewModelInstance.ReachableUsersPercentage(0);

                this.viewModelInstance.UnReachableUsers(0);
                this.viewModelInstance.UnReachableUsersPercentage(0);

                //draw pie
                var contactInfo = [{
                    "type": "none",
                    "number": 100,
                    "color": "#ccc"
                }];

                PieChartObject.update(contactInfo);
                //$("#contactInfo").data("kendoChart").dataSource.data(contactInfo);

            },

            treeSelectionChanged: function () {

                this.TreeIsSelected = (this.targetGroupInstance.ViewModel.SelectedNodes.length != 0);

                this.targetingChanged();

                athoc.iws.publishing.detail.isTreeLoaded = true;

                if (this.TreeIsSelected) {
                    this.updateContactInfo();
                } else {
                    this.viewModelInstance.UsersCount(0);
                    this.updateContactInfo();
                }
            },

            targetingChanged: function () {
                //if advanced targeting is enabled get criteria
                // var advancedCriteriaSelected = (athoc.iws.publishing.settings.IsAdvancedQuerySuuported) && (this.viewModelInstance.numberQueryCriteria() > 0);
                var advancedCriteriaSelected = 0;
                if ((athoc.iws.publishing.contextName == "Alert" || athoc.iws.publishing.contextName == "AccountEvent")
                    && athoc.iws.scenario.settings.ReadonlyViewModel != null && athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Targeting.Readonly) {
                    advancedCriteriaSelected = (athoc.iws.publishing.settings.IsAdvancedQuerySuuported) && (athoc.iws.publishing.view.viewModel.QueryCriteriaCount() > 0);
                } else {
                    advancedCriteriaSelected = (athoc.iws.publishing.settings.IsAdvancedQuerySuuported) && (this.viewModelInstance.numberQueryCriteria() > 0);
                }

                //is target by area selected
                var targetByAreaSelected = (athoc.iws.publishing.settings.IsTargetByAreaSupported)
                    && (athoc.iws.publishing.geo.viewModel.isGeoSelected())
                    && (athoc.iws.publishing.geo.viewModel.isUsersTargeted());

                //is IUT selected
                var iutTargeted = (athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList().length > 0);

                //check if any of targeting is selected
                var anyTargetingSelected = (this.TreeIsSelected
                    || iutTargeted
                    || advancedCriteriaSelected
                    || targetByAreaSelected || (athoc.iws.publishing.rbt != null));

                if (anyTargetingSelected && this.viewModelInstance.AnyDeviceSelected()) {
                    athoc.iws.publishing.targetUsers.isReadyToPublish = true;
                    athoc.iws.publishing.targetUsers.isInErrorState = false;
                    athoc.iws.publishing.SetSectionStatus("#targetUsersStatus", "ready");
                } else if (anyTargetingSelected || this.viewModelInstance.AnyDeviceSelected()) {
                    athoc.iws.publishing.targetUsers.isReadyToPublish = false;
                    athoc.iws.publishing.targetUsers.isInErrorState = true;
                    athoc.iws.publishing.SetSectionStatus("#targetUsersStatus", "notReady");
                } else {
                    athoc.iws.publishing.targetUsers.isReadyToPublish = false;
                    athoc.iws.publishing.targetUsers.isInErrorState = false;
                    athoc.iws.publishing.SetSectionStatus("#targetUsersStatus", "open");

                }


                if (athoc.iws.publishing.contextName == "Scenario")
                    athoc.iws.scenario.schedule.isActiveRecurrenceEnabled();


            },

            resetTargetingInfo: function () {
                $("#treeview").hide();
                this.resetReach();
            },

            getTargetedUsersCount: function (cnt) {
                athoc.iws.publishing.targetUsers.viewModelInstance.numTargetedUsers(cnt);
            },

            getBlockedUsersCount: function (cnt) {
                athoc.iws.publishing.targetUsers.viewModelInstance.numBlockedUsers(cnt);
            },

            pieChartClick: function (e) {
                if (e.category == "covered") {
                    if (athoc.iws.publishing.source == 'p' || athoc.iws.publishing.source == 'h' || athoc.iws.publishing.source == 'a' || athoc.iws.publishing.source == 'readonly') {
                        athoc.iws.alert.reviewandpublish.GetReachableUserList(1);
                    }
                    else
                        athoc.iws.publishing.targetUsers.viewModelInstance.GetReachableUserList(1);
                }
                else if (e.category == "notcovered") {
                    if (athoc.iws.publishing.source == 'p' || athoc.iws.publishing.source == 'h' || athoc.iws.publishing.source == 'a' || athoc.iws.publishing.source == 'readonly') {
                        athoc.iws.alert.reviewandpublish.GetUnReachableUserList(0);
                    }
                    else
                        athoc.iws.publishing.targetUsers.viewModelInstance.GetUnReachableUserList(0);
                }
            },

            //bind contact data to target section in readonly
            applyReadonlySettingsOnTargetUsers: function (data, targetDiv) {

                var targetVM = function (context) {
                    var self = this;
                    //Contact info
                    self.targetedBlockerUsersList = data.TargetUsers.TargetedBlockedUsers;
                    self.ContactinfoTotalCoveredNumber = ko.observable(0);
                    self.ContactinfoTotalCoveredPercentage = ko.observable(0);
                    self.ContactinfoNotCoveredNumber = ko.observable(0);
                    self.ContactinfoNotCoveredPercentage = ko.observable(0);
                    self.TotalUsers = ko.observable(0);
                    if (athoc.iws.publishing.iut != undefined && athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList() == null && data.TargetUsers.TargetedBlockedUsers != null)
                        athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList(data.TargetUsers.TargetedBlockedUsers);
                    self.Devices = ko.observableArray();
                    self.TargetingTree = ko.observableArray();
                    self.groupedDevices = ko.observableArray();
                    self.numberQueryCriteria = ko.observable(0);
                    self.numberAreaCriteria = ko.observable(0);

                    self.numberOfDevices = ko.observable(0);
                    self.DeliveryOrderList = ko.observableArray();
                    self.numGroupsTargeted = ko.observable(0);
                    self.numGroupsBlocked = ko.observable(0);
                    self.numTargetedUsers = ko.observable(0);
                    self.numBlockedUsers = ko.observable(0);
                    self.targetedUsers = ko.observableArray();
                    self.getTargetedUsers = function () {
                        var targetdata = [];
                        _.each(data.TargetUsers.TargetedBlockedUsers, function (item, index) {
                            if (!item.IsBlocked) {
                                targetdata.push(item.UserId);
                            }

                        });
                        return targetdata;
                    };
                    self.targetedBlockedUsers = ko.observableArray();
                    self.getBlockedUsers = function () {
                        var targetdata = [];
                        _.each(data.TargetUsers.TargetedBlockedUsers, function (item, index) {
                            if (item.IsBlocked) {
                                targetdata.push(item.UserId);
                            }

                        });
                        return targetdata;
                    };

                    self.showQuerySummary = function () {
                        if (self.numberQueryCriteria() > 0) {
                            $("#dialogTargetingSummary").find("#spanTitle").text(athoc.iws.publishing.iut.resources.TargetUsers_Advanced_Query);
                            var summaryDiv = $("#dialogTargetingSummary").find("#targetingSummaryContentDiv");
                            summaryDiv.html("");
                            var selections = $("#queryBuilderDiv").athocQueryBuilder("getCurrentSelections");

                            var seletionTextArray = selections.display;

                            _.each(seletionTextArray, function (item, index) {
                                if (index != 0) {
                                    summaryDiv.append("<div class=\"summary-row summary-operator-row\">" + athoc.iws.publishing.resources.Publishing_TargetUsers_Advanced_Query_Summary_And + "</div>");
                                }

                                summaryDiv.append(context.summaryDivTrmplate.format(item, selections.displayNoStyle[index]));
                                index += 1;
                            });
                            $("#dialogTargetingSummary").modal("show");
                        }
                    };

                    //on number of map area clicked
                    self.showAreaSummary = function () {
                        if (self.numberAreaCriteria() > 0) {
                            //Show map with objects in model window
                            $("#dialogGeoTargetingSummary").modal("show");
                        }
                    };

                    //show selected devices list
                    self.showDeviceSummary = function () {
                        if (self.numberOfDevices() > 0) {
                            //show device summary
                            $("#personalDeviceSummaryDiv").html('');
                            ko.cleanNode($("#dialogPersonalDevicesSummary").get(0));
                            var groupedDevices = athoc.iws.publishing.targetUsers.SelectedGroupedDevices();
                            ko.applyBindings(groupedDevices, $("#dialogPersonalDevicesSummary").get(0));
                            $("#dialogPersonalDevicesSummary").modal("show");
                        }
                    };

                    self.showTargetedGroupSummary = function () {
                        $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP").html('');
                        if (self.numGroupsTargeted() > 0) {
                            var result = "";
                            athoc.iws.alert.reviewandpublish.showModalonModal("#targetedUsersSummaryRP");
                            $("#targetedUsersSummaryRP").find("#spanTitleDetails").text(athoc.iws.publishing.iut.resources.ByGroups);
                            var summaryDiv = $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP");
                            var template = kendo.template($("#groupsummary-template-RP").html());
                            result = template(athoc.iws.alert.reviewandpublish.TargetedGroupsFormatted());
                            summaryDiv.html(result);
                        }
                    };

                    self.showBlockedGroupSummary = function () {
                        $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP").html('');
                        if (self.numGroupsBlocked() > 0) {
                            athoc.iws.alert.reviewandpublish.showModalonModal("#targetedUsersSummaryRP");
                            $("#targetedUsersSummaryRP").find("#spanTitleDetails").text(athoc.iws.publishing.iut.resources.ByGroupsBlocked);
                            var summaryDiv = $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP");
                            var template = kendo.template($("#groupsummary-template-RP").html());
                            var result = "";
                            result = template(athoc.iws.alert.reviewandpublish.BlockedGroupsFormatted());
                            summaryDiv.html(result);
                        }
                    };

                    self.showTargetedUsersSummary = function () {
                        $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP").html('');
                        if (self.numTargetedUsers() > 0) {
                            athoc.iws.alert.reviewandpublish.showModalonModal("#targetedUsersSummaryRP");
                            athoc.iws.alert.reviewandpublish.showTargetedUsersSummary();
                            $("#targetedUsersSummaryRP").find("#spanTitleDetails").text(athoc.iws.publishing.iut.resources.ByUsers + '(' + self.numTargetedUsers() + ')');
                        }
                    };

                    self.showBlockedUsersSummary = function () {
                        $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP").html('');
                        if (self.numBlockedUsers() > 0) {
                            athoc.iws.alert.reviewandpublish.showModalonModal("#targetedUsersSummaryRP");
                            athoc.iws.alert.reviewandpublish.showBlockedUsersSummary();
                            $("#targetedUsersSummaryRP").find("#spanTitleDetails").text(athoc.iws.publishing.iut.resources.ByUsersBlocked + '(' + self.numBlockedUsers() + ')');
                        }
                    };

                    self.SelectedGroupedDevices = function () {
                        var selectedDevices = [];
                        var lastGroup = '';
                        _.each(this.ReadonlyviewModel.Devices(), function (item, index) {
                            if (item.Selected()) {
                                var groupChanged = false;
                                if (lastGroup != item.GroupName()) {
                                    groupChanged = true;
                                    lastGroup = item.GroupName();
                                }
                                var device = { DeviceId: item.DeviceId, DeviceName: item.DeviceName, GroupChange: groupChanged, GroupId: item.GroupId, GroupName: item.GroupName, HideInReadOnlyView: item.HideInReadOnlyView, Reach: item.Reach, Selected: true };
                                selectedDevices.push(device);
                            }
                        });

                        return { Devices: selectedDevices };
                    };

                    self.GetReachableUserList = function () {
                        athoc.iws.alert.reviewandpublish.LaunchContactInfoUserList(1);
                    };

                    self.GetUnReachableUserList = function () {
                        athoc.iws.alert.reviewandpublish.LaunchContactInfoUserList(0);
                    };
                    self.DisplayUserList = function () {
                        $("#readOnlyUserListTitle").html(athoc.iws.publishing.iut.resources.readOnlyUserCountTitle);
                        athoc.iws.alert.reviewandpublish.ShowUsersList(athoc.iws.alert.reviewandpublish.SessionId, -1, "", athoc.iws.publishing.targetUsers.ReadonlyviewModel.TotalUsers());
                    };
                };

                this.ReadonlyviewModel = new targetVM(this);

                //do knockout binding using viewModel
                ko.cleanNode(targetDiv.find(".contact-info-section").get(0));
                ko.cleanNode(targetDiv.find(".contact-info-section").get(1));
                ko.cleanNode(targetDiv.find("#targetSummaryDetail").get(0));
                ko.cleanNode(targetDiv.find("#PersonalDeviceListDetail").get(0));

                ko.applyBindings(athoc.iws.publishing.targetUsers.ReadonlyviewModel, targetDiv.find(".contact-info-section").get(0));
                ko.applyBindings(athoc.iws.publishing.targetUsers.ReadonlyviewModel, targetDiv.find(".contact-info-section").get(1));
                ko.applyBindings(athoc.iws.publishing.targetUsers.ReadonlyviewModel, targetDiv.find("#targetSummaryDetail").get(0));


                ko.applyBindings(athoc.iws.publishing.targetUsers.ReadonlyviewModel, targetDiv.find("#targetSummaryDetail").get(0));
                //Skip ajax call : in Edit Mode
                //if (athoc.iws.publishing.source == "a" && (athoc.iws.scenario.settings != undefined && athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Targeting != undefined && !athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Targeting.Readonly)) {
                if (athoc.iws.publishing.source == "a" && (athoc.iws.publishing.source != "readonly")) {
                    ko.mapping.fromJS(data.TargetUsers.Devices, {}, this.ReadonlyviewModel.Devices);
                    ko.mapping.fromJS(data.TargetUsers.TargetingTree, {}, this.ReadonlyviewModel.TargetingTree);
                    athoc.iws.publishing.view.showContactInfo();
                }
                else {

                    //making a single ajax call to get targeting tree and device data
                    var ajaxSuccessWrapper = function (context) {
                        return function (data) {
                            ko.mapping.fromJS(data.Devices, {}, context.ReadonlyviewModel.Devices);
                            ko.mapping.fromJS(data.TargetingTree, {}, context.ReadonlyviewModel.TargetingTree);
                        }
                    }(this);

                    var targetingInfoSuccess = function (data) {
                        ajaxSuccessWrapper(data);

                        athoc.iws.publishing.view.showContactInfo();


                    };

                    var targetingInfoError = function (e) {
                        kendo.ui.progress($("#publishing-user-detail"), false);
                        var errorCallBack = function (returnedErrorObject) {
                            $('#listMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        };
                    }
                    //need to check context
                    var paramcontext = 'Scenario';

                    if (athoc.iws.alert.action == 'rbt') {
                        param1 = athoc.iws.alert.rbt.AlertId;
                        param2 = athoc.iws.alert.rbt.EntityFilterId;
                        paramcontext = 'Alert';

                    } else if (athoc.iws.alert.action == "v") {
                        param1 = athoc.iws.alert.id;
                        paramcontext = 'Alert';
                        param2 = "";
                    } else {
                        param1 = data.EntityId == 0 ? data.ParentId : data.EntityId;
                        param2 = "";
                    }

                    var ajaxOptions = {
                        cache: false,
                        url: athoc.iws.publishing.urls.GetDeviceListUrl,
                        data: { context: paramcontext, id: param1, recipientType: param2 },
                        type: "POST"
                    };

                    var ajaxOptions = $.extend({}, AjaxUtility(targetingInfoError, targetingInfoSuccess).ajaxPostOptions, ajaxOptions);
                    $.ajax(ajaxOptions);

                    //End
                }
            },

            refreshPersonalDevices: function (data) {
                /* var deletedItems = [];
                 _.each(athoc.iws.publishing.targetUsers.viewModelInstance.Devices(), function (item, index) {
                     var flag = _.find(data, function (device) {
                         return (device.DeviceId == item.DeviceId());
                     });
                     if (flag == null) {
                         deletedItems.push(item.DeviceId());
                     }
                 });
                 _.each(data, function (obj, index) {
                     var newDevice = _.find(athoc.iws.publishing.targetUsers.viewModelInstance.Devices(), function (device) {
                         return device.DeviceId() == obj.DeviceId;
                     });
                     if (newDevice == null) {
                         //obj.GroupChange = true;
                         obj.Selected = false;
                         athoc.iws.publishing.targetUsers.viewModelInstance.Devices.push(ko.mapping.fromJS(obj));
                     }
                 });
                 if (deletedItems.length > 0) {
                     athoc.iws.publishing.targetUsers.viewModelInstance.Devices.remove(function (i) {
                         return deletedItems.indexOf(i.DeviceId()) > -1;
                     });
                 }*/
                var selectedList = $.grep(athoc.iws.publishing.targetUsers.viewModelInstance.Devices(), function (d) {
                    return d.Selected() == true;
                });
                _.each(data, function (obj, index) {
                    var selected = _.find(selectedList, function (s) {
                        return s.DeviceId() == obj.DeviceId;
                    });
                    if (selected == null)
                        obj.Selected = false;
                });
                ko.mapping.fromJS(data, {}, athoc.iws.publishing.targetUsers.viewModelInstance.Devices);
                //athoc.iws.publishing.targetUsers.updateContactInfo();
                //athoc.iws.publishing.targetUsers.viewModelInstance.Devices().sort(function (l, r) { return [l.GroupId() < r.GroupId()] ? -1 : 1 })
                //ko.cleanNode($("#devicesListDiv").get(0));
                //ko.applyBindings(this.viewModelInstance, $("#devicesListDiv").get(0));


            },

            isThisDeviceGroupTargeted: function (groupid) {

                var checkedDevices = ko.mapping.toJS(this.viewModelInstance.Devices()).filter(function (el) {
                    return el.Selected;
                });

                for (i = 0; i < checkedDevices.length; i++) {
                    if (checkedDevices[i].GroupId == groupid) {
                        return true;
                    }
                }
                return false;
            }
        };
    }();
}


///#source 1 1 /Scripts/Publishing/athoc.iws.publishing.targetGroup.js
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};

athoc.iws.publishing.TargetGroup = function (treeContainer) {
    var self = this;
    this.ViewModel = kendo.observable(
                  {
                      Devices: [],
                      SelectedNodes: [],
                      TargetedUserCountForLiveEndedAlert: "0",

                      TargetedGroups: function () {
                          var nodes = this.get("SelectedNodes");
                          return $.grep(nodes, function (i) {
                              return !i.IsBlocked;
                          });
                      },

                      TargetedGroupsFormatted: function () {
                          var tg = this.TargetedGroups();
                          return self._formatGroups(tg);
                      },

                      BlockedGroups: function () {
                          var nodes = this.get("SelectedNodes");
                          return $.grep(nodes, function (i) {
                              return i.IsBlocked;
                          });
                      },

                      BlockedGroupsFormatted: function () {
                          var bg = this.BlockedGroups();
                          return self._formatGroups(bg);
                      },

                      ExpandAll: function (e) {
                          self.TreeView.expand(".k-item");
                      },
                      CollapseAll: function (e) {
                          self.TreeView.collapse(".k-item:not(li:first)");
                      },
                      Visible: function () {
                          return this.get("Devices").length > 0 && this.get("SelectedNodes").length > 0;
                      },
                  });

    this._formatGroups = function (groups) {
        var x = {};
        var nodes = groups;// this.get("SelectedNodes");
        for (var i = 0; i < nodes.length; ++i) {
            var n = nodes[i];
            switch (n.Type) {
                case 0:
                case 1:
                case 3:
                    if (x[n.Name] == undefined)
                        x[n.Name] = [];
                    x[n.Name].push({ Type: n.Type, Item: athoc.iws.publishing.resources.Publishing_TargetUsers_All_Selected });
                    break;
                case 2:
                    if (x[n.ParentName] == undefined)
                        x[n.ParentName] = [];
                    x[n.ParentName].push({ Type: n.Type, Item: n.Name });
                    break;
                case 4:
                case 5:
                    if (x[n.RootName] == undefined) {
                        x[n.RootName] = [];
                    }
                    if (n.Type == 5) {
                        x[n.RootName].push({ Type: n.Type, Item: n.Name });
                    } else {
                        if (n.Lineage) {
                            x[n.RootName].push({ Type: n.Type, Item: kendo.format("{0}{1}/", n.Lineage, n.Name) });
                        } else {
                            x[n.RootName].push({ Type: n.Type, Item: kendo.format(n.Type == 4 ? "{0}" : "/{0}/", n.Name) }); //loading on review/publish
                        }
                    }
                    break;
            }
        }
        var ret = Object.keys(x).map(function (k) {
            return { Group: k, Items: x[k], Type: x[k][0] != undefined ? x[k][0].Type : -1 }
        });
        return ret;

    };

    this.LoadViewModel = function (data) {
        if (arguments.length > 0) {
            self.ViewModel.set("SelectedNodes", data.TargetingNodes);
            self.ViewModel.set("Devices", data.Devices);
        }
        kendo.bind($(".kTGBound"), self.ViewModel);
    };

    this.toggleBlock = function (a) {
        var item = $(a).closest("li");
        //if (item.hasClass("k-state-disabled"))
        //    return;

        var node = self.TreeView.dataItem(item);
        var val = !node.get("IsBlocked");
        self._toggleBlockStateForNode(item, val);
        if (node.hasChildren)
            self._toggleBlockChildren(node.Children, val);

        //need to wait till all block state is reset and then fire check
        var checkbox = item.find(":checkbox").first();
        checkbox.trigger("click");
    };

    this.showCheckBox = function (node) {
        var ret = true;
        if (node.Type == 3 && !node.HasChildren)//if a root has no chilren, don't show checkbox
        {
            node.Name += node.SubType == 0 ? athoc.iws.publishing.resources.Publishing_TargetUsers_EmptyHierarchy : athoc.iws.publishing.resources.Publishing_TargetUsers_EmptyFolder;
            node.Type = 6; //go ahead and hide the node, treat it as a dummy node. IWS-11867
            ret = false;
        }
        else if (!node.IsTargetable) {
            ret = false;
        }
        return ret;
    };

    this._selectionChanged = function (node) {
        var targetedNodes = [];
        var blockedNodes = [];
        //due to target and block being mixed in one tree and to accomadate all scenarios, 
        //we need to traverse the tree seperately for getting targeted and blocked nodes
        self._getTargetedNodes(node, self.TreeView.dataSource.view(), targetedNodes);
        self._getBlockedNodes(node, self.TreeView.dataSource.view(), blockedNodes);
        var selectedNodes = targetedNodes.concat(blockedNodes);
        self.ViewModel.set("SelectedNodes", selectedNodes);
    };

    //check to see if the given node is a child of the parent node
    this._checkIfChildExists = function (node, nodes) {
        var childFound;
        var found = [];
        for (var i = 0; i < nodes.length; i++) {
            if (nodes[i].Name == node.Name && nodes[i].Id == node.Id)
                found.push(nodes[i]);
            else if (nodes[i].hasChildren) {
                childFound = self._checkIfChildExists(node, nodes[i].Children);
                if (childFound.length > 0) {
                    //var treeNode = self.TreeView.findByUid(nodes[i].uid);
                    //var chk = treeNode.find('input:checkbox').first();
                    //var img = treeNode.find('div.targeting-sprite').first();
                    //var item = nodes[i];
                    //item.set("CommandText", "Block");
                    //item.set("IsBlocked", false);
                    //item.set("checked", false);
                    //img.hide();
                    //chk.show();
                    found = found.concat(childFound);
                }
            }
        }
        return found;
    };

    this._hideFakeNodes = function (nodes) {
        if (nodes) {
            for (var i = 0; i < nodes.length; i++) {
                var treeNode = self.TreeView.findByUid(nodes[i].uid);
                if (nodes[i].Type == 6) {
                    treeNode.hide();
                }
                if (nodes[i].hasChildren) {
                    self._hideFakeNodes(nodes[i].Children);
                }
            }
        }
    };

    //_getTargetedNodes gets the targeted nodes as well as setting the correct state of all nodes
    this._getTargetedNodes = function (node, nodes, targetedNodes, parent, root) {

        for (var i = 0; i < nodes.length; i++) {
            var treeNode = self.TreeView.findByUid(nodes[i].uid);
            var chk = treeNode.find('input:checkbox').first();
            var img = treeNode.find('div.targeting-sprite').first();
            //the below logic is to retain the block/unblock state for the parent nodes
            var found = node && nodes[i].hasChildren ? self._checkIfChildExists(node, nodes[i].Children) : [];
            if (nodes[i].IsBlocked && found.length > 0) {
                var item = nodes[i];
                item.set("CommandText", athoc.iws.scenario.resources.Publishing_TargetUsers_Block ? athoc.iws.scenario.resources.Publishing_TargetUsers_Block : athoc.iws.publishing.resources.Publishing_TargetUsers_Block);
                item.set("IsBlocked", false);//unblocking child should unblock parent
                //item.set("checked", false);
                img.hide();
                chk.show();
            }

            //Mohit: if any child is unchecked, also uncheck the fake node.
            if (node && parent && nodes[i].Type == 6 && !node.checked)
                nodes[i].set("checked", false);

            var r = !root && nodes[i].Type == 3 ? nodes[i] : root;
            //this is where we save the targeted nodes and we need to check to see if it's not blocked
            //otherwise, we need to keep traversing the tree to set the correct blocked state for each node
            if (nodes[i].checked && !nodes[i].IsBlocked && nodes[i].Type != 6 && nodes[i].IsTargetable) {
                var parentId = 0;
                var parentName = "";
                try {
                    parentId = parent.Id;
                    parentName = parent.Name;
                } catch (e) {

                }

                //creating a flat list here for save()
                targetedNodes.push({
                    Id: nodes[i].Id,
                    Name: nodes[i].Name,
                    Type: nodes[i].Type,
                    Lineage: nodes[i].Lineage,
                    ParentId: parentId,
                    ParentName: parentName,
                    SubType: nodes[i].SubType,
                    RootId: root != null ? root.Id : 0,
                    RootName: root != null ? root.Name : "",
                    DlType: nodes[i].DlType,
                    //IsBlocked: nodes[i].IsBlocked
                    //todo: add IsBlocked
                });
            }
            else if (nodes[i].hasChildren) {
                self._getTargetedNodes(node, nodes[i].children.view(), targetedNodes, nodes[i], r);
            }
        }
    };

    //_getBlockedNodes gets the blocked nodes only
    this._getBlockedNodes = function (node, nodes, blockedNodes, parent, root) {

        for (var i = 0; i < nodes.length; i++) {
            var r = !root && nodes[i].Type == 3 ? nodes[i] : root;
            //this is where we save the targeted nodes and we need to check to see if it's not blocked
            //otherwise, we need to keep traversing the tree to set the correct blocked state for each node
            if (nodes[i].IsBlocked && nodes[i].Type != 6) {
                var parentId = 0;
                var parentName = "";
                try {
                    parentId = parent.Id;
                    parentName = parent.Name;
                } catch (e) {

                }

                //creating a flat list here for save()
                blockedNodes.push({
                    Id: nodes[i].Id,
                    Name: nodes[i].Name,
                    Type: nodes[i].Type,
                    Lineage: nodes[i].Lineage,
                    ParentId: parentId,
                    ParentName: parentName,
                    SubType: nodes[i].SubType,
                    RootId: root != null ? root.Id : 0,
                    RootName: root != null ? root.Name : "",
                    DlType: nodes[i].DlType,
                    IsBlocked: nodes[i].IsBlocked
                    //todo: add IsBlocked
                });
            }
            else if (nodes[i].hasChildren) {
                self._getBlockedNodes(node, nodes[i].children.view(), blockedNodes, nodes[i], r);
            }
        }
    };

    this._initializeTreeView = function () {
        self.TreeView.updateIndeterminate();
        var lastElement = self.TreeView.wrapper.find("li:last");
        var node = self.TreeView.dataItem(lastElement);
        if (node != null && node.Type == 3)
            self.TreeView.expand(lastElement);
        self._setSort(self.TreeView.dataSource.view());
    };

    this._setSort = function (items) {
        for (var i = 0; i < items.length; i++) {

            // Only perform sorting on Distribution List Node
            if (items[i].SubType && items[i].SubType == 1) {
                if (items[i].hasChildren) {
                    items[i].children.sort({ field: "Name", dir: "asc", field: "SortOrder", dir: "asc" });
                    self._setSort(items[i].children.view());
                }
            }
        }
    };

    this._toggleBlockChildren = function (children, blocked) {
        for (var i = 0; i < children.length; i++) {
            var item = self.TreeView.findByUid(children[i].uid);
            //item.toggleClass('k-state-disabled', blocked);
            self._toggleBlockStateForNode(item, blocked);
            if (children[i].hasChildren) {
                self._toggleBlockChildren(children[i].Children, blocked);
            }
        }
    };

    this._toggleBlockStateForNode = function (treeNode, val) {
        var item = self.TreeView.dataItem(treeNode);
        item.set("CommandText", val ? (athoc.iws.scenario.resources.Publishing_TargetUsers_Unblock ? athoc.iws.scenario.resources.Publishing_TargetUsers_Unblock : athoc.iws.publishing.resources.Publishing_TargetUsers_Unblock) : (athoc.iws.scenario.resources.Publishing_TargetUsers_Block ? athoc.iws.scenario.resources.Publishing_TargetUsers_Block : athoc.iws.publishing.resources.Publishing_TargetUsers_Block));
        item.set("IsBlocked", val);
        item.set("checked", !val); //Mohit: block will check/uncheck nodes
        //todo: store blocked nodes...
        var chk = treeNode.find('input:checkbox').first();
        var img = treeNode.find('div.targeting-sprite').first();
        if (val) {
            chk.hide();
            img.show();
        } else {
            img.hide();
            chk.show();
        }
    };

    this.showBlockBtn = function (node) {
        var ret = athoc.iws.publishing.settings.IsGroupBlockSupported && node.Type > 0;
        if (ret && node.Type == 3 && !node.HasChildren) {
            ret = false;
        }
        return ret;
    };


    this.TreeView = $(treeContainer).kendoTreeView({
        autoBind: false,
        loadOnDemand: false,//setting this to false will cause the tree to load all child initially
        checkboxes: {
            checkChildren: true,
            template: "# if(athoc.iws.publishing.targetUsers.targetGroupInstance.showCheckBox(item)){# <div class='targeting-sprite blocked' #=item.IsBlocked ? '' : 'style=\"display:none\"' #></div><input type='checkbox' #=item.checked ? 'checked' : '' # #=item.IsBlocked ? 'style=\"display:none\"' : '' # /> #} #"
        },
        template: "<div class=\"tree-block\"># if(athoc.iws.publishing.targetUsers.targetGroupInstance.showBlockBtn(item)){# <a onclick=\"athoc.iws.publishing.targetUsers.targetGroupInstance.toggleBlock(this)\">#=item.IsBlocked? (athoc.iws.scenario.resources.Publishing_TargetUsers_Unblock ? athoc.iws.scenario.resources.Publishing_TargetUsers_Unblock : athoc.iws.publishing.resources.Publishing_TargetUsers_Unblock)  : (athoc.iws.scenario.resources.Publishing_TargetUsers_Block ? athoc.iws.scenario.resources.Publishing_TargetUsers_Block : athoc.iws.publishing.resources.Publishing_TargetUsers_Block)#</a>#} #</div><div class=\"ellipsis\" style=\"width:400px\" title=\"#=$.customizedHtmlEncoding(item.Name)# \">#=$.htmlEncode(item.Name)#</div>",
        check: function (e) {//check fires once when all the checked states have changed
            var item = self.TreeView.dataItem(e.node);
            self._selectionChanged(item);
        },
        dataBound: function (e) {
            if (!e.node) {//dataBound is fired for each node but not the last one
                self._initializeTreeView();
                self._hideFakeNodes(this.dataSource.view());
                self._selectionChanged();//walk through the tree and get the selection in case user press 'Save' right away w/o changing the tree selection
            }
        },
        dataTextField: "CommandText",
    }).data("kendoTreeView");

    this.RefreshTreeView = function (data) {
        self.TreeView.setDataSource(new kendo.data.HierarchicalDataSource({
            data: data.TargetingTree,
            schema: {
                model: {
                    children: "Children",//the child nodes property in the data model
                    fields: {
                        checked: {
                            from: "Selected", type: "boolean"
                        },
                    },
                },
            }
        }));
    };


}

///#source 1 1 /Scripts/Publishing/athoc.iws.publishing.targetOrg.js
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};

if (athoc.iws.publishing) {
    athoc.iws.publishing.targetOrg = function () {
        return {
            Parameters: {},
            //AtHoc.IWS.Web.Controllers.OrganizationController.OrganizatioSearchParameters
            //OrgSearchParameters:{},
            //DataSource: null,
            //ViewModel: {},
            //Message: "",
            OrgViewModel: null,
            OrgInfoHolder: null,
            //is section ready to publish
            isReadyToPublish: false,
            getOrgConnectedStatus: true,
            showOrganizations: true,
            load: function (orgSelection) {
                var self = this;

                if (!self.OrgViewModel) {
                    return;
                }                

                self.OrgViewModel.Reset();

                kendo.ui.progress($(self.Parameters.orgSectionDivs.targetOrgSection), true);

                ko.mapping.fromJS(orgSelection.TargetAllOrganizations, {}, self.OrgViewModel.TargetAllOrg);
                ko.mapping.fromJS(orgSelection.TargetOrganizationsByArea, {}, self.OrgViewModel.TargetOrgByArea);

                //making a single ajax call to get targeting tree and device data
                var orgInfoSuccess = function (data) {

                    if (self.getOrgConnectedStatus) {
                        self.showOrganizations = data.ShowOrgs; //reset this flag only first time
                    }

                    if (self.showOrganizations) {
                        if (data.Organizations.length == 0) {
                            $(self.Parameters.orgSectionDivs.noOrganizationDiv).show();
                            $(self.Parameters.orgSectionDivs.organizationTableDiv).hide();
                        } else {
                            $(self.Parameters.orgSectionDivs.noOrganizationDiv).hide();
                            $(self.Parameters.orgSectionDivs.organizationTableDiv).show();

                            var ids = $.map(orgSelection.TargetedOrganizations.filter(function (to) { return !to.GeoSelected; }), function (org) {
                                return org.UserId;
                            });
                            _.each(data.Organizations, function (org) {
                                if ($.inArray(org.UserId, ids) != -1) {
                                    org.Selected = true;
                                }
                            });
                            var userIds = $.map(orgSelection.TargetedOrganizations.filter(function (to) { return to.GeoSelected; }), function (org) {
                                return org.UserId;
                            });
                            var toByArea = $.map(data.Organizations.filter(function (o) { return $.inArray(o.UserId, userIds) != -1; }), function (org) {
                                return org.Id;
                            });
                            self.OrgViewModel.SelectedOrgsByArea(toByArea);
                            self.OrgViewModel.OrgCountByArea(toByArea.length);
                        }
                    } else {
                        $(self.Parameters.orgSectionDivs.noOrganizationDiv).show();
                        $(self.Parameters.orgSectionDivs.organizationTableDiv).hide();
                    }

                    ko.mapping.fromJS(data.Organizations, {}, self.OrgViewModel.Organizations);
                    if (self.OrgViewModel.TargetAllOrg()) {
                        if ((athoc.iws.scenario.settings.viewModel.scenariosettings.Organization && athoc.iws.scenario.settings.viewModel.scenariosettings.Organization.TargetByNameEnabled) || (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings && athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Organization.TargetByNameEnabled))
                            self.OrgViewModel.SelectAll();
                        else
                            self.OrgViewModel.ClearAll();
                        self.OrgViewModel.TargetOrgByArea(true);
                    }

                    self.OrgViewModel.UpdateTargetedOrgStatus();

                    self.getOrgConnectedStatus = false;

                    kendo.ui.progress($(self.Parameters.orgSectionDivs.targetOrgSection), false);

                };

                var ajaxOptions = {
                    cache: false,
                    url: athoc.iws.publishing.urls.GetTargetableOrganizationsUrl,
                    data: { getVPSConnectedStatus: self.getOrgConnectedStatus },
                    type: "POST"
                };


                var ajaxOptions = $.extend({}, AjaxUtility(null, orgInfoSuccess).ajaxPostOptions, ajaxOptions);
                $.ajax(ajaxOptions);

            },
            init: function (parameters) {
                var context = this;
                this.Parameters = parameters;


                var orgVM = function (context) {
                    var self = this;

                    self.TargetAllOrg = ko.observable(false);

                    self.TargetAllOrg.subscribe(function (newValue) {
                        var overlay = '<div class="overlay-light-grey" style="display:block"></div>';
                        athoc.iws.publishing.scenario.isChanged = true;
                        if (newValue) {
                            if ((athoc.iws.scenario.settings.viewModel.scenariosettings.Organization && athoc.iws.scenario.settings.viewModel.scenariosettings.Organization.TargetByNameEnabled)
                                ||(athoc.iws.scenario.settings.ReadonlyViewModel.applysettings && athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Organization.TargetByNameEnabled))
                                self.SelectAll();
                            self.TargetOrgByArea(self.TargetOrgByAreaVisible());
                                $("#organizationList").scrollTop(0);
                                $("#organizationList").css("overflowY", "hidden");
                                $("#organizationList").append(overlay);
                                $("#divTargetOrgByArea").append(overlay);
                                $("#targetOrgByName").find("button").prop("disabled", true);
                            
                           

                        } else {
                            self.ClearAll();
                            $("#organizationList").css("overflowY", "auto");
                            $("#organizationList").find(".overlay-light-grey").remove();
                            $("#divTargetOrgByArea").find(".overlay-light-grey").remove();
                            $("#targetOrgByName").find("button").prop("disabled", false);
                        }
                    });

                    self.TargetOrgByArea = ko.observable(false);

                    self.TargetOrgByArea.subscribe(function (newValue) {
                        
                        athoc.iws.publishing.geo.viewModel.isOrganizationsTargeted(newValue);
                        self.UpdateTargetedOrgStatus();

                    });

                    self.TargetOrgByAreaVisible = function () {
                        return athoc.iws.publishing.geo.viewModel.isGeoSelected();
                    };

                    self.Organizations = ko.observableArray();

                    self.OrgSelected = ko.pureComputed(function () {

                        var ret = self.Organizations().filter(function (el) {
                            return el.Selected();
                        });

                        return ko.toJS(ret).map(function (o) { return o.Id; });
                    });

                    self.TargetedOrgCountByArea = ko.pureComputed(function () {
                        return self.TargetOrgByArea() && athoc.iws.publishing.settings.IsTargetByAreaSupported ? self.OrgCountByArea() : 0;
                    });

                    self.SelectedOrgsByArea = ko.observableArray([]);
                    self.SelectedOrgsByArea.subscribe(function (newValue) {
                        self.UpdateTargetedOrgStatus();
                    });

                    self.OrgCountByArea = ko.observable(0);
                    self.OrgCountByArea.subscribe(function (newValue) {
                        self.UpdateTargetedOrgStatus();
                    });

                    self.OrgCountTotal = ko.pureComputed(function () {
                        var ret = self.OrgSelected();
                        if (self.TargetOrgByArea() && athoc.iws.publishing.settings.IsTargetByAreaSupported) {
                            ret = ret.concat(self.SelectedOrgsByArea());
                            var existingIDs = [];
                            ret = $.grep(ret, function (id) {
                                if ($.inArray(id, existingIDs) !== -1) {
                                    return false;
                                }
                                else {
                                    existingIDs.push(id);
                                    return true;
                                }
                            });
                        }
                        return ret.length;
                    });

                    self.OrgChanged = function () {

                        // athoc.iws.publishing.scenario.isChanged = true;                       
                        self.UpdateTargetedOrgStatus();

                        return true;
                    };

                    self.SelectAll = function () {
                        _.each(self.Organizations(), function (org) {
                            org.Selected(true);
                        });
                        self.OrgChanged();
                    };

                    self.ClearAll = function () {
                        _.each(self.Organizations(), function (org) {
                            org.Selected(false);
                        });
                        self.OrgChanged();
                    };


                    self.ShowDetails = function (selectedOrg) {

                        require(['widget/OrgInfo'], function (OrgInfo) {
                            if (context.OrgInfoHolder == null) {
                                $('<div id="orgInfoHolder"></div>').appendTo("body");
                                context.OrgInfoHolder = new OrgInfo("orgInfoHolder");
                                context.OrgInfoHolder.startup();
                            }

                            context.OrgInfoHolder.update({ orgId: selectedOrg.Id(), orgName: selectedOrg.Name() });
                        });


                        return true;
                    }


                    self.UpdateTargetedOrgStatus = function () {
                        if (self.OrgSelected().length > 0 || (self.TargetOrgByArea() && self.SelectedOrgsByArea() && self.SelectedOrgsByArea().length > 0)) {
                            athoc.iws.publishing.SetSectionStatus(parameters.orgSectionDivs.targetOrgStatus, "ready");
                            athoc.iws.publishing.targetOrg.isReadyToPublish = true;
                        } else {
                            athoc.iws.publishing.SetSectionStatus(parameters.orgSectionDivs.targetOrgStatus, "open");
                            athoc.iws.publishing.targetOrg.isReadyToPublish = false;
                        }
                        athoc.iws.publishing.detail.checkStatusChange();
                    }

                    self.Reset = function () {
                        self.Organizations([]);
                    };

                };

                this.OrgViewModel = new orgVM(this);

                ko.cleanNode($(this.Parameters.orgSectionDivs.targetOrgSection).get(0));
                ko.applyBindings(this.OrgViewModel, $(this.Parameters.orgSectionDivs.targetOrgSection).get(0));

              
               

            },
            getModel: function () {
                //convert viewmodel to the format that will be set to server side with all of other sections. 
                var checkedOrganizations = new Array();
                if (this.showOrganizations) {
                    checkedOrganizations = ko.mapping.toJS(this.OrgViewModel.Organizations).filter(function (el) {
                        return el.Selected;
                    });

                    if (this.OrgViewModel.TargetOrgByArea()) {
                        var allOrgs = ko.mapping.toJS(this.OrgViewModel.Organizations);
                        _.each(this.OrgViewModel.SelectedOrgsByArea(), function (itemId) {
                            var foundOrg = _.find(allOrgs, function (orgItem) {
                                return orgItem.Id === itemId;
                            });
                            if (foundOrg) {
                                //foundOrg.Selected(true);
                                foundOrg.GeoSelected = true;
                                checkedOrganizations.push(ko.mapping.toJS(foundOrg));
                            }

                            //var orgAlreadyExist = _.find(checkedOrganizations, function(item) {
                            //    return itemId === item.Id;
                            //});
                            //if (!orgAlreadyExist) {
                            //    var foundOrg = _.find(allOrgs, function(orgItem) {
                            //        return orgItem.Id() === itemId;
                            //    });
                            //    if (foundOrg) {
                            //        foundOrg.Selected(true);
                            //        foundOrg.GeoSelected(true);
                            //        checkedOrganizations.push(ko.mapping.toJS(foundOrg));
                            //    }
                            //}
                        });
                    }
                }
                return {
                    TargetedOrganizations: checkedOrganizations,
                    TargetAllOrganizations: this.OrgViewModel.TargetAllOrg(),
                    TargetOrganizationsByArea: this.OrgViewModel.TargetOrgByArea()
                };
            },

            bindReadOnlyViewModel: function (data, targetDiv) {
                var vm = kendo.observable(
                  {
                      Organizations: [],
                      CombinedOrgs: function () {
                          var ret = this.get("Organizations");
                          var existingIDs = [];
                          ret = $.grep(ret, function (o) {
                              if ($.inArray(o.UserId, existingIDs) !== -1) {
                                  return false;
                              } else {
                                  existingIDs.push(o.UserId);
                                  return true;
                              }
                          });
                          return ret;
                      },
                      OrgCountText: function () {
                          var orgs = this.CombinedOrgs();
                          return kendo.format(athoc.iws.publishing.resources.Publishing_TargetOrg_TargetOrganizations, orgs.length);
                      },
                      Visible: function () {
                          return this.get("Organizations").length > 0;
                      }
                  });
                vm.set("Organizations", data);
                //targetDiv.find("#targetOrgDetail")
                kendo.bind(targetDiv.find(".kOrgBound"), vm);
            },
        };
    }();
}

///#source 1 1 /Scripts/Publishing/athoc.iws.publishing.view.js
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};

if (athoc.iws.publishing) {
    athoc.iws.publishing.view = function () {
        return {
            objData: null,
            publishingModel: null,
            messages: [],
            readOnlyMap: null,
            context: "Alert",
            id: 0,
            summaryDivTrmplate: "<div class=\"summary-row ellipsis\" title='{1}'>{0}</div>",
            PresetDeviceGroupOptions: [], //used to store device option when targeting is read only 
            //view model! 
            viewModel: {
                audioFileName: ko.observable(),
                data: ko.observable(),
                alertTitle: ko.observable(''),
                bodyWithLineBreak: ko.observable(''),
                isGeoSelected: ko.observable(false),
                personalDeviceList: { Devices: ko.observableArray() },

                TargetedBlockerUsersList: [],
                TargetedGroupCount: ko.observable(0),
                BlockedGroupCount: ko.observable(0),
                TargetedUserCount: ko.observable(0),
                BlockedUserCount: ko.observable(0),
                QueryCriteriaCount: ko.observable(0),
                TargetedAreaCount: ko.observable(0),
                ContactinfoTotalCoveredNumber: ko.observable(new String("0")),
                ContactinfoTotalCoveredPercentage: ko.observable(new String("0")),
                ContactinfoNotCoveredNumber: ko.observable(new String("0")),
                ContactinfoNotCoveredPercentage: ko.observable(new String("0")),
                TotalUsers: ko.observable(new String("0")),
                loadTargetUsers: ko.observable(new String("true")),
                targetedNodes: [],
                showQuerySummary: function () {
                    if (athoc.iws.publishing.view.viewModel.QueryCriteriaCount() > 0) {
                        $("#dialogTargetSummaryPublish").find("#spanTitleDetailsPublish").text(athoc.iws.publishing.iut.resources.TargetUsers_Advanced_Query);
                        var summaryDiv = $("#dialogTargetSummaryPublish").find("#targetingSummaryDetailPublish");
                        summaryDiv.html("");


                        var selections = ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetedCriteria.display);
                        var selectionsNoDisplay = ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetedCriteria.displayNoStyle);

                        _.each(selections, function (item, index) {
                            if (index != 0) {
                                summaryDiv.append("<div class=\"summary-row summary-operator-row\">" + athoc.iws.publishing.resources.Publishing_TargetUsers_Advanced_Query_Summary_And + "</div>");
                            }

                            summaryDiv.append(athoc.iws.publishing.view.summaryDivTrmplate.format(item, selectionsNoDisplay[index]));

                            //summaryDiv.append(athoc.iws.publishing.view.summaryDivTrmplate.format("<span class='bold'>" + item.entity.name + "</span>" + " " + item.operandName + " " + selValue, item.entity.name));
                            index += 1;
                        });
                        athoc.iws.alert.reviewandpublish.showModalonModal("#dialogTargetSummaryPublish");
                    }
                },

                //on number of map area clicked
                showAreaSummary: function () {
                    if (athoc.iws.publishing.view.viewModel.TargetedAreaCount() > 0) {
                        //Show map with objects in model window
                        athoc.iws.alert.reviewandpublish.showModalonModal("#dialogGeoPublish");
                    }
                },

                //show selected devices list
                showDeviceSummary: function () {
                    if (athoc.iws.publishing.view.viewModel.numberOfDevices() > 0) {
                        //show device summary
                        $("#personalDeviceSummaryDiv").html('');
                        ko.cleanNode($("#dialogPersonalDevicesSummary").get(0));
                        var groupedDevices = athoc.iws.publishing.targetUsers.SelectedGroupedDevices();
                        ko.applyBindings(groupedDevices, $("#dialogPersonalDevicesSummary").get(0));
                        $("#dialogPersonalDevicesSummary").modal("show");
                    }
                },

                showTargetedGroupSummary: function () {
                    if (athoc.iws.publishing.view.viewModel.TargetedGroupCount() > 0) {
                        $("#dialogTargetSummaryPublish").find("#spanTitleDetailsPublish").text(athoc.iws.publishing.iut.resources.ByGroups);
                        var summaryDiv = $("#dialogTargetSummaryPublish").find("#targetingSummaryDetailPublish");
                        var template = kendo.template($("#groupsummary-template-RP").html());
                        var result = template(athoc.iws.alert.reviewandpublish.TargetedGroupsFormatted());
                        summaryDiv.html(result);
                        athoc.iws.alert.reviewandpublish.showModalonModal("#dialogTargetSummaryPublish");
                    }
                },
                showBlockedGroupSummary: function () {
                    if (athoc.iws.publishing.view.viewModel.BlockedGroupCount() > 0) {
                        $("#dialogTargetSummaryPublish").find("#spanTitleDetailsPublish").text(athoc.iws.publishing.iut.resources.ByGroupsBlocked);
                        var summaryDiv = $("#dialogTargetSummaryPublish").find("#targetingSummaryDetailPublish");
                        var template = kendo.template($("#groupsummary-template-RP").html());
                        var result = template(athoc.iws.alert.reviewandpublish.BlockedGroupsFormatted());
                        summaryDiv.html(result);
                        athoc.iws.alert.reviewandpublish.showModalonModal("#dialogTargetSummaryPublish");
                    }
                },

                showTargetedUsersSummary: function () {
                    $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP").html('');
                    if (athoc.iws.publishing.view.viewModel.TargetedUserCount() > 0) {
                        athoc.iws.alert.reviewandpublish.showModalonModal("#targetedUsersSummaryRP");
                        athoc.iws.alert.reviewandpublish.showTargetedUsersSummary();
                        $("#targetedUsersSummaryRP").find("#spanTitleDetails").text(athoc.iws.publishing.iut.resources.ByUsers + '(' + this.TargetedUserCount() + ')');
                    }
                },

                showBlockedUsersSummary: function () {
                    $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP").html('');
                    if (athoc.iws.publishing.view.viewModel.BlockedUserCount() > 0) {
                        athoc.iws.alert.reviewandpublish.showModalonModal("#targetedUsersSummaryRP");
                        athoc.iws.alert.reviewandpublish.showBlockedUsersSummary();
                        $("#targetedUsersSummaryRP").find("#spanTitleDetails").text(athoc.iws.publishing.iut.resources.ByUsersBlocked + '(' + this.BlockedUserCount() + ')');
                    }
                },
                GetReachableUserList: function () {
                    if (athoc.iws.publishing.view.viewModel.ContactinfoTotalCoveredNumber() > 0)
                        athoc.iws.alert.reviewandpublish.LaunchContactInfoUserList(1);
                },

                GetUnReachableUserList: function () {
                    if (athoc.iws.publishing.view.viewModel.ContactinfoNotCoveredNumber() > 0)
                        athoc.iws.alert.reviewandpublish.LaunchContactInfoUserList(0);
                },
                DisplayUserList: function () {
                    if (athoc.iws.publishing.view.viewModel.TotalUsers() > 0) {
                        $("#readOnlyUserListTitle").html(athoc.iws.publishing.iut.resources.readOnlyUserCountTitle);
                        athoc.iws.alert.reviewandpublish.ShowUsersList(athoc.iws.alert.reviewandpublish.SessionId, -1, "", athoc.iws.publishing.view.viewModel.TotalUsers());
                    }
                },
            },

            //source of request
            source: '',

            showNotReadyError: true,

            PieChartObject: null,

            //Called from publisher/home page the id is scenarioId which to be published
            PublishScenario: function (id, source) {
                athoc.iws.publishing.view.showReviewAndPublish(true, id, "ScenarioPublisher");

                var loadUrl = athoc.iws.publishing.urls.CreateAlertFromScenarioUrl + "?id=" + id + "&loadTargetingTree=true";

                athoc.iws.publishing.view.loadFromUrl(loadUrl, true, "Scenario", id);

                if (source != undefined) {
                    if (source == "home") {
                        athoc.iws.publishing.source = "h";
                    } else {
                        athoc.iws.publishing.source = "p";
                    }
                }
            },

            //Called from alert list page the id is alertId which to be published
            PublishAlert: function (id) {
                athoc.iws.publishing.source = "p";
                athoc.iws.alert.action = "v";
                athoc.iws.alert.id = id;
                athoc.iws.publishing.view.showReviewAndPublish(true, id, "AlertManager");

                var loadUrl = athoc.iws.publishing.urls.GetAlertUrl + "?id=" + id + "&loadTargetingTree=true";

                athoc.iws.publishing.view.loadFromUrl(loadUrl, true, "Alert", id);
            },

            //Called from alert detail page the data is model for alert
            ReviewAndPublish: function (data) {
                if (data.Content.LocationGeo != null && data.Content.LocationGeo.length == 0)
                    data.Content.LocationGeo = athoc.iws.publishing.geo.getModel();
                athoc.iws.publishing.source = "a";
                athoc.iws.publishing.view.showReviewAndPublish(false, 0, "AlertDetail");

                data = athoc.iws.publishing.view.cleanEmptyMassDeviceCustomText(data);

                athoc.iws.publishing.view.bind(data, $("#dialogReviewAndPublish"));

                athoc.iws.publishing.view.replacePlaceholder();
            },

            //helper metod to cleanup mass device empty custom text
            cleanEmptyMassDeviceCustomText: function (data) {
                try {
                    if (data && data.MassDevices && data.MassDevices.length > 0) {
                        _.each(data.MassDevices, function (device) {
                            if (device && device.CustomText) {
                                device.CustomText = null;
                            }
                        });
                    }
                } catch (e) { }

                return data;
            },

            bindReadonlyViews: function (data, targetDiv) {
                $("#btnPublishAlert").unbind("click");
                $("#btnPublishAlert").click(function () {
                    athoc.iws.publishing.view.publishAlert();
                });
                athoc.iws.publishing.content.applyReadonlySettingsOnContent(data, targetDiv);
                ko.cleanNode(targetDiv.find(".content-section").get(0));
                ko.applyBindings(athoc.iws.publishing.view.viewModel, targetDiv.find(".content-section").get(0));

                // source ='a' from Review and Publish button
                //source ='p' from publish button from new alert grid
                //source ='h' from publish button from home page
                if (athoc.iws.publishing.source == "a") {
                    if (athoc.iws.scenario != undefined && athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Targeting != undefined && athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Targeting.Readonly) // Target user section is set readonly 
                    {
                        athoc.iws.publishing.targetUsers.applyReadonlySettingsOnTargetUsers(athoc.iws.publishing.detail.viewModel, targetDiv);
                    } else {
                        athoc.iws.publishing.targetUsers.applyReadonlySettingsOnTargetUsers(data, targetDiv);
                    }
                }
                else
                    athoc.iws.publishing.targetUsers.applyReadonlySettingsOnTargetUsers(data, targetDiv);

            },

            applyVisibilitySettings: function (data, targetDiv) {
                // apply content settings such as dropbox , Location, response option  on Scenario and Alert
                //athoc.iws.scenario.settings.applyContentSettings(athoc.iws.scenario.settings.ReadonlyViewModel.applysettings);
                var content = data;
                if (content.LocationEnabled)

                    $(targetDiv).find("#dvContentLocation").css("display", "");
                else
                    $(targetDiv).find("#dvContentLocation").css("display", "none");


                if (content.ResponseOptionEnabled) {
                    $(targetDiv).find("#dvContentResponseOpt").css("display", "");
                    $(targetDiv).find("#dvContentAddResponseOpt").css("display", "");
                }
                else {
                    $(targetDiv).find("#dvContentResponseOpt").css("display", "none");
                    $(targetDiv).find("#dvContentAddResponseOpt").css("display", "none");
                }

                if (content.DropboxEnabled)
                    $(targetDiv).find("#dvContentDropBox").css("display", "");
                else
                    $(targetDiv).find("#dvContentDropBox").css("display", "none");
            },

            publishedAlertId: 0,

            OnCloseAfterPublish: null,

            //Origin of publisher this can be ScenarioPublisher, AlertManager or AlertDetail
            //ScenarioPublisher is origin from home page or scenario publisher
            //AlertManager is origin from Alert list screen
            //AlertDetail is origin from edit alert screen
            Origin: '',

            //parentId will be alertId or scenarioId based on context
            ParentId: 0,

            showReviewAndPublish: function (showEdit, id, origin) {
                athoc.iws.publishing.view.messages = [];
                athoc.iws.publishing.view.Origin = origin;
                athoc.iws.publishing.view.ParentId = id;


                if ($('#dialogReviewAndPublish').length > 0) {
                    $('#btnPublishAlert').prop("disabled", false);

                    var resizeFunction = function () {
                        //athoc.iws.utilities.resizeModalBasedOnScreen($('#dialogReviewAndPublish'), 600, 770, 20, 170);
                        if ($(window).height() > 1024)
                            athoc.iws.utilities.resizeModalBasedOnScreen($('#dialogReviewAndPublish'), 600, 770, 40, 170);
                        else
                            athoc.iws.utilities.resizeModalBasedOnScreen($('#dialogReviewAndPublish'), 560, 710, 15, 145);
                    }



                    var updateLayout = _.debounce(resizeFunction, 500); // Maximum run of once per 500 milliseconds
                    window.addEventListener("resize", updateLayout, false);

                    athoc.iws.publishing.view.publishedAlertId = 0;

                    athoc.iws.publishing.view.messages = [];
                    $('#dialogReviewAndPublish').find("#messagePanel").messagesPanel('reset');

                    $("#dialogReviewAndPublish").find(".pre-publish").show();
                    $("#dialogReviewAndPublish").find(".post-publish").hide();
                    $("#dialogReviewAndPublish").find("#btn_print_alert").unbind("click");
                    $("#dialogReviewAndPublish").find("#btn_print_alert").click(function () { athoc.iws.publishing.view.downloadPdfFile(athoc.iws.publishing.urls.CreatePrintAlertUrl); });
                    if (showEdit && origin == "ScenarioPublisher") {
                        $("#btnDialogReviewEdit").show();
                        $("#btnDialogReviewEdit").unbind("click");
                        $("#btnDialogReviewEdit").click(function () { athoc.iws.publishing.view.editAndPublishScenario(id); });
                    } else if (showEdit && origin == "AlertManager") {
                        $("#btnDialogReviewEdit").show();
                        $("#btnDialogReviewEdit").unbind("click");
                        $("#btnDialogReviewEdit").click(function () { athoc.iws.publishing.view.editAlert(id); });
                    }
                    else {
                        $("#btnDialogReviewEdit").hide();
                    }

                    $("#dialogReviewAndPublish").find("#btnPublishClose").unbind("click");
                    $("#dialogReviewAndPublish").find("#btnPublishClose").click(function () {
                        if (athoc.iws.publishing.view.publishedAlertId != 0 && athoc.iws.publishing.view.OnCloseAfterPublish != null) {
                            athoc.iws.publishing.view.OnCloseAfterPublish(athoc.iws.publishing.view.publishedAlertId);
                        } else {
                            $('#dialogReviewAndPublish').modal('hide');
                        }
                        // added to reset the source
                        athoc.iws.publishing.source = "";
                    });

                    $("#dialogReviewAndPublish").find("#btnDependencyListCancel").click(function () {
                        // added to reset the source
                        athoc.iws.publishing.source = "";
                    });


                    $("#dialogReviewAndPublish").find(".publishing-detail").show();

                    $('#dialogReviewAndPublish').modal('show');
                    //athoc.iws.publishing.view.resizeModalBasedOnScreen();                    
                    if ($(window).height() > 1024)
                        athoc.iws.utilities.resizeModalBasedOnScreen($('#dialogReviewAndPublish'), 600, 770, 20, 190);
                    else
                        athoc.iws.utilities.resizeModalBasedOnScreen($('#dialogReviewAndPublish'), 560, 710, 15, 165);

                }
            },

            editAlert: function (id) {
                $('#dialogReviewAndPublish').modal('hide');

                $(".alert-nav").hide();
                $(".edit-alert").show();
                navigateToPage('alertDetail', function () { });

                athoc.iws.alert.detail.editAlert(id == 0 ? athoc.iws.publishing.view.ParentId : id);

                var breadcrumbsModel = athoc.iws.alert.breadcrumbModel;
                breadcrumbsModel.SelectedPage('alertDetail');
                $.titleCrumb("pageBreadcrumbs");
                $(document).scrollTop(0);
            },

            editAndPublishScenario: function (id) {
                $('#dialogReviewAndPublish').modal('hide');
                window.location = "/athoc-iws/alertmanager?nav=c&source=" + athoc.iws.publishing.source + "&id=" + id;
            },

            viewReport: function (id) {
                window.location = "/athoc-iws/AlertManager/ReportView?id=" + id;
            },

            loadFromUrl: function (loadUrl, showNotReadyError, context, id) {
                athoc.iws.publishing.view.context = context;
                athoc.iws.publishing.view.id = id;
                $("#dialogReviewAndPublish").find(".publishing-detail").hide();
                $('#btnPublishAlert').prop("disabled", true);

                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $(window), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();

                var dlSuccess = function (data) {

                    athoc.iws.publishing.view.publishingModel = data.Data;
                    $.AjaxLoader.hideLoader();
                    $("#dialogReviewAndPublish").find(".publishing-detail").show();

                    $("#dialogReviewAndPublish .blockMsg").css("top", "350px");
                    $("#dialogReviewAndPublish .blockMsg").css("left", "400px");

                    if (data.Success) {
                        $('#btnPublishAlert').prop("disabled", false);
                        athoc.iws.publishing.view.bind(data.Data, $("#dialogReviewAndPublish"));

                        //publishing scenario with placehoder
                        athoc.iws.publishing.view.replacePlaceholder();
                        $('#dialogReviewAndPublish').find('.modal-body').scrollTop(0);
                    } else {
                        athoc.iws.publishing.view.messages.push({ Type: '4', Value: data.Messages });
                        $('#dialogReviewAndPublish').find("#messagePanel").messagesPanel({ messages: athoc.iws.publishing.view.messages }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        $('#dialogReviewAndPublish').find('.modal-body').scrollTop(0);
                    }
                    var targDevices = _.where(data.Data.TargetUsers.Devices, { HideInReadOnlyView: false });

                    // var targetUsersSelection = (data.Data.TargetUsers.TargetUsersByArea == true) || (data.Data.TargetUsers.TargetedBlockedUsers.length > 0) || (data.Data.TargetUsers.TargetedCriteria != null) || (data.Data.TargetUsers.TargetingNodes.length > 0) || (data.Data.rbt != null);
                    var targetUsersSelection = (data.Data.TargetUsers.TargetUsersByArea == true) || (data.Data.TargetUsers.TargetedBlockedUsers.length > 0) || (data.Data.TargetUsers.TargetedCriteria != null) || (data.Data.TargetUsers.TargetingNodes.length > 0) || (data.Data.rbt != null);


                    if (showNotReadyError && (!targetUsersSelection && targDevices.length != 0))
                        //commented to work in demo
                        //||
                        //(data.Data.TargetUsers.TargetingNodes.length == 0 && targDevices.length != 0)
                    {
                        $('#dialogReviewAndPublish').find("#messagePanel").messagesPanel({ messages: [{ Type: '4', Value: athoc.iws.publishing.resources.Publishing_Alert_NotReady_Error }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        $("#dialogReviewAndPublish").find(".pre-publish").hide();
                        $("#dialogReviewAndPublish").find(".post-publish").show();
                        $("#dialogReviewAndPublish").find("#btnPublishViewReport").hide();
                        if ($("#btn_detail_standby").length == 0)
                            $("#dialogReviewAndPublish").find("#btnDialogReviewEdit").show();
                        $("#btnDialogReviewEdit").unbind("click");
                        $("#btnDialogReviewEdit").click(function () {
                            athoc.iws.publishing.view.editAlert(data.Data.EntityId);
                        });
                    }
                    athoc.iws.publishing.view.showDeviceWarningText(targDevices);



                    //show error is alert is not ready to publish
                    // here validattion code is written to  validate the Publish  ready status but this method is failing incase of target user condition so we  moved it below this method, the new function is called in the update contact info
                    athoc.iws.publishing.view.showNotReadyError = showNotReadyError;
                };

                var dlAjaxOption =
                {
                    type: "POST",
                    url: loadUrl,
                };

                var ajaxOptions = $.extend({}, AjaxUtility(null, dlSuccess).ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);

            },

            validatePublishStatus: function (targetUsersCnt) {
                var showErrorMsg = false;
                //check for Targetting Users supported or not
                var isTargetUsersSupported = (athoc.iws.publishing.settings.IsAdvancedQuerySuuported || athoc.iws.publishing.settings.IsIndividualUserTargetingSupported || athoc.iws.publishing.settings.IsTargetByAreaSupported);
                var data = athoc.iws.publishing.view.publishingModel;
                //get device count w/o org
                var targDevices = _.where(data.TargetUsers.Devices, { HideInReadOnlyView: false });

                if (isTargetUsersSupported && athoc.iws.publishing.view.showNotReadyError &&
                            (
                                (targetUsersCnt == 0 && targDevices.length == 0 && data.TargetOrg.TargetedOrganizations.length == 0)
                                 || (targetUsersCnt != 0 && targDevices.length == 0)
                                 || (targetUsersCnt != 0 && targDevices.length == 0)
                                 || (targetUsersCnt == 0 && targDevices.length != 0)
                            )
                    )
                    showErrorMsg = true;

                if (isTargetUsersSupported == false && athoc.iws.publishing.settings.IsMassDeviceTargetSupported && data.MassDevices.length == 0)
                    showErrorMsg = true;


                if (showErrorMsg) {
                    athoc.iws.publishing.view.messages.push({ Type: '4', Value: athoc.iws.publishing.resources.Publishing_Alert_NotReady_Error });
                    $('#dialogReviewAndPublish').find("#messagePanel").messagesPanel({ messages: athoc.iws.publishing.view.messages }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                    $("#dialogReviewAndPublish").find(".pre-publish").hide();
                    $("#dialogReviewAndPublish").find(".post-publish").show();
                    $("#dialogReviewAndPublish").find("#btnPublishViewReport").hide();
                    if ($("#btn_detail_standby").length == 0)
                        $("#dialogReviewAndPublish").find("#btnDialogReviewEdit").show();
                    $("#btnDialogReviewEdit").unbind("click");
                    $("#btnDialogReviewEdit").click(function () {
                        athoc.iws.publishing.view.editAlert(data.EntityId);
                    });
                }

            },

            showDeviceWarningText: function (data) {
                if (athoc.iws.publishing.view.messages.length > 0) {
                    athoc.iws.publishing.view.messages = $.grep(athoc.iws.publishing.view.messages, function (message) {
                        return message.Type !== '1';
                    });
                }

                var devicesWithWarningText = [];
                var devices = [];

                if (data && data.TargetUsers && data.TargetUsers.Devices) {
                    _.each(data.TargetUsers.Devices, function (device) {
                        var result = $.grep(devices, function (e) { return e.DeviceId == device.DeviceId; });
                        if (result.length == 0) {
                            devices.push(device);
                        }
                    });
                }

                if (data && data.MassDevices && data.MassDevices.length > 0) {
                    _.each(data.MassDevices, function (device) {
                        if (device.Selected) {
                            var result = $.grep(devices, function (e) { return e.DeviceId == device.DeviceId; });
                            if (result.length == 0) {
                                devices.push(device);
                            }
                        }
                    });
                }

                if (devices.length > 0) {
                    devicesWithWarningText = $.map($.grep(devices, function (d) {
                        return d.WarningText && d.WarningText.length > 0;
                    }), function (d) {
                        athoc.iws.publishing.view.messages.push({ Type: '1', Value: d.WarningText });
                        return { Type: '1', Value: d.WarningText };
                    });
                }

                if (devicesWithWarningText && devicesWithWarningText.length > 0)
                    $('#dialogReviewAndPublish').find("#messagePanel").messagesPanel({ messages: athoc.iws.publishing.view.messages }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
            },

            //bind R&P model with data
            bind: function (data, targetDiv) {

                athoc.iws.publishing.view.replacedPlaceholder = false;

                //bind publish event
                $("#btnPublishAlert").unbind("click");
                $("#btnPublishAlert").click(function () { athoc.iws.publishing.view.publishAlert(); });

                var _self = athoc.iws.publishing.view;

                //add contact info to the data
                data.ContactinfoTotalCoveredNumber = "0";
                data.ContactinfoTotalCoveredPercentage = "0";
                data.ContactinfoNotCoveredNumber = "0";
                data.ContactinfoNotCoveredPercentage = "0";
                data.TotalUsers = 0;

                //moved to content section


                //content
                _self.bindContentSection(data, targetDiv);

                //geo location
                _self.bindGeoLocation(data.Content.LocationGeo, targetDiv);

                //target user section
                // Commented: Redundant call.
                _self.bindTargetUsers(data, targetDiv);

                //orgnaizations
                _self.bindOrganizationSection(data, targetDiv);

                //mass devices
                _self.bindMassDevices(data, targetDiv);


                //scheduling
                _self.bindSchedulingSection(data, targetDiv);


                if ((athoc.iws.publishing.detail.viewModel.AlertStatus == "Ended" || athoc.iws.publishing.detail.viewModel.AlertStatus == "Live") && !athoc.iws.publishing.view.replacedPlaceholder) {
                    //Live ended showing custom text/recorded message
                    athoc.iws.publishing.view.publishingModel = data;
                    _self.replacePlaceholder();
                    athoc.iws.publishing.view.replacedPlaceholder = true;
                }

                _self.showDeviceWarningText(data);

                _self.updateMoreLess(targetDiv);

                athoc.iws.publishing.detail.bindBucketExpandCollapse(targetDiv);

                //TODO: why would you need following code?
                //if (athoc.iws.alert.source == "rbt") {
                //    $("#dialogReviewAndPublish").find("#publishing-mass-view").hide();
                //    $("#dialogReviewAndPublish").find("#targetOrgDetail").hide();
                //}

            },

            //bind content section
            bindContentSection: function (data, targetDiv) {
                //the below lines of code moved from bind
                var _self = athoc.iws.publishing.view;
                if (data.Content != undefined && data.Content.ResponseOptions != undefined && data.Content.ResponseOptions.length > 0) {
                    var reponseOptions = [];
                    for (var i = 0; i < data.Content.ResponseOptions.length; i++) {
                        if (data.Content.ResponseOptions[i].ResponseText.trim() !== '') {
                            reponseOptions.push(data.Content.ResponseOptions[i]);
                        }
                    }
                    data.Content.ResponseOptions = reponseOptions;
                }

                _self.viewModel.data = ko.mapping.fromJS(data);

                _self.viewModel.data.Content.language = ko.computed(function () {
                    var lang = _self.viewModel.data.Content.Local();
                    var arr = $.grep(_self.viewModel.data.Content.Languages(), function (l) {
                        return l.Code() == lang;
                    });
                    return arr[0] ? arr[0].Name() : "";
                });

                //adding linebreak for alert body
                if (data.Content && data.Content.Body) {
                    _self.viewModel.bodyWithLineBreak($.htmlEncode(data.Content.Body.trim()).replace(/(?:\r\n|\r|\n)/g, '<br />'));
                } else {
                    _self.viewModel.bodyWithLineBreak('');
                }

                //do knockout binding using viewModel
                //Binding
                ko.cleanNode(targetDiv.find(".content-section").get(0));

                targetDiv.find("#responseOptionDiv").empty();

                _self.viewModel.typeVisible = ko.observable(athoc.iws.publishing.contextName == "AccountEvent" ? data.ScenarioSettings.AccountabilityWorkflow.IsContentTypeVisible : true);
                _self.viewModel.severityVisible = ko.observable(athoc.iws.publishing.contextName == "AccountEvent" ? data.ScenarioSettings.AccountabilityWorkflow.IsContentSeverityVisible : true);
                ko.applyBindings(athoc.iws.publishing.view.viewModel, targetDiv.find(".content-section").get(0));
            },

            //bind geo-location with readonly map view
            //added targetDiv as parameter
            bindGeoLocation: function (location, targetDiv) {
                if (!location || location == null || location == '') {
                    athoc.iws.publishing.view.viewModel.isGeoSelected(false);
                    return;
                }


                /* IWS-20491 - Creating map instance using leaflet  and adding geo coordinates  */
                var geoJson = JSON.parse(location);

                /*24187 - hide the empty map when coordinates are empty*/
                if (!geoJson || !geoJson.features || geoJson.features.length === 0) {
                    athoc.iws.publishing.view.viewModel.isGeoSelected(false);
                    return;
                }

                athoc.iws.publishing.view.geoJson = geoJson;
                athoc.iws.publishing.view.viewModel.isGeoSelected(true);

                /* IWS-20388 - loading resources keys*/
                var minimapresources = null;
                if (athoc.iws.publishing && athoc.iws.publishing.mapResources) {
                    minimapresources = athoc.iws.publishing.mapResources;
                }
                else if (athoc.iws.home && athoc.iws.home.mapResources) {
                    minimapresources = athoc.iws.home.mapResources;
                }
                require(["widget/Map"], function (WidgetMap) {
                    //athoc.iws.publishing.view.readOnlyMap = null;
                    var reviewMapHolder = targetDiv.find(".readOnlyMiniMapHolder");

                    /* commented below line to not make empty every time*/
                    //targetDiv.find(".readOnlyMiniMapHolder").html('');
                    if (targetDiv[0].id === "alert-content-detail") {
                        if (!athoc.iws.publishing.view.readOnlyMap) {
                            //map creating when content section expanded
                            if (!athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content || !athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.Collapsed) {
                                athoc.iws.publishing.view.viewModel.isGeoSelected(true);
                                athoc.iws.publishing.view.readOnlyMap = new WidgetMap(reviewMapHolder, {
                                    i18n: minimapresources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture
                                });
                            }
                        }

                        $('#dialogGeoTargetingSummary').on('shown.bs.modal', function () {
                            if (!athoc.iws.publishing.view.summaryMap) {
                                athoc.iws.publishing.view.summaryMap = new WidgetMap("dialogGeoTargetingSummaryContent", {
                                    i18n: minimapresources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture
                                });
                            }
                            athoc.iws.publishing.view.bindGeoAlertMiniMap(athoc.iws.publishing.view.summaryMap, geoJson);
                        });

                        //20388 binding map in modal window from "ByLocation count" in readonly time
                        $('#dialogGeoPublish').on('shown.bs.modal', function () {
                            if (!athoc.iws.publishing.view.summaryMapReadOnly) {
                                athoc.iws.publishing.view.summaryMapReadOnly = new WidgetMap("dialogGeoPublishContent", {
                                    i18n: minimapresources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture
                                });
                            }
                            athoc.iws.publishing.view.bindGeoAlertMiniMap(athoc.iws.publishing.view.summaryMapReadOnly, geoJson);
                        });

                    } else if (targetDiv[0].id === "dialogReviewAndPublish" || targetDiv[0].id === "dialogReviewAndStart") {
                        if (!athoc.iws.publishing.view.readOnlyMapInRP) {
                            var id = "#" + targetDiv[0].id;
                            $(id).show();
                            athoc.iws.publishing.view.viewModel.isGeoSelected(true);
                            athoc.iws.publishing.view.readOnlyMapInRP = new WidgetMap(reviewMapHolder, {
                                i18n: minimapresources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture
                            });
                        }
                        else {
                            athoc.iws.publishing.view.readOnlyMapInRP.removeGeoJson();
                        }
                        /*the second popup modal in review and publish page*/
                        $('#dialogGeoPublish').on('shown.bs.modal', function () {
                            if (!athoc.iws.publishing.view.summaryMapReadOnly) {
                                athoc.iws.publishing.view.summaryMapReadOnly = new WidgetMap("dialogGeoPublishContent", {
                                    i18n: minimapresources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture
                                });
                            }
                            athoc.iws.publishing.view.bindGeoAlertMiniMap(athoc.iws.publishing.view.summaryMapReadOnly, geoJson);
                        });

                    } else {
                        if (!athoc.iws.publishing.view.readOnlyMapOtherCases) {
                            if (!athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content || !athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.Collapsed) {
                                if ($("#rptForm #target-contentarea #alertView").length == 0) {
                                    athoc.iws.publishing.view.viewModel.isGeoSelected(true);
                                    athoc.iws.publishing.view.readOnlyMapOtherCases = new WidgetMap(reviewMapHolder, {
                                        i18n: minimapresources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture
                                    });
                                }
                            }
                        }
                    }


                    if (!location || location == null || location == '') {
                        athoc.iws.publishing.view.viewModel.isGeoSelected(false);
                    }
                    else {
                        //Binding Targted area data when content section is readonly and Target Section is in edit. If Target Area is selected in scenario
                        //athoc.iws.publishing.source == undefined - Coming from edit alert.
                        /*IWS-22599 - In readonly case athoc.iws.publishing.source value is coming readonly so I modified "undefined" to "readonly" */
                        if ((athoc.iws.publishing.source == undefined || athoc.iws.publishing.source == "readonly") && athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetUsersByArea()) {
                            athoc.iws.publishing.geo.viewModel.isUsersTargeted(true);
                            athoc.iws.publishing.geo.viewModel.isGeoSelected(true);
                            athoc.iws.publishing.geo.geoJson = JSON.parse(location);
                            if ($("#targetContentArea").length > 0) {
                                ko.cleanNode($("#targetContentArea").get(0));
                                ko.applyBindings(athoc.iws.publishing.geo.viewModel, $("#targetContentArea").get(0));
                            }
                            athoc.iws.publishing.geo.updateTargetingSummary();
                        }
                        //end

                        if (geoJson && geoJson.features.length > 0) {
                            athoc.iws.publishing.view.viewModel.isGeoSelected(true);
                            if (athoc.iws.publishing.view.readOnlyMap) {
                                athoc.iws.publishing.view.bindGeoAlertMiniMap(athoc.iws.publishing.view.readOnlyMap, geoJson);
                            }
                            if (athoc.iws.publishing.view.readOnlyMapInRP) {
                                athoc.iws.publishing.view.bindGeoAlertMiniMap(athoc.iws.publishing.view.readOnlyMapInRP, geoJson);
                            }
                            if (athoc.iws.publishing.view.readOnlyMapOtherCases) {
                                athoc.iws.publishing.view.bindGeoAlertMiniMap(athoc.iws.publishing.view.readOnlyMapOtherCases, geoJson);
                            }
                        }
                    }
                });

                /*Commented esri mini map implementation

                require(["maps/MiniMap"], function (MiniMap) {
                    //athoc.iws.publishing.view.readOnlyMap = null;
                    var reviewMapHolder = targetDiv.find(".readOnlyMiniMapHolder")[0];
                    targetDiv.find(".readOnlyMiniMapHolder").html('');
                    if (targetDiv[0].id === "alert-content-detail") {
                        athoc.iws.publishing.view.readOnlyMap = new MiniMap({ width: 447, height: 200 }, reviewMapHolder);
                    } else if (targetDiv[0].id === "dialogReviewAndPublish") {
                        athoc.iws.publishing.view.readOnlyMapInRP = new MiniMap({ width: 447, height: 200 }, reviewMapHolder);
                    } else {
                        athoc.iws.publishing.view.readOnlyMapOtherCases = new MiniMap({ width: 447, height: 200 }, reviewMapHolder);
                    }


                    if (!location || location == null || location == '') {
                        athoc.iws.publishing.view.viewModel.isGeoSelected(false);
                    }
                    else {
                        //Binding Targted area data when content section is readonly and Target Section is in edit. If Target Area is selected in scenario
                        //athoc.iws.publishing.source == undefined - Coming from edit alert.
                        if (athoc.iws.publishing.source == undefined && athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetUsersByArea()) {
                            athoc.iws.publishing.geo.viewModel.isUsersTargeted(true);
                            athoc.iws.publishing.geo.viewModel.isGeoSelected(true);
                            athoc.iws.publishing.geo.geoJson = JSON.parse(location);
                            if ($("#targetContentArea").length > 0) {
                                ko.cleanNode($("#targetContentArea").get(0));
                                ko.applyBindings(athoc.iws.publishing.geo.viewModel, $("#targetContentArea").get(0));
                            }
                            athoc.iws.publishing.geo.updateTargetingSummary();
                        }
                        //end
                        var geoJson = JSON.parse(location);
                        if (geoJson && geoJson.features.length > 0) {
                            athoc.iws.publishing.view.viewModel.isGeoSelected(true);
                            if (athoc.iws.publishing.view.readOnlyMap) {
                                athoc.iws.publishing.view.readOnlyMap.restore(geoJson);
                            }
                            if (athoc.iws.publishing.view.readOnlyMapInRP) {
                                athoc.iws.publishing.view.readOnlyMapInRP.restore(geoJson);
                            }
                            if (athoc.iws.publishing.view.readOnlyMapOtherCases) {
                                athoc.iws.publishing.view.readOnlyMapOtherCases.restore(geoJson);
                            }
                        }
                    }

                    setTimeout(function () {
                        if (athoc.iws.publishing.view.readOnlyMap) {
                            athoc.iws.publishing.view.readOnlyMap.resize();
                            athoc.iws.publishing.view.readOnlyMap.zoomToFit();
                        }
                        if (athoc.iws.publishing.view.readOnlyMapInRP) {
                            athoc.iws.publishing.view.readOnlyMapInRP.resize();
                            athoc.iws.publishing.view.readOnlyMapInRP.zoomToFit();
                        }
                        if (athoc.iws.publishing.view.readOnlyMapOtherCases) {
                            athoc.iws.publishing.view.readOnlyMapOtherCases.resize();
                            athoc.iws.publishing.view.readOnlyMapOtherCases.zoomToFit();
                        }
                    }, 500);
                });
                */




            },

            /* IWS-20491 created common function to bind map*/
            bindGeoAlertMiniMap: function (miniMap, geoLocationsJson) {
                if (miniMap != null || miniMap) {
                    miniMap.removeGeoJson();
                    miniMap.addGeoJson(geoLocationsJson);
                    miniMap.centerAt([0, 0]);
                    miniMap.zoomToFit();
                }
            },

            //bind target users section
            bindTargetUsers: function (data, targetDiv) {
                // case:1
                /*
                athoc.iws.publishing.targetUsers.targetGroupInstance = new athoc.iws.publishing.TargetGroup('#treeview');
                athoc.iws.publishing.targetUsers.targetGroupInstance.RefreshTreeView(data);
                athoc.iws.publishing.targetUsers.targetGroupInstance.ViewModel.set("SelectedNodes", athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetingNodes());
                */
                //case :2 
                if (data.TargetingTree != null) {
                    athoc.iws.publishing.view.viewModel.targetedNodes = [];
                    athoc.iws.publishing.view.getTargetedNodes(data.TargetingTree, athoc.iws.publishing.view.viewModel.targetedNodes);
                    if (athoc.iws.publishing.view.viewModel.targetedNodes.length > 0)
                        athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetingNodes(athoc.iws.publishing.view.viewModel.targetedNodes);
                }

                athoc.iws.publishing.view.generateUserTargeting(data, targetDiv);

                if (!athoc.iws.publishing.view.replacedPlaceholder) {
                    athoc.iws.publishing.view.publishingModel = data;
                    athoc.iws.publishing.view.replacePlaceholder();
                    athoc.iws.publishing.view.replacedPlaceholder = true;
                }
            },
            targetingChanged: function (data) {
                //if advanced targeting is enabled get criteria
                // var advancedCriteriaSelected = (this.viewModel.QueryCriteriaCount) && (this.viewModel.QueryCriteriaCount > 0);

                var advancedCriteriaSelected = (this.viewModel.QueryCriteriaCount) && (this.viewModel.QueryCriteriaCount() > 0);

                //is target by area selected

                /* IWS-22599 - TargetedAreaCount is property doens't have length 
                 var targetByAreaSelected = (this.viewModel.TargetedAreaCount().length > 0);
                */
                var targetByAreaSelected = (this.viewModel.TargetedAreaCount() > 0);



                //is IUT selected
                var iutTargeted = (this.viewModel.TargetedBlockerUsersList.length > 0);

                //check if any of targeting is selected
                var anyTargetingSelected = (data.TargetUsers.TargetingNodes.length > 0
                    || iutTargeted
                    || advancedCriteriaSelected
                    || targetByAreaSelected);
                //|| (athoc.iws.publishing.rbt != null)
                var isAnyPersonalDeviceTargeted = (data.TargetUsers && data.TargetUsers.Devices && data.TargetUsers.Devices.length > 0);



                if (anyTargetingSelected && isAnyPersonalDeviceTargeted) {
                    athoc.iws.publishing.targetUsers.isReadyToPublish = true;
                    athoc.iws.publishing.targetUsers.isInErrorState = false;
                } else
                    if (anyTargetingSelected || isAnyPersonalDeviceTargeted) {
                        athoc.iws.publishing.targetUsers.isReadyToPublish = false;
                        athoc.iws.publishing.targetUsers.isInErrorState = true;
                    }
                    else {
                        athoc.iws.publishing.targetUsers.isReadyToPublish = false;
                        athoc.iws.publishing.targetUsers.isInErrorState = false;

                    }
            },

            //Method to check the ready state of selected mass devices.
            isMassDeviceReady: function (data) {

                //this is not required for PA
                if (!(athoc.iws.publishing.contextName == "Alert" || athoc.iws.publishing.contextName == "Scenario"))
                    return;

                if (athoc.iws.publishing.settings.IsMassDeviceTargetSupported && athoc.iws.publishing.massdevices.filterDataforReadOnly(data.MassDevices).length > 0) {
                    athoc.iws.publishing.massdevices.isReadyToPublish = true;
                    athoc.iws.publishing.massdevices.isInErrorState = false;
                    _.each(data.MassDevices, function (device) {
                        if ((!device.EndPoints || device.EndPoints.length == 0) && (device.Selected)) {
                            athoc.iws.publishing.massdevices.isReadyToPublish = false;
                            athoc.iws.publishing.massdevices.isInErrorState = true;
                        }
                        if (device.IsAreaRequired)
                            if (!athoc.iws.publishing.massdevices.isLocationPresent()) {
                                athoc.iws.publishing.massdevices.isReadyToPublish = false;
                                athoc.iws.publishing.massdevices.isInErrorState = true;
                            }
                    });
                }
            },

            getTargetedNodes: function (nodes, targetedNodes, parent, root) {

                for (var i = 0; i < nodes.length; i++) {

                    var r = !root && nodes[i].Type == 3 ? nodes[i] : root;
                    //this is where we save the targeted nodes and we need to check to see if it's not blocked
                    var targetedList = ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetingNodes);
                    var found = _.find(targetedList, function (existingItem) {
                        return (existingItem.Id == nodes[i].Id);
                    });

                    //otherwise, we need to keep traversing the tree to set the correct blocked state for each node
                    if (nodes[i].Type != 6 && found) {
                        var parentId = 0;
                        var parentName = "";
                        try {
                            parentId = parent.Id;
                            parentName = parent.Name;
                        } catch (e) {

                        }

                        //creating a flat list here for save()
                        targetedNodes.push({
                            Id: nodes[i].Id,
                            Name: nodes[i].Name,
                            Type: nodes[i].Type,
                            Lineage: nodes[i].Lineage,
                            ParentId: parentId,
                            ParentName: parentName,
                            SubType: nodes[i].SubType,
                            RootId: root != null ? root.Id : 0,
                            RootName: root != null ? root.Name : "",
                            DlType: nodes[i].DlType,
                            IsBlocked: found.IsBlocked,
                            Selected: found.Selected,

                            //todo: add IsBlocked
                        });
                    }
                    if (nodes[i].HasChildren) {
                        athoc.iws.publishing.view.getTargetedNodes(nodes[i].Children, targetedNodes, nodes[i], r);
                    }
                }
            },


            //Method to handle read node details in order to save the details
            treeToJson: function (nodes, ParentName) {

                return $.map(nodes, function (n, i) {

                    var selected = _.find(athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetingNodes(), function (selectedNode) {
                        return n.Id === selectedNode.Id();
                    });

                    if (selected != undefined) {
                        selected.Name(n.Name);
                        selected.RootName(ParentName);
                        athoc.iws.publishing.view.viewModel.selectedNodes.push(ko.mapping.toJS(selected));
                    }

                    if (n.HasChildren)
                        athoc.iws.publishing.view.treeToJson(n.Children, n.Name);
                });
            },
            //bind scheduling section
            bindSchedulingSection: function (data, targetDiv) {
                if (athoc.iws.publishing.settings.IsSchedulingSupported) {
                    if ((data.AlertStatus == undefined) || ((data.AlertStatus.toLowerCase() == "live" || data.AlertStatus.toLowerCase() == "ended" || data.AlertStatus.toLowerCase() == "scheduled") && (data.rbt == null || data.EntityId > 0))) {
                        targetDiv.find("#publishing-alert-view").show();
                    } else {
                        $("#publishing-alert-view").show();
                    }
                    athoc.iws.alert.schedule.bindReadOnlyView(data.AlertScheduleSettings, targetDiv);
                } else {
                    targetDiv.find("#publishing-alert-view").hide();
                }



            },

            //orgnaizations
            bindOrganizationSection: function (data, targetDiv) {
                if (data.TargetOrg.TargetedOrganizations.length > 0 && data.rbt == null) {
                    athoc.iws.publishing.targetOrg.bindReadOnlyViewModel(data.TargetOrg.TargetedOrganizations, targetDiv);
                } else {
                    targetDiv.find("#targetOrgDetail").hide();
                }
            },

            //bind mass devices based on feature and if mass devices selected
            bindMassDevices: function (data, targetDiv) {
                if (athoc.iws.publishing.settings.IsMassDeviceTargetSupported && athoc.iws.publishing.massdevices.filterDataforReadOnly(data.MassDevices).length > 0 && data.rbt == null) {
                    targetDiv.find("#publishing-mass-view").show();
                    athoc.iws.publishing.massdevices.bindReadOnlyView(data.MassDevices, targetDiv);
                } else {
                    athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList([]);
                    targetDiv.find("#publishing-mass-view").hide();
                }
            },

            //generate user targeting section from data (vm)
            generateUserTargeting: function (data, targetDiv) {
                var _self = athoc.iws.publishing.view;

                //initial targeting counts
                _self.viewModel.TargetedGroupCount(0);
                _self.viewModel.BlockedGroupCount(0);
                _self.viewModel.TargetedUserCount(0);
                _self.viewModel.BlockedUserCount(0);
                _self.viewModel.QueryCriteriaCount(0);
                _self.viewModel.TargetedAreaCount(0);

                var targetedAndBlockedGroups = [];
                var targetedUsers = [];
                var blockedUsers = [];
                var queryCriterias = {};
                var targetArea = "";
                var devices = [];


                //targeted blocked groups
                if (data.TargetUsers && data.TargetUsers.TargetingNodes) {
                    var targetedGroups = data.TargetUsers.TargetingNodes.filter(function (node) {
                        return !node.IsBlocked;
                    });
                    if (targetedGroups) {
                        _self.viewModel.TargetedGroupCount(targetedGroups.length);
                    }

                    var blockedGroups = data.TargetUsers.TargetingNodes.filter(function (node) {
                        return node.IsBlocked;
                    });
                    if (blockedGroups) {
                        _self.viewModel.BlockedGroupCount(blockedGroups.length);
                    }

                    targetedAndBlockedGroups = data.TargetUsers.TargetingNodes;
                }

                //targeted or blocked users
                if (data.TargetUsers && data.TargetUsers.TargetedBlockedUsers) {
                    targetedUsers = data.TargetUsers.TargetedBlockedUsers.filter(function (node) {
                        return !node.IsBlocked;
                    }).map(function (item) { return item.UserId; });
                    if (targetedUsers) {
                        _self.viewModel.TargetedUserCount(targetedUsers.length);
                    }

                    blockedUsers = data.TargetUsers.TargetedBlockedUsers.filter(function (node) {
                        return node.IsBlocked;
                    }).map(function (item) { return item.UserId; });
                    if (blockedUsers) {
                        _self.viewModel.BlockedUserCount(blockedUsers.length);
                    }

                    _self.viewModel.TargetedBlockerUsersList = data.TargetUsers.TargetedBlockedUsers;
                }

                //target query criteria
                if (data.TargetUsers && data.TargetUsers.TargetedCriteria && data.TargetUsers.TargetedCriteria.selections) {
                    queryCriterias = data.TargetUsers.TargetedCriteria;
                    _self.viewModel.QueryCriteriaCount(queryCriterias.selections.length);
                }

                //target by area
                if (data.TargetUsers && data.TargetUsers.TargetUsersByArea && data.Content.LocationGeo) {
                    targetArea = data.Content.LocationGeo;
                    var geoJson = JSON.parse(data.Content.LocationGeo);
                    if (geoJson && geoJson.features) {
                        _self.viewModel.TargetedAreaCount(geoJson.features.length);
                    }
                }

                if (data.rbt != null)
                    athoc.iws.publishing.rbt = data.rbt;
                var isAnyUserTargetingSelected = (_self.viewModel.TargetedGroupCount() > 0
                    || _self.viewModel.TargetedUserCount() > 0
                    || _self.viewModel.QueryCriteriaCount() > 0
                    || _self.viewModel.TargetedAreaCount() > 0
                    || _self.viewModel.BlockedGroupCount() > 0
                    || _self.viewModel.BlockedUserCount() > 0 || (athoc.iws.publishing.rbt != null));

                var isAnyPersonalDeviceTargeted = (data.TargetUsers && data.TargetUsers.Devices && data.TargetUsers.Devices.length > 0);
                _.each(data.TargetUsers.Devices, function (device) { devices.push(device.DeviceId); });

                if (isAnyUserTargetingSelected && isAnyPersonalDeviceTargeted) {
                    targetDiv.find("#publishing-user-detail").show();
                } else {
                    //Added the below condition to display section in readonly
                    if (athoc.iws.publishing.source == 'readonly')
                        targetDiv.find("#publishing-user-detail").show();
                    else {
                        targetDiv.find("#publishing-user-detail").hide();
                        return;
                    }
                }
                //athoc.iws.publishing.fillCount
                //for Review&Publish take the Fill count enabled flag from data.ScenarioSettings object; if this object not available then consider the flag from scenario settings object 
                athoc.iws.publishing.fillcount.readOnlyFillCountSummary(data, targetDiv, true, data.ScenarioSettings != undefined ? data.ScenarioSettings.Targeting.FillCount : athoc.iws.scenario.settings.isFillCountEnabled);

                //workaround for alert detail, for some reason ko binding does not work
                if (targetDiv.find("#targetedGroups").length > 0) {
                    targetDiv.find("#targetedGroups").html(_self.viewModel.TargetedGroupCount());
                }
                if (targetDiv.find("#blockedGroups").length > 0) {
                    targetDiv.find("#blockedGroups").html(_self.viewModel.BlockedGroupCount());
                }
                if (targetDiv.find("#targetedUsers").length > 0) {
                    targetDiv.find("#targetedUsers").html(_self.viewModel.TargetedUserCount());
                }
                if (targetDiv.find("#blockedUsers").length > 0) {
                    targetDiv.find("#blockedUsers").html(_self.viewModel.BlockedUserCount());
                }
                if (targetDiv.find("#targetedQuery").length > 0) {
                    targetDiv.find("#targetedQuery").html(_self.viewModel.QueryCriteriaCount());
                }
                if (targetDiv.find("#targetedArea").length > 0) {
                    targetDiv.find("#targetedArea").html(_self.viewModel.TargetedAreaCount());
                }
                if (targetDiv.find("#PersonalDeviceListDetailForAlertDetail").length > 0) {
                    ko.cleanNode(targetDiv.find("#PersonalDeviceListDetailForAlertDetail").get(0));
                    ko.applyBindings(athoc.iws.publishing.view.viewModel.personalDeviceList, targetDiv.find("#PersonalDeviceListDetailForAlertDetail").get(0));
                }

                //targeting summary
                if (targetDiv.find("#targetSummaryDetail").length > 0) {
                    ko.cleanNode(targetDiv.find("#targetSummaryDetail").get(0));
                    ko.applyBindings(_self.viewModel, targetDiv.find("#targetSummaryDetail").get(0));
                }

                if (athoc.iws.publishing.view && athoc.iws.publishing.view.viewModel && athoc.iws.publishing.view.viewModel.data && athoc.iws.publishing.view.viewModel.data.AlertStatus && (athoc.iws.publishing.view.viewModel.data.AlertStatus() == "Live" || athoc.iws.publishing.view.viewModel.data.AlertStatus() == "Ended"))
                    targetDiv.find("#targetSummaryDetail")[0].parentElement.style.display = "none";

                if (athoc.iws.publishing.rbt != null) {
                    if (athoc.iws.publishing.rbt.EntityFilterId != "")
                        targetDiv.find("#targetSummaryDetail")[0].parentElement.style.display = "none";
                }


                athoc.iws.publishing.view.viewModel.personalDeviceList.Devices([]);
                _.each(data.TargetUsers.Devices, function (device) {
                    var newDevice = ko.mapping.fromJS(device);
                    athoc.iws.publishing.view.viewModel.personalDeviceList.Devices.push(newDevice);
                });

                if (targetDiv.find("#PersonalDeviceListDetailForAlertDetail").length == 0) {
                    if (targetDiv.find("#PersonalDeviceListDetail").length > 0) {
                        ko.cleanNode(targetDiv.find("#PersonalDeviceListDetail").get(0));
                        ko.applyBindings(athoc.iws.publishing.view.viewModel.personalDeviceList, targetDiv.find("#PersonalDeviceListDetail").get(0));
                    }
                }

                //pie chart
                if (targetDiv.find(".contact-info-section").length > 0) {
                    ko.cleanNode(targetDiv.find(".contact-info-section").get(0));
                    ko.applyBindings(_self.viewModel, targetDiv.find(".contact-info-section").get(0));
                    if (targetDiv.find(".contact-info-section").length > 1) {
                        ko.cleanNode(targetDiv.find(".contact-info-section").get(1));
                        ko.applyBindings(_self.viewModel, targetDiv.find(".contact-info-section").get(1));

                        _self.showTargetingPieChart(devices, targetedAndBlockedGroups, targetedUsers, blockedUsers, queryCriterias, targetArea, data);
                    }
                }

            },

            //show user targeting pie chart
            showTargetingPieChart: function (devices, targetedAndBlockedGroups, targetedUsers, blockedUsers, queryCriterias, targetArea, data) {
                kendo.ui.progress($(".contact-info-loading"), true);

                require(['publishing/athoc.iws.publishing.contactInfoPieChart'], function (ContactInfoPieChart) {
                    //added condition to assign the div name based on the source
                    var pointer = null;
                    if (athoc.iws.publishing.source == 'readonly')
                        pointer = "#contactInfoReadOnly";
                    else
                        pointer = $("#dialogReviewAndStart #contactInfoReadOnly").length > 0 ? "#dialogReviewAndStart #contactInfoReadOnly" : "#dialogReviewAndPublish #contactInfoReadOnly";

                    //Commented the below line. If target user section is readonly and clicks on review and publish Piechart is not rending.
                    // if (athoc.iws.publishing.view.PieChartObject == null) {
                    athoc.iws.publishing.view.PieChartObject = new ContactInfoPieChart(
                    {
                        domPointer: pointer,
                        Publishing_Contact_Info_No_users_found: athoc.iws.publishing.resources.Publishing_Contact_Info_No_users_found,
                        Publishing_Contact_Info_Reachable_Tooltip: athoc.iws.publishing.resources.Publishing_Contact_Info_Reachable_Tooltip,
                        Publishing_Contact_Info_Not_Reachable_Tooltip: athoc.iws.publishing.resources.Publishing_Contact_Info_Not_Reachable_Tooltip,
                    });
                    //}
                });

                var userInfoSuccess = function (data) {
                    var current = athoc.iws.publishing.view;

                    //draw pie (default)
                    var contactInfo = [{
                        "type": "none",
                        "number": 100,
                        "color": "#ccc"
                    }];

                    current.viewModel.ContactinfoTotalCoveredNumber(new String("0"));
                    current.viewModel.ContactinfoTotalCoveredPercentage(new String("0"));
                    current.viewModel.ContactinfoNotCoveredNumber(new String("0"));
                    current.viewModel.ContactinfoNotCoveredPercentage(new String("0"));
                    current.viewModel.TotalUsers(new String("0"));

                    if (data.TotalCount > 0) {
                        //draw pie
                        contactInfo = [{
                            "type": "covered",
                            "number": data.ContactInfo.TotalCovered,
                            "color": "#7CB500",
                            "customPercentage": data.ContactInfo.TotalCoveredPercentage
                        }, {
                            "type": "notcovered",
                            "number": data.ContactInfo.TotalNotCovered,
                            "color": "#AE004B",
                            "customPercentage": data.ContactInfo.TotalNotCoveredPercentage
                        }];

                        current.viewModel.ContactinfoTotalCoveredNumber(new String(data.ContactInfo.TotalCovered));
                        current.viewModel.ContactinfoTotalCoveredPercentage(new String(data.ContactInfo.TotalCoveredPercentage));
                        current.viewModel.ContactinfoNotCoveredNumber(new String(data.ContactInfo.TotalNotCovered));
                        current.viewModel.ContactinfoNotCoveredPercentage(new String(data.ContactInfo.TotalNotCoveredPercentage));
                        current.viewModel.TotalUsers(data.TotalCount);

                    }

                    //set up values to targetusers model to display information on Pie chart click
                    /*if (athoc.iws.publishing.targetUsers.viewModelInstance.ReachableUsers != undefined)
                        athoc.iws.publishing.targetUsers.viewModelInstance.ReachableUsers(data.ContactInfo.TotalCovered);
                    else
                        athoc.iws.publishing.targetUsers.viewModelInstance.ReachableUsers = ko.observable(data.ContactInfo.TotalCovered);

                    if (athoc.iws.publishing.targetUsers.viewModelInstance.ReachableUsersPercentage != undefined)
                        athoc.iws.publishing.targetUsers.viewModelInstance.ReachableUsersPercentage(data.ContactInfo.TotalCoveredPercentage);
                    else
                        athoc.iws.publishing.targetUsers.viewModelInstance.ReachableUsersPercentage = ko.observable(data.ContactInfo.TotalCoveredPercentage);

                    if (athoc.iws.publishing.targetUsers.viewModelInstance.UnReachableUsers != undefined)
                        athoc.iws.publishing.targetUsers.viewModelInstance.UnReachableUsers(data.ContactInfo.TotalNotCovered);
                    else
                        athoc.iws.publishing.targetUsers.viewModelInstance.UnReachableUsers = ko.observable(data.ContactInfo.TotalNotCovered);

                    if (athoc.iws.publishing.targetUsers.viewModelInstance.UnReachableUsersPercentage != undefined)
                        athoc.iws.publishing.targetUsers.viewModelInstance.UnReachableUsersPercentage(data.ContactInfo.TotalNotCoveredPercentage);
                    else
                        athoc.iws.publishing.targetUsers.viewModelInstance.UnReachableUsersPercentage = ko.observable(data.ContactInfo.TotalNotCoveredPercentage);
                        */
                    if (athoc.iws.publishing.targetUsers.viewModelInstance.data != undefined)
                        current.viewModel.data.SessionId = data.SessionId;

                    ///set up values to targetusers model to display information on Pie chart click from Review and Publish
                    if (athoc.iws.alert.reviewandpublish == undefined) {
                        athoc.iws.alert.reviewandpublish = {};
                    }

                    athoc.iws.alert.reviewandpublish.SessionId = data.SessionId;
                    athoc.iws.alert.reviewandpublish.ReachableUsers(data.ContactInfo.TotalCovered);
                    athoc.iws.alert.reviewandpublish.ReachableUsersPercentage(data.ContactInfo.TotalCoveredPercentage);
                    athoc.iws.alert.reviewandpublish.UnReachableUsers(data.ContactInfo.TotalNotCovered);
                    athoc.iws.alert.reviewandpublish.UnReachableUsersPercentage(data.ContactInfo.TotalNotCoveredPercentage);


                    //TODO: need to check with deviceoptions to display custom text link

                    //Show updated coverage
                    var groupedDevices = athoc.iws.publishing.view.viewModel.personalDeviceList.Devices();
                    //getting devices having the reach percentage
                    var percentagesDevices = data.ContactInfo.ContactInfo;
                    //updating the reach based on the device id.
                    _.each(percentagesDevices, function (item) {
                        _.each(groupedDevices, function (device) {
                            if (item.DeviceId == device.DeviceId()) {
                                if (item.Percentage > 0)
                                    device.Reach(item.Percentage);
                                else
                                    device.Reach(0);
                            }
                        });
                    });

                    current.PieChartObject.update(contactInfo);
                    if (athoc.iws.publishing.source == 'readonly')
                        divContactInfo = "#contactInfoReadOnly";
                    else
                        divContactInfo = "#dialogReviewAndPublish #contactInfoReadOnly";

                    if (data.ContactInfo.TotalCovered > 0 || data.ContactInfo.TotalNotCovered > 0)
                        $(divContactInfo).css("cursor", "pointer");
                    else
                        $(divContactInfo).css("cursor", "default");

                    // this function is called to validate whether publishing is ready or not
                    if (athoc.iws.publishing.source == "p" || athoc.iws.publishing.source == "h" || athoc.iws.publishing.source == "a") {
                        //commented out this code to unblock everyone
                        athoc.iws.publishing.view.validatePublishStatus(data.TotalCount);
                    } else {
                        if (athoc.iws.scenario.settings != undefined)
                            athoc.iws.scenario.settings.applyVisibleSettingsOnAlert();
                    }

                    kendo.ui.progress($(".contact-info-loading"), false);
                };

                var userInfoError = function (error) {
                    kendo.ui.progress($(".contact-info-loading"), false);
                };


                var entityId = athoc.iws.publishing.view.id;
                var context = athoc.iws.publishing.view.context;
                var status = ["Publishing", "Live", "Ended"];
                if (data.AlertStatus && (status.indexOf(data.AlertStatus) > -1) && (athoc.iws.alert.source != "rbt")) {
                    if (athoc.iws.publishing.view.viewModel.loadTargetUsers() == true) {
                        //console.log('loading user');
                        athoc.iws.publishing.view.getUsersCountFromAlert(data.EntityId, userInfoSuccess, userInfoError);
                    }
                }
                else if (athoc.iws.alert.action != 'rbt') //in rbt flow, updateContactInfo is triggered when device checkbox is selected. thus, no need to invoke it here. 
                {
                    athoc.iws.publishing.UpdateContactInfo(entityId, context, targetedAndBlockedGroups, devices, userInfoSuccess, userInfoError, queryCriterias, targetArea, targetedUsers, blockedUsers, athoc.iws.publishing.rbt);
                }
                    ////else if ((data.AlertStatus == undefined && athoc.iws.alert.source == 'rbt'))
                    ////        athoc.iws.publishing.UpdateContactInfo(entityId, context, targetedAndBlockedGroups, devices, userInfoSuccess, userInfoError, queryCriterias, targetArea, targetedUsers, blockedUsers, athoc.iws.publishing.rbt);
                else if ((data.AlertStatus == undefined || data.AlertStatus === 'Live') && (athoc.iws.alert.source == 'rbt'))
                    athoc.iws.publishing.UpdateContactInfo(entityId, context, targetedAndBlockedGroups, devices, userInfoSuccess, userInfoError, queryCriterias, targetArea, targetedUsers, blockedUsers, athoc.iws.publishing.rbt);


            },

            //Returns users count for the sent alert
            getUsersCountFromAlert: function (alertid) {
                var current = athoc.iws.publishing.view;
                var alertData =
                  {
                      url: athoc.iws.publishing.urls.GetUsersCountFromAlertUrl + "?alertId=" + alertid,
                      contentType: 'application/json',
                      dataType: 'json',
                      type: 'GET',
                      cache: false
                  };
                var userInfoSuccess = function (data) {
                    if (data.Success) {
                        current.viewModel.TotalUsers(data.TotalCount);
                        athoc.iws.alert.reviewandpublish.SessionId = data.SessionId;
                    } else {
                        $('#alertView').find("#messagePanel").messagesPanel({ messages: [{ Type: '4', Value: data.Message }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                    }
                };

                var userInfoError = function (error) {
                    console.log(error);
                };

                var ajaxOptions = $.extend({}, AjaxUtility(userInfoError, userInfoSuccess).ajaxPostOptions, alertData);
                $.ajax(ajaxOptions);
            },

            //replace placeholder values before publishing
            replacePlaceholder: function () {

                if (athoc.iws.publishing.view.replacedPlaceholder)
                    return;
                athoc.iws.publishing.view.replacedPlaceholder = true;

                var placeholders = null;
                if (athoc.iws.alert.placeholder) {
                    placeholders = athoc.iws.alert.placeholder.getModel();
                }


                var viewmodel = athoc.iws.publishing.view.viewModel.data;

                var replacementModels =
                    [{ GroupId: 0, FieldId: 'title', Value: viewmodel.Content.Title(), MinLength: 3, MaxLength: 100, Label: 'Title' },
                        { GroupId: 0, FieldId: 'body', Value: viewmodel.Content.Body(), MinLength: 0, MaxLength: 2000, Label: 'Body' }];

                if (viewmodel.Content.ResponseOptionId() == 0 && viewmodel.Content.ResponseOptions().length) {
                    $.each(viewmodel.Content.ResponseOptions(), function (index, objOption) {
                        replacementModels.push({ GroupId: 0, FieldId: 'response-option-' + index, Value: objOption.ResponseText(), MinLength: 1, MaxLength: 64, Label: 'Response Option ' + (index + 1) });
                    });
                }

                var deviceOptionArray = [];
                var deviceGroupOptionsRawXML = [];


                if (athoc.iws.publishing.source == "a") {

                    var massDeviceDeviceOptionsModel = athoc.iws.publishing.massdevices.getModel();

                    if (massDeviceDeviceOptionsModel != null) {
                        deviceOptionArray = deviceOptionArray.concat(massDeviceDeviceOptionsModel.MassDeviceGroupOptions);
                    }

                    var targetUsersModel = athoc.iws.publishing.targetUsers.getModel();
                    if (targetUsersModel != null) {
                        deviceOptionArray = deviceOptionArray.concat(targetUsersModel.DeviceGroupOptions);
                    }

                    deviceOptionArray = athoc.iws.publishing.view.filterDeviceOptionForSelectedDevices(deviceOptionArray);

                    if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Targeting.Readonly || athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Delivery.Readonly) {
                        //if target user is read only, get 
                        this.replacePlaceholderAjax([], replacementModels, placeholders, this.PresetDeviceGroupOptions);
                    } else {
                        this.replacePlaceholderAjax(deviceOptionArray, replacementModels, placeholders);
                    }

                    //athoc.iws.publishing.view.showDeviceCustomText(deviceOptionArray);

                } else {
                    this.replacePlaceholderAjax(deviceOptionArray, replacementModels, placeholders, athoc.iws.publishing.view.publishingModel.PresetDeviceGroupOptions);
                }
            },

            replacePlaceholderAjax: function (deviceOptionArray, replacementModels, placeholders, deviceGroupOptionsRawXML) {

                $(".customTextWrapper").hide();

                $('#btnPublishAlert').prop("disabled", true);

                var model = {
                    PlaceholderReplacementModels: replacementModels,
                    SelectedPlaceHolders: placeholders,
                    DeviceGroupOptions: deviceOptionArray,
                    DeviceGroupOptionsRawXML: deviceGroupOptionsRawXML
                };

                var dlAjaxOption =
                {
                    url: "/athoc-iws/publishing/ReplacePlaceholders",
                    contentType: false,
                    dataType: 'json',
                    type: 'POST',
                    data: JSON.stringify(model)
                };

                $.AjaxLoader.hideLoader();
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#dialogReviewAndPublish').find(".modal-body"), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();

                var ajaxSuccess = function (data) {

                    if (data.Success) {

                        //replace values into publishing model and show any validation errors
                        var vm = athoc.iws.publishing.view.viewModel.data;
                        var isValid = true;
                        if (data.Model && data.Model.PlaceholderReplacementModels) {
                            $.each(data.Model.PlaceholderReplacementModels, function (index, objResponse) {
                                var field = objResponse.Label;
                                if (objResponse.GroupId == 0 && objResponse.FieldId == 'title') {
                                    vm.Content.Title(objResponse.Value);
                                } else if (objResponse.GroupId == 0 && objResponse.FieldId == 'body') {
                                    vm.Content.Body(objResponse.Value);
                                    if (objResponse.Value) {
                                        athoc.iws.publishing.view.viewModel.bodyWithLineBreak($.htmlEncode(objResponse.Value.trim()).replace(/(?:\r\n|\r|\n)/g, '<br />'));
                                    } else {
                                        athoc.iws.publishing.view.viewModel.bodyWithLineBreak('');
                                    }
                                } else if (objResponse.GroupId == 0 && objResponse.FieldId.lastIndexOf('response-option-', 0) === 0) {
                                    var id = objResponse.FieldId.split("-")[2];
                                    athoc.iws.publishing.view.viewModel.data.Content.ResponseOptions()[id].ResponseText(objResponse.Value);

                                    //fill count text replacement
                                    if (athoc.iws.publishing.fillcount && athoc.iws.publishing.fillcount.viewModel && athoc.iws.publishing.fillcount.viewModel.fillCountModel
                                        && athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId && athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId() > 0) {
                                        var fillCountId = athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId() - 1;

                                        //compare FillCount's response option with currently replaced response option
                                        if (id == fillCountId && $('#dialogReviewAndPublish').find("#responseText").length > 0) {
                                            var fillCountResponseText = $('#dialogReviewAndPublish').find("#responseText");
                                            fillCountResponseText.html(objResponse.Value);
                                            fillCountResponseText.attr("title", objResponse.Value);
                                        }
                                    }

                                } else if (objResponse.GroupId != 0) {
                                    var deviceName = athoc.iws.publishing.view.setDeviceCustomText(objResponse.GroupId, objResponse.FieldId, objResponse.Value, false, field);
                                    if (deviceName && deviceName != "") {
                                        field = deviceName;
                                        if (objResponse.Label != "") {
                                            field += ' ' + objResponse.Label;
                                        }
                                    } else {
                                        field = objResponse.Label;
                                    }
                                }

                                if (!athoc.iws.publishing.view.isPlaceholderReplacementModelValid(objResponse)) {
                                    isValid = false;
                                    var errorString = kendo.format(athoc.iws.publishing.resources.Publishing_Replaceholder_ErrorMessage, field, objResponse.MinLength, objResponse.MaxLength);
                                    athoc.iws.publishing.view.messages.push({ Type: '4', Value: errorString });
                                }
                            });
                        }

                        if (data.Model && data.Model.RecordingPreviewModels) {
                            $.each(data.Model.RecordingPreviewModels, function (index, objAudio) {
                                athoc.iws.publishing.view.setDeviceAudio(objAudio.GroupId, objAudio.Id, objAudio.Name, objAudio.Stream);
                            });
                        }

                        if (!isValid && athoc.iws.publishing.view.messages.length > 0) {
                            $('#dialogReviewAndPublish').find("#messagePanel").messagesPanel({ messages: athoc.iws.publishing.view.messages }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                            $('#btnPublishAlert').prop("disabled", true);
                        } else {
                            $('#btnPublishAlert').prop("disabled", false);
                        }


                    } else {
                        athoc.iws.publishing.view.messages.push({ Type: '4', Value: data.Messages });
                        $('#dialogReviewAndPublish').find("#messagePanel").messagesPanel({ messages: athoc.iws.publishing.view.messages }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        $('#dialogReviewAndPublish').find('.modal-body').scrollTop(0);
                        $('#btnPublishAlert').prop("disabled", true);
                    }
                    $(".customTextWrapper").show();
                    $.AjaxLoader.hideLoader();

                };

                //athoc.iws.publishing.content.ReadonlyViewModel.alertTitle('');
                //athoc.iws.publishing.content.ReadonlyViewModel.bodyWithLineBreak('');

                //kendo.ui.progress($("#publishing-content-detail"), true);

                var ajaxOptions = $.extend({}, AjaxUtility(null, ajaxSuccess).ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);

            },
            getCustomTextViaAjax: function (deviceGroupOptionsRawXML) {
                //store as variable here so it can be obtained while replacing with placeholder in r&p
                this.PresetDeviceGroupOptions = deviceGroupOptionsRawXML;
                var model = {
                    optionPresets: deviceGroupOptionsRawXML
                };

                var dlAjaxOption =
                {
                    url: "/athoc-iws/publishing/RetrieveCustomText",
                    contentType: 'application/json',
                    dataType: 'json',
                    type: 'POST',
                    data: JSON.stringify(model)
                };

                var ajaxSuccess = function (data) {

                    kendo.ui.progress($("#publishing-content-detail"), false);

                    if (data.Success) {
                        //replace values into publishing model and show any validation errors
                        var vm = athoc.iws.publishing.view.viewModel.data;
                        var isValid = true;
                        if (data.Model && data.Model.PlaceholderReplacementModels) {
                            $.each(data.Model.PlaceholderReplacementModels, function (index, objResponse) {
                                var field = objResponse.Label;

                                var deviceName = athoc.iws.publishing.view.setDeviceCustomText(objResponse.GroupId, objResponse.FieldId, objResponse.Value, true, field);
                                if (deviceName && deviceName != "") {
                                    field = deviceName;
                                    if (objResponse.Label != "") {
                                        field += ' ' + objResponse.Label;
                                    }
                                } else {
                                    field = objResponse.Label;
                                }
                            });
                        }
                    }

                };

                //athoc.iws.publishing.content.ReadonlyViewModel.alertTitle('');
                //athoc.iws.publishing.content.ReadonlyViewModel.bodyWithLineBreak('');

                kendo.ui.progress($("#publishing-content-detail"), true);

                var ajaxOptions = $.extend({}, AjaxUtility(null, ajaxSuccess).ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);

            },
            //filter device options for selected devices only
            filterDeviceOptionForSelectedDevices: function (deviceOptionArray) {
                if (!deviceOptionArray || deviceOptionArray.length == 0) {
                    return deviceOptionArray;
                }

                var selecedDevicesOptionArray = [];

                var isMassDeviceTargeted = (athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList() && athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList().length > 0);
                try {
                    isMassDeviceTargeted = (athoc.iws.publishing.massdevices.getModel().MassDevices && athoc.iws.publishing.massdevices.getModel().MassDevices.length > 0);
                } catch (e) {

                }

                var isPersonalDeviceTargeted = (athoc.iws.publishing.view.viewModel.personalDeviceList && athoc.iws.publishing.view.viewModel.personalDeviceList.Devices().length > 0);

                _.each(deviceOptionArray, function (deviceOption) {
                    if (deviceOption && deviceOption.GroupId && deviceOption.GroupId > 0) {
                        if (isPersonalDeviceTargeted) {
                            var personalDeviceObj = jQuery.grep(athoc.iws.publishing.view.viewModel.personalDeviceList.Devices(), function (device) { return device.GroupId() == deviceOption.GroupId; });
                            if (personalDeviceObj && personalDeviceObj.length > 0) {
                                selecedDevicesOptionArray.push(deviceOption);
                            }
                        }

                        if (isMassDeviceTargeted) {

                            var deviceObj = jQuery.grep(athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList(), function (device) { return device.GroupId() == deviceOption.GroupId; });
                            if (deviceObj && deviceObj.length > 0) {
                                selecedDevicesOptionArray.push(deviceOption);
                            } else {
                                try {
                                    //check on non-readonly mass device model to see if device group is targeted
                                    var deviceObj = jQuery.grep(athoc.iws.publishing.massdevices.getModel().MassDevices, function (device) { return device.GroupId == deviceOption.GroupId; });
                                    if (deviceObj && deviceObj.length > 0) {
                                        selecedDevicesOptionArray.push(deviceOption);
                                    }
                                } catch (e) {
                                }
                            }
                        }
                    }
                });

                return selecedDevicesOptionArray;
            },

            //method to set device custom text
            setDeviceCustomText: function (groupId, fieldId, customText, setRawValue, label) {

                /*localizizing label - no longer deduce label from fieldId
                var label = "Value";
                var deviceName = "";
                if (fieldId && fieldId.indexOf(".") >= 0) {
                    var arrLabel = fieldId.split(".");
                    label = arrLabel[arrLabel.length - 1];
                }*/

                if (athoc.iws.publishing.view.viewModel.personalDeviceList && athoc.iws.publishing.view.viewModel.personalDeviceList.Devices().length > 0) {
                    _.each(athoc.iws.publishing.view.viewModel.personalDeviceList.Devices(), function (device) {
                        if (device.GroupId() == groupId) {
                            athoc.iws.publishing.view.setDeviceCustomTextProperty(device, fieldId, label, customText, setRawValue);
                            deviceName = device.GroupName();
                        }
                    });
                }


                if (athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList() && athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList().length > 0) {
                    _.each(athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList(), function (deviceGroup) {
                        if (deviceGroup.GroupId() == groupId) {
                            athoc.iws.publishing.view.setDeviceCustomTextProperty(deviceGroup, fieldId, label, customText, setRawValue);
                            _.each(deviceGroup.DeviceList(), function (device) {
                                athoc.iws.publishing.view.setDeviceCustomTextProperty(device, fieldId, label, customText, setRawValue);
                                deviceName = device.GroupName();
                            });
                        }
                    });
                }

                return deviceName;
            },

            //helper method for setting device custom text property
            setDeviceCustomTextProperty: function (device, fieldId, label, customText, setRawValue) {
                if (!device.CustomText()) {
                    if (customText && customText != '') {
                        var item = { Field: fieldId, Name: label };
                        if (setRawValue) {
                            item.RawValue = customText;
                        } else {
                            item.Value = customText;
                        }
                        device.CustomText(new Array(item));
                    }
                } else {
                    //replace if exists
                    var exists = false;
                    _.each(device.CustomText(), function (txt) {

                        var name = txt.Name;
                        if (typeof txt.Name == "function") {
                            name = txt.Name();
                        }

                        if (name == label) {
                            exists = true;
                            if (setRawValue) {
                                txt.RawValue = customText;
                            } else {
                                txt.Value = customText;
                            }
                        }
                    });
                    if (!exists && customText && customText != '') {
                        var item = { Field: fieldId, Name: label };
                        if (setRawValue) {
                            item.RawValue = customText;
                        } else {
                            item.Value = customText;
                        }

                        device.CustomText().push(item);
                    }
                }
            },

            //show custom text for personal/mass device
            showCustomText: function (targetDiv, event) {

                //check to see if you are in review and publish or read only
                var isReviewAndPublish = ($(event.target).closest("#dialogReviewAndPublish").length != 0) || ($(event.target).closest("#PersonalDeviceListDetailForAlertDetail").length != 0);

                if (this.CustomText) {
                    $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP").html('');
                    athoc.iws.alert.reviewandpublish.showModalonModal("#targetedUsersSummaryRP");
                    $("#targetedUsersSummaryRP").find("#spanTitleDetails").text(athoc.iws.publishing.resources.Publishing_Custom_Text);
                    var summaryDiv = $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP");
                    var content = "<div style='word-wrap: break-word;'>";
                    if (this.CustomText().length == 1) {
                        var value = this.CustomText()[0].Value;
                        if (!isReviewAndPublish) {
                            if (typeof this.CustomText()[0].RawValue == "function") {
                                value = this.CustomText()[0].RawValue();
                            } else {

                                if (this.CustomText()[0].RawValue != undefined)
                                    value = this.CustomText()[0].RawValue;
                            }
                        }
                        var textValue = $.htmlEncode(value).replace(/(?:\r\n|\r|\n)/g, '<br />');
                        content = textValue;
                    } else if (this.CustomText().length > 1) {
                        _.each(this.CustomText(), function (customText) {
                            var value = customText.Value;

                            if (!isReviewAndPublish) {
                                if (typeof customText.RawValue == "function") {
                                    value = customText.RawValue();
                                } else {
                                    if (customText.RawValue != undefined)
                                        value = customText.RawValue;
                                }
                            }
                            var txtValue = $.htmlEncode(value).replace(/(?:\r\n|\r|\n)/g, '<br />');

                            var name = customText.Name;
                            if (typeof customText.Name == "function")
                                name = customText.Name();
                            content += "<b>" + name + "</b> <br/>" + txtValue + "<br/><br/>";
                        });
                    }
                    content += "</div>";
                    summaryDiv.html(content);
                }
            },

            //replace device custom text before publishing (personal & mass)
            replaceDeviceCustomText: function (alert) {
                //personal devices
                if (alert && alert.TargetUsers && alert.TargetUsers.DeviceGroupOptions && alert.TargetUsers.DeviceGroupOptions.length > 0
                    && athoc.iws.publishing.view.viewModel.personalDeviceList && athoc.iws.publishing.view.viewModel.personalDeviceList.Devices().length > 0) {
                    _.each(alert.TargetUsers.DeviceGroupOptions, function (deviceOption) {
                        var deviceObj = jQuery.grep(athoc.iws.publishing.view.viewModel.personalDeviceList.Devices(), function (device) { return device.GroupId() == deviceOption.GroupId; });
                        if (deviceObj && deviceObj.length > 0) {
                            athoc.iws.publishing.view.replaceDeviceOptions(deviceOption, deviceObj[0]);
                        }
                    });
                }

                //mass devices 
                if (alert && alert.MassDeviceGroupOptions && alert.MassDeviceGroupOptions.length > 0
                    && athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList() && athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList().length > 0) {
                    _.each(alert.MassDeviceGroupOptions, function (deviceOption) {
                        var deviceObj = jQuery.grep(athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList(), function (device) { return device.GroupId() == deviceOption.GroupId; });
                        if (deviceObj && deviceObj.length > 0) {
                            athoc.iws.publishing.view.replaceDeviceOptions(deviceOption, deviceObj[0]);
                        }
                    });
                }

                return alert;
            },

            //method to set audio property
            setDeviceAudio: function (groupId, audioId, fileName, audioStream) {
                var deviceName = "";

                if (athoc.iws.publishing.view.viewModel.personalDeviceList && athoc.iws.publishing.view.viewModel.personalDeviceList.Devices().length > 0) {
                    _.each(athoc.iws.publishing.view.viewModel.personalDeviceList.Devices(), function (device) {
                        if (device.GroupId() == groupId) {
                            deviceName = device.GroupName();
                            if (jQuery.isFunction(device.RecordedMessage)) {
                                device.RecordedMessage({ AudioId: audioId, FileName: fileName, Stream: audioStream });
                            } else {
                                //device.RecordedMessage({ AudioId: audioId, FileName: fileName, Stream : audioStream });
                            }
                        }
                    });
                }

                return deviceName;
            },

            //show recorded audio
            showAudio: function (targetDiv, event) {
                //check to see if you are in review and publish or read only
                if (this.RecordedMessage) {
                    var fileName = "";
                    var audioId = "";
                    var audioStream = "";

                    if (jQuery.isFunction(this.RecordedMessage)) {
                        fileName = this.RecordedMessage().FileName;
                        audioId = this.RecordedMessage().AudioId;
                        audioStream = this.RecordedMessage().Stream;
                    } else {
                        fileName = this.RecordedMessage.FileName();
                        audioId = this.RecordedMessage.AudioId();
                        audioStream = this.RecordedMessage.Stream();
                    }
                    $("#recordedMessageModal").find("#recorderContainer").html('');
                    athoc.iws.alert.reviewandpublish.showModalonModal("#recordedMessageModal");
                    $("#recordedMessageModal").find("#spanTitleDetails").text("Recorded Message");
                    var summaryDiv = $("#recordedMessageModal").find("#recorderContainer");
                    var content = "<div id='readOnlyRecordedMessage'></div>";
                    summaryDiv.html(content);

                    $("#recordedMessageModal").find("#btn_Cancel").click(function () {
                        athoc.iws.publishing.view.readonlyRecordedMessage.stopAudio();
                        $("#recordedMessageModal").find("#recorderContainer").html('');
                    });

                    require(["publishing/AudioUploader/AudioUploader"], function (AudioUploader) {
                        var options = {
                            fileName: fileName,
                            audioId: audioId,
                            fileStream: audioStream,
                            isReadOnly: true,
                            isBrowseSpecific: navigator.userAgent.toLowerCase().indexOf('trident') != -1 ? true : false,
                            operator: audioUploader.operatorName,
                        }
                        var currentItem = $("#recordedMessageModal").find("#readOnlyRecordedMessage");
                        if (athoc.iws.publishing.view.readonlyRecordedMessage) {
                            athoc.iws.publishing.view.readonlyRecordedMessage.destroy();
                        }

                        athoc.iws.publishing.view.readonlyRecordedMessage = new AudioUploader(options, $(currentItem)[0], audioUploader);
                        athoc.iws.publishing.view.readonlyRecordedMessage.startup();
                        athoc.iws.publishing.view.readonlyRecordedMessage.viewModel.isChanged(audioUploader.isAudioFileChanged);
                    });
                }
            },

            //helper for replaceing device options
            replaceDeviceOptions: function (deviceOption, device) {
                if (!deviceOption || !device || !deviceOption.Options || !device.CustomText())
                    return;

                _.each(deviceOption.Options, function (option) {
                    var sourceOption = jQuery.grep(device.CustomText(), function (src) { return src.Field == option.Name; });
                    if (sourceOption && sourceOption.length > 0) {
                        option.Value = sourceOption[0].Value;
                    }
                });
            },

            isPlaceholderReplacementModelValid: function (model) {
                if (model && model.Value) {
                    return (model.Value.length >= model.MinLength && model.Value.length <= model.MaxLength);
                }
                else if (!model.Value && model.MinLength == 0) {
                    return true;
                }
                return false;
            },

            //show more less for header
            updateMoreLess: function (targetDiv) {
                targetDiv.find('.moretext').each(function () {
                    if ($(this).find(".morecontent").length == 0) {
                        var showChar = 300;
                        var ellipsestext = "...";
                        var moretext = "more";
                        var content = $(this).html();

                        if (content.length > showChar) {
                            var c = content.substr(0, showChar);
                            var h = content.substr(showChar, content.length - showChar);

                            var html = c + '<span class="moreelipses">' + ellipsestext + '</span><span class="morecontent"><span>' + h + '</span>&nbsp;&nbsp;<a href="" class="morelink">' + moretext + '</a></span>';

                            $(this).html(html);
                        }
                    }
                });

                targetDiv.find('.morelink').unbind('click');

                targetDiv.find(".morelink").click(function () {
                    var moretext = "more";
                    var lesstext = "less";
                    if ($(this).hasClass("less")) {
                        $(this).removeClass("less");
                        $(this).html(moretext);
                    } else {
                        $(this).addClass("less");
                        $(this).html(lesstext);
                    }
                    $(this).parent().prev().toggle();
                    $(this).prev().toggle();
                    return false;
                });
            },

            //publish alert
            publishAlert: function () {
                //Get updated data from each section in viewmodel
                var alertObj = ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data);


                alertObj.Origin = athoc.iws.publishing.view.Origin;
                if (athoc.iws.publishing.view.Origin != "AlertDetail") {
                    alertObj.ParentId = athoc.iws.publishing.view.ParentId;
                }

                //replace device custom text with placeholder
                alertObj = athoc.iws.publishing.view.replaceDeviceCustomText(alertObj);

                var dlAjaxOption =
                {
                    url: athoc.iws.publishing.urls.PublishAlertUrl,
                    contentType: false,
                    dataType: 'json',
                    type: 'POST',
                    data: JSON.stringify(alertObj)
                };

                //Send view model to server for saving
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#dialogReviewAndPublish'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();

                var ajaxSuccess = function (data) {

                    if (data.Success) {
                        athoc.iws.publishing.detail.setChanged(false);
                        athoc.iws.publishing.view.publishedAlertId = data.Data.EntityId;
                        $('#dialogReviewAndPublish').find("#messagePanel").messagesPanel({ messages: [{ Type: '9', Value: ((alertObj.AlertScheduleSettings != null && alertObj.AlertScheduleSettings != undefined && alertObj.AlertScheduleSettings.ScheduleAlertPublishStartModeSettime != 'ASAP') ? athoc.iws.publishing.resources.Publishing_Msg_Alert_Scheduled_Successfully : athoc.iws.publishing.resources.Publishing_Msg_ForMoreInformation_ClickAlertSummary) }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        $('#dialogReviewAndPublish').find('.modal-body').scrollTop(0);
                        $("#dialogReviewAndPublish").find(".pre-publish").hide();
                        $("#dialogReviewAndPublish").find(".post-publish").show();
                        $("#btnDialogReviewEdit").hide();
                        $("#btnPublishViewReport").unbind("click");
                        $("#btnPublishViewReport").click(function () { athoc.iws.publishing.view.viewReport(data.Data.EntityId); });
                        if (data.Data.AlertStatus == "Scheduled")
                            $("#dialogReviewAndPublish").find("#btnPublishViewReport").hide();
                        else
                            $("#dialogReviewAndPublish").find("#btnPublishViewReport").show();
                    } else {
                        athoc.iws.publishing.view.messages.push({ Type: '4', Value: data.Messages });
                        $('#dialogReviewAndPublish').find("#messagePanel").messagesPanel({ messages: athoc.iws.publishing.view.messages }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        $('#dialogReviewAndPublish').find('.modal-body').scrollTop(0);
                    }

                    $.AjaxLoader.hideLoader();

                };

                var ajaxOptions = $.extend({}, AjaxUtility(null, ajaxSuccess).ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);

                return true;
            },

            //download alert as pdf
            downloadPdfFile: function (postUrl) {
                try {
                    $("#dialogReviewAndPublish").append('<div id="displayShadow" class="modal-backdrop fade in"><div class="LoadingImage_Overlay"><img src= ' + athoc.iws.publishing.urls.cdnUrl + "Images/ajax-loader.gif" + '></img></div></div>');

                    var alertObj = "";
                    athoc.iws.publishing.detail.setChanged(false);
                    var personalDevicesList = ko.mapping.toJS(athoc.iws.publishing.view.viewModel.personalDeviceList.Devices());
                    //Get updated data from each section in viewmodel
                    alertObj = {
                        Content: ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.Content),
                        TargetUsers: ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.TargetUsers),
                        DeviceList: personalDevicesList,
                        TargetOrg: ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.TargetOrg),
                        AlertScheduleSettings: athoc.iws.publishing.settings.IsSchedulingSupported ? ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.AlertScheduleSettings) : null,
                        MassDevices: ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.MassDevices),
                        MassDeviceGroupOptions: ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.MassDeviceGroupOptions)
                    };


                    // This is for Mass device list data, Custom text would already replaced here with placeholder if any.
                    var massDevicesList = ko.mapping.toJS(athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList());
                    var arrMassOption = [];

                    _.each(massDevicesList, function (device) {
                        var cText = []
                        if (device.DeviceList != null && device.DeviceList.length > 0) {
                            _.each(device.DeviceList, function (dobj) {
                                _.each(dobj.CustomText, function (cusObj) {
                                    if (cusObj != null && cusObj.Name != null && cusObj.Name != "")
                                        cText.push({ Name: cusObj.Name, Value: cusObj.Value });
                                });

                                var massSelectedDevice = {
                                    GroupId: device.GroupId,
                                    DeviceId: dobj.DeviceId,
                                    Options: cText
                                };

                                arrMassOption.push(massSelectedDevice);
                            });
                        }
                    });

                    // This is for personal device list data, Custom text would already replaced here with placeholder if any.                
                    var arrDeviceOption = [];

                    _.each(personalDevicesList, function (device) {
                        var cText = []
                        if (device.CustomText != null) {
                            _.each(device.CustomText, function (dobj) {
                                cText.push({ Name: dobj.Name, Value: dobj.Value });
                            })
                        }

                        var personalSelectedDevice = {
                            GroupId: device.GroupId == null ? 0 : device.GroupId,
                            DeviceId: device.DeviceId == null ? 0 : device.DeviceId,
                            Options: cText
                        };

                        arrDeviceOption.push(personalSelectedDevice);

                    });

                    var piechartData = $("#dialogReviewAndPublish").find("#piechartSummaryDetail").outerHTML();
                    var targetingSummary = $("#dialogReviewAndPublish").find("#targetSummaryDetail").outerHTML();
                    //Added the condition to check the targetSummary counts. If all below counts are Zero assigning null to the targetSummary bug#16402
                    if ((alertObj.TargetUsers.TargetedBlockedUsers != null && alertObj.TargetUsers.TargetedBlockedUsers.length == 0) && (alertObj.TargetUsers.Devices != null && alertObj.TargetUsers.Devices.length == 0) && (alertObj.TargetUsers.TargetingNodes != null && alertObj.TargetUsers.TargetingNodes.length == 0))
                        targetingSummary = "";

                    if (athoc.iws.publishing.rbt != null && athoc.iws.publishing.rbt.EntityFilterId != "") {
                        targetingSummary = 'notapplicable';
                    }
                    var locationdata = "";
                    if (athoc.iws.publishing.view.viewModel.isGeoSelected() && $("#dialogReviewAndPublish").find(".readOnlyMiniMapHolder").html() != "") {
                        locationdata = $("#dialogReviewAndPublish").find(".readOnlyMiniMapHolder").outerHTML();
                    }

                    athoc.iws.publishing.view.viewModel.audioFileName("");
                    var foundRMsg = _.find(personalDevicesList, function (item) {
                        return item.RecordedMessage != null;
                    });
                    if (foundRMsg) {
                        athoc.iws.publishing.view.viewModel.audioFileName(foundRMsg.RecordedMessage.FileName);
                    }
                    var fillCounthtml = "";
                    var oldHtml = "";

                    if (($('#dialogReviewAndPublish #FillCountSummary') != undefined) && ($('#dialogReviewAndPublish #FillCountSummary').css('display') == 'block') && ($('#dialogReviewAndPublish #FillCountSummary').find('#FillCountDetails').css('display') == 'block')) {
                        oldHtml = $('#dialogReviewAndPublish #FillCountSummary').find('#FillCountDetails').outerHTML();
                        fillCounthtml = $('#dialogReviewAndPublish #FillCountSummary').find('#FillCountDetails');
                        fillCounthtml.find(".wide span").attr("style", "width:200px;word-wrap:wrap-all;white-space: normal;display:block;margin-right:10px;margin-bottom:5px");

                    }

                    var param = $.param({
                        feed: ko.toJSON(alertObj), pieChartData: piechartData, locationData: locationdata,
                        targetingSummary: targetingSummary, MassDevicesList: ko.toJSON(arrMassOption),
                        PersonalDevicesList: ko.toJSON(arrDeviceOption), TotalUsers: athoc.iws.publishing.view.viewModel.TotalUsers()
                        , audioFileName: athoc.iws.publishing.view.viewModel.audioFileName() != "" ? ko.toJSON(athoc.iws.publishing.view.viewModel.audioFileName()) : "",
                        fillCountInfo: fillCounthtml != "" ? fillCounthtml.outerHTML() : ""
                    });

                    if (oldHtml != '') {
                        $('#dialogReviewAndPublish #FillCountSummary').html('');
                        $('#dialogReviewAndPublish #FillCountSummary').html(oldHtml);
                    }

                    $.fileDownload(postUrl, {
                        httpMethod: "POST",
                        data: param,
                        successCallback: function () { $("#dialogReviewAndPublish").find('#displayShadow').remove(); },
                        failureCallback: function () { $("#dialogReviewAndPublish").find('#displayShadow').remove(); }
                    });

                }
                catch (ex) {
                    localStorage.setItem('pdfError', ex);
                    $("#dialogReviewAndPublish").find('#displayShadow').remove();

                }
                return true;
            },
        }
    }();
}
///#source 1 1 /Scripts/Publishing/athoc.iws.publishing.geo.js
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};

if (athoc.iws.publishing) {
    athoc.iws.publishing.geo = function () {
        return {
            viewModel: {
                geoTargetingEnabled: ko.observable(true),

                //geo location
                isGeoSelected: ko.observable(false),

                geoImageUrl: ko.observable(''),

                shapes: ko.observable([]),

                isUsersTargeted: ko.observable(false),

                isOrganizationsTargeted: ko.observable(false),

                usersCount: ko.observable(0),

                organizationsCount: ko.observable(0),

                onTargetUserByAreaChange: function () {
                    if (!athoc.iws.publishing.geo.viewModel.isUsersTargeted())
                        athoc.iws.publishing.targetUsers.viewModelInstance.numberAreaCriteria(0);
                    else
                        athoc.iws.publishing.geo.updateTargetingSummary();
                    athoc.iws.publishing.geo.updateContactPieChart();
                    return true;
                }
            },

            geoJson: null, //stores geoJson for currently loaded alert/scenario
            geoTargetMap: null, //map component
            miniMap: null,

            //triggered onload, function can have any load logic
            load: function () {
                //athoc.iws.publishing.geo.loadMap();
            },

            //load map component
            loadMap: function () {

                /*IWS-19267 
                1) removed esri minimap reference. 
                2) commented minimap creation using esri
                3) commented restoring geo coordinates for minimap
                4) called new method called bindAlertMiniMap
                5) impelemted GeoTargetingSummary maps  using leaflet on screen and r&p window 
                
                */
                //require(["maps/GeoTargetMap", "maps/MiniMap"], function (GeoTargetMap, MiniMap) {
                require(["maps/GeoTargetMap"], function (GeoTargetMap) {
                    athoc.iws.publishing.geo.geoTargetMap = new GeoTargetMap({ i18n: athoc.iws.publishing.mapResources, culture: languageParams.currentCulture }, "geoTargetMapHolder");

                    /* IWS-19267 - commnted out min map code implementation using esri. */

                    //athoc.iws.publishing.geo.miniMap = new MiniMap(null, "miniMapHolder");

                    athoc.iws.publishing.geo.geoTargetMap.startup();
                    athoc.iws.publishing.geo.geoTargetMap.geoTargetLayer.on("orgTargetComplete", function (e) {
                        if (athoc.iws.publishing.targetOrg.OrgViewMod) {
                            //e.orgIds
                            athoc.iws.publishing.targetOrg.OrgViewModel.OrgCountByArea(e.selectedOrgs);
                            athoc.iws.publishing.targetOrg.OrgViewModel.SelectedOrgsByArea(e.orgIds);
                        }
                    });

                    athoc.iws.publishing.geo.geoTargetMap.on("close", function () {
                        athoc.iws.publishing.geo.geoJson = athoc.iws.publishing.geo.geoTargetMap.toGeoJson();
                        if (!athoc.iws.publishing.geo.geoJson || !athoc.iws.publishing.geo.geoJson.features || athoc.iws.publishing.geo.geoJson.features.length === 0) {
                            athoc.iws.publishing.geo.viewModel.isGeoSelected(false);
                            athoc.iws.publishing.content.viewModel.isGeoSelected(false);
                            athoc.iws.publishing.geo.updateTargetingSummary();
                            athoc.iws.publishing.geo.viewModel.isUsersTargeted(false);
                            athoc.iws.publishing.geo.viewModel.isOrganizationsTargeted(false);
                            if (athoc.iws.publishing.targetOrg.OrgViewModel) {
                                athoc.iws.publishing.targetOrg.OrgViewModel.TargetOrgByArea(false);
                            }
                        } else {
                            athoc.iws.publishing.geo.viewModel.isGeoSelected(true);
                            athoc.iws.publishing.content.viewModel.isGeoSelected(true);

                            /*IWS-19267 - commented out restoring selected shape coordinates using esri mini map*/

                            //athoc.iws.publishing.geo.miniMap.setBasemap(athoc.iws.publishing.geo.geoTargetMap.getBasemap());
                            //athoc.iws.publishing.geo.miniMap.restore(athoc.iws.publishing.geo.geoJson);

                            /*IWS-19267 - calling new method to bind selected shape coordinates in leaflet map*/
                            athoc.iws.publishing.geo.bindAlertMiniMap(athoc.iws.publishing.geo.miniMap,athoc.iws.publishing.geo.geoJson);

                            athoc.iws.publishing.geo.viewModel.isUsersTargeted(athoc.iws.publishing.geo.geoTargetMap.isTargetingUser);
                            athoc.iws.publishing.geo.viewModel.isOrganizationsTargeted(athoc.iws.publishing.geo.geoTargetMap.isTargetingOrg);
                            if (athoc.iws.publishing.targetOrg.OrgViewModel) {
                                athoc.iws.publishing.targetOrg.OrgViewModel.TargetOrgByArea(athoc.iws.publishing.geo.geoTargetMap.isTargetingOrg);
                            }
                            athoc.iws.publishing.geo.updateTargetingSummary();
                        }
                        athoc.iws.publishing.geo.updateContactPieChart();
                        athoc.iws.publishing.content.checkReadyNotReady();
                    });

                    $('#dialogGeoTargetingSummary').on('shown.bs.modal', function () {
                        /*IWS-19267 - removed olde code and impelemted using leaflet */

                        //if (!athoc.iws.publishing.geo.summaryMap) {
                        //    athoc.iws.publishing.geo.summaryMap = new MiniMap({ width: 980, height: 300 }, "dialogGeoTargetingSummaryContent");
                        //}
                        //athoc.iws.publishing.geo.summaryMap.setBasemap(athoc.iws.publishing.geo.geoTargetMap.getBasemap());
                        //athoc.iws.publishing.geo.summaryMap.restore(athoc.iws.publishing.geo.geoJson);
                        //setTimeout(function () {
                        //    athoc.iws.publishing.geo.summaryMap.resize();
                        //    athoc.iws.publishing.geo.summaryMap.zoomToFit();
                        //}, 500);


                        require(["widget/Map"], function (Map) {
                            if (!athoc.iws.publishing.geo.summaryMap) {
                                athoc.iws.publishing.geo.summaryMap = new Map("dialogGeoTargetingSummaryContent", { i18n: athoc.iws.publishing.mapResources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture });
                            }
                            athoc.iws.publishing.geo.bindAlertMiniMap(athoc.iws.publishing.geo.summaryMap, athoc.iws.publishing.geo.geoJson);
                        });
                    });

                    /*IWS-19267 - removed olde code and impelemted using leaflet in R&P publish window binding to display in all places like home and alerts screen*/
                    //the second popup modal in review and publish page
                   
                    $('#dialogGeoPublish').on('shown.bs.modal', function () {
                        /* if (!athoc.iws.publishing.geo.summaryMapOnRP) {
                            athoc.iws.publishing.geo.summaryMapOnRP = new MiniMap({ width: 980, height: 300 }, "dialogGeoPublishContent");
                        }
                        athoc.iws.publishing.geo.summaryMapOnRP.setBasemap(athoc.iws.publishing.geo.geoTargetMap.getBasemap());
                        athoc.iws.publishing.geo.summaryMapOnRP.restore(athoc.iws.publishing.geo.geoJson);
                        setTimeout(function () {
                            athoc.iws.publishing.geo.summaryMapOnRP.resize();
                            athoc.iws.publishing.geo.summaryMapOnRP.zoomToFit();
                        }, 500); */

                        require(["widget/Map"], function (Map) {
                            if (!athoc.iws.publishing.view.summaryMapReadOnly) {
                                athoc.iws.publishing.view.summaryMapReadOnly = new Map("dialogGeoPublishContent", {
                                    i18n: athoc.iws.publishing.mapResources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture
                                });
                            }
                            athoc.iws.publishing.view.bindGeoAlertMiniMap(athoc.iws.publishing.view.summaryMapReadOnly, athoc.iws.publishing.geo.geoJson);
                        });

                    });
                   


                });
            },


            /* IWS-19267 - Written new method to removing old ge coordinates then adding new geo coordinates*/
            bindAlertMiniMap: function (miniMap,geoLocationsJson) {
                if (miniMap != null || miniMap) {
                    miniMap.removeGeoJson();
                    miniMap.addGeoJson(geoLocationsJson);
                    miniMap.centerAt([0, 0]);
                    miniMap.zoomToFit();
                }
            },

            //called when geo targeting model gets binded
            bind: function (data, isUsersTargeted, isOrganizationsTargeted) {
                athoc.iws.publishing.geo.viewModel.isUsersTargeted(isUsersTargeted);
                athoc.iws.publishing.geo.viewModel.isOrganizationsTargeted(isOrganizationsTargeted);
                var geoJson = data != "" ? JSON.parse(data) : null;
                //if (data == null || data == '') {
                if (geoJson == null || geoJson.features.length == 0) {// condition to stop loading generic map.

                    athoc.iws.publishing.geo.viewModel.isGeoSelected(false);
                    athoc.iws.publishing.content.viewModel.isGeoSelected(false);
                    athoc.iws.publishing.geo.viewModel.geoImageUrl('');
                } else {
                    if (athoc.iws.publishing.geo.geoTargetMap == null || athoc.iws.publishing.geo.miniMap == null) {
                        athoc.iws.publishing.geo.loadMap();
                    }

                    athoc.iws.publishing.geo.viewModel.isGeoSelected(true);
                    athoc.iws.publishing.content.viewModel.isGeoSelected(true);
                    athoc.iws.publishing.geo.geoJson = JSON.parse(data);

                    athoc.iws.publishing.geo.geoTargetMap.removeTargetAreas();

                   
                    athoc.iws.publishing.geo.geoTargetMap.geoTargetLayer.restore(athoc.iws.publishing.geo.geoJson);


                    /*IWS-19267- commented out restoring selected shape coordinates using esri mini map*/

                    //athoc.iws.publishing.geo.miniMap.setBasemap(athoc.iws.publishing.geo.geoTargetMap.getBasemap());
                    //athoc.iws.publishing.geo.miniMap.restore(athoc.iws.publishing.geo.geoJson);

                    /*IWS-19267 - written code to create mini map using leaflet and binding geo coordinates. this section will call while editing drafted alert*/
                    if (athoc.iws.publishing.geo.geoJson != "" || athoc.iws.publishing.geo.geoJson != null) {

                        require(["widget/Map"], function (Map) {
                            if (!athoc.iws.publishing.geo.miniMap) {
                                if (!athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content || !athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.Collapsed) {
                                    athoc.iws.publishing.geo.miniMap = new Map("miniMapHolder", {i18n: athoc.iws.publishing.mapResources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture });
                                    athoc.iws.publishing.geo.bindAlertMiniMap(athoc.iws.publishing.geo.miniMap,athoc.iws.publishing.geo.geoJson);
                                }
                            }
                            else {
                                athoc.iws.publishing.geo.bindAlertMiniMap(athoc.iws.publishing.geo.miniMap,athoc.iws.publishing.geo.geoJson);
                            }

                        });
                    }
                }

                //Binding
                if ($("#targetContentArea").length > 0) {
                    ko.cleanNode($("#targetContentArea").get(0));
                    ko.applyBindings(athoc.iws.publishing.geo.viewModel, $("#targetContentArea").get(0));
                }

                athoc.iws.publishing.geo.updateTargetingSummary();
            },

            //called to get model for persisting
            getModel: function () {
                //return shape data for persisting
                if (athoc.iws.publishing.geo.geoJson != null) {
                    return JSON.stringify(athoc.iws.publishing.geo.geoJson);
                } else {
                    return null;
                }
            },

            //add geo location, entry point when alert/scenario does not have any existing location
            add: function () {
                var params = {};
                params.isNewMap = false;
                if (athoc.iws.publishing.geo.geoTargetMap == null || athoc.iws.publishing.geo.miniMap==null) {
                    athoc.iws.publishing.geo.loadMap();
                    params.isNewMap = true;
                }
                var isTargetByUserEnabled = (($("#targetArea").length > 0) && ($('#targetArea').css('display') != 'none'));
                if (isTargetByUserEnabled) {
                    isTargetByUserEnabled = (($("#publishing-user-edit").length > 0) && ($('#publishing-user-edit').css('display') != 'none'));
                }

                var isTargetOrganizationEnabled = (($(".org-by-area").length > 0) && ($('.org-by-area').css('display') != 'none'));
                if (isTargetOrganizationEnabled && ($("#alert-org-edit").length > 0)) {
                    isTargetOrganizationEnabled = ($('#alert-org-edit').css('display') != 'none');
                } else  if (isTargetOrganizationEnabled &&  ($("#targetOrgSection").length > 0)) {
                    isTargetOrganizationEnabled = ($('#targetOrgSection').css('display') != 'none');
                }

                if (isTargetByUserEnabled || isTargetOrganizationEnabled) {
                    athoc.iws.publishing.geo.geoTargetMap.setTargetable(true);
                } else {
                    athoc.iws.publishing.geo.geoTargetMap.setTargetable(false);
                }

                athoc.iws.publishing.geo.geoTargetMap.setUserTargetable(isTargetByUserEnabled);
                athoc.iws.publishing.geo.geoTargetMap.setOrgTargetable(isTargetOrganizationEnabled);

                athoc.iws.publishing.geo.geoTargetMap.removeTargetAreas();

                athoc.iws.publishing.geo.geoTargetMap.isTargetingUser = isTargetByUserEnabled;
                athoc.iws.publishing.geo.geoTargetMap.isTargetingOrg = isTargetOrganizationEnabled;


                athoc.iws.publishing.geo.geoTargetMap.show(params);

                /*IWS-19267 - Creating mini map instance using leaflet*/
                require(["widget/Map"], function (Map) {

                    if (!athoc.iws.publishing.geo.miniMap) {
                        // updating map div visible
                        athoc.iws.publishing.content.viewModel.isGeoSelected(true);
                        athoc.iws.publishing.geo.miniMap = new Map("miniMapHolder", { i18n: athoc.iws.publishing.mapResources,zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture });
                    }
                });
            },

            //remove/clear shapes
            remove: function () {
                if (athoc.iws.publishing.geo.geoTargetMap == null || athoc.iws.publishing.geo.miniMap == null) {
                    athoc.iws.publishing.geo.loadMap();
                }
                athoc.iws.publishing.geo.viewModel.isGeoSelected(false);
                athoc.iws.publishing.content.viewModel.isGeoSelected(false);
                athoc.iws.publishing.geo.viewModel.geoImageUrl('');
                athoc.iws.publishing.geo.geoTargetMap.removeTargetAreas();
                athoc.iws.publishing.geo.geoJson = null;
                athoc.iws.publishing.geo.updateTargetingSummary();
                athoc.iws.publishing.geo.viewModel.isUsersTargeted(false);
                athoc.iws.publishing.geo.viewModel.isOrganizationsTargeted(false);
                if (athoc.iws.publishing.targetOrg.OrgViewModel) {
                    athoc.iws.publishing.targetOrg.OrgViewModel.TargetOrgByArea(false);
                    athoc.iws.publishing.targetOrg.OrgViewModel.OrgCountByArea(0);
                    athoc.iws.publishing.targetOrg.OrgViewModel.SelectedOrgsByArea([]);
                }
                athoc.iws.publishing.geo.updateContactPieChart();
                athoc.iws.publishing.content.checkReadyNotReady();
            },

            //edit alert/scenario location
            edit: function () {
                if (athoc.iws.publishing.geo.geoTargetMap == null || athoc.iws.publishing.geo.miniMap == null) {
                    athoc.iws.publishing.geo.loadMap();
                }
                var isTargetByUserEnabled = (($("#targetArea").length > 0) && ($('#targetArea').css('display') != 'none'));
                if (isTargetByUserEnabled) {
                    isTargetByUserEnabled = (($("#publishing-user-edit").length > 0) && ($('#publishing-user-edit').css('display') != 'none'));
                }

                var isTargetOrganizationEnabled = (($(".org-by-area").length > 0) && ($('.org-by-area').css('display') != 'none'));
                if (isTargetOrganizationEnabled && ($("#alert-org-edit").length > 0)) {
                    isTargetOrganizationEnabled = ($('#alert-org-edit').css('display') != 'none');
                } else if (isTargetOrganizationEnabled && ($("#targetOrgSection").length > 0)) {
                    isTargetOrganizationEnabled = ($('#targetOrgSection').css('display') != 'none');
                }

                if (isTargetByUserEnabled || isTargetOrganizationEnabled) {
                    athoc.iws.publishing.geo.geoTargetMap.setTargetable(true);
                } else {
                    athoc.iws.publishing.geo.geoTargetMap.setTargetable(false);
                }

                athoc.iws.publishing.geo.geoTargetMap.setUserTargetable(isTargetByUserEnabled);
                athoc.iws.publishing.geo.geoTargetMap.setOrgTargetable(isTargetOrganizationEnabled);

                /*athoc.iws.publishing.geo.geoTargetMap.removeTargetAreas();
                if (athoc.iws.publishing.geo.geoJson != null) {
                    athoc.iws.publishing.geo.geoTargetMap.geoTargetLayer.restore(athoc.iws.publishing.geo.geoJson);
                } */

                athoc.iws.publishing.geo.geoTargetMap.isTargetingUser = athoc.iws.publishing.geo.viewModel.isUsersTargeted() && isTargetByUserEnabled;                
                athoc.iws.publishing.geo.geoTargetMap.isTargetingOrg = athoc.iws.publishing.targetOrg.OrgViewModel && athoc.iws.publishing.targetOrg.OrgViewModel.TargetOrgByArea() && isTargetOrganizationEnabled;

                athoc.iws.publishing.geo.geoTargetMap.show();
            },

            //reflect map selection in targeting summary
            updateTargetingSummary: function () {
                var objectCount = 0, nonPoint;
                if (athoc.iws.publishing.geo.geoJson
                    && athoc.iws.publishing.geo.geoJson.features
                    && athoc.iws.publishing.geo.viewModel.isUsersTargeted()) {
                    nonPoint = $.grep(athoc.iws.publishing.geo.geoJson.features, function (item, idx) {
                        return item.geometry.type.toLowerCase() !== 'point';
                    });
                    objectCount = nonPoint.length;
                }

                if(athoc.iws.publishing.targetUsers.viewModelInstance.numberAreaCriteria)
                athoc.iws.publishing.targetUsers.viewModelInstance.numberAreaCriteria(objectCount);
            },

            //update contact pie chart based on geo-location
            updateContactPieChart: function () {
                athoc.iws.publishing.targetUsers.updateContactInfo();
                athoc.iws.publishing.targetUsers.targetingChanged();
            },

            //apply map changes from add/edit dialog 
            applyMapChanges: function () {
                //TODO: apply map changes may be recalculate users (not sure yet)
            },

            //make a json call to get users and organizations based on selected area
            getUsersAndOrgsForSelectedArea: function () {
                //TODO: send shape information in ajax request and get user and organization
            },

        };
    }();
}
///#source 1 1 /Scripts/Publishing/athoc.iws.alert.schedule.js
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.alert = athoc.iws.alert || {};

if (athoc.iws.alert) {
    // Enable/disable controls in all browsers
    ko.bindingHandlers['CustomEnable'] = (function () {
        return {
            init: function (element, valueAccessor) {
                var $element = $(element);
                var value = ko.utils.unwrapObservable(valueAccessor());
                if (value)
                    $('[data-id=' + ($element[0].id) + ']').removeClass("disabled");
                else
                    $('[data-id=' + ($element[0].id) + ']').addClass("disabled"); 

            },
            update: function (element, valueAccessor) {
                var value = ko.utils.unwrapObservable(valueAccessor());
                var $element = $(element);
                if (value)
                    $('[data-id=' + ($element[0].id) + ']').removeClass("disabled");
                else
                    $('[data-id=' + ($element[0].id) + ']').addClass("disabled");
            }
        };
    }());
    athoc.iws.alert.schedule = function () {
        return {
            isReadyToPublish: false,
            isInErrorState: false,
            AMPMformat: false,
            viewModel: {
                alertschedule: ko.observableArray(),
                timeformart: ko.observableArray(),
                Visible: ko.observable(false),
                Collapsed: ko.observable(false),
                Readonly: ko.observable(false),
                Mode: "",
                isLiveAlert: ko.observable(false),
                isLiveorEnded: ko.observable(true),
                isEndedAert: ko.observable(false),
                isFillCountEnabled: ko.observable(false),
            },


            load: function () {

            },

            GetLocalizedDurationUnit: function(){
                switch (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleDurationInputUnit()) {
                case 'Minute':
                    return $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_Minutes);
                case 'Hour':
                    return $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_Hours);
                case 'Day':
                    return $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_Days);
                }

                return athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleDurationInputUnit();
            },

        initiatePickers: function () {

                var AMPMformat = $.vpsDateTimeFormat.indexOf('tt') > 0 ? true : false;
                //var datetimeformat = AMPMformat ? athoc.iws.alert.schedule.getVPSTimeFormat('dateformat') : athoc.iws.alert.schedule.getVPSTimeFormat('dateformat').replace("HH:", "hh:");
                var momentdatetimeformat = athoc.iws.alert.schedule.getVPSTimeFormat('momentformat');

                if (!athoc.iws.alert.schedule.viewModel.isLiveAlert()) {
                    $("#ddlAlertScheduleDurationHours").selectpicker();

                    $('#publishing-alert-edit').find('#istartDateValue').datetimepicker({
                        pick12HourFormat: AMPMformat,
                        pickSeconds: ($.vpsDateTimeFormat.indexOf('ss') > 0 ? true : false),
                        language: $.culture,
                         startDate: new Date(moment($.vpsTimeZone.CurrentVPSDate.toLocaleString(), "MM/DD/YYYY")),
                         format: $.vpsDateTimeFormat
                    }).on('changeDate', function (ev) {
                        var newDate = null;
                        if (ev.localDate != null)
                            newDate = moment(ev.localDate).format(momentdatetimeformat);
                        athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartDateInput(newDate);
                    });


                } else {

                    $('#alert-detail').find('#iendDateValue').datetimepicker({
                        pick12HourFormat: AMPMformat,
                        language: $.culture,
                        pickSeconds: ($.vpsDateTimeFormat.indexOf('ss') > 0 ? true : false),
                        startDate: new Date(moment($.vpsTimeZone.CurrentVPSDate.toLocaleString(), "MM/DD/YYYY")),
                        format: $.vpsDateTimeFormat
                    }).on('changeDate', function (ev) {
                        if (ev.localDate == null)
                            return;
                        var newDate = moment(ev.localDate).format(momentdatetimeformat);
                        athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishEndDateInput(newDate);
                    });
                    $("#ddlviewAlertScheduleHr").selectpicker();
                    $("#ddlAlertScheduleMin").selectpicker();
                    $("#ddlAlertScheduleMer").selectpicker();

                }

                $("#publishing-alert-view .icon-calendar").click(function () { $('html,body').animate({ scrollTop: 9999 }, 'slow'); $('.bootstrap-datetimepicker-widget').css("z-index", "6"); });
                $("#publishing-alert-edit .icon-calendar").click(function () { $('html,body').animate({ scrollTop: 9999 }, 'slow'); $('.bootstrap-datetimepicker-widget').css("z-index", "6"); });
            },
            bindReadOnlyView: function (alertscheduledata, targetDiv) {

                if ((athoc.iws.publishing.detail.viewModel.AlertStatus == "Live" || athoc.iws.publishing.detail.viewModel.AlertStatus == "Ended") && (athoc.iws.alert.source != "rbt")) {
                    athoc.iws.alert.schedule.viewModel.isLiveorEnded(true);

                    if (athoc.iws.publishing.detail.viewModel.AlertStatus == "Live")
                        athoc.iws.alert.schedule.viewModel.isLiveAlert(true);

                    if (athoc.iws.publishing.detail.viewModel.AlertStatus == "Ended")
                        athoc.iws.alert.schedule.viewModel.isEndedAert(true);
                } else {
                    athoc.iws.alert.schedule.viewModel.isLiveorEnded(false);
                    athoc.iws.alert.schedule.viewModel.isLiveAlert(false);
                    athoc.iws.alert.schedule.viewModel.isEndedAert(false);
                }

                athoc.iws.alert.schedule.setIsFillCountEnabled();

                athoc.iws.alert.schedule.viewModel.alertschedule = ko.mapping.fromJS(alertscheduledata, athoc.iws.alert.schedule.getValidation());

                ko.cleanNode($(targetDiv).find("#publishing-alert-view").get(0));
                athoc.iws.alert.schedule.viewModel.Mode = (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertPublishStartModeSettime() == "ASAP" ? "ASAP" : "SET TIME");
                ko.applyBindings(athoc.iws.alert.schedule.viewModel, $(targetDiv).find("#publishing-alert-view").get(0));


            },
            bind: function (data, alertscheduledata) {

                //check if schedule feature is enabled
                if (!athoc.iws.publishing.settings.IsSchedulingSupported)
                    return;

                if (athoc.iws.alert && athoc.iws.alert.action && athoc.iws.alert.action == 'rbt')
                    alertscheduledata.ScheduleAlertPublishStartModeSettime = "ASAP";

                athoc.iws.alert.schedule.viewModel.Visible(data.Advanced.Visible);
                athoc.iws.alert.schedule.viewModel.Collapsed(data.Advanced.Collapsed);
                athoc.iws.alert.schedule.viewModel.Readonly(data.Advanced.Readonly);

                athoc.iws.alert.schedule.viewModel.alertschedule = ko.mapping.fromJS(alertscheduledata, athoc.iws.alert.schedule.getValidation());
                athoc.iws.alert.schedule.viewModel.timeformart(alertscheduledata.TimeFormat);

                //If Status is live ko binding based on the target div.
                //Hiding the status span
                var status = ["Publishing", "Live", "Ended"];
                if ((status.indexOf(athoc.iws.publishing.detail.viewModel.AlertStatus) > -1) && (athoc.iws.alert.source != "rbt")) {
                    athoc.iws.alert.schedule.viewModel.isLiveorEnded(true);

                    if (athoc.iws.publishing.detail.viewModel.AlertStatus == "Live")
                        athoc.iws.alert.schedule.viewModel.isLiveAlert(true);

                    if (athoc.iws.publishing.detail.viewModel.AlertStatus == "Ended")
                        athoc.iws.alert.schedule.viewModel.isEndedAert(true);

                    $("#alert-detail").find(".bootstrap-select").remove();
                    if (athoc.iws.publishing.fillcountfillCountSummary != null)
                        athoc.iws.alert.schedule.viewModel.isFillCountEnabled(true);
                    ko.cleanNode($("#alert-detail").get(0));
                    ko.applyBindings(athoc.iws.alert.schedule.viewModel, $("#alert-detail").get(0));
                    athoc.iws.alert.schedule.initiatePickers();
                }
                else {
                    $("#publishing-alert-edit").find(".bootstrap-select").remove(); 
                    if (athoc.iws.publishing.fillcountfillCountSummary != null)
                        athoc.iws.alert.schedule.viewModel.isFillCountEnabled(true);
                    if (athoc.iws.publishing.fillcountfillCountSummary != null)
                        athoc.iws.alert.schedule.viewModel.isFillCountEnabled(true);
                    ko.cleanNode($("#publishing-alert-edit").get(0));
                    ko.applyBindings(athoc.iws.alert.schedule.viewModel, $("#publishing-alert-edit").get(0));
                    athoc.iws.alert.schedule.initiatePickers();
                    if (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertPublishStartModeSettime() == "ASAP")
                    athoc.iws.alert.schedule.enableDateforSetTime(athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertPublishStartModeSettime());
                }
                if (athoc.iws.publishing.fillcountfillCountSummary != null)
                    athoc.iws.alert.schedule.viewModel.isFillCountEnabled(true);

                athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleDurationInput.subscribe(function (newValue) {
                    athoc.iws.alert.schedule.isAlertScheduleReady();
                });

                athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertPublishStartModeSettime.subscribe(function (newValue) {
                    athoc.iws.alert.schedule.enableDateforSetTime(newValue);
                    athoc.iws.alert.schedule.isAlertScheduleReady();
                });
                athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartDateInput.subscribe(function (newValue) {
                    athoc.iws.alert.schedule.isAlertScheduleReady();
                });
                athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartDateInput.extend({ notify: 'always' });
                athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartdateHourSelect.subscribe(function (newValue) {
                    athoc.iws.alert.schedule.isAlertScheduleReady();
                });
                athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartdateMinuteSelect.subscribe(function (newValue) {
                    athoc.iws.alert.schedule.isAlertScheduleReady();
                });
                athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartdateAmpmSelect.subscribe(function (newValue) {
                    athoc.iws.alert.schedule.isAlertScheduleReady();
                });

                athoc.iws.alert.schedule.isAlertScheduleReady();

            },
            setIsFillCountEnabled: function () {
                var fillCount = ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.FillCount);
                athoc.iws.alert.schedule.viewModel.isFillCountEnabled((fillCount == null || fillCount.FillCount == 0) ? false : true);
            },
            toggleCollpase: function () {
                targetDiv = $("#publishing-alert-edit");

                ////show bucket expanded by default
                if (athoc.iws.alert.schedule.viewModel.Collapsed()) {
                    targetDiv.find(".bucket-toggle .row").hide();
                    targetDiv.find(".bucket-toggle .expand-arrow-open").hide();
                    targetDiv.find(".bucket-toggle .expand-arrow-closed").show();
                }
                else {
                    targetDiv.find(".bucket-toggle .row").show();
                    targetDiv.find(".bucket-toggle .expand-arrow-open").show();
                    targetDiv.find(".bucket-toggle .expand-arrow-closed").hide();
                }
            },
            validDateTime: function (checkStartDate) {
                var vDate;
                if (checkStartDate)
                    vDate = athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartDateInput();// + " " + athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartdateHourSelect() + ":" + athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartdateMinuteSelect() + " " + athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartdateAmpmSelect();
                else
                    vDate = athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishEndDateInput();// + " " + athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishEnddateHourSelect() + ":" + athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishEnddateMinuteSelect() + " " + athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishEnddateAmpmSelect();
                
                return 		new Date(moment(vDate,athoc.iws.alert.schedule.getVPSTimeFormat('momentformat'))).getTime() -new Date($.vpsTimeZone.CurrentVPSDate.toDateString() + ' ' + $.vpsTimeZone.CurrentVPSDate.toTimeString()).getTime() > 0;
            },
            isValid: function () {

                if (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleDurationInput() == "")
                    return false;
                if ($.isNumeric(athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleDurationInput()) == false)
                    return false;
                if (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleDurationInput() < 1)
                    return false;

                if (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertPublishStartModeSettime() == "ASAP")
                    return true;
                else {
                    if (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartDateInput() == "")
                        return false;
                    if (!athoc.iws.alert.schedule.isValidDate(athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartDateInput()))
                        return false;
                    //start date should not be older date from today                        


                    if (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartDateInput != undefined && !athoc.iws.alert.schedule.viewModel.isLiveorEnded()) {
                        if (!athoc.iws.alert.schedule.validDateTime(true)) {
                            $("#StartDateErrorMsg").html(athoc.iws.publishing.resources.Publishing_Schedule_Err_AlertStartDate_LessThan_CurrDate);
                            $("#StartDateErrorMsg").show();
                            athoc.iws.alert.schedule.isInErrorState = true;
                            return false;
                        }
                        else
                            $("#StartDateErrorMsg").hide();
                    }

                }
                return true;

            },
          

            isValidDate: function (val) {
                var isValid = true;
                try {
                    isValid = moment(val, $.vpsDateFormat.toUpperCase()).isValid();
                }
                catch (error) {
                    isValid = false;
                }

                return isValid;
            },
            //this method will set ready state
            isAlertScheduleReady: function () {
                if (athoc.iws.alert.schedule.isValid()) {
                    athoc.iws.alert.schedule.isReadyToPublish = true;
                    athoc.iws.alert.schedule.isInErrorState = false;
                    athoc.iws.publishing.SetSectionStatus("#alertscheduleStatus", "ready");
                } else {
                    athoc.iws.alert.schedule.isReadyToPublish = false;
                    athoc.iws.alert.schedule.isInErrorState = true;
                    athoc.iws.publishing.SetSectionStatus("#alertscheduleStatus", "notReady");
                }
            },
            enableDateforSetTime: function (newValue) {
                if (newValue == "ASAP") {                    
                    $("#istartDateValue").datetimepicker("disable");

                } else {                    
                    $("#istartDateValue").datetimepicker("enable");
                    //$("input#istartDateValue").prop("disabled", true);
                }
            },
            //this method will be called when data is required for updating
            getModel: function () {
                //check if schedule feature is enabled
                if (!athoc.iws.publishing.settings.IsSchedulingSupported)
                    return null;

                return ko.mapping.toJS(athoc.iws.alert.schedule.viewModel.alertschedule);
            },
            //this method will pad chars to left of the string
            padLeft: function (value, length, char) {
                return new Array(length - (value + '').length + 1).join(char) + value;
            },
            handleError: function (e) {
                if (e != undefined && e.status == 401) {
                    window.onbeforeunload = null;
                    window.location = window.location;
                } else {
                    $('#listMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                }
            },
            validDayArrange: function (param1, param2, param3) {
                if (param2[1].indexOf('StartDate') < 0 && param2[1].indexOf('EndDate') < 0) {
                    if ($.isNumeric(param1) == false)
                        return false;
                    if (param1 < 1)
                        return false;
                }
                switch (param2[1]) {
                    case 'Duration':
                        {
                            switch (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleDurationInputUnit()) {
                                case 'Minute':
                                    if (param1 > 5256000)
                                        return false;
                                    break;
                                case 'Hour':
                                    if (param1 > 87600)
                                        return false;
                                    break;
                                case 'Day':
                                    if (param1 > 3650)
                                        return false;
                                    break;
                            }
                            break;
                        }

                    case 'AlertEndDate':
                        {
                            //iws#12687
                            if (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishEndDateInput != undefined && athoc.iws.alert.schedule.viewModel.isLiveAlert()) {
                                //End date should not be older date from today
                                //alert(athoc.iws.alert.schedule.validDateTime(false));
                                if (!athoc.iws.alert.schedule.validDateTime(false)) {
                                    athoc.iws.alert.schedule.isInErrorState = true;
                                    return false;
                                }
                            }
                            break;
                        }

                    case 'StartDate':
                        {

                            if (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartDateInput != undefined && !athoc.iws.alert.schedule.viewModel.isLiveorEnded() && athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertPublishStartModeSettime() != "ASAP") {
                                if (!athoc.iws.alert.schedule.validDateTime(true)) {
                                    athoc.iws.alert.schedule.isInErrorState = true;
                                    $("#StartDateErrorMsg").html(athoc.iws.publishing.resources.Publishing_Schedule_Err_AlertStartDate_LessThan_CurrDate);
                                    $("#StartDateErrorMsg").show();
                                    return false;
                                }
                                else
                                    $("#StartDateErrorMsg").hide();
                            }
                            break;
                        }

                }
                athoc.iws.alert.schedule.isInErrorState = false;
                return true;
            },


            getVPSTimeFormat: function (formatType) {
                var timeFormat = $.trim($.vpsDateTimeFormat.replace($.vpsDateFormat, "").toLowerCase().replace("tt", "PP"));
                var meridianFormat = $.vpsDateTimeFormat.indexOf('tt') > 0 ? " A" : "";
                var secondsIncluded = $.vpsDateTimeFormat.indexOf('ss') > 0 ? ":ss" : "";
                var dateFormat;
                switch (formatType) {
                    case "dateformat":
                        dateFormat = $.vpsDateFormat;
                            timeFormat = $.trim($.vpsDateTimeFormat.replace($.vpsDateFormat, "").toLowerCase().replace("tt", "PP").replace("hh", "HH"));
                        break;
                    case "momentformat":
                        dateFormat = $.vpsDateFormat.toUpperCase();
                        if (meridianFormat == "")
                            timeFormat = "HH:mm" + secondsIncluded;
                        else
                            timeFormat = "hh:mm" + secondsIncluded + meridianFormat;

                        break;
                }


                return dateFormat + ' ' + timeFormat;
            },

            //setup validation
            getValidation: function () {
                var validationMapping = {
                    ScheduleAlertpublishEndDateInput: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                required: { message: athoc.iws.publishing.resources.Publishing_Schedule_Err_AlertEndDate_Require },
                                validation: {
                                    validator: athoc.iws.alert.schedule.validDayArrange,
                                    message: athoc.iws.publishing.resources.Publishing_Schedule_Err_AlertEndDate_LessThan_CurrDate,
                                    params: [this.value, "AlertEndDate", 2]
                                }
                            });
                        }
                    },
                   

                    ScheduleAlertPublishStartModeSettime: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                validation: {
                                    validator: athoc.iws.alert.schedule.validDayArrange,
                                    message: athoc.iws.publishing.resources.Publishing_Schedule_Err_AlertStartDate_LessThan_CurrDate,
                                    params: [this.value, "StartDate", 2]
                                }
                            });
                        }
                    },

                    ScheduleDurationInput: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                required: { message: athoc.iws.publishing.resources.Publishing_Schedule_Err_AlertDuration },
                                maxLength: { params: 7, message: athoc.iws.publishing.resources.Publishing_Schedule_Err_MaxLength.format(7) },
                                pattern: {
                                    message: athoc.iws.publishing.resources.Publishing_Schedule_Err_OnlyNumerics,
                                    params: "^[0-9]+$"
                                },
                                validation: {
                                    validator: athoc.iws.alert.schedule.validDayArrange,
                                    message: athoc.iws.publishing.resources.Publishing_Schedule_Err_ValidDuration_Years.format('10'),
                                    params: [this.value, "Duration", 2]
                                }
                            });
                        }
                    },


                };

                return validationMapping;
            },
        };
    }();
}
///#source 1 1 /Scripts/Publishing/athoc.iws.publishing.massDevices.js
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};

if (athoc.iws.publishing) {
    athoc.iws.publishing.massdevices = function () {
        return {
            isChanged: false,
            IsRightToLeft: false,
            isReadyToPublish: true,
            isInErrorState: false,
            selectedCount: 0,
            DeviceGroupOptions: new Array(),
            massDeviceList: ko.observableArray(),
            isLocationPresent: ko.observable(false),
            Parameters: new Array(),
            readOnlyModel: {
                massDeviceList: ko.observableArray(),
                showCustomText: function () {
                    if (this.CustomText) {
                        $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP").html('');
                        athoc.iws.alert.reviewandpublish.showModalonModal("#targetedUsersSummaryRP");
                        $("#targetedUsersSummaryRP").find("#spanTitleDetails").text(athoc.iws.publishing.resources.Publishing_Custom_Text);
                        var summaryDiv = $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP");
                        summaryDiv.html(this.CustomText());
                    }
                }
            },
            viewModel: {
                keyDict: {},
                context: this,
                massDeviceList: ko.observableArray(),
                IsAffiliate: ko.observable(false),
                launchMassDeviceOptions: function () {
                    if (athoc.iws.publishing.massdevices.isAnyMassDeviceSelected()) {
                        $(athoc.iws.publishing.massdevices.Parameters.dialogDeviceOptions).modal("show");
                        athoc.iws.utilities.resizeModalBasedOnScreen($(athoc.iws.publishing.massdevices.Parameters.dialogDeviceOptions), 600, 770, 20, 170);
                    }
                },
                subscribeLocationChanges: function () {
                    if (athoc.iws.publishing.geo && athoc.iws.publishing.geo.viewModel && athoc.iws.publishing.geo.viewModel.isGeoSelected) {
                        athoc.iws.publishing.geo.viewModel.isGeoSelected.subscribe(function (newvalue) {
                            if (newvalue) {
                                athoc.iws.publishing.massdevices.isLocationPresent(true);
                            } else {
                                athoc.iws.publishing.massdevices.isLocationPresent(false);
                            }
                            athoc.iws.publishing.massdevices.isMassDeviceReady();
                        });
                    }
                },
                subscribeEndPoints : function(massdevices) {
                    _.each(massdevices(), function(massdevice) {
                        _.each(massdevice.DeviceList(), function(device) {
                            device.SelectedUsers.subscribe(function(newValue) {
                                 athoc.iws.publishing.massdevices.isMassDeviceReady();
                            });
                        });
                    });
                }
            },
            init: function (parameters) {
                this.Parameters = parameters;
                var self = this;
                athoc.iws.publishing.massdevices.viewModel.subscribeLocationChanges();
            },
            load: function () {
            },

            loadEndPoints: function (url, data) {
                var deferred = $.Deferred();
                var dlAjaxOption =
               {
                   type: "POST",
                   url: url,
                   data: {
                       devices: data,
                   },
               };
                var ajaxSuccess = function (datawithendpoints) {
                    if (datawithendpoints) {
                        deferred.resolve(datawithendpoints);
                    } else {
                        console.log("EndPoints are invalid");
                        deferred.reject();
                    }
                };
                var ajaxError = function (data) {
                    console.log(data);
                    deferred.reject(data);
                };

                var ajaxOptions = $.extend({}, AjaxUtility(ajaxError, ajaxSuccess).ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);
                return deferred.promise();
            },


            bind: function (data, IsReadOnly, readOnly, presetDeviceOptions) {

                var self = this;

                if (!data || data.length == 0) {
                    athoc.iws.publishing.massdevices.isMassDeviceReady();
                    return;
                }
             
                //check if schedule feature is enabled
                if (!athoc.iws.publishing.settings.IsMassDeviceTargetSupported) {
                    athoc.iws.publishing.massdevices.isMassDeviceReady();
                    return;
                }

                console.log(athoc.iws.publishing.contextName);
                if (athoc.iws.publishing.contextName != "Scenario" && IsReadOnly) {

                    athoc.iws.publishing.massdevices.bindReadOnlyView(data, "#alert-mass-detail");
                } else {

                    var url = self.Parameters.getEndPointsURL;
                    var input = ko.toJS(data);

                    kendo.ui.progress($("#publishing-mass-edit"), true);

                    $.when(athoc.iws.publishing.massdevices.loadEndPoints(url, input)).then(function (datawithendpoints) {
                        var setTargetingAndSelectionProp = function (fromData, toData) {
                            var selectedfromData = _.filter(fromData, function (selectedDevice) {
                                return selectedDevice.Selected;
                            });
                           _.each(selectedfromData, function (fromDevice) {
                                var toDataDevice = _.find(toData, function(toDevice) {
                                    return fromDevice.DeviceId === toDevice.DeviceId;
                                });
                                if (toDataDevice) {
                                    _.each(toDataDevice.EndPoints, function(toEndPoint) {
                                       var fromEndPoint =  _.find(fromDevice.EndPoints, function(fromEndPointItem) {
                                           return fromEndPointItem.UserId === toEndPoint.UserId;
                                       });
                                        if (fromEndPoint) {
                                            toEndPoint.IsTargetable = fromEndPoint.IsTargetable;
                                            toEndPoint.IsSelected = fromEndPoint.IsSelected;
                                        }
                                    });
                                }
                            });
                        };
                        
                        setTargetingAndSelectionProp(data,datawithendpoints);

                        athoc.iws.publishing.massdevices.selectedCount = 0;
                        athoc.iws.publishing.massdevices.massDeviceList.removeAll();
                        athoc.iws.publishing.massdevices.removeKeyUser(datawithendpoints,true);

                        ko.cleanNode($("#publishing-mass-edit").get(0));
                        athoc.iws.publishing.massdevices.viewModel.massDeviceList = ko.mapping.fromJS(athoc.iws.publishing.massdevices.formatMassDeviceList(datawithendpoints));
                        $("#massdevicesdisplay").html("");

                        ko.applyBindings(athoc.iws.publishing.massdevices.viewModel, $("#publishing-mass-edit").get(0));
                        athoc.iws.publishing.massdevices.viewModel.subscribeEndPoints(athoc.iws.publishing.massdevices.viewModel.massDeviceList);

                        if (athoc.iws.publishing.massdevices.viewModel.massDeviceList()[0].GroupName() != "")
                            $('#MassDeviceFlatList').show();
                        else
                            $('#MassDeviceFlatList').hide();

                        var onSave = function (selectedOptions) {
                            self.DeviceGroupOptions = selectedOptions;
                        }

                        $(".alert-nav").attr("disabled", true);
                        kendo.ui.progress($("#alert-mass-edit"), true);

                        var onLoadDone = function (selectedOptions) {
                            kendo.ui.progress($("#alert-mass-edit"), false);
                            $(".alert-nav").attr("disabled", false);

                            self.DeviceGroupOptions = selectedOptions;

                        }

                        athoc.iws.publishing.massDeviceOptions.load(datawithendpoints, presetDeviceOptions, onSave, onLoadDone);
                        athoc.iws.publishing.massdevices.collapsePanel();
                        athoc.iws.publishing.massdevices.isMassDeviceReady();

                        kendo.ui.progress($("#publishing-mass-edit"), false);

                    });

                }
            },

            removeKeyUser: function (data, canClear) {
                if (canClear) {
                    athoc.iws.publishing.massdevices.viewModel.keyDict = {};
                }
                _.each(data, function (device) {
                    var keyUser = _.find(device.EndPoints, function (endPoint) {
                        return endPoint.IsKeyUser ;
                    });
                    if (keyUser) {
                        athoc.iws.publishing.massdevices.viewModel.keyDict[device.DeviceId] = keyUser;
                        var index = device.EndPoints.indexOf(keyUser);
                        if (index > -1) {
                            device.EndPoints.splice(index, 1);
                        }
                    }
                });
            },


            //this method will be called when data is required for updating
            getModel: function () {
                //check if schedule feature is enabled
                if (!athoc.iws.publishing.settings.IsMassDeviceTargetSupported)
                    return null;

                var devicedata = ko.observableArray();
                
                //create a deep copy of object
                var massdevices = ko.mapping.fromJS(ko.mapping.toJS(athoc.iws.publishing.massdevices.viewModel.massDeviceList()));;
                
                _.each(massdevices(), function (massdevice) {
                    var selectedMassdevice = _.filter(massdevice.DeviceList(), function(selectedDevice) {
                        return selectedDevice.Selected();
                    });
                    _.each(selectedMassdevice, function (device) {
                        var endPointLength = device.EndPoints().length;
                        var deviceusers = ko.observableArray();
                        var keyListDict = athoc.iws.publishing.massdevices.viewModel.keyDict;
                        if (keyListDict) {
                            var enduser = keyListDict[device.DeviceId()];
                            if (enduser){
                                if (enduser.IsTargetable) {
                                    deviceusers.push(ko.mapping.fromJS(enduser));
                                }
                                if (endPointLength === 0) {
                                    device.EndPoints = deviceusers;
                                }
                            }
                        }
                        if (endPointLength == 1) {
                            var endPoint = device.EndPoints()[0];
                            if ((endPoint.IsKeyUser() && endPoint.IsTargetable()) ||
                                endPoint.IsSelected()) {
                                deviceusers.push(endPoint);
                            }
                            if (device.HideMassDeviceUsers() && !endPoint.IsSelected()) {
                                deviceusers.push(endPoint);
                            }
                            device.EndPoints = deviceusers;
                        } else if (endPointLength >= 2) {
                            _.each(device.SelectedUsers(), function(selectedendPoint) {
                                var selectedEndPoint = _.find(device.EndPoints(), function(endPointItem) {
                                    return endPointItem.UserId() === selectedendPoint && !endPointItem.IsKeyUser();
                                });
                                if (selectedEndPoint) {
                                    deviceusers.push(selectedEndPoint);
                                }
                            });
                            device.EndPoints = deviceusers;
                        }
                        devicedata.push(device);
                    });
                });
                var targetlist = athoc.iws.publishing.massdevices.viewModel.targetList = ko.mapping.toJS(devicedata);
                return { MassDevices: targetlist, MassDeviceGroupOptions: this.DeviceGroupOptions }
            },

            bindReadOnlyView: function (data, targetDiv) {
                athoc.iws.publishing.massdevices.massDeviceList.removeAll();
                athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList = ko.mapping.fromJS(athoc.iws.publishing.massdevices.formatMassDeviceList(athoc.iws.publishing.massdevices.filterDataforReadOnly(ko.mapping.fromJS(data))));;
                if (targetDiv[0].id !== "dialogReviewAndPublish") {
                    athoc.iws.publishing.massdevices.viewModel.massDeviceList = athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList;
                }
                ko.cleanNode($(targetDiv).find("#publishing-mass-view").get(0));
                ko.applyBindings(athoc.iws.publishing.massdevices.readOnlyModel, $(targetDiv).find("#publishing-mass-view").get(0));

                if (athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList()[0].DeviceList().length > 0)
                    $(targetDiv).find('#MassDeviceFlatList').show();
                else
                    $(targetDiv).find('#MassDeviceFlatList').hide();
            },

            collapsePanel: function () {
               $('.bucket-toggle h2').bind('click', function (e) {
                    if (e.target.id === "massDeviceOptionsLink") {
                        return;
                    }
                   if (!e.isDefaultPrevented()) {
                       $(this).parent().find('.row').slideToggle(500);
                       $(this).parent().find('.expand-arrow-open').toggle();
                       $(this).parent().find('.expand-arrow-closed').toggle();
                       if ($(this).parent().find('.expand-arrow-open').css("display") === "block") {
                           $("#massDeviceOptionsLink").show();
                       } else {
                           $("#massDeviceOptionsLink").hide();
                       }
                   }
                   e.preventDefault();
                });
               
            },

            refreshMassDevicesList: function (data) {
                var massdevices = ko.mapping.toJS(athoc.iws.publishing.massdevices.viewModel.massDeviceList());
                var url = this.Parameters.getEndPointsURL;
                var deviceColl = [];
                var refreshViewModel = function (datawithendpoints) {
                    athoc.iws.publishing.massdevices.removeKeyUser(datawithendpoints,false);
                    athoc.iws.publishing.massdevices.viewModel.massDeviceList = ko.mapping.fromJS(athoc.iws.publishing.massdevices.formatMassDeviceList(datawithendpoints, true));
                    ko.cleanNode($("#publishing-mass-edit").get(0));
                    ko.applyBindings(athoc.iws.publishing.massdevices.viewModel, $("#publishing-mass-edit").get(0));
                    athoc.iws.publishing.massdevices.viewModel.subscribeEndPoints(athoc.iws.publishing.massdevices.viewModel.massDeviceList);
                    athoc.iws.publishing.massdevices.collapsePanel();
                    athoc.iws.publishing.massdevices.isMassDeviceReady();
                }
                $(data).each(function (item) {
                    var device = null;
                    for (var i = 0; i < massdevices.length; i++) {
                        device = _.find(massdevices[i].DeviceList, function (dev) {
                            return (dev.DeviceId === data[item].DeviceId);
                        });
                        if (device) {
                            data[item].HideMassDeviceUsers = device.HideMassDeviceUsers;
                            data[item].IsAreaRequired = device.IsAreaRequired;
                            athoc.iws.publishing.massdevices.selectedCount++;
                            data[item].Selected = device.Selected;
                            data[item].EndPoints = device.EndPoints;
                            data[item].SelectedUsers = device.SelectedUsers;
                            if (data[item].EndPoints.length == 0) {
                                data[item].Enabled = false;
                            } else {
                                data[item].Enabled = true;
                            }
                            break;
                        }
                    }
                    if (!device) {
                        deviceColl.push(data[item]);
                    }

                });

                if (deviceColl.length > 0) {
                    kendo.ui.progress($("#publishing-mass-edit"), true);

                    $.when(athoc.iws.publishing.massdevices.loadEndPoints(url, deviceColl)).then(function (datawithendpoints) {
                        _.each(datawithendpoints, function (item) {
                            var dev = _.find(data, function (item2) {
                                return item.DeviceId === item2.DeviceId;
                            });
                            dev.Selected = false;
                            dev.EndPoints = item.EndPoints;
                            dev.IsAreaRequired = item.IsAreaRequired;
                            dev.HideMassDeviceUsers = item.HideMassDeviceUsers;
                            if (dev.EndPoints.length == 0) {
                                dev.Enabled = false;
                            } else {
                                dev.Enabled = true;
                            }
                        });
                        refreshViewModel(data);

                        kendo.ui.progress($("#publishing-mass-edit"), true);

                    });
                } else {
                    refreshViewModel(data);
                }
            },

            filterDataforReadOnly: function (data) {
                var filterData = ko.mapping.toJS(data).filter(function (el) {
                    return el.Selected;
                });
                return filterData;
            },

            formatMassDeviceList: function (data, justFormat) {
                var groupList = [];
                var deviceList = [];
                var groupId = 0;
                var groupName = "";
                var filterData = data;
                var skipDevices = false;
                if (justFormat !== undefined) {
                    skipDevices = true;
                }
                $(filterData).each(function (index) {
                   if (groupId != filterData[index].GroupId) {

                        if (deviceList.length > 0) {
                            groupList.push({ GroupId: groupId, GroupName: groupName, DeviceList: deviceList, CustomText: null });
                            deviceList = [];
                        }

                        deviceList.push(filterData[index]);
                        //if (filterData[index].Selected) {
                        if (!skipDevices) {
                            athoc.iws.publishing.massdevices.massDeviceList.push(filterData[index]);
                        }
                        athoc.iws.publishing.massdevices.selectedCount++;
                        //}
                        groupName = filterData[index].GroupName;
                        groupId = filterData[index].GroupId;

                    } else {
                        //if (filterData[index].Selected) {
                        if (!skipDevices) {
                            athoc.iws.publishing.massdevices.massDeviceList.push(filterData[index]);
                        }
                        athoc.iws.publishing.massdevices.selectedCount++;
                        //}

                        deviceList.push(filterData[index]);
                    }

                });
                groupList.push({ GroupId: groupId, GroupName: groupName, DeviceList: deviceList, CustomText: null });
                return groupList;
            },

            readonlyMassDeviceList: function (data) {
                var groupList = [];
                var deviceList = [];
                var groupId = 0;
                var groupName = "";
                var filterData = data;

                $(filterData).each(function (index) {
                    if (groupId != filterData[index].GroupId) {
                        groupId = filterData[index].GroupId;

                        if (deviceList.length > 0) {
                            groupList.push({ GroupId: filterData[index].GroupId, GroupName: groupName, DeviceList: deviceList, CustomText: null });
                            deviceList = [];
                        }

                        deviceList.push(filterData[index]);
                        groupName = filterData[index].GroupName;
                    } else {

                        deviceList.push(filterData[index]);
                    }

                });
                groupList.push({ GroupId: groupId, GroupName: groupName, DeviceList: deviceList, CustomText: null });
                return groupList;

            },

            endPointSelected:function(device,arg) {
                device.EndPoints()[0].IsSelected(arg.originalEvent.target.checked);
                athoc.iws.publishing.massdevices.isMassDeviceReady();
                return true;
            },

            massDeviceChanged: function (device) {
                athoc.iws.publishing.massdevices.isChanged = true;
                var self = this;
                if (device.Selected()) {
                    athoc.iws.publishing.massdevices.massDeviceList.push(ko.mapping.toJS(device));
                    athoc.iws.publishing.massdevices.selectedCount++;

                    $(".alert-nav").attr("disabled", true);
                    kendo.ui.progress($("#alert-mass-edit"), true);

                    var onLoadDone = function (selectedOptions) {

                        kendo.ui.progress($("#alert-mass-edit"), false);
                        $(".alert-nav").attr("disabled", false);
                        athoc.iws.publishing.massdevices.DeviceGroupOptions = selectedOptions;
                    }


                } else {
                    athoc.iws.publishing.massdevices.massDeviceList.remove(function (item) {
                        return item.DeviceId == device.DeviceId();
                    });
                    athoc.iws.publishing.massdevices.selectedCount--;
                }

                var checkedDevices = new Array();
                var mlist = ko.mapping.toJS(athoc.iws.publishing.massdevices.viewModel.massDeviceList);
                for (var i = 0; i < mlist.length; i++) {
                    for (j = 0; j < mlist[i].DeviceList.length; j++) {
                        var device = mlist[i].DeviceList[j];
                        if (device.Selected) {
                            checkedDevices.push(mlist[i].DeviceList[j]);
                        }
                    }
                }

                athoc.iws.publishing.massDeviceOptions.loadOnlyNewDeviceGroups(checkedDevices, onLoadDone);

                $(athoc.iws.publishing.massdevices.Parameters.massDeviceOptionsLink).toggleClass("link-disabled", (checkedDevices.length == 0));

                athoc.iws.publishing.massdevices.isMassDeviceReady();
                return true;
            },
            isAnyMassDeviceSelected: function () {
                var mlist = ko.mapping.toJS(athoc.iws.publishing.massdevices.viewModel.massDeviceList);
                for (var i = 0; i < mlist.length; i++) {
                    for (j = 0; j < mlist[i].DeviceList.length; j++) {
                        var device = mlist[i].DeviceList[j];
                        if (device.Selected) {
                            return true;
                        }
                    }
                }
                return false;

            },
            isMassDeviceReady: function () {
                var notReady = function () {
                    athoc.iws.publishing.massdevices.isReadyToPublish = false;
                    athoc.iws.publishing.massdevices.isInErrorState = true;
                    athoc.iws.publishing.SetSectionStatus("#massDevicesStatus", "notReady");
                };
                var ready = function () {
                    athoc.iws.publishing.massdevices.isReadyToPublish = true;
                    athoc.iws.publishing.massdevices.isInErrorState = false;
                    athoc.iws.publishing.SetSectionStatus("#massDevicesStatus", "ready");
                };
                var open = function () {
                    athoc.iws.publishing.massdevices.isReadyToPublish = false;
                    athoc.iws.publishing.massdevices.isInErrorState = false;
                    athoc.iws.publishing.SetSectionStatus("#massDevicesStatus", "open");
                };
                var massDeviceModel = athoc.iws.publishing.massdevices.getModel();
                if (massDeviceModel && massDeviceModel.MassDevices && massDeviceModel.MassDevices.length > 0) {
                    var selectedDevices = $.grep(massDeviceModel.MassDevices, function (device) {
                        return device.Selected;
                    });
                    if (selectedDevices.length == 0) {
                        open();
                    } else {
                        ready();
                    }
                    _.each(massDeviceModel.MassDevices, function (device) {
                        if (!device.EndPoints || device.EndPoints.length == 0) {
                            notReady();
                        }
                        if (device.IsAreaRequired)
                            if (!athoc.iws.publishing.massdevices.isLocationPresent()) {
                                notReady();
                            }
                    });
                } else {
                    open();
                }
            },

            handleError: function (e) {
                if (e != undefined && e.status == 401) {
                    window.onbeforeunload = null;
                    window.location = window.location;
                } else {
                    $('#listMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                }
            },
            targetKeyUser: function (groupid, select, elementId) {
                var massdevices = athoc.iws.publishing.massdevices.viewModel.massDeviceList();
                var keyListDict = athoc.iws.publishing.massdevices.viewModel.keyDict;
                var endPointFound = false;
                for (var i = 0; i < massdevices.length; i++) {
                    var massdevice = massdevices[i];
                    for (var j = 0; j < massdevice.DeviceList().length; j++) {
                        var device = massdevice.DeviceList()[j];
                        if (groupid === device.GroupId()) {
                            if (keyListDict) {
                                var keyuser = keyListDict[device.DeviceId()];

                                if (keyuser) {
                                    if (select) {

                                        if (typeof elementId != "undefined") //must apply targeting not allowed changes 
                                        {

                                            var className = $('select[id^="' + $("input:radio[name='" + elementId + "']:checked").attr("id") + '"]').find("option:selected").attr("class");
                                            if (className == "MSG-TARGETING-NOT-ALLOWED") {
                                                //if ($('[name="' + elementId + '"]').find(":selected").attr("class") == "MSG-TARGETING-NOT-ALLOWED") {
                                                //$("input:radio[name='" + elementId + "']:checked")
                                                //unselect all of the non-key users
                                                device.SelectedUsers([]);

                                                //disable dropdown
                                                if ($("[deviceidentifier='" + device.DeviceId() + "']").find(".nonKeyUserCB").length !=0)
												{
													$("[deviceidentifier='" + device.DeviceId() + "']").find(".nonKeyUserCB").prop("disabled", true);
													device.EndPoints()[0].IsSelected(false); //uncheck checkbox
												}
												

                                                $("[deviceidentifier='" + device.DeviceId() + "']").find(".show-tick").css('pointer-events', 'none');
                                                //$("[deviceidentifier='" + device.DeviceId() + "']").find("select").attr("disabled", true);
                                                //$("[deviceidentifier='" + device.DeviceId() + "']").find("select").selectpicker('refresh');
                                                $("[deviceidentifier='" + device.DeviceId() + "']").find("button").prop("disabled", true)


                                            } else {
                                                //enble dropdown
                                                
                                                //$("[deviceidentifier='" + device.DeviceId() + "']").find("select").attr("disabled", false);
												if ($("[deviceidentifier='" + device.DeviceId() + "']").find(".nonKeyUserCB").length !=0)
												{
													$("[deviceidentifier='" + device.DeviceId() + "']").find(".nonKeyUserCB").prop("disabled", false);

												}
                                                //$("[deviceidentifier='" + device.DeviceId() + "']").find("select").selectpicker('refresh');
                                                $("[deviceidentifier='" + device.DeviceId() + "']").find("button").prop("disabled", false);
                                                $("[deviceidentifier='" + device.DeviceId() + "']").find(".show-tick").css('pointer-events', '');


                                            }
                                        } 

                                        keyuser.IsTargetable = true;
                                    } else {
                                        keyuser.IsTargetable = false;
                                        if (typeof elementId != "undefined") //must apply targeting not allowed changes 
                                        {
                                            //enble dropdown
											if ($("[deviceidentifier='" + device.DeviceId() + "']").find(".nonKeyUserCB").length !=0)
											{
												$("[deviceidentifier='" + device.DeviceId() + "']").find(".nonKeyUserCB").prop("disabled", false);
											}
                                            //$("[deviceidentifier='" + device.DeviceId() + "']").find("select").attr("disabled", false);
                                            //$("[deviceidentifier='" + device.DeviceId() + "']").find("select").selectpicker('refresh');
                                            $("[deviceidentifier='" + device.DeviceId() + "']").find("button").prop("disabled", false);
                                            $("[deviceidentifier='" + device.DeviceId() + "']").find(".show-tick").css('pointer-events', '');




                                        }
                                    }
                                    endPointFound = true;
                                    break;
                                }
                            }
                        }
                    }
                    if (endPointFound) {
                        athoc.iws.publishing.massdevices.isMassDeviceReady();
                        break;
                    }
                }
            },
            IsThisDeviceGroupTargeted: function (groupid) {
                var massdevices = ko.mapping.toJS(athoc.iws.publishing.massdevices.viewModel.massDeviceList());
                var targeted = false;


                _.each(massdevices, function (group) {

                    _.each(group.DeviceList, function (dev) {
                        if (dev.GroupId == groupid && dev.Selected) {
                            targeted = true;
                        }
                    });

                });
                return targeted;
            }

        };
    }();
}
///#source 1 1 /Scripts/Publishing/athoc.iws.alert.reviewandpublish.js
/// <reference path="athoc.iws.alert.reviewandpublish.js" />
/* define javascript namespace for Test Alert  */
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.alert = athoc.iws.alert || {};
if (athoc.iws.alert) {
    athoc.iws.alert.reviewandpublish = function () {
        //
        var extraSpaceAddBlock = 55;
        return {
            //is model changed
            //id for deeplinking
            Sessionid: 0,
            ReachableUsers: ko.observable(0),
            ReachableUsersPercentage: ko.observable(0),
            UnReachableUsers: ko.observable(0),
            UnReachableUsersPercentage: ko.observable(0),
            readOnlyMap: null,
            //called when new data will be available for this section for binding
            load: function () {

            },

            showModalonModal: function (targetDiv) {
                $(targetDiv).css({ display: 'block' });
                //$(targetDiv).addClass('width600');
                $(targetDiv).modal().css(
                   {
                       'z-index': '999999',
                       'margin-top': '-299px',

                   });
                $("#dialogReviewAndPublish").append('<div id="displayShadowRP" class="modal-backdrop fade in"></div>');
                $(targetDiv).on('hidden.bs.modal', function () {
                    $("#dialogReviewAndPublish").find('#displayShadowRP').remove();
                })
                this.resizeModalBasedOnScreen($(targetDiv));

                if (targetDiv == "#dialogGeoPublish") {
                    this.loadMap($(targetDiv));
                    $(targetDiv).modal().css(
                   {
                       'z-index': '999999',
                       'margin-left': '-491px',
                       'margin-top': '-204px',

                   });
                }

            },
            loadMap: function (targetDiv) {
                //removed the event listener here. Keep in mind, event listener should always call once.
                //require(["maps/MiniMap"], function (MiniMap) {
                //    $('#dialogGeoPublish').on('shown.bs.modal', function () {
                //        if (!athoc.iws.alert.reviewandpublish.readOnlyMap) {
                //            athoc.iws.alert.reviewandpublish.readOnlyMap = new MiniMap({ width: 980, height: 300 }, "dialogGeoPublishContent");
                //        }
                //        var geoJson = JSON.parse(athoc.iws.publishing.view.viewModel.data.Content.LocationGeo());
                //        athoc.iws.alert.reviewandpublish.readOnlyMap.restore(geoJson);

                //        setTimeout(function () {
                //            athoc.iws.alert.reviewandpublish.readOnlyMap.resize();
                //            athoc.iws.alert.reviewandpublish.readOnlyMap.zoomToFit();
                //        }, 500);
                //    });
                //});

            },
            resizeModalBasedOnScreen: function (modal) {

                if (modal.attr("id") == "ReadOnlyUserList") return;
                modal.css("margin-left", (($(window).width() / 2) - (modal.width() / 2)) - $(window).width() / 2);


                modal.find(".modal-body").css("max-height", 500);

                var windowHeight = $(window).height();

                if (windowHeight > 770) {
                    modal.css("margin-top", 80 - (windowHeight / 2) + ((windowHeight - 770) / 2));
                    modal.find(".modal-body").css("height", windowHeight - 340);
                } else {
                    modal.css("margin-top", 20 - (windowHeight / 2));
                    modal.find(".modal-body").css("height", windowHeight - 120);
                }

                if (modal.height() + 170 > windowHeight) {
                    var newHeight = windowHeight - 170;
                    modal.find(".modal-body").css("max-height", newHeight);
                }

                if (modal.attr("id") == "recordedMessageModal") {
                    modal.css({ "top": '40%', "margin-top": "0px" });
                    //modal.css("margin-top", (modal.height() + 100) - (windowHeight / 2));
                    modal.find(".modal-body").css({"height":"31px", "overflow-y":"hidden"});
                    //modal.find(".modal-body").css("max-height", 15);
                }

            },

            showTargetedUsersSummary: function () {
                var windowHeight = $("#targetedUsersSummaryRP .modal-body").height();
                var sortState = '';
                var dataTb = [];
                var usersList = athoc.iws.publishing.view.viewModel.TargetedBlockerUsersList;
                $.grep(usersList == undefined ? athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList() : usersList, function (i) {
                    if (!i.IsBlocked)
                        dataTb.push({ IsBlocked: i.IsBlocked, Name: i.Name, UserId: i.UserId });
                });

                dataTb.sort(function (l, r) { return [l.IsBlocked, l.Name.toLowerCase()] < [r.IsBlocked, r.Name.toLowerCase()] ? -1 : 1 })
                var datasourcetbu = new kendo.data.DataSource({
                    data: dataTb,
                    pageSize: 50,
                    change: function (e) {
                        var newState = JSON.stringify(this.sort());
                        if (newState != sortState) {
                            sortState = newState;
                            e.preventDefault();
                            this.page(1);
                        }

                    }
                });
                //datasource.read();
                var cntrl = $("#targetedUsersSummaryDetailRP");
                var grid = cntrl.kendoGrid({
                    dataSource: datasourcetbu,
                    selectable: false,
                    scrollable: true,
                    sortable: { allowUnsort: false },
                    height: windowHeight,
                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5,
                        messages: {
                            display: $.htmlDecode(athoc.iws.publishing.iut.resources.IUTAllUsers_PagingInfo),
                            empty: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Empty),
                            itemsPerPage: $.htmlDecode(athoc.iws.publishing.iut.resources.IUT_ItemsPerPage),
                            first: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                            previous: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                            next: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                            last: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                        }
                    },
                    columns:
                            [
                                 {
                                     field: "Name",
                                     title: athoc.iws.publishing.iut.resources.IUTTargetedSummary_Name,
                                     template: '<span title="#=Name#">#=Name#</span>',
                                     width: "95%",
                                     headerAttributes: {
                                         tabindex: "3"
                                     },
                                     headerTemplate: '<span style="color:black;font-weight:bold;font-size:16px">' + athoc.iws.publishing.iut.resources.IUTTargetedSummary_Name + '</span>'
                                 },
                            ],
                    change: function (e) {
                    }
                }).data().kendoGrid;
                grid.refresh();
                this.OverrideCssPropertyForPopup(cntrl);
            },

            showBlockedUsersSummary: function () {
                var windowHeight = $("#targetedUsersSummaryRP .modal-body").height();
                var dataTb = [];
                var sortState = '';
                var usersList = athoc.iws.publishing.view.viewModel.TargetedBlockerUsersList;
                $.grep(usersList == undefined ? athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList() : usersList, function (i) {
                    if (i.IsBlocked)
                        dataTb.push({ IsBlocked: i.IsBlocked, Name: i.Name, UserId: i.UserId });
                });
                dataTb.sort(function (l, r) { return [l.IsBlocked, l.Name.toLowerCase()] < [r.IsBlocked, r.Name.toLowerCase()] ? -1 : 1 })
                var datasourcetbu = new kendo.data.DataSource({
                    data: dataTb,
                    pageSize: 50,
                    change: function (e) {
                        var newState = JSON.stringify(this.sort());
                        if (newState != sortState) {
                            sortState = newState;
                            e.preventDefault();
                            this.page(1);
                        }

                    }
                });

                //datasource.read();
                var cntrl = $("#targetedUsersSummaryDetailRP")
                var grid = cntrl.kendoGrid({
                    dataSource: datasourcetbu,
                    selectable: false,
                    scrollable: true,
                    sortable: { allowUnsort: false },
                    height: windowHeight,
                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5,
                        messages: {
                            display: $.htmlDecode(athoc.iws.publishing.iut.resources.IUTAllUsers_PagingInfo),
                            empty: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Empty),
                            itemsPerPage: $.htmlDecode(athoc.iws.publishing.iut.resources.IUT_ItemsPerPage),
                            first: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                            previous: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                            next: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                            last: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                        }
                    },
                    columns:
                            [
                                 {
                                     field: "Name",
                                     title: athoc.iws.publishing.iut.resources.IUTTargetedSummary_Name,
                                     template: '<span title="#=Name#">#=Name#</span>',
                                     width: "95%",
                                     headerAttributes: {
                                         tabindex: "3"
                                     },
                                     headerTemplate: '<span style="color:black;font-weight:bold;font-size:16px">' + athoc.iws.publishing.iut.resources.IUTTargetedSummary_Name + '</span>'
                                 },
                            ],
                    change: function (e) {
                    }
                }).data().kendoGrid;
                this.OverrideCssPropertyForPopup(cntrl);
            },


            OverrideCssPropertyForPopup: function (popupDivStr) {
                popupDivStr.find(".k-grid-header").css("margin-left", 0);
                popupDivStr.find(".k-grid-header").css("border", 1);
                popupDivStr.parent().parent().css('overflow-y', 'hidden');
                popupDivStr.find(".k-grid-header-wrap").css("width", 718);
                if (athoc.iws.publishing.source == "h") {
                    popupDivStr.find(".k-grid-header-wrap").css("border-bottom-width", 1);
                }
                else {
                    var existingStyle = popupDivStr.find(".k-grid-content").attr("style");
                    popupDivStr.find(".k-grid-content").attr("style", "overflow-y:auto !important" + ";" + existingStyle);
                }
            },

            TargetedGroupsFormatted: function () {
                var tg = this.TargetedGroups();
                return this._formatGroups(tg);
            },

            TargetedGroups: function () {
                if (athoc.iws.publishing.source == "a") {
                    var nodes = ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetingNodes == undefined ? athoc.iws.publishing.targetUsers.targetGroupInstance.ViewModel.SelectedNodes : athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetingNodes);
                    return $.grep(nodes, function (i) {
                        return !i.IsBlocked;
                    });
                }
                else
                    return tg = this.selectedNodes(ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetingNodes()));
            },

            BlockedGroups: function () {
                if (athoc.iws.publishing.source == "a") {
                    var nodes = ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetingNodes == undefined ? athoc.iws.publishing.targetUsers.targetGroupInstance.ViewModel.SelectedNodes : athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetingNodes);
                    return $.grep(nodes, function (i) {
                        return i.IsBlocked;
                    });
                }
                else
                    return tg = this.blockedNodes(ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetingNodes()));
            },

            BlockedGroupsFormatted: function () {
                var bg = this.BlockedGroups();
                return this._formatGroups(bg);
            },

            _formatGroups: function (groups) {
                var x = {};
                var nodes = groups;// this.get("SelectedNodes");
                for (var i = 0; i < nodes.length; ++i) {
                    var n = nodes[i];
                    switch (n.Type) {
                        case 0:
                        case 1:
                        case 3:
                            if (x[n.Name] == undefined)
                                x[n.Name] = [];
                            x[n.Name].push({ Type: n.Type, Item: athoc.iws.publishing.resources.Publishing_TargetUsers_All_Selected });
                            break;
                        case 2:
                            if (x[n.ParentName] == undefined)
                                x[n.ParentName] = [];
                            x[n.ParentName].push({ Type: n.Type, Item: (n.Name != null ? n.Name : "null") });
                            break;
                        case 4:
                        case 5:
                            if (x[n.RootName] == undefined) {
                                x[n.RootName] = [];
                            }
                            if (n.Type == 5) {
                                x[n.RootName].push({ Type: n.Type, Item: (n.Name != null ? n.Name : "null") });
                            } else {
                                if (n.Lineage) {
                                    x[n.RootName].push({ Type: n.Type, Item: kendo.format("{0}{1}/", n.Lineage, (n.Name != null ? n.Name : "null")) });
                                } else {
                                    x[n.RootName].push({ Type: n.Type, Item: kendo.format(n.Type == 4 ? "{0}" : "/{0}/", (n.Name != null ? n.Name : "null")) }); //loading on review/publish
                                }
                            }
                            break;
                    }
                }
                var ret = Object.keys(x).map(function (k) {
                    return { Group: k, Items: x[k], Type: x[k][0] != undefined ? x[k][0].Type : -1 }
                });
                return ret;

            },

            GetReachableUserList: function () {
                this.LaunchContactInfoUserList(1);
            },

            GetUnReachableUserList: function () {
                this.LaunchContactInfoUserList(0);
            },
            LaunchContactInfoUserList: function (covered) {
                var checkedDevices = null;
                checkedDevices = ko.mapping.toJS(athoc.iws.publishing.view.viewModel.personalDeviceList.Devices()).map(function (item) { return item.DeviceId; });

                //workaround due to pie chart uses following model
                athoc.iws.publishing.targetUsers.ReadonlyviewModel.Devices = ko.mapping.fromJS(athoc.iws.publishing.view.viewModel.personalDeviceList.Devices);

                var attributeIdCSV = checkedDevices.join(",");
                //to show readOnlyUserList
                if (covered == 1)
                    $("#readOnlyUserListTitle").html(athoc.iws.publishing.resources.Publishing_TargetUsers_Reachable_Users + " (" + this.ReachableUsers() + ")");
                else
                    $("#readOnlyUserListTitle").html(athoc.iws.publishing.resources.Publishing_TargetUsers_Unreachable_Users +" (" + this.UnReachableUsers() + ")");

                $("#txtReadOnlySearch").keyup(function (e) {
                    $("#btn_readonlyusersearch").removeAttr('disabled');
                    if ($.hotkeys.enter(e)) {
                        athoc.iws.publishing.iut.createReadOnlyUserList();
                    }
                });

                $("#btn_readonlyusersearch").click(function () {
                    athoc.iws.publishing.iut.createReadOnlyUserList();
                });

                this.ShowUsersList(athoc.iws.alert.reviewandpublish.SessionId, covered, "", covered == 1 ? this.ReachableUsers() : this.UnReachableUsers());
            },

            ShowUsersList: function (sessionId, covered, attributeCSV, totalCount) {
                athoc.iws.publishing.iut.readOnlyInputParameters.sessionId(sessionId);
                athoc.iws.publishing.iut.readOnlyInputParameters.covered(covered);
                athoc.iws.publishing.iut.readOnlyInputParameters.attributeCSV(attributeCSV);
                athoc.iws.publishing.iut.readOnlyInputParameters.totalCount(totalCount);
                $("#txtReadOnlySearch").val('');
                //$("#btn_readonlyusersearch").attr('disabled', true);
                this.showModalonModal("#ReadOnlyUserList");
                this.resizeReadonlyModalBasedOnScreen($('#ReadOnlyUserList'));
                $('#ReadOnlyUserList').removeClass("width600");
                $("#dialogReviewAndPublish").append('<div id="displayShadowRP" class="modal-backdrop fade in" style="background:url(../Images/overlay-light-grey.png) 0 0 repeat;width:100%;height:100%"></div>');
                $('#ReadOnlyUserList').on('hidden.bs.modal', function () {
                    $("#dialogReviewAndPublish").find('#displayShadowRP').remove();
                })
                athoc.iws.publishing.iut.createReadOnlyUserList();
                if (athoc.iws.publishing.source == 'a') {
                    $("#dialogReviewAndPublish").find("#ReadOnlyUserList").html($('#ReadOnlyUserList').get(0));
                }
                //$("#showUserlistInRP").find("#readonlyUserList").attr("style", "top:10px;left:0px");
                $("body").click(function () {
                    athoc.iws.publishing.iut.hideAddColumns();
                    $("#contextDropdown").hide();

                });
                //this.fitHeightReadOnlyList();
            },
            fitHeightReadOnlyList: function () {
                var extraSpace = 118;
                var windowHeight = $(window).height();
                if (windowHeight > 770) {

                    extraSpace = 138;
                    $("#showUserlistInRP").find("#readonlyUserList").css("height", windowHeight - 355 - extraSpace);
                    $("#showUserlistInRP").find("#readonlyUserList .k-grid-content").css("height", windowHeight - 460 - extraSpace);
                }
                else {
                    $("#showUserlistInRP").find("#readonlyUserList").css("height", windowHeight - 228 - extraSpace);
                    $("#showUserlistInRP").find("#readonlyUserList .k-grid-content").css("height", windowHeight - extraSpace - extraSpace);

                }
                var gridStyle = $("#readonlyUserList .k-grid-content")[0];
                var grid = $("#readonlyUserList").data("kendoGrid");
                /*if (gridStyle.scrollHeight > gridStyle.clientHeight)
                    grid.showColumn(grid.columns.length - 1);
                else
                    grid.hideColumn(grid.columns.length - 1);*/

            },
            resizeReadonlyModalBasedOnScreen: function (modal) {

                modal.find(".modal-body").css("max-height", 600);
                var windowHeight = $(window).height();

                if (windowHeight > 770) {
                    modal.css("margin-top", 40 - (windowHeight / 2) + ((windowHeight - 770) / 2));
                    modal.find(".modal-body").css("height", windowHeight - 340);
                } else {
                    modal.css("margin-top", 40 - (windowHeight / 2));
                    modal.find(".modal-body").css("height", windowHeight - 240);
                }

                if (modal.height() + 170 > windowHeight) {
                    var newHeight = windowHeight - 170;
                    modal.find(".modal-body").css("max-height", newHeight);

                }
            },

            selectedNodes: function (treeNodes) {
                var selectedNodes = [];
                var nodes = treeNodes.length;
                for (var i = 0; i < nodes; i++) {
                    if (treeNodes[i].Selected && !treeNodes[i].IsBlocked) {

                        if (treeNodes[i].Type == 2)
                            selectedNodes.push({
                                Id: treeNodes[i].Id,
                                Name: treeNodes[i].Name,
                                Type: treeNodes[i].Type,
                                Lineage: treeNodes[i].Lineage,
                                SubType: treeNodes[i].SubType,
                                DlType: treeNodes[i].DlType,
                                RootName: treeNodes[i].RootName,
                                ParentName: treeNodes[i].ParentName,

                            });

                        else
                            selectedNodes.push({
                                Id: treeNodes[i].Id,
                                Name: treeNodes[i].Name,
                                Type: treeNodes[i].Type,
                                Lineage: treeNodes[i].Lineage,
                                SubType: treeNodes[i].SubType,
                                DlType: treeNodes[i].DlType,
                                RootName: treeNodes[i].RootName,

                            });
                    }
                    if (treeNodes[i].HasChildren) {
                        for (var j = 0; j < treeNodes[i].Children.length; j++) {
                            if (treeNodes[i].Children[j].Selected && !treeNodes[i].Children[j].IsBlocked) {
                                selectedNodes.push({
                                    Id: treeNodes[i].Children[j].Id,
                                    Name: treeNodes[i].Children[j].Name,
                                    Type: treeNodes[i].Children[j].Type,
                                    RootId: treeNodes[i].Id,
                                    RootName: treeNodes[i].Name,
                                    Lineage: treeNodes[i].Children[j].Lineage,
                                    SubType: treeNodes[i].Children[j].SubType,
                                    DlType: treeNodes[i].Children[j].DlType,
                                });
                            }
                        }
                    }
                }
                return selectedNodes;
            },

            blockedNodes: function (treeNodes) {
                var selectedNodes = [];
                var nodes = treeNodes.length;
                for (var i = 0; i < nodes; i++) {
                    if (treeNodes[i].IsBlocked) {
                        if (treeNodes[i].Type == 2)
                            selectedNodes.push({
                                Id: treeNodes[i].Id,
                                Name: treeNodes[i].Name,
                                Type: treeNodes[i].Type,
                                Lineage: treeNodes[i].Lineage,
                                SubType: treeNodes[i].SubType,
                                DlType: treeNodes[i].DlType,
                                RootName: treeNodes[i].RootName,
                                ParentName: treeNodes[i].ParentName,

                            });

                        else
                            selectedNodes.push({
                                Id: treeNodes[i].Id,
                                Name: treeNodes[i].Name,
                                Type: treeNodes[i].Type,
                                Lineage: treeNodes[i].Lineage,
                                SubType: treeNodes[i].SubType,
                                DlType: treeNodes[i].DlType,
                                RootName: treeNodes[i].RootName,

                            });
                    }
                    if (treeNodes[i].HasChildren) {
                        for (var j = 0; j < treeNodes[i].Children.length; j++) {
                            if (treeNodes[i].Children[j].IsBlocked) {
                                selectedNodes.push({
                                    Id: treeNodes[i].Children[j].Id,
                                    Name: treeNodes[i].Children[j].Name,
                                    Type: treeNodes[i].Children[j].Type,
                                    RootId: treeNodes[i].Id,
                                    RootName: treeNodes[i].Name,
                                    Lineage: treeNodes[i].Children[j].Lineag,
                                    SubType: treeNodes[i].Children[j].SubType,
                                    DlType: treeNodes[i].Children[j].DlType,
                                });
                            }
                        }
                    }
                }
                return selectedNodes;
            },


        };



    }();
}

///#source 1 1 /Scripts/Publishing/athoc.iws.publishing.iut.js
/* define javascript namespace for IUT = Individual User Targeting */
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};
if (athoc.iws.publishing) {
    athoc.iws.publishing.iut = function () {
        //
        var extraSpaceAddBlock = 55;
        var userCountType = 0;
        var operatorRoleColumn = "OPERATOR-ROLES";
        return {
            viewModel: {
                targetedBlockerUsersList: ko.observableArray(),
                targetedBlockerUsers: ko.observableArray(),
                allAvailableUser: ko.observableArray(),
                status: ko.observable('ready'),
                targetedCnt: ko.observable(0),
                blockedCnt: ko.observable(0),
            },

            readOnlyInputParameters:
                {
                    sessionId: ko.observable(0),
                    covered: ko.observable(0),
                    attributeCSV: ko.observable(""),
                    totalCount: ko.observable(0),
                },
            //is model changed
            isChanged: false,
            IsRefered: false,
            rowsObject: [],
            reportCols: [],
            readOnlyDatasource: null,
            readOnlyDatasourcetemp: null,
            columnDefs: null,
            gridColumnDefs: null,
            allUsersgrid: null,
            allUserDatasource: null,
            userInfo: null,
            allUserSortColumn: 'DisplayName',
            allUserSortOrder: 'asc',
            allUserSortField: '_DISPLAYNAME',
            readOnlySortColumn: '',
            readOnlySortOrder: '',
            readOnlySortField: '_LOGIN_ID',
            allUsersPageSize: 50,
            targetBlockSort: 'asc',
            targetBlockPageSize: 50,
            searchString: [],
            newlyaddedColumns: [],
            errors: null,
            firstTimeOpenAddUser: 0,
            firstTimeReachableUser: 0,
            //this method will be called when new data will be available for this section for binding

            bind: function (data) {
                if (athoc.iws.publishing && athoc.iws.publishing.iut && athoc.iws.publishing.iut.newlyaddedColumns != null)
                    athoc.iws.publishing.iut.newlyaddedColumns.length = 0;

                //try to bind only if IUT is enabled (affiliate/non-affiliate)
                if ($("#targetBlockingList").length == 0)
                    return;
                athoc.iws.publishing.iut.viewModel.targetedBlockerUsers(data);
                // dataobject for maniplication
                athoc.iws.publishing.iut.createTargettingUserListGrid(data);

                $('#targetBlockingList .k-grid-header').hide();
                $('#targetBlockingList .k-pager-wrap').hide();
            },

            load: function () {

              
                    require(["widget/UserInfo"], function(UserInfo) {
                        athoc.iws.publishing.iut.userInfo = new UserInfo("alertinguserInfoHolder", "#userInfoModalBody");
                        athoc.iws.publishing.iut.userInfo.startup();
                    });
                
                ko.cleanNode($("#AddBlockUsers").get(0));
                ko.applyBindings(athoc.iws.publishing.iut.viewModel, $("#AddBlockUsers").get(0));


                $("#ddlAlertHr").selectpicker();
                $("#ddlAlertMin").selectpicker();
                $("#ddlAlertMer").selectpicker();
                $("#ddlAlertDurationHours").selectpicker();


                // to remove the column from the available users list
                /*$('#allUserList').on('click', '.remove-column', function (event) {
                    event.preventDefault();
                    athoc.iws.publishing.iut.updateGridColumn(this.parentNode.getAttribute("viewid"), this.parentNode.getAttribute("Id"),
                       "remove",
                       this.parentNode.getAttribute("customviewcolumntype"),
                       this.parentNode.getAttribute("key"),
                       function () {
                           //$.AjaxLoader.hideLoader();
                       });
                });*/
                //
                $("#txtReadOnlySearch").keyup(function (e) {
                    $("#btn_readonlyusersearch").removeAttr('disabled');
                    if ($.hotkeys.enter(e)) {
                        $('#pillContainer').show();
                        athoc.iws.publishing.iut.createReadOnlyUserList();
                    }

                });
                //
                $("#btn_readonlyusersearch").click(function () {
                    $('#pillContainer').show();
                    athoc.iws.publishing.iut.createReadOnlyUserList();
                });
                //
                $("#txtAllUserSearch").keyup(function (e) {

                    var seaString = $.trim($('#txtAllUserSearch').val());
                    if ($.hotkeys.enter(e) && seaString != "") {
                        $('#pillContainer').show();
                        athoc.iws.publishing.iut.createPills(seaString, "SIMPLESEARCH", $('#txtAllUserSearch').val());
                        //athoc.iws.publishing.iut.createAddBlockUsersGrid();
                        $('#txtAllUserSearch').val('');
                    }
                    if (seaString.length > 0) {
                        $("#btn_userSearch").removeAttr('disabled');
                    }
                });
                $("#btn_readonlyclearall").click(function () {
                    $("#txtReadOnlySearch").val("");
                    $('#pillContainer').hide();
                    athoc.iws.publishing.iut.createReadOnlyUserList();
                    $("#btn_readonlyusersearch").attr('disabled', true);
                    athoc.iws.publishing.iut.hideAddColumns();
                });
                //
                $("#btn_userSearch").click(function () {
                    if ($.trim($('#txtAllUserSearch').val()).length > 0) {
                        athoc.iws.publishing.iut.createPills($('#txtAllUserSearch').val(), "SIMPLESEARCH", $('#txtAllUserSearch').val());
                        $('#pillContainer').show();
                    }
                });
                //                
                $("#clearAllBtn").click(function () {
                    athoc.iws.publishing.iut.clearAllTargetedBlockedUsersPopUp();
                    $('#pillContainer').hide();
                });

                $("#btn_Apply").click(function () {
                    athoc.iws.publishing.iut.applyChangesToList();
                });

                $("body").click(function () {
                    athoc.iws.publishing.iut.hideAddColumns();
                    $("#contextDropdown").hide();

                });
            },
            userListRemoveColumn: function (event) {
                event.preventDefault();
                athoc.iws.publishing.iut.updateGridColumn(event.currentTarget.parentNode.getAttribute("viewid"), event.currentTarget.parentNode.getAttribute("Id"),
                   "remove",
                   event.currentTarget.parentNode.getAttribute("customviewcolumntype"),
                   event.currentTarget.parentNode.getAttribute("key"),
                   function () {
                       //$.AjaxLoader.hideLoader();
                   });
            },
            // to remove the column from the read only  userlist
            readonlyUserlistRemoveColumn: function (event) {
                event.preventDefault();
                //this.parentNode.parentNode.getAttribute("viewid")
                name = event.target.getAttribute("Key");
                var cList = ko.mapping.toJS(athoc.iws.publishing.iut.newlyaddedColumns).filter(function (i) {
                    return i.Key != name;
                })
                athoc.iws.publishing.iut.newlyaddedColumns = cList;
                if (athoc.iws.publishing.iut.readOnlySortColumn == name) {
                    athoc.iws.publishing.iut.readOnlySortColumn = "USERNAME";
                    athoc.iws.publishing.iut.readOnlySortOrder = "ASC";
                }
                athoc.iws.publishing.iut.createReadOnlyUserList();

                //athoc.iws.publishing.iut.updateReportViewColumn(this.parentNode.getAttribute("viewid"), this.parentNode.getAttribute("id"),
                //   "remove",
                //   "",
                //    "",
                //   function () {
                //       //$.AjaxLoader.hideLoader();
                //   });
            },

            //
            createTargettingUserListGrid: function (data) {
                var tbData = [];
                tbData = new kendo.data.DataSource({
                    data: data,
                });

                //datasource.read();
                var grid = $("#targetBlockingList").kendoGrid({
                    dataSource: tbData,
                    selectable: false,
                    sortable: {
                        allowUnsort: false
                    },
                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5,
                        messages: {
                            display: $.htmlDecode(athoc.iws.publishing.iut.resources.IUTAllUsers_PagingInfo),
                            empty: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Empty),
                            itemsPerPage: $.htmlDecode(athoc.iws.publishing.iut.resources.IUT_ItemsPerPage),
                            first: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                            previous: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                            next: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                            last: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                        }
                    },
                    columns:
                            [

                                 {
                                     field: "",
                                     title: "",
                                     template: $("#targeting-imgtargeting-template").html(),
                                     headerTemplate: kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', "Users", ""),
                                     width: 10,
                                     headerAttributes: {
                                         tabindex: "3"
                                     }
                                 },
                                {
                                    field: "Name",
                                    title: "",
                                    template: $("#targeting-name-template").html(),
                                    headerTemplate: kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', "Name", ""),
                                    width: 130,
                                    headerAttributes: {
                                        tabindex: "3"
                                    }
                                },
                                {
                                    field: "",
                                    title: "",
                                    template: $("#targeting-imgremove-template").html(),
                                    headerTemplate: kendo.format('<span title="{0}">{1}</span>', "", ""),
                                    width: 10,
                                    headerAttributes: {
                                        tabindex: "5"
                                    }
                                },
                            ],
                    dataBound: athoc.iws.publishing.iut.OnDataBound,
                    change: function (e) {
                        var model = this.dataItem(this.select());
                        this.select().removeClass("k-state-selected");

                    }
                }).data().kendoGrid;

                grid.dataSource.pageSize(grid.dataSource.total());
                athoc.iws.publishing.iut.updateChangesToSummaryAndChart();
                $("#TargetedUsers").html(athoc.iws.publishing.iut.viewModel.targetedBlockerUsers().length);
            },

            //
            UserToolTip: function (model) {

                $.ajax({
                    url: athoc.iws.publishing.urls.GetUserDetailsUrl,
                    type: 'POST',

                    data: {
                        Id: model.UserId
                    },
                    cache: false,
                    async: true,
                    success: function (result) {
                        athoc.iws.publishing.iut.IsRefered = false;
                        result = result.replace(" alt='Close'", " alt='Close' style='display:none' ");

                        // $("#userInfoModal").html(result);
                        var tooltip = $("#readonlyUserList").kendoTooltip({
                            filter: "closeImg",
                            autoHide: false,
                            content: result,
                            position: "right",

                        }).data("kendoTooltip").show($("#readonlyUserList"));

                    },
                });
            },

            //
            removeUserId: function (userId) {
                var raw = $("#targetBlockingList").data("kendoGrid").dataSource.data();
                var length = raw.length;

                var item, i;
                for (i = length - 1; i >= 0; i--) {
                    if (raw[i].UserId == userId) {
                        item = raw[i];
                        $("#targetBlockingList").data("kendoGrid").dataSource.remove(item);
                        break;
                    }

                }
                if (item != undefined) {
                    $("#targetBlockingList").data("kendoGrid").refresh();
                }
                athoc.iws.publishing.iut.updateChangesToSummaryAndChart();
                var current = athoc.iws.publishing.content;
                current.isChanged = true;
                athoc.iws.publishing.targetUsers.targetingChanged();
            },

            OnBoundEmptyRow: function (data) {
                var colCount = $("#targetBlockingList").find('.k-grid-header colgroup > col').length;
                if (data.length == 0) {
                    $("#targetBlockingList").find('.k-grid-content tbody')
                        .append('<tr class="kendo-data-row"><td colspan="' +
                            colCount +
                            '" style="text-align:left;height:10px;overflow:auto; cursor:default; background-color:#fff">' +
                            kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', "", athoc.iws.publishing.iut.resources.IUTTargeted_Blocked_Emptyrow_Message) +
                            '</td></tr>');
                }
            },

            //
            OnBoundReadonlyEmptyRow: function (data) {
                var colCount = $("#readonlyUserList").find('.k-grid-header colgroup > col').length;
                if (data.length == 0) {
                    $("#readonlyUserList").find('.k-grid-content tbody')
                        .append('<tr class="kendo-data-row"><td colspan="' +
                            colCount +
                            '" style="text-align:center;height:10px;overflow:auto;">' +
                            kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', athoc.iws.publishing.iut.resources.IUTReadOnly_Emptyrow_Message, athoc.iws.publishing.iut.resources.IUTReadOnly_Emptyrow_Message) +
                            '</td></tr>');
                }
            },

            //
            OnDataBound: function () {
                var grid = $("#targetBlockingList").data("kendoGrid");

                var grid = $("#targetBlockingList").data("kendoGrid");
                var data = $("#targetBlockingList").data("kendoGrid").dataSource.view();
                athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList(data);
                athoc.iws.publishing.iut.OnBoundEmptyRow(data);


            },

            //
            refreshGrid: function () {
                grid.setDataSource(athoc.iws.publishing.iut.viewModel.targetedBlockerUsers());
                grid.dataSource.pageSize(grid.dataSource.total());

            },

            //this method will be called when data is required for updating
            getModel: function () {
                if ($("#targetBlockingList").data("kendoGrid") != undefined) {
                    return ko.mapping.toJS($("#targetBlockingList").data("kendoGrid").dataSource.view());
                } else {
                    return null;
                }
            },

            //indicates if the section is ready or not
            isReady: function () {
                //if at least one user is targed then this should be true
                return false;
            },

            //triggered on data changed
            dataChanged: function () {
                var current = athoc.iws.publishing.content;
                current.isChanged = true;
                current.checkReadyNotReady();
            },

            //
            createReadOnlyUserList: function () {
                var self = this;
                var searchString = "";
                var rowsObject = [];
                var attributeIds = "";
                var dIds = "";
                var displayIds = "";
                var cNames = "";

                if ($("#txtReadOnlySearch").val() != "") {
                    searchString = $("#txtReadOnlySearch").val();
                    var rGrid = $("#readonlyUserList").data("kendoGrid");
                    if (rGrid != null && rGrid.columns.length > 0) {
                        _.each(rGrid.columns, function (col, index) {
                            if (col.headerAttributes != null && (col.headerAttributes.key == "LOGIN_ID" || col.headerAttributes.key == "FIRSTNAME" || col.headerAttributes.key == "LASTNAME" || col.headerAttributes.key == "DISPLAYNAME") && col.headerAttributes.id > 0)
                                attributeIds = attributeIds + col.headerAttributes.id + ",";
                        });
                    }
                }

                _.each(athoc.iws.publishing.iut.newlyaddedColumns, function (item, index) {
                    if (item.CustomViewColumnType.toUpperCase() == "DEVICE") {
                        displayIds = displayIds + item.Id + ",";
                        //dNames = dNames + item.Key + ",";
                    }
                    else if (item.CustomViewColumnType.toUpperCase() == "CF") {
                        cNames = cNames + item.Key + ",";
                    }
                });
                cNames = cNames + athoc.iws.publishing.iut.readOnlyInputParameters.attributeCSV();
                //if (dIds == "") {

                var checkedDevices = ko.mapping.toJS(athoc.iws.publishing.targetUsers.SelectedGroupedDevices().Devices).map(function (item) { return item.DeviceId; });
                dIds = checkedDevices.join(",");


                var escalationAttributeId = 0;
                var escalationSortOrder = "";
                escalationSortOrder = athoc.iws.publishing.fillcount.getModel() != null ? athoc.iws.publishing.fillcount.getModel().OrderByAscending : "";
                escalationAttributeId = athoc.iws.publishing.fillcount.getModel() != null ? athoc.iws.publishing.fillcount.getModel().ControlledDeliveryAttributeId : 0;
                var sortBy = athoc.iws.publishing.iut.readOnlySortColumn == "" ? ((escalationAttributeId > 0) ? escalationAttributeId : "") : athoc.iws.publishing.iut.readOnlySortColumn;

                var sortOrder = athoc.iws.publishing.iut.readOnlySortOrder == "" ? (escalationAttributeId > 0 ? (escalationSortOrder ? "ASC" : "DESC") : "") : athoc.iws.publishing.iut.readOnlySortOrder;

                var inparameters = {
                    userCountType: athoc.iws.publishing.iut.readOnlyInputParameters.covered(),
                    sessionId: athoc.iws.publishing.iut.readOnlyInputParameters.sessionId(),
                    attributeCSV: cNames,
                    totalCount: athoc.iws.publishing.iut.readOnlyInputParameters.totalCount(),
                    attributeSearchValue: searchString,
                    sortBy: sortBy,
                    sortOrder: sortOrder,
                    deviceIds: dIds,
                    displayColumnDeviceIds: displayIds,
                    attributeIds: attributeIds,
                    fillCountAttributeId: escalationAttributeId
                };

                readOnlyDatasource = new kendo.data.DataSource({
                    transport:
                    {
                        read: {
                            url: athoc.iws.publishing.urls.GetAlertUserListDataUrl,
                            type: "POST",
                            dataType: "json",
                            data: inparameters,
                            traditional: true,
                        },

                    },

                    requestStart: function (e) {
                        $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#divReadOnlyProgress'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '150px', left: '60%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();
                        //$("#readonlyUserList").hide();
                        //$("#readOnlyPageInfo").hide();
                    },
                    requestEnd: function (e) {
                        $.AjaxLoader.hideLoader();
                        if (e.response) {
                            athoc.iws.publishing.iut.createReadOnlyDataSource(e.response);
                            e.response["Rows"] = rowsObject;
                            readOnlyDatasource._total = e.response.TotalCounts;
                            athoc.iws.publishing.iut.createReadOnlyGrid();

                        }

                    },

                    error: function (e) {
                        athoc.iws.publishing.iut.handleError(e);
                    },
                    schema:
                    {
                        data: "Rows",
                        total: "TotalCounts",
                    },
                    serverPaging: true,
                    serverSorting: true,
                    sort: {},
                    pageSize: 50,
                });
                readOnlyDatasource.read();

            },

            createReadOnlyGrid: function () {
                if (athoc.iws.publishing.iut.firstTimeReachableUser == 0) {
                    $("#readonlyUserList").html('');
                    $("#readonlyUserList").hide();
                    athoc.iws.publishing.iut.firstTimeReachableUser = 1;
                }


                $("#readOnlyPageInfo").kendoPager({
                    dataSource: readOnlyDatasource,
                    autoBind: false,
                    numeric: false,
                    previousNext: false,
                    messages: {
                        display: athoc.iws.publishing.iut.resources.IUTReadOnly_PageingInfo,
                        empty: athoc.iws.publishing.iut.resources.IUTReadOnly_Emptyrow_Message
                    }
                });
                $("#readonlyUserList .k-grid-header").html('');

                if (rowsObject.length == 0) {
                    rowsObject = [];
                }
                var grid = $("#readonlyUserList").kendoGrid().data("kendoGrid");
                var options = grid.options;
                grid.destroy();

                kendoGrid = $("#readonlyUserList").kendoGrid({
                    columns: columnDefs,
                    dataSource: rowsObject,
                    autoBind: true,
                    scrollable: true,
                    sortable: false,
                    pageable:
                            {
                                refresh: false,
                                pageSizes: true,
                                pageSizes: [20, 50, 100],
                                buttonCount: 5,
                                messages: {
                                    display: $.htmlDecode(athoc.iws.publishing.iut.resources.IUTAllUsers_PagingInfo),
                                    empty: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Empty),
                                    itemsPerPage: $.htmlDecode(athoc.iws.publishing.iut.resources.IUT_ItemsPerPage),
                                    first: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                                    previous: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                                    next: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                                    last: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                                }
                            },
                    dataBinding: athoc.iws.publishing.iut.OnReadOnlyDataBinding,
                    dataBound: athoc.iws.publishing.iut.OnReadOnlyDataBound,
                    error: function (e) {
                        var errorCallBack = function (returnedErrorObject) {
                            $('#readonlyMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        };
                        AjaxUtility().athocKendoGridAjaxErrorHandler(e, errorCallBack);

                    },

                }).data("kendoGrid");

                setTimeout(function () {
                    athoc.iws.publishing.iut.fitHeightReadOnlyList();
                    $("#readonlyUserList").show();
                    $("#readOnlyPageInfo").show();
                    $.AjaxLoader.hideLoader();
                }, 1500);
            },

            fitHeighUserList: function () {
                var windowHeight = $("#AddBlockUsers .modal-content").height();
                if (windowHeight > 600) { // Resolution : 1920 * 1080
                    $("#tbUsersList .k-grid-content").css("height", (windowHeight * 73.2 / 100) - 12);
                }
                else if (windowHeight > 460) { // Resolution : 1280*1024
                    $("#tbUsersList .k-grid-content").css("height", (windowHeight * 73.2 / 100) + 8);
                }
                else {
                    $("#tbUsersList .k-grid-content").css("height", (windowHeight * 63 / 100) - 9);
                }
            },

            fitHeightReadOnlyList: function () {

                var windowHeight = $("#ReadOnlyUserList .modal-content:eq(1)").height() - $("#ReadOnlyUserList .content-current").height();
                if (windowHeight > 500) {
                    $("#readonlyUserList .k-grid-content").css("height", (windowHeight * 79 / 100) - 10);
                }
                else if ((windowHeight <= 500) && (windowHeight > 400)) {
                    $("#readonlyUserList .k-grid-content").css("height", (windowHeight * 79 / 100) - 15);
                }
                else {
                    $("#readonlyUserList .k-grid-content").css("height", (windowHeight * 67 / 100) - 10);
                }
            },

            fitHeightAllUsers: function () {
                var extraSpace = 0;
                if (athoc.iws.publishing.iut.searchString.length > 0)
                    extraSpace = 4;

                var windowHeight = $("#AddBlockUsers .modal-content").height() - $("#allUsersBucket .content-current").height();
                if (windowHeight >= 590) {
                    $("#allUserList .k-grid-content").css("height", (windowHeight * 73.2 / 100) - extraSpace + 22);
                }
                else if (windowHeight > 400) {
                    $("#allUserList .k-grid-content").css("height", (windowHeight * 73.2 / 100) - extraSpace + 5);
                }
                else {
                    $("#allUserList .k-grid-content").css("height", ((windowHeight * 54 / 100) + 20));
                }

                if ($("#pillContainer").children().length == 0)
                    $("#pillContainer").hide();
                else {
                    $("#pillContainer").show();
                    if (windowHeight <= 400)
                        $("#allUserList .k-grid-content").css("height", ((windowHeight * 54 / 100) - 10));
                }

                $('#allUserList').show();
            },

            fitHeightTargetedUsersSummaryList: function () {
                var windowHeight = $("#targetedUsersSummary .modal-body").height();
                if (windowHeight < 450) {
                    $("#targetedUsersList .k-grid-content").css("height", (windowHeight * 82 / 100));
                }
                else if ((windowHeight > 500) && (windowHeight < 600)) {
                    $("#targetedUsersList .k-grid-content").css("height", windowHeight - 70);
                }
                else if (windowHeight >= 600) { // resolution: 1920*1080
                    if (navigator.userAgent.toLowerCase().indexOf('chrome') > -1) {
                        $("#targetedUsersList .k-grid-content").css("height", windowHeight - 110);
                    }
                    else if (navigator.userAgent.toLowerCase().indexOf('firefox') > -1) {
                        $("#targetedUsersList .k-grid-content").css("height", windowHeight - 76);
                    }
                    else
                        $("#targetedUsersList .k-grid-content").css("height", windowHeight - 130);

                }
                else {
                    $("#targetedUsersList .k-grid-content").css("height", windowHeight - 84);

                }
            },

            fitHeightBlockedUsersSummaryList: function () {
                var windowHeight = $("#blockedUsersSummary .modal-body").height();
                if (windowHeight < 450) {
                    $("#blockedUsersList .k-grid-content").css("height", (windowHeight * 82 / 100));
                }
                else if ((windowHeight > 500) && (windowHeight < 600)) {
                    $("#blockedUsersList .k-grid-content").css("height", windowHeight - 70);
                }
                else if (windowHeight >= 600) {// resolution: 1920*1080
                    if (navigator.userAgent.toLowerCase().indexOf('chrome') > -1) {
                        $("#blockedUsersList .k-grid-content").css("height", windowHeight - 110);
                    }
                    else if (navigator.userAgent.toLowerCase().indexOf('firefox') > -1) {
                        $("#blockedUsersList .k-grid-content").css("height", windowHeight - 76);
                    }
                    else
                        $("#blockedUsersList .k-grid-content").css("height", windowHeight - 130);
                }
                else {
                    $("#blockedUsersList .k-grid-content").css("height", windowHeight - 84);

                }
            },

            createReadOnlyDataSource: function (data) {
                columnDefs = [];
                rowsObject = [];
                colObject = [];
                var colWidth = "auto";
                if (data.ReportsColumns.length > 7)
                    colWidth = "120px";
                // Add coumns to column array

                athoc.iws.publishing.iut.reportCols = [];
                var ReportLayoutColumns = data.ReportLayoutColumns;

                _.each(athoc.iws.publishing.iut.newlyaddedColumns, function (item, index) {
                    var existColCount = ko.mapping.toJS(data.ReportLayoutColumns).filter(function (DisplayName) {
                        return DisplayName == item.DisplayName;
                    }).length;

                    if (existColCount == 0)
                        ReportLayoutColumns.push(item.DisplayName);

                });

                _.each(ReportLayoutColumns, function (item, cIndex) {
                    _.find(data.ReportsColumns, function (obj) {
                        if (item == obj.DisplayName) {
                            athoc.iws.publishing.iut.reportCols.push(obj);
                        }
                    });
                });

                _.each(athoc.iws.publishing.iut.reportCols, function (item, cIndex) {
                    var columnName = item.Key;
                    var headerTemplate = "";
                    var field = '_' + columnName.replace(/[-:~!@#$%^&*(){}\[\]<>,.\s'\"?\\\/]/g, "");
                    if (item.Key.toUpperCase() != "USER_ID" || item.Key.toUpperCase() != "LOGIN_ID") {
                        var existColCount = ko.mapping.toJS(athoc.iws.publishing.iut.newlyaddedColumns).filter(function (i) {
                            return i.Key == item.Key;
                        }).length;

                        if (existColCount == 0) {
                            headerTemplate = kendo.format('<span title="' + $.htmlEncode(item.DisplayName) + '" onclick="athoc.iws.publishing.iut.readOnlyGridColumnSort(event);">' + $.htmlEncode(item.DisplayName) + '</span>');
                        }
                        else
                            headerTemplate = kendo.format('<div title="' + athoc.iws.publishing.resources.Publishing_RemoveGridColumn + ' ' + $.htmlEncode(item.DisplayName) + '" class="icon_clear remove-column"  key="' + columnName + '" onclick="athoc.iws.publishing.iut.readonlyUserlistRemoveColumn(event);"></div>' + '<span title="' + $.htmlEncode(item.DisplayName) + '" onclick="athoc.iws.publishing.iut.readOnlyGridColumnSort(event);" >' + $.htmlEncode(item.DisplayName) + '</span>');

                        if (athoc.iws.publishing.iut.readOnlySortColumn.toUpperCase() == item.Key.toUpperCase()) {
                            athoc.iws.publishing.iut.readOnlySortField = field;
                            if (athoc.iws.publishing.iut.readOnlySortOrder.toUpperCase() == "ASC") {
                                if (athoc.iws.publishing.iut.readOnlySortColumn.toUpperCase() == "ORGANIZATIONAL HIERARCHY")
                                    headerTemplate += '<span class="sort-indicator-ascending sort-indicator-margin-userlist"></span>';
                                else
                                    headerTemplate += '<span class="sort-indicator-ascending"></span>';
                            }
                            else if (athoc.iws.publishing.iut.readOnlySortOrder.toUpperCase() == "DESC") {
                                if (athoc.iws.publishing.iut.readOnlySortColumn.toUpperCase() == "ORGANIZATIONAL HIERARCHY")
                                    headerTemplate += '<span class="sort-indicator-descending sort-indicator-margin-userlist"></span>';
                                else
                                    headerTemplate += '<span class="sort-indicator-descending"></span>';
                            }
                        }

                        columnDefs.push({
                            title: columnName,
                            field: field,
                            width: colWidth,
                            headerTemplate: headerTemplate,
                            template: '<span title="#=' + field + '#">#=' + field + '#</span>',
                            headerAttributes: {
                                id: item.Id,
                                customviewcolumntype: item.CustomViewColumnType,
                                key: item.Key
                            }
                        });
                    }
                });

                rowsObject.length = 0;
                rowNumber = 0;
                rowsObject = [];
                // Prepare datasource for kendo grid
                _.each(data.ReportRows, function (row, rIndex) {
                    var colObject = new Object();
                    //colObject["Id"] = row.Id;                    
                    colObject["_LOGIN_ID"] = row.UserName;
                    _.each(data.ReportsColumns, function (column, cIndex) {
                        if (column.Key.toUpperCase() != "USER_ID") {
                            var value = $.customizedHtmlEncoding(athoc.iws.publishing.iut.getReadOnlyColumnValue(column, row));
                            //if (column.DataFormat && column.DataType && (!(column.DataType == 4 || column.DataType == 5)))
                            //    value = $.getFormattedValue(column.DataType, column.DataFormat, value);
                            colObject["_" + column.Key.replace(/[-:~!@#$%^&*(){}\[\]<>,.\s'\"?\\\/]/g, "")] = value;
                        }
                    });

                    rowsObject.push(colObject);
                })
               

                columnDefs.push({
                    title: athoc.iws.publishing.iut.resources.IUTReadOnly_Add_Reset,
                    field: "",
                    width: "80px",
                    headerTemplate: '<a href="#" class="small-msg block column-select" id="addColumn" onClick="athoc.iws.publishing.iut.addNewReportColumn(this)"  >' + athoc.iws.publishing.iut.resources.IUTReadOnly_Add + '</a><a href="#" class="small-msg block" id="reset"  onClick="athoc.iws.publishing.iut.ResetReportColumns()"  >' + athoc.iws.publishing.iut.resources.IUTReadOnly_Reset + '</a>'
                });

               
            },

            getReadOnlyColumnValue: function (column, row) {

                if (column.Key == "OPERATOR-ROLES") {
                    var roleCount = row.UserAttributes["ROLECOUNT_OTHERORGS"];
                    if (roleCount && roleCount != " ") {
                        return row.UserAttributes[column.Key] + " (" + row.UserAttributes["ROLECOUNT_OTHERORGS"] + ") ";
                    } else {
                        return row.UserAttributes[column.Key];
                    }
                }
                return row.UserAttributes[column.Key] != null
                    ? row.UserAttributes[column.Key]
                    : (row.UserDevice[column.Key] != null ? row.UserDevice[column.Key] : '');
            },

            readOnlyGridColumnSort: function (event) {
                event.preventDefault();
                event.cancelBubble = true;
                var grid = $("#readonlyUserList").data("kendoGrid");
                athoc.iws.publishing.iut.readOnlySortField = grid.columns[event.target.parentNode.cellIndex].field;
                athoc.iws.publishing.iut.readOnlySortColumn = grid.columns[event.target.parentNode.cellIndex].title; //event.target.getAttribute("title");
                if (athoc.iws.publishing.iut.readOnlySortOrder == "desc")
                    athoc.iws.publishing.iut.readOnlySortOrder = "asc";
                else
                    athoc.iws.publishing.iut.readOnlySortOrder = "desc";
                athoc.iws.publishing.iut.createReadOnlyUserList();

            },

            resizeModalBasedOnScreen: function (modal) {

                modal.find(".modal-body").css("max-height", 600);
                var windowHeight = $(window).height();

                if (windowHeight > 770) {
                    modal.css("margin-top", 40 - (windowHeight / 2) + ((windowHeight - 770) / 2));
                    modal.find(".modal-body").css("height", windowHeight - 340);
                } else {
                    modal.css("margin-top", 40 - (windowHeight / 2));
                    modal.find(".modal-body").css("height", windowHeight - 240);
                }

                if (modal.height() + 170 > windowHeight) {
                    var newHeight = windowHeight - 170;
                    modal.find(".modal-body").css("max-height", newHeight);

                }

            },

            showAddColumns: function (event) {

                var position = $("#ReadOnlyUserList .column-select").offset();

                var selColumn = $("#ReadOnlyUserList .column-filter");
                var windowHeight = $(window).height();
                if (athoc.iws.publishing.source == "p" || athoc.iws.publishing.source == "a" || athoc.iws.publishing.source == "h" || athoc.iws.publishing.source == "readonly" || (athoc.iws.alert != undefined && athoc.iws.alert.source == "publisher"))
                    selColumn.css({ top: "126px" });
                else if (athoc.iws.publishing.source == undefined)
                    selColumn.css({ top: "157px" });
                else
                    selColumn.css({ top: "142px" });

                selColumn.css({ left: "710px" });


                selColumn.show();

            },

            hideAddColumns: function (data, event) {
                var selColumn = $(".column-filter");
                selColumn.hide();
            },

            //
            ResetReportColumns: function () {
                $("#dialogResetReadonlyUsers").find(".modal-body").css("max-height", 50);
                $("#dialogResetReadonlyUsers").show();
                $("#ReadOnlyUserList").append('<div id="displayShadow" class="modal-backdrop fade in"></div>');
                $("#dialogResetReadonlyUsers").on('click', '.btn-info', function (event) {
                    $("#dialogResetReadonlyUsers").hide();
                    $("#ReadOnlyUserList").find('#displayShadow').remove();
                });
            },

            ResetReadonlyGridListOk: function () {
                $("#dialogResetReadonlyUsers").hide();
                $("#ReadOnlyUserList").find('#displayShadow').remove();
                athoc.iws.publishing.iut.newlyaddedColumns.length = 0;
                athoc.iws.publishing.iut.createReadOnlyUserList();

                /*target = "_blank";
                athoc.iws.publishing.iut.hideAddColumns();
                var parameters = {
                    viewType: "UserReport",
                };
                var myAjaxOptions = {
                    url: athoc.iws.publishing.urls.ResetToReportDefaultViewUrl,
                    type: "POST",
                    dataType: "json",
                    data: parameters,
                    success: function (data) {
                        athoc.iws.publishing.iut.createReadOnlyUserList();
                        $.AjaxLoader.hideLoader();
                    }
                };
                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);*/
            },

            //
            addNewReportColumn: function () {

                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#ReadOnlyUserList .dropdown-div'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '150px', left: '60%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();
                var self = this;
                var parameters = {
                    viewType: "UserReport",
                };

                var myAjaxOptions = {
                    url: athoc.iws.publishing.urls.GetReportCustomViewUrl,
                    type: "POST",
                    dataType: "json",
                    data: parameters,
                    success: function (data) {
                        if (data && data.length > 0) {
                            $("#newColumn").html('');
                            //  self.render(true, function () {
                            var htmlAttributes = '';
                            var deviceOptions = '';
                            var operatorOptions = '';
                            var hierarchyOptions = '';
                            var hierarchyGroup = '', attributeGroup = '', deviceGroup = '', operatorAttributeGroup = '';
                            var html = "";
                            html += '<select style="width: 248px !important; margin-left: 5px !important;" name="addReportColumnDropdown" data-placeholder="" size=10>';

                            _.each(data, function (item, index) {
                                var existColCount = ko.mapping.toJS(athoc.iws.publishing.iut.reportCols).filter(function (i) {
                                    return (i.Key == item.Key);
                                }).length;

                                
                                


                                if (existColCount == 0)
                                    //athoc.iws.publishing.iut.newlyaddedColumns == "" || athoc.iws.publishing.iut.newlyaddedColumns.split(',').indexOf($.htmlEncode(item.DisplayName)) == -1) {
                                {
                                    var optionList = "<option value='" + item.Id + "' data-customviewcolumntype='" + item.CustomViewColumnType + "' data-key='" + item.Key + "'>" + $.htmlEncode(item.DisplayName) + "</option>";

                                    if (item.CustomViewColumnType == "CF" && item.IsHierarchy == false && item.Key == operatorRoleColumn) {
                                        operatorOptions = operatorOptions + optionList;
                                    }
                                    else if (item.CustomViewColumnType == "CF" && item.IsHierarchy == false) {
                                        htmlAttributes = htmlAttributes + optionList;
                                    }
                                    else if (item.CustomViewColumnType == "CF" && item.IsHierarchy == true) {
                                        hierarchyOptions = hierarchyOptions + optionList;
                                    }
                                    else if (item.CustomViewColumnType == "Device") {
                                        deviceOptions = deviceOptions + optionList;
                                    }
                                }
                            });

                            if (hierarchyOptions != '') {
                                hierarchyGroup = '<optgroup label="Organization Hierarchy">' + hierarchyOptions + '</optgroup>';
                            }

                            if (htmlAttributes != '')
                                attributeGroup = '<optgroup label="Attributes">' + htmlAttributes + '</optgroup>';

                            if (deviceOptions != '')
                                deviceGroup = '<optgroup label="Devices">' + deviceOptions + '</optgroup>';

                            if (operatorOptions != '')
                                operatorAttributeGroup = '<optgroup label="' + $.htmlDecode(athoc.iws.publishing.iut.resources.operatorAttributesLabel) + '">' + operatorOptions + '</optgroup>';

                            html = html + hierarchyGroup + attributeGroup + operatorAttributeGroup + deviceGroup;
                            html += '</select>';
                            //html += '</div></div>';
                            $("#newColumn").html(html);



                            var selectElm = $("select[name='addReportColumnDropdown']");


                            // selectElm.selectpicker({});

                            selectElm.change(function () {
                                var elm = $(this);
                                var displayName = "";

                                if (elm.find("option:selected").data("customviewcolumntype") == "Device")
                                    displayName = elm.find("option:selected").html().replace(/\(Device\)?$/, "").trim();
                                else
                                    displayName = elm.find("option:selected").html();

                                athoc.iws.publishing.iut.newlyaddedColumns.push({ Id: elm.val(), Key: elm.find("option:selected").data("key"), CustomViewColumnType: elm.find("option:selected").data("customviewcolumntype"), DisplayName: displayName });
                                athoc.iws.publishing.iut.createReadOnlyUserList();
                                /*athoc.iws.publishing.iut.updateReportViewColumn(0, elm.val(),
                                    "add",
                                    elm.find("option:selected").data("customviewcolumntype"),
                                    elm.find("option:selected").data("key"),elm.find("option:selected").html(),
                                    function () {
                                        // $.AjaxLoader.hideLoader();

                                        athoc.iws.publishing.iut.hideAddColumns();

                                    });*/
                            });
                            //  });

                            athoc.iws.publishing.iut.showAddColumns();

                            var existCssValue = $("#newColumn").parent().css("top");
                            existCssValue = existCssValue.replace("px", '');
                            if (parseInt(existCssValue) > 134)
                                $("#newColumn").parent().css("top", (parseInt(existCssValue) - 14) + 'px');


                            existCssValue = $("#newColumn").parent().css("left");
                            existCssValue = existCssValue.replace("px", '');
                            $("#newColumn").parent().css("left", (parseInt(existCssValue) + 4) + 'px');
                        }
                        $.AjaxLoader.hideLoader();
                    }
                };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);
                //}
            },

            //
            updateReportViewColumn: function (viewId, id, action, columnType, columnKey, columnName, onSuccess) {
                var self = this;
                if (viewId == "" || viewId == null || viewId == undefined)
                    viewId = 0;
                if (id) {
                    $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#ReadOnlyUserList .dropdown-div'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '150px', left: '60%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();
                    if (action == "remove" && athoc.iws.publishing.iut.readOnlySortColumn == columnKey) {
                        athoc.iws.publishing.iut.readOnlySortColumn = "USERNAME";
                        athoc.iws.publishing.iut.readOnlySortOrder = "ASC";
                    }

                    var myAjaxOptions = {
                        url: athoc.iws.publishing.urls.SaveReportCustomViewUrl,
                        type: "POST",
                        dataType: "json",
                        data: { viewId: viewId, id: id, action: action, type: columnType, commonName: columnKey },
                        success: function () {
                            athoc.iws.publishing.iut.newlyaddedColumns = athoc.iws.publishing.iut.newlyaddedColumns + "," + columnName;
                            athoc.iws.publishing.iut.createReadOnlyUserList();
                            $.AjaxLoader.hideLoader();

                        },
                        error: function (e) {
                            athoc.iws.publishing.iut.handleError(e);
                        },

                    };

                    var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);

                    $.ajax(ajaxOptions);
                }
            },

            OnReadOnlyDataBound: function (e) {
                $(".kendo-mini-pager").removeClass("k-pager-wrap");
                $(".kendo-mini-pager").removeClass("k-widget");
                $(".kendo-mini-pager").removeClass("k-floatwrap");
                var data = $("#readonlyUserList").data("kendoGrid").dataSource.view();
                var grid = $("#readonlyUserList").data("kendoGrid");
                grid.pager.dataSource = readOnlyDatasource;
                athoc.iws.publishing.iut.OnBoundReadonlyEmptyRow(data);
            },

            OnReadOnlyDataBinding: function () {
                var ds = $("#readonlyUserList").data("kendoGrid").dataSource;
                ds._sort = [{ field: athoc.iws.publishing.iut.readOnlySortField, dir: athoc.iws.publishing.iut.readOnlySortOrder }];
            },

            ShowUsersList: function (sessionId, covered, attributeCSV, totalCount) {
                athoc.iws.publishing.iut.readOnlyInputParameters.sessionId(sessionId);
                athoc.iws.publishing.iut.readOnlyInputParameters.covered(covered);
                athoc.iws.publishing.iut.readOnlyInputParameters.attributeCSV(attributeCSV);
                athoc.iws.publishing.iut.readOnlyInputParameters.totalCount(totalCount);
                $("#txtReadOnlySearch").val('');
                //$("#btn_readonlyusersearch").attr('disabled', true);
                $('#ReadOnlyUserList').modal('show');
                athoc.iws.publishing.iut.resizeModalBasedOnScreen($('#ReadOnlyUserList'));
                athoc.iws.publishing.iut.createReadOnlyUserList();
                athoc.iws.publishing.iut.firstTimeReachableUser = 0;
            },

            //All Available users and Targeted/Blocked user PopUp

            // Get all users data and bind to kendo grid
            createAddBlockUsersGrid: function (getNextPage, onSuccess, searchParameters, page, showSpinner) {
                var self = this;
                var strSearch = [];
                var gridRowsObject = [];

                $.grep(athoc.iws.publishing.iut.searchString, function (i) {
                    strSearch.push(i.value);
                });
                if (firstTimeOpenAddUser == 0) {
                    $("#allUserList").html('');
                    $('#allUserList').hide();
                    firstTimeOpenAddUser = 1;
                }
                var parameters = {
                    searchStrings: strSearch,
                    staticQueryCriteria: '',
                    sortBy: athoc.iws.publishing.iut.allUserSortColumn,
                    sortOrder: athoc.iws.publishing.iut.allUserSortOrder,
                    pageSize: athoc.iws.publishing.iut.allUsersPageSize,
                    searchFlow: "FromUserManager",
                };
                gridColumnDefs = [];
                allUserDatasource = new kendo.data.DataSource({
                    transport: {
                        read: {
                            url: athoc.iws.publishing.urls.GetUserListUrl,
                            type: "POST",
                            dataType: "json",
                            data: parameters,
                            traditional: true,
                        },

                    },
                    requestStart: function (e) {
                        $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#divProgress'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '50%', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();
                        $("#divProgress .blockMsg").css("margin", "-13px");
                        $("#divProgress .blockMsg").css("left", "40px");
                    },
                    requestEnd: function (e) {

                        if (e.response != null) {
                            gridColumnDefs.length = 0;
                            // Add checkbox column to the column array
                            gridColumnDefs.push({
                                title: '',
                                field: '',
                                template: $("#userList-chkTargeted-template").html(),
                                headerTemplate: kendo.format('<input name="chbox" id="allUsersCheckAll" value="0" type="checkbox" title="' + athoc.iws.publishing.iut.resources.IUTAllUsers_SelectAll_DeSelect + '" data-type="selectAll" onclick="athoc.iws.publishing.iut.allUsersSelectAll();"/>', ""),
                                width: 34,
                            });

                            // column width based on column count
                            var colWidth = 0;
                            if (e.response.Columns.length < 7)
                                colWidth = "auto";
                            else
                                colWidth = "120px";

                            // Add secondary columns to the column array 
                            _.each(e.response.SecondaryColumns, function (column, cIndex) {
                                var headerSecTemplate = "";
                                var dtemplate = "";
                                var sfield = "_" + column.Key.replace(/[-:~!@#$%^&*(){}\[\]<>,.€\s'\"?\\\/]/g, "");

                                headerSecTemplate = '<span title="' + $.htmlEncode(column.DisplayName) + '" class="table-head-primary' + (column.IsSortable ? " table-head-sortable" : "") + '"data-key="' + column.Key + '" onclick="athoc.iws.publishing.iut.allUserGridColumnSort(\'' + sfield + '\',\'' + column.Key + '\');">' + $.htmlEncode(column.DisplayName) + '</span>';

                                if (athoc.iws.publishing.iut.allUserSortColumn.toUpperCase() == column.Key) {
                                    athoc.iws.publishing.iut.allUserSortField = sfield;
                                    if (athoc.iws.publishing.iut.allUserSortOrder.toUpperCase() == "ASC") {
                                        headerSecTemplate += '<span class="sort-indicator-ascending"></span>';
                                    }
                                    else if (athoc.iws.publishing.iut.allUserSortOrder.toUpperCase() == "DESC") {
                                        headerSecTemplate += '<span class="sort-indicator-descending"></span>';
                                    }
                                }

                                headerSecTemplate = kendo.format(headerSecTemplate);
                                if (gridColumnDefs.length == 1)
                                    dtemplate = $("#userList-link-template").html();
                                else
                                    dtemplate = '<span title="#=' + sfield + '#">#=' + sfield + '#</span>';

                                gridColumnDefs.push({
                                    title: column.DisplayName,
                                    field: sfield,
                                    width: colWidth,
                                    template: dtemplate,
                                    headerTemplate: headerSecTemplate,
                                    headerAttributes: {
                                        viewid: column.ViewId,
                                        id: column.Id,
                                        customviewcolumntype: "",
                                        key: column.Key
                                    }
                                });
                            });
                            // Add coumns to column array
                            _.each(e.response.Columns, function (column, cIndex) {
                                var headerTemplate = "";
                                var field = "_" + column.Key.replace(/[-:~!@#$%^&*(){}\[\]<>,.€\s'\"?\\\\/]/g, "");
                                if (column.IsRequired != true) {
                                    headerTemplate = '<div title="' + athoc.iws.publishing.resources.Publishing_RemoveGridColumn + ' ' +$.htmlEncode(column.DisplayName) + '" class="icon_clear remove-column" onclick="athoc.iws.publishing.iut.userListRemoveColumn(event);"></div>' +
                                        '<span title="' + $.htmlEncode(column.DisplayName) + '" class="table-head-primary' + (column.IsSortable ? " table-head-sortable" : "") + '" data-key="' + column.Key + '" onclick="athoc.iws.publishing.iut.allUserGridColumnSort(\'' + field + '\',\'' + column.Key + '\');">' + $.htmlEncode(column.DisplayName) + '</span>';
                                }
                                else
                                    headerTemplate = '<span title="' + $.htmlEncode(column.DisplayName) + '" class="table-head-primary' + (column.IsSortable ? " table-head-sortable" : "") + '"data-key="' + column.Key + '"onclick="athoc.iws.publishing.iut.allUserGridColumnSort(\'' + field + '\',\'' + column.Key + '\');" >' + $.htmlEncode(column.DisplayName) + '</span>';

                                if (athoc.iws.publishing.iut.allUserSortColumn.toUpperCase() == column.Key) {
                                    athoc.iws.publishing.iut.allUserSortField = field;
                                    if (athoc.iws.publishing.iut.allUserSortOrder.toUpperCase() == "ASC") {
                                        headerTemplate += '<span class="sort-indicator-ascending"></span>';
                                    }
                                    else if (athoc.iws.publishing.iut.allUserSortOrder.toUpperCase() == "DESC") {
                                        headerTemplate += '<span class="sort-indicator-descending"></span>';
                                    }
                                }
                                headerTemplate = kendo.format(headerTemplate);
                                gridColumnDefs.push({
                                    title: column.DisplayName,
                                    field: field,
                                    width: colWidth,
                                    template: '<span title="#=' + field + '#">#=' + field + '#</span>',
                                    headerTemplate: headerTemplate,
                                    headerAttributes: {
                                        viewid: column.ViewId,
                                        id: column.Id,
                                        customviewcolumntype: "",
                                        key: column.Key
                                    }
                                });
                            });

                            // Add add/reset column to column array
                            gridColumnDefs.push({
                                title: athoc.iws.publishing.iut.resources.IUTAllUsers_Add_Reset,
                                field: "",
                                width: "80px",
                                template: $("#userList-BlockUnblock-template").html(),
                                headerTemplate: '<a href="#" class="small-msg block column-select" id="addReportColumn" onClick="athoc.iws.publishing.iut.addNewGridColumn()" title="' + athoc.iws.publishing.iut.resources.IUTAllUsers_Add + '"  >' + athoc.iws.publishing.iut.resources.IUTAllUsers_Add + '</a><a href="#" class="small-msg block" id="reset"  onClick="athoc.iws.publishing.iut.ResetGridList()" title="' + athoc.iws.publishing.iut.resources.IUTAllUsers_Reset + '" >' + athoc.iws.publishing.iut.resources.IUTAllUsers_Reset + '</a>'
                            });

                            // Prepare datasource for kendo grid
                            gridRowsObject.length = 0;
                            _.each(e.response.Rows, function (row, rIndex) {
                                var colObject = new Object();
                                colObject["Id"] = row.Id;
                                _.each(e.response.SecondaryColumns, function (column, cIndex) {
                                    var value = athoc.iws.publishing.iut.getColumnValue(column, row);
                                    colObject["_" + column.Key.replace(/[-:~!@#$%^&*(){}\[\]<>,.€\s'\"?\\\/]/g, "")] = $.customizedHtmlEncoding(value);
                                });

                                _.each(e.response.Columns, function (column, cIndex) {
                                    var value = athoc.iws.publishing.iut.getColumnValue(column, row);
                                    if (column.DataFormat && column.DataType && (!(column.DataType == 4 || column.DataType == 5)))
                                        value = $.getFormattedValue(column.DataType, column.DataFormat, value);
                                    colObject["_" + column.Key.replace(/[-:~!@#$%^&*(){}\[\]<>,.€\s'\"?\\\/]/g, "")] = $.customizedHtmlEncoding(value);
                                });
                                var tbItem = $.grep(athoc.iws.publishing.iut.viewModel.targetedBlockerUsers(), function (i) {
                                    return i.UserId == row.Id;
                                });
                                if (tbItem.length > 0 && !tbItem[0].IsBlocked)
                                    colObject["IsTargeted"] = true;
                                else
                                    colObject["IsTargeted"] = false;

                                if (tbItem.length > 0 && tbItem[0].IsBlocked)
                                    colObject["IsBlocked"] = true;
                                else
                                    colObject["IsBlocked"] = false;

                                gridRowsObject.push(colObject);
                            })
                            allUserDatasource._total = e.response.TotalCounts;
                        }
                        else {
                            gridColumnDefs.length = 0;
                            gridRowsObject.length = 0;
                            gridColumnDefs.push({
                                title: '',
                                field: '',
                                template: $("#userList-chkTargeted-template").html(),
                                headerTemplate: kendo.format('<input name="chbox" id="allUsersCheckAll" value="0" type="checkbox" title="' + athoc.iws.publishing.iut.resources.IUTAllUsers_SelectAll_DeSelect + '" data-type="selectAll" onclick="athoc.iws.publishing.iut.allUsersSelectAll();"/>', ""),
                                width: 5,
                            });
                            gridColumnDefs.push({
                                title: 'Username',
                                field: '',
                                width: 80,
                            });
                            gridColumnDefs.push({
                                title: athoc.iws.publishing.iut.resources.IUTAllUsers_Add_Reset,
                                field: "",
                                width: "10px",
                                template: $("#userList-BlockUnblock-template").html(),
                                headerTemplate: '<a href="#" class="small-msg block column-select" id="addReportColumn" onClick="athoc.iws.publishing.iut.addNewGridColumn()" title="' + athoc.iws.publishing.iut.resources.IUTAllUsers_Add + '"  >' + athoc.iws.publishing.iut.resources.IUTAllUsers_Add + '</a><a href="#" class="small-msg block" id="reset"  onClick="athoc.iws.publishing.iut.ResetGridList()" title="' + athoc.iws.publishing.iut.resources.IUTAllUsers_Reset + '" >' + athoc.iws.publishing.iut.resources.IUTAllUsers_Reset + '</a>'
                            });
                        }
                        // Page info of kendo grid
                        $("#allUserPageInfo").kendoPager({
                            dataSource: allUserDatasource,
                            autoBind: false,
                            numeric: false,
                            previousNext: false,
                            messages: {
                                display: athoc.iws.publishing.iut.resources.IUTAllUsers_PagingInfo,
                                empty: athoc.iws.publishing.iut.resources.IUTReadOnly_Emptyrow_Message
                            }
                        });
                        // Allusers kendo grid
                        $("#allUserList .k-grid-header").html('');
                        $("#allUserList").find(".bootstrap-select").remove();
                        ko.cleanNode($("#allUserList").get(0));
                        athoc.iws.publishing.iut.allUsersgrid = $("#allUserList").kendoGrid({
                            columns: gridColumnDefs,
                            dataSource: gridRowsObject,
                            selectable: false,
                            scrollable: true,
                            autoBind: true,
                            sortable: false,
                            pageable: {
                                refresh: false,
                                pageSizes: true,
                                pageSizes: [20, 50, 100],
                                buttonCount: 5,
                                messages: {
                                    display: $.htmlDecode(athoc.iws.publishing.iut.resources.IUTAllUsers_PagingInfo),
                                    empty: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Empty),
                                    itemsPerPage: $.htmlDecode(athoc.iws.publishing.iut.resources.IUT_ItemsPerPage),
                                    first: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                                    previous: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                                    next: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                                    last: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                                }
                            },
                            dataBinding: athoc.iws.publishing.iut.onAllUserDataBinding,
                            dataBound: athoc.iws.publishing.iut.onAllUserDataBound,
                            change: function (e) {
                                var model = this.dataItem(this.select());
                                this.select().removeClass("k-state-selected");
                                athoc.iws.publishing.iut.userInfo.update({ userId: model.Id, userName: model._LOGIN_ID });
                                $("#userInfoModal", athoc.iws.publishing.iut.userInfo.refDomNode).modal("show");
                                // athoc.iws.publishing.iut.UserKendoToolTip(model.Id);
                            }

                        }).data().kendoGrid;

                        $("#newColumns").html('');
                        athoc.iws.publishing.iut.allUsersPageSize = athoc.iws.publishing.iut.allUsersgrid.pager.dataSource._pageSize;

                        setTimeout(function () {
                            // Fit height for the alluer grid
                            athoc.iws.publishing.iut.fitHeightAllUsers();
                            $.AjaxLoader.hideLoader();
                        }, 100);


                        if (onSuccess)
                            onSuccess();

                    },
                    schema: {
                        data: "Rows",
                        total: "TotalCounts",
                    },
                    serverPaging: true,
                    serverSorting: true,
                    serverFiltering: true,
                    sort: { field: "Username", dir: "desc" },
                    pageSize: 50,
                    error: function (e) {
                        var errorCallBack = function (returnedErrorObject) {
                            $('#listMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        };
                        AjaxUtility().athocKendoGridAjaxErrorHandler(e, errorCallBack);
                        athoc.iws.publishing.iut.handleError(e);
                    },
                    change: function (e) {
                        athoc.iws.publishing.iut.retainSelectAll();
                    }
                });
                allUserDatasource._pageSize = athoc.iws.publishing.iut.allUsersPageSize;
                allUserDatasource.read();
                return 0;
            },

            // Databound event for the allusers grid
            onAllUserDataBound: function (e) {

                var data = $("#allUserList").data("kendoGrid").dataSource.view();
                athoc.iws.publishing.iut.viewModel.allAvailableUser(data);

                var grid = $("#allUserList").data("kendoGrid");
                grid.pager.dataSource = allUserDatasource;

                if (data.length > 0)
                    $("#allUserList .k-grid-header").css("width", "98% !important");
                else
                    $("#allUserList .k-grid-header").css("width", "100% !important");
                athoc.iws.publishing.iut.OnBoundAllUsersEmptyRow(data);

            },

            // Databinding event for the allusers grid
            onAllUserDataBinding: function (e) {
                var ds = $("#allUserList").data("kendoGrid").dataSource;
                ds._sort = [{ field: athoc.iws.publishing.iut.allUserSortField, dir: athoc.iws.publishing.iut.allUserSortOrder }];
            },

            OnBoundAllUsersEmptyRow: function (data) {
                var colCount = $("#allUserList").find('.k-grid-header colgroup > col').length;
                if (data.length == 0) {
                    $("#allUserList").find('.k-grid-content tbody')
                        .append('<tr class="kendo-data-row"><td colspan="' +
                            colCount +
                            '" style="text-align:center;height:10px;overflow:auto;">' +
                            kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', athoc.iws.publishing.iut.resources.IUTAllUsers_Emptyrow_Message, athoc.iws.publishing.iut.resources.IUTAllUsers_Emptyrow_Message) +
                            '</td></tr>');

                }
            },

            // Get user info for the compact popup
            getUserInfo: function (obj) {

                var id = obj.getAttribute('value');
                var name = obj.getAttribute('title');
                athoc.iws.publishing.iut.userInfo.update({ userId: id, userName: name }, $('#userInfoModal').find('#showProgress'));
                $("#userInfoModal", athoc.iws.publishing.iut.userInfo.refDomNode).modal("show");
                $("#AddBlockUsers").append('<div id="displayShadow" class="modal-backdrop fade in"></div>');
                $('#userInfoModal').on('hidden.bs.modal', function () {
                    $("#AddBlockUsers").find('#displayShadow').remove();
                })
            },

            // Get user info for the compact popup
            getUserInfoforFlatList: function (obj) {
                var id = obj.getAttribute('value');
                var name = obj.getAttribute('title');
                athoc.iws.publishing.iut.userInfo.update({ userId: id, userName: name });
                $("#userInfoModal", athoc.iws.publishing.iut.userInfo.refDomNode).modal("show");

            },

            // Sorting of columns for allusers grid
            allUserGridColumnSort: function (field, key) {
                athoc.iws.publishing.iut.allUserSortField = field;
                athoc.iws.publishing.iut.allUserSortColumn = key;
                if (athoc.iws.publishing.iut.allUserSortOrder == "desc")
                    athoc.iws.publishing.iut.allUserSortOrder = "asc";
                else
                    athoc.iws.publishing.iut.allUserSortOrder = "desc";
                athoc.iws.publishing.iut.createAddBlockUsersGrid();

            },

            // Select all event for the allusers grid
            allUsersSelectAll: function () {
                var checked = $('#allUsersCheckAll').is(':checked');
                var grid = $('#allUserList').data().kendoGrid;
                $.each(grid.dataSource.view(), function (i, item) {
                    if (checked) {
                        if (!item.IsBlocked && athoc.iws.publishing.iut.viewModel.targetedCnt() < athoc.iws.publishing.settings.IndividualUserTargetSelectionLimit) {
                            item.IsTargeted = checked;
                            athoc.iws.publishing.iut.updateTargetedBlockedUsers(item);
                        }
                        else if (!item.IsBlocked) {
                            $("#AddBlockUsers").append('<div id="displayShadow" class="modal-backdrop fade in"></div>');
                            $("#lblUsersLimit").html(athoc.iws.publishing.settings.IndividualUserTargetSelectionLimit);
                            $('#btn_limitCancel').on('click', function (event) {
                                $("#dialogUsersLimit").hide();

                                $("#AddBlockUsers").find('#displayShadow').remove();
                            });
                            $("#dialogUsersLimit").show();
                            $("#allUsersCheckAll").prop('checked', false);
                            return false;
                        }
                    }
                    else if (!item.IsBlocked && item.IsTargeted) {
                        item.IsTargeted = checked;
                        athoc.iws.publishing.iut.updateTargetedBlockedUsers(item);
                    }
                });
                grid.refresh();//update the grid...

            },

            // Retain check all when the paging is done
            retainSelectAll: function () {

                var grid = $('#allUserList').data().kendoGrid;
                var items = grid.dataSource.view();
                var ttlCnt = 0;
                // Get the selected items for the current page.
                $.grep(items, function (v) {
                    if (v.IsTargeted || v.IsBlocked)
                        ttlCnt++;
                });

                // Check total page count equal to selected count 
                var checked = ttlCnt > 0 && (items.length == ttlCnt);
                $("#allUsersCheckAll").prop('checked', checked);


            },

            // Createing pills when search is done
            createPills: function (value, type, display) {

                var found = _.find(athoc.iws.publishing.iut.searchString, function (item) {
                    return (item.value == value && item.type == type);
                });
                if (!found) {
                    athoc.iws.publishing.iut.searchString.push({ value: value, type: type, display: display });
                    athoc.iws.publishing.iut.renderPills();
                    athoc.iws.publishing.iut.createAddBlockUsersGrid();

                }
            },

            // Rendering the pills when search is done
            renderPills: function (css) {
                var self = this;
                var html = "";
                $("#divSearch .pill-container").html('');
                if (athoc.iws.publishing.iut.searchString && athoc.iws.publishing.iut.searchString.length > 0) {
                    _.each(athoc.iws.publishing.iut.searchString, function (item, index) {
                        var iconCss = "";
                        var prefix = "";
                        //html += '<div class="pill" data-index="' + index + '"><span class="pill-content">' + prefix + item.display + '</span><div class="pill-icon ' + iconCss + '"></div><a class="pill-close" href="javascript://"></a></div>';
                        var pillLabel = prefix + $.htmlEncode(item.display);
                        var pillTooltip = prefix + $.htmlEncode(item.display);
                        var closeButton = (typeof (css) === 'undefined' ? '<a class="pill-close" href="#"></a>' : '');
                        html = '<div class="pill" data-index="' + index + '" title="' + pillTooltip + '"><span class="pill-content">' + pillLabel + '</span>' + closeButton + '</div>' + html;
                    });

                    var pillsElm = $("#divSearch .pill-container");
                    pillsElm.html(html);
                    //wire up events
                    $("#divSearch .pill-close").click(function (event) {
                        var parentElm = $(this).parent(".pill");
                        athoc.iws.publishing.iut.deSelect(parentElm.data("index"));
                        event.stopPropagation();
                    });
                }
            },

            // Deleteing the pills
            deSelect: function (index, onSuccess) {
                if (athoc.iws.publishing.iut.searchString && athoc.iws.publishing.iut.searchString.length > index) {
                    athoc.iws.publishing.iut.searchString.splice(index, 1);
                    athoc.iws.publishing.iut.renderPills();
                    athoc.iws.publishing.iut.createAddBlockUsersGrid();
                }
            },

            // For Add/Block Users reset grid 
            ResetGridList: function () {
                $("#AddBlockUsers").append('<div id="displayShadow" class="modal-backdrop fade in"></div>');
                $("#dialogResetAllUsers").show();
                $("#dialogResetAllUsers").on('click', '.btn-info', function (event) {
                    $("#dialogResetAllUsers").hide();
                    $("#AddBlockUsers").find('#displayShadow').remove();
                });
            },

            ResetGridListOk: function () {
                $("#dialogResetAllUsers").hide();
                $("#AddBlockUsers").find('#displayShadow').remove();
                var myAjaxOptions = {
                    url: athoc.iws.publishing.urls.ResetToDefaultViewUrl,
                    type: "POST",
                    dataType: "json",
                    success: function (data) {
                        athoc.iws.publishing.iut.createAddBlockUsersGrid();
                    }
                };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);
            },

            // common to grids
            getColumnValue: function (column, row) {
                if (column.Key == "OPERATOR-ROLES") {
                    var roleCount = row.UserAttributes["ROLECOUNT_OTHERORGS"];
                    if (roleCount && roleCount != " ") {
                        return row.UserAttributes[column.Key] + " (" + row.UserAttributes["ROLECOUNT_OTHERORGS"] + ") ";
                    } else {
                        return row.UserAttributes[column.Key];
                    }
                }
                return column.CustomViewColumnType === "CF"
                    ? row.UserAttributes[column.Key]
                    : row.UserDevice[column.Key];
            },

            // For Add/Block Users add new GridColumn to grid 
            addNewGridColumn: function () {
                var self = this;

                var myAjaxOptions = {
                    url: athoc.iws.publishing.urls.GetCustomViewsUrl,
                    type: "POST",
                    dataType: "json",
                    success: function (data) {
                        if (data && data.length > 0) {
                            $("#newColumns").html('');
                            var htmlAttributes = '';
                            var deviceOptions = '';
                            var operatorOptions = '';
                            var hierarchyOptions = '';
                            var hierarchyGroup = '', attributeGroup = '', deviceGroup = '', operatorAttributeGroup = '';
                            var html = "";
                            html += '<select  name="addColumnDropdown"  data-placeholder="" size=10  style="width:250px !important;margin-left:5px !important">';

                            _.each(data, function (item, index) {
                                var optionList = "<option value='" + item.Id + "' data-customviewcolumntype='" + item.CustomViewColumnType + "' data-key='" + item.Key + "'>" + $.htmlEncode(item.DisplayName) + "</option>";

                                if (item.CustomViewColumnType == "CF" && item.IsHierarchy == false && item.Key == $.htmlDecode(athoc.iws.publishing.iut.resources.operatorRolesCommonName)) {
                                    operatorOptions = operatorOptions + optionList;
                                }
                                else if (item.CustomViewColumnType == "CF" && item.IsHierarchy == false) {
                                    htmlAttributes = htmlAttributes + optionList;
                                }
                                else if (item.CustomViewColumnType == "CF" && item.IsHierarchy == true) {
                                    hierarchyOptions = hierarchyOptions + optionList;
                                }
                                else if (item.CustomViewColumnType == "Device") {
                                    deviceOptions = deviceOptions + optionList;
                                }
                            });

                            if (hierarchyOptions != '') {
                                hierarchyGroup = '<optgroup label="Organization Hierarchy">' + hierarchyOptions + '</optgroup>';
                            }

                            if (htmlAttributes != '')
                                attributeGroup = '<optgroup label="Attributes">' + htmlAttributes + '</optgroup>';

                            if (deviceOptions != '')
                                deviceGroup = '<optgroup label="Devices">' + deviceOptions + '</optgroup>';

                            if (operatorOptions != '')
                                operatorAttributeGroup = '<optgroup label="' + $.htmlDecode(athoc.iws.publishing.iut.resources.operatorAttributesLabel) + '">' + operatorOptions + '</optgroup>';

                            html = html + hierarchyGroup + attributeGroup + operatorAttributeGroup + deviceGroup;
                            html += '</select>';
                            $("#newColumns").html(html);

                            var selectElm = $("select[name='addColumnDropdown']");
                            selectElm.change(function () {
                                var elm = $(this);

                                athoc.iws.publishing.iut.updateGridColumn(0, elm.val(),
                                    "add",
                                    elm.find("option:selected").data("customviewcolumntype"),
                                    elm.find("option:selected").data("key"),
                                    function () {
                                        $("#contextDropdown").hide();
                                    });
                            });

                            var position = $("#AddBlockUsers .column-select").offset();
                            var selColumn = $("#AddBlockUsers .column-filter");
                            selColumn.css({ top: '190px' });
                            $("#contextDropdown").show();
                        }

                    }
                };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);
                //}
            },

            // For Add/Block user Update grid columns in a grid
            updateGridColumn: function (viewId, id, action, columnType, columnKey, onSuccess) {
                var self = this;
                if (id) {
                    //$.AjaxLoader.setup({ useBlock: true, idToShow: self._id + '-pageAjaxLoader', elementToBlock: $('.table-header'), imageURL: self.options.cdnUrl + '/Images/ajax-loader.gif' }).showLoader();
                    if (action == "remove" && athoc.iws.publishing.iut.allUserSortColumn == columnKey) {
                        athoc.iws.publishing.iut.allUserSortColumn = "DISPLAYNAME";
                        athoc.iws.publishing.iut.allUserSortOrder = "ASC";
                    }
                    var myAjaxOptions = {
                        url: athoc.iws.publishing.urls.SaveCustomViewUrl,
                        type: "POST",
                        dataType: "json",
                        data: { viewId: viewId, id: id, action: action, type: columnType, commonName: columnKey },
                        success: function (data) {
                            athoc.iws.publishing.iut.createAddBlockUsersGrid(undefined, onSuccess, undefined, undefined, false);
                        }
                    };

                    var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);

                    $.ajax(ajaxOptions);
                }
            },

            // Open Add/Blocked users popup
            OpenAddBlockUsers: function () {
                $("#allUsersBucket").show();
                $("#targetBlockBucket").hide();
                $('#AddBlockUsers').modal('show');
                athoc.iws.publishing.iut.viewModel.targetedBlockerUsers.removeAll();
                if ($("#targetBlockingList").data("kendoGrid") != null) {
                    var data = $("#targetBlockingList").data("kendoGrid").dataSource.view();
                    $.grep(data, function (i) {
                        athoc.iws.publishing.iut.viewModel.targetedBlockerUsers.push({ UserId: i.UserId, IsBlocked: i.IsBlocked, Name: i.Name });
                    });
                }
                firstTimeOpenAddUser = 0;
                athoc.iws.publishing.iut.clearAllTargetedBlockedUsersPopUp();
            },

            // Clear all updated data and reset the grid
            clearAllTargetedBlockedUsersPopUp: function () {
                //athoc.iws.publishing.iut.viewModel.targetedBlockerUsers.removeAll();
                athoc.iws.publishing.iut.viewModel.blockedCnt(0);
                athoc.iws.publishing.iut.viewModel.targetedCnt(0);
                $("#pillContainer").html("");
                $("#txtAllUserSearch").val('');
                athoc.iws.publishing.iut.allUserSortColumn = "DisplayName";
                athoc.iws.publishing.iut.allUserSortField = "_DISPLAYNAME";
                athoc.iws.publishing.iut.allUserSortOrder = "asc";
                athoc.iws.publishing.iut.allUsersPageSize = 50;
                athoc.iws.publishing.iut.searchString.length = 0;
                /*if ($("#targetBlockingList").data("kendoGrid") != null) {
                    var data = $("#targetBlockingList").data("kendoGrid").dataSource.view();
                    $.grep(data, function (i) {
                        athoc.iws.publishing.iut.viewModel.targetedBlockerUsers.push({ UserId: i.UserId, IsBlocked: i.IsBlocked, Name: i.Name });
                    });
                }*/
                athoc.iws.publishing.iut.countTargetedBlocked();
                athoc.iws.publishing.iut.createAddBlockUsersGrid();
                //$("#btn_userSearch").attr('disabled', 'true');
                $("#AddBlockUsers").find(".bootstrap-select").remove();
                athoc.iws.publishing.iut.resizeModalBasedOnScreen($('#AddBlockUsers'));
            },

            // Show all user tab
            showAllUsers: function () {
                athoc.iws.publishing.iut.createAddBlockUsersGrid();
                athoc.iws.publishing.iut.countTargetedBlocked();
                $("#allUsersBucket").show();
                $("#targetBlockBucket").hide();

            },
            // Show targeted/blocked tab
            showTargetedBlockedUsers: function () {
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#tbUsersList'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();
                $("#tbUsersList").html('');
                athoc.iws.publishing.iut.targetBlockPageSize = 50;
                athoc.iws.publishing.iut.targetingBlockUsers();
                $("#allUsersBucket").hide();
                $("#targetBlockBucket").show();
                $.AjaxLoader.hideLoader();

            },
            // Check event of checkbox in all user grid
            Targeted: function (obj) {
                var userId = obj.getAttribute("value");
                var item = _.find(athoc.iws.publishing.iut.viewModel.allAvailableUser(), function (i) {
                    return i.Id == userId;
                });
                //athoc.iws.publishing.settings.IndividualUserTargetSelectionLimit = 5;
                if (obj.checked && athoc.iws.publishing.iut.viewModel.targetedCnt() >= athoc.iws.publishing.settings.IndividualUserTargetSelectionLimit) {
                    $("#AddBlockUsers").append('<div id="displayShadow" class="modal-backdrop fade in"></div>');
                    $("#lblUsersLimit").html(athoc.iws.publishing.settings.IndividualUserTargetSelectionLimit);
                    $('#btn_limitCancel').on('click', function (event) {
                        $("#dialogUsersLimit").hide();

                        $("#AddBlockUsers").find('#displayShadow').remove();
                    });
                    $("#dialogUsersLimit").show();
                    obj.checked = false;
                    return false;
                }
                if (item != null) {
                    item.IsBlocked = false;
                    item.IsTargeted = obj.checked;
                    athoc.iws.publishing.iut.updateTargetedBlockedUsers(item);
                    athoc.iws.publishing.iut.retainSelectAll();
                }
            },
            //Block event of all users grid
            blockUser: function (obj) {
                var userId = obj;
                var item = _.find(athoc.iws.publishing.iut.viewModel.allAvailableUser(), function (i) {
                    return i.Id == userId;
                });
                if (item != null) {
                    item.IsBlocked = true;
                    item.IsTargeted = false;
                    athoc.iws.publishing.iut.updateTargetedBlockedUsers(item);
                    $("#allUserList").data("kendoGrid").refresh();
                    athoc.iws.publishing.iut.retainSelectAll();
                }
            },
            // UnBlock event of all users grid
            unBlockUser: function (obj) {
                //event.preventDefault();
                var userId = obj;
                var item = _.find(athoc.iws.publishing.iut.viewModel.allAvailableUser(), function (i) {
                    return i.Id == userId;
                });
                if (item != null) {
                    item.IsBlocked = false;
                    item.IsTargeted = false;
                    athoc.iws.publishing.iut.updateTargetedBlockedUsers(item);
                    $("#allUserList").data("kendoGrid").refresh();
                    athoc.iws.publishing.iut.retainSelectAll();
                }
            },
            // Remove event of all users grid
            removeTargBlockUser: function (id) {
                athoc.iws.publishing.iut.viewModel.targetedBlockerUsers.remove(function (i) { return i.UserId == id; });
                var item = _.find(athoc.iws.publishing.iut.viewModel.allAvailableUser(), function (i) {
                    return i.Id == id;
                });
                if (item != null) {
                    item.IsBlocked = false;
                    item.IsTargeted = false;
                }
                athoc.iws.publishing.iut.countTargetedBlocked();
                //var ds = $("#tbUsersList").data("kendoGrid").dataSource;
                //ds.remove(function (i) { return i.UserId == id; });
                //  $("#tbUsersList").data("kendoGrid").refresh();
            },
            // Adding targeted and blocked user to array
            updateTargetedBlockedUsers: function (obj) {
                var displayName = '';
                var item = _.find(athoc.iws.publishing.iut.viewModel.targetedBlockerUsers(), function (i) {
                    return obj.Id == i.UserId;
                });
                if (item == null && (obj.IsBlocked || athoc.iws.publishing.iut.viewModel.targetedCnt() < athoc.iws.publishing.settings.IndividualUserTargetSelectionLimit)) {
                    if (obj._DISPLAYNAME != null && $.trim(obj._DISPLAYNAME) != '' && $.trim(obj._DISPLAYNAME) != 'N/A')
                        displayName = obj._DISPLAYNAME;
                    else if ((obj._FIRSTNAME != null && $.trim(obj._FIRSTNAME) != '') || (obj._LASTNAME != null && $.trim(obj._LASTNAME) != ''))
                        displayName = $.trim(obj._FIRSTNAME + ' ' + obj._LASTNAME);
                    else
                        displayName = obj._LOGIN_ID;

                    athoc.iws.publishing.iut.viewModel.targetedBlockerUsers.push({ UserId: obj.Id, Name: displayName, IsBlocked: obj.IsBlocked });
                }
                else {
                    if (obj.IsBlocked == false && obj.IsTargeted == false)
                        athoc.iws.publishing.iut.viewModel.targetedBlockerUsers.remove(function (i) { return i.UserId == obj.Id });
                    else {
                        item.IsBlocked = obj.IsBlocked;
                    }
                }
                athoc.iws.publishing.iut.countTargetedBlocked();
            },
            // Updating targeted and blocked user count
            countTargetedBlocked: function () {
                athoc.iws.publishing.iut.viewModel.targetedCnt(
                ko.mapping.toJS(athoc.iws.publishing.iut.viewModel.targetedBlockerUsers()).filter(function (i) {
                    return !i.IsBlocked;
                }).length);

                athoc.iws.publishing.iut.viewModel.blockedCnt(
                ko.mapping.toJS(athoc.iws.publishing.iut.viewModel.targetedBlockerUsers()).filter(function (i) {
                    return i.IsBlocked;
                }).length);
            },
            // Apply event of popup
            applyChangesToList: function () {
                var data = [];
                $.grep(athoc.iws.publishing.iut.viewModel.targetedBlockerUsers(), function (i) {
                    data.push({ IsBlocked: i.IsBlocked, Name: i.Name, UserId: i.UserId });
                });
                //athoc.iws.publishing.iut.viewModel.targetedBlockerUsers().length = 0
                //data.sort(function (l, r) { return l.Name.toLowerCase() == r.Name.toLowerCase() ? 0 : (l.Name.toLowerCase() < r.Name.toLowerCase() ? -1 : 1); }).sort(function (l, r) { return l.IsBlocked < r.IsBlocked ? -1 : 1; });
                if (data.length > 0)
                    data.sort(function (l, r) { return [l.IsBlocked, l.Name.toLowerCase()] < [r.IsBlocked, r.Name.toLowerCase()] ? -1 : 1 })
                var tbuList = new kendo.data.DataSource({
                    data: data,
                });

                $("#targetBlockingList").data("kendoGrid").setDataSource(tbuList);
                $('#AddBlockUsers').modal('hide');
                athoc.iws.publishing.iut.updateChangesToSummaryAndChart();
                athoc.iws.publishing.targetUsers.targetingChanged();
                athoc.iws.publishing.iut.dataChanged();

            },
            // Updating the Pie chart data and targeted summary
            updateChangesToSummaryAndChart: function () {
                var targetCount = ko.mapping.toJS(athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList()).filter(function (i) {
                    return !i.IsBlocked;
                }).length;

                var blockedCount = ko.mapping.toJS(athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList()).filter(function (i) {
                    return i.IsBlocked;
                }).length;

                athoc.iws.publishing.targetUsers.getTargetedUsersCount(targetCount);
                athoc.iws.publishing.targetUsers.getBlockedUsersCount(blockedCount);


                athoc.iws.publishing.detail.isIUTLoaded = true;
                athoc.iws.publishing.targetUsers.updateContactInfo();

            },

            // Bind data to targeted/blocked users grid
            targetingBlockUsers: function () {
                var dataTb = [];
                var sortState = '';
                $.grep(athoc.iws.publishing.iut.viewModel.targetedBlockerUsers(), function (i) {
                    dataTb.push({ IsBlocked: i.IsBlocked, Name: $.htmlDecode(i.Name), UserId: i.UserId });
                });

                if (athoc.iws.publishing.iut.targetBlockSort == "asc")
                    dataTb.sort(function (l, r) { return [l.IsBlocked, l.Name.toLowerCase()] < [r.IsBlocked, r.Name.toLowerCase()] ? -1 : 1 });
                else {
                    var tList = ko.mapping.toJS(dataTb).filter(function (i) {
                        return !i.IsBlocked;
                    }).sort(function (i, j) { return i.Name.toLowerCase() > j.Name.toLowerCase() ? -1 : 1; });

                    var rList = ko.mapping.toJS(dataTb).filter(function (i) {
                        return i.IsBlocked;
                    }).sort(function (i, j) { return i.Name.toLowerCase() > j.Name.toLowerCase() ? -1 : 1; });

                    dataTb.length = 0;
                    dataTb = tList.concat(rList);
                }

                var datasourcetbu = new kendo.data.DataSource({
                    data: dataTb,
                    pageSize: athoc.iws.publishing.iut.targetBlockPageSize,
                    change: function (e) {
                        var newState = JSON.stringify(this.sort());
                        if (newState != sortState) {
                            sortState = newState;
                            e.preventDefault();
                            this.page(1);
                        }

                    }
                });
                $("#tbUsersList").html('');
                //datasource.read();
                var grid = $("#tbUsersList").kendoGrid({
                    dataSource: datasourcetbu,
                    selectable: false,
                    scrollable: true,
                    sortable: false,
                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5,
                        messages: {
                            display: $.htmlDecode(athoc.iws.publishing.iut.resources.IUTAllUsers_PagingInfo),
                            empty: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Empty),
                            itemsPerPage: $.htmlDecode(athoc.iws.publishing.iut.resources.IUT_ItemsPerPage),
                            first: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                            previous: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                            next: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                            last: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                        }
                    },
                    columns:
                            [
                                 {
                                     field: "",
                                     title: "",
                                     template: $("#targblock-imgtargeting-template").html(),
                                     width: "3%",
                                     headerAttributes: {
                                         tabindex: "2"
                                     }
                                 },
                                 {
                                     field: "Name",
                                     title: athoc.iws.publishing.iut.resources.IUTTBUserList_Name,
                                     // template: '<span title="#=Name#">#=Name#</span>',
                                     template: $("#targblock-name-template").html(),
                                     width: "92%",
                                     headerTemplate: kendo.format('<span title="' + athoc.iws.publishing.iut.resources.IUTTBUserList_Name + '" onclick="athoc.iws.publishing.iut.onTargetBlockedNameSort();">' + athoc.iws.publishing.iut.resources.IUTTBUserList_Name + '</span>{0}', athoc.iws.publishing.iut.targetBlockSort.toUpperCase() == "ASC" ? '<span class="sort-indicator-ascending"></span>' : '<span class="sort-indicator-descending"></span>'),
                                     headerAttributes: {
                                         tabindex: "3"
                                     }
                                 },
                                {
                                    field: "",
                                    title: athoc.iws.publishing.iut.resources.IUTTBUserList_Remove_User,
                                    template: $("#targblock-imgremove-template").html(),
                                    headerTemplate: kendo.format('<span title="{0}">{1}</span>', "", ""),
                                    width: "5%",
                                    headerAttributes: {
                                        tabindex: "4"
                                    }
                                },

                            ],
                    dataBound: athoc.iws.publishing.iut.onTargetBlockedDataBound,
                    change: function (e) {
                    }
                }).data().kendoGrid;

                athoc.iws.publishing.iut.fitHeighUserList();
            },
            // Databind evnet of targeted/blocked user grid
            onTargetBlockedDataBound: function (e) {
                var data = $("#tbUsersList").data("kendoGrid").dataSource.data();
                athoc.iws.publishing.iut.viewModel.targetedBlockerUsers(data);
                athoc.iws.publishing.iut.OnBoundTargetedBlockedEmptyRow(data);
                athoc.iws.publishing.iut.targetBlockPageSize = $("#tbUsersList").data("kendoGrid").dataSource._pageSize;
            },

            onTargetBlockeddataBinding: function (e) {
                var ds = $("#tbUsersList").data("kendoGrid").dataSource;
                ds._sort = [{ field: 'Name', dir: athoc.iws.publishing.iut.targetBlockSort }];
            },

            onTargetBlockedNameSort: function (e) {
                if (athoc.iws.publishing.iut.targetBlockSort == "asc")
                    athoc.iws.publishing.iut.targetBlockSort = "desc";
                else
                    athoc.iws.publishing.iut.targetBlockSort = "asc"

                athoc.iws.publishing.iut.targetingBlockUsers();
            },

            OnBoundTargetedBlockedEmptyRow: function (data) {
                var colCount = $("#tbUsersList").find('.k-grid-header colgroup > col').length;
                if (data.length == 0) {
                    $("#tbUsersList").find('.k-grid-content tbody')
                        .append('<tr class="kendo-data-row"><td colspan="' +
                            colCount +
                            '" style="text-align:center;height:10px;overflow:auto;">' +
                            kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', athoc.iws.publishing.iut.resources.IUTTBUserList_Emptyrow_Message, athoc.iws.publishing.iut.resources.IUTTBUserList_Emptyrow_Message) +
                            '</td></tr>');

                }
            },

            showTargetedUsersSummary: function (isReadonly) {
                var sortState = '';
                var dataTb = [];
                $.grep(athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList(), function (i) {
                    if (!i.IsBlocked)
                        dataTb.push({ IsBlocked: i.IsBlocked, Name: i.Name, UserId: i.UserId });
                });

                dataTb.sort(function (l, r) { return [l.IsBlocked, l.Name.toLowerCase()] < [r.IsBlocked, r.Name.toLowerCase()] ? -1 : 1 })
                var datasourcetbu = new kendo.data.DataSource({
                    data: dataTb,
                    pageSize: 50,
                    change: function (e) {
                        var newState = JSON.stringify(this.sort());
                        if (newState != sortState) {
                            sortState = newState;
                            e.preventDefault();
                            this.page(1);
                        }

                    }
                });
                //datasource.read();
                var cntrl = isReadonly ? $("#targetedUsersListDetail") : $("#targetedUsersList");
                cntrl.html('');
                var grid = cntrl.kendoGrid({
                    dataSource: datasourcetbu,
                    selectable: false,
                    scrollable: true,
                    sortable: { allowUnsort: false },
                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5,
                        messages: {
                            display: $.htmlDecode(athoc.iws.publishing.iut.resources.IUTAllUsers_PagingInfo),
                            empty: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Empty),
                            itemsPerPage: $.htmlDecode(athoc.iws.publishing.iut.resources.IUT_ItemsPerPage),
                            first: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                            previous: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                            next: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                            last: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                        }
                    },
                    columns:
                            [
                                 {
                                     field: "Name",
                                     title: athoc.iws.publishing.iut.resources.IUTTargetedSummary_Name,
                                     template: '<span title="#=Name#">#=Name#</span>',
                                     width: "95%",
                                     headerAttributes: {
                                         tabindex: "3"
                                     }
                                 },
                            ],
                    change: function (e) {
                    }
                }).data().kendoGrid;
                grid.refresh();
                athoc.iws.publishing.iut.resizeModalBasedOnScreen($('#targetedUsersSummary'));
                athoc.iws.publishing.iut.fitHeightTargetedUsersSummaryList();
            },

            showBlockedUsersSummary: function (isReadonly) {
                var dataTb = [];
                var sortState = '';
                $.grep(athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList(), function (i) {
                    if (i.IsBlocked)
                        dataTb.push({ IsBlocked: i.IsBlocked, Name: i.Name, UserId: i.UserId });
                });

                dataTb.sort(function (l, r) { return [l.IsBlocked, l.Name.toLowerCase()] < [r.IsBlocked, r.Name.toLowerCase()] ? -1 : 1 })
                var datasourcetbu = new kendo.data.DataSource({
                    data: dataTb,
                    pageSize: 50,
                    change: function (e) {
                        var newState = JSON.stringify(this.sort());
                        if (newState != sortState) {
                            sortState = newState;
                            e.preventDefault();
                            this.page(1);
                        }

                    }
                });

                //datasource.read();
                var cntrl = isReadonly ? $("#blockedUsersListDetail") : $("#blockedUsersList");
                cntrl.html('');
                var grid = cntrl.kendoGrid({
                    dataSource: datasourcetbu,
                    selectable: false,
                    scrollable: true,
                    sortable: { allowUnsort: false },
                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5,
                        messages: {
                            display: $.htmlDecode(athoc.iws.publishing.iut.resources.IUTAllUsers_PagingInfo),
                            empty: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Empty),
                            itemsPerPage: $.htmlDecode(athoc.iws.publishing.iut.resources.IUT_ItemsPerPage),
                            first: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                            previous: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                            next: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                            last: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                        }
                    },
                    columns:
                            [
                                 {
                                     field: "Name",
                                     title: athoc.iws.publishing.iut.resources.IUTBlockedSummary_Name,
                                     template: '<span title="#=Name#">#=Name#</span>',
                                     width: "95%",
                                     headerAttributes: {
                                         tabindex: "3"
                                     }
                                 },
                            ],
                    change: function (e) {
                    }
                }).data().kendoGrid;
                athoc.iws.publishing.iut.resizeModalBasedOnScreen($('#blockedUsersSummary'));
                athoc.iws.publishing.iut.fitHeightBlockedUsersSummaryList();

            },
            //Method to handle erro and session time out, this is boud with Ajax calls
            handleError: function (e) {

                if (e != undefined && e.status == 401 || (e != undefined && e.xhr != undefined && e.xhr.status == 401)) {
                    window.onbeforeunload = null;
                    window.location = window.location;
                } else if (e.errorThrown != "") {
                    if (athoc.iws.publishing.iut.errors === null) {
                        athoc.iws.publishing.iut.errors = [{ Type: '4', Value: e.errorThrown }];
                    } else {
                        athoc.iws.publishing.iut.errors.push({ Type: '4', Value: e.errorThrown });
                    }
                    $('#listMessagePanel').messagesPanel({ messages: this.errors }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                }
            },
            getTargetedUsers: function () {

                var targetdata = [];

                if (athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList().length > 0) {
                    $(athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList()).each(function (index, item) {
                        if (!item.IsBlocked)
                            targetdata.push(item.UserId);
                    });
                }
                return targetdata;
            },

            getBlockedUsers: function () {
                var blockeddata = [];
                if (athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList().length > 0) {
                    $(athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList()).each(function (index, item) {
                        if (item.IsBlocked)
                            blockeddata.push(item.UserId);
                    });
                }
                return blockeddata;
            },
            Rebind: function (data) {
                $(data).each(function (index, item) {
                    athoc.iws.publishing.iut.viewModel.targetedBlockerUsers.remove(function (i) { return i.UserId == item; });
                });

                athoc.iws.publishing.iut.firsttimneLoad = false;

                // dataobject for maniplication
                athoc.iws.publishing.iut.createTargettingUserListGrid(athoc.iws.publishing.iut.viewModel.targetedBlockerUsers());
                $('#targetBlockingList .k-grid-header').hide();
                $('#targetBlockingList .k-pager-wrap').hide();
                athoc.iws.publishing.targetUsers.targetingChanged();
            },
           
        };
    }();
}

///#source 1 1 /Scripts/Publishing/athoc.iws.publishing.fillcount.js
/* define javascript namespace for fill count  */
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};
if (athoc.iws.publishing) {
    $.fn.setCursorPosition = function (pos) {
        this.each(function (index, elem) {
            if (elem.setSelectionRange) {
                elem.setSelectionRange(pos, pos);
            } else if (elem.createTextRange) {
                var range = elem.createTextRange();
                range.collapse(true);
                range.moveEnd('character', pos);
                range.moveStart('character', pos);
                range.select();
            }
        });
        return this;
    };
    athoc.iws.publishing.fillcount = function () {
        //
        return {
            //is model changed
            isChanged: false,
            responseChangedText: '',
            deleteResponseIndex: -1,
            confirmationDailogType: 0,
            isTUSectionReadonly: false,
            // fill count summary 
            fillCountSummary: ko.observable(),
            defaultFillCountSummary: {
                ResponseText: "",
                FillCount: 0,
                AttributeName: "",
                ControlDeliveryTypeText: "",
                WaitTimeTitle: "",
                WaitTime: "",
                ControlDeliveryType: 0,
            },
            defaultFillCount: {
                ResponseOptionId: -1,
                EntityId: 0,
                AnyResponseOption: true,
                FillCount: 1,
                EscalationAttributeId: 0,
                PhoneAttributeId: 0,
                WaitTime: 15,
                WaitTimeUnit: "Minutes",
                GroupByAscending: true,
                OrderByAscending: true,
                ControlledDeliveryType: 0,
                EnableControlledDelivery: false,
                EnableEscalation: false,
            },

            // viewmodel
            viewModel: {
                initialFocus: ko.observable(true),
                fillCountModel: ko.observable(),
                responseOptions: ko.observableArray(),
                escalationAttributes: ko.observableArray(),
                phonesequencingAttributes: ko.observableArray(),
                waitTimeUnits: ko.observableArray(),
                editFillCountModel: {},
            },
            //This method is used to resize the popup when window is resizing
            attachResizePopupWindowEvent: function () {
                var resizeFunction = function () {
                    if ($(window).height() > 1024)
                        athoc.iws.utilities.resizeModalBasedOnScreen($('#FillCount'), 600, 770, 20, 170);
                    else
                        athoc.iws.utilities.resizeModalBasedOnScreen($('#FillCount'), 560, 710, 15, 145);

                    athoc.iws.publishing.fillcount.fcDivScrollEventActions();

                }
                var updateLayout = _.debounce(resizeFunction, 500); // Maximum run of once per 500 milliseconds
                window.addEventListener("resize", updateLayout, false);
            },
            fcDivScrollEventActions: function () {
                if ($('#FillCount .modal-body').get(0).scrollHeight > $('#FillCount .modal-body').innerHeight())
                    $("#secondBucket").removeClass("mar-bot0");
                else
                    $("#secondBucket").addClass("mar-bot0");

            },
            //This is method when new data is loaded from publishing model
            load: function () {
                athoc.iws.publishing.fillcount.viewModel.waitTimeUnits.push({ text: athoc.iws.publishing.fillcount.resources.FillCount_Minutes, value: "Minutes" });
                athoc.iws.publishing.fillcount.viewModel.waitTimeUnits.push({ text: athoc.iws.publishing.fillcount.resources.FillCount_Hours, value: "Hours" });

                // Edit Link to show Fill Count UI
                $("#EditFillCount").click(function () {
                    $('#FillCount').modal('show');
                    athoc.iws.publishing.fillcount.attachResizePopupWindowEvent();
                    // athoc.iws.utilities.resizeModalBasedOnScreenwithCenter($('#FillCount'), 600, 770, (navigator.userAgent.toLocaleLowerCase().indexOf('mozilla') != -1 ? 25 : 40), 170, 720, 40, 770);
                    athoc.iws.publishing.fillcount.viewModel.editFillCountModel = ko.mapping.toJS(athoc.iws.publishing.fillcount.viewModel.fillCountModel);
                    athoc.iws.publishing.fillcount.showFillCount();
                });

                // Open Fill Count Popup
                $("#FillCountLink").click(function () {
                    if (!athoc.iws.publishing.fillcount.isResponsesAvailable()) {
                        /// TODO move text to resource file
                        athoc.iws.publishing.fillcount.showConfirmationDialog(3, $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_AtleastOneResponse));
                    } else {
                        $('#FillCount').modal('show');
                        athoc.iws.publishing.fillcount.attachResizePopupWindowEvent();
                        //athoc.iws.utilities.resizeModalBasedOnScreenwithCenter($('#FillCount'), 600, 770, (navigator.userAgent.toLocaleLowerCase().indexOf('mozilla') != -1 ? 25 : 40), 170, 720, 40, 770);
                        athoc.iws.publishing.fillcount.viewModel.editFillCountModel = ko.mapping.toJS(athoc.iws.publishing.fillcount.viewModel.fillCountModel);
                        athoc.iws.publishing.fillcount.showFillCount();

                    }
                });

                //Apply Fill Count on Target User Section
                $("#ApplyFillCount").click(function () {
                    if (!athoc.iws.publishing.fillcount.isValid()) {
                        $("#FillCountSummary").show();
                        $("#EditFillCountDetails").show();
                        $("#FillCountLink").hide();
                        $('#FillCount').modal('hide');
                        athoc.iws.publishing.fillcount.setFillCountSummary(null);
                        var targetDiv = $("#publishing-user-edit");
                        athoc.iws.publishing.fillcount.ShowFillCountSummary(athoc.iws.publishing.fillcount.fillCountSummary, targetDiv);

                        athoc.iws.publishing.fillcount.isChanged = true;
                    }
                });

                //Cancel Fill Count 
                $("#CancelFillCount").click(function () {
                    $('#FillCount').modal('hide');
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.ResponseOptionId);
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.AnyResponseOption(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.AnyResponseOption);
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.FillCount(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.FillCount);
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.ControlledDeliveryType);
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.EscalationAttributeId(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.EscalationAttributeId);
                    $('#escalationAttribute').selectpicker('refresh');

                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.WaitTime);
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTimeUnit(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.WaitTimeUnit);
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.GroupByAscending(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.GroupByAscending);
                    // athoc.iws.publishing.fillcount.viewModel.fillCountModel.PhoneAttributeId(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.PhoneAttributeId);
                    // $('#phoneAttribute').selectpicker('refresh');
                    // athoc.iws.publishing.fillcount.viewModel.fillCountModel.OrderByAscending(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.OrderByAscending);
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.EntityId(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.ControlledDeliveryType.EntityId);
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.EnableEscalation(athoc.iws.publishing.fillcount.viewModel.editFillCountModel.EnableEscalation);
                });

                //Clear Fill Count
                $("#ClearFillCount").click(function () {
                    athoc.iws.publishing.fillcount.confirmationDailogType = 1;
                    /// TODO move text to resource file
                    athoc.iws.publishing.fillcount.showConfirmationDialog(1, athoc.iws.publishing.fillcount.resources.FillCount_Removemsg);
                });
            },

            // Modal resizing
            resizeModalBasedOnScreen: function (modal) {
                modal.find(".modal-body").css("max-height", 460);
                var windowHeight = $(window).height();

                if (windowHeight > 770) {
                    modal.css("margin-top", 60 - (windowHeight / 2) + ((windowHeight - 770) / 2));
                    modal.find(".modal-body").css("height", windowHeight - 340);
                } else {
                    modal.css("margin-top", 60 - (windowHeight / 2));
                    modal.find(".modal-body").css("height", windowHeight - 240);
                }

                if (modal.height() + 170 > windowHeight) {
                    var newHeight = windowHeight - 170;
                    modal.find(".modal-body").css("max-height", newHeight);

                }

            },

            // to show escalation breadcrum
            showEscalationBreadCrum: function (flag) {
                if (!flag) {
                    $("#showEscalationBreadCrumLess").show();
                    $("#showEscalationBreadCrumMore").hide();
                } else {
                    $("#showEscalationBreadCrumLess").hide();
                    $("#showEscalationBreadCrumMore").show();
                }
                athoc.iws.publishing.fillcount.fcDivScrollEventActions();
                return false;
            },

            EditFillcount: function () {

                $('#FillCount').modal('show');
                athoc.iws.publishing.fillcount.attachResizePopupWindowEvent();
                //athoc.iws.utilities.resizeModalBasedOnScreenwithCenter($('#FillCount'), 600, 770, (navigator.userAgent.toLocaleLowerCase().indexOf('mozilla') != -1 ? 25 : 40), 170, 720, 40, 770);
                athoc.iws.publishing.fillcount.viewModel.editFillCountModel = ko.mapping.toJS(athoc.iws.publishing.fillcount.viewModel.fillCountModel);
                athoc.iws.publishing.fillcount.showFillCount();
            },
            /// TODO : we can delete this method
            CancelDailog: function () {
                if (athoc.iws.publishing.fillcount.confirmationDailogType == 1 || athoc.iws.publishing.fillcount.confirmationDailogType == 0)
                    $("#dialogResponseDeleteConfirm").modal("hide");
                else if (athoc.iws.publishing.fillcount.confirmationDailogType == 2) {
                    athoc.iws.publishing.fillcount.fillCountSummary.ResponseText(athoc.iws.publishing.fillcount.responseChangedText);
                    athoc.iws.publishing.fillcount.responseChangedText = '';
                    $("#dialogResponseChangeConfirm").modal("hide");
                } else if (athoc.iws.publishing.fillcount.confirmationDailogType == 3) {
                    athoc.iws.publishing.content.viewModel.data.ResponseOptionId(athoc.iws.publishing.content.responseOptionPreviousId);
                    $('#responseList').selectpicker('refresh');
                    $("#dialogResponseDeleteConfirm").modal("hide");
                }
                athoc.iws.publishing.fillcount.confirmationDailogType = 0;
            },

            localizeTimeUnit: function (unit) {
                if ((unit.toLowerCase() == "hour") || (unit.toLowerCase() == "hours"))
                    return $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_Hours);
                if ((unit.toLowerCase() == "minute") || (unit.toLowerCase() == "minutes"))
                    return $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_Minutes);
            },

            // set Fill count summary data
            setFillCountSummary: function (existingSummary) {
                var self = athoc.iws.publishing.fillcount.fillCountSummary;
                if (existingSummary == null) {
                    self.ResponseText($("#fillCountResponses option:selected").text());
                    self.FillCount($("#fillcount").val() + ' ' + $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_Summary_ResponseText));



                    switch (athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType()) {
                        case 0:
                            self.ControlDeliveryType(0);
                            self.ControlDeliveryTypeText("");
                            self.AttributeName("");
                            self.WaitTimeTitle("");
                            self.WaitTime("");

                            break;
                        case 1:
                            self.ControlDeliveryType(1);
                            self.ControlDeliveryTypeText( $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_ControlledDelivery_Escalation));
                            self.AttributeName($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_EscalationBy) + ' ' + $("#escalationAttribute option:selected").text() + ' ' + (athoc.iws.publishing.fillcount.viewModel.fillCountModel.GroupByAscending() ? $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_ToptoBottom) : $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_BottomtoTop)));
                            self.WaitTimeTitle($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_WaitTime));
                            self.WaitTime(athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime() + ' ' + athoc.iws.publishing.fillcount.localizeTimeUnit((athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime() > 1 ? athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTimeUnit().toLowerCase() : athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTimeUnit().toLowerCase().substring(0, athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTimeUnit().length - 1))));
                            break;
                        case 2:
                            self.ControlDeliveryType(2);
                            self.ControlDeliveryTypeText($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_ControlledDelivery_Escalation));
                            self.AttributeName($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_EscalationBy) + ' ' + $("#escalationAttribute option:selected").text() + ' ' + (athoc.iws.publishing.fillcount.viewModel.fillCountModel.GroupByAscending() ? $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_ToptoBottom) : $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_BottomtoTop)));
                            self.WaitTimeTitle($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_WaitTime));
                            self.WaitTime(athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime() + ' ' + athoc.iws.publishing.fillcount.localizeTimeUnit((athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime() > 1 ? athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTimeUnit().toLowerCase() : athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTimeUnit().toLowerCase().substring(0, athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTimeUnit().length - 1))));
                            break;
                            /*    case 2:
                                    self.ControlDeliveryType(2);
                                    self.ControlDeliveryTypeText(athoc.iws.publishing.fillcount.resources.FillCount_ControlledDelivery_Sequencing);
                                    self.WaitTimeTitle("");
                                    self.WaitTime("");
                                    self.AttributeName(athoc.iws.publishing.fillcount.resources.FillCount_Sortby + ' ' + $("#phoneAttribute option:selected").text() + ' ' + (athoc.iws.publishing.fillcount.viewModel.fillCountModel.OrderByAscending() ? athoc.iws.publishing.fillcount.resources.FillCount_Asc : athoc.iws.publishing.fillcount.resources.FillCount_Desc));
                                    break;*/
                    }
                } else {
                    // set Default Fill Count Summary Model

                    self.ResponseText(athoc.iws.publishing.fillcount.getControlDeliveryAttributeValue(existingSummary.ResponseOptionId, 0));
                    self.FillCount(existingSummary.FillCount + ' ' + $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_Summary_ResponseText));
                    athoc.iws.publishing.fillcount.setNoneFillCountSummary(self);
                    var attributeName;
                    switch (existingSummary.ControlledDeliveryType) {
                        case 1:
                            attributeName = athoc.iws.publishing.fillcount.getControlDeliveryAttributeValue(existingSummary.EscalationAttributeId, 1);
                            if (attributeName != $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_SelectanAttribute)) {
                                self.ControlDeliveryType(1);
                                self.ControlDeliveryTypeText($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_ControlledDelivery_Escalation));
                                self.AttributeName($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_EscalationBy) + ' ' + attributeName + ' ' + (existingSummary.OrderByAscending == true ? $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_ToptoBottom) : $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_BottomtoTop)));
                                self.WaitTimeTitle($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_WaitTime));
                                self.WaitTime(existingSummary.WaitTime + ' ' + athoc.iws.publishing.fillcount.localizeTimeUnit((existingSummary.WaitTime > 1 ? existingSummary.WaitTimeUnit.toLowerCase() : existingSummary.WaitTimeUnit.toLowerCase().substring(0, existingSummary.WaitTimeUnit.length - 1))));
                            }
                            break;
                        case 2:
                            attributeName = athoc.iws.publishing.fillcount.getControlDeliveryAttributeValue(existingSummary.EscalationAttributeId, 1);
                            if (attributeName != $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_SelectanAttribute)) {
                                self.ControlDeliveryType(2);
                                self.ControlDeliveryTypeText($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_ControlledDelivery_Escalation));
                                self.AttributeName($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_EscalationBy) + ' ' + attributeName + ' ' + (existingSummary.OrderByAscending == true ? $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_ToptoBottom) : $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_BottomtoTop)));
                                self.WaitTimeTitle($.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_WaitTime));
                                self.WaitTime(existingSummary.WaitTime + ' ' + athoc.iws.publishing.fillcount.localizeTimeUnit((existingSummary.WaitTime > 1 ? existingSummary.WaitTimeUnit.toLowerCase() : existingSummary.WaitTimeUnit.toLowerCase().substring(0, existingSummary.WaitTimeUnit.length - 1))));

                            }
                            break;
                            /*  case 2:
                                  attributeName = athoc.iws.publishing.fillcount.getControlDeliveryAttributeValue(existingSummary.PhoneAttributeId, 2);
                                  if (attributeName != athoc.iws.publishing.fillcount.resources.FillCount_SelectanAttribute) {
                                      self.ControlDeliveryType(2);
                                      self.ControlDeliveryTypeText(athoc.iws.publishing.fillcount.resources.FillCount_ControlledDelivery_Sequencing);
                                      self.AttributeName(athoc.iws.publishing.fillcount.resources.FillCount_Sortby + ' ' + athoc.iws.publishing.fillcount.getControlDeliveryAttributeValue(existingSummary.PhoneAttributeId, 2) + ' ' + (existingSummary.OrderByAscending == true ? athoc.iws.publishing.fillcount.resources.FillCount_Asc : athoc.iws.publishing.fillcount.resources.FillCount_Desc));
                                      self.WaitTimeTitle("");
                                      self.WaitTime("");
                                  }
                                  break;*/
                    }
                }
            },

            // reset fill count summary on selecting none of delivery control type
            setNoneFillCountSummary: function (objModel) {

                // set fillcount summary attributes to default before assigning the db values
                objModel.ControlDeliveryType(0);
                objModel.ControlDeliveryTypeText("");
                objModel.AttributeName("");
                objModel.WaitTimeTitle("");
                objModel.WaitTime("");


            },

            // Attribute value from ID
            getControlDeliveryAttributeValue: function (Id, srctype) {
                var data;
                var iResponses = -1;
                var self = athoc.iws.publishing.fillcount.viewModel;
                if (srctype == 0 && Id == 0)
                    /// TODO move text to resource file
                    return athoc.iws.publishing.fillcount.resources.FillCount_Any;
                switch (srctype) {
                    case 0:
                        data = ko.mapping.toJS(self.responseOptions);
                        break;
                    case 1:
                        data = ko.mapping.toJS(self.escalationAttributes);
                        break;
                    case 2:
                        data = ko.mapping.toJS(self.phonesequencingAttributes);
                        break;
                }

                var attributeData = _.find(data, function (item) {
                    iResponses++;
                    return (srctype == 0) ? iResponses == Id : Id === item.Id;

                });
                if (attributeData == undefined)
                    switch (srctype) {
                        case 0:
                            /// TODO move text to resource file
                            return athoc.iws.publishing.fillcount.resources.FillCount_SelectaResponseOption;
                        case 1:
                        case 2:
                            /// TODO move text to resource file
                            if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType != undefined) {
                                athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType(0);
                                athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime("15");
                                athoc.iws.publishing.fillcount.viewModel.fillCountModel.EscalationAttributeId(0);
                                athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTimeUnit("Minutes");
                                athoc.iws.publishing.fillcount.viewModel.fillCountModel.GroupByAscending(true);
                            }

                            return $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_SelectanAttribute);
                            /*case 2:
                                /// TODO move text to resource file
                                if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType != undefined) {
                                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType(0);
                                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.PhoneAttributeId(0);
                                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.OrderByAscending(true);
                                
                                return athoc.iws.publishing.fillcount.resources.FillCount_SelectanAttribute;
                                }*/
                    }

                return attributeData.Name;
            },

            // to fill summary section0
            ShowFillCountSummary: function (fillcountsummary, targetDiv) {
                ko.cleanNode(targetDiv.find("#FillCountDetails").get(0));
                ko.applyBindings(fillcountsummary, targetDiv.find("#FillCountDetails").get(0));
            },

            // to show fill count modal
            showFillCount: function () {


                var escalationDiv = $("#EscalationAttributeBreadCrum");
                if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType() == 0)
                    escalationDiv.hide();
                else
                    athoc.iws.publishing.fillcount.escalationBreadCrum(athoc.iws.publishing.fillcount.viewModel.fillCountModel.EscalationAttributeId());


                athoc.iws.publishing.fillcount.viewModel.responseOptions(athoc.iws.publishing.fillcount.fillResponses(ko.mapping.toJS(athoc.iws.publishing.content.viewModel.data.ResponseOptions || athoc.iws.publishing.view.viewModel.data.Content.ResponseOptions)));
                $("#responseOption").find(".bootstrap-select").remove();
                ko.cleanNode($("#responseOption").get(0));
                ko.applyBindings(athoc.iws.publishing.fillcount.viewModel, $("#responseOption").get(0));
                $("#fillCountResponses").selectpicker('refresh');
                $("#waitTimeDuration").selectpicker('refresh');

                //athoc.iws.publishing.fillcount.enableControlDeliveryAttributes(athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType());
                $('#FillCount').modal({
                    keyboard: true
                }).promise().done(function () {
                    setTimeout(function () {
                        $("#fillcount").trigger('focus').setCursorPosition($("#fillcount").val().length);
                        //    $('[data-id=fillCountResponses]').trigger('focus');
                    }, 1000);
                });

            },

            // to enable the control delivery attributes based on delivery control  type attribute selection
            enableControlDeliveryAttributes: function (newValue) {
                switch (newValue) {
                    case 0:
                        $("#ErrorMsg_EscalationAttributeId").css('display', "none");
                        $("#ErrorMsg_PhoneAttributeId").css('display', "none");
                        $("#EscalationAttributeBreadCrum").hide();
                        $('[data-id=escalationAttribute]').attr("disabled", "disabled");
                        $('[data-id=phoneAttribute]').attr("disabled", "disabled");
                        $('[data-id=waitTimeDuration]').attr("disabled", "disabled");
                        break;
                    case 1:
                        $("#ErrorMsg_PhoneAttributeId").css('display', "none");
                        $("#EscalationAttributeBreadCrum").show();
                        $('[data-id=escalationAttribute]').removeAttr("disabled");
                        $('[data-id=phoneAttribute]').attr("disabled", "disabled");
                        $('[data-id=waitTimeDuration]').removeAttr("disabled");
                        break;
                    case 2:
                        $("#ErrorMsg_EscalationAttributeId").css('display', "none");
                        $("#EscalationAttributeBreadCrum").hide();
                        $('[data-id=phoneAttribute]').removeAttr("disabled");
                        $('[data-id=escalationAttribute]').attr("disabled", "disabled");
                        $('[data-id=waitTimeDuration]').attr("disabled", "disabled");
                        break;

                }
            },

            // to generate escalation breadcrum based on escalation attribute selection
            escalationBreadCrum: function (Id) {

                var toData = ko.mapping.toJS(athoc.iws.publishing.fillcount.viewModel.escalationAttributes);
                var data = _.find(toData, function (toItem) {
                    return Id === toItem.Id;
                });
                var escalationDiv = $("#divEscalationAttributeBreadCrum");
                var template = kendo.template($("#fillCountEscalate-template").html());
                var lessdata = '';
                var moredata = '';
                var noitems = 0;
                var txtStyle = "font-size:11px; white-space:nowrap;display:none";
                data = data.Values;
                if (data == null || Id == 0) {
                    escalationDiv.hide();
                    return;
                } else
                    escalationDiv.show();
                if (!athoc.iws.publishing.fillcount.viewModel.fillCountModel.GroupByAscending())
                    data = data.reverse();

                for (var i = 0; i < data.length; i++) {                         
                    if ((lessdata == moredata) && this.fnCalcTextWidth("", txtStyle, ((lessdata + (lessdata != "" ? " > " : "") + data[i]) + " and more...")) < 385) { 
                        lessdata = lessdata + (lessdata != "" ? " > " : "") + data[i];
                        noitems++;
                    }
                    if (data.length > 1)
                        moredata = moredata + (moredata != "" ? " > " : "") + data[i];
                }
                if (lessdata == moredata)
                    moredata = "";
                noitems = ((data.length) - noitems);
                var data = { more: moredata, less: lessdata, items: noitems };
                var result = template(data);
                $("#escalationAttributeBreadCrum").html(result);
                
                if (moredata != "")
                    $("#morelinkfillcount").show();
                else
                    $("#morelinkfillcount").hide();
            },
            fnCalcTextWidth: function (Class,Style,text) {
                var tmpSpan = $('<span id="escalationAttributeBreadCrumTmp" ' + (Class != '' ? ' class="' + Class + '" ' : '') + '  ' + (Style != '' ? ' style="' + Style + '" ' : '') + ' >' + text + '</span>')
                      .appendTo($('body'));
                columnWidth = tmpSpan.width();
                tmpSpan.remove();
                return columnWidth;
            },
            // Subcribe Methods to capture changed state
            fillCountSubscribeMethods: function () {
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.EnableControlledDelivery.subscribe(function (newValue) {
                    if (!newValue)
                        athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType(1);
                    else
                        athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType(2);
                });
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.EnableEscalation.subscribe(function (newValue) {
                    ///IWS-15930
                    //athoc.iws.utilities.resizeModalBasedOnScreenwithCenter($('#FillCount'), 600, 770, (navigator.userAgent.toLocaleLowerCase().indexOf('mozilla') != -1 ? 25 : 40), 170, 720, 40, 770);
                    if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime() == "" || isNaN(athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime()))
                        athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime('15');
                    if (!newValue) {
                        athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType(0);
                    } else
                        athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType(athoc.iws.publishing.fillcount.viewModel.fillCountModel.EnableControlledDelivery() ? 2 : 1);
                    athoc.iws.publishing.fillcount.fcDivScrollEventActions();
                });

                athoc.iws.publishing.fillcount.viewModel.fillCountModel.FillCount.subscribe(function (newValue) {
                    ///IWS-15930
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.FillCount($.trim(newValue));
                });

                athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId.subscribe(function (newValue) {

                });

                athoc.iws.publishing.fillcount.viewModel.fillCountModel.GroupByAscending.subscribe(function (newValue) {
                    athoc.iws.publishing.iut.readOnlySortColumn = "";
                    athoc.iws.publishing.iut.readOnlySortOrder = "";
                    athoc.iws.publishing.fillcount.escalationBreadCrum(athoc.iws.publishing.fillcount.viewModel.fillCountModel.EscalationAttributeId());
                });



                athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime.subscribe(function (newValue) {
                    ///IWS-15930
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime($.trim(newValue));
                });

                athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTimeUnit.subscribe(function (newValue) {
                });

                athoc.iws.publishing.fillcount.viewModel.fillCountModel.EscalationAttributeId.subscribe(function (newValue) {

                    // if (athoc.iws.publishing.iut.readOnlySortColumn != null || athoc.iws.publishing.iut.readOnlySortColumn!=undefined)

                    athoc.iws.publishing.iut.readOnlySortColumn = "";
                    athoc.iws.publishing.iut.readOnlySortOrder = "";

                    athoc.iws.publishing.fillcount.escalationBreadCrum(newValue);


                });

                /*      athoc.iws.publishing.fillcount.viewModel.fillCountModel.PhoneAttributeId.subscribe(function (newValue) {
                          if (newValue == 0) {
                              $("#ErrorMsg_EscalationAttributeId").css('display', "none");
                              /// TODO move text to resource file
                              $("#ErrorMsg_PhoneAttributeId").html(athoc.iws.publishing.fillcount.resources.FillCount_FieldRequired);
                              $("#ErrorMsg_PhoneAttributeId").css('display', "inline-block");
                          }
                      });*/
            },

            // data from server side
            bind: function (data, isReadOnly) {

                athoc.iws.publishing.fillcount.isTUSectionReadonly = isReadOnly;

                //reset fill count model  based on fill count settings
                if (athoc.iws.publishing.fillcount.clearFillCountData(data.ScenarioSettings.Targeting.FillCount, data.FillCount))
                    return;

                // initilize data model
                athoc.iws.publishing.fillcount.initializeFillCountModel(data);
                // make sure to verify scenario setting before loading the data               

                if (!isReadOnly) {
                    athoc.iws.publishing.fillcount.enableFillCountSummary(data.ScenarioSettings.Targeting.FillCount);
                    $("#fillCountContent").find(".bootstrap-select").remove();
                    ko.cleanNode($("#fillCountContent").get(0));
                    ko.applyBindings(athoc.iws.publishing.fillcount.viewModel, $("#fillCountContent").get(0));
                    athoc.iws.publishing.fillcount.fillCountSubscribeMethods();
                    athoc.iws.publishing.fillcount.initiatePickers();
                } else {
                    athoc.iws.publishing.fillcount.readOnlyFillCountSummary(null, $("#publishing-user-detail"), false, data.ScenarioSettings.Targeting.FillCount);
                }
            },

            // to clear the fill count on removing  the fill count settings
            clearFillCountData: function (isFillCountEnabled, fillCountData) {
                if (!isFillCountEnabled && fillCountData != null && athoc.iws.publishing.fillcount.viewModel.fillCountModel.EntityId != undefined) {
                    var entityId = athoc.iws.publishing.fillcount.viewModel.fillCountModel.EntityId();
                    // default model values to fill count model
                    athoc.iws.publishing.fillcount.setDefaultFillCountModel();
                    return true;
                }
                return false;
            },

            // to enable or disable the fill count summary based on scenario settings and readonly mode
            enableFillCountSummary: function (isFillCountEnabled) {
                if (!isFillCountEnabled) {
                    $("#publishing-user-edit").find("#FillCountLink").hide();
                    $("#publishing-user-edit").find("#EditFillCountDetails").hide();
                    $("#publishing-user-edit").find("#FillCountSummary").hide();
                    return;
                }
                var showflag = athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId() > -1;
                // check if fill count data exists
                athoc.iws.publishing.fillcount.toggleFillCountSummary(showflag, $("#publishing-user-edit"));
            },

            // Show or Hide Fill Count Summary
            toggleFillCountSummary: function (ishowflag, targetDiv) {
                if (ishowflag) {
                    targetDiv.find("#FillCountSummary").show();
                    targetDiv.find("#EditFillCountDetails").show();
                    targetDiv.find("#FillCountLink").hide();
                    athoc.iws.publishing.fillcount.ShowFillCountSummary(athoc.iws.publishing.fillcount.fillCountSummary, targetDiv);
                } else {
                    targetDiv.find("#FillCountLink").show();
                    targetDiv.find("#EditFillCountDetails").hide();
                    targetDiv.find("#FillCountSummary").hide();
                }
            },

            // to show readOnly view of Fill Count Summary
            readOnlyFillCountSummary: function (data, targetDiv, isPublishing, isFillCountEnabled) {

                if (data == null || (athoc.iws.publishing.fillcount.clearFillCountData(isFillCountEnabled, data.FillCount)) || (!isFillCountEnabled)) return;
                targetDiv.find("#EditFillCountDetails").hide();
                targetDiv.find("#FillCountLink").hide();

                if (data != null)
                    athoc.iws.publishing.fillcount.initializeReadOnlyFillCountModel(data);
                var showflag = data == null ? athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId() > -1 : data.FillCount != null && data.FillCount.ResponseOptionId > -1;
                if (showflag) {
                    targetDiv.find("#FillCountDetails").show();
                    targetDiv.find("#FillCountSummary").show();
                    if (athoc.iws.publishing.fillcount.fillCountSummary != null)
                        athoc.iws.publishing.fillcount.ShowFillCountSummary(athoc.iws.publishing.fillcount.fillCountSummary, targetDiv);
                } else {
                    targetDiv.find("#FillCountDetails").hide();
                    targetDiv.find("#FillCountSummary").hide();
                }
            },
            //  // initialize view model for Scenario or Alert Edit
            initializeFillCountModel: function (data) {
                data.EscalationAttributes.unshift({ Id: 0, Name: $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_SelectanAttribute), Values: [] });
                athoc.iws.publishing.fillcount.viewModel.escalationAttributes = ko.mapping.fromJS(data.EscalationAttributes);
                //data.SequencingAttributes.unshift({ Id: 0, Name: "Select an Attribute", Values: [] });
                //athoc.iws.publishing.fillcount.viewModel.phonesequencingAttributes = ko.mapping.fromJS(data.SequencingAttributes);
                athoc.iws.publishing.fillcount.viewModel.responseOptions = ko.mapping.fromJS(athoc.iws.publishing.fillcount.fillResponses(data.Content.ResponseOptions));
                athoc.iws.publishing.fillcount.fillCountSummary = ko.mapping.fromJS(athoc.iws.publishing.fillcount.defaultFillCountSummary);
                athoc.iws.publishing.fillcount.viewModel.fillCountModel = ko.mapping.fromJS(athoc.iws.publishing.fillcount.setFillCountCustModel(data), athoc.iws.publishing.fillcount.getValidation());

                if (data.FillCount != null) {
                    /// TODO  Remove below attributes if they are not being used

                    data.FillCount.EscalationAttributeId = data.FillCount.ControlledDeliveryType != 0 ? data.FillCount.ControlledDeliveryAttributeId : 0;

                    //data.FillCount.PhoneAttributeId = data.FillCount.ControlledDeliveryType == 2 ? data.FillCount.ControlledDeliveryAttributeId : 0;
                    athoc.iws.publishing.fillcount.setFillCountSummary(data.FillCount, athoc.iws.publishing.fillcount.defaultFillCountSummary);
                }


            },

            // set Fill Count Cust Model for UI binding
            setFillCountCustModel: function (data) {
                var model = {};
                if (data.FillCount != null) {
                    model.ResponseOptionId = data.FillCount.ResponseOptionId;
                    model.AnyResponseOption = data.FillCount.AnyResponseOption;
                    model.FillCount = data.FillCount.FillCount;
                    model.ControlledDeliveryType = data.FillCount.ControlledDeliveryType;
                    // model.PhoneAttributeId = data.FillCount.ControlledDeliveryType == 2 ? data.FillCount.ControlledDeliveryAttributeId : 0;
                    // model.OrderByAscending = data.FillCount.ControlledDeliveryType == 2 ? data.FillCount.OrderByAscending : true;

                    var attributeName = athoc.iws.publishing.fillcount.getControlDeliveryAttributeValue(data.FillCount.ControlledDeliveryAttributeId, 1);
                    if (attributeName == $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_SelectanAttribute)) {
                        model.EscalationAttributeId = 0;
                        model.EnableEscalation = false;
                        model.ControlledDeliveryType = 0;
                        model.EnableControlledDelivery = data.FillCount.ControlledDeliveryType == 2 ? true : false;
                    } else {
                        model.EnableEscalation = data.FillCount.ControlledDeliveryType != 0 ? true : false;
                        model.EnableControlledDelivery = data.FillCount.ControlledDeliveryType == 2 ? true : false;
                        model.EscalationAttributeId = data.FillCount.ControlledDeliveryType != 0 ? data.FillCount.ControlledDeliveryAttributeId : 0;
                    }
                    model.WaitTime = data.FillCount.ControlledDeliveryAttributeId != 0 ? data.FillCount.WaitTime : athoc.iws.publishing.fillcount.defaultFillCount.WaitTime;
                    model.WaitTimeUnit = data.FillCount.ControlledDeliveryAttributeId != 0 ? data.FillCount.WaitTimeUnit : athoc.iws.publishing.fillcount.defaultFillCount.WaitTimeUnit;
                    model.GroupByAscending = data.FillCount.ControlledDeliveryAttributeId != 0 ? data.FillCount.OrderByAscending : true;
                    model.EntityId = data.FillCount.EntityId;
                }
                else
                    model = athoc.iws.publishing.fillcount.defaultFillCount;

                return model;
            },

            // initialize readonly fill Count model for Scenario or Alert or Publishing
            initializeReadOnlyFillCountModel: function (data) {
                athoc.iws.publishing.fillcount.viewModel.escalationAttributes = ko.mapping.fromJS(data.EscalationAttributes);
                //athoc.iws.publishing.fillcount.viewModel.phonesequencingAttributes = ko.mapping.fromJS(data.SequencingAttributes);
                athoc.iws.publishing.fillcount.viewModel.responseOptions = ko.mapping.fromJS(athoc.iws.publishing.fillcount.fillResponses(data.Content.ResponseOptions));
                athoc.iws.publishing.fillcount.fillCountSummary = ko.mapping.fromJS(athoc.iws.publishing.fillcount.defaultFillCountSummary);
                if (data.FillCount != null) {

                    data.FillCount.EscalationAttributeId = data.FillCount.ControlledDeliveryType != 0 ? data.FillCount.ControlledDeliveryAttributeId : 0;

                }
                if (data.FillCount != null && data.FillCount.ResponseOptionId > -1) {
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel = ko.mapping.fromJS(athoc.iws.publishing.fillcount.setFillCountCustModel(data));
                    athoc.iws.publishing.fillcount.setFillCountSummary(data.FillCount, athoc.iws.publishing.fillcount.defaultFillCountSummary);
                }
            },

            // fill Response Options from the content model
            fillResponses: function (responseList) {
                var i = 0;

                /// TODO move text to resource file
                var responseOptions = [{
                    Id: -1, Name: $.htmlDecode(athoc.iws.publishing.fillcount.resources.FillCount_SelectaResponseOption)
                }];
                if (responseList.length >= 1) {
                    _.each(responseList, function (item) {
                        i++;
                        if ($.trim(item.ResponseText) != "") {
                            responseOptions.push({ Id: i, Name: $.htmlDecode(item.ResponseText) });
                        }
                    });
                    responseOptions.push({ Id: 0, Name: $.htmlDecode( athoc.iws.publishing.fillcount.resources.FillCount_Any) });
                }

                return responseOptions;
            },

            // Refresh all select pickers , this is required when you enable and disable the dropdowns
            refreshPickers: function () {

                $("#fillCountResponses").selectpicker('refresh');
                $('#escalationAttribute').selectpicker('refresh');
                $('#waitTimeDuration').selectpicker('refresh');
                // $('#phoneAttribute').selectpicker('refresh');
            },

            // initiate all select pickers
            initiatePickers: function () {
                $("#fillCountResponses").selectpicker();
                $("#escalationAttribute").selectpicker();
                // $("#phoneAttribute").selectpicker();
                $("#waitTimeDuration").selectpicker();
            },

            // get model returns Fill Data Model  , same function works for new ,modify and delete
            getModel: function () {

                var data = ko.mapping.toJS(athoc.iws.publishing.fillcount.viewModel.fillCountModel);
                if (data == null || data == undefined || (data.ResponseOptionId == -1 && (data.EntityId == 0 || athoc.iws.publishing.entityId == 0)))
                    return null;
                // Re-calculate the responseId since some are empty.
                if (athoc.iws.publishing.content.viewModel.data.ResponseOptions != null || athoc.iws.publishing.view.viewModel.data.Content.ResponseOptions != null) {
                    var res = ko.mapping.toJS(athoc.iws.publishing.content.viewModel.data.ResponseOptions || athoc.iws.publishing.view.viewModel.data.Content.ResponseOptions);
                    var selectedRes = 0;
                    _.each(res, function (item, index) {
                        if (item.ResponseText != "")
                            selectedRes++;
                        if (data.ResponseOptionId == (index + 1)) {
                            data.ResponseOptionId = selectedRes;
                            return;
                        }
                    });
                }

                var fillcountdata = {
                    ID: 0,
                    ResponseOptionId: data.ResponseOptionId,
                    EntityId: data.EntityId,
                    AnyResponseOption: data.ResponseOptionId == 0 ? true : false,
                    FillCount: data.ResponseOptionId == -1 ? 0 : data.FillCount,
                    ControlledDeliveryAttributeId: data.ControlledDeliveryType != 0 ? data.EscalationAttributeId : 0,
                    WaitTime: data.ControlledDeliveryType != 0 ? data.WaitTime : 0,
                    WaitTimeUnit: data.ControlledDeliveryType != 0 ? data.WaitTimeUnit : null,
                    OrderByAscending: data.ControlledDeliveryType != 0 ? data.GroupByAscending : true,
                    ControlledDeliveryType: data.ControlledDeliveryType
                };
                return fillcountdata;
            },

            // return phone sequencing flag whether it is enabled or not
            isPhoneSequencingEnabled: function () {
                /* if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId() == -1)
                     return false;
                 var data = ko.mapping.toJS(athoc.iws.publishing.fillcount.viewModel.fillCountModel);
                 return data.ControlledDeliveryType == 2 ? true : false;*/
                return false;
            },
            // to verify whether
            isResponsesAvailable: function () {
                var data = athoc.iws.publishing.content.viewModel.data.ResponseOptions == undefined ? athoc.iws.publishing.view.viewModel.data.Content.ResponseOptions() : athoc.iws.publishing.content.viewModel.data.ResponseOptions();
                if (data.length >= 1) {
                    var flag = false;
                    _.each(data, function (item) {

                        if ($.trim(item.ResponseText()) != "") {
                            flag = true;
                            return;
                        }
                    });
                    return flag;
                }
                return false;
            },
            // Validation
            isValid: function () {
                if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId() < 0) {
                    /// TODO move text to resource file
                    $("#ErrorMsg_ResponseOptionId").html(athoc.iws.publishing.fillcount.resources.FillCount_FieldRequired);
                    $("#ErrorMsg_ResponseOptionId").css('display', "inline-block");
                }

                if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.EnableEscalation() && (athoc.iws.publishing.fillcount.viewModel.fillCountModel.EscalationAttributeId() == undefined || athoc.iws.publishing.fillcount.viewModel.fillCountModel.EscalationAttributeId() == 0)) {
                    /// TODO move text to resource file
                    $("#ErrorMsg_EscalationAttributeId").html(athoc.iws.publishing.fillcount.resources.FillCount_FieldRequired);
                    $("#ErrorMsg_EscalationAttributeId").css('display', "inline-block");
                }

                if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.EnableEscalation() && athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime() <= 0)
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime.valueHasMutated();

                athoc.iws.publishing.fillcount.fcDivScrollEventActions();

                //verify any error message is displayed
                var bValid = $("#FillCount").find(".warning-msg").is(':visible');
                return bValid;
            },
            // TODO : Bring entire show dailog logic here
            showConfirmationDialog: function (dialogType, itext) {
                itext = $.htmlDecode(itext);
                switch (dialogType) {

                    case 0:
                        //show dialog for delete response
                        $("#fillCountText").text(itext);
                        $("#btnResDeleteCancel").show();
                        $("#btnResDeleteConfirm").show();
                        $("#btnResDeleteConfirm").text(athoc.iws.publishing.fillcount.resources.Action_Button_Delete);
                        $("#btnInfo").hide();
                        $("#dialogResponseDeleteConfirm").modal("show");
                        break;
                    case 1:
                        // show dialog for clear
                        $("#fillCountText").text(itext);
                        $("#btnResDeleteCancel").show();
                        $("#btnResDeleteConfirm").show();
                        $("#btnResDeleteConfirm").text(athoc.iws.publishing.fillcount.resources.FillCount_Summary_ClearTitle);
                        $("#btnInfo").hide();
                        $("#dialogResponseDeleteConfirm").modal("show");
                        break;

                    case 2:
                        // show dialog for response change
                        $("#respnseChangeText").text(itext);
                        $("#dialogResponseChangeConfirm").modal("show");
                        break;
                    case 3:
                        //show  dialog for no response
                        $("#fillCountText").text(itext);
                        $("#btnResDeleteCancel").hide();
                        $("#btnResDeleteConfirm").hide();
                        $("#btnInfo").show();
                        $("#dialogResponseDeleteConfirm").modal('show');
                        break;
                    case -1:
                        if (athoc.iws.publishing.fillcount.confirmationDailogType == 1 || athoc.iws.publishing.fillcount.confirmationDailogType == 0 || athoc.iws.publishing.fillcount.confirmationDailogType == 3)
                            $("#dialogResponseDeleteConfirm").modal("hide");
                        else if (athoc.iws.publishing.fillcount.confirmationDailogType == 2) {
                            $("#dialogResponseChangeConfirm").modal("hide");
                        }
                        athoc.iws.publishing.fillcount.confirmationDailogType = 0;
                        break;

                }
            },

            // On response delete  this method is invoke
            setFillCountOnResponseDelete: function (index) {
                athoc.iws.publishing.fillcount.deleteResponseIndex = index;
                var responseCount = athoc.iws.publishing.content.viewModel.data.ResponseOptions().length;
                var data = ko.mapping.toJS(athoc.iws.publishing.fillcount.viewModel.fillCountModel);
                if (data.ResponseOptionId == 0 && responseCount == 1) {
                    /// TODO move text to resource file
                    athoc.iws.publishing.fillcount.showConfirmationDialog(0, athoc.iws.publishing.fillcount.resources.FillCount_DeleteAnymsg);
                    return false;
                } else if ((index + 1) == data.ResponseOptionId) {
                    /// TODO move text to resource file
                    athoc.iws.publishing.fillcount.showConfirmationDialog(0, athoc.iws.publishing.fillcount.resources.FillCount_Deletemsg);

                    return false;
                }

                if (data.ResponseOptionId > index)
                    athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId(data.ResponseOptionId - 1);
                return true;
            },

            /// TODO move  fill count default settings to here
            setDefaultFillCountModel: function () {
                var entityId = athoc.iws.publishing.fillcount.viewModel.fillCountModel.EntityId();
                // default model values to fill count model
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId(athoc.iws.publishing.fillcount.defaultFillCount.ResponseOptionId);
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.AnyResponseOption(athoc.iws.publishing.fillcount.defaultFillCount.AnyResponseOption);
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.FillCount(athoc.iws.publishing.fillcount.defaultFillCount.FillCount);
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.EntityId(entityId);
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.EscalationAttributeId(athoc.iws.publishing.fillcount.defaultFillCount.EscalationAttributeId);
                $('#escalationAttribute').selectpicker('refresh');
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTime(athoc.iws.publishing.fillcount.defaultFillCount.WaitTime);
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.WaitTimeUnit(athoc.iws.publishing.fillcount.defaultFillCount.WaitTimeUnit);
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.GroupByAscending(athoc.iws.publishing.fillcount.defaultFillCount.GroupByAscending);
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.EnableEscalation(athoc.iws.publishing.fillcount.defaultFillCount.EnableEscalation);
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.EnableControlledDelivery(athoc.iws.publishing.fillcount.defaultFillCount.EnableControlledDelivery);
                //athoc.iws.publishing.fillcount.viewModel.fillCountModel.PhoneAttributeId(athoc.iws.publishing.fillcount.defaultFillCount.PhoneAttributeId);
                //athoc.iws.publishing.fillcount.viewModel.fillCountModel.OrderByAscending(athoc.iws.publishing.fillcount.defaultFillCount.OrderByAscending);
                athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType(athoc.iws.publishing.fillcount.defaultFillCount.ControlledDeliveryType);
                athoc.iws.publishing.fillcount.isChanged = true;

                if (!athoc.iws.publishing.fillcount.isTUSectionReadonly) {
                    $("#publishing-user-edit").find("#FillCountLink").show();
                    $("#publishing-user-edit").find("#FillCountSummary").hide();
                } else {
                    $("#publishing-user-detail").find("#FillCountSummary").hide();
                }
            },

            // to set  fill count model to default in case of delete or clear function is invoked
            responseChangeAction: function () {
                var cdType = athoc.iws.publishing.fillcount.viewModel.fillCountModel.ControlledDeliveryType();
                athoc.iws.publishing.fillcount.setDefaultFillCountModel();
                switch (cdType) {
                    case 1:
                        $('#escalationAttribute').selectpicker('refresh');
                        var escalationDiv = $("#EscalationAttributeBreadCrum");
                        escalationDiv.hide();
                        escalationDiv.html("");
                        break;
                    case 2:
                        $('#phoneAttribute').selectpicker('refresh');
                        break;
                }
                if (athoc.iws.publishing.fillcount.confirmationDailogType == 0)
                    athoc.iws.publishing.content.viewModel.deleteResponseOption(athoc.iws.publishing.fillcount.deleteResponseIndex);
                else if (athoc.iws.publishing.fillcount.confirmationDailogType == 3)
                    athoc.iws.publishing.content.responseOptionChanged();
                athoc.iws.publishing.fillcount.showConfirmationDialog(-1, "");
            },

            // On response change this method is invoked
            responseChange: function (index, chngText) {
                if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId != null && athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId() - 1 == index) {
                    /// TODO move text to resource file
                    athoc.iws.publishing.fillcount.confirmationDailogType = 2;
                    athoc.iws.publishing.fillcount.responseChangedText = chngText;
                    //athoc.iws.publishing.fillcount.fillCountSummary.ResponseText(chngText);
                    if (!athoc.iws.publishing.fillcount.isTUSectionReadonly)
                        athoc.iws.publishing.fillcount.ShowFillCountSummary(athoc.iws.publishing.fillcount.fillCountSummary, $("#publishing-user-edit"));
                    else
                        athoc.iws.publishing.fillcount.ShowFillCountSummary(athoc.iws.publishing.fillcount.fillCountSummary, $("#publishing-user-detail"));

                    if ($.trim(chngText) == "") {
                        athoc.iws.publishing.fillcount.showConfirmationDialog(3, athoc.iws.publishing.fillcount.resources.FillCount_ResponseConfirm_Msg);
                        athoc.iws.publishing.fillcount.responseChangeAction();
                    } else if (athoc.iws.publishing.fillcount.fillCountSummary.ResponseText() != $.trim(chngText))
                        athoc.iws.publishing.fillcount.showConfirmationDialog(2, athoc.iws.publishing.fillcount.resources.FillCount_ModResponsemsg);
                }
            },

            reponseTypeChange: function () {
                if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId != null && athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId() > -1) {
                    athoc.iws.publishing.fillcount.confirmationDailogType = 3;
                    athoc.iws.publishing.fillcount.showConfirmationDialog(1, athoc.iws.publishing.fillcount.resources.FillCount_ModResponseConf);
                }
            },

            // Fill Count UI validation
            getValidation: function () {
                athoc.iws.publishing.fillcount.fcDivScrollEventActions();
                var validationMapping = {
                    FillCount: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                required: {params:true, message:athoc.iws.publishing.fillcount.resources.FillCount_FieldRequired},
                                min: { params: 1, message: athoc.iws.scenario.resources.Scenario_Schedule_Err_NumberLessThanOne },
                                /// TODO move text to resource file
                                maxLength: { params: 7, message: athoc.iws.publishing.fillcount.resources.FillCount_ExceedMaxLength },
                                pattern: {
                                    message: athoc.iws.publishing.fillcount.resources.FillCount_OnlyNummsg,
                                    params: "^[0-9]+$"
                                }
                            });
                        }
                    },
                    WaitTime: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                /// TODO move text to resource file
                                maxLength: { params: 7, message: athoc.iws.publishing.fillcount.resources.FillCount_ExceedMaxLength },
                                min: { params: 1, message: athoc.iws.scenario.resources.Scenario_Schedule_Err_NumberLessThanOne },
                                required: { params: true, message: athoc.iws.publishing.fillcount.resources.FillCount_FieldRequired },
                                pattern: {
                                    /// TODO move text to resource file
                                    message: athoc.iws.publishing.fillcount.resources.FillCount_OnlyNummsg,
                                    params: "^[0-9]+$"
                                },
                            });
                        }
                    },
                };
                return validationMapping;
            },


        };

    }();
}

