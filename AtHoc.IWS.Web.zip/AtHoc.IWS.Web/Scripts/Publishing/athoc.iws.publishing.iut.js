﻿/* define javascript namespace for IUT = Individual User Targeting */
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};
if (athoc.iws.publishing) {
    athoc.iws.publishing.iut = function () {
        //
        var extraSpaceAddBlock = 55;
        var userCountType = 0;
        var operatorRoleColumn = "OPERATOR-ROLES";
        return {
            viewModel: {
                targetedBlockerUsersList: ko.observableArray(),
                targetedBlockerUsers: ko.observableArray(),
                allAvailableUser: ko.observableArray(),
                status: ko.observable('ready'),
                targetedCnt: ko.observable(0),
                blockedCnt: ko.observable(0),
            },

            readOnlyInputParameters:
                {
                    sessionId: ko.observable(0),
                    covered: ko.observable(0),
                    attributeCSV: ko.observable(""),
                    totalCount: ko.observable(0),
                },
            //is model changed
            isChanged: false,
            IsRefered: false,
            rowsObject: [],
            reportCols: [],
            readOnlyDatasource: null,
            readOnlyDatasourcetemp: null,
            columnDefs: null,
            gridColumnDefs: null,
            allUsersgrid: null,
            allUserDatasource: null,
            userInfo: null,
            allUserSortColumn: 'DisplayName',
            allUserSortOrder: 'asc',
            allUserSortField: '_DISPLAYNAME',
            readOnlySortColumn: '',
            readOnlySortOrder: '',
            readOnlySortField: '_LOGIN_ID',
            allUsersPageSize: 50,
            targetBlockSort: 'asc',
            targetBlockPageSize: 50,
            searchString: [],
            newlyaddedColumns: [],
            errors: null,
            firstTimeOpenAddUser: 0,
            firstTimeReachableUser: 0,
            //this method will be called when new data will be available for this section for binding

            bind: function (data) {
                if (athoc.iws.publishing && athoc.iws.publishing.iut && athoc.iws.publishing.iut.newlyaddedColumns != null)
                    athoc.iws.publishing.iut.newlyaddedColumns.length = 0;

                //try to bind only if IUT is enabled (affiliate/non-affiliate)
                if ($("#targetBlockingList").length == 0)
                    return;
                athoc.iws.publishing.iut.viewModel.targetedBlockerUsers(data);
                // dataobject for maniplication
                athoc.iws.publishing.iut.createTargettingUserListGrid(data);

                $('#targetBlockingList .k-grid-header').hide();
                $('#targetBlockingList .k-pager-wrap').hide();
            },

            load: function () {

              
                    require(["widget/UserInfo"], function(UserInfo) {
                        athoc.iws.publishing.iut.userInfo = new UserInfo($("#alertinguserInfoHolder"), "#userInfoModalBody");
                        athoc.iws.publishing.iut.userInfo.startup();
                    });
                
                ko.cleanNode($("#AddBlockUsers").get(0));
                ko.applyBindings(athoc.iws.publishing.iut.viewModel, $("#AddBlockUsers").get(0));


                $("#ddlAlertHr").selectpicker();
                $("#ddlAlertMin").selectpicker();
                $("#ddlAlertMer").selectpicker();
                $("#ddlAlertDurationHours").selectpicker();


                // to remove the column from the available users list
                /*$('#allUserList').on('click', '.remove-column', function (event) {
                    event.preventDefault();
                    athoc.iws.publishing.iut.updateGridColumn(this.parentNode.getAttribute("viewid"), this.parentNode.getAttribute("Id"),
                       "remove",
                       this.parentNode.getAttribute("customviewcolumntype"),
                       this.parentNode.getAttribute("key"),
                       function () {
                           //$.AjaxLoader.hideLoader();
                       });
                });*/
                //
                $("#txtReadOnlySearch").keyup(function (e) {
                    $("#btn_readonlyusersearch").removeAttr('disabled');
                    if ($.hotkeys.enter(e)) {
                        $('#pillContainer').show();
                        athoc.iws.publishing.iut.createReadOnlyUserList();
                    }

                });
                //
                $("#btn_readonlyusersearch").click(function () {
                    $('#pillContainer').show();
                    athoc.iws.publishing.iut.createReadOnlyUserList();
                });
                //
                $("#txtAllUserSearch").keyup(function (e) {

                    var seaString = $.trim($('#txtAllUserSearch').val());
                    if ($.hotkeys.enter(e) && seaString != "") {
                        $('#pillContainer').show();
                        athoc.iws.publishing.iut.createPills(seaString, "SIMPLESEARCH", $('#txtAllUserSearch').val());
                        //athoc.iws.publishing.iut.createAddBlockUsersGrid();
                        $('#txtAllUserSearch').val('');
                    }
                    if (seaString.length > 0) {
                        $("#btn_userSearch").removeAttr('disabled');
                    }
                });
                $("#btn_readonlyclearall").click(function () {
                    $("#txtReadOnlySearch").val("");
                    $('#pillContainer').hide();
                    athoc.iws.publishing.iut.createReadOnlyUserList();
                    $("#btn_readonlyusersearch").attr('disabled', true);
                    athoc.iws.publishing.iut.hideAddColumns();
                });
                //
                $("#btn_userSearch").click(function () {
                    if ($.trim($('#txtAllUserSearch').val()).length > 0) {
                        athoc.iws.publishing.iut.createPills($('#txtAllUserSearch').val(), "SIMPLESEARCH", $('#txtAllUserSearch').val());
                        $('#pillContainer').show();
                    }
                });
                //                
                $("#clearAllBtn").click(function () {
                    athoc.iws.publishing.iut.clearAllTargetedBlockedUsersPopUp();
                    $('#pillContainer').hide();
                });

                $("#btn_Apply").click(function () {
                    athoc.iws.publishing.iut.applyChangesToList();
                });

                $("body").click(function () {
                    athoc.iws.publishing.iut.hideAddColumns();
                    $("#contextDropdown").hide();

                });
            },
            userListRemoveColumn: function (event) {
                event.preventDefault();
                athoc.iws.publishing.iut.updateGridColumn(event.currentTarget.parentNode.getAttribute("viewid"), event.currentTarget.parentNode.getAttribute("Id"),
                   "remove",
                   event.currentTarget.parentNode.getAttribute("customviewcolumntype"),
                   event.currentTarget.parentNode.getAttribute("key"),
                   function () {
                       //$.AjaxLoader.hideLoader();
                   });
            },
            // to remove the column from the read only  userlist
            readonlyUserlistRemoveColumn: function (event) {
                event.preventDefault();
                //this.parentNode.parentNode.getAttribute("viewid")
                name = event.target.getAttribute("Key");
                var cList = ko.mapping.toJS(athoc.iws.publishing.iut.newlyaddedColumns).filter(function (i) {
                    return i.Key != name;
                })
                athoc.iws.publishing.iut.newlyaddedColumns = cList;
                if (athoc.iws.publishing.iut.readOnlySortColumn == name) {
                    athoc.iws.publishing.iut.readOnlySortColumn = "USERNAME";
                    athoc.iws.publishing.iut.readOnlySortOrder = "ASC";
                }
                athoc.iws.publishing.iut.createReadOnlyUserList();

                //athoc.iws.publishing.iut.updateReportViewColumn(this.parentNode.getAttribute("viewid"), this.parentNode.getAttribute("id"),
                //   "remove",
                //   "",
                //    "",
                //   function () {
                //       //$.AjaxLoader.hideLoader();
                //   });
            },

            //
            createTargettingUserListGrid: function (data) {
                var tbData = [];
                tbData = new kendo.data.DataSource({
                    data: data,
                });

                //datasource.read();
                var grid = $("#targetBlockingList").kendoGrid({
                    dataSource: tbData,
                    selectable: false,
                    sortable: {
                        allowUnsort: false
                    },
                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5,
                        messages: {
                            display: $.htmlDecode(athoc.iws.publishing.iut.resources.IUTAllUsers_PagingInfo),
                            empty: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Empty),
                            itemsPerPage: $.htmlDecode(athoc.iws.publishing.iut.resources.IUTAllUsers_ItemsPerPage),
                            first: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                            previous: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                            next: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                            last: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                        }
                    },
                    columns:
                            [

                                 {
                                     field: "",
                                     title: "",
                                     template: $("#targeting-imgtargeting-template").html(),
                                     headerTemplate: kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', "Users", ""),
                                     width: 10,
                                     headerAttributes: {
                                         tabindex: "3"
                                     }
                                 },
                                {
                                    field: "Name",
                                    title: "",
                                    template: $("#targeting-name-template").html(),
                                    headerTemplate: kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', "Name", ""),
                                    width: 130,
                                    headerAttributes: {
                                        tabindex: "3"
                                    }
                                },
                                {
                                    field: "",
                                    title: "",
                                    template: $("#targeting-imgremove-template").html(),
                                    headerTemplate: kendo.format('<span title="{0}">{1}</span>', "", ""),
                                    width: 10,
                                    headerAttributes: {
                                        tabindex: "5"
                                    }
                                },
                            ],
                    dataBound: athoc.iws.publishing.iut.OnDataBound,
                    change: function (e) {
                        var model = this.dataItem(this.select());
                        this.select().removeClass("k-state-selected");

                    }
                }).data().kendoGrid;

                grid.dataSource.pageSize(grid.dataSource.total());
                athoc.iws.publishing.iut.updateChangesToSummaryAndChart();
                $("#TargetedUsers").html(athoc.iws.publishing.iut.viewModel.targetedBlockerUsers().length);
            },

            //
            UserToolTip: function (model) {

                $.ajax({
                    url: athoc.iws.publishing.urls.GetUserDetailsUrl,
                    type: 'POST',

                    data: {
                        Id: model.UserId
                    },
                    cache: false,
                    async: true,
                    success: function (result) {
                        athoc.iws.publishing.iut.IsRefered = false;
                        result = result.replace(" alt='Close'", " alt='Close' style='display:none' ");

                        // $("#userInfoModal").html(result);
                        var tooltip = $("#readonlyUserList").kendoTooltip({
                            filter: "closeImg",
                            autoHide: false,
                            content: result,
                            position: "right",

                        }).data("kendoTooltip").show($("#readonlyUserList"));

                    },
                });
            },

            //
            removeUserId: function (userId) {
                var raw = $("#targetBlockingList").data("kendoGrid").dataSource.data();
                var length = raw.length;

                var item, i;
                for (i = length - 1; i >= 0; i--) {
                    if (raw[i].UserId == userId) {
                        item = raw[i];
                        $("#targetBlockingList").data("kendoGrid").dataSource.remove(item);
                        break;
                    }

                }
                if (item != undefined) {
                    $("#targetBlockingList").data("kendoGrid").refresh();
                }
                athoc.iws.publishing.iut.updateChangesToSummaryAndChart();
                var current = athoc.iws.publishing.content;
                current.isChanged = true;
                athoc.iws.publishing.targetUsers.targetingChanged();
            },

            OnBoundEmptyRow: function (data) {
                var colCount = $("#targetBlockingList").find('.k-grid-header colgroup > col').length;
                if (data.length == 0) {
                    $("#targetBlockingList").find('.k-grid-content tbody')
                        .append('<tr class="kendo-data-row"><td colspan="' +
                            colCount +
                            '" style="text-align:left;height:10px;overflow:auto; cursor:default; background-color:#fff">' +
                            kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', "", athoc.iws.publishing.iut.resources.IUTTargeted_Blocked_Emptyrow_Message) +
                            '</td></tr>');
                }
            },

            //
            OnBoundReadonlyEmptyRow: function (data) {
                var colCount = $("#readonlyUserList").find('.k-grid-header colgroup > col').length;
                if (data.length == 0) {
                    $("#readonlyUserList").find('.k-grid-content tbody')
                        .append('<tr class="kendo-data-row"><td colspan="' +
                            colCount +
                            '" style="text-align:center;height:10px;overflow:auto;">' +
                            kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', athoc.iws.publishing.iut.resources.AtHoc_Pager_Message_Empty, athoc.iws.publishing.iut.resources.AtHoc_Pager_Message_Empty) +
                            '</td></tr>');
                }
            },

            //
            OnDataBound: function () {
                var grid = $("#targetBlockingList").data("kendoGrid");

                var grid = $("#targetBlockingList").data("kendoGrid");
                var data = $("#targetBlockingList").data("kendoGrid").dataSource.view();
                athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList(data);
                athoc.iws.publishing.iut.OnBoundEmptyRow(data);


            },

            //
            refreshGrid: function () {
                grid.setDataSource(athoc.iws.publishing.iut.viewModel.targetedBlockerUsers());
                grid.dataSource.pageSize(grid.dataSource.total());

            },

            //this method will be called when data is required for updating
            getModel: function () {
                if ($("#targetBlockingList").data("kendoGrid") != undefined) {
                    return ko.mapping.toJS($("#targetBlockingList").data("kendoGrid").dataSource.view());
                } else {
                    return null;
                }
            },

            //indicates if the section is ready or not
            isReady: function () {
                //if at least one user is targed then this should be true
                return false;
            },

            //triggered on data changed
            dataChanged: function () {
                var current = athoc.iws.publishing.content;
                current.isChanged = true;
                current.checkReadyNotReady();
            },

            //
            createReadOnlyUserList: function () {
                var self = this;
                var searchString = "";
                var rowsObject = [];
                var attributeIds = "";
                var dIds = "";
                var displayIds = "";
                var cNames = "";

                if ($("#txtReadOnlySearch").val() != "") {
                    searchString = $("#txtReadOnlySearch").val();
                    var rGrid = $("#readonlyUserList").data("kendoGrid");
                    if (rGrid != null && rGrid.columns.length > 0) {
                        _.each(rGrid.columns, function (col, index) {
                            if (col.headerAttributes != null && (col.headerAttributes.key == "LOGIN_ID" || col.headerAttributes.key == "FIRSTNAME" || col.headerAttributes.key == "LASTNAME" || col.headerAttributes.key == "DISPLAYNAME") && col.headerAttributes.id > 0)
                                attributeIds = attributeIds + col.headerAttributes.id + ",";
                        });
                    }
                }

                _.each(athoc.iws.publishing.iut.newlyaddedColumns, function (item, index) {
                    if (item.CustomViewColumnType.toUpperCase() == "DEVICE") {
                        displayIds = displayIds + item.Id + ",";
                        //dNames = dNames + item.Key + ",";
                    }
                    else if (item.CustomViewColumnType.toUpperCase() == "CF") {
                        cNames = cNames + item.Key + ",";
                    }
                });
                cNames = cNames + athoc.iws.publishing.iut.readOnlyInputParameters.attributeCSV();
                //if (dIds == "") {

                var checkedDevices = ko.mapping.toJS(athoc.iws.publishing.targetUsers.SelectedGroupedDevices().Devices).map(function (item) { return item.DeviceId; });
                dIds = checkedDevices.join(",");


                var escalationAttributeId = 0;
                var escalationSortOrder = "";
                escalationSortOrder = athoc.iws.publishing.fillcount.getModel() != null ? athoc.iws.publishing.fillcount.getModel().OrderByAscending : "";
                escalationAttributeId = athoc.iws.publishing.fillcount.getModel() != null ? athoc.iws.publishing.fillcount.getModel().ControlledDeliveryAttributeId : 0;
                var sortBy = athoc.iws.publishing.iut.readOnlySortColumn == "" ? ((escalationAttributeId > 0) ? escalationAttributeId : "") : athoc.iws.publishing.iut.readOnlySortColumn;

                var sortOrder = athoc.iws.publishing.iut.readOnlySortOrder == "" ? (escalationAttributeId > 0 ? (escalationSortOrder ? "ASC" : "DESC") : "") : athoc.iws.publishing.iut.readOnlySortOrder;

                var inparameters = {
                    userCountType: athoc.iws.publishing.iut.readOnlyInputParameters.covered(),
                    sessionId: athoc.iws.publishing.iut.readOnlyInputParameters.sessionId(),
                    attributeCSV: cNames,
                    totalCount: athoc.iws.publishing.iut.readOnlyInputParameters.totalCount(),
                    attributeSearchValue: searchString,
                    sortBy: sortBy,
                    sortOrder: sortOrder,
                    deviceIds: dIds,
                    displayColumnDeviceIds: displayIds,
                    attributeIds: attributeIds,
                    fillCountAttributeId: escalationAttributeId
                };

                readOnlyDatasource = new kendo.data.DataSource({
                    transport:
                    {
                        read: {
                            url: athoc.iws.publishing.urls.GetAlertUserListDataUrl,
                            type: "POST",
                            dataType: "json",
                            data: inparameters,
                            traditional: true,
                        },

                    },

                    requestStart: function (e) {
                        $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#divReadOnlyProgress'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '150px', left: '60%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();
                        //$("#readonlyUserList").hide();
                        //$("#readOnlyPageInfo").hide();
                    },
                    requestEnd: function (e) {
                        $.AjaxLoader.hideLoader();
                        if (e.response) {
                            athoc.iws.publishing.iut.createReadOnlyDataSource(e.response);
                            e.response["Rows"] = rowsObject;
                            readOnlyDatasource._total = e.response.TotalCounts;
                            athoc.iws.publishing.iut.createReadOnlyGrid();

                        }

                    },

                    error: function (e) {
                        athoc.iws.publishing.iut.handleError(e);
                    },
                    schema:
                    {
                        data: "Rows",
                        total: "TotalCounts",
                    },
                    serverPaging: true,
                    serverSorting: true,
                    sort: {},
                    pageSize: 50,
                });
                readOnlyDatasource.read();

            },

            createReadOnlyGrid: function () {
                if (athoc.iws.publishing.iut.firstTimeReachableUser == 0) {
                    $("#readonlyUserList").html('');
                    $("#readonlyUserList").hide();
                    athoc.iws.publishing.iut.firstTimeReachableUser = 1;
                }


                $("#readOnlyPageInfo").kendoPager({
                    dataSource: readOnlyDatasource,
                    autoBind: false,
                    numeric: false,
                    previousNext: false,
                    messages: {
                        display: athoc.iws.publishing.iut.resources.IUTReadOnly_PageingInfo,
                        empty: athoc.iws.publishing.iut.resources.AtHoc_Pager_Message_Empty
                    }
                });
                $("#readonlyUserList .k-grid-header").html('');

                if (rowsObject.length == 0) {
                    rowsObject = [];
                }
                var grid = $("#readonlyUserList").kendoGrid().data("kendoGrid");
                var options = grid.options;
                grid.destroy();

                kendoGrid = $("#readonlyUserList").kendoGrid({
                    columns: columnDefs,
                    dataSource: rowsObject,
                    autoBind: true,
                    scrollable: true,
                    sortable: false,
                    pageable:
                            {
                                refresh: false,
                                pageSizes: true,
                                pageSizes: [20, 50, 100],
                                buttonCount: 5,
                                messages: {
                                    display: $.htmlDecode(athoc.iws.publishing.iut.resources.IUTAllUsers_PagingInfo),
                                    empty: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Empty),
                                    itemsPerPage: $.htmlDecode(athoc.iws.publishing.iut.resources.IUTAllUsers_ItemsPerPage),
                                    first: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                                    previous: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                                    next: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                                    last: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                                }
                            },
                    dataBinding: athoc.iws.publishing.iut.OnReadOnlyDataBinding,
                    dataBound: athoc.iws.publishing.iut.OnReadOnlyDataBound,
                    error: function (e) {
                        var errorCallBack = function (returnedErrorObject) {
                            $('#readonlyMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        };
                        AjaxUtility().athocKendoGridAjaxErrorHandler(e, errorCallBack);

                    },

                }).data("kendoGrid");

                setTimeout(function () {
                    athoc.iws.publishing.iut.fitHeightReadOnlyList();
                    $("#readonlyUserList").show();
                    $("#readOnlyPageInfo").show();
                    $.AjaxLoader.hideLoader();
                }, 1500);
            },

            fitHeighUserList: function () {
                var windowHeight = $("#AddBlockUsers .modal-content").height();
                if (windowHeight > 600) { // Resolution : 1920 * 1080
                    $("#tbUsersList .k-grid-content").css("height", (windowHeight * 73.2 / 100) - 12);
                }
                else if (windowHeight > 460) { // Resolution : 1280*1024
                    $("#tbUsersList .k-grid-content").css("height", (windowHeight * 73.2 / 100) + 8);
                }
                else {
                    $("#tbUsersList .k-grid-content").css("height", (windowHeight * 63 / 100) - 9);
                }
            },

            fitHeightReadOnlyList: function () {

                var windowHeight = $("#ReadOnlyUserList .modal-content:eq(1)").height() - $("#ReadOnlyUserList .content-current").height();
                if (windowHeight > 500) {
                    $("#readonlyUserList .k-grid-content").css("height", (windowHeight * 79 / 100) - 10);
                }
                else if ((windowHeight <= 500) && (windowHeight > 400)) {
                    $("#readonlyUserList .k-grid-content").css("height", (windowHeight * 79 / 100) - 15);
                }
                else {
                    $("#readonlyUserList .k-grid-content").css("height", (windowHeight * 67 / 100) - 10);
                }
            },

            fitHeightAllUsers: function () {
                var extraSpace = 0;
                if (athoc.iws.publishing.iut.searchString.length > 0)
                    extraSpace = 4;

                var windowHeight = $("#AddBlockUsers .modal-content").height() - $("#allUsersBucket .content-current").height();
                if (windowHeight >= 590) {
                    $("#allUserList .k-grid-content").css("height", (windowHeight * 73.2 / 100) - extraSpace + 22);
                }
                else if (windowHeight > 400) {
                    $("#allUserList .k-grid-content").css("height", (windowHeight * 73.2 / 100) - extraSpace + 5);
                }
                else {
                    $("#allUserList .k-grid-content").css("height", ((windowHeight * 54 / 100) + 20));
                }

                if ($("#pillContainer").children().length == 0)
                    $("#pillContainer").hide();
                else {
                    $("#pillContainer").show();
                    if (windowHeight <= 400)
                        $("#allUserList .k-grid-content").css("height", ((windowHeight * 54 / 100) - 10));
                }

                $('#allUserList').show();
            },

            fitHeightTargetedUsersSummaryList: function () {
                var windowHeight = $("#targetedUsersSummary .modal-body").height();
                if (windowHeight < 450) {
                    $("#targetedUsersList .k-grid-content").css("height", (windowHeight * 82 / 100));
                }
                else if ((windowHeight > 500) && (windowHeight < 600)) {
                    $("#targetedUsersList .k-grid-content").css("height", windowHeight - 70);
                }
                else if (windowHeight >= 600) { // resolution: 1920*1080
                    if (navigator.userAgent.toLowerCase().indexOf('chrome') > -1) {
                        $("#targetedUsersList .k-grid-content").css("height", windowHeight - 110);
                    }
                    else if (navigator.userAgent.toLowerCase().indexOf('firefox') > -1) {
                        $("#targetedUsersList .k-grid-content").css("height", windowHeight - 76);
                    }
                    else
                        $("#targetedUsersList .k-grid-content").css("height", windowHeight - 130);

                }
                else {
                    $("#targetedUsersList .k-grid-content").css("height", windowHeight - 84);

                }
            },

            fitHeightBlockedUsersSummaryList: function () {
                var windowHeight = $("#blockedUsersSummary .modal-body").height();
                if (windowHeight < 450) {
                    $("#blockedUsersList .k-grid-content").css("height", (windowHeight * 82 / 100));
                }
                else if ((windowHeight > 500) && (windowHeight < 600)) {
                    $("#blockedUsersList .k-grid-content").css("height", windowHeight - 70);
                }
                else if (windowHeight >= 600) {// resolution: 1920*1080
                    if (navigator.userAgent.toLowerCase().indexOf('chrome') > -1) {
                        $("#blockedUsersList .k-grid-content").css("height", windowHeight - 110);
                    }
                    else if (navigator.userAgent.toLowerCase().indexOf('firefox') > -1) {
                        $("#blockedUsersList .k-grid-content").css("height", windowHeight - 76);
                    }
                    else
                        $("#blockedUsersList .k-grid-content").css("height", windowHeight - 130);
                }
                else {
                    $("#blockedUsersList .k-grid-content").css("height", windowHeight - 84);

                }
            },

            createReadOnlyDataSource: function (data) {
                columnDefs = [];
                rowsObject = [];
                colObject = [];
                var colWidth = "auto";
                if (data.ReportsColumns.length > 7)
                    colWidth = "120px";
                // Add coumns to column array

                athoc.iws.publishing.iut.reportCols = [];
                var ReportLayoutColumns = data.ReportLayoutColumns;

                _.each(athoc.iws.publishing.iut.newlyaddedColumns, function (item, index) {
                    var existColCount = ko.mapping.toJS(data.ReportLayoutColumns).filter(function (DisplayName) {
                        return DisplayName == item.DisplayName;
                    }).length;

                    if (existColCount == 0)
                        ReportLayoutColumns.push(item.DisplayName);

                });

                _.each(ReportLayoutColumns, function (item, cIndex) {
                    _.find(data.ReportsColumns, function (obj) {
                        if (item == obj.DisplayName) {
                            athoc.iws.publishing.iut.reportCols.push(obj);
                        }
                    });
                });

                _.each(athoc.iws.publishing.iut.reportCols, function (item, cIndex) {
                    var columnName = item.Key;
                    var headerTemplate = "";
                    var field = '_' + columnName.replace(/[-:~!@#$%^&*(){}\[\]<>,.\s'\"?\\\/]/g, "");
                    if (item.Key.toUpperCase() != "USER_ID" || item.Key.toUpperCase() != "LOGIN_ID") {
                        var existColCount = ko.mapping.toJS(athoc.iws.publishing.iut.newlyaddedColumns).filter(function (i) {
                            return i.Key == item.Key;
                        }).length;

                        if (existColCount == 0) {
                            headerTemplate = kendo.format('<span title="' + $.htmlEncode(item.DisplayName) + '" onclick="athoc.iws.publishing.iut.readOnlyGridColumnSort(event);">' + $.htmlEncode(item.DisplayName) + '</span>');
                        }
                        else
                            headerTemplate = kendo.format('<div title="' + athoc.iws.publishing.resources.Publishing_RemoveGridColumn + ' ' + $.htmlEncode(item.DisplayName) + '" class="icon_clear remove-column"  key="' + columnName + '" onclick="athoc.iws.publishing.iut.readonlyUserlistRemoveColumn(event);"></div>' + '<span title="' + $.htmlEncode(item.DisplayName) + '" onclick="athoc.iws.publishing.iut.readOnlyGridColumnSort(event);" >' + $.htmlEncode(item.DisplayName) + '</span>');

                        if (athoc.iws.publishing.iut.readOnlySortColumn.toUpperCase() == item.Key.toUpperCase()) {
                            athoc.iws.publishing.iut.readOnlySortField = field;
                            if (athoc.iws.publishing.iut.readOnlySortOrder.toUpperCase() == "ASC") {
                                if (athoc.iws.publishing.iut.readOnlySortColumn.toUpperCase() == "ORGANIZATIONAL HIERARCHY")
                                    headerTemplate += '<span class="sort-indicator-ascending sort-indicator-margin-userlist"></span>';
                                else
                                    headerTemplate += '<span class="sort-indicator-ascending"></span>';
                            }
                            else if (athoc.iws.publishing.iut.readOnlySortOrder.toUpperCase() == "DESC") {
                                if (athoc.iws.publishing.iut.readOnlySortColumn.toUpperCase() == "ORGANIZATIONAL HIERARCHY")
                                    headerTemplate += '<span class="sort-indicator-descending sort-indicator-margin-userlist"></span>';
                                else
                                    headerTemplate += '<span class="sort-indicator-descending"></span>';
                            }
                        }

                        columnDefs.push({
                            title: columnName,
                            field: field,
                            width: colWidth,
                            headerTemplate: headerTemplate,
                            template: '<span title="#=' + field + '#">#=' + field + '#</span>',
                            headerAttributes: {
                                id: item.Id,
                                customviewcolumntype: item.CustomViewColumnType,
                                key: item.Key
                            }
                        });
                    }
                });

                rowsObject.length = 0;
                rowNumber = 0;
                rowsObject = [];
                // Prepare datasource for kendo grid
                _.each(data.ReportRows, function (row, rIndex) {
                    var colObject = new Object();
                    //colObject["Id"] = row.Id;                    
                    colObject["_LOGIN_ID"] = row.UserName;
                    _.each(data.ReportsColumns, function (column, cIndex) {
                        if (column.Key.toUpperCase() != "USER_ID") {
                            var value = $.customizedHtmlEncoding(athoc.iws.publishing.iut.getReadOnlyColumnValue(column, row));
                            //if (column.DataFormat && column.DataType && (!(column.DataType == 4 || column.DataType == 5)))
                            //    value = $.getFormattedValue(column.DataType, column.DataFormat, value);
                            colObject["_" + column.Key.replace(/[-:~!@#$%^&*(){}\[\]<>,.\s'\"?\\\/]/g, "")] = value;
                        }
                    });

                    rowsObject.push(colObject);
                })
               

                columnDefs.push({
                    title: athoc.iws.publishing.iut.resources.IUTReadOnly_Add_Reset,
                    field: "",
                    width: "80px",
                    headerTemplate: '<a href="#" class="small-msg block column-select" id="addColumn" onClick="athoc.iws.publishing.iut.addNewReportColumn(this)"  >' + athoc.iws.publishing.iut.resources.Action_Link_Add + '</a><a href="#" class="small-msg block" id="reset"  onClick="athoc.iws.publishing.iut.ResetReportColumns()"  >' + athoc.iws.publishing.iut.resources.IUTReadOnly_Reset + '</a>'
                });

               
            },

            getReadOnlyColumnValue: function (column, row) {

                if (column.Key == "OPERATOR-ROLES") {
                    var roleCount = row.UserAttributes["ROLECOUNT_OTHERORGS"];
                    if (roleCount && roleCount != " ") {
                        return row.UserAttributes[column.Key] + " (" + row.UserAttributes["ROLECOUNT_OTHERORGS"] + ") ";
                    } else {
                        return row.UserAttributes[column.Key];
                    }
                }
                return row.UserAttributes[column.Key] != null
                    ? row.UserAttributes[column.Key]
                    : (row.UserDevice[column.Key] != null ? row.UserDevice[column.Key] : '');
            },

            readOnlyGridColumnSort: function (event) {
                event.preventDefault();
                event.cancelBubble = true;
                var grid = $("#readonlyUserList").data("kendoGrid");
                athoc.iws.publishing.iut.readOnlySortField = grid.columns[event.target.parentNode.cellIndex].field;
                athoc.iws.publishing.iut.readOnlySortColumn = grid.columns[event.target.parentNode.cellIndex].title; //event.target.getAttribute("title");
                if (athoc.iws.publishing.iut.readOnlySortOrder == "desc")
                    athoc.iws.publishing.iut.readOnlySortOrder = "asc";
                else
                    athoc.iws.publishing.iut.readOnlySortOrder = "desc";
                athoc.iws.publishing.iut.createReadOnlyUserList();

            },

            resizeModalBasedOnScreen: function (modal) {

                modal.find(".modal-body").css("max-height", 600);
                var windowHeight = $(window).height();

                if (windowHeight > 770) {
                    modal.css("margin-top", 40 - (windowHeight / 2) + ((windowHeight - 770) / 2));
                    modal.find(".modal-body").css("height", windowHeight - 340);
                } else {
                    modal.css("margin-top", 40 - (windowHeight / 2));
                    modal.find(".modal-body").css("height", windowHeight - 240);
                }

                if (modal.height() + 170 > windowHeight) {
                    var newHeight = windowHeight - 170;
                    modal.find(".modal-body").css("max-height", newHeight);

                }

            },

            showAddColumns: function (event) {

                var position = $("#ReadOnlyUserList .column-select").offset();

                var selColumn = $("#ReadOnlyUserList .column-filter");
                var windowHeight = $(window).height();
                if (athoc.iws.publishing.source == "p" || athoc.iws.publishing.source == "a" || athoc.iws.publishing.source == "h" || athoc.iws.publishing.source == "readonly" || (athoc.iws.alert != undefined && athoc.iws.alert.source == "publisher"))
                    selColumn.css({ top: "126px" });
                else if (athoc.iws.publishing.source == undefined)
                    selColumn.css({ top: "157px" });
                else
                    selColumn.css({ top: "142px" });

                selColumn.css({ left: "710px" });


                selColumn.show();

            },

            hideAddColumns: function (data, event) {
                var selColumn = $(".column-filter");
                selColumn.hide();
            },

            //
            ResetReportColumns: function () {
                $("#dialogResetReadonlyUsers").find(".modal-body").css("max-height", 50);
                $("#dialogResetReadonlyUsers").show();
                $("#ReadOnlyUserList").append('<div id="displayShadow" class="modal-backdrop fade in"></div>');
                $("#dialogResetReadonlyUsers").on('click', '.btn-info', function (event) {
                    $("#dialogResetReadonlyUsers").hide();
                    $("#ReadOnlyUserList").find('#displayShadow').remove();
                });
            },

            ResetReadonlyGridListOk: function () {
                $("#dialogResetReadonlyUsers").hide();
                $("#ReadOnlyUserList").find('#displayShadow').remove();
                athoc.iws.publishing.iut.newlyaddedColumns.length = 0;
                athoc.iws.publishing.iut.createReadOnlyUserList();

                /*target = "_blank";
                athoc.iws.publishing.iut.hideAddColumns();
                var parameters = {
                    viewType: "UserReport",
                };
                var myAjaxOptions = {
                    url: athoc.iws.publishing.urls.ResetToReportDefaultViewUrl,
                    type: "POST",
                    dataType: "json",
                    data: parameters,
                    success: function (data) {
                        athoc.iws.publishing.iut.createReadOnlyUserList();
                        $.AjaxLoader.hideLoader();
                    }
                };
                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);*/
            },

            //
            addNewReportColumn: function () {

                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#ReadOnlyUserList .dropdown-div'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '150px', left: '60%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();
                var self = this;
                var parameters = {
                    viewType: "UserReport",
                };

                var myAjaxOptions = {
                    url: athoc.iws.publishing.urls.GetReportCustomViewUrl,
                    type: "POST",
                    dataType: "json",
                    data: parameters,
                    success: function (data) {
                        if (data && data.length > 0) {
                            $("#newColumn").html('');
                            //  self.render(true, function () {
                            var htmlAttributes = '';
                            var deviceOptions = '';
                            var operatorOptions = '';
                            var hierarchyOptions = '';
                            var hierarchyGroup = '', attributeGroup = '', deviceGroup = '', operatorAttributeGroup = '';
                            var html = "";
                            html += '<select style="width: 248px !important; margin-left: 5px !important;" name="addReportColumnDropdown" data-placeholder="" size=10>';

                            _.each(data, function (item, index) {
                                var existColCount = ko.mapping.toJS(athoc.iws.publishing.iut.reportCols).filter(function (i) {
                                    return (i.Key == item.Key);
                                }).length;

                                
                                


                                if (existColCount == 0)
                                    //athoc.iws.publishing.iut.newlyaddedColumns == "" || athoc.iws.publishing.iut.newlyaddedColumns.split(',').indexOf($.htmlEncode(item.DisplayName)) == -1) {
                                {
                                    var optionList = "<option value='" + item.Id + "' data-customviewcolumntype='" + item.CustomViewColumnType + "' data-key='" + item.Key + "'>" + $.htmlEncode(item.DisplayName) + "</option>";

                                    if (item.CustomViewColumnType == "CF" && item.IsHierarchy == false && item.Key == operatorRoleColumn) {
                                        operatorOptions = operatorOptions + optionList;
                                    }
                                    else if (item.CustomViewColumnType == "CF" && item.IsHierarchy == false) {
                                        htmlAttributes = htmlAttributes + optionList;
                                    }
                                    else if (item.CustomViewColumnType == "CF" && item.IsHierarchy == true) {
                                        hierarchyOptions = hierarchyOptions + optionList;
                                    }
                                    else if (item.CustomViewColumnType == "Device") {
                                        deviceOptions = deviceOptions + optionList;
                                    }
                                }
                            });

                            if (hierarchyOptions != '') {
                                hierarchyGroup = '<optgroup label="Organization Hierarchy">' + hierarchyOptions + '</optgroup>';
                            }

                            if (htmlAttributes != '')
                                attributeGroup = '<optgroup label="Attributes">' + htmlAttributes + '</optgroup>';

                            if (deviceOptions != '')
                                deviceGroup = '<optgroup label="Devices">' + deviceOptions + '</optgroup>';

                            if (operatorOptions != '')
                                operatorAttributeGroup = '<optgroup label="' + $.htmlDecode(athoc.iws.publishing.iut.resources.AtHoc_Grid_OperatorAttributesLabel) + '">' + operatorOptions + '</optgroup>';

                            html = html + hierarchyGroup + attributeGroup + operatorAttributeGroup + deviceGroup;
                            html += '</select>';
                            //html += '</div></div>';
                            $("#newColumn").html(html);



                            var selectElm = $("select[name='addReportColumnDropdown']");


                            // selectElm.selectpicker({});

                            selectElm.change(function () {
                                var elm = $(this);
                                var displayName = "";

                                if (elm.find("option:selected").data("customviewcolumntype") == "Device")
                                    displayName = elm.find("option:selected").html().replace(/\(Device\)?$/, "").trim();
                                else
                                    displayName = elm.find("option:selected").html();

                                athoc.iws.publishing.iut.newlyaddedColumns.push({ Id: elm.val(), Key: elm.find("option:selected").data("key"), CustomViewColumnType: elm.find("option:selected").data("customviewcolumntype"), DisplayName: displayName });
                                athoc.iws.publishing.iut.createReadOnlyUserList();
                                /*athoc.iws.publishing.iut.updateReportViewColumn(0, elm.val(),
                                    "add",
                                    elm.find("option:selected").data("customviewcolumntype"),
                                    elm.find("option:selected").data("key"),elm.find("option:selected").html(),
                                    function () {
                                        // $.AjaxLoader.hideLoader();

                                        athoc.iws.publishing.iut.hideAddColumns();

                                    });*/
                            });
                            //  });

                            athoc.iws.publishing.iut.showAddColumns();

                            var existCssValue = $("#newColumn").parent().css("top");
                            existCssValue = existCssValue.replace("px", '');
                            if (parseInt(existCssValue) > 134)
                                $("#newColumn").parent().css("top", (parseInt(existCssValue) - 14) + 'px');


                            existCssValue = $("#newColumn").parent().css("left");
                            existCssValue = existCssValue.replace("px", '');
                            $("#newColumn").parent().css("left", (parseInt(existCssValue) + 4) + 'px');
                        }
                        $.AjaxLoader.hideLoader();
                    }
                };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);
                //}
            },

            //
            updateReportViewColumn: function (viewId, id, action, columnType, columnKey, columnName, onSuccess) {
                var self = this;
                if (viewId == "" || viewId == null || viewId == undefined)
                    viewId = 0;
                if (id) {
                    $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#ReadOnlyUserList .dropdown-div'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '150px', left: '60%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();
                    if (action == "remove" && athoc.iws.publishing.iut.readOnlySortColumn == columnKey) {
                        athoc.iws.publishing.iut.readOnlySortColumn = "USERNAME";
                        athoc.iws.publishing.iut.readOnlySortOrder = "ASC";
                    }

                    var myAjaxOptions = {
                        url: athoc.iws.publishing.urls.SaveReportCustomViewUrl,
                        type: "POST",
                        dataType: "json",
                        data: { viewId: viewId, id: id, action: action, type: columnType, commonName: columnKey },
                        success: function () {
                            athoc.iws.publishing.iut.newlyaddedColumns = athoc.iws.publishing.iut.newlyaddedColumns + "," + columnName;
                            athoc.iws.publishing.iut.createReadOnlyUserList();
                            $.AjaxLoader.hideLoader();

                        },
                        error: function (e) {
                            athoc.iws.publishing.iut.handleError(e);
                        },

                    };

                    var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);

                    $.ajax(ajaxOptions);
                }
            },

            OnReadOnlyDataBound: function (e) {
                $(".kendo-mini-pager").removeClass("k-pager-wrap");
                $(".kendo-mini-pager").removeClass("k-widget");
                $(".kendo-mini-pager").removeClass("k-floatwrap");
                var data = $("#readonlyUserList").data("kendoGrid").dataSource.view();
                var grid = $("#readonlyUserList").data("kendoGrid");
                grid.pager.dataSource = readOnlyDatasource;
                athoc.iws.publishing.iut.OnBoundReadonlyEmptyRow(data);
            },

            OnReadOnlyDataBinding: function () {
                var ds = $("#readonlyUserList").data("kendoGrid").dataSource;
                ds._sort = [{ field: athoc.iws.publishing.iut.readOnlySortField, dir: athoc.iws.publishing.iut.readOnlySortOrder }];
            },

            ShowUsersList: function (sessionId, covered, attributeCSV, totalCount) {
                athoc.iws.publishing.iut.readOnlyInputParameters.sessionId(sessionId);
                athoc.iws.publishing.iut.readOnlyInputParameters.covered(covered);
                athoc.iws.publishing.iut.readOnlyInputParameters.attributeCSV(attributeCSV);
                athoc.iws.publishing.iut.readOnlyInputParameters.totalCount(totalCount);
                $("#txtReadOnlySearch").val('');
                //$("#btn_readonlyusersearch").attr('disabled', true);
                $('#ReadOnlyUserList').modal('show');
                athoc.iws.publishing.iut.resizeModalBasedOnScreen($('#ReadOnlyUserList'));
                athoc.iws.publishing.iut.createReadOnlyUserList();
                athoc.iws.publishing.iut.firstTimeReachableUser = 0;
            },

            //All Available users and Targeted/Blocked user PopUp

            // Get all users data and bind to kendo grid
            createAddBlockUsersGrid: function (getNextPage, onSuccess, searchParameters, page, showSpinner) {
                var self = this;
                var strSearch = [];
                var gridRowsObject = [];

                $.grep(athoc.iws.publishing.iut.searchString, function (i) {
                    strSearch.push(i.value);
                });
                if (firstTimeOpenAddUser == 0) {
                    $("#allUserList").html('');
                    $('#allUserList').hide();
                    firstTimeOpenAddUser = 1;
                }
                var parameters = {
                    searchStrings: strSearch,
                    staticQueryCriteria: '',
                    sortBy: athoc.iws.publishing.iut.allUserSortColumn,
                    sortOrder: athoc.iws.publishing.iut.allUserSortOrder,
                    pageSize: athoc.iws.publishing.iut.allUsersPageSize,
                    searchFlow: "FromUserManager",
                };
                gridColumnDefs = [];
                allUserDatasource = new kendo.data.DataSource({
                    transport: {
                        read: {
                            url: athoc.iws.publishing.urls.GetUserListUrl,
                            type: "POST",
                            dataType: "json",
                            data: parameters,
                            traditional: true,
                        },

                    },
                    requestStart: function (e) {
                        $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#divProgress'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '50%', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();
                        $("#divProgress .blockMsg").css("margin", "-13px");
                        $("#divProgress .blockMsg").css("left", "40px");
                    },
                    requestEnd: function (e) {

                        if (e.response != null) {
                            gridColumnDefs.length = 0;
                            // Add checkbox column to the column array
                            gridColumnDefs.push({
                                title: '',
                                field: '',
                                template: $("#userList-chkTargeted-template").html(),
                                headerTemplate: kendo.format('<input name="chbox" id="allUsersCheckAll" value="0" type="checkbox" title="' + athoc.iws.publishing.iut.resources.IUTAllUsers_SelectAll_DeSelect + '" data-type="selectAll" onclick="athoc.iws.publishing.iut.allUsersSelectAll();"/>', ""),
                                width: 34,
                            });

                            // column width based on column count
                            var colWidth = 0;
                            if (e.response.Columns.length < 7)
                                colWidth = "auto";
                            else
                                colWidth = "120px";

                            // Add secondary columns to the column array 
                            _.each(e.response.SecondaryColumns, function (column, cIndex) {
                                var headerSecTemplate = "";
                                var dtemplate = "";
                                var sfield = "_" + column.Key.replace(/[-:~!@#$%^&*(){}\[\]<>,.€\s'\"?\\\/]/g, "");

                                headerSecTemplate = '<span title="' + $.htmlEncode(column.DisplayName) + '" class="table-head-primary' + (column.IsSortable ? " table-head-sortable" : "") + '"data-key="' + column.Key + '" onclick="athoc.iws.publishing.iut.allUserGridColumnSort(\'' + sfield + '\',\'' + column.Key + '\');">' + $.htmlEncode(column.DisplayName) + '</span>';

                                if (athoc.iws.publishing.iut.allUserSortColumn.toUpperCase() == column.Key) {
                                    athoc.iws.publishing.iut.allUserSortField = sfield;
                                    if (athoc.iws.publishing.iut.allUserSortOrder.toUpperCase() == "ASC") {
                                        headerSecTemplate += '<span class="sort-indicator-ascending"></span>';
                                    }
                                    else if (athoc.iws.publishing.iut.allUserSortOrder.toUpperCase() == "DESC") {
                                        headerSecTemplate += '<span class="sort-indicator-descending"></span>';
                                    }
                                }

                                headerSecTemplate = kendo.format(headerSecTemplate);
                                if (gridColumnDefs.length == 1)
                                    dtemplate = $("#userList-link-template").html();
                                else
                                    dtemplate = '<span title="#=' + sfield + '#">#=' + sfield + '#</span>';

                                gridColumnDefs.push({
                                    title: column.DisplayName,
                                    field: sfield,
                                    width: colWidth,
                                    template: dtemplate,
                                    headerTemplate: headerSecTemplate,
                                    headerAttributes: {
                                        viewid: column.ViewId,
                                        id: column.Id,
                                        customviewcolumntype: "",
                                        key: column.Key
                                    }
                                });
                            });
                            // Add coumns to column array
                            _.each(e.response.Columns, function (column, cIndex) {
                                var headerTemplate = "";
                                var field = "_" + column.Key.replace(/[-:~!@#$%^&*(){}\[\]<>,.€\s'\"?\\\\/]/g, "");
                                if (column.IsRequired != true) {
                                    headerTemplate = '<div title="' + athoc.iws.publishing.resources.Publishing_RemoveGridColumn + ' ' +$.htmlEncode(column.DisplayName) + '" class="icon_clear remove-column" onclick="athoc.iws.publishing.iut.userListRemoveColumn(event);"></div>' +
                                        '<span title="' + $.htmlEncode(column.DisplayName) + '" class="table-head-primary' + (column.IsSortable ? " table-head-sortable" : "") + '" data-key="' + column.Key + '" onclick="athoc.iws.publishing.iut.allUserGridColumnSort(\'' + field + '\',\'' + column.Key + '\');">' + $.htmlEncode(column.DisplayName) + '</span>';
                                }
                                else
                                    headerTemplate = '<span title="' + $.htmlEncode(column.DisplayName) + '" class="table-head-primary' + (column.IsSortable ? " table-head-sortable" : "") + '"data-key="' + column.Key + '"onclick="athoc.iws.publishing.iut.allUserGridColumnSort(\'' + field + '\',\'' + column.Key + '\');" >' + $.htmlEncode(column.DisplayName) + '</span>';

                                if (athoc.iws.publishing.iut.allUserSortColumn.toUpperCase() == column.Key) {
                                    athoc.iws.publishing.iut.allUserSortField = field;
                                    if (athoc.iws.publishing.iut.allUserSortOrder.toUpperCase() == "ASC") {
                                        headerTemplate += '<span class="sort-indicator-ascending"></span>';
                                    }
                                    else if (athoc.iws.publishing.iut.allUserSortOrder.toUpperCase() == "DESC") {
                                        headerTemplate += '<span class="sort-indicator-descending"></span>';
                                    }
                                }
                                headerTemplate = kendo.format(headerTemplate);
                                gridColumnDefs.push({
                                    title: column.DisplayName,
                                    field: field,
                                    width: colWidth,
                                    template: '<span title="#=' + field + '#">#=' + field + '#</span>',
                                    headerTemplate: headerTemplate,
                                    headerAttributes: {
                                        viewid: column.ViewId,
                                        id: column.Id,
                                        customviewcolumntype: "",
                                        key: column.Key
                                    }
                                });
                            });

                            // Add add/reset column to column array
                            gridColumnDefs.push({
                                title: athoc.iws.publishing.iut.resources.IUTAllUsers_Add_Reset,
                                field: "",
                                width: "80px",
                                template: $("#userList-BlockUnblock-template").html(),
                                headerTemplate: '<a href="#" class="small-msg block column-select" id="addReportColumn" onClick="athoc.iws.publishing.iut.addNewGridColumn()" title="' + athoc.iws.publishing.iut.resources.Action_Link_Add + '"  >' + athoc.iws.publishing.iut.resources.Action_Link_Add + '</a><a href="#" class="small-msg block" id="reset"  onClick="athoc.iws.publishing.iut.ResetGridList()" title="' + athoc.iws.publishing.iut.resources.IUTAllUsers_Reset + '" >' + athoc.iws.publishing.iut.resources.IUTAllUsers_Reset + '</a>'
                            });

                            // Prepare datasource for kendo grid
                            gridRowsObject.length = 0;
                            _.each(e.response.Rows, function (row, rIndex) {
                                var colObject = new Object();
                                colObject["Id"] = row.Id;
                                _.each(e.response.SecondaryColumns, function (column, cIndex) {
                                    var value = athoc.iws.publishing.iut.getColumnValue(column, row);
                                    colObject["_" + column.Key.replace(/[-:~!@#$%^&*(){}\[\]<>,.€\s'\"?\\\/]/g, "")] = $.customizedHtmlEncoding(value);
                                });

                                _.each(e.response.Columns, function (column, cIndex) {
                                    var value = athoc.iws.publishing.iut.getColumnValue(column, row);
                                    if (column.DataFormat && column.DataType && (!(column.DataType == 4 || column.DataType == 5)))
                                        value = $.getFormattedValue(column.DataType, column.DataFormat, value);
                                    colObject["_" + column.Key.replace(/[-:~!@#$%^&*(){}\[\]<>,.€\s'\"?\\\/]/g, "")] = $.customizedHtmlEncoding(value);
                                });
                                var tbItem = $.grep(athoc.iws.publishing.iut.viewModel.targetedBlockerUsers(), function (i) {
                                    return i.UserId == row.Id;
                                });
                                if (tbItem.length > 0 && !tbItem[0].IsBlocked)
                                    colObject["IsTargeted"] = true;
                                else
                                    colObject["IsTargeted"] = false;

                                if (tbItem.length > 0 && tbItem[0].IsBlocked)
                                    colObject["IsBlocked"] = true;
                                else
                                    colObject["IsBlocked"] = false;

                                gridRowsObject.push(colObject);
                            })
                            allUserDatasource._total = e.response.TotalCounts;
                        }
                        else {
                            gridColumnDefs.length = 0;
                            gridRowsObject.length = 0;
                            gridColumnDefs.push({
                                title: '',
                                field: '',
                                template: $("#userList-chkTargeted-template").html(),
                                headerTemplate: kendo.format('<input name="chbox" id="allUsersCheckAll" value="0" type="checkbox" title="' + athoc.iws.publishing.iut.resources.IUTAllUsers_SelectAll_DeSelect + '" data-type="selectAll" onclick="athoc.iws.publishing.iut.allUsersSelectAll();"/>', ""),
                                width: 5,
                            });
                            gridColumnDefs.push({
                                title: 'Username',
                                field: '',
                                width: 80,
                            });
                            gridColumnDefs.push({
                                title: athoc.iws.publishing.iut.resources.IUTAllUsers_Add_Reset,
                                field: "",
                                width: "10px",
                                template: $("#userList-BlockUnblock-template").html(),
                                headerTemplate: '<a href="#" class="small-msg block column-select" id="addReportColumn" onClick="athoc.iws.publishing.iut.addNewGridColumn()" title="' + athoc.iws.publishing.iut.resources.Action_Link_Add + '"  >' + athoc.iws.publishing.iut.resources.IUTAllUsers_Add + '</a><a href="#" class="small-msg block" id="reset"  onClick="athoc.iws.publishing.iut.ResetGridList()" title="' + athoc.iws.publishing.iut.resources.IUTAllUsers_Reset + '" >' + athoc.iws.publishing.iut.resources.IUTAllUsers_Reset + '</a>'
                            });
                        }
                        // Page info of kendo grid
                        $("#allUserPageInfo").kendoPager({
                            dataSource: allUserDatasource,
                            autoBind: false,
                            numeric: false,
                            previousNext: false,
                            messages: {
                                display: athoc.iws.publishing.iut.resources.IUTAllUsers_PagingInfo,
                                empty: athoc.iws.publishing.iut.resources.IUTReadOnly_Emptyrow_Message
                            }
                        });
                        // Allusers kendo grid
                        $("#allUserList .k-grid-header").html('');
                        $("#allUserList").find(".bootstrap-select").remove();
                        ko.cleanNode($("#allUserList").get(0));
                        athoc.iws.publishing.iut.allUsersgrid = $("#allUserList").kendoGrid({
                            columns: gridColumnDefs,
                            dataSource: gridRowsObject,
                            selectable: false,
                            scrollable: true,
                            autoBind: true,
                            sortable: false,
                            pageable: {
                                refresh: false,
                                pageSizes: true,
                                pageSizes: [20, 50, 100],
                                buttonCount: 5,
                                messages: {
                                    display: $.htmlDecode(athoc.iws.publishing.iut.resources.IUTAllUsers_PagingInfo),
                                    empty: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Empty),
                                    itemsPerPage: $.htmlDecode(athoc.iws.publishing.iut.resources.IUTAllUsers_ItemsPerPage),
                                    first: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                                    previous: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                                    next: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                                    last: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                                }
                            },
                            dataBinding: athoc.iws.publishing.iut.onAllUserDataBinding,
                            dataBound: athoc.iws.publishing.iut.onAllUserDataBound,
                            change: function (e) {
                                var model = this.dataItem(this.select());
                                this.select().removeClass("k-state-selected");
                                athoc.iws.publishing.iut.userInfo.update({ userId: model.Id, userName: model._LOGIN_ID });
                                $("#userInfoModal", athoc.iws.publishing.iut.userInfo.refDomNode).modal("show");
                                // athoc.iws.publishing.iut.UserKendoToolTip(model.Id);
                            }

                        }).data().kendoGrid;

                        $("#newColumns").html('');
                        athoc.iws.publishing.iut.allUsersPageSize = athoc.iws.publishing.iut.allUsersgrid.pager.dataSource._pageSize;

                        setTimeout(function () {
                            // Fit height for the alluer grid
                            athoc.iws.publishing.iut.fitHeightAllUsers();
                            $.AjaxLoader.hideLoader();
                        }, 100);


                        if (onSuccess)
                            onSuccess();

                    },
                    schema: {
                        data: "Rows",
                        total: "TotalCounts",
                    },
                    serverPaging: true,
                    serverSorting: true,
                    serverFiltering: true,
                    sort: { field: "Username", dir: "desc" },
                    pageSize: 50,
                    error: function (e) {
                        var errorCallBack = function (returnedErrorObject) {
                            $('#listMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        };
                        AjaxUtility().athocKendoGridAjaxErrorHandler(e, errorCallBack);
                        athoc.iws.publishing.iut.handleError(e);
                    },
                    change: function (e) {
                        athoc.iws.publishing.iut.retainSelectAll();
                        // Added the below line to make the grid scroll on top in case of paging and sorting
                        $("#allUserList").find("div.k-grid-content").scrollTop(0);
                        
                    }
                });
                allUserDatasource._pageSize = athoc.iws.publishing.iut.allUsersPageSize;
                allUserDatasource.read();
                return 0;
            },

            // Databound event for the allusers grid
            onAllUserDataBound: function (e) {

                var data = $("#allUserList").data("kendoGrid").dataSource.view();
                athoc.iws.publishing.iut.viewModel.allAvailableUser(data);

                var grid = $("#allUserList").data("kendoGrid");
                grid.pager.dataSource = allUserDatasource;

                if (data.length > 0)
                    $("#allUserList .k-grid-header").css("width", "98% !important");
                else
                    $("#allUserList .k-grid-header").css("width", "100% !important");
                athoc.iws.publishing.iut.OnBoundAllUsersEmptyRow(data);

            },

            // Databinding event for the allusers grid
            onAllUserDataBinding: function (e) {
                var ds = $("#allUserList").data("kendoGrid").dataSource;
                ds._sort = [{ field: athoc.iws.publishing.iut.allUserSortField, dir: athoc.iws.publishing.iut.allUserSortOrder }];
            },

            OnBoundAllUsersEmptyRow: function (data) {
                var colCount = $("#allUserList").find('.k-grid-header colgroup > col').length;
                if (data.length == 0) {
                    $("#allUserList").find('.k-grid-content tbody')
                        .append('<tr class="kendo-data-row"><td colspan="' +
                            colCount +
                            '" style="text-align:center;height:10px;overflow:auto;">' +
                            kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', athoc.iws.publishing.iut.resources.AtHoc_Pager_Message_Empty, athoc.iws.publishing.iut.resources.AtHoc_Pager_Message_Empty) +
                            '</td></tr>');

                }
            },

            // Get user info for the compact popup
            getUserInfo: function (obj) {

                var id = obj.getAttribute('value');
                var name = obj.getAttribute('title');
                athoc.iws.publishing.iut.userInfo.update({ userId: id, userName: name }, $('#userInfoModal').find('#showProgress'));
                $("#alertinguserInfoHolder").find($("#userInfoModal")).modal("show");
                $("#AddBlockUsers").append('<div id="displayShadow" class="modal-backdrop fade in"></div>');
                $('#userInfoModal',$("#alertinguserInfoHolder")).on('hidden.bs.modal', function () {
                    $("#AddBlockUsers").find('#displayShadow').remove();
                })
            },

            // Get user info for the compact popup
            getUserInfoforFlatList: function (obj) {
                var id = obj.getAttribute('value');
                var name = obj.getAttribute('title');
                athoc.iws.publishing.iut.userInfo.update({ userId: id, userName: name });
                $("#alertinguserInfoHolder").find($("#userInfoModal")).modal("show");

            },

            // Sorting of columns for allusers grid
            allUserGridColumnSort: function (field, key) {
                athoc.iws.publishing.iut.allUserSortField = field;
                athoc.iws.publishing.iut.allUserSortColumn = key;
                if (athoc.iws.publishing.iut.allUserSortOrder == "desc")
                    athoc.iws.publishing.iut.allUserSortOrder = "asc";
                else
                    athoc.iws.publishing.iut.allUserSortOrder = "desc";
                athoc.iws.publishing.iut.createAddBlockUsersGrid();

            },

            // Select all event for the allusers grid
            allUsersSelectAll: function () {
                var checked = $('#allUsersCheckAll').is(':checked');
                var grid = $('#allUserList').data().kendoGrid;
                $.each(grid.dataSource.view(), function (i, item) {
                    if (checked) {
                        if (!item.IsBlocked && athoc.iws.publishing.iut.viewModel.targetedCnt() < athoc.iws.publishing.settings.IndividualUserTargetSelectionLimit) {
                            item.IsTargeted = checked;
                            athoc.iws.publishing.iut.updateTargetedBlockedUsers(item);
                        }
                        else if (!item.IsBlocked) {
                            $("#AddBlockUsers").append('<div id="displayShadow" class="modal-backdrop fade in"></div>');
                            $("#lblUsersLimit").html(athoc.iws.publishing.settings.IndividualUserTargetSelectionLimit);
                            $('#btn_limitCancel').on('click', function (event) {
                                $("#dialogUsersLimit").hide();

                                $("#AddBlockUsers").find('#displayShadow').remove();
                            });
                            $("#dialogUsersLimit").show();
                            $("#allUsersCheckAll").prop('checked', false);
                            return false;
                        }
                    }
                    else if (!item.IsBlocked && item.IsTargeted) {
                        item.IsTargeted = checked;
                        athoc.iws.publishing.iut.updateTargetedBlockedUsers(item);
                    }
                });
                grid.refresh();//update the grid...

            },

            // Retain check all when the paging is done
            retainSelectAll: function () {

                var grid = $('#allUserList').data().kendoGrid;
                var items = grid.dataSource.view();
                var ttlCnt = 0;
                // Get the selected items for the current page.
                $.grep(items, function (v) {
                    if (v.IsTargeted || v.IsBlocked)
                        ttlCnt++;
                });

                // Check total page count equal to selected count 
                var checked = ttlCnt > 0 && (items.length == ttlCnt);
                $("#allUsersCheckAll").prop('checked', checked);


            },

            // Createing pills when search is done
            createPills: function (value, type, display) {

                var found = _.find(athoc.iws.publishing.iut.searchString, function (item) {
                    return (item.value == value && item.type == type);
                });
                if (!found) {
                    athoc.iws.publishing.iut.searchString.push({ value: value, type: type, display: display });
                    athoc.iws.publishing.iut.renderPills();
                    athoc.iws.publishing.iut.createAddBlockUsersGrid();

                }
            },

            // Rendering the pills when search is done
            renderPills: function (css) {
                var self = this;
                var html = "";
                $("#divSearch .pill-container").html('');
                if (athoc.iws.publishing.iut.searchString && athoc.iws.publishing.iut.searchString.length > 0) {
                    _.each(athoc.iws.publishing.iut.searchString, function (item, index) {
                        var iconCss = "";
                        var prefix = "";
                        //html += '<div class="pill" data-index="' + index + '"><span class="pill-content">' + prefix + item.display + '</span><div class="pill-icon ' + iconCss + '"></div><a class="pill-close" href="javascript://"></a></div>';
                        var pillLabel = prefix + $.htmlEncode(item.display);
                        var pillTooltip = prefix + $.htmlEncode(item.display);
                        var closeButton = (typeof (css) === 'undefined' ? '<a class="pill-close" href="#"></a>' : '');
                        html = '<div class="pill" data-index="' + index + '" title="' + pillTooltip + '"><span class="pill-content">' + pillLabel + '</span>' + closeButton + '</div>' + html;
                    });

                    var pillsElm = $("#divSearch .pill-container");
                    pillsElm.html(html);
                    //wire up events
                    $("#divSearch .pill-close").click(function (event) {
                        var parentElm = $(this).parent(".pill");
                        athoc.iws.publishing.iut.deSelect(parentElm.data("index"));
                        event.stopPropagation();
                    });
                }
            },

            // Deleteing the pills
            deSelect: function (index, onSuccess) {
                if (athoc.iws.publishing.iut.searchString && athoc.iws.publishing.iut.searchString.length > index) {
                    athoc.iws.publishing.iut.searchString.splice(index, 1);
                    athoc.iws.publishing.iut.renderPills();
                    athoc.iws.publishing.iut.createAddBlockUsersGrid();
                }
            },

            // For Add/Block Users reset grid 
            ResetGridList: function () {
                $("#AddBlockUsers").append('<div id="displayShadow" class="modal-backdrop fade in"></div>');
                $("#dialogResetAllUsers").show();
                $("#dialogResetAllUsers").on('click', '.btn-info', function (event) {
                    $("#dialogResetAllUsers").hide();
                    $("#AddBlockUsers").find('#displayShadow').remove();
                });
            },

            ResetGridListOk: function () {
                $("#dialogResetAllUsers").hide();
                $("#AddBlockUsers").find('#displayShadow').remove();
                var myAjaxOptions = {
                    url: athoc.iws.publishing.urls.ResetToDefaultViewUrl,
                    type: "POST",
                    dataType: "json",
                    success: function (data) {
                        athoc.iws.publishing.iut.createAddBlockUsersGrid();
                    }
                };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);
            },

            // common to grids
            getColumnValue: function (column, row) {
                if (column.Key == "OPERATOR-ROLES") {
                    var roleCount = row.UserAttributes["ROLECOUNT_OTHERORGS"];
                    if (roleCount && roleCount != " ") {
                        return row.UserAttributes[column.Key] + " (" + row.UserAttributes["ROLECOUNT_OTHERORGS"] + ") ";
                    } else {
                        return row.UserAttributes[column.Key];
                    }
                }
                return column.CustomViewColumnType === "CF"
                    ? row.UserAttributes[column.Key]
                    : row.UserDevice[column.Key];
            },

            // For Add/Block Users add new GridColumn to grid 
            addNewGridColumn: function () {
                var self = this;

                var myAjaxOptions = {
                    url: athoc.iws.publishing.urls.GetCustomViewsUrl,
                    type: "POST",
                    dataType: "json",
                    success: function (data) {
                        if (data && data.length > 0) {
                            $("#newColumns").html('');
                            var htmlAttributes = '';
                            var deviceOptions = '';
                            var operatorOptions = '';
                            var hierarchyOptions = '';
                            var hierarchyGroup = '', attributeGroup = '', deviceGroup = '', operatorAttributeGroup = '';
                            var html = "";
                            html += '<select  name="addColumnDropdown"  data-placeholder="" size=10  style="width:250px !important;margin-left:5px !important">';

                            _.each(data, function (item, index) {
                                var optionList = "<option value='" + item.Id + "' data-customviewcolumntype='" + item.CustomViewColumnType + "' data-key='" + item.Key + "'>" + $.htmlEncode(item.DisplayName) + "</option>";

                                if (item.CustomViewColumnType == "CF" && item.IsHierarchy == false && item.Key == $.htmlDecode(athoc.iws.publishing.iut.resources.AtHoc_Grid_CommonName_OperatorRoles)) {
                                    operatorOptions = operatorOptions + optionList;
                                }
                                else if (item.CustomViewColumnType == "CF" && item.IsHierarchy == false) {
                                    htmlAttributes = htmlAttributes + optionList;
                                }
                                else if (item.CustomViewColumnType == "CF" && item.IsHierarchy == true) {
                                    hierarchyOptions = hierarchyOptions + optionList;
                                }
                                else if (item.CustomViewColumnType == "Device") {
                                    deviceOptions = deviceOptions + optionList;
                                }
                            });

                            if (hierarchyOptions != '') {
                                hierarchyGroup = '<optgroup label="Organization Hierarchy">' + hierarchyOptions + '</optgroup>';
                            }

                            if (htmlAttributes != '')
                                attributeGroup = '<optgroup label="Attributes">' + htmlAttributes + '</optgroup>';

                            if (deviceOptions != '')
                                deviceGroup = '<optgroup label="Devices">' + deviceOptions + '</optgroup>';

                            if (operatorOptions != '')
                                operatorAttributeGroup = '<optgroup label="' + $.htmlDecode(athoc.iws.publishing.iut.resources.AtHoc_Grid_OperatorAttributesLabel) + '">' + operatorOptions + '</optgroup>';

                            html = html + hierarchyGroup + attributeGroup + operatorAttributeGroup + deviceGroup;
                            html += '</select>';
                            $("#newColumns").html(html);

                            var selectElm = $("select[name='addColumnDropdown']");
                            selectElm.change(function () {
                                var elm = $(this);

                                athoc.iws.publishing.iut.updateGridColumn(0, elm.val(),
                                    "add",
                                    elm.find("option:selected").data("customviewcolumntype"),
                                    elm.find("option:selected").data("key"),
                                    function () {
                                        $("#contextDropdown").hide();
                                    });
                            });

                            var position = $("#AddBlockUsers .column-select").offset();
                            var selColumn = $("#AddBlockUsers .column-filter");
                            selColumn.css({ top: '190px' });
                            $("#contextDropdown").show();
                        }

                    }
                };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);
                //}
            },

            // For Add/Block user Update grid columns in a grid
            updateGridColumn: function (viewId, id, action, columnType, columnKey, onSuccess) {
                var self = this;
                if (id) {
                    //$.AjaxLoader.setup({ useBlock: true, idToShow: self._id + '-pageAjaxLoader', elementToBlock: $('.table-header'), imageURL: self.options.cdnUrl + '/Images/ajax-loader.gif' }).showLoader();
                    if (action == "remove" && athoc.iws.publishing.iut.allUserSortColumn == columnKey) {
                        athoc.iws.publishing.iut.allUserSortColumn = "DISPLAYNAME";
                        athoc.iws.publishing.iut.allUserSortOrder = "ASC";
                    }
                    var myAjaxOptions = {
                        url: athoc.iws.publishing.urls.SaveCustomViewUrl,
                        type: "POST",
                        dataType: "json",
                        data: { viewId: viewId, id: id, action: action, type: columnType, commonName: columnKey },
                        success: function (data) {
                            athoc.iws.publishing.iut.createAddBlockUsersGrid(undefined, onSuccess, undefined, undefined, false);
                        }
                    };

                    var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);

                    $.ajax(ajaxOptions);
                }
            },

            // Open Add/Blocked users popup
            OpenAddBlockUsers: function () {
                $("#allUsersBucket").show();
                $("#targetBlockBucket").hide();
                $('#AddBlockUsers').modal('show');
                athoc.iws.publishing.iut.viewModel.targetedBlockerUsers.removeAll();
                if ($("#targetBlockingList").data("kendoGrid") != null) {
                    var data = $("#targetBlockingList").data("kendoGrid").dataSource.view();
                    $.grep(data, function (i) {
                        athoc.iws.publishing.iut.viewModel.targetedBlockerUsers.push({ UserId: i.UserId, IsBlocked: i.IsBlocked, Name: i.Name });
                    });
                }
                firstTimeOpenAddUser = 0;
                athoc.iws.publishing.iut.clearAllTargetedBlockedUsersPopUp();
            },

            // Clear all updated data and reset the grid
            clearAllTargetedBlockedUsersPopUp: function () {
                //athoc.iws.publishing.iut.viewModel.targetedBlockerUsers.removeAll();
                athoc.iws.publishing.iut.viewModel.blockedCnt(0);
                athoc.iws.publishing.iut.viewModel.targetedCnt(0);
                $("#pillContainer").html("");
                $("#txtAllUserSearch").val('');
                athoc.iws.publishing.iut.allUserSortColumn = "DisplayName";
                athoc.iws.publishing.iut.allUserSortField = "_DISPLAYNAME";
                athoc.iws.publishing.iut.allUserSortOrder = "asc";
                athoc.iws.publishing.iut.allUsersPageSize = 50;
                athoc.iws.publishing.iut.searchString.length = 0;
                /*if ($("#targetBlockingList").data("kendoGrid") != null) {
                    var data = $("#targetBlockingList").data("kendoGrid").dataSource.view();
                    $.grep(data, function (i) {
                        athoc.iws.publishing.iut.viewModel.targetedBlockerUsers.push({ UserId: i.UserId, IsBlocked: i.IsBlocked, Name: i.Name });
                    });
                }*/
                athoc.iws.publishing.iut.countTargetedBlocked();
                athoc.iws.publishing.iut.createAddBlockUsersGrid();
                //$("#btn_userSearch").attr('disabled', 'true');
                $("#AddBlockUsers").find(".bootstrap-select").remove();
                athoc.iws.publishing.iut.resizeModalBasedOnScreen($('#AddBlockUsers'));
            },

            // Show all user tab
            showAllUsers: function () {
                athoc.iws.publishing.iut.createAddBlockUsersGrid();
                athoc.iws.publishing.iut.countTargetedBlocked();
                $("#allUsersBucket").show();
                $("#targetBlockBucket").hide();

            },
            // Show targeted/blocked tab
            showTargetedBlockedUsers: function () {
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#tbUsersList'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();
                $("#tbUsersList").html('');
                athoc.iws.publishing.iut.targetBlockPageSize = 50;
                athoc.iws.publishing.iut.targetingBlockUsers();
                $("#allUsersBucket").hide();
                $("#targetBlockBucket").show();
                $.AjaxLoader.hideLoader();

            },
            // Check event of checkbox in all user grid
            Targeted: function (obj) {
                var userId = obj.getAttribute("value");
                var item = _.find(athoc.iws.publishing.iut.viewModel.allAvailableUser(), function (i) {
                    return i.Id == userId;
                });
                //athoc.iws.publishing.settings.IndividualUserTargetSelectionLimit = 5;
                if (obj.checked && athoc.iws.publishing.iut.viewModel.targetedCnt() >= athoc.iws.publishing.settings.IndividualUserTargetSelectionLimit) {
                    $("#AddBlockUsers").append('<div id="displayShadow" class="modal-backdrop fade in"></div>');
                    $("#lblUsersLimit").html(athoc.iws.publishing.settings.IndividualUserTargetSelectionLimit);
                    $('#btn_limitCancel').on('click', function (event) {
                        $("#dialogUsersLimit").hide();

                        $("#AddBlockUsers").find('#displayShadow').remove();
                    });
                    $("#dialogUsersLimit").show();
                    obj.checked = false;
                    return false;
                }
                if (item != null) {
                    item.IsBlocked = false;
                    item.IsTargeted = obj.checked;
                    athoc.iws.publishing.iut.updateTargetedBlockedUsers(item);
                    athoc.iws.publishing.iut.retainSelectAll();
                }
            },
            //Block event of all users grid
            blockUser: function (obj) {
                var userId = obj;
                var item = _.find(athoc.iws.publishing.iut.viewModel.allAvailableUser(), function (i) {
                    return i.Id == userId;
                });
                if (item != null) {
                    item.IsBlocked = true;
                    item.IsTargeted = false;
                    athoc.iws.publishing.iut.updateTargetedBlockedUsers(item);
                    $("#allUserList").data("kendoGrid").refresh();
                    athoc.iws.publishing.iut.retainSelectAll();
                }
            },
            // UnBlock event of all users grid
            unBlockUser: function (obj) {
                //event.preventDefault();
                var userId = obj;
                var item = _.find(athoc.iws.publishing.iut.viewModel.allAvailableUser(), function (i) {
                    return i.Id == userId;
                });
                if (item != null) {
                    item.IsBlocked = false;
                    item.IsTargeted = false;
                    athoc.iws.publishing.iut.updateTargetedBlockedUsers(item);
                    $("#allUserList").data("kendoGrid").refresh();
                    athoc.iws.publishing.iut.retainSelectAll();
                }
            },
            // Remove event of all users grid
            removeTargBlockUser: function (id) {
                athoc.iws.publishing.iut.viewModel.targetedBlockerUsers.remove(function (i) { return i.UserId == id; });
                var item = _.find(athoc.iws.publishing.iut.viewModel.allAvailableUser(), function (i) {
                    return i.Id == id;
                });
                if (item != null) {
                    item.IsBlocked = false;
                    item.IsTargeted = false;
                }
                athoc.iws.publishing.iut.countTargetedBlocked();
                //var ds = $("#tbUsersList").data("kendoGrid").dataSource;
                //ds.remove(function (i) { return i.UserId == id; });
                //  $("#tbUsersList").data("kendoGrid").refresh();
            },
            // Adding targeted and blocked user to array
            updateTargetedBlockedUsers: function (obj) {
                var displayName = '';
                var item = _.find(athoc.iws.publishing.iut.viewModel.targetedBlockerUsers(), function (i) {
                    return obj.Id == i.UserId;
                });
                if (item == null && (obj.IsBlocked || athoc.iws.publishing.iut.viewModel.targetedCnt() < athoc.iws.publishing.settings.IndividualUserTargetSelectionLimit)) {
                    if (obj._DISPLAYNAME != null && $.trim(obj._DISPLAYNAME) != '' && $.trim(obj._DISPLAYNAME) != 'N/A')
                        displayName = obj._DISPLAYNAME;
                    else if ((obj._FIRSTNAME != null && $.trim(obj._FIRSTNAME) != '') || (obj._LASTNAME != null && $.trim(obj._LASTNAME) != ''))
                        displayName = $.trim(obj._FIRSTNAME + ' ' + obj._LASTNAME);
                    else
                        displayName = obj._LOGIN_ID;

                    athoc.iws.publishing.iut.viewModel.targetedBlockerUsers.push({ UserId: obj.Id, Name: displayName, IsBlocked: obj.IsBlocked });
                }
                else {
                    if (obj.IsBlocked == false && obj.IsTargeted == false)
                        athoc.iws.publishing.iut.viewModel.targetedBlockerUsers.remove(function (i) { return i.UserId == obj.Id });
                    else {
                        item.IsBlocked = obj.IsBlocked;
                    }
                }
                athoc.iws.publishing.iut.countTargetedBlocked();
            },
            // Updating targeted and blocked user count
            countTargetedBlocked: function () {
                athoc.iws.publishing.iut.viewModel.targetedCnt(
                ko.mapping.toJS(athoc.iws.publishing.iut.viewModel.targetedBlockerUsers()).filter(function (i) {
                    return !i.IsBlocked;
                }).length);

                athoc.iws.publishing.iut.viewModel.blockedCnt(
                ko.mapping.toJS(athoc.iws.publishing.iut.viewModel.targetedBlockerUsers()).filter(function (i) {
                    return i.IsBlocked;
                }).length);
            },
            // Apply event of popup
            applyChangesToList: function () {
                var data = [];
                $.grep(athoc.iws.publishing.iut.viewModel.targetedBlockerUsers(), function (i) {
                    data.push({ IsBlocked: i.IsBlocked, Name: i.Name, UserId: i.UserId });
                });
                //athoc.iws.publishing.iut.viewModel.targetedBlockerUsers().length = 0
                //data.sort(function (l, r) { return l.Name.toLowerCase() == r.Name.toLowerCase() ? 0 : (l.Name.toLowerCase() < r.Name.toLowerCase() ? -1 : 1); }).sort(function (l, r) { return l.IsBlocked < r.IsBlocked ? -1 : 1; });
                if (data.length > 0)
                    data.sort(function (l, r) { return [l.IsBlocked, l.Name.toLowerCase()] < [r.IsBlocked, r.Name.toLowerCase()] ? -1 : 1 })
                var tbuList = new kendo.data.DataSource({
                    data: data,
                });

                athoc.iws.publishing.iut.isChanged = true;

                $("#targetBlockingList").data("kendoGrid").setDataSource(tbuList);
                $('#AddBlockUsers').modal('hide');
                athoc.iws.publishing.iut.updateChangesToSummaryAndChart();
                athoc.iws.publishing.targetUsers.targetingChanged();
                athoc.iws.publishing.iut.dataChanged();

            },
            // Updating the Pie chart data and targeted summary
            updateChangesToSummaryAndChart: function () {
                var targetCount = ko.mapping.toJS(athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList()).filter(function (i) {
                    return !i.IsBlocked;
                }).length;

                var blockedCount = ko.mapping.toJS(athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList()).filter(function (i) {
                    return i.IsBlocked;
                }).length;

                athoc.iws.publishing.targetUsers.getTargetedUsersCount(targetCount);
                athoc.iws.publishing.targetUsers.getBlockedUsersCount(blockedCount);


                athoc.iws.publishing.detail.isIUTLoaded = true;
                athoc.iws.publishing.targetUsers.updateContactInfo();

            },

            // Bind data to targeted/blocked users grid
            targetingBlockUsers: function () {
                var dataTb = [];
                var sortState = '';
                $.grep(athoc.iws.publishing.iut.viewModel.targetedBlockerUsers(), function (i) {
                    dataTb.push({ IsBlocked: i.IsBlocked, Name: $.htmlDecode(i.Name), UserId: i.UserId });
                });

                if (athoc.iws.publishing.iut.targetBlockSort == "asc")
                    dataTb.sort(function (l, r) { return [l.IsBlocked, l.Name.toLowerCase()] < [r.IsBlocked, r.Name.toLowerCase()] ? -1 : 1 });
                else {
                    var tList = ko.mapping.toJS(dataTb).filter(function (i) {
                        return !i.IsBlocked;
                    }).sort(function (i, j) { return i.Name.toLowerCase() > j.Name.toLowerCase() ? -1 : 1; });

                    var rList = ko.mapping.toJS(dataTb).filter(function (i) {
                        return i.IsBlocked;
                    }).sort(function (i, j) { return i.Name.toLowerCase() > j.Name.toLowerCase() ? -1 : 1; });

                    dataTb.length = 0;
                    dataTb = tList.concat(rList);
                }

                var datasourcetbu = new kendo.data.DataSource({
                    data: dataTb,
                    pageSize: athoc.iws.publishing.iut.targetBlockPageSize,
                    change: function (e) {
                        var newState = JSON.stringify(this.sort());
                        if (newState != sortState) {
                            sortState = newState;
                            e.preventDefault();
                            this.page(1);
                        }
                        // Added the below line to make the grid scroll on top in case of paging and sorting
                        $("#tbUsersList").find("div.k-grid-content").scrollTop(0);

                    }
                });
                $("#tbUsersList").html('');
                //datasource.read();
                var grid = $("#tbUsersList").kendoGrid({
                    dataSource: datasourcetbu,
                    selectable: false,
                    scrollable: true,
                    sortable: false,
                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5,
                        messages: {
                            display: $.htmlDecode(athoc.iws.publishing.iut.resources.IUTAllUsers_PagingInfo),
                            empty: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Empty),
                            itemsPerPage: $.htmlDecode(athoc.iws.publishing.iut.resources.IUTAllUsers_ItemsPerPage),
                            first: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                            previous: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                            next: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                            last: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                        }
                    },
                    columns:
                            [
                                 {
                                     field: "",
                                     title: "",
                                     template: $("#targblock-imgtargeting-template").html(),
                                     width: "3%",
                                     headerAttributes: {
                                         tabindex: "2"
                                     }
                                 },
                                 {
                                     field: "Name",
                                     title: athoc.iws.publishing.iut.resources.IUTTBUserList_Name,
                                     // template: '<span title="#=Name#">#=Name#</span>',
                                     template: $("#targblock-name-template").html(),
                                     width: "92%",
                                     headerTemplate: kendo.format('<span title="' + athoc.iws.publishing.iut.resources.IUTTBUserList_Name + '" onclick="athoc.iws.publishing.iut.onTargetBlockedNameSort();">' + athoc.iws.publishing.iut.resources.IUTTBUserList_Name + '</span>{0}', athoc.iws.publishing.iut.targetBlockSort.toUpperCase() == "ASC" ? '<span class="sort-indicator-ascending"></span>' : '<span class="sort-indicator-descending"></span>'),
                                     headerAttributes: {
                                         tabindex: "3"
                                     }
                                 },
                                {
                                    field: "",
                                    title: athoc.iws.publishing.iut.resources.IUTTBUserList_Remove_User,
                                    template: $("#targblock-imgremove-template").html(),
                                    headerTemplate: kendo.format('<span title="{0}">{1}</span>', "", ""),
                                    width: "5%",
                                    headerAttributes: {
                                        tabindex: "4"
                                    }
                                },

                            ],
                    dataBound: athoc.iws.publishing.iut.onTargetBlockedDataBound,
                    change: function (e) {
                    }
                }).data().kendoGrid;

                athoc.iws.publishing.iut.fitHeighUserList();
            },
            // Databind evnet of targeted/blocked user grid
            onTargetBlockedDataBound: function (e) {
                var data = $("#tbUsersList").data("kendoGrid").dataSource.data();
                athoc.iws.publishing.iut.viewModel.targetedBlockerUsers(data);
                athoc.iws.publishing.iut.OnBoundTargetedBlockedEmptyRow(data);
                athoc.iws.publishing.iut.targetBlockPageSize = $("#tbUsersList").data("kendoGrid").dataSource._pageSize;
            },

            onTargetBlockeddataBinding: function (e) {
                var ds = $("#tbUsersList").data("kendoGrid").dataSource;
                ds._sort = [{ field: 'Name', dir: athoc.iws.publishing.iut.targetBlockSort }];
            },

            onTargetBlockedNameSort: function (e) {
                if (athoc.iws.publishing.iut.targetBlockSort == "asc")
                    athoc.iws.publishing.iut.targetBlockSort = "desc";
                else
                    athoc.iws.publishing.iut.targetBlockSort = "asc"

                athoc.iws.publishing.iut.targetingBlockUsers();
            },

            OnBoundTargetedBlockedEmptyRow: function (data) {
                var colCount = $("#tbUsersList").find('.k-grid-header colgroup > col').length;
                if (data.length == 0) {
                    $("#tbUsersList").find('.k-grid-content tbody')
                        .append('<tr class="kendo-data-row"><td colspan="' +
                            colCount +
                            '" style="text-align:center;height:10px;overflow:auto;">' +
                            kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', athoc.iws.publishing.iut.resources.AtHoc_Pager_Message_Empty, athoc.iws.publishing.iut.resources.AtHoc_Pager_Message_Empty) +
                            '</td></tr>');

                }
            },

            showTargetedUsersSummary: function (isReadonly) {
                var sortState = '';
                var dataTb = [];
                $.grep(athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList(), function (i) {
                    if (!i.IsBlocked)
                        dataTb.push({ IsBlocked: i.IsBlocked, Name: i.Name, UserId: i.UserId });
                });

                dataTb.sort(function (l, r) { return [l.IsBlocked, l.Name.toLowerCase()] < [r.IsBlocked, r.Name.toLowerCase()] ? -1 : 1 })
                var datasourcetbu = new kendo.data.DataSource({
                    data: dataTb,
                    pageSize: 50,
                    change: function (e) {
                        var newState = JSON.stringify(this.sort());
                        if (newState != sortState) {
                            sortState = newState;
                            e.preventDefault();
                            this.page(1);
                        }

                    }
                });
                //datasource.read();
                var cntrl = isReadonly ? $("#targetedUsersListDetail") : $("#targetedUsersList");
                cntrl.html('');
                var grid = cntrl.kendoGrid({
                    dataSource: datasourcetbu,
                    selectable: false,
                    scrollable: true,
                    sortable: { allowUnsort: false },
                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5,
                        messages: {
                            display: $.htmlDecode(athoc.iws.publishing.iut.resources.IUTAllUsers_PagingInfo),
                            empty: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Empty),
                            itemsPerPage: $.htmlDecode(athoc.iws.publishing.iut.resources.IUTAllUsers_ItemsPerPage),
                            first: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                            previous: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                            next: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                            last: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                        }
                    },
                    columns:
                            [
                                 {
                                     field: "Name",
                                     title: athoc.iws.publishing.iut.resources.IUTTargetedSummary_Name,
                                     template: '<span title="#=Name#">#=Name#</span>',
                                     width: "95%",
                                     headerAttributes: {
                                         tabindex: "3"
                                     }
                                 },
                            ],
                    change: function (e) {
                    }
                }).data().kendoGrid;
                grid.refresh();
                athoc.iws.publishing.iut.resizeModalBasedOnScreen($('#targetedUsersSummary'));
                athoc.iws.publishing.iut.fitHeightTargetedUsersSummaryList();
            },

            showBlockedUsersSummary: function (isReadonly) {
                var dataTb = [];
                var sortState = '';
                $.grep(athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList(), function (i) {
                    if (i.IsBlocked)
                        dataTb.push({ IsBlocked: i.IsBlocked, Name: i.Name, UserId: i.UserId });
                });

                dataTb.sort(function (l, r) { return [l.IsBlocked, l.Name.toLowerCase()] < [r.IsBlocked, r.Name.toLowerCase()] ? -1 : 1 })
                var datasourcetbu = new kendo.data.DataSource({
                    data: dataTb,
                    pageSize: 50,
                    change: function (e) {
                        var newState = JSON.stringify(this.sort());
                        if (newState != sortState) {
                            sortState = newState;
                            e.preventDefault();
                            this.page(1);
                        }

                    }
                });

                //datasource.read();
                var cntrl = isReadonly ? $("#blockedUsersListDetail") : $("#blockedUsersList");
                cntrl.html('');
                var grid = cntrl.kendoGrid({
                    dataSource: datasourcetbu,
                    selectable: false,
                    scrollable: true,
                    sortable: { allowUnsort: false },
                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5,
                        messages: {
                            display: $.htmlDecode(athoc.iws.publishing.iut.resources.IUTAllUsers_PagingInfo),
                            empty: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Empty),
                            itemsPerPage: $.htmlDecode(athoc.iws.publishing.iut.resources.IUTAllUsers_ItemsPerPage),
                            first: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                            previous: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                            next: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                            last: $.htmlDecode(athoc.iws.publishing.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                        }
                    },
                    columns:
                            [
                                 {
                                     field: "Name",
                                     title: athoc.iws.publishing.iut.resources.IUTBlockedSummary_Name,
                                     template: '<span title="#=Name#">#=Name#</span>',
                                     width: "95%",
                                     headerAttributes: {
                                         tabindex: "3"
                                     }
                                 },
                            ],
                    change: function (e) {
                    }
                }).data().kendoGrid;
                athoc.iws.publishing.iut.resizeModalBasedOnScreen($('#blockedUsersSummary'));
                athoc.iws.publishing.iut.fitHeightBlockedUsersSummaryList();

            },
            //Method to handle erro and session time out, this is boud with Ajax calls
            handleError: function (e) {

                if (e != undefined && e.status == 401 || (e != undefined && e.xhr != undefined && e.xhr.status == 401)) {
                    window.onbeforeunload = null;
                    window.location = window.location;
                } else if (e.errorThrown != "") {
                    if (athoc.iws.publishing.iut.errors === null) {
                        athoc.iws.publishing.iut.errors = [{ Type: '4', Value: e.errorThrown }];
                    } else {
                        athoc.iws.publishing.iut.errors.push({ Type: '4', Value: e.errorThrown });
                    }
                    $('#listMessagePanel').messagesPanel({ messages: this.errors }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                }
            },
            getTargetedUsers: function () {

                var targetdata = [];

                if (athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList().length > 0) {
                    $(athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList()).each(function (index, item) {
                        if (!item.IsBlocked)
                            targetdata.push(item.UserId);
                    });
                }
                return targetdata;
            },

            getBlockedUsers: function () {
                var blockeddata = [];
                if (athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList().length > 0) {
                    $(athoc.iws.publishing.iut.viewModel.targetedBlockerUsersList()).each(function (index, item) {
                        if (item.IsBlocked)
                            blockeddata.push(item.UserId);
                    });
                }
                return blockeddata;
            },
            Rebind: function (data) {
                $(data).each(function (index, item) {
                    athoc.iws.publishing.iut.viewModel.targetedBlockerUsers.remove(function (i) { return i.UserId == item; });
                });

                athoc.iws.publishing.iut.firsttimneLoad = false;

                // dataobject for maniplication
                athoc.iws.publishing.iut.createTargettingUserListGrid(athoc.iws.publishing.iut.viewModel.targetedBlockerUsers());
                $('#targetBlockingList .k-grid-header').hide();
                $('#targetBlockingList .k-pager-wrap').hide();
                athoc.iws.publishing.targetUsers.targetingChanged();
            },
           
        };
    }();
}
