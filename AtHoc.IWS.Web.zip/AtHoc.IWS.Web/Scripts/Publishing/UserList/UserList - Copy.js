﻿define([
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/array",
"dijit/_WidgetBase",
"dijit/_TemplatedMixin",
"dojo/Evented",
"dojo/dom-style",
"dojo/on",
"dojo/query",
"dojo/text!publishing/UserList/UserListTemplate.html"
],
function (declare, lang, array, widgetBase, templatedMixin, evented, domStyle, on, query, template) {
    var userList = declare("athoc.iws.publishing.UserList", [widgetBase, templatedMixin, evented], {
        templateString: template,
        userGridDom: null,
        //
        constructor: function (options, iUserInfo, iUserView) {
            var self = this;
            self.srcElement = options.srcRefNode;
            self.userPageLayout = options.pageLayout;
            self.resourceStrings = this.resourceStrings;
            self.GetUserListUrl = options.GetUserListUrl;
            self.gridColumnDefinitions = [];
            self.gridRows = [];
            self.searchString = [];
            self.allUserSortColumn = 'LOGIN_ID';
            self.allUserSortOrder = 'asc';
            self.allUsersPageSize = 50;
            self.allUserSortField = '_LOGIN_ID';
            self.allUsersgrid = '';
            self.userPageLayout = 'FromUserManager';
            self.divProgress = '';
            self.keyRegExpression = /[-:~!@#$%^&*(){}\[\]<>,.€\s'\"?\\\\/]/g;
            self.resourceStrings = [];
            self.defaultColumnWidth = '120px';
            self.allAvailableUser = [];
            self.Urls = options.Urls;
            self.width = options.width;
            self.height = options.height;
            self.gridDataSource = [];
            self.selectedUsers = [];
            self.iUserInfo = iUserInfo;
            self.userInfo = null;
            self.userView = iUserView;
            self.updatedRows = [];
            self.eventId = options.eventId;
            self.responseTypes = [];
            self.newlyaddedColumns = [];
            self.filterType = -1;
            self.statusFlag = false;
            self.hierarchyIds = [];
            self.listItemIds = [];
            self.responseId = "";
            self.comments = "";
            self.eventStatus = options.eventStatus;
            self.isAllowedToUpdateStatus = options.isAllowedToUpdateStatus;
            self.queryCriteria = "";
            self.queryCriteriaSelections = [];
            self.qroupsSelections = [];
            self.groupRefNode = options.groupRefNode;
            self.queryRefNode = options.queryRefNode;
            self.listItemIds = [];
            self.staticQueryCriteria = "",
            self.attributeValueIds = [];
            self.attributeIds = [];
            self.isGroupEnabled = options.isGroupEnabled;
            self.isAdvanceSearchEnabled = options.isAdvanceSearchEnabled;
            self.hierarchy = options.hierarchyRefNode;
        },

        // To initiate component
        startUp: function () {
            var self = this;
            if (self.userInfo == null) {
                self.userInfo = new self.iUserInfo($('#userCompactPopup', this.domNode), "#userInfoModalBody");
                self.userInfo.startup();
            }
            $(self.hierarchy).athocEntitySelectorPopup({
                i18n: userListResources,
                title: userListResources.User_Criteria_Builder_Select_Hierarchy,
                isHierarchySelector: true,
                showSummary: true,
                cdnUrl: userListUrls.cdnUrl,
                startTabIndex: 10000,
                onApplyClick: function (selections) {
                    $(self.queryRefNode).find("#groupSelectorContent").modal("show");
                },
                applyPreselectionViaLineage: true,
                hierarchyContext: ''
            });
            if (self.isAdvanceSearchEnabled) {
                $(self.queryRefNode).athocEntitySelectorPopup({
                    i18n: userListResources,
                    title: userListResources.AtHoc_User_Search_Create_Conditions,
                    cdnUrl: userListUrls.cdnUrl,
                    startTabIndex: 10000,
                    dateFormat: $.vpsDateFormat,
                    dateTimeFormat: $.vpsDateTimeFormat,
                    utcOffsetInMinutes: $.vpsTimeZone.UtcOffsetInMinutes,
                    vpsOffsetFromSystemInMinutes: $.vpsTimeZone.VPSOffsetFromSystemInMinutes,
                    widgetName: "athocQueryBuilder",
                    hideGeolocation: true,
                    hierarchySelectorTagId: "hierarchy-selector-popup-container",
                    onApplyClick: function (selections) {
                        self.renderAdvanceSearchpills(selections, false);
                    }
                });
                
            }
            if (self.isGroupEnabled) {
                //$(".btn-groups", this.domNode).removeClass("hide");
                $(self.groupRefNode).athocEntitySelectorPopup({
                    i18n: userListResources,
                    title: "Select Groups",
                    cdnUrl: userListUrls.cdnUrl,
                    startTabIndex: 1000,
                    selectorToClickToLaunch: ".btn-groups",
                    showSummary: true,
                    removeEmptyFolder: true,
                    onApplyClick: function (selections) {
                        self.renderAdvanceSearchpills(selections, true);
                    }
                });
            }
            self.inherited(arguments);
            self.createGrid();
            $("#filterName", this.domNode).text(self.resourceStrings.PAEvent_AllUsers);
            $("#txtAllUserSearch", this.domNode).keyup(function (e) {
                var seaString = $.trim($('#txtAllUserSearch', this.domNode).val());
                if ($.hotkeys.enter(e) && seaString != "") {
                    $('#pillContainer', this.domNode).show();
                    self.createPills(seaString, "SIMPLESEARCH", $('#txtAllUserSearch', this.domNode).val());
                    $('#txtAllUserSearch', this.domNode).val('');
                }
                if (seaString.length > 0) {
                    $("#btn_userSearch", this.domNode).removeAttr('disabled');
                }
            });

            $("#btn_userSearch", this.domNode).click(function () {
                if ($.trim($('#txtAllUserSearch', this.domNode).val()).length > 0) {
                    self.createPills($('#txtAllUserSearch', this.domNode).val(), "SIMPLESEARCH", $('#txtAllUserSearch', this.domNode).val());
                    $('#txtAllUserSearch', this.domNode).val('');
                    $('#pillContainer').show();
                }
            });

            $("#clearAllBtn", this.domNode).click(function () {
                self.clearAll();
                $('#pillContainer').hide();
            });
            $("body").click(function () {
                $("#contextDropdown").hide();
                //$("#filterContextDropdown", self.domNode).hide();
            });
        },
        //Render Avanced Serach Pills
        renderAdvanceSearchpills: function (selections, isGroup) {
            var self = this;
            if (selections["selections"].length > 0) {
                if (isGroup) {
                    self.qroupsSelections = selections.selections;
                    selections["selections"].forEach(function (selecteditem) {
                        //self.listItemIds.push(selecteditem.value);
                        self.listItemIds.push(selecteditem.value);
                        self.createPills(selecteditem.value, selecteditem.type, selecteditem.display);
                    });
                }
                else {
                    var query = "";
                    self.queryCriteriaSelections = selections.selections;
                    var queryCriteria = [];
                    self.queryCriteriaSelections.forEach(function (selecteditem) {
                        var selectedValues = [];
                        if (selecteditem.value.length > 0) {
                            queryCriteria.push(selecteditem);
                            selecteditem.value.forEach(function (selectedvalue) {
                                selectedValues.push(selectedvalue.text);
                            });
                        }
                        else
                            selectedValues.push(selecteditem.value);

                        if (query != "")
                            query = query + " AND " + selecteditem.entity.name + " " + selecteditem.operandName + " " + (selectedValues.length > 1 ? selectedValues.join(" OR ") : selectedValues.toString());
                        else
                            query = selecteditem.entity.name + " " + selecteditem.operandName + " " + (selectedValues.length > 1 ? selectedValues.join(" OR ") : selectedValues.toString());

                    });
                    self.queryCriteria = "";
                    self.queryCriteria = JSON.stringify(queryCriteria);
                    var found = _.find(self.searchString, function (item, i) {
                        if (item.value == "" && item.type == "ADVANCESEARCH")
                            self.searchString.splice(i, 1);
                    });
                    self.createPills("", "ADVANCESEARCH", query);
                }
            }
        },
        // Get all users data and bind to kendo grid
        createGrid: function (getNextPage, onSuccess, searchParameters, page, showSpinner) {
            var self = this;
            var strSearch = [];
            var cNames = '';
            var displayIds = '';
            gridRows = [];
            $.grep(this.searchString, function (i) {
                if (i.type == "SIMPLESEARCH")
                    strSearch.push(i.value);
            });

            var obj = [];
            _.each(self.newlyaddedColumns, function (item, index) {
                cNames = cNames + item.Key + ",";
            });

            var parameters = {
                selectedColumns: obj,
                searchStrings: strSearch,
                sortBy: this.allUserSortColumn,
                sortOrder: this.allUserSortOrder,
                pageSize: this.allUsersPageSize,
                searchFlow: this.userPageLayout,
                eventId: this.eventId,
                attributeCSV: cNames,
                displayColumnDeviceIds: displayIds,
                responseType: self.filterType,
                hierarchyIds: self.hierarchyIds,
                listItemIds: self.listItemIds,
                queryCriteria: self.queryCriteria,
                staticQueryCriteria: self.staticQueryCriteria,
                attributeValueIds: self.attributeValueIds,
                attributeIds: self.attributeIds

            };
            this.gridColumnDefinitions = [];
            self.gridDataSource = new kendo.data.DataSource({
                transport: {
                    read: {
                        url: this.Urls.GetEventUserListUrl,
                        type: "POST",
                        dataType: "json",
                        data: parameters,
                        traditional: true,
                    },
                },
                requestStart: function (e) {
                    //$.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $(this.divProgress), imageURL: options.cdnUrl + '/Images/ajax-loader.gif', top: '50%', left: '50%', displayText: this.resources.General_LoadingMessage }).showLoader();
                    //$(divProgress).find('.blockMsg').css("margin", "-13px");
                    //$(divProgress).find('.blockMsg').css("left", "40px");
                },
                requestEnd: function (e) {

                    if (e.response != null) {
                        self.gridColumnDefinitions.length = 0;
                        // Add checkbox column to the column array
                        self.gridColumnDefinitions.push({
                            title: '',
                            field: '',
                            template: $("#userList-chkTargeted-template", self.domNode).html(),//kendo.format('<input name="chbox" id="allUserList-chbox-#= Id #" value="#= Id #" type="checkbox" data-type="checkbox" class="chkClass" title=' + self.resourceStrings.IUTAllUsers_Select_Deselect + ' onchange="self.ph.Targeted(this)" #=IsTargeted ? checked="checked" :"" #/>'),
                            headerTemplate: $("#userList-chkAll-template", self.domNode).html(),//kendo.format('<input name="usersCheckAll" id="usersCheckAll" value="0" type="checkbox" title="' + self.resourceStrings.IUTAllUsers_SelectAll_DeSelect + '" data-type="selectAll" data-dojo-attach-event="ondijitclick:allUsersSelectAll" />', ""),
                            width: 34,
                        });

                        // column width based on column count
                        if (e.response.Columns.length < 7)
                            self.defaultColumnWidth = "auto";
                        else
                            self.defaultColumnWidth = "120px";
                        self.responseTypes = e.response.ResponseTypes;
                        // Add secondary columns to the column array 
                        _.each(e.response.SecondaryColumns, function (column, cIndex) {
                            var headerSecTemplate;
                            var dtemplate;
                            var fieldKey = "_" + column.Key.replace(self.keyRegExpression, "");
                            headerSecTemplate = '<span title="' + $.htmlEncode(column.DisplayName) + '" class="table-head-primary' + (column.IsSortable ? " table-head-sortable" : "") + '"data-key="' + column.Key + '" >' + $.htmlEncode(column.DisplayName) + '</span>';

                            if (self.allUserSortColumn.toUpperCase() == column.Key) {
                                self.allUserSortField = fieldKey;
                                if (self.allUserSortOrder.toUpperCase() == "ASC") {
                                    headerSecTemplate += '<span class="sort-indicator-ascending"></span>';
                                }
                                else if (self.allUserSortOrder.toUpperCase() == "DESC") {
                                    headerSecTemplate += '<span class="sort-indicator-descending"></span>';
                                }
                            }

                            headerSecTemplate = kendo.format(headerSecTemplate);
                            if (self.gridColumnDefinitions.length == 1)
                                dtemplate = '<a id="allUserListLink" value="#= Id #" class="allUserListLink" >#=_LOGIN_ID#</a>';//$("#userList-link-template").html();
                            else
                                dtemplate = '<span title="#=' + fieldKey + '#">#=' + fieldKey + '#</span>';

                            self.gridColumnDefinitions.push({
                                title: column.DisplayName,
                                field: fieldKey,
                                width: self.defaultColumnWidth,
                                template: dtemplate,
                                headerTemplate: headerSecTemplate,
                                headerAttributes: {
                                    viewid: column.ViewId,
                                    id: column.Id,
                                    customviewcolumntype: "",
                                    key: column.Key
                                }
                            });
                        });
                        // Add coumns to column array
                        _.each(e.response.Columns, function (column, cIndex) {
                            var headerTemplate = "";
                            var fieldKey = "_" + column.Key.replace(self.keyRegExpression, "");
                            if (column.IsDefault != true) {
                                headerTemplate = '<div title="' + self.resourceStrings.Publishing_RemoveGridColumn + ' ' + $.htmlEncode(column.DisplayName) + '" class="icon_clear remove-column" ></div>' +
                                    '<span title="' + $.htmlEncode(column.DisplayName) + '" class="table-head-primary' + (column.IsSortable ? " table-head-sortable" : "") + '" data-key="' + column.Key + '" >' + $.htmlEncode(column.DisplayName) + '</span>';
                            }
                            else
                                headerTemplate = '<span title="' + $.htmlEncode(column.DisplayName) + '" class="table-head-primary' + (column.IsSortable ? " table-head-sortable" : "") + '"data-key="' + column.Key + '" >' + $.htmlEncode(column.DisplayName) + '</span>';

                            if (self.allUserSortColumn.toUpperCase() == column.Key.toUpperCase()) {
                                self.allUserSortField = fieldKey;
                                if (self.allUserSortOrder.toUpperCase() == "ASC") {
                                    headerTemplate += '<span class="sort-indicator-ascending"></span>';
                                }
                                else if (self.allUserSortOrder.toUpperCase() == "DESC") {
                                    headerTemplate += '<span class="sort-indicator-descending"></span>';
                                }
                            }
                            headerTemplate = kendo.format(headerTemplate);

                            var template = '<span title="#=' + fieldKey + '#">#=' + fieldKey + '#</span>';
                            if (fieldKey == "_LOGIN_ID")
                                template = '<a id="allUserListLink" value="#= Id #" class="allUserListLink" title="#=' + fieldKey + '#" >#=' + fieldKey + '#</a>';
                            if (fieldKey == "_StatusId" && self.eventStatus == "Live" && self.isAllowedToUpdateStatus)
                                template = '<a id="StatusLink" value="#= Id #" class="StatusLink" title="#=' + fieldKey + '#" comments ="#=_Comments#" >#=' + fieldKey + '#</a>';

                            self.gridColumnDefinitions.push({
                                title: column.DisplayName,
                                field: fieldKey,
                                width: self.defaultColumnWidth,
                                ///  editor: function (container,options) { self.getColumnValues(container,options);},
                                template: template,
                                headerTemplate: headerTemplate,
                                headerAttributes: {
                                    viewid: column.ViewId,
                                    id: column.Id,
                                    customviewcolumntype: "",
                                    key: column.Key,
                                    dataType: column.DataType
                                }
                            });
                        });

                        // Add add/reset column to column array
                        self.gridColumnDefinitions.push({
                            title: self.resourceStrings.IUTAllUsers_Add_Reset,
                            field: "",
                            width: "80px",
                            template: '',//"<a id='allUserList-UnBlock-#= Id #' value='#= Id #' onclick='unBlockUser('#=Id #');' title='UnBlock'>Unblock</a>",
                            headerTemplate: '<a href="#" class="small-msg block column-select" id="addReportColumn" title="' + self.resourceStrings.IUTAllUsers_Add + '"  >' + self.resourceStrings.IUTAllUsers_Add + '</a><a href="#" class="small-msg block" id="reset" title="' + self.resourceStrings.IUTAllUsers_Reset + '" >' + self.resourceStrings.IUTAllUsers_Reset + '</a>'
                        });

                        // Prepare datasource for kendo grid
                        self.gridRows.length = 0;
                        _.each(e.response.Rows, function (row, rIndex) {
                            var gridColumnData = new Object();
                            gridColumnData["Id"] = row.Id;
                            var uRow = _.find(self.updatedRows, function (i) {
                                return i.Id == row.Id;
                            });
                            _.each(e.response.SecondaryColumns, function (column) {
                                var value = self.getColumnValue(column, row);
                                gridColumnData["_" + column.Key.replace(self.keyRegExpression, "")] = value;
                            });

                            _.each(e.response.Columns, function (column) {
                                var value = self.getColumnValue(column, row);
                                if (column.DataFormat && column.DataType && (!(column.DataType == 4 || column.DataType == 5)))
                                    value = $.getFormattedValue(column.DataType, column.DataFormat, value);
                                if (uRow != undefined && uRow["_" + column.Key.replace(self.keyRegExpression, "")] != undefined)
                                    gridColumnData["_" + column.Key.replace(self.keyRegExpression, "")] = uRow["_" + column.Key.replace(self.keyRegExpression, "")];
                                else
                                    gridColumnData["_" + column.Key.replace(self.keyRegExpression, "")] = value;
                            });
                            var tbItem = $.grep(self.selectedUsers, function (i) {
                                return i.UserId == row.Id;
                            });
                            if (tbItem.length > 0 && tbItem[0].IsTargeted)
                                gridColumnData["IsTargeted"] = true;
                            else
                                gridColumnData["IsTargeted"] = false;
                            self.gridRows.push(gridColumnData);
                        });
                        self.gridDataSource._total = e.response.TotalCounts;
                        $("#totalUsersCount", self.domNode).html(e.response.TotalCounts);
                    }
                    else {
                        self.gridColumnDefinitions.length = 0;
                        gridRows.length = 0;
                        self.gridColumnDefinitions.push({
                            title: '',
                            field: '',
                            template: $("#userList-chkTargeted-template").html(),
                            headerTemplate: kendo.format('<input name="chbox" id="UsersCheckAll" value="0" type="checkbox" title="' + self.resourceStrings.IUTAllUsers_SelectAll_DeSelect + '" data-type="selectAll" />', ""),
                            width: 5,
                        });
                        self.gridColumnDefinitions.push({
                            title: 'Username',
                            field: '',
                            width: 80,
                        });
                        self.gridColumnDefinitions.push({
                            title: self.resourceStrings.IUTAllUsers_Add_Reset,
                            field: "",
                            width: "10px",
                            template: $("#userList-BlockUnblock-template").html(),
                            headerTemplate: '<a href="#" class="small-msg block column-select" id="addReportColumn" title="' + self.resourceStrings.IUTAllUsers_Add + '"  >' + self.resourceStrings.IUTAllUsers_Add + '</a><a href="#" class="small-msg block" id="reset" title="' + self.resourceStrings.IUTAllUsers_Reset + '" >' + self.resourceStrings.IUTAllUsers_Reset + '</a>'
                        });
                    }
                    // Page info of kendo grid
                    $("#allUserPageInfo", self.domNode).kendoPager({
                        dataSource: self.gridDataSource,
                        autoBind: false,
                        numeric: false,
                        previousNext: false,
                        messages: {
                            display: self.resourceStrings.IUTAllUsers_PagingInfo,
                            empty: self.resourceStrings.IUTReadOnly_Emptyrow_Message
                        }
                    });
                    userGridDom = $("#userGrid", self.domNode);

                    // Allusers kendo grid
                    userGridDom.find(".k-grid-header").html('');
                    userGridDom.find(".bootstrap-select").remove();
                    ko.cleanNode($(userGridDom).get(0));
                    self.allUsersgrid = userGridDom.kendoGrid({
                        columns: self.gridColumnDefinitions,
                        dataSource: self.gridRows,
                        selectable: false,
                        scrollable: true,
                        autoBind: true,
                        sortable: false,
                        pageable: {
                            refresh: true,
                            pageSizes: true,
                            pageSizes: [20, 50, 100],
                            buttonCount: 5,
                            messages: {
                                display: $.htmlDecode(self.resourceStrings.IUTAllUsers_PagingInfo),
                                empty: $.htmlDecode(self.resourceStrings.AtHoc_Pager_Message_Empty),
                                itemsPerPage: $.htmlDecode(self.resourceStrings.IUT_ItemsPerPage),
                                first: $.htmlDecode(self.resourceStrings.AtHoc_Pager_Message_Go_To_The_First_Page),
                                previous: $.htmlDecode(self.resourceStrings.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                                next: $.htmlDecode(self.resourceStrings.AtHoc_Pager_Message_Go_To_The_Next_Page),
                                last: $.htmlDecode(self.resourceStrings.AtHoc_Pager_Message_Go_To_The_Last_Page)
                            }
                        },
                        // editable:true,
                        dataBinding: function () { self.userListDataBinding(); },
                        dataBound: function () { self.userListDataBound(); },
                        change: function (e) {
                            var model = this.dataItem(this.select());
                            this.select().removeClass("k-state-selected");
                            self.userInfo.update({ userId: model.Id, userName: model._LOGIN_ID });
                            $("#userInfoHolder", self.userInfo.refDomNode).modal("show");
                        }

                    }).data().kendoGrid;

                    $("#newColumns").html('');
                    self.allUsersPageSize = self.gridDataSource._pageSize;
                    setTimeout(function () {
                        // Fit height for the alluer grid
                        self.fitHeightAllUsers();
                        //$.AjaxLoader.hideLoader();
                    }, 100);


                    if (onSuccess)
                        onSuccess();
                    $(self.srcRefNode).append($(self.domNode));

                    var captionElm = self.srcElement.find(".table-crown-caption .counter");
                    var search = self.srcElement.find(".filter-col-last").find(".btn-primary");
                    $(captionElm).find('.text-toggle.search-settings').attr("title", self.resourceStrings.PAEvent_Filter_Title)
                    if (!self.statusFlag)
                        $(captionElm).find('.text-toggle.search-settings').text(self.resourceStrings.PAEvent_AllUsers).append("<span style='margin-top:2px' class='caret'></span>");
                    $(search).html(self.resourceStrings.PAEvent_Search);
                    self.srcElement.find(".filter-col-last").find(".faux-link").html(self.resourceStrings.PAEvent_ClearAll);
                    self.srcElement.find(".filter-col-last").find(".faux-link").attr("title", self.resourceStrings.PAEvent_ClearAll);
                    self.srcElement.find(".lang-filter").find(".lang-filter-header").html(self.resourceStrings.PAEvent_NewColumn_Title);
                    self.srcElement.find(".totalUsersCount").html(self.totalUsers);
                    self.srcElement.find(".filter-search-input").attr("placeholder", self.resourceStrings.PAEvent_Search_PlacedHolder);
                    self.srcElement.find(".advanced-search-open").html(self.resourceStrings.PAEvent_Advanced_Search);
                    self.srcElement.find(".advanced-search-open").attr("title", self.resourceStrings.PAEvent_Advanced_Search);
                    self.srcElement.find("#dialogResetAllUsers").find(".modal-header h2").html(self.resourceStrings.PAEvent_ResetDialog_Title);
                    self.srcElement.find("#dialogResetAllUsers").find(".modal-body").html(self.resourceStrings.PAEvent_ResetDialog_Message);
                    self.srcElement.find("#dialogResetAllUsers").find(".modal-footer .btn-info").html(self.resourceStrings.PAEvent_Cancel);
                    self.srcElement.find("#dialogResetAllUsers").find(".modal-footer .btn-primary").html(self.resourceStrings.PAEvent_Ok);
                    self.srcElement.find(".chkClass").attr("title", self.resourceStrings.PAEvent_Select_Deselect);
                    self.srcElement.find("[name='usersCheckAll']").attr("title", self.resourceStrings.PAEvent_SelectAll_DeSelect);


                    $(".advanced-search-open", self.domNode).click(function () {
                        $(self.queryRefNode).athocEntitySelectorPopup('setPreselections', self.queryCriteriaSelections);
                        $(self.queryRefNode).athocEntitySelectorPopup('launchAndShow');
                    });
                    $(".select-group", self.domNode).click(function () {
                        $(self.qroupRefNode).athocEntitySelectorPopup('setPreselections', self.qroupsSelections);
                        $(self.qroupRefNode).athocEntitySelectorPopup('launchAndShow');
                    });

                    $("#usersCheckAll", self.domNode).click(function () {
                        self.allUsersSelectAll();
                    });
                    $("#addReportColumn", self.domNode).click(function () {
                        self.addNewGridColumn();
                    });
                    $("#reset", self.domNode).click(function () {
                        self.ResetGridList();
                    });


                    $(".remove-column", self.domNode).click(function (e) {
                        self.userListRemoveColumn(e);
                    });
                    $(".table-head-primary", self.domNode).click(function (e) {
                        self.allUserGridColumnSort(e);
                    });
                    $(".chkClass", self.domNode).click(function (e) {
                        self.Targeted(this);
                    });
                    $(".allUserListLink", self.domNode).click(function () {
                        self.getUserInfo(this);
                    });

                    $(".StatusLink", self.domNode).click(function () {

                        var id = this.getAttribute('value');
                        var name = this.getAttribute('title');
                        var comments = this.getAttribute('Comments');
                        self.selectedUsers = [];
                        var uAttribute = _.find(self.responseTypes, function (i) {
                            return i.ValueName == name;
                        });
                        self.responseId = uAttribute.ValueId;
                        self.selectedUsers.push({ UserId: id, Name: "", IsTargeted: false });
                        self.comments = comments;
                        self.userView.showDialog();
                    });


                    $("#filterTypes", self.domNode).click(function () {
                        $("#filterContextDropdown", self.domNode).show();
                    });
                    if (!self.statusFlag) {
                        self.populateStatusFilter(self.responseTypes, self.resourceStrings);
                        self.statusFlag = true;
                        self._renderQuickSearchFilter();
                    }

                },
                schema: {
                    data: "Rows",
                    total: "TotalCounts",
                },
                serverPaging: true,
                serverSorting: true,
                serverFiltering: true,
                sort: { field: "LOGIN_ID", dir: "desc" },
                pageSize: 50,
                error: function (e) {
                    var errorCallBack = function (returnedErrorObject) {
                        //    $('#listMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                    };
                    //AjaxUtility().athocKendoGridAjaxErrorHandler(e, errorCallBack);
                    //handleError(e);
                },
                change: function (e) {
                    self.retainSelectAll();
                }
            });
            self.gridDataSource._pageSize = this.allUsersPageSize;
            self.gridDataSource.read();
            return 0;
        },

        // Creating status filters
        populateStatusFilter: function (data, resourceStrings) {
            var html = "";
            html = "<div class='text-select text-select-checked'  data-settings-value=-1  tabindex='220' data-tab-index-seq='227' id=-1>" + resourceStrings.PAEvent_AllUsers + "</div>";
            if (data!=undefined && data.length > 0)
                html = html + "<div class='text-select'  data-settings-value=-1  tabindex='220' data-tab-index-seq='227' id=-2>" + resourceStrings.PAEvent_AllResponses + "</div>";
            
            _.each(data, function (item, index) {
                html = html + " <div class='text-select mar-left10'  tabindex='220' data-tab-index-seq='227' data-settings-value='" + item.ValueId + "' id='" + item.SortOrder + "'>" + $.htmlEncode(item.ValueName) + "</div>";
            });
            html = html + " <div class='text-select'  tabindex='220' data-tab-index-seq='227' data-settings-value=0 id=0>" + resourceStrings.PAEvent_NoStatus + "</div>";
            $("#rTypes", self.domNode).html(html);
        },

        // Databound event for the allusers grid
        userListDataBound: function (e) {
            // var uGrid = $("#userGrid", self.ph.domNode);
            var data = userGridDom.data("kendoGrid").dataSource.view();
            userGridDom.find(".k-grid-header").attr("style", "padding-right:17px!important");

            if (data.length > 0)
                userGridDom.find(".k-grid-header").css("width", $(this.srcElement).width() - 19);
            else
                userGridDom.find(".k-grid-header").attr("style", "width:100% !important");

            //self.allAvailableUser(data);

            var grid = userGridDom.data("kendoGrid");
            grid.pager.dataSource = this.gridDataSource;
            this.onBoundEmptyRow(data);
        },

        // Databinding event for the allusers grid
        userListDataBinding: function (e) {
            //var uGrid = $("#userGrid", self.ph.domNode);
            var ds = userGridDom.data("kendoGrid").dataSource;
            ds._sort = [{ field: this.allUserSortField, dir: this.allUserSortOrder }];
            userGridDom.find(".k-pager-refresh").remove();
        },

        //
        onBoundEmptyRow: function (data) {

            var colCount = userGridDom.find('.k-grid-header colgroup > col').length;
            if (data.length == 0) {
                $("#userGrid").find('.k-grid-content tbody')
                    .append('<tr class="kendo-data-row"><td colspan="' +
                        colCount +
                        '" style="text-align:center;height:10px;overflow:auto;">' +
                        kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', this.resourceStrings.IUTAllUsers_Emptyrow_Message, this.resourceStrings.IUTAllUsers_Emptyrow_Message) +
                        '</td></tr>');
            }
        },

        // Get user info for the compact popup
        getUserInfo: function (obj) {
            var self = this;
            var id = obj.getAttribute('value');
            var name = obj.getAttribute('title');
            self.userInfo.update({ userId: id, userName: name }, $('#userInfoModal').find('#showProgress'));
            $("#userInfoModal", self.userInfo.refDomNode).modal("show");
            $(self.srcRefNode).append('<div id="displayShadow" class="modal-backdrop fade in"></div>');
            $('#userInfoModal').on('hidden.bs.modal', function () {
                $(self.srcRefNode).find('#displayShadow').remove();
            });
        },

        //
        _renderQuickSearchFilter: function () {
            var self = this;
            var captionElm = $.find(".table-crown-caption .counter");
            self.selectedFilterValue = $(captionElm).find('.text-toggle.search-settings').text().trim();
            var closeSearchOnOtherUserEvent = function (e) {
                if (($('.search-setting-panel').has(e.target).length == 0) && ($(e.target).hasClass('search-settings') == false)) {
                    refreshSearchSettings();
                }
            };

            var refreshSearchSettings = function () {
                var panel = $(captionElm).find(".search-setting-panel");
                panel.toggle();
                //make panel invisible when user is clicking
                //other area or event
                var isPanelVisible = panel.is(":visible");
                if (isPanelVisible) {
                    $(document).off('click.refreshSearchSettings').on('click.refreshSearchSettings', function (e) {
                        closeSearchOnOtherUserEvent.bind(self);
                        closeSearchOnOtherUserEvent(e);
                    });
                    $(document).off('keyup.refreshSearchSettings').on('keyup.refreshSearchSettings', function (e) {
                        closeSearchOnOtherUserEvent.bind(self);
                        closeSearchOnOtherUserEvent(e);
                    });
                } else {
                    $(document).off('click.refreshSearchSettings');
                    $(document).off('keyup.refreshSearchSettings');
                }
            };

            $(captionElm).find(".search-settings").click(function (e) {
                refreshSearchSettings();
                e.stopPropagation();
            });

            $(captionElm).find('.text-select').click(function (event) {
                $(captionElm).find('.text-select').removeClass("text-select-checked");
                $(this).addClass('text-select-checked');
                self.selectedFilterValue = $(this).attr('id');
                $(captionElm).find('.text-toggle.search-settings').text($(this).text()).append("<span style='margin-top:2px' class='caret'></span>");
                refreshSearchSettings();
                self.filterType = $(this).attr('id');
                self.createGrid();
                event.stopPropagation();
            });
        },

        // Removing column from grid
        userListRemoveColumn: function (event) {
            event.preventDefault();
            var key = event.currentTarget.parentNode.getAttribute("Key");
            var cList = this.newlyaddedColumns.filter(function (i) {
                return i.Key != key;
            });
            this.newlyaddedColumns = cList;
            this.createGrid();
        },

        // Sorting of columns for allusers grid
        allUserGridColumnSort: function (event) {
            var self = this;
            self.allUserSortField = event.currentTarget.parentNode.getAttribute("data-field");
            self.allUserSortColumn = event.currentTarget.parentNode.getAttribute("key");
            if (self.allUserSortOrder == "desc")
                self.allUserSortOrder = "asc";
            else
                self.allUserSortOrder = "desc";
            self.createGrid();

        },

        // Select all event for the allusers grid
        allUsersSelectAll: function () {
            var self = this;
            var checked = $('#usersCheckAll', self.domNode).is(':checked');
            var grid = userGridDom.data().kendoGrid;
            $('.chkClass').prop('checked', checked);
            $.each(grid.dataSource.view(), function (i, item) {
                if (checked) {
                    item.IsTargeted = checked;
                }
                else
                    item.IsTargeted = false;
                self.updateSelectedUsers(item);
            });
            $(".chkClass", self.domNode).click(function (e) {
                self.Targeted(this);
            });

        },

        // Retain check all when the paging is done
        retainSelectAll: function () {

            var grid = userGridDom.data().kendoGrid;
            var items = grid.dataSource.view();
            var ttlCnt = 0;
            // Get the selected items for the current page.
            $.grep(items, function (v) {
                if (v.IsTargeted)
                    ttlCnt++;
            });

            // Check total page count equal to selected count 
            var checked = ttlCnt > 0 && (items.length == ttlCnt);
            $("#usersCheckAll").prop('checked', checked);
        },

        // Createing pills when search is done
        createPills: function (value, type, display) {
            var self = this;
            var found = _.find(self.searchString, function (item) {
                return (item.value == value && item.type == type);
            });
            if (!found) {
                self.searchString.push({ value: value, type: type, display: display });
                self.renderPills();
                self.createGrid();
            }
        },

        // Rendering the pills when search is done
        renderPills: function (css) {
            var self = this;
            var html = "";
            $("#divSearch .pill-container").html('');
            if (self.searchString && self.searchString.length > 0) {
                _.each(self.searchString, function (item, index) {
                    var prefix = "";
                    var pillLabel = prefix + $.htmlEncode(item.display);
                    var pillTooltip = prefix + $.htmlEncode(item.display);
                    var closeButton = (typeof (css) === 'undefined' ? '<a class="pill-close" href="#"></a>' : '');
                    html = '<div class="pill" data-index="' + index + '" title="' + pillTooltip + '"><span class="pill-content">' + pillLabel + '</span>' + closeButton + '</div>' + html;
                });

                var pillsElm = $("#divSearch .pill-container");
                pillsElm.html(html);
                //wire up events
                $("#divSearch .pill-close").click(function (event) {
                    var parentElm = $(this).parent(".pill");
                    self.deSelect(parentElm.data("index"));
                    event.stopPropagation();
                });
            }
        },

        // Deleteing the pills
        deSelect: function (index, onSuccess) {
            var self = this;
            if (self.searchString && self.searchString.length > index) {

                if (self.searchString[index].type == "HIERARCHY") {
                    $.each(self.hierarchyIds, function (i, value) {
                        if (value == self.searchString[index].value) {
                            self.hierarchyIds.splice(i, 1);
                            self.filterType = -1;
                            var captionElm = $.find(".table-crown-caption .counter");
                            $(captionElm).find('.text-select').removeClass("text-select-checked");
                            $(captionElm).find('.text-toggle.search-settings').text(self.resourceStrings.PAEvent_AllUsers).append("<span style='margin-top:2px' class='caret'></span>");
                            $("[id=" + self.filterType + "]").addClass('text-select-checked');
                            return i;
                        }
                    });
                }

                if (self.searchString[index].type == "LIST") {
                    $.each(self.listItemIds, function (i, value) {
                        if (value == self.searchString[index].value) {
                            self.listItemIds.splice(i, 1);
                            self.filterType = -1;
                            var captionElm = $.find(".table-crown-caption .counter");
                            $(captionElm).find('.text-select').removeClass("text-select-checked");
                            $(captionElm).find('.text-toggle.search-settings').text(self.resourceStrings.PAEvent_AllUsers).append("<span style='margin-top:2px' class='caret'></span>");
                            $("[id=" + self.filterType + "]").addClass('text-select-checked');
                            return i;
                        }
                    });
                }

                if (self.searchString[index].type == "ADVANCESEARCH") {
                    self.queryCriteria = "";
                    self.queryCriteriaSelections = [];
                }

                self.searchString.splice(index, 1);

                self.renderPills();
                self.createGrid();
            }
        },

        // Adjust height of the grid.
        fitHeightAllUsers: function () {
            var self = this;
            var extraSpace = 0;
            if ($("#pillContainer", self.domNode).children().length == 0)
                $("#pillContainer", self.domNode).hide();
            else {
                $("#pillContainer", self.domNode).show();
                extraSpace = 35;
            }
            $("#userGrid .k-grid-content", self.domNode).attr("style", "overflow:scroll!important");
            var windowHeight = $(self.srcElement).height() - $("#divAllUsers", self.domNode).height() - 70;
            if (windowHeight > 700) {
                $("#userGrid .k-grid-content", self.domNode).css("height", (windowHeight * 95 / 100) - extraSpace);
            }
            else if (windowHeight > 400) {
                $("#userGrid .k-grid-content", self.domNode).css("height", (windowHeight * 93 / 100) - extraSpace);
            }
            else if (windowHeight < 0) {
                $("#userGrid .k-grid-content", self.domNode).css("height", "auto");
            }

            $('#userGrid', self.domNode).show();

        },

        // Get column value from datasource.
        getColumnValue: function (column, row) {
            if (column.Key == "OPERATOR-ROLES") {
                var roleCount = row.UserAttributes["ROLECOUNT_OTHERORGS"];
                if (roleCount && roleCount != " ") {
                    return row.UserAttributes[column.Key] + " (" + row.UserAttributes["ROLECOUNT_OTHERORGS"] + ") ";
                } else {
                    return row.UserAttributes[column.Key];
                }
            }
            return column.CustomViewColumnType === "CF"
                ? row.UserAttributes[column.Key]
                : row.UserDevice[column.Key];
        },

        // For Add/Block user Update grid columns in a grid
        updateGridColumn: function (viewId, id, action, columnType, columnKey, onSuccess) {
            var self = this;
            if (id) {
                if (action == "remove" && self.allUserSortColumn == columnKey) {
                    self.allUserSortColumn = "LOGIN_ID";
                    self.allUserSortOrder = "ASC";
                }
                var myAjaxOptions = {
                    url: options.saveCustomViewUrl,
                    type: "POST",
                    dataType: "json",
                    data: { viewId: viewId, id: id, action: action, type: columnType, commonName: columnKey },
                    success: function (data) {
                        createGrid(undefined, onSuccess, undefined, undefined, false);
                    }
                };
                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);

                $.ajax(ajaxOptions);
            }
        },

        // Check event of checkbox in all user grid
        Targeted: function (obj) {
            var userId = obj.getAttribute("value");
            var grid = userGridDom.data().kendoGrid;
            var items = grid.dataSource.view();

            var item = _.find(items, function (i) {
                return i.Id == userId;
            });

            if (item != null) {
                item.IsTargeted = obj.checked;
                this.updateSelectedUsers(item);
                this.retainSelectAll();

            }
        },

        // Adding new column to the grid. 
        addNewGridColumn: function () {
            var self = this;
            var parameters = {
                viewType: "UserManager",
            };
            var myAjaxOptions = {
                url: self.Urls.GetCustomViewsUrl,
                type: "POST",
                dataType: "json",
                data: parameters,
                success: function (data) {
                    if (data && data.length > 0) {
                        $("#newColumns").html('');
                        var htmlAttributes = '';
                        var deviceOptions = '';
                        var operatorOptions = '';
                        var hierarchyOptions = '';
                        var hierarchyGroup = '', attributeGroup = '', deviceGroup = '', operatorAttributeGroup = '';
                        var html = "";
                        html += '<select  name="addColumnDropdown"  data-placeholder="" size=10  style="width:235px !important;margin-left:5px !important">';
                        _.each(data, function (item, index) {
                            //var existColCount = self.newlyaddedColumns.filter(function (i) {
                            //    return (i.Key == item.Key);
                            //}).length;
                            var fieldKey = "_" + item.Key.replace(self.keyRegExpression, "");
                            var existColCount = self.gridColumnDefinitions.filter(function (i) {
                                return (i.field == fieldKey);
                            }).length;
                            if (existColCount == 0) {
                                var optionList = "<option value='" + item.Id + "' data-customviewcolumntype='" + item.CustomViewColumnType + "' data-key='" + item.Key + "'>" + $.htmlEncode(item.DisplayName) + "</option>";

                                if (item.CustomViewColumnType == "CF" && item.IsHierarchy == false && item.Key == $.htmlDecode("OPERATOR-ROLES")) {
                                    operatorOptions = operatorOptions + optionList;
                                }
                                else if (item.CustomViewColumnType == "CF" && item.IsHierarchy == false && item.Key != $.htmlDecode("LOGIN_ID")) {
                                    htmlAttributes = htmlAttributes + optionList;
                                }
                                else if (item.CustomViewColumnType == "CF" && item.IsHierarchy == true) {
                                    hierarchyOptions = hierarchyOptions + optionList;
                                }
                                else if (item.CustomViewColumnType == "Device") {
                                    deviceOptions = deviceOptions + optionList;
                                }
                            }
                        });
                        if (hierarchyOptions != '') {
                            hierarchyGroup = '<optgroup label="Organization Hierarchy">' + hierarchyOptions + '</optgroup>';
                        }

                        if (htmlAttributes != '')
                            attributeGroup = '<optgroup label="Attributes">' + htmlAttributes + '</optgroup>';

                        if (deviceOptions != '')
                            deviceGroup = '<optgroup label="Devices">' + deviceOptions + '</optgroup>';

                        if (operatorOptions != '')
                            operatorAttributeGroup = '<optgroup label="' + $.htmlDecode("Operator Attributes") + '">' + operatorOptions + '</optgroup>';

                        html = html + hierarchyGroup + attributeGroup + operatorAttributeGroup + deviceGroup;
                        html += '</select>';
                        $("#newColumns").html(html);

                        var selectElm = $("select[name='addColumnDropdown']");

                        selectElm.change(function () {
                            var elm = $(this);
                            var displayName = "";

                            if (elm.find("option:selected").data("customviewcolumntype") == "Device")
                                displayName = elm.find("option:selected").html().replace(/\(Device\)?$/, "").trim();
                            else
                                displayName = elm.find("option:selected").html();

                            self.newlyaddedColumns.push({ Id: elm.val(), Key: elm.find("option:selected").data("key"), CustomViewColumnType: elm.find("option:selected").data("customviewcolumntype"), DisplayName: displayName });
                            self.createGrid();

                        });
                        $("#contextDropdown").show();

                        $("#contextDropdown").position({
                            my: "right+55 top+15",
                            at: "center",
                            of: "#addReportColumn"
                        });
                    }
                }
            };

            var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);
            $.ajax(ajaxOptions);
            //}
        },

        // Reset confirmation popup
        ResetGridList: function () {
            var self = this;
            $(self.srcRefNode).append('<div id="displayShadow" class="modal-backdrop fade in"></div>');
            $("#dialogResetAllUsers").show();
            $("#dialogResetAllUsers").on('click', '.btn-info', function (event) {
                $("#dialogResetAllUsers").hide();
                $(self.srcRefNode).find('#displayShadow').remove();
            });
        },
        // For Add/Block user Update grid columns in a grid
        updateGridColumn: function (viewId, id, action, columnType, columnKey, onSuccess) {
            var self = this;
            if (id) {
                //$.AjaxLoader.setup({ useBlock: true, idToShow: self._id + '-pageAjaxLoader', elementToBlock: $('.table-header'), imageURL: self.options.cdnUrl + '/Images/ajax-loader.gif' }).showLoader();
                if (action == "remove" && self.allUserSortColumn == columnKey) {
                    self.allUserSortColumn = "LOGIN_ID";
                    self.allUserSortOrder = "ASC";
                }
                var myAjaxOptions = {
                    url: self.Urls.SaveCustomViewUrl,
                    type: "POST",
                    dataType: "json",
                    data: { viewId: viewId, id: id, action: action, type: columnType, commonName: columnKey },
                    success: function (data) {
                        self.createGrid(undefined, onSuccess, undefined, undefined, false);
                    }
                };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);

                $.ajax(ajaxOptions);
            }
        },

        // Removing all added new columns
        resetGridListOk: function () {
            var self = this;
            $("#dialogResetAllUsers").hide();
            $(self.srcRefNode).find('#displayShadow').remove();
            self.newlyaddedColumns.length = 0;
            self.createGrid();
        },

        // Clear all updated data and reset the grid
        clearAll: function () {
            var self = this;
            $("#pillContainer").html("");
            $("#txtAllUserSearch").val('');
            self.allUserSortColumn = "LOGIN_ID";
            self.allUserSortField = "_LOGIN_ID";
            self.allUserSortOrder = "asc";
            self.allUsersPageSize = 50;
            self.searchString.length = 0;
            self.filterType = -1;
            self.hierarchyId = -1;
            var captionElm = $.find(".table-crown-caption .counter");
            $(captionElm).find('.text-select').removeClass("text-select-checked");
            $(captionElm).find('.text-toggle.search-settings').text(self.resourceStrings.PAEvent_AllUsers).append("<span style='margin-top:2px' class='caret'></span>");
            $("[id=-1]").addClass('text-select-checked');
            self.selectedUsers.length = 0;
            self.queryCriteria = "";
            self.queryCriteriaSelections = [];
            self.hierarchyIds = [];
            self.listItemIds = [];
            self.newlyaddedColumns = [];
            self.createGrid();
           

        },

        // Collecting the selected users.
        updateSelectedUsers: function (obj) {
            var displayName = '';
            var idx = 0;
            var item = _.find(this.selectedUsers, function (i, index) {
                idx = index;
                return obj.Id == i.UserId;
            });
            if (item == null) {
                if (obj.IsTargeted) {
                    if (obj._DISPLAYNAME != null && $.trim(obj._DISPLAYNAME) != '' && $.trim(obj._DISPLAYNAME) != 'N/A')
                        displayName = obj._DISPLAYNAME;
                    else if ((obj._FIRSTNAME != null && $.trim(obj._FIRSTNAME) != '') || (obj._LASTNAME != null && $.trim(obj._LASTNAME) != ''))
                        displayName = $.trim(obj._FIRSTNAME + ' ' + obj._LASTNAME);
                    else
                        displayName = obj._LOGIN_ID;

                    this.selectedUsers.push({ UserId: obj.Id, Name: displayName, IsTargeted: obj.IsTargeted });
                }
            }
            else if (!obj.IsTargeted) {
                this.selectedUsers.splice(idx, 1);//function (i) { return i.UserId == obj.Id });                                 
            }
            this.userView.onUserSelectionChange(this.selectedUsers.length);
        },

        // Filter the users grid based on other tab selections.
        changeStatus: function (filter) {
            var self = this;
            var filterText = "";
            self.hierarchyIds = [];
            self.listItemIds = [];
            self.searchString.length = 0;
            self.queryCriteria = "";
            self.queryCriteriaSelections = [];
            self.selectedUsers = [];
            self.newlyaddedColumns = [];
            $("#txtAllUserSearch").val('');
            self.allUserSortColumn = "LOGIN_ID";
            self.allUserSortField = "_LOGIN_ID";
            self.allUserSortOrder = "asc";
            self.allUsersPageSize = 50;
            self.se
            if (filter.status != undefined) {
                var filterType = parseInt(filter.status);
                var uAttribute = _.find(self.responseTypes, function (i) {
                    return i.SortOrder == filterType;
                });
                if (uAttribute != null) {
                    self.filterType = uAttribute.SortOrder;
                    filterText = uAttribute.ValueName;
                }
            }

            if (filterText == "") {
                switch (parseInt(filter.status)) {
                    case 0:
                        filterText = self.resourceStrings.PAEvent_NoStatus;
                        self.filterType = 0;
                        break;
                    default:
                        filterText = self.resourceStrings.PAEvent_AllUsers;
                        self.filterType = -1;
                        break;
                }
            }

            if (filter.hierarchyId != null) {
                self.hierarchyIds.push(filter.hierarchyId);
                self.createPills(filter.hierarchyId, "HIERARCHY", filter.pillText);
            }

            if (filter.listItemId != null) {
                self.listItemIds.push(filter.listItemId);
                self.createPills(filter.listItemId, "LIST", filter.pillText);
            }
            //Below condition is added to show the pills when it is clicked from the summary tab.
            if (filter.listItemId == null && filter.hierarchyId == null) {
                self.renderPills();
                self.createGrid();
            }
            var captionElm = $.find(".table-crown-caption .counter");
            $(captionElm).find('.text-select').removeClass("text-select-checked");
            $(captionElm).find('.text-toggle.search-settings').text(filterText).append("<span style='margin-top:2px' class='caret'></span>");
            $("[id=" + self.filterType + "]").addClass('text-select-checked');

        },

        //
        destroy: function () {
            this.inherited(arguments);
        }

    });

    return userList;

});