﻿define([
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/array",
"dijit/_WidgetBase",
"dijit/_TemplatedMixin",
"dojo/Evented",
"dojo/dom-style",
"dojo/on",
"dojo/query",
"dojo/text!publishing/UserList/UserListTemplate.html"
],
function (declare, lang, array, widgetBase, templatedMixin, evented, domStyle, on, query, template) {
    var userList = declare("athoc.iws.publishing.UserList", [widgetBase, templatedMixin, evented], {
        templateString: template,
        userGridDom: null,
        //
        constructor: function (options, iUserInfo, iUserView) {
            var self = this;
            self.srcElement = options.srcRefNode;
            self.gridColumnDefinitions = [];
            self.gridRows = [];
            self.searchString = [];
            self.allUserSortColumn = 'DisplayName';
            self.allUserSortOrder = 'asc';
            self.allUsersPageSize = 50;
            self.allUserSortField = 'DisplayName';
            self.allUsersgrid = '';
            self.userPageLayout = options.userPageLayout;
            self.divProgress = '';
            self.keyRegExpression = /[-:~!@#$%^&*(){}\[\]<>,.€\s'\"?\\\\/]/g;
            self.userListResourceStrings = options.resourceStrings;
            self.defaultColumnWidth = '120px';
            self.allAvailableUser = [];
            self.Urls = options.Urls;
            self.width = options.width;
            self.height = options.height;
            self.gridDataSource = [];
            self.selectedUsers = [];
            self.iUserInfo = iUserInfo;
            self.userInfo = null;
            self.userView = iUserView;
            self.updatedRows = [];
            self.eventIds = options.eventIds;
            self.responseTypes = [];
            self.newlyaddedColumns = [];
            self.filterType = -1;
            self.statusFlag = false;
            self.hierarchyIds = [];
            self.listItemIds = [];
            self.providerId = 0;
            self.responseId = "";
            self.comments = "";
            self.eventStatus = options.eventStatus;
            self.isAllowedToUpdateStatus = options.isAllowedToUpdateStatus;
            self.queryCriteria = "";
            self.queryCriteriaSelections = [];
            self.qroupsSelections = [];
            self.groupRefNode = options.groupRefNode;
            self.queryRefNode = options.queryRefNode;
            self.staticQueryCriteria = "",
            self.attributeValueIds = [];
            self.attributeIds = [];
            self.isGroupEnabled = options.isGroupEnabled;
            self.isAdvanceSearchEnabled = options.isAdvanceSearchEnabled;
            self.extraCommonNames = "";
            self.userSearchSpec = {};
            self.isModal = options.isModal || false;
            self.deepLink = false;
            self.currentPage = 1;
            self.userSearchSessionId = 0;
        },

        // To initiate component
        startUp: function () {
            var self = this;
            if (self.userInfo == null && self.userView.refDomNode.find("#userCompactPopup").length != 0) {
                self.userInfo = new self.iUserInfo(self.userView.refDomNode.find("#userCompactPopup"), "#userInfoModalBody");
                self.userInfo.startup();

                $(self.hierarchyRefNode).athocEntitySelectorPopup({
                    i18n: self.userListResourceStrings,
                    title: self.userListResourceStrings.User_Criteria_Builder_Select_Hierarchy,
                    isHierarchySelector: true,
                    showSummary: true,
                    cdnUrl: this.Urls.cdnUrl,
                    startTabIndex: 10000,
                    onApplyClick: function (selections) {
                        this.refDomNode.find(self.queryRefNode).find("#groupSelectorContent").modal("show");
                    },
                    applyPreselectionViaLineage: true,
                    hierarchyContext: 'OrgHierarchy'
                });
            }
            if (self.isAdvanceSearchEnabled) {
                $(self.queryRefNode).athocEntitySelectorPopup({
                    i18n: self.userListResourceStrings,
                    title: self.userListResourceStrings.AtHoc_User_Search_Create_Conditions,
                    cdnUrl: this.Urls.cdnUrl,
                    startTabIndex: 10000,
                    dateFormat: $.vpsDateFormat,
                    dateTimeFormat: $.vpsDateTimeFormat,
                    utcOffsetInMinutes: $.vpsTimeZone.UtcOffsetInMinutes,
                    vpsOffsetFromSystemInMinutes: $.vpsTimeZone.VPSOffsetFromSystemInMinutes,
                    widgetName: "athocQueryBuilder",
                    hideGeolocation: true,
                    hierarchySelectorTagId: "hierarchy-selector-popup-container",
                    onApplyClick: function (selections) {
                        self.renderAdvanceSearchpills(selections, false);
                    }
                });
            }

            if (self.isGroupEnabled) {
                $(self.groupRefNode).athocEntitySelectorPopup({
                    i18n: self.userListResourceStrings,
                    title: self.userListResourceStrings.PA_Event_Details_Select_Groups,
                    cdnUrl: this.Urls.cdnUrl,
                    startTabIndex: 1000,
                    selectorToClickToLaunch: ".btn-groups",
                    showSummary: true,
                    removeEmptyFolder: true,
                    onApplyClick: function (selections) {
                        self.renderAdvanceSearchpills(selections, true);
                    }
                });
            }



            $("[type=radio][name='filterusers']", this.domNode).click(function (e) {

                if (this.value == "All") {
                    var data = [];
                    _.each(self.gridRows, function (item, index) {
                        var obj = self.selectedUsers.filter(function (i) { return item.Id == i.UserId });
                        if (obj.length > 0)
                            item.IsTargeted = true;
                        else
                            item.IsTargeted = false;
                        data.push(item);
                    });

                    var dataSource = new kendo.data.DataSource({
                        data: data,
                    });
                    userGridDom.data("kendoGrid").setDataSource(dataSource);
                }
                else {
                    var data = userGridDom.data("kendoGrid").dataSource.data();
                    var selected = $.grep(data, function (item) {
                        return item.IsTargeted;
                    });
                    var selectedList = new kendo.data.DataSource({
                        data: selected,
                    });
                    userGridDom.data("kendoGrid").setDataSource(selectedList);
                }

                $(".chkClass", self.domNode).click(function (e) {
                    self.Targeted(this);
                });
                self.retainSelectAll();

            });

            self.inherited(arguments);
            self.showFilters();
            //self.createGrid();
            $('.ClearAll').attr("disabled", "disabled");
            $('.Search').attr("disabled", "disabled");

        },
        update: function () {
            this.currentPage = 1;
            this.createGrid();
        },

        showFilters: function () {
            var self = this;;
            if (self.userPageLayout != "FromUserManager") {
                $(".btn-groups", this.domNode).removeClass("hide");
                $(".advanced-search-open", this.domNode).removeClass('hide');
                $(".table-crown-search .filter-element", this.domNode).removeClass("hide");
            }
            else {
                $(".table-crown-search .allUserPageInfo", this.domNode).removeClass("hide");
                //$(".table-crown-search .search-filters-checkboxes", this.domNode).removeClass("hide");
            }

        },

        //Render Avanced Serach Pills
        renderAdvanceSearchpills: function (selections, isGroup) {
            var self = this;
            if (selections["selections"].length > 0) {

                $('.ClearAll').removeAttr("disabled");
                if (isGroup) {
                    var pillsArray = [{}];
                    self.hierarchyIds = []; self.attributeValueIds = [];
                    self.listItemIds = []; self.attributeIds = [];
                    var filteredSearch = $.grep(self.searchString, function (item) {
                        return item.type != "LISTITEM" && item.type != "HIERARCHYITEM" && item.type != "ATTRIBUTE" && item.type != "ATTRIBUTEVALUE" && item.type != "HIERARCHY";
                    });
                    self.searchString = filteredSearch; //Search string cont
                    self.renderPills();
                    self.qroupsSelections = selections.selections;
                    selections["selections"].forEach(function (selecteditem) {
                        if (selecteditem.type == "HIERARCHYITEM" || selecteditem.type == "LISTITEM")
                            self.listItemIds.push(selecteditem.value);
                        else if (selecteditem.type == "ATTRIBUTE")
                            self.attributeIds.push(selecteditem.value);
                        else if (selecteditem.type == "ATTRIBUTEVALUE")
                            self.attributeValueIds.push(selecteditem.value);
                        else
                            self.hierarchyIds.push(selecteditem.value);

                        var iconCss = "";
                        var prefix = "";
                        var pillsJsonObject = {};

                        var pillLabel = prefix + $.customizedHtmlEncoding(selecteditem.display);
                        var pillTooltip = prefix + $.customizedHtmlEncoding(selecteditem.display);


                        if (selecteditem.type == "SIMPLESEARCH") {
                            prefix = self.resourceStrings.AtHoc_User_Search_NameContains;
                        }
                        else if (selecteditem.type == "HIERARCHYITEM") {
                            if (typeof selecteditem.lineageForDisplay != "undefined") {
                                pillTooltip = $.customizedHtmlEncoding(selecteditem.lineageForDisplay);
                            }
                        }

                        if (selecteditem.type == "QUERYBYATTRIBUTE") {
                            pillLabel = selecteditem.display.join(self.resourceStrings.AtHoc_User_Search_Pill_Display_Connector);
                            pillTooltip = selecteditem.display.join(self.resourceStrings.AtHoc_User_Search_Pill_Display_Connector);
                            var regex = new RegExp("(<span class='bold'>)", 'g');
                            pillTooltip = pillTooltip.replace(regex, "");
                            regex = new RegExp("(</span>)", 'g');
                            pillTooltip = pillTooltip.replace(regex, "");
                        }

                        //code implementation to group the pills
                        pillsJsonObject.ToolTip = pillTooltip;
                        pillsJsonObject.NodeName = pillLabel;
                        pillsJsonObject.Index = index;
                        //pillsJsonObject.Close = $.tabIndex.attr(self.options.startTabIndex, 10, 9);
                        pillsJsonObject.Value = selecteditem.value;
                        pillsJsonObject.Type = selecteditem.type;

                        var key = self.getNodeKey(selecteditem);
                        var filterList = pillsArray.filter(function (pill) {
                            return pill.Key === key && pill.Key;
                        });
                        if (filterList.length == 0) {
                            var pillsList = [{}];
                            pillsList.push(pillsJsonObject);
                            pillsArray.push({ "Key": key, "PillValueList": pillsList });
                        }
                        else {
                            filterList[0].PillValueList.push(pillsJsonObject);
                        }


                        /* var found = _.find(self.searchString, function (item) {
                             return (item.value == selecteditem.value && item.type == selecteditem.type);
                         });
                         if (!found) {
                             self.searchString.push({ value: selecteditem.value, type: selecteditem.type, display: selecteditem.display });
                             self.renderPills();
                         }*/
                        });

                    $.each(pillsArray, function (index, item) {
                        if (index > 0) {

                            var toolTip = "";
                            var nodeName = "";
                            var index = "";
                            var close = "";
                            var value = [];
                            var type = '';
                            $.each(item.PillValueList, function (keyIndex, val) {
                                if (keyIndex > 0) {

                                    if (nodeName.length > 0) {
                                        nodeName += " " + self.resourceStrings.AtHoc_User_Search_or + " ";
                                        toolTip += " " + self.resourceStrings.AtHoc_User_Search_or + " ";
                                        index += ",";
                                    }
                                    nodeName += val.NodeName;
                                    toolTip += val.ToolTip;
                                    index += val.Index;
                                    close = val.Close;
                                    type = val.Type;
                                    value.push(val.Value);
                                }
                            });
                            self.searchString.push({ value: value, type: type, display: nodeName });
                            self.renderPills();
                            //var closeButton = (typeof (css) === 'undefined' ? '<a class="pill-close" href="javascript://"' + close + '></a>' : '');
                            //html = '<div class="pill" data-index="' + index + '" title="' + toolTip + '"><span class="pill-content">' + nodeName + '</span>' + closeButton + '</div>' + html;
                        }
                    });
                    self.currentPage = 1;
                    self.createGrid();
                }
                else {
                    var index = 0;
                    var query = "";
                    self.queryCriteriaSelections = selections.selections;
                    self.queryCriteriaDisplay = selections.display;
                    var queryCriteria = [];
                    self.queryCriteriaSelections.forEach(function (selecteditem) {
                        var selectedValues = [];
                        queryCriteria.push(selecteditem);
                        if (selecteditem.value.length > 0) {
                            selecteditem.value.forEach(function (selectedvalue) {
                                selectedValues.push(selectedvalue.text);
                            });
                        }
                        else
                            selectedValues.push(selecteditem.value);

                        if (selecteditem.entity.dataType == "DateTime" || selecteditem.entity.dataType == "Date") {
                            if (query != "") {
                                var displayData = "";

                                displayData = (selecteditem.operandName == "is empty" || selecteditem.operandName == "is not empty") ? ($(self.queryCriteriaDisplay[index]).text() + ' ' + selecteditem.operandName) : $(self.queryCriteriaDisplay[index]).text();

                                query = query + self.resourceStrings.AtHoc_User_Search_Pill_Display_Connector + displayData;
                            }
                            else

                                query = (selecteditem.operandName == "is empty" || selecteditem.operandName == "is not empty") ? ($(self.queryCriteriaDisplay[index]).text() + ' ' + selecteditem.operandName) : $(self.queryCriteriaDisplay[index]).text();
                        }
                        else {
                            if (query != "")
                                query = query + self.resourceStrings.AtHoc_User_Search_Pill_Display_Connector + selecteditem.entity.name + " " + selecteditem.operandName + " " + (selectedValues.length > 1 ? selectedValues.join(" " + self.resourceStrings.AtHoc_User_Search_or + " ") : selectedValues.toString());
                            else
                                query = selecteditem.entity.name + " " + selecteditem.operandName + " " + (selectedValues.length > 1 ? selectedValues.join(" " + self.resourceStrings.AtHoc_User_Search_or + " ") : selectedValues.toString());
                        }
                        index++;
                    });
                    self.queryCriteria = "";
                    self.queryCriteria = JSON.stringify(queryCriteria);
                    var found = _.find(self.searchString, function (item, i) {
                        if (item.value == "" && item.type == "ADVANCESEARCH")
                            self.searchString.splice(i, 1);
                    });
                    self.createPills("", "ADVANCESEARCH", query);
                }
            }
            else {
                if (isGroup) {
                    var filteredSearch = $.grep(self.searchString, function (item) {
                        return item.type != "HIERARCHY" && item.type != "ATTRIBUTE" && item.type != "ATTRIBUTEVALUE" && item.type != "LISTITEM" && item.type != "HIERARCHYITEM";
                    });
                    self.searchString = filteredSearch;
                    self.renderPills();
                    /*
                    var deletedSelection = selections["deleted"];
                    selections["deleted"].forEach(function (deleteditem) {
                        var found = _.find(self.searchString, function (item, i) {
                            if (item.value == deleteditem.value) {
                                self.searchString.splice(i, 1);
                                self.renderPills();
                            }
                        });
                    });*/
                }
                else {

                    var filteredSearch = $.grep(self.searchString, function (item) {
                        return item.type != "ADVANCESEARCH";
                    });
                    self.searchString = filteredSearch;
                    self.renderPills();
                }

                self.currentPage = 1;
                self.createGrid();
                self.queryCriteriaSelections = []; self.qroupsSelections = [];
                self.hierarchyIds = []; self.attributeValueIds = [];
                self.listItemIds = []; self.attributeIds = [];
            }
        },
        getNodeKey: function (item) {
            switch (item.nodeType) {
                case 1://CustomAttribute: concattinated item value to diff. the each individual custom attribute
                    return item.nodeType + ("-").concat(item.value);
                    break;
                case 2://CustomAttributeValue: concattinated item attributeId to group the custom attribute values
                    return item.nodeType + ("-").concat(item.attributeId);
                    break;
                case 3://Root
                    return item.value;
                    break;
                case 4://Folder 
                case 5://DistributionList
                    return item.nodeSubType == 0 ? item.nodeType : 5;
                    break;
                default:
                    return "0";

            }
        },
        resetSearchString: function () {
            var self = this;
            self.searchString = [];
            self.renderPills();
            self.currentPage = 1;
            self.createGrid();
        },
        // Get all users data and bind to kendo grid
        createGrid: function (getNextPage, onSuccess, searchParameters, page, showSpinner) {
            var self = this;
            var strSearch = [];
            var cNames = '';
            var displayIds = '';
            gridRows = [];

            $.grep(this.searchString, function (i) {
                if (i.type == "SIMPLESEARCH")
                    strSearch.push(i.value);
            });

            var obj = [];
            _.each(self.newlyaddedColumns, function (item, index) {
                cNames = cNames + item.Key + ",";
            });
            self.extraCommonNames = cNames;

            if (strSearch.length > 0 || self.hierarchyIds.length > 0 || self.listItemIds.length > 0)
                $('.ClearAll').removeAttr("disabled");

            var parameters = {
                SelectedColumns: obj,
                SearchStrings: strSearch,
                SortBy: this.allUserSortColumn,
                SortOrder: this.allUserSortOrder,
                pageSize: this.allUsersPageSize,
                SearchFlow: this.userPageLayout,
                EventIds: this.eventIds,
                AttributeCSV: cNames,
                DisplayColumnDeviceIds: displayIds,
                ResponseType: self.filterType,
                HierarchyIds: self.hierarchyIds,
                ListItemIds: self.listItemIds,
                QueryCriteria: self.queryCriteria,
                StaticQueryCriteria: self.staticQueryCriteria,
                AttributeValueIds: self.attributeValueIds,
                AttributeIds: self.attributeIds,
                ProviderId: self.providerId,
                isRoleBasedUsers: true,
                page: self.currentPage,
                userSearchSessionId: self.userSearchSessionId
            };
            this.gridColumnDefinitions = [];
            self.gridDataSource = new kendo.data.DataSource({
                transport: {
                    read: {
                        url: this.Urls.GetEventUserListUrl,
                        type: "POST",
                        dataType: "json",
                        data: parameters,
                        traditional: true,
                    },
                },
                requestStart: function (e) {
                    //$.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: self.srcElement.find("#divProgress"), imageURL: '/athoc-cdn//Images/ajax-loader.gif', top: '150px', left: '65%', zIndex: 2000 }).showLoader();

                    //$(divProgress).find('.blockMsg').css("margin", "-13px");
                    //$(divProgress).find('.blockMsg').css("left", "40px");
                },
                requestEnd: function (e) {

                    if (e.response != null) {
                        $(self.srcRefNode).append($(self.domNode));

                        self.gridColumnDefinitions.length = 0;
                        // Add checkbox column to the column array
                        self.gridColumnDefinitions.push({
                            title: '',
                            field: '',
                            template: self.srcElement.find(".userList-chkTargeted-template").html(),//kendo.format('<input name="chbox" id="allUserList-chbox-#= Id #" value="#= Id #" type="checkbox" data-type="checkbox" class="chkClass" title=' + self.userListResourceStrings.IUTAllUsers_Select_Deselect + ' onchange="self.ph.Targeted(this)" #=IsTargeted ? checked="checked" :"" #/>'),
                            headerTemplate: self.srcElement.find(".userList-chkAll-template").html(),//kendo.format('<input name="usersCheckAll" id="usersCheckAll" value="0" type="checkbox" title="' + self.userListResourceStrings.IUTAllUsers_SelectAll_DeSelect + '" data-type="selectAll" data-dojo-attach-event="ondijitclick:allUsersSelectAll" />', ""),
                            width: 34,
                        });

                        // column width based on column count
                        if (e.response.Columns.length < 7)
                            self.defaultColumnWidth = "auto";
                        else
                            self.defaultColumnWidth = "120px";
                        self.responseTypes = e.response.ResponseTypes;
                        self.userSearchSessionId = e.response.UserSearchSessionId;
                        // Add secondary columns to the column array 
                        /* _.each(e.response.SecondaryColumns, function (column, cIndex) {
                             var headerSecTemplate;
                             var dtemplate;
                             var fieldKey = "_" + column.Key.replace(self.keyRegExpression, "");
                             headerSecTemplate = '<span title="' + $.htmlEncode(column.DisplayName) + '" class="table-head-primary' + (column.IsSortable ? " table-head-sortable" : "") + '"data-key="' + column.Key + '" >' + $.htmlEncode(column.DisplayName);
 
                             if (self.allUserSortColumn.toUpperCase() == column.Key) {
                                 self.allUserSortField = fieldKey;
                                 if (self.allUserSortOrder.toUpperCase() == "ASC") {
                                     headerSecTemplate += '<span class="sort-indicator-ascending"></span></span>';
                                 }
                                 else if (self.allUserSortOrder.toUpperCase() == "DESC") {
                                     headerSecTemplate += '<span class="sort-indicator-descending"></span></span>';
                                 }
                             }
 
                             headerSecTemplate = kendo.format(headerSecTemplate);
                             if (self.gridColumnDefinitions.length == 1)
                                 dtemplate = '<a id="allUserListLink" value="#= Id #" class="allUserListLink" title=#=' + fieldKey + '# >#=_DISPLAYNAME#</a>';//$("#userList-link-template").html();
                             else
                                 dtemplate = '<span title="#=' + fieldKey + '#">#=' + fieldKey + '#</span>';
 
                             self.gridColumnDefinitions.push({
                                 title: column.DisplayName,
                                 field: fieldKey,
                                 width: self.defaultColumnWidth,
                                 template: dtemplate,
                                 headerTemplate: headerSecTemplate,
                                 headerAttributes: {
                                     viewid: column.ViewId,
                                     id: column.Id,
                                     customviewcolumntype: "",
                                     key: column.Key
                                 }
                             });
                         });*/
                        // Add coumns to column array
                        _.each(e.response.Columns, function (column, cIndex) {
                            var headerTemplate = "";
                            var fieldKey = "_" + column.Key.replace(self.keyRegExpression, "");
                            if (column.IsRequired != true) {
                                headerTemplate = '<div title="' + self.userListResourceStrings.Publishing_RemoveGridColumn + ' ' + $.htmlEncode(column.DisplayName) + '" class="icon_clear remove-column" ></div>' +
                                    '<span title="' + $.htmlEncode(column.DisplayName) + '" class="table-head-primary' + (column.IsSortable ? " table-head-sortable" : "") + '" data-key="' + column.Key + '" >' + $.htmlEncode(column.DisplayName);
                            }
                            else
                                headerTemplate = '<span title="' + $.htmlEncode(column.DisplayName) + '" class="table-head-primary' + (column.IsSortable ? " table-head-sortable" : "") + '"data-key="' + column.Key + '" >' + $.htmlEncode(column.DisplayName);

                            if (self.allUserSortColumn.toUpperCase() == column.Key.toUpperCase()) {
                                self.allUserSortField = fieldKey;
                                if (self.allUserSortOrder.toUpperCase() == "ASC") {
                                    headerTemplate += '<span class="sort-indicator-ascending"></span></span>';
                                }
                                else if (self.allUserSortOrder.toUpperCase() == "DESC") {
                                    headerTemplate += '<span class="sort-indicator-descending"></span></span>';
                                }
                            }
                            headerTemplate = kendo.format(headerTemplate);

                            var template = '<span title="#=' + fieldKey + '#">#=' + fieldKey + '#</span>';
                            if (fieldKey == "_DISPLAYNAME")
                                template = '<a id="allUserListLink" value="#= Id #" class="allUserListLink" title="#=' + fieldKey + '#" >#=' + fieldKey + '#</a>';
                            if (fieldKey == "_StatusId" && self.eventStatus == "Live" && self.isAllowedToUpdateStatus)
                                template = '<div class="float-left pa-event-statusTitle" title="#=' + fieldKey + '#" >#=' + fieldKey + '#</div><a><span style="float:right;height:20px"value="#= Id #" title="#=' + fieldKey + '#" comments ="#=_Comments#" class="StatusLink icon-edit-row"></span></a>';

                            self.gridColumnDefinitions.push({
                                title: column.DisplayName,
                                field: fieldKey,
                                width: self.defaultColumnWidth,
                                ///  editor: function (container,options) { self.getColumnValues(container,options);},
                                template: template,
                                headerTemplate: headerTemplate,
                                headerAttributes: {
                                    viewid: column.ViewId,
                                    id: column.Id,
                                    customviewcolumntype: "",
                                    key: column.Key,
                                    dataType: column.DataType
                                }
                            });
                        });

                        // Add add/reset column to column array
                        self.gridColumnDefinitions.push({
                            title: self.userListResourceStrings.IUTAllUsers_Add_Reset,
                            field: "",
                            width: "80px",
                            template: '',//"<a id='allUserList-UnBlock-#= Id #' value='#= Id #' onclick='unBlockUser('#=Id #');' title='UnBlock'>Unblock</a>",
                            headerTemplate: '<a href="#" class="small-msg block column-select addReportColumn" title="' + self.userListResourceStrings.IUTAllUsers_Add + '"  >' + self.userListResourceStrings.IUTAllUsers_Add + '</a><a href="#" class="small-msg block reset" title="' + self.userListResourceStrings.IUTAllUsers_Reset + '" >' + self.userListResourceStrings.IUTAllUsers_Reset + '</a>'
                        });

                        // Prepare datasource for kendo grid
                        self.gridRows.length = 0;
                        _.each(e.response.Rows, function (row, rIndex) {
                            var gridColumnData = new Object();
                            gridColumnData["Id"] = row.Id;
                            var uRow = _.find(self.updatedRows, function (i) {
                                return i.Id == row.Id;
                            });
                            _.each(e.response.SecondaryColumns, function (column) {
                                var value = self.getColumnValue(column, row);
                                gridColumnData["_" + column.Key.replace(self.keyRegExpression, "")] = $.customizedHtmlEncoding(value);
                            });

                            _.each(e.response.Columns, function (column) {
                                var value = self.getColumnValue(column, row);
                                if (column.DataFormat && column.DataType && (!(column.DataType == 4 || column.DataType == 5)))
                                    value = $.getFormattedValue(column.DataType, column.DataFormat, value);
                                if (uRow != undefined && uRow["_" + column.Key.replace(self.keyRegExpression, "")] != undefined)
                                    gridColumnData["_" + column.Key.replace(self.keyRegExpression, "")] = uRow["_" + column.Key.replace(self.keyRegExpression, "")];
                                else
                                    gridColumnData["_" + column.Key.replace(self.keyRegExpression, "")] = $.customizedHtmlEncoding(value);
                            });
                            var tbItem = $.grep(self.selectedUsers, function (i) {
                                return i.UserId == row.Id;
                            });
                            if (tbItem.length > 0)
                                gridColumnData["IsTargeted"] = true;
                            else
                                gridColumnData["IsTargeted"] = false;
                            self.gridRows.push(gridColumnData);
                        });
                        self.gridDataSource._total = e.response.TotalCounts;
                        self.srcElement.find(".totalUsersCount").html(e.response.TotalCounts);
                        self.srcElement.find(".totalUsersCount").html(e.response.TotalCounts);
                    }
                    else {
                        self.gridColumnDefinitions.length = 0;
                        gridRows.length = 0;
                        self.gridColumnDefinitions.push({
                            title: '',
                            field: '',
                            template: self.srcElement.find(".userList-chkTargeted-template").html(),
                            headerTemplate: kendo.format('<input name="chbox" class="UsersCheckAll" value="0" type="checkbox" title="' + self.userListResourceStrings.IUTAllUsers_SelectAll_DeSelect + '" data-type="selectAll" />', ""),
                            width: 5,
                        });
                        self.gridColumnDefinitions.push({
                            title: 'Username',
                            field: '',
                            width: 80,
                        });
                        self.gridColumnDefinitions.push({
                            title: self.userListResourceStrings.IUTAllUsers_Add_Reset,
                            field: "",
                            width: "10px",
                            headerTemplate: '<a href="#" class="small-msg block column-select addReportColumn" title="' + self.userListResourceStrings.IUTAllUsers_Add + '"  >' + self.userListResourceStrings.IUTAllUsers_Add + '</a><a href="#" class="small-msg block reset" title="' + self.userListResourceStrings.IUTAllUsers_Reset + '" >' + self.userListResourceStrings.IUTAllUsers_Reset + '</a>'
                        });
                    }

                    userGridDom = self.srcElement.find(".userGrid");

                    // Page info of kendo grid
                    if (self.userPageLayout == "FromUserManager") {
                        self.srcElement.find(".allUserPageInfo").kendoPager({
                            dataSource: self.gridDataSource,
                            autoBind: false,
                            numeric: false,
                            previousNext: false,
                            messages: {
                                display: $.htmlDecode(self.PA_Template_AllUsers_PagingInfo || self.userListResourceStrings.IUTAllUsers_PagingInfo),
                                empty: $.htmlDecode(self.userListResourceStrings.AtHoc_Pager_Message_Empty),
                            }
                        });
                    }

                    // Allusers kendo grid
                    userGridDom.find(".k-grid-header").html('');
                    userGridDom.find(".bootstrap-select").remove();
                    ko.cleanNode($(userGridDom).get(0));
                    self.allUsersgrid = userGridDom.kendoGrid({
                        columns: self.gridColumnDefinitions,
                        dataSource: self.gridRows,
                        selectable: false,
                        scrollable: true,
                        autoBind: true,
                        sortable: false,
                        pageable: {
                            refresh: true,
                            pageSizes: true,
                            pageSizes: [20, 50, 100],
                            buttonCount: 5,
                            messages: {
                                display: $.htmlDecode(self.PA_Template_AllUsers_PagingInfo || self.userListResourceStrings.IUTAllUsers_PagingInfo),
                                empty: $.htmlDecode(self.userListResourceStrings.AtHoc_Pager_Message_Empty),
                                itemsPerPage: $.htmlDecode(self.PA_Template_ItemsPerPage || self.userListResourceStrings.IUT_ItemsPerPage),
                                first: $.htmlDecode(self.userListResourceStrings.AtHoc_Pager_Message_Go_To_The_First_Page),
                                previous: $.htmlDecode(self.userListResourceStrings.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                                next: $.htmlDecode(self.userListResourceStrings.AtHoc_Pager_Message_Go_To_The_Next_Page),
                                last: $.htmlDecode(self.userListResourceStrings.AtHoc_Pager_Message_Go_To_The_Last_Page)
                            }
                        },
                        // editable:true,
                        dataBinding: function () { self.userListDataBinding(); },
                        dataBound: function () { self.userListDataBound(); },
                        change: function (e) {
                            //var model = this.dataItem(this.select());
                            //this.select().removeClass("k-state-selected");
                            //self.userInfo.update({ userId: model.Id, userName: model._LOGIN_ID });
                            //$("#userInfoHolder", self.userInfo.refDomNode).modal("show");
                        }

                    }).data().kendoGrid;

                    self.srcElement.find(".filter-menu").find(".dropdown-selection-wrap").html('');
                    self.allUsersPageSize = self.gridDataSource._pageSize;
                    self.currentPage = self.gridDataSource._page;
                    setTimeout(function () {
                        // Fit height for the alluer grid
                        self.fitHeightAllUsers();
                        $.AjaxLoader.hideLoader();
                        $(self.srcElement.find("#divProgress")).html("");
                    }, 100);


                    if (onSuccess)
                        onSuccess();

                    var captionElm = self.srcElement.find(".table-crown-caption .counter");
                    var search = self.srcElement.find(".filter-col-last").find(".btn-primary");

                    $(captionElm).find('.text-toggle.search-settings').attr("title", self.userListResourceStrings.PAEvent_Filter_Title);
                    if (!self.statusFlag)
                        $(captionElm).find('.text-toggle.search-settings').text(self.userListResourceStrings.PAEvent_AllUsers).append("<span style='margin-top:2px' class='caret'></span>");
                    $(search).html(self.userListResourceStrings.PAEvent_Search);
                    self.srcElement.find(".table-crown-search").find(".faux-link").html(self.userListResourceStrings.PAEvent_ClearAll);
                    self.srcElement.find(".table-crown-search").find(".faux-link").attr("title", self.userListResourceStrings.PAEvent_ClearAll);
                    self.srcElement.find(".lang-filter").find(".lang-filter-header").html(self.userListResourceStrings.PAEvent_NewColumn_Title);
                    self.srcElement.find(".totalUsersCount").html(self.totalUsers);
                    self.srcElement.find(".filter-search-input").attr("placeholder", self.userListResourceStrings.PAEvent_Search_PlacedHolder);
                    self.srcElement.find(".advanced-search-open").html(self.userListResourceStrings.PAEvent_Advanced_Search);
                    self.srcElement.find(".advanced-search-open").attr("title", self.userListResourceStrings.PAEvent_Advanced_Search);
                    self.srcElement.find('.select-group').attr("title", self.userListResourceStrings.PA_Event_Details_Select_Groups);
                    self.srcElement.find(".dialogResetAllUsers").find(".modal-header h2").html(self.userListResourceStrings.PAEvent_ResetDialog_Title);
                    self.srcElement.find(".dialogResetAllUsers").find(".modal-body").html(self.userListResourceStrings.PAEvent_ResetDialog_Message);
                    self.srcElement.find(".dialogResetAllUsers").find(".modal-footer .btn-info").html(self.userListResourceStrings.PAEvent_Cancel);
                    self.srcElement.find(".dialogResetAllUsers").find(".modal-footer .btn-primary").html(self.userListResourceStrings.PAEvent_Ok);
                    self.srcElement.find(".chkClass").attr("title", self.userListResourceStrings.PAEvent_Select_Deselect);
                    self.srcElement.find(".usersCheckAll").attr("title", self.userListResourceStrings.PAEvent_SelectAll_DeSelect);

                    $(".advanced-search-open", self.domNode).click(function () {
                        $(self.queryRefNode).athocEntitySelectorPopup('setPreselections', self.queryCriteriaSelections);
                        $(self.queryRefNode).athocEntitySelectorPopup('launchAndShow');
                    });
                    $(".select-group", self.domNode).click(function () {
                        var arrayToReturn = new Array();
                        _.each(self.qroupsSelections, function (item) {
                            arrayToReturn.push({ id: item.value, entityType: item.type, lineage: item.lineage });
                        });
                        $(self.groupRefNode).athocEntitySelectorPopup('setPreselections', arrayToReturn);
                    });

                    self.srcElement.find(".usersCheckAll").click(function () {
                        self.allUsersSelectAll();
                    });
                    self.srcElement.find(".addReportColumn").click(function () {
                        self.addNewGridColumn();
                    });
                    self.srcElement.find(".reset").click(function () {
                        self.ResetGridList();
                    });

                    self.srcElement.find(".remove-column").click(function (e) {
                        self.userListRemoveColumn(e);
                    });

                    self.srcElement.find(".table-head-primary").click(function (e) {
                        self.allUserGridColumnSort(e);
                    });
                    self.srcElement.find(".chkClass").click(function (e) {
                        self.Targeted(this);
                    });
                    self.srcElement.find(".allUserListLink").click(function () {
                        self.getUserInfo(this);
                    });

                    self.srcElement.find(".StatusLink").click(function () {

                        var id = this.getAttribute('value');
                        var name = this.getAttribute('title');
                        var comments = this.getAttribute('Comments');
                        self.selectedUsers = [];
                        var uAttribute = _.find(self.responseTypes, function (i) {
                            return i.ValueName == name;
                        });
                        if (uAttribute != null)
                            self.responseId = uAttribute.ValueId;
                        else
                            self.responseId = 0;
                        self.selectedUsers.push({ UserId: id, Name: "", IsTargeted: false });
                        self.comments = comments;
                        self.userView.showDialog();
                    });

                    self.srcElement.find(".float-left").find(".filter-element").click(function () {
                        self.srcElement.find(".search-setting-panel .cond-panel-wrap .end-user-filter").show();
                    });

                    if (!self.statusFlag) {

                        self.populateStatusFilter(self.responseTypes, self.userListResourceStrings);
                        self.statusFlag = true;
                        self._renderQuickSearchFilter();


                        //$.find(".table-crown-caption .counter").find('.text-toggle .search-settings').text(self.userListResourceStrings.PAEvent_AllUsers);
                        var search = self.srcElement.find(".filter-col").find(".btn-search");
                        self.srcElement.find(".filter-search-input").keyup(function (e) {
                            var seaString = $.trim(self.srcElement.find(".filter-search-input").val());
                            if ($.hotkeys.enter(e) && seaString != "") {
                                self.srcElement.find('.pill-container').show();
                                self.createPills(seaString, "SIMPLESEARCH", self.srcElement.find(".filter-search-input").val());
                                self.srcElement.find(".filter-search-input").val('');
                            }
                            if (seaString.length > 0) {
                                $(search).removeAttr('disabled');
                                $('.ClearAll').removeAttr('disabled');
                            }
                        });

                        $(search).click(function () {
                            if ($.trim(self.srcElement.find('.filter-search-input').val()).length > 0) {
                                self.createPills($.trim(self.srcElement.find('.filter-search-input').val()), "SIMPLESEARCH", self.srcElement.find('.filter-search-input').val());
                                self.srcElement.find('.filter-search-input').val('');
                                self.srcElement.find(".pill-container").show();
                            }
                        });
                       
                        // To render pills at first time when it is loading from other tabs..
                        if (self.filterType != undefined) {
                            var filterText = '';
                            var uAttribute = _.find(self.responseTypes, function (i) {
                                return i.SortOrder == self.filterType;
                            });
                            if (uAttribute != null) {
                                filterText = uAttribute.ValueName;
                            }


                            if (filterText == "") {
                                switch (parseInt(self.filterType)) {
                                    case 0:
                                        filterText = self.userListResourceStrings.PAEvent_NoStatus;
                                        break;
                                    case -2:
                                        filterText = self.userListResourceStrings.PAEvent_AllResponses;
                                        break;
                                    default:
                                        filterText = self.userListResourceStrings.PAEvent_AllUsers;
                                        break;
                                }
                            }
                            self.setStatusFilter(filterText, self.filterType);
                            self.renderPills();
                        }
                        $("body").click(function () {
                            self.srcElement.find(".filter-menu .lang-filter").hide();
                            //$("#filterContextDropdown", self.domNode).hide();
                        });
                    }
                },
                schema: {
                    data: "Rows",
                    total: "TotalCounts",
                },
                serverPaging: true,
                serverSorting: true,
                serverFiltering: true,
                sort: { field: "LOGIN_ID", dir: "desc" },
                pageSize: 50,
                error: function (e) {
                    var errorCallBack = function (returnedErrorObject) {
                        //    $('#listMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                    };
                    //AjaxUtility().athocKendoGridAjaxErrorHandler(e, errorCallBack);
                    //handleError(e);
                },
                change: function (e) {
                    self.retainSelectAll();
                }
            });
            self.gridDataSource._pageSize = this.allUsersPageSize;
            self.gridDataSource._page = self.currentPage;
            self.gridDataSource.read();
            return 0;
        },


        // Creating status filters
        populateStatusFilter: function (data, userListResourceStrings) {
            var html = "";
            html = "<div class='text-select text-select-checked'  data-settings-value=-1  tabindex='220' data-tab-index-seq='227' id=-1>" + userListResourceStrings.PAEvent_AllUsers + "</div>";
            if (data != undefined && data.length > 0)
                html = html + "<div class='text-select'  data-settings-value=-1  tabindex='220' data-tab-index-seq='227' id=-2>" + userListResourceStrings.PAEvent_AllResponses + "</div>";

            _.each(data, function (item, index) {
                html = html + " <div class='text-select'  tabindex='220' data-tab-index-seq='227' data-settings-value='" + item.ValueId + "' id='" + item.SortOrder + "'>" + $.htmlEncode(item.ValueName) + "</div>";
            });
            html = html + " <div class='text-select'  tabindex='220' data-tab-index-seq='227' data-settings-value=0 id=0>" + userListResourceStrings.PAEvent_NoStatus + "</div>";
            this.srcElement.find(".table-crown-caption .dropdown-selection-wrap ").html(html);
            $(".lang-list .text-select:nth-child(2)").css('border-bottom', '1px solid #ddd');
            $(".lang-list .text-select:last").css('border-top', '1px solid #ddd');
        },


        // Databound event for the allusers grid
        userListDataBound: function (e) {
            // var uGrid = $("#userGrid", self.ph.domNode);          
            var data = userGridDom.data("kendoGrid").dataSource.view();
            //self.allAvailableUser(data);

            var grid = userGridDom.data("kendoGrid");
            grid.pager.dataSource = this.gridDataSource;
            this.onBoundEmptyRow(data);
        },

        // Databinding event for the allusers grid
        userListDataBinding: function (e) {
            //var uGrid = $("#userGrid", self.ph.domNode);
            var ds = userGridDom.data("kendoGrid").dataSource;
            ds._sort = [{ field: this.allUserSortField, dir: this.allUserSortOrder }];
            userGridDom.find(".k-pager-refresh").remove();
        },

        //
        onBoundEmptyRow: function (data) {

            var colCount = userGridDom.find('.k-grid-header colgroup > col').length;
            if (data.length == 0) {
                this.srcElement.find(".userGrid").find('.k-grid-content tbody')
                    .append('<tr class="kendo-data-row"><td colspan="' +
                        colCount +
                        '" style="text-align:center;height:10px;overflow:auto;">' +
                        kendo.format('<span class="word-break-txt" title="{0}">{1}</span>', this.userListResourceStrings.IUTAllUsers_Emptyrow_Message, this.userListResourceStrings.IUTAllUsers_Emptyrow_Message) +
                        '</td></tr>');
            }
        },

        // Get user info for the compact popup
        getUserInfo: function (obj) {
            var self = this;
            var id = obj.getAttribute('value');
            var name = obj.getAttribute('title');
            self.userInfo.update({ userId: id, userName: name }, $('#userInfoModal').find('#showProgress'));
            //self.userView.refDomNode.find("#userCompactPopup").show();
            self.userView.refDomNode.find("#userCompactPopup").find("#userInfoModal").modal();
            $(self.srcRefNode).append('<div id="displayShadow" class="modal-backdrop fade in"></div>');
            $('#userInfoModal', self.userView.refDomNode.find("#userCompactPopup")).on('hidden.bs.modal', function () {
                $(self.srcRefNode).find('#displayShadow').remove();
            });
        },

        //
        _renderQuickSearchFilter: function () {
            var self = this;
            var captionElm = $.find(".table-crown-caption .counter");
            if (self.deepLink)
                self.setStatusFilter(self.userListResourceStrings.PAEvent_NoStatus, 0);
            self.selectedFilterValue = $(captionElm).find('.text-toggle.search-settings').text().trim();
            var closeSearchOnOtherUserEvent = function (e) {
                if (($('.search-setting-panel').has(e.target).length == 0) && ($(e.target).hasClass('search-settings') == false)) {
                    refreshSearchSettings();
                }
            };

            var refreshSearchSettings = function () {
                var panel = $(captionElm).find(".search-setting-panel");
                panel.toggle();
                //make panel invisible when user is clicking
                //other area or event
                var isPanelVisible = panel.is(":visible");
                if (isPanelVisible) {
                    $(document).off('click.refreshSearchSettings').on('click.refreshSearchSettings', function (e) {
                        closeSearchOnOtherUserEvent.bind(self);
                        closeSearchOnOtherUserEvent(e);
                    });
                    $(document).off('keyup.refreshSearchSettings').on('keyup.refreshSearchSettings', function (e) {
                        closeSearchOnOtherUserEvent.bind(self);
                        closeSearchOnOtherUserEvent(e);
                    });
                } else {
                    $(document).off('click.refreshSearchSettings');
                    $(document).off('keyup.refreshSearchSettings');
                }
            };

            $(captionElm).find(".search-settings").click(function (e) {
                refreshSearchSettings();
                self.srcElement.find(".end-user-filter").position({
                    my: "right+55 top+15",
                    at: "center",
                    of: ".search-settings"
                });
                e.stopPropagation();
            });

            $(captionElm).find('.text-select').click(function (event) {
                $(captionElm).find('.text-select').removeClass("text-select-checked");
                $(this).addClass('text-select-checked');
                self.selectedFilterValue = $(this).attr('id');
                $(captionElm).find('.text-toggle.search-settings').text($(this).text()).append("<span style='margin-top:2px' class='caret'></span>");
                refreshSearchSettings();
                self.filterType = $(this).attr('id');
                $('.ClearAll').removeAttr('disabled');
                self.currentPage = 1;
                self.createGrid();
                event.stopPropagation();

            });
        },

        // Removing column from grid
        userListRemoveColumn: function (event) {
            if (this.userPageLayout != "FromUserManager") {

                event.preventDefault();
                var key = event.currentTarget.parentNode.getAttribute("Key");
                var cList = this.newlyaddedColumns.filter(function (i) {
                    return i.Key != key;
                });
                this.newlyaddedColumns = cList;
                this.currentPage = 1;
                this.createGrid();
            } else {
                this.updateGridColumn(event.currentTarget.parentNode.getAttribute("viewid"), event.currentTarget.parentNode.getAttribute("Id"),
                      "remove",
                      event.currentTarget.parentNode.getAttribute("customviewcolumntype"),
                      event.currentTarget.parentNode.getAttribute("key"),
                      function () {
                          //$.AjaxLoader.hideLoader();
                      });
            }
        },

        // Sorting of columns for allusers grid
        allUserGridColumnSort: function (event) {
            var self = this;
            self.allUserSortField = event.currentTarget.parentNode.getAttribute("data-field");
            self.allUserSortColumn = event.currentTarget.parentNode.getAttribute("key");
            if (self.allUserSortOrder == "desc")
                self.allUserSortOrder = "asc";
            else
                self.allUserSortOrder = "desc";
            self.currentPage = 1;
            self.createGrid();

        },

        // Select all event for the allusers grid
        allUsersSelectAll: function () {
            var self = this;
            var checked = self.srcElement.find('.usersCheckAll').is(':checked');
            var grid = userGridDom.data().kendoGrid;
            $('.chkClass').prop('checked', checked);
            $.each(grid.dataSource.view(), function (i, item) {
                if (checked) {
                    item.IsTargeted = checked;
                }
                else
                    item.IsTargeted = false;
                self.updateSelectedUsers(item);
            });
            $(".chkClass", self.domNode).click(function (e) {
                self.Targeted(this);
            });
            this.srcElement.find(".selectedUsersCount").html(this.selectedUsers.length);
        },

        // Retain check all when the paging is done
        retainSelectAll: function () {

            var grid = userGridDom.data().kendoGrid;
            var items = grid.dataSource.view();
            var ttlCnt = 0;
            // Get the selected items for the current page.
            $.grep(items, function (v) {
                if (v.IsTargeted)
                    ttlCnt++;
            });

            // Check total page count equal to selected count 
            var checked = ttlCnt > 0 && (items.length == ttlCnt);
            this.srcElement.find(".usersCheckAll").prop('checked', checked);
            this.srcElement.find(".selectedUsersCount").html(this.selectedUsers.length);

        },

        // Createing pills when search is done
        createPills: function (value, type, display) {
            var self = this;
            var found = _.find(self.searchString, function (item) {
                return (item.value == value && item.type == type);
            });
            if (!found) {
                self.searchString.push({ value: value, type: type, display: display });
                self.renderPills();
                self.currentPage = 1;
                self.createGrid();
            }
        },

        // Rendering the pills when search is done
        renderPills: function (css) {
            var self = this;
            var html = "";
            var search = self.srcElement.find(".table-crown-search");
            $(search).find(".pill-container").html('');
            if (self.searchString && self.searchString.length > 0) {
                _.each(self.searchString, function (item, index) {
                    var prefix = "";
                    var pillLabel = prefix + $.htmlEncode(item.display);
                    var pillTooltip = prefix + $.htmlEncode(item.display);
                    var closeButton = (typeof (css) === 'undefined' ? '<a class="pill-close" href="#"></a>' : '');
                    html = '<div class="pill" data-index="' + index + '" title="' + pillTooltip + '"><span class="pill-content">' + pillLabel + '</span>' + closeButton + '</div>' + html;
                });
                html = html + '<button tabindex="4" class="btn btn-large faux-link mar-bot0 ClearAll" type="button">Clear All</button>';
                var pillsElm = $(search).find(".pill-container");
                pillsElm.html(html);
                //wire up events
                $(search).find(".pill-close").click(function (event) {
                    var parentElm = $(this).parent(".pill");
                    self.deSelect(parentElm.data("index"));
                    event.stopPropagation();
                });
                $(search).find(".faux-link").click(function () {
                    self.clearAll();
                    $(search).find(".pill-container").hide();
                });
            }
        },

        // Deleteing the pills
        deSelect: function (index, onSuccess) {
            var self = this;
            var remove = [];
            if (self.searchString && self.searchString.length > index) {

                if (self.searchString[index].type == "HIERARCHY") {
                    $.each(self.hierarchyIds, function (i, value) {
                        _.find(self.searchString[index].value, function (val) {
                            if (val == value)
                                remove.push(val);
                        });
                    });
                    $.each(remove, function (i, value) {
                        var indexToSplice = -1;
                        _.each(self.hierarchyIds, function (item, index) {
                            if (value == item) {
                                indexToSplice = index;
                            }
                        });
                        self.hierarchyIds.splice(indexToSplice, 1);
                    });
                    self.filterType = -1;
                    var captionElm = $.find(".table-crown-caption .counter");
                    $(captionElm).find('.text-select').removeClass("text-select-checked");
                    $(captionElm).find('.text-toggle.search-settings').text(self.userListResourceStrings.PAEvent_AllUsers).append("<span style='margin-top:2px' class='caret'></span>");
                    $("[id=" + self.filterType + "]").addClass('text-select-checked');

                }
                else if (self.searchString[index].type == "ATTRIBUTE") {
                    $.each(self.attributeIds, function (i, value) {
                        _.find(self.searchString[index].value, function (val) {
                            if (val == value)
                                remove.push(val);
                        });
                    });
                    $.each(remove, function (i, value) {
                        var indexToSplice = -1;
                        _.each(self.attributeIds, function (item, index) {
                            if (value == item) {
                                indexToSplice = index;
                            }
                        });
                        self.attributeIds.splice(indexToSplice, 1);
                    });

                    self.filterType = -1;
                    var captionElm = $.find(".table-crown-caption .counter");
                    $(captionElm).find('.text-select').removeClass("text-select-checked");
                    $(captionElm).find('.text-toggle.search-settings').text(self.userListResourceStrings.PAEvent_AllUsers).append("<span style='margin-top:2px' class='caret'></span>");
                    $("[id=" + self.filterType + "]").addClass('text-select-checked');

                }
                else if (self.searchString[index].type == "ATTRIBUTEVALUE") {
                    $.each(self.attributeValueIds, function (i, value) {
                        _.find(self.searchString[index].value, function (val) {
                            if (val == value)
                                remove.push(val);
                        });
                    });
                    $.each(remove, function (i, value) {
                        var indexToSplice = -1;
                        _.each(self.attributeValueIds, function (item, index) {
                            if (value == item) {
                                indexToSplice = index;
                            }
                        });
                        self.attributeValueIds.splice(indexToSplice, 1);
                    });

                    self.filterType = -1;
                    var captionElm = $.find(".table-crown-caption .counter");
                    $(captionElm).find('.text-select').removeClass("text-select-checked");
                    $(captionElm).find('.text-toggle.search-settings').text(self.userListResourceStrings.PAEvent_AllUsers).append("<span style='margin-top:2px' class='caret'></span>");
                    $("[id=" + self.filterType + "]").addClass('text-select-checked');
                }
                else if (self.searchString[index].type == "LISTITEM" || self.searchString[index].type == "HIERARCHYITEM") {
                    $.each(self.listItemIds, function (i, value) {
                        _.find(self.searchString[index].value, function (val) {
                            if (val == value)
                                remove.push(val);
                        });
                    });
                    $.each(remove, function (i, value) {
                        var indexToSplice = -1;
                        _.each(self.listItemIds, function (item, index) {
                            if (value == item) {
                                indexToSplice = index;
                            }
                        });
                        self.listItemIds.splice(indexToSplice, 1);
                    });

                    self.providerId = 0;
                    self.filterType = -1;
                    var captionElm = $.find(".table-crown-caption .counter");
                    $(captionElm).find('.text-select').removeClass("text-select-checked");
                    $(captionElm).find('.text-toggle.search-settings').text(self.userListResourceStrings.PAEvent_AllUsers).append("<span style='margin-top:2px' class='caret'></span>");
                    $("[id=" + self.filterType + "]").addClass('text-select-checked');
                }

                if (self.searchString[index].type == "ADVANCESEARCH") {
                    self.queryCriteria = "";
                    self.queryCriteriaSelections = [];
                }
                //Deleteing the items from groupSelection Array
                _.each(remove, function (value, idx) {
                    var indexToSplice = -1;
                    _.each(self.qroupsSelections, function (item, index) {
                        if (value == item.value)
                            indexToSplice = index;
                    });
                    self.qroupsSelections.splice(indexToSplice, 1);
                });

                self.searchString.splice(index, 1);

                self.renderPills();
                self.currentPage = 1;
                self.createGrid();
            }
        },

        // Adjust height of the grid.
        fitHeightAllUsers: function () {
            var self = this;
            var extraSpace = 0;
            var height = 0;

            if (self.srcElement.find(".pill-container").children().length == 0)
                self.srcElement.find(".pill-container").hide();
            else {
                self.srcElement.find(".pill-container").show();
                extraSpace = 20;
            }
            // if it is modal then making height dynamically
            if (self.isModal) {
                var windowHeight = self.userView.refDomNode.find(".modal-content").height() - self.srcElement.find(".table-crown-center").height();
                if (windowHeight >= 530) {
                    height = ((windowHeight * 73.2 / 100) - extraSpace);
                }
                else if (windowHeight > 380) {
                    height = ((windowHeight * 64.5 / 100) - extraSpace);
                }
                else {
                    height = ((windowHeight * 54 / 100) - extraSpace);
                }
            }
            // For grid scroll bars are dynamic
            self.srcElement.find(".userGrid .k-grid-content").attr("style", "overflow:auto!important;");

            if (height > 0)
                self.srcElement.find(".userGrid .k-grid-content").css("height", height);
            else
                self.srcElement.find(".userGrid .k-grid-content").css("height", 'auto');

            // If it has vertical scrollbar in case if modal then keeping padding for header
            if (self.srcElement.find(".userGrid .k-grid-content")[0].scrollHeight > self.srcElement.find(".userGrid .k-grid-content")[0].offsetHeight)
                self.srcElement.find(".userGrid .k-grid-header").attr("style", "padding-right:17px!important");

            self.srcElement.find(".userGrid").show();

        },

        // Get column value from datasource.
        getColumnValue: function (column, row) {
            if (column.Key == "OPERATOR-ROLES") {
                var roleCount = row.UserAttributes["ROLECOUNT_OTHERORGS"];
                if (roleCount && roleCount != " ") {
                    return row.UserAttributes[column.Key] + " (" + row.UserAttributes["ROLECOUNT_OTHERORGS"] + ") ";
                } else {
                    return row.UserAttributes[column.Key];
                }
            }
            return column.CustomViewColumnType === "CF"
                ? row.UserAttributes[column.Key]
                : row.UserDevice[column.Key];
        },

        // Check event of checkbox in all user grid
        Targeted: function (obj) {
            var userId = obj.getAttribute("value");
            var grid = userGridDom.data().kendoGrid;
            var items = grid.dataSource.view();

            var item = _.find(items, function (i) {
                return i.Id == userId;
            });

            if (item != null) {
                item.IsTargeted = obj.checked;
                this.selectedStatusChanged(item._StatusId);
                this.updateSelectedUsers(item);
                this.retainSelectAll();

            }
        },

        selectedStatusChanged: function (id) {
            if (id != "") {
                var uAttribute = _.find(this.responseTypes, function(i) {
                    return i.ValueName == id;
                });
                if (uAttribute != null)
                    this.responseId = uAttribute.ValueId;
                else
                    this.responseId = 0;
            }
        },

        // Adding new column to the grid. 
        addNewGridColumn: function () {
            var self = this;
            var parameters = {
                viewType: "UserManager",
            };
            var myAjaxOptions = {
                url: self.Urls.GetCustomViewsUrl,
                type: "POST",
                dataType: "json",
                data: parameters,
                success: function (data) {
                    if (data && data.length > 0) {
                        self.srcElement.find(".filter-menu").find(".dropdown-selection-wrap").html('');
                        var htmlAttributes = '';
                        var deviceOptions = '';
                        var operatorOptions = '';
                        var hierarchyOptions = '';
                        var hierarchyGroup = '', attributeGroup = '', deviceGroup = '', operatorAttributeGroup = '';
                        var html = "";
                        html += '<select  name="addColumnDropdown"  data-placeholder="" size=10  style="width:235px !important;margin-left:5px !important">';
                        _.each(data, function (item, index) {
                            //var existColCount = self.newlyaddedColumns.filter(function (i) {
                            //    return (i.Key == item.Key);
                            //}).length;
                            var fieldKey = "_" + item.Key.replace(self.keyRegExpression, "");
                            var existColCount = self.gridColumnDefinitions.filter(function (i) {
                                return (i.field == fieldKey);
                            }).length;
                            if (existColCount == 0) {
                                var optionList = "<option value='" + item.Id + "' data-customviewcolumntype='" + item.CustomViewColumnType + "' data-key='" + item.Key + "'>" + $.htmlEncode(item.DisplayName) + "</option>";

                                if (item.CustomViewColumnType == "CF" && item.IsHierarchy == false && item.Key == $.htmlDecode("OPERATOR-ROLES")) {
                                    operatorOptions = operatorOptions + optionList;
                                }
                                else if (item.CustomViewColumnType == "CF" && item.IsHierarchy == false && item.Key != $.htmlDecode("DISPLAY_NAME")) {
                                    htmlAttributes = htmlAttributes + optionList;
                                }
                                else if (item.CustomViewColumnType == "CF" && item.IsHierarchy == true) {
                                    hierarchyOptions = hierarchyOptions + optionList;
                                }
                                else if (item.CustomViewColumnType == "Device") {
                                    deviceOptions = deviceOptions + optionList;
                                }
                            }
                        });
                        if (hierarchyOptions != '') {
                            hierarchyGroup = '<optgroup label="' + self.userListResourceStrings.PAEvent_Users_OrganizationHierarchy + '">' + hierarchyOptions + '</optgroup>';
                        }

                        if (htmlAttributes != '')
                            attributeGroup = '<optgroup label="' + self.userListResourceStrings.PAEvent_Users_Attributes + '">' + htmlAttributes + '</optgroup>';

                        if (deviceOptions != '')
                            deviceGroup = '<optgroup label="' + self.userListResourceStrings.PAEvent_Users_Devices + '">' + deviceOptions + '</optgroup>';

                        if (operatorOptions != '')
                            operatorAttributeGroup = '<optgroup label="' + $.htmlDecode(self.userListResourceStrings.PAEvent_Users_OperatorAttributes) + '">' + operatorOptions + '</optgroup>';

                        html = html + hierarchyGroup + attributeGroup + operatorAttributeGroup + deviceGroup;
                        html += '</select>';
                        self.srcElement.find(".filter-menu").find(".dropdown-selection-wrap").html(html);

                        var selectElm = $("select[name='addColumnDropdown']");

                        selectElm.change(function () {
                            var elm = $(this);
                            if (self.userPageLayout != "FromUserManager") {
                                var displayName = "";

                                if (elm.find("option:selected").data("customviewcolumntype") == "Device")
                                    displayName = elm.find("option:selected").html().replace(/\(Device\)?$/, "").trim();
                                else
                                    displayName = elm.find("option:selected").html();

                                self.newlyaddedColumns.push({ Id: elm.val(), Key: elm.find("option:selected").data("key"), CustomViewColumnType: elm.find("option:selected").data("customviewcolumntype"), DisplayName: displayName });
                                self.srcElement.find(".filter-menu .lang-filter").hide();
                                self.currentPage = 1;
                                self.createGrid();
                            }
                            else {
                                self.updateGridColumn(0, elm.val(),
                                       "add",
                                       elm.find("option:selected").data("customviewcolumntype"),
                                       elm.find("option:selected").data("key"),
                                       function () {
                                           $("#contextDropdown").hide();
                                       });
                            }

                        });
                        self.srcElement.find(".filter-menu .lang-filter").show();

                        self.srcElement.find(".filter-menu .lang-filter").position({
                            my: "right+55 top+15",
                            at: "center",
                            of: ".addReportColumn"
                        });
                    }
                }
            };

            var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);
            $.ajax(ajaxOptions);
            //}
        },

        // Reset confirmation popup
        ResetGridList: function () {
            var self = this;
            $(self.srcRefNode).append('<div id="displayShadow" class="modal-backdrop fade in"></div>');
            self.srcElement.find(".dialogResetAllUsers").show();
            self.srcElement.find(".dialogResetAllUsers").on('click', '.btn-info', function (event) {
                $(self.srcElement).find(".dialogResetAllUsers").hide();
                $(self.srcElement).find('.modal-backdrop').remove();
            });
        },
        // For Add/Block user Update grid columns in a grid
        updateGridColumn: function (viewId, id, action, columnType, columnKey, onSuccess) {
            var self = this;
            if (id) {
                //$.AjaxLoader.setup({ useBlock: true, idToShow: self._id + '-pageAjaxLoader', elementToBlock: $('.table-header'), imageURL: self.options.cdnUrl + '/Images/ajax-loader.gif' }).showLoader();
                if (action == "remove" && self.allUserSortColumn == columnKey) {
                    self.allUserSortColumn = "LOGIN_ID";
                    self.allUserSortOrder = "ASC";
                }
                var myAjaxOptions = {
                    url: self.Urls.SaveCustomViewUrl,
                    type: "POST",
                    dataType: "json",
                    data: { viewId: viewId, id: id, action: action, type: columnType, commonName: columnKey },
                    success: function (data) {
                        self.currentPage = 1;
                        self.createGrid(undefined, onSuccess, undefined, undefined, false);
                    }
                };

                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);

                $.ajax(ajaxOptions);
            }
        },

        // Removing all added new columns
        resetGridListOk: function () {
            var self = this;

            if (self.userPageLayout != "FromUserManager") {

                self.srcElement.find(".dialogResetAllUsers").hide();
                $(self.srcRefNode).find('.modal-backdrop').remove();
                self.newlyaddedColumns.length = 0;
                self.currentPage = 1;
                self.createGrid();
            } else {
                var myAjaxOptions = {
                    url: self.Urls.ResetToDefaultViewUrl,
                    type: "POST",
                    dataType: "json",
                    success: function (data) {
                        self.srcElement.find(".dialogResetAllUsers").hide();
                        $(self.srcRefNode).find('.modal-backdrop').remove();
                        self.currentPage = 1;
                        self.createGrid();
                    }
                };
                var ajaxOptions = $.extend({}, AjaxUtility().ajaxPostOptions, myAjaxOptions);
                $.ajax(ajaxOptions);
            }
        },
        resetGridListCancel: function () {
            var self = this;
            self.srcElement.find(".dialogResetAllUsers").hide();
            $(self.srcRefNode).find('.modal-backdrop').remove();
        },
        // Clear all updated data and reset the grid
        clearAll: function () {
            var self = this;
            self.srcElement.find(".pill-container").html("");
            $(".filter-search-input").val('');
            $('.ClearAll').attr("disabled", "disabled");
            $('.Search').attr("disabled", "disabled");
            self.allUserSortColumn = "DisplayName";
            self.allUserSortField = "DisplayName";
            self.allUserSortOrder = "asc";
            self.allUsersPageSize = 50;
            self.searchString.length = 0;
            self.hierarchyId = -1;
            //self.filterType = -1;
            //var captionElm = $.find(".table-crown-caption .counter");
            //$(captionElm).find('.text-select').removeClass("text-select-checked");
            //$(captionElm).find('.text-toggle.search-settings').text(self.userListResourceStrings.PAEvent_AllUsers).append("<span style='margin-top:2px' class='caret'></span>");
            //$("[id=-1]").addClass('text-select-checked');
            //self.selectedUsers.length = 0;
            self.queryCriteria = "";
            self.queryCriteriaSelections = [];
            self.hierarchyIds = []; self.attributeValueIds = [];
            self.listItemIds = []; self.attributeIds = [];
            self.qroupsSelections = [];
            self.providerId = 0;
            //self.newlyaddedColumns = [];
            self.currentPage = 1;
            self.createGrid();

        },

        // Collecting the selected users.
        updateSelectedUsers: function (obj) {
            var displayName = '';
            var idx = 0;
            var item = _.find(this.selectedUsers, function (i, index) {
                idx = index;
                return obj.Id == i.UserId;
            });
            if (item == null) {
                if (obj.IsTargeted) {
                    if (obj._DISPLAYNAME != null && $.trim(obj._DISPLAYNAME) != '' && $.trim(obj._DISPLAYNAME) != 'N/A')
                        displayName = obj._DISPLAYNAME;
                    else if ((obj._FIRSTNAME != null && $.trim(obj._FIRSTNAME) != '') || (obj._LASTNAME != null && $.trim(obj._LASTNAME) != ''))
                        displayName = $.trim(obj._FIRSTNAME + ' ' + obj._LASTNAME);
                    else
                        displayName = obj._LOGIN_ID;

                    this.selectedUsers.push({ UserId: obj.Id, Name: displayName, IsTargeted: obj.IsTargeted });
                }
            }
            else if (!obj.IsTargeted) {
                this.selectedUsers.splice(idx, 1);//function (i) { return i.UserId == obj.Id });                                 
            }
            if (this.userView.onUserSelectionChange)
                this.userView.onUserSelectionChange(this.selectedUsers.length);
        },
        setStatusFilter: function (filterText, filterType) {
            var captionElm = $.find(".table-crown-caption .counter");
            $(captionElm).find('.text-select').removeClass("text-select-checked");
            $(captionElm).find('.text-toggle.search-settings').text(filterText).append("<span style='margin-top:2px' class='caret'></span>");
            $("[id=" + filterType + "]").addClass('text-select-checked');
        },
        // Filter the users grid based on other tab selections.
        changeStatus: function (filter) {
            var self = this;
            var filterText = "";
            self.hierarchyIds = [];
            self.listItemIds = [];
            self.searchString.length = 0;
            self.queryCriteria = "";
            self.queryCriteriaSelections = [];
            self.selectedUsers = [];
            //self.newlyaddedColumns = [];
            $(".filter-search-input").val('');
            self.allUserSortColumn = "DisplayName";
            self.allUserSortField = "DisplayName";
            self.allUserSortOrder = "asc";
            self.allUsersPageSize = 50;
            self.deepLink = false;
            if (filter.deepLink != undefined) {
                self.deepLink = true;
                $.AjaxLoader.hideLoader();
            }
            if (filter.status != undefined) {
                var filterType = parseInt(filter.status);
                var uAttribute = _.find(self.responseTypes, function (i) {
                    return i.SortOrder == filterType;
                });
                if (uAttribute != null) {
                    self.filterType = uAttribute.SortOrder;
                    filterText = uAttribute.ValueName;
                }
            }

            if (filterText == "") {
                switch (parseInt(filter.status)) {
                    case 0:
                        filterText = self.userListResourceStrings.PAEvent_NoStatus;
                        self.filterType = 0;
                        break;
                    case -2:
                        filterText = self.userListResourceStrings.PAEvent_AllResponses;
                        self.filterType = -2;
                        break;
                    default:
                        filterText = self.userListResourceStrings.PAEvent_AllUsers;
                        self.filterType = -1;
                        break;
                }
            }
            self.providerId = 0;
            if (filter.hierarchyId != null) {
                // below condition will trigger for Standalone Enterprise and Sub Vpses 
                if (!filter.IsSubVps) {
                    self.hierarchyIds.push(filter.hierarchyId);
                    self.createPills(filter.hierarchyId, "HIERARCHYITEM", filter.pillText);
                } else {
                    filter.hierarchyId = null;
                }
            }

            if (filter.listItemId != null) {
                // below condition will trigger for Enterprise with Sub Vpses 
                if (filter.IsSubVps)
                    self.providerId = filter.listItemId;
                else {
                    self.listItemIds.push(filter.listItemId);
                }
                self.createPills(filter.listItemId, "LISTITEM", filter.pillText);
            }
            //Below condition is added to show the pills when it is clicked from the summary tab.
            if (filter.listItemId == null && filter.hierarchyId == null) {
                self.renderPills();
                self.currentPage = 1;
                self.createGrid();
            }

            self.setStatusFilter(filterText, self.filterType);

        },

        //
        destroy: function () {
            this.inherited(arguments);
        }

    });

    return userList;

});