﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};

if (athoc.iws.publishing) {
    athoc.iws.publishing.scenario = function() {
        return {
            viewModel: {
                data: ko.observable(),
                status: ko.observable('ready'),
                statusTooltip: ko.observable(athoc.iws.publishing.resources.Publishing_Section_Ready_Tooltip),
                Channels: ko.observable([]),
            },

            setChannels: function(channels) {
                var list = [];
                if (channels) {
                    $.each(channels, function (index, value) {
                        if (value.Id && value.Id > 0) {
                            list.push(value);
                        }
                    });
                }
                athoc.iws.publishing.scenario.viewModel.Channels(list);
            },

            //is model changed
            isChanged: false,

            //is ready for publish
            isReadyToPublish: function() {
                return (this.viewModel.status() == 'ready');
            },

            //this method will be called when new data will be available for this section for binding
            bind: function (data) {
                var model = athoc.iws.publishing.scenario.viewModel;
                var current = athoc.iws.publishing.scenario;

                $("#scenarioDetailsDiv").find(".bootstrap-select").remove();
                if ($("#channelList").length > 0) {
                    $("#channelList").html('');
                }

                model.data = ko.mapping.fromJS(data, athoc.iws.publishing.scenario.getValidation());
                

                //Binding
                if ($("#publishing-scenario-edit").length > 0) {
                    ko.cleanNode($("#publishing-scenario-edit").get(0));
                    ko.applyBindings(model, $("#publishing-scenario-edit").get(0));
                }
                

                if ($("#channelList").length > 0) {
                    $("#channelList").val(data.ChannelId).change();
                }

                //Change events binding
                current.isChanged = false;

                model.data.Name.subscribe(function(newValue) {
                    current.dataChanged();

                    var name = newValue;
                    if (name == "") {
                        name = "Untitled";
                    }

                    athoc.iws.scenario.breadcrumbModel.updateTitle(name, undefined, undefined, 'scenarioDetail');
                });
                model.data.CommonName.subscribe(function (newValue) { current.dataChanged(); });
                model.data.AvailableForQuickPublish.subscribe(function (newValue) { current.dataChanged(); });
                model.data.Description.subscribe(function (newValue) { current.dataChanged(); });

                current.checkReadyNotReady();

            },

            //this method will be called when data is required for updating
            getModel: function () {
                return ko.mapping.toJS(athoc.iws.publishing.scenario.viewModel.data);
            },

            //setup validation
            getValidation: function () {
                var validationMapping = {
                    Name: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                required: {
                                    params: true,
                                    message: athoc.iws.scenario.resources.Publishing_Validation_ScenarioName
                                },
                                maxLength: {
                                    params: 200,
                                    message: athoc.iws.scenario.resources.Publishing_Validation_ScenarioName
                                } 
                            });
                        }
                    },
                    Description: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                maxLength: {
                                    params: 200,
                                    message: athoc.iws.scenario.resources.Publishing_Validation_Description
                                }
                            });
                        }
                    },
                    CommonName: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                maxLength: {
                                    params: 200,
                                    message: athoc.iws.scenario.resources.Publishing_Validation_CommonName
                                }
                            });
                        }
                    },
                };

                return validationMapping;
            },

            //is model valid
            isValid: function () {
                var result = ko.validation.group(athoc.iws.publishing.scenario.viewModel.data, { deep: true });
                if (result().length > 0) {
                    result.showAllMessages(true);
                    $.AjaxLoader.hideLoader();
                    return false;
                }
                return true;
            },

            //triggered on data changed
            dataChanged: function () {
                var current = athoc.iws.publishing.scenario;
                current.isChanged = true;
                current.checkReadyNotReady();
            },

            //set ready not-ready
            checkReadyNotReady: function() {
                var current = athoc.iws.publishing.scenario;
                if (current.isValid()) {
                    current.viewModel.status('ready');
                    current.viewModel.statusTooltip(athoc.iws.scenario.resources.Publishing_Section_Ready_Tooltip);
                } else {
                    current.viewModel.status('not-ready');
                    current.viewModel.statusTooltip(athoc.iws.scenario.resources.Publishing_Section_NotReady_Tooltip);
                }
                athoc.iws.publishing.detail.checkStatusChange();
            },
        };
    }();
}