﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.scenario = athoc.iws.scenario || {};

if (athoc.iws.scenario) {
    athoc.iws.scenario.list = function () {
        var datasource = null;
        //var filter = {};
        //var getChannels = true;
        var sortState;
        return {
            IsRightToLeft: false,

            ViewModel: {},

            loadViewModel: function () {
                this.ViewModel = kendo.observable(
                 {
                     TotalCount: 0,
                     SelectedCount: 0,
                     QuickOnly: false,
                     RecurrentOnly: false,
                     ChannelId: -1,
                     SearchText: "",
                     DupDisabled: true,
                     DelDisabled: true,
                     FilterDisabled: true,
                     Channels: { Id: -1, Name: athoc.iws.scenario.resources.Scenario_List_ChannelAll },
                     FilterScenarioList: function (e) {
                         //only update when enter key is pressed and when the apply button is clicked
                         if ($.hotkeys.enter(e) || e.target.id == "btn_filter")
                             athoc.iws.scenario.list.refreshGrid();

                         if (e.target.id == "btn_filter")
                             $("#btn_clear").focus();
                     },
                     ClearFilters: function (e) {
                         this.set("QuickOnly", false);
                         this.set("RecurrentOnly", false);
                         this.set("ChannelId", -1);
                         this.set("SearchText", "");
                         this.set("DupDisabled", true);
                         this.set("DelDisabled", true);
                         athoc.iws.scenario.list.refreshGrid();
                         //$("#txtSearch").blur(); fix to 6139 and removing it fixes 6283
                         var sp = $("#channels").data("selectpicker");
                         if (sp) {
                             sp.refresh();
                         }
                         e.preventDefault();
                     },
                 });

                //make a seperate call to load channels since we are using standard <select>
                $.ajax({
                    cache: false,
                    url: athoc.iws.scenario.urls.GetChannelsUrl,
                    success: function (data) {
                        data.splice(0, 0, { Id: -1, Name: athoc.iws.scenario.resources.Scenario_List_ChannelAll });
                        athoc.iws.scenario.list.ViewModel.set("Channels", data);
                        athoc.iws.publishing.scenario.setChannels(data);
                        $("#channels").selectpicker();

                    },
                    error: function (e) {
                        athoc.iws.scenario.list.handleError(e);
                    },
                });
            },

            load: function () {

                this.loadViewModel();
                kendo.bind($(".kendoBound"), this.ViewModel);

                this.createScenarioListGrid();

                var gridHeader = $(".kgrid-fix-header").find(".k-grid-header");
                if (gridHeader) {
                    gridHeader.addClass('table-header affix');
                }

                $(".kendo-mini-pager").removeClass("k-pager-wrap");
                $(".kendo-mini-pager").removeClass("k-widget");
                $(".kendo-mini-pager").removeClass("k-floatwrap");

                this.ViewModel.bind("change", function (e) {
                    switch (e.field) {
                        case "QuickOnly":
                        case "RecurrentOnly":
                        case "ChannelId":
                        case "SearchText":
                            //if any filter field is changed, we enable the apply filter button
                            //$("#btn_filter").removeClass("disabled");
                            athoc.iws.scenario.list.ViewModel.set("FilterDisabled", false);
                            break;
                    }
                });
            },

            handleError: function (e) {
                if (e != undefined && e.status == 401 || (e != undefined && e.xhr != undefined && e.xhr.status == 401)) {
                    window.onbeforeunload = null;
                    window.location = window.location;
                } else {
                    $('#listMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                }
            },

            createScenarioListGrid: function () {
                var ro = athoc.iws.utils.urlHelper.getUrlParameter('ro') == 'true' ? true : false;
                this.ViewModel.set("RecurrentOnly", ro);

                var self = this;
                $("#btn_delete").click(function () { self.deleteScenariosFromList(); }); //moving delete button binding here to contain deletion from list (which is diff from deletion from detail page per se) within this library

                var url = athoc.iws.scenario.urls.GetScenarioListUrl;

                datasource = new kendo.data.DataSource({
                    transport: {
                        read: {
                            url: url,
                            cache: false,
                            dataType: "json",
                            contentType: "application/json; charset=utf-8",
                            type: "POST"
                        },
                        parameterMap: function (options) {
                            $.extend(options, athoc.iws.scenario.list.ViewModel);
                            //options.getChannels = getChannels;
                            return kendo.stringify(options);
                        },
                    },
                    requestStart: function (e) {
                        //commented this out because requestStart gets triggered on client side sorting and paging...no need to display the loader in these events.
                        //if (e.type == 'read') 
                        //    $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.scenario.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%' }).showLoader();
                    },
                    requestEnd: function (e) {
                        //if (getChannels) {
                        //    _.each(e.response.Channels, function (item, index) {
                        //        $("#channelSelector").append("<option value='" + item.Id + "'>" + item.Name + "</option>");
                        //    });

                        //}
                        //getChannels = false;
                          $.AjaxLoader.hideLoader();
                        if (e.response) {
                            athoc.iws.scenario.list.ViewModel.set("TotalCount", e.response.length);
                            //clear selected
                            athoc.iws.scenario.list.ViewModel.set("SelectedCount", 0);
                            //reset all buttons
                            athoc.iws.scenario.list.reInitializeButtons();
                        }
                    },
                    //schema: {
                    //    data: "Data",
                    //    total: "TotalCount",
                    //},
                    //serverPaging: true,
                    //serverSorting: true,
                    //serverFiltering:true,
                    sort: { field: "Name", dir: "asc" },
                    pageSize: 50,
                    error: function (e) {
                        athoc.iws.scenario.list.handleError(e);
                    },
                    change: function (e) {
                        athoc.iws.scenario.list.retainSelectAll();
                        var newState = JSON.stringify(this.sort());
                        if (newState != sortState) {
                            sortState = newState;
                            e.preventDefault();
                            //when sort changes, go to first page.
                            this.page(1);
                        }
                        //scrolling to the top when paging and sorting.
                        $("html,body").scrollTop(0);
                    }
                });

                $("#pageInfo").kendoPager({
                    dataSource: datasource,
                    autoBind: false,
                    numeric: false,
                    previousNext: false,
                    messages: {
                        display: athoc.iws.scenario.resources.Scenario_List_PageInfo,
                        empty: athoc.iws.scenario.resources.Scenario_List_PageInfo_NoRecords
                    }
                    //refresh: true,
                    //width: 300,
                });

                var grid = $("#scenarioList").kendoGrid({
                    dataSource: datasource,
                    autoBind: false,
                    //height: 650,
                    //navigatable: true,
                    sortable: {
                        allowUnsort: false
                    },
                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5,
                        messages: {
                            display: $.htmlDecode(athoc.iws.scenario.resources.Scenario_List_PageInfo),
                            empty: $.htmlDecode(athoc.iws.scenario.resources.Scenario_List_PageInfo_NoRecords),
                            itemsPerPage: $.htmlDecode(athoc.iws.scenario.resources.AtHoc_Pager_Message_Items_Per_Page),
                            first: $.htmlDecode(athoc.iws.scenario.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                            previous: $.htmlDecode(athoc.iws.scenario.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                            next: $.htmlDecode(athoc.iws.scenario.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                            last: $.htmlDecode(athoc.iws.scenario.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                        }
                    },
                    columns:
                            [
                                {
                                    field: "ScenarioId",
                                    hidden: true
                                },
                                {
                                    field: "IsChecked",
                                    template: $("#scenario-checkbox-template").html(),
                                    width: 40,
                                    headerTemplate: kendo.format('<div align="center"><input type="checkbox" class="senario-select" id="senario-select-all" title="{0}" /></div>', athoc.iws.scenario.resources.Scenario_List_SelectAll),
                                    sortable: false
                                },
                                {
                                    field: "Name",
                                    title: athoc.iws.scenario.resources.Scenario_List_Name,
                                    width: 300
                                },
                                {
                                    field: "ChannelName",
                                    title: athoc.iws.scenario.resources.Scenario_List_ChannelName,
                                    template: '<span class="cellTooltip" title="#=ChannelName#">#=ChannelName#</span>',
                                    width: 250,
                                    hidden: !(athoc.iws.publishing.settings.IsChannelSupported) //hide "Channel" for affiliate VPS
                                },
                                {
                                    field: "NextRecurrence",
                                    title: athoc.iws.scenario.resources.Scenario_List_NextOccurrence,
                                    template: '<span class="cellTooltip" title="#=NextRecurrenceString#">#=NextRecurrenceString#</span>',
                                    width: 200,
                                    hidden: !(athoc.iws.publishing.settings.IsSchedulingSupported) //hide "NextRecurrence" for affiliate VPS
                                },
                                //{
                                //    field: "IsQuickPublish",
                                //    title: athoc.iws.scenario.resources.Scenario_List_QuickPublish,
                                //    template: $("#scenario-quickpublish-template").html(),
                                //},
                            ],
                    dataBound: athoc.iws.scenario.list.OnDataBound,
                    change: function (e) {
                        var model = this.dataItem(this.select());
                    }
                }).data().kendoGrid;

                var lastMouseX, oldTooltipTop;
                var windowWidth, maxMoveLimit;
                windowWidth = $(window).width();
                maxMoveLimit = windowWidth - 650 - 60 - 50;   // 650px is the max-width of tooltip,
                                                              // 60px space between tooltip and cursor
                                                              // 50px to adjust padding and box shadow
                var $template = kendo.template($("#scenario-tooltip-template").html());
                var scenarioListTooltip = $("#scenarioList").kendoTooltip({
                    filter: "td:nth-child(3)", //this filter selects the first column cells                   
                    position: "right",
                    show: function () {
                        $(this.popup.wrapper).css({
                            left: lastMouseX + 60
                        });

                        var currTooltip = $(this.popup.wrapper).find('.k-tooltip');                      
                        if (currTooltip.width() >= 650) {                           
                            currTooltip.addClass("tooltipWrap");                          
                        }
                        oldTooltipTop = currTooltip.offset().top;
                        var tooltipTopFromWindow = oldTooltipTop - $(window).scrollTop();
                        var tooltipHeight = currTooltip.outerHeight();
                        var tooltipTopAndHeight = tooltipTopFromWindow + tooltipHeight;
                        var windowHeight = $(window).height();
                        if (tooltipTopAndHeight >= windowHeight) {
                            var newTooltipTop = oldTooltipTop - (tooltipTopAndHeight - windowHeight) - 5;
                             currTooltip.offset({ top: newTooltipTop });
                        }
                    },
                    hide: function () {
                        var currTooltip = $(this.popup.wrapper).find('.k-tooltip');
                        if (currTooltip.hasClass("tooltipWrap")) {
                            currTooltip.removeClass("tooltipWrap");                           
                        }
                        currTooltip.offset({ top: oldTooltipTop });
                    },
                    content: function (e) {
                        e.sender.content.parent().addClass('scenario-list-tooltip');                       
                        var dataItem = $("#scenarioList").data("kendoGrid").dataItem(e.target.closest("tr"));
                        return $template(dataItem);
                    },
                    animation: false
                }).on('mouseout', function (e) {
                    scenarioListTooltip.data('kendoTooltip').hide();
                });

                $("#scenarioList").on("mousemove", function (e) {
                    lastMouseX = e.pageX;
      
                    if (lastMouseX >= maxMoveLimit) {
                        lastMouseX = maxMoveLimit;
                    }

                    $(".scenario-list-tooltip").parent().css({
                        left: lastMouseX + 60
                    });                    
                });

                this.refreshGrid();
                athoc.iws.scenario.list.bindSelectAll();
            },

            reInitializeButtons: function () {
                //$("#btn_delete").addClass("disabled");
                //$("#btn_duplicate").addClass("disabled");
                athoc.iws.scenario.list.ViewModel.set("FilterDisabled", true);
                //$("#btn_filter").addClass("disabled");
            },

            refreshGrid: function () {
                //show the loader when we make a request to the server...
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.table-crown-wrap'), imageURL: athoc.iws.scenario.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: athoc.iws.scenario.resources.General_LoadingMessage }).showLoader();
                //Per telerik, this will set the page only after datasource refreshes.
                datasource.one("change", function () {
                    //pagination needs to be reset after a reload
                    this.page(1);
                });
                datasource.read();
            },
            OnDataBound: function () {
                athoc.iws.scenario.list.bindCheckboxChanged();
                $("#scenarioList tbody").find("tr").attr("tabindex", "0");
                // this.pager.element.hide();

                //if ($("#senario-select-all").is(':checked')) {
                //    $(".senario-select").prop('checked', true);
                //}

                var grid = $("#scenarioList").data("kendoGrid");
                var data = grid.dataSource.data();

                $(grid.tbody).unbind("click");

                $(grid.tbody).on("click", "td", function (e) {

                    var row = $(this).closest("tr");
                    var rowIdx = $("tr", grid.tbody).index(row);
                    var colIdx = $("td", row).index(this);

                    if (colIdx > 1 && colIdx < 5) {
                        var view = grid.dataSource.view();
                        var model = view[rowIdx];
                        athoc.iws.scenario.viewScenarioDetail(model.ScenarioId);
                    }

                    e.stopPropagation();

                });

                $(grid.tbody).on("keypress", "tr", function (e) {

                    var code = e.keyCode || e.which;

                    if (code == 13) {
                        var row = $(this);
                        var rowIdx = $("tr", grid.tbody).index(row);
                        var model = data[rowIdx];
                        athoc.iws.scenario.viewScenarioDetail(model.ScenarioId);
                    }
                });

                if (athoc.iws.scenario.list.IsRightToLeft) {
                    $("#scenarioList").find('.pull-right').addClass('pull-left');
                    $("#scenarioList").find('.pull-right').removeClass('pull-right');
                }
            },

            bindSelectAll: function () {
                $("#senario-select-all").change(function () {
                    //change the underlying observable...
                    var checked = $(this).is(':checked');
                    var grid = $('#scenarioList').data().kendoGrid;
                    //dataSource.view() returns the page not the entire dataset.
                    $.each(grid.dataSource.view(), function (i, item) {
                        if (!(item.IsDefaultforNewAlert || item.IsDefaultforNewScenario || item.IsSystem))
                            item.IsChecked = checked;
                    });
                    grid.refresh();//update the grid...
                    athoc.iws.scenario.list.updateSelectedTotal();
                    //$(".senario-select").prop('checked', $(this).is(':checked'));
                });
            },

            bindCheckboxChanged: function () {
                var grid = $('#scenarioList').data().kendoGrid;
                grid.tbody.on("change", ".senario-select", function (e) {
                    var row = $(e.target).closest("tr");
                    var item = grid.dataItem(row);
                    item.IsChecked = $(e.target).is(":checked");
                    athoc.iws.scenario.list.retainSelectAll();
                    athoc.iws.scenario.list.updateSelectedTotal();
                });
            },

            retainSelectAll: function () {
                var items = datasource.view();
                //get the non selectable items for the current page.
                var nonSelectable = $.grep(items, function (v) {
                    return (v.IsDefaultforNewAlert || v.IsDefaultforNewScenario || v.IsSystem);
                });
                //get the selected items for the current page.
                var selected = $.grep(items, function (v) {
                    return v.IsChecked;
                });
                //if the selected count matches the current page size - the non selectable count
                //then 'select all' should be checked.
                var checked = selected.length > 0 && (items.length - nonSelectable.length) == selected.length;
                $("#senario-select-all").prop('checked', checked);
            },

            updateSelectedTotal: function () {
                var items = datasource.data();
                var r = $.grep(items, function (v) {
                    return v.IsChecked;
                });
                athoc.iws.scenario.list.toggleButtonStates(r.length);
                athoc.iws.scenario.list.ViewModel.set("SelectedCount", r.length);
            },

            getSingleSelection: function () {
                var items = datasource.data();
                var selected = $.grep(items, function (v) {
                    return v.IsChecked;
                });

                if (selected.length == 1) {
                    return selected[0].ScenarioId;
                }

                return -1;
            },
            toggleButtonStates: function (count) {
                if (count < 1) {
                    athoc.iws.scenario.list.ViewModel.set("DupDisabled", true);
                    athoc.iws.scenario.list.ViewModel.set("DelDisabled", true);
                }
                else if (count == 1) {
                    athoc.iws.scenario.list.ViewModel.set("DupDisabled", false);
                    athoc.iws.scenario.list.ViewModel.set("DelDisabled", false);
                }
                else {
                    athoc.iws.scenario.list.ViewModel.set("DupDisabled", true);
                    athoc.iws.scenario.list.ViewModel.set("DelDisabled", false);
                }
            },
            deleteScenariosFromList: function () {
                var items = datasource.data();
                var selected = $.grep(items, function (v) {
                    return v.IsChecked;
                });

                var selectedIds = _.pluck(selected, "ScenarioId");
                var selectedNames = _.pluck(selected, "Name");



                var self = this;
                var deleteSuccessCallback = function () {
                    self.refreshGrid();
                }
                athoc.iws.scenario.deleteScenario(selectedIds, selectedNames, deleteSuccessCallback);
            }
        };
    }();
}