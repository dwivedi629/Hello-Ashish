﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.scenario = athoc.iws.scenario || {};

if (athoc.iws.scenario) {
    athoc.iws.scenario.publisher = function () {
        var datasource = null;
        var sortState;
        var filtered = false;
        return {
            IsRightToLeft: false,

            ViewModel: {},

            loadViewModel: function () {
                this.ViewModel = kendo.observable(
                 {
                     TotalCount: 0,
                     ChannelId: -1,
                     SearchText: "",
                     ExcludeSystemScenarios: true,
                     FilterDisabled: true,
                     Channels: { Id: -1, Name: athoc.iws.scenario.resources.Scenario_List_ChannelAll },
                     FilterScenarioList: function (e) {
                         //only update when enter key is pressed and when the apply button is clicked
                         if ($.hotkeys.enter(e) || e.target.id == "btn_filter") {
                             filtered = true;
                             athoc.iws.scenario.publisher.refreshGrid();
                         }
                         if (e.target.id == "btn_filter")
                             $("#btn_clear").focus();
                     },
                     ClearFilters: function (e) {
                         this.set("ChannelId", -1);
                         this.set("SearchText", "");
                         athoc.iws.scenario.publisher.refreshGrid();
                         //$("#txtSearch").blur(); fix to 6139 and removing it fixes 6283
                         var sp = $("#channels").data("selectpicker");
                         if (sp) {
                             sp.refresh();
                         }
                         e.preventDefault();
                     },
                 });

                //make a seperate call to load channels since we are using standard <select>
                $.ajax({
                    cache: false,
                    url: athoc.iws.scenario.urls.GetChannelsUrl,
                    success: function (d) {
                        d.splice(0, 0, { Id: -1, Name: athoc.iws.scenario.resources.Scenario_List_ChannelAll });
                        athoc.iws.scenario.publisher.ViewModel.set("Channels", d);
                        $("#channels").selectpicker();
                    },
                    error: function (e) {
                        athoc.iws.scenario.list.handleError(e);
                    },
                });
            },

            load: function () {
                $("#btn_new").click(function () {                  
                   
                    athoc.iws.publishing.createRequest("/athoc-iws/alertmanager?nav=c&source=p");                  
                });

                this.loadViewModel();
                kendo.bind($(".kendoBound"), this.ViewModel);

                this.createScenarioPublisherGrid();

                var gridHeader = $(".kgrid-fix-header").find(".k-grid-header");
                if (gridHeader) {
                    gridHeader.addClass('table-header affix');
                }

                $(".kendo-mini-pager").removeClass("k-pager-wrap");
                $(".kendo-mini-pager").removeClass("k-widget");
                $(".kendo-mini-pager").removeClass("k-floatwrap");

                this.ViewModel.bind("change", function (e) {
                    switch (e.field) {
                        case "ChannelId":
                        case "SearchText":
                            //if any filter field is changed, we enable the apply filter button
                            //$("#btn_filter").removeClass("disabled");
                            athoc.iws.scenario.publisher.ViewModel.set("FilterDisabled", false);
                            break;
                    }
                });

            },

            handleError: function (e) {
                if (e != undefined && e.status == 401 || (e!=undefined && e.xhr!=undefined && e.xhr.status==401)) {
                    window.onbeforeunload = null;
                    window.location = window.location;
                } else {
                    $('#listMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                }
            },

            createScenarioPublisherGrid: function () {

                datasource = new kendo.data.DataSource({
                    transport: {
                        read: {
                            url: athoc.iws.scenario.urls.GetScenarioListUrl,
                            cache: false,
                            dataType: "json",
                            contentType: "application/json; charset=utf-8",
                            type: "POST"
                        },
                        parameterMap: function (options) {
                            $.extend(options, athoc.iws.scenario.publisher.ViewModel);
                            return kendo.stringify(options);
                        },
                    },
                    requestEnd: function (e) {
                        $.AjaxLoader.hideLoader();
                        if (e.response) {
                            athoc.iws.scenario.publisher.ViewModel.set("TotalCount", e.response.length);
                            //reset all buttons
                            athoc.iws.scenario.publisher.reInitializeButtons();
                        }
                    },
                    sort: { field: "Name", dir: "asc" },
                    pageSize: 50,
                    error: function (e) {
                        athoc.iws.scenario.publisher.handleError(e);
                    },
                    change: function (e) {
                        var newState = JSON.stringify(this.sort());
                        if (newState != sortState) {
                            sortState = newState;
                            e.preventDefault();
                            //when sort changes, go to first page.
                            this.page(1);
                        }
                        //scrolling to the top when paging and sorting.
                        $("html,body").scrollTop(0);
                    }
                });

                $("#pageInfo").kendoPager({
                    dataSource: datasource,
                    autoBind: false,
                    numeric: false,
                    previousNext: false,
                    messages: {
                        display: athoc.iws.scenario.resources.Scenario_List_PageInfo,
                        empty: athoc.iws.scenario.resources.Scenario_List_PageInfo_NoRecords
                    }
                });

                var grid = $("#scenarioList").kendoGrid({
                    dataSource: datasource,
                    autoBind: false,
                    //navigatable: true,
                    sortable: {
                        allowUnsort: false
                    },
                    pageable: {
                        refresh: false,
                        pageSizes: true,
                        pageSizes: [20, 50, 100],
                        buttonCount: 5,
                        messages: {
                            display: $.htmlDecode(athoc.iws.scenario.resources.Scenario_List_PageInfo),
                            empty: $.htmlDecode(athoc.iws.scenario.resources.Scenario_List_PageInfo_NoRecords),
                            itemsPerPage: $.htmlDecode(athoc.iws.scenario.resources.AtHoc_Pager_Message_Items_Per_Page),
                            first: $.htmlDecode(athoc.iws.scenario.resources.AtHoc_Pager_Message_Go_To_The_First_Page),
                            previous: $.htmlDecode(athoc.iws.scenario.resources.AtHoc_Pager_Message_Go_To_The_Previous_Page),
                            next: $.htmlDecode(athoc.iws.scenario.resources.AtHoc_Pager_Message_Go_To_The_Next_Page),
                            last: $.htmlDecode(athoc.iws.scenario.resources.AtHoc_Pager_Message_Go_To_The_Last_Page)
                        }
                    },
                    columns:
                            [
                                {
                                    field: "ScenarioId",
                                    hidden: true
                                },
                                {
                                    field: "IsReadyForPublish",
                                    title: athoc.iws.scenario.resources.Scenario_List_Ready_Publish,
                                    headerAttributes: { "title": athoc.iws.scenario.resources.Scenario_List_Ready_Publish },
                                    template: $("#publish-template").html(),
                                    width: 135
                                },
                                {
                                    field: "Name",
                                    title: athoc.iws.scenario.resources.Scenario_List_Name,
                                },
                                {
                                    field: "ChannelName",
                                    title: athoc.iws.scenario.resources.Scenario_List_ChannelName,
                                    template: '<span class="cellTooltip" title="#=ChannelName#">#=ChannelName#</span>',
                                    headerAttributes: { "colspan": "2" },
                                    hidden: !(athoc.iws.publishing.settings.IsChannelSupported) //hide "Channel" for affiliate VPS
                                },
                                {
                                    template: $("#edit-alert").html(),
                                    sortable: false,
                                    width: 110,
                                    headerAttributes: { "style": "display:none" }
                                }
                            ],
                    dataBound: athoc.iws.scenario.publisher.OnDataBound,
                }).data().kendoGrid;

                var lastMouseX, oldTooltipTop;
                var windowWidth, maxMoveLimit;
                windowWidth = $(window).width();
                maxMoveLimit = windowWidth - 650 - 60 - 50;   // 650px is the max-width of tooltip,
                                                              // 60px space between tooltip and cursor
                                                              // 50px to adjust padding and box shadow
                var $template = kendo.template($("#scenario-tooltip-template").html());
                var scenarioListTooltip = $("#scenarioList").kendoTooltip({
                    filter: "td:nth-child(3)", //this filter selects the 2nd column cells
                    position: "right",
                    show: function () {
                        $(this.popup.wrapper).css({
                            left: lastMouseX + 60
                        });
                        var currTooltip = $(this.popup.wrapper).find('.k-tooltip');                       
                        if (currTooltip.width() >= 580) {                           
                            currTooltip.addClass("tooltipWrap");                          
                        }                     
                        oldTooltipTop = currTooltip.offset().top;
                        var tooltipTopFromWindow = oldTooltipTop - $(window).scrollTop();
                        var tooltipHeight = currTooltip.outerHeight();
                        var tooltipTopAndHeight = tooltipTopFromWindow + tooltipHeight;
                        var windowHeight = $(window).height();
                        if (tooltipTopAndHeight >= windowHeight) {
                            var newTooltipTop = oldTooltipTop - (tooltipTopAndHeight - windowHeight) - 5;
                             currTooltip.offset({ top: newTooltipTop });
                        }
                    },
                    hide: function () {
                        var currTooltip = $(this.popup.wrapper).find('.k-tooltip');
                        if (currTooltip.hasClass("tooltipWrap")) {
                            currTooltip.removeClass("tooltipWrap");                           
                        }
                        currTooltip.offset({ top: oldTooltipTop });
                    },
                    content: function (e) {
                        e.sender.content.parent().addClass('scenario-publisher-tooltip');                      
                        var dataItem = $("#scenarioList").data("kendoGrid").dataItem(e.target.closest("tr"));
                        return $template(dataItem);
                    },
                    animation: false
                }).on('mouseout', function (e) {
                    scenarioListTooltip.data('kendoTooltip').hide();
                });

                $("#scenarioList").on("mousemove", function (e) {
                    lastMouseX = e.pageX;
                    if (lastMouseX >= maxMoveLimit) {
                        lastMouseX = maxMoveLimit;
                    }
                    $(".scenario-publisher-tooltip").parent().css({
                        left: lastMouseX + 60
                    });
                });

                this.refreshGrid();
            },

            editAlert: function (id) {
                athoc.iws.publishing.createRequest("/athoc-iws/alertmanager?nav=c&source=p&id=" + id);
              
            },

            //publish alert
            publishAlert: function (id) {

                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $(window), imageURL: athoc.iws.scenario.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();

                var dlSuccess = function (data) {
                    if (data.Success) {
                        if (!data.Status) {

                            athoc.iws.publishing.view.PublishScenario(id, "publisher");
                        } else
                            athoc.iws.scenario.publisher.editAlert(id);

                    };


                };
                var dlAjaxOption =
               {
                   type: "POST",
                   url: "/athoc-iws/Publishing/GetScenarioPlaceholdersStatus?id=" + id
               }
                var ajaxOptions = $.extend({}, AjaxUtility(null, dlSuccess).ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);

            },

            reInitializeButtons: function () {
                athoc.iws.scenario.publisher.ViewModel.set("FilterDisabled", true);
            },

            refreshGrid: function () {
                //show the loader when we make a request to the server...
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.table-crown-wrap'), imageURL: athoc.iws.scenario.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();
                //Per telerik, this will set the page only after datasource refreshes.
                datasource.one("change", function () {
                    //pagination needs to be reset after a reload
                    this.page(1);
                });
                datasource.read();
            },

            OnDataBound: function () {
                $("#scenarioList tbody").find("tr").attr("tabindex", "0");

                var grid = $("#scenarioList").data("kendoGrid");

                if (athoc.iws.scenario.publisher.IsRightToLeft) {
                    $("#scenarioList").find('.pull-right').addClass('pull-left');
                    $("#scenarioList").find('.pull-right').removeClass('pull-right');
                }

                var colCount = $("#scenarioList").find('.k-grid-header colgroup > col').length;
                if (grid.dataSource.view().length == 0 && !filtered) {
                    $("#scenarioList").find('.k-grid-content tbody')
                        .append('<tr class="kendo-data-row"><td colspan="' +
                            colCount +
                            '" style="text-align:center;height:200px"><b>' +
                            kendo.format(athoc.iws.scenario.resources.QuickPublish_EmptyDataMsg, athoc.iws.scenario.urls.ScenarioMgrUrl) +
                            '</b></td></tr>');
                }
            },
        };
    }();
}