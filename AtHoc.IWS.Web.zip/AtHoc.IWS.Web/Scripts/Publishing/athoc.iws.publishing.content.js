﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};

if (athoc.iws.publishing) {
    athoc.iws.publishing.content = function () {
        return {
            viewModel: {
                data: ko.observable(),
                ResponseName: ko.observable(''), // to display selected response in the readonly view.
                status: ko.observable('ready'),
                statusTooltip: ko.observable(athoc.iws.publishing.resources.Publishing_Section_Ready_Tooltip),
                titleLength: ko.observable(0),
                bodyLength: ko.observable(0),
                severityVisible: ko.observable(true),
                typeVisible: ko.observable(true),
                context: 0,
                responseChange: function (index, data) {
                    var isValid = false;
                    var chngText = "";
                    athoc.iws.publishing.content.dataChanged();
                    var options = athoc.iws.publishing.content.viewModel.data.ResponseOptions;
                    for (var i = 0; i < options().length; i++) {
                        isValid = options()[i].ResponseText.isValid();
                        if (i == index) chngText = options()[i].ResponseText();
                    }
                    if (isValid)
                        athoc.iws.publishing.fillcount.responseChange(index, chngText);

                    return isValid;
                },

                bindContent: function (SeverityId, TypeId, ResponseOptionId) {
                    $("#publishing-content-edit").find("#severityList").val(SeverityId).change();
                    $("#publishing-content-edit").find("#typeList").val(TypeId).change();
                    $("#publishing-content-edit").find("#responseList").val(ResponseOptionId).change();
                },

                selectLanguage: function (data, event) {
                    var selLanguage = $("#lang-dropdown");
                    selLanguage.css({ right: '-70px' });
                    selLanguage.toggle();
                    event.stopPropagation();
                },

                changeLanguage: function (data, event) {
                    var lang = $(event.target).attr('data-settings-value');
                    athoc.iws.publishing.content.viewModel.data.Local(lang);
                    var selLanguage = $("#lang-dropdown");
                    selLanguage.hide();
                },

                localDisplay: ko.observable('EN (US)'),
                localDisplayTooltip: ko.observable('English (United States)'),

                gotoTargetUrl: function (data, event) {
                    var url = athoc.iws.publishing.content.viewModel.data.TargetUrl;
                    if (!url.isValid() || url().trim().length == 0) {
                        return;
                    }

                    window.open(athoc.iws.publishing.content.viewModel.data.TargetUrl(), '_blank');
                },

                triggerClick: function (data, event) {
                    var keyCode = event.which || event.keyCode;
                    if (keyCode == 13) {
                        $(event.target).trigger("click");
                    }
                },

                addResponseOption: function () {
                    var model = athoc.iws.publishing.content.viewModel;
                    model.data.ResponseOptions.push(new athoc.iws.publishing.content.ResponseOptionItem({ ResponseText: '', CallBridgeNumber: '', ShowCallBridge: false, PassCode: '', ConferenceUrl: '' }));
                },

                removeResponseOption: function (index) {
                    if (!athoc.iws.scenario.settings.isFillCountEnabled)
                        athoc.iws.publishing.content.viewModel.deleteResponseOption(index);
                    else if (athoc.iws.scenario.settings.isFillCountEnabled && athoc.iws.publishing.fillcount.setFillCountOnResponseDelete(index))
                        athoc.iws.publishing.content.viewModel.deleteResponseOption(index);
                },

                deleteResponseOption: function (index) {
                    var model = athoc.iws.publishing.content.viewModel;
                    model.data.ResponseOptions.splice(index, 1);
                    if (model.data.ResponseOptionId() == 0 && model.data.ResponseOptions().length == 0) {
                        model.data.ResponseOptions.push(new athoc.iws.publishing.content.ResponseOptionItem({ ResponseText: '', CallBridgeNumber: '', ShowCallBridge: false, PassCode: '', ConferenceUrl: '' }));
                    }
                },

                //geo location
                isGeoSelected: ko.observable(false),

                geoImageUrl: ko.observable(''),

                addLocation: function () {
                    athoc.iws.publishing.geo.add();
                },

                editLocation: function () {
                    athoc.iws.publishing.geo.edit();
                },

                removeLocation: function () {
                    athoc.iws.publishing.geo.remove();
                },

                //Publishing event as alert
                inboxEvent: null,
            },
            responseOptionPreviousId: -1,
            getCharCount: function (str) {
                var result = 0;
                if (str !== undefined) {
                    for (var n = 0; n < str.length; n++) {
                        var charCode = str.charCodeAt();
                        if (typeof charCode === "number") {
                            if (charCode < 128)
                            { result = result + 1; }
                            else if (charCode < 2048)
                            { result = result + 2; }
                            else if (charCode < 65536)
                            { result = result + 3; }
                            else if (charCode < 2097152)
                            { result = result + 4; }
                            else if (charCode < 67108864)
                            { result = result + 5; }
                            else
                            { result = result + 6; }
                        }
                    }
                }
                return result;
            },

            lengthValidation: function (str, minChar, maxChar) {
                if (str.length < minChar[1] || str.length > minChar[2]) {
                    return false;
                }
                return true;
            },

            //Readonly view model
            ReadonlyViewModel:
                        {
                            data: ko.observable(),
                            alertTitle: ko.observable(''),
                            bodyWithLineBreak: ko.observable(''),
                            isGeoSelected: ko.observable(false),
                        },
            //is model changed
            isChanged: false,

            phBody: null,

            init: function () {
                if (athoc.iws.publishing.settings.IsPlaceholderSupported) {
                    //var list = context == 0 ? athoc.iws.publishing.placeHolderItems.filter(function (i) { return i.IsSystem; }) : athoc.iws.publishing.placeHolderItems;
                    require(["publishing/Placeholder/Placeholder"], function (Placeholder) {
                        var txt = $("#content-title")[0];
                        var options = { textField: txt, items: athoc.iws.publishing.placeHolderItems, isPA: athoc.iws.publishing.isPA == undefined ? false : true }
                        //var list = context }
                        var ph = new Placeholder(options, $("#divTitlePlaceholder", txt.parentNode)[0]);
                        ph.startup();
                    });

                    require(["publishing/Placeholder/Placeholder"], function (Placeholder) {
                        var txt = $("#content-body")[0];
                        var options = { textField: txt, items: athoc.iws.publishing.placeHolderItems, isPA: athoc.iws.publishing.isPA == undefined ? false : true }
                        athoc.iws.publishing.content.phBody = new Placeholder(options, $("#divBodyPlaceholder", txt.parentNode)[0]);
                        athoc.iws.publishing.content.phBody.startup();
                    });
                    ko.bindingHandlers.addPlaceHolder = {
                        init: function (element) {
                            require(["publishing/Placeholder/Placeholder"], function (Placeholder) {
                                var txt = element;
                                var options = { textField: txt, items: athoc.iws.publishing.placeHolderItems, isStatic: true, isPA: athoc.iws.publishing.isPA == undefined ? false : true }
                                var ph = new Placeholder(options, $(".roPh", txt.parentNode)[0]);
                                ph.startup();
                            });
                        },
                        update: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
                            if (bindingContext.$parent.data.ResponseOptionId() > 0) {
                                $(element).nextAll("span:first").hide();
                            }
                            else
                                $(element).nextAll("span:first").show();
                        }
                    };
                }
            },

            //set the tooltip position for title and body input fields.
            _setTooltipPosition: function (inputField) {           
                var tooltipId = inputField + "-tooltip-template";
                var tooltip = $(tooltipId);
                var tooltipHeight = $('#content-title-tooltip-template').height();
                var caretHeight = 7;
                tooltip.css({ top:  - (tooltipHeight + caretHeight) + 'px', right: '230px' });
                setTimeout(function () { tooltip.show(); }, 50);
            },

            //this method will be called when new data will be available for this section for binding
            bind: function (data, context) {

                //IF alert is created from event - Forward Alert
                if (athoc.iws.publishing.content.viewModel.inboxEvent != null && athoc.iws.publishing.content.viewModel.inboxEvent.IsEvent) {
                    var event = athoc.iws.publishing.content.viewModel.inboxEvent;
                    //Decode Inbox Title and Body -
                    data.Title = $.htmlDecode(event.Title);
                    data.Body = $.htmlDecode(event.Body);
                    var targetUrl = '';

                    if (event.Link && event.Link != "null") {
                        targetUrl = event.Link;
                    }
                    data.TargetUrl = targetUrl;
                    data.TypeId = event.TypeId;
                    data.SeverityId = event.SeverityId;
                    data.Type = event.Type;
                    data.Severity = event.Severity;


                    //data.SeverityName = event.SeverityName;

                    if (event.Location == "{}")
                        data.LocationGeo = null;
                    else
                        data.LocationGeo = event.Location;
                }

                var current = athoc.iws.publishing.content;

                if ($("#dbChooser").length > 0) {
                    current.createDropBoxButton(data.TargetUrl);
                }

                current.viewModel.data = ko.mapping.fromJS(data, athoc.iws.publishing.content.getValidation());
                current.viewModel.context = context;
                var model = athoc.iws.publishing.content.viewModel.data;
                current.updateLocal();

                //Rebind response options so validation kicks-off
                current.viewModel.data.ResponseOptions.removeAll();
                $.each(data.ResponseOptions, function (index, value) {
                    current.viewModel.data.ResponseOptions.push(new athoc.iws.publishing.content.ResponseOptionItem({ ResponseText: value.ResponseText, CallBridgeNumber: $.htmlDecode(value.CallBridgeNumber), ShowCallBridge: $.htmlDecode(value.ShowCallBridge), PassCode: $.htmlDecode(value.PassCode), ConferenceUrl: value.ConferenceUrl }));
                });

                //remove previous dropdown

                $("#publishing-content-edit").find(".lang-list").html("");
                $("#publishing-content-edit").find(".response-list").html("");
                $("#publishing-content-edit").find(".severity-list").html("");
                $("#publishing-content-edit").find(".content-type").html("");


                /*save typeid,severityid and responseoption before ko.applybindings as 
                that is causing to reset the bindings 
                TODO:research why comboxbox bindings with ko is not working
                */
                var typeid = athoc.iws.publishing.content.viewModel.data.TypeId();
                var severityid = athoc.iws.publishing.content.viewModel.data.SeverityId();
                var responseOption = athoc.iws.publishing.content.viewModel.data.ResponseOptionId();

                if ((athoc.iws.publishing.contextName == "AccountEvent" || athoc.iws.publishing.contextName == "AccountTemplate") && athoc.iws.publishing.detail.viewModel) {
                    current.viewModel.severityVisible(athoc.iws.publishing.detail.viewModel.ScenarioSettings.AccountabilityWorkflow.IsContentSeverityVisible
                    );
                    current.viewModel.typeVisible(athoc.iws.publishing.detail.viewModel.ScenarioSettings.AccountabilityWorkflow.IsContentTypeVisible
                    );
                }

                //Binding
                ko.cleanNode($("#publishing-content-edit").get(0));
                ko.applyBindings(athoc.iws.publishing.content.viewModel, $("#publishing-content-edit").get(0));

                athoc.iws.publishing.content.viewModel.bindContent(severityid, typeid, responseOption);

                //for some reason bootstrap creates another control
                $("#publishing-content-edit").find(".bootstrap-select.response-list").eq(1).remove();
                $("#publishing-content-edit").find(".bootstrap-select.severity-list").eq(1).remove();
                $("#publishing-content-edit").find(".bootstrap-select.content-type").eq(1).remove();


                if (athoc.iws.publishing.contextName == "AccountEvent") {
                    $('#responseList').attr('disabled', true);
                    $('#responseList').selectpicker('refresh');
                }

                if (model.Title() == null) {
                    athoc.iws.publishing.content.viewModel.titleLength(0);
                } else {
                    //athoc.iws.publishing.content.viewModel.titleLength(athoc.iws.publishing.content.getCharCount(model.Title()));
                    athoc.iws.publishing.content.viewModel.titleLength(model.Title().length);
                }

                if (model.Body() == null) {
                    athoc.iws.publishing.content.viewModel.bodyLength(0);
                } else {
                    athoc.iws.publishing.content.viewModel.bodyLength(model.Body().length);
                }

                $("#content-title").focus(function () {
                    athoc.iws.publishing.content._setTooltipPosition("#content-title");
                });

                $("#content-body").focus(function () {
                    athoc.iws.publishing.content._setTooltipPosition("#content-body");
                });

                $(document).click(function () {
                    var selLanguage = $(".lang-filter");
                    selLanguage.hide();
                });

                $("#lang-dropdown").click(function (e) { e.stopPropagation(); });

                $("#content-title").on('change keyup paste', function () {
                    var vm = athoc.iws.publishing.content.viewModel;
                    vm.titleLength($(this).val().length);
                });

                //IE-10 Clear event
                $("#content-title").on("mouseup", function (e) {
                    var $input = $(this),
                        oldValue = $input.val();

                    if (oldValue == "") return;

                    setTimeout(function () {
                        var newValue = $input.val();

                        if (newValue == "") {
                            var vm = athoc.iws.publishing.content.viewModel;
                            vm.titleLength(0);
                        }
                    }, 1);
                });

                $("#content-body").on('change keyup paste', function () {
                    var vm = athoc.iws.publishing.content.viewModel;
                    vm.bodyLength($(this).val().length);
                });

                //IE-10 Clear event
                $("#content-body").on("mouseup", function (e) {
                    var $input = $(this),
                        oldValue = $input.val();

                    if (oldValue == "") return;

                    setTimeout(function () {
                        var newValue = $input.val();

                        if (newValue == "") {
                            var vm = athoc.iws.publishing.content.viewModel;
                            vm.bodyLength(0);
                        }
                    }, 1);
                });

                $("#content-title").focusout(function () {
                    var tooltip = $("#content-title-tooltip-template");                 
                    tooltip.hide();
                });

                $("#content-body").focusout(function () {
                    var tooltip = $("#content-body-tooltip-template");
                    tooltip.hide();
                });

                //Change events binding
                current.isChanged = false;

                model.Title.subscribe(function (newValue) {
                    current.dataChanged();
                    if (athoc.iws.alert != undefined) {
                        if (newValue == undefined || newValue.trim() == '') {
                            athoc.iws.alert.breadcrumbModel.updateTitle("Untitled", undefined, undefined, 'alertDetail');
                        } else {
                            athoc.iws.alert.breadcrumbModel.updateTitle(newValue, undefined, undefined, 'alertDetail');
                        }
                    }
                });
                model.Body.subscribe(function (newValue) { current.dataChanged(); });
                model.TargetUrl.subscribe(function (newValue) {

                    athoc.iws.publishing.content.createDropBoxButton(newValue);

                    current.dataChanged();

                    var prefix = 'http://';
                    var httpsPrefix = "https://";

                    newValue = newValue.trim();
                    model.TargetUrl(newValue);
                    var url = newValue.toLowerCase().trim();
                    if (url.length == 0 || url.substr(0, httpsPrefix.length).toLowerCase() == httpsPrefix)
                        return;

                    if (url.substr(0, prefix.length) !== prefix) {
                        newValue = prefix + newValue.trim();
                        model.TargetUrl(newValue);
                    } else if (newValue.indexOf(' ') >= 0) {
                        model.TargetUrl(newValue.trim());
                    }

                });
                model.Local.subscribe(function (newValue) {
                    current.dataChanged();
                    current.updateLocal();
                    athoc.iws.publishing.personalDeviceOptions.changeBasedOnLocale(newValue);
                });
                model.SeverityId.subscribe(function (newValue) {
                    current.dataChanged();
                    athoc.iws.publishing.personalDeviceOptions.changeBasedOnSeverity(newValue);
                });
                model.getSeverityNanmeFromId = function (severityId) {
                    var severityName = "";

                    var severities = athoc.iws.publishing.content.viewModel.data.Severities();

                    var found = $.grep(severities, function (severity) {
                        return severity.Id() == severityId;
                    });
                    if (found.length > 0)
                        severityName = found[0].Name();

                    return severityName;
                };
                model.SeverityName = ko.computed(function () {
                    var severityId = athoc.iws.publishing.content.viewModel.data.SeverityId();
                    return athoc.iws.publishing.content.viewModel.data.getSeverityNanmeFromId(severityId);
                    /*var severityName = "";

                    var severityId = athoc.iws.publishing.content.viewModel.data.SeverityId();
                    var severities = athoc.iws.publishing.content.viewModel.data.Severities();

                    var found = $.grep(severities, function (severity) {
                        return severity.Id() == severityId;
                    });
                    if (found.length > 0)
                        severityName = found[0].Name();

                    return severityName;
                    */
                });
                model.TypeId.subscribe(function (newValue) {
                    current.dataChanged();
                    var found = _.find(model.Types(), function (item) {
                        return (item.Id() == newValue);
                    });

                    if (found) {
                        model.CategoryType = found;
                    }

                });
                model.TypeName = ko.computed(function () {
                    var typeId = athoc.iws.publishing.content.viewModel.data.TypeId();
                    var types = athoc.iws.publishing.content.viewModel.data.Types();
                    try {
                        var typeName = $.grep(types, function (type) {
                            return type.Id() == typeId;
                        })[0].Name();
                        return typeName;

                    } catch (e) {
                        return "";
                    }

                });

                model.ResponseOptionId.subscribe(function (previousValue) {
                    if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId() > -1) {
                        athoc.iws.publishing.content.responseOptionPreviousId = previousValue;
                        athoc.iws.publishing.fillcount.reponseTypeChange();
                    }

                }, this, "beforeChange");

                model.ResponseOptionId.subscribe(function (previousValue) {
                    if (athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId() == -1) {
                        current.responseOptionChanged();
                    }
                });

                if (model.ResponseOptionId() == 0 && model.ResponseOptions().length == 0) {
                    model.ResponseOptions.push(new athoc.iws.publishing.content.ResponseOptionItem({ ResponseText: '', CallBridgeNumber: '', ShowCallBridge: false, PassCode: '', ConferenceUrl: '' }));
                }
                model.ResponseOptions.subscribe(function (newValue) { current.dataChanged(); });

                //bind geo location
                athoc.iws.publishing.geo.bind(model.LocationGeo(), athoc.iws.publishing.targetByUserArea, true);

                current.checkReadyNotReady();

                if (athoc.iws.publishing.content.phBody)
                    athoc.iws.publishing.content.phBody.adjustButton();

                if (model.Languages().length == 1) {
                    $(".btn-lang").attr("disabled", "disabled");
                }

                $("#publishing-content-edit").find(".content-type button").focus();

            },

            createDropBoxButton: function (url) {
                var options = {
                    success: function (files) {
                        athoc.iws.publishing.content.viewModel.data.TargetUrl(files[0].link);
                    }
                };
                try { // If dropbox not selected for current VPS then it'll skip
                    var button = Dropbox.createChooseButton(options);
                    $("#dbChooser").empty().append(button);


                    if ($("#dbChooser").find('.dropbox-dropin-btn').length > 0)
                        $("#dbChooser").find('.dropbox-dropin-btn')[0].innerHTML = '<span class="dropin-btn-status"></span>' + athoc.iws.publishing.resources.Publishing_Content_ChooseFromDropbox;


                }
                catch (e) { }
            },

            //this method will be called when data is required for updating
            getModel: function () {
                if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content != undefined && athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.Readonly)
                    return ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.Content)

                //Load geo json as string for geo targeting
                // todo: this check is for PA case where we load only preview mode, and have no LocationGeo
                // todo: review with Nishith
                if (athoc.iws.publishing.content.viewModel.data.LocationGeo) {
                    athoc.iws.publishing.content.viewModel.data.LocationGeo(athoc.iws.publishing.geo.getModel());
                    return ko.mapping.toJS(athoc.iws.publishing.content.viewModel.data);
                }
            },


            //setup validation
            getValidation: function () {
                if (athoc.iws.publishing.isPA == undefined ? false : true) {
                    athoc.iws.publishing.requiredtitlemessage = athoc.iws.publishing.resources.PA_Template_Process_Detail_Name_Length_ValidationMessage;
                    athoc.iws.publishing.requiredbodymessage = athoc.iws.publishing.resources.PA_Template_Process_Detail_Description_Length_ValidationMessage;
                } else {
                    athoc.iws.publishing.requiredtitlemessage = athoc.iws.publishing.resources.Publishing_Validation_Title;
                    athoc.iws.publishing.requiredbodymessage = athoc.iws.publishing.resources.Publishing_Validation_Body;
                }
                var validationMapping = {
                    Title: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                required: {
                                    params: true,
                                    message: athoc.iws.publishing.requiredtitlemessage
                                },
                                validation: {
                                    validator: athoc.iws.publishing.content.lengthValidation,
                                    message: athoc.iws.publishing.requiredtitlemessage,
                                    params: [this.value, 3, 100]
                                }
                            });
                        }
                    },
                    Body: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                validation: {
                                    validator: athoc.iws.publishing.content.lengthValidation,
                                    message: athoc.iws.publishing.requiredbodymessage,
                                    params: [this.value, 0, 4000]
                                }
                            });
                        }
                    },
                    //ResponseOptionId: {
                    //    create: function (options) {
                    //        return ko.observable(options.data).extend({
                    //            required: {
                    //                params: true,
                    //            }
                    //        });
                    //    }
                    //},
                    //TargetUrl: {
                    //    create: function (options) {
                    //        return ko.observable(options.data).extend({
                    //            validation: {
                    //                message: athoc.iws.publishing.resources.Publishing_Validation_TargetUrl,
                    //                validator: function (val) {
                    //                    if (val == undefined || val == '')
                    //                        return true;

                    //                    var isValid = true;
                    //                    var urlRegex = /(^|\s)((https?:\/\/)?[\w-]+(\.[\w-]+)+\.?(:\d+)?(\/^\S*)?)/i;
                    //                    var noSpaceRegex = /^[\S]*$/;
                    //                    isValid = val.match(urlRegex) && val.match(noSpaceRegex);
                    //                    return isValid;
                    //                },
                    //                params: [self],

                    //            },
                    //        });
                    //    }
                    //},
                    ResponseOptions: {
                        create: function (options) {
                            return new athoc.iws.publishing.content.ResponseOptionItem(options.data);
                        }
                    }
                };

                return validationMapping;
            },

            ResponseOptionItem: function (data) {
                var self = this;
                ko.mapping.fromJS(data, {}, self);
                self.ResponseText.extend({
                    maxLength: {
                        params: 64,
                        message: athoc.iws.publishing.resources.Publishing_Validation_ResponseOption
                    },
                    validation: {
                        validator: athoc.iws.publishing.content.DuplicateResponseOptionValidation,
                        message: athoc.iws.publishing.resources.Publishing_DuplicateResponseOption_ValidationMessage,
                        params: [athoc.iws.publishing.content.viewModel.data.ResponseOptions, self, 'ResponseText']
                    }
                });

                //self.CallBridgeNumber.extend({
                //    maxLength: {
                //        params: 64,
                //        message: athoc.iws.publishing.resources.Publishing_Validation_ResponseOption
                //    },
                //    //validation: {
                //    //    validator: athoc.iws.publishing.content.DuplicateResponseOptionValidation,
                //    //    message: athoc.iws.publishing.resources.Publishing_DuplicateResponseOption_ValidationMessage,
                //    //    params: [athoc.iws.publishing.content.viewModel.data.ResponseOptions, self, 'ResponseText']
                //    //}
                //});
            },

            DuplicateResponseOptionValidation: function (val, params) {

                var options = athoc.iws.publishing.content.viewModel.data.ResponseOptions;

                if (val == undefined || val == '' || options == undefined)
                    return true;

                //issue with grep switching to old way of looping
                //var numOccurences = $.grep(options(), function (elem) { return elem.Name() == val; }).length;

                var numOccurences = 0;
                for (var i = 0; i < options().length; i++) {
                    if (options()[i].ResponseText() == val)
                        numOccurences++;
                }

                return (numOccurences <= 1);

                //var isValid = true;
                //var responseOptions = athoc.iws.publishing.content.viewModel.data.ResponseOptions;
                //console.log(params);
                //console.log(responseOptions);

                //if (val == undefined || val == '' || responseOptions == undefined || responseOptions.length == 0)
                //    return isValid;

                //ko.utils.arrayFirst(params[0](), function (item) {
                //    if (val === item[params[2]]() && item !== params[1]) {
                //        isValid = false;
                //        return true;
                //    }
                //});
                //return isValid;
            },

            isLocationMandatory: function (forReadyStatus) {
                if (forReadyStatus) {
                    //TODO: Use following after implementing setting form PA
                    //if (athoc.iws.publishing.contextName == "Scenario" || athoc.iws.publishing.contextName == "AccountTemplate") {
                    if (athoc.iws.publishing.contextName == "Scenario" || athoc.iws.publishing.contextName == "AccountTemplate") {
                        if (athoc.iws.scenario.settings.viewModel.scenariosettings.Content.LocationMandatoryEnabled
                            && athoc.iws.publishing.geo.viewModel.isGeoSelected() == false) {
                            $('#location-mandatory').css("display", "");
                            return false;
                        }
                    }

                    //TODO: Use following after implementing setting form PA
                    //if (athoc.iws.publishing.contextName == "Alert" || athoc.iws.publishing.contextName == "AccountEvent") {
                    if (athoc.iws.publishing.contextName == "Alert" || athoc.iws.publishing.contextName == "AccountEvent") {
                        if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.LocationMandatoryEnabled
                            && athoc.iws.publishing.geo.viewModel.isGeoSelected() == false) {
                            $('#location-mandatory').css("display", "");

                            return false;
                        }
                    }
                }
                else
                    //TODO: Use following after PA setting
                    //if (athoc.iws.publishing.contextName == "Alert" || athoc.iws.publishing.contextName == "AccountEvent") {
                    if (athoc.iws.publishing.contextName == "Alert") {
                        if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.LocationMandatoryEnabled
                        && athoc.iws.publishing.geo.viewModel.isGeoSelected() == false) {
                            $('#location-mandatory').css("display", "");

                            return false;
                        }
                    }
                //TODO: Use following after PA setting
                //if (athoc.iws.publishing.contextName == "Scenario" || athoc.iws.publishing.contextName == "AccountTemplate") {
                if (athoc.iws.publishing.contextName == "Scenario") {
                    if (athoc.iws.scenario.settings.viewModel.scenariosettings.Content.LocationMandatoryEnabled
                            && athoc.iws.publishing.geo.viewModel.isGeoSelected() == false) {
                        $('#location-mandatory').css("display", "");
                        return false;
                    }
                }
                $('#location-mandatory').css("display", "none");
                return true;
            },

            //is model valid
            isValid: function () {
                var result = ko.validation.group(athoc.iws.publishing.content.viewModel.data, { deep: true });
                if (result().length > 0) {
                    result.showAllMessages(true);
                    $.AjaxLoader.hideLoader();
                    return false;
                }

                return true;
            },

            //is ready for publish
            isReadyToPublish: function () {
                return (this.viewModel.status() == 'ready');
            },


            //triggered on data changed
            dataChanged: function () {
                var current = athoc.iws.publishing.content;
                current.isChanged = true;
                current.checkReadyNotReady();
            },

            //set ready not-ready
            checkReadyNotReady: function () {
                var current = athoc.iws.publishing.content;
                if (current.isValid() && current.isLocationMandatory(true)) {
                    current.viewModel.status('ready');
                    current.viewModel.statusTooltip(athoc.iws.publishing.resources.Publishing_Section_Ready_Tooltip);
                } else {
                    current.viewModel.status('not-ready');
                    current.viewModel.statusTooltip(athoc.iws.publishing.resources.Publishing_Section_NotReady_Tooltip);
                }
                current.onReadyChange(current.viewModel.status() == 'ready' ? true : false);

                if (athoc.iws.publishing.contextName == "Alert" && athoc.iws.alert.test)
                    athoc.iws.alert.test.enableTestAlertButton(athoc.iws.publishing.content.isReadyToPublish());

                athoc.iws.publishing.detail.checkStatusChange();
            },

            //on response option change
            responseOptionChanged: function () {
                var current = athoc.iws.publishing.content;
                current.dataChanged();

                var model = current.viewModel;
                model.data.ResponseOptions.removeAll();

                var option = $.grep(model.data.ResponseOptionList(), function (e) { return e.Id() == model.data.ResponseOptionId(); });
                if (option.length == 1) {

                    $.each(option[0].Values(), function (index, value) {
                        model.data.ResponseOptions.push(new athoc.iws.publishing.content.ResponseOptionItem({ ResponseText: value, CallBridgeNumber: '', ShowCallBridge: false, PassCode: '', ConferenceUrl: '' }));
                    });
                }

                if (model.data.ResponseOptionId() == 0 && model.data.ResponseOptions().length == 0) {
                    model.data.ResponseOptions.push(new athoc.iws.publishing.content.ResponseOptionItem({ ResponseText: '', CallBridgeNumber: '', ShowCallBridge: false, PassCode: '', ConferenceUrl: '' }));
                }
            },

            //update local
            updateLocal: function () {
                var displayVal = '';
                var model = ko.mapping.toJS(athoc.iws.publishing.content.viewModel.data);
                for (var index = 0; index < model.Languages.length; index++) {
                    if (model.Languages[index].Code === athoc.iws.publishing.content.viewModel.data.Local()) {
                        displayVal = model.Languages[index].Name;
                        break;
                    };
                };
                athoc.iws.publishing.content.viewModel.localDisplay(displayVal);
                athoc.iws.publishing.content.viewModel.localDisplayTooltip(displayVal);

                //athoc.iws.publishing.content.updateLanguageTooltip();
                //if (displayVal == 'en-US') {
                //    displayVal = "EN (US)";
                //} else if (displayVal == 'ar-SA') {
                //    displayVal = "AR (SA)";
                //} else if (displayVal == 'fr-FR') {
                //    displayVal = "FR (FR)";
                //} else if (displayVal == 'ja-JP') {
                //    displayVal = "JA (JP)";
                //}

            },

            updateLanguageTooltip: function () {
                var displayVal = athoc.iws.publishing.content.viewModel.data.Local();
                if (displayVal == 'en-US') {
                    displayVal = "English (United States)";
                } else if (displayVal == 'ar-SA') {
                    displayVal = "Arabic (Saudi Arabia)";
                } else if (displayVal == 'fr-FR') {
                    displayVal = "French (France)";
                } else if (displayVal == 'ja-JP') {
                    displayVal = "Japanese (Japan)";
                }
                athoc.iws.publishing.content.viewModel.localDisplayTooltip(displayVal);
            },
            applyReadonlySettingsOnContent: function (data, targetDiv) {
                //var targetDiv = $("#alert-content-detail");
                if (data.Content != undefined && data.Content.ResponseOptions != undefined && data.Content.ResponseOptions.length > 0) {
                    var reponseOptions = [];
                    for (var i = 0; i < data.Content.ResponseOptions.length; i++) {
                        if (data.Content.ResponseOptions[i].ResponseText.trim() !== '') {
                            reponseOptions.push(data.Content.ResponseOptions[i]);
                        }
                    }
                    data.Content.ResponseOptions = reponseOptions;
                    var responseOptions = $.grep(data.Content.ResponseOptionList, function (e) { return e.Id == data.Content.ResponseOptionId; });
                    if (responseOptions && responseOptions.ResponseText)
                        athoc.iws.publishing.content.viewModel.ResponseName = responseOptions.ResponseText;
                }

                athoc.iws.publishing.content.ReadonlyViewModel.data = ko.mapping.fromJS(data);
                //adding linebreak for alert body
                try {
                    if (data.Content != undefined && data.Content.Body != undefined && data.Content.Body != null) {
                        athoc.iws.publishing.content.ReadonlyViewModel.bodyWithLineBreak($.htmlEncode(data.Content.Body.trim()).replace(/(?:\r\n|\r|\n)/g, '<br />'));
                    } else {
                        athoc.iws.publishing.content.ReadonlyViewModel.bodyWithLineBreak('');
                    }
                    athoc.iws.publishing.content.ReadonlyViewModel.alertTitle(data.Content.Title);
                }
                catch (e) { }
                //ko.cleanNode(targetDiv.get(0));
                // if (data.Content.LocationGeo != "" && data.Content.LocationGeo != undefined)
                //  athoc.iws.publishing.geo.readOnlyBind(data.Content.LocationGeo, true, true);

                //TODO: Readonly view of alert
                //ko.cleanNode(targetDiv.find(".content-section").get(0));
                //ko.applyBindings(athoc.iws.publishing.content.ReadonlyViewModel, targetDiv.find(".content-section").get(0));


            },

            onReadyChange: function (isReady) { },
        };
    }();
}