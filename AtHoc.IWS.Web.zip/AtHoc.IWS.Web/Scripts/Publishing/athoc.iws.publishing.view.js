﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};

if (athoc.iws.publishing) {
    athoc.iws.publishing.view = function () {
        return {
            objData: null,
            publishingModel: null,
            messages: [],
            readOnlyMap: null,
            context: "Alert",
            id: 0,
            summaryDivTrmplate: "<div class=\"summary-row ellipsis\" title='{1}'>{0}</div>",
            PresetDeviceGroupOptions: [], //used to store device option when targeting is read only 
            //view model! 
            viewModel: {
                audioFileName: ko.observable(),
                data: ko.observable(),
                alertTitle: ko.observable(''),
                bodyWithLineBreak: ko.observable(''),
                isGeoSelected: ko.observable(false),
                personalDeviceList: { Devices: ko.observableArray() },

                TargetedBlockerUsersList: [],
                TargetedGroupCount: ko.observable(0),
                BlockedGroupCount: ko.observable(0),
                TargetedUserCount: ko.observable(0),
                BlockedUserCount: ko.observable(0),
                QueryCriteriaCount: ko.observable(0),
                TargetedAreaCount: ko.observable(0),
                ContactinfoTotalCoveredNumber: ko.observable(new String("0")),
                ContactinfoTotalCoveredPercentage: ko.observable(new String("0")),
                ContactinfoNotCoveredNumber: ko.observable(new String("0")),
                ContactinfoNotCoveredPercentage: ko.observable(new String("0")),
                TotalUsers: ko.observable(new String("0")),
                loadTargetUsers: ko.observable(new String("true")),
                targetedNodes: [],
                showQuerySummary: function () {
                    if (athoc.iws.publishing.view.viewModel.QueryCriteriaCount() > 0) {
                        $("#dialogTargetSummaryPublish").find("#spanTitleDetailsPublish").text(athoc.iws.publishing.iut.resources.Publishing_TargetUsers_Advanced_Query);
                        var summaryDiv = $("#dialogTargetSummaryPublish").find("#targetingSummaryDetailPublish");
                        summaryDiv.html("");


                        var selections = ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetedCriteria.display);
                        var selectionsNoDisplay = ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetedCriteria.displayNoStyle);

                        _.each(selections, function (item, index) {
                            if (index != 0) {
                                summaryDiv.append("<div class=\"summary-row summary-operator-row\">" + athoc.iws.publishing.resources.Publishing_TargetUsers_Advanced_Query_Summary_And + "</div>");
                            }

                            summaryDiv.append(athoc.iws.publishing.view.summaryDivTrmplate.format(item, selectionsNoDisplay[index]));

                            //summaryDiv.append(athoc.iws.publishing.view.summaryDivTrmplate.format("<span class='bold'>" + item.entity.name + "</span>" + " " + item.operandName + " " + selValue, item.entity.name));
                            index += 1;
                        });
                        athoc.iws.alert.reviewandpublish.showModalonModal("#dialogTargetSummaryPublish");
                    }
                },

                //on number of map area clicked
                showAreaSummary: function () {
                    if (athoc.iws.publishing.view.viewModel.TargetedAreaCount() > 0) {
                        //Show map with objects in model window
                        athoc.iws.alert.reviewandpublish.showModalonModal("#dialogGeoPublish");
                    }
                },

                //show selected devices list
                showDeviceSummary: function () {
                    if (athoc.iws.publishing.view.viewModel.numberOfDevices() > 0) {
                        //show device summary
                        $("#personalDeviceSummaryDiv").html('');
                        ko.cleanNode($("#dialogPersonalDevicesSummary").get(0));
                        var groupedDevices = athoc.iws.publishing.targetUsers.SelectedGroupedDevices();
                        ko.applyBindings(groupedDevices, $("#dialogPersonalDevicesSummary").get(0));
                        $("#dialogPersonalDevicesSummary").modal("show");
                    }
                },

                showTargetedGroupSummary: function () {
                    if (athoc.iws.publishing.view.viewModel.TargetedGroupCount() > 0) {
                        $("#dialogTargetSummaryPublish").find("#spanTitleDetailsPublish").text(athoc.iws.publishing.iut.resources.Publishing_TargetUsers_ByGroups);
                        var summaryDiv = $("#dialogTargetSummaryPublish").find("#targetingSummaryDetailPublish");
                        var template = kendo.template($("#groupsummary-template-RP").html());
                        var result = template(athoc.iws.alert.reviewandpublish.TargetedGroupsFormatted());
                        summaryDiv.html(result);
                        athoc.iws.alert.reviewandpublish.showModalonModal("#dialogTargetSummaryPublish");
                    }
                },
                showBlockedGroupSummary: function () {
                    if (athoc.iws.publishing.view.viewModel.BlockedGroupCount() > 0) {
                        $("#dialogTargetSummaryPublish").find("#spanTitleDetailsPublish").text(athoc.iws.publishing.iut.resources.Publishing_TargetUsers_ByGroupsBlocked);
                        var summaryDiv = $("#dialogTargetSummaryPublish").find("#targetingSummaryDetailPublish");
                        var template = kendo.template($("#groupsummary-template-RP").html());
                        var result = template(athoc.iws.alert.reviewandpublish.BlockedGroupsFormatted());
                        summaryDiv.html(result);
                        athoc.iws.alert.reviewandpublish.showModalonModal("#dialogTargetSummaryPublish");
                    }
                },

                showTargetedUsersSummary: function () {
                    $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP").html('');
                    if (athoc.iws.publishing.view.viewModel.TargetedUserCount() > 0) {
                        athoc.iws.alert.reviewandpublish.showModalonModal("#targetedUsersSummaryRP");
                        athoc.iws.alert.reviewandpublish.showTargetedUsersSummary();
                        $("#targetedUsersSummaryRP").find("#spanTitleDetails").text(athoc.iws.publishing.iut.resources.Publishing_TargetUsers_ByUsers + '(' + this.TargetedUserCount() + ')');
                    }
                },

                showBlockedUsersSummary: function () {
                    $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP").html('');
                    if (athoc.iws.publishing.view.viewModel.BlockedUserCount() > 0) {
                        athoc.iws.alert.reviewandpublish.showModalonModal("#targetedUsersSummaryRP");
                        athoc.iws.alert.reviewandpublish.showBlockedUsersSummary();
                        $("#targetedUsersSummaryRP").find("#spanTitleDetails").text(athoc.iws.publishing.iut.resources.Publishing_TargetUsers_ByUsersBlocked + '(' + this.BlockedUserCount() + ')');
                    }
                },
                GetReachableUserList: function () {
                    if (athoc.iws.publishing.view.viewModel.ContactinfoTotalCoveredNumber() > 0)
                        athoc.iws.alert.reviewandpublish.LaunchContactInfoUserList(1);
                },

                GetUnReachableUserList: function () {
                    if (athoc.iws.publishing.view.viewModel.ContactinfoNotCoveredNumber() > 0)
                        athoc.iws.alert.reviewandpublish.LaunchContactInfoUserList(0);
                },
                DisplayUserList: function () {
                    if (athoc.iws.publishing.view.viewModel.TotalUsers() > 0) {
                        $("#readOnlyUserListTitle").html(athoc.iws.publishing.iut.resources.IUTReadOnly_AllUsers);
                        athoc.iws.alert.reviewandpublish.ShowUsersList(athoc.iws.alert.reviewandpublish.SessionId, -1, "", athoc.iws.publishing.view.viewModel.TotalUsers());
                    }
                },
            },

            //source of request
            source: '',

            showNotReadyError: true,

            PieChartObject: null,

            //Called from publisher/home page the id is scenarioId which to be published
            PublishScenario: function (id, source) {
                athoc.iws.publishing.view.showReviewAndPublish(true, id, "ScenarioPublisher");

                var loadUrl = athoc.iws.publishing.urls.CreateAlertFromScenarioUrl + "?id=" + id + "&loadTargetingTree=true";

                athoc.iws.publishing.view.loadFromUrl(loadUrl, true, "Scenario", id);

                if (source != undefined) {
                    if (source == "home") {
                        athoc.iws.publishing.source = "h";
                    } else {
                        athoc.iws.publishing.source = "p";
                    }
                }
            },

            //Called from alert list page the id is alertId which to be published
            PublishAlert: function (id) {
                athoc.iws.publishing.source = "p";
                athoc.iws.alert.action = "v";
                athoc.iws.alert.id = id;
                athoc.iws.publishing.view.showReviewAndPublish(true, id, "AlertManager");

                var loadUrl = athoc.iws.publishing.urls.GetAlertUrl + "?id=" + id + "&loadTargetingTree=true";

                athoc.iws.publishing.view.loadFromUrl(loadUrl, true, "Alert", id);
            },

            //Called from alert detail page the data is model for alert
            ReviewAndPublish: function (data) {
                if (data.Content.LocationGeo != null && data.Content.LocationGeo.length == 0)
                    data.Content.LocationGeo = athoc.iws.publishing.geo.getModel();
                athoc.iws.publishing.source = "a";
                athoc.iws.publishing.view.showReviewAndPublish(false, 0, "AlertDetail");

                data = athoc.iws.publishing.view.cleanEmptyMassDeviceCustomText(data);

                athoc.iws.publishing.view.bind(data, $("#dialogReviewAndPublish"));

                athoc.iws.publishing.view.replacePlaceholder();
            },

            //helper metod to cleanup mass device empty custom text
            cleanEmptyMassDeviceCustomText: function (data) {
                try {
                    if (data && data.MassDevices && data.MassDevices.length > 0) {
                        _.each(data.MassDevices, function (device) {
                            if (device && device.CustomText) {
                                device.CustomText = null;
                            }
                        });
                    }
                } catch (e) { }

                return data;
            },

            bindReadonlyViews: function (data, targetDiv) {
                $("#btnPublishAlert").unbind("click");
                $("#btnPublishAlert").click(function () {
                    athoc.iws.publishing.view.publishAlert();
                });
                athoc.iws.publishing.content.applyReadonlySettingsOnContent(data, targetDiv);
                ko.cleanNode(targetDiv.find(".content-section").get(0));
                ko.applyBindings(athoc.iws.publishing.view.viewModel, targetDiv.find(".content-section").get(0));

                // source ='a' from Review and Publish button
                //source ='p' from publish button from new alert grid
                //source ='h' from publish button from home page
                if (athoc.iws.publishing.source == "a") {
                    if (athoc.iws.scenario != undefined && athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Targeting != undefined && athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Targeting.Readonly) // Target user section is set readonly 
                    {
                        athoc.iws.publishing.targetUsers.applyReadonlySettingsOnTargetUsers(athoc.iws.publishing.detail.viewModel, targetDiv);
                    } else {
                        athoc.iws.publishing.targetUsers.applyReadonlySettingsOnTargetUsers(data, targetDiv);
                    }
                }
                else
                    athoc.iws.publishing.targetUsers.applyReadonlySettingsOnTargetUsers(data, targetDiv);

            },

            applyVisibilitySettings: function (data, targetDiv) {
                // apply content settings such as dropbox , Location, response option  on Scenario and Alert
                //athoc.iws.scenario.settings.applyContentSettings(athoc.iws.scenario.settings.ReadonlyViewModel.applysettings);
                var content = data;
                if (content.LocationEnabled)

                    $(targetDiv).find("#dvContentLocation").css("display", "");
                else
                    $(targetDiv).find("#dvContentLocation").css("display", "none");


                if (content.ResponseOptionEnabled) {
                    $(targetDiv).find("#dvContentResponseOpt").css("display", "");
                    $(targetDiv).find("#dvContentAddResponseOpt").css("display", "");
                }
                else {
                    $(targetDiv).find("#dvContentResponseOpt").css("display", "none");
                    $(targetDiv).find("#dvContentAddResponseOpt").css("display", "none");
                }

                if (content.DropboxEnabled)
                    $(targetDiv).find("#dvContentDropBox").css("display", "");
                else
                    $(targetDiv).find("#dvContentDropBox").css("display", "none");
            },

            publishedAlertId: 0,

            OnCloseAfterPublish: null,

            //Origin of publisher this can be ScenarioPublisher, AlertManager or AlertDetail
            //ScenarioPublisher is origin from home page or scenario publisher
            //AlertManager is origin from Alert list screen
            //AlertDetail is origin from edit alert screen
            Origin: '',

            //parentId will be alertId or scenarioId based on context
            ParentId: 0,

            showReviewAndPublish: function (showEdit, id, origin) {
                athoc.iws.publishing.view.messages = [];
                athoc.iws.publishing.view.Origin = origin;
                athoc.iws.publishing.view.ParentId = id;


                if ($('#dialogReviewAndPublish').length > 0) {
                    $('#btnPublishAlert').prop("disabled", false);

                    var resizeFunction = function () {
                        //athoc.iws.utilities.resizeModalBasedOnScreen($('#dialogReviewAndPublish'), 600, 770, 20, 170);
                        if ($(window).height() > 1024)
                            athoc.iws.utilities.resizeModalBasedOnScreen($('#dialogReviewAndPublish'), 600, 770, 40, 170);
                        else
                            athoc.iws.utilities.resizeModalBasedOnScreen($('#dialogReviewAndPublish'), 560, 710, 15, 145);
                    }



                    var updateLayout = _.debounce(resizeFunction, 500); // Maximum run of once per 500 milliseconds
                    window.addEventListener("resize", updateLayout, false);

                    athoc.iws.publishing.view.publishedAlertId = 0;

                    athoc.iws.publishing.view.messages = [];
                    $('#dialogReviewAndPublish').find("#messagePanel").messagesPanel('reset');

                    $("#dialogReviewAndPublish").find(".pre-publish").show();
                    $("#dialogReviewAndPublish").find(".post-publish").hide();
                    $("#dialogReviewAndPublish").find("#btn_print_alert").unbind("click");
                    $("#dialogReviewAndPublish").find("#btn_print_alert").click(function () { athoc.iws.publishing.view.downloadPdfFile(athoc.iws.publishing.urls.CreatePrintAlertUrl); });
                    if (showEdit && origin == "ScenarioPublisher") {
                        $("#btnDialogReviewEdit").show();
                        $("#btnDialogReviewEdit").unbind("click");
                        $("#btnDialogReviewEdit").click(function () { athoc.iws.publishing.view.editAndPublishScenario(id); });
                    } else if (showEdit && origin == "AlertManager") {
                        $("#btnDialogReviewEdit").show();
                        $("#btnDialogReviewEdit").unbind("click");
                        $("#btnDialogReviewEdit").click(function () { athoc.iws.publishing.view.editAlert(id); });
                    }
                    else {
                        $("#btnDialogReviewEdit").hide();
                    }

                    $("#dialogReviewAndPublish").find("#btnPublishClose").unbind("click");
                    $("#dialogReviewAndPublish").find("#btnPublishClose").click(function () {
                        if (athoc.iws.publishing.view.publishedAlertId != 0 && athoc.iws.publishing.view.OnCloseAfterPublish != null) {
                            athoc.iws.publishing.view.OnCloseAfterPublish(athoc.iws.publishing.view.publishedAlertId);
                        } else {
                            $('#dialogReviewAndPublish').modal('hide');
                        }
                        // added to reset the source
                        athoc.iws.publishing.source = "";
                    });

                    $("#dialogReviewAndPublish").find("#btnDependencyListCancel").click(function () {
                        // added to reset the source
                        athoc.iws.publishing.source = "";
                    });


                    $("#dialogReviewAndPublish").find(".publishing-detail").show();

                    $('#dialogReviewAndPublish').modal('show');
                    //athoc.iws.publishing.view.resizeModalBasedOnScreen();                    
                    if ($(window).height() > 1024)
                        athoc.iws.utilities.resizeModalBasedOnScreen($('#dialogReviewAndPublish'), 600, 770, 20, 190);
                    else
                        athoc.iws.utilities.resizeModalBasedOnScreen($('#dialogReviewAndPublish'), 560, 710, 15, 165);

                }
            },

            editAlert: function (id) {
                $('#dialogReviewAndPublish').modal('hide');

                $(".alert-nav").hide();
                $(".edit-alert").show();
                navigateToPage('alertDetail', function () { });

                athoc.iws.alert.detail.editAlert(id == 0 ? athoc.iws.publishing.view.ParentId : id);

                var breadcrumbsModel = athoc.iws.alert.breadcrumbModel;
                breadcrumbsModel.SelectedPage('alertDetail');
                $.titleCrumb("pageBreadcrumbs");
                $(document).scrollTop(0);
            },

            editAndPublishScenario: function (id) {
                $('#dialogReviewAndPublish').modal('hide');              
                athoc.iws.publishing.createRequest("/athoc-iws/alertmanager?nav=c&source=" + athoc.iws.publishing.source + "&id=" + id);
            },

            viewReport: function (id) {
                window.location = "/athoc-iws/AlertManager/ReportView?id=" + id;
            },

            loadFromUrl: function (loadUrl, showNotReadyError, context, id) {
                athoc.iws.publishing.view.context = context;
                athoc.iws.publishing.view.id = id;
                $("#dialogReviewAndPublish").find(".publishing-detail").hide();
                $('#btnPublishAlert').prop("disabled", true);

                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $(window), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();

                var dlSuccess = function (data) {

                    athoc.iws.publishing.view.publishingModel = data.Data;
                    $.AjaxLoader.hideLoader();
                    $("#dialogReviewAndPublish").find(".publishing-detail").show();

                    $("#dialogReviewAndPublish .blockMsg").css("top", "350px");
                    $("#dialogReviewAndPublish .blockMsg").css("left", "400px");

                    if (data.Success) {
                        $('#btnPublishAlert').prop("disabled", false);
                        athoc.iws.publishing.view.bind(data.Data, $("#dialogReviewAndPublish"));

                        //publishing scenario with placehoder
                        athoc.iws.publishing.view.replacePlaceholder();
                        $('#dialogReviewAndPublish').find('.modal-body').scrollTop(0);
                    } else {
                        athoc.iws.publishing.view.messages.push({ Type: '4', Value: data.Messages });
                        $('#dialogReviewAndPublish').find("#messagePanel").messagesPanel({ messages: athoc.iws.publishing.view.messages }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        $('#dialogReviewAndPublish').find('.modal-body').scrollTop(0);
                    }
                    var targDevices = _.where(data.Data.TargetUsers.Devices, { HideInReadOnlyView: false });

                    // var targetUsersSelection = (data.Data.TargetUsers.TargetUsersByArea == true) || (data.Data.TargetUsers.TargetedBlockedUsers.length > 0) || (data.Data.TargetUsers.TargetedCriteria != null) || (data.Data.TargetUsers.TargetingNodes.length > 0) || (data.Data.rbt != null);
                    var targetUsersSelection = (data.Data.TargetUsers.TargetUsersByArea == true) || (data.Data.TargetUsers.TargetedBlockedUsers.length > 0) || (data.Data.TargetUsers.TargetedCriteria != null) || (data.Data.TargetUsers.TargetingNodes.length > 0) || (data.Data.rbt != null);


                    if (showNotReadyError && (!targetUsersSelection && targDevices.length != 0))
                        //commented to work in demo
                        //||
                        //(data.Data.TargetUsers.TargetingNodes.length == 0 && targDevices.length != 0)
                    {
                        $('#dialogReviewAndPublish').find("#messagePanel").messagesPanel({ messages: [{ Type: '4', Value: athoc.iws.publishing.resources.Publishing_Alert_NotReady_Error }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        $("#dialogReviewAndPublish").find(".pre-publish").hide();
                        $("#dialogReviewAndPublish").find(".post-publish").show();
                        $("#dialogReviewAndPublish").find("#btnPublishViewReport").hide();
                        if ($("#btn_detail_standby").length == 0)
                            $("#dialogReviewAndPublish").find("#btnDialogReviewEdit").show();
                        $("#btnDialogReviewEdit").unbind("click");
                        $("#btnDialogReviewEdit").click(function () {
                            athoc.iws.publishing.view.editAlert(data.Data.EntityId);
                        });
                    }
                    athoc.iws.publishing.view.showDeviceWarningText(targDevices);



                    //show error is alert is not ready to publish
                    // here validattion code is written to  validate the Publish  ready status but this method is failing incase of target user condition so we  moved it below this method, the new function is called in the update contact info
                    athoc.iws.publishing.view.showNotReadyError = showNotReadyError;
                };

                var dlAjaxOption =
                {
                    type: "POST",
                    url: loadUrl,
                };

                var ajaxOptions = $.extend({}, AjaxUtility(null, dlSuccess).ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);

            },

            validatePublishStatus: function (targetUsersCnt) {
                var showErrorMsg = false;
                //check for Targetting Users supported or not
                var isTargetUsersSupported = (athoc.iws.publishing.settings.IsAdvancedQuerySuuported || athoc.iws.publishing.settings.IsIndividualUserTargetingSupported || athoc.iws.publishing.settings.IsTargetByAreaSupported);
                var data = athoc.iws.publishing.view.publishingModel;
                //get device count w/o org
                var targDevices = _.where(data.TargetUsers.Devices, { HideInReadOnlyView: false });

                if (isTargetUsersSupported && athoc.iws.publishing.view.showNotReadyError &&
                            (
                                (targetUsersCnt == 0 && targDevices.length == 0 && data.TargetOrg.TargetedOrganizations.length == 0)
                                 || (targetUsersCnt != 0 && targDevices.length == 0)
                                 || (targetUsersCnt != 0 && targDevices.length == 0)
                                 || (targetUsersCnt == 0 && targDevices.length != 0)
                            )
                    )
                    showErrorMsg = true;

                if (isTargetUsersSupported == false && athoc.iws.publishing.settings.IsMassDeviceTargetSupported && data.MassDevices.length == 0)
                    showErrorMsg = true;


                if (showErrorMsg) {
                    athoc.iws.publishing.view.messages.push({ Type: '4', Value: athoc.iws.publishing.resources.Publishing_Alert_NotReady_Error });
                    $('#dialogReviewAndPublish').find("#messagePanel").messagesPanel({ messages: athoc.iws.publishing.view.messages }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                    $("#dialogReviewAndPublish").find(".pre-publish").hide();
                    $("#dialogReviewAndPublish").find(".post-publish").show();
                    $("#dialogReviewAndPublish").find("#btnPublishViewReport").hide();
                    if ($("#btn_detail_standby").length == 0)
                        $("#dialogReviewAndPublish").find("#btnDialogReviewEdit").show();
                    $("#btnDialogReviewEdit").unbind("click");
                    $("#btnDialogReviewEdit").click(function () {
                        athoc.iws.publishing.view.editAlert(data.EntityId);
                    });
                }

            },

            showDeviceWarningText: function (data) {
                if (athoc.iws.publishing.view.messages.length > 0) {
                    athoc.iws.publishing.view.messages = $.grep(athoc.iws.publishing.view.messages, function (message) {
                        return message.Type !== '1';
                    });
                }

                var devicesWithWarningText = [];
                var devices = [];

                if (data && data.TargetUsers && data.TargetUsers.Devices) {
                    _.each(data.TargetUsers.Devices, function (device) {
                        var result = $.grep(devices, function (e) { return e.DeviceId == device.DeviceId; });
                        if (result.length == 0) {
                            devices.push(device);
                        }
                    });
                }

                if (data && data.MassDevices && data.MassDevices.length > 0) {
                    _.each(data.MassDevices, function (device) {
                        if (device.Selected) {
                            var result = $.grep(devices, function (e) { return e.DeviceId == device.DeviceId; });
                            if (result.length == 0) {
                                devices.push(device);
                            }
                        }
                    });
                }

                if (devices.length > 0) {
                    devicesWithWarningText = $.map($.grep(devices, function (d) {
                        return d.WarningText && d.WarningText.length > 0;
                    }), function (d) {
                        athoc.iws.publishing.view.messages.push({ Type: '1', Value: d.WarningText });
                        return { Type: '1', Value: d.WarningText };
                    });
                }

                if (devicesWithWarningText && devicesWithWarningText.length > 0)
                    $('#dialogReviewAndPublish').find("#messagePanel").messagesPanel({ messages: athoc.iws.publishing.view.messages }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
            },

            //bind R&P model with data
            bind: function (data, targetDiv) {

                athoc.iws.publishing.view.replacedPlaceholder = false;

                //bind publish event
                $("#btnPublishAlert").unbind("click");
                $("#btnPublishAlert").click(function () { athoc.iws.publishing.view.publishAlert(); });

                var _self = athoc.iws.publishing.view;

                //add contact info to the data
                data.ContactinfoTotalCoveredNumber = "0";
                data.ContactinfoTotalCoveredPercentage = "0";
                data.ContactinfoNotCoveredNumber = "0";
                data.ContactinfoNotCoveredPercentage = "0";
                data.TotalUsers = 0;

                //moved to content section


                //content
                _self.bindContentSection(data, targetDiv);

                //geo location
                _self.bindGeoLocation(data.Content.LocationGeo, targetDiv);

                //target user section
                // Commented: Redundant call.
                _self.bindTargetUsers(data, targetDiv);

                //orgnaizations
                _self.bindOrganizationSection(data, targetDiv);

                //mass devices
                _self.bindMassDevices(data, targetDiv);


                //scheduling
                _self.bindSchedulingSection(data, targetDiv);


                if ((athoc.iws.publishing.detail.viewModel.AlertStatus == "Ended" || athoc.iws.publishing.detail.viewModel.AlertStatus == "Live") && !athoc.iws.publishing.view.replacedPlaceholder) {
                    //Live ended showing custom text/recorded message
                    athoc.iws.publishing.view.publishingModel = data;
                    _self.replacePlaceholder();
                    athoc.iws.publishing.view.replacedPlaceholder = true;
                }

                _self.showDeviceWarningText(data);

                _self.updateMoreLess(targetDiv);

                athoc.iws.publishing.detail.bindBucketExpandCollapse(targetDiv);

                //TODO: why would you need following code?
                //if (athoc.iws.alert.source == "rbt") {
                //    $("#dialogReviewAndPublish").find("#publishing-mass-view").hide();
                //    $("#dialogReviewAndPublish").find("#targetOrgDetail").hide();
                //}

            },

            //bind content section
            bindContentSection: function (data, targetDiv) {
                //the below lines of code moved from bind
                var _self = athoc.iws.publishing.view;
                if (data.Content != undefined && data.Content.ResponseOptions != undefined && data.Content.ResponseOptions.length > 0) {
                    var reponseOptions = [];
                    for (var i = 0; i < data.Content.ResponseOptions.length; i++) {
                        if (data.Content.ResponseOptions[i].ResponseText.trim() !== '') {
                            reponseOptions.push(data.Content.ResponseOptions[i]);
                        }
                    }
                    data.Content.ResponseOptions = reponseOptions;
                }

                _self.viewModel.data = ko.mapping.fromJS(data);

                _self.viewModel.data.Content.language = ko.computed(function () {
                    var lang = _self.viewModel.data.Content.Local();
                    var arr = $.grep(_self.viewModel.data.Content.Languages(), function (l) {
                        return l.Code() == lang;
                    });
                    return arr[0] ? arr[0].Name() : "";
                });

                //adding linebreak for alert body
                if (data.Content && data.Content.Body) {
                    _self.viewModel.bodyWithLineBreak($.htmlEncode(data.Content.Body.trim()).replace(/(?:\r\n|\r|\n)/g, '<br />'));
                } else {
                    _self.viewModel.bodyWithLineBreak('');
                }

                //do knockout binding using viewModel
                //Binding
                ko.cleanNode(targetDiv.find(".content-section").get(0));

                targetDiv.find("#responseOptionDiv").empty();

                _self.viewModel.typeVisible = ko.observable(athoc.iws.publishing.contextName == "AccountEvent" ? data.ScenarioSettings.AccountabilityWorkflow.IsContentTypeVisible : true);
                _self.viewModel.severityVisible = ko.observable(athoc.iws.publishing.contextName == "AccountEvent" ? data.ScenarioSettings.AccountabilityWorkflow.IsContentSeverityVisible : true);
                ko.applyBindings(athoc.iws.publishing.view.viewModel, targetDiv.find(".content-section").get(0));
            },

            //bind geo-location with readonly map view
            //added targetDiv as parameter
            bindGeoLocation: function (location, targetDiv) {
                if (!location || location == null || location == '') {
                    athoc.iws.publishing.view.viewModel.isGeoSelected(false);
                    return;
                }


                /* IWS-20491 - Creating map instance using leaflet  and adding geo coordinates  */
                var geoJson = JSON.parse(location);

                /*24187 - hide the empty map when coordinates are empty*/
                if (!geoJson || !geoJson.features || geoJson.features.length === 0) {
                    athoc.iws.publishing.view.viewModel.isGeoSelected(false);
                    return;
                }

                athoc.iws.publishing.view.geoJson = geoJson;
                athoc.iws.publishing.view.viewModel.isGeoSelected(true);

                /* IWS-20388 - loading resources keys*/
                var minimapresources = null;
                if (athoc.iws.publishing && athoc.iws.publishing.mapResources) {
                    minimapresources = athoc.iws.publishing.mapResources;
                }
                else if (athoc.iws.home && athoc.iws.home.mapResources) {
                    minimapresources = athoc.iws.home.mapResources;
                }
                require(["widget/Map"], function (WidgetMap) {
                    //athoc.iws.publishing.view.readOnlyMap = null;
                    var reviewMapHolder = targetDiv.find(".readOnlyMiniMapHolder");

                    /* commented below line to not make empty every time*/
                    //targetDiv.find(".readOnlyMiniMapHolder").html('');
                    if (targetDiv[0].id === "alert-content-detail") {
                        if (!athoc.iws.publishing.view.readOnlyMap) {
                            //map creating when content section expanded
                            if (!athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content || !athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.Collapsed) {
                                athoc.iws.publishing.view.viewModel.isGeoSelected(true);
                                athoc.iws.publishing.view.readOnlyMap = new WidgetMap(reviewMapHolder, {
                                    i18n: minimapresources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture
                                });
                            }
                        }

                        $('#dialogGeoTargetingSummary').on('shown.bs.modal', function () {
                            if (!athoc.iws.publishing.view.summaryMap) {
                                athoc.iws.publishing.view.summaryMap = new WidgetMap("dialogGeoTargetingSummaryContent", {
                                    i18n: minimapresources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture
                                });
                            }
                            athoc.iws.publishing.view.bindGeoAlertMiniMap(athoc.iws.publishing.view.summaryMap, geoJson);
                        });

                        //20388 binding map in modal window from "ByLocation count" in readonly time
                        $('#dialogGeoPublish').on('shown.bs.modal', function () {
                            if (!athoc.iws.publishing.view.summaryMapReadOnly) {
                                athoc.iws.publishing.view.summaryMapReadOnly = new WidgetMap("dialogGeoPublishContent", {
                                    i18n: minimapresources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture
                                });
                            }
                            athoc.iws.publishing.view.bindGeoAlertMiniMap(athoc.iws.publishing.view.summaryMapReadOnly, geoJson);
                        });

                    } else if (targetDiv[0].id === "dialogReviewAndPublish" || targetDiv[0].id === "dialogReviewAndStart") {
                        if (!athoc.iws.publishing.view.readOnlyMapInRP) {
                            var id = "#" + targetDiv[0].id;
                            $(id).show();
                            athoc.iws.publishing.view.viewModel.isGeoSelected(true);
                            athoc.iws.publishing.view.readOnlyMapInRP = new WidgetMap(reviewMapHolder, {
                                i18n: minimapresources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture
                            });
                        }
                        else {
                            athoc.iws.publishing.view.readOnlyMapInRP.removeGeoJson();
                        }
                        /*the second popup modal in review and publish page*/
                        $('#dialogGeoPublish').on('shown.bs.modal', function () {
                            if (!athoc.iws.publishing.view.summaryMapReadOnly) {
                                athoc.iws.publishing.view.summaryMapReadOnly = new WidgetMap("dialogGeoPublishContent", {
                                    i18n: minimapresources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture
                                });
                            }
                            athoc.iws.publishing.view.bindGeoAlertMiniMap(athoc.iws.publishing.view.summaryMapReadOnly, geoJson);
                        });

                    } else {
                        if (!athoc.iws.publishing.view.readOnlyMapOtherCases) {
                            if (!athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content || !athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Content.Collapsed) {
                                if ($("#rptForm #target-contentarea #alertView").length == 0) {
                                    athoc.iws.publishing.view.viewModel.isGeoSelected(true);
                                    athoc.iws.publishing.view.readOnlyMapOtherCases = new WidgetMap(reviewMapHolder, {
                                        i18n: minimapresources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture
                                    });
                                }
                            }
                        }
                    }


                    if (!location || location == null || location == '') {
                        athoc.iws.publishing.view.viewModel.isGeoSelected(false);
                    }
                    else {
                        //Binding Targted area data when content section is readonly and Target Section is in edit. If Target Area is selected in scenario
                        //athoc.iws.publishing.source == undefined - Coming from edit alert.
                        /*IWS-22599 - In readonly case athoc.iws.publishing.source value is coming readonly so I modified "undefined" to "readonly" */
                        if ((athoc.iws.publishing.source == undefined || athoc.iws.publishing.source == "readonly") && athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetUsersByArea()) {
                            athoc.iws.publishing.geo.viewModel.isUsersTargeted(true);
                            athoc.iws.publishing.geo.viewModel.isGeoSelected(true);
                            athoc.iws.publishing.geo.geoJson = JSON.parse(location);
                            if ($("#targetContentArea").length > 0) {
                                ko.cleanNode($("#targetContentArea").get(0));
                                ko.applyBindings(athoc.iws.publishing.geo.viewModel, $("#targetContentArea").get(0));
                            }
                            athoc.iws.publishing.geo.updateTargetingSummary();
                        }
                        //end

                        if (geoJson && geoJson.features.length > 0) {
                            athoc.iws.publishing.view.viewModel.isGeoSelected(true);
                            if (athoc.iws.publishing.view.readOnlyMap) {
                                athoc.iws.publishing.view.bindGeoAlertMiniMap(athoc.iws.publishing.view.readOnlyMap, geoJson);
                            }
                            if (athoc.iws.publishing.view.readOnlyMapInRP) {
                                athoc.iws.publishing.view.bindGeoAlertMiniMap(athoc.iws.publishing.view.readOnlyMapInRP, geoJson);
                            }
                            if (athoc.iws.publishing.view.readOnlyMapOtherCases) {
                                athoc.iws.publishing.view.bindGeoAlertMiniMap(athoc.iws.publishing.view.readOnlyMapOtherCases, geoJson);
                            }
                        }
                    }
                });

                /*Commented esri mini map implementation

                require(["maps/MiniMap"], function (MiniMap) {
                    //athoc.iws.publishing.view.readOnlyMap = null;
                    var reviewMapHolder = targetDiv.find(".readOnlyMiniMapHolder")[0];
                    targetDiv.find(".readOnlyMiniMapHolder").html('');
                    if (targetDiv[0].id === "alert-content-detail") {
                        athoc.iws.publishing.view.readOnlyMap = new MiniMap({ width: 447, height: 200 }, reviewMapHolder);
                    } else if (targetDiv[0].id === "dialogReviewAndPublish") {
                        athoc.iws.publishing.view.readOnlyMapInRP = new MiniMap({ width: 447, height: 200 }, reviewMapHolder);
                    } else {
                        athoc.iws.publishing.view.readOnlyMapOtherCases = new MiniMap({ width: 447, height: 200 }, reviewMapHolder);
                    }


                    if (!location || location == null || location == '') {
                        athoc.iws.publishing.view.viewModel.isGeoSelected(false);
                    }
                    else {
                        //Binding Targted area data when content section is readonly and Target Section is in edit. If Target Area is selected in scenario
                        //athoc.iws.publishing.source == undefined - Coming from edit alert.
                        if (athoc.iws.publishing.source == undefined && athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetUsersByArea()) {
                            athoc.iws.publishing.geo.viewModel.isUsersTargeted(true);
                            athoc.iws.publishing.geo.viewModel.isGeoSelected(true);
                            athoc.iws.publishing.geo.geoJson = JSON.parse(location);
                            if ($("#targetContentArea").length > 0) {
                                ko.cleanNode($("#targetContentArea").get(0));
                                ko.applyBindings(athoc.iws.publishing.geo.viewModel, $("#targetContentArea").get(0));
                            }
                            athoc.iws.publishing.geo.updateTargetingSummary();
                        }
                        //end
                        var geoJson = JSON.parse(location);
                        if (geoJson && geoJson.features.length > 0) {
                            athoc.iws.publishing.view.viewModel.isGeoSelected(true);
                            if (athoc.iws.publishing.view.readOnlyMap) {
                                athoc.iws.publishing.view.readOnlyMap.restore(geoJson);
                            }
                            if (athoc.iws.publishing.view.readOnlyMapInRP) {
                                athoc.iws.publishing.view.readOnlyMapInRP.restore(geoJson);
                            }
                            if (athoc.iws.publishing.view.readOnlyMapOtherCases) {
                                athoc.iws.publishing.view.readOnlyMapOtherCases.restore(geoJson);
                            }
                        }
                    }

                    setTimeout(function () {
                        if (athoc.iws.publishing.view.readOnlyMap) {
                            athoc.iws.publishing.view.readOnlyMap.resize();
                            athoc.iws.publishing.view.readOnlyMap.zoomToFit();
                        }
                        if (athoc.iws.publishing.view.readOnlyMapInRP) {
                            athoc.iws.publishing.view.readOnlyMapInRP.resize();
                            athoc.iws.publishing.view.readOnlyMapInRP.zoomToFit();
                        }
                        if (athoc.iws.publishing.view.readOnlyMapOtherCases) {
                            athoc.iws.publishing.view.readOnlyMapOtherCases.resize();
                            athoc.iws.publishing.view.readOnlyMapOtherCases.zoomToFit();
                        }
                    }, 500);
                });
                */




            },

            /* IWS-20491 created common function to bind map*/
            bindGeoAlertMiniMap: function (miniMap, geoLocationsJson) {
                if (miniMap != null || miniMap) {
                    miniMap.removeGeoJson();
                    miniMap.addGeoJson(geoLocationsJson);
                    miniMap.centerAt([0, 0]);
                    miniMap.zoomToFit();
                }
            },

            //bind target users section
            bindTargetUsers: function (data, targetDiv) {
                // case:1
                /*
                athoc.iws.publishing.targetUsers.targetGroupInstance = new athoc.iws.publishing.TargetGroup('#treeview');
                athoc.iws.publishing.targetUsers.targetGroupInstance.RefreshTreeView(data);
                athoc.iws.publishing.targetUsers.targetGroupInstance.ViewModel.set("SelectedNodes", athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetingNodes());
                */
                //case :2 
                if (data.TargetingTree != null) {
                    athoc.iws.publishing.view.viewModel.targetedNodes = [];
                    athoc.iws.publishing.view.getTargetedNodes(data.TargetingTree, athoc.iws.publishing.view.viewModel.targetedNodes);
                    if (athoc.iws.publishing.view.viewModel.targetedNodes.length > 0)
                        athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetingNodes(athoc.iws.publishing.view.viewModel.targetedNodes);
                }

                athoc.iws.publishing.view.generateUserTargeting(data, targetDiv);

                if (!athoc.iws.publishing.view.replacedPlaceholder) {
                    athoc.iws.publishing.view.publishingModel = data;
                    athoc.iws.publishing.view.replacePlaceholder();
                    athoc.iws.publishing.view.replacedPlaceholder = true;
                }
            },
            targetingChanged: function (data) {
                //if advanced targeting is enabled get criteria
                // var advancedCriteriaSelected = (this.viewModel.QueryCriteriaCount) && (this.viewModel.QueryCriteriaCount > 0);

                var advancedCriteriaSelected = (this.viewModel.QueryCriteriaCount) && (this.viewModel.QueryCriteriaCount() > 0);

                //is target by area selected

                /* IWS-22599 - TargetedAreaCount is property doens't have length 
                 var targetByAreaSelected = (this.viewModel.TargetedAreaCount().length > 0);
                */
                var targetByAreaSelected = (this.viewModel.TargetedAreaCount() > 0);



                //is IUT selected
                var iutTargeted = (this.viewModel.TargetedBlockerUsersList.length > 0);

                //check if any of targeting is selected
                var anyTargetingSelected = (data.TargetUsers.TargetingNodes.length > 0
                    || iutTargeted
                    || advancedCriteriaSelected
                    || targetByAreaSelected);
                //|| (athoc.iws.publishing.rbt != null)
                var isAnyPersonalDeviceTargeted = (data.TargetUsers && data.TargetUsers.Devices && data.TargetUsers.Devices.length > 0);



                if (anyTargetingSelected && isAnyPersonalDeviceTargeted) {
                    athoc.iws.publishing.targetUsers.isReadyToPublish = true;
                    athoc.iws.publishing.targetUsers.isInErrorState = false;
                } else
                    if (anyTargetingSelected || isAnyPersonalDeviceTargeted) {
                        athoc.iws.publishing.targetUsers.isReadyToPublish = false;
                        athoc.iws.publishing.targetUsers.isInErrorState = true;
                    }
                    else {
                        athoc.iws.publishing.targetUsers.isReadyToPublish = false;
                        athoc.iws.publishing.targetUsers.isInErrorState = false;

                    }
            },

            //Method to check the ready state of selected mass devices.
            isMassDeviceReady: function (data) {

                //this is not required for PA
                if (!(athoc.iws.publishing.contextName == "Alert" || athoc.iws.publishing.contextName == "Scenario"))
                    return;

                if (athoc.iws.publishing.settings.IsMassDeviceTargetSupported && athoc.iws.publishing.massdevices.filterDataforReadOnly(data.MassDevices).length > 0) {
                    athoc.iws.publishing.massdevices.isReadyToPublish = true;
                    athoc.iws.publishing.massdevices.isInErrorState = false;
                    _.each(data.MassDevices, function (device) {
                        if ((!device.EndPoints || device.EndPoints.length == 0) && (device.Selected)) {
                            athoc.iws.publishing.massdevices.isReadyToPublish = false;
                            athoc.iws.publishing.massdevices.isInErrorState = true;
                        }
                        if (device.IsAreaRequired)
                            if (!athoc.iws.publishing.massdevices.isLocationPresent()) {
                                athoc.iws.publishing.massdevices.isReadyToPublish = false;
                                athoc.iws.publishing.massdevices.isInErrorState = true;
                            }
                    });
                }
            },

            getTargetedNodes: function (nodes, targetedNodes, parent, root) {

                for (var i = 0; i < nodes.length; i++) {

                    var r = !root && nodes[i].Type == 3 ? nodes[i] : root;
                    //this is where we save the targeted nodes and we need to check to see if it's not blocked
                    var targetedList = ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetingNodes);
                    var found = _.find(targetedList, function (existingItem) {
                        return (existingItem.Id == nodes[i].Id);
                    });

                    //otherwise, we need to keep traversing the tree to set the correct blocked state for each node
                    if (nodes[i].Type != 6 && found) {
                        var parentId = 0;
                        var parentName = "";
                        try {
                            parentId = parent.Id;
                            parentName = parent.Name;
                        } catch (e) {

                        }

                        //creating a flat list here for save()
                        targetedNodes.push({
                            Id: nodes[i].Id,
                            Name: nodes[i].Name,
                            Type: nodes[i].Type,
                            Lineage: nodes[i].Lineage,
                            ParentId: parentId,
                            ParentName: parentName,
                            SubType: nodes[i].SubType,
                            RootId: root != null ? root.Id : 0,
                            RootName: root != null ? root.Name : "",
                            DlType: nodes[i].DlType,
                            IsBlocked: found.IsBlocked,
                            Selected: found.Selected,

                            //todo: add IsBlocked
                        });
                    }
                    if (nodes[i].HasChildren) {
                        athoc.iws.publishing.view.getTargetedNodes(nodes[i].Children, targetedNodes, nodes[i], r);
                    }
                }
            },


            //Method to handle read node details in order to save the details
            treeToJson: function (nodes, ParentName) {

                return $.map(nodes, function (n, i) {

                    var selected = _.find(athoc.iws.publishing.view.viewModel.data.TargetUsers.TargetingNodes(), function (selectedNode) {
                        return n.Id === selectedNode.Id();
                    });

                    if (selected != undefined) {
                        selected.Name(n.Name);
                        selected.RootName(ParentName);
                        athoc.iws.publishing.view.viewModel.selectedNodes.push(ko.mapping.toJS(selected));
                    }

                    if (n.HasChildren)
                        athoc.iws.publishing.view.treeToJson(n.Children, n.Name);
                });
            },
            //bind scheduling section
            bindSchedulingSection: function (data, targetDiv) {
                if (athoc.iws.publishing.settings.IsSchedulingSupported) {
                    if ((data.AlertStatus == undefined) || ((data.AlertStatus.toLowerCase() == "live" || data.AlertStatus.toLowerCase() == "ended" || data.AlertStatus.toLowerCase() == "scheduled") && (data.rbt == null || data.EntityId > 0))) {
                        targetDiv.find("#publishing-alert-view").show();
                    } else {
                        $("#publishing-alert-view").show();
                    }
                    athoc.iws.alert.schedule.bindReadOnlyView(data.AlertScheduleSettings, targetDiv);
                } else {
                    targetDiv.find("#publishing-alert-view").hide();
                }



            },

            //orgnaizations
            bindOrganizationSection: function (data, targetDiv) {
                if (data.TargetOrg.TargetedOrganizations.length > 0 && data.rbt == null) {
                    athoc.iws.publishing.targetOrg.bindReadOnlyViewModel(data.TargetOrg.TargetedOrganizations, targetDiv);
                } else {
                    targetDiv.find("#targetOrgDetail").hide();
                }
            },

            //bind mass devices based on feature and if mass devices selected
            bindMassDevices: function (data, targetDiv) {
                if (athoc.iws.publishing.settings.IsMassDeviceTargetSupported && athoc.iws.publishing.massdevices.filterDataforReadOnly(data.MassDevices).length > 0 && data.rbt == null) {
                    targetDiv.find("#publishing-mass-view").show();
                    athoc.iws.publishing.massdevices.bindReadOnlyView(data.MassDevices, targetDiv);
                } else {
                    athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList([]);
                    targetDiv.find("#publishing-mass-view").hide();
                }
            },

            //generate user targeting section from data (vm)
            generateUserTargeting: function (data, targetDiv) {
                var _self = athoc.iws.publishing.view;

                //initial targeting counts
                _self.viewModel.TargetedGroupCount(0);
                _self.viewModel.BlockedGroupCount(0);
                _self.viewModel.TargetedUserCount(0);
                _self.viewModel.BlockedUserCount(0);
                _self.viewModel.QueryCriteriaCount(0);
                _self.viewModel.TargetedAreaCount(0);

                var targetedAndBlockedGroups = [];
                var targetedUsers = [];
                var blockedUsers = [];
                var queryCriterias = {};
                var targetArea = "";
                var devices = [];


                //targeted blocked groups
                if (data.TargetUsers && data.TargetUsers.TargetingNodes) {
                    var targetedGroups = data.TargetUsers.TargetingNodes.filter(function (node) {
                        return !node.IsBlocked;
                    });
                    if (targetedGroups) {
                        _self.viewModel.TargetedGroupCount(targetedGroups.length);
                    }

                    var blockedGroups = data.TargetUsers.TargetingNodes.filter(function (node) {
                        return node.IsBlocked;
                    });
                    if (blockedGroups) {
                        _self.viewModel.BlockedGroupCount(blockedGroups.length);
                    }

                    targetedAndBlockedGroups = data.TargetUsers.TargetingNodes;
                }

                //targeted or blocked users
                if (data.TargetUsers && data.TargetUsers.TargetedBlockedUsers) {
                    targetedUsers = data.TargetUsers.TargetedBlockedUsers.filter(function (node) {
                        return !node.IsBlocked;
                    }).map(function (item) { return item.UserId; });
                    if (targetedUsers) {
                        _self.viewModel.TargetedUserCount(targetedUsers.length);
                    }

                    blockedUsers = data.TargetUsers.TargetedBlockedUsers.filter(function (node) {
                        return node.IsBlocked;
                    }).map(function (item) { return item.UserId; });
                    if (blockedUsers) {
                        _self.viewModel.BlockedUserCount(blockedUsers.length);
                    }

                    _self.viewModel.TargetedBlockerUsersList = data.TargetUsers.TargetedBlockedUsers;
                }

                //target query criteria
                if (data.TargetUsers && data.TargetUsers.TargetedCriteria && data.TargetUsers.TargetedCriteria.selections) {
                    queryCriterias = data.TargetUsers.TargetedCriteria;
                    _self.viewModel.QueryCriteriaCount(queryCriterias.selections.length);
                }

                //target by area
                if (data.TargetUsers && data.TargetUsers.TargetUsersByArea && data.Content.LocationGeo) {
                    targetArea = data.Content.LocationGeo;
                    var geoJson = JSON.parse(data.Content.LocationGeo);
                    if (geoJson && geoJson.features) {
                        _self.viewModel.TargetedAreaCount(geoJson.features.length);
                    }
                }

                if (data.rbt != null)
                    athoc.iws.publishing.rbt = data.rbt;
                var isAnyUserTargetingSelected = (_self.viewModel.TargetedGroupCount() > 0
                    || _self.viewModel.TargetedUserCount() > 0
                    || _self.viewModel.QueryCriteriaCount() > 0
                    || _self.viewModel.TargetedAreaCount() > 0
                    || _self.viewModel.BlockedGroupCount() > 0
                    || _self.viewModel.BlockedUserCount() > 0 || (athoc.iws.publishing.rbt != null));

                var isAnyPersonalDeviceTargeted = (data.TargetUsers && data.TargetUsers.Devices && data.TargetUsers.Devices.length > 0);
                _.each(data.TargetUsers.Devices, function (device) { devices.push(device.DeviceId); });

                if (isAnyUserTargetingSelected && isAnyPersonalDeviceTargeted) {
                    targetDiv.find("#publishing-user-detail").show();
                } else {
                    //Added the below condition to display section in readonly
                    if (athoc.iws.publishing.source == 'readonly')
                        targetDiv.find("#publishing-user-detail").show();
                    else {
                        targetDiv.find("#publishing-user-detail").hide();
                        return;
                    }
                }
                //athoc.iws.publishing.fillCount
                //for Review&Publish take the Fill count enabled flag from data.ScenarioSettings object; if this object not available then consider the flag from scenario settings object 
                athoc.iws.publishing.fillcount.readOnlyFillCountSummary(data, targetDiv, true, data.ScenarioSettings != undefined ? data.ScenarioSettings.Targeting.FillCount : athoc.iws.scenario.settings.isFillCountEnabled);

                //workaround for alert detail, for some reason ko binding does not work
                if (targetDiv.find("#targetedGroups").length > 0) {
                    targetDiv.find("#targetedGroups").html(_self.viewModel.TargetedGroupCount());
                }
                if (targetDiv.find("#blockedGroups").length > 0) {
                    targetDiv.find("#blockedGroups").html(_self.viewModel.BlockedGroupCount());
                }
                if (targetDiv.find("#targetedUsers").length > 0) {
                    targetDiv.find("#targetedUsers").html(_self.viewModel.TargetedUserCount());
                }
                if (targetDiv.find("#blockedUsers").length > 0) {
                    targetDiv.find("#blockedUsers").html(_self.viewModel.BlockedUserCount());
                }
                if (targetDiv.find("#targetedQuery").length > 0) {
                    targetDiv.find("#targetedQuery").html(_self.viewModel.QueryCriteriaCount());
                }
                if (targetDiv.find("#targetedArea").length > 0) {
                    targetDiv.find("#targetedArea").html(_self.viewModel.TargetedAreaCount());
                }
                if (targetDiv.find("#PersonalDeviceListDetailForAlertDetail").length > 0) {
                    ko.cleanNode(targetDiv.find("#PersonalDeviceListDetailForAlertDetail").get(0));
                    ko.applyBindings(athoc.iws.publishing.view.viewModel.personalDeviceList, targetDiv.find("#PersonalDeviceListDetailForAlertDetail").get(0));
                }

                //targeting summary
                if (targetDiv.find("#targetSummaryDetail").length > 0) {
                    ko.cleanNode(targetDiv.find("#targetSummaryDetail").get(0));
                    ko.applyBindings(_self.viewModel, targetDiv.find("#targetSummaryDetail").get(0));
                }

                if (athoc.iws.publishing.view && athoc.iws.publishing.view.viewModel && athoc.iws.publishing.view.viewModel.data && athoc.iws.publishing.view.viewModel.data.AlertStatus && (athoc.iws.publishing.view.viewModel.data.AlertStatus() == "Live" || athoc.iws.publishing.view.viewModel.data.AlertStatus() == "Ended"))
                    targetDiv.find("#targetSummaryDetail")[0].parentElement.style.display = "none";

                if (athoc.iws.publishing.rbt != null) {
                    if (athoc.iws.publishing.rbt.EntityFilterId != "")
                        targetDiv.find("#targetSummaryDetail")[0].parentElement.style.display = "none";
                }


                athoc.iws.publishing.view.viewModel.personalDeviceList.Devices([]);
                _.each(data.TargetUsers.Devices, function (device) {
                    var newDevice = ko.mapping.fromJS(device);
                    athoc.iws.publishing.view.viewModel.personalDeviceList.Devices.push(newDevice);
                });

                if (targetDiv.find("#PersonalDeviceListDetailForAlertDetail").length == 0) {
                    if (targetDiv.find("#PersonalDeviceListDetail").length > 0) {
                        ko.cleanNode(targetDiv.find("#PersonalDeviceListDetail").get(0));
                        ko.applyBindings(athoc.iws.publishing.view.viewModel.personalDeviceList, targetDiv.find("#PersonalDeviceListDetail").get(0));
                    }
                }

                //pie chart
                if (targetDiv.find(".contact-info-section").length > 0) {
                    ko.cleanNode(targetDiv.find(".contact-info-section").get(0));
                    ko.applyBindings(_self.viewModel, targetDiv.find(".contact-info-section").get(0));
                    if (targetDiv.find(".contact-info-section").length > 1) {
                        ko.cleanNode(targetDiv.find(".contact-info-section").get(1));
                        ko.applyBindings(_self.viewModel, targetDiv.find(".contact-info-section").get(1));

                        _self.showTargetingPieChart(devices, targetedAndBlockedGroups, targetedUsers, blockedUsers, queryCriterias, targetArea, data);
                    }
                }

            },

            //show user targeting pie chart
            showTargetingPieChart: function (devices, targetedAndBlockedGroups, targetedUsers, blockedUsers, queryCriterias, targetArea, data) {
                kendo.ui.progress($(".contact-info-loading"), true);

                require(['publishing/athoc.iws.publishing.contactInfoPieChart'], function (ContactInfoPieChart) {
                    //added condition to assign the div name based on the source
                    var pointer = null;
                    if (athoc.iws.publishing.source == 'readonly')
                        pointer = "#contactInfoReadOnly";
                    else
                        pointer = $("#dialogReviewAndStart #contactInfoReadOnly").length > 0 ? "#dialogReviewAndStart #contactInfoReadOnly" : "#dialogReviewAndPublish #contactInfoReadOnly";

                    //Commented the below line. If target user section is readonly and clicks on review and publish Piechart is not rending.
                    // if (athoc.iws.publishing.view.PieChartObject == null) {
                    athoc.iws.publishing.view.PieChartObject = new ContactInfoPieChart(
                    {
                        domPointer: pointer,
                        Publishing_Contact_Info_No_users_found: athoc.iws.publishing.resources.Publishing_Contact_Info_No_users_found,
                        Publishing_Contact_Info_Reachable_Tooltip: athoc.iws.publishing.resources.Publishing_Contact_Info_Reachable_Tooltip,
                        Publishing_Contact_Info_Not_Reachable_Tooltip: athoc.iws.publishing.resources.Publishing_Contact_Info_Not_Reachable_Tooltip,
                    });
                    //}
                });

                var userInfoSuccess = function (data) {
                    var current = athoc.iws.publishing.view;

                    //draw pie (default)
                    var contactInfo = [{
                        "type": "none",
                        "number": 100,
                        "color": "#ccc"
                    }];

                    current.viewModel.ContactinfoTotalCoveredNumber(new String("0"));
                    current.viewModel.ContactinfoTotalCoveredPercentage(new String("0"));
                    current.viewModel.ContactinfoNotCoveredNumber(new String("0"));
                    current.viewModel.ContactinfoNotCoveredPercentage(new String("0"));
                    current.viewModel.TotalUsers(new String("0"));

                    if (data.TotalCount > 0) {
                        //draw pie
                        contactInfo = [{
                            "type": "covered",
                            "number": data.ContactInfo.TotalCovered,
                            "color": "#7CB500",
                            "customPercentage": data.ContactInfo.TotalCoveredPercentage
                        }, {
                            "type": "notcovered",
                            "number": data.ContactInfo.TotalNotCovered,
                            "color": "#AE004B",
                            "customPercentage": data.ContactInfo.TotalNotCoveredPercentage
                        }];

                        current.viewModel.ContactinfoTotalCoveredNumber(new String(data.ContactInfo.TotalCovered));
                        current.viewModel.ContactinfoTotalCoveredPercentage(new String(data.ContactInfo.TotalCoveredPercentage));
                        current.viewModel.ContactinfoNotCoveredNumber(new String(data.ContactInfo.TotalNotCovered));
                        current.viewModel.ContactinfoNotCoveredPercentage(new String(data.ContactInfo.TotalNotCoveredPercentage));
                        current.viewModel.TotalUsers(data.TotalCount);

                    }

                    //set up values to targetusers model to display information on Pie chart click
                    /*if (athoc.iws.publishing.targetUsers.viewModelInstance.ReachableUsers != undefined)
                        athoc.iws.publishing.targetUsers.viewModelInstance.ReachableUsers(data.ContactInfo.TotalCovered);
                    else
                        athoc.iws.publishing.targetUsers.viewModelInstance.ReachableUsers = ko.observable(data.ContactInfo.TotalCovered);

                    if (athoc.iws.publishing.targetUsers.viewModelInstance.ReachableUsersPercentage != undefined)
                        athoc.iws.publishing.targetUsers.viewModelInstance.ReachableUsersPercentage(data.ContactInfo.TotalCoveredPercentage);
                    else
                        athoc.iws.publishing.targetUsers.viewModelInstance.ReachableUsersPercentage = ko.observable(data.ContactInfo.TotalCoveredPercentage);

                    if (athoc.iws.publishing.targetUsers.viewModelInstance.UnReachableUsers != undefined)
                        athoc.iws.publishing.targetUsers.viewModelInstance.UnReachableUsers(data.ContactInfo.TotalNotCovered);
                    else
                        athoc.iws.publishing.targetUsers.viewModelInstance.UnReachableUsers = ko.observable(data.ContactInfo.TotalNotCovered);

                    if (athoc.iws.publishing.targetUsers.viewModelInstance.UnReachableUsersPercentage != undefined)
                        athoc.iws.publishing.targetUsers.viewModelInstance.UnReachableUsersPercentage(data.ContactInfo.TotalNotCoveredPercentage);
                    else
                        athoc.iws.publishing.targetUsers.viewModelInstance.UnReachableUsersPercentage = ko.observable(data.ContactInfo.TotalNotCoveredPercentage);
                        */
                    if (athoc.iws.publishing.targetUsers.viewModelInstance.data != undefined)
                        current.viewModel.data.SessionId = data.SessionId;

                    ///set up values to targetusers model to display information on Pie chart click from Review and Publish
                    if (athoc.iws.alert.reviewandpublish == undefined) {
                        athoc.iws.alert.reviewandpublish = {};
                    }

                    athoc.iws.alert.reviewandpublish.SessionId = data.SessionId;
                    athoc.iws.alert.reviewandpublish.ReachableUsers(data.ContactInfo.TotalCovered);
                    athoc.iws.alert.reviewandpublish.ReachableUsersPercentage(data.ContactInfo.TotalCoveredPercentage);
                    athoc.iws.alert.reviewandpublish.UnReachableUsers(data.ContactInfo.TotalNotCovered);
                    athoc.iws.alert.reviewandpublish.UnReachableUsersPercentage(data.ContactInfo.TotalNotCoveredPercentage);


                    //TODO: need to check with deviceoptions to display custom text link

                    //Show updated coverage
                    var groupedDevices = athoc.iws.publishing.view.viewModel.personalDeviceList.Devices();
                    //getting devices having the reach percentage
                    var percentagesDevices = data.ContactInfo.ContactInfo;
                    //updating the reach based on the device id.
                    _.each(percentagesDevices, function (item) {
                        _.each(groupedDevices, function (device) {
                            if (item.DeviceId == device.DeviceId()) {
                                if (item.Percentage > 0)
                                    device.Reach(item.Percentage);
                                else
                                    device.Reach(0);
                            }
                        });
                    });

                    current.PieChartObject.update(contactInfo);
                    if (athoc.iws.publishing.source == 'readonly')
                        divContactInfo = "#contactInfoReadOnly";
                    else
                        divContactInfo = "#dialogReviewAndPublish #contactInfoReadOnly";

                    if (data.ContactInfo.TotalCovered > 0 || data.ContactInfo.TotalNotCovered > 0)
                        $(divContactInfo).css("cursor", "pointer");
                    else
                        $(divContactInfo).css("cursor", "default");

                    // this function is called to validate whether publishing is ready or not
                    if (athoc.iws.publishing.source == "p" || athoc.iws.publishing.source == "h" || athoc.iws.publishing.source == "a") {
                        //commented out this code to unblock everyone
                        athoc.iws.publishing.view.validatePublishStatus(data.TotalCount);
                    } else {
                        if (athoc.iws.scenario.settings != undefined)
                            athoc.iws.scenario.settings.applyVisibleSettingsOnAlert();
                    }

                    kendo.ui.progress($(".contact-info-loading"), false);
                };

                var userInfoError = function (error) {
                    kendo.ui.progress($(".contact-info-loading"), false);
                };


                var entityId = athoc.iws.publishing.view.id;
                var context = athoc.iws.publishing.view.context;
                var status = ["Publishing", "Live", "Ended"];
                if (data.AlertStatus && (status.indexOf(data.AlertStatus) > -1) && (athoc.iws.alert.source != "rbt")) {
                    if (athoc.iws.publishing.view.viewModel.loadTargetUsers() == true) {
                        //console.log('loading user');
                        athoc.iws.publishing.view.getUsersCountFromAlert(data.EntityId, userInfoSuccess, userInfoError);
                    }
                }
                else if (athoc.iws.alert.action != 'rbt') //in rbt flow, updateContactInfo is triggered when device checkbox is selected. thus, no need to invoke it here. 
                {
                    athoc.iws.publishing.UpdateContactInfo(entityId, context, targetedAndBlockedGroups, devices, userInfoSuccess, userInfoError, queryCriterias, targetArea, targetedUsers, blockedUsers, athoc.iws.publishing.rbt);
                }
                    ////else if ((data.AlertStatus == undefined && athoc.iws.alert.source == 'rbt'))
                    ////        athoc.iws.publishing.UpdateContactInfo(entityId, context, targetedAndBlockedGroups, devices, userInfoSuccess, userInfoError, queryCriterias, targetArea, targetedUsers, blockedUsers, athoc.iws.publishing.rbt);
                else if ((data.AlertStatus == undefined || data.AlertStatus === 'Live') && (athoc.iws.alert.source == 'rbt'))
                    athoc.iws.publishing.UpdateContactInfo(entityId, context, targetedAndBlockedGroups, devices, userInfoSuccess, userInfoError, queryCriterias, targetArea, targetedUsers, blockedUsers, athoc.iws.publishing.rbt);


            },

            //Returns users count for the sent alert
            getUsersCountFromAlert: function (alertid) {
                var current = athoc.iws.publishing.view;
                var alertData =
                  {
                      url: athoc.iws.publishing.urls.GetUsersCountFromAlertUrl + "?alertId=" + alertid,
                      contentType: 'application/json',
                      dataType: 'json',
                      type: 'GET',
                      cache: false
                  };
                var userInfoSuccess = function (data) {
                    if (data.Success) {
                        current.viewModel.TotalUsers(data.TotalCount);
                        athoc.iws.alert.reviewandpublish.SessionId = data.SessionId;
                    } else {
                        $('#alertView').find("#messagePanel").messagesPanel({ messages: [{ Type: '4', Value: data.Message }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                    }
                };

                var userInfoError = function (error) {
                    console.log(error);
                };

                var ajaxOptions = $.extend({}, AjaxUtility(userInfoError, userInfoSuccess).ajaxPostOptions, alertData);
                $.ajax(ajaxOptions);
            },

            //replace placeholder values before publishing
            replacePlaceholder: function () {

                if (athoc.iws.publishing.view.replacedPlaceholder)
                    return;
                athoc.iws.publishing.view.replacedPlaceholder = true;

                var placeholders = null;
                if (athoc.iws.alert.placeholder) {
                    placeholders = athoc.iws.alert.placeholder.getModel();
                }


                var viewmodel = athoc.iws.publishing.view.viewModel.data;

                var replacementModels =
                    [{ GroupId: 0, FieldId: 'title', Value: viewmodel.Content.Title(), MinLength: 3, MaxLength: 100, Label: 'Title' },
                        { GroupId: 0, FieldId: 'body', Value: viewmodel.Content.Body(), MinLength: 0, MaxLength: 4000, Label: 'Body' }];

                if (viewmodel.Content.ResponseOptionId() == 0 && viewmodel.Content.ResponseOptions().length) {
                    $.each(viewmodel.Content.ResponseOptions(), function (index, objOption) {
                        replacementModels.push({ GroupId: 0, FieldId: 'response-option-' + index, Value: objOption.ResponseText(), MinLength: 1, MaxLength: 64, Label: 'Response Option ' + (index + 1) });
                    });
                }

                var deviceOptionArray = [];
                var deviceGroupOptionsRawXML = [];


                if (athoc.iws.publishing.source == "a") {

                    var massDeviceDeviceOptionsModel = athoc.iws.publishing.massdevices.getModel();

                    if (massDeviceDeviceOptionsModel != null) {
                        deviceOptionArray = deviceOptionArray.concat(massDeviceDeviceOptionsModel.MassDeviceGroupOptions);
                    }

                    var targetUsersModel = athoc.iws.publishing.targetUsers.getModel();
                    if (targetUsersModel != null) {
                        deviceOptionArray = deviceOptionArray.concat(targetUsersModel.DeviceGroupOptions);
                    }

                    deviceOptionArray = athoc.iws.publishing.view.filterDeviceOptionForSelectedDevices(deviceOptionArray);

                    if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Targeting.Readonly || athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Delivery.Readonly) {
                        //if target user is read only, get 
                        this.replacePlaceholderAjax([], replacementModels, placeholders, this.PresetDeviceGroupOptions);
                    } else {
                        this.replacePlaceholderAjax(deviceOptionArray, replacementModels, placeholders);
                    }

                    //athoc.iws.publishing.view.showDeviceCustomText(deviceOptionArray);

                } else {
                    this.replacePlaceholderAjax(deviceOptionArray, replacementModels, placeholders, athoc.iws.publishing.view.publishingModel.PresetDeviceGroupOptions);
                }
            },

            replacePlaceholderAjax: function (deviceOptionArray, replacementModels, placeholders, deviceGroupOptionsRawXML) {

                $(".customTextWrapper").hide();

                $('#btnPublishAlert').prop("disabled", true);

                var model = {
                    PlaceholderReplacementModels: replacementModels,
                    SelectedPlaceHolders: placeholders,
                    DeviceGroupOptions: deviceOptionArray,
                    DeviceGroupOptionsRawXML: deviceGroupOptionsRawXML
                };

                var dlAjaxOption =
                {
                    url: "/athoc-iws/publishing/ReplacePlaceholders",
                    contentType: false,
                    dataType: 'json',
                    type: 'POST',
                    data: JSON.stringify(model)
                };

                $.AjaxLoader.hideLoader();
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#dialogReviewAndPublish').find(".modal-body"), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();

                var ajaxSuccess = function (data) {

                    if (data.Success) {

                        //replace values into publishing model and show any validation errors
                        var vm = athoc.iws.publishing.view.viewModel.data;
                        var isValid = true;
                        if (data.Model && data.Model.PlaceholderReplacementModels) {
                            $.each(data.Model.PlaceholderReplacementModels, function (index, objResponse) {
                                var field = objResponse.Label;
                                if (objResponse.GroupId == 0 && objResponse.FieldId == 'title') {
                                    vm.Content.Title(objResponse.Value);
                                } else if (objResponse.GroupId == 0 && objResponse.FieldId == 'body') {
                                    vm.Content.Body(objResponse.Value);
                                    if (objResponse.Value) {
                                        athoc.iws.publishing.view.viewModel.bodyWithLineBreak($.htmlEncode(objResponse.Value.trim()).replace(/(?:\r\n|\r|\n)/g, '<br />'));
                                    } else {
                                        athoc.iws.publishing.view.viewModel.bodyWithLineBreak('');
                                    }
                                } else if (objResponse.GroupId == 0 && objResponse.FieldId.lastIndexOf('response-option-', 0) === 0) {
                                    var id = objResponse.FieldId.split("-")[2];
                                    athoc.iws.publishing.view.viewModel.data.Content.ResponseOptions()[id].ResponseText(objResponse.Value);

                                    //fill count text replacement
                                    if (athoc.iws.publishing.fillcount && athoc.iws.publishing.fillcount.viewModel && athoc.iws.publishing.fillcount.viewModel.fillCountModel
                                        && athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId && athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId() > 0) {
                                        var fillCountId = athoc.iws.publishing.fillcount.viewModel.fillCountModel.ResponseOptionId() - 1;

                                        //compare FillCount's response option with currently replaced response option
                                        if (id == fillCountId && $('#dialogReviewAndPublish').find("#responseText").length > 0) {
                                            var fillCountResponseText = $('#dialogReviewAndPublish').find("#responseText");
                                            fillCountResponseText.html(objResponse.Value);
                                            fillCountResponseText.attr("title", objResponse.Value);
                                        }
                                    }

                                } else if (objResponse.GroupId != 0) {
                                    var deviceName = athoc.iws.publishing.view.setDeviceCustomText(objResponse.GroupId, objResponse.FieldId, objResponse.Value, false, field);
                                    if (deviceName && deviceName != "") {
                                        field = deviceName;
                                        if (objResponse.Label != "") {
                                            field += ' ' + objResponse.Label;
                                        }
                                    } else {
                                        field = objResponse.Label;
                                    }
                                }

                                if (!athoc.iws.publishing.view.isPlaceholderReplacementModelValid(objResponse)) {
                                    isValid = false;
                                    var errorString = kendo.format(athoc.iws.publishing.resources.Publishing_Replaceholder_ErrorMessage, field, objResponse.MinLength, objResponse.MaxLength);
                                    athoc.iws.publishing.view.messages.push({ Type: '4', Value: errorString });
                                }
                            });
                        }

                        if (data.Model && data.Model.RecordingPreviewModels) {
                            $.each(data.Model.RecordingPreviewModels, function (index, objAudio) {
                                athoc.iws.publishing.view.setDeviceAudio(objAudio.GroupId, objAudio.Id, objAudio.Name, objAudio.Stream);
                            });
                        }

                        if (!isValid && athoc.iws.publishing.view.messages.length > 0) {
                            $('#dialogReviewAndPublish').find("#messagePanel").messagesPanel({ messages: athoc.iws.publishing.view.messages }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                            $('#btnPublishAlert').prop("disabled", true);
                        } else {
                            $('#btnPublishAlert').prop("disabled", false);
                        }


                    } else {
                        athoc.iws.publishing.view.messages.push({ Type: '4', Value: data.Messages });
                        $('#dialogReviewAndPublish').find("#messagePanel").messagesPanel({ messages: athoc.iws.publishing.view.messages }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        $('#dialogReviewAndPublish').find('.modal-body').scrollTop(0);
                        $('#btnPublishAlert').prop("disabled", true);
                    }
                    $(".customTextWrapper").show();
                    $.AjaxLoader.hideLoader();

                };

                //athoc.iws.publishing.content.ReadonlyViewModel.alertTitle('');
                //athoc.iws.publishing.content.ReadonlyViewModel.bodyWithLineBreak('');

                //kendo.ui.progress($("#publishing-content-detail"), true);

                var ajaxOptions = $.extend({}, AjaxUtility(null, ajaxSuccess).ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);

            },
            getCustomTextViaAjax: function (deviceGroupOptionsRawXML) {
                //store as variable here so it can be obtained while replacing with placeholder in r&p
                this.PresetDeviceGroupOptions = deviceGroupOptionsRawXML;
                var model = {
                    optionPresets: deviceGroupOptionsRawXML
                };

                var dlAjaxOption =
                {
                    url: "/athoc-iws/publishing/RetrieveCustomText",
                    contentType: 'application/json',
                    dataType: 'json',
                    type: 'POST',
                    data: JSON.stringify(model)
                };

                var ajaxSuccess = function (data) {

                    kendo.ui.progress($("#publishing-content-detail"), false);

                    if (data.Success) {
                        //replace values into publishing model and show any validation errors
                        var vm = athoc.iws.publishing.view.viewModel.data;
                        var isValid = true;
                        if (data.Model && data.Model.PlaceholderReplacementModels) {
                            $.each(data.Model.PlaceholderReplacementModels, function (index, objResponse) {
                                var field = objResponse.Label;

                                var deviceName = athoc.iws.publishing.view.setDeviceCustomText(objResponse.GroupId, objResponse.FieldId, objResponse.Value, true, field);
                                if (deviceName && deviceName != "") {
                                    field = deviceName;
                                    if (objResponse.Label != "") {
                                        field += ' ' + objResponse.Label;
                                    }
                                } else {
                                    field = objResponse.Label;
                                }
                            });
                        }
                    }

                };

                //athoc.iws.publishing.content.ReadonlyViewModel.alertTitle('');
                //athoc.iws.publishing.content.ReadonlyViewModel.bodyWithLineBreak('');

                kendo.ui.progress($("#publishing-content-detail"), true);

                var ajaxOptions = $.extend({}, AjaxUtility(null, ajaxSuccess).ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);

            },
            //filter device options for selected devices only
            filterDeviceOptionForSelectedDevices: function (deviceOptionArray) {
                if (!deviceOptionArray || deviceOptionArray.length == 0) {
                    return deviceOptionArray;
                }

                var selecedDevicesOptionArray = [];

                var isMassDeviceTargeted = (athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList() && athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList().length > 0);
                try {
                    isMassDeviceTargeted = (athoc.iws.publishing.massdevices.getModel().MassDevices && athoc.iws.publishing.massdevices.getModel().MassDevices.length > 0);
                } catch (e) {

                }

                var isPersonalDeviceTargeted = (athoc.iws.publishing.view.viewModel.personalDeviceList && athoc.iws.publishing.view.viewModel.personalDeviceList.Devices().length > 0);

                _.each(deviceOptionArray, function (deviceOption) {
                    if (deviceOption && deviceOption.GroupId && deviceOption.GroupId > 0) {
                        if (isPersonalDeviceTargeted) {
                            var personalDeviceObj = jQuery.grep(athoc.iws.publishing.view.viewModel.personalDeviceList.Devices(), function (device) { return device.GroupId() == deviceOption.GroupId; });
                            if (personalDeviceObj && personalDeviceObj.length > 0) {
                                selecedDevicesOptionArray.push(deviceOption);
                            }
                        }

                        if (isMassDeviceTargeted) {

                            var deviceObj = jQuery.grep(athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList(), function (device) { return device.GroupId() == deviceOption.GroupId; });
                            if (deviceObj && deviceObj.length > 0) {
                                selecedDevicesOptionArray.push(deviceOption);
                            } else {
                                try {
                                    //check on non-readonly mass device model to see if device group is targeted
                                    var deviceObj = jQuery.grep(athoc.iws.publishing.massdevices.getModel().MassDevices, function (device) { return device.GroupId == deviceOption.GroupId; });
                                    if (deviceObj && deviceObj.length > 0) {
                                        selecedDevicesOptionArray.push(deviceOption);
                                    }
                                } catch (e) {
                                }
                            }
                        }
                    }
                });

                return selecedDevicesOptionArray;
            },

            //method to set device custom text
            setDeviceCustomText: function (groupId, fieldId, customText, setRawValue, label) {

                /*localizizing label - no longer deduce label from fieldId
                var label = "Value";
                var deviceName = "";
                if (fieldId && fieldId.indexOf(".") >= 0) {
                    var arrLabel = fieldId.split(".");
                    label = arrLabel[arrLabel.length - 1];
                }*/

                var deviceName = "";
                if (athoc.iws.publishing.view.viewModel.personalDeviceList && athoc.iws.publishing.view.viewModel.personalDeviceList.Devices().length > 0) {
                    _.each(athoc.iws.publishing.view.viewModel.personalDeviceList.Devices(), function (device) {
                        if (device.GroupId() == groupId) {
                            athoc.iws.publishing.view.setDeviceCustomTextProperty(device, fieldId, label, customText, setRawValue);
                            deviceName = device.GroupName();
                        }
                    });
                }


                if (athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList() && athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList().length > 0) {
                    _.each(athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList(), function (deviceGroup) {
                        if (deviceGroup.GroupId() == groupId) {
                            athoc.iws.publishing.view.setDeviceCustomTextProperty(deviceGroup, fieldId, label, customText, setRawValue);
                            _.each(deviceGroup.DeviceList(), function (device) {
                                athoc.iws.publishing.view.setDeviceCustomTextProperty(device, fieldId, label, customText, setRawValue);
                                deviceName = device.GroupName();
                            });
                        }
                    });
                }

                return deviceName;
            },

            //helper method for setting device custom text property
            setDeviceCustomTextProperty: function (device, fieldId, label, customText, setRawValue) {
                if (!device.CustomText()) {
                    if (customText && customText != '') {
                        var item = { Field: fieldId, Name: label };
                        if (setRawValue) {
                            item.RawValue = customText;
                        } else {
                            item.Value = customText;
                        }
                        device.CustomText(new Array(item));
                    }
                } else {
                    //replace if exists
                    var exists = false;
                    _.each(device.CustomText(), function (txt) {

                        var name = txt.Name;
                        if (typeof txt.Name == "function") {
                            name = txt.Name();
                        }

                        if (name == label) {
                            exists = true;
                            if (setRawValue) {
                                txt.RawValue = customText;
                            } else {
                                txt.Value = customText;
                            }
                        }
                    });
                    if (!exists && customText && customText != '') {
                        var item = { Field: fieldId, Name: label };
                        if (setRawValue) {
                            item.RawValue = customText;
                        } else {
                            item.Value = customText;
                        }

                        device.CustomText().push(item);
                    }
                }
            },

            //show custom text for personal/mass device
            showCustomText: function (targetDiv, event) {

                //check to see if you are in review and publish or read only
                var isReviewAndPublish = ($(event.target).closest("#dialogReviewAndPublish").length != 0) || ($(event.target).closest("#PersonalDeviceListDetailForAlertDetail").length != 0);

                if (this.CustomText) {
                    $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP").html('');
                    athoc.iws.alert.reviewandpublish.showModalonModal("#targetedUsersSummaryRP");
                    $("#targetedUsersSummaryRP").find("#spanTitleDetails").text(athoc.iws.publishing.resources.Publishing_Custom_Text);
                    var summaryDiv = $("#targetedUsersSummaryRP").find("#targetedUsersSummaryDetailRP");
                    var content = "<div style='word-wrap: break-word;'>";
                    if (this.CustomText().length == 1) {
                        var value = this.CustomText()[0].Value;
                        if (!isReviewAndPublish) {
                            if (typeof this.CustomText()[0].RawValue == "function") {
                                value = this.CustomText()[0].RawValue();
                            } else {

                                if (this.CustomText()[0].RawValue != undefined)
                                    value = this.CustomText()[0].RawValue;
                            }
                        }
                        var textValue = $.htmlEncode(value).replace(/(?:\r\n|\r|\n)/g, '<br />');
                        content = textValue;
                    } else if (this.CustomText().length > 1) {
                        _.each(this.CustomText(), function (customText) {
                            var value = customText.Value;

                            if (!isReviewAndPublish) {
                                if (typeof customText.RawValue == "function") {
                                    value = customText.RawValue();
                                } else {
                                    if (customText.RawValue != undefined)
                                        value = customText.RawValue;
                                }
                            }
                            var txtValue = $.htmlEncode(value).replace(/(?:\r\n|\r|\n)/g, '<br />');

                            var name = customText.Name;
                            if (typeof customText.Name == "function")
                                name = customText.Name();
                            content += "<b>" + name + "</b> <br/>" + txtValue + "<br/><br/>";
                        });
                    }
                    content += "</div>";
                    summaryDiv.html(content);
                }
            },

            //replace device custom text before publishing (personal & mass)
            replaceDeviceCustomText: function (alert) {
                //personal devices
                if (alert && alert.TargetUsers && alert.TargetUsers.DeviceGroupOptions && alert.TargetUsers.DeviceGroupOptions.length > 0
                    && athoc.iws.publishing.view.viewModel.personalDeviceList && athoc.iws.publishing.view.viewModel.personalDeviceList.Devices().length > 0) {
                    _.each(alert.TargetUsers.DeviceGroupOptions, function (deviceOption) {
                        var deviceObj = jQuery.grep(athoc.iws.publishing.view.viewModel.personalDeviceList.Devices(), function (device) { return device.GroupId() == deviceOption.GroupId; });
                        if (deviceObj && deviceObj.length > 0) {
                            athoc.iws.publishing.view.replaceDeviceOptions(deviceOption, deviceObj[0]);
                        }
                    });
                }

                //mass devices 
                if (alert && alert.MassDeviceGroupOptions && alert.MassDeviceGroupOptions.length > 0
                    && athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList() && athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList().length > 0) {
                    _.each(alert.MassDeviceGroupOptions, function (deviceOption) {
                        var deviceObj = jQuery.grep(athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList(), function (device) { return device.GroupId() == deviceOption.GroupId; });
                        if (deviceObj && deviceObj.length > 0) {
                            athoc.iws.publishing.view.replaceDeviceOptions(deviceOption, deviceObj[0]);
                        }
                    });
                }

                return alert;
            },

            //method to set audio property
            setDeviceAudio: function (groupId, audioId, fileName, audioStream) {
                var deviceName = "";

                if (athoc.iws.publishing.view.viewModel.personalDeviceList && athoc.iws.publishing.view.viewModel.personalDeviceList.Devices().length > 0) {
                    _.each(athoc.iws.publishing.view.viewModel.personalDeviceList.Devices(), function (device) {
                        if (device.GroupId() == groupId) {
                            deviceName = device.GroupName();
                            if (jQuery.isFunction(device.RecordedMessage)) {
                                device.RecordedMessage({ AudioId: audioId, FileName: fileName, Stream: audioStream });
                            } else {
                                //device.RecordedMessage({ AudioId: audioId, FileName: fileName, Stream : audioStream });
                            }
                        }
                    });
                }

                return deviceName;
            },

            //show recorded audio
            showAudio: function (targetDiv, event) {
                //check to see if you are in review and publish or read only
                if (this.RecordedMessage) {
                    var fileName = "";
                    var audioId = "";
                    var audioStream = "";

                    if (jQuery.isFunction(this.RecordedMessage)) {
                        fileName = this.RecordedMessage().FileName;
                        audioId = this.RecordedMessage().AudioId;
                        audioStream = this.RecordedMessage().Stream;
                    } else {
                        fileName = this.RecordedMessage.FileName();
                        audioId = this.RecordedMessage.AudioId();
                        audioStream = this.RecordedMessage.Stream();
                    }
                    $("#recordedMessageModal").find("#recorderContainer").html('');
                    athoc.iws.alert.reviewandpublish.showModalonModal("#recordedMessageModal");
                    $("#recordedMessageModal").find("#spanTitleDetails").text("Recorded Message");
                    var summaryDiv = $("#recordedMessageModal").find("#recorderContainer");
                    var content = "<div id='readOnlyRecordedMessage'></div>";
                    summaryDiv.html(content);

                    $("#recordedMessageModal").find("#btn_Cancel").click(function () {
                        athoc.iws.publishing.view.readonlyRecordedMessage.stopAudio();
                        $("#recordedMessageModal").find("#recorderContainer").html('');
                    });

                    require(["publishing/AudioUploader/AudioUploader"], function (AudioUploader) {
                        var options = {
                            fileName: fileName,
                            audioId: audioId,
                            fileStream: audioStream,
                            isReadOnly: true,
                            isBrowseSpecific: navigator.userAgent.toLowerCase().indexOf('trident') != -1 ? true : false,
                            operator: audioUploader.operatorName,
                        }
                        var currentItem = $("#recordedMessageModal").find("#readOnlyRecordedMessage");
                        if (athoc.iws.publishing.view.readonlyRecordedMessage) {
                            athoc.iws.publishing.view.readonlyRecordedMessage.destroy();
                        }

                        athoc.iws.publishing.view.readonlyRecordedMessage = new AudioUploader(options, $(currentItem)[0], audioUploader);
                        athoc.iws.publishing.view.readonlyRecordedMessage.startup();
                        athoc.iws.publishing.view.readonlyRecordedMessage.viewModel.isChanged(audioUploader.isAudioFileChanged);
                    });
                }
            },

            //helper for replaceing device options
            replaceDeviceOptions: function (deviceOption, device) {
                if (!deviceOption || !device || !deviceOption.Options || !device.CustomText())
                    return;

                _.each(deviceOption.Options, function (option) {
                    var sourceOption = jQuery.grep(device.CustomText(), function (src) { return src.Field == option.Name; });
                    if (sourceOption && sourceOption.length > 0) {
                        option.Value = sourceOption[0].Value;
                    }
                });
            },

            //checkLengthInByte method has been used from library "ExtensionToolbox.js" under cdn scripts
            isPlaceholderReplacementModelValid: function (model) {
                if (model && model.Value) {
                    return (model.Value.length >= model.MinLength && model.Value.length <= model.MaxLength);
                    //var textByteLength = checkLengthInByte(model.Value);
                    //return (textByteLength >= model.MinLength && textByteLength <= model.MaxLength);
                }
                else if (!model.Value && model.MinLength == 0) {
                    return true;
                }
                return false;
            },

            //show more less for header
            updateMoreLess: function (targetDiv) {
                targetDiv.find('.moretext').each(function () {
                    if ($(this).find(".morecontent").length == 0) {
                        var showChar = 300;
                        var ellipsestext = "...";
                        var moretext = "more";
                        var content = $(this).html();

                        if (content.length > showChar) {
                            var c = content.substr(0, showChar);
                            var h = content.substr(showChar, content.length - showChar);

                            var html = c + '<span class="moreelipses">' + ellipsestext + '</span><span class="morecontent"><span>' + h + '</span>&nbsp;&nbsp;<a href="" class="morelink">' + moretext + '</a></span>';

                            $(this).html(html);
                        }
                    }
                });

                targetDiv.find('.morelink').unbind('click');

                targetDiv.find(".morelink").click(function () {
                    var moretext = "more";
                    var lesstext = "less";
                    if ($(this).hasClass("less")) {
                        $(this).removeClass("less");
                        $(this).html(moretext);
                    } else {
                        $(this).addClass("less");
                        $(this).html(lesstext);
                    }
                    $(this).parent().prev().toggle();
                    $(this).prev().toggle();
                    return false;
                });
            },

            //publish alert
            publishAlert: function () {
                //Get updated data from each section in viewmodel
                var alertObj = ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data);


                alertObj.Origin = athoc.iws.publishing.view.Origin;
                if (athoc.iws.publishing.view.Origin != "AlertDetail") {
                    alertObj.ParentId = athoc.iws.publishing.view.ParentId;
                }

                //replace device custom text with placeholder
                alertObj = athoc.iws.publishing.view.replaceDeviceCustomText(alertObj);

                var dlAjaxOption =
                {
                    url: athoc.iws.publishing.urls.PublishAlertUrl,
                    contentType: false,
                    dataType: 'json',
                    type: 'POST',
                    data: JSON.stringify(alertObj)
                };

                //Send view model to server for saving
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#dialogReviewAndPublish'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();

                var ajaxSuccess = function (data) {

                    if (data.Success) {
                        athoc.iws.publishing.detail.setChanged(false);
                        athoc.iws.publishing.view.publishedAlertId = data.Data.EntityId;
                        $('#dialogReviewAndPublish').find("#messagePanel").messagesPanel({ messages: [{ Type: '9', Value: ((alertObj.AlertScheduleSettings != null && alertObj.AlertScheduleSettings != undefined && alertObj.AlertScheduleSettings.ScheduleAlertPublishStartModeSettime != 'ASAP') ? athoc.iws.publishing.resources.Publishing_Msg_Alert_Scheduled_Successfully : athoc.iws.publishing.resources.Publishing_Msg_ForMoreInformation_ClickAlertSummary) }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        $('#dialogReviewAndPublish').find('.modal-body').scrollTop(0);
                        $("#dialogReviewAndPublish").find(".pre-publish").hide();
                        $("#dialogReviewAndPublish").find(".post-publish").show();
                        $("#btnDialogReviewEdit").hide();
                        $("#btnPublishViewReport").unbind("click");
                        $("#btnPublishViewReport").click(function () { athoc.iws.publishing.view.viewReport(data.Data.EntityId); });
                        if (data.Data.AlertStatus == "Scheduled" ||   data.Data.AlertStatus == "1")  //For Scheduled AlertStatus=1
                            $("#dialogReviewAndPublish").find("#btnPublishViewReport").hide();
                        else
                            $("#dialogReviewAndPublish").find("#btnPublishViewReport").show();
                    } else {
                        athoc.iws.publishing.view.messages.push({ Type: '4', Value: data.Messages });
                        $('#dialogReviewAndPublish').find("#messagePanel").messagesPanel({ messages: athoc.iws.publishing.view.messages }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        $('#dialogReviewAndPublish').find('.modal-body').scrollTop(0);
                    }

                    $.AjaxLoader.hideLoader();

                };

                var ajaxOptions = $.extend({}, AjaxUtility(null, ajaxSuccess).ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);

                return true;
            },

            //download alert as pdf
            downloadPdfFile: function (postUrl) {
                try {
                    $("#dialogReviewAndPublish").append('<div id="displayShadow" class="modal-backdrop fade in"><div class="LoadingImage_Overlay"><img src= ' + athoc.iws.publishing.urls.cdnUrl + "Images/ajax-loader.gif" + '></img></div></div>');

                    var alertObj = "";
                    athoc.iws.publishing.detail.setChanged(false);
                    var personalDevicesList = ko.mapping.toJS(athoc.iws.publishing.view.viewModel.personalDeviceList.Devices());
                    //Get updated data from each section in viewmodel
                    alertObj = {
                        Content: ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.Content),
                        TargetUsers: ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.TargetUsers),
                        DeviceList: personalDevicesList,
                        TargetOrg: ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.TargetOrg),
                        AlertScheduleSettings: athoc.iws.publishing.settings.IsSchedulingSupported ? ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.AlertScheduleSettings) : null,
                        MassDevices: ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.MassDevices),
                        MassDeviceGroupOptions: ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.MassDeviceGroupOptions)
                    };


                    // This is for Mass device list data, Custom text would already replaced here with placeholder if any.
                    var massDevicesList = ko.mapping.toJS(athoc.iws.publishing.massdevices.readOnlyModel.massDeviceList());
                    var arrMassOption = [];

                    _.each(massDevicesList, function (device) {
                        var cText = []
                        if (device.DeviceList != null && device.DeviceList.length > 0) {
                            _.each(device.DeviceList, function (dobj) {
                                _.each(dobj.CustomText, function (cusObj) {
                                    if (cusObj != null && cusObj.Name != null && cusObj.Name != "")
                                        cText.push({ Name: cusObj.Name, Value: cusObj.Value });
                                });

                                var massSelectedDevice = {
                                    GroupId: device.GroupId,
                                    DeviceId: dobj.DeviceId,
                                    Options: cText
                                };

                                arrMassOption.push(massSelectedDevice);
                            });
                        }
                    });

                    // This is for personal device list data, Custom text would already replaced here with placeholder if any.                
                    var arrDeviceOption = [];

                    _.each(personalDevicesList, function (device) {
                        var cText = []
                        if (device.CustomText != null) {
                            _.each(device.CustomText, function (dobj) {
                                cText.push({ Name: dobj.Name, Value: dobj.Value });
                            })
                        }

                        var personalSelectedDevice = {
                            GroupId: device.GroupId == null ? 0 : device.GroupId,
                            DeviceId: device.DeviceId == null ? 0 : device.DeviceId,
                            Options: cText
                        };

                        arrDeviceOption.push(personalSelectedDevice);

                    });

                    var piechartData = $("#dialogReviewAndPublish").find("#piechartSummaryDetail").outerHTML();
                    var targetingSummary = $("#dialogReviewAndPublish").find("#targetSummaryDetail").outerHTML();
                    //Added the condition to check the targetSummary counts. If all below counts are Zero assigning null to the targetSummary bug#16402
                    if ((alertObj.TargetUsers.TargetedBlockedUsers != null && alertObj.TargetUsers.TargetedBlockedUsers.length == 0) && (alertObj.TargetUsers.Devices != null && alertObj.TargetUsers.Devices.length == 0) && (alertObj.TargetUsers.TargetingNodes != null && alertObj.TargetUsers.TargetingNodes.length == 0))
                        targetingSummary = "";

                    if (athoc.iws.publishing.rbt != null && athoc.iws.publishing.rbt.EntityFilterId != "") {
                        targetingSummary = 'notapplicable';
                    }
                    var locationdata = "";
                    if (athoc.iws.publishing.view.viewModel.isGeoSelected() && $("#dialogReviewAndPublish").find(".readOnlyMiniMapHolder").html() != "") {
                        locationdata = $("#dialogReviewAndPublish").find(".readOnlyMiniMapHolder").outerHTML();
                    }

                    athoc.iws.publishing.view.viewModel.audioFileName("");
                    var foundRMsg = _.find(personalDevicesList, function (item) {
                        return item.RecordedMessage != null;
                    });
                    if (foundRMsg) {
                        athoc.iws.publishing.view.viewModel.audioFileName(foundRMsg.RecordedMessage.FileName);
                    }
                    var fillCounthtml = "";
                    var oldHtml = "";

                    if (($('#dialogReviewAndPublish #FillCountSummary') != undefined) && ($('#dialogReviewAndPublish #FillCountSummary').css('display') == 'block') && ($('#dialogReviewAndPublish #FillCountSummary').find('#FillCountDetails').css('display') == 'block')) {
                        oldHtml = $('#dialogReviewAndPublish #FillCountSummary').find('#FillCountDetails').outerHTML();
                        fillCounthtml = $('#dialogReviewAndPublish #FillCountSummary').find('#FillCountDetails');
                        fillCounthtml.find(".wide span").attr("style", "width:200px;word-wrap:wrap-all;white-space: normal;display:block;margin-right:10px;margin-bottom:5px");

                    }

                    var param = $.param({
                        feed: ko.toJSON(alertObj), pieChartData: piechartData, locationData: locationdata,
                        targetingSummary: targetingSummary, MassDevicesList: ko.toJSON(arrMassOption),
                        PersonalDevicesList: ko.toJSON(arrDeviceOption), TotalUsers: athoc.iws.publishing.view.viewModel.TotalUsers()
                        , audioFileName: athoc.iws.publishing.view.viewModel.audioFileName() != "" ? ko.toJSON(athoc.iws.publishing.view.viewModel.audioFileName()) : "",
                        fillCountInfo: fillCounthtml != "" ? fillCounthtml.outerHTML() : ""
                    });

                    if (oldHtml != '') {
                        $('#dialogReviewAndPublish #FillCountSummary').html('');
                        $('#dialogReviewAndPublish #FillCountSummary').html(oldHtml);
                    }

                    $.fileDownload(postUrl, {
                        httpMethod: "POST",
                        data: param,
                        successCallback: function () { $("#dialogReviewAndPublish").find('#displayShadow').remove(); },
                        failureCallback: function () { $("#dialogReviewAndPublish").find('#displayShadow').remove(); }
                    });

                }
                catch (ex) {
                    localStorage.setItem('pdfError', ex);
                    $("#dialogReviewAndPublish").find('#displayShadow').remove();

                }
                return true;
            },
        }
    }();
}