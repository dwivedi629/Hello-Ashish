﻿/// <reference path="athoc.iws.alert.placeholder.js" />
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};

if (athoc.iws.publishing) {
    athoc.iws.publishing.detail = function () {
        return {
            parameters: null,
            entityId: 0,
            context: null,
            alertOrgin: null,
            rbtCriteria: null,
            targetByUserArea: false,
            isQueryLoaded: false,
            isIUTLoaded: false,
            isTreeLoaded: false,
            rbt: null,
            init: function (args) {
                this.parameters = args;
                athoc.iws.publishing.content.init();
            },
            //model to hold publishing model for alert/scenario
            //structure is same as AtHoc.IWS.Web.Models.Publishing.PublishingModel C# class
            viewModel: {},
            isEverythingLoaded: function () {
                return ((!athoc.iws.publishing.settings.IsAdvancedQuerySuuported || this.isQueryLoaded)
                    && (!athoc.iws.publishing.settings.IsIndividualUserTargetingSupported || this.isIUTLoaded)
                    && (this.isTreeLoaded));
                //|| (athoc.iws.publishing.rbt != undefined);
            },
            resetLoadedStatus: function () {
                this.isQueryLoaded = false;
                this.isIUTLoaded = false;
                this.isTreeLoaded = false;
            },
            //load publishing model for alert/scenario
            loadPublishingModel: function (loadUrl, isEdit, id, loadTargetUsers) {

                athoc.iws.publishing.detail.firstLoad = true;
                athoc.iws.publishing.detail.userSearchOnce = false;

                this.resetLoadedStatus();
                if (athoc.iws.scenario != undefined) {
                    athoc.iws.scenario.breadcrumbModel.updateTitle('', undefined, undefined, 'scenarioDetail');
                }
                if (athoc.iws.alert != undefined) {
                    athoc.iws.alert.breadcrumbModel.updateTitle('', undefined, undefined, 'alertDetail');
                }
                athoc.iws.publishing.detail.setChanged(false);

                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();

                var dlSuccess = function (data) {
                    $(".publishing-detail").show();

                    if (data.Success) {
                        athoc.iws.publishing.detail.bindModel(data, isEdit);
                        if (typeof loadTargetUsers != "undefined" && loadTargetUsers) {
                            athoc.iws.publishing.targetUsers.setPresetDeviceOptions(data.Data.PresetDeviceGroupOptions);                            
                        }
                        //target users should be loaded after the binding the viewmodel that is the reason it was moved to here, it must happen only in case of rbt, in other cases it will proceed as usual.
                        if ((athoc.iws.alert && athoc.iws.alert.action && athoc.iws.alert.action == 'rbt')||(typeof loadTargetUsers != "undefined" && loadTargetUsers))
                             athoc.iws.publishing.targetUsers.load(id);
                    } else {
                        $.AjaxLoader.hideLoader();
                        $('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: data.Messages }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                    }
                    $("#alertListBreadcrumbs .title-crumb:last").addClass("ellipsis width80");
                };

                var dlAjaxOption =
                {
                    type: "POST",
                    url: loadUrl,
                };

                var ajaxOptions = $.extend({}, AjaxUtility(null, dlSuccess).ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);
            },

            //bind publishing model to ui with knockout
            bindModel: function (data, isEdit) {
                athoc.iws.publishing.detail.bindFingerTabs();

                athoc.iws.publishing.detail.viewModel = data.Data;

                $.AjaxLoader.hideLoader();

                //remove old validation
                $(".warning").each(function () { $(this).parent().remove(); });

                athoc.iws.publishing.rbt = data.Data.rbt;
                athoc.iws.publishing.detail.bindReadonlyView(data.Data);
              
                athoc.iws.publishing.context = data.Data.Context;
                athoc.iws.publishing.contextName = data.Data.ContextName;
                athoc.iws.publishing.entityId = data.Data.EntityId;
               
                athoc.iws.publishing.targetByUserArea = data.Data.TargetUsers.TargetUsersByArea;

                //if scenario bind this section, Context 1 is for scenario
                if (data.Data.Context == 1) {
                    athoc.iws.publishing.scenario.bind(data.Data.ScenarioSection);
                    // to bind scenario settings 
                    athoc.iws.scenario.settings.bind(data.Data.ScenarioSettings);

                    
                    athoc.iws.publishing.content.bind(data.Data.Content, data.Data.Context);
                    athoc.iws.publishing.targetUsers.bind(data.Data.TargetUsers, data.Data.PresetDeviceGroupOptions);
                    athoc.iws.publishing.iut.bind(data.Data.TargetUsers.TargetedBlockedUsers);
                    //
                   // athoc.iws.publishing.targetOrg.load(data.Data.TargetOrg);
                    // to bind mass devices settings
                    athoc.iws.publishing.massdevices.bind(data.Data.MassDevices, data.Data.Context, data.Data.ScenarioSettings.Delivery.Readonly, data.Data.PresetDeviceGroupOptions);
                    // to bind scenario schedule settings 
                    athoc.iws.scenario.schedule.bind(data.Data.ScenarioScheduleSettings);
                    athoc.iws.publishing.massdevices.collapsePanel();
                    
                } else {

                    //apply scenario settings on alert 
                    athoc.iws.scenario.settings.applySettingsOnAlert(data.Data.ScenarioSettings, data.Data);
                    //bind test alert device list with addresses
                    athoc.iws.alert.test.bind(data.Data.TestDeviceList);
                    // apply place holder settings
                    athoc.iws.alert.placeholder.bind(data.Data.CustomPlaceHolders);
                    athoc.iws.publishing.alertOrgin = data.Data.AlertOrigin;
                    // to bind  alert schedule settings
                    athoc.iws.alert.schedule.bind(data.Data.ScenarioSettings, data.Data.AlertScheduleSettings); 
                }
                // Commented: Redundant call.
                athoc.iws.publishing.targetOrg.load(data.Data.TargetOrg);

                //if scenario
                if (data.Data.Context == 1) {
                    athoc.iws.scenario.breadcrumbModel.updateTitle(data.Data.ScenarioSection.Name, undefined, undefined, 'scenarioDetail');

                    $("#scenario-name").focus();

                    //show info section
                    if (isEdit) {
                        $("#scenarioCreatedBy").text(data.Data.ScenarioInfo.CreatedBy).attr("title", data.Data.ScenarioInfo.CreatedBy);
                        $("#scenarioCreatedOn").text(data.Data.ScenarioInfo.CreatedOn).attr("title", data.Data.ScenarioInfo.CreatedOn);
                        $("#scenarioUpdatedBy").text(data.Data.ScenarioInfo.UpdatedBy).attr("title", data.Data.ScenarioInfo.UpdatedBy);
                        $("#scenarioUpdatedOn").text(data.Data.ScenarioInfo.UpdatedOn).attr("title", data.Data.ScenarioInfo.UpdatedOn);
                        $("#scenarioCommonName").text(data.Data.ScenarioSection.CommonName).attr("title", data.Data.ScenarioSection.CommonName);
                        $("#templateId").text(data.Data.EntityId).attr("title", data.Data.EntityId);
                        $("#scenarioInfoSection").show();
                    }
                } else {
                    // in case of alert
                    if ((athoc.iws.publishing.settings.IsTestAlertSupported) && (data.Data.AlertStatus.toUpperCase() != "LIVE" || data.Data.AlertStatus.toUpperCase() != "ENDED") && data.Data.IsTestAlertSupportOperator) {
                        $("#btn_test_alert").show();
                    } else {
                        $("#btn_test_alert").hide();
                    }
                    //IWS-14925 - show save button after loading
                    if ((data.Data.AlertStatus.toUpperCase() != "LIVE" || data.Data.AlertStatus.toUpperCase() != "ENDED") && !$("#btn_detail_standby").is(":visible")) {
                        $("#btn_detail_save").show();
                    }
                    
                    if (athoc.iws.alert.action == 'create') {
                        var titlePrefix = '';
                        $(".severity-list").find("button").focus();
                        if (athoc.iws.alert.id == 0) {
                            if (athoc.iws.alert.source != "event") {
                                titlePrefix = "<span class='title-crumb'>"+athoc.iws.publishing.resources.Publishing_NewAlert+"</span><span class='normal-narrow mar-left5 mar-right5'>"+athoc.iws.publishing.resources.Publishing_BasedOn+"</span>";
                                athoc.iws.alert.breadcrumbModel.updateTitle(data.Data.ScenarioSection.Name, undefined, undefined, 'alertCreate', titlePrefix);
                            }
                        } else {
                            titlePrefix = "<span>"+athoc.iws.publishing.resources.Publishing_PublishAlert+"</span><span class='normal-narrow mar-left5 mar-right5'>"+athoc.iws.publishing.resources.Publishing_BasedOn+"</span>";
                            athoc.iws.alert.breadcrumbModel.updateTitle(data.Data.ScenarioSection.Name, undefined, undefined, 'alertCreate', titlePrefix);
                        }
                    }
                    if (athoc.iws.alert.action == 'rbt') {
                        var titlePrefix = '';
                        $(".severity-list").find("button").focus();
                        titlePrefix = "<span>" + athoc.iws.publishing.resources.Publishing_NewAlert + "</span><span class='normal-narrow mar-left5 mar-right5'>" + athoc.iws.publishing.resources.Publishing_BasedOn + "</span>";
                        athoc.iws.alert.breadcrumbModel.updateTitle(data.Data.Content.Title, undefined, undefined, 'alertCreate', titlePrefix);
                    }
                    else {
                        if (athoc.iws.alert.action == 'view') {//enable end button
                            if (data.Data.AlertStatus == "Live") {
                                $("#btn_alert_end").show();
                                if(athoc.iws.publishing.settings.IsSchedulingSupported)
                                $("#btn_alert_save").show();
                            }
                        }

                        $(".severity-list").find("button").focus();
                        setTimeout(function () { $(".severity-list").find("button").focus(); }, 50);
                        athoc.iws.alert.breadcrumbModel.updateTitle(data.Data.Content.Title, undefined, undefined, 'alertDetail');
                    }
                }

                //commented to avoid multiple times collapse and expand when click
                // if($._data($("html").find('.section-title, .expand-arrow-open, .expand-arrow-closed')[0], "events")== undefined)
                //    athoc.iws.publishing.detail.bindBucketExpandCollapse($("html"));

                // apply finger tab settings on on Scenario and Alert
                athoc.iws.scenario.settings.ApplysettingsOnFingerTabs(data.Data.ScenarioSettings.Targeting.EnabledTargetingTypes);
                athoc.iws.scenario.settings.ApplyOrgsettingsOnFingerTabs(data.Data.ScenarioSettings.Organization);
                if (data.Data.Context == 1) {
                    athoc.iws.publishing.detail.bindBucketExpandCollapse($("html"));
                    // toggle schedule section 
                    athoc.iws.scenario.schedule.toggleScheduleSection();
                    // apply content settings such as dropbox , Location, response option  on Scenario
                    athoc.iws.scenario.settings.applyScenarioContentSettings(data.Data.ScenarioSettings.Content);
                } else {
                    // apply content settings such as dropbox , Location, response option  on Alert
                    athoc.iws.scenario.settings.applyAlertContentSettings(data.Data.ScenarioSettings.Content);

                    athoc.iws.scenario.settings.applyCollapseSettingsOnAlert();

                }
                
                athoc.iws.scenario.settings.isFillCountEnabled = data.Data.ScenarioSettings.Targeting.FillCount;
                //for Scenario always readonly=false
                //fill count summary can be readonly=true only when readonly is set scenario settings  and section is ready  
                athoc.iws.publishing.fillcount.bind(data.Data, data.Data.Context == 1 ? false: (data.Data.ScenarioSettings.Targeting.Readonly==true && athoc.iws.publishing.targetUsers.isReadyToPublish==true));

                //after loading the data reset the changed flag to not changed
                athoc.iws.publishing.detail.setChanged(false);
                $(document).scrollTop(0);
                //if the content panel is collapse initially, map doesn't have a chance to adjust ot the size of the container
                //only needs to do it once
                //for editing mode content
                var contentDom = $('#publishing-content-edit');
                var contentExpandHeaderDom = $('#bucketTitle', contentDom);
                var expandArrow = $('.expand-arrow-closed', contentExpandHeaderDom);
                if (expandArrow.css('display') == 'block') {
                    contentExpandHeaderDom.on('click', function () {
                        if (!athoc.iws.publishing.geo.miniMap && athoc.iws.publishing.geo.geoJson) {
                            require(["widget/Map"], function (WidgetMap) {
                                athoc.iws.publishing.geo.miniMap = new WidgetMap("miniMapHolder", {i18n: athoc.iws.publishing.mapResources, zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture });
                                athoc.iws.publishing.geo.bindAlertMiniMap(athoc.iws.publishing.geo.miniMap,athoc.iws.publishing.geo.geoJson);
                            });
                        }
                        /*
                        if (!athoc.iws.publishing.geo.miniMapResized) {
                            setTimeout(function () {
                                athoc.iws.publishing.geo.miniMapResized = true;
                                athoc.iws.publishing.geo.miniMap.resize();
                                athoc.iws.publishing.geo.miniMap.zoomToFit();
                            }, 500);
                        }*/
                    });
                }
                //for readonly content
                var readOnlyContentDom = $('#publishing-content-detail');
                var readOnlyContentExpandHeaderDom = $('#bucketTitle', readOnlyContentDom);
                var readOnlyExpandArrow = $('.expand-arrow-closed', readOnlyContentExpandHeaderDom);
                if (readOnlyExpandArrow.css('display') == 'block') {
                    readOnlyContentExpandHeaderDom.on('click', function () {
                        if (!athoc.iws.publishing.view.readOnlyMap && athoc.iws.publishing.view.geoJson) {
                            require(["widget/Map"], function (WidgetMap) {
                                var reviewMapHolder = readOnlyContentDom.find(".readOnlyMiniMapHolder");
                                athoc.iws.publishing.view.readOnlyMap = new WidgetMap(reviewMapHolder, { i18n: athoc.iws.publishing.mapResources,zoomControl: false, zoomToFitControl: true, culture: languageParams.currentCulture });
                                athoc.iws.publishing.view.bindGeoAlertMiniMap(athoc.iws.publishing.view.readOnlyMap, athoc.iws.publishing.view.geoJson);
                            });
                        }
                        /*
                        if (!athoc.iws.publishing.view.readOnlyMapResized) {
                            setTimeout(function () {
                                athoc.iws.publishing.view.readOnlyMapResized = true;
                                if (athoc.iws.publishing.view.readOnlyMap) {
                                    athoc.iws.publishing.view.readOnlyMap.resize();
                                    athoc.iws.publishing.view.readOnlyMap.zoomToFit();
                                }
                                if (athoc.iws.publishing.view.readOnlyMapInRP) {
                                    athoc.iws.publishing.view.readOnlyMapInRP.resize();
                                    athoc.iws.publishing.view.readOnlyMapInRP.zoomToFit();
                                }
                            }, 500);
                        }*/
                    });
                }
            },

            //bind readonly view
            bindReadonlyView: function (data) {
                if ($("#alertView").length > 0) {
                    if (athoc.iws.publishing.view) {
                        athoc.iws.publishing.view.bind(data, $("#alertView"));
                    }
                }
            },

            //has any section got changed
            isChanged: function () {
                var changed = athoc.iws.publishing.content.isChanged || athoc.iws.publishing.scenario.isChanged || athoc.iws.publishing.massdevices.isChanged || athoc.iws.publishing.fillcount.isChanged;
                return changed;
            },

            //is ready to publish
            isReadyToPublish: function () {
                var isReady = false;
                //if alert is ready and either or targeting ready and no errors
                if (athoc.iws.publishing.contextName == "Scenario" ||  athoc.iws.publishing.contextName == "AccountTemplate")
                    isReady = athoc.iws.publishing.content.isReadyToPublish() &&
                       (athoc.iws.publishing.targetUsers.isReadyToPublish || athoc.iws.publishing.targetOrg.isReadyToPublish || athoc.iws.publishing.massdevices.isReadyToPublish) &&
                       (!athoc.iws.publishing.targetUsers.isInErrorState) && (!athoc.iws.publishing.massdevices.isInErrorState) && (!athoc.iws.scenario.schedule.isInErrorState);
                else
                    isReady = athoc.iws.publishing.content.isReadyToPublish() &&
                    (athoc.iws.publishing.targetUsers.isReadyToPublish || athoc.iws.publishing.targetOrg.isReadyToPublish || athoc.iws.publishing.massdevices.isReadyToPublish) &&
                    (!athoc.iws.publishing.targetUsers.isInErrorState) && (!athoc.iws.publishing.massdevices.isInErrorState) && (!athoc.iws.alert.schedule.isInErrorState)
                    && ((athoc.iws.alert.placeholder.placeholderModel && athoc.iws.alert.placeholder.placeholderModel.length > 0 ) ? athoc.iws.alert.placeholder.isValid() : true);

                return isReady;
            },

            //change status
            checkStatusChange: function (enablePublishReview) {
                if (athoc.iws.publishing.detail.isChanged()) {
                    $('#messagePanel').messagesPanel('reset');
                }
                //iws12104
                if (athoc.iws.publishing.detail.viewModel.AlertStatus != undefined && athoc.iws.publishing.detail.viewModel.AlertStatus == "Scheduled" && athoc.iws.publishing.entityId > 0)
                {
                    $("#btn_review_and_publish").hide();
                    if ($("#btn_detail_save").is(":visible")) {
                        $("#btn_detail_save").removeClass('btn-info');
                        $("#btn_detail_save").addClass('btn-primary');
                    }
                    else
                        if ($("#btn_detail_standby").is(":visible")) {
                            $("#btn_detail_save").removeClass('btn-info');
                            $("#btn_detail_standby").addClass('btn-primary');
                        }
                }
                else
                {
                    //IWS12606
                        if (athoc.iws.publishing.detail.viewModel.AlertStatus && athoc.iws.publishing.detail.viewModel.AlertStatus != "Live" && (enablePublishReview != undefined || enablePublishReview == false) )
                          $("#btn_review_and_publish").show();

                    if ($("#btn_detail_save").is(":visible")) {
                        $("#btn_detail_save").removeClass('btn-primary');
                        $("#btn_detail_save").addClass('btn-info'); // IWS12553
                    }
                    else
                        if ($("#btn_detail_standby").is(":visible"))
                            $("#btn_detail_standby").removeClass('btn-primary');
                }

                if ($("#btn_review_and_publish").is(":visible"))
                {
                    var reviewIcon = $("#btn_review_and_publish").find(".ready-indicator");

                    if (athoc.iws.publishing.detail.isReadyToPublish()) {
                        reviewIcon.removeClass('not-ready');
                        reviewIcon.addClass('ready');
                        $("#btn_review_and_publish_tooltip").hide();
                    } else
                    {
                        reviewIcon.removeClass('ready');
                        reviewIcon.addClass('not-ready');

                        var position = reviewIcon.offset();
                        var tooltip = $("#btn_review_and_publish_tooltip");
                        tooltip.css({ top: '30px', right: '5px', 'z-index': '0' });

                        if (!tooltip.parent().hasClass('header-bar')) {
                            tooltip.appendTo(".header-bar");
                        }

                        if ($("#btn_review_and_publish").is(":enabled"))
                            tooltip.show();
                        else {
                            //reviewIcon.removeClass('ready');
                            //reviewIcon.removeClass('not-ready');
                            tooltip.hide();
                        }
                    }
                }
                if (athoc.iws.publishing.detail.viewModel.Context == 1) {
                    athoc.iws.scenario.schedule.isActiveRecurrence(athoc.iws.publishing.detail.isReadyToPublish(), false,athoc.iws.publishing.detail.isChanged());
                }
            },

            //set changed
            setChanged: function (val) {
                athoc.iws.publishing.content.isChanged = val;
                athoc.iws.publishing.scenario.isChanged = val;
                athoc.iws.publishing.massdevices.isChanged = val;
                athoc.iws.publishing.fillcount.isChanged = val;
            },

            //bind bucket section header for collape/expand
            bindBucketExpandCollapse: function (targetDiv) {
                //bind the toggle event
                //iws-12353
                //added condition for basic vps bind the sections toggle event
                if (targetDiv.selector == "#dialogReviewAndPublish" || !athoc.iws.publishing.settings.IsSchedulingSupported) {
                    //bind bucket toggle 
                    targetDiv.find('.section-title, .expand-arrow-open, .expand-arrow-closed').unbind("click");
                    targetDiv.find('#bucketTitle').unbind("click");

                    targetDiv.find('.section-title, .expand-arrow-open, .expand-arrow-closed').click(function () {
                        $(this).parent().parent().find('.row').slideToggle(500);
                        $(this).parent().parent().find('.expand-arrow-open:not(.advanced-arrow-open)').toggle();
                        $(this).parent().parent().find('.expand-arrow-closed:not(.advanced-arrow-closed)').toggle();
                    });
                }
                ////show bucket expanded by default
                targetDiv.find(".bucket-toggle .row").show();
                targetDiv.find(".bucket-toggle .expand-arrow-open").show();
                targetDiv.find(".bucket-toggle .expand-arrow-closed").hide();

            },

            //bind finger tab
            bindFingerTabs: function () {
                /*START finger tabs*/
                $('.finger-tab.by-groups').click(function () {
                    $('.finger-tab.by-groups, .finger-tab.by-users, .finger-tab.by-query, .finger-tab.by-area, .finger-tab.personal-devices').removeClass('selected');
                    $('.finger-tab.by-groups').addClass('selected');
                    $('#targetContentGroups, #targetContentUsers, #targetContentQuery, #targetContentArea, #targetContentDevices').hide();
                    $('#targetContentGroups').show();
                });
                $('.finger-tab.by-users').click(function () {
                    $('.finger-tab.by-groups, .finger-tab.by-users, .finger-tab.by-query, .finger-tab.by-area, .finger-tab.personal-devices').removeClass('selected');
                    $('.finger-tab.by-users').addClass('selected');
                    $('#targetContentGroups, #targetContentUsers, #targetContentQuery, #targetContentArea, #targetContentDevices').hide();
                    $('#targetContentUsers').show();
                });
                $('.finger-tab.by-query').click(function () {
                    $('.finger-tab.by-groups, .finger-tab.by-users, .finger-tab.by-query, .finger-tab.by-area, .finger-tab.personal-devices').removeClass('selected');
                    $('.finger-tab.by-query').addClass('selected');
                    $('#targetContentGroups, #targetContentUsers, #targetContentQuery, #targetContentArea, #targetContentDevices').hide();
                    $('#targetContentQuery').show();
                });
                $('.finger-tab.by-area').click(function () {
                    $('.finger-tab.by-groups, .finger-tab.by-users, .finger-tab.by-query, .finger-tab.by-area, .finger-tab.personal-devices').removeClass('selected');
                    $('.finger-tab.by-area').addClass('selected');
                    $('#targetContentGroups, #targetContentUsers, #targetContentQuery, #targetContentArea, #targetContentDevices').hide();
                    $('#targetContentArea').show();
                });
                $('.finger-tab.personal-devices').click(function () {
                    $('.finger-tab.by-groups, .finger-tab.by-users, .finger-tab.by-query, .finger-tab.by-area, .finger-tab.personal-devices').removeClass('selected');
                    $('.finger-tab.personal-devices').addClass('selected');
                    $('#targetContentGroups, #targetContentUsers, #targetContentQuery, #targetContentArea, #targetContentDevices').hide();
                    $('#targetContentDevices').show();
                });
                $('.finger-tab.org-by-name').click(function () {
                    $('.finger-tab.org-by-area').removeClass('selected');
                    $('.finger-tab.org-by-name').addClass('selected');
                    $('#targetOrgByArea').hide();
                    $('#targetOrgByName').show();
                });
                $('.finger-tab.org-by-area').click(function () {
                    $('.finger-tab.org-by-name').removeClass('selected');
                    $('.finger-tab.org-by-area').addClass('selected');
                    $('#targetOrgByName').hide();
                    $('#targetOrgByArea').show();
                });
                /*END finger tabs*/
            },

        };
    }();
}