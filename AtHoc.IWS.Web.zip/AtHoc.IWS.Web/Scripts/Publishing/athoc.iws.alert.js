﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
//athoc.iws.alert = athoc.iws.alert || {};

if (athoc.iws) {
    athoc.iws.alert = function () {
        return {
            parameters: {},

            //default action for deeplinking
            action: '',

            //source for deeplinking
            source: '',

            //id for deeplinking
            id: 0,

            rbt: [],

            //init method for alert list, will be triggered before document load
            init: function (args, targetUsersParameters, deviceOptionsParameters, massDeviceParameters) {
                this.parameters = args;
                this.initBreadcrumb();
                athoc.iws.publishing.targetUsers.init(targetUsersParameters);
                athoc.iws.publishing.personalDeviceOptions.init(deviceOptionsParameters);

                if (args.context && args.context == "PA") //skip initiating mass and org for PA
                    return;

                athoc.iws.publishing.massdevices.init(massDeviceParameters);
                var orgParameters = {
                    resources: athoc.iws.scenario.resources,
                    context: "Alert",
                    orgSectionDivs: this.parameters.orgSectionDivs
                }

                athoc.iws.publishing.targetOrg.init(orgParameters);
            },

            breadcrumbModel: new BreadcrumbModel(),

            initBreadcrumb: function () {
                var sn = athoc.iws.alert;

                //Page Breadcrumb Knockout Model
                var breadcrumbsModel = sn.breadcrumbModel;

                //Sub-level breadcrumb
                var alertListBreadCrumb = new Breadcrumb('dlLink', athoc.iws.publishing.resources.Publishing_Alerts_PageTitle, '', function () {
                    athoc.iws.alert.list.viewAlertList();
                });

                var inboxBreadCrumb = new Breadcrumb('dlLink', "Inbox", '', function () {
                    window.location = "/athoc-iws/EventManager";
                });


                //Page breadcrumb
                var alertListPageBreadcrumb = new PageBreadcrumb('alertList', athoc.iws.publishing.resources.Publishing_Alerts_PageTitle, [], '');

                //Alert detail
                var alertDetailPageBreadcrumb = new PageBreadcrumb('alertDetail', '', [alertListBreadCrumb], '');

                //Alert create
                var alertCreatePageBreadcrumb = new PageBreadcrumb('alertCreate', '', [], '');

                //Alert detail
                var alertDuplicatePageBreadcrumb = new PageBreadcrumb('alertDuplicate', athoc.iws.publishing.resources.Publishing_Alert_DuplicateAlert, [alertListBreadCrumb], '');

                //Fowrard alert
                var forwardAlertPageBreadcrumb = new PageBreadcrumb('alertForward', athoc.iws.publishing.resources.Publishing_Alert_ForwardAlert, [inboxBreadCrumb], '');

                breadcrumbsModel.addPage(alertListPageBreadcrumb);
                breadcrumbsModel.addPage(alertDetailPageBreadcrumb);
                breadcrumbsModel.addPage(alertCreatePageBreadcrumb);
                breadcrumbsModel.addPage(alertDuplicatePageBreadcrumb);
                breadcrumbsModel.addPage(forwardAlertPageBreadcrumb);
            },

            //load method, will be tirggered on document load
            load: function () {
                var self = this;

                this.bindBreadcrumb();
                this.parameters.alertActionFunction = this.executeAlertAction(this); //preserve context within closure

                athoc.iws.alert.list.loadParam(this.parameters);

                if (this.action == "create") {
                    athoc.iws.alert.list.createAlertFromScenairo(this.id);
                } else if (this.action == "view") {
                    athoc.iws.alert.list.viewAlertSummary(this.id);
                } else if (this.action == "rbt") {
                    athoc.iws.alert.list.createAlertFromRbt(0, athoc.iws.alert.rbt);
                } else {
                    navigateToPage('alertList', function () { });
                    athoc.iws.alert.list.load();
                }
                $("#btn_edit_cancel").click(function () {
                    if (athoc.iws.publishing.detail.isChanged()) {
                        var confirmLeave = confirm(athoc.iws.publishing.resources.Unsaved_Data_Text);
                        if (!confirmLeave) {
                            return;
                        } else {
                            athoc.iws.publishing.detail.setChanged(false);

                        }
                    }

                    if (athoc.iws.alert.source == 'publisher') {
                        window.location = '/athoc-iws/scenariomanager/scenariopublisher';
                    }
                    else if (athoc.iws.alert.source == 'home') {
                        window.location = '/athoc-iws';
                    }
                    else if (athoc.iws.alert.source == 'event') {
                        window.location = '/athoc-iws/EventManager';
                    }
                    else if (athoc.iws.alert.source == 'log') {
                        window.location = '/athoc-iws/EventManager/activitylog';
                    }

                    else {
                        athoc.iws.alert.list.viewAlertList();
                    }


                });
                $("#btn_detail_standby").click(function () { athoc.iws.alert.detail.standbyAlert(); });
                $("#btn_detail_save").click(function () { athoc.iws.alert.detail.saveAlert(); $(this).removeClass("active"); });
                $("#btn_review_and_publish").click(function () { athoc.iws.alert.detail.reviewAndPublish(); });
                $("#btn_view_cancel").click(function () { athoc.iws.alert.list.viewAlertList(); });
                $("#btn_alert_summary").click(function () {
	
                    if (athoc.iws.alert.id != 0) {
                        window.location = '/client/alertmanager/summary/' + athoc.iws.alert.id;
                        } else if (athoc.iws.publishing != undefined && athoc.iws.publishing.entityId != undefined)
                            window.location = '/client/alertmanager/summary/' + athoc.iws.publishing.entityId;                 
                });
                //~M
                $("#btn_alert_save").click(function () { athoc.iws.alert.detail.saveAlertDetails(athoc.iws.alert.parameters.urls.SaveAlertUrl, true); $(this).removeClass("active"); });
                $("#btn_alert_end").click(function () {
                    var endCallBack = function () {
                        athoc.iws.alert.list.viewAlertList();
                    };

                    if (athoc.iws.alert.id != 0) {

                        var showProgressFunc = function () {
                            kendo.ui.progress($("#mainContainer"), true);
                        };
                        var hideProgressFunc = function () {
                            //$("#mainContainer").css("position", "");
                            kendo.ui.progress($("#mainContainer"), false);
                        };

                        self.executeAlertAction(self)("end", [{ AlertId: athoc.iws.alert.id, Title: athoc.iws.publishing.detail.viewModel.Content.Title }], endCallBack, showProgressFunc, hideProgressFunc);
                    }
                });

                window.onbeforeunload = function (event) {
                    var isModified = athoc.iws.publishing.detail.isChanged();

                    if (isModified) {
                        return athoc.iws.publishing.resources.Unsaved_Data_Text;
                    }
                };

            },

            bindBreadcrumb: function () {
                var breadcrumbsModel = this.breadcrumbModel;
                breadcrumbsModel.SelectedPage('alertList');

                var pageBreadcrumbDiv = document.getElementById('pageBreadcrumbs');
                ko.applyBindings(breadcrumbsModel, pageBreadcrumbDiv);
                $.titleCrumb("pageBreadcrumbs");
            },


            executeAlertAction: function (context) {
                return function (actionType, selectedArray, deleteSuccessCallback, showProgressFunction, hideProgressFunction) {
                    var self = context;
                    var ids = selectedArray.map(function (item) { return item.AlertId; });
                    var names = selectedArray.map(function (item) { return item.Title; });

                    //check for userbase permission
                    if (typeof showProgressFunction == "function") {
                        showProgressFunction();
                    } else {
                        $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.table-crown-wrap'), imageURL: self.parameters.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: self.parameters.resources.General_LoadingMessage }).showLoader();
                    }
                    var myAjaxOptionsForModifyCheck = {
                        url: self.parameters.urls.CheckCanModifyUrl,
                        contentType: 'application/json',
                        dataType: 'json',
                        data: JSON.stringify(ids),
                        type: 'POST',
                    };

                    var executeOnCanModify = self.onSuccessForModifyCheck(actionType, names, deleteSuccessCallback, self, selectedArray, ids, hideProgressFunction);

                    var onErrorForModifyCheck = function () {
                        $.AjaxLoader.hideLoader();
                    };

                    var ajaxOptionsForModifyCheck = $.extend({}, AjaxUtility(onErrorForModifyCheck, executeOnCanModify).ajaxPostOptions, myAjaxOptionsForModifyCheck);
                    $.ajax(ajaxOptionsForModifyCheck);


                }
            },


            onSuccessForModifyCheck: function (actionType, names, deleteSuccessCallback, context, selectedArray, ids, hideProgressFunction) {
                return function (data, textStatus, jqXHR) {
                    var self = context;

                    if (typeof hideProgressFunction == "function") {
                        hideProgressFunction();
                    } else {
                        $.AjaxLoader.hideLoader();
                    }
                    if (data.CanModify) {

                        self.setupAndShowDialog(names,
                            (actionType == "end") ? self.parameters.resources.Alert_EndDialog_Title : self.parameters.resources.Alert_DeleteDialog_Title,
                            (actionType == "end") ? self.parameters.resources.Alert_EndDialog_Body : self.parameters.resources.Alert_DeleteDialog_Body,
                            (actionType == "end") ? self.parameters.resources.Alert_Dialog_EndButton : self.parameters.resources.Action_Button_Delete);
                        (actionType == "end") ? $('#dialogActionButton').attr('title', self.parameters.resources.Alert_Dialog_EndButton) : $('#dialogActionButton').attr('title', self.parameters.resources.Action_Button_Delete);



                        $(self.parameters.dialogButtonLabelSelector).off('click').on('click', function (e) {
                            $(self.parameters.dialogSelector).modal('hide');
                            $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.table-crown-wrap'), imageURL: self.parameters.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000,displayText :self.parameters.resources.General_LoadingMessage }).showLoader();

                            var myAjaxOptions = {
                                url: (actionType == "end") ? self.parameters.urls.EndAlertsUrl : self.parameters.urls.DeleteAlertsUrl,
                                contentType: 'application/json',
                                dataType: 'json',
                                data: JSON.stringify(ids),
                                type: 'POST',
                            };

                            var onError = function () {
                                $.AjaxLoader.hideLoader();
                            };

                            var onSuccess = function (data, textStatus, jqXHR) {
                                $.AjaxLoader.hideLoader();
                                if (typeof deleteSuccessCallback == "function") {
                                    deleteSuccessCallback(data, textStatus, jqXHR);
                                }
                            }

                            var ajaxOptions = $.extend({}, AjaxUtility(onError, onSuccess).ajaxPostOptions, myAjaxOptions);
                            $.ajax(ajaxOptions);

                        });

                    } else {
                        //show dialog
                        var unmodifiableNames = new Array();
                        _.each(selectedArray, function (item) {
                            var found = _.find(data.UnmodifiableAlerts, function (item2) {
                                return (item.AlertId == item2);
                            });
                            if (found) {
                                unmodifiableNames.push(item.Title);
                            }
                        });

                        self.setupAndShowDialog(unmodifiableNames,
                        (actionType == "end") ? self.parameters.resources.Alert_CouldntEndDialog_Title : self.parameters.resources.Alert_CouldntDeleteDialog_Title,
                        (actionType == "end") ? self.parameters.resources.Alert_CouldntEndDialog_Body : self.parameters.resources.Alert_CouldntDeleteDialog_Body,
                        "",
                        self.parameters.resources.Alert_Dialog_OkButton,
                        true);
                    }
                }
            },


            setupAndShowDialog: function (names, title, body, buttonLabel, cancelButtonText, hideActionButton) {
                var self = this;
                var nameTags = "";
                names.sort();
                for (var i = 0; i < names.length; i++) {
                    nameTags += "<div class='pseudo-li ellipsis mar-left10' title='" + $.htmlEncode(names[i]).replace(/'/g, "&#39;") + "'>" + $.htmlEncode(names[i]) + "</div>";
                }

                $(self.parameters.dialogItemListSelector).html("<div class='mar-top10'>" + nameTags + "</div>");
                $(self.parameters.dialogTitleSelector).html(title);
                $(self.parameters.dialogBodySelector).html(body);
                $(self.parameters.dialogButtonLabelSelector).html(buttonLabel);

                if (typeof cancelButtonText != "undefined") {
                    $(self.parameters.dialogCancelButton).html(cancelButtonText);
                } else {
                    $(self.parameters.dialogCancelButton).html(self.parameters.resources.Action_Button_Cancel);
                }

                $(self.parameters.dialogButtonLabelSelector).show();
                if (typeof hideActionButton != "undefined") {
                    if (hideActionButton) {
                        $(self.parameters.dialogButtonLabelSelector).hide();
                    }
                }

                $(self.parameters.dialogSelector).modal('show');

            }

        }
    }();
}