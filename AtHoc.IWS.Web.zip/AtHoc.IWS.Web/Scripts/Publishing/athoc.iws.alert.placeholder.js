﻿/* define javascript namespace for Test Alert  */
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.alert = athoc.iws.alert || {};
if (athoc.iws.alert) {
    athoc.iws.alert.placeholder = function () {
        //
        var extraSpaceAddBlock = 55;
        return {
            //is model changed
            isChanged: false,
            IsRefered: false, 
            tesDeviceList: [],
            placeholderModel: [],
            systemPlaceHolderModel:[],
            viewModel: {
                placeholderModel: ko.observableArray(), 
            },
            //called when new data will be available for this section for binding
            load: function () {
             

            },
            bind: function (data) {
                var _self = this;
                _self.placeholderModel = [];
                _self.systemPlaceHolderModel = [];
                $(data).each(function(index) {
                    if (data[index].DisplayType == 'Custom')
                        _self.placeholderModel.push(data[index]);
                });

                $(data).each(function (index) {
                    if (data[index].DisplayType == 'System')
                        _self.systemPlaceHolderModel.push(data[index]);
                });


                if (_self.placeholderModel.length > 0)
                    $("#CustomPlaceHolderDetails").show();
                else
                {
                    $("#CustomPlaceHolderDetails").hide();
                    return;
                }
                
               
                var bucketContent = "";
                $("#divPlaceHolders").html("");
                var data = _self.placeholderModel;
                $(data).each(function (index) {
                    var name = 'ph_' + data[index].Id;
                    var values = data[index].Values;
                    var type =data[index].ControlType;
                    var cell = "";

                    var row = '<div class=\"row single-edit control-group\"><div class=\"edit-icon\"></div><span class=\"read-label\"><label  class=\"control-label\">' + data[index].CommonName + '</label></span><div class=\"controls\">';

                    // to bind text control''
                    if (type == "Text") {
                        var textValue = (values.length > 0) ? values[0].Value : "";
                        cell = cell + "<textarea id='" + name + "' name='" + name + "' class='text-area ' cols='60' rows='" + data[index].DisplayLines + "' minLen='" + data[index].MinimumLength + "' maxLen='" + data[index].MaximumLength + "' >";
                        cell = cell + textValue;
                        cell = cell + "</textarea>";
                        cell = cell + "<p class='warning-msg' style='display:none' id='error_" + name + "' >" + athoc.iws.publishing.resources.Publishing_PlaceHolder_Error_Between + " " + data[index].MinimumLength + " " + athoc.iws.publishing.resources.Publishing_PlaceHolder_Error_And + " " + data[index].MaximumLength + " " + athoc.iws.publishing.resources.Publishing_PlaceHolder_Error_Characters + " </p>";
                    }
                        // to bind Single Picker
                    else if (type == "SingleSelection") {
                        cell = cell + "<select id='" + name + "' name='" + name + "' class='selectpicker' data-width='533'>";
                        $(values).each(function (index2) {
                            var isSelected = values[index2].IsDefault ? "selected" : "";
                            cell = cell + "<option value='" + values[index2].Value + "'" + isSelected + ">" + values[index2].Value + "</option>";
                        });
                        cell = cell + "</select>";
                        cell = cell + "<p class='warning-msg' style='display:none' id='error_" + name + "'>" + athoc.iws.publishing.resources.Publishing_PlaceHolder_Error_Invalid + "</p>";
                    }
                        // to bind Multiple Picker
                    else if (type == "MultiSelection") {
                        cell = cell + "<select id='" + name + "' name='" + name + "' class='selectpicker' multiple data-width='533'>";
                        $(values).each(function (index2) {
                            var isSelected = values[index2].IsDefault ? "selected" : "";
                            cell = cell + "<option value='" + values[index2].Value +" " + "'" + isSelected + ">" + values[index2].Value + "</option>";
                        });
                        cell = cell + "</select>";
                        cell = cell + "<p class='warning-msg' style='display:none' id='error_" + name + "'>" + athoc.iws.publishing.resources.Publishing_PlaceHolder_Error_AtLeastOneSelection + "</p>";
                    }
                        // to bind Date 
                    else if (type == "DateTime") {
                        //data-bind="attr: { title: 'choose date', 'placeholder': '@ViewBag.DateFormat.ToUpper()'}"
                        var val = (values != null && values.length > 0) ? values[0].Value : "none";                        
                        cell = '<div id="' + name + '" class="input-append date"> <div> <input id=' + name + ' tabindex="220" type="text" class="width110" value="' + val + '"   >';
                        cell = cell + '<span class="add-on"><i data-date-icon="icon-calendar" data-time-icon="icon-time" class="icon-calendar"></i></span></div></div>';
                        cell = cell + "<p class='warning-msg' style='display:none' id='error_" + name + "'>" + athoc.iws.publishing.resources.Publishing_PlaceHolder_Error_InvalidDate + "</p>";

                    }
                        // to bind Time 
                    else if (type == "Time") {
                        var val = (values != null && values.length > 0) ? values[0].Value : "none";                        
                        cell = '<div id="' + name + '" class="input-append"> <div> <input id=' + name + '  tabindex="220" type="text"  class="width110"  >';
                        cell = cell + '<span class="add-on"><i data-time-icon="icon-time"  data-date-icon="icon-calendar"></i></span></div></div>';
                        cell = cell + "<p class='warning-msg' style='display:none' id='error_" + name + "'>" + athoc.iws.publishing.resources.Publishing_PlaceHolder_Error_InvalidTime + "</p>";
                       
                    }
                        // to bind Date & Time
                    else if (type == "Date") {
                        var val = (values != null && values.length > 0) ? values[0].Value : "none";
                        cell = '<div id="' + name + '" class="input-append datetime"> <div> <input id=' + name + ' tabindex="220" type="text" class="width110"  value="' + val + '" >';
                        cell = cell + '<span class="add-on"><i data-date-icon="icon-calendar" data-time-icon=icon-datetimepicker1 class="icon-calendar"></i></span></div></div>';
                        cell = cell + "<p class='warning-msg' style='display:none' id='error_" + name + "'>" + athoc.iws.publishing.resources.Publishing_PlaceHolder_Error_InvalidDate + "</p>";
                    }
                    bucketContent = bucketContent + row + cell + "</div></div>";
                });
                $("#divPlaceHolders").html(bucketContent);
                $("#CustomPlaceHolderDetails").find(".bootstrap-select").remove();
                athoc.iws.alert.placeholder.initiatePickers();
          
            },

           Convert24HrsFormat:function(val, cVal)
        {
             var timeFormat = $.vpsDateTimeFormat.replace($.vpsDateFormat, "").toLowerCase().replace("tt", "");
            var cnt = timeFormat.split(':').length-1;
            if (cVal.indexOf('PM') > 0) {
                nval = parseInt(val.split(':')[0]) + 12;
                cnt--;

                while (cnt > 0) {
                    nval = nval + ":" + val.split(':')[cnt];
                    cnt--;
                }
            }
            if (cVal.indexOf('AM'))
                nval = val;
            return nval;
        },
        initiatePickers: function () {
                var data = this.placeholderModel;                                
                var AMPMformat = $.vpsDateTimeFormat.indexOf('tt') > 0 ? true : false;
                var timeformat = athoc.iws.alert.placeholder.getVPSTimeFormat(true);
                var datetimeformat = athoc.iws.alert.placeholder.getVPSTimeFormat(false);
                $(data).each(function (index) {

                    //var name = data[index].CommonName.replace(/[\s]/g, "_");
                    var minLen = data[index].MinimumLength;
                    var maxLen = data[index].MaximumLength;
                     var name = 'ph_' + data[index].Id;
                     switch (data[index].ControlType) {
                         case "Text":
                             $("#" + name).focusout(function () {
                                 athoc.iws.alert.placeholder.validControl(name, data[index].ControlType, minLen, maxLen, this.value);
                             });
                             break;

                        case "Time":
                            $("#" + name).datetimepicker({
                                pickDate: false,
                                pickTime: true,
                                language: $.culture,
                                pick12HourFormat: AMPMformat,
                                format: timeformat,
                                pickSeconds: $.vpsDateTimeFormat.indexOf('ss') > 0 ? true : false,
                            });       
                            var cntrl = $("#" + name).datetimepicker().on('changeDate', function (ev) {
                                if (ev.localDate != null) {
                                    var newDate = moment(ev.localDate).format(timeformat);
                                    athoc.iws.alert.placeholder.validControl(  name , data[index].ControlType, minLen, maxLen, athoc.iws.alert.placeholder.getControlSelectedValue(data[index].ControlType,   name));
                                }
                            }); 
                            cntrl.focusout(function () {
                                athoc.iws.alert.placeholder.validControl(name, data[index].ControlType, minLen, maxLen, athoc.iws.alert.placeholder.getControlSelectedValue(data[index].ControlType, name));
                            });

                            var picker = $("#" + name).data('datetimepicker');
                            if (picker && picker != null && data[index].Values[0] != undefined)
                                picker.setDate(data[index].Values[0].Value);
                            break;
                        case "DateTime":
                            $("#" + name).datetimepicker({
                                language: $.culture,
                                pick12HourFormat: AMPMformat,
                                format: datetimeformat,
                                pickSeconds: $.vpsDateTimeFormat.indexOf('ss') > 0 ? true : false,
                            });
                            var cntrl = $("#" + name).datetimepicker().on('changeDate', function (ev) {
                                if (ev.localDate != null) {
                                    var newDate = moment(ev.localDate).format(datetimeformat);
                                    athoc.iws.alert.placeholder.validControl(  name , data[index].ControlType, minLen, maxLen, athoc.iws.alert.placeholder.getControlSelectedValue(data[index].ControlType,  name  ));
                                }
                            });
                            cntrl.focusout(function () {
                                athoc.iws.alert.placeholder.validControl(name, data[index].ControlType, minLen, maxLen, athoc.iws.alert.placeholder.getControlSelectedValue(data[index].ControlType, name));
                            });


                            var picker = $("#" + name).data('datetimepicker');
                            if (picker && picker != null && data[index].Values[0] != undefined)
                                picker.setDate(data[index].Values[0].Value);
                            break;
                        case "Date":
                            $("#" + name);
                            $("#" + name).datetimepicker({
                                pickDate: true,
                                pickTime: false,
                                format: $.vpsDateFormat,
                                language: $.culture,
                            });                           
                           var cntrl = $("#" + name).datetimepicker().on('changeDate', function (ev) {
                                if (ev.localDate != null) {
                                    var newDate = moment(ev.localDate).format($.vpsDateFormat);
                                    athoc.iws.alert.placeholder.validControl(  name  , data[index].ControlType, minLen, maxLen, athoc.iws.alert.placeholder.getControlSelectedValue(data[index].ControlType,   name ));
                                }
                            }); 
                           cntrl.focusout(function () {
                               athoc.iws.alert.placeholder.validControl(name, data[index].ControlType, minLen, maxLen, athoc.iws.alert.placeholder.getControlSelectedValue(data[index].ControlType, name));
                            });

                            var picker = $("#" + name).data('datetimepicker');
                            if (picker && picker != null && data[index].Values[0] != undefined)
                                picker.setDate(data[index].Values[0].Value);
                            break;

                        case "SingleSelection":
                            $("#" + name).selectpicker();
                            $("#" + name).on('change', function () {
                                athoc.iws.alert.placeholder.validControl(name, data[index].ControlType, minLen, maxLen, athoc.iws.alert.placeholder.getControlSelectedValue(data[index].ControlType, name));
                            });
                            break;

                        case "MultiSelection":
                            $("#" + name).selectpicker();
                            $("#" + name).on('change', function () {
                                athoc.iws.alert.placeholder.validControl(name, data[index].ControlType, minLen, maxLen, athoc.iws.alert.placeholder.getControlSelectedValue(data[index].ControlType, name));
                            });
                            break;
                    }
                });
            },
            // get model returns attribute selected values 
            getModel: function () {
                var data = athoc.iws.alert.placeholder.placeholderModel;
                    $(data).each(function(index) {
                        var name = "ph_" + data[index].Id;
                        var type = data[index].ControlType;
                        data[index].SelectedValue = athoc.iws.alert.placeholder.getControlSelectedValue(type, name);
                    });
                    athoc.iws.alert.placeholder.validatePlaceholder();
                return data;
            },
            // get control selected value
            getControlSelectedValue: function (type, name) {
                var selectedItems="";

                switch (type) {

                    case "SingleSelection":
                        $("#" + name + " :selected").each(function (i, selected) {
                            selectedItems =  $(selected).text();
                        });
                        break;
                    case "MultiSelection":

                        $("#" + name + " :selected").each(function (i, selected) {
                            if (selectedItems!="")
                                selectedItems = selectedItems + "," + $.trim($(selected).text());
                            else
                                selectedItems =  $.trim($(selected).text());
                        });
                       
                        break;
					case "Date":
                    case "DateTime":
                    case "Time":
                        selectedItems = $("#" + name).find("input").val();
                        break;
                    default:
                        {
                            selectedItems = $("#" + name).val();
                        }
                        break;
                }


                return selectedItems;
            },
            validControl: function (name, type, minLen, maxLen, selectedValue) {

                
                switch (type) {
                    case "SingleSelection":
                        if (selectedValue.length == 0) {
                            $("#error_" + name).show();
                            self.isValid = false;
                        }
                        else
                            $("#error_" + name).hide();
                        break;
                    case "MultiSelection":
                        if (selectedValue.length == 0) {
                            $("#error_" + name).show();
                            self.isValid = false;
                        }
                        else
                            $("#error_" + name).hide();
                        break;
                    case "Date":
                    case "DateTime":
                        if (minLen > 0 && selectedValue == "") {
                            $("#error_" + name).show();
                            self.isValid = false;
                        }
                        else if (!athoc.iws.alert.placeholder.isValidDate(selectedValue)) {
                            $("#error_" + name).show();
                            self.isValid = false;
                        }
                        else
                            $("#error_" + name).hide();
                        break;
                    case "Time":
                        if (minLen > 0 && selectedValue == "") {
                            $("#error_" + name).show();
                            self.isValid = false;
                        }
                        else if (!athoc.iws.alert.placeholder.isValidTime(selectedValue)) {
                            $("#error_" + name).show();
                            self.isValid = false;
                        }
                        else
                            $("#error_" + name).hide();
                        break;
                    default:
                        if (selectedValue != undefined && ((minLen > 0 && selectedValue.length < minLen) || (maxLen > 0 && selectedValue.length > maxLen))) {
                            $("#error_" + name).show();
                            self.isValid = false;
                        }
                        else
                            $("#error_" + name).hide();
                        break;
                }
              
                //reset isReadyToPublish status
                athoc.iws.publishing.detail.checkStatusChange();
            },
            isValid: function () {
                //verify any error message is displayed
                var bValid = !($("#CustomPlaceHolderDetails").find(".warning-msg").is(':visible'));
                if (bValid) {
                    $("#CustomPlaceHolderDetails").find(".ready-indicator").toggleClass('ready', true);
                    $("#CustomPlaceHolderDetails").find(".ready-indicator").toggleClass('not-ready', false);
                }
                else {
                    $("#CustomPlaceHolderDetails").find(".ready-indicator").toggleClass('ready', false);
                    $("#CustomPlaceHolderDetails").find(".ready-indicator").toggleClass('not-ready', true);
                }
                return bValid;
            },
            //validate the control values
            validatePlaceholder: function () { 
                var data = athoc.iws.alert.placeholder.placeholderModel;
			    if (data == undefined )
			        return true;
                
                $(data).each(function (index) {
                    var name = 'ph_' + data[index].Id;
                    var values = data[index].Values;
                    var type = data[index].ControlType;
                    var minLen =data[index].MinimumLength ;
                    var maxLen = data[index].MaximumLength;
                    var selectedValue = athoc.iws.alert.placeholder.getControlSelectedValue(type, name);
                    athoc.iws.alert.placeholder.validControl(name, type, minLen, maxLen, selectedValue);
                });
                 
            },
            isValidDate: function (val) {
                isValidDt = true;
                try {
                    isValidDt = moment(val, $.vpsDateFormat.toUpperCase()).isValid();
                }
                catch (error) {
                    isValidDt = false;
                }

                return isValidDt;
            },
            isValidTime: function (val) {
                isValidDt = true;
                try {
                    isValidDt = moment(val, $.trim($.vpsDateTimeFormat.replace($.vpsDateFormat, "").toLowerCase().replace("tt", "PP"))).isValid();
                }
                catch (error) {
                    isValidDt = false;
                }

                return isValidDt;
            },

            getVPSTimeFormat: function (onlyTimeFormat) {
                var timeFormat = $.trim($.vpsDateTimeFormat.replace($.vpsDateFormat, "").toLowerCase().replace("tt", "PP"));
                if ( $.vpsDateTimeFormat.indexOf('tt') > 0)
                    timeFormat = $.trim($.vpsDateTimeFormat.replace($.vpsDateFormat, "").toLowerCase().replace("tt", "PP").replace("hh", "HH"));

                if (onlyTimeFormat)
                    return timeFormat;
                else
                    return $.vpsDateFormat + ' ' + timeFormat;
            },
           
        };

    }();
}
