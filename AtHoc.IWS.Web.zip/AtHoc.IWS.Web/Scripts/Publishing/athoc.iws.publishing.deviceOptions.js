﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};

if (athoc.iws.publishing) {
    athoc.iws.publishing.deviceOptions = function () {
        return {
            Parameters: {},
            CONST_TAB_TEMPLATE: "<div class=\"finger-tab device-option-tab\" id=\"deviceGroupOptionTab{0}\" groupId=\"{0}\" index=\"{2}\">" +
                            "<span class=\"block ellipsis\" title=\"{1}\">{1}</span><span class=\"finger-tab-extended\"></span>" +
                            "<span style=\"display:none\" id=\"deviceoption_{0}_trigger\"></span></div>",
            CONST_TAB_BODY_CONTAINER: "<div class=\"span8a finger-tab-content device-option-content \" id=\"deviceGroupOptionTab{0}Body\" style=\"display:none;\"></div>",
            CONST_TAB_BODY_TEMPLATE: "<div class=\"inner-bucket white-bg\"><div class=\"no-header inner-bucket-header mar-bot0\"><h4>&nbsp;</h4></div>{0}</div>",
            CONST_INFO_TAG_SELECTOR: "#deviceoption_{0}_trigger",
            CONST_BODY_UNAVAILABLE_TEMPLATE: "<div class=\"inner-bucket-grid-wrap\"><div class=\"mar-top10 mar-left15\">{0}</div></div>",
            CurrentlySelectedGroup: -1,
            OnSaveCallBack: null,
            AllDeviceGroups: new Array(),
            AudioComponents: new Array(),
            audioControlIsLoaded: false,
            audioControlIsRequired: false,

            bind: function (data) {
                var self = this;




            },

            deviceGroupOption: function (selected, label, html) {
                this.Selected = ko.observable(selected);
                this.Name = ko.observable(label);
                this.HTML = ko.observable(html);
            },

            loadViewModel: function () {

            },

            init: function (parameters) {
                var self = this;

                //init is called once when the page loads for the first time.
                //all controls are created here.
                this.Parameters = parameters;
                //this.loadViewModel();

                $(self.Parameters.dialogDeviceOptions + " " + this.Parameters.btnDialogDeviceOptionsSave).on("click", function () {
                    if ($("#RecordWarning") != null && $("#RecordWarning") != undefined)
                        $("#RecordWarning").html("");
                    if (self.CurrentlySelectedGroup != -1) {
                        self.Parameters.submitEventWrapperObj.ExecuteAll();

                        if ($(self.CONST_INFO_TAG_SELECTOR.format(self.CurrentlySelectedGroup)).data("ValidationError").length != 0) //validation error, stay on the page
                        {
                            return;
                        }
                    }

                    //verify validity of audio components
                    if (!self.validateAudio()) return;

                    if (typeof self.OnSaveCallBack == "function") {
                        self.OnSaveCallBack(self.serialize());
                    }
                    $(self.Parameters.dialogDeviceOptions).modal('hide');

                });

                $(self.Parameters.dialogDeviceOptions + " " + this.Parameters.btnDialogDeviceOptionsCancel).on("click", function () {


                    _.each(self.AllDeviceGroups, function (item) {
                        if (item.DeviceOptionLoaded && item.Selected && item.Selected && item.HasExtension) {
                            _.each(item.CurrentSavedSelection, function (element) {
                                var obj = $('[name="' + element.Name + '"]');
                                if (obj.length != 0) {
                                    if (obj.prop("type") == "radio") {
                                        $('[name="' + element.Name + '"][value="' + element.Value + '"]').click();
                                    } else if (obj.prop("tagName").toLowerCase() == "textarea") {
                                        $('[name="' + element.Name + '"]').val(element.Value);
                                    } else if (obj.prop("tagName").toLowerCase() == "select") {
                                        if (obj.attr("multiple") == "multiple") {
                                            if (element.Value != "") {
                                                $('[name="' + element.Name + '"]').val(element.Value.split(","));
                                            }

                                        } else {
                                            $('[name="' + element.Name + '"]').val(element.Value);
                                            if (element.Value == "") { //if nothing was originally selected in the dropdown, select the first item
                                                $('[name="' + element.Name + '"]').find("option").each(function () {
                                                    if ($(this).css("display") != "none") {
                                                        $('[name="' + element.Name + '"]').val($(this).val());
                                                        return false;
                                                    }
                                                });
                                            }
                                        }

                                        $('[name="' + element.Name + '"]').selectpicker('render');
                                    } else if (obj.prop("type") == "checkbox") {
                                        obj.prop('checked', element.Value == "on");
                                    } else if (obj.prop("type") == "hidden") {
                                        //we need to reset all of the audio properties in one shot. 
                                        if (obj.hasClass("AudioId")) {
                                            var component = self.findAudioComponent(self.getAudioComponentId(element.Name));
                                            if (component) {
                                                var audioId = element.Value;

                                                //now must retrieve filename and stream
                                                var fileName = _.find(this, function (item) { return item.Name == element.Name.replace(/(?=.)[a-zA-Z]*$/, "Name") }).Value;
                                                var fileStream = _.find(this, function (item) { return item.Name == element.Name.replace(/(?=.)[a-zA-Z]*$/, "Stream") }).Value;
                                                //stop the audio if its playing                                                 
                                                component.Component.stopAudio();
                                                component.Component.setAudioProperties(audioId, fileName, fileStream);
                                            }
                                        }
                                    }
                                } else { //special handling for audio component

                                }
                            }, item.CurrentSavedSelection);
                        }

                    });

                    self.Parameters.submitEventWrapperObj.ExecuteAll();

                    //need to manually refresh selectpicker component after applying UI changes due to cancel. 
                    _.each(self.AllDeviceGroups, function (item) {
                        if (item.DeviceOptionLoaded && item.Selected && item.Selected && item.HasExtension) {
                            _.each(item.CurrentSavedSelection, function (element) {
                                var obj = $('[name="' + element.Name + '"]');
                                if (obj.length != 0) {
                                    if (obj.prop("tagName").toLowerCase() == "select") {
                                        $('[name="' + element.Name + '"]').selectpicker('render');
                                    }
                                }
                            }, item.CurrentSavedSelection);
                        }

                    });

                    $(self.Parameters.dialogDeviceOptions).modal('hide');

                });

            },

            serialize: function () {
                var self = this;
                var optionsArray = new Array();
                _.each(this.AllDeviceGroups, function (item) {
                    if (item.DeviceOptionLoaded && item.Selected && item.Selected && item.HasExtension) {
                        var options = self.serializeForDeviceGroup(item);
                        item.CurrentSavedSelection = options;

                        optionsArray.push({
                            GroupId: item.Id,
                            Options: options
                        });
                    }

                });

                return optionsArray;

            },

            serializeForDeviceGroup: function (item) {
                var self = this;

                var options = new Array();
                _.each(item.ElementList, function (element) {
                    var value = "";
                    var obj = $('[name="' + element + '"]');

                    if (obj.length != 0) {
                        if (obj.prop("type") == "checkbox") {
                            if (!obj.prop("disabled")) {
                                value = obj.is(":checked") ? obj.val() : "";
                            } else {
                                value = "";
                            }
                        } else if (obj.length > 1) { //select
                            var allDisabled = true;
                            for (var i = 0; i < obj.length; i++) {
                                if (!obj[i].disabled) {
                                    allDisabled = false;
                                }
                            }
                            if (!allDisabled) {
                                value = $('[name="' + element + '"]:checked').val();
                            } else {
                                value = "";
                            }
                        } else if (obj.prop("type") == "hidden") { //audio Id, audio name

                            var component = self.findAudioComponent(self.getAudioComponentId(element));

                            if (typeof component != "undefined") {
                                if (component.Required) {
                                    if (obj.hasClass("AudioId")) {
                                        //get  audio Id property from component
                                        value = component.Component.getAudioProperties().audioId;
                                    } else if (obj.hasClass("AudioName")) {
                                        //get audio name prop from component
                                        value = component.Component.getAudioProperties().fileName;
                                    }
                                }
                            } else { //is not audio control, it's simple hidden input
                                value = $('[name="' + element + '"]').val();
                            }
                        } else if (obj.attr("multiple") == "multiple") { //multi select pick list
                            if (typeof $('[name="' + element + '"]').val() == "undefined" || $('[name="' + element + '"]').val() == null) {
                                value = "";
                            } else {
                                value = $('[name="' + element + '"]').val().join(",");
                            }
                        } else { //radio button, textbox, textarea
                            if (!obj.prop("disabled")) {
                                value = $('[name="' + element + '"]').val();
                            } else {
                                value = "";
                            }
                        }
                    } else {
                        //recording component needs to be handled in a special way. 
                        var obj = $('[id="' + element + '"]');
                        if (obj.length != 0) {
                            if (obj.hasClass("recording")) { //is a recording
                                var component = self.findAudioComponent(self.getAudioComponentId(element));

                                //now extract info from it. 
                                if (component.Required) { //retrieve audio only if required
                                    value = component.Component.getAudioProperties().fileStream;
                                }

                            }
                        }
                    }

                    options.push({
                        Name: element,
                        Value: value
                    });
                });
                return options;
            },

            load: function (devices, presetDeviceOptions, onSaveCallback, onLoadDoneCallback) {

                this.CurrentlySelectedGroup = -1;

                this.OnSaveCallBack = onSaveCallback;

                //delete all of the audio components prev created. 
                _.each(this.AudioComponents, function (audio) {
                    audio.Component.destroy();
                });
                //reset audio components array

                this.AudioComponents = new Array();

                //reset all of the flag required for synced loading
                this.audioControlIsLoaded = false;
                this.audioControlIsRequired = false;
                this.intervalSerialize = null;
                var self = this;
                $(self.Parameters.dialogDeviceOptions + " " + self.Parameters.deviceOptionTabs).html("");
                $(self.Parameters.dialogDeviceOptions + " " + self.Parameters.deviceOptionTabBody).html("");

                //var encodedPresets = {};
                //for (var key in presetDeviceOptions) {
                //    encodedPresets[key] = $.htmlEncode(presetDeviceOptions[key]);
                //}

                var dlAjaxOption =
                {
                    type: "POST",
                    url: self.Parameters.deviceOptionURL,
                    data: {
                        devices: devices,
                        presetOptions: presetDeviceOptions,
                        type: this.Parameters.deviceType
                    },
                };

                kendo.ui.progress($(self.Parameters.dialogDeviceOptions), true);

                var dlSuccess = function (data) {
                    //$("#deviceOptionPanel").html(data);
                    //this.viewModelInstance.deviceGroups().push(new deviceGroup(true, "hello", "bleh"))
                    //ko.mapping.fromJS(data.DeviceOptions, {}, self.viewModelInstance.deviceGroups);
                    var firstTab = null;

                    self.AllDeviceGroups = data.DeviceOptions;

                    _.each(self.AllDeviceGroups, function (item, index) {

                        var tab = $(self.CONST_TAB_TEMPLATE.format(item.Id, item.Name));

                        /*had to resort to native DOM instead of knockout for a device option specific reason*/
                        $(self.Parameters.dialogDeviceOptions + " " + self.Parameters.deviceOptionTabs).append(tab);

                        //$(self.CONST_INFO_TAG_SELECTOR.format(item.Id)).data("ElementList", item.ElementList);
                        $(self.CONST_INFO_TAG_SELECTOR.format(item.Id)).data("ValidationError", new Array());

                        var tabBody = $(self.CONST_TAB_BODY_CONTAINER.format(item.Id));
                        $(self.Parameters.dialogDeviceOptions + " " + self.Parameters.deviceOptionTabBody).append(tabBody);
                        if (item.Selected) {
                            if (!item.HasExtension) {
                                tabBody.append(self.CONST_TAB_BODY_TEMPLATE.format(self.CONST_BODY_UNAVAILABLE_TEMPLATE.format(self.Parameters.resources.Publishing_Devices_Device_Options_Unavailable)));
                            } else {
                                var content = (item.HTML == null) ? "" : item.HTML;
                                tabBody.append(self.CONST_TAB_BODY_TEMPLATE.format(content)).promise().done(function () {
                                    if (item.HTML != null) {
                                        //eval(tabBody.find("script").text());
                                        try {
                                            eval("device_option_load_" + item.Id + "()");//<xsl:value-of select="$DeviceGroupID" />() {

                                            $("#deviceGroupOptionTab" + item.Id + "Body select").each(function (i) {

                                                if ($(this).find("option").length != 0) {
                                                    $(this).selectpicker({
                                                        noneSelectedText: self.Parameters.resources.Publishing_Devices_Select_None,
                                                        selectedTextFormat: "count>2",
                                                        includeSelectAllOption: true
                                                    });
                                                } else {
                                                    self.disableRadioButton($(this));
                                                }

                                            });

                                            //eval(tabBody.find("script").text());
                                            $("#deviceGroupOptionTab" + item.Id + "Body .device-option-placeholder").each(function (i) {
                                                var currentItem = $(this);
                                                self.showPlaceholder(currentItem);
                                            });

                                            $("#deviceGroupOptionTab" + item.Id + "Body .recording").each(function (i) {

                                                self.audioControlIsRequired = true;
                                                audioUploader.isAudioFileChanged = false;

                                                self.showAudioRecorder("#deviceGroupOptionTab" + item.Id + "Body .recording");

                                            });

                                        } catch (e) {

                                        }

                                        if (!self.audioControlIsRequired || self.audioControlIsLoaded)  //must wait til audio component is loaded. 
                                        {
                                            item.CurrentSavedSelection = self.serializeForDeviceGroup(item);


                                            if ($("#deviceGroupOptionTab" + item.Id + "Body .default-template-severity-label").length != 0) {

                                                var severity = self.getSeverityInfo();

                                                self.setSeverityText(severity.id,
                                                                        "#deviceGroupOptionTab" + item.Id + "Body ",
                                                                        self,
                                                                        severity.name);
                                                self.setSeverityBasedInfo("#deviceGroupOptionTab" + item.Id + "Body ",
                                                                            severity.id);
                                            }

                                            self.localeChange(item, self);


                                        } else {

                                            //must delay serialize until audiocomponent is loaded
                                            var intervalSerialize = null;
                                            function checkAudioComponent() {
                                                //console.log(self.audioControlIsLoaded);
                                                if (self.audioControlIsLoaded) {
                                                    clearInterval(intervalSerialize);
                                                    item.CurrentSavedSelection = self.serializeForDeviceGroup(item);

                                                }
                                            }
                                            intervalSerialize = window.setInterval(checkAudioComponent, 200);

                                        }
                                    }


                                });

                            }
                        }

                        if (!item.Selected) { //if device/devicegroup is not selected hide tab. 
                            $("#deviceGroupOptionTab" + item.Id).hide();
                            $("#" + item.Id + "Body").hide();
                        }
                        tab.on("click", function () {
                            self.clickTab(self, $(this), true);

                            /*
                                        if ($("#RecordWarning") != null && $("#RecordWarning") != undefined)
                                            $("#RecordWarning").html("");
            
                                        if (self.CurrentlySelectedGroup != -1) {
                                            self.Parameters.submitEventWrapperObj.ExecuteAll();
                                            
                                            if ($(self.CONST_INFO_TAG_SELECTOR.format(self.CurrentlySelectedGroup)).data("ValidationError").length != 0) //validation error, stay on the page
                                            {
                                                return;
                                            }
                                        }                
                                        //verify validity of audio components
                                        if (!self.validateAudio()) return;
            
                                        self.CurrentlySelectedGroup = $(this).attr("groupId");
                                        $(self.Parameters.dialogDeviceOptions + " " + ".device-option-content").hide();
                                        $("#" + $(this).attr("id") + "Body").show();
                                        $(self.Parameters.dialogDeviceOptions + " " + '.device-option-tab').removeClass('selected');
            
                                        $(this).addClass('selected');
                                        */
                        });



                        if (firstTab == null) {
                            if (item.Selected)
                                firstTab = tab;
                        }


                        //self.viewModelInstance.deviceGroups.push(new self.deviceGroupOption(item.Selected,item.Name,item.HTML));
                    });
                    if (firstTab != null) {
                        self.clickTab(self, firstTab, false);
                        //firstTab.click();
                    }
                    if (typeof onLoadDoneCallback == "function") {

                        if (!self.audioControlIsRequired || self.audioControlIsLoaded)  //must wait til audio component is loaded. 
                        {
                            onLoadDoneCallback(self.serialize());

                        } else {

                            //must delay serialize until audiocomponent is loaded
                            var intervalSerialize = null;
                            function checkAudioComponent() {
                                //console.log(self.audioControlIsLoaded);
                                if (self.audioControlIsLoaded) {
                                    clearInterval(intervalSerialize);
                                    onLoadDoneCallback(self.serialize());
                                }
                            }
                            intervalSerialize = window.setInterval(checkAudioComponent, 200);
                        }
                    }

                    //load preset options to UI if DeviceOption cache is enabled
                    self.loadPresetDeviceOptions(data.DeviceOptionPreset);

                    kendo.ui.progress($(self.Parameters.dialogDeviceOptions), false);
                }
                var dlError = function (data) {

                }

                var ajaxOptions = $.extend({}, AjaxUtility(dlError, dlSuccess).ajaxPostOptions, dlAjaxOption);
                setTimeout(function () {
                    $.ajax(ajaxOptions);
                }, 1000);
            },

            loadPresetDeviceOptions: function (deviceOptions) {
                var self = this;

                //Element type: radio, checkbox, textbox, multiline, single select, multiselect, audio
                if (athoc.iws.publishing.settings.EnableDeviceOptionCache && deviceOptions) {

                    //TODO: remove console logs
                    console.log("Device Option Cache Enabled : " + athoc.iws.publishing.settings.EnableDeviceOptionCache);
                    console.log(deviceOptions);

                    if (deviceOptions != null && deviceOptions.length != 0) {
                        _.each(deviceOptions, function (deviceOption) {
                            if (deviceOption.Elements && deviceOption.Elements.length != 0) {
                                _.each(deviceOption.Elements, function (element) {

                                    var obj = $('[name="' + element.Id + '"]');
                                    if (obj.length != 0) {
                                        if (obj.prop("type") == "radio") {
                                            //radio
                                            var selRadio = $('[name="' + element.Id + '"]').filter('[value="' + element.Value + '"]');
                                            selRadio.prop('checked', true);
                                            selRadio.click();
                                        }
                                        else if (obj.prop("type") == "checkbox") {
                                            //checkbox
                                            var checked = (element.Value && element.Value == 'on');

                                            //IWS-33320: Do opposit selection and trigger click!
                                            obj.prop('checked', !checked);
                                            obj.click();

                                        }
                                        else if (obj.prop("type") == "select-one")  {
                                            //single select
                                            obj.val(element.Value);
                                            obj.selectpicker('render');
                                        }
                                        else if (obj.prop("multiple") == "multiple") {
                                            //multiselect
                                            if (element.Value && element.Value != "") {
                                                obj.val(element.Value.split(","));
                                                obj.selectpicker('render');
                                            }
                                        }
                                        else if ((obj.prop("type") == "textarea") || (obj.prop("type") == "text")) {
                                            //textbox, multiline
                                            obj.val(element.Value);
                                        }
                                        else if (obj.prop("type") == "hidden") {
                                            //audio
                                            if (obj.hasClass("AudioId") && element.Value) {
                                                var component = self.findAudioComponent(self.getAudioComponentId(element.Name));
                                                if (component) {
                                                    var audioId = element.Value;

                                                    //now must retrieve filename and stream
                                                    var fileName = _.find(this, function (item) { return item.Name == element.Name.replace(/(?=.)[a-zA-Z]*$/, "Name") }).Value;
                                                    var fileStream = _.find(this, function (item) { return item.Name == element.Name.replace(/(?=.)[a-zA-Z]*$/, "Stream") }).Value;
                                                    //stop the audio if its playing                                                 
                                                    component.Component.stopAudio();
                                                    component.Component.setAudioProperties(audioId, fileName, fileStream);
                                                }
                                            }
                                        }
                                        else {
                                            //TODO: remove console logs
                                            console.log("Missing control type: " + obj.prop("type") + ": Id: " + element.Id + " Value: " + element.Value);
                                        }
                                    }
                                });
                            }
                        });
                    }

                    //save the changes
                    self.serialize();
                }
            },

            loadOnlyNewDeviceGroups: function (selectedDevices, callback) {
                var groupIdsToGetOptions = new Array();
                var self = this;
                _.each(self.AllDeviceGroups, function (itemGroup) {
                    var found = _.find(selectedDevices, function (item) {
                        return (item.GroupId == itemGroup.Id);
                    });

                    if (found) {
                        if (!itemGroup.DeviceOptionLoaded) {
                            groupIdsToGetOptions.push(itemGroup.Id);
                        }
                        $("#deviceGroupOptionTab" + itemGroup.Id).show();
                        $("#deviceGroupOptionTab" + itemGroup.Id + "Body").show();
                        itemGroup.Selected = true;
                    } else { //unselected device group
                        itemGroup.Selected = false;
                        //hide tab
                        $("#deviceGroupOptionTab" + itemGroup.Id).hide();
                        $("#deviceGroupOptionTab" + itemGroup.Id + "Body").hide();
                    }

                });

                //make ajax call if there are device options not yet loaded.
                if (groupIdsToGetOptions.length != 0) {
                    kendo.ui.progress($(self.Parameters.dialogDeviceOptions), true);

                    var dlAjaxOption =
                    {
                        type: "POST",
                        url: self.Parameters.moreDeviceOptionURL,
                        data: { deviceGroupIds: groupIdsToGetOptions, type: self.Parameters.deviceType },
                    };

                    var dlSuccess = function (data) {
                        _.each(data.deviceGroupOptions, function (itemFromServer) {
                            var found = _.find(self.AllDeviceGroups, function (item) {
                                return (itemFromServer.Id == item.Id);
                            });

                            if (found) {
                                found.DeviceOptionLoaded = true;
                                found.ElementList = itemFromServer.ElementList;

                                found.HasExtension = itemFromServer.HasExtension;

                                found.Selected = true;
                                if (!itemFromServer.HasExtension) {
                                    $("#deviceGroupOptionTab" + itemFromServer.Id + "Body").append(self.CONST_TAB_BODY_TEMPLATE.format(self.CONST_BODY_UNAVAILABLE_TEMPLATE.format(self.Parameters.resources.Publishing_Devices_Device_Options_Unavailable)));
                                    //$("#deviceGroupOptionTab" + itemFromServer.Id + "Body").find(":nth-child(1)").find(":nth-child(1)").after(itemFromServer.HTML);
                                } else {
                                    $("#deviceGroupOptionTab" + itemFromServer.Id + "Body").append(self.CONST_TAB_BODY_TEMPLATE.format(itemFromServer.HTML)).promise().done(function () {
                                        if (itemFromServer.HTML != null) {
                                            var tabBody = $(self.CONST_TAB_BODY_CONTAINER.format(itemFromServer.Id));

                                            try {
                                                eval("device_option_load_" + itemFromServer.Id + "()");//<xsl:value-of select="$DeviceGroupID" />() {
                                                //eval(tabBody.find("script").text());

                                            } catch (e) {
                                            }

                                            $("#deviceGroupOptionTab" + itemFromServer.Id + "Body select").each(function (i) {

                                                if ($(this).find("option").length != 0) {

                                                    $(this).selectpicker({
                                                        noneSelectedText: self.Parameters.resources.Publishing_Devices_Select_None,
                                                        selectedTextFormat: "count>2",
                                                        includeSelectAllOption: true
                                                    });

                                                }else {
                                                    self.disableRadioButton($(this));  
                                                }
                                            });


                                            //eval(tabBody.find("script").text());
                                            $("#deviceGroupOptionTab" + itemFromServer.Id + "Body .device-option-placeholder").each(function (i) {
                                                var currentItem = $(this);
                                                self.showPlaceholder(currentItem);
                                            });

                                            $("#deviceGroupOptionTab" + itemFromServer.Id + "Body .recording").each(function (i) {
                                                self.audioControlIsRequired = true;
                                                audioUploader.isAudioFileChanged = false;
                                                self.showAudioRecorder("#deviceGroupOptionTab" + itemFromServer.Id + "Body .recording");
                                            });


                                            if (!self.audioControlIsRequired || self.audioControlIsLoaded)  //must wait til audio component is loaded. 
                                            {
                                                /*found.CurrentSavedSelection = self.serializeForDeviceGroup(itemFromServer);
                                                if ($("#deviceGroupOptionTab" + itemFromServer.Id + "Body .severityAffected").length != 0 || 
                                                        $("#deviceGroupOptionTab" + itemFromServer.Id + "Body .default-template-severity-label").length != 0) {

                                                    var severity = self.getSeverityInfo();
                                                    self.changeBasedOnSeverity(severity.id,
																			"#deviceGroupOptionTab" + itemFromServer.Id + "Body ",
																			self,
                                                                            severity.name);

                                                }*/
                                                self.runAfterLoad(found, self, itemFromServer)

                                            } else {

                                                //must delay serialize until audiocomponent is loaded
                                                var intervalSerialize = null;
                                                function checkAudioComponent() {
                                                    if (self.audioControlIsLoaded) {
                                                        clearInterval(intervalSerialize);

                                                        self.runAfterLoad(found, self, itemFromServer);

                                                        /*
                                                        found.CurrentSavedSelection = self.serializeForDeviceGroup(itemFromServer);

                                                        if ($("#deviceGroupOptionTab" + itemFromServer.Id + "Body .severityAffected").length != 0 ||
                                                            $("#deviceGroupOptionTab" + itemFromServer.Id + "Body .default-template-severity-label").length != 0)
                                                             {

                                                                var severity = self.getSeverityInfo();

                                                                self.changeBasedOnSeverity(severity.id,
																						"#deviceGroupOptionTab" + itemFromServer.Id + "Body ",
																						self,
                                                                                        severity.name);
                                                            }
                                                            */
                                                    }
                                                }
                                                intervalSerialize = window.setInterval(checkAudioComponent, 200);
                                            }


                                        }
                                    });

                                    //$("#deviceGroupOptionTab" + itemFromServer.Id + "Body").first().first().after(self.CONST_BODY_UNAVAILABLE_TEMPLATE.format(self.Parameters.resources.Publishing_Devices_Device_Options_Unavailable));
                                }
                                $(self.Parameters.dialogDeviceOptions + " .device-option-content").hide();
                                $("#deviceGroupOptionTab" + itemFromServer.Id).show();

                            }

                        });

                        self.showFirstVisibleTab();
                        kendo.ui.progress($(self.Parameters.dialogDeviceOptions), false);

                        if (typeof callback == "function") {

                            if (!self.audioControlIsRequired || self.audioControlIsLoaded)  //must wait til audio component is loaded. 
                            {
                                callback(self.serialize());
                            } else {

                                //must delay serialize until audiocomponent is loaded
                                var intervalSerialize = null;
                                function checkAudioComponent() {
                                    if (self.audioControlIsLoaded) {
                                        clearInterval(intervalSerialize);
                                        callback(self.serialize());
                                    }
                                }
                                intervalSerialize = window.setInterval(checkAudioComponent, 200);
                            }

                        }


                    }

                    var dlError = function (data) {
                    }

                    var ajaxOptions = $.extend({}, AjaxUtility(dlError, dlSuccess).ajaxPostOptions, dlAjaxOption);
                    $.ajax(ajaxOptions);
                } else {
                    self.showFirstVisibleTab();
                    if (typeof callback == "function") {
                        callback(self.serialize());
                    }
                }


            },

            runAfterLoad: function (found, self, itemFromServer) {
                found.CurrentSavedSelection = self.serializeForDeviceGroup(itemFromServer);
                if ($("#deviceGroupOptionTab" + itemFromServer.Id + "Body .severityAffected").length != 0 ||
                        $("#deviceGroupOptionTab" + itemFromServer.Id + "Body .default-template-severity-label").length != 0) {

                    var severity = self.getSeverityInfo();
                    self.changeBasedOnSeverity(severity.id,
                                            "#deviceGroupOptionTab" + itemFromServer.Id + "Body ",
                                            self,
                                            severity.name);

                }

                //apply changes based on locale
                self.localeChange(itemFromServer, self);

                /*if ($("#deviceGroupOptionTab" + itemFromServer.Id + "Body .filter-by-alert-locale").length != 0) {

                    self.changeBasedOnLocale(self.getLocale(),
                                            "#deviceGroupOptionTab" + itemFromServer.Id + "Body ",
                                            self);
                }*/

            },

            localeChange: function (itemFromServer, self) {
                if ($("#deviceGroupOptionTab" + itemFromServer.Id + "Body .filter-by-alert-locale").length != 0) {

                    self.changeBasedOnLocale(self.getLocale(),
                                            "#deviceGroupOptionTab" + itemFromServer.Id + "Body ",
                                            self);
                }
            },

            showPlaceholder: function (currentItem) {

                require(["publishing/Placeholder/Placeholder", "dijit/registry"], function (Placeholder, registry) {


                    var ph = registry.byId(currentItem.attr("id"));
                    if (ph) {
                        ph.destroy();
                    }

                    var txt = $($('[name="' + currentItem.attr("textbox") + '"]'))[0];
                    var options = { textField: txt, items: athoc.iws.publishing.placeHolderItems, showOnLeft: true, isStatic: false }

                    ph = new Placeholder(options, currentItem[0]);

                    //var ph = new Placeholder(options, $("#" + currentItem.attr('id'), txt.parentNode)[0]);

                    ph.startup();
                });
            },

            showAudioRecorder: function (currentItem) {

                var self = this;

                //try to retrieve audio Id and Name by searching in other fields. 
                var controlId = $(currentItem).attr("id");

                //text manipulation to get element name
                var splitted = controlId.split(".");
                splitted.pop();
                splitted = splitted.join(".");

                var audioId = $("*[name='" + splitted + ".Id']").val();
                var audioName = $("*[name='" + splitted + ".Name']").val();

                //pass audio Id and audio Name if already selected

                var ph;
                var safari = false;
                if (navigator.userAgent.indexOf('Safari') != -1 && navigator.userAgent.indexOf('Chrome') == -1) {
                    safari = true;
                }

                require(["publishing/AudioUploader/AudioUploader"], function (AudioUploader) {
                    var options = {
                        fileName: audioName,
                        audioId: audioId,
                        fileStream: "",
                        isReadOnly: false,
                        isBrowseSpecific: navigator.userAgent.toLowerCase().indexOf('trident') != -1 || safari ? true : false,
                        operator: audioUploader.operatorName,
                    }
                    ph = new AudioUploader(options, $(currentItem)[0], audioUploader);

                    ph.on("ready", function () {
                        self.audioControlIsLoaded = true;
                        //save component instance so it can be referenced during serialize
                        self.AudioComponents.push({ Id: splitted, Component: ph, Required: (audioId != "") });
                        self.AudioComponents[0].Component.viewModel.isChanged(audioUploader.isAudioFileChanged);
                    });
                    ph.startup();

                });


                //hide audio if not supported
                if (!athoc.iws.publishing.settings.IsRecordedAudioSupported) {
                    $("[id*='.Recorded-Container']").css("display", "none");
                }
            },

            showFirstVisibleTab: function () {
                var self = this;

                _.each(this.AllDeviceGroups, function (item) {
                    if (item.Selected) {
                        self.clickTab(self, $("#deviceGroupOptionTab" + item.Id), false);
                        //$("#deviceGroupOptionTab" + item.Id).click();
                        return;
                    }
                });
            },

            setDeviceValidation: function (groupId, control, isValid, errMsg) {

                var varlidationArray = $(this.CONST_INFO_TAG_SELECTOR.format(groupId)).data("ValidationError");
                if (isValid) { //remove from validation array
                    varlidationArray = _.filter(varlidationArray, function (item) { return item.controlName !== control });
                } else {
                    var found = _.find(varlidationArray, function (item) {
                        return (item.controlName == control);
                    });

                    if (!found) {
                        varlidationArray.push({
                            controlName: control,
                            error: errMsg
                        });
                    }
                }
                $(this.CONST_INFO_TAG_SELECTOR.format(groupId)).data("ValidationError", varlidationArray);

                //if (isValid == false) {
                //    setValidationError(SHELLSECTIONID_DEVICES, "../../images/inlinehelp.gif", control, errMsg);
                //}
                //else {
                //    removeValidationError(SHELLSECTIONID_DEVICES, control);
                //}

                //testSelectedDevice();
            },

            isDeviceGroupSelected: function (groupId) {
                var self = this;
                var found = _.find(self.AllDeviceGroups, function (item) {
                    return (item.Id == groupId && item.Selected);
                });
                return found;
            },

            requireUnrequireAudioControl: function (elementId, required) { // set required status of audio control

                //go through list of audio components and see if corresponding audio component can be found. 
                _.each(this.AudioComponents, function (audio) {
                    if (audio.Id.indexOf(elementId) == 0) { //audio Id starts with elementId 
                        audio.Required = required;
                    }
                });
            },

            validateAudio: function () {
                var self = this;
                var optionsArray = new Array();
                var isValid = true;
                _.each(this.AllDeviceGroups, function (item) {
                    if (item.DeviceOptionLoaded && item.Selected && item.Selected && item.HasExtension) {
                        _.each(item.ElementList, function (element) {
                            var obj = $('[id="' + element + '"]');
                            if (obj.length != 0) {

                                if (obj.hasClass("recording")) { //is a recording

                                    value = "some value";

                                    //find audio component
                                    var found = self.findAudioComponent(self.getAudioComponentId(element));

                                    if (found) {
                                        //stop the audio if its playing 
                                        found.Component.stopAudio();
                                        audioUploader.isAudioFileChanged = found.Component.viewModel.isChanged();
                                        //check to see if it is required, and also check to see if it is valid. 
                                        if (found.Required) {
                                            if (!found.Component.audioProperties.isValid) { //if component is invalid return false
                                                found.Component.showValidation();
                                                isValid = false;
                                            }
                                        }
                                    }

                                }
                            }

                        });

                    }

                });
                return isValid;
            },

            getAudioComponentId: function (eid) {
                //text manipulation to get element name
                var splitted = eid.split(".");
                splitted.pop();
                splitted = splitted.join(".");
                return splitted;
            },

            findAudioComponent: function (id) {
                var self = this;
                var found = _.find(self.AudioComponents, function (item) {
                    return (id == item.Id);
                });
                return found;
            },

            changeBasedOnSeverity: function (severity, parentDiv, self, severityName) {

                if (typeof self == "undefined") {
                    self = this;
                }

                //if parentDiv has value, only modify within specified div
                if (typeof parentDiv === "undefined") {
                    parentDiv = "";
                }

                $(parentDiv + ".severityAffected").each(function () {
                    if ($(this).hasClass(severity)) {
                        $(this).click();
                    }
                });
                self.setSeverityText(severity, parentDiv, self, severityName);

                self.setSeverityBasedInfo(parentDiv, severity);

                //disable all radios if required etc.
                self.Parameters.submitEventWrapperObj.ExecuteAll();

                //save the changes
                if (typeof self.OnSaveCallBack == "function") {
                    self.OnSaveCallBack(self.serialize());
                }
            },

            setSeverityText: function (severity, parentDiv, self, severityName) {
                if (typeof severityName == "undefined") {
                    severityName = athoc.iws.publishing.content.viewModel.data.getSeverityNanmeFromId(severity);
                }
                $(parentDiv + ".default-template-severity-label").text(severityName);
            },

            setSeverityBasedInfo: function (parentDiv, severity) {
                //set any hidden value affected by severity (for mpn)
                $(parentDiv + ".change-value-by-severity").each(function () {
                    $(this).val($(this).attr("severity" + severity));
                });

                $(parentDiv + ".change-text-by-severity").each(function () {
                    $(this).text($(this).attr("severity" + severity));
                });

            },

            changeBasedOnLocale: function (newLocale, parentDiv, self) {

                if (typeof self == "undefined") {
                    self = this;
                }

                var selectSelector = "select";

                //if parentDiv has value, only modify within specified div
                if (typeof parentDiv === "undefined") {
                    parentDiv = "";
                } else {
                    selectSelector = parentDiv + " select";
                }

                //for each item that should be filtered by locale (audio and template)
                $(selectSelector).each(function (index, selectObj) {



                    if ($(selectObj).hasClass("filter-by-alert-locale")) {

                        var selected = $(selectObj).find("option:selected");

                        var selectionNeedsToBeModified = (selected.length == 0) ? true : (selected.attr("class").toLowerCase() != newLocale.toLowerCase() && selected.attr("class").toLowerCase() != "any"); //selected template does not match current alert locale 

                        //show hide based on locale. 
                        $(selectObj).find("option").each(function (indexOption, optionObj) {

                            if ($(optionObj).attr("class").toLowerCase() != newLocale.toLowerCase() && $(optionObj).attr("class").toLowerCase() != "any") {
                                $(optionObj).hide();
                            } else {
                                $(optionObj).show();
                            }
                        });

                        $(this).selectpicker("refresh");


                        // see if selected option no longer matches the locale
                        if (selectionNeedsToBeModified) //selected template does not match current alert locale 
                        {
                            //select "default" option
                            $(parentDiv + " ." + $(this).attr("defaultradiobuttonselector")).click();

                            var visibleFound = false;

                            var selectObj = $(this);
                            $(selectObj).find("option").each(function (indexOption, optionObj) {
                                if ($(optionObj).attr("class").toLowerCase() == newLocale.toLowerCase() || $(optionObj).attr("class").toLowerCase() == "any") { //this option is visible.                                    
                                    selectObj.selectpicker('val', $(optionObj).val());
                                    visibleFound = true;
                                    return false;
                                }
                            });

                            var previewButtonObj = $("a[id^='" + $(selectObj).prop("id").replace(/\.\w*$/, "") + "']");

                            if (!visibleFound) { //no audio/template is there for selected locale
                                $(selectObj).selectpicker('val', '');

                                previewButtonObj.addClass("disabled");

                                //remove event - for IEs
                                if (typeof previewButtonObj.data("click") == "undefined") //store events
                                {
                                    previewButtonObj.data("click_event", $._data(previewButtonObj[0], "events").click[0].handler)
                                }
                                previewButtonObj.off("click");
                                //put return false so click here doesn't scroll the page. 
                                previewButtonObj.on("click", function () {
                                    return false;
                                });


                            } else {
                                previewButtonObj.removeClass("disabled");

                              
                                // if data("click") is not empty then add the click
                                if (typeof previewButtonObj.data("click_event") != "undefined") {
                                    previewButtonObj.off("click");
                                    previewButtonObj.on("click", previewButtonObj.data("click_event"));
                                }
                            }
                        }



                    }

                })

                //disable all radios if required etc.
                self.Parameters.submitEventWrapperObj.ExecuteAll();

                //save the changes
                if (typeof self.OnSaveCallBack == "function") {
                    self.OnSaveCallBack(self.serialize());
                }
            },

            clickTab: function (self, element, fromUserAction) {

                if ($("#RecordWarning") != null && $("#RecordWarning") != undefined) {
                    $("#RecordWarning").html("");
                }

                if (self.CurrentlySelectedGroup != -1) {
                    self.Parameters.submitEventWrapperObj.ExecuteAll();

                    if (fromUserAction) { //apply this only when there is a validation error
                        if ($(self.CONST_INFO_TAG_SELECTOR.format(self.CurrentlySelectedGroup)).data("ValidationError").length != 0) //validation error, stay on the page
                        {
                            return;
                        }
                    }
                }


                //verify validity of audio components
                if (!self.validateAudio()) return;

                self.CurrentlySelectedGroup = element.attr("groupId");
                $(self.Parameters.dialogDeviceOptions + " " + ".device-option-content").hide();
                $("#" + element.attr("id") + "Body").show();
                $(self.Parameters.dialogDeviceOptions + " " + '.device-option-tab').removeClass('selected');

                element.addClass('selected');

            },

            getSeverityInfo: function () {
                var severityId;
                var severityName;
                try {
                    severityId =  athoc.iws.publishing.content.viewModel.data.SeverityId();
                    severityName = undefined;
                } catch (e) {
                    severityId = athoc.iws.publishing.detail.viewModel.Content.SeverityId;
                    severityName = athoc.iws.publishing.detail.viewModel.Content.SeverityName;
                }
                
                return {
                    id: severityId,
                    name: severityName
                };

            },

            getLocale: function () {
                try {
                    return athoc.iws.publishing.content.viewModel.data.Local();
                    severityName = undefined;
                } catch (e) { // if content section is read only come here
                    return athoc.iws.publishing.detail.viewModel.Content.Local;
                }
            },
			
			disableRadioButton: function($this) {
                try {
                    $parent = $($this).closest('div.option-content');
                    $selectId = $($parent).find("select").attr("id");
                    $label = $($parent).prev().prev();

                    var labelId = $($label).attr("id");
                    var containerId = $selectId.substring(0, $selectId.lastIndexOf(".")) + "-Container";

                    if (labelId == containerId) {
                        $label.find('input[type=radio]').attr('disabled', 'disabled')
                            .attr('doNotEnable', 'true')
                            .css("cursor", "not-allowed");
                    }
                } catch (e) { }
            }
        };
    }
}

