﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.scenario = athoc.iws.scenario || {};

if (athoc.iws.scenario) {
    var FromDateValueForServer;
    ko.validation.init({
        insertMessages: false,
        errorElementClass: 'err-cntrl'
    });
    athoc.iws.scenario.schedule = function () {

        return {
            isInErrorState: false,
            IsActiveRecurrence: false,
            IsActiveError: false,
            tempRecur_StartDate: "",
            scheduleRecurrenceType: "0",
            IsScheduleChanged: false,
            viewModel: {
                starttimehours: ko.observableArray([{ value: 1, text: "01" }, { value: 2, text: "02" }, { value: 3, text: "03" }, { value: 4, text: "04" }, { value: 5, text: "05" }, { value: 6, text: "06" }, { value: 7, text: "07" }, { value: 8, text: "08" }, { value: 9, text: "09" }, { value: 10, text: "10" }, { value: 11, text: "11" }, { value: 12, text: "12" }]),
                starttimeminutes: ko.observableArray([{ value: 0, text: "00" }, { value: 1, text: "01" }, { value: 2, text: "02" }, { value: 03, text: "03" }, { value: 4, text: "04" }, { value: 5, text: "05" }, { value: 6, text: "06" }, { value: 7, text: "07" }, { value: 8, text: "08" }, { value: 9, text: "09" }, { value: 10, text: "10" }, { value: 11, text: "11" }, { value: 12, text: "12" }, { value: 13, text: "13" }, { value: 14, text: "14" }, { value: 15, text: "15" }, { value: 16, text: "16" }, { value: 17, text: "17" }, { value: 18, text: "18" }, { value: 19, text: "19" }, { value: 20, text: "20" }, { value: 21, text: "21" }, { value: 22, text: "22" }, { value: 23, text: "23" }, { value: 24, text: "24" }, { value: 25, text: "25" }, { value: 26, text: "26" }, { value: 27, text: "27" }, { value: 28, text: "28" }, { value: 29, text: "29" }, { value: 30, text: "30" }, { value: 31, text: "31" }, { value: 32, text: "32" }, { value: 33, text: "33" }, { value: 34, text: "34" }, { value: 35, text: "35" }, { value: 36, text: "36" }, { value: 37, text: "37" }, { value: 38, text: "38" }, { value: 39, text: "39" }, { value: 40, text: "40" }, { value: 41, text: "41" }, { value: 42, text: "42" }, { value: 43, text: "43" }, { value: 44, text: "44" }, { value: 45, text: "45" }, { value: 46, text: "46" }, { value: 47, text: "47" }, { value: 48, text: "48" }, { value: 49, text: "49" }, { value: 50, text: "50" }, { value: 51, text: "51" }, { value: 52, text: "52" }, { value: 53, text: "53" }, { value: 54, text: "54" }, { value: 55, text: "55" }, { value: 56, text: "56" }, { value: 57, text: "57" }, { value: 58, text: "58" }, { value: 59, text: "59" }]),
                starttimemeridian: ko.observableArray([{ value: "AM", text: "AM" }, { value: "PM", text: "PM" }]),
                scenarioSchedule: ko.observable(),
                FromDateValue: ko.observable(),
                timeformart: ko.observableArray(),
                recurrencepath: ko.observableArray(),
                days: ko.observableArray([{ value: 1, text: 1 }, { value: 2, text: 2 }, { value: 3, text: 3 }, { value: 4, text: 4 }, { value: 5, text: 5 }, { value: 6, text: 6 }, { value: 7, text: 7 }, { value: 8, text: 8 }, { value: 9, text: 9 }, { value: 10, text: 10 }, { value: 11, text: 11 }, { value: 12, text: 12 }, { value: 13, text: 13 }, { value: 14, text: 14 }, { value: 15, text: 15 }, { value: 16, text: 16 }, { value: 17, text: 17 }, { value: 18, text: 18 }, { value: 19, text: 19 }, { value: 20, text: 20 }, { value: 21, text: 21 }, { value: 22, text: 22 }, { value: 23, text: 23 }, { value: 24, text: 24 }, { value: 25, text: 25 }, { value: 26, text: 26 }, { value: 27, text: 27 }, { value: 28, text: 28 }, { value: 29, text: 29 }, { value: 30, text: 30 }, { value: 31, text: 31 }]),
                daynames: ko.observableArray(),
                numbernames: ko.observableArray(),
                monthnames: ko.observableArray(),
                IsAffiliate: ko.observable(false),
            },

            load: function () {
            },

            //is ready for publish
            isReadyToPublish: function () {
                return (this.isValid);
            },

            initiatePickers: function () {

                var dateformat = athoc.iws.scenario.schedule.getVPSTimeFormat('dateformat');
                var timeformat = athoc.iws.scenario.schedule.getVPSTimeFormat('timeformat');
                var momentdateformat = athoc.iws.scenario.schedule.getVPSTimeFormat('momentdateformat');
                var momenttimeformat = athoc.iws.scenario.schedule.getVPSTimeFormat('momenttimeformat');
                var AMPMformat = $.vpsDateTimeFormat.indexOf('tt') > 0 ? true : false;


                $("#ddlAlertTimeHr").selectpicker();
                $("#ddlAlertTimeFormat").selectpicker();
                $("#ddlRecurrencePattern").selectpicker();

                $("#ddlYearMonthsctr1").selectpicker();
                $("#ddlYearIndexDay").selectpicker();
                $("#ddlYearWeekDays").selectpicker();
                $("#ddlYearMonthsCtr2").selectpicker();

                $("#ddlMonthDays").selectpicker();
                $("#ddlIndexDay").selectpicker();
                $("#ddlWeekDays").selectpicker();

                //Recurrence Time dropdowns
                var Dt = new Date(moment(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.recurrenceTime(), "HH:mm A"));
                var hours = Dt.getHours();
                var minutes = Dt.getMinutes();
                var ampm = hours >= 12 ? "PM" : "AM";
                hours = (hours % 12) ? (hours < 10 ? '0' + hours : (hours < 13 ? hours : ((hours - 12) < 10 ? '0' + (hours - 12) : (hours - 12)))) : 12;
                minutes = minutes < 10 ? '0' + minutes : minutes;
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartHourSelect(hours.toString());
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartMinuteSelect(minutes.toString());
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartAmpmSelect(ampm); 
                $("#ddlStartTimeHr").selectpicker();
                $("#ddlStartTimeMin").selectpicker();
                $("#ddlStartTimelMer").selectpicker();
                //End Recurrence Time dropdowns

                $('#iScheduleRecurrenceTime').datetimepicker({
                    pickDate: false,
                    pickTime: true,
                    pick12HourFormat: AMPMformat,
                    pickSeconds: false,
                    language: $.culture,
                    startDate: new Date(moment($.vpsTimeZone.CurrentVPSDate.toDateString() + " " + athoc.iws.scenario.schedule.viewModel.scenarioSchedule.recurrenceTime(), momenttimeformat)),// "MM/DD/YYYY hh:mm A"
                    format: momenttimeformat.replace(":ss", ""),
                    setValue: new Date(moment($.vpsTimeZone.CurrentVPSDate.toDateString() + " " + athoc.iws.scenario.schedule.viewModel.scenarioSchedule.recurrenceTime(), momenttimeformat)),// "MM/DD/YYYY hh:mm A"
                }).on('changeDate', function (ev) {
                    if (ev.localDate == null)
                        ev.localDate = new Date(moment($.vpsTimeZone.CurrentVPSDate.toDateString() + " " + athoc.iws.scenario.schedule.viewModel.scenarioSchedule.recurrenceTime(), "MM/DD/YYYY hh:mm A"));
                    if (ev.localDate != null) {
                        var newDate = moment(ev.localDate).format(momenttimeformat.replace(":ss", ""));
                        athoc.iws.scenario.schedule.viewModel.scenarioSchedule.recurrenceTime(newDate);
                    }
                    else
                        athoc.iws.scenario.schedule.viewModel.scenarioSchedule.recurrenceTime(moment($.vpsTimeZone.CurrentVPSDate.toLocaleString(), momenttimeformat.replace(":ss", "")));
                });

                $('#startDateValue').datetimepicker({
                    pickDate: true,
                    pickTime: false,
                    language: $.culture,

                    startDate: new Date(moment($.vpsTimeZone.CurrentVPSDate.toLocaleDateString(), 'MM/DD/YYYY')),
                    format: dateformat
                }).on('changeDate', function (ev) {
                    if (ev.localDate != null) {
                        var newDate = moment(ev.localDate).format(momentdateformat);
                        athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput(newDate);
                    }
                });

                $('#endDateValue').datetimepicker({
                    pickDate: true,
                    pickTime: false,
                    language: $.culture, startDate: new Date(moment($.vpsTimeZone.CurrentVPSDate.toLocaleDateString(), 'MM/DD/YYYY')),
                    format: dateformat
                }).on('changeDate', function (ev) {
                    if (ev.localDate != null) {
                        var newDate = moment(ev.localDate).format(momentdateformat);
                        athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEnddateInput(newDate);
                    }
                });

                $("#ScenarioSchedules .icon-calendar").click(function () {
                    $('html,body').animate({ scrollTop: 9999 }, 'slow');
                    $('.bootstrap-datetimepicker-widget').css("z-index", "6");
                });
            },

            getVPSTimeFormat: function (formatType) {
                var timeFormat;
                var meridianFormat = $.vpsDateTimeFormat.indexOf('tt') > 0 ? " A" : "";
                var secondsIncluded = $.vpsDateTimeFormat.indexOf('ss') > 0 ? ":ss" : "";
                var dateFormat;
                switch (formatType) {

                    case "timeformat":
                        timeFormat = $.trim($.vpsDateTimeFormat.replace($.vpsDateFormat, "").toLowerCase().replace("tt", "PP").replace("hh", "HH"));
                        return timeFormat;
                        break;
                    case "dateformat":
                        dateFormat = $.vpsDateFormat;
                        return dateFormat;
                        break;
                    case "momenttimeformat":
                        if (meridianFormat == "")
                            timeFormat = "HH:mm" + secondsIncluded;
                        else
                            timeFormat = "hh:mm" + secondsIncluded + meridianFormat;
                        return timeFormat;

                        break;
                    case "momentdateformat":
                        dateFormat = $.vpsDateFormat.toUpperCase();
                        return dateFormat;
                        break;
                }



            },


            bind: function (data) {
                //check if schedule feature is enabled
                if (!athoc.iws.publishing.settings.IsSchedulingSupported)
                    return;
                data.ScheduleRecurrenceType = 0;
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule = ko.mapping.fromJS(data, athoc.iws.scenario.schedule.getValidation());
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceType(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleActivateRecurrenceCheck() ? "1" : "0");
                // Dropdown List
                athoc.iws.scenario.schedule.viewModel.timeformart(data.TimeFormat);
                athoc.iws.scenario.schedule.viewModel.recurrencepath(data.TimePeriod);
                athoc.iws.scenario.schedule.viewModel.daynames(data.DayNames);
                athoc.iws.scenario.schedule.viewModel.monthnames(data.MonthNames);
                athoc.iws.scenario.schedule.viewModel.numbernames(data.NumberNames);
                //keep old start date into temp variable to verify
                if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleActivateRecurrenceCheck())
                    athoc.iws.scenario.schedule.tempRecur_StartDate = athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput();
                else
                    athoc.iws.scenario.schedule.tempRecur_StartDate = "";

                //View Model binding
                $("#ScenarioSchedules").find(".bootstrap-select").remove();
                ko.cleanNode($("#ScenarioSchedules").get(0));
                ko.applyBindings(athoc.iws.scenario.schedule.viewModel, $("#ScenarioSchedules").get(0));
                // set model parameters
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio(data.ScheduleRecurrenceRadio);
                athoc.iws.scenario.schedule.IsActiveRecurrence = athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleActivateRecurrenceCheck();
                athoc.iws.scenario.schedule.scheduleRecurrenceType = athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleActivateRecurrenceCheck() ? "1" : "0";
                //reset start date to current date if recurrence is not checked.
                if (!athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleActivateRecurrenceCheck())
                    athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput(moment($.vpsTimeZone.CurrentVPSDate).format(dateformat));
                // Initiate Bootstrap pickers
                athoc.iws.scenario.schedule.initiatePickers();
                athoc.iws.scenario.schedule.enableRecurrencePeriod(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndRadiogroup());

                athoc.iws.scenario.schedule.enableDailyGroupOptions(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceDailyRadiogroup());

                athoc.iws.scenario.schedule.enableYearlyGroupOptions(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceYearlyModeRadiogroup());

                athoc.iws.scenario.schedule.enableMonthlyGroupOptions(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceMonthlyRadiogroup());

                //Initiate Subscribe Methods
                athoc.iws.scenario.schedule.scenarioSchedulesubscribers();
                //Verify schedule section is ready
                athoc.iws.scenario.schedule.isScheduleReady();
            },
            scenarioSchedulesubscribers: function () {

                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartHourSelect.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.IsScheduleChanged = true;
                    athoc.iws.scenario.schedule.viewModel.scenarioSchedule.recurrenceTime(moment(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartHourSelect() + ":" + athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartMinuteSelect() + ": " + athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartAmpmSelect(), "hh:mm A").format(athoc.iws.scenario.schedule.getVPSTimeFormat('momenttimeformat').replace(":ss", "")));
                });
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartMinuteSelect.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.IsScheduleChanged = true;
                    athoc.iws.scenario.schedule.viewModel.scenarioSchedule.recurrenceTime(moment(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartHourSelect() + ":" + athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartMinuteSelect() + ": " + athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartAmpmSelect(), "hh:mm A").format(athoc.iws.scenario.schedule.getVPSTimeFormat('momenttimeformat').replace(":ss", "")));
                });
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartAmpmSelect.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.IsScheduleChanged = true;
                    athoc.iws.scenario.schedule.viewModel.scenarioSchedule.recurrenceTime(moment(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartHourSelect() + ":" + athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartMinuteSelect() + ": " + athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartAmpmSelect(), "hh:mm A").format(athoc.iws.scenario.schedule.getVPSTimeFormat('momenttimeformat').replace(":ss", "")));
                });

                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleActivateRecurrenceCheck.subscribe(function (newValue) {
                    if (newValue)
                        athoc.iws.scenario.schedule.IsScheduleChanged = true;
                    else
                        athoc.iws.scenario.schedule.IsScheduleChanged = false;
                    switch (parseInt(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio())) {
                        case 4:
                            $("#RecurrenceWeekly").css("display", "none");
                            $("#RecurrenceMonthly").css("display", "none");
                            $("#RecurrenceYearly").css("display", "none");
                            $("#RecurrenceDaily").css("display", "");
                            break;
                        case 8:
                            $("#RecurrenceMonthly").css("display", "none");
                            $("#RecurrenceYearly").css("display", "none");
                            $("#RecurrenceDaily").css("display", "none");
                            $("#RecurrenceWeekly").css("display", "");
                            break;
                        case 16:
                            $("#ddlMonthDays").selectpicker();
                            $("#ddlIndexDay").selectpicker();
                            $("#ddlWeekDays").selectpicker();
                            $("#RecurrenceWeekly").css("display", "none");
                            $("#RecurrenceYearly").css("display", "none");
                            $("#RecurrenceDaily").css("display", "none");
                            $("#RecurrenceMonthly").css("display", "");
                            break;
                        case 64:
                            $("#ddlYearMonthsctr1").selectpicker();
                            $("#ddlYearIndexDay").selectpicker();
                            $("#ddlYearWeekDays").selectpicker();
                            $("#ddlYearMonthsCtr2").selectpicker();
                            $("#RecurrenceWeekly").css("display", "none");
                            $("#RecurrenceMonthly").css("display", "none");
                            $("#RecurrenceDaily").css("display", "none");
                            $("#RecurrenceYearly").css("display", "");
                            break;

                    }

                    if (!athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput.isValid())
                        athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput.valueHasMutated();
                });
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio.subscribe(function (newValue) {

                    if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio() == 64) {
                        $("#ddlYearMonthsctr1").selectpicker();
                        $("#ddlYearIndexDay").selectpicker();
                        $("#ddlYearWeekDays").selectpicker();
                        $("#ddlYearMonthsCtr2").selectpicker();
                    }

                    if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio() == 16) {
                        $("#ddlMonthDays").selectpicker();
                        $("#ddlIndexDay").selectpicker();
                        $("#ddlWeekDays").selectpicker();
                    }
                });
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleDurationInput.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.isScheduleReady();
                });
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceDailyFrequencyInput.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.isScheduleReady();
                });


                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceWeeklyFrequencyInput.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.isScheduleReady();
                });

                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceMonthlyFrequencyInput.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.isScheduleReady();
                });

                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceYearlyAbsoluteDayInput.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.isScheduleReady();
                });

                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndCountInput.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.isScheduleReady();
                });

                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndCountInput.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.isScheduleReady();
                });

                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.isScheduleReady();
                });

                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEnddateInput.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.isScheduleReady();
                });
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.isScheduleReady();
                });
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceYearlyModeRadiogroup.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.enableYearlyGroupOptions(newValue);
                    athoc.iws.scenario.schedule.isScheduleReady();
                });
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceDailyRadiogroup.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.enableDailyGroupOptions(newValue);
                    athoc.iws.scenario.schedule.isScheduleReady();
                });
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceMonthlyRadiogroup.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.enableMonthlyGroupOptions(newValue);
                });
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndRadiogroup.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.enableRecurrencePeriod(newValue);
                    athoc.iws.scenario.schedule.isScheduleReady();
                });
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceYearlyAbsoluteMonthSelect.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.isScheduleReady();
                });
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceWeeklyFrequencyInput.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.isScheduleReady();
                });
                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceWeekly.subscribe(function (newValue) {
                    athoc.iws.scenario.schedule.isScheduleReady();
                });

                athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceType.subscribe(function (newValue) {
                    if (newValue == 0)
                        athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleActivateRecurrenceCheck(false);
                    else
                        athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleActivateRecurrenceCheck(true);
                    athoc.iws.scenario.schedule.isScheduleReady();
                });
                athoc.iws.scenario.schedule.isScheduleReady();
            },
            enableDailyGroupOptions: function (value) {
                if (value == 2) {
                    $("#txtScheduleRecurrenceDailyFrequencyInput").removeAttr("disabled");
                    if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceDailyFrequencyInput() == "") {
                        athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceDailyFrequencyInput.isModified(true);
                    }
                    else {
                        athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceDailyFrequencyInput.isModified(false);
                    }
                }
                else {
                    athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceDailyFrequencyInput.isModified(false);
                    $("#txtScheduleRecurrenceDailyFrequencyInput").attr("disabled", "disabled");
                }
            },

            enableMonthlyGroupOptions: function (value) {
                if (value == 16) {
                    $('[data-id=ddlMonthDays]').removeAttr("disabled");
                    $('[data-id=ddlIndexDay]').attr("disabled", "disabled");
                    $('[data-id=ddlWeekDays]').attr("disabled", "disabled");
                }
                if (value == 32) {
                    $('[data-id=ddlMonthDays]').attr("disabled", "disabled");
                    $('[data-id=ddlIndexDay]').removeAttr("disabled");
                    $('[data-id=ddlWeekDays]').removeAttr("disabled");
                }


            },
            enableYearlyGroupOptions: function (value) {

                if (value == 64) {
                    $('[data-id=ddlYearMonthsctr1]').removeAttr("disabled");
                    $("#txtDay").removeAttr("disabled");
                    $('[data-id=ddlYearIndexDay]').attr("disabled", "disabled");
                    $('[data-id=ddlYearWeekDays]').attr("disabled", "disabled");
                    $('[data-id=ddlYearMonthsCtr2]').attr("disabled", "disabled");
                }
                if (value == 128) {
                    $('[data-id=ddlYearMonthsctr1]').attr("disabled", "disabled");
                    $("#txtDay").attr("disabled", "disabled");
                    $('[data-id=ddlYearIndexDay]').removeAttr("disabled");
                    $('[data-id=ddlYearWeekDays]').removeAttr("disabled");
                    $('[data-id=ddlYearMonthsCtr2]').removeAttr("disabled");
                }
            },
            enableRecurrencePeriod: function (value) {
                if (value == 1) {
                    $("#txtScheduleRecurrenceEndCountInput").attr("disabled", "disabled");
                    $("#endDateValue").datetimepicker("disable");
                    athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndCountInput.isModified(false);
                    athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEnddateInput.isModified(false);
                }
                if (value == 2) {
                    $("#txtScheduleRecurrenceEndCountInput").removeAttr("disabled");
                    $("#endDateValue").datetimepicker("disable");
                    athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEnddateInput.isModified(false);
                    if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndCountInput() == "") {
                        athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndCountInput.isModified(true);
                    }
                    else {
                        athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndCountInput.isModified(false);
                    }
                }
                if (value == 3) {
                    $("#txtScheduleRecurrenceEndCountInput").attr("disabled", "disabled");
                    //$("#endDateValue").datetimepicker("disable");
                    $("#endDateValue").datetimepicker("enable");
                    athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndCountInput.isModified(false);
                    if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEnddateInput() == "") {
                        athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEnddateInput.isModified(true);
                    }
                    else {
                        athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEnddateInput.isModified(false);
                    }
                }
            },
            isValid: function () {
                //check if schedule feature is enabled
                if (!athoc.iws.publishing.settings.IsSchedulingSupported)
                    return true;


                athoc.iws.scenario.schedule.IsActiveError = false;
                if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleDurationInput() == "")
                    return false;
                else {
                    if ($.isNumeric(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleDurationInput()) == false)
                        return false;
                    else {
                        if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleDurationInput() < 1)
                            return false;
                        switch (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleDurationUnitSelect()) {
                            case 'Minute':
                                if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleDurationInput() > 5256000)
                                    return false;
                                break;
                            case 'Hour':
                                if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleDurationInput() > 87600)
                                    return false;
                                break;
                            case 'Day':
                                if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleDurationInput() > 3650)
                                    return false;
                                break;
                        }
                    }
                }
                //if Activate Recurrence is checked
                if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleActivateRecurrenceCheck()) {
                    //Daily group validations
                    if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio() == 4 && athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceDailyRadiogroup() == 2) {
                        if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceDailyFrequencyInput() == "") {
                            athoc.iws.scenario.schedule.IsActiveError = true;
                            return false;
                        } else {
                            if ($.isNumeric(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceDailyFrequencyInput()) == false)
                            { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                            else {
                                if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceDailyFrequencyInput() < 1 || athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceDailyFrequencyInput() > 365)
                                { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                            }
                        }
                    }
                    //Weekly group validations
                    if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio() == 8) {
                        if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceWeeklyFrequencyInput() == "")
                        { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                        else {
                            if ($.isNumeric(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceWeeklyFrequencyInput()) == false)
                            { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                            else {
                                if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceWeeklyFrequencyInput() < 1 || athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceWeeklyFrequencyInput() > 52)
                                { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                            }
                        }
                        //Week days check boxes
                        if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceWeekly().length < 1)
                        { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                    }
                    //Monthly group validations
                    if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio() == 16) {
                        if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceMonthlyFrequencyInput() == "")
                        { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                        else {
                            if ($.isNumeric(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceMonthlyFrequencyInput()) == false)
                            { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                            else {
                                if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceMonthlyFrequencyInput() < 1 || athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceMonthlyFrequencyInput() > 12)
                                { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                            }
                        }
                    }
                    //Yearly group validations
                    if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio() == 64 && athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceYearlyModeRadiogroup() == 64) {
                        if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceYearlyAbsoluteDayInput() == "")
                        { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                        else {
                            if ($.isNumeric(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceYearlyAbsoluteDayInput()) == false)
                            { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                            else {
                                if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceYearlyAbsoluteDayInput() < 1)
                                { athoc.iws.scenario.schedule.IsActiveError = true; return false; }

                                //days per months 
                                switch (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceYearlyAbsoluteMonthSelect()) {
                                    case 2:
                                        if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceYearlyAbsoluteDayInput() > 29)
                                        { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                                        break;
                                    case 1:
                                    case 3:
                                    case 5:
                                    case 7:
                                    case 8:
                                    case 10:
                                    case 12:
                                        if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceYearlyAbsoluteDayInput() > 31)
                                        { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                                        break;
                                    case 4:
                                    case 6:
                                    case 9:
                                    case 11:
                                        if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceYearlyAbsoluteDayInput() > 30)
                                        { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                                        break;
                                }

                            }
                        }
                    }

                    //Start Date
                    if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput() == "")
                    { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                    else {
                        if (!athoc.iws.scenario.schedule.isValidDate(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput()))
                        { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                        //start date should not be older date from today                        
                        if ((moment(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput(), $.vpsDateFormat.toUpperCase()).toDate().toDateString() != ($.vpsTimeZone.CurrentVPSDate).toDateString()) && moment(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput(), $.vpsDateFormat.toUpperCase()).toDate().getTime() - (new Date(($.vpsTimeZone.CurrentVPSDate).toDateString()).getTime()) < 0)
                            //iws-12152(issue#1)
                            //ignore, if already saved start date is not changed
                            if (athoc.iws.scenario.schedule.tempRecur_StartDate != athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput())
                            { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                        //End Date
                        if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndRadiogroup() == 3) {
                            if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEnddateInput() == "")
                            { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                            else {
                                if (!athoc.iws.scenario.schedule.isValidDate(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEnddateInput()))
                                { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                                //End Date should be greater than or equal to Start date
                                if (moment(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEnddateInput(), $.vpsDateFormat.toUpperCase()).toDate() < moment(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput(), $.vpsDateFormat.toUpperCase()).toDate())
                                { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                                if ((athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEnddateInput() != athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput()) && (moment(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEnddateInput(), $.vpsDateFormat.toUpperCase()).toDate().getTime() - moment(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput(), $.vpsDateFormat.toUpperCase()).toDate().getTime() / (24 * 60 * 60 * 1000) < 0))
                                { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                                //Duration between End Date and Start date shuld be less than 10 years
                                if (Math.abs((moment(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEnddateInput(), $.vpsDateFormat.toUpperCase()).toDate().getTime() - moment(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput(), $.vpsDateFormat.toUpperCase()).toDate().getTime()) / (24 * 60 * 60 * 1000)) > 3650)
                                { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                            }
                        }
                    }

                    if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndRadiogroup() == 2) {
                        if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndCountInput() == "")
                        { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                        else {
                            if ($.isNumeric(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndCountInput()) == false)
                            { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                            else {
                                if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndCountInput() < 1 || athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndCountInput() > 3650)
                                { athoc.iws.scenario.schedule.IsActiveError = true; return false; }
                            }
                        }
                    }

                }
                return true;

            },

            isValidDate: function (val) {
                var isValid = true;
                try {
                    // jQuery.datepicker.parseDate($.vpsDateFormat, val, null);
                    //isValid = !isNaN(Date.parse(val));
                    isValid = moment(val, $.vpsDateFormat.toUpperCase()).isValid();
                }
                catch (error) {
                    isValid = false;
                }

                return isValid;
            },
            validDayArrange: function (param1, param2, param3) {
                if (param2[1].indexOf('StartDate') < 0 && param2[1].indexOf('EndDate') < 0) {
                    if ($.isNumeric(param1) == false)
                        return false;
                    if (param1 < 1)
                        return false;
                }
                switch (param2[1]) {
                    case 'Duration':
                        {
                            switch (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleDurationUnitSelect()) {
                                case 'Minute':
                                    if (param1 > 5256000)
                                        return false;
                                    break;
                                case 'Hour':
                                    if (param1 > 87600)
                                        return false;
                                    break;
                                case 'Day':
                                    if (param1 > 3650)
                                        return false;
                                    break;
                            }
                            break;
                        }
                    case 'Days':
                        {
                            if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceDailyRadiogroup() == 2 && param1 > 365)
                                return false;
                            break;
                        }
                    case 'Weeks':
                        {
                            if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio() == 8 && param1 > 52)
                                return false;
                            //Week days check boxes
                            //if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio() == 8 && athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceWeekly().length < 1)
                            //    return false;
                            break;
                        }
                    case 'Months':
                        {
                            if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio() == 16 && param1 > 12)
                                return false;
                            break;
                        }
                    case 'Recurrence':
                        {
                            if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndRadiogroup() == 2 && param1 > 3650)
                                return false;
                            break;
                        }
                    case 'StartDate':
                        {
                            if (!athoc.iws.scenario.schedule.isValidDate(param1))
                                return false;
                            break;
                        }
                    case 'StartDateIsOlder':
                        {
                            if (athoc.iws.scenario.schedule.isValidDate(param1))
                                //start date should not be older date from today
                                if ((moment(param1, $.vpsDateFormat.toUpperCase()).toDate().toDateString() != ($.vpsTimeZone.CurrentVPSDate).toDateString()) && (moment(param1, $.vpsDateFormat.toUpperCase()).toDate().getTime() - (new Date(($.vpsTimeZone.CurrentVPSDate).toDateString()).getTime()) < 0))
                                    //iws-12152(issue#1)
                                    //ignore, if already saved start date is not changed
                                    if (athoc.iws.scenario.schedule.tempRecur_StartDate != param1)
                                        return false;
                            break;
                        }
                    case 'StartDateVsEndDate':
                        {
                            if (athoc.iws.scenario.schedule.isValidDate(param1) && athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndRadiogroup != undefined && athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndRadiogroup() == 3
                                && athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEnddateInput != undefined)
                                //Start date should not be grater date from End date
                                if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEnddateInput() != '') {
                                    if (moment(param1, $.vpsDateFormat.toUpperCase()).toDate() > moment(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEnddateInput(), $.vpsDateFormat.toUpperCase()).toDate())
                                        return false;
                                }
                            break;
                        }
                    case 'StartDate10Years':
                        {
                            if (athoc.iws.scenario.schedule.isValidDate(param1))
                                //start date should not be 10 years from today
                                if (Math.abs((moment(param1, $.vpsDateFormat.toUpperCase()).toDate().getTime() - new Date(($.vpsTimeZone.CurrentVPSDate).toDateString()).getTime()) / (24 * 60 * 60 * 1000)) > 3650)
                                    return false;
                            break;
                        }
                    case 'EndDate':
                        {
                            if (!athoc.iws.scenario.schedule.isValidDate(param1))
                                return false;
                            break;
                        }
                    case 'EndDateIsOlder':
                        {
                            if (athoc.iws.scenario.schedule.isValidDate(param1))
                                //End date should not be older date from today
                                if ((moment(param1, $.vpsDateFormat.toUpperCase()).toDate().toDateString() != ($.vpsTimeZone.CurrentVPSDate).toDateString()) && (moment(param1, $.vpsDateFormat.toUpperCase()).toDate().getTime() - (new Date(($.vpsTimeZone.CurrentVPSDate).toDateString()).getTime()) < 0))
                                    return false;
                            break;
                        }
                    case 'EndDateVsStartDate':
                        {
                            if (athoc.iws.scenario.schedule.isValidDate(param1) && athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput != undefined)
                                //End date should not be older date from start date
                                if (moment(param1, $.vpsDateFormat.toUpperCase()).toDate() < moment(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput(), $.vpsDateFormat.toUpperCase()).toDate())
                                    return false;
                            break;
                        }
                    case 'EndDate10Years':
                        {
                            if (athoc.iws.scenario.schedule.isValidDate(param1))
                                //End Date should be greater than or equal to Start date
                                if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndRadiogroup != undefined && athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceEndRadiogroup() == 3)
                                    if (moment(param1, $.vpsDateFormat.toUpperCase()).toDate() < moment(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceStartDateInput(), $.vpsDateFormat.toUpperCase()).toDate())
                                        return false;
                            break;
                        }
                    case 'WeekName':
                        {
                            //Week days check boxes
                            if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio() == 8 && athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceWeekly().length < 1)
                                return false;
                            break;
                        }
                    case 'DaysPerMonth':
                        {
                            if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio() == 64 && athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceYearlyModeRadiogroup() == 64) {
                                switch (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceYearlyAbsoluteMonthSelect()) {
                                    case 2:
                                        if (param1 > 29)
                                            return false;
                                        break;
                                    case 1:
                                    case 3:
                                    case 5:
                                    case 7:
                                    case 8:
                                    case 10:
                                    case 12:
                                        if (param1 > 31)
                                            return false;
                                        break;
                                    case 4:
                                    case 6:
                                    case 9:
                                    case 11:
                                        if (param1 > 30)
                                            return false;
                                        break;
                                }
                                break;
                            }

                            break;
                        }

                }
                return true;
            },
            isScheduleReady: function () {
                if (athoc.iws.scenario.schedule.isValid()) {
                    athoc.iws.scenario.schedule.isReadyToPublish = true;
                    athoc.iws.scenario.schedule.isInErrorState = false;
                    athoc.iws.publishing.SetSectionStatus("#scheduleStatus", "ready");


                } else {
                    athoc.iws.scenario.schedule.isReadyToPublish = false;
                    athoc.iws.scenario.schedule.isInErrorState = true;
                    athoc.iws.publishing.SetSectionStatus("#scheduleStatus", "notReady");

                }
            },
            isActiveRecurrence: function (isReady, isActiveError, isChanged) {
                isActiveError = athoc.iws.scenario.schedule.IsActiveError == undefined ? false : athoc.iws.scenario.schedule.IsActiveError;
                if (!isActiveError) {
                    if (!isReady) {
                        if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceType != undefined && athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceType() == "1" && isChanged) {
                            athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceType("0");
                        }
                        $("#rdSetAtPublish").prop("disabled", true);
                    } else {

                        if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceType != undefined && athoc.iws.scenario.schedule.scheduleRecurrenceType != undefined && athoc.iws.scenario.schedule.scheduleRecurrenceType == "1" && athoc.iws.scenario.schedule.IsScheduleChanged && isChanged) {
                            athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceType("1");
                        }
                        $("#rdSetAtPublish").prop("disabled", false);
                    }
                }

            },
            //setup validation
            getValidation: function () {
                var validationMapping = {
                    ScheduleDurationInput: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                required: { message: athoc.iws.scenario.resources.Scenario_Schedule_Err_Duration },
                                maxLength: { params: 7, message: athoc.iws.scenario.resources.Scenario_Schedule_Err_MaxLength.format('7') },
                                pattern: {
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_OnlyNumerics,
                                    params: "^[0-9]+$"
                                },
                                validation: {
                                    validator: athoc.iws.scenario.schedule.validDayArrange,
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_ValidDuration_Years.format('10'),
                                    params: [this.value, "Duration", 2]
                                }
                            });
                        }
                    },
                    ScheduleRecurrenceDailyFrequencyInput: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                maxLength: { params: 3, message: athoc.iws.scenario.resources.Scenario_Schedule_Err_MaxLength.format('3') },
                                pattern: {
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_OnlyNumerics,
                                    params: "^[0-9]+$"
                                },
                                validation: {
                                    validator: athoc.iws.scenario.schedule.validDayArrange,
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_ValidNumberBetween.format(1, 365),
                                    params: [this.value, "Days", 2]
                                }
                            });
                        }
                    },
                    ScheduleRecurrenceWeeklyFrequencyInput: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                maxLength: { params: 3, message: athoc.iws.scenario.resources.Scenario_Schedule_Err_MaxLength.format('3') },
                                pattern: {
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_OnlyNumerics,
                                    params: "^[0-9]+$"
                                },
                                validation: {
                                    validator: athoc.iws.scenario.schedule.validDayArrange,
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_ValidNumberBetween.format(1, 52),
                                    params: [this.value, "Weeks", 2]
                                }
                            });
                        }
                    },
                    ScheduleRecurrenceRadio: {
                        create: function (options) {
                            return ko.observable("").extend({
                                validation: {
                                    validator: athoc.iws.scenario.schedule.validDayArrange,
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_AtleastOneDay,
                                    params: [3, "WeekName", 2]
                                }
                            });
                        }
                    },
                    ScheduleRecurrenceMonthlyFrequencyInput: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                maxLength: { params: 2, message: athoc.iws.scenario.resources.Scenario_Schedule_Err_MaxLength.format('2') },
                                pattern: {
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_OnlyNumerics,
                                    params: "^[0-9]+$"
                                },
                                validation: {
                                    validator: athoc.iws.scenario.schedule.validDayArrange,
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_ValidNumberBetween.format(1, 12),
                                    params: [this.value, "Months", 2]
                                }
                            });
                        }
                    },
                    ScheduleRecurrenceYearlyAbsoluteDayInput: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                maxLength: { params: 2, message: athoc.iws.scenario.resources.Scenario_Schedule_Err_MaxLength.format('2') },
                                pattern: {
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_OnlyNumerics,
                                    params: "^[0-9]+$"
                                },
                                validation: {
                                    validator: athoc.iws.scenario.schedule.validDayArrange,
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_DayMonth_NotValid,
                                    params: [this.value, 'DaysPerMonth', 2]
                                }
                            });
                        }
                    },
                    ScheduleRecurrenceEndCountInput: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                maxLength: { params: 7, message: athoc.iws.scenario.resources.Scenario_Schedule_Err_MaxLength.format('7') },
                                pattern: {
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_OnlyNumerics,
                                    params: "^[0-9]+$"
                                },
                                min: { params: 1, message: athoc.iws.scenario.resources.Scenario_Schedule_Err_NumberLessThanOne },
                                validation: {
                                    validator: athoc.iws.scenario.schedule.validDayArrange,
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_RecurrenceDuration_Years.format(10),
                                    params: [this.value, 'Recurrence', 2]
                                }
                            });
                        }
                    },
                    ScheduleRecurrenceStartDateInput: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                validation: [{
                                    validator: athoc.iws.scenario.schedule.validDayArrange,
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_NotValidDate,
                                    params: [this.value, 'StartDate', 2]
                                }, {
                                    validator: athoc.iws.scenario.schedule.validDayArrange,
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_StartDate_LessThan_CurrDate,
                                    params: [this.value, 'StartDateIsOlder', 2]
                                }, {
                                    validator: athoc.iws.scenario.schedule.validDayArrange,
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_StartDate_MoreThan_EndDate,
                                    params: [this.value, 'StartDateVsEndDate', 2]
                                }, {
                                    validator: athoc.iws.scenario.schedule.validDayArrange,
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_StartDate_Exceed_Years.format(10),
                                    params: [this.value, 'StartDate10Years', 2]
                                }
                                ]
                            });
                        }
                    },

                    ScheduleRecurrenceEnddateInput: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                validation: [{
                                    validator: athoc.iws.scenario.schedule.validDayArrange,
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_NotValidDate,
                                    params: [this.value, 'EndDate', 2]
                                }, {
                                    validator: athoc.iws.scenario.schedule.validDayArrange,
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_EndDate_LessThan_CurrDate,
                                    params: [this.value, 'EndDateIsOlder', 2]
                                }, {
                                    validator: athoc.iws.scenario.schedule.validDayArrange,
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_EndDate_LessThan_StartDate,
                                    params: [this.value, 'EndDateVsStartDate', 2]
                                }, {
                                    validator: athoc.iws.scenario.schedule.validDayArrange,
                                    message: athoc.iws.scenario.resources.Scenario_Schedule_Err_EndDate_Exceed_Years.format(10),
                                    params: [this.value, 'EndDate10Years', 2]
                                }
                                ]
                            });
                        }
                    },

                };

                return validationMapping;
            },

            //this method will be called when data is required for updating
            getModel: function () {
                //check if schedule feature is enabled
                if (!athoc.iws.publishing.settings.IsSchedulingSupported)
                    return null;
                return ko.mapping.toJS(athoc.iws.scenario.schedule.viewModel.scenarioSchedule);
            },

            toggleScheduleSection: function () {
                if (!athoc.iws.publishing.settings.IsSchedulingSupported)
                    return;
                if (!athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleActivateRecurrenceCheck()) {
                    $("#RecurrencePattern").css("display", "none");
                    $("#RecurrencePeriod").css("display", "none");

                    $("#RecurrenceDaily").css("display", "none");
                    $("#RecurrenceWeekly").css("display", "none");
                    $("#RecurrenceMonthly").css("display", "none");
                    $("#RecurrenceYearly").css("display", "none");
                    switch (parseInt(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio())) {
                        case 4:
                            $("#RecurrenceDaily").css("display", "");
                            break;
                        case 8:
                            $("#RecurrenceWeekly").css("display", "");
                            break;
                        case 16:
                            $("#RecurrenceMonthly").css("display", "");
                            break;
                        case 64:
                            $("#RecurrenceYearly").css("display", "");
                            break;
                        default:
                            $("#RecurrenceDaily").css("display", "");
                            break;
                    }

                } else {
                    switch (parseInt(athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleRecurrenceRadio())) {
                        case 4:
                            $("#RecurrenceWeekly").css("display", "none");
                            $("#RecurrenceMonthly").css("display", "none");
                            $("#RecurrenceYearly").css("display", "none");
                            $("#RecurrenceDaily").css("display", "");
                            break;
                        case 8:
                            $("#RecurrenceMonthly").css("display", "none");
                            $("#RecurrenceYearly").css("display", "none");
                            $("#RecurrenceDaily").css("display", "none");
                            $("#RecurrenceWeekly").css("display", "");
                            break;
                        case 16:
                            $("#RecurrenceWeekly").css("display", "none");
                            $("#RecurrenceYearly").css("display", "none");
                            $("#RecurrenceDaily").css("display", "none");
                            $("#RecurrenceMonthly").css("display", "");
                            break;
                        case 64:
                            $("#RecurrenceWeekly").css("display", "none");
                            $("#RecurrenceMonthly").css("display", "none");
                            $("#RecurrenceDaily").css("display", "none");
                            $("#RecurrenceYearly").css("display", "");
                            break;
                        default:
                            $("#RecurrenceWeekly").css("display", "none");
                            $("#RecurrenceMonthly").css("display", "none");
                            $("#RecurrenceYearly").css("display", "none");
                            $("#RecurrenceDaily").css("display", "");
                            break;
                    }
                }

            },
            isActiveRecurrenceEnabled: function () {
                if (!athoc.iws.publishing.settings.IsSchedulingSupported)
                    return false;
                if (athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleActivateRecurrenceCheck != undefined) {
                    athoc.iws.scenario.schedule.IsActiveRecurrence = athoc.iws.scenario.schedule.viewModel.scenarioSchedule.ScheduleActivateRecurrenceCheck();
                    return athoc.iws.scenario.schedule.IsActiveRecurrence;
                }
                else
                    return false;
            },
            isTUnMSDevicesReady: function () {
                var bTU = false;
                var bTUEmpty = false;
                var bMD = athoc.iws.publishing.massdevices.isReadyToPublish;
                var bFinalResult = false;

                //Empty status
                bTUEmpty = (!athoc.iws.publishing.targetUsers.isInErrorState && !athoc.iws.publishing.targetUsers.isReadyToPublish);
                //TU Ready to publish or Empty status
                if (!athoc.iws.publishing.targetUsers.isInErrorState && athoc.iws.publishing.targetUsers.isReadyToPublish)
                    bTU = true;

                //TU Ready to publish or Empty status  and MD are ready                
                if ((bTU && bMD) || (bTU && !bMD) || (bTUEmpty && bMD))
                    bFinalResult = true;


                return bFinalResult;
            },
            handleError: function (e) {
                if (e != undefined && e.status == 401) {
                    window.onbeforeunload = null;
                    window.location = window.location;
                } else {
                    $('#listMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                }
            },

        };
    }();
}