﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.alert = athoc.iws.alert || {};

if (athoc.iws.alert) {
    // Enable/disable controls in all browsers
    ko.bindingHandlers['CustomEnable'] = (function () {
        return {
            init: function (element, valueAccessor) {
                var $element = $(element);
                var value = ko.utils.unwrapObservable(valueAccessor());
                if (value)
                    $('[data-id=' + ($element[0].id) + ']').removeClass("disabled");
                else
                    $('[data-id=' + ($element[0].id) + ']').addClass("disabled"); 

            },
            update: function (element, valueAccessor) {
                var value = ko.utils.unwrapObservable(valueAccessor());
                var $element = $(element);
                if (value)
                    $('[data-id=' + ($element[0].id) + ']').removeClass("disabled");
                else
                    $('[data-id=' + ($element[0].id) + ']').addClass("disabled");
            }
        };
    }());
    athoc.iws.alert.schedule = function () {
        return {
            isReadyToPublish: false,
            isInErrorState: false,
            AMPMformat: false,
            viewModel: {
                alertschedule: ko.observableArray(),
                timeformart: ko.observableArray(),
                Visible: ko.observable(false),
                Collapsed: ko.observable(false),
                Readonly: ko.observable(false),
                Mode: "",
                isLiveAlert: ko.observable(false),
                isLiveorEnded: ko.observable(true),
                isEndedAert: ko.observable(false),
                isFillCountEnabled: ko.observable(false),
            },


            load: function () {

            },

            GetLocalizedDurationUnit: function(){
                switch (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleDurationInputUnit()) {
                case 'Minute':
                    return $.htmlDecode(athoc.iws.publishing.fillcount.resources.TimeFormat_Minutes);
                case 'Hour':
                    return $.htmlDecode(athoc.iws.publishing.fillcount.resources.TimeFormat_Hours);
                case 'Day':
                    return $.htmlDecode(athoc.iws.publishing.fillcount.resources.TimeFormat_Days);
                }

                return athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleDurationInputUnit();
            },

        initiatePickers: function () {

                var AMPMformat = $.vpsDateTimeFormat.indexOf('tt') > 0 ? true : false;
                //var datetimeformat = AMPMformat ? athoc.iws.alert.schedule.getVPSTimeFormat('dateformat') : athoc.iws.alert.schedule.getVPSTimeFormat('dateformat').replace("HH:", "hh:");
                var momentdatetimeformat = athoc.iws.alert.schedule.getVPSTimeFormat('momentformat');

                if (!athoc.iws.alert.schedule.viewModel.isLiveAlert()) {
                    $("#ddlAlertScheduleDurationHours").selectpicker();

                    $('#publishing-alert-edit').find('#istartDateValue').datetimepicker({
                        pick12HourFormat: AMPMformat,
                        pickSeconds: ($.vpsDateTimeFormat.indexOf('ss') > 0 ? true : false),
                        language: $.culture,
                         startDate: new Date(moment($.vpsTimeZone.CurrentVPSDate.toLocaleString(), "MM/DD/YYYY")),
                         format: $.vpsDateTimeFormat
                    }).on('changeDate', function (ev) {
                        var newDate = null;
                        if (ev.localDate != null)
                            newDate = moment(ev.localDate).format(momentdatetimeformat);
                        athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartDateInput(newDate);
                    });


                } else {

                    $('#alert-detail').find('#iendDateValue').datetimepicker({
                        pick12HourFormat: AMPMformat,
                        language: $.culture,
                        pickSeconds: ($.vpsDateTimeFormat.indexOf('ss') > 0 ? true : false),
                        startDate: new Date(moment($.vpsTimeZone.CurrentVPSDate.toLocaleString(), "MM/DD/YYYY")),
                        format: $.vpsDateTimeFormat
                    }).on('changeDate', function (ev) {
                        if (ev.localDate == null)
                            return;
                        var newDate = moment(ev.localDate).format(momentdatetimeformat);
                        athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishEndDateInput(newDate);
                    });
                    $("#ddlviewAlertScheduleHr").selectpicker();
                    $("#ddlAlertScheduleMin").selectpicker();
                    $("#ddlAlertScheduleMer").selectpicker();

                }

                $("#publishing-alert-view .icon-calendar").click(function () { $('html,body').animate({ scrollTop: 9999 }, 'slow'); $('.bootstrap-datetimepicker-widget').css("z-index", "6"); });
                $("#publishing-alert-edit .icon-calendar").click(function () { $('html,body').animate({ scrollTop: 9999 }, 'slow'); $('.bootstrap-datetimepicker-widget').css("z-index", "6"); });
            },
            bindReadOnlyView: function (alertscheduledata, targetDiv) {

                if ((athoc.iws.publishing.detail.viewModel.AlertStatus == "Live" || athoc.iws.publishing.detail.viewModel.AlertStatus == "Ended") && (athoc.iws.alert.source != "rbt")) {
                    athoc.iws.alert.schedule.viewModel.isLiveorEnded(true);

                    if (athoc.iws.publishing.detail.viewModel.AlertStatus == "Live")
                        athoc.iws.alert.schedule.viewModel.isLiveAlert(true);

                    if (athoc.iws.publishing.detail.viewModel.AlertStatus == "Ended")
                        athoc.iws.alert.schedule.viewModel.isEndedAert(true);
                } else {
                    athoc.iws.alert.schedule.viewModel.isLiveorEnded(false);
                    athoc.iws.alert.schedule.viewModel.isLiveAlert(false);
                    athoc.iws.alert.schedule.viewModel.isEndedAert(false);
                }

                athoc.iws.alert.schedule.setIsFillCountEnabled();

                athoc.iws.alert.schedule.viewModel.alertschedule = ko.mapping.fromJS(alertscheduledata, athoc.iws.alert.schedule.getValidation());

                ko.cleanNode($(targetDiv).find("#publishing-alert-view").get(0));
                athoc.iws.alert.schedule.viewModel.Mode = (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertPublishStartModeSettime() == "ASAP" ? "ASAP" : "SET TIME");
                ko.applyBindings(athoc.iws.alert.schedule.viewModel, $(targetDiv).find("#publishing-alert-view").get(0));


            },
            bind: function (data, alertscheduledata) {

                //check if schedule feature is enabled
                if (!athoc.iws.publishing.settings.IsSchedulingSupported)
                    return;

                if (athoc.iws.alert && athoc.iws.alert.action && athoc.iws.alert.action == 'rbt')
                    alertscheduledata.ScheduleAlertPublishStartModeSettime = "ASAP";

                athoc.iws.alert.schedule.viewModel.Visible(data.Advanced.Visible);
                athoc.iws.alert.schedule.viewModel.Collapsed(data.Advanced.Collapsed);
                athoc.iws.alert.schedule.viewModel.Readonly(data.Advanced.Readonly);

                athoc.iws.alert.schedule.viewModel.alertschedule = ko.mapping.fromJS(alertscheduledata, athoc.iws.alert.schedule.getValidation());
                athoc.iws.alert.schedule.viewModel.timeformart(alertscheduledata.TimeFormat);

                //If Status is live ko binding based on the target div.
                //Hiding the status span
                var status = ["Publishing", "Live", "Ended"];
                if ((status.indexOf(athoc.iws.publishing.detail.viewModel.AlertStatus) > -1) && (athoc.iws.alert.source != "rbt")) {
                    athoc.iws.alert.schedule.viewModel.isLiveorEnded(true);

                    if (athoc.iws.publishing.detail.viewModel.AlertStatus == "Live")
                        athoc.iws.alert.schedule.viewModel.isLiveAlert(true);

                    if (athoc.iws.publishing.detail.viewModel.AlertStatus == "Ended")
                        athoc.iws.alert.schedule.viewModel.isEndedAert(true);

                    $("#alert-detail").find(".bootstrap-select").remove();
                    if (athoc.iws.publishing.fillcountfillCountSummary != null)
                        athoc.iws.alert.schedule.viewModel.isFillCountEnabled(true);
                    ko.cleanNode($("#alert-detail").get(0));
                    ko.applyBindings(athoc.iws.alert.schedule.viewModel, $("#alert-detail").get(0));
                    athoc.iws.alert.schedule.initiatePickers();
                }
                else {
                    $("#publishing-alert-edit").find(".bootstrap-select").remove(); 
                    if (athoc.iws.publishing.fillcountfillCountSummary != null)
                        athoc.iws.alert.schedule.viewModel.isFillCountEnabled(true);
                    if (athoc.iws.publishing.fillcountfillCountSummary != null)
                        athoc.iws.alert.schedule.viewModel.isFillCountEnabled(true);
                    ko.cleanNode($("#publishing-alert-edit").get(0));
                    ko.applyBindings(athoc.iws.alert.schedule.viewModel, $("#publishing-alert-edit").get(0));
                    athoc.iws.alert.schedule.initiatePickers();
                    if (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertPublishStartModeSettime() == "ASAP")
                    athoc.iws.alert.schedule.enableDateforSetTime(athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertPublishStartModeSettime());
                }
                if (athoc.iws.publishing.fillcountfillCountSummary != null)
                    athoc.iws.alert.schedule.viewModel.isFillCountEnabled(true);

                athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleDurationInput.subscribe(function (newValue) {
                    athoc.iws.alert.schedule.isAlertScheduleReady();
                });

                athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertPublishStartModeSettime.subscribe(function (newValue) {
                    athoc.iws.alert.schedule.enableDateforSetTime(newValue);
                    athoc.iws.alert.schedule.isAlertScheduleReady();
                });
                athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartDateInput.subscribe(function (newValue) {
                    athoc.iws.alert.schedule.isAlertScheduleReady();
                });
                athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartDateInput.extend({ notify: 'always' });
                athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartdateHourSelect.subscribe(function (newValue) {
                    athoc.iws.alert.schedule.isAlertScheduleReady();
                });
                athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartdateMinuteSelect.subscribe(function (newValue) {
                    athoc.iws.alert.schedule.isAlertScheduleReady();
                });
                athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartdateAmpmSelect.subscribe(function (newValue) {
                    athoc.iws.alert.schedule.isAlertScheduleReady();
                });

                athoc.iws.alert.schedule.isAlertScheduleReady();

            },
            setIsFillCountEnabled: function () {
                var fillCount = ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.FillCount);
                athoc.iws.alert.schedule.viewModel.isFillCountEnabled((fillCount == null || fillCount.FillCount == 0) ? false : true);
            },
            toggleCollpase: function () {
                targetDiv = $("#publishing-alert-edit");

                ////show bucket expanded by default
                if (athoc.iws.alert.schedule.viewModel.Collapsed()) {
                    targetDiv.find(".bucket-toggle .row").hide();
                    targetDiv.find(".bucket-toggle .expand-arrow-open").hide();
                    targetDiv.find(".bucket-toggle .expand-arrow-closed").show();
                }
                else {
                    targetDiv.find(".bucket-toggle .row").show();
                    targetDiv.find(".bucket-toggle .expand-arrow-open").show();
                    targetDiv.find(".bucket-toggle .expand-arrow-closed").hide();
                }
            },
            validDateTime: function (checkStartDate) {
                var vDate;
                if (checkStartDate)
                    vDate = athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartDateInput();// + " " + athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartdateHourSelect() + ":" + athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartdateMinuteSelect() + " " + athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartdateAmpmSelect();
                else
                    vDate = athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishEndDateInput();// + " " + athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishEnddateHourSelect() + ":" + athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishEnddateMinuteSelect() + " " + athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishEnddateAmpmSelect();
               
                return (new Date(moment(vDate,athoc.iws.alert.schedule.getVPSTimeFormat('momentformat'))).getTime() - athoc.iws.alert.schedule.formatDate($.vpsTimeZone.CurrentVPSDate).getTime()) >= 0;

            },
            formatDate: function (currentVPSDate)
            {
                if ($.vpsDateTimeFormat.indexOf('ss') < 0) {
                    currentVPSDate.setSeconds(00);
                }
                return currentVPSDate;
            },
            isValid: function () {

                if (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleDurationInput() == "")
                    return false;
                if ($.isNumeric(athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleDurationInput()) == false)
                    return false;
                if (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleDurationInput() < 1)
                    return false;

                if (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertPublishStartModeSettime() == "ASAP")
                    return true;
                else {
                    if (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartDateInput() == "")
                        return false;
                    if (!athoc.iws.alert.schedule.isValidDate(athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartDateInput()))
                        return false;
                    //start date should not be older date from today                        


                    if (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartDateInput != undefined && !athoc.iws.alert.schedule.viewModel.isLiveorEnded()) {
                        if (!athoc.iws.alert.schedule.validDateTime(true)) {
                            $("#StartDateErrorMsg").html(athoc.iws.publishing.resources.Publishing_Schedule_Err_AlertStartDate_LessThan_CurrDate);
                            $("#StartDateErrorMsg").show();
                            athoc.iws.alert.schedule.isInErrorState = true;
                            return false;
                        }
                        else
                            $("#StartDateErrorMsg").hide();
                    }

                }
                return true;

            },
          

            isValidDate: function (val) {
                var isValid = true;
                try {
                    isValid = moment(val, $.vpsDateFormat.toUpperCase()).isValid();
                }
                catch (error) {
                    isValid = false;
                }

                return isValid;
            },
            //this method will set ready state
            isAlertScheduleReady: function () {
                if (athoc.iws.alert.schedule.isValid()) {
                    athoc.iws.alert.schedule.isReadyToPublish = true;
                    athoc.iws.alert.schedule.isInErrorState = false;
                    athoc.iws.publishing.SetSectionStatus("#alertscheduleStatus", "ready");
                } else {
                    athoc.iws.alert.schedule.isReadyToPublish = false;
                    athoc.iws.alert.schedule.isInErrorState = true;
                    athoc.iws.publishing.SetSectionStatus("#alertscheduleStatus", "notReady");
                }
            },
            enableDateforSetTime: function (newValue) {
                if (newValue == "ASAP") {                    
                    $("#istartDateValue").datetimepicker("disable");

                } else {                    
                    $("#istartDateValue").datetimepicker("enable");
                    //$("input#istartDateValue").prop("disabled", true);
                }
            },
            //this method will be called when data is required for updating
            getModel: function () {
                //check if schedule feature is enabled
                if (!athoc.iws.publishing.settings.IsSchedulingSupported)
                    return null;

                return ko.mapping.toJS(athoc.iws.alert.schedule.viewModel.alertschedule);
            },
            //this method will pad chars to left of the string
            padLeft: function (value, length, char) {
                return new Array(length - (value + '').length + 1).join(char) + value;
            },
            handleError: function (e) {
                if (e != undefined && e.status == 401) {
                    window.onbeforeunload = null;
                    window.location = window.location;
                } else {
                    $('#listMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: e.errorThrown }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                }
            },
            validDayArrange: function (param1, param2, param3) {
                if (param2[1].indexOf('StartDate') < 0 && param2[1].indexOf('EndDate') < 0) {
                    if ($.isNumeric(param1) == false)
                        return false;
                    if (param1 < 1)
                        return false;
                }
                switch (param2[1]) {
                    case 'Duration':
                        {
                            switch (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleDurationInputUnit()) {
                                case 'Minute':
                                    if (param1 > 5256000)
                                        return false;
                                    break;
                                case 'Hour':
                                    if (param1 > 87600)
                                        return false;
                                    break;
                                case 'Day':
                                    if (param1 > 3650)
                                        return false;
                                    break;
                            }
                            break;
                        }

                    case 'AlertEndDate':
                        {
                            //iws#12687
                            if (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishEndDateInput != undefined && athoc.iws.alert.schedule.viewModel.isLiveAlert()) {
                                //End date should not be older date from today
                                //alert(athoc.iws.alert.schedule.validDateTime(false));
                                if (!athoc.iws.alert.schedule.validDateTime(false)) {
                                    athoc.iws.alert.schedule.isInErrorState = true;
                                    return false;
                                }
                            }
                            break;
                        }

                    case 'StartDate':
                        {

                            if (athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertpublishStartDateInput != undefined && !athoc.iws.alert.schedule.viewModel.isLiveorEnded() && athoc.iws.alert.schedule.viewModel.alertschedule.ScheduleAlertPublishStartModeSettime() != "ASAP") {
                                if (!athoc.iws.alert.schedule.validDateTime(true)) {
                                    athoc.iws.alert.schedule.isInErrorState = true;
                                    $("#StartDateErrorMsg").html(athoc.iws.publishing.resources.Publishing_Schedule_Err_AlertStartDate_LessThan_CurrDate);
                                    $("#StartDateErrorMsg").show();
                                    return false;
                                }
                                else
                                    $("#StartDateErrorMsg").hide();
                            }
                            break;
                        }

                }
                athoc.iws.alert.schedule.isInErrorState = false;
                return true;
            },


            getVPSTimeFormat: function (formatType) {
                var timeFormat = $.trim($.vpsDateTimeFormat.replace($.vpsDateFormat, "").toLowerCase().replace("tt", "PP"));
                var meridianFormat = $.vpsDateTimeFormat.indexOf('tt') > 0 ? " A" : "";
                var secondsIncluded = $.vpsDateTimeFormat.indexOf('ss') > 0 ? ":ss" : "";
                var dateFormat;
                switch (formatType) {
                    case "dateformat":
                        dateFormat = $.vpsDateFormat;
                            timeFormat = $.trim($.vpsDateTimeFormat.replace($.vpsDateFormat, "").toLowerCase().replace("tt", "PP").replace("hh", "HH"));
                        break;
                    case "momentformat":
                        dateFormat = $.vpsDateFormat.toUpperCase();
                        if (meridianFormat == "")
                            timeFormat = "HH:mm" + secondsIncluded;
                        else
                            timeFormat = "hh:mm" + secondsIncluded + meridianFormat;

                        break;
                }


                return dateFormat + ' ' + timeFormat;
            },

            //setup validation
            getValidation: function () {
                var validationMapping = {
                    ScheduleAlertpublishEndDateInput: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                required: { message: athoc.iws.publishing.resources.Publishing_Schedule_Err_AlertEndDate_Require },
                                validation: {
                                    validator: athoc.iws.alert.schedule.validDayArrange,
                                    message: athoc.iws.publishing.resources.Publishing_Schedule_Err_AlertEndDate_LessThan_CurrDate,
                                    params: [this.value, "AlertEndDate", 2]
                                }
                            });
                        }
                    },
                   

                    ScheduleAlertPublishStartModeSettime: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                validation: {
                                    validator: athoc.iws.alert.schedule.validDayArrange,
                                    message: athoc.iws.publishing.resources.Publishing_Schedule_Err_AlertStartDate_LessThan_CurrDate,
                                    params: [this.value, "StartDate", 2]
                                }
                            });
                        }
                    },

                    ScheduleDurationInput: {
                        create: function (options) {
                            return ko.observable(options.data).extend({
                                required: { message: athoc.iws.publishing.resources.Publishing_Schedule_Err_AlertDuration },
                                maxLength: { params: 7, message: athoc.iws.publishing.resources.Publishing_Schedule_Err_MaxLength.format(7) },
                                pattern: {
                                    message: athoc.iws.publishing.resources.Publishing_Schedule_Err_OnlyNumerics,
                                    params: "^[0-9]+$"
                                },
                                validation: {
                                    validator: athoc.iws.alert.schedule.validDayArrange,
                                    message: athoc.iws.publishing.resources.Publishing_Schedule_Err_ValidDuration_Years.format('10'),
                                    params: [this.value, "Duration", 2]
                                }
                            });
                        }
                    },


                };

                return validationMapping;
            },
        };
    }();
}