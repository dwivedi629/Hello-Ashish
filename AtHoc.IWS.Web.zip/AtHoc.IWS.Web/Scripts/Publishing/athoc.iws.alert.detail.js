﻿/// <reference path="athoc.iws.alert.detail.js" />
var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.alert = athoc.iws.alert || {};

if (athoc.iws.alert) {
    athoc.iws.alert.detail = function () {
        return {
            parameters: null,
            init: function (args) {
                this.parameters = args;
            },

            //create alert
            createAlertFromScenario: function (id, show) {
                $(".publishing-detail").hide();
                $('#messagePanel').messagesPanel('reset');

                var loadUrl = athoc.iws.alert.parameters.urls.CreateAlertFromScenarioUrl + "?id=" + id;
                athoc.iws.publishing.detail.loadPublishingModel(loadUrl, true,id, true);

                //if id is 0 that means we are creating a blank alert.
                athoc.iws.publishing.targetUsers.Parameters.context = id == 0 ? "Alert" : "Scenario";

                //athoc.iws.publishing.targetUsers.load(id);
            },

            //create alert
            createAlertFromRbt: function (id, rbtdetails, show) {
                $(".publishing-detail").hide();
                $('#messagePanel').messagesPanel('reset');
                var loadUrl = athoc.iws.publishing.urls.CreateAlertFromRbtUrl + "?id=" + rbtdetails.AlertId + "&recipientType=" + rbtdetails.EntityFilterId + "&deviceId=" + rbtdetails.DeviceId + "&fillCount=" + rbtdetails.FillCountType + "&source=" + rbtdetails.Source + "&accEventId=" + rbtdetails.AccountabilityEventId;

                athoc.iws.publishing.targetUsers.Parameters.context = id == 0 ? "Alert" : "Scenario";
                athoc.iws.publishing.detail.loadPublishingModel(loadUrl, true,id);

                //if id is 0 that means we are creating a blank alert.
               

               
            },


            //edit alert
            editAlert: function (id, show) {
                $(".publishing-detail").hide();
                $("#btn_review_and_publish").hide();
                $('#messagePanel').messagesPanel('reset');
                //IWS-14925 - hide the buttons while loading
                $("#btn_test_alert").hide();                
                $("#btn_detail_save").hide();

                var loadUrl = athoc.iws.alert.parameters.urls.GetAlertDetailUrl + "?id=" + id;
                athoc.iws.publishing.detail.loadPublishingModel(loadUrl, true,id,true);
                //athoc.iws.publishing.targetUsers.load(id);
            },

            //view alert
            viewAlert: function (id, show) {
                $(".publishing-detail").hide();
                $('#messagePanel').messagesPanel('reset');

                var loadUrl = athoc.iws.alert.parameters.urls.GetAlertDetailUrl + "?id=" + id;
                athoc.iws.publishing.detail.loadPublishingModel(loadUrl, true, id, true);
            },

            //duplicate alert
            duplicateAlert: function (id) {
                $(".publishing-detail").hide();
                $('#messagePanel').messagesPanel('reset');

                var loadUrl = athoc.iws.alert.parameters.urls.DuplicateAlertUrl + "?id=" + id;
                athoc.iws.publishing.detail.loadPublishingModel(loadUrl, true,id, true);
                //athoc.iws.publishing.targetUsers.load(id);
                //reset Live/Ended Alerts flags when its duplicated 
                athoc.iws.alert.schedule.viewModel.isLiveAlert(false);                
                athoc.iws.alert.schedule.viewModel.isLiveorEnded(false);                
                athoc.iws.alert.schedule.viewModel.isEndedAert(false);
            },

            //save alert
            saveAlert: function () {
                athoc.iws.alert.detail.postAlert(athoc.iws.alert.parameters.urls.SaveAlertUrl);
                athoc.iws.alert.list.refreshOnLoad = true;
                return true;
            },

            //standby alert
            standbyAlert: function () {
                athoc.iws.alert.detail.postAlert(athoc.iws.alert.parameters.urls.StandbyAlertUrl, false);
                return true;
            },

            //review & publish
            reviewAndPublish: function () {
                $('#messagePanel').messagesPanel('reset');

                //check if is data valid
                var isValid = athoc.iws.publishing.content.isValid();

                if (!isValid) {
                    $('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: athoc.iws.alert.parameters.resources.Alert_Validation_SectionNotReady }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                    $('html,body').scrollTop(-200);
                    return false;
                }


                //try publishing only if ready
                if (!athoc.iws.publishing.detail.isReadyToPublish()) {
                    $('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: athoc.iws.alert.parameters.resources.Alert_Validation_NotReadyForPublish }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                    $('html,body').scrollTop(-200);
                    return false;
                }


                var massDeviceModel = athoc.iws.publishing.massdevices.getModel();
                var contentModel = athoc.iws.publishing.content.getModel();
                var placeholderModel = athoc.iws.publishing.content.getModel();


                var alertObj = {
                    EntityId: athoc.iws.publishing.detail.viewModel.EntityId,
                    ParentId: athoc.iws.publishing.detail.viewModel.ParentId,
                    Content: contentModel ,
                    TargetUsers: athoc.iws.publishing.targetUsers.getModel(),
                    TargetOrg: athoc.iws.publishing.targetOrg.getModel(),
                    AlertScheduleSettings: athoc.iws.alert.schedule.getModel(),
                    MassDevices: massDeviceModel == null ? [] : massDeviceModel.MassDevices,
                    MassDeviceGroupOptions: massDeviceModel == null ? [] : massDeviceModel.MassDeviceGroupOptions,
                    CustomPlaceHolders: placeholderModel,
                    AllPlaceHolderIds: athoc.iws.publishing.getPlaceholderList(),
                    //TargetingTree: athoc.iws.publishing.view.viewModel.TargetingTree(),
                    alertOrigin: athoc.iws.publishing.alertOrgin,
                    rbt: athoc.iws.publishing.rbt,
                    FillCount: athoc.iws.publishing.fillcount.getModel(),
                    EscalationAttributes:  athoc.iws.publishing.fillcount.viewModel.escalationAttributes()  ,
                    SequencingAttributes:  athoc.iws.publishing.fillcount.viewModel.phonesequencingAttributes(),
                };


               
                athoc.iws.publishing.view.ReviewAndPublish(alertObj);
                athoc.iws.publishing.view.OnCloseAfterPublish = function (id) {
                    if (athoc.iws.alert.source == 'publisher') {
                        window.location = '/athoc-iws/scenariomanager/scenariopublisher';
                    }
                    else if (athoc.iws.alert.source == 'home') {
                        window.location = '/athoc-iws';
                    }
                    else if (athoc.iws.alert.source == 'event') {
                        window.location = '/athoc-iws/EventManager';
                    }
                    else if (athoc.iws.alert.source == 'log') {
                        window.location = '/athoc-iws/EventManager/activitylog';
                    }

                    else {
                        athoc.iws.alert.list.viewAlertList(true);
                        $('#dialogReviewAndPublish').modal('hide');
                    }
                };
            },

            postAlert: function (postUrl, stayOnPage) {
                $('#messagePanel').messagesPanel('reset');
                //set the flat to reload
                //athoc.iws.alert.refreshList = true;

                //Check if all sections are valid
                var isValid = athoc.iws.publishing.content.isValid() && athoc.iws.publishing.content.isLocationMandatory(false);

                if (!isValid) {
                    $('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: athoc.iws.alert.parameters.resources.Alert_Validation_SectionNotReady }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                    $('html,body').scrollTop(-200);
                    return false;
                }

                athoc.iws.publishing.detail.setChanged(false);
                var massDeviceModel = athoc.iws.publishing.massdevices.getModel();
                //If content section is readonly need to get data from Publishing.View.viewModel.data.content
                var contentModel = athoc.iws.publishing.content.getModel() == undefined ?  ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.Content) :  athoc.iws.publishing.content.getModel();
                //Get updated data from each section in viewmodel
                var alertObj = {
                    EntityId: athoc.iws.publishing.detail.viewModel.EntityId,
                    ParentId: athoc.iws.publishing.detail.viewModel.ParentId,
                    Content: contentModel,
                    TargetUsers: athoc.iws.publishing.targetUsers.getModel(),
                    TargetOrg: athoc.iws.publishing.targetOrg.getModel(),
                    AlertScheduleSettings: athoc.iws.alert.schedule.getModel(),
                    MassDevices: massDeviceModel == null ? [] : massDeviceModel.MassDevices,
                    MassDeviceGroupOptions: massDeviceModel == null ? [] : massDeviceModel.MassDeviceGroupOptions,
                    AllPlaceHolderIds: athoc.iws.publishing.getPlaceholderList(),
                    CustomPlaceHolders: athoc.iws.alert.placeholder.getModel(),
                    AlertOrigin: athoc.iws.publishing.alertOrgin,
                    rbt: athoc.iws.publishing.rbt != null ? athoc.iws.publishing.rbt : null,
                    FillCount: athoc.iws.publishing.fillcount.getModel(),
                    IsReadyToPublish: athoc.iws.publishing.detail.isReadyToPublish(),
                };

                //Check Alert Duration while saving  Draft Alert, if empty set to default value
                if (alertObj.AlertScheduleSettings != null && ((postUrl == athoc.iws.alert.parameters.urls.StandbyAlertUrl || postUrl == athoc.iws.alert.parameters.urls.SaveAlertUrl) && alertObj.AlertScheduleSettings.ScheduleDurationInput == ""))
                    alertObj.AlertScheduleSettings.ScheduleDurationInput = "4";

                if (this.parameters.showOrganizations) {
                    alertObj.TargetOrg = athoc.iws.publishing.targetOrg.getModel();
                }

                //Send view model to server for saving
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();

                var dlAjaxOption =
                    {
                        url: postUrl,
                        contentType: false,
                        dataType: 'json',
                        type: 'POST',
                        data: JSON.stringify(alertObj)
                    };

                var ajaxSuccess = function (data) {
                    $.AjaxLoader.hideLoader();
                    if (data.Success) {
                        //IWS12606
                        //redirect to Sent Alerts screen when Alert status is not Draft or Standby
                        if (data.Data.AlertStatus != 'Draft' && data.Data.AlertStatus != 'Standby')
                        {
                            $('#messagePanel').messagesPanel({ messages: [{ Type: '8', Value: athoc.iws.alert.parameters.resources.Alert_SaveSuccess }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                            $('html,body').scrollTop(-200);

                            athoc.iws.publishing.createRequest('/athoc-iws/AlertManager/Index');
                            //redirectToExternalUrl('/athoc-iws/AlertManager/Index');
                            return true;
                        }
                        if (stayOnPage == undefined || stayOnPage) {
                            athoc.iws.publishing.detail.resetLoadedStatus();

                            athoc.iws.publishing.detail.bindModel(data, true);
                            $('#messagePanel').messagesPanel({ messages: [{ Type: '8', Value: athoc.iws.alert.parameters.resources.Alert_SaveSuccess }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                            $('html,body').scrollTop(-200);

                            //reset targeting selection
                            //athoc.iws.publishing.targetUsers.getTargetingSelection();
                            athoc.iws.publishing.targetUsers.load(athoc.iws.publishing.detail.viewModel.EntityId);


                        } else {
                            athoc.iws.publishing.targetUsers.Parameters.context = "Alert"; //reset context to Alert just in case you are coming from scenario publisher
                            athoc.iws.alert.list.viewAlertList(true);
                        }
                    } else {
                        $('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: data.Messages }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        $('html,body').scrollTop(-200);
                    }

                };

                var ajaxOptions = $.extend({}, AjaxUtility(null, ajaxSuccess).ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);

                return true;

            },
            TestAlert: function () {

                var replacementModels = null;
                var placeholders = null;
                if (athoc.iws.alert.placeholder) {
                    placeholders = athoc.iws.alert.placeholder.getModel();
                }
                var alertObj = {
                    EntityId: 0,
                    ParentId: 0,
                    Content: athoc.iws.publishing.content.getModel(),
                    TargetUsers: athoc.iws.publishing.targetUsers.getModel(),
                    AlertScheduleSettings: athoc.iws.alert.schedule.getModel(),
                    AlertOrigin: athoc.iws.publishing.alertOrgin,
                    rbt: athoc.iws.publishing.rbt
                };

                var replacementModels =
                    [{ GroupId: 0, FieldId: 'title', Value: alertObj.Content.Title, MinLength: 3, MaxLength: 100, Label: 'Title' },
                        { GroupId: 0, FieldId: 'body', Value: alertObj.Content.Body, MinLength: 0, MaxLength: 4000, Label: 'Body' }];

                if (alertObj.Content.ResponseOptionId == 0 && alertObj.Content.ResponseOptions.length) {
                    $.each(alertObj.Content.ResponseOptions, function (index, objOption) {
                        replacementModels.push({ GroupId: 0, FieldId: 'response-option-' + index, Value: objOption.ResponseText, MinLength: 1, MaxLength: 64, Label: 'Response Option ' + (index + 1) });
                    });
                }
                $('#alertMessagePanel').messagesPanel('reset');

                //Check if all sections are valid
                var isValid = athoc.iws.publishing.content.isValid();

                if (!isValid) {
                    $('#alertMessagePanel').messagesPanel({ messages: [{ Type: '4', Value: athoc.iws.alert.parameters.resources.Alert_Validation_SectionNotReady }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                    $('html,body').scrollTop(-200);
                    return false;
                }
                isValid = athoc.iws.alert.test.getModel().length > 0;
                if (!isValid) {
                    $('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: "At least ONE personal device should be selected." }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                    $('html,body').scrollTop(-200);
                    return false;
                }

                $('#btn_send_test_alert').prop("disabled", true);

                var model = {
                    PlaceholderReplacementModels: replacementModels,
                    SelectedPlaceHolders: placeholders,
                    DeviceGroupOptions: [],
                    DeviceGroupOptionsRawXML: []
                };

                var dlAjaxOption =
                {
                    url: "/athoc-iws/publishing/ReplacePlaceholders",
                    dataType: 'json',
                    type: 'POST',
                    data: JSON.stringify(model)
                };
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#TestAlert'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();
                var reqError = new Array();
                var ajaxSuccess = function (data) {

                    if (data.Success) {

                        //replace values into publishing model and show any validation errors
                        var vm = alertObj;
                        var isValid = true;
                        if (data.Model && data.Model.PlaceholderReplacementModels) {
                            $.each(data.Model.PlaceholderReplacementModels, function (index, objResponse) {
                                var field = objResponse.Label;
                                if (objResponse.GroupId == 0 && objResponse.FieldId == 'title') {
                                    vm.Content.Title=objResponse.Value;
                                } else if (objResponse.GroupId == 0 && objResponse.FieldId == 'body') {
                                    vm.Content.Body=objResponse.Value;
                                    if (objResponse.Value) {
                                        athoc.iws.publishing.view.viewModel.bodyWithLineBreak($.htmlEncode(objResponse.Value.trim()).replace(/(?:\r\n|\r|\n)/g, '<br />'));
                                    } else {
                                        athoc.iws.publishing.view.viewModel.bodyWithLineBreak('');
                                    }
                                } else if (objResponse.GroupId == 0 && objResponse.FieldId.lastIndexOf('response-option-', 0) === 0) {
                                    var id = objResponse.FieldId.split("-")[2];
                                    alertObj.Content.ResponseOptions[id].ResponseText=objResponse.Value;
                                } else if (objResponse.GroupId != 0) { //pass label (field) for localization
                                    var deviceName = athoc.iws.publishing.view.setDeviceCustomText(objResponse.GroupId, objResponse.FieldId, objResponse.Value, false, field);
                                    if (deviceName && deviceName != "") {
                                        field = deviceName;
                                        if (objResponse.Label != "") {
                                            field += ' ' + objResponse.Label;
                                        }
                                    } else {
                                        field = objResponse.Label;
                                    }
                                }

                                if (objResponse.Value!="" && !athoc.iws.publishing.view.isPlaceholderReplacementModelValid(objResponse)) {
                                    isValid = false;
                                    var errorString=kendo.format(athoc.iws.publishing.resources.Publishing_Replaceholder_ErrorMessage, field, objResponse.MinLength, objResponse.MaxLength);
                                    reqError.push({ Type: '4', Value: errorString });
                                }
                            });
                        }

                        
                        if (!isValid && reqError.length > 0) {
                            $('#alertMessagePanel').messagesPanel({ messages: reqError }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                            $.AjaxLoader.hideLoader();

                        } else {
                            $.AjaxLoader.hideLoader();
                            athoc.iws.alert.detail.TestAlertSubmit(vm);
                        }
                        


                    } else {
                        reqError.push({ Type: '4', Value: data.Messages });
                        $('#alertMessagePanel').messagesPanel({ messages: athoc.iws.publishing.view.messages }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        
                        $.AjaxLoader.hideLoader();
                    }

                };

                var ajaxOptions = $.extend({}, AjaxUtility(null, ajaxSuccess).ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);

            },
            TestAlertSubmit: function (alertObj) {
                
                // Below settings are modified to target logged in operator for test alert
                // Assign devices which operator is allowed
                alertObj.TargetUsers.Devices = athoc.iws.alert.test.getModel();
                // Remove all Targeting criterias
                alertObj.TargetUsers.TargetingNodes = [];
                alertObj.TargetUsers.TargetUsersByArea = false;
                alertObj.TargetUsers.TargetedCriteria = null;
                alertObj.TargetUsers.TargetedBlockedUsers = [];
                alertObj.AlertScheduleSettings.ScheduleAlertPublishStartModeSettime = "ASAP";
                //Send view model to server for saving
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('#TestAlert'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();

                var dlAjaxOption =
                    {
                        url: athoc.iws.publishing.urls.CreateTestAlertUrl,
                        contentType: false,
                        dataType: 'json',
                        type: 'POST',
                        data: JSON.stringify(alertObj)
                    };

                var ajaxSuccess = function (data) {
                    $.AjaxLoader.hideLoader();
                    if (data.Success) {
                        $('#messagePanel').messagesPanel({ messages: [{ Type: '8', Value: data.Messages }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        $('html,body').scrollTop(-200);

                    } else {
                        $('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: data.Messages }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        $('html,body').scrollTop(-200);
                    }
                    $("#TestAlert").hide();
                    $("#testbackshade").hide();
                };

                var ajaxOptions = $.extend({}, AjaxUtility(null, ajaxSuccess).ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);

                return true;

            },


            downloadPdfFile: function (postUrl) {

                athoc.iws.publishing.detail.setChanged(false);
                var contentModel = athoc.iws.publishing.content.getModel();
                //Get updated data from each section in viewmodel
                var alertObj = {
                    Content: contentModel == undefined ? ko.mapping.toJS(athoc.iws.publishing.content.ReadonlyViewModel.data.Content) : contentModel,
                    TargetUsers: athoc.iws.publishing.targetUsers.getModel(),
                    TargetOrg: athoc.iws.publishing.targetOrg.getModel(),
                    AlertScheduleSettings: athoc.iws.publishing.settings.IsSchedulingSupported ? athoc.iws.alert.schedule.getModel() : null,
                    MassDevices: athoc.iws.publishing.massdevices.getModel() == null ? [] : athoc.iws.publishing.massdevices.getModel().MassDevices,
                    MassDeviceGroupOptions: athoc.iws.publishing.massdevices.getModel() == null ? [] : athoc.iws.publishing.massdevices.getModel().MassDeviceGroupOptions,
                };

                if (this.parameters.showOrganizations) {
                    alertObj.TargetOrg = athoc.iws.publishing.targetOrg.getModel();
                }

                //Send view model to server for saving
                var piechartData = "";
                if (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Targeting.Readonly)
                    piechartData = $("#piechartSummaryDetail").outerHTML();
                else
                    piechartData = $("#piechartSummary").outerHTML();

                // Set the data for location map
                if ($('#miniMapHolder').html() != "")
                    locationdata = $('#miniMapHolder').outerHTML();


                var param = $.param({ feed: ko.toJSON(alertObj), pieChartData: piechartData, locationData: locationdata });
                $.fileDownload(postUrl, {
                    httpMethod: "POST",
                    data: param,
                    successCallback: function () {
                    },
                    failureCallback: function () {
                    }
                });
                return true;
            },

            saveAlertDetails: function (postUrl, stayOnPage) {
                $('#alertView').find('#messagePanel').messagesPanel('reset');
           

                if (athoc.iws.alert.schedule.viewModel.isLiveAlert());
                var isValid = athoc.iws.alert.schedule.isInErrorState;

                if (isValid) {
                    $('#alertView').find('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: athoc.iws.alert.parameters.resources.Alert_Validation_SectionNotReady }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                    $('html,body').scrollTop(-200);
                    return false;
                }



                athoc.iws.publishing.detail.setChanged(false);
                var massDeviceModel = athoc.iws.publishing.massdevices.getModel();
                //If content section is readonly need to get data from Publishing.View.viewModel.data.content
                var contentModel = athoc.iws.publishing.content.getModel() == undefined ? ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.Content) : athoc.iws.publishing.content.getModel();
                //Get updated data from each section in viewmodel
                var alertObj = {
                    EntityId: athoc.iws.publishing.detail.viewModel.EntityId,
                    ParentId: athoc.iws.publishing.detail.viewModel.ParentId,
                    Content: contentModel,
                    TargetUsers: athoc.iws.publishing.targetUsers.getModel(),
                    TargetOrg: athoc.iws.publishing.targetOrg.getModel(),
                    AlertScheduleSettings: athoc.iws.alert.schedule.getModel(),
                    MassDevices: massDeviceModel == null ? [] : massDeviceModel.MassDevices,
                    MassDeviceGroupOptions: massDeviceModel == null ? [] : massDeviceModel.MassDeviceGroupOptions,
                    AllPlaceHolderIds: athoc.iws.publishing.getPlaceholderList(),
                    CustomPlaceHolders: athoc.iws.alert.placeholder.getModel(),
                    AlertOrigin: athoc.iws.publishing.detail.viewModel.AlertOrigin,
                    rbt: athoc.iws.publishing.rbt,
                };


                //Send view model to server for saving
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();

                var dlAjaxOption =
                    {
                        url: postUrl,
                        contentType: false,
                        dataType: 'json',
                        type: 'POST',
                        data: JSON.stringify(alertObj)
                    };

                var ajaxSuccess = function (data) {
                    $.AjaxLoader.hideLoader();
                    if (data.Success) {
                        //IWS12606
                        //redirect to Sent Alerts screen when Alert status is not Draft or Standby
                        if (data.Data.AlertStatus != 'Draft' && data.Data.AlertStatus != 'Standby') {
                            $('#messagePanel').messagesPanel({ messages: [{ Type: '8', Value: athoc.iws.alert.parameters.resources.Alert_SaveSuccess }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                            $('html,body').scrollTop(-200);
                            //redirectToExternalUrl('/athoc-iws/AlertManager/Index');
                            athoc.iws.publishing.createRequest('/athoc-iws/AlertManager/Index');
                            return true;
                        }
                        if (stayOnPage == undefined || stayOnPage) {
                            athoc.iws.publishing.detail.bindModel(data, true);
                            $('#alertView').find('#messagePanel').messagesPanel({ messages: [{ Type: '8', Value: athoc.iws.alert.parameters.resources.Alert_SaveSuccess }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                            $('html,body').scrollTop(-200);

                            //reset targeting selection
                            //athoc.iws.publishing.targetUsers.getTargetingSelection();
                            athoc.iws.publishing.targetUsers.load(athoc.iws.publishing.detail.viewModel.EntityId);


                        } else {
                            athoc.iws.publishing.targetUsers.Parameters.context = "Alert"; //reset context to Alert just in case you are coming from scenario publisher
                            athoc.iws.alert.list.viewAlertList(true);
                        }
                    } else {
                        $('#alertView').find('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: data.Messages }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        $('html,body').scrollTop(-200);
                    }

                };

                var ajaxOptions = $.extend({}, AjaxUtility(null, ajaxSuccess).ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);

                return true;

            },
                       
            saveReportAlertDetails: function (postUrl, stayOnPage) {
                $('#messagePanel').messagesPanel('reset');
                $('#alertView').find('#messagePanel').messagesPanel('reset');
                


                if (athoc.iws.alert.schedule.viewModel.isLiveAlert());
                var isValid = athoc.iws.alert.schedule.isInErrorState;

                if (isValid) {
                    $('#alertView').find('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: athoc.iws.alert.report.resources.Alert_Validation_SectionNotReady }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                    $('html,body').scrollTop(-200);
                    return false;
                }



                athoc.iws.publishing.detail.setChanged(false);

                var massDeviceModel = athoc.iws.publishing.massdevices.getModel();

                //If content section is readonly need to get data from Publishing.View.viewModel.data.content
                // var contentModel = athoc.iws.publishing.content.getModel() == undefined ? ko.mapping.toJS(athoc.iws.publishing.view.viewModel.data.Content) : athoc.iws.publishing.content.getModel();

                //Get updated data from each section in viewmodel
                var alertObj = {
                    EntityId: athoc.iws.publishing.detail.viewModel.EntityId,
                    ParentId: athoc.iws.publishing.detail.viewModel.ParentId,
                    AlertScheduleSettings: athoc.iws.alert.schedule.getModel(),
                    CustomPlaceHolders: athoc.iws.alert.placeholder.getModel(),
                    AlertOrigin: athoc.iws.publishing.detail.viewModel.AlertOrigin,
                    rbt: athoc.iws.publishing.rbt,
                };


                //Send view model to server for saving
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.title-bar'), imageURL: athoc.iws.publishing.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', displayText: athoc.iws.publishing.resources.General_LoadingMessage }).showLoader();

                var dlAjaxOption =
                    {
                        url: postUrl,
                        contentType: false,
                        dataType: 'json',
                        type: 'POST',
                        data: JSON.stringify(alertObj)
                    };

                var ajaxSuccess = function (data) {
                    $.AjaxLoader.hideLoader();
                    if (data.Success) {
                        //IWS12606
                        //redirect to Sent Alerts screen when Alert status is not Draft or Standby
                        if (data.Data.AlertStatus != 'Draft' && data.Data.AlertStatus != 'Standby') {
                            $('#messagePanel').messagesPanel({ messages: [{ Type: '8', Value: athoc.iws.alert.report.resources.Alert_SaveSuccess }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                            $('html,body').scrollTop(-200);
                            //redirectToExternalUrl('/athoc-iws/AlertManager/Index');
                            return true;
                        }
                        if (stayOnPage == undefined || stayOnPage) {
                            athoc.iws.publishing.detail.bindModel(data, true);
                            $('#alertView').find('#messagePanel').messagesPanel({ messages: [{ Type: '8', Value: athoc.iws.alert.report.resources.Alert_SaveSuccess }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                            $('html,body').scrollTop(-200);

                            //reset targeting selection
                            //athoc.iws.publishing.targetUsers.getTargetingSelection();
                            athoc.iws.publishing.targetUsers.load(athoc.iws.publishing.detail.viewModel.EntityId);


                        } else {
                            athoc.iws.publishing.targetUsers.Parameters.context = "Alert"; //reset context to Alert just in case you are coming from scenario publisher
                            athoc.iws.alert.list.viewAlertList(true);
                        }
                    } else {
                        $('#alertView').find('#messagePanel').messagesPanel({ messages: [{ Type: '4', Value: data.Messages }] }, undefined, undefined, undefined, athoc.iws.publishing.getErrorTitleList());
                        $('html,body').scrollTop(-200);
                    }

                };

                var ajaxOptions = $.extend({}, AjaxUtility(null, ajaxSuccess).ajaxPostOptions, dlAjaxOption);
                $.ajax(ajaxOptions);

                return true;

            },
            
        };
    }();
}