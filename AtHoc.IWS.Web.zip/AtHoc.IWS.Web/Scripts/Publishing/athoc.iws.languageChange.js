﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.languageChange = athoc.iws.languageChange || {};

if (athoc.iws.languageChange) {
    athoc.iws.languageChange = function () {
       
        return {
           
            viewModel: {

                // To add different language, just add the one more item in this list
                langsupports: [
                                { DisplayName: 'English (United States)', LangCode: 'en-US' },
                                { DisplayName: 'Français (Canada)', LangCode: 'fr-CA' }
                ],

                closePopup: function () { return athoc.iws.languageChange.closePopup(); },

                cancelPopup: function () { return athoc.iws.languageChange.cancelPopup(); },

                defaultLanguage: ko.observable(""),
            },

            getSelectedLang: ko.observable(""),
           
            closePopup: function () {

                if ($('#selectLanguage').val() != "") {
                    //cookie path is case sensitive so, we need to write cookie for each path
                    document.cookie = 'AtHoc_CurrentLanguage' + '=' + $('#selectLanguage').val() + '; path=/athoc-iws;';
                    document.cookie = 'AtHoc_CurrentLanguage' + '=' + $('#selectLanguage').val() + '; path=/AtHoc-IWS;';
                    document.cookie = 'AtHoc_CurrentLanguage' + '=' + $('#selectLanguage').val() + '; path=/athoc-iws/settings;';
                    document.cookie = 'AtHoc_CurrentLanguage' + '=' + $('#selectLanguage').val() + '; path=/AtHoc-IWS/Settings;';
                    //document.cookie = 'AtHoc_WalkMeSetLanguage=true; path=/client;';
                    //document.cookie = 'AtHoc_WalkMeSetLanguage=true; path=/Client;';
                    this.viewModel.defaultLanguage($('#selectLanguage').text());
                    this.selectedLang();
                    $('#selectLanguageModal').css({ display: 'none' });
                    // Reloading the page to call global.asax event
                    window.location.reload(true);
                }
            },
            cancelPopup: function () {
                $('#selectLanguageModal').css({ display: 'none' });
            },

            selectedLang : function(){
                var cLang = _.find(athoc.iws.languageChange.viewModel.langsupports, function (item) {
                    return item.LangCode == athoc.iws.languageChange.viewModel.defaultLanguage();
                });

                if (cLang)
                    this.getSelectedLang(cLang.DisplayName);
                else {
                    athoc.iws.languageChange.viewModel.defaultLanguage('en-US');//Default setting the english
                    this.getSelectedLang('English (United States)');
                }
            },

            load: function () {
                this.selectedLang();
                ko.cleanNode($('#selectLanguageModal').get(0));
                ko.applyBindings(athoc.iws.languageChange.viewModel, $('#selectLanguageModal').get(0));
            }
        };
    }();
}

 function ChangeLanguage() {
     athoc.iws.languageChange.viewModel.defaultLanguage(layoutJavascriptVars.currentCulture);
     $("#selectLanguageModal").modal('show');
     $('#selectLanguageModal .modal').css({ top: '32%' });
     $("#selectLanguage").selectpicker({});
 }

 function InitiateLanguageControl()
 {
     athoc.iws.languageChange.viewModel.defaultLanguage(layoutJavascriptVars.currentCulture);
     athoc.iws.languageChange.load();
     $(".languageChanger").html(athoc.iws.languageChange.getSelectedLang());
 }
