﻿/// <reference path="athoc-knockout-grid.js" />
/* define javascript namespace for Scenario */
var athoc = athoc || {};
athoc.iws = athoc.iws || {};

if (athoc.iws) {
    athoc.iws.scenario = function () {
        return {
            //Required URLs these URLs should be loaded from inline page JavaScript
            urls: {},

            //Required resources these resources should be loaded from inline page JavaScript
            resources: {},

            //init method for scenario list, will be triggered before document load
            init: function (targetUsersParameters, deviceOptionParameters, massDeviceParameters) {
                athoc.iws.scenario.initBreadcrumb();
                navigateToPage('scenarioList', function () { });

                athoc.iws.publishing.targetUsers.init(targetUsersParameters);
                athoc.iws.publishing.personalDeviceOptions.init(deviceOptionParameters);
                athoc.iws.publishing.massdevices.init(massDeviceParameters);


                var orgParameters = {
                    resources: athoc.iws.scenario.resources,
                    context: "Scenario",
                    orgSectionDivs: {
                        noOrganizationDiv: "#noOrganizationDiv",
                        organizationTableDiv: "#organizationTableDiv",
                        targetOrgStatus: "#targetOrgStatus",
                        targetOrgSection: "#targetOrgSection",
                        targetedOrgCount: "#targetedOrgCount"
                    }

                }
                athoc.iws.publishing.targetOrg.init(orgParameters);

            },

            //load method, will be tirggered on document load
            load: function () {
                athoc.iws.scenario.bindBreadcrumb();

                $("#scenario-button").click(function () {
                    var id = $("#scenario-id").val();
                    if ($.isNumeric(id)) {
                        athoc.iws.scenario.viewScenarioDetail(id);
                    }
                });

                $("#btn_new").click(function () { athoc.iws.scenario.createScenario(); });

                $("#btn_duplicate").click(function () { athoc.iws.scenario.duplicateScenario(); });

                $("#btn_cancel_detail").click(function () {
                    athoc.iws.scenario.viewScenarioList();
                });
                $("#deleteCancelScenarioButton").click(function () { $("#deleteScenario").modal('hide'); });              
                $("#btn_save").click(function () { athoc.iws.scenario.detail.saveScenario(); });

                athoc.iws.scenario.list.load();

                window.onbeforeunload = function (event) {
                    var isModified = athoc.iws.publishing.detail.isChanged();

                    if (isModified) {
                        return athoc.iws.publishing.resources.Unsaved_Data_Text;
                    }
                };

            },

            //breadcrumb model! 
            breadcrumbModel: new BreadcrumbModel(),

            initBreadcrumb: function () {
                var sn = athoc.iws.scenario;

                //Page Breadcrumb Knockout Model
                var breadcrumbsModel = sn.breadcrumbModel;

                //Sub-level breadcrumb
                var scenarioListBreadCrumb = new Breadcrumb('dlLink', sn.resources.Scenario_Breadcrumb_ScenarioList, '', function () {
                    athoc.iws.scenario.viewScenarioList();
                });

                var scenarioDetailBreadCrumb = new Breadcrumb('dlViewLink', '', '', function () {
                    athoc.iws.scenario.showDetail();
                });

                //Page breadcrumb
                var scenarioListPageBreadcrumb = new PageBreadcrumb('scenarioList', sn.resources.Scenario_Breadcrumb_ScenarioList, [], '');
                var dlViewPageBreadcrumb = new PageBreadcrumb('scenarioDetail', '', [scenarioListBreadCrumb], '');

                breadcrumbsModel.addPage(scenarioListPageBreadcrumb);
                breadcrumbsModel.addPage(dlViewPageBreadcrumb);
            },

            bindBreadcrumb: function () {
                var breadcrumbsModel = athoc.iws.scenario.breadcrumbModel;
                breadcrumbsModel.SelectedPage('scenarioList');

                var pageBreadcrumbDiv = document.getElementById('pageBreadcrumbs');
                ko.applyBindings(breadcrumbsModel, pageBreadcrumbDiv);
                $.titleCrumb("pageBreadcrumbs");
            },

            refreshList: false,

            viewScenarioList: function (refresh) {
                var isModified = athoc.iws.publishing.detail.isChanged();

                if (isModified == true) {
                    var confirmLeave = confirm(athoc.iws.scenario.resources.Unsaved_Data_Text);
                    if (!confirmLeave) {
                        return;
                    } else {
                        athoc.iws.publishing.targetUsers.resetTargetingInfo();
                    }
                } else {
                    athoc.iws.publishing.targetUsers.resetTargetingInfo();
                }

                athoc.iws.publishing.detail.setChanged(false);

                navigateToPage('scenarioList', function () { });

                var breadcrumbsModel = athoc.iws.scenario.breadcrumbModel;
                breadcrumbsModel.SelectedPage('scenarioList');
                $.titleCrumb("pageBreadcrumbs");
                $(document).scrollTop(0);

                if (refresh || this.refreshList) {
                    athoc.iws.scenario.list.refreshGrid();
                }
                this.refreshList = false;
            },

            viewScenarioDetail: function (id) {
                $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.table-crown-wrap'), imageURL: athoc.iws.scenario.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 2000, displayText: athoc.iws.scenario.resources.General_LoadingMessage }).showLoader();

                $(".publishing-detail").hide();
                navigateToPage('scenarioDetail', function () { });
                var breadcrumbsModel = athoc.iws.scenario.breadcrumbModel;
                breadcrumbsModel.SelectedPage('scenarioDetail');
                $.titleCrumb("pageBreadcrumbs");
                $(document).scrollTop(0);

                $.AjaxLoader.hideLoader();

                athoc.iws.scenario.detail.editScenario(id);
            },

            createScenario: function () {
                $(".publishing-detail").hide();
                navigateToPage('scenarioDetail', function () { });

                var breadcrumbsModel = athoc.iws.scenario.breadcrumbModel;
                breadcrumbsModel.SelectedPage('scenarioDetail');
                $.titleCrumb("pageBreadcrumbs");
                $(document).scrollTop(0);
                $.AjaxLoader.hideLoader();

                athoc.iws.scenario.detail.createScenario();
            },

            duplicateScenario: function () {
                var id = athoc.iws.scenario.list.getSingleSelection();

                if (id <= 0)
                    return;

                $(".publishing-detail").hide();
                navigateToPage('scenarioDetail', function () { });

                var breadcrumbsModel = athoc.iws.scenario.breadcrumbModel;
                breadcrumbsModel.SelectedPage('scenarioDetail');
                $.titleCrumb("pageBreadcrumbs");
                $(document).scrollTop(0);
                $.AjaxLoader.hideLoader();

                athoc.iws.scenario.detail.duplicateScenario(id);
            },

            deleteScenario: function (ids, names, deleteSuccessCallback) {
                var self = this;

                var nameTags = "";
                names.sort();
                for (var i = 0; i < names.length; i++) {

                    nameTags += "<div class='pseudo-li ellipsis mar-left10' title='" + $.htmlEncode(names[i]).replace(/'/g, "&#39;") + "'>" + $.htmlEncode(names[i]) + "</div>";
                }


                $("#itemsToDelete").html("<div class='mar-top10'>" + nameTags + "</div>");
                $('#deleteScenario').modal('show');


                $('#deleteScenarioButton').off('click').on('click', function (e) {
                    $('#deleteScenario').modal('hide');
                    $.AjaxLoader.setup({ useBlock: true, idToShow: undefined, elementToBlock: $('.table-crown-wrap'), imageURL: athoc.iws.scenario.urls.cdnUrl + '/Images/ajax-loader.gif', top: '200px', left: '50%', zIndex: 1200, displayText: athoc.iws.scenario.resources.General_LoadingMessage }).showLoader();

                    var myAjaxOptions = {
                        url: athoc.iws.scenario.urls.DeleteScenarioUrl,
                        contentType: 'application/json',
                        dataType: 'json',
                        data: JSON.stringify(ids),
                        type: 'POST',
                    };

                    $.AjaxLoader.hideLoader();

                    var onSuccess = function () {
                        if (typeof deleteSuccessCallback == "function") {
                            deleteSuccessCallback();
                        }
                    }

                    var ajaxOptions = $.extend({}, AjaxUtility(null, onSuccess).ajaxPostOptions, myAjaxOptions);
                    $.ajax(ajaxOptions);

                });


            }
        };
    }();
}