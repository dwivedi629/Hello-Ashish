﻿var athoc = athoc || {};
athoc.iws = athoc.iws || {};
athoc.iws.publishing = athoc.iws.publishing || {};

if (athoc.iws.publishing) {
    athoc.iws.publishing.targetOrg = function () {
        return {
            Parameters: {},
            //AtHoc.IWS.Web.Controllers.OrganizationController.OrganizatioSearchParameters
            //OrgSearchParameters:{},
            //DataSource: null,
            //ViewModel: {},
            //Message: "",
            OrgViewModel: null,
            OrgInfoHolder: null,
            //is section ready to publish
            isReadyToPublish: false,
            getOrgConnectedStatus: true,
            showOrganizations: true,
            load: function (orgSelection) {
                var self = this;

                if (!self.OrgViewModel) {
                    return;
                }                

                self.OrgViewModel.Reset();

                kendo.ui.progress($(self.Parameters.orgSectionDivs.targetOrgSection), true);

                ko.mapping.fromJS(orgSelection.TargetAllOrganizations, {}, self.OrgViewModel.TargetAllOrg);
                ko.mapping.fromJS(orgSelection.TargetOrganizationsByArea, {}, self.OrgViewModel.TargetOrgByArea);

                //making a single ajax call to get targeting tree and device data
                var orgInfoSuccess = function (data) {

                    if (self.getOrgConnectedStatus) {
                        self.showOrganizations = data.ShowOrgs; //reset this flag only first time
                    }

                    if (self.showOrganizations) {
                        if (data.Organizations.length == 0) {
                            $(self.Parameters.orgSectionDivs.noOrganizationDiv).show();
                            $(self.Parameters.orgSectionDivs.organizationTableDiv).hide();
                        } else {
                            $(self.Parameters.orgSectionDivs.noOrganizationDiv).hide();
                            $(self.Parameters.orgSectionDivs.organizationTableDiv).show();

                            var ids = $.map(orgSelection.TargetedOrganizations.filter(function (to) { return !to.GeoSelected; }), function (org) {
                                return org.UserId;
                            });
                            _.each(data.Organizations, function (org) {
                                if ($.inArray(org.UserId, ids) != -1) {
                                    org.Selected = true;
                                }
                            });
                            var userIds = $.map(orgSelection.TargetedOrganizations.filter(function (to) { return to.GeoSelected; }), function (org) {
                                return org.UserId;
                            });
                            var toByArea = $.map(data.Organizations.filter(function (o) { return $.inArray(o.UserId, userIds) != -1; }), function (org) {
                                return org.Id;
                            });
                            self.OrgViewModel.SelectedOrgsByArea(toByArea);
                            self.OrgViewModel.OrgCountByArea(toByArea.length);
                        }
                    } else {
                        $(self.Parameters.orgSectionDivs.noOrganizationDiv).show();
                        $(self.Parameters.orgSectionDivs.organizationTableDiv).hide();
                    }

                    ko.mapping.fromJS(data.Organizations, {}, self.OrgViewModel.Organizations);
                    if (self.OrgViewModel.TargetAllOrg()) {
                        if ((athoc.iws.scenario.settings.viewModel.scenariosettings.Organization && athoc.iws.scenario.settings.viewModel.scenariosettings.Organization.TargetByNameEnabled) || (athoc.iws.scenario.settings.ReadonlyViewModel.applysettings && athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Organization.TargetByNameEnabled))
                            self.OrgViewModel.SelectAll();
                        else
                            self.OrgViewModel.ClearAll();
                        self.OrgViewModel.TargetOrgByArea(true);
                    }

                    self.OrgViewModel.UpdateTargetedOrgStatus();

                    self.getOrgConnectedStatus = false;

                    kendo.ui.progress($(self.Parameters.orgSectionDivs.targetOrgSection), false);

                };

                var ajaxOptions = {
                    cache: false,
                    url: athoc.iws.publishing.urls.GetTargetableOrganizationsUrl,
                    data: { getVPSConnectedStatus: self.getOrgConnectedStatus },
                    type: "POST"
                };


                var ajaxOptions = $.extend({}, AjaxUtility(null, orgInfoSuccess).ajaxPostOptions, ajaxOptions);
                $.ajax(ajaxOptions);

            },
            init: function (parameters) {
                var context = this;
                this.Parameters = parameters;


                var orgVM = function (context) {
                    var self = this;

                    self.TargetAllOrg = ko.observable(false);

                    self.TargetAllOrg.subscribe(function (newValue) {
                        var overlay = '<div class="overlay-light-grey" style="display:block"></div>';
                        athoc.iws.publishing.scenario.isChanged = true;
                        if (newValue) {
                            if ((athoc.iws.scenario.settings.viewModel.scenariosettings.Organization && athoc.iws.scenario.settings.viewModel.scenariosettings.Organization.TargetByNameEnabled)
                                ||(athoc.iws.scenario.settings.ReadonlyViewModel.applysettings && athoc.iws.scenario.settings.ReadonlyViewModel.applysettings.Organization.TargetByNameEnabled))
                                self.SelectAll();
                            self.TargetOrgByArea(self.TargetOrgByAreaVisible());
                                $("#organizationList").scrollTop(0);
                                $("#organizationList").css("overflowY", "hidden");
                                $("#organizationList").append(overlay);
                                $("#divTargetOrgByArea").append(overlay);
                                $("#targetOrgByName").find("button").prop("disabled", true);
                            
                           

                        } else {
                            self.ClearAll();
                            $("#organizationList").css("overflowY", "auto");
                            $("#organizationList").find(".overlay-light-grey").remove();
                            $("#divTargetOrgByArea").find(".overlay-light-grey").remove();
                            $("#targetOrgByName").find("button").prop("disabled", false);
                        }
                    });

                    self.TargetOrgByArea = ko.observable(false);

                    self.TargetOrgByArea.subscribe(function (newValue) {
                        
                        athoc.iws.publishing.geo.viewModel.isOrganizationsTargeted(newValue);
                        self.UpdateTargetedOrgStatus();

                    });

                    self.TargetOrgByAreaVisible = function () {
                        return athoc.iws.publishing.geo.viewModel.isGeoSelected();
                    };

                    self.Organizations = ko.observableArray();

                    self.OrgSelected = ko.pureComputed(function () {

                        var ret = self.Organizations().filter(function (el) {
                            return el.Selected();
                        });

                        return ko.toJS(ret).map(function (o) { return o.Id; });
                    });

                    self.TargetedOrgCountByArea = ko.pureComputed(function () {
                        return self.TargetOrgByArea() && athoc.iws.publishing.settings.IsTargetByAreaSupported ? self.OrgCountByArea() : 0;
                    });

                    self.SelectedOrgsByArea = ko.observableArray([]);
                    self.SelectedOrgsByArea.subscribe(function (newValue) {
                        self.UpdateTargetedOrgStatus();
                    });

                    self.OrgCountByArea = ko.observable(0);
                    self.OrgCountByArea.subscribe(function (newValue) {
                        self.UpdateTargetedOrgStatus();
                    });

                    self.OrgCountTotal = ko.pureComputed(function () {
                        var ret = self.OrgSelected();
                        if (self.TargetOrgByArea() && athoc.iws.publishing.settings.IsTargetByAreaSupported) {
                            ret = ret.concat(self.SelectedOrgsByArea());
                            var existingIDs = [];
                            ret = $.grep(ret, function (id) {
                                if ($.inArray(id, existingIDs) !== -1) {
                                    return false;
                                }
                                else {
                                    existingIDs.push(id);
                                    return true;
                                }
                            });
                        }
                        return ret.length;
                    });

                    self.OrgChanged = function () {

                        // athoc.iws.publishing.scenario.isChanged = true;                       
                        self.UpdateTargetedOrgStatus();

                        return true;
                    };

                    self.SelectAll = function () {
                        _.each(self.Organizations(), function (org) {
                            org.Selected(true);
                        });
                        self.OrgChanged();
                    };

                    self.ClearAll = function () {
                        _.each(self.Organizations(), function (org) {
                            org.Selected(false);
                        });
                        self.OrgChanged();
                    };


                    self.ShowDetails = function (selectedOrg) {

                        require(['widget/OrgInfo'], function (OrgInfo) {
                            if (context.OrgInfoHolder == null) {
                                $('<div id="orgInfoHolder"></div>').appendTo("body");
                                context.OrgInfoHolder = new OrgInfo("orgInfoHolder");
                                context.OrgInfoHolder.startup();
                            }

                            context.OrgInfoHolder.update({ orgId: selectedOrg.Id(), orgName: selectedOrg.Name() });
                        });


                        return true;
                    }


                    self.UpdateTargetedOrgStatus = function () {
                        if (self.OrgSelected().length > 0 || (self.TargetOrgByArea() && self.SelectedOrgsByArea() && self.SelectedOrgsByArea().length > 0)) {
                            athoc.iws.publishing.SetSectionStatus(parameters.orgSectionDivs.targetOrgStatus, "ready");
                            athoc.iws.publishing.targetOrg.isReadyToPublish = true;
                        } else {
                            athoc.iws.publishing.SetSectionStatus(parameters.orgSectionDivs.targetOrgStatus, "open");
                            athoc.iws.publishing.targetOrg.isReadyToPublish = false;
                        }
                        athoc.iws.publishing.detail.checkStatusChange();
                    }

                    self.Reset = function () {
                        self.Organizations([]);
                    };

                };

                this.OrgViewModel = new orgVM(this);

                ko.cleanNode($(this.Parameters.orgSectionDivs.targetOrgSection).get(0));
                ko.applyBindings(this.OrgViewModel, $(this.Parameters.orgSectionDivs.targetOrgSection).get(0));

              
               

            },
            getModel: function () {
                //convert viewmodel to the format that will be set to server side with all of other sections. 
                var checkedOrganizations = new Array();
                if (this.showOrganizations) {
                    checkedOrganizations = ko.mapping.toJS(this.OrgViewModel.Organizations).filter(function (el) {
                        return el.Selected;
                    });

                    if (this.OrgViewModel.TargetOrgByArea()) {
                        var allOrgs = ko.mapping.toJS(this.OrgViewModel.Organizations);
                        _.each(this.OrgViewModel.SelectedOrgsByArea(), function (itemId) {
                            var foundOrg = _.find(allOrgs, function (orgItem) {
                                return orgItem.Id === itemId;
                            });
                            if (foundOrg) {
                                //foundOrg.Selected(true);
                                foundOrg.GeoSelected = true;
                                checkedOrganizations.push(ko.mapping.toJS(foundOrg));
                            }

                            //var orgAlreadyExist = _.find(checkedOrganizations, function(item) {
                            //    return itemId === item.Id;
                            //});
                            //if (!orgAlreadyExist) {
                            //    var foundOrg = _.find(allOrgs, function(orgItem) {
                            //        return orgItem.Id() === itemId;
                            //    });
                            //    if (foundOrg) {
                            //        foundOrg.Selected(true);
                            //        foundOrg.GeoSelected(true);
                            //        checkedOrganizations.push(ko.mapping.toJS(foundOrg));
                            //    }
                            //}
                        });
                    }
                }
                return {
                    TargetedOrganizations: checkedOrganizations,
                    TargetAllOrganizations: this.OrgViewModel.TargetAllOrg(),
                    TargetOrganizationsByArea: this.OrgViewModel.TargetOrgByArea()
                };
            },

            bindReadOnlyViewModel: function (data, targetDiv) {
                var vm = kendo.observable(
                  {
                      Organizations: [],
                      CombinedOrgs: function () {
                          var ret = this.get("Organizations");
                          var existingIDs = [];
                          ret = $.grep(ret, function (o) {
                              if ($.inArray(o.UserId, existingIDs) !== -1) {
                                  return false;
                              } else {
                                  existingIDs.push(o.UserId);
                                  return true;
                              }
                          });
                          return ret;
                      },
                      OrgCountText: function () {
                          var orgs = this.CombinedOrgs();
                          return kendo.format(athoc.iws.publishing.resources.Publishing_TargetOrg_TargetOrganizations, orgs.length);
                      },
                      Visible: function () {
                          return this.get("Organizations").length > 0;
                      }
                  });
                vm.set("Organizations", data);
                //targetDiv.find("#targetOrgDetail")
                kendo.bind(targetDiv.find(".kOrgBound"), vm);
            },
        };
    }();
}
